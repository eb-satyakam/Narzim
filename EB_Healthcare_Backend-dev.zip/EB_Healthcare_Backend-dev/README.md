# Remedisys Healthcare Backend

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.2
> Frappe v16 custom app powering the Remedisys clinical platform — a multi-tenant Healthcare SaaS for pediatric clinics in Mexico and India (ADR-018).

**Stack:** Frappe v16 · ERPNext Healthcare · MariaDB 11+ · Redis 7+ · Python 3.14+
**Deployment:** Frappe Cloud
**Jurisdiction:** India + Mexico — pluggable via `ComplianceProfile` (ADR-018). Default `mx` = LFPDPPP + NOM-024-SSA3-2010; `in` = DPDPA 2023 + ABDM
**Frontend:** `Healthcare_next_app` (Next.js 14, separate repo)
**AI:** OpenAI `gpt-5-mini` + Deepgram `nova-3` — **live in production**

---

## Build status

**Status lives in exactly one document:** [`docs/STATUS.md`](./docs/STATUS.md) — phase state, what is
live in production, counts measured on `marley.local`, the open P0 queue, and the decisions waiting on
a person.

It was previously restated here and in seven other places, last updated across six different dates,
the oldest two months stale. Whichever a reader opened first became "the current state". This README
now points rather than repeats — see `CLAUDE.md` §9 (one fact, one owner).

> **⚠️ The build order was not followed, and that matters when reading the older planning docs.**
> `CLAUDE.md` and `ROADMAP.md` state that AI must not start until Phases 0–4 are complete. AI capture
> shipped **2026-05-15** and the agent went live around **2026-07-23**, while Phase 4 is still
> partial. This is a durable fact about the project's history, not a status, which is why it stays
> here.
>
> **Do not plan from `CLAUDE.md` §6/§8/§12 for anything AI-related** — those sections describe a repo
> layout, a phase order and a current state that have all moved on. Use [`docs/ai/`](./docs/ai/):
> [`REMEDISYS_AI_MASTER_PLAN.md`](./docs/ai/REMEDISYS_AI_MASTER_PLAN.md) for the plan and
> [`CURRENT_SYSTEM_AUDIT.md`](./docs/ai/CURRENT_SYSTEM_AUDIT.md) for what is actually true with
> `file:line` evidence. [`DECISION_LOG.md`](./docs/ai/DECISION_LOG.md) records how the divergence
> happened. For the encounter specifically, start with
> [`docs/audit/practitioner/screens/03-encounter-deep-audit.md`](docs/_archive/audit-screens/practitioner/03-encounter-deep-audit.md).

---

## Documentation rules and gates

Every `.md` in this repo carries a provenance header and is covered by five CI gates. Full rules in
[`CLAUDE.md`](./CLAUDE.md) §9–§10; the enforcement:

```bash
python3 scripts/check_md_headers.py                 # header + Doc status: present and valid
python3 scripts/check_md_links.py                   # every relative link resolves
python3 scripts/check_version_bump.py --staged      # living docs versioned when they change
python3 scripts/gen_doc_indexes.py --check          # no directory index is stale
python3 scripts/check_adr_numbering.py --extra-root ../../../Healthcare_next_app
```

`Doc status:` tells you whether to trust a document: **`living`** must be current (if it is wrong,
that is a bug) · **`record`** is a dated snapshot, **frozen and stale by design — never "correct" it**
· `superseded` names its replacement · `draft` is not yet decided.

Decisions are indexed in [`docs/adr/README.md`](./docs/adr/README.md). **Cite an ADR by filename, not
by number** — nine numbers identify two different decisions each, frozen by
[ADR-042](./docs/adr/adr-043-adr-identity-is-the-filename.md).

---

## Architecture

All data access goes through custom whitelisted methods only — no Frappe `/api/resource/` endpoints.

```
Next.js BFF (Vercel)
    ↓  Authorization: Bearer token (eb_frappe_jwt)
Frappe Cloud
    ↓  api/v1/<module>/api.py  (permission check + delegate)
    ↓  services/<module>.py    (business logic + Frappe ORM)
    ↓  MariaDB 11+
```

Authentication: **eb_frappe_jwt** Bearer JWT (ADR-011). Tokens live server-side in NextAuth — browser never sees a JWT.

### AI path (Phase 5 — live)

```
Browser mic ──► Deepgram (nova-3, direct WSS — audio never touches Frappe)
                    ↓  transcript + speaker roles
Next.js BFF ──► api/v1/ai/api.py::ask_copilot        ← the ONE agent
                    ↓  services/ai_tools.py — 36 curated tools (13 read / 23 write)
                OpenAI gpt-5-mini, ≤20 tool round-trips
                    ↓  write tools return SUGGESTIONS, never DB writes
                Physician reviews the draft
                    ↓  save_draft() re-validates every field against masters
                complete_encounter() → docstatus 0 → 1
```

"Analyze" and "Ask Narzim AI" are **two interfaces over the same agent** — `analyze_encounter()`
calls `ask_copilot()` with a fixed instruction string. Same model, same tools, same prompt.

---

## Installation

```bash
# Prerequisites: bench, frappe, erpnext, healthcare, eb_frappe_jwt installed
cd $PATH_TO_YOUR_BENCH
bench get-app https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend --branch main
bench install-app remedisys_healthcare_ai

# Set JWT secret
bench set-config eb_jwt_secret "$(openssl rand -base64 32)"
```

### Required apps

```
frappe              >= 16
erpnext             >= 16
healthcare          >= 16
payments            (ERPNext payments)
eb_frappe_jwt       (Bearer JWT auth — ADR-011)
```

### CORS (dev)

```json
// sites/common_site_config.json
{ "allow_cors": "http://localhost:3000" }
```

---

## Local Development

```bash
# Activate virtualenv
source /PATH_TO_BENCH/env/bin/activate

# Start bench
cd /PATH_TO_BENCH && bench start

# Run all tests
bench --site YOUR_SITE run-tests --app remedisys_healthcare_ai

# Run a single module
bench --site YOUR_SITE run-tests --app remedisys_healthcare_ai \
    --module remedisys_healthcare_ai.tests.auth.test_auth
```

**Local site:** `marley.local:8003` (team default)

---

## Code Quality

```bash
pip install pre-commit
pre-commit install

# Manual run
ruff check .            # Python linting
mypy .                  # Python types (strict on app/)
```

---

## Key Documentation

| Document | Purpose |
|---|---|
| [`CLAUDE.md`](./CLAUDE.md) | Engineering constitution — rules, locked assumptions, working style. ⚠️ **§6 (repo layout), §8 (phase order) and §12 (current state) are stale** — they state facts that have moved on. The rules themselves (§1–§5, §9–§11) are current |
| [`ROADMAP.md`](./ROADMAP.md) | Full product roadmap — every screen, every feature, all phases. ⚠️ **AI sections are stale** |
| **[`docs/ai/README.md`](./docs/ai/README.md)** | **★ AI documentation index — start here for anything AI.** Master plan · explainer · audit · decision log |
| [`docs/planning/PLANNING.md`](./docs/planning/PLANNING.md) | Current state — what is built, what is not, what to build next |
| [`docs/api/API_SPEC.md`](./docs/api/API_SPEC.md) | API contract — request/response shapes. ⚠️ Method count is stale: `api/v1/ai/` + `api/ai/` alone expose 63 whitelisted methods |
| [`docs/architecture/SYSTEM_DESIGN.md`](./docs/architecture/SYSTEM_DESIGN.md) | System architecture — auth, DocTypes, permissions |
| [`docs/planning/PHASES.md`](./docs/planning/PHASES.md) | Build phases — exit gates, dependency chain |
| [`docs/architecture/BACKEND_ARCHITECTURE.md`](./docs/architecture/BACKEND_ARCHITECTURE.md) | Code patterns — two-layer arch, folder structure |
| [`docs/architecture/ROLES_AND_PERMISSIONS.md`](./docs/architecture/ROLES_AND_PERMISSIONS.md) | Custom Frappe roles, capability matrix |
| [`docs/api/FRONTEND_API_GAP_CHECKLIST.md`](./docs/api/FRONTEND_API_GAP_CHECKLIST.md) | Gap analysis — what frontend needs vs. what is built |
| [`docs/adr/`](./docs/adr/) | Architecture Decision Records |

---

## Repository Layout

```
remedisys_healthcare_ai/
├── CLAUDE.md                          ← Engineering constitution
├── ROADMAP.md                         ← Product roadmap
├── CONTRIBUTING.md                    ← Branching + PR rules
│
├── docs/                              ← All backend documentation
│   ├── README.md                      ← ★ Docs index (start here)
│   ├── planning/                      ← PLANNING.md · PHASES.md · SPRINT.md · AUTH_INTEGRATION_PLAN.md
│   ├── architecture/                  ← SYSTEM_DESIGN.md · BACKEND_ARCHITECTURE.md · FRONTEND_CONTRACT.md · ROLES_AND_PERMISSIONS.md
│   ├── api/                           ← API_SPEC.md · FRONTEND_API_GAP_CHECKLIST.md
│   ├── flows/                         ← WORKFLOWS.md · FLOWS_AUTH.md · FLOWS_REFERRAL_OUT.md
│   ├── ai/                            ← ★ AI docs — master plan · explainer · audit · decision log
│   └── adr/                           ← Architecture Decision Records (adr-003 → adr-039)
│
├── remedisys_healthcare_ai/           ← Python package
│   ├── api/
│   │   ├── v1/                        ← Clinical APIs (whitelisted methods)
│   │   │   ├── auth/api.py            ← ✅ get_current_user()
│   │   │   ├── patients/api.py        ← ✅ Full patient + Patient 360
│   │   │   ├── appointments/api.py    ← ✅ Full booking lifecycle
│   │   │   ├── encounters/api.py      ← ✅ Full encounter lifecycle
│   │   │   ├── dashboard/api.py       ← ✅ KPI + room queue
│   │   │   ├── providers/api.py       ← ✅ List + get
│   │   │   ├── vital_signs/api.py     ← ✅ Vitals with BMI/BP calc
│   │   │   ├── labs/api.py            ← ✅ Orders + results
│   │   │   ├── immunizations/api.py   ← ✅ Mexico EPI schedule
│   │   │   ├── clinical/api.py        ← ✅ Allergies + conditions
│   │   │   ├── billing/api.py         ← ✅ Invoices + payments
│   │   │   ├── insurance/api.py       ← ⚠️ Partial (4 methods)
│   │   │   ├── notifications/api.py   ← ✅ Built (16 methods)
│   │   │   ├── tasks/api.py           ← ✅ Built (18 methods)
│   │   │   ├── inbox/api.py           ← ✅ Built (3 methods)
│   │   │   ├── ai/api.py              ← ✅ LIVE — 1,778 lines, Encounter Copilot
│   │   │   └── … admin · documents · messages · nursing · patient_portal ·
│   │   │         procedures · prescriptions · notes · company · narzim_assistant
│   │   └── ai/                        ← ✅ LIVE — sessions · segments · realtime ·
│   │                                     lab + imaging extraction · patient summary
│   ├── services/                      ← Business logic (~13,200 lines — NOT stubs)
│   │   ├── ai_tools.py                ← ✅ TOOL_REGISTRY — the 36 curated AI tools
│   │   ├── ai.py                      ← ✅ Context builder · prompt log · fingerprint
│   │   ├── patient_clinical_summary.py ← ✅ Rolling cross-encounter summary
│   │   ├── transcript_digest.py       ← ✅ Deterministic digest (no LLM, no embeddings)
│   │   ├── clinical_lexicon.py        ← ✅ Catalog-derived clinical vocabulary
│   │   ├── pii_redaction.py           ← ✅ Local deterministic PHI masking
│   │   └── billing · labs · providers · lab_result_summary · …  ← ✅ Built
│   ├── integrations/                  ← ✅ openai.py · anthropic.py · deepgram.py · llm.py
│   └── tests/                         ← pytest test suites
│
├── bruno/                             ← API collection (Bruno)
└── .github/workflows/                 ← CI: unit tests + install/uninstall
```

---

## License

MIT
   

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-25 | Satyakam (AI-assisted) | Links repointed: session transcripts and screen audits moved to `docs/_archive/` |
| 1.1 | 2026-08-20 | Sarvesh-SocialAngel (AI-assisted) | Build-status table replaced by a pointer to docs/STATUS.md (one fact, one owner); added the Documentation rules and gates section |
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
