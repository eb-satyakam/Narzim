# WhatsApp Integration — Remedisys Healthcare Platform

**Doc status:** living · **Created:** 2026-06-20 by Invincible · **Updated:** 2026-09-28 by Ashutosh (AI-assisted) · **Version:** 2.2

> ## ⚠️ READ THIS FIRST — the channel changed shape on 2026-09-04
>
> This document was written when WhatsApp was a **two-way chat with personalised
> templates**. It is now a **consent-gated, template-only notification channel**, and several
> sections below described behaviour that has since been deliberately removed. They are corrected
> in place; this banner exists so nothing here is read as current without knowing what moved.
>
> **What changed:**
>
> | Was | Now |
> |---|---|
> | Staff replied free-form inside Meta's 24-hour window | **No free text at all.** Five backend paths refuse and both composers are gone. The 24h window no longer affects outbound |
> | Staff could attach files; the encounter PDF could be sent | **Both removed.** The PDF path was the largest single disclosure in the system |
> | Ten templates carrying patient name, doctor name, test name, invoice amount | **Seven templates carrying appointment date/time and clinic identity only.** The five PHI-bearing configs are deleted by a patch |
> | Possession of a mobile number was treated as permission | **Consent is required**, recorded per number, checked server-side on every send |
> | §15's PHI table allowed patient and doctor names | **Refused by code.** `phi_policy.py` rejects them on save |
>
> **Ownership, so the two documents cannot drift (`CLAUDE.md` §9, one fact one owner):**
>
> | Concern | Owner |
> |---|---|
> | Why the channel is permissible, the consent model, the template catalogue, what Meta must provide, go-live steps | [`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) |
> | The consent record's rules and schema | [`adr/adr-060-patient-communication-consent.md`](adr/adr-060-patient-communication-consent.md) |
> | **This document** — how the integration works mechanically: `frappe_whatsapp`, the doctypes, the dispatch flow, multi-tenancy, setup steps | here |

> **Audience:** Backend + Frontend developers
> **Status:** Approved for implementation — Phase 4
> **Last updated:** 2026-06-20
> **Owner:** Backend team
> **Decision:** `frappe_whatsapp` (infrastructure) + `Remedisys WhatsApp Notification` (our custom UI-configurable trigger system) + thin chat layer (conversation management + Next.js inbox)

---

## Table of Contents

1. [Decision Summary](#1-decision-summary)
2. [What We Are Building](#2-what-we-are-building)
3. [User Stories with Examples](#3-user-stories-with-examples)
4. [Architecture](#4-architecture)
5. [frappe_whatsapp — What It Handles](#5-frappe_whatsapp--what-it-handles)
6. [Our Layer — What We Build](#6-our-layer--what-we-build)
7. [DocTypes](#7-doctypes)
8. [Notification Configuration System](#8-notification-configuration-system)
9. [Message Templates](#9-message-templates)
10. [API Endpoints](#10-api-endpoints)
11. [Frontend BFF Routes](#11-frontend-bff-routes)
12. [Multi-Tenant Design](#12-multi-tenant-design)
13. [Step-by-Step Integration](#13-step-by-step-integration)
14. [Error Handling and Retry](#14-error-handling-and-retry)
15. [PHI Rules](#15-phi-rules)
16. [Testing Checklist](#16-testing-checklist)

---

## 1. Decision Summary

### Chosen approach: `frappe_whatsapp` (infrastructure) + custom notification system + thin chat layer

| Layer | Tool | Reason |
|---|---|---|
| WhatsApp API client | `frappe_whatsapp` (Meta Cloud direct) | Webhook handler, message storage, template registry — built and tested |
| Event-triggered notifications | `Remedisys WhatsApp Notification` (our custom DocType) | frappe_whatsapp's built-in notification renders a Jinja string — Meta templates need an ordered variable array. We need full control. |
| Chat conversation management | `WhatsApp Conversation` + `chat_api.py` (our app) | frappe_whatsapp has no chat inbox for Next.js — we build a thin layer on top |
| Real-time push to Next.js | **SSE, via the `notify()` chokepoint** (2026-08-25) | Superseded the 15-second poll. An inbound WhatsApp message now raises a notification and wakes the staff browser within about a second. Previously it notified **nobody** — staff only found out by already having the inbox open. See [`PUSH_NOTIFICATIONS.md`](PUSH_NOTIFICATIONS.md) §4.5 |
| Chat UI | Next.js Screen 16 | Our frontend — calls our BFF routes |

### What we do NOT install

- `whatsapp_chat` (companion to frappe_whatsapp) — uses Frappe Desk + Socket.IO; our frontend is Next.js on Vercel, different domain, Socket.IO cannot reach it.
- `clefincode_chat` — 43 doctypes, heavy deps (moviepy, pydub), designed for single-business Frappe Desk use.
- ~~Firebase (Phase 4) — polling every 15s is sufficient.~~ **Superseded 2026-08-25.** Firebase Cloud
  Messaging *is* now used, for out-of-app push, and the 15s polling is gone. WhatsApp inbound rides the
  same `notify()` chokepoint as every other notification — see
  [`adr/adr-045-push-notifications-fcm-and-sse.md`](adr/adr-045-push-notifications-fcm-and-sse.md).
  Note push reaches *staff* only once EHR push is built; that is deliberately deferred.

### Why we do NOT use frappe_whatsapp's `WhatsApp Notification`

frappe_whatsapp's notification has a `Message` field that renders a Jinja string. Meta's Cloud API requires two different call shapes:

- **Free-text message** — plain string body, only works within the 24h patient reply window
- **Template message** — ordered variable array `["Juan García", "21 Jun 2026", "10:30"]`, works anytime

All clinic notifications (appointment confirmation, lab result, payment receipt) are template messages — patients may not have messaged us recently. frappe_whatsapp's notification cannot produce the ordered variable array Meta requires. Additionally, accessing linked document fields (e.g. clinic name from Company when the event fires on Patient Appointment) requires Jinja like `{{ frappe.db.get_value("Company", doc.company, "company_name") }}` — that is code, not something a clinic admin can write.

Our `Remedisys WhatsApp Notification` solves both: correct Meta API call shape + Browse Fields dialog so non-technical admins never touch field names or syntax.

---

## 2. What We Are Building

A WhatsApp Business integration with two distinct capabilities:

### 2.1 Automated Notifications (Outbound)

System sends pre-approved template messages automatically when clinical events occur. Clinic admin configures all notification types from the UI — no code required.

| Trigger | Recipient | Template | Configured via |
|---|---|---|---|
| Appointment booked | Patient | Confirmation: doctor, date, time, clinic | Remedisys WhatsApp Notification UI |
| 24h before appointment | Patient | Reminder with CONFIRM / CANCEL instructions | Scheduler + Remedisys WhatsApp Notification |
| 2h before appointment | Patient | Final reminder | Scheduler + Remedisys WhatsApp Notification |
| Appointment cancelled | Patient | Cancellation with rebooking info | Remedisys WhatsApp Notification UI |
| Lab result ready | Patient | "Results available — check portal" (no values) | Remedisys WhatsApp Notification UI |
| Encounter signed + has Rx | Patient | "Prescription ready" (names only, no dosages) | Remedisys WhatsApp Notification UI |
| Payment recorded | Patient | Receipt: invoice number, amount, date | Remedisys WhatsApp Notification UI |
| No-show (15 min past start) | Front Desk staff | Alert to free the slot | Scheduler + Python |
| Patient replies CONFIRM | Patient | Acknowledgement | Python only — triggered by inbound reply |
| Patient replies CANCEL | Patient | Acknowledgement | Python only — triggered by inbound reply |

### 2.2 Inbound only — the staff inbox is read-only

**Corrected 2026-09-04.** This section described a two-way chat. It is now one-way:

- A patient can message at any time; it lands in the staff inbox and is shown in full
- **Staff cannot reply free-form.** There is no text box, and the five backend paths that could
  send free text, a file, or the encounter PDF all refuse
- Staff may send an **approved template** — that is the only outbound action
- **Meta's 24-hour window no longer matters for outbound.** It existed to permit free-form
  replies; every send is a template now, and a template can be sent at any time
- Conversations are still assigned to staff members
- A patient sending their own records inbound is fine and is *not* a HIPAA-regulated disclosure —
  they are not a covered entity. **Never solicit it**, though: asking makes the clinic the cause
- Screen 16 (Messages) and the chart's WhatsApp tab are the two places it is shown

---

## 3. User Stories with Examples

### US-001 — Appointment Confirmation

**Story:** As a patient, I want to receive a WhatsApp message right after my appointment is booked so I have the details saved.

**Example:**

> Valentina Rosales books an appointment with Dr. García for tomorrow at 10:00 AM at Chavitos Clinic.
>
> Within 60 seconds she receives:
>
> *"Hola Valentina, tu cita con el Dr. García está confirmada para el 21 de junio a las 10:00 AM.*
> *Chavitos Clínica Pediátrica — ¡Hasta entonces!"*

**What happens in the system:**
1. `Patient Appointment` created — After Insert fires
2. `notifications.process_notifications` wildcard hook runs
3. Finds matching `Remedisys WhatsApp Notification` (Patient Appointment + After Insert)
4. Evaluates condition, resolves phone, builds ordered variable list from configured rows
5. Calls Meta Graph API — template `appt_confirmation_v1` sent
6. `WhatsApp Message` (Outbound) created; `WhatsApp Conversation` created for Valentina

---

### US-002 — 24-Hour Reminder with Confirm/Cancel

**Story:** As a patient, I want a reminder the day before with the option to confirm or cancel without calling.

**Example:**

> At 9:00 AM Valentina receives:
> *"Hola Valentina, recordatorio: tienes cita mañana con el Dr. García a las 10:00 AM.*
> *Responde 1 para CONFIRMAR o 2 para CANCELAR."*
>
> Valentina replies: **1**
>
> She immediately receives:
> *"¡Tu cita está confirmada! Nos vemos mañana a las 10:00 AM. — Remedisys"*

**What happens in the system:**
1. Frappe scheduler finds appointments in the 24h window
2. Reads `Remedisys WhatsApp Notification` config (scheduled type) for template + account
3. Sends `appt_reminder_24h_v1` with resolved variable list
4. Valentina replies "1" → Meta webhook → `WhatsApp Message` (Inbound)
5. Our hook detects intent = confirm → `custom_patient_confirmed = True` saved
6. Ack template sent (Python — inbound acks are not doc events)

---

### US-003 — Patient Sends a Free-Form Message

**Example:**

> Valentina replies: *"¿Necesito llevar algún documento?"*
> Staff Ana sees it in Screen 16, replies free-form. Valentina receives it on WhatsApp.

---

### US-004 — 24h Window Expired

**Example:**

> Three days later Ana opens the conversation. Compose box shows "Window expired — Send Template."
> She picks a template, fills variables, sends. Window reopens.

---

### US-005 — Clinic Admin Adds a New Notification (Zero Code)

**Story:** As a clinic admin, I want to add a new WhatsApp notification for a new clinical event without involving a developer.

**Example:**

> Template `referral_accepted_v1` approved on Meta.
>
> Admin opens: Frappe Desk → Remedisys WhatsApp Notification → New
>
> - Document Type: Referral
> - Event: On Submit
> - Condition: (blank)
> - Template: referral_accepted_v1
> - Phone: clicks Browse → selects "Patient Mobile" from Patient group
>
> Variable rows:
> - Row 1: Browse → "Patient Name" (Appointment) → As-is
> - Row 2: Browse → "Doctor Name" (Practitioner) → As-is
> - Row 3: Browse → "Clinic Name" (Company) → As-is
>
> Save. Done. Every submitted Referral now triggers the WhatsApp. Zero code. Zero deployment.

---

### US-006 — Multi-Clinic Isolation

**Example:**

> Two clinics on the same Frappe site — Chavitos (+52 999 111 2222) and Clínica del Sol (+52 998 333 4444).
> Ana (Chavitos) sees only Chavitos conversations in Screen 16. Carlos (Clínica del Sol) sees only his clinic's.

---

## 4. Architecture

### 4.1 High-Level Flow

```
OUTBOUND — EVENT-TRIGGERED
────────────────────────────────────────────────────────────────────
Clinical event fires (Patient Appointment inserted, Lab Test submitted...)
        ↓
notifications.process_notifications (wildcard hook)
        ↓
Indexed query: Remedisys WhatsApp Notification WHERE enabled=1
  AND document_type = doc.doctype AND event = frappe_event
  → no rows: return in ~1ms (zero overhead for unmatched doctypes)
  → rows found: continue
        ↓
Evaluate condition (Python expression, optional — blank = always send)
        ↓
Resolve phone via field path (e.g. patient_mobile_number)
        ↓
Resolve each variable row in order → ordered string list
        ↓
POST Meta Graph API — template message with variable array
        ↓
Log WhatsApp Message (Outbound) + find/create WhatsApp Conversation


OUTBOUND — INBOUND ACK (patient replies CONFIRM or CANCEL)
────────────────────────────────────────────────────────────────────
Patient replies "1" or "2"
        ↓
Meta webhook → frappe_whatsapp → WhatsApp Message (Inbound)
        ↓
on_whatsapp_message_created hook detects intent
        ↓
Updates Patient Appointment
        ↓
Python sends ack template directly (no doc event — Python only)


OUTBOUND — SCHEDULER (24h reminder, 2h reminder, no-show alert)
────────────────────────────────────────────────────────────────────
Frappe scheduler fires (every 15 min)
        ↓
Python queries upcoming appointments in the relevant time window
        ↓
Reads template name + WhatsApp account from Remedisys WhatsApp Notification
        ↓
Calls notifications._send_template() for each matching appointment


INBOUND — FREE-FORM CHAT (Screen 16)
────────────────────────────────────────────────────────────────────
Patient sends any message (not CONFIRM/CANCEL)
        ↓
Meta webhook → WhatsApp Message (Inbound) → our hook → unread_count += 1
        ↓
Next.js polls every 15s → conversation appears with unread badge
        ↓
Staff replies:
  within 24h window → send_chat_message() → Meta free-text
  window expired    → send_template_message() → Meta template
```

### 4.2 Component Ownership

```
frappe_whatsapp (installed app — configure, never modify its files)
├── WhatsApp Account        ← credentials per clinic phone number
├── WhatsApp Message        ← every message in/out (storage)
├── WhatsApp Template       ← template registry with Meta sync
├── WhatsApp Settings       ← global config
└── webhook.py              ← Meta webhook handler + HMAC verification

remedisys_healthcare_ai (our app)
├── Remedisys WhatsApp Notification          ← UI-configurable event triggers
├── Remedisys WhatsApp Notification Variable ← child: ordered variable rows
├── WhatsApp Conversation                    ← thread, 24h window, tenant isolation
├── integrations/whatsapp/
│   ├── chat_api.py          ← whitelisted BFF methods + inbound hook handler
│   └── notifications.py     ← wildcard hook processor + get_available_fields + _send_template
└── fixtures/custom_field.json  ← company on WhatsApp Account
                                   custom_patient_confirmed on Patient Appointment
```

### 4.3 Notification Responsibility Split

| Trigger type | Handler | Configurable via UI? |
|---|---|---|
| Doc events (appointment, lab, payment, any future event) | `Remedisys WhatsApp Notification` + `notifications.py` | Yes — clinic admin |
| Scheduler reminders (24h, 2h before appointment) | Frappe RQ scheduler + reads Remedisys WA Notification config | Partial — template/account from UI, time window in code |
| No-show alert (sent to staff) | Frappe RQ scheduler | No — Python only |
| CONFIRM ack (patient replies "1") | `chat_api._handle_confirm()` | No — Python only |
| CANCEL ack (patient replies "2") | `chat_api._handle_cancel()` | No — Python only |

CONFIRM/CANCEL acks stay in Python because they are triggered by inbound messages, not document saves — there is no DocType event to hook into.

---

## 5. frappe_whatsapp — What It Handles

### Installation

```bash
bench get-app https://github.com/shridarpatil/frappe_whatsapp
bench --site remedisis.localhost install-app frappe_whatsapp
bench --site remedisis.localhost migrate
bench restart
```

After install, verify actual field names on `WhatsApp Message` before wiring `chat_api.py`:

```python
# bench console
frappe.get_meta("WhatsApp Message").fields
```

### What it gives us

| Feature | How |
|---|---|
| Meta webhook endpoint | `POST /api/method/frappe_whatsapp.utils.webhook.webhook` |
| HMAC-SHA256 verification | Built into webhook handler |
| Template registry + Meta sync | `WhatsApp Template` doctype |
| Message storage | `WhatsApp Message` doctype — every message in/out |
| Multi-account | `WhatsApp Account` doctype — one per clinic phone number |

### What frappe_whatsapp does NOT handle (we build this)

| Gap | Our solution |
|---|---|
| Ordered variable array for Meta template messages | `Remedisys WhatsApp Notification` variable table + `notifications._send_template()` |
| Multi-doctype field access without code | Field path dot-notation + Browse Fields dialog |
| UI for non-technical notification config | Browse Fields dialog in our form JS |
| Conversation threading + 24h window | `WhatsApp Conversation` doctype |
| Free-form chat API for Next.js | `chat_api.py` whitelisted methods |
| CONFIRM/CANCEL intent → appointment update | `chat_api.on_whatsapp_message_created` |
| Tenant isolation by Company | `company` custom field + query filters |

---

## 6. Our Layer — What We Build

### File structure

```
remedisys_healthcare_ai/integrations/whatsapp/
    __init__.py
    chat_api.py          ← whitelisted BFF methods + inbound hook handler
    notifications.py     ← wildcard hook processor, field resolver, _send_template,
                            get_available_fields (Browse Fields backend)

remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/
    whatsapp_conversation/
        whatsapp_conversation.json
        whatsapp_conversation.py
    remedisys_whatsapp_notification/
        remedisys_whatsapp_notification.json
        remedisys_whatsapp_notification.py
        remedisys_whatsapp_notification.js   ← Browse Fields dialog (Frappe Desk JS)
    remedisys_whatsapp_notification_variable/
        remedisys_whatsapp_notification_variable.json
        remedisys_whatsapp_notification_variable.py

remedisys_healthcare_ai/fixtures/
    custom_field.json    ← company on WhatsApp Account
                            custom_patient_confirmed on Patient Appointment
```

### hooks.py additions

```python
doc_events = {
    # ... existing doc_events ...

    # Inbound message routing + conversation tracking
    "WhatsApp Message": {
        "after_insert": "remedisys_healthcare_ai.integrations.whatsapp.chat_api.on_whatsapp_message_created",
    },

    # Wildcard — indexed query per save; ~1ms overhead; exits immediately if no config matches
    "*": {
        "after_insert":           "remedisys_healthcare_ai.integrations.whatsapp.notifications.process_notifications",
        "after_save":             "remedisys_healthcare_ai.integrations.whatsapp.notifications.process_notifications",
        "on_submit":              "remedisys_healthcare_ai.integrations.whatsapp.notifications.process_notifications",
        "on_update_after_submit": "remedisys_healthcare_ai.integrations.whatsapp.notifications.process_notifications",
    },
}
```

---

## 7. DocTypes

### 7.1 `WhatsApp Conversation` (built)

One record per patient conversation thread.

| Field | Type | Notes |
|---|---|---|
| `patient` | Link → Patient | |
| `patient_name` | Data (fetch) | Fetched from Patient |
| `patient_phone` | Data | Normalised +52XXXXXXXXXX |
| `company` | Link → Company | Tenant isolation — required |
| `whatsapp_account` | Link → WhatsApp Account | |
| `status` | Select | Open / Waiting / Closed |
| `window_expires_at` | Datetime | Last inbound + 24h |
| `window_open` | Check (read-only) | Computed on save |
| `last_message_at` | Datetime | |
| `last_message_preview` | Small Text | First 100 chars — PHI, restricted |
| `assigned_to` | Link → User | Staff member handling this thread |
| `unread_count` | Int | Reset to 0 when staff opens conversation |

**Permissions:** EB_Front Desk (r/w/c), EB_Nurse (r/w/c), EB_Healthcare Admin (r/w/c), EB_Practitioner (read), System Manager (full)

---

### 7.2 `Remedisys WhatsApp Notification` (new)

Clinic admin creates one record per notification type. No code required.

| Field | Type | Notes |
|---|---|---|
| `title` | Data | e.g. "Appointment Confirmation" — used as record name |
| `enabled` | Check | Toggle on/off without deleting |
| `document_type` | Link → DocType | Which DocType fires this |
| `event` | Select | After Insert / After Save / On Submit / On Update After Submit |
| `condition` | Small Text | Optional Python expression. Blank = always send. e.g. `doc.status != 'Cancelled'` |
| `whatsapp_account` | Link → WhatsApp Account | Which clinic's number sends this |
| `template_name` | Data | Exact Meta-approved template name |
| `language` | Select | es (default) / en |
| `phone_field_path` | Small Text | Field path for recipient phone. e.g. `patient_mobile_number` or `patient.mobile` |
| `variables` | Table | Child rows — ordered, one per `{{1}}`, `{{2}}`, etc. |

**Permissions:** EB_Healthcare Admin (r/w/c/d), System Manager (full)

---

### 7.3 `Remedisys WhatsApp Notification Variable` (child — new)

Row 1 → `{{1}}`, Row 2 → `{{2}}`, etc.

| Field | Type | Notes |
|---|---|---|
| `label` | Data | Documentation only — not sent to Meta |
| `field_path` | Data | e.g. `patient_name`, `patient.mobile`, `company.company_name` |
| `format` | Select | As-is / Format Date / Format Time / Format Currency / Advanced Expression |
| `advanced_expression` | Small Text | Shown only when Format = Advanced Expression |

**Format behaviour:**

| Format | Input | Output |
|---|---|---|
| As-is | `patient_name` → "María García" | "María García" |
| Format Date | `appointment_date` → 2026-06-21 | "21 Jun 2026" |
| Format Time | `appointment_time` → 10:30:00 | "10:30" |
| Format Currency | `grand_total` → 1500.00 | "$1,500.00" |
| Advanced Expression | `str(doc.appointment_time)[:5]` | "10:30" |

**Field path resolution:**

| Path | What the processor does |
|---|---|
| `patient_name` | Direct field on the triggering document |
| `patient.mobile` | Reads `patient` field → looks up `Patient` doctype (from Frappe metadata) → returns `mobile` |
| `company.company_name` | Reads `company` field → looks up `Company` → returns `company_name` |

The processor uses `frappe.get_meta(doc.doctype).get_field(link_field).options` to resolve the linked doctype automatically. Admin never specifies which doctype to look in.

---

### 7.4 Browse Fields Dialog (form JS — non-technical UX)

When `document_type` is selected, the form JS calls `get_available_fields(doctype)` and caches the result. Each variable row and the phone field have a **Browse** button.

Clicking Browse opens a searchable dialog:

```
Search: [_____________________]

── Patient Appointment ─────────────────────────
  Patient Name              ← click to select
  Appointment Date          ← click to select
  Appointment Time          ← click to select

── Patient ──────────────────────────────────────
  Mobile                    ← click to select
  Date of Birth             ← click to select

── Clinic (Company) ─────────────────────────────
  Clinic Name               ← click to select
  Phone Number              ← click to select

── Doctor (Healthcare Practitioner) ─────────────
  Doctor Name               ← click to select
  Department                ← click to select
```

Admin sees **labels** — not field names. Clicking fills `field_path` silently. No typing required.

`get_available_fields(doctype)`:
1. Reads all non-system fields from the primary DocType
2. Finds all Link fields — reads their linked DocType from Frappe metadata
3. For each linked DocType, reads its data fields
4. Returns grouped list with labels + resolved dot-notation paths

---

### 7.5 Custom fields via fixtures

| DocType | Field | Type | Purpose |
|---|---|---|---|
| `WhatsApp Account` | `company` | Link → Company | Tenant isolation |
| `Patient Appointment` | `custom_patient_confirmed` | Check (read-only) | Set to 1 when patient replies CONFIRM |

---

## 8. Notification Configuration System

### 8.1 Processor flow (`notifications.py`)

```
Wildcard hook fires (after_insert / after_save / on_submit / on_update_after_submit)
        ↓
Skip internal doctypes (WhatsApp Message, WhatsApp Conversation, Error Log...)
        ↓
Map method → event label ("after_insert" → "After Insert")
        ↓
SELECT from Remedisys WhatsApp Notification WHERE enabled=1
  AND document_type=doc.doctype AND event=frappe_event
  → empty: return immediately (~1ms)
        ↓
For each matching config:
  1. Evaluate condition with frappe.safe_eval — skip if False or raises
  2. Resolve phone_field_path → phone string — skip if empty
  3. For each variable row in order:
       - "Advanced Expression": frappe.safe_eval against doc
       - Other: _resolve_field(doc, field_path) → apply format
  4. POST Meta Graph API — template + ordered variable array
  5. Log WhatsApp Message (Outbound)
  6. find_or_create WhatsApp Conversation
  Any error → Error Log — never blocks the document save
```

### 8.2 Which templates use which track

| Template | Track | Trigger |
|---|---|---|
| `appt_confirmation_v1` | UI — Remedisys WhatsApp Notification | Patient Appointment — After Insert |
| `appt_cancelled_v1` | UI — Remedisys WhatsApp Notification | Patient Appointment — After Save, condition: `doc.status == 'Cancelled'` |
| `lab_result_ready_v1` | UI — Remedisys WhatsApp Notification | Lab Test — After Save, condition: `doc.status == 'Result Interpreted'` |
| `prescription_ready_v1` | UI — Remedisys WhatsApp Notification | Patient Encounter — On Submit, condition: `len(doc.drug_prescription) > 0` |
| `payment_receipt_v1` | UI — Remedisys WhatsApp Notification | Sales Invoice — On Submit |
| `appt_reminder_24h_v1` | Scheduler | Python reads template name from Remedisys WhatsApp Notification |
| `appt_reminder_2h_v1` | Scheduler | Same |
| `noshow_staff_alert_v1` | Scheduler | Python — sent to staff, not patient |
| `appt_confirm_ack_v1` | Python only | Inbound CONFIRM reply — no doc event |
| `appt_cancel_ack_v1` | Python only | Inbound CANCEL reply — no doc event |

### 8.3 Adding a new notification in future (clinic admin — zero code)

1. Submit template to Meta → wait for approval (1–3 days — always the real bottleneck)
2. Frappe Desk → Remedisys WhatsApp Notification → New
3. Select Document Type + Event
4. Write condition if needed (leave blank to always send)
5. Select WhatsApp Account + enter template name
6. Click Browse on Phone row → select phone field
7. Add variable rows → Browse → select field → pick format
8. Save and enable
9. Fires immediately on next matching event — zero code, zero deployment

---

## 9. Message Templates

> **⚠️ SUPERSEDED 2026-09-04.** The ten templates below carried `patient_name`, and several also
> carried the doctor's name, the test name or an invoice amount — all now **refused by
> `phi_policy.py`**. Five of the corresponding configs have been **deleted** from the database by
> `patches/v0/retire_phi_whatsapp_templates_20260904.py`, and `Encounter Summary Ready` went with
> them because its body promised a PDF the system now refuses to send.
>
> **The current catalogue is seven templates carrying appointment date/time and clinic identity
> only**, and it is owned by
> [`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) §6.2 — with the
> exact names, placeholder counts and bodies to register with Meta in its §15.3. Three clinical
> templates were collapsed into one contentless *"you have an update"*, because three separate
> ones each disclose **which kind** of clinical event occurred while one discloses only that
> something did.
>
> The ten below are kept **as a record of what was originally designed**, not as instructions. Do
> not submit them.

### T-001 — Appointment Confirmation (`appt_confirmation_v1`)

```
ES: Hola {{1}}, tu cita con {{2}} está confirmada para el {{3}} a las {{4}}. {{5}} — ¡Hasta entonces!
EN: Hi {{1}}, your appointment with {{2}} is confirmed for {{3}} at {{4}}. {{5}} — See you then!
```

Variables: `[patient_name, doctor_name, date, time, clinic_name]`

UI variable configuration:

| Row | Label | Field Path | Format |
|---|---|---|---|
| 1 | Patient Name | `patient_name` | As-is |
| 2 | Doctor Name | `practitioner.practitioner_name` | As-is |
| 3 | Date | `appointment_date` | Format Date |
| 4 | Time | `appointment_time` | Format Time |
| 5 | Clinic Name | `company.company_name` | As-is |

---

### T-002 — 24-Hour Reminder (`appt_reminder_24h_v1`)

```
ES: Hola {{1}}, recordatorio: tienes cita mañana con {{2}} a las {{3}}. Responde *1* para CONFIRMAR o *2* para CANCELAR.
EN: Hi {{1}}, reminder: appointment tomorrow with {{2}} at {{3}}. Reply *1* to CONFIRM or *2* to CANCEL.
```

Variables: `[patient_name, doctor_name, time]`

---

### T-003 — 2-Hour Reminder (`appt_reminder_2h_v1`)

```
ES: Hola {{1}}, tu cita con {{2}} comienza en 2 horas a las {{3}}.
EN: Hi {{1}}, your appointment with {{2}} starts in 2 hours at {{3}}.
```

Variables: `[patient_name, doctor_name, time]`

---

### T-004 — Cancellation Notice (`appt_cancelled_v1`)

```
ES: Hola {{1}}, tu cita del {{2}} a las {{3}} ha sido cancelada. Para reagendar llámanos al {{4}}.
EN: Hi {{1}}, your appointment on {{2}} at {{3}} has been cancelled. To rebook call us at {{4}}.
```

Variables: `[patient_name, date, time, clinic_phone]`

UI variable configuration:

| Row | Label | Field Path | Format |
|---|---|---|---|
| 1 | Patient Name | `patient_name` | As-is |
| 2 | Date | `appointment_date` | Format Date |
| 3 | Time | `appointment_time` | Format Time |
| 4 | Clinic Phone | `company.phone_no` | As-is |

---

### T-005 — Confirm Acknowledgement (`appt_confirm_ack_v1`)

```
ES: ¡Tu cita está confirmada! Nos vemos el {{1}} a las {{2}}. — Remedisys
EN: Your appointment is confirmed! See you on {{1}} at {{2}}. — Remedisys
```

Variables: `[date, time]`

Sent by Python in `chat_api._handle_confirm()`. Not UI-configurable — triggered by inbound reply.

---

### T-006 — Cancel Acknowledgement (`appt_cancel_ack_v1`)

```
ES: Tu cita ha sido cancelada. Para reagendar llámanos al {{1}}. — Remedisys
EN: Your appointment has been cancelled. To rebook call us at {{1}}. — Remedisys
```

Variables: `[clinic_phone]`

Sent by Python in `chat_api._handle_cancel()`. Not UI-configurable — triggered by inbound reply.

---

### T-007 — Lab Result Ready (`lab_result_ready_v1`)

```
ES: Hola {{1}}, tus resultados de *{{2}}* ya están disponibles. Ingresa a tu portal para verlos.
EN: Hi {{1}}, your results for *{{2}}* are ready. Log in to your portal to view them.
```

Variables: `[patient_name, test_name]`

PHI rule: test name only — never result values, ranges, or interpretation.

---

### T-008 — Prescription Ready (`prescription_ready_v1`)

```
ES: Hola {{1}}, el Dr. {{2}} firmó tu receta. Preséntala en tu farmacia o consulta los detalles en el portal.
EN: Hi {{1}}, Dr. {{2}} signed your prescription. Take it to your pharmacy or view details in the portal.
```

Variables: `[patient_name, doctor_name]`

PHI rule: drug names and dosages never via WhatsApp — portal only.

---

### T-009 — Payment Receipt (`payment_receipt_v1`)

```
ES: Hola {{1}}, pago recibido. Factura: {{2}} | Monto: ${{3}} {{4}} | Fecha: {{5}}. Gracias — Remedisys
EN: Hi {{1}}, payment received. Invoice: {{2}} | Amount: ${{3}} {{4}} | Date: {{5}}. Thank you — Remedisys
```

Variables: `[patient_name, invoice_number, amount, currency, date]`

---

### T-010 — No-Show Staff Alert (`noshow_staff_alert_v1`)

```
ES: Alerta: {{1}} tenía cita a las {{2}} con {{3}} y no se ha presentado ({{4}} min de retraso).
EN: Alert: {{1}} had an appointment at {{2}} with {{3}} and has not checked in ({{4}} min late).
```

Variables: `[patient_name, time, doctor_name, minutes_late]`

Sent to **staff WhatsApp** — not to patient. Python scheduler only.

---

## 10. API Endpoints

All whitelisted methods in `remedisys_healthcare_ai.integrations.whatsapp`.

### Chat API (`chat_api.py`)

#### `list_conversations`
```python
@frappe.whitelist()
def list_conversations(status="Open", assigned_to=None, limit=50, offset=0) -> dict
```
Returns conversations for logged-in user's company only, sorted by `last_message_at DESC`.

Response:
```json
{
  "data": [
    {
      "name": "WC-00001",
      "patient": "PAT-0001",
      "patient_name": "Valentina Rosales",
      "patient_phone": "+529991234567",
      "status": "Open",
      "assigned_to": "ana@chavitos.mx",
      "unread_count": 2,
      "last_message_at": "2026-06-20 14:32:00",
      "last_message_preview": "¿Necesito llevar algún documento?",
      "window_expires_at": "2026-06-21 14:32:00",
      "window_open": true
    }
  ],
  "total": 12,
  "limit": 50,
  "offset": 0
}
```

#### `get_conversation`
```python
@frappe.whitelist()
def get_conversation(conversation: str) -> dict
```
Full thread + all messages ordered ASC. Resets `unread_count` to 0.

#### `send_chat_message` — **REFUSES since 2026-09-04**
```python
@frappe.whitelist()
def send_chat_message(conversation: str, body: str) -> dict
```
~~Free-form reply.~~ Raises `PermissionError` — *"WhatsApp is notification-only"* — via
`phi_policy.refuse_free_form()`. The endpoint is kept rather than deleted so a caller we have not
found gets the explanation instead of a 404 that reads like a bug.

**Four other paths refuse the same way**, and the two that were easiest to miss were the worst:
`api/v1/notifications/api.py::send_whatsapp_reply` and `send_whatsapp_media`, plus
`start_whatsapp_conversation` (free text via its `message` argument) and
`send_encounter_summary_whatsapp` — which forwarded the **signed clinical record of a visit** to
Meta as a PDF. Removing the UI was never the control; these are.

#### `send_template_message`
```python
@frappe.whitelist()
def send_template_message(conversation: str, template_name: str, variables: list) -> dict
```
Template send. Works regardless of 24h window.

#### `assign_conversation`
```python
@frappe.whitelist()
def assign_conversation(conversation: str, user: str) -> dict
```
EB_Healthcare Admin + System Manager only.

#### `close_conversation`
```python
@frappe.whitelist()
def close_conversation(conversation: str) -> dict
```

### Notification API (`notifications.py`)

#### `get_available_fields`
```python
@frappe.whitelist()
def get_available_fields(doctype: str) -> list
```
Called only by Browse Fields dialog in Frappe Desk. Returns fields grouped by source document with labels and resolved paths. Not exposed to Next.js.

---

## 11. Frontend BFF Routes

All routes in `src/app/api/whatsapp/`.

```
GET  /api/whatsapp/conversations
GET  /api/whatsapp/conversations/[id]
POST /api/whatsapp/conversations/[id]/reply          body: { body: string }
POST /api/whatsapp/conversations/[id]/send-template  body: { template_name, variables }
POST /api/whatsapp/conversations/[id]/assign         body: { user: string }
POST /api/whatsapp/conversations/[id]/close
```

### Delivery strategy — polling is gone

**Corrected: the interval-polling below was removed on 2026-08-25 by
[adr-045](adr/adr-045-push-notifications-fcm-and-sse.md).** All 13 polling intervals across both
frontends were deleted in favour of live delivery over SSE, with FCM for out-of-app push to
patients. The mechanism is [`PUSH_NOTIFICATIONS.md`](PUSH_NOTIFICATIONS.md); every notification
passes through the single `services/notifications.py::notify()` chokepoint.

Kept as a record of the original design:

```typescript
// SUPERSEDED — do not reintroduce. See adr-045.
useEffect(() => {
  const i = setInterval(() => refetchConversations(), 15_000)
  return () => clearInterval(i)
}, [])
```

### Screen 16 UI states

**Inbox (`/messages`):** conversations sorted by last_message_at, columns: patient name / preview / time / assigned staff / unread badge. Filter tabs: All / Mine / Unassigned.

**Thread (`/messages/[id]`):**
- Bubbles: inbound left (grey), outbound right (green)
- `window_open = true` → free-text compose + Send
- `window_open = false` → "Window expired — Send Template" → template picker modal

---

## 12. Multi-Tenant Design

Each clinic is a separate `Company` with its own WhatsApp Business phone number.

```python
def _get_user_company():
    company = frappe.db.get_value("User", frappe.session.user, "company")
    if not company:
        frappe.throw("Your user account has no Company set.")
    return company

def _assert_company(conv_company):
    if frappe.session.user == "Administrator":
        return
    if conv_company != _get_user_company():
        frappe.throw("Not permitted", frappe.PermissionError)
```

Inbound company resolution:
```python
company = frappe.db.get_value("WhatsApp Account", doc.whatsapp_account, "company")
```

Webhook URL is one per Frappe site. frappe_whatsapp routes by `phone_number_id`. Our code resolves company from the account's `company` custom field.

---

## 13. Step-by-Step Integration

### Step 1 — Install frappe_whatsapp
```bash
bench get-app https://github.com/shridarpatil/frappe_whatsapp
bench --site remedisis.localhost install-app frappe_whatsapp
bench --site remedisis.localhost migrate
bench restart
```
Verify WhatsApp Message field names in bench console before wiring `chat_api.py`.

### Step 2 — Apply custom fields
Add `company` on `WhatsApp Account` and `custom_patient_confirmed` on `Patient Appointment` to `fixtures/custom_field.json`. Run `bench migrate`.

### Step 3 — Register webhook with Meta
Callback URL: `https://your-domain.com/api/method/frappe_whatsapp.utils.webhook.webhook`
Subscribe to: `messages`, `message_deliveries`, `message_reads`, `message_template_status_update`

### Step 4 — Create WhatsApp Account per clinic
Fill in: Account Name, Token, Phone ID, Business ID, Webhook Verify Token, Company, Is Default Incoming ✅, Is Default Outgoing ✅.

### Step 5 — Submit the templates to Meta for approval

**It is seven, not ten, and they are different.** Exact names, placeholder counts and bodies:
[`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) §15.3. Category
**UTILITY**, language **Spanish (MEX)**. Do not add a greeting by name — it is both a PHI
disclosure and a common cause of template rejection.
Create one `WhatsApp Template` record per template. Wait for Approved status.

### Step 6 — Deploy our custom doctypes
```bash
bench --site remedisis.localhost migrate
bench restart
```
Creates: `WhatsApp Conversation`, `Remedisys WhatsApp Notification`, `Remedisys WhatsApp Notification Variable`.

### Step 7 — Configure notifications in UI (clinic admin)
For each event-triggered template, create a `Remedisys WhatsApp Notification` record. Use Browse to pick fields — no typing of field names or expressions.

Example — Appointment Confirmation:
```
Document Type:  Patient Appointment
Event:          After Insert
Condition:      doc.status != 'Cancelled'
Account:        Chavitos Principal
Template:       appt_confirmation_v1
Language:       es
Phone Field:    Browse → "Patient Mobile"

Variables:
  Row 1: Browse → "Patient Name"       → As-is
  Row 2: Browse → "Doctor Name"        → As-is
  Row 3: Browse → "Appointment Date"   → Format Date
  Row 4: Browse → "Appointment Time"   → Format Time
  Row 5: Browse → "Clinic Name"        → As-is
```

### Step 8 — Wire hooks.py
Add `WhatsApp Message` hook + wildcard hook. Run `bench migrate && bench restart`.

### Step 9 — Build BFF routes in Next.js
6 route handlers under `src/app/api/whatsapp/`.

### Step 10 — Build Screen 16 in Next.js
Inbox + Thread views. Poll 15s on list, 10s inside thread.

### Step 11 — End-to-end test with ngrok
```bash
ngrok http 8003
# Set ngrok URL as webhook in Meta Developer Console
# Send test message → verify WhatsApp Message → WhatsApp Conversation → Screen 16
```

---

## 14. Error Handling and Retry

| Scenario | Handling |
|---|---|
| Patient has no phone number | Skip silently, log warning |
| Condition expression raises exception | Log to Error Log, skip this notification — others still fire |
| Field path resolves to empty | Return empty string, log warning |
| Meta returns 4xx (unapproved template) | Mark WhatsApp Message as Failed, no retry |
| Meta returns 5xx | frappe_whatsapp handles retry |
| Webhook HMAC mismatch | frappe_whatsapp returns 403, logs security event |
| Patient phone not found for inbound | Log warning, create anonymous conversation with phone only |
| 24h window expired — staff tries free-text | Raise `ValidationError` — frontend shows template picker |
| Appointment not found for CONFIRM/CANCEL | Send "No encontramos tu cita. Llámanos al {clinic_phone}." |
| Notification processor error | Caught per-notification, logged — never blocks document save |

---

## 15. PHI Rules

> **⚠️ REWRITTEN 2026-09-04. The previous table was wrong and is the most dangerous thing this
> document contained.** It listed patient name, doctor name, lab test name and invoice amount as
> **allowed** on WhatsApp. All four are now **refused by code** — `phi_policy.py` throws on save
> for any enabled template carrying them — so a reader following the old table would have built
> templates the guard rejects, and would have believed a patient's name on WhatsApp was fine. It
> never was: Meta has signed no BAA.

**These are enforced, not advisory.** `integrations/whatsapp/phi_policy.py` holds an **allowlist**
(deliberately, since a blocklist has to anticipate every field anyone adds later and only has to
be wrong once), and `assert_no_phi_to_meta()` refuses to save any `enabled` template carrying
anything outside it.

| Variable path | WhatsApp | Why |
|---|---|---|
| `company.company_name` | ✅ Allowed | Meta already knows which business account relayed the message |
| `company.phone_no` | ✅ Allowed | Same |
| `appointment_date` | ✅ Allowed | Not an identifier under §164.514(b)(2), and reveals no clinical fact beyond the appointment existing — which is what the patient authorised us to tell them |
| `appointment_time` | ✅ Allowed | Same |
| `expires_on` | ✅ Allowed | A date, on a record about the authorisation rather than about care (template T7) |
| `patient_name` | ❌ **Refused** | One of HIPAA's 18 identifiers |
| `practitioner_name` | ❌ **Refused** | **More disclosing than the patient's own name** — a specialty is public, so naming the doctor can reveal the nature of the care |
| `lab_test_name` | ❌ **Refused** | Says what the patient was tested for. In a shared household that discloses to whoever holds the phone |
| Invoice number / amount | ❌ **Refused** | Financial detail about care received |
| Lab result values | ❌ Never | Portal only |
| Drug dosages / instructions | ❌ Never | Portal only |
| Diagnosis / ICD codes | ❌ Never | Portal only |
| MRN / Patient ID | ❌ Never | Identifier, and unnecessary |
| Clinical findings | ❌ Never | Portal only |
| Any `advanced_expression` | ❌ **Refused** | Arbitrary code against `doc` cannot be shown to be clinic-generic |

**And the constraint the old table missed entirely:** the recipient's phone number is itself one
of the 18 identifiers, and it reaches Meta on every send. So even a fully generic message
discloses *"this person is a patient of this clinic"*. Content minimisation reduces how much,
never whether — which is why the channel rests on **consent** rather than on careful wording. See
[`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) §1 and §2.

**Consent is now a precondition for every send**, checked server-side in
`services/communication_consent.py` and bound to a specific phone number. A patient with no
record is never messaged. See ADR-057.

`last_message_preview` — may contain patient free-form text. Treat as PHI. Never log. Never expose beyond staff with conversation permission.

`advanced_expression` — executes Python. Restricted to EB_Healthcare Admin + System Manager. Must never write PHI to logs.

---

## 16. Testing Checklist

### Unit tests
- [ ] `_parse_intent("1")` → `"confirm"`
- [ ] `_parse_intent("Cancelar")` → `"cancel"`
- [ ] `_parse_intent("hola como estas")` → `"unknown"`
- [ ] `send_chat_message()` raises `ValidationError` when window expired
- [ ] `list_conversations()` returns only logged-in user's company conversations
- [ ] `_find_patient()` returns None when no match
- [ ] `_resolve_field(doc, "patient_name")` returns direct field
- [ ] `_resolve_field(doc, "patient.mobile")` follows link and returns linked field
- [ ] `_resolve_field(doc, "nonexistent.field")` returns empty string without raising
- [ ] Condition `doc.status != 'Cancelled'` — skips when status is Cancelled
- [ ] Blank condition — always fires
- [ ] `get_available_fields("Patient Appointment")` returns groups for Appointment + Patient + Company + Practitioner

### Integration tests
- [ ] Patient Appointment created → notification fires → WhatsApp Message (Outbound) created
- [ ] Lab Test status updated to "Result Interpreted" → lab notification fires
- [ ] Patient Encounter submitted with drug_prescription → prescription notification fires
- [ ] Inbound message → WhatsApp Conversation created or updated
- [ ] Inbound "1" → `custom_patient_confirmed = True` → ack template sent
- [ ] Inbound "2" → appointment cancelled → ack sent → front desk notified
- [ ] Inbound unknown text → `unread_count` incremented
- [ ] `send_chat_message()` within window → outbound message created
- [ ] `close_conversation()` → status = Closed → excluded from default inbox
- [ ] Clinic A staff cannot see Clinic B conversations
- [ ] Disabling a notification → no send on next matching event

### End-to-end tests (staging + real Meta credentials + ngrok)
- [ ] Book appointment → confirmation received within 60s with all variables correct
- [ ] 24h reminder received with CONFIRM/CANCEL prompt
- [ ] Reply "1" → confirmed in Frappe, ack received
- [ ] Reply "2" → cancelled in Frappe, ack received
- [ ] Reply free text → appears in Screen 16 within 15s
- [ ] Staff replies → patient receives on WhatsApp
- [ ] Staff replies after 24h → template picker shown → window reopens
- [ ] Lab result ready → patient notified
- [ ] Encounter with Rx submitted → patient notified
- [ ] Payment recorded → patient receives receipt
- [ ] Clinic A staff cannot see Clinic B conversations in Screen 16
- [ ] Admin adds new notification in UI → event fires → message sent — zero code

---

## 17. Two URLs that must be publicly reachable by Meta

**Added 2026-09-28 after both were found pointing at the same dead ngrok tunnel.** Neither failure
produces an error anywhere. Check these first when "WhatsApp stopped working".

| Setting | Where | If unreachable |
|---|---|---|
| `whatsapp_header_image_url` | `site_config.json` | Every template with an IMAGE header is **accepted and silently dropped** |
| Webhook `callback_url` | Meta app → `/{app_id}/subscriptions` | **All inbound patient messages are lost**, and no delivery status ever arrives |

### Why an unreachable header image is invisible

Every branded `_v3`/`_v4` template is approved **with an IMAGE header**. Meta fetches that image
server-side while building the message. When the fetch fails, the send still returns:

```
HTTP 200  {"messages":[{"id":"wamid...","message_status":"accepted"}]}
```

...and the message is never delivered. No error, no failure webhook, nothing in Insights, and
`health_status` stays `AVAILABLE` — it reports account health (payment, quality, policy), not media
fetchability. On 2026-09-28 this looked in turn like a payment failure, a test-number recipient
allow-list and an unregistered number. It was none of them.

**Diagnosing it takes one comparison, not a day:** send one approved template **with** a header and
one **without**. If the header-less one arrives and the other does not, it is the image.

```
none                                   -> delivered
link -> dead ngrok                     -> dropped
link -> scontent.whatsapp.net CDN      -> dropped   (signed preview URL, NOT fetchable when sending)
id   -> media uploaded to Meta         -> delivered
link -> https://mycare.narzim.com/...  -> delivered  <- what we use
```

A `header_handle` taken from the template definition is a **preview** URL and cannot be used as a send
`link`. Use a public URL you control, or upload the media and send `{"id": ...}`.

### Why the webhook URL matters just as much

`callback_url` must point at **this Frappe site**, not the portal. Locally that means a tunnel
(`ngrok http 8000`); in production, the deployed backend domain. Subscribing the app is not enough —
`/{waba_id}/subscribed_apps` only tells Meta to send callbacks; they still go to whatever
`callback_url` the app has.

Update it without the dashboard, using the app secret:

```
POST /{app_id}/subscriptions
  object=whatsapp_business_account
  callback_url=<public base>/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook
  verify_token=<WhatsApp Account.webhook_verify_token>
  fields=messages,message_template_status_update
```

### A third silent failure: an empty `phone_field_path`

`_fire_notification()` resolves the recipient's number from the config's `phone_field_path` and
**returns at that step when it is empty** — before the consent gate, before the send, with no error
and no log. The config looks enabled and correctly templated, and sends nothing.

Found on two configs on 2026-09-28: **Appointment Reminder** (which also had no caller at all) and
**Consent Ending** (which `services/consent_lifecycle.py` had been running daily and sending nothing
from). `seed_whatsapp_notification_configs_20260910` sets the field, but that line was added after the
patch had already run on existing sites, and a patch never runs twice — so fresh sites were fine and
migrated ones were not. `repair_whatsapp_phone_field_paths_20260928` fills them.

Consent Ending uses `phone_number` rather than `patient.mobile`: on a representative consent the
authorised number is the guardian's, and `has_consent()` matches that exact field, so sending to the
patient's own mobile would fail the consent gate whenever the two differ.

**If a config is enabled, its template approved, and nothing arrives — check `phone_field_path`
before anything else.**

### Keyword auto-replies depend entirely on this

`_match()` is word-bounded, so *"I want to book appointment"* correctly resolves to
`auto_reply_book_v3`. When the webhook URL is dead the message never arrives, so nothing runs — and
the UI shows the ADR-068 "waiting for a clinician" banner from an earlier message, which reads like
the auto-reply is broken. It is not. Verified 2026-09-28 by posting a signed webhook to the local
endpoint: the inbound row was created and `auto_reply_book_v3` went out two seconds later.

## Open Questions (Resolved)

| Question | Resolution |
|---|---|
| clefincode_chat vs Meta direct? | `frappe_whatsapp` — maintained, Meta direct |
| Install `whatsapp_chat`? | No — Frappe Desk + Socket.IO, cannot reach Next.js |
| Firebase for real-time? | No Phase 4 — polling sufficient |
| Multi-tenant? | `company` custom field on `WhatsApp Account` + query filters |
| Free-form chat? | Yes — `send_chat_message()`, 24h window enforced |
| Use frappe_whatsapp's `WhatsApp Notification`? | No — renders Jinja string; Meta needs ordered variable array; linked-doc access requires code. We build `Remedisys WhatsApp Notification`. |
| Jinja in DB for variable expressions? | No — replaced by field-path dot notation + format dropdown + Browse Fields. No Jinja visible to admin. |
| Non-technical users typing field names? | Solved — Browse Fields dialog shows labels, admin clicks, path fills automatically. |
| Adding new notifications without code? | `Remedisys WhatsApp Notification` UI — create record, Browse fields, save. Zero code. Meta approval is the bottleneck. |
| CONFIRM/CANCEL acks — UI or Python? | Python only — triggered by inbound message, not a doc event. |

---

*Document maintained by the Remedisys backend team.*
*Update this file when any implementation decision changes.*
*Next: build `Remedisys WhatsApp Notification` DocType + Variable child + `notifications.py` + Browse Fields JS.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.2 | 2026-09-28 | Ashutosh (AI-assisted) | Added the third silent failure to §17: an empty `phone_field_path` makes a config inert with no error. Wired the WhatsApp appointment reminder to the `*/5` scheduler |
| 2.1 | 2026-09-28 | Ashutosh (AI-assisted) | Added §17: the header-image URL and the webhook callback URL must both be publicly reachable by Meta; an unreachable header image is accepted and silently dropped |
| 2.0 | 2026-09-04 | Ashutosh (AI-assisted) | **Corrected against a channel that changed shape.** This document described a two-way chat with personalised templates; WhatsApp is now a consent-gated, template-only notification channel, so several sections documented behaviour that has since been deliberately removed. A banner at the top states what moved and hands design/compliance/catalogue/go-live ownership to `security/WHATSAPP_HIPAA_COMPLIANT.md` and the consent record to ADR-060, so the two cannot drift (§9, one fact one owner). **§15's PHI table was the most dangerous content here and is rewritten**: it listed patient name, doctor name, lab test name and invoice amount as *allowed*, and all four are now refused by `phi_policy.py` on save — a reader following it would have built templates the guard rejects while believing a patient's name on WhatsApp was fine. The new table is the enforced allowlist, notes that `practitioner_name` is **more** disclosing than the patient's own name because a specialty is public, and adds the constraint the old one missed entirely: the recipient's phone number is itself one of the 18 identifiers, so even a generic message discloses that this person is a patient here — which is why the channel rests on consent rather than on careful wording. §2.2 corrected from two-way chat to inbound-only, including that Meta's 24-hour window no longer affects outbound. §9's ten templates marked superseded and kept only as a record of the original design, with a do-not-submit warning. §11's polling code marked superseded by adr-045. §13 step 5 corrected from ten templates to seven |
| 1.0 | 2026-06-20 | Sarvesh | Initial version (header backfilled from git history) |
