# Should we use `frappe_whatsapp_chatbot`? — evaluation and decision

**Doc status:** record · **Created:** 2026-09-11 by Ashutosh (AI-assisted) · **Updated:** 2026-09-11 by Ashutosh (AI-assisted) · **Version:** 1.1

> **This is a `record`.** It is a dated evaluation of a third-party app **as it stood at commit
> `e98a655` (2026-03-30)**. If that app changes, this document does not become wrong — it becomes
> historical. Re-evaluate against a new commit rather than editing this one.

---

## The decision, in one box

> **We are NOT using `frappe_whatsapp_chatbot`.**
>
> **Reason 1 (decisive, and nothing can fix it):** its licence forbids use in a product that is
> sold. Remedisys is sold to clinics.
>
> **Reason 2 (independent of the licence):** to make it safe we would have to rewrite parts of it.
> Those rewrites are **bigger than simply writing the feature ourselves** — about **23× more code
> to maintain** for the same result.
>
> **What we do instead:** ~50 lines inside the inbound handler we already own, plus one small
> doctype so staff can edit the keywords without a deployment.

### Tweak vs. build, at a glance

|  | Fork theirs | Build ours |
|---|---|---|
| Lines we maintain | 2,597 | ~110 |
| Lines we'd use | ~117 | ~110 |
| New doctypes | 10 | 1 |
| Consent / audit / window / language | must add | already built |

The full breakdown, including licence and upstream maintenance, is in §6.

---

## 1. What we actually need (the real requirement)

Management asked for a "WhatsApp chatbot". After clarifying the scope with the team, the real
requirement is **auto-replies only**:

| Patient sends | Clinic replies |
|---|---|
| `book` / `agendar` | "You can book here: https://mycare.narzim.com/" |
| `cancel` / `cancelar` | "You can cancel here: …" |
| `reschedule` / `reagendar` | "You can reschedule here: …" |
| anything else | "This number is not monitored. For anything urgent, call the clinic." |

Read that table carefully, because **it is the whole reason this decision comes out the way it
does**. There is:

- no conversation to remember,
- no question to understand,
- no patient data to look up,
- no AI of any kind.

It is **text in → fixed text out**. Three words, three links.

A tool that is much bigger than the job is not a shortcut. It is a bigger thing to carry.

---

## 2. What the app is, and what it genuinely does well

Repository: `https://github.com/shridarpatil/frappe_whatsapp_chatbot`
Author: Shridhar Patil — **the same author as `frappe_whatsapp`**, which we already use and rely on.

Measured facts:

| Measure | Value |
|---|---|
| Commits in history | **1** |
| Date of that commit | 2026-03-30 |
| Files | 98 |
| Python lines | 2,597 |
| New doctypes it installs | **10** |
| Licence | **Commons Clause** |

It hooks into WhatsApp the same way we do (`hooks.py:10-14`):

```python
doc_events = {
    "WhatsApp Message": {
        "after_insert": "frappe_whatsapp_chatbot.chatbot.processor.process_incoming_message"
    }
}
```

When a message arrives, `processor.py:102-190` tries five things in order:

| # | Stage | What it means |
|---|---|---|
| 1 | Continue an open multi-step form | "What is your name?" → "What date?" → … |
| 2 | Keyword match → canned reply | **this is the only stage we need** |
| 3 | Keyword starts a new multi-step form | |
| 4 | **AI fallback** — send the message to an LLM | |
| 5 | Default reply | |

**Credit where it is due.** This is not bad software:

- The multi-step flow engine (`flow_engine.py`, 575 lines) is real, non-trivial work.
- The keyword matcher supports Exact, Contains, Starts With and Regex.
- It has sensible operational features: business-hours gate, an excluded-numbers list, and
  **agent transfer** — the bot stands down when a human replies in the thread. That last idea is
  genuinely good and we are going to copy it.

If we needed a general-purpose WhatsApp chatbot for a non-commercial internal tool, this would be
a reasonable starting point. Our situation is different on both counts.

---

## 3. Reason 1 — the licence forbids it. This is decisive.

### What the licence says

The file `LICENSE` in the repository is a **Commons Clause** licence. Commons Clause is **not an
open-source licence** — it is a permissive licence with a commercial-use restriction bolted on.

Clause 2, quoted exactly:

> **2. The Software may not be sold, sublicensed for a fee, or used as part of a commercial product
> or service that is sold.** This includes but is not limited to:
> - Selling the Software as a standalone product
> - **Including the Software in a paid product or service**
> - Offering paid hosting, support, or consulting services where the primary value derives from
>   this Software

Clause 3 lists what *is* allowed: personal use, **internal business use**, education,
non-commercial projects, and open-source projects that do not sell.

### Why that stops us

Remedisys is described in [`CLAUDE.md`](../CLAUDE.md) §2 as a **multi-tenant Healthcare SaaS
platform for paediatric clinics in Mexico**. Clinics pay for it. That is, in the licence's own
words, "a paid product or service".

So installing this app would mean **including the Software in a paid product or service** — the
exact phrase clause 2 prohibits.

"Internal business use" in clause 3 does not rescue us. That covers a company using the tool to run
itself. It does not cover shipping the tool to paying customers as part of the product.

### Why forking does not help

This is the important part, and it is where people usually hope for a way out.

**The licence travels with the code.** Copying the files into our repository, renaming them, or
keeping only the 117 lines we like does not remove Shridhar Patil's copyright or the conditions he
attached to it. A fork of restricted code is still restricted code.

Deleting the `LICENSE` file does not change the licence. It just removes the evidence that we read it.

### Contrast: why `frappe_whatsapp` is completely fine

| App | Licence | Can we ship it in a paid product? |
|---|---|---|
| `frappe_whatsapp` (we use this) | **MIT** | **Yes** |
| `remedisys_healthcare_ai` (ours) | **MIT** | Yes |
| `frappe_whatsapp_chatbot` | **Commons Clause** | **No** |

Same author, different licence. MIT permits commercial use without conditions. This is why we can
build the whole WhatsApp channel on `frappe_whatsapp` and still not touch its sibling app.

### This is not a new kind of decision for us

We have rejected a third-party app on licensing grounds before.
[ADR-030](adr/adr-030-llm-curated-tool-access.md) records that **Frappe_Assistant_Core** is
disallowed for PHI flows, for two reasons: its **AGPL-3.0 licence**, and because it exposes
SQL/Python/CRUD directly to an LLM.

`frappe_whatsapp_chatbot` fails on the same two axes — a restrictive licence, plus an
unbounded-data-to-LLM path (§4.2 below). The precedent is already set.

> **Action required:** this document states the plain reading of the licence text; it is not legal
> advice. Before anyone reconsiders, the licence needs a yes/no from whoever owns legal/commercial
> sign-off. But the plain reading is not ambiguous, and the technical reasons below stand on their
> own even if a lawyer disagrees.

---

## 4. Reason 2 — the technical problems, and which ones survive our narrow use

We found four technical problems. Being honest about scope matters here, so each is marked with
whether it still applies when we use **keyword replies only** (no AI, no flows).

### 4.1 Summary table

| # | Problem | Still applies to keyword-only use? | Fixable by a setting? |
|---|---|---|---|
| 1 | Patient messages have **no consent / STOP check** | **YES** | **No — needs code change** |
| 2 | AI can read **any doctype** and send it to an LLM | Only if AI is switched on | Setting — but a tickbox with no review gate |
| 3 | It calls `commit()` / `rollback()` **inside our transaction** | **YES** | **No — needs code change** |
| 4 | Stores patient message text in a **second table** | No — flows only | n/a |

Two of the four survive, and **neither can be configured away**. That is the technical core of the
decision.

### 4.2 Finding 1 — no consent or STOP check (survives)

**WHAT.** `processor.py:64-89` is `should_process()`, the function that decides whether to reply.
It checks four things: the message type, the WhatsApp account, a manual excluded-numbers list, and
whether a human agent has taken over. **It does not check consent.**

We verified this is not hidden elsewhere:

```
grep -riE "consent|opt.?in|opt.?out|unsubscribe|stop" --include="*.py" .
→ (no matches anywhere in the app)
```

**WHY it matters.** Our own inbound handler already honours withdrawal —
`integrations/whatsapp/chat_api.py:118`:

```python
if is_stop_word(raw_body):
    revoke_for_number(doc.get("from"), reason=_("Withdrawn by reply on WhatsApp"))
```

Both handlers are bound to the **same event on the same doctype**, so both run on the same message.
Ours revokes consent. Theirs, not knowing about consent, falls through stages 1–4 and sends
`default_response` (`processor.py:189`).

The result is that we reply to a person who just told us to stop.

As [`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) records, Meta
enforces opt-out for MARKETING templates but **not** for UTILITY, and every template we use is
UTILITY. So honouring withdrawal is entirely **our** obligation. Nothing in the platform catches
this for us.

**Why a setting cannot fix it.** Their only opt-out mechanism is `excluded_numbers`, a **manually
typed list**. A staff member would have to add every number that ever texted STOP, by hand, forever.
Our system revokes automatically. Bridging the two means writing code into their app.

### 4.3 Finding 2 — the AI path can read any doctype (only if AI is enabled)

**WHAT.** `ai_responder.py:80-113`. A `WhatsApp AI Context` record with
`context_type = "DocType Query"` holds free-text fields: `query_doctype`, `fields_to_include`, a
`filters` JSON blob, and a `phone_field`. The code passes them straight through:

```python
target_doctype = ctx.query_doctype              # free text, typed into a Desk form
fields = [f.strip() for f in ctx.fields_to_include.split(",")]
return frappe.get_all(target_doctype, filters=filters, fields=fields, limit=limit)
```

The result is then `json.dumps`'d directly into the LLM prompt (`ai_responder.py:68`).

There is **no doctype allowlist, no field allowlist, and no permission check** — it runs inside a
document hook, not a logged-in user's session, so Frappe's own permission system is not consulted.

**WHY it matters.** It bypasses every control we built:

- It uses its **own** API key (`ai_responder.py:12`, a Password field on the settings doctype), so
  it never goes through `services/llm.py::get_llm_client()` and the
  [ADR-026](adr/adr-026-llm-provider-allowlist.md) provider allowlist never runs.
- The active `ComplianceProfile` therefore never names the subprocessor — a direct **PHI-1**
  violation ([`CLAUDE.md`](../CLAUDE.md) §9.9).
- It is configured from a **Desk form**, so it needs no commit, no code review, and no ADR. A
  well-meaning admin can open this path on a Tuesday afternoon.

**On the Bedrock question.** It was asked whether using AWS Bedrock instead of OpenAI would make
this acceptable. Half of that reasoning is right, so it is worth being precise:

- **Right:** AWS signs a BAA and Bedrock is HIPAA-eligible. That converts the disclosure from
  *unlawful* into *lawful*. That is a real improvement, not a technicality.
- **Not enough:** lawful is not the same as compliant. **PHI-6 (minimum necessary)** is a separate
  requirement — a BAA lets you send PHI, it does not let you send *all of it*. An admin pointing
  `query_doctype` at `Patient` and pulling every field is still wrong with a BAA in place. And
  Bedrock writes nothing back to `AI Prompt Log`, so we could not reconstruct what was sent
  (audit controls).
- **And it is not even possible here.** The provider options are `OpenAI`, `Anthropic`, `Google`,
  `Custom` — and `Custom` is an empty stub (`ai_responder.py:279-283`):

  ```python
  def custom_response(self, message, conversation_history):
      """Generate response using custom endpoint."""
      # Placeholder for custom AI provider integration
      frappe.log_error("Custom AI provider not implemented")
      return None
  ```

  There is no Bedrock code in the app (`grep -riE "bedrock|boto3|aws"` → nothing). "Use it with
  Bedrock" therefore means *writing* Bedrock support into someone else's app.

**Separately:** Bedrock is not on our approved allowlist today. ADR-026 lists Anthropic and OpenAI
only. Adding it needs a data-terms check and a `ComplianceProfile` entry **regardless** of whether
we ever touch this chatbot app.

**For our actual requirement, none of this matters** — three static links need no AI at all. The
finding is recorded because the capability would sit in our database, one tickbox from being live.

### 4.4 Finding 3 — it commits and rolls back our transaction (survives)

**WHAT.** `send_response()` calls `frappe.db.commit()` at lines 210 and 224. The AI error branch
calls `frappe.db.rollback()` at line 186.

**WHY it matters.** This code runs inside an `after_insert` hook — which means inside the webhook
request that is **still** writing the inbound message row, the `reference_name` update, the
conversation-window extension, the unread counter and the audit trail.

A `commit()` there ends our transaction early, at a point we did not choose. The `rollback()` is
worse: it discards **our** uncommitted work along with theirs.

Our own handler is careful about exactly this. `chat_api.py` has a deliberate comment explaining why
it must *not* roll back in a similar spot:

> *We cannot rollback here because the WhatsApp Message INSERT + reference_name SET are still
> pending in this transaction. Defer the metadata update to a fresh transaction instead.*

We solved this problem thoughtfully. Installing this app reintroduces it from outside.

**Transaction boundaries belong to the request, not to a hook.** This cannot be turned off with a
setting.

### 4.5 Finding 4 — a second store of patient message text (does NOT apply to us)

Recorded for completeness, and to correct an earlier claim of our own.

`WhatsApp Session Message.message` is a `Text` field holding patient message content verbatim. That
would be a **PHI-4** concern (duplicated PHI must be reachable by one erasure path), because our
erasure path does not know that table exists.

**But we checked, and it does not apply to keyword-only use.** `add_message()` is called from only
three places, all inside the flow engine:

```
flow_engine.py:169   session.add_message("Incoming", user_input, ...)
flow_engine.py:216   session.add_message("Outgoing", response, ...)
processor.py:275     session.add_message("Incoming", f"Flow completed: ...")
```

A plain keyword reply never creates a session and never writes this table. This objection was
raised in an earlier discussion and was **wrong for our scope**; it is withdrawn.

### 4.6 Two smaller things

- **Two responders on one event.** Our `hooks.py:326-328` already binds
  `WhatsApp Message → after_insert → chat_api.on_whatsapp_message_created`. Theirs binds the same
  doctype and event. Load order decides who runs first, and theirs is the one that commits.
- **Test coverage is thin for a clinical system.** 23 tests exist in `tests/test_chatbot.py`, but 6
  of those only assert that a doctype exists. Four further test files contain **zero** test
  functions. There are **no tests** on the AI responder, the consent behaviour, or the send path.

---

## 5. User stories

These are the point of this document. The findings above are mechanisms; the stories are what the
mechanisms do to real people.

### Story 1 — the patient who asked us to stop (Finding 1)

> **Elena Vargas** is the mother of a 4-year-old patient. She is tired of clinic messages, so she
> replies **`ALTO`** ("STOP") to a WhatsApp appointment reminder.
>
> → Our consent handler does its job: `is_stop_word("ALTO")` matches, `revoke_for_number()` runs,
> and her WhatsApp consent is withdrawn. **The database correctly contains** a revoked
> `Patient Communication Consent` row with reason *"Withdrawn by reply on WhatsApp"*.
>
> → But the chatbot's `after_insert` hook fires on the **same message**. `should_process()` checks
> message type, account, excluded-numbers and agent-transfer — all pass. `ALTO` is not a configured
> keyword, so it falls to stage 5 and sends `default_response`.
>
> → **Elena's phone buzzes again**, seconds after she asked us to stop. From her side, the clinic
> ignored her.
>
> **Consequence:** the withdrawal was honoured in the database and violated on the handset. This is
> the one failure a messaging integration must never have, and it is worse than not honouring the
> STOP at all — because our records will show we did, so nobody will believe the complaint.

### Story 2 — the helpful admin (Finding 2)

> **Marco**, a clinic administrator, wants the bot to answer "when is my appointment?". He has no
> access to the code and needs no deployment. He opens the Desk and creates a
> `WhatsApp AI Context` record:
>
> ```
> context_type      = DocType Query
> query_doctype     = Patient Appointment
> fields_to_include = patient_name, practitioner, appointment_date, department
> user_specific     = 1
> phone_field       = patient_mobile
> max_results       = 10
> ```
>
> → **The system shows** a working, genuinely helpful bot. Marco is pleased and tells his manager.
>
> → **What actually happens** is that every inbound message now ships up to 10 appointment rows —
> including `patient_name` and `department`, which in a paediatric clinic can itself be diagnostic
> — to OpenAI, under an API key stored in a Desk password field that no `ComplianceProfile` names.
>
> → **The database contains** no record of the disclosure. `AI Prompt Log` was never involved. The
> only trace is an outbound WhatsApp message that looks completely correct.
>
> **Consequence:** PHI sent to an unregistered subprocessor with no BAA, no audit trail, and no
> code change to review. Nobody did anything wrong by the app's own rules. Marco filled in a form.

### Story 3 — the message that vanished (Finding 3)

> A patient sends **"mi hijo tiene fiebre"** at 14:32.
>
> → Our webhook begins its transaction: insert the `WhatsApp Message` row, link
> `reference_name`, extend the 24-hour window, bump the unread count, notify the staff inbox, write
> the audit row.
>
> → Mid-way through, the chatbot's hook fires, sends a reply, and calls `frappe.db.commit()`
> (`processor.py:210`) — ending our transaction at a line we did not choose. Then a later step in
> our own handler hits a deadlock on the conversation row.
>
> → **The database now contains** a half-finished picture: some rows committed by someone else's
> hook, the rest rolled back into a state our deadlock recovery was not designed for.
>
> **Consequence:** a clinical message whose delivery state cannot be trusted. Our handler has a
> written comment explaining precisely why it must not roll back at that point — and an external
> hook does it anyway.

### Story 4 — the licence, eighteen months later (Reason 1)

> Remedisys wins a contract. During procurement, the customer's legal team asks for a software bill
> of materials — a standard request in healthcare.
>
> → The list shows `frappe_whatsapp_chatbot`, licensed under **Commons Clause**, whose clause 2
> forbids "including the Software in a paid product or service".
>
> → **What the codebase actually contains** is 2,597 lines of restricted third-party code, woven
> into the WhatsApp path, shipped to every paying clinic for eighteen months.
>
> **Consequence:** the cheapest outcome is an emergency removal of a live patient-facing feature
> under deal pressure. The worst is a licence dispute. And the whole thing was avoidable by reading
> one 34-line file **before** installing — which is exactly what this evaluation did.

---

## 6. "Can't we just tweak it?" — the honest comparison

This was the fairest challenge raised, and it deserves numbers rather than opinion.

**Yes, it could technically be tweaked.** The question is what that costs compared with writing the
feature ourselves. (Set the licence aside for this section — on licence grounds alone the answer is
already no. This is the argument that stands even if the licence were MIT.)

### What "tweaking" actually requires

| # | Change needed | Why | Difficulty |
|---|---|---|---|
| 1 | Patch `should_process()` to call our consent service | Finding 1 | Their app must now import **our** app — a circular dependency between two apps |
| 2 | Remove `commit()` ×2 and `rollback()` ×1 from `send_response()` | Finding 3 | Risky — their reply flow may depend on the commit; there are no tests to tell us |
| 3 | Delete `ai_responder.py` (283 lines), the `WhatsApp AI Context` doctype, and 4 fields on `WhatsApp Chatbot` | Finding 2, permanently | Schema change; a migration if ever installed |
| 4 | Add STOP-word handling | Finding 1 | New code in their processor |
| 5 | Resolve the double `after_insert` ordering | §4.6 | Load-order dependency between two apps |
| 6 | Fork, host, and maintain the result | all of it | **Forever, with no upstream to pull from** |

Every one of items 1–5 is a change to code we did not write, with no test suite covering the parts
we are changing, and no upstream maintainer to review it. That is not a tweak. **That is adopting
2,597 lines of someone else's code into a clinical PHI path, and taking ownership of it.**

### The numbers

| | Use their app (forked and patched) | Write our own |
|---|---|---|
| Lines we become responsible for | **2,597** | **~110** |
| Lines we would actually use | ~117 (`keyword_matcher.py`) | ~110 |
| New doctypes installed | **10** | **1** |
| Existing code reused | none | the whole inbound handler |
| Consent handling | must be added | **already there** |
| Transaction safety | must be fixed | **already correct** |
| Audit trail | must be wired | **already there** |
| Patient language (ES/EN) | must be added | **already built** |
| Tests on the parts we changed | none | we write them |
| Upstream to pull fixes from | **none** (1 commit, forked) | n/a — it is ours |
| Licence | **blocks commercial use** | MIT, ours |

**About 23× more code to maintain, to get the same three replies.**

### The one-line version

> **The patch we would have to write into their app is longer than the entire feature.**

And here is the proof. Our inbound handler already does every hard part — consent, the conversation
record, the 24-hour window, unread counts, the staff inbox, the audit trail, transaction safety.
The auto-reply goes on the line **after** the consent check that already exists at
`chat_api.py:118`:

```python
if is_stop_word(raw_body):
    revoke_for_number(doc.get("from"), reason=_("Withdrawn by reply on WhatsApp"))
# ← the auto-reply slots in right here, after withdrawal is honoured
```

That single integration point is the whole argument. Adopting their app means bolting a second
engine onto the side of a machine that is already running. Writing our own means adding one step to
a pipeline that already works.

### A note on when the answer would flip

If the requirement were **multi-step conversational booking** — "what date? / which doctor? /
confirm?" — then their 575-line flow engine would represent real work we would otherwise have to
do, and the trade would be genuinely close. It is not close, because the requirement is three
static links. **We are rejecting the app for this requirement, not for all time.**

---

## 7. The four options we considered

[`CLAUDE.md`](../CLAUDE.md) §10 requires at least four distinct approaches before a consequential
recommendation.

| Approach | Pros | Cons |
|---|---|---|
| **A.** Install as-is, AI fallback enabled | Fastest possible demo | Finding 2 live in production: any doctype to an unregistered LLM, configurable from the Desk. Licence breach. Not viable at any price |
| **B.** Install, `enable_ai = 0`, keywords only | Nothing to build; 10 doctypes of admin UI free | Licence breach. Findings 1 and 3 remain and cannot be configured away. `enable_ai` is one tickbox from Finding 2, with no review gate — a risk that survives in the schema is a risk we carry |
| **C.** Fork it, delete the AI module, add a consent gate | Keeps the flow engine; closes Finding 2 permanently | Licence travels with the fork, so still a breach. We own 98 files and 2,597 lines to use 117, with no upstream. Only pays off if we need flows — and we do not |
| **D.** Build ~110 lines in our own app **(chosen)** | MIT and ours. Reuses consent, audit, window, transaction safety and patient language. One doctype. Tested by us | No multi-step flows on day one |

**Why each rejected option loses, specifically:**

- **A** loses on Finding 2 alone — it is an unbounded PHI path with a Desk form in front of it.
- **B** loses on a precise mechanism, not on taste: `enable_ai` is a Check field and `ai_api_key` is
  a Password field, both editable by any clinic admin. Disabling the AI does not remove the risk, it
  defers it to whoever next clicks the box. And Findings 1 and 3 need code changes regardless, which
  turns B into C.
- **C** loses because its entire value is the flow engine, and nothing in the requirement needs
  multi-step flows. We would carry 2,597 lines to use 117.
- **All three** additionally lose on the licence, which no amount of engineering changes.

---

## 8. What we build instead

- **~50 lines** in `integrations/whatsapp/chat_api.py`, immediately after the existing consent
  check at line 118 — so withdrawal is always honoured **before** any reply is considered.
- **One doctype**, `Remedisys WhatsApp Auto Reply`: `keyword`, `language`, `reply_text`, `enabled`.
  Staff edit keywords in the Desk with no deployment. (This is the one genuinely good idea we are
  taking from their app — the idea, not the code.)
- **Replies in the patient's own language.** We already built `Patient.language` and
  `resolve_language()`, so Spanish-speaking patients get Spanish automatically. Their app has no
  concept of per-patient language.
- **Rate-limited per number**, and it never echoes the patient's own text back.
- **Nothing sent to any LLM** — so Bedrock, OpenAI, BAAs and ADR-026 do not enter into this feature
  at all. That is a deliberate design property, not an omission.
- **Tests** on the consent ordering and the unmatched-message fallback.

### Ideas worth copying (not code)

| Their idea | Our version |
|---|---|
| Agent transfer — bot stands down when a human replies | Worth doing; our `WhatsApp Conversation` already tracks staff replies |
| Business-hours gate | Useful later; out of scope for v1 |
| Excluded-numbers list | We have something better — real consent records |

### The safety line that must be in the fallback

The unmatched-message reply **must** say the number is not monitored. A parent who texts
*"mi hijo tiene fiebre de 40"* and receives a booking link may reasonably believe they have told the
clinic about a sick child. Out of hours, nobody is reading that inbox.

This is a clinical-safety requirement, not copywriting. It is the single most important string in
the feature.

---

## 9. What would change this decision

Recording this so the decision is falsifiable rather than just asserted:

1. **The licence changes to MIT or Apache-2.0.** This removes Reason 1 entirely. The technical
   findings would then have to be argued on their own merits — and §6 says they still lose for a
   three-keyword feature.
2. **The requirement grows into real multi-step conversations.** Their flow engine becomes genuinely
   valuable and option C is worth re-costing — *if* the licence has also changed.
3. **The app gains a maintained history.** One commit with no releases is not a dependency for a
   clinical system, whatever the licence says.

None of these are true today. All three would have to be, before this is worth reopening.

---

## 10. Current state

- The app was downloaded with `bench get-app` for this evaluation, so it sits in
  `apps/frappe_whatsapp_chatbot` and appears in the bench-level `apps.txt`.
- **It was never installed on any site.** Verified: `frappe.get_installed_apps()` on
  `mysite.localhost` does not list it. No doctypes were created, no hooks are active, nothing runs.
- Recommendation: **delete the directory**, so it cannot be installed by accident. Leaving
  restricted code in the bench is the one way this evaluation could still cause the problem it was
  written to prevent.
- Implementing option D **reverses** the "notification-only, no reply path" decision in
  [`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) §5, so it needs its
  own ADR before any code is written.

---

## 11. How to reproduce these findings

Everything above is checkable. Run from the bench root, against commit `e98a655`:

```bash
cd apps/frappe_whatsapp_chatbot

# Reason 1 — the licence
cat LICENSE                                   # Commons Clause, clause 2
head -2 ../frappe_whatsapp/license.txt        # MIT, for contrast

# Finding 1 — no consent handling anywhere
grep -riE "consent|opt.?in|opt.?out|unsubscribe|stop" --include="*.py" .   # → nothing
sed -n '64,89p' frappe_whatsapp_chatbot/chatbot/processor.py               # should_process()

# Finding 2 — arbitrary doctype into the prompt
sed -n '80,113p' frappe_whatsapp_chatbot/chatbot/ai_responder.py           # query_doctype()
sed -n '279,283p' frappe_whatsapp_chatbot/chatbot/ai_responder.py          # Custom is a stub
grep -riE "bedrock|boto3|aws" --include="*.py" .                           # → nothing

# Finding 3 — commit/rollback inside a hook
grep -n "db.commit\|db.rollback" frappe_whatsapp_chatbot/chatbot/processor.py

# Finding 4 — flows only, withdrawn for our scope
grep -rn "add_message" frappe_whatsapp_chatbot/chatbot/

# Size
find . -name "*.py" -not -path "*__pycache__*" | xargs wc -l | tail -1
git rev-list --count HEAD

# Not installed
cd ../../sites && ../env/bin/python -c "
import frappe; frappe.init(site='mysite.localhost'); frappe.connect()
print('frappe_whatsapp_chatbot' in frappe.get_installed_apps())"
```

---

## Related documents

- [`WHATSAPP_INTEGRATION.md`](WHATSAPP_INTEGRATION.md) — how the channel actually works
- [`security/WHATSAPP_HIPAA_COMPLIANT.md`](security/WHATSAPP_HIPAA_COMPLIANT.md) — §5 is the
  "notification-only" decision this feature reverses
- [`adr/adr-026-llm-provider-allowlist.md`](adr/adr-026-llm-provider-allowlist.md) — the approved
  LLM provider list
- [`adr/adr-030-llm-curated-tool-access.md`](adr/adr-030-llm-curated-tool-access.md) — the
  precedent for rejecting a third-party app on licence + LLM-data-access grounds
- [`adr/adr-060-patient-communication-consent.md`](adr/adr-060-patient-communication-consent.md) —
  the consent model Finding 1 breaks
- [`compliance/HIPAA_READINESS.md`](compliance/HIPAA_READINESS.md) — what we do and do not claim
- [`../CLAUDE.md`](../CLAUDE.md) — §9.9 PHI rules, §10 four-approaches rule, §11 hard don'ts

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-11 | Ashutosh (AI-assisted) | Added the tweak-vs-build summary table to the decision box |
| 1.0 | 2026-09-11 | Ashutosh (AI-assisted) | Initial evaluation of `frappe_whatsapp_chatbot` at commit `e98a655`; decision not to adopt, on licence grounds plus two unfixable-by-config technical findings |
