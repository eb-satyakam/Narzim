# Remedisys — Complete Platform & AI Handoff Brief

**Doc status:** record · **Created:** 2026-08-04 by Sarvesh-SocialAngel · **Updated:** 2026-08-04 by Sarvesh-SocialAngel · **Version:** 1.0

> **Purpose of this document.** A single self-contained explanation of everything built so far
> on the Remedisys healthcare platform, written for an outside reader (e.g. ChatGPT) that has
> **no access to the repositories**. Emphasis is on **how the AI actually works** — providers,
> models, prompts, pipelines, tool calling, guardrails, cost and audit.
>
> **Generated:** 2026-08-04 · **Source of truth:** the backend code + `docs/` + ADRs in
> `remedisys_healthcare_ai` as of this date. Where code and older design docs disagree, the code
> was taken as authoritative.

**Suggested opening line when you paste this elsewhere:**

> "Here is a full technical brief of a healthcare SaaS platform I'm building called Remedisys.
> It covers the whole product plus, in detail, the AI subsystem. Read it and then help me with
> [your question]. Don't assume anything not written here."

---

## Table of Contents

**Part A — The platform**
1. [What Remedisys is](#1-what-remedisys-is)
2. [Stack, repositories, deployment](#2-stack-repositories-deployment)
3. [Architecture and request path](#3-architecture-and-request-path)
4. [Roles and permissions](#4-roles-and-permissions)
5. [Functional modules built](#5-functional-modules-built)
6. [The core clinical flow, end to end](#6-the-core-clinical-flow-end-to-end)

**Part B — The AI (main section)**
7. [AI ground rules — the safety contract](#7-ai-ground-rules--the-safety-contract)
8. [Shared AI infrastructure](#8-shared-ai-infrastructure)
9. [AI Feature 1 — Encounter Copilot ("Narzim AI" in the encounter)](#9-ai-feature-1--encounter-copilot-narzim-ai-in-the-encounter)
10. [AI Feature 2 — Lab report extraction](#10-ai-feature-2--lab-report-extraction)
11. [AI Feature 3 — Lab summaries and lab chat](#11-ai-feature-3--lab-summaries-and-lab-chat)
12. [AI Feature 4 — Patient Clinical Summary (rolling)](#12-ai-feature-4--patient-clinical-summary-rolling)
13. [AI Feature 5 — General Narzim AI Assistant (sidebar)](#13-ai-feature-5--general-narzim-ai-assistant-sidebar)
14. [Cost, audit and retention across all AI](#14-cost-audit-and-retention-across-all-ai)
15. [AI data model — every AI doctype](#15-ai-data-model--every-ai-doctype)

**Part C — Reality check**
16. [Known gaps, risks and open decisions](#16-known-gaps-risks-and-open-decisions)
17. [Glossary](#17-glossary)

---

# PART A — THE PLATFORM

## 1. What Remedisys is

A **multi-tenant clinical operations SaaS for clinics**, built on top of ERPNext Healthcare
(Frappe framework). Primary market is **Mexico** (Spanish `es-MX` + English `en-US`), with India
as a second pluggable jurisdiction. Compliance profiles: Mexico = LFPDPPP + NOM-024-SSA3-2010;
India = DPDPA 2023 + ABDM. Selected per-site by a `remedisys_compliance_profile` config key.

It covers the full patient visit lifecycle: registration → appointment → check-in → vitals →
encounter (consultation) → orders (medications, labs, procedures, therapies, vaccines) →
billing → results → follow-up. On top of that sits an **AI layer** that listens to the
consultation, drafts the clinical note, reads uploaded lab/imaging reports, and answers
clinician questions.

Two important framings:

- **It is a healthcare platform first, an AI product second.** The rule from day one was: every
  clinical screen must work fully with real data *manually*, and AI is added on top as an
  assistive layer that can be switched off without breaking anything.
- **The AI never finalizes anything clinical.** Every AI output is a *draft suggestion* the
  clinician reviews, edits or discards. Persistence to the medical record only happens when a
  human clicks Save or Sign.

There are actually **three front-facing products**:

| Product | Who uses it | Repo |
|---|---|---|
| Clinic / staff app | Front desk, nurses, doctors, clinic admins | `EB_Healthcare_EHR` (local checkout: `Healthcare_next_app`) |
| Patient portal | Patients — book, view records, labs, chat with the clinic | `EB_Healthcare_PatientPortal` |
| Marketing/marketplace site | Public | `EB_Healthcare_Marketplace`, `Remedisys-Frontend` |

---

## 2. Stack, repositories, deployment

**Backend**
- Frappe Framework **v16**, ERPNext v16, **ERPNext Healthcare** v16
- Python **3.14+**, MariaDB 11+, Redis 7 (cache + queue)
- Background jobs: Frappe RQ workers (in-app; no separate FastAPI/Celery service)
- Deployment: **Frappe Cloud** (managed)
- All custom code lives in ONE custom app: **`remedisys_healthcare_ai`**. Frappe/ERPNext/
  Healthcare core files are never modified — customization only via hooks, overrides, custom
  fields (fixtures), migration patches and whitelisted methods. Uninstalling the custom app must
  leave the healthcare system fully functional (this is a CI gate).

**Other installed Frappe apps:** `eb_frappe_jwt` (auth), `frappe_whatsapp`, `payments`,
`clefincode_chat`, `telephony`.

**Frontend**
- Next.js (App Router) + TypeScript + shadcn/ui, deployed on **Vercel**
- Bilingual via message catalogs (`en` / `es-MX`) — no hardcoded user-visible strings
- **BFF pattern**: the browser never talks to Frappe directly and never holds a token. Next.js
  route handlers hold the JWT server-side (httpOnly cookie / NextAuth) and proxy to Frappe.

**Auth**
- `eb_frappe_jwt` **Bearer JWT**. Login → `get_token`, refresh with single-use rotation →
  `refresh_token`, logout → `revoke_token`. 2FA is backend-ready but the frontend flow is
  deferred.
- All app users (including admins) are **Website Users** — no Frappe Desk access.

---

## 3. Architecture and request path

```
Browser (Next.js app on Vercel)
   │   no token in the browser — session cookie only
   ▼
Next.js route handler (BFF)  ── injects Authorization: Bearer <JWT> ──┐
                                                                      ▼
                                            Frappe Cloud (remedisys_healthcare_ai)
                                            api/v1/<module>/api.py      ← whitelisted method
                                              • auth + permission check
                                              • delegates to…
                                            services/<module>.py        ← business logic, ORM
                                              ▼
                                            MariaDB (ERPNext Healthcare doctypes)
```

Hard rules that shape everything:

- **No use of Frappe's generic `/api/resource/` endpoints.** Every read/write goes through a
  named, permission-checked whitelisted method in `api/v1/<module>/api.py`. This is what makes
  the AI tool layer safe later — there is no generic CRUD surface to expose.
- Clinical data lives in **core ERPNext Healthcare doctypes** (Patient, Patient Appointment,
  Patient Encounter, Vital Signs, Lab Test, Service Request, Medication Request, Immunization,
  Clinical Procedure, Sales Invoice…). Custom doctypes only exist where core has no equivalent
  (AI records, clinic settings, immunization scheduling, WhatsApp, portal chat, etc.).

---

## 4. Roles and permissions

Application roles are all prefixed **`EB_`** and all have `desk_access = 0`:

| Role | Scope |
|---|---|
| `EB_Front Desk` / `EB_Clinic Staff` | Appointments, check-in, billing, POS, documents |
| `EB_Nurse` | Vitals, lab sample collection, immunization administration, nurse-draft writes to encounters |
| `EB_Practitioner` (doctor) | Encounters, diagnoses, prescriptions, orders, signing, full patient chart |
| `EB_Healthcare Admin` | Clinic settings, staff, master data, reports, AI usage visibility |
| Patient (portal user) | Their own record only |

Permissions for `EB_` roles are rebuilt through a **migration patch driven by a spec file**
(`eb_docperm_spec.json`), not a fixture. Missing permissions are fixed by editing that spec and
adding a dated re-apply patch — never by bypassing permissions in code.

Notable enforced rules:
- Only the **assigned practitioner** can sign an encounter (admins have a narrow override path).
- Portal users can only reach `_my_*` endpoints scoped to their own patient record.
- Row-level scoping (e.g. private AI assistant threads) is done via Frappe
  `permission_query_conditions`.

---

## 5. Functional modules built

Everything below is **built and working against real data** unless marked otherwise. Endpoint
counts are indicative of scope, not exhaustive.

| Module | What it does |
|---|---|
| **Auth** | Login/refresh/logout, current user, profile update, password change + reset, notification preferences |
| **Patients** | Full CRUD, MRN, guardians (pediatric), demographics, favorites, **Patient Chart 360**: overview, visits, medications, immunizations, clinical activity, documents |
| **Appointments** | Slot availability, booking (atomic patient+appointment creation in one transaction), booking with payment, reschedule, reassign, cancel, confirm, check-in, practitioner schedules, holiday lists |
| **Encounters** | Start (idempotent, from an appointment or walk-in), draft save, chief complaint, symptoms, diagnoses, orders (medications / labs / procedures / therapies / vaccines), treatment-plan templates, sign & submit, cancel with cascade, follow-up booking + assignment to front desk |
| **Vital Signs** | Create/update/list, auto BMI and BP calculation, nurse-entered drafts auto-linked to the encounter, auto-submitted on sign, configurable vital-sign templates |
| **Labs** | Lab Test Templates, lab parameter master, analyte aliases, unit conversions, order creation via Service Request, pending order worklist, result entry, imaging/descriptive results, report attachment, submit, trends |
| **Immunizations** | Mexico EPI schedule, immunization programs/templates/dose schedules, nurse administration handoff, two-part billing at administration |
| **Clinical** | Allergies, conditions, medical history, surgical history |
| **Procedures / Therapies** | Clinical procedure templates and lifecycle (create → start → complete → submit → cancel), therapy types |
| **Billing** | Invoices from encounters and appointments, payment collection, consolidated front-desk POS, cash drawer / shift reconciliation, internal vs external order tagging (per-company), payment methods. *Insurance claim submission is deliberately deferred.* |
| **Documents** | Clinical documents, categories, attachments, per-user sharing, patient-uploaded documents |
| **Messages / Chat** | Internal staff threads, WhatsApp conversations (via `frappe_whatsapp` + a custom configurable notification trigger system), **Portal Chat** as a separate thread from WhatsApp (ADR-037) |
| **Tasks / My Work** | ToDos and Tasks, per-role work queues, follow-up tasks |
| **Dashboard** | KPIs, room queue / patient flow state machine, command center |
| **Reports** | Daily patient flow, no-show analysis, queue wait times, check-in rates, provider patient volume, utilization |
| **Admin** | Staff invite/management, practitioners + schedules + profiles, service units, clinic settings, setup checklist, role permission viewer, and a large **master-data catalog** area (appointment types, medications, dosage forms, medication classes, prescription dosages/durations, lab templates, lab UOMs, therapy types, procedure templates, complaints, diagnoses, brands, manufacturers, items, insurance, payment methods, genders, treatment plan templates) |
| **Patient Portal** | Self-registration, clinics/practitioners/doctor profiles, slot search, book/cancel/reschedule own appointments, health record, own labs + lab summary, own encounters, own documents, own vitals, next follow-up, portal chat |
| **Demo data** | A generator that seeds/removes realistic test data for demos and sandboxes |

---

## 6. The core clinical flow, end to end

This state machine is shared by the dashboard queue, the patient chart and the AI copilot.

```
1. BOOK            Patient + Patient Appointment created atomically
                   status: Open        room: Arriving Soon
        ↓
2. CONFIRM         front desk confirms
                   status: Confirmed   room: Waiting Room
        ↓
3. VITALS          nurse records Vital Signs (Draft), linked to the appointment
                   check-in → status: Checked In   room: Nursing Room
        ↓
4. START ENCOUNTER doctor opens the encounter (idempotent)
                   • the nurse's Draft Vital Signs are auto-linked onto the encounter
                   • Healthcare core closes the appointment as soon as the draft exists
                   room: Practitioner Room
        ↓
5. AI ASSISTS      recording + live suggestions, "Analyze" pill, "Ask Narzim AI" chat
                   → everything lands in the draft as an editable item with a ✦ AI badge
                   → NOTHING is saved yet
        ↓
6. DOCTOR DECIDES
   ├── SIGN        chief complaint required; docstatus 0 → 1 (submit)
   │               • draft Vital Signs auto-submitted
   │               • Immunization docs created for administered vaccines
   │               • Healthcare core creates lab orders / invoicing from the signed draft
   │               • a patient-facing plain-language visit summary is generated
   └── CANCEL      cascades to cancel the linked appointment;
                   cancels an UNPAID linked invoice; a PAID one is left for a
                   deliberate refund through the credit-note flow
```

---

# PART B — THE AI

## 7. AI ground rules — the safety contract

These are enforced architecturally, not just by prompt text. They explain *why* the AI code
looks the way it does.

| Rule | Meaning in practice |
|---|---|
| **No direct DB access for the LLM** | The model never sees SQL, never runs Python, and has no generic CRUD. Its only path to data is a **fixed registry of typed, permission-checked, audited tool functions** defined in code. |
| **No full-history dumping** | Tools return bounded, summarized data (e.g. max 8 labs, max 5 prior encounters, last 6000 characters of transcript). One deliberate exception is the patient clinical summary — see §12. |
| **Physician in control** | AI "write" tools **never touch the database**. They return a suggestion object that lands in the on-screen draft with an AI badge. Only the clinician's own Save/Sign persists anything. |
| **AI failure must not break healthcare** | If Deepgram or the LLM provider is down, the encounter form still loads, the doctor still writes manually, and the AI panel shows an unavailable state. Every AI feature is behind a feature flag defaulting to OFF. |
| **Pipelines over agents** | Deterministic pipelines with explicit state and retry. The one tool-calling agent that exists is a **bounded single turn** (hard cap on tool round-trips), not an autonomous loop. |
| **No PHI in logs** | Application logs carry IDs only. The audit doctype (`AI Prompt Log`) stores model, token counts, cost, latency, status and **tool names** — not prompt text or replies. (One deliberate exception: the lab-extraction audit row stores the model's raw JSON because that *is* the clinical record of what was extracted — it's a record, not a log sink.) |
| **Prompts are never inline in code** | Every system prompt is a versioned `.txt` file loaded at runtime; its version and SHA-256 hash are recorded with the call. |
| **Provider is pluggable, from an approved allowlist** | Anthropic and OpenAI today. Adding a provider requires a data-processing-terms check against the active compliance profile plus a shared-interface implementation. No "any LLM" free-for-all. |

---

## 8. Shared AI infrastructure

### 8.1 Provider abstraction

```python
services/llm.py::get_llm_client()
    reads AI Settings.llm_provider  →  "Anthropic" | "OpenAI"
    returns integrations/anthropic.py  or  integrations/openai.py
```

Both integration modules implement the **same function names and return shapes**, so every
feature calls through `get_llm_client()` and swapping providers is a settings change, not a code
change. Shared function surface includes:

- `ask_copilot_agent(prompt, history, ctx, tools, call_tool)` — the bounded tool-calling loop
- `generate_suggestions(transcript, ctx)` — live incremental suggestions
- `generate_soap_draft(...)` — one-pass SOAP note
- `generate_review_details(...)` — patient-facing visit summary
- `resegregate_speakers(...)` — repair a garbled diarized transcript
- `answer_lab_question(...)`, `answer_general_question(...)`, `answer_document_question(...)`
- `summarize_document(files)` — native multimodal PDF/image reading
- `infer_medication_fields(...)`, `infer_lab_fields(...)` — structured field inference
- `_estimate_cost` / `_pricing_for_model` — per-provider cost estimation

There is also `integrations/groq.py` (Groq **whisper-large-v3**) which exists but is **not
wired to anything** — a deferred alternative ASR path.

### 8.2 `AI Settings` (a Frappe Single doctype — the control panel)

| Group | Fields |
|---|---|
| **Feature flags** (all default OFF) | `enable_ambient_documentation`, `enable_soap_generation`, `enable_safety_validators`, `enable_suggestions`, `enable_lab_extraction`, `lab_upload_monthly_limit` (50) |
| **LLM** | `llm_provider` (Anthropic \| OpenAI; default Anthropic) · `anthropic_model` (`claude-haiku-4-5` \| `claude-sonnet-4-6` \| `claude-opus-4-8`; default sonnet) · `openai_model` (`gpt-4o` \| `gpt-5` \| `gpt-5-mini`) · `openai_reasoning_effort` (minimal/low/medium/high; default **low**) · `suggestion_country` override (Mexico/India) · `llm_temperature` 0.2 · `llm_max_tokens_out` 4096 · `llm_context_token_budget` 4000 · `narzim_assistant_max_tokens` 350 |
| **ASR** | `deepgram_model` (`nova-3-medical` \| `nova-2-medical` \| `nova-3` \| `nova-2`) · `deepgram_language` (`en`/`en-US`/`en-GB`/`es`/`es-MX`/`multi`) · `deepgram_diarize` · `deepgram_multichannel` (dual-mic) · `deepgram_cost_per_minute_usd` (0.0077) |
| **Session** | `idle_timeout_seconds` 300 · `max_session_minutes` 60 |
| **Retention** | `retain_audio` OFF · `audio_retention_days` 0 · `transcript_retention_days` 2555 (7y) · `soap_draft_retention_days` 2555 · `prompt_log_retention_days` 365 |

The live encounter-copilot deployment currently runs **OpenAI `gpt-5-mini` with
`reasoning_effort=low`** (chosen over `gpt-4o-mini`, which was rejected on clinical-safety
grounds), with Deepgram `nova-3` + `language=multi` + keyterm prompting.

### 8.3 Prompt files

Two prompt directories, both plain `.txt`, both loaded at runtime with a hash recorded:

**`prompts/` (repo root)** — the encounter copilot + general assistant. Every file has a
manifest row in `prompts/README.md`, and the rule is: a prompt may not be deleted without
grepping for zero references, and the manifest must be updated in the same commit.

| File | Used by |
|---|---|
| `ask-copilot-v2.txt` | the tool-calling agent — both the Analyze pill **and** the chat box |
| `suggest-v2.txt` | live incremental suggestions during recording |
| `soap-v1.txt` | end-of-visit one-pass SOAP draft |
| `review-details-v1.txt` | patient-facing plain-language visit summary at Sign |
| `resegregate-v1.txt` | rebuild a garbled speaker-diarized transcript (words never changed, only re-split/re-labeled) |
| `medication-fields-v1.txt`, `lab-fields-v1.txt` | structured field inference when a doctor confirms a brand-new medication or lab template |
| `narzim-assistant-v1.txt` | the general (patient-agnostic) sidebar assistant |
| `narzim-thread-title-v1.txt` | auto-titling assistant chat threads |
| `narzim-assistant-phi-check-v1.txt` | orphaned — see §13 |

**`remedisys_healthcare_ai/llm/prompts/`** — the lab/document/patient-summary family, versioned
by number (`_v1` … `_v10`) and selected by a `prompt_version` argument in code:
`lab_extraction_v1..v10`, `multi_panel_extraction_v1..v9`, `imaging_transcription_v1`,
`lab_result_summary_v1..v3`, `lab_report_summary_v1..v2`, `patient_lab_summary_v1..v3`,
`patient_clinical_summary_v1..v2`, `patient_chat_v1..v6`, `lab_chat_v1..v2`, `report_chat_v1`,
`report_narrative_summary_v1`, `document_summary_v1..v4`.

### 8.4 The audit row — `AI Prompt Log`

One row per LLM invocation, across **every** AI feature. Fields: `patient`, `encounter`,
`lab_test`, `service_request`, `purpose`, `model`, `prompt_version`, `prompt_hash`,
`tokens_in`, `tokens_out`, `cost_estimate_usd`, `latency_ms`, `status`, `error`, `source_file`,
`tools_used` (names only), plus extraction-specific fields (`raw_response`, `filled_rows`,
`qualifier_conflicts`).

`purpose` enumerates every AI call site in the product:

```
Lab Extraction · Imaging Transcription · Multi-Panel Extraction · Lab Result Summary
Patient Lab Summary · Report Lab Summary · Patient Clinical Summary · Lab Chat
Copilot Transcribe · Copilot Suggestions · Copilot SOAP Draft · Copilot Chat
Copilot Review Details · Narzim Assistant Chat · Narzim Assistant Document Check
Narzim Assistant Thread Title
```

---

## 9. AI Feature 1 — Encounter Copilot ("Narzim AI" in the encounter)

This is the flagship feature: an ambient scribe + tool-calling clinical assistant that lives
inside the consultation screen.

> **Naming warning.** The product has **two** things branded "Narzim AI":
> (a) the in-encounter copilot described here, and (b) a separate patient-agnostic sidebar
> assistant (§13). Different backends, different data scope. Don't conflate them.

### 9.1 Speech → transcript (ASR)

**Live path (during the consultation):**

1. The browser captures the mic. Single-mic → `MediaRecorder`, `audio/webm;codecs=opus`,
   250 ms chunks. Dual-mic → raw linear16 PCM @ 48 kHz.
2. Frontend calls `start_session` → the backend mints a **short-lived Deepgram token** via
   Deepgram's `/v1/auth/grant` and returns `{url, token, ttl_seconds, params}`. The frontend
   opens the WebSocket to that URL **verbatim** — it never builds Deepgram params itself, so all
   ASR configuration is server-controlled.
3. Deepgram streams back interim + final results; the frontend assembles segments and posts them
   to `append_segment`, which appends to `AI Transcript Segment` (append-only: speaker, text,
   timing, confidence).
4. Session lifecycle: `get_active_session`, `refresh_deepgram_token`, `stop_session`,
   `get_encounter_transcript`, `sync_transcript`, plus a realtime fan-out helper
   (`publish_to_encounter`) over Frappe's SocketIO. Consent gate, idle timeout (300 s) and a max
   session length (60 min) are enforced on the session doctype.

**Current ASR configuration and why:** `nova-3` with `language=multi` (multilingual) rather than
`nova-3-medical`. The clinic has a **Scottish-accented doctor and EN/ES patients**; the
US-clinical-tuned medical model handled that badly. To recover drug-name accuracy without the
medical model, the backend uses **keyterm prompting** — it pulls distinct cleaned medication
generic names out of the Medication master and sends them as `keyterm` params (nova-3 only;
nova-2 uses `keywords` and rejects `keyterm`). Deepgram caps keyterms, so the list is capped at
50 entries, and any failure building the list is swallowed so a keyterm problem can never stop
transcription.

Speaker separation is **either** multichannel (each speaker on their own audio channel, dual-mic)
**or** diarization — never both; when multichannel is on, `diarize` is omitted and speakers come
from `channel_index`.

**Batch path:** `transcribe_audio` sends a whole audio blob to Deepgram (`nova-2-medical` by
default) — used for **imaging-result dictation**, not the live sidebar.

**Transcript repair:** `resegregate_transcript` sends a garbled diarized transcript to the LLM
with instructions to **re-split and re-label speakers only — never change the words**.

**Audio retention is OFF by default.** Only transcripts are kept (7-year default retention).

### 9.2 Live incremental suggestions (during recording)

While recording, the transcript is periodically sent to `generate_suggestions`
(prompt `suggest-v2.txt`). It returns clinical suggestions — symptoms, diagnoses, medications,
labs, procedures, therapies, vitals — that appear in the panel as the conversation happens. For
latency, the work is **split in parallel** (narrative vs. decisions). It is gated by
`AI Settings.enable_suggestions`, which genuinely blocks the call (this was previously a
non-functioning flag; it was wired up properly).

The prompt is given the **real master catalogs** (Medication, Lab Test Template, Therapy Type,
Clinical Procedure Template, Diagnosis, Complaint) plus validated enums for prescription dosages
and durations, and is told to reuse an exact catalog match rather than invent a near-duplicate.
That last part matters for a specific bug class: one invalid enum value in a suggestion used to
400 the entire encounter save.

### 9.3 One-pass SOAP draft

`generate_soap_draft` (prompt `soap-v1.txt`) takes the whole transcript in a single call and
produces a comprehensive SOAP note stored as an **`AI SOAP Draft`** (versioned per
regeneration, with an `accepted_by_physician` flag). Endpoints: `generate_soap_draft`,
`accept_soap_draft`, `discard_soap_draft`.

### 9.4 The tool-calling agent — the heart of the system

Two UI surfaces, **one backend mechanism**:

- The **"Analyze" pill** → `analyze_encounter` — reviews the entire transcript + conversation
  and fills the whole draft in one pass.
- The **"Ask Narzim AI…" chat box** → `ask_copilot` — one typed question, same tool registry,
  persisted as chat.

**Request flow:**

```
Doctor clicks Analyze / types a question
   ↓
Next.js BFF  →  ask_copilot / analyze_encounter   (physician's own Bearer token)
   ↓
_require_auth  +  _require_encounter_read
allow_write = has_permission(Patient Encounter, "write")
ctx = build_encounter_context(encounter)      ← bounded context, not a history dump
   ↓
ask_copilot_agent(prompt, history, ctx, tools, call_tool)
   │
   ├── loop, capped at _MAX_TOOL_ITERATIONS = 20 round-trips:
   │      • the ENTIRE accumulated message list is re-sent each round-trip (no prompt caching)
   │      • model requests one or more tool calls
   │      • execute_tool(name, args)
   │           READ  tool  → bounded query against Frappe/MariaDB
   │           WRITE tool  → validate args against JSON schema, return a SUGGESTION OBJECT
   │                         (it does not touch the database at all)
   │      • tool result is fed back as a "tool" message
   └── model returns final text → loop ends
   ↓
log_prompt_call()  → one AI Prompt Log row (model, tokens, cost, latency, tool NAMES, no content)
persist the turn   → AI Encounter Chat Message
   ↓
{reply, actions[], patient_draft, follow_up}  →  frontend
   ↓
each suggestion lands in the draft form with a ✦ AI badge, fully editable
   ↓
Doctor reviews / edits / discards → Save or Sign  ← the ONLY step that persists anything
```

**The tool registry** (`services/ai_tools.py::TOOL_REGISTRY`) — **36 tools: 13 read, 23 write.**

*Read tools (return bounded, summarized JSON):*

| Tool | Bound |
|---|---|
| `get_patient_labs` | max 8 labs, max 6 items per test |
| `get_previous_encounters` | max 5 (default 3) — diagnosis, orders, plan, date, status |
| `get_current_transcript` | last 6000 characters |
| `get_encounter_state` | everything currently in the draft; the model is instructed to call this **before** claiming something is absent |
| `get_appointment_details` | the originating appointment (`has_appointment: false` for a walk-in) |
| `get_vaccine_catalog` | this facility's own immunization schedule |
| `get_lab_analysis` | AI interpretation of one named lab test (cached if already analyzed) |
| `search_medication_catalog` · `search_lab_catalog` · `search_diagnosis_catalog` · `search_procedure_catalog` · `search_therapy_catalog` · `search_complaint_catalog` | each: permission check + `like %query%` + `disabled = 0` + `limit 10`, returning `{matches, match_count}` |

*Write tools (validate against a JSON schema, return a draft suggestion — never a DB write):*

`add_medication`, `add_lab`, `add_procedure`, `add_therapy`, `add_diagnosis`, `add_symptom`,
`add_vital`, `add_chief_complaint`, `add_review_details`, `add_follow_up`, `add_vaccine`,
`add_allergy`, `add_patient_medication`, `add_medical_history`, `add_surgical_history`,
`set_patient_summary`, plus `remove_*` mirrors for the order/diagnosis/symptom categories.

**The catalog-matching pattern** — this is the most important design detail in the agent:

- For every category the model can add, it is instructed to call the matching `search_*_catalog`
  tool **first**. On a hit it reuses the catalog entry **verbatim** (exact name, dosage form,
  strength; for diagnoses, the ICD-10 code already baked into the catalog name is reused rather
  than re-derived). On zero matches it may still propose a new free-text entry — the physician
  can accept it, which creates a new master record through `create_master`.
- **`add_vaccine` is the single blocking exception.** It must match an entry from
  `get_vaccine_catalog`; a non-match is refused outright and never auto-created, because a
  vaccine needs an admin-configured dose schedule that a bare name cannot supply.
- `add_follow_up` validates against a fixed enum, not a catalog.

**Other copilot endpoints:** `get_ai_flags`, `enhance_text`, `mint_deepgram_token`,
`list_encounter_labs`, `analyze_lab`, `get_encounter_chat`, `get_encounter_threads`,
`create_master`, and `upload_and_analyze_document` (attach a PDF/image inside the encounter and
have the model read it — this one **is** safe to send raw bytes because it is gated by
`_require_encounter_read`, i.e. the caller is already authorized for that patient).

### 9.5 Chat persistence

There is **no separate "session" doctype**. A conversation is simply every
`AI Encounter Chat Message` row sharing the same client-generated `thread` UUID, filtered by
encounter. The history sidebar is built by grouping messages by thread server-side
(`get_encounter_threads`). Each row stores role, content, `actions_json`, `kind`
(`chat` | `analysis`), and model/tokens/latency.

The copilot also has UX behaviors worth knowing: auto-start and resume of recording, stop/resize
controls, auto-pause, and per-encounter chat memory.

### 9.6 At sign-off — the patient-facing summary

`generate_review_details` (prompt `review-details-v1.txt`) produces a **plain-language visit
summary for the patient**, generated at Sign, in the compliance profile's primary language.

### 9.7 Measured cost and latency (real run, 2026-07-28)

A fever-and-cough consultation (under 200 words of transcript) run through the Analyze pill:

| Metric | Value |
|---|---|
| Tool calls in the turn | 18 |
| Round-trips to the model | ~19 |
| `tokens_in` (summed across round-trips) | 166,672 |
| `tokens_out` | 1,813 |
| Cost (gpt-5-mini @ $0.25 / $2.00 per Mtok) | **$0.0453** |
| Latency | **50.4 seconds** |

**The dominant cost driver is tool-call protocol overhead, not transcript size.** Because the
loop re-sends the entire accumulated message list on every round-trip and there is no prompt
caching, `tokens_in` for one Analyze is the *sum across all round-trips*. Cost scales roughly
linearly per invocation with no caching discount today. Model pricing is resolved by
**longest-prefix match** (OpenAI returns dated snapshot IDs like `gpt-5-mini-2025-08-07`, which
an exact-match lookup would miss and silently price at a more expensive default — that was a
real bug, fixed).

---

## 10. AI Feature 2 — Lab report extraction

**The problem it solves.** The clinic sends some tests to external labs. The lab bills the
patient directly and hands them a PDF. Somebody has to type that PDF into the EHR. This feature
is the *result-entry method for the external lab path*.

The order spine is **Service-Request-anchored** (ERPNext-correct): an encounter submit creates a
`Service Request` per ordered test, tagged `source = "Direct"` (in-house, billed) or
`"External Referral"` (outside lab, recorded but **not charged**). Both paths converge on the
same core `Lab Test` record with `Normal Test Result` child rows — no new reading doctype, no
core modification.

### 10.1 Single-template extraction

`upload_lab_report` → `extract_lab_report` → `get_extraction_status`. One LLM call reads the PDF
and returns the analyte values for the already-ordered test. Supporting logic:

- **Analyte matching** is name-first, with an LLM-assisted EN/ES matching step and a
  `Lab Analyte Alias` doctype for learned synonyms.
- **Unit conversion** happens at review/display time (`Lab Unit Conversion` master), so the
  reviewer sees a value already converted into the template's unit rather than the raw report
  unit.
- **Qualifier conflicts** (e.g. the report prints "Direct bilirubin" but the ordered analyte is
  "Total") are held back and recorded rather than silently mapped.
- **Duplicate detection** — file hashes and report metadata are checked so the same report
  isn't extracted twice, and a patient-name mismatch between the report and the record raises a
  warning.

**Crucially (ADR-021): the pipeline never writes to the Lab Test draft.** It only *proposes*.
The proposed rows live in the `AI Prompt Log` row (`filled_rows`), the frontend renders them as
editable unsaved form state, and only the clinician's own `record_result` /
`record_imaging_result` / submit persists a value. A re-extraction therefore cannot clobber a
manual edit, because there is nothing to clobber.

### 10.2 Multi-panel extraction

One PDF often contains many independent panels (CBC + Lipid + Thyroid + HbA1c + Vitamin D …).
The multi-panel pipeline handles this with a deliberate strategy: **one LLM call per upload,
then deterministic bucketing in Python** — rather than "classify templates, then re-extract per
template." That's roughly 9× fewer LLM calls and it reuses the already-hardened index-based
matcher instead of adding a new classification step.

Endpoints: `upload_lab_report_package`, `get_panel_extraction_status`, `create_order_for_panel`,
`finalize_section_order`, `ignore_panel`, `search_analytes`, `map_unmapped_as_alias`,
`add_analyte_to_template`, `create_template_from_section`, `create_imaging_order_from_narrative`.

Rules:
- **A detected-but-unordered panel is never auto-ordered.** The physician must explicitly create
  the order.
- **No extracted data is discarded** — unmatched values are surfaced for mapping.
- **Continuous learning without a review queue**: adding a synonym alias needs no elevated
  permission (it never touches a clinical template); adding a new analyte to a template or
  creating a new template is gated purely by Frappe's existing `Lab Test Template` write
  permission — *that permission check is the approval*, applied at the moment of the action.

### 10.3 Narrative / imaging reports

Genetic, pathology, imaging and functional-study reports have no discrete analyte rows. They are
created as **Imaging-type Lab Tests** whose entire result is one free-text `descriptive_result`
field (one real example was 40,615 characters). `upload_imaging_report` /
`extract_imaging_report` handle transcription of these, and there's a dictation path where a
radiologist speaks the result and Deepgram transcribes it.

These narrative reports produce no High/Low flags and no trend points — but their **content**
does now feed the stored patient-wide lab summary and the clinical summary (ADR-035), which it
previously did not.

### 10.4 Guardrails on this feature

Gated by `AI Settings.enable_lab_extraction` (default OFF) with a `lab_upload_monthly_limit`
(default 50). Every call is logged to `AI Prompt Log` with `purpose = Lab Extraction` /
`Multi-Panel Extraction` / `Imaging Transcription`. This is the one place where the model's raw
JSON response **is** stored — deliberately, because it's the clinical audit trail of what was
extracted from the patient's own report.

There is also a **PHI-stripped external lab report analyzer**: a patient uploads a lab PDF and
gets a Claude-generated summary, with identifying details stripped first.

---

## 11. AI Feature 3 — Lab summaries and lab chat

There are three distinct lab-summary surfaces, and their relationship changed over time:

1. **Per-test summary (retired as the user-facing summary).** A terse "All N results within
   normal range" line generated per Lab Test. Superseded (ADR-033).
2. **Report summary (the current one).** Generated once per uploaded multi-panel report — a
   richer narrative explaining the whole report, plus per-abnormal flags and every item row.
   When the physician clicks Done on the review screen, `save_report_summary(lab_tests, summary,
   chat)` writes that already-generated payload into **every** Lab Test the report created
   (reusing the existing `custom_ai_summary` JSON field rather than adding a new doctype). **No
   new LLM call happens at Done** — the payload the physician just reviewed is persisted as-is.
   A hand-entered Lab Test has an empty summary and shows a "Not uploaded by AI" badge.
3. **Patient-wide lab summary + assistant.** A panel summarizing all of a patient's labs, with a
   chat.

**Chats around labs:**

- `ask_report_question(extraction, question, history)` — stateless Q&A scoped to one report's
  extracted values + summary. The review-screen transcript is accumulated client-side and saved
  with the summary on Done; afterwards it is **read-only** history on the Lab Test detail.
- `ask_lab_question` — the **patient-portal lab assistant**. Read-only over the whole patient
  record, **no tool access at all** (plain system + history + user turn). Persisted as
  `AI Patient Chat Message`. Endpoints: `list_patient_chat`, `set_patient_chat_feedback`,
  `get_patient_summary`, `regenerate_patient_summary`, `preview_patient_summary`,
  `preview_report_summary`, `get_result_summary`, `retry_result_summary`.
- Feedback steering: user feedback on a summary/answer is fed back into subsequent generations.

---

## 12. AI Feature 4 — Patient Clinical Summary (rolling)

A cross-encounter, whole-record clinical summary of a patient, stored in
**`AI Patient Clinical Summary`**. This is the one feature that deliberately relaxes the
"no full history" rule, and the design is worth understanding because it's how that's made
affordable.

**Sources read:** Patient demographics (sex, age, blood group, allergies, medical history),
Patient Encounter, Vital Signs, Lab Test, Medication Request, Immunization, Clinical Procedure,
Patient Appointment. Everything unbounded (`limit=0`) except one safety ceiling: **lab analyte
rows are capped at 1000**, purely so a very-long-history patient can't overflow the context
window and fail the call.

**Rolling (incremental) generation — the key idea:**

- First run, an explicit Regenerate, or no prior summary → read the **full** record and generate.
- Any later change → read **only what changed** since a stored watermark (`last_synced_at`) and
  hand the model *the existing summary + that delta* to revise in place. The prompt stays small
  no matter how long the history is.
- Nothing changed since the watermark → **no LLM call at all**.
- The watermark is captured **before** the gather and advanced **only on success**, so a failed
  run retries the same delta and the last good summary stays visible rather than erroring.

**Event-driven, not view-time:** a `doc_events` hook (`on_patient_activity`) on the eight source
doctypes marks the row *Summarizing* and enqueues **one deduplicated background job per patient**
(`job_id = "clinical_summary::<patient>"`), so several edits during a visit collapse into a single
regeneration. The UI only reads the stored row and polls while it's Summarizing. The app's own AI
doctypes are excluded from the trigger to prevent a regeneration loop. A migration patch ensures
a `patient` index exists on all six list-source doctypes.

Output is **advisory only, labelled unverified**, and never written into the clinical record.

---

## 13. AI Feature 5 — General Narzim AI Assistant (sidebar)

A top-level sidebar chat, reachable from anywhere, **with zero patient data in scope** — a
general assistant for clinical/medication knowledge (and, since a later scope widening, any
topic), plus document upload. Available to **every role, including Front Desk**.

**Backend:** `api/v1/narzim_assistant/api.py` (`send_message`, `list_threads`, `get_thread`,
`set_feedback`, `get_usage_summary`) + `services/narzim_assistant.py`. Messages stored in
`AI Narzim Assistant Message` (thread UUID + `session_user`, with per-message model, tokens, cost,
latency and a link to the `AI Prompt Log` row). Threads are **private per user**, enforced by a
`permission_query_conditions` entry; System Manager / Healthcare Admin bypass it for the usage
report. Per-user token/cost visibility is a plain aggregation — **no hard caps, no blocking**.

**The original safety design** was architectural, not prompt-based: the endpoint never accepts a
patient or encounter identifier, and **no tools are passed to the model at all** — there is no
code path from this feature back to the database.

### The PHI incident and the three redesigns — read this part carefully

This is the most instructive part of the whole AI subsystem, and it should be understood as a
sequence:

**1. The incident (2026-07-30).** Within hours of launch, a Front Desk user uploaded a real
patient's discharge note (a "Nota de Prealta" PDF). The guardrail only inspected the *question
text* for patient references — it never inspected the *uploaded document*. The assistant read the
PDF and produced a full clinical summary (name, admission/discharge dates, diagnosis, treatment,
microbiology, imaging), which was displayed, **persisted in full** to the message content, and
whose source PDF was saved as a private `File` — a permanent copy of a patient record sitting
outside the Patient record system with none of its access controls. A follow-up translation
request was refused, but only because the model noticed the name already in its own conversation
history; by then the exposure had happened.

**First fix:** a dedicated LLM **PHI pre-check** call (`check_document_for_patient_phi`, its own
prompt file, classify-and-refuse only) run *before* the answering call, plus: uploads are **never
persisted at all** any more (held in memory for one exchange, then discarded), plus the specific
exposed thread, its log rows and its two `File` records were purged after confirming the physical
paths were not shared with that patient's legitimate copies elsewhere.

**Stated residual risk at the time:** the pre-check *still transmitted the raw file bytes to the
LLM provider* before deciding anything.

**2. The redesign (2026-07-31) — local extraction + deterministic redaction.** That residual
transmission was judged unacceptable for a feature whose whole premise is zero patient-data
reach. `send_message` no longer sends file bytes to any LLM call:

1. Text is extracted **locally** (`pdf_pages.py`, pypdf — no AI).
2. That text goes through **`services/pii_redaction.py::redact_text()`** — local, deterministic
   regex + **bilingual (es-MX / en-US) labeled-field** matching (`Name:`/`Nombre:`,
   `DOB:`/`Fecha de Nacimiento:`, email, MRN, CURP, address, phone-under-a-label), masking each
   as `[REDACTED]`. No AI call anywhere in this module.
3. The masked text is folded into a normal `answer_general_question()` call — the same function
   used for plain text questions.

**3. Format coverage completed (same day).** The extract-locally-then-redact pattern was extended
to every common format, all via local libraries with no bytes leaving the process:

| Format | Extractor |
|---|---|
| PDF (with text layer) | `pdf_pages.extract_text_layer()` (pypdf) |
| Excel `.xlsx` / `.xls` | `openpyxl` / `xlrd` — **plus column-header masking**: a spreadsheet's personal-detail column is identified by its *header cell*, not a `Label: value` line, so every cell under a matching header is masked by column position before flattening |
| Word `.docx` | `python-docx` |
| PowerPoint `.pptx` | `python-pptx` |
| Legacy `.doc` | `antiword` (system binary) |
| CSV | Python `csv` + the same column-header masking |
| Plain `.txt` | raw bytes, redaction only |
| Images (PNG/JPEG/WEBP/GIF) | `pytesseract` + `tesseract-ocr` + `tesseract-ocr-spa` |
| Scanned/photographed PDFs | pages rendered locally via `pymupdf`, then OCR'd |

Two honest caveats recorded with this: the apt packages (`tesseract-ocr`, `tesseract-ocr-spa`,
`antiword`) were added to the deploy dependency list **but never verified against a real Frappe
Cloud deploy** — if that assumption is wrong, OCR and `.doc` silently return `""` and degrade to
"could not read any text" rather than crashing. And OCR is a materially weaker guarantee than the
other extractors: it *infers* text from pixels, and redaction can only mask what OCR actually
produced as recognizable text.

**4. The deliberate exception — raw-image vision fallback (2026-07-31).** A user uploaded a
photograph of an X-ray on a monitor. OCR correctly found no text (an X-ray's value is the pixels),
so the upload was rejected. Asked to support this case, the tradeoff was put to the user
explicitly — this reintroduces the same shape of risk as the original incident, in a
patient-agnostic assistant reachable by Front Desk, with **no possible redaction** since there's
no text to mask. The user's explicit answer was **"yes proceed with no patient authorization."**

So: for an image where OCR extracts **no text at all**, the raw bytes go to the vision model
(`answer_document_question`). This is the **only** path in this feature where raw file bytes
reach an LLM. Every other upload type still masks-before-sending. The only remaining safeguard
there is a prompt instruction to decline if a name/MRN is visibly burned into the image — an
LLM-judgment guardrail, explicitly a mitigation and not a guarantee.

**5. Model no longer second-guesses masking on the text path (2026-08-01).** A screenshot of the
app's own Patient Chart page was refused because the patient's name appeared in the **browser URL**
(`/patients/Divyanshu Chauhan - 1`) — unlabeled, so `redact_text()` had no pattern to catch it, and
the model then declined on its own judgment. The instruction to decline was removed: masking is
now the safeguard, and the model answers with whatever remains. **Stated residual risk:** anything
redaction misses (a name in a URL, in unlabeled prose, or under an unusual label) will now reach
the answer instead of triggering a refusal. That's a deliberate trade of false-refusal annoyance
against a real chance of a masking gap surfacing. Closing it properly would need NER.

---

## 14. Cost, audit and retention across all AI

**Cost formula** (per provider module, `_estimate_cost` / `_pricing_for_model`):

```
cost_usd = (tokens_in / 1_000_000 × input_rate) + (tokens_out / 1_000_000 × output_rate)
```

Reference rates in code (USD per million tokens): `gpt-4o` 2.5 / 10.0 · `gpt-4o-mini` 0.15 / 0.60
· `gpt-5` 15.0 / 60.0 · `gpt-5-mini` 0.25 / 2.0. Deepgram is costed separately at a configurable
$0.0077/minute.

**Known measurement defects** (logged, from a measured audit over 485 logged calls): cost is
overstated ≈8× on the portal/lab path; `cached_tokens` is never captured; `prompt_hash` is never
written on some paths. Also, model pricing is duplicated across four+ modules, and two of those
copies hardcode Sonnet pricing regardless of the configured provider — a live bug. New features
are required to call the provider module's own estimator rather than add a fifth copy.

**Metering/billing scaffolding exists but is NOT active.** `AI Subscription Plan` (+ Company,
Seat) and `AI Usage Counter` doctypes are installed but unwired — the current model is **BYOK
(bring your own key), Phase 1, no credit or seat metering**. Every write-tool docstring says so.
Don't assume that billing layer is live.

**Retention:** audio off by default (0 days) · transcripts 2555 days · SOAP drafts 2555 days ·
prompt logs 365 days.

---

## 15. AI data model — every AI doctype

| Doctype | Role |
|---|---|
| `AI Settings` (Single) | All feature flags, provider/model config, ASR config, retention (§8.2) |
| `AI Prompt Log` | One audit row per LLM call, every feature (§8.4) |
| `AI Encounter Session` | Live recording session: state machine, consent gate, timing |
| `AI Transcript Segment` | Append-only finalized transcript segments (speaker, text, timing, confidence) |
| `AI SOAP Draft` | One-pass SOAP output, versioned, `accepted_by_physician` flag |
| `AI Encounter Chat Message` | Persisted encounter-copilot chat (role, content, `actions_json`, `kind`, model/tokens/latency), grouped by `thread` |
| `AI Encounter Record` | Consolidated per-encounter AI record |
| `AI Patient Chat Message` | Patient-portal lab-assistant chat |
| `AI Patient Clinical Summary` | Rolling whole-record clinical summary + `last_synced_at` watermark (§12) |
| `AI Narzim Assistant Message` | General sidebar assistant messages, private per user, inline cost/tokens |
| `AI Lab Panel Extraction Panel` | Multi-panel lab extraction working state |
| `AI Prompt Template` | Runtime-editable prompt storage — **verify whether it's actually read at runtime before relying on it** |
| `AI Subscription Plan` / `…Company` / `…Seat` / `AI Usage Counter` | Credit/seat metering scaffolding — **installed but not wired** |

Non-AI custom doctypes worth knowing (for context on what the AI reads/writes into): `EB Clinic
Settings`, `Lab Parameter`, `Lab Analyte Alias`, `Lab Unit Conversion`, `Immunization Program` /
`Template` / `Schedule Dose` / `Patient Vaccine`, `Vital Signs Template` (+ fields, readings),
`Clinical Document` (+ share), `Doctor Profile`, `Portal Conversation` / `Portal Message`,
`WhatsApp Conversation`, `Remedisys WhatsApp Notification`, `Patient Health Summary` /
`Health Domain Score`, `External Lab Report Summary` / `Result Item`, `Allergy`,
`Surgical History`, `Practitioner Qualification` / `Certification` / `Language` /
`Work Experience`, `Chat Thread` / `Message` / `Participant`.

---

# PART C — REALITY CHECK

## 16. Known gaps, risks and open decisions

**AI-specific**

1. **Cost per Analyze is high relative to value** — ~4.5¢ and ~50 s, dominated by tool-call
   protocol overhead, not transcript size. No prompt caching is used anywhere. This is the single
   biggest optimization opportunity in the system.
2. **Cost-model defects** (§14): ~8× overstatement on one path, `cached_tokens` never captured,
   `prompt_hash` not always written, pricing duplicated in 4+ places with two stale copies.
3. **The general assistant's raw-image path** is an explicit, user-authorized hole in an
   otherwise architectural guarantee (§13). Future maintainers must not assume the assistant is
   uniformly incapable of reaching patient data.
4. **`redact_text()` is pattern matching, not language understanding** — a name in unlabeled
   prose or inside a URL is not caught, and since 2026-08-01 that no longer triggers a refusal.
5. **OCR / `.doc` apt dependencies are unverified on Frappe Cloud** — a silent capability gap if
   the assumption is wrong.
6. **Prompt-level guardrails are not reliable**, and the codebase says so explicitly in several
   places. Every "the model is instructed to…" is a mitigation, not a control.
7. **Duplicate ADR numbering** — two different ADRs are both numbered 030
   (`llm-curated-tool-access` and `ai-patient-chat-persistence`), and two are numbered 018, 020,
   026, 027, 028, 030, 038. Always specify which when citing.
8. **`CLAUDE.md`'s AI file map is stale** — it labels live 1,600-line AI modules as "Phase 5
   stubs" and lists 5 AI doctypes where 17 exist. Don't plan from it; read the code.
9. `AI Prompt Template` may or may not actually be read at runtime — unverified.
10. Some frontend dead code remains for a removed backend mechanism (`autopopulate`) — it would
    now fail immediately if wired up.
11. No permanent test fixtures were added for the assistant's file-format paths — verified
    manually end-to-end, but not regression-protected.

**Platform**

12. **Insurance claim submission is not built** (deliberate scope cut). The commented-out
    insurance pay-timing button is intentional, not a bug.
13. **Encounter consultation billing** has a designed-but-deferred model
    (`create_invoice_from_encounter()` with a 3-lane "clinical record is never gated by billing"
    approach for walk-ins/emergencies). Open questions remain around IPD, unidentified-patient
    merging, and deferred-billing policy.
14. **Outbound referral documents** (Rx slip, lab sheet, procedure letter) were cancelled
    2026-06-18; focus is Rx + labs in-encounter.
15. **A non-System-Manager creating a user cannot grant roles it doesn't hold** — `EB_Practitioner`
    gets silently stripped. Fix decision still open.
16. Reports module is partially built (appointments + providers report families exist; clinical
    and financial report families are not all complete).

## 17. Glossary

| Term | Meaning |
|---|---|
| **Frappe / ERPNext / Healthcare** | The open-source Python framework, ERP, and healthcare module the platform is built on. "Doctype" = a model/table. "Whitelisted method" = an explicitly exposed RPC endpoint. "Docstatus 0/1/2" = draft / submitted / cancelled. |
| **BFF** | Backend-for-frontend. Next.js route handlers hold the JWT and proxy to Frappe so the browser never holds a credential. |
| **Encounter** | One consultation. The central clinical document. |
| **Service Request** | The order record created when an encounter is signed; anchors labs/procedures. |
| **Narzim AI** | The product brand for the AI. Used for **two** different features — the encounter copilot (§9) and the general sidebar assistant (§13). |
| **Analyze pill** | The button that runs the tool-calling agent over the whole encounter and fills the draft. |
| **Tool registry** | The fixed, code-defined set of 36 typed functions the LLM may call. The model's only path to data. |
| **Write tool** | A tool that returns a *suggestion object* into the on-screen draft. It never writes to the database. |
| **ADR** | Architecture Decision Record. Numbered, never edited once merged — superseded by a new one. |
| **BYOK** | Bring your own key — the current AI commercial model; no credit metering. |
| **PHI** | Protected Health Information. |
| **es-MX / en-US** | The two supported locales. |

---

*End of brief. If something here contradicts the running code, the code is authoritative — this
document was written by reading it on 2026-08-04, and the AI subsystem changes quickly.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-04 | Sarvesh | Initial version (header backfilled from git history) |
