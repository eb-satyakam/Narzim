# Scribe — the document agent in Narzim Drive

**Doc status:** living · **Created:** 2026-09-10 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-10 by Anant Sharma (AI-assisted) · **Version:** 1.0

> Open a file in Narzim Drive, press the ✨ button, and **Scribe** summarises it and answers
> questions about it. This is how that works and what stops it going wrong.
>
> It replaced a panel that showed five invented lab values over every document — see
> [`DOCUMENT_SUMMARY.md`](DOCUMENT_SUMMARY.md) for what that was and why.

## 1. What it does

| | |
|---|---|
| **Summarise** | Names the document type and lists what is on the page, in a few bullets |
| **Suggest** | 3–4 questions this document can answer, offered as buttons |
| **Answer** | Questions about the document, citing the page |

Scribe is the "Documentation Specialist" from the AI Workforce directory — same portrait and name,
read from that roster so the two cannot drift apart.

## 2. How it works

**Reading the file.** Text-layer PDFs, Word, Excel, CSV and text are read as text. Photos and
scanned PDFs go to the vision model instead, because OCR reads printed labels well and handwriting
badly — on a registration form it returned `'First Name * Te Q'` for "Texes Longe".

**Summarising.** Up to 8 pages: one call over the whole file. Longer: the file is split into
page ranges, each summarised, then merged. Every page is read — a long document is never summarised
from the part that happened to fit.

**Answering.** The pages relevant to the question are selected by word overlap and sent with it.
A document small enough to fit is never subsetted. **No embeddings** — `CLAUDE.md` §3 locks that
decision, and it is not needed: embeddings find one document among thousands, and this document is
already open.

**Remembering.** Extracted text is cached for 30 minutes so a follow-up question does not re-read
the file.

## 3. Guardrails

| | Guardrail | Why it exists |
|---|---|---|
| 1 | Off unless switched on (`AI Settings.enable_drive_document_summary`) | It sends document text to an LLM provider; that must never begin by upgrading |
| 2 | Refuses a provider the `ComplianceProfile` does not name | PHI-1 — the subprocessor record must match reality |
| 3 | You can only summarise what you can already open | Same permission path as opening it; invisible files 404, never 403 |
| 4 | Permission is checked **before** the cache | The cache is keyed by document, not viewer — consulted first, it would hand one person's text to another |
| 5 | Text is redacted before it leaves | Same masking the Narzim assistant applies to its own uploads |
| 6 | Bounded to the context budget | Rule 5 — never an unbounded dump |
| 7 | Coverage is always reported ("Read 20 of 20 pages") | A summary that hides its coverage looks complete either way |
| 8 | The model is told the document's true size | Handed a subset, it counted the subset and called it the document — "2 pages" for a 3-page file |
| 9 | Never uses outside knowledge | The guard that separates this from a chatbot with a document attached |
| 10 | "That is not in this document" is a valid answer | Preferred to a plausible guess |
| 11 | Answers cite the page | An uncited answer cannot be checked |
| 12 | Read-only — never writes to any record | Rule 6 |
| 13 | Every call is logged to `AI Prompt Log`, committed separately | A failure is the call most worth having a record of, and a `throw` rolls back the request |
| 14 | Cache dies with the file | PHI-4 — duplicated patient data needs one erasure path |

Numbers 4, 7, 8 and 13 were each added after the failure they now prevent was observed.

## 4. What it will not do

- Write anything to a patient chart, or anywhere else
- Invent a value, a page count, or a document type
- Answer from general knowledge — *"who is the president of France?"* is refused
- Show a suggested question the document cannot answer

## 5. Known limits

- **Handwriting is read approximately.** "Texes Longe" came back as "Texas Longer", and a CURP ID
  lost a digit. Fine for orientation; **not** for copying an identifier into a record. Use the
  deterministic reader (`registration_form_extraction`, ADR-058) for that.
- **Definitional questions are refused.** "What is HIPAA" on a document that *applies* HIPAA but
  never defines it gets what the document says, not a definition. That is the no-outside-knowledge
  guard working.
- **`AI Prompt Log` records counts, not content** — so *why* an answer was given cannot be
  reconstructed. Known gap in Rule 6, not specific to Scribe.
- Above 40 pages the document is not read in full.

## 6. Where the code is

| | |
|---|---|
| Logic | [`services/drive_summary.py`](../../remedisys_healthcare_ai/services/drive_summary.py) |
| Endpoints | [`api/v1/drive/api.py`](../../remedisys_healthcare_ai/api/v1/drive/api.py) — `summarize_entry`, `ask_entry` |
| Flag + audit purposes | `patches/v0/add_drive_document_summary_settings_20260909.py` |
| Tests | `tests/security/test_drive_service.py` |
| Panel | `remedisys-ai-ehr` → `src/components/narzim/inbox/clinical-documents-tab.tsx` |
| Frontend routes | `remedisys-ai-ehr` → `src/app/api/drive/[id]/{summary,ask}/route.ts` |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-10 | Anant Sharma (AI-assisted) | Initial version — how Scribe works, its 14 guardrails, and its limits |
