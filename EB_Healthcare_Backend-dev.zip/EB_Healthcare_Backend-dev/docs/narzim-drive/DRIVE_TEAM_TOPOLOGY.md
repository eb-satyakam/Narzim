# Narzim Drive — personal and shared drives: requirements, what exists, and the recommendation

**Doc status:** superseded · **Created:** 2026-09-15 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-16 by Anant Sharma (AI-assisted) · **Version:** 3.0

> **SUPERSEDED 2026-09-16 by [`NARZIM_DRIVE.md`](NARZIM_DRIVE.md).** Its recommendation — one
> shared team, no per-user drives — was reversed: every user now owns a personal team and uploads land
> in it. Kept as the record of the reasoning and of what the options cost.
>
> **What this was.** What the clinic needs from Narzim Drive, what is already built (measured, not
> assumed), and the recommended `Drive Team` structure. It closes decision **#2** in
> [`DRIVE_MIGRATION_PLAN.md`](DRIVE_MIGRATION_PLAN.md) §6.3, open since 2026-09-09.
>
> **The work that follows from it** is in
> [`DRIVE_ACTION_PLAN.md`](DRIVE_ACTION_PLAN.md). This document decides *what is true and what we
> should do*; that one tracks *what is being done*.
>
> **⚠️ v2.0 REVERSES v1.1.** v1.1 recommended a Drive Team per user, on the premise that a document
> cannot be made private inside a single team. That premise is wrong at the product layer:
> `services/drive.py::_is_visible()` already enforces private-by-default. Measured proof is in §4.
> The recommendation is now **one shared team**.
>
> **Not approved.** Per [`CLAUDE.md`](../../CLAUDE.md) §9 a `draft` must not be cited as decided.
> **Project and phase status is not here** — it lives only in [`docs/STATUS.md`](../STATUS.md).

---

## At a glance

| # | Requirement | Status |
|---|---|---|
| R1 | Personal drive — my documents are private until I share them | ✅ Working |
| R2 | Shared drive — a clinic-wide space | ✅ Working |
| R3 | Share with a named colleague, view or edit | ✅ Working |
| R4 | Trash, visible and restorable in the EHR | ⚠️ Half — no Trash screen |
| R5 | Creating a Drive team must never break Documents | ✅ **Fixed 2026-09-15** — pinned |
| R6 | New users get a drive automatically | ✅ In the EHR · ❌ not in `/drive` |
| R7 | Administrator can reach the backend for maintenance | ✅ Working — but not Administrator-only |
| R8 | Clinical staff must not use the backend | ❌ **Open — most serious gap** |
| R9 | Storage is understood and controlled | ⚠️ Misleading — quota is per-user |
| R10 | Administrators can manage others' documents | ✅ Working — ⚠️ unaudited |

**Recommendation: one shared clinic team. Do not give each user a separate `Drive Team`.**

---

## 1. The question

Every `Drive File` carries a `team`, and all tenancy keys off it. For Chavitos Pediátrica — one
clinic, ~19 staff — should that be one shared team, or one personal drive per user?

## 2. Requirements

Stated in plain English, as the clinic expresses them.

**R1 — Personal drive.** Every staff member has a private space. Documents I upload are visible only
to me until I choose to share them. Not even an administrator sees them by default.

**R2 — Shared drive.** The clinic has a shared space. Documents placed there are visible to all
clinical staff.

**R3 — Share with a named colleague.** I can give a specific colleague access to a specific document
or folder, view-only or editable. Only clinical staff can receive a share — never the public, never
an outside email address.

**R4 — Trash, visible in the EHR.** When a user deletes a document it moves to Trash instead of
disappearing. The user can open Trash in the EHR, see what they deleted, and restore it.

**R5 — Creating a Drive team must never break Documents.** Adding a team must not cause "documents
not found" for everyone else.

**R6 — New users get a drive automatically.** A user created with any of the four clinical roles —
Doctor, Nurse, Front Desk, Clinic Admin — can use Documents immediately, with no manual setup.

**R7 — Administrator access to the backend.** As Administrator I can reach Drive's own UI for
maintenance and recovery.

**R8 — Clinical staff must not use the backend.** Doctors, nurses and front desk use the EHR only.

**R9 — Storage is understood and controlled.** I know how much space the clinic has, and get warning
before it runs out.

**R10 — Administrators can manage other users' documents.** As Administrator I can delete or recover
a colleague's document when necessary.


## 3. What we have

Measured on `remedisys.localhost`, **2026-09-15**:

| Fact | Value |
|---|---|
| `Drive Team` rows | 2 — `0pul9ncq46` (`personal=1`, owned by Administrator) and `Dev Team` |
| `Drive File` rows | 32 active in the main team, 25 trashed |
| Staff in the share picker | 19 |
| `remedisys_drive_team` pin | `0pul9ncq46` — **set 2026-09-15**, Documents restored for all users |

## 4. Is the "personal drive + shared drive" model already met?

**Yes — R1, R2 and R3 are met, and this was proven rather than assumed.**

The enforcing mechanism is `services/drive.py::_is_visible()`, applied at both `list_entries` and
`get_entry` (and therefore `download()`, which routes through `get_entry`):

```python
if row.get("owner") == user:
    return True
return _shared_with(user, row.get("name"))
```

Its docstring states the intent, including that administrators are not exempt:

> *"Drive treats a team as a shared drive... Narzim Drive's model is the one Clinical Document
> enforced — your documents are yours until you share them... **Administrators are NOT exempt.**"*

**Measured proof**, run on 2026-09-15 and then reverted:

```
file: Remedisys_HIPAA_AWS_Encryption_Analysis (1).pdf | owner: adrian@narzim.com

BEFORE  nurse can see it? -> False
BEFORE  get_entry: DoesNotExistError - Document not found
        shared with nurse@narzim.com
AFTER   nurse can see it? -> True
AFTER   get_entry: OK
```

Private by default; visible immediately on share; a 404 rather than a 403, so an unshared document
is indistinguishable from one that does not exist.

**The caveat that keeps this from being "done":** the guarantee holds only on the Narzim Drive path.
See §6.

## 5. Why a separate team per user is *not* required

The privacy boundary in Narzim Drive is **ownership**, not team membership. A per-user `Drive Team`
would deliver what ownership already delivers, and would cost:

1. A rewrite of `_team()` ([`services/drive.py`](../../remedisys_healthcare_ai/services/drive.py))
2. Removal of the `Multiple Drive teams exist` guard — the code that fails closed today
3. Per-user team provisioning for 19 accounts
4. A data migration of the existing 32 files
5. **A new "Shared with me" listing** — `list_entries` queries one team, so a document shared from
   another user's team would be readable by direct link and invisible in the UI

Point 5 is the decisive one: per-user teams would *break* R3 until extra work was done.

## 6. The one real gap — the vendor UI

`_is_visible()` lives in the service layer. Drive's own UI at `/drive` does not call it.

Measured 2026-09-15:

```
nurse@narzim.com     owns=0   | /drive shows=31  | Narzim Drive would show=3
adrian@narzim.com    owns=9   | /drive shows=31  | Narzim Drive would show=12
admin@narzim.com     owns=16  | /drive shows=31  | Narzim Drive would show=16
```

A nurse who owns no documents sees all 31 through `/drive` — and Drive writes no `make_access_log`
row, so the disclosure is also untraceable. This is **R5**, and it is the highest-severity item.

The proportionate fix is a guard change, not a topology change: widen
`overrides/drive_guard.py` Layer 1 from *deny anonymous* to *deny anyone who is not Administrator*.

## 7. Options

| # | Approach | Assessment |
|---|---|---|
| **A** | **One shared clinic team** | **Recommended.** R1–R3 already met; residual risk is one UI |
| B | Personal `Drive Team` per user | Rejected — breaks R3 discovery; large cost for no gain |
| C | Both (shared team + per-user teams) | Rejected — v1.1's recommendation, based on a wrong premise |
| D | A team per department | Rejected — clinical work is cross-role |

## 8. Best approach

**One shared clinic team, with ownership as the privacy line and explicit sharing on top.**

Concretely:

- **Personal drive** = documents you own (the Private tab)
- **Shared drive** = documents shared with you, plus one folder shared with the team
- **Backend** = Administrator only, for operations

## 9. What would falsify this

- **If `/drive` cannot be restricted**, the privacy guarantee is unenforceable and per-user teams
  become the fallback.
- **If a second clinic is onboarded onto this site**, the shared team stops being "the clinic" and
  this must be reopened *before* that onboarding.
- **If a requirement appears for documents owned by the clinic rather than a person**, a non-personal
  team becomes necessary rather than optional.

## 10. Open questions

1. **`System Manager` or Administrator only** for `/drive` access (blocks R5).
2. **Whose trash** does a user see — own only, or team-wide for `EB_Healthcare Admin`? (blocks R4).
3. **Deletion is unaudited** — `Drive File` has `track_changes` unset, `tabVersion` holds 0 rows;
   only `modified_by` survives and the next write overwrites it.
4. **Storage (R6)** — `quota` is per-user, pooled `storage` is never enforced; no clinic-wide ceiling.
5. **AGPL** (§6.3 decision #1) remains unanswered and is unaffected by this document.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.0 | 2026-09-16 | Anant Sharma (AI-assisted) | Superseded by NARZIM_DRIVE.md — per-user drives were built, reversing this document's recommendation |
| 2.1 | 2026-09-15 | Anant Sharma (AI-assisted) | Requirements restated as R1-R10 in plain English; R5 marked fixed (team pinned) |
| 2.0 | 2026-09-15 | Anant Sharma (AI-assisted) | **Reversed the recommendation to one shared team.** `_is_visible()` already enforces private-by-default (proven §4); identified the `/drive` bypass as the real gap |
| 1.1 | 2026-09-15 | Anant Sharma (AI-assisted) | Added requirements, current-state and at-a-glance sections |
| 1.0 | 2026-09-15 | Anant Sharma (AI-assisted) | Initial draft — recommended per-user drives (superseded by 2.0) |
