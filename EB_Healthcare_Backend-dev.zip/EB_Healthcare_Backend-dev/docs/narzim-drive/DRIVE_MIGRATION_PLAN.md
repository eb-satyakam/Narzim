# Narzim Drive — migrating `Clinical Document` to Frappe Drive

**Doc status:** living · **Created:** 2026-09-09 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-10 by Anant Sharma (AI-assisted) · **Version:** 2.1

> **What this is.** The build plan for replacing the `Clinical Document` doctype behind Narzim
> Drive with **Frappe Drive** as the storage engine, keeping our own API layer as the permission
> and audit boundary, and wiring it to the redesigned Documents screen.
>
> **Why it is `draft` and not `living`.** Two gates in [§6](#6-stage-0--preconditions) have no
> answer yet — the **AGPL** question and the **Drive Team topology**. Per
> [`CLAUDE.md`](../../CLAUDE.md) §9 a `draft` must not be cited as decided. It becomes `living`
> when **ADR-061** is merged.
>
> **What it reverses.** [`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md) v1.0
> (2026-09-08) recommended *"Do not install Frappe Drive."* That recommendation is superseded
> here — see [§3](#3-the-decision-and-what-it-reverses) for what changed and what did not.
>
> **The document agent that runs on top of this store** is described in
> [`SCRIBE_DOCUMENT_AGENT.md`](SCRIBE_DOCUMENT_AGENT.md).
>
> **Project and phase status is not in this document.** It lives only in
> [`docs/STATUS.md`](../STATUS.md).

---

## 1. Where we are today — three systems, measured

All figures measured on `remedisys.localhost` on **2026-09-09**, not estimated.

### 1.1 The backend we have

| Thing | Value |
|---|---|
| Doctypes | `Clinical Document`, `Clinical Document Share` (child) |
| API | ``api/v1/clinical_documents/api.py`` — 8 whitelisted methods |
| Service | ``services/clinical_documents.py`` — every privacy rule |
| Reference | [`docs/CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md) |
| Upload limit | 25 MB, single request; extensions limited to images, PDF, `xlsx`/`xls`/`csv` |

### 1.2 The data that would move

```
CLINICAL_DOC_ROWS: 31        BY_STATUS: Saved=7, Deleted=24
BY_VISIBILITY:               Private=20, Shared=11
ATTACHMENTS:                 17 files, 1,133,804 bytes (1.1 MB)
```

**Seven live documents and 17 files.** This is the single most important number in the document:
the data migration is a non-event. The cost of this project is the API layer, the audit layer and
the frontend — not the data. Any plan that spends its risk budget on data migration is
mis-weighted.

### 1.3 Frappe Drive is already installed

Contrary to [`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md) §1, which states it is not:

| Fact | Value |
|---|---|
| In `installed_apps` on `remedisys.localhost` | **yes** |
| In `sites/apps.txt` | **yes** |
| Pinned commit | `0bd11d8f412410922ec704647e29d61216e500b4` (2026-06-16) |
| `Drive Team` rows | 1 (`0pul9ncq46`) |
| `Drive File` rows | 6 |
| UI mounted | `/drive/<path:app_path>`, plus `add_to_apps_screen`, plus `app_include_js` injected into every Desk page |

The evaluation is `living` and factually wrong on this point, so per §9 it is a bug with an owner.
[§14](#14-documentation-debt-this-creates) lists the fix.

---

## 2. Why the new design forces the question

The redesigned screen is
`src/components/narzim/inbox/clinical-documents-tab.tsx` in the `remedisys-ai-ehr` repo
(3,648 lines; the route component `documents-page-client.tsx` is a 7-line re-export).

It ships: **New Note · New Upload · New Folder**, an All/Private/Shared filter, grid and list
views, sort, pagination, a Google-Drive-style share dialog, and per-type thumbnails
(PDF, DOCX, spreadsheet).

Two things in it cannot be honoured by the current backend.

### 2.1 Folders exist only in the browser

```tsx
// clinical-documents-tab.tsx:2731
const [folders, setFolders] = React.useState<DocFolder[]>([])
```

No API call, no `localStorage`, no persistence of any kind. `DocFolder` carries a `docIds`
array held in React state.

**USER STORY.** Dr. Bracamontes files eleven referral scans into a folder he names
*"Referencias pendientes"* → **the system shows** the folder, with the documents inside it, and
it behaves correctly for the rest of the session → he refreshes the tab → **the database
actually contains** no folder at all, because none was ever created: `tabClinical Document` has
no `parent` column and no row was written → **consequence:** the folder and the filing are gone,
the eleven documents are back in one flat list, and no error was ever shown. He assumes the
system lost his documents.

**WHY it is this way:** the design was built against a doctype that is flat by construction.
`Clinical Document` has no `parent`, no `is_folder`, no tree. The frontend implemented the
feature the design called for in the only place it could.

**WHEN:** present in the working tree now, uncommitted, alongside modified `messages/en.json`
and `messages/es.json`.

### 2.2 The share dialog states something the code does not do

```tsx
// clinical-documents-tab.tsx:1375
doc.visibility === "Shared" ? "AnyoneWithLink" : "Restricted",
```

The dialog labels a Shared document **"Anyone with the link"** and offers a Copy link button
producing `${origin}/documents/${doc.id}`. The backend does no such thing: a shared document is
readable only by an authenticated user holding one of the 7 roles in `_STAFF_ROLES`, and a
non-permitted caller gets a 404, not the document.

This violates [`CLAUDE.md`](../../CLAUDE.md) **PHI-5** — *never say in the UI what the code does
not do*. The direction of the error is the safer one (the UI over-promises openness rather than
under-promising it), but a clinician who believes that link works outside the clinic will send it
outside the clinic. Fix the wording regardless of which option below is chosen; it is not
contingent on the migration.

---

## 3. The decision, and what it reverses

**Adopt Frappe Drive as the storage engine for Narzim Drive. Retire `Clinical Document`.**

[`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md) v1.0 argued the opposite one day
earlier. Being precise about what changed, because most of that document is still correct:

| Evaluation's claim | Status now |
|---|---|
| 26 of 83 `drive/api/` methods are `allow_guest=True` | **Holds** — re-measured on the pinned commit: 26 of **89**, plus 17 `ignore_permissions=True` |
| Drive has no clinical audit trail | **Holds** — no `make_access_log` equivalent anywhere in Drive |
| Drive's Vue UI is unusable for us | **Holds** — we ship Next.js; none of Drive's frontend is used |
| AGPL and beta status are real costs | **Holds** — unresolved, see [§6](#6-stage-0--preconditions) |
| *"It is not installed on this bench"* | **False** — it is installed ([§1.3](#13-frappe-drive-is-already-installed)) |
| *"No new deployment surface"* as a reason to stay | **Spent** — the surface was added on 2026-09-08 |

The security findings did not weaken. What changed is the **cost comparison**: the evaluation's
strongest argument for staying was that staying was free. It is no longer free — the app is
installed and its guest surface is live whether or not we build on it. Staying now means
carrying Drive's costs and getting none of its capability, *unless Drive is uninstalled*, which
remains a legitimate choice ([option E](#4-approaches-considered)).

One correction to the evaluation's security case, in Drive's favour. Upstream's own comment in
`get_file_content` reads *"JWT tokens are a vulnerability … Only the file name and secret token
is needed to get access to all files."* On the pinned commit that comment is **stale**:
`create_auth_token` gates on `user_has_permission(entity_name, "read")`, and the token encodes
`{name, expiry}` with `auth["name"] != entity_name` checked and a 60-second life. It is scoped to
one file, for one minute, for someone who could already read it.

The real exposure is simpler: **a `Drive Permission` row with `user="Guest", read=1` makes a file
readable with no login at all**, and nothing writes an access log when it is read. Drive's own
`get_user_access` carries the upstream comment `# broken: leaks parent breadcrumbs` on its Guest
branch.

---

## 4. Approaches considered

Per [`CLAUDE.md`](../../CLAUDE.md) §10, five distinct approaches. Distinct means *what* is done or
*where the problem is solved* differs — not a schedule variation.

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | Next.js BFF calls Drive's whitelisted HTTP API directly | Least backend work; fastest to a demo | Violates the locked API pattern (§3, *custom whitelisted methods only*); **no `make_access_log` on any download**; frontend couples to 89 upstream signatures that move each release; inherits the guest surface wholesale |
| **B** ✅ | **`api/v1/drive/api.py` + `services/drive.py` wrap Drive's Python layer in-process. Drive stores; we remain the boundary** | Keeps the locked API pattern; downloads proxied so `make_access_log` fires; guest surface never exposed to the browser; our envelope preserved so frontend churn is bounded; tree, chunked upload, previews, versioning, restore come free | We own a wrapper over a beta app's internals; **AGPL coupling is tightest here**; upstream refactors can break us |
| **C** | Drive stores bytes and tree; a retained Remedisys doctype owns permissions and audit | Audit and permission logic stay in code we own | Keeps the doctype we are trying to remove; **two permission systems that must agree — when they disagree the failure is silent and in the unsafe direction**; doubles the migration |
| **D** | Vendor Drive's *data model* into our app; do not run the app | No AGPL, no beta, no guest surface | Discards the actual engineering value (chunked upload, path resolution, previews, CRDT) while keeping all the maintenance. This is the evaluation's option E, rejected there as a premature rewrite |
| **E** | Keep `Clinical Document`, add folders; **uninstall Drive** | 44 existing tests, two documented production defect fixes, smallest surface | The design has outgrown a flat doctype ([§2.1](#21-folders-exist-only-in-the-browser)); rebuilds tree, chunking, quotas and versioning by hand. Only coherent if Drive is actually uninstalled |

**Chosen: B.**

**Why each other loses, specifically.** **A** loses on one fact, not on taste: your patient
documents path already calls `make_access_log(...)` on every download-URL issue
([`api/v1/documents/api.py`](../../remedisys_healthcare_ai/api/v1/documents/api.py)), with a
comment recording why it is there rather than relying on core. Routing downloads through
`drive.api.files.get_file_content` stops that log being written for this whole feature — a
regression in a control already built deliberately, and the NOM-024 §7 traceability claim rests
on it. **C** loses because two authorities on permissions is the exact bug class
`services/clinical_documents.py` already records having been bitten by, and it does not deliver
the stated goal of removing the doctype. **D** loses because it pays Drive's complexity without
Drive's code. **E** is the only genuinely close call — it loses on
[§2.1](#21-folders-exist-only-in-the-browser) plus the sunk-surface argument in
[§3](#3-the-decision-and-what-it-reverses), and it should be reconsidered if the AGPL gate fails.

**What would falsify this choice:** a legal answer that in-process calls into an AGPL app create
a derivative work. That single answer moves the recommendation to **E**, not to A or C.

---

## 5. Target architecture

```
Next.js (remedisys-ai-ehr)
  └── BFF route handlers  /api/drive/*
        │  Bearer JWT, token stays server-side
        ▼
  api/v1/drive/api.py          ← whitelisted, @handle_api_errors, parses + shapes only
        ▼
  services/drive.py            ← EVERY permission decision + make_access_log
        ▼
  drive.* Python functions     ← in-process; storage, tree, chunking, previews
        ▼
  Drive File / Drive Document / Drive Permission
```

Hard boundaries:

- The browser **never** reaches a `drive.*` whitelisted method. Not one.
- Every download is issued by our endpoint and writes an access-log row before bytes move.
- `user="Guest"` is never written to `Drive Permission`, and is rejected at the chokepoint even
  if something writes it.

---

## 6. Stage 0 — preconditions

**Nothing below starts until these are done. Items 6.1 and 6.2 are worth doing even if the
migration is cancelled.**

### 6.1 Close the guest surface (do this first, independent of everything else)

> **DONE 2026-09-09.** Implemented in
> [`overrides/drive_guard.py`](../../remedisys_healthcare_ai/overrides/drive_guard.py), wired at
> [`hooks.py`](../../remedisys_healthcare_ai/hooks.py) as both `before_request` and a
> `Drive Permission` `validate` doc_event, covered by 12 tests in
> `remedisys_healthcare_ai/tests/security/test_drive_guard.py`.
> **Measured before and after, anonymously over HTTP:**
> `drive.api.permissions.get_user_access` 200 -> 403, `drive.api.product.signup` 500 (handler
> reached) -> 403, `/drive` 200 -> 403; `frappe.ping` and `/login` stayed 200. Neutering both
> layers produces 14 test failures. See [WORK_LOG 2026-09-09](../../WORK_LOG.md).
> Note `get_file_content` was already 403 *because no Guest permission row exists* — which is
> precisely why Layer 2 (creation) is needed alongside Layer 1 (exploitation).


Drive's SPA is mounted at `/drive/<path>` on the same site and is on the Desk apps screen. Any
staff member with a Desk session can reach its share dialog and share to the public.

**USER STORY.** Ana (Front Desk) has a Desk session for a bench task → she opens
`localhost:8003/drive`, uploads a scanned INE and a CBC report, and shares "Anyone with the link"
to send it to a colleague → **the system shows** a normal share confirmation → **the database
actually contains** a `tabDrive Permission` row with `user="Guest"`, `read=1`, and `tabAccess Log`
contains **no row at all** → **consequence:** a patient's identity document and lab result are
reachable without a login, and under NOM-024 §7 we cannot answer "who accessed this record,"
because nothing was written.

The mechanism is Rule-1 safe and already used twice in this app:

| Control | Mechanism | Precedent |
|---|---|---|
| Reject `Guest` for any `/api/method/drive.*` path | `before_request` hook | [`hooks.py:508`](../../remedisys_healthcare_ai/hooks.py) — `traceback_sanitizer` |
| Replace specific Drive methods with audited wrappers | `override_whitelisted_methods` | [`hooks.py:471`](../../remedisys_healthcare_ai/hooks.py) |
| Remove the `/drive` UI for non-admins | drop `website_route_rules` / `add_to_apps_screen` for our roles | — |

No fork, no core patch, survives Drive upgrades. Needs a test that fails without it.

### 6.2 Fix the share-dialog wording

[§2.2](#22-the-share-dialog-states-something-the-code-does-not-do). Frontend-only, through the
`messages/en.json` + `messages/es.json` catalogs per frontend rule 10.

### 6.3 Decisions only a human can make

| # | Decision | Why it blocks |
|---|---|---|
| 1 | **AGPL.** Is in-process calling of an AGPL-3.0 app from non-AGPL `remedisys_healthcare_ai` acceptable? | Approach B is the tightest coupling of the five. A "no" moves us to option E |
| 2 | **Drive Team topology.** One `Drive Team` per clinic/company, or one shared team? | Every `Drive File` carries `team`; all tenancy keys off it. Changing it later is a data migration |
| 3 | **Beta acceptance.** Upstream advises backups in production | A recorded decision, not a blocker |

### 6.4 Record the decision

- **ADR-061** (next free — `adr-060` is highest merged), using
  [`docs/adr/adr-template.md`](../adr/adr-template.md). Supersedes
  [`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md) §5.
- Add `"drive"` to `required_apps` in
  [`hooks.py:19`](../../remedisys_healthcare_ai/hooks.py) **and to the install/uninstall CI gate**
  — otherwise the Rule 2 gate goes green while testing a configuration we do not run.

---

## 7. Stage 1 — backend

> **DONE 2026-09-09** (except chunked upload). Built as
> [`services/drive.py`](../../remedisys_healthcare_ai/services/drive.py) +
> [`api/v1/drive/api.py`](../../remedisys_healthcare_ai/api/v1/drive/api.py), 12 tests in
> `remedisys_healthcare_ai/tests/security/test_drive_service.py`, all passing against live
> data. Two upstream Drive defects were found and worked around without patching Drive —
> `files(folders=1)` is folders-only, and `FileManager.restore` lacks the frappe-doc guard
> its `move_to_trash` counterpart has, so restoring a note always threw. See
> [WORK_LOG 2026-09-09](../../WORK_LOG.md). **Not yet built:** chunked upload, because
> Drive's `upload_file` reads `frappe.request.files` directly.


New: `api/v1/drive/api.py` (whitelisted, `@handle_api_errors`, parse and shape only) and
`services/drive.py` (every permission decision). Same split as every other module.

| Method | Notes |
|---|---|
| `list_entries(parent=None, search=None)` | folders + files at one level; `parent=None` is the user's root |
| `get_entry(id)` | 404 for "not visible", never 403 — preserves the existing non-disclosure behaviour |
| `create_folder(parent, name)` | |
| `create_note(parent, title, content)` | `Drive File` + linked `Drive Document` |
| `upload(parent, ...)` | chunked; retires the 25 MB single-request cap |
| `update_entry(id, ...)` | title, content, tags |
| `move(id, new_parent)` / `rename(id, name)` | |
| `share(id, users, level)` | **never** writes `user="Guest"` |
| `trash(id)` / `restore(id)` | `is_active` — finally delivers restore |
| `download(id)` | **writes `make_access_log` before returning bytes** |
| `list_shareable_users()` | keep the existing `_SHAREABLE_ROLES` allowlist verbatim |

**Carry forward, do not re-derive** — these encode production defects already paid for:

1. **Positive allowlists.** `_STAFF_ROLES` (who may see another's shared document) and
   `_SHAREABLE_ROLES` (who appears in the picker) are deliberately different sets. A new role
   sees nothing until added. Keep both.
2. **404, not 403.** A 403 discloses that a document exists — for a document titled after a
   patient, that is itself a disclosure.
3. **Owner vs. editor.** A shared editor may change content; only the owner changes who sees it
   or deletes it. A non-owner passing a sharing field gets `PermissionError`, never a silent
   ignore.
4. **Salted attachment dedup.** `save_private_file` in
   [`utils.py`](../../remedisys_healthcare_ai/utils.py) salts Frappe's content-hash dedup with
   `(doctype, name)`. Without it a byte-identical PDF uploaded for two patients threw
   `PermissionError` for whoever could not read the first chart. Verify Drive's `FileManager`
   does not reintroduce this.

---

## 8. Stage 2 — schema mapping

| `Clinical Document` | → | Drive |
|---|---|---|
| `name` (hash) | → | `Drive File.name` (also hash); old id preserved for traceability |
| `title` | → | `Drive File.title` |
| `notes` (Text Editor) | → | `Drive Document.content`, linked via `Drive File.document` |
| attachments (`tabFile`) | → | child `Drive File` rows |
| `visibility=Private` | → | no `Drive Permission` rows (owner-only) |
| `shared_with[].user` | → | one `Drive Permission` per user, `read=1` (+ `write=1` when `shared_access_level=Edit`) |
| `share_with_team=1` | → | `Drive Permission` with `team=1` — **never** `user="Guest"` |
| `status=Deleted` | → | `is_active=0` |
| `tags` (JSON in Small Text) | → | `Drive Entity Tag` rows — queryable at last |
| *(does not exist)* | → | `parent_entity` — the folders [§2.1](#21-folders-exist-only-in-the-browser) needs |
| *(does not exist)* | → | `file_size`, `mime_type`, `path`, `allow_download` |

`Drive File` fields available: `title`, `team`, `is_group`, `parent_entity`, `path`, `color`,
`mime_type`, `file_size`, `tags`, `is_active`, `document`, `is_private`, `old_name`, `is_link`,
`comments`, `_modified`, `allow_download`.
`Drive Permission` fields: `user`, `entity`, `read`, `comment`, `share`, `write`, `upload`,
`team`.

---

## 9. Stage 3 — migration patch

> **NOT DONE, AND DELIBERATELY.** The 7 surviving documents were test material, so no data was
> migrated. `patches/v0/drop_clinical_document_20260909.py` removes the doctype and its files
> instead — which is also what closes the attachment-exposure path in §12. It is registered in
> `patches.txt` and applied by `bench migrate`.

`patches/v1/migrate_clinical_documents_to_drive_20260909.py`, registered in `patches.txt` per
[`CLAUDE.md`](../../CLAUDE.md) §9 (*every doctype change gets a patch; no manual schema fixes*).

Properties: **idempotent**, **dry-run first**, migrates only `status="Saved"`, and leaves the 24
`Deleted` rows untouched as the audit trail.

**EXAMPLE — the real payload.** 7 documents, 17 files, 1,133,804 bytes. It runs in under a
second. Do not let the size of the mapping table above suggest otherwise.

**The one subtle failure, and it is a leak.** Drive resolves permissions by walking **up** the
tree, applying the nearest sharing setting it finds. A private note inside a shared folder
inherits the share. Our current model has no inheritance at all.

**USER STORY.** The patch files all 7 migrated documents under one convenient parent folder →
that folder happens to carry a team permission → **the system shows** the same 7 documents to
their owners as before, so the migration looks clean → **the database actually contains**
`Drive Permission(team=1)` resolving down onto all 20 `Private` documents → **consequence:**
every private staff note becomes team-readable, silently, with no UI change to signal it.

**Mitigation, mandatory:** migrated documents land in **owner-private roots** — one root per
owner, no permission rows on it. A test asserts that post-migration, `get_user_access` for a
non-owner on every migrated `Private` document returns no read. That test must fail before the
fix exists.

---

## 10. Stage 4 — frontend cutover

> **DONE 2026-09-09**, by a route the plan did not anticipate: rather than rewriting the
> 3.6k-line screen at the same time as swapping the store, `use-clinical-documents.ts` was
> rewritten as a **transitional adapter** over `/api/drive/*`. Same exported names, same return
> shapes, different source. Two large changes landing together would have left no way to tell
> which one broke. Folders, upload, notes, sharing and delete all reach Drive; the adapter is
> marked for deletion once the screen moves to `use-drive.ts`.

Repo: `remedisys-ai-ehr`. Per [`CLAUDE.md`](../../CLAUDE.md) §13, the backend contract is the
reference; no backend behaviour is invented frontend-side.

| Today | Becomes |
|---|---|
| `src/app/api/clinical-documents/route.ts` | `src/app/api/drive/route.ts` |
| `src/app/api/clinical-documents/[id]/route.ts` | `src/app/api/drive/[id]/route.ts` |
| `src/app/api/clinical-documents/[id]/attachments/route.ts` | `src/app/api/drive/[id]/upload/route.ts` (chunked) |
| `src/app/api/clinical-documents/shareable-users/route.ts` | `src/app/api/drive/shareable-users/route.ts` |
| `src/hooks/use-clinical-documents.ts` | `src/hooks/use-drive.ts` |
| `clinical-documents-tab.tsx` folder state (line 2731) | server-backed `parent_entity` |

Keep the response envelope and the `id` / `title` / `notes_preview` field names identical so the
diff stays bounded. The design surface already built — grid/list toggle, All/Private/Shared
filter, sort, pagination, thumbnails — needs no change; only the folder layer becomes real.

All new user-visible strings go through `messages/en.json` + `messages/es.json` (frontend rule
10). Both files are already modified in the working tree.

---

## 11. Stage 5 — decommission

> **DONE in code 2026-09-09.** `Clinical Document`, `Clinical Document Share`,
> `api/v1/clinical_documents/`, `services/clinical_documents.py`, their tests and the
> frontend's `/api/clinical-documents/` routes are deleted. The doctype itself goes when the
> patch runs on each site.

Only after a bake period on real use:

1. Patch drops `Clinical Document` and `Clinical Document Share`.
2. [`docs/CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md) → `Doc status: superseded`,
   naming this document's successor ADR on its first line.
3. The naming debt in that document's §8 clears: Narzim Drive is Drive; the patient-chart
   Documents tab ([`docs/PATIENT_DOCUMENTS.md`](../PATIENT_DOCUMENTS.md)) keeps
   `Patient Medical Record`. The two features stop sharing a name.

---

## 12. Risks

| Risk | Consequence | Mitigation |
|---|---|---|
| **Audit regression** | A download path reaching Drive directly stops recording PHI reads; NOM-024 §7 unanswerable | Chokepoint blocks `drive.api.*` for **everyone**, not only Guest; test asserts an access-log row per download |
| **Folder permission inheritance** | Silent exposure of the 20 `Private` documents ([§9](#9-stage-3--migration-patch)) | Owner-private roots + a failing-first test |
| **Guest surface** | Public PHI with no login | [§6.1](#61-close-the-guest-surface-do-this-first-independent-of-everything-else) |
| **Rule 10 — PHI in logs** | Drive's activity logs record entity *titles*; a document titled after a patient puts a name in a log table | Assess `Drive Entity Log` against [`docs/security/AUDIT_LOGGING.md`](../security/AUDIT_LOGGING.md) before go-live. **UNVERIFIED** — still not done, flagged in the evaluation too |
| **Rule 2 — uninstall safety** | `required_apps` changes what the CI gate tests | Gate must install Drive |
| **AGPL** | Licence exposure | [§6.3](#63-decisions-only-a-human-can-make) — lawyer, not engineer |
| **Beta upstream** | Data loss risk near patient documents | Recorded acceptance + backup policy |
| **Upstream refactor** | Wrapper breaks on Drive upgrade | Pin the commit; wrapper covered by tests |

---

## 13. Gates

Per [`CLAUDE.md`](../../CLAUDE.md) §9, every PR: `ruff`, `mypy`, `eslint`, unit, integration,
install/uninstall.

Specific to this work, each written to **fail before** its fix exists:

1. Guest is rejected on `/api/method/drive.*`.
2. Every `download()` writes an access-log row.
3. Post-migration, a non-owner has no read on any migrated `Private` document.
4. A shared **editor** cannot change sharing fields (`PermissionError`, not silent ignore).
5. `get_entry` on an invisible document returns 404, never 403.
6. Byte-identical file uploaded by two owners does not throw (dedup salt intact).
7. Uninstalling `remedisys_healthcare_ai` leaves healthcare working with Drive installed.

**UNVERIFIED:** the existing 44 `clinical_documents` tests have not been re-run for this
document, and `bench run-tests` is broken bench-wide (ERPNext `before_tests` raises a Fiscal Year
overlap for every module).

---

## 14. Documentation debt this creates

| Document | Action |
|---|---|
| [`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md) | Bump to **2.0** — correct the "not installed" claim, point §5 here. It is `living`, so being wrong is a defect |
| [`CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md) | `superseded` at Stage 5, not before |
| `docs/adr/adr-061-*.md` | New — the decision record |
| [`docs/api/API_SPEC.md`](../api/API_SPEC.md) | Regenerate for the new module |
| [`CHANGELOG.md`](../../CHANGELOG.md) | Entry per change, `Security` section for the guest chokepoint |
| [`WORK_LOG.md`](../../WORK_LOG.md) | One entry per completed stage |
| [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md) | Add §2.1 and §2.2 until fixed |
| `README.md` in this directory | Regenerate — `scripts/gen_doc_indexes.py` |
| [`CLAUDE.md`](../../CLAUDE.md) | Open question from the evaluation §7.1: state the `allow_guest` / `ignore_permissions` prohibition in **this** repo's constitution. It currently lives only in the frontend's |

---

## 15. Open questions

1. **AGPL** — blocking. A "no" moves us to option E.
2. **Drive Team topology** — blocking. One per clinic, or one shared?
3. Is Drive's Writer (YJS collaborative editing) wanted, or is the current single-editor note
   enough? It is the most valuable thing Drive has and the most expensive to surface in Next.js.
4. Do we keep Drive's file-type breadth (video, DOCX, DICOM) or retain the current narrow
   allowlist? Broader upload is a compliance decision, not a convenience — PHI-6.
5. **UNVERIFIED** — has `Drive Entity Log` ever been assessed against
   [`docs/security/AUDIT_LOGGING.md`](../security/AUDIT_LOGGING.md)?
6. Does "Narzim Drive" stay English in `es-MX`?

---

## Sources

- Measured on `remedisys.localhost` via `bench console`, 2026-09-09 — row counts, attachment
  bytes, `Drive Team`, `installed_apps`
- `apps/drive` at pinned commit `0bd11d8` — `drive/api/*.py`, `drive/hooks.py`,
  `drive/drive/doctype/drive_file/drive_file.json`, `drive_permission.json`. The `allow_guest`
  count was obtained by grep on the pinned tree, not from upstream `main` or a summary
- This repo — [`CLAUDE.md`](../../CLAUDE.md) Rules 1, 2, 10, §3, §9, §9.9, §10, §13;
  [`CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md);
  [`FRAPPE_DRIVE_EVALUATION.md`](FRAPPE_DRIVE_EVALUATION.md);
  ``services/clinical_documents.py``;
  ``api/v1/clinical_documents/api.py``;
  [`api/v1/documents/api.py`](../../remedisys_healthcare_ai/api/v1/documents/api.py);
  [`utils.py`](../../remedisys_healthcare_ai/utils.py);
  [`hooks.py`](../../remedisys_healthcare_ai/hooks.py)
- Frontend repo (outside this repository, not linked): `remedisys-ai-ehr` —
  `src/components/narzim/inbox/clinical-documents-tab.tsx`,
  `src/hooks/use-clinical-documents.ts`, `src/app/api/clinical-documents/`

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.1 | 2026-09-10 | Anant Sharma (AI-assisted) | Stages 3-5 status recorded; links to the Scribe agent doc |
| 2.0 | 2026-09-09 | Anant Sharma (AI-assisted) | Executed: Clinical Document removed, Narzim Drive runs on Frappe Drive; status draft -> living |
| 1.2 | 2026-09-09 | Anant Sharma (AI-assisted) | Stage 1 backend built and verified; two upstream Drive defects recorded |
| 1.1 | 2026-09-09 | Anant Sharma (AI-assisted) | §6.1 implemented and verified end-to-end; guest surface closed |
| 1.0 | 2026-09-09 | Anant Sharma (AI-assisted) | Initial plan — five approaches compared, approach B chosen; records that Drive is already installed and that the new design's folders are client-only |
