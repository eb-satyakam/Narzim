# Narzim Drive — what it must do, and how it works now

**Doc status:** living · **Created:** 2026-09-16 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-22 by Anant Sharma (AI-assisted) · **Version:** 1.1

> **What this is.** The requirements in plain words, and how the feature actually behaves today.
> It replaces [`DRIVE_TEAM_TOPOLOGY.md`](DRIVE_TEAM_TOPOLOGY.md), whose recommendation (one shared
> team, no per-user drives) was reversed in practice on 2026-09-16.
>
> **Work still to do** is in [`DRIVE_ACTION_PLAN.md`](DRIVE_ACTION_PLAN.md). Open defects are in
> [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md). Project status lives only in
> [`docs/STATUS.md`](../STATUS.md). This document does not restate any of them.

---

## 1. What we need, in plain words

| # | Requirement | Status |
|---|---|---|
| R1 | My documents are mine. Nobody sees them until I share — not even an administrator | ✅ |
| R2 | The clinic has a shared space for documents everyone works on | ✅ |
| R3 | I can share one document with one named colleague, view-only or editable | ✅ |
| R4 | Deleting is recoverable. I can see what I deleted and put it back | ✅ |
| R5 | Creating a Drive team must never break Documents for everyone else | ✅ |
| R6 | A new user can use Documents immediately, with no setup step | ✅ |
| R7 | Administrators can reach Drive's own backend for maintenance | ✅ |
| R8 | Clinical staff use the EHR, not Drive's backend | ⚠️ widened by decision, see §6 |
| R9 | I can see how much storage I have used | ✅ |
| R10 | Administrators can manage other people's documents when needed | ⚠️ partly — see §7 |
| R11 | I can upload several files at once | ✅ |
| R12 | I can empty my trash, or delete selected items from it | ✅ |

## 2. The one idea that explains everything

**Your documents are private because you OWN them, not because of which team they sit in.**

Every check asks the same two questions:

1. Do you own it? → you see it
2. Was it shared with you? → you see it
3. Otherwise → it does not exist as far as you are concerned (a 404, never a 403)

This is `services/drive.py::_is_visible()`, and administrators are not exempt from it.

## 3. What happens when you add a user

```
Admin creates a user, gives them one clinical role
        ↓
A personal Drive Team is created, owned by that user        (overrides/user_drive.py)
        ↓
They log in and open Documents — it just works              (_ensure_team_member)
        ↓
What they upload goes into THEIR OWN team                   (_write_team)
```

No setup screen, no button, no admin step. Roles that count: `EB_Practitioner`, `EB_Nurse`,
`EB_Healthcare Admin`, `EB_Front Desk` — granted at creation **or later**.

If someone cannot see Documents, it is almost always a **missing role**, not a missing drive.

## 4. Where documents live

| | |
|---|---|
| **Your own team** | everything you upload or create from now on |
| **The clinic team** | documents created before 2026-09-16, and uploads by users who have no personal team |

You see **both**, plus anything shared with you — so the split is invisible in normal use. Nothing
was migrated; old documents simply stay where they are.

## 5. What you can do

| Action | Notes |
|---|---|
| **Upload** | Several files at once — picker, drag-and-drop or paste. 3 upload at a time |
| | 25 MB per file; images, PDF, xlsx, xls, csv only |
| **Share** | Named colleagues (view or edit), or the whole clinic team |
| | Only staff can receive a share. Never the public — refused at two layers |
| **Revoke** | Removes access completely, including by direct link |
| **Delete** | Goes to Trash. Recoverable for 30 days |
| **Trash** | Sort, search, restore, delete one, delete selected, or Empty |
| **Storage** | Shown in the Documents footer. Amber at 80%, red at 90% |

**Trash shows the whole clinic's deletions**, but you can only restore or delete **your own** — the
buttons appear only on rows you can act on.

## 6. Drive's own backend (`/drive`)

Reachable by **Desk users** (`user_type = "System User"`). Website User accounts — which most
clinical staff are — are blocked, as is Guest.

⚠️ **What this costs, stated plainly.** Drive's own UI does not call `services/drive.py`, so
`_is_visible()` never runs there and **no access-log row is written**. A Desk user can read
colleagues' documents through it without leaving a trace. Measured before the guard existed: a
nurse owning **zero** documents saw **31**.

This was widened from Administrator-only by explicit decision on 2026-09-16. `overrides/drive_guard.py`
records the reasoning and the measurement.

## 7. What is recorded, and what is not

| Event | Recorded? |
|---|---|
| Opening/downloading a document in the EHR | ✅ `Access Log`, written before the bytes |
| Permanently deleting from Trash | ✅ `Access Log`, written before the delete |
| Moving a document to a patient chart | ✅ logged as an egress |
| **Moving a document to Trash** | ❌ only `modified_by`, overwritten by the next write |
| **Anything done through `/drive`** | ❌ nothing at all |

## 8. Two settings that matter

**`remedisys_drive_team` in `site_config.json` — mandatory.** It names the clinic's shared team.
With a team per user there are always several, and without this key **every Narzim Drive call fails
for every user**. Pin the team whose `personal = 0`. Each site needs its own value, set **before**
anyone creates a user there.

**Storage quota is per user, not per clinic.** `Drive Team.quota` is checked against your own files
only, so with N staff the site can hold N × quota. **No clinic-wide ceiling exists anywhere in
Drive**, and the meter does not invent one.

## 8.5 Previews, and how a file's bytes reach the browser

A document card renders a real preview of the file, not an icon: images inline, PDFs in a scaled
`<iframe>`, spreadsheets and .docx rendered client-side. All of it is served through
`/api/drive/<id>/download`, our audited endpoint — never a raw `/private/files` path — so every byte
shown on the Documents screen is attributable in the Access Log.

**Served inline, not as an attachment.** The same URL renders the thumbnail and performs an explicit
download; only `?download=1` sets `attachment`. This is load-bearing: served as an attachment, merely
*looking* at the Documents screen saved every PDF on it, once per render (reported 2026-09-09, five
copies of one file from a single visit).

**The proxy must preserve range and conditional semantics.** Chrome's built-in PDF viewer does not
fetch a PDF in one request — it issues `Range` requests and expects `206` replies carrying
`Content-Range`. Until 2026-09-22 the proxy sent no `Range` upstream, dropped `Accept-Ranges` and
`Content-Range` on the way back, and hardcoded `status: 200`, so the viewer received a `200` whose
`Content-Length` did not describe its body and rendered nothing — **every PDF card showed Chrome's
grey "cannot display" placeholder, while image cards were fine, because `<img>` does not use ranges.**

Measured against Frappe on 2026-09-22, which does support them:

```
GET  …/download                      → 200  application/pdf  Content-Length: 396391
GET  …/download  Range: bytes=0-1023 → 206  Accept-Ranges: bytes
                                            Content-Range: bytes 0-1023/396391
```

`Cache-Control` is deliberately **not** forwarded. Frappe answers with
`no-store, no-cache, must-revalidate`, which is right for an API reply and wrong for a thumbnail: it
forbade the browser from keeping a single byte, so every render re-fetched ~400 KB per PDF card. The
proxy sets `private, max-age=300` instead — out of any shared cache, since these are patient
documents, but reusable by the one browser that fetched it.

Trash renders the same previews, through the same component (`DocumentThumbnail`). It works on a
deleted row because `get_entry()` gates on permission, not on `is_active`.

## 9. Known limits

- A document trashed and left for 30 days is deleted automatically, and that is not reversible.
- Permanent deletion is immediate and cannot be undone. Nothing checks whether the document is a
  clinical record subject to NOM-024's five-year retention floor — Narzim Drive cannot tell.
- Deleting a user removes their Drive membership but **not** their documents; a departing
  clinician's records are deliberately left in place.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-22 | Anant Sharma (AI-assisted) | Added §8.5 — how previews are served, the range/conditional requirement that broke PDF thumbnails, and the cache-control override |
| 1.0 | 2026-09-16 | Anant Sharma (AI-assisted) | First version — requirements in plain words and how the feature behaves after per-user drives, trash management, multi-upload and the storage meter |
