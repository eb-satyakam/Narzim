# Frappe Drive vs. Clinical Document — evaluation for Narzim Drive

**Doc status:** superseded · **Created:** 2026-09-08 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-10 by Anant Sharma (AI-assisted) · **Version:** 2.1

> **SUPERSEDED 2026-09-09 by [`DRIVE_MIGRATION_PLAN.md`](DRIVE_MIGRATION_PLAN.md).** Its
> recommendation — *do not install Frappe Drive* — was reversed and the migration is done.
> What runs today: [`DRIVE_MIGRATION_PLAN.md`](DRIVE_MIGRATION_PLAN.md) for the store,
> [`SCRIBE_DOCUMENT_AGENT.md`](SCRIBE_DOCUMENT_AGENT.md) for the document agent.
> Two of its factual claims were already wrong when written: Drive **was** installed on this
> bench, and its `get_file_content` JWT finding was overstated (the token is scoped to one
> entity for 60 seconds). Its security analysis of Drive's 26 guest endpoints still holds and
> is why `overrides/drive_guard.py` exists. Kept as the record of the reasoning, not as
> current guidance.
>
> **Question this answers.** Narzim Drive is today backed by our own `Clinical Document`
> doctype ([`docs/CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md)). Frappe ships an
> official file-storage app, **Frappe Drive**. Should we install it, and what do we give up or
> gain either way?
>
> **Short answer: no — keep `Clinical Document` and extend it.** Frappe Drive is a good
> general-purpose product built on assumptions a PHI system cannot accept. §2 is the evidence,
> §5 the recommendation, §6 what to build instead.
>
> **Nothing in this document is approved or started.** It is an evaluation and a proposal.

---

## 1. What Frappe Drive is

An open-source cloud-storage product from Frappe Technologies — a self-hostable alternative to
Google Drive, positioned by its authors against NextCloud and OwnCloud. Two halves:

| Half | What it does |
|---|---|
| **Core** (file manager) | Chunked multi-part uploads, folder uploads preserving structure, in-browser preview, video streaming with range requests, search, activity log, tags, favourites, trash, storage pooling or per-user quotas |
| **Writer** (document editor) | Real-time collaborative rich-text editing (CRDT), inline comments and annotations, manual + automatic versioning, DOCX import |

**Stack:** Frappe Framework (Python) · Frappe UI (Vue 3 SPA) · TipTap / ProseMirror ·
YJS + `pycrdt`.
**Licence:** AGPL-3.0.
**Maturity:** the project's own README carries the warning *"Frappe Drive is in beta. It is
strongly advised to take backups in production use."*

**It is not installed on this bench.** `sites/apps.txt` lists 11 apps — `frappe`, `payments`,
`telephony`, `erpnext`, `clefincode_chat`, `frappe_whatsapp`, `eb_frappe_jwt`,
`remedisys_healthcare_ai`, `healthcare`, `insights`, `frappe_assistant_core`. `drive` is not
among them, so adopting it is an install decision, not a configuration one.

### Data model — 21 doctypes

`Drive File` (the entity — file *or* folder, self-referencing tree) · `Drive Permission` ·
`Drive Team` · `Drive Team Member` · `Drive Document` · `Drive Doc Version` ·
`Drive Document Version` · `Drive Comment` · `Drive Tag` · `Drive Entity Tag` ·
`Drive Favourite` · `Drive Entity Log` · `Drive Entity Activity Log` · `Drive Notification` ·
`Drive Transfer` · `Drive File Update` · `Drive Settings` · `Drive Disk Settings` ·
`Drive Desktop Client` · `Drive User Invitation` · `Account Request`

For comparison, our whole Narzim Drive feature is three doctypes
([§3](#3-clinical-document--what-we-have-today)).

### Permission model

Three tiers — **View** (view, download, comment, share), **Edit**, **Upload** — on a
`Drive Permission` row carrying `user`, `entity`, `read`, `comment`, `share`, `write`,
`upload`, `team`.

Permissions **cascade down the folder tree**: on access, Drive walks *up* the path looking for
the nearest sharing setting, applies the first one it finds, and otherwise falls back to
defaults. Sharing targets are individual users, a team, or **the public**. From the official
docs, verbatim: *"If you share an item publicly, **anyone can access the file**. They will not
need to login."*

Drive does not rely on the doctype permission table — `Drive Permission`'s own table grants the
**`All` role** create/read/write/delete. It substitutes its own logic via
`permission_query_conditions` on 8 doctypes and `has_permission` hooks on `Drive File` and
`Drive Document`. That is a legitimate design, but it means the safety of the whole model rests
on hook code we would not own and would not review on every upgrade.

### Storage

`FileManager` abstracts local filesystem and **S3-compatible object storage** (`boto3`).
Uploads accumulate as chunks in `private/files/{team}/.uploads/`, then move to
`{team_home}/{entity_id}`. MIME type is resolved from both filename and binary magic numbers.

### Deployment cost

Python ≥ 3.10, plus `opencv-python-headless`, `python-magic`, `mimemapper`, **`unoconv`**
(which pulls in LibreOffice, for previews), `PyJWT`, `thumbnail`, `boto3`, `pycrdt`, `Markdown`,
`beautifulsoup4`, `html2text` — and **`ffmpeg`** as a system APT package. Every one of those
lands on the same bench that serves patient data.

---

## 2. Is it useful for Narzim Drive?

Feature-for-feature it is *more* capable than what we have ([§2.4](#24-what-frappe-drive-genuinely-has-that-we-do-not)).
That is not the question. The question is whether its assumptions survive contact with a
clinical product, and three of them do not.

### 2.1 Blocker — guest access is architectural, not incidental

Measured directly against `frappe/drive@main`, files under `drive/api/`, read 2026-09-08:

| Metric | Count |
|---|---|
| `@frappe.whitelist(...)` methods across `drive/api/` | **83** |
| of those, carrying `allow_guest=True` | **26 (31 %)** |
| `ignore_permissions=True` call sites in `drive/api/` | **16** |

The guest-accessible methods include the ones that matter most:

```
files.py         upload_file · get_file_content · stream_file_content · get_thumbnail
                 save_doc · create_auth_token · upload_embed · list_entity_comments
                 call_controller_method · get_entity_type
permissions.py   get_user_access · get_entity_with_permissions
docs.py          save_doc_comment · create_comment · get_wiki_link
list.py          files
embed.py         get_file_content
```

`get_file_content` and `stream_file_content` are the download paths. `create_auth_token` mints a
JWT for an unauthenticated caller. `call_controller_method` is a generic dispatcher. All
reachable without a session.

The frontend constitution forbids exactly this — `EB_Healthcare_Frontend/CLAUDE.md` §3 and §5
rules 6–7 ("Never `allow_guest=True`", "Never `ignore_permissions`"), which govern what that
repo may *request of us*. Nothing in this repo's [`CLAUDE.md`](../../CLAUDE.md) states the rule
in those words, and it probably should — see [§7](#7-open-questions).

This is not a bug in Drive. Public-link sharing is a *headline feature* of a Google Drive
competitor, and a guest-issued JWT is the honest implementation of it. It is simply the wrong
product shape for us. We could hide public sharing in a UI, but the endpoints stay reachable on
the bench — **a UI toggle is not an authorisation boundary.**

### 2.2 Blocker — the consuming frontend cannot use Drive's own frontend

Drive ships a Frappe UI (Vue 3) SPA, mounted by
`website_route_rules: /drive/<path:app_path> → drive`. The Narzim frontend is Next.js App
Router + shadcn/ui + next-intl, and is explicitly *fully decoupled from Frappe Desk*
(`EB_Healthcare_Frontend/CLAUDE.md` §1, locked assumptions). We would ship none of Drive's UI.

Installing Drive therefore means running an app whose entire presentation layer — plausibly most
of its engineering value — is dead weight, while the same file browser, preview, share dialog
and editor get rebuilt in Next.js regardless. The collaborative Writer is the sharpest case:
YJS/CRDT editing is genuinely hard and genuinely valuable, and it is exactly the part least
portable to another frontend.

This also cuts against **Rule 8 — Frappe-Native UX** ([`CLAUDE.md`](../../CLAUDE.md) §4) in an
awkward direction: Drive *is* Frappe-native, but native to a UX we have deliberately left.

### 2.3 Blocker — audit trail, licence, and beta status

- **Audit.** `Drive Entity Log` / `Drive Entity Activity Log` are product analytics ("what did I
  open recently"), not a compliance audit trail. Our own patient-documents path already writes a
  `make_access_log(...)` on every download-URL issue — see
  [`api/v1/documents/api.py`](../../remedisys_healthcare_ai/api/v1/documents/api.py), where the
  call carries a comment recording exactly why it is there rather than relying on core's own
  Access Log write. Drive has no equivalent hook, no retention policy and no jurisdiction
  awareness. Bolting one on means patching a third-party app on every upgrade — precisely what
  **Rule 1 — Upgrade-Safe** exists to prevent.
  **UNVERIFIED:** nobody has audited Drive's logs against
  [`docs/security/AUDIT_LOGGING.md`](../security/AUDIT_LOGGING.md). This document assumes they
  are insufficient rather than having proven it.
- **Rule 10 — No PHI in Logs, Ever.** Drive's activity logs record entity *titles*. A document
  titled after a patient puts a name in a log table by default, with no scrubbing layer. That
  would need review before any install, not after.
- **Licence.** AGPL-3.0. `remedisys_healthcare_ai` is not AGPL. Whether installing and calling
  an AGPL app across a bench creates a network-served derivative work is a lawyer's question,
  not an engineer's — but it is a question we currently do not have to ask at all.
- **Beta.** The upstream project self-describes as beta and advises backups. For patient
  documents that is a real cost, not boilerplate.

### 2.4 What Frappe Drive genuinely has that we do not

Being fair to it — every one of these is a real gap in `Clinical Document`:

| Capability | Drive | Clinical Document |
|---|---|---|
| Folders / hierarchy | yes, recursive tree | **no** — flat list |
| Chunked / resumable upload | yes | no — single request, 25 MB cap |
| S3-compatible object storage | yes | no — Frappe private files on disk |
| Storage quotas | per-user or pooled | **none** |
| File versioning | yes | no |
| Real-time collaborative editing | yes (YJS) | no — last write wins |
| Video streaming (range requests) | yes | no |
| Trash / restore | yes | soft-delete exists but is **not restorable** by any endpoint |
| Full-text search | yes | no — field match only |
| Public links | yes | no *(and we do not want it)* |
| Desktop sync client | yes | no |

---

## 3. `Clinical Document` — what we have today

- API: ``api/v1/clinical_documents/api.py``
  — 8 whitelisted endpoints, 113 lines, no business logic
- Service: ``services/clinical_documents.py``
  — 513 lines, every privacy rule
- Doctypes: `Clinical Document`, `Clinical Document Share` (child table). `Document Category`
  belongs to the *other* feature ([`docs/PATIENT_DOCUMENTS.md`](../PATIENT_DOCUMENTS.md)) — a
  Clinical Document has no `patient` field and no category link
- Tests: `remedisys_healthcare_ai/tests/clinical_documents/test_clinical_documents.py` — 44,
  documented passing 2026-08-18. *Not re-run for this document.*
- Reference: [`docs/CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md), and
  [`docs/api/API_SPEC.md`](../api/API_SPEC.md) for the generated endpoint entry

All 8 endpoints are consumed by the frontend; there are no unwired methods and no frontend
calls without a backend method.

### Pros

1. **Private by default, and it 404s rather than 403s.** `_get_visible_or_404` returns an
   identical `DoesNotExistError` for "does not exist" and "exists but you may not see it", so a
   private document is indistinguishable from a nonexistent one. A 403 leaks that the document
   exists — and for a document titled after a patient, that is itself a disclosure.
2. **The confidentiality gate is a positive allowlist.** `_STAFF_ROLES` (7 roles) governs who
   may see *another* person's shared document; `_SHAREABLE_ROLES` (4) governs who appears in the
   share picker. Deliberately different sets, both allowlists — a newly created role sees nothing
   until someone adds it. That is the safe failure direction.
3. **A real defect is already fixed here.** Every read path uses `frappe.get_all` /
   `frappe.get_doc`, neither of which applies doctype permissions — so the permission table never
   runs and `_is_staff()` must enforce it in code. The service module records that without this,
   every patient-portal account could read the notes and attachment URLs of any team-shared
   document. Verified against live data 2026-08-18. Re-platforming discards that knowledge and
   re-opens the class of bug.
4. **Owner vs. editor is separated correctly.** A shared editor may change what the document
   *says*; only the owner may change *who sees it*, or delete it. A non-owner slipping a sharing
   field into an update gets a `PermissionError` — not a silent ignore, which is the failure mode
   that hides privilege bugs.
5. **Soft delete preserves the audit trail** while behaving like a hard delete for every reader,
   owner included.
6. **Attachment dedup is already de-fanged.** `save_private_file`
   ([`utils.py`](../../remedisys_healthcare_ai/utils.py)) salts Frappe's content-hash dedup with
   `(doctype, name)`, because core's global dedup made a byte-identical PDF uploaded for two
   patients throw `PermissionError` for whoever could not read the first patient's chart. Hit in
   production-shaped testing 2026-07-16.
7. **Rule 1 and Rule 2 hold trivially.** No core patching, and uninstalling
   `remedisys_healthcare_ai` takes the whole feature with it cleanly. Adding a third-party app
   with 21 doctypes and its own permission hooks makes the uninstall-safety CI gate a harder
   question than it is today.
8. **No new deployment surface** — no ffmpeg, no LibreOffice, no OpenCV, no S3 credentials, no
   AGPL, no beta dependency anywhere near patient data.
9. **We own every line**, so a jurisdiction or retention rule lands as a normal change rather
   than a fork.

### Cons

1. **Flat.** No folders, no hierarchy. This is the gap users will feel first, and the single
   strongest argument for Drive.
2. **25 MB hard cap, single-request upload.** No chunking, no resume. A large imaging study or a
   long video simply cannot be stored.
3. **Narrow file allowlist** — images, PDF, `xlsx`/`xls`/`csv`. No DOCX, no video, no audio, no
   DICOM.
4. **No quotas.** Nothing stops one user filling the disk.
5. **No versioning.** Editing `notes` overwrites; last write wins, with no conflict detection
   between two editors of the same shared document.
6. **Soft delete is one-way.** `status` flips to `Deleted` and no endpoint restores it. No trash
   view, no recovery path short of a DB edit.
7. **Files live on the bench filesystem.** No object storage, so disk growth is a server
   operations problem and geo-redundancy is a backup problem.
8. **Two features share one name.** `Clinical Document` (staff personal drive) vs. the
   patient-chart Documents tab (`Patient Medical Record` rows). We keep a whole document alive
   largely to stop people confusing the two — a naming debt worth paying down.
9. **`tags` is JSON stuffed into a `Small Text` field**, so tags are neither queryable nor
   indexable; filtering by tag happens in Python or in the client.
10. **No full-text search** over notes or attachment contents. `list_documents(search)` is a
    field match, not an index.

---

## 4. Options considered

Five, with the reason each was rejected or kept.

**A. Adopt Frappe Drive wholesale — install it and send staff to its Vue UI at `/drive`.**
Rejected. It abandons the single-application experience, drops the `en`/`es` catalogs (Drive is
not translated for us), drops the design system, and hands staff a second surface to log into.
And it still carries every §2.1 guest endpoint.

**B. Install Frappe Drive as a headless backend; the Next.js app consumes it through its BFF.**
The most tempting option, and worth naming explicitly because it is what most people mean by
"use Frappe Drive". Rejected on §2.1 alone: the 26 guest endpoints are reachable on the bench
whether or not anything of ours calls them, so **installing the app is the risk, independent of
how we consume it**. Add AGPL, beta status, no clinical audit trail, Rule 10 exposure through
entity titles in activity logs, and 21 doctypes of upgrade surface we do not control — in
exchange for a feature set whose most valuable parts (the Writer, previews, the desktop client)
we would never expose.

**C. Keep `Clinical Document` and extend it incrementally.** **Recommended.** Every §3 con is
normal scoped work on code we own, with the §3 pros preserved. Nothing in the gap list requires
Drive's architecture: folders are a `parent` link, chunking is an upload protocol, quotas are a
query and a limit.

**D. Hybrid — keep `Clinical Document` for staff work documents, adopt Drive only for a non-PHI
corpus** (clinic SOPs, policy manuals, training material, HR forms).
Not rejected on the merits — genuinely reasonable, since none of §2.1 matters where no patient
data exists. Deferred rather than adopted: it is a second system to run, upgrade and back up for
a document set nobody has yet requested, and "no PHI ever enters this drive" is a policy promise
enforced by nothing. Revisit if a real SOP-library requirement appears, and only with a hard
tenancy boundary.

**E. Build a new PHI-safe doctype modelled on Drive's data model** — a `Drive File`-style
self-referencing tree, our own permission rows, our own storage abstraction.
Rejected as premature. This is option C's endpoint reached by rewrite instead of by increments,
discarding 44 passing tests, two documented production defect fixes and a working frontend to
get there. Executing C's roadmap arrives at substantially this design anyway, with continuity.

---

## 5. Recommendation

**Do not install Frappe Drive. Keep `Clinical Document` and close its gaps.**

The decision turns on one measured fact rather than on preference: **26 of 83** whitelisted
methods in `drive/api/` carry `allow_guest=True`, including both file-download paths and a
generic controller dispatcher. Everything else — AGPL, beta status, the unusable Vue frontend,
the missing audit trail, Rule 10 exposure, the ffmpeg/LibreOffice/OpenCV deployment tail — is
corroborating, not load-bearing.

Frappe Drive is a good product. It is a *general-purpose* product, and its most attractive
property — frictionless sharing, up to and including the public internet — is precisely the one
a clinical document store must not have.

---

## 6. What to build instead — proposed roadmap

Ordered by value per unit of work. **Nothing here is approved or started.**

| # | Gap | Proposed shape | Owner |
|---|---|---|---|
| 1 | No folders | `parent` Link on `Clinical Document` (self-referencing) plus an `is_folder` flag. Visibility must resolve at the **root of a subtree**, not per node, or a shared folder leaks a private child — the one genuinely subtle piece | backend + FE |
| 2 | Soft delete is one-way | `restore_document(id)` endpoint and a Trash view. The rows already exist; this is the cheapest item on the list | backend + FE |
| 3 | Tags not queryable | Move `tags` from JSON-in-`Small Text` to a child table, keeping the API response shape identical so the frontend does not change | backend |
| 4 | 25 MB cap, no resume | Our own chunked upload endpoint — not Drive's | backend + FE |
| 5 | No versioning | Snapshot `notes` into a child table on save; surfaces "who changed what" on shared documents | backend + FE |
| 6 | No quotas | Per-user byte total and a configurable ceiling | backend |
| 7 | Naming collision | Rename the *frontend* surface consistently to "Narzim Drive", leaving `Clinical Document` as the doctype name. No backend change | FE only |
| 8 | No object storage | Only if disk growth becomes real. Frappe supports S3 backends independently of Drive | ops |

Each of 1–6 needs its own doctype-change checklist ([`CLAUDE.md`](../../CLAUDE.md) §9, "Every
doctype change") and a test that fails before the fix. Items 1 and 4 are what users will ask for
first; item 2 is the cheapest thing on the list.

---

## 7. Open questions

1. **Should this repo's [`CLAUDE.md`](../../CLAUDE.md) state the `allow_guest` / `ignore_permissions`
   prohibition directly?** It is currently written only in the frontend constitution, as a rule
   about what that repo may request. The rule is really a backend rule, and this evaluation had
   to reach across repos to cite it.
2. Is there a real requirement for a non-PHI SOP/policy library (option D), or was Frappe Drive
   raised only as an alternative backing store for the existing feature?
3. Which roadmap items in §6 are wanted, and in what order?
4. **UNVERIFIED** — have Drive's `Drive Entity Log` / `Drive Entity Activity Log` ever been
   assessed against [`docs/security/AUDIT_LOGGING.md`](../security/AUDIT_LOGGING.md)? This
   document assumes not, and says so rather than asserting they are inadequate.
5. Is "Narzim Drive" a product name that stays English in `es-MX`? A frontend question, recorded
   here because it surfaced during this review.

---

## Sources

- Frappe Drive repository — <https://github.com/frappe/drive> (README, `pyproject.toml`,
  `hooks.py`, `drive/api/*.py`, `drive/drive/doctype/`), read at `main`, 2026-09-08. The
  `allow_guest` and `ignore_permissions` counts in §2.1 were obtained by downloading
  `drive/api/*.py` and counting, not from a summary
- Frappe Drive documentation — <https://docs.frappe.io/drive/introduction> and
  <https://docs.frappe.io/drive/file-access>
- Frappe Cloud marketplace listing — <https://cloud.frappe.io/marketplace/apps/drive>
- This repo — [`CLAUDE.md`](../../CLAUDE.md) Rules 1, 2, 8, 10 and §9;
  [`docs/CLINICAL_DOCUMENT_DRIVE.md`](../CLINICAL_DOCUMENT_DRIVE.md);
  [`docs/PATIENT_DOCUMENTS.md`](../PATIENT_DOCUMENTS.md);
  ``services/clinical_documents.py``;
  ``api/v1/clinical_documents/api.py``;
  [`api/v1/documents/api.py`](../../remedisys_healthcare_ai/api/v1/documents/api.py);
  [`utils.py`](../../remedisys_healthcare_ai/utils.py)
- Frontend repo (not linked — outside this repository): `EB_Healthcare_Frontend/CLAUDE.md` §1,
  §3, §5; `src/hooks/use-clinical-documents.ts`; `src/app/api/clinical-documents/`

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.1 | 2026-09-10 | Anant Sharma (AI-assisted) | Links to what now runs |
| 2.0 | 2026-09-09 | Anant Sharma (AI-assisted) | Superseded by DRIVE_MIGRATION_PLAN.md; recommendation reversed and executed |
| 1.0 | 2026-09-08 | Anant Sharma (AI-assisted) | Initial evaluation — Frappe Drive assessed against `Clinical Document`; recommendation to keep and extend |
