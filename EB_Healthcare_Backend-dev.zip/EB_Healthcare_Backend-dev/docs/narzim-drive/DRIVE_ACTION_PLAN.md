# Narzim Drive — action plan

**Doc status:** living · **Created:** 2026-09-15 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-15 by Anant Sharma (AI-assisted) · **Version:** 1.1

> **What this is.** The ordered list of work on Narzim Drive, why each item exists, and what blocks
> what. It is the *plan*; the *reasoning and the decision* live in
> [`DRIVE_TEAM_TOPOLOGY.md`](DRIVE_TEAM_TOPOLOGY.md), and defects still open live in
> [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md). This document does not restate either.
>
> **Project and phase status is not here** — it lives only in [`docs/STATUS.md`](../STATUS.md).

---

## Summary

| Priority | Item | Why now |
|---|---|---|
| ~~P0~~ | ~~Pin `remedisys_drive_team`~~ | ✅ **DONE 2026-09-15** — Documents restored |
| **P1** | Restrict `/drive` to operations use | A nurse can read 31 clinical documents, unaudited |
| **P2** | Trash view in Narzim Drive | Deleted documents are unrecoverable through the product |
| **P3** | Move the drive to a real clinic team | Clinic documents live in one person's personal drive |
| **P4** | Documentation corrections | Two `KNOWN_ISSUES` entries are stale; new findings unrecorded |

Nothing here requires a per-user `Drive Team`. That option was considered and rejected — see
[`DRIVE_TEAM_TOPOLOGY.md`](DRIVE_TEAM_TOPOLOGY.md) §7.

---

## P0 — Pin the clinic team ✅ DONE 2026-09-15

**Problem.** `_team()` refuses to guess when more than one `Drive Team` exists and no pin is set. It
throws, and every Narzim Drive endpoint begins with `_context()`, so the whole Documents feature
fails closed for all users. This happened **three times on 2026-09-15**, each time because a team was
created in Drive's own UI.

**Change.** In `sites/<site>/site_config.json`:

```json
"remedisys_drive_team": "0pul9ncq46"
```

**Effect.** Documents works again, and creating a team becomes harmless instead of an outage.

**Verified 2026-09-15**, with both teams still present — which is the proof that the pin removes the
failure rather than merely avoiding it:

```
OK  admin@narzim.com  -> 12 entries
OK  nurse@narzim.com  ->  1 entries
OK  adrian@narzim.com ->  7 entries
OK  Administrator     ->  4 entries
```

The previous config is backed up at `site_config.json.bak.20260915`. **This is a local dev site
only** — the same pin must be applied to `dev-healthcare.m.frappe.cloud` and to production before
anyone creates a team there.

**Note.** Deleting a `Drive Team` is impossible through Drive's UI or Desk at the pinned commit
(`0bd11d8`) — an upstream `on_trash` defect. Recovery requires a console session. So the pin is the
only practical guard.

---

## P1 — Restrict the vendor backend

**Problem.** `_is_visible()` lives in `services/drive.py`; Drive's own UI at `/drive` never calls it.
Measured 2026-09-15: a nurse owning **zero** documents is shown **31**. Drive writes no
`make_access_log` row, so such a read is also untraceable.

**Change.** Widen `overrides/drive_guard.py` Layer 1 from *deny anonymous* to *deny anyone who is not
Administrator*. The file already blocks the same URL surface, already has the two-layer design, and
already fails open on internal error (Rule 7) — this is a condition change, not new machinery.

**Tests required** — access-control code, per [`CLAUDE.md`](../../CLAUDE.md) §11. Add to
`remedisys_healthcare_ai/tests/security/test_drive_guard.py`.

**Decision needed.** Administrator only, or does `System Manager` keep access?

---

## P2 — Trash view

**Problem.** `trash()` and `restore()` are built and the BFF routes exist, but `list_entries`
hardcodes `is_active=1` and there is **no endpoint that lists trashed items**. A document deleted in
Narzim Drive cannot be found or restored through the product.

**Depends on P1** — `/drive` is currently the only working trash UI, so it must not be closed until
this exists.

**Backend**
- `services/drive.py` — `list_trash()`, reusing `_context()`, `_is_visible()`, `_entry_fmt()`
- `api/v1/drive/api.py` — whitelist it
- `tests/security/test_drive_service.py` — non-staff refused; scoping; trashed appears; restored leaves

**Frontend** (`remedisys-ai-ehr`)
- `src/app/api/drive/trash/route.ts`
- A **Trash** tab beside All / Private / Shared — *fetched*, not filtered, since trashed rows never
  reach the browser today
- Strings through `messages/en.json` + `messages/es.json` (frontend rule 10)

**Do not add "Delete permanently."** Upstream `clear_deleted_files` computes
`today + timedelta(days=30)` and filters `modified < that`, so every `is_active = -1` row matches
immediately. Permanent delete is purged at the next daily run — about 24 hours, not 30 days.

**Decision needed.** Whose trash does a user see — own only, or team-wide for `EB_Healthcare Admin`?

---

## P3 — A real clinic team

**Problem.** The clinic's 32 documents live in `0pul9ncq46`, a `personal = 1` team titled
*Administrator*, created automatically by Drive's setup wizard. Nobody chose it.

**Change.** Create a non-personal `Chavitos Pediátrica` team, move the active files, repoint the pin.

**Order matters.** The pin (P0) must already be in place, or creating the new team reproduces the P0
outage.

**Not urgent.** Cosmetic and organisational rather than a safety issue — R1–R3 hold either way.

---

## P4 — Documentation corrections

In [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md):

- **Remove** *"Narzim Drive folders exist only in the browser"* — fixed; folders now call
  `create_folder` and persist via `Drive File.parent_entity`
- **Remove** *"share dialog says 'Anyone with the link'"* — fixed; the option is gone and the code
  comment records it as deliberately absent
- **Add** the `/drive` bypass (P1)
- **Add** the team-creation trap: creating a team takes Documents down and the team cannot be deleted
  through any UI
- **Add** deletion is unaudited — `track_changes` unset on `Drive File`, `tabVersion` holds 0 rows

---

## Upstream defects (not fixable here)

Recorded so they are not rediscovered. Frappe Drive @ `0bd11d8`; Rule 1 forbids patching a vendored
app, so each is worked around or accepted.

| Defect | Effect |
|---|---|
| `drive_team.py:58` — `pluck=["name"]` and a column that does not exist | A `Drive Team` can never be deleted through the UI |
| `clear_deleted_files` — `+ timedelta(days=30)` | Permanent delete purges in ~24h, not 30 days |
| `delete_entities` throws on an empty list | The daily trash job errors whenever nothing is due |
| `"You're out of storage!"` not wrapped in `_()` | English text in a Spanish clinic |

---

## Decisions blocking work

1. **P1** — Administrator only, or `System Manager` too?
2. **P2** — whose trash: own only, or team-wide for `EB_Healthcare Admin`?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-15 | Anant Sharma (AI-assisted) | P0 completed — clinic team pinned on the local bench, Documents restored; other sites still to do |
| 1.0 | 2026-09-15 | Anant Sharma (AI-assisted) | Initial plan — P0 pin, P1 backend restriction, P2 trash view, P3 clinic team, P4 doc corrections |
