# Claude Code — command and shortcut reference

**Doc status:** living · **Created:** 2026-09-02 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

> **Scope.** Every prompt prefix, key, slash command, skill and CLI flag that speeds up work
> in this bench. Written for the Remedisys workflow specifically, not as generic Claude Code docs.
>
> **Verification status.** CLI flags in §6 were read from `claude --help` on 2026-09-02 and are
> exact. Slash commands (§3) and key bindings (§2) are **build-dependent** — the authoritative
> list for your installed version is always `/help`. Where a binding is uncertain it is marked
> ⚠️. Skills in §4 were read from this session's loaded skill list and are exact for this machine.

---

## 1. Prompt-line prefixes

These are the highest-leverage items on the page. Everything else is convenience; these change
how much work the model has to do before it can start.

| Prefix | Meaning | Why it matters here |
| --- | --- | --- |
| `/name` | Invoke a skill or built-in command. | See §3 and §4. |
| `@path/to/file` | Inline that file or directory into context immediately. | Replaces a Glob + Grep + Read round-trip. `@apps/remedisys_healthcare_ai/docs/STATUS.md` is one turn faster than "read the status doc". Tab-completes. |
| `!cmd` | Run a shell command directly. Output lands in the conversation. | The only correct way to run anything interactive or long-lived. `!bench start`, `!gcloud auth login`. See [`reference_bench_start_dev_server`] — `bench start` dies under Claude's background tools, so it must run through `!` or your own terminal. |
| `#text` | Append a line to CLAUDE.md / memory without spending a turn. | Use for durable rules. Not for one-off context. |

**Rule of thumb:** if you already know which file is wrong, `@` it. Describing it in prose costs
two to four tool calls of searching.

---

## 2. Keyboard shortcuts

| Key | Meaning |
| --- | --- |
| `Shift+Tab` | Cycle permission mode: **manual → acceptEdits → plan**. The single biggest speed lever. `acceptEdits` removes the approve-every-write prompt loop. `plan` forces design-before-code. |
| `Esc` | Interrupt the current turn. The model stops where it is; context is kept. |
| `Esc` `Esc` | Rewind to an earlier message and re-steer from there. Use instead of arguing forward. |
| `Ctrl+O` | Toggle verbose tool output on/off. |
| `Ctrl+T` | Show the todo list. |
| `Ctrl+B` | Send the running Bash command to the background. |
| `Ctrl+L` | Clear the **terminal screen only**. Context is untouched. |
| `Ctrl+R` | ⚠️ Reverse-search prompt history (some builds: expand last output). |
| `Ctrl+]` | Reopen the most recent Artifact from this session. |
| `Ctrl+C` ×2 | Exit. `Ctrl+D` also exits. |
| `Option+Enter` | Newline without submitting. Run `/terminal-setup` once if unbound. Fallback: `\` then `Enter`. |
| `↑` / `↓` | Prompt history. |

**`Ctrl+L` vs `/clear`.** `Ctrl+L` wipes the screen. `/clear` wipes the conversation. They look
identical in the terminal and are not. Losing a session to the wrong one is a common mistake.

No `~/.claude/keybindings.json` exists on this machine yet, so all bindings are at their defaults.
The `keybindings-help` skill writes that file if you want to rebind anything.

---

## 3. Built-in slash commands

### Context and cost
| Command | Meaning |
| --- | --- |
| `/context` | Show what is consuming the context window, by category. Run this before blaming the model for forgetting something. |
| `/compact` | Summarise the conversation and keep working. Use at ~70% full, not at 100%. |
| `/clear` | Discard the conversation entirely. Irreversible. |
| `/cost`, `/usage` | Spend and quota for this session. |

### Session
| Command | Meaning |
| --- | --- |
| `/resume` | Reopen a past session by ID, or pick from a list. |
| `/rewind` | Roll the conversation (and optionally the file changes) back to an earlier point. |
| `/export` | Write the transcript out to a file. Useful when a session becomes a prompt-archive entry. |
| `/status` | Model, auth, working dirs, connected servers. |
| `/doctor` | Diagnose broken config. First stop when hooks, MCP or skills misbehave. |
| `/tasks` | Background tasks and live Artifact watches started by this session. |
| `/artifacts` | List published Artifacts. `o` opens, `c` copies the link. |

### Configuration
| Command | Meaning |
| --- | --- |
| `/config` | Interactive settings: theme, model, effort, workflow size. |
| `/model` | Switch model for this session. |
| `/fast` | Fast mode. Same Opus model, faster output. It does **not** downgrade to a smaller model. |
| `/permissions` | View and edit the allow/deny tool rules. |
| `/hooks` | View and edit lifecycle hooks. This is the only mechanism that can enforce "always do X before Y" — see §5. |
| `/agents` | Define and inspect subagents. |
| `/mcp` | MCP server status. The `ide` server failed to connect on 2026-09-02 (`WebSocket is not open`); restart the IDE extension to restore it. |
| `/memory` | Edit CLAUDE.md files. |
| `/init` | Generate a CLAUDE.md for a repo that has none. |

---

## 4. Skills loaded on this machine

Skills are packaged instruction sets. Invoking one loads its procedure in place of the model's
default approach.

### Review and quality
| Skill | Meaning |
| --- | --- |
| `/code-review [low\|medium\|high\|xhigh\|max]` | Review the current diff, a PR number, a branch or a path. Low/medium give few high-confidence findings; high and above widen coverage and may include uncertain ones. `--fix` applies findings to the working tree. `--comment` posts them as inline PR comments. |
| `/simplify` | Reuse, simplification and efficiency pass, then applies the fixes. **Quality only — it does not look for bugs.** Use `/code-review` for correctness. |
| `/security-review` | Security review of the pending changes on the branch. Relevant on every branch that touches PHI. |

### Workflow
| Skill | Meaning |
| --- | --- |
| `/fewer-permission-prompts` | Scans past transcripts for repeated read-only Bash and MCP calls, then writes a prioritised allowlist into `.claude/settings.json`. **Highest-ROI item for this project**, because the standing rules require approval before every write. Run once per repo. |
| `/update-config` | Edit `settings.json`: permissions, env vars, hooks. Required for any "from now on, whenever X happens, do Y" automation. |
| `/run` | Launch this project's app and confirm a change works in the real app, not only in tests. |
| `/loop <interval> <prompt>` | Run a prompt or command on a repeating interval. Omit the interval to let the model pace itself. |
| `/schedule` | Cron-scheduled cloud agents, or a one-time future run. |
| `/init` | Bootstrap a `CLAUDE.md`. |

### Reference
| Skill | Meaning |
| --- | --- |
| `/claude-api` | Model IDs, pricing, params, streaming, tool use, caching. Loaded automatically before touching Anthropic API code. Stops the model answering LLM questions from stale memory. |
| `/artifact-design`, `/artifact-diagramming`, `/artifact-capabilities` | Design, diagram and runtime-capability guidance for published Artifact pages. |
| `/dataviz` | Read before writing any chart, in any library or medium. |
| `/design` | Multi-artboard visual design canvas for mockups and screen flows. |

### Vercel — for `/Users/apple/Healthcare_next_app`
| Skill | Meaning |
| --- | --- |
| `/vercel:env` | List, pull, add, remove, diff environment variables. Pairs with `docs/platform/PRODUCTION_ENV.md`. |
| `/vercel:deploy [prod]` | Preview deploy by default; `prod` promotes to production. |
| `/vercel:status` | Recent deployments, linked project, env overview. |
| `/vercel:nextjs` | App Router, Server Components, Server Actions, caching, middleware. |
| `/vercel:shadcn` | shadcn/ui CLI, composition, theming. |
| `/vercel:ai-sdk`, `/vercel:ai-gateway` | AI SDK and multi-provider gateway guidance. |

**Note:** the Vercel CLI on this machine is **58.4.4**; current is **59.11.2**.
Upgrade with `pnpm add -g vercel@latest`.

---

## 5. Preferences vs hooks — an important distinction

A preference stored in memory is **advice to the model**. It can be missed under load or in a
long session.

A hook in `settings.json` is **executed by the harness**. It cannot be missed.

So anything phrased as "every time", "before X", "never let me forget Y" belongs in a hook, not
in a memory note. Examples that apply to this project:

- Block a commit when `apps/remedisys_healthcare_ai/prompts/<date>-<slug>.md` is missing.
- Warn on any write inside `apps/frappe`, `apps/erpnext`, `apps/healthcare` or another vendored
  app, per the customisation-isolation rule in `RULES.md`.
- Refuse a tool call whose environment names the production site.

Use `/update-config` or `/hooks` to add these.

---

## 6. CLI flags

Verified against `claude --help` on 2026-09-02.

```bash
claude -c                          # continue the most recent conversation in this directory
claude -r                          # resume picker (or: -r <session-id>)
claude --fork-session -r <id>      # resume into a NEW session id, leaving the original intact
claude --effort max                # low | medium | high | xhigh | max
claude --permission-mode plan      # manual | acceptEdits | plan | auto | dontAsk | bypassPermissions
claude --model opus                # or sonnet, fable, or a full model id
claude --add-dir ../other-repo     # grant tool access to a second directory
claude -n "encounter-billing"      # name the session; shows in the prompt box and /resume picker
```

Non-interactive and scripted:

```bash
claude -p "..." --output-format json          # single JSON result, for pipes and CI
claude -p "..." --output-format stream-json   # realtime streaming
claude -p "..." --json-schema '{...}'         # enforce a structured output shape
claude -p "..." --max-budget-usd 2            # hard spend cap (print mode only)
claude --bg "..."                             # detached; then: claude agents | attach | logs | stop
```

Debugging a broken setup:

```bash
claude --safe-mode        # disables CLAUDE.md, skills, plugins, hooks, MCP, custom commands
claude --bare             # minimal: no hooks, LSP, auto-memory, CLAUDE.md discovery
claude -d "api,hooks"     # debug with category filter
claude --debug-file /tmp/cc.log
```

Restricting what a session can do:

```bash
claude --restricted                       # removes Bash and other code-running tools, confines file tools
claude --allowed-tools "Read" "Grep"
claude --disallowed-tools "Bash(git push*)"
claude --strict-mcp-config --mcp-config ./mcp.json
```

`--restricted` is the right mode for letting a session read this bench without any chance of it
writing, committing or running anything.

---

## 7. Verifying against Frappe — which door to use

Added 2026-09-10, out of [`architecture/FAC_EVALUATION.md`](architecture/FAC_EVALUATION.md).
That evaluation measured the three ways this bench can be read, and the ranking is not what
the habit suggests.

| Door | Cost, measured 2026-09-10 | Use it for |
| --- | --- | --- |
| `Read` / `Grep` on source | instant | code, hooks, permissions, method bodies |
| `scripts/dev/frappe_probe.sh` (HTTP + cached JWT) | **~0.2 s per call** | "did it save?", row values, live schema |
| `bench --site marley.local execute` | **~2.8 s per call** | patches, jobs, anything needing app context |

**WHY the probe script exists.** Minting a JWT costs about 1.5 s and every hand-written curl
was a new permission prompt. `~/.claude/settings.json` had grown 154 allow rules, many of them
single-use `bench ... execute frappe.db.sql --kwargs '{"query": "SELECT ..."}'` strings. The
script caches the token for 40 minutes and is allow-listed once as a prefix, so neither cost
repeats.

**HOW.**

```bash
scripts/dev/frappe_probe.sh count  "Patient Encounter"
scripts/dev/frappe_probe.sh child  "Drug Prescription" "Patient Encounter" HLC-ENC-2026-00684 \
                                   '["drug_name","dosage","period"]'
scripts/dev/frappe_probe.sh meta   "Patient Encounter" "custom|drug"
scripts/dev/frappe_probe.sh custom "Patient Encounter"
scripts/dev/frappe_probe.sh call   remedisys_healthcare_ai.api.v1.encounters.api.get_encounter \
                                   '{"encounter":"HLC-ENC-2026-00684"}'
```

Credentials come from the environment or from a gitignored `scripts/dev/.probe.env`. The script
refuses any host that is not `localhost`, `127.0.0.1`, `*.localhost` or `*.local` over plain
http, so it cannot be pointed at production even by accident.

**The schema trap this closes.** The DocType JSON on disk is **incomplete**. Patient Encounter
has 39 fields in `apps/healthcare/.../patient_encounter.json`, and the live site adds 3 Custom
Fields (`custom_encounter_done_by`, `custom_encounter_end`, `custom_patient_email`) plus 1
Property Setter on top. Code written from the file alone is written against a schema the site
does not have. Use `meta` (which reads `frappe.get_meta` through
`frappe.desk.form.load.getdoctype`, so customisations are merged) rather than reading the file,
whenever the answer matters. `meta` needs a desk-capable user; `EB_` roles are `desk_access=0`
by design, so run it as Administrator.

**WHEN a Frappe read is the wrong tool entirely.** For "the database has it but the screen is
empty", the bug is usually **above** Frappe: a `set_response` / `set_list_response` envelope
mismatch, the wrong fetcher in the frontend, a BFF parameter mapping, or React state. Reading
Frappe harder cannot see any of those. Start instead with:

```bash
# in Healthcare_next_app/.env.local
FRAPPE_DEBUG=true
```

Every upstream call then prints to the dev-server terminal with its dotted method name, body,
status and duration, and each response carries an `x-frappe-calls` header visible in the browser
Network tab. It is hard-disabled whenever `NODE_ENV === "production"`, and PHI is redacted both
by field name and by string length, so it is safe to leave on locally
(`src/lib/api/frappe-debug.ts`).

**WHEN not to use any of this.** Never against production. All dev and test work stays on local
or staging (standing rule, and the script enforces it).

---

## 8. Custom commands — the current gap

`~/.claude/commands/` is **empty**. Every repeated instruction in this project is being retyped
each session instead of being encoded once.

A file at `~/.claude/commands/<name>.md` (global) or `<repo>/.claude/commands/<name>.md`
(project-scoped) becomes `/<name>`. Three that map directly to standing rules:

| Proposed | What it would do |
| --- | --- |
| `/prompt-archive <slug>` | Create `apps/remedisys_healthcare_ai/prompts/<today>-<slug>.md` with the §9 provenance header and an "The ask" section, before substantive work starts. |
| `/adr <n> <title>` | ADR skeleton in `docs/adr/`, byline pre-filled as `Sarvesh-SocialAngel (AI-assisted)`, context/options/decision/consequences sections. |
| `/four-options <decision>` | Force the four-distinct-approaches comparison, with depth scaled to how reversible the decision is. |

---

## 9. Open question

The stored preference `feedback_simple_english` requires simple English everywhere — chat, docs,
ADRs, commits and code comments. On 2026-09-02 the request was made to drop simple English in
favour of denser, more critical prose.

**The two audiences are different.** Terminal replies are read by one person. Docs and ADRs are
read by the clinical and engineering team, and the original rule exists for their benefit.

The scope of the override is **not yet decided**:

1. Chat only — docs, ADRs and commits stay simple English.
2. Chat plus commits and PR text.
3. Everything, including team-facing docs.

This document is written to option 1: dense here because it is a personal tool reference, while
`docs/flows/`, `docs/adr/` and similar stay as they are. Update this section once the scope is fixed.

---

## Related

- `CLAUDE.md` §9 (one fact, one owner), §10 (WHAT / WHY / HOW / WHEN)
- `RULES.md` — customisation isolation, vendored apps that must never be edited
- `docs/STATUS.md` — the only document that states project status
- `docs/platform/PRODUCTION_ENV.md` — the env vars `/vercel:env` manages

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Added §7 "Verifying against Frappe": the three doors with measured costs, the frappe_probe.sh helper, the incomplete-DocType-JSON trap, and FRAPPE_DEBUG for above-Frappe bugs. Renumbered old §7 and §8 |
| 1.0 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
