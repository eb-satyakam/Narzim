# Immunization Concurrent Rounds — Mechanism

**Doc status:** living · **Created:** 2026-09-15 by Ashutosh (AI-assisted) · **Updated:** 2026-09-15 by Ashutosh (AI-assisted) · **Version:** 1.4

## 1. Scope

How a patient can now have more than one open (`Active`, incomplete) `Patient
Vaccine` round of the same template at once, how the system decides which
round a later administered dose belongs to when that happens, and how the
chart itself displays every open round rather than collapsing them. See
ADR-070 for the decision and rejected alternatives; this document is the
mechanism, layer by layer, including §5, which records the chart-display gap
this change originally left open and how it was closed the same day.

## 2. Why this needed to change

Reported live: jaani (patient) had an open, incomplete Immunization course
under Dr Hathi. Assigning the same vaccine again — the doctor placing a
genuine second order, not an accidental duplicate click — needs to leave a
trace distinct from the first order, so that a dose recorded weeks later can
say unambiguously which order it fulfils.

Three separate places assumed the opposite — at most one `Active` round per
`(patient, immunization_template)` — and each would have broken or rejected
the change silently:

1. **`assign_vaccine` / `ensure_patient_vaccine`** (`api/v1/immunizations/api.py`)
   reused the existing open round and only re-billed it. A second real order
   collapsed into the first, with nothing left to tell them apart.
2. **`_schedule_payload`**, which backs both the chart
   (`get_immunization_schedule`) and the "Add immunization" picker
   (`list_pending_vaccines`), builds a dict keyed by `immunization_template`.
   Two `Active` rows for one template would silently collapse to whichever
   row the database returned last building that dict — the other round's
   doses vanish from the UI with no error.
3. **`PatientVaccine.validate()`** (the doctype's own controller) —
   deliberately, not by accident — rejected inserting a second `Active` row
   for the same patient+template outright, with `frappe.DuplicateEntryError`.
   This was the deepest of the three and the last one found: everything built
   against (1) worked in isolation until it was actually run end to end,
   because insert() itself refused the second row before the new API logic
   ever mattered.

Also found and closed here: `create_immunization_record`'s worklist path
discarded the *specific* round a `Nursing Task` was created against
(`task_document_name`) and re-resolved "the" `Active` round for the template
from scratch on every dose. Correct by accident while at most one such round
could exist; silently wrong the moment a second one does.

## 3. The shape of the fix

1. Remove the doctype-level rule (3 above) — the API layer becomes the sole,
   deliberate decision-maker for when a second round opens.
2. `assign_vaccine` / `ensure_patient_vaccine`: on an existing, still-open
   round, stop reusing it — fall through and create a new one instead.
3. Dose recording (`ensure_patient_vaccine` with `always_bill=False`,
   i.e. resolving rather than ordering) refuses to guess once more than one
   open round exists — it throws, naming how many rounds were found, unless
   the caller pins the exact round via a new `patient_vaccine` parameter.
4. The one caller that already knows its round unambiguously — a `Nursing
   Task`, which is always created against one specific `Patient Vaccine`,
   never a bare template — is wired to actually use that instead of
   re-resolving it.
5. The frontend gains a narrow disambiguation step at the point of actual
   conflict, without touching the chart (2 above is **not** fixed here — see
   §5).

## 4. Layer by layer

### 4.1 The doctype guard — removed

```python
# patient_vaccine.py, before:
class PatientVaccine(Document):
    def validate(self) -> None:
        if self.status == "Active":
            existing = frappe.get_all("Patient Vaccine", filters={
                "patient": self.patient, "immunization_template": self.immunization_template,
                "status": "Active", "name": ["!=", self.name],
            }, limit=1)
            if existing:
                frappe.throw(_("{0} is already assigned to this patient ({1}).")
                    .format(self.immunization_template, existing[0].name), frappe.DuplicateEntryError)
```

Removed entirely. `apply_program` (bulk program application), the one other
direct-insert caller, already checks `frappe.db.exists(..., status="Active")`
before inserting and never reaches this guard either way — nothing else in
the codebase relied on it firing. See ADR-070 §Alternatives for why this was
chosen over a flag-gated bypass that would have kept the check for any
*future*, unreviewed caller.

### 4.2 `assign_vaccine` — still-open reassignment opens a new round

```python
existing = frappe.get_all(_PATIENT_VACCINE_DT, filters={
    "patient": patient, "immunization_template": immunization_template, "status": "Active",
}, pluck="name", limit=1)

if existing and _course_complete(immunization_template, existing[0]):
    if _is_repeatable_template(immunization_template):
        # finished, repeatable -> stop it, fall through to open a fresh round (unchanged)
        ...
    else:
        # finished, non-repeatable, never explicitly stopped -> reuse/re-bill (unchanged, pre-existing edge case)
        ...
        return
# else: no existing round, OR one exists but is still open -> fall through
# and create a new Active Patient Vaccine below, leaving any open existing
# round untouched.
```

The branch on `_course_complete` is now checked **before** deciding to reuse
at all — previously the only branch was "repeatable and complete" vs.
"everything else reuses." Now "still open" is its own outcome: create a new
row, touch nothing about the existing one.

### 4.3 `ensure_patient_vaccine` — the ambiguity guard and the `patient_vaccine` pin

```python
def ensure_patient_vaccine(patient, template, ..., always_bill=False, patient_vaccine=None):
    if patient_vaccine:
        # caller already knows exactly which round — validate it belongs to
        # this patient+template, optionally bill, return it as-is.
        ...
        return patient_vaccine

    existing = frappe.get_all(_PATIENT_VACCINE_DT, filters={...})  # no limit — need the real count

    if not always_bill and len(existing) > 1:
        frappe.throw(_("Patient has {0} open rounds of {1} — specify which one "
                        "this dose belongs to.").format(len(existing), template))

    if existing and always_bill and _course_complete(...):
        ...  # same finished-round handling as assign_vaccine, mirrored here

    if existing:
        if always_bill:
            pass  # still open, ordering again -> fall through, open a new round
        else:
            return existing[0]["name"]  # resolving a dose, exactly one open round -> unambiguous
    # create a new Active Patient Vaccine
```

`always_bill=True` (placing an order — the encounter order flow, or
`assign_vaccine` calling through) never needs the ambiguity guard: it always
either reuses a finished round or opens a new one, so there is nothing to
pick among. `always_bill=False` (resolving a dose already ordered) is where
ambiguity is real and must be refused rather than guessed.

### 4.4 The worklist — using the round a task already names

```python
def _patient_vaccine_from_nursing_task(task: str) -> str | None:
    row = frappe.db.get_value("Nursing Task", task, ["task_doctype", "task_document_name"], as_dict=True)
    if not row or row.get("task_doctype") != _PATIENT_VACCINE_DT:
        return None
    return _clean(row.get("task_document_name"))
```

`create_immunization_record`:

```python
if nursing_task and not encounter:
    encounter = _encounter_from_nursing_task(nursing_task)          # unchanged
if nursing_task and not patient_vaccine:
    patient_vaccine = _patient_vaccine_from_nursing_task(nursing_task)  # new

patient_vaccine = ensure_patient_vaccine(patient, immunization_template,
    ..., patient_vaccine=patient_vaccine)
```

A task's own `task_document_name` is unambiguous by construction — a task is
never created against a bare template, only against one specific round (see
`create_vaccine_administration_task` / `encounters/api.py`'s order flow,
which always passes a resolved `pv`). Reading it directly means two nurses
working two tasks for two concurrent rounds of the same vaccine each record
correctly, with no possibility of the ambiguity guard ever firing on this
path — verified live (§6).

### 4.5 Frontend — the disambiguation picker

`EB_Healthcare_Frontend`'s "Add immunization" dialog
(`immunizations-tab.tsx`) fetches the patient's Active assignments
(`GET /api/immunizations/assigned` → `list_assigned_vaccines`, unchanged
backend endpoint, new frontend consumer) and filters to whichever template is
selected. When more than one match exists, a required round picker appears
(`fRound`/`roundPlaceholder`/`roundOption`/`roundHelp` — bilingual, en/es);
the chosen round's name is sent as `patient_vaccine` in the create-immunization
call. The worklist path (`nursingTask` set) never shows this — it's already
unambiguous per §4.4.

**Fixed same day (2026-09-15), found via the same live screenshot check as
§5**: `list_assigned_vaccines` returns rounds newest-first with no time
component on `assigned_on` (a Date field), so the original option label
(`"Assigned {date}"` alone) rendered byte-identical text for two rounds
opened the same day — Ananya's two Influenza rounds, 3 minutes apart, both
showed "Assigned Sep 15, 2026" with nothing to pick between. Fixed by
numbering each option chronologically (`matchingRounds.length - idx` against
the newest-first array, so the oldest reads as "Round 1"): the label is now
`"Round {index} of {count} — Assigned {date}"`, unique regardless of date
granularity. This is a label-text fix inside a functional control, not a
layout/design change — the picker itself, and the rest of the dialog, are
unchanged.

**Then made unnecessary for almost every case, same day.** Two further
requests:

1. *A dot click already knows its round.* Every dot on the Schedule
   Card/Timeline belongs to one specific `ScheduleVaccine` row, which (per §5
   below) is already scoped to a specific round whenever 2+ are open.
   `StatusCell`/`TimelineDot`'s `onPick` and `GridView`/`TimelineView`'s
   `onPickVaccine` now carry that row's `patient_vaccine` through to
   `openAddForTemplate`, which sets it as `EditState.patientVaccine`.
   `EditorDialog` seeds `selectedRound` from it at mount and computes
   `needsRoundPick` as `!selectedRound && matchingRounds.length > 1` — a
   dot-click open with a known round never satisfies that, so the field never
   renders. No picker, no extra step, for any dot-click entry point.
2. *The generic "Add immunization" header button had no click context to
   auto-resolve from.* Asked directly rather than guessing: keep a fallback
   picker there, silently default to a round (rejected — this is exactly the
   silent-misattribution risk ADR-070's `ensure_patient_vaccine` guard refuses
   server-side), or list every round explicitly. Chosen: list every round.
   `list_pending_vaccines`'s same-day dedup (§6/§7 below) is reverted — each
   `schedule` entry's open dose becomes its own pending row again, carrying
   `patient_vaccine`/`round_index`/`round_count`. The dialog's "VACCINE"
   dropdown (`pending.map(...)`) now shows one option per (dose, round) —
   e.g. two separate "Influenza — 6 meses (anual) (Overdue) — Round 1 of 2" /
   "...Round 2 of 2" entries — and `pendingKey` includes `patientVaccine` so
   they don't collide. `onPick` (the dropdown's change handler) now sets
   `selectedRound` directly from the picked option's own `patientVaccine`, the
   same way a dot click does. The "Which assignment?" field becomes
   unreachable in normal use either way now — kept only as a fallback so a
   dose is never silently recorded against a guessed round if some future
   change breaks this assumption.

**Verified live that the dot-click path already works end to end**, from the
user's own testing, not just code review: `HLC-IMM-2026-00097` was recorded
against Ananya's Influenza round 1 (`HLC-PV-2026-00124`) and
`HLC-IMM-2026-00098` against her VPH round 2 (`HLC-PV-2026-00126`), both at
20:42 the same day, each correctly tagged to its own round. Real clinical
data, left untouched.

## 5. The chart — fixed same day, after being found live

**Originally shipped as a known gap** (2026-09-15, ADR-070 v1.0): `_schedule_payload`'s
`assigned_map` (`{template: patient_vaccine_name}`, built via a plain dict
comprehension over the patient's `Active` rows) collapsed two open rounds of
the same template down to whichever the database happened to return last —
the chart (`get_immunization_schedule`) and the pending-dose picker
(`list_pending_vaccines`) only ever showed one round.

**Found live the same day**, on request ("for this patient check how many
vaccine we have and how many of them we are showing"): patient Ananya Kapoor
(MRN-2026-0001429) had 6 Active `Patient Vaccine` rows — 2 concurrent rounds
each of Influenza, Td, and VPH — but the chart showed only 3 vaccine cards,
one per template, with no hint a second round of any of them existed.
Confirmed directly against the live record before any fix, via
`_schedule_payload(patient)`: `active_patient_vaccine_count: 6`,
`chart_shown_template_count: 3`.

**Fixed the same day.** `_schedule_payload` now keys on
`rounds_map: {template: [round_name, ...]}` (ordered oldest-first) instead of
one name per template, and the per-template loop iterates every round,
emitting one `schedule` entry per round rather than one per template. Each
entry carries `patient_vaccine` (that round's name), `round_index`, and
`round_count`; all three are `None`/absent for the ordinary 0- or 1-round
case, so nothing changes for the overwhelming majority of patients who never
have a concurrent round.

Dose-matching for a round is scoped to `Immunization` records tagged with
that round's `patient_vaccine` field whenever **2 or more** rounds are open —
previously this round-scoping only ever applied to repeatable (Event Based)
templates, and only when there happened to be exactly one round. A single
round of any template still matches exactly as before (alias-based for
non-repeatable templates, round-scoped for repeatable ones) — this is
additive for the multi-round case, not a behavior change for the common one.

`list_pending_vaccines` reads off the same payload. It briefly deduplicated
by `(template, dose_label)` this same day, so a patient with two open rounds
of one vaccine saw one "Add immunization" option per open dose rather than
two identical-looking copies — but that traded the duplicate-looking-options
problem for a different one (needing a second "which round?" step
afterward), and was reverted a few hours later once asked directly: see §4.5
for the final shape, where each round's open dose is its own row again,
labeled distinctly, and picking one resolves the round without a second
step.

**Frontend** (`immunizations-tab.tsx`): `ScheduleVaccine` gained the three
optional round fields, but the row markup is unchanged — on explicit
instruction, the existing design was kept exactly as it was; the fix is
scoped to making every round appear, not to how a round looks. The only
functional change is `GridView` and `TimelineView` keying each row on
`` `${template}::${patient_vaccine ?? ""}` `` instead of `template` alone —
without it, two rows sharing a template collide on React key and one
silently fails to render. A "Round N of M" badge was tried and then removed
on request; two concurrent rounds of the same vaccine now render as two
plain rows, distinguished only by their own doses/status, same as any other
pair of rows on the chart.

**Verified live**, same patient, via `bench execute`: `_schedule_payload` now
returns all 6 entries (2 each for Influenza, Td, VPH, each with its own dose
set and `round_index`/`round_count`), and `list_pending_vaccines` returns 4
deduplicated rows instead of 6. Both temporary read-only diagnostic scripts
were deleted immediately after use; nothing was written to the patient's real
`Patient Vaccine`/`Immunization` records — this fix only changes how existing
rows are read and grouped for display.

No new automated test was added for this specific display fix in this pass —
`TestConcurrentOpenRounds` (§6) already covers the backend round-creation and
pinning logic being displayed here. A chart-shape assertion ("N schedule
entries for N Active rounds") would be a reasonable follow-up addition.

## 6. Testing

- `tests/immunizations/test_vaccine_billing.py::TestConcurrentOpenRounds` (4
  tests): `assign_vaccine` opens a second round while the first is open; a
  dose with no pin and two open rounds throws; an explicit pin tags the
  correct round; a pin belonging to a different template is rejected.
- `tests/immunizations/test_vaccine_billing.py::test_always_bill_reorders_a_second_batch`
  — updated: now asserts `pv1 != pv2` (previously asserted reuse).
- `tests/immunizations/test_vaccine_billing.py::test_unassign_cancels_pending_mrs_but_not_invoiced`
  — updated: the "two MRs on one round" fixture is now built by calling
  `_create_vaccine_assignment_billables` directly against a known round
  (its actual subject — `unassign_vaccine`'s MR-cancellation behavior — is
  independent of which round-opening policy is in effect).
- `tests/immunizations/test_vaccine_nurse_handoff.py::test_assign_nurse_creates_order_and_task_not_immunization`
  — updated: the "re-sign is idempotent" scenario is a synthetic direct call
  to an internal helper (the real encounter-sign endpoint has a hard
  `docstatus != 0` guard and can never be invoked twice for one encounter);
  now asserts the correct new outcome — a second order opens a second round
  with its own task, and the first order's own task is still never
  duplicated.
- `tests/immunizations/test_vaccine_nurse_handoff.py::test_worklist_task_resolves_its_own_round_even_with_a_second_open_round`
  (new) — two tasks, two rounds, each dose lands on its own task's round.
- All five new/changed tests currently **skip** on `remedisis.localhost`
  (this site's generic seed fixtures — `MRN-2026-00001`,
  `Lourdes Ritto Mijangos` — don't exist here; a pre-existing limitation of
  this test file, not introduced by this change).
- **What actually exercised this change end to end**: a live, manual
  verification against a real patient/practitioner/template on
  `remedisis.localhost`, run via `bench execute` (not `bench console` — see
  §7), confirming all five behaviors above against real data, with every
  record it created (Patient Vaccines, Medication Requests, Service
  Requests, Immunizations, Nursing Tasks) explicitly deleted afterward and
  confirmed removed rather than relying on a transaction rollback.

## 7. A `bench console` / `bench execute` gotcha, recorded so it isn't rediscovered

The first two attempts at the live verification above were run via `bench
console` (interactive IPython, piped a script via stdin) and appeared to do
nothing — IPython's line-by-line paste parsing mis-detected where an indented
function body or a `try:`/`finally:` block ended, silently executing most
lines as top-level statements against undefined names (`NameError` on almost
every line). This is the same class of issue already recorded in this
session's memory as "IPython mangles multi-line/backticks/def-scope."

The third attempt used `frappe.db.savepoint(...)` /
`frappe.db.rollback(save_point=...)` around the verification, run via `bench
console` again — this one *did* execute, but the final rollback failed with
`SAVEPOINT ... does not exist`, because `assign_vaccine` calls
`frappe.db.commit()` internally (it owns its own transaction boundary,
per its docstring), and a `COMMIT` releases every earlier `SAVEPOINT` in
MariaDB. Everything written before that commit — including by functions that
never call `.commit()` themselves — became permanently persisted, not rolled
back. Nine real records were left in the database against a real patient
this way; all were traced and deleted (see WORK_LOG 2026-09-15).

**The fix that actually worked**: `bench --site <site> execute
<dotted.path.to.function>` — a plain Python function call inside the site's
context, no REPL line-parsing involved at all — combined with **not**
relying on rollback: the verification script explicitly deletes every record
it created, in dependency order, inside the same function, and reports what
it deleted. For any future manual verification that writes real data on this
site: use `bench execute` for anything beyond trivial one-liners, and delete
what you create explicitly rather than trusting a savepoint to survive a
function that might commit internally.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-15 | Ashutosh (AI-assisted) | §4.5/§5: the round-picker is no longer the normal path — dot clicks auto-resolve their round, and `list_pending_vaccines`'s dedup was reverted so the generic "Add immunization" dropdown lists every open round as its own pickable entry; the picker is now an unreachable-in-practice fallback |
| 1.3 | 2026-09-15 | Ashutosh (AI-assisted) | §4.5: fixed the "Add immunization" round-picker's option labels — same-day rounds previously showed byte-identical "Assigned {date}" text; now numbered "Round N of M" |
| 1.2 | 2026-09-15 | Ashutosh (AI-assisted) | §5 corrected: the "Round N of M" badge described at 1.1 was removed on request — kept the existing row design unchanged, fixed only the React key collision |
| 1.1 | 2026-09-15 | Ashutosh (AI-assisted) | §5 rewritten: the chart-display gap (named unfixed at 1.0) is fixed — `_schedule_payload` now emits one entry per concurrent Active round; verified live against Ananya Kapoor (6 rounds, was showing 3) |
| 1.0 | 2026-09-15 | Ashutosh (AI-assisted) | Initial version |
