# Research — Appointment Notifications to Patients

**Doc status:** record · **Created:** 2026-08-26 by Ashutosh (AI-assisted) · **Updated:** 2026-08-26 by Ashutosh (AI-assisted) · **Version:** 1.1

**This is now a `record` — a dated snapshot of the investigation, deliberately frozen.** It is not
maintained, and per `../CLAUDE.md` §9 it reading out-of-date later is correct behaviour, not a defect.

The decisions it fed into are owned elsewhere:

- **[`adr/adr-046-notification-event-keys-and-channel-roles.md`](adr/adr-046-notification-event-keys-and-channel-roles.md)** —
  event keys + parameters, and the job of each delivery channel.
- **[`PUSH_NOTIFICATIONS.md`](PUSH_NOTIFICATIONS.md)** — the mechanism as built.

**Outcome summary (2026-08-26):** approach **B** was taken (one doctype hook on `Patient Appointment`,
calling `notify()`), with the localisation problem in §4.3 resolved by event keys rather than by core's
both-languages-in-one-string trick. All existing channels were **kept** — the decision was three
channels with distinct jobs, not fewer channels. §7's open questions were answered as: cancellation
reason withheld from patients, config in code rather than a doctype, and events enabled one at a time.

**The ask.** When staff book, cancel or reschedule an appointment, the patient should be notified
automatically — the way portal-chat messages already are, with the relevant date/time details.

---

## 1. The one-paragraph summary

Most of the machinery exists. The `notify()` chokepoint already delivers a row, a live event and a
push in one call, so the *delivery* problem is solved. What is missing is (a) something that decides
*when* an appointment event has happened, and (b) the wording. Two independent mechanisms already fire
on appointment events — core Frappe `Notification` rows (**enabled, sending email today**) and a
dormant WhatsApp config — so the real question is not "how do we build this" but **"which of three
existing mechanisms should own it, and how do the others not double-fire."**

There is also a **latent localisation defect in the chat notifications already shipped** (§4.3) that
becomes much more visible once a date is in the message.

---

## 2. What already exists

### 2.1 The delivery layer — done, reusable

`services/notifications.py::notify()` writes the `Notification Log` row, emits the live SSE event and
enqueues FCM push. Anything that calls it inherits the preference check, the dedupe, `type="Alert"`
email safety, and the never-raises guarantee. See [`PUSH_NOTIFICATIONS.md`](PUSH_NOTIFICATIONS.md).

`Patient.user_id` → the portal login is already the resolution used by
`portal_chat.py::_notify_patient_of_staff_message`.

### 2.2 Core Frappe `Notification` — **already live, already emailing patients**

This was the surprise of the research. Four rows exist and are **enabled**:

| Name | Event | Channel | Notes |
|---|---|---|---|
`Remedisys Appointment Created (Email)` | New | Email | `condition: doc.status != "Cancelled"` |
`Remedisys Appointment Cancelled (Email)` | Value Change on `status` | Email | `condition: doc.status == "Cancelled"` |
`Remedisys Appointment Reminder 1 Day (Email)` | Days Before | Email | — |
`Remedisys Appointment Reminder 1 Hour (Email)` | Minutes Before | Email | — |

Three things worth noticing:

- **Recipient is `custom_patient_email`**, a Data field on Patient Appointment. Verified: **66/66
  appointments have it populated**, and in every sample it is *identical to* `Patient.user_id` and is a
  real `User`. So it can address a portal account.
- **The subjects are already bilingual by concatenation** — `"Cita agendada / Appointment booked —
  {{ doc.appointment_date }}"`. Crude, but it sidesteps the whole per-recipient-language problem. Worth
  respecting as a precedent rather than dismissing.
- **`send_system_notification = 0`.** Flipping that flag is the cheapest possible route to a bell
  entry — see approach D and its limits.
- **Reminders already exist.** `notify()` has no scheduling of any kind; core's `Days Before` /
  `Minutes Before` events do. If in-app reminders are ever wanted, core is the only one of the three
  that can already do it.

### 2.3 The WhatsApp config machinery — dormant

A wildcard `doc_events` hook runs `integrations/whatsapp/notifications.py::process_notifications` on
every doctype's insert/save/submit, matching against `Remedisys WhatsApp Notification` rows. Two
appointment rows exist and are **both disabled**:

| Title | Event | Condition |
|---|---|---|
`Appointment Confirmation` | After Insert | — |
`Appointment Cancelled` | After Save | `doc.status == 'Cancelled'` |

> **A latent bug in that second config, for whenever it is enabled.** The condition is
> `doc.status == 'Cancelled'` — a *state* test, not a *transition* test. `after_save` fires on every
> subsequent save of an already-cancelled appointment, so the patient would be told it was cancelled
> again each time anything else on the record changed. The correct test is `has_value_changed("status")`
> *and* the new value being `Cancelled`. Core's own row gets this right by using `Value Change` +
> `value_changed: status`.

### 2.4 No reschedule notification exists anywhere

Neither mechanism has a reschedule rule. This is the genuinely new one.

---

## 3. How appointments actually change — the write points

**There are roughly ten**, which is the single most important input to the design:

| Path | Function |
|---|---|
Booking (4) | `create_appointment` · `book_appointment` · `book_appointment_with_payment` · `book_appointment_for_patient` |
Cancel (2) | `cancel_appointment` · `update_status(status="Cancelled")` |
Reschedule (3) | `reschedule_appointment` · `reschedule_appointment_with_payment` · `reassign_appointment` |
Patient self-service (3) | `book_my_appointment` · `cancel_my_appointment` · `reschedule_my_appointment` |

**Reschedule mutates the same document** — `reschedule_appointment` sets `appointment_date` /
`appointment_time` and calls `save()`. It does not create a new appointment. So `on_update` fires, and
distinguishing a reschedule from an unrelated save requires `doc.has_value_changed(...)`.

`status` options are: `Scheduled`, `Open`, `Confirmed`, `Checked In`, `Checked Out`, `Closed`,
`Cancelled`, `No Show`.

**`Appointment Reschedule History`** already records `old_appointment_date`, `old_appointment_time`,
`old_practitioner_name`, and the matching `new_*` fields — everything needed for a *"moved from X to
Y"* message, without recomputing it.

---

## 4. Constraints and gotchas found

### 4.1 `on_update` fires on far more than the three events we care about

Saves happen for check-in, invoice linking, the `department` backfill patch, status transitions to
`Closed`/`No Show`, and the `set_only_once` reconciliation in `_ensure_appointment_*`. A naive hook
would notify a patient every time any of those ran. Any doctype-hook approach **must** gate on
`has_value_changed()` for the specific fields, not merely on "a save happened".

### 4.2 A patient's own action must not notify the patient

Three of the ten write points are the patient acting on their own appointment from the portal. Being
told *"your appointment was cancelled"* immediately after cancelling it yourself is noise. The event
needs to know who caused it — and the mirror case is worth deciding at the same time: **should staff be
notified when a patient self-cancels?** Probably yes, and that is a second, separate notification.

### 4.3 Localisation is already broken, and a date makes it obvious

Two distinct problems, both verified:

1. **The strings shipped for chat are not in the Spanish catalog.** `locale/es.po` contains none of
   `"New message from your clinic"`, `"sent a message"`, `"sent a WhatsApp message"`. They are wrapped
   in `_()`, so they *look* translated and are not.
2. **`_()` resolves at write time, in the sender's session language — not the recipient's.** A staff
   member working in English produces an English notification for a Spanish-speaking patient. Invisible
   today (all 45 users are `language: en`) and wrong for an `es-MX` deployment.

This matters more here than for chat, because an appointment message contains a **date and time**, and
`"Tuesday 2 September at 4:00 PM"` versus `"martes 2 de septiembre a las 16:00"` is not a cosmetic
difference to a parent trying to turn up at the right hour.

Three ways out, in increasing cost: copy core's existing trick and put **both languages in one string**
(ugly, proven, zero infrastructure); **store a message key + parameters** and let the client render in
its own locale (correct, and the client already has `next-intl` catalogues); or **resolve the
recipient's language** at write time and wrap each recipient's render in it.

### 4.4 The site timezone is `Asia/Kolkata`

Worth flagging, because the product's default `ComplianceProfile` is `mx`
(`adr-018-multi-jurisdiction-compliance`). Any *"tomorrow"* / *"in 2 hours"* phrasing, and any
date formatting, resolves against this. Formats are `dd-mm-yyyy` and `HH:mm:ss`.

### 4.5 `appointment_time` is a `timedelta`, not a time

Verified: `datetime.timedelta(seconds=72060)`. Formatting must go through
`appointment_datetime` (a real `datetime`) or convert deliberately. Naively interpolating
`{{ doc.appointment_time }}` yields `20:01:00` at best and `7:21:00` nonsense at worst.

### 4.6 The portal will not show these rows without a change

`api/v1/patient_portal/notifications.py::_PATIENT_VISIBLE_DOCTYPES` is currently
`("Portal Conversation",)` — a deliberate allow-list, so that internal chatter can never surface to a
patient. Appointment rows are invisible until `"Patient Appointment"` is added to it. **Any approach
that writes `Notification Log` rows needs this one-line change**, including approach D.

Link target: the portal has an `/appointments` route.

---

## 5. Four approaches

### A. Call `notify()` from each API endpoint

- **Pros:** completely explicit — each call site states its own event and wording, so there is no
  inference from field diffs. Trivially skips the self-service case, because *that endpoint* simply
  does not call it. No risk of firing on an unrelated save.
- **Cons:** **ten call sites**, and the count only grows. The four booking paths already exist because
  payment variants were bolted on over time; the eleventh will be added by someone who does not know to
  add the notification, and the omission is silent. This is precisely the drift `notify()` was created
  to end — reproducing it one layer up.

### B. One doctype hook on Patient Appointment (`after_insert` + `on_update`)

- **Pros:** **one place, all ten paths**, including any future eleventh — the hook cannot be forgotten.
  `has_value_changed()` distinguishes booked / cancelled / rescheduled precisely. `Appointment
  Reschedule History` supplies the old values for free. Sits naturally beside the existing
  `on_update` hook for `patient_clinical_summary`.
- **Cons:** must be written defensively — `on_update` fires on many unrelated saves (§4.1), so the
  guard is the whole design. Inferring intent from a field diff is slightly less honest than a call
  site declaring it; a status moving to `Cancelled` by some path nobody anticipated still notifies.

### C. Extend the `Remedisys WhatsApp Notification` config machinery to drive in-app too

- **Pros:** config-driven, so clinic staff can change wording and enable/disable per event without a
  deploy. The condition/variable/`message_body` plumbing already exists and is proven. One config row
  could fan out to WhatsApp *and* the bell, keeping channels consistent by construction.
- **Cons:** that doctype is explicitly WhatsApp-shaped — `whatsapp_account`, `template_name`, Meta's
  ordered-variable array. Generalising it means either a misleading name or a migration. It also runs
  on a **wildcard hook across every doctype**, and widening that path's responsibilities raises the
  blast radius of a bug in it. And it inherits §2.3's state-vs-transition bug unless that is fixed.

### D. Flip `send_system_notification = 1` on the core `Notification` rows that already exist

- **Pros:** **by far the cheapest** — a checkbox on rows that are already enabled and already correctly
  targeted at `custom_patient_email`, which is verified to be the portal `User`. Reminders come free
  (§2.2), and `notify()` cannot schedule at all. Wording is editable in the Desk with no deploy, and
  already bilingual.
- **Cons:** the row is created by **core**, not by `notify()` — so **no SSE event and no push.** The
  bell would only update on page load, which is a visible regression against how chat behaves. Also
  bypasses our `is_notifications_enabled` handling and our dedupe, sets no `link` (so the row would not
  deep-link to `/appointments`), and its notification `type` is core's choice — which matters, because
  `type="Alert"` is the *only* type Frappe never emails, and these rows carry a patient name and
  appointment time.

---

## 6. Leaning, and what would change it

**Recommendation: B, with D's reminders kept, and C rejected for now.**

A hook on Patient Appointment calling `notify()` gets all three delivery legs (row + live + push) that
patients already experience for chat, covers all ten write points without anyone remembering to, and
can use `Appointment Reschedule History` for accurate before/after wording.

- **A loses** on the ten call sites. It is the more *honest* design — an endpoint declaring its own
  event beats inferring one from a diff — but the failure mode is silent omission, and this codebase has
  already been bitten by exactly that (three drifted notification call sites, one of which never fired
  at all).
- **C loses** on shape, not on idea. Config-driven wording is genuinely attractive and may be right
  later; today it means bending a WhatsApp/Meta-specific doctype and widening a wildcard hook.
- **D loses** as the *primary* mechanism because it produces no live update and no push — the patient
  would get a worse experience for appointments than for chat, on the same screen. It does **not** lose
  as a *complement*: its reminders are a real capability we have no answer to, and they should stay.

**What would change the recommendation:** if clinic staff need to edit this wording themselves without
a deploy, C becomes the right answer and the doctype should be renamed and generalised deliberately
rather than by accident.

---

## 7. Design questions that need answers before implementation

1. **Which events?** Booked / cancelled / rescheduled are asked for. Also available and arguably
   expected: **reassigned to a different practitioner** (`reassign_appointment` — the patient's doctor
   changed, which they would want to know), and **No Show**. Reminders exist already as email.
2. **How much detail in the in-app row?** The `Notification Log` row can safely carry date, time,
   practitioner and department — `type="Alert"` is never emailed. The **push payload must stay
   content-free** (`PUSH_NOTIFICATIONS.md` §4.4): a lock screen must not reveal that someone has a
   clinic appointment, let alone with which specialist. So *"Your appointment has been rescheduled"* is
   the push, and the detail lives in the row the app fetches.
3. **Localisation approach** — §4.3's three options. This is the one with real consequences and it
   should be settled first, because it shapes what `notify()` stores.
4. **Self-service:** confirm no notification to the patient for their own action, and decide whether
   staff/practitioner get one instead.
5. **Cancellation reason:** `cancel_appointment(reason=...)` takes one. Should the patient see it? It
   may be clinically or commercially sensitive ("practitioner unavailable" vs "patient did not pay").
6. **Do the existing email notifications stay on?** If both fire, a patient gets an email *and* a bell
   entry *and* a push for one booking. That may be desirable, or may be too much.

---

## 8. What was verified, and how

Everything above is from the live site or the source, not inference:

| Claim | Evidence |
|---|---|
10 write points | `grep` over `appointments/api.py` + `patient_portal/api.py` |
Reschedule mutates in place | read `reschedule_appointment` — sets fields, calls `save()` |
4 core Notification rows enabled | queried `tabNotification` on `mysite.localhost` |
`custom_patient_email` populated | 66/66 appointments, and it equals `Patient.user_id` in every sample |
2 WhatsApp configs, both disabled | queried `Remedisys WhatsApp Notification` |
`es.po` missing the strings | read the catalog |
Timezone `Asia/Kolkata` | `System Settings.time_zone` |
`appointment_time` is a timedelta | read a real row: `timedelta(seconds=72060)` |
Portal allow-list excludes appointments | `_PATIENT_VISIBLE_DOCTYPES == ("Portal Conversation",)` |
`has_value_changed` available | checked on a real `Patient Appointment` doc |

**Not verified / open:** whether core's `send_system_notification` resolves `custom_patient_email` to a
`Notification Log` row reliably (approach D's viability rests on it, and it was not tested because D is
not the recommendation); and whether any clinic actually wants reminders in-app as well as by email.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-26 | Ashutosh (AI-assisted) | Frozen as a record once the decisions landed; outcome and owning documents named |
| 1.0 | 2026-08-26 | Ashutosh (AI-assisted) | Initial research |
