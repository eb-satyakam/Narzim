# HIPAA readiness — gap analysis

**Doc status:** living · **Created:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-23 by Nishant · **Version:** 1.2

> ## Read this before saying the product is HIPAA compliant
>
> **It is not, today.** Not because of a missing feature, but because HIPAA compliance is mostly not
> a property of code, and because two blocking legal prerequisites are unsigned or unverified.
> This document says exactly what is done, what is missing, and which parts engineering cannot fix.

**Evidence labels:** **CONFIRMED** (verified in code/DB) · **PARTIAL** · **MISSING** · **NOT CODE**
(an administrative or legal control that no amount of engineering satisfies) · **UNKNOWN**.

---

## 0. The two questions that come before any work

### Q1 — Does HIPAA actually apply to us?

**UNKNOWN, and it changes the whole answer.** HIPAA binds *covered entities* (US health plans,
clearinghouses, and providers who transmit health information electronically in connection with a
HIPAA transaction) and their *business associates*. A clinic operating in Mexico, treating Mexican
patients, billing in Mexico, is **not** a HIPAA covered entity — **LFPDPPP** and
**NOM-024-SSA3-2012** apply, which is what
[`compliance/profiles/mx.py`](../../remedisys_healthcare_ai/compliance/profiles/mx.py) already
encodes.

Three readings of "make this app HIPAA compliant", with different work attached:

| Reading | What it means | Work |
|---|---|---|
| **A — US expansion is planned** | We will have US covered-entity customers | Full programme below, plus BAAs, plus a `us` compliance profile |
| **B — HIPAA as a quality bar** | Stay in Mexico, but hold ourselves to HIPAA-grade technical safeguards because they are stricter and better documented than LFPDPPP's | Technical safeguards below; skip US-specific administrative machinery |
| **C — Enterprise buyers ask for it** | A questionnaire needs answering | The gap table below is the answer, honestly filled in |

**Recommendation: B now, A when a US customer is real.** B is genuinely useful — HIPAA's Security
Rule is a better engineering checklist than LFPDPPP's text — and it costs nothing to adopt.
Claiming A without BAAs and a risk analysis would be a false compliance claim, which is its own
liability.

### Q2 — Do we have BAAs with the subprocessors that receive PHI?

**This is the single blocking item.** Under HIPAA, any vendor that creates, receives, maintains or
transmits PHI on our behalf must sign a **Business Associate Agreement**. Today PHI (verbatim
doctor–patient conversation) leaves our infrastructure to:

| Subprocessor | What it receives | BAA status |
|---|---|---|
| **Deepgram** | Live audio stream → transcript text | **UNKNOWN — not verified** |
| **OpenAI** | Transcript text + patient clinical context | **UNKNOWN — and its DPA is open decision D1** |
| **Frappe Cloud** | The entire database | **UNKNOWN** |
| **Vercel** | Frontend hosting; PHI transits it | **UNKNOWN** |

[`integrations/openai.py`](../../remedisys_healthcare_ai/integrations/openai.py) lines 12–15 state
the provider must stay off until a data-processing agreement exists. `AI Settings.llm_provider` is
`OpenAI` and 2,430 prompt-log rows exist. **CONFIRMED:** we are running a PHI-processing provider
that our own code says should be disabled until paperwork exists.

**NOT CODE.** No engineering change makes this compliant. Until BAAs are signed, the honest
statement is "not HIPAA compliant", regardless of how good the safeguards are.

---

## 1. A finding that matters more than the label

**The compliance profile names different vendors than the ones actually receiving PHI.**

`compliance/profiles/mx.py` declares:

```python
llm_provider="anthropic",
audio_provider="groq",
```

Live `AI Settings` (**CONFIRMED**, `marley.local`, 2026-08-25):

```
deepgram_model = nova-3      deepgram_language = multi
llm_provider   = OpenAI      (gpt-5-mini)
```

So the document that is supposed to be our record of *who processes patient data* names Anthropic
and Groq, while the traffic goes to OpenAI and Deepgram. Under HIPAA this is a §164.308(b)
failure (business-associate contracts) **and** an accuracy failure in the record itself; under
LFPDPPP it undermines the privacy notice. Either way, a subprocessor register that is wrong is
worse than no register, because it will be relied on.

**Fix (engineering):** make the profile the single source of truth for provider selection and have
the integrations refuse to run against a provider the active profile does not name. That converts a
silent drift into a startup error.

---

## 2. HIPAA Security Rule — where we stand

### §164.308 Administrative safeguards

| Requirement | Status | Evidence / gap |
|---|---|---|
| Security Management Process — risk analysis | **MISSING · NOT CODE** | No documented Security Risk Analysis exists |
| Assigned Security Responsibility | **MISSING · NOT CODE** | No named Security Official |
| Workforce Security / clearance | **MISSING · NOT CODE** | — |
| Information Access Management | **PARTIAL** | RBAC is real and enforced server-side: `EB_` roles, docperm spec, patient-portal query conditions. **CONFIRMED** |
| Security Awareness & Training | **MISSING · NOT CODE** | — |
| Security Incident Procedures | **MISSING · NOT CODE** | `breach_notification_hours=72` is declared in the profile and consumed by nothing |
| Contingency Plan (backup, DR, emergency mode) | **UNKNOWN** | Frappe Cloud provides backups; no documented tested restore |
| Evaluation (periodic) | **MISSING · NOT CODE** | — |
| **Business Associate Contracts** | **MISSING · BLOCKING** | See Q2 |

### §164.310 Physical safeguards

| Requirement | Status | Notes |
|---|---|---|
| Facility Access Controls | **NOT CODE** | Inherited from Frappe Cloud / Vercel; needs their attestations on file |
| Workstation Use & Security | **MISSING · NOT CODE** | Clinic policy: shared tablets in consult rooms are the real exposure |
| Device & Media Controls / disposal | **MISSING · NOT CODE** | — |

### §164.312 Technical safeguards — the part engineering owns

| Requirement | Status | Evidence |
|---|---|---|
| **Access Control** — unique user ID | **CONFIRMED** | JWT Bearer via `eb_frappe_jwt`; no shared accounts in the auth path |
| Access Control — emergency access | **MISSING** | No documented break-glass procedure |
| Access Control — automatic logoff | **PARTIAL** | Token TTL + refresh exist; no idle-session timeout in the clinical UI |
| Access Control — encryption/decryption | **PARTIAL** | TLS in transit **CONFIRMED**; encryption at rest is the hosting provider's, unverified by us |
| **Audit Controls** | **PARTIAL** | `AI Transcript Segment` has `track_changes: 1` and is append-only (`_enforce_append_only`); signing stamps `custom_encounter_done_by`. **But** field-level authorship of clinical content is React state only — `aiFlags` does not persist. **CONFIRMED gap** |
| **Integrity** — alteration/destruction | **PARTIAL** | Append-only transcript, `docstatus` immutability after submit. **But** `save_draft` uses replace semantics on child tables, which already destroyed dosing intervals once (P0-4) |
| **Person/Entity Authentication** | **CONFIRMED** | Bearer JWT; `allow_guest=True` is banned by CLAUDE.md and absent |
| **Transmission Security** | **PARTIAL** | Browser → Deepgram is direct TLS WebSocket; audio never touches our servers (ADR-009). Good. But the destination is an unBAA'd subprocessor |

### §164.316 Documentation

| Requirement | Status |
|---|---|
| Written policies & procedures | **MISSING · NOT CODE** |
| Retain documentation 6 years | **MISSING** — `audit_retention_years=5` (Mexico), short of HIPAA's 6 |
| Periodic review & update | **MISSING · NOT CODE** |

---

## 3. Privacy Rule items that bite immediately

| Requirement | Status | Evidence |
|---|---|---|
| **Minimum Necessary** (§164.502(b)) | **AT RISK** | The AI tool registry has 36 tools, 13 of them read. `patient_clinical_summary` assembles broad record context into prompts. Open decision D5 is literally whether to permit full-record retrieval or bound the summary — that decision *is* a minimum-necessary decision |
| **Authorization / consent for recording** | **BROKEN** | **CONFIRMED:** 13,631 transcript turns across 126 encounters; all 137 sessions carry `consent_obtained = 1` set by a hardcoded frontend `true` (`CopilotPanel.tsx:109`) with auto-start (`CopilotHost.tsx:87`). No human was asked. This is the most serious item in this document |
| Right of Access (§164.524) | **PARTIAL** | Patient portal exposes encounters and labs; no transcript access path |
| Right of Amendment (§164.526) | **MISSING** | `amended_from` exists on the doctype with **0 rows** and no API or UI |
| Accounting of Disclosures (§164.528) | **MISSING** | No disclosure log; AI subprocessor calls are disclosures |
| Breach Notification (§164.400) | **MISSING** | No detection, no procedure, no template |

**Also directly relevant, and already found:**

- **No retention enforcement.** `transcript_retention_days = 90` is read by no deletion code;
  `scheduler_events` is commented out in `hooks.py`. **CONFIRMED.** Oldest segment 2026-07-26, so
  nothing is overdue yet — there is runway, not a breach.
- **Erasure is a two-place operation with no implementation.**
  `services/encounter_ai_record.py` states in its own docstring that the consolidated record sits
  outside the retention promise and that erasure must reach it separately.
- **Session-replay analytics.** PostHog replay is off locally and masking is on by default, and the
  masking switch governs production too — but a replay of a clinical screen is a PHI disclosure to
  PostHog. Requires a BAA and an explicit decision, not a default.
- **23% of transcript turns are unattributed** (`unknown` speaker). Not a HIPAA violation, but it
  weakens the record's evidentiary value.

---

## 4. The ambient capture layer — Encounter step 1

The highest-PHI-density surface in the product: a live microphone in a consult room. Full technical
audit in [`architecture/ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md); this section maps it
against the safeguards. Figures read from `marley.local` on 2026-08-26.

### What the safeguards say about this one screen

| Safeguard | Status | Evidence on this screen |
|---|---|---|
| §164.312(e) Transmission Security | **PARTIAL** | Browser → Deepgram is direct TLS (ADR-009); audio never reaches Frappe, so the highest-risk data class never lands in our estate. The destination is still an unBAA'd subprocessor (Q2) |
| §164.312(a) Access Control | **CONFIRMED** | `_require_encounter_read` on every session and segment endpoint; sessions are scoped to `(encounter, session_user)` |
| §164.312(c) Integrity | **CONFIRMED** | `AI Transcript Segment` is append-only with `track_changes: 1`; corrections go through one audited path (`sync_transcript`), and a sealed session refuses edits |
| §164.312(b) **Audit Controls** | **FAILING** | The audit trail cannot say when recording stopped (GAP-2) or whether it was paused (GAP-3). 141 of 144 sessions have `started_at` and no `ended_at` |
| §164.308(a)(1) Risk analysis input | **FAILING** | Consent records assert a fact that never happened (GAP-1) — a control that reports success while doing nothing |
| §164.310(d) / Privacy Rule retention | **FAILING** | 7-year declared retention, no purge job, 14,187 PHI segments (GAP-4) |
| §164.502(b) Minimum Necessary | **AT RISK** | The whole consultation is captured, including anything said that is not clinically relevant. There is no way to mute (GAP-6) |

### The three that are compliance failures, not feature gaps

**Consent — PHI-2.** `CopilotHost` starts recording in a mount effect and stamps
`consent_obtained = 1` client-side. **144 of 144** sessions carry that flag; none was obtained.
This is worse than an absent control: an auditor reading the field is actively misled, and every
one of those 14,187 segments was captured without a lawful basis on record. The server-side gate
is sound — the doctype refuses `Recording` without consent — so the failure is entirely that the
UI satisfies the flag on the patient's behalf. Fixed in v3 (`useCopilot` driven directly; `start()`
reachable only from a human answer). **V1 must not ship as-is.**

**Retention — PHI-3 and PHI-5.** `transcript_retention_days = 2555` with `scheduler_events`
commented out in `hooks.py` means nothing is ever deleted. A declared period no code enforces is a
false promise (PHI-3), and the capture screen compounds it by telling the family "transcript kept 90
days" — a statement the backend contradicts by a factor of 28 (PHI-5). Two fixes, and the UI string
is the urgent one because it is what a patient is told.

**Audit controls — §164.312(b).** A recording that cannot say when it ended, or whether it was
paused, cannot answer the one question an audit asks: what was captured, and when. 141 open
sessions is not a reporting inconvenience; it is the audit control not working.

### What this screen gets right, and should not be traded away

Audio never entering our infrastructure removes the largest exposure outright, and it is *enforced*
(`retain_audio = 0`, `audio_retention_days = 0`) rather than promised. The consent gate lives in the
doctype, so once the UI stops lying to it the control is real. Token minting precedes the state
transition, so a Deepgram outage cannot strand a session mid-consultation. Segment writes are
idempotent and a late segment after a clean stop is handled explicitly.

### If HIPAA is ever actually in scope

Beyond the three failures above, this screen adds two prerequisites that are **NOT CODE**: a BAA with
Deepgram before a single US patient is recorded (Q2 — the audio path is the most direct PHI
disclosure in the product), and a written consent script, because a verbal consent flow with no
documented wording is not a defensible control regardless of what the software does.

---

## 5. What we already do well — worth not breaking

- **Audio is never stored.** `audio_retention_days = 0`, `retain_audio = 0`, enforced in
  `integrations/deepgram.py`, and audio never reaches Frappe at all (ADR-009). **CONFIRMED.**
  This removes the highest-risk data class entirely.
- **Append-only transcript with change tracking.** Corrections go through one audited path.
- **Server-side authorisation.** `frappe.flags.ignore_permissions` and `allow_guest=True` are
  banned by CLAUDE.md; permission gaps are fixed via the docperm spec plus a dated patch.
- **A jurisdiction abstraction already exists** (ADR-018), so adding HIPAA is a profile, not a
  rewrite.
- **PHI-stripping already exists** for the external lab-report analyser (ADR-013).

---

## 6. Engineering plan (what code can actually do)

Ordered by risk reduced per unit of work. None of it makes us HIPAA compliant on its own.

1. **Restore consent.** Frontend-only; the consent UI is already built and unreachable behind one
   hardcoded `true`. Until this lands, every new recording adds to a pile of PHI with no
   authorisation behind it.
2. **Make the compliance profile authoritative for subprocessors.** Integrations refuse to call a
   provider the active profile does not name. Kills the drift in §1.
3. **Terminate sessions.** `sendBeacon` on unload plus an `idle_timeout` sweep; requires
   `scheduler_events` to be uncommented. Gives every session a real end time — an audit control.
4. **Enforce retention.** One scheduled purge honouring `transcript_retention_days`, covering
   **both** the segments and the consolidated AI record.
5. **Persist field-level provenance.** Currently React state. Required for Audit Controls and for
   the Right of Amendment to mean anything.
6. **Implement erasure** as one operation that reaches every store holding a patient's data.
7. **Add a disclosure log** — one row per PHI transmission to a subprocessor, per §164.528.
8. **Idle-session timeout** in the clinical UI (§164.312 automatic logoff).
9. **Bound the AI's record access** (decision D5) and record the decision as a minimum-necessary
   determination.
10. **A `us` compliance profile** — *proposed, not written*, because its retention numbers are a
    legal determination, not an engineering guess. HIPAA itself sets no clinical-record retention
    period; state law and our own policy do, and documentation must be kept 6 years.

---

## 7. What engineering cannot do

Listed so nobody mistakes a green test suite for compliance:

- Signing BAAs with Deepgram, OpenAI, Frappe Cloud and Vercel
- The Security Risk Analysis
- Naming a Security Official and a Privacy Official
- Workforce training and sanction policy
- Written policies and procedures, reviewed periodically
- Notice of Privacy Practices
- Breach notification decisions
- Deciding whether HIPAA applies at all

---

## 8. Honest current statement

Until Q1 is answered and BAAs exist, this is what may truthfully be said:

> Remedisys is built to LFPDPPP and NOM-024-SSA3-2012 for the Mexican market. Audio is never
> retained. Transcript text is processed by named subprocessors and retained for a bounded period.
> The platform is being aligned to the HIPAA Security Rule's technical safeguards as an engineering
> standard; it is **not** certified or contractually HIPAA compliant, and no Business Associate
> Agreements are in place.

Do not shorten this to "HIPAA compliant".

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 1.1 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Added §4 — the ambient capture layer mapped against the safeguards, with live figures (144/144 false consent, 141 open sessions, 14,187 unexpiring segments); renumbered §4–§7 to §5–§8 |
| 1.0 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Created — gap analysis against HIPAA Security and Privacy Rules |
