# AI transcript erasure path — documented, not implemented

**Doc status:** living · **Created:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

> ## Read this before assuming a patient's transcript can be deleted today
>
> **It cannot be, today.** This document enumerates every place AI transcript
> content lives, so that a future, explicitly authorized erasure capability
> knows exactly what it must reach. It is a map, not a mechanism. No code in
> this repository deletes any of the rows named below. Building that
> mechanism is a separate piece of work requiring its own explicit approval
> — see [ADR-051](../adr/adr-051-transcript-retention-indefinite-single-source.md)
> §"Decision" item 4.

## Why this exists

[ADR-051](../adr/adr-051-transcript-retention-indefinite-single-source.md)
decided transcript retention is **indefinite** — no scheduled expiry, no
automatic purge. `ComplianceProfile.right_to_erasure = True` (both `mx` and
`india` profiles) declares that patients may request deletion of their
personal data (LFPDPPP Art. 16 ARCO — *cancelación* — for `mx`; DPDPA 2023
S.12 for `india`). **A declared right with no known mechanism is a claim
this codebase cannot honour.** This document is the first step toward
closing that gap honestly: know where everything is before promising to
remove it.

## The three copies

An erasure request for one patient's AI-generated content must reach **all
three** of these, not just the obvious one:

| # | Location | Nature | Scope | Notes |
|---|---|---|---|---|
| 1 | `AI Transcript Segment` | **Authoritative** live transcript | Every session, append-only | The real-time write path (`api/ai/segments.py::append_segment`, `sync_transcript`). Filtered by `session`/`encounter`. |
| 2 | `AI Encounter Record.transcript_json` | **Derived** copy | One row per *signed* encounter, bounded at 5,000 segments | Written once, at signature time, by `services/encounter_ai_record.py` (`Patient Encounter` `on_submit` hook). A snapshot, not synced after signing. |
| 3 | `tabVersion` (Frappe's own `track_changes` mechanism) | **Incidental** copy | Grows with every manual speaker correction on a segment | Undeclared until the design work behind Phase 7 named it. `AI Transcript Segment` has `track_changes: 1`; every field-level edit (a speaker swap via "Fix speakers"/the correction flow) writes the full before/after value into a `Version` row on the core `tabVersion` table — a table with no PHI classification and no dedicated erasure tooling. |

**Also relevant, not transcript text itself:** `AI Prompt Log` stores hashes
and token counts (Rule 10 — no raw content, verified `raw_response` is empty
for every encounter/copilot call), so it is **not** a fourth transcript copy
— named here only so a future erasure design doesn't need to re-derive that.

## What "reaching all three" would require (design notes, not a plan)

This section records what an eventual erasure mechanism would need to
consider — not a commitment to build it, and not an implementation
schedule.

- **Copy 1** (`AI Transcript Segment`): straightforward per-encounter or
  per-patient row deletion, but is the medico-legal record of the
  encounter (append-only by design, per `ai_transcript_segment.py`'s own
  `_enforce_append_only`) — an erasure mechanism would need an explicit,
  audited exception to that append-only guarantee, not a silent bypass.
- **Copy 2** (`AI Encounter Record.transcript_json`): a JSON blob field on
  a signed, submitted document. Signed encounters carry their own
  compliance weight (NOM-024 clinical-record retention); erasing content
  from an already-signed record is a different, likely harder, question
  than erasing an unsigned draft's transcript.
- **Copy 3** (`tabVersion`): a **core Frappe table**, not an app-owned
  doctype (Rule 1 — never modify Frappe core). Any erasure touching it
  needs to happen through Frappe's own supported APIs for version data,
  scoped precisely enough that it never touches Version rows belonging to
  unrelated doctypes that happen to share the same core table.
- **Cross-cutting:** a real erasure mechanism needs to answer "erase for
  which identity" (patient? encounter? both?), how it interacts with
  Frappe Cloud's backups (§17 of the implementation plan notes there is
  "no documented tested restore, and no position on how backups interact
  with a future erasure" — a backup a request predates would still hold
  the data), and how it is itself audited (an erasure event is exactly the
  kind of thing that must be logged, without logging the erased PHI
  itself — Rule 10).

## What this document deliberately does not do

- Does not implement deletion, redaction, or anonymization of any row.
- Does not implement a purge job tied to `AI Settings.transcript_retention_days`
  (which remains `0` / indefinite per ADR-051).
- Does not propose a UI for a patient or staff member to request erasure.
- Does not resolve whether a *signed* encounter's transcript (clinical
  record) is even legally erasable under NOM-024 — that is a legal
  question, not an engineering one, and is out of scope here.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Initial version — enumerates the three known transcript copies as the erasure-path map required by ADR-051 |
