# Frontend ↔ Backend Contract

**Doc status:** living · **Created:** 2026-06-10 by Invincible · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

> **Read this before implementing any API method.**
> This document defines what the Next.js frontend expects from every Frappe method.
> Breaking these contracts silently breaks the frontend — no error, just undefined data.
>
> Frontend repo: `Healthcare_next_app` (Next.js 16, Vercel)
> This repo: `EB_Healthcare_Backend` (Frappe v16, Frappe Cloud)

---

## How the system works

```
Browser
  → Next.js Route Handler  (src/app/api/*)    ← never visible to browser
      → Frappe Backend     (FRAPPE_URL/api/method/...)
```

The browser **never** calls Frappe directly. Every Frappe call is proxied through
a Next.js route handler that injects the Bearer token from an httpOnly cookie.
`FRAPPE_URL` never reaches the browser.

---

## Response Shape Contract — CRITICAL

The frontend uses different fetchers depending on how your method returns data.
**Using the wrong return style causes silent `undefined` data — no error is thrown.**

| Your method does | Frontend fetcher | Response shape Frappe sends | What frontend receives |
|---|---|---|---|
| `return value` | `frappeFetch<T>` | `{ "message": T }` | `T` (unwrapped) |
| `set_response(data)` | `frappeFetchSet<T>` | `{ "status": "success", "data": T }` | `T` (unwrapped) |
| `set_list_response(data, pagination)` | `frappeFetchList<T>` | `{ "status": "success", "data": T[], "pagination": {...} }` | `{ data, pagination }` |

### Rules

- **Standard Frappe methods** (e.g. `frappe.client.get_list`) → use `return` → frontend uses `frappeFetch`
- **Custom `remedisys_healthcare_ai` methods** → use `set_response()` / `set_list_response()` → frontend uses `frappeFetchSet` / `frappeFetchList`
- **Never mix them.** A method that calls `set_response()` but is consumed by `frappeFetch` returns `undefined`.

### Pagination shape (for list endpoints)

```python
# ✅ correct — matches frappeFetchList contract
set_list_response(
    data=records,
    pagination={
        "total": total_count,
        "page": page,
        "page_size": page_size,
    }
)
```

### Error shape

Use `handle_api_errors` or raise `frappe.exceptions.ValidationError` / `PermissionError`.
Both `frappeFetchSet` and `frappeFetchList` surface these as `FrappeApiError` on the frontend.

```python
# ✅ correct
if not patient:
    frappe.throw("Patient not found", frappe.DoesNotExistError)

# ❌ wrong — frontend receives generic 500 with no usable message
raise Exception("something went wrong")
```

---

## Whitelisting Rules

Every method called from the frontend **must** have `@frappe.whitelist()`.
Frappe checks the whitelist **before** authentication — a valid Bearer token does
not bypass this check.

```python
# ✅ correct — requires authenticated user, respects Frappe role permissions
@frappe.whitelist()
def my_method(param: str):
    ...

# ❌ never — allows unauthenticated public access
@frappe.whitelist(allow_guest=True)

# ❌ never — bypasses Frappe permissions entirely
frappe.flags.ignore_permissions = True
frappe.db.get_value(..., ignore_permissions=True)
```

---

## Current API Endpoints

Status: **✅ integrated** = frontend calls real API · **⚠️ stub** = backend method exists but is empty · **🔲 pending** = not started

| Method | Next.js path | Frappe method | Return style | Status |
|---|---|---|---|---|
| GET | `/api/auth/login` | `eb_frappe_jwt.api.get_token` | `return` | ✅ |
| POST | `/api/auth/refresh` | `eb_frappe_jwt.api.refresh_token` | `return` | ✅ |
| POST | `/api/auth/logout` | `eb_frappe_jwt.api.revoke_token` | `return` | ✅ |
| GET | `/api/auth/me` | `remedisys_healthcare_ai.api.v1.auth.api.get_current_user` | `return` | ✅ |
| GET | `/api/patients` (list) | `remedisys_healthcare_ai.api.v1.patients.api.list_patients` | `set_list_response` | ✅ |
| GET | `/api/patients?id=` | `remedisys_healthcare_ai.api.v1.patients.api.get_patient` | `set_response` | ✅ |
| POST | `/api/patients` | `remedisys_healthcare_ai.api.v1.patients.api.create_patient` | `set_response` | ✅ |
| GET | `/api/healthcare/service-units` | `frappe.client.get_list` (Healthcare Service Unit) | `return` | ✅ |
| GET | `/api/healthcare/service-units?mode=admin` | `frappe.client.get_list` (Healthcare Service Unit, all fields, no appt filter) | `return` | ✅ |
| POST | `/api/healthcare/service-units` | `remedisys_healthcare_ai.api.v1.admin.api.create_service_unit` | `set_response` | 🔲 |
| PATCH | `/api/healthcare/service-units` | `remedisys_healthcare_ai.api.v1.admin.api.update_service_unit` | `set_response` | 🔲 |
| DELETE | `/api/healthcare/service-units` | `remedisys_healthcare_ai.api.v1.admin.api.delete_service_unit` | `set_response` | 🔲 |
| GET | `/api/healthcare/practitioners` | `frappe.client.get_list` (Healthcare Practitioner) | `return` | ✅ |
| GET | `/api/healthcare/appointment-types` | `frappe.client.get_list` (Appointment Type) | `return` | ✅ |
| GET | `/api/appointments` | `remedisys_healthcare_ai.api.v1.appointments.api.list_appointments` | `set_list_response` | ✅ |
| POST | `/api/appointments` | `remedisys_healthcare_ai.api.v1.appointments.api.book_appointment` | `set_response` | ✅ |
| GET | `/api/appointments/slots` | `remedisys_healthcare_ai.api.v1.appointments.api.get_available_slots` | `set_response` | ✅ |
| GET | `/api/healthcare/practitioners` | `remedisys_healthcare_ai.api.v1.providers.api.get_providers` | `set_list_response` | ✅ |
| GET | `/api/healthcare/practitioners?id=` | `remedisys_healthcare_ai.api.v1.providers.api.get_provider_detail` | `set_response` | ✅ |
| PATCH | `/api/appointments` | `remedisys_healthcare_ai.api.v1.appointments.api.update_status` | `set_response` | ✅ |
| POST | `/api/appointments/cancel` | `remedisys_healthcare_ai.api.v1.appointments.api.cancel_appointment` | `set_response` | ✅ |
| POST | `/api/appointments/check-in` | `remedisys_healthcare_ai.api.v1.appointments.api.check_in_patient` | `set_response` | ✅ |
| PATCH | `/api/patients` | `remedisys_healthcare_ai.api.v1.patients.api.update_patient` | `set_response` | ✅ |
| POST | `/api/patients/guardian` | `remedisys_healthcare_ai.api.v1.patients.api.add_guardian` | `set_response` | ✅ |
| DELETE | `/api/patients/guardian` | `remedisys_healthcare_ai.api.v1.patients.api.remove_guardian` | `set_response` | ✅ |
| GET | `/api/encounters` | `remedisys_healthcare_ai.api.v1.encounters.api.list_encounters` | `set_list_response` | ✅ |
| POST | `/api/encounters` | `remedisys_healthcare_ai.api.v1.encounters.api.create_encounter` | `set_response` | ✅ |
| GET | `/api/vitals` | `remedisys_healthcare_ai.api.v1.clinical.api.list_vitals` | `set_list_response` | 🔲 |
| POST | `/api/vitals` | `remedisys_healthcare_ai.api.v1.clinical.api.record_vitals` | `set_response` | 🔲 |
| GET | `/api/labs` | `remedisys_healthcare_ai.api.v1.labs.api.list_lab_results` | `set_list_response` | 🔲 |
| POST | `/api/labs` | `remedisys_healthcare_ai.api.v1.labs.api.order_lab_test` | `set_response` | 🔲 |
| GET | `/api/billing` | `remedisys_healthcare_ai.api.v1.billing.api.list_invoices` | `set_list_response` | 🔲 |
| POST | `/api/billing/payment` | `remedisys_healthcare_ai.api.v1.billing.api.record_payment` | `set_response` | 🔲 |
| GET | `/api/dashboard` | `remedisys_healthcare_ai.api.v1.dashboard.api.get_dashboard_data` | `set_response` | 🔲 |
| GET | `/api/admin/companies` | `frappe.client.get_list` (Company) | `return` | ✅ standard Frappe |
| POST | `/api/admin/companies` | `remedisys_healthcare_ai.api.v1.admin.api.create_company` | `set_response` | 🔲 |
| PATCH | `/api/admin/companies` | `remedisys_healthcare_ai.api.v1.admin.api.update_company` | `set_response` | 🔲 |
| GET | `/api/admin/users` | `remedisys_healthcare_ai.api.v1.admin.api.list_staff` | `set_list_response` | 🔲 |
| POST | `/api/admin/users` | `remedisys_healthcare_ai.api.v1.admin.api.invite_staff` | `set_response` | 🔲 |
| PATCH | `/api/admin/users` | `remedisys_healthcare_ai.api.v1.admin.api.update_user` | `set_response` | 🔲 |
| GET | `/api/admin/departments` | `frappe.client.get_list` (Department) | `return` | ✅ standard Frappe |
| POST | `/api/admin/departments` | `remedisys_healthcare_ai.api.v1.admin.api.create_department` | `set_response` | 🔲 |
| PATCH | `/api/admin/departments` | `remedisys_healthcare_ai.api.v1.admin.api.update_department` | `set_response` | 🔲 |
| DELETE | `/api/admin/departments` | `remedisys_healthcare_ai.api.v1.admin.api.delete_department` | `set_response` | 🔲 |
| POST | `/api/healthcare/appointment-types` | `remedisys_healthcare_ai.api.v1.admin.api.create_appointment_type` | `set_response` | 🔲 |
| PATCH | `/api/healthcare/appointment-types` | `remedisys_healthcare_ai.api.v1.admin.api.update_appointment_type` | `set_response` | 🔲 |
| DELETE | `/api/healthcare/appointment-types` | `remedisys_healthcare_ai.api.v1.admin.api.delete_appointment_type` | `set_response` | 🔲 |
| GET | `/api/admin/medications` | `frappe.client.get_list` (Medication) | `return` | ✅ standard Frappe |
| POST | `/api/admin/medications` | `remedisys_healthcare_ai.api.v1.admin.api.create_medication` | `set_response` | 🔲 |
| PATCH | `/api/admin/medications` | `remedisys_healthcare_ai.api.v1.admin.api.update_medication` | `set_response` | 🔲 |
| DELETE | `/api/admin/medications` | `remedisys_healthcare_ai.api.v1.admin.api.delete_medication` | `set_response` | 🔲 |
| GET | `/api/admin/insurance` | `frappe.client.get_list` (Healthcare Insurance Company) | `return` | ✅ standard Frappe |
| POST | `/api/admin/insurance` | `remedisys_healthcare_ai.api.v1.admin.api.create_insurance` | `set_response` | 🔲 |
| PATCH | `/api/admin/insurance` | `remedisys_healthcare_ai.api.v1.admin.api.update_insurance` | `set_response` | 🔲 |
| DELETE | `/api/admin/insurance` | `remedisys_healthcare_ai.api.v1.admin.api.delete_insurance` | `set_response` | 🔲 |
| GET | `/api/admin/lab-tests` | `frappe.client.get_list` (Lab Test Template) | `return` | ✅ standard Frappe |
| POST | `/api/admin/lab-tests` | `remedisys_healthcare_ai.api.v1.admin.api.create_lab_test` | `set_response` | 🔲 |
| PATCH | `/api/admin/lab-tests` | `remedisys_healthcare_ai.api.v1.admin.api.update_lab_test` | `set_response` | 🔲 |
| DELETE | `/api/admin/lab-tests` | `remedisys_healthcare_ai.api.v1.admin.api.delete_lab_test` | `set_response` | 🔲 |
| GET | `/api/admin/symptoms` | `frappe.client.get_list` (Complaint) | `return` | ✅ standard Frappe |
| POST | `/api/admin/symptoms` | `remedisys_healthcare_ai.api.v1.admin.api.create_complaint` | `set_response` | 🔲 |
| PATCH | `/api/admin/symptoms` | `remedisys_healthcare_ai.api.v1.admin.api.update_complaint` | `set_response` | 🔲 |
| DELETE | `/api/admin/symptoms` | `remedisys_healthcare_ai.api.v1.admin.api.delete_complaint` | `set_response` | 🔲 |
| GET | `/api/admin/diagnosis` | `frappe.client.get_list` (Diagnosis) | `return` | ✅ standard Frappe |
| POST | `/api/admin/diagnosis` | `remedisys_healthcare_ai.api.v1.admin.api.create_diagnosis` | `set_response` | 🔲 |
| PATCH | `/api/admin/diagnosis` | `remedisys_healthcare_ai.api.v1.admin.api.update_diagnosis` | `set_response` | 🔲 |
| DELETE | `/api/admin/diagnosis` | `remedisys_healthcare_ai.api.v1.admin.api.delete_diagnosis` | `set_response` | 🔲 |
| GET | `/api/admin/practitioners` | `frappe.client.get_list` (Healthcare Practitioner) | `return` | ✅ standard Frappe |
| POST | `/api/admin/practitioners` | `remedisys_healthcare_ai.api.v1.admin.api.create_practitioner` | `set_response` | 🔲 |
| PATCH | `/api/admin/practitioners` | `remedisys_healthcare_ai.api.v1.admin.api.update_practitioner` | `set_response` | 🔲 |
| DELETE | `/api/admin/practitioners` | `remedisys_healthcare_ai.api.v1.admin.api.delete_practitioner` | `set_response` | 🔲 |
| GET | `/api/admin/practitioner-schedules` | `frappe.client.get_list` (Practitioner Schedule) | `return` | ✅ standard Frappe |
| POST | `/api/admin/practitioner-schedules` | `remedisys_healthcare_ai.api.v1.admin.api.create_practitioner_schedule` | `set_response` | 🔲 |
| PATCH | `/api/admin/practitioner-schedules` | `remedisys_healthcare_ai.api.v1.admin.api.update_practitioner_schedule` | `set_response` | 🔲 |
| DELETE | `/api/admin/practitioner-schedules` | `remedisys_healthcare_ai.api.v1.admin.api.delete_practitioner_schedule` | `set_response` | 🔲 |
| GET | `/api/admin/payment-methods` | `frappe.client.get_list` (Mode of Payment) | `return` | ✅ standard Frappe |
| POST | `/api/admin/payment-methods` | `remedisys_healthcare_ai.api.v1.admin.api.create_payment_method` | `set_response` | 🔲 |
| PATCH | `/api/admin/payment-methods` | `remedisys_healthcare_ai.api.v1.admin.api.update_payment_method` | `set_response` | 🔲 |
| DELETE | `/api/admin/payment-methods` | `remedisys_healthcare_ai.api.v1.admin.api.delete_payment_method` | `set_response` | 🔲 |
| GET | `/api/admin/holiday-lists` | `frappe.client.get_list` (Holiday List) | `return` | ✅ standard Frappe |
| POST | `/api/admin/holiday-lists` | `remedisys_healthcare_ai.api.v1.admin.api.create_holiday_list` | `set_response` | 🔲 |
| PATCH | `/api/admin/holiday-lists` | `remedisys_healthcare_ai.api.v1.admin.api.update_holiday_list` | `set_response` | 🔲 |
| DELETE | `/api/admin/holiday-lists` | `remedisys_healthcare_ai.api.v1.admin.api.delete_holiday_list` | `set_response` | 🔲 |
| GET | `/api/admin/dosage-forms` | `frappe.client.get_list` (Dosage Form) | `return` | ✅ standard Frappe |
| POST | `/api/admin/dosage-forms` | `remedisys_healthcare_ai.api.v1.admin.api.create_dosage_form` | `set_response` | 🔲 |
| PATCH | `/api/admin/dosage-forms` | `remedisys_healthcare_ai.api.v1.admin.api.update_dosage_form` | `set_response` | 🔲 |
| DELETE | `/api/admin/dosage-forms` | `remedisys_healthcare_ai.api.v1.admin.api.delete_dosage_form` | `set_response` | 🔲 |
| GET | `/api/admin/lab-test-groups` | `frappe.client.get_list` (Lab Test Group) | `return` | ✅ standard Frappe |
| POST | `/api/admin/lab-test-groups` | `remedisys_healthcare_ai.api.v1.admin.api.create_lab_test_group` | `set_response` | 🔲 |
| PATCH | `/api/admin/lab-test-groups` | `remedisys_healthcare_ai.api.v1.admin.api.update_lab_test_group` | `set_response` | 🔲 |
| DELETE | `/api/admin/lab-test-groups` | `remedisys_healthcare_ai.api.v1.admin.api.delete_lab_test_group` | `set_response` | 🔲 |
| GET | `/api/admin/sample-collections` | `frappe.client.get_list` (Sample Collection) | `return` | ✅ standard Frappe |
| POST | `/api/admin/sample-collections` | `remedisys_healthcare_ai.api.v1.admin.api.create_sample_collection` | `set_response` | 🔲 |
| PATCH | `/api/admin/sample-collections` | `remedisys_healthcare_ai.api.v1.admin.api.update_sample_collection` | `set_response` | 🔲 |
| DELETE | `/api/admin/sample-collections` | `remedisys_healthcare_ai.api.v1.admin.api.delete_sample_collection` | `set_response` | 🔲 |
| GET | `/api/admin/price-lists` | `frappe.client.get_list` (Price List) | `return` | ✅ standard Frappe |
| POST | `/api/admin/price-lists` | `remedisys_healthcare_ai.api.v1.admin.api.create_price_list` | `set_response` | 🔲 |
| PATCH | `/api/admin/price-lists` | `remedisys_healthcare_ai.api.v1.admin.api.update_price_list` | `set_response` | 🔲 |
| DELETE | `/api/admin/price-lists` | `remedisys_healthcare_ai.api.v1.admin.api.delete_price_list` | `set_response` | 🔲 |
| GET | `/api/admin/tax-categories` | `frappe.client.get_list` (Tax Category) | `return` | ✅ standard Frappe |
| POST | `/api/admin/tax-categories` | `remedisys_healthcare_ai.api.v1.admin.api.create_tax_category` | `set_response` | 🔲 |
| PATCH | `/api/admin/tax-categories` | `remedisys_healthcare_ai.api.v1.admin.api.update_tax_category` | `set_response` | 🔲 |
| DELETE | `/api/admin/tax-categories` | `remedisys_healthcare_ai.api.v1.admin.api.delete_tax_category` | `set_response` | 🔲 |

> When you implement a stub or new endpoint: update the **Status** column above and notify the frontend developer so they can swap dummy data → real API call in `src/lib/api/<module>.ts`.

---

## Screen → API Dependency Map

Which frontend screens are blocked on which backend methods.

| Frontend screen | Blocked on |
|---|---|
| Dashboard (live queue) | `get_dashboard_data`, `list_appointments` |
| Patient list | `list_patients` ✅ |
| Patient 360 | `get_patient` ✅, `list_vitals`, `list_encounters`, `list_lab_results`, `list_invoices` |
| Book appointment | `book_appointment` ✅, `get_available_slots` ✅ |
| Check-in flow | `check_in_patient` (not yet in table — add when built) |
| Encounter screen | `create_encounter`, `get_encounter`, `save_draft`, `complete_encounter` |
| Vitals intake | `record_vitals`, `list_vitals` |
| Lab orders | `order_lab_test`, `list_lab_results` |
| Prescriptions | `create_prescription`, `list_prescriptions` |
| Billing / payments | `list_invoices`, `record_payment` |

---

## How Frontend Integrates a New Endpoint

When you mark an endpoint ✅ ready, the frontend swap is **one file change**:

```typescript
// src/lib/api/encounters.ts — BEFORE (dummy data)
export async function listEncounters() {
  return MOCK_ENCOUNTERS;
}

// src/lib/api/encounters.ts — AFTER (real API)
export async function listEncounters() {
  const res = await fetch("/api/encounters");
  return res.json();
}
```

No component changes. No UI changes. Only `src/lib/api/<module>.ts` changes.

**Coordinate the swap:** ping the frontend developer with the exact method name,
response shape, and a sample response payload. They'll do the swap in under 30 minutes.

---

## Naming Convention

Frontend route handler paths follow this pattern:

```
/api/<resource>               GET list, POST create
/api/<resource>?id=<name>     GET single record
/api/<resource>/<action>      custom action (e.g. /api/appointments/slots)
```

Frappe method names follow:

```
remedisys_healthcare_ai.api.v1.<module>.api.<method_name>
```

Keep method names verb_noun: `list_patients`, `get_patient`, `book_appointment`, `record_vitals`.

---

## Auth Context

Every request from the frontend carries `Authorization: Bearer <access_token>`.
The token is the user's Frappe session. You get the current user in any method via:

```python
frappe.session.user   # e.g. "dr.ariel@chavitos.health"
```

Frappe's permission system automatically enforces document-level access based on
the user's roles. You do not need to write permission checks manually for standard
DocType access — Frappe does it. Use `require_permission()` from `utils.py` for
business-logic gating (e.g. only nurses can mark vitals).

---

## References

| Document | Location |
|---|---|
| Backend architecture + patterns | `docs/architecture/BACKEND_ARCHITECTURE.md` (this repo) |
| Backend engineering rules | `CLAUDE.md` (this repo) |
| Frontend system design | `Healthcare_next_app/docs/SYSTEM_DESIGN_FRONTEND.md` |
| Auth flows (full sequence diagrams) | `Healthcare_next_app/docs/AUTH.md` |
| Frontend API rules (BFF pattern) | `Healthcare_next_app/API_RULES.md` |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-10 | Sarvesh | Initial version (header backfilled from git history) |
