# Encounter v3 — how the screen works

**Doc status:** living · **Created:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 4.2

**This is the only document you need to understand the encounter screen.**
Everything else about it is frozen evidence — see §8 for the reading order.

---

## 1. The flow

```
  1 Capture  ──►  2 Review SOAP  ──►  3 Fill Encounter  ──►  Report  ──►  SIGNED
  (talk)          (read the note)     (the record)         (read it)   Patient 360

      ◄────────────────◄──────────────────◄─────────────────◄
      back is free from every step, the report included
```

You talk, you read what the AI wrote, you check the record, you read it once
more, you sign.

**Forward is gated, back is free — including from the report.** You reach a step
through the button that leads to it, never by tapping ahead. Going back stays
open everywhere, because re-reading the transcript before committing to an
assessment is a normal thing to want, and so is changing your mind while
reading the report.

**Sign & Close does not sign.** It flushes the draft and opens the report, still
unsigned. Back from there returns to the encounter with the draft intact —
nothing is written while previewing, so it costs nothing. Only **Sign & finish**
on the report signs, and then you land on Patient 360.

**Why the report is the gate**, rather than an "are you sure?" dialog: the thing
you need to check before attesting is the document itself, and the report is it.
A dialog trains a reflex; the report trains a reading.

**You can only reach the report from step 3.** The medications, lab orders,
vitals and diagnoses only appear there, and its footer says "You are attesting
to all of them". Before 2026-08-31 the Sign button was live on step 1 too, next
to a footer reading *"Nothing has been written to the record yet"*.

---

## 2. The one rule

Three kinds of data. Keep them apart.

| Kind | Where it comes from | Can it reach the record? |
| --- | --- | --- |
| **Transcript** | what was said out loud | evidence only |
| **Documented** | the note the clinician wrote and read | **yes** |
| **Considered** | AI ideas | **no** — the clinician must press Add |

They are separate TypeScript types, so a consideration cannot reach the save
function by accident. Not a convention. The compiler enforces it.

**USER STORY.** Dr. Bracamontes records a visit — fever, sore throat. He names
no drug, writing *"medication to be specified"* → **the screen shows** an empty
Prescriptions box → **the database holds** no prescription → **consequence:** the
child gets no drug the doctor did not choose.

**EXAMPLE** — real data, `HLC-ENC-2026-00552`:

```
Doctor's Plan text  : "symptomatic medication (to be specified by clinician)"
Prescriptions box   : empty                      ← correct
Doctor's Assessment : "Acute upper respiratory infection (J06.9)"
Diagnosis box       : that same text             ← copied word for word
```

---

## 3. Step 1 — Capture

**What it does.** Records the visit and turns speech into text.

Consent is asked first, and recording never starts on its own. Any line can be
corrected at any time: the pencil changes the words, the dropdown changes the
speaker.

**USER STORY.** The mic hears "pet turt" instead of "पेट दर्द" (stomach pain) →
the clinician presses the pencil and types the right words → **the database
stores** the corrected line → the note is built from "stomach pain", not from
the mistake.

**EXAMPLE**

```
Before : Patient   pet turt          [pencil]
After  : Patient   पेट दर्द है        [saved]
```

---

## 4. Step 2 — Review SOAP

**What it does.** The AI writes a first draft. The clinician reads it and fixes it.

Six boxes: Chief complaint, Subjective, Objective, Assessment, Plan, Education.
Edits autosave about 1.5 seconds after typing stops.

**This is the decision point.** Whatever is left in these boxes is what gets
signed. An edit here always wins.

### Pressing it again re-reads the consultation

Ask the patient more, press again, and it re-reads. New speech means it
processes; nothing new means it skips the call, so a double press is free.

The merge rule never changes:

```
empty box              →  filled directly
box you have written in →  the new material is OFFERED underneath, you press Add
```

Your words are never replaced. That is why it can run as often as you like.

**USER STORY.** The note is drafted. The patient then says *"my hands burn
also"* → **the screen shows** that sentence as an offer under Subjective, with
the quote beneath it as proof → the clinician presses Add → **the database
holds** their paragraph plus that line. Nothing was overwritten.

**EXAMPLE**

```
Said in the consultation, not in this section              Not now
Reports abdominal pain and fever. Took paracetamol last night.   [ Add ]
  "I have abdominal pain. I have fever." · "I take medicine last night to Paracetamol."
```

The top line is what gets added. The quotes below are the evidence, verbatim
from the transcript — the backend throws away any quote it cannot find there.

### Recording without leaving the note

If you notice Education is empty while reading, record right here. **Ask the
patient more** → talk → **Stop & update the note**. Same merge rule.

The strip states plainly whether audio is being captured, including when the mic
paused itself after two minutes of silence. A reading screen must never let a
clinician believe they are being recorded when they are not.

---

## 5. Step 3 — Fill Encounter

**What it does.** Shows the whole record before signing. Nothing hidden.

It uses V1's own components — same dose dropdowns, same lab search, same vaccine
row. Only the layout is new ([ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md)).

### Two lanes

**Lane A — Documented.** Read verbatim out of the note the clinician just
reviewed. Fills Symptoms, Diagnoses, Prescriptions, Labs, Procedures. Invents
nothing.

**Orders come from Plan only.** A test named in Objective came *back*. A test
named in Plan is being *sent*. Same words, opposite direction.

**Lane B — Considered.** AI suggestions, shown separately, marked "Not ordered".
They reach the record only when the clinician presses Add.

**USER STORY.** A five-week-old lab result sits in Objective → Lane A emits **no
lab order** → **otherwise the database gets** a fresh requisition →
**consequence:** a five-year-old is stuck for a second blood draw for a test he
already had, and the family pays twice.

**EXAMPLE**

```
Objective : "Lab - Akulab, resulted 29/07/2026: IgG all serotypes <0.3 mcg/mL"
Labs box  : empty        ← correct: a result, not an order
Plan      : "CBC and CRP"
Labs box  : CBC · CRP    ← correct: these are being sent
```

---

## 6. Where the data lives

`Patient Encounter` has no columns for SOAP text, so all seven text fields are
packed into one JSON blob on the encounter
([ADR-019](../adr/adr-019-encounter-native-binding.md)) rather than patching
ERPNext core.

```
Patient Encounter
  encounter_comment (JSON)   chief_complaint · hpi · physical_examination
                             diagnosis · plan · education · notes
  ├─ Patient Encounter Symptom     symptom chips
  ├─ Patient Encounter Diagnosis   diagnosis chips
  ├─ Drug Prescription             medications
  └─ Lab Prescription              lab orders

Vital Signs                 one row per visit
AI Transcript Segment       the conversation
AI Encounter Chat Message   Narzim chat and uploaded-document readings
AI SOAP Draft               the AI's own draft, versioned
```

**Text and chips are different things.** Assessment is free text in the blob.
Diagnosis chips are linked rows. Confusing the two has caused live bugs, because
one unmatched chip fails the *entire* save.

---

## 7. Which screen a clinician gets

One URL, `/encounters/[id]`, two screens behind it.

| Source | Effect |
| --- | --- |
| `NEXT_PUBLIC_FEATURE_ENCOUNTER_V2` | the deployment default |
| cookie `remedisys.encounter_view` | the clinician's own choice, and it wins |

The switch sits in the top bar on **both** screens, so the choice is reversible,
and to the left of Sign & Close so a mis-tap costs a page reload rather than a
signature.

---

## 8. Everything else, in reading order

You do **not** need these to understand the screen. They are dated evidence,
kept for anyone tracing why something is the way it is.

**The decisions.** One line each — you should not need to open one unless you
want the reasoning behind it.

| Decided | Where |
|---|---|
| Three steps, reusing V1's own components rather than rebuilding them | [ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md) |
| SOAP text lives in one JSON blob, because native has no columns for it | [ADR-019](../adr/adr-019-encounter-native-binding.md) |
| Transcripts are kept indefinitely, with one authoritative setting | [ADR-051](../adr/adr-051-transcript-retention-indefinite-single-source.md) |
| An uploaded lab is split: values go to Objective, interpretation never writes itself | [ADR-053](../adr/adr-053-uploaded-lab-documents-split-into-note-and-consideration.md) |
| **Any** practitioner may sign, and who signed is recorded | [ADR-039](../adr/adr-039-encounter-signing-any-practitioner-with-provenance.md) |
| A nurse may write to the encounter draft | [ADR-022](../adr/adr-022-nurse-encounter-draft-write.md) |
| Narzim chat is stored per encounter | [ADR-034](../adr/adr-034-encounter-chat-persistence.md) |

Superseded, kept only for the history: [ADR-038](../adr/adr-038-encounter-signing-assigned-practitioner-only.md)
said only the assigned practitioner may sign. ADR-039 reversed it — in a clinic
where the assigned doctor has gone home, that rule stops the note being signed
at all.

**The build history.** Evidence, not instructions. You do not need any of it.

| Read this when you want | Document |
|---|---|
| the research behind the 3-step decision | [ENCOUNTER_UX_RESEARCH.md](ENCOUNTER_UX_RESEARCH.md) |
| how Capture was built | [ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md) |
| what each build phase delivered | [Phase 3](ENCOUNTER_V3_PHASE3_CHECKLIST.md) · [Phase 4](ENCOUNTER_V3_PHASE4_CHECKLIST.md) · [Phase 5](ENCOUNTER_V3_PHASE5_CHECKLIST.md) · [Phase 6](ENCOUNTER_V3_PHASE6_CHECKLIST.md) |
| the single-screen design that was rejected | [ENCOUNTER_FROM_SCRATCH.md](ENCOUNTER_FROM_SCRATCH.md) |

A `record` is a dated snapshot. It is allowed to be out of date, and it is never
"corrected" — that is what makes it evidence.

---

## 9. What is deliberately not here

- **Known bugs.** [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md) owns those.
- **What changed and when.** [`CHANGELOG.md`](../../CHANGELOG.md) and
  [`WORK_LOG.md`](../../WORK_LOG.md) own that.
- **Project status.** [`docs/STATUS.md`](../STATUS.md) owns that, and only that.

One fact, one owner (CLAUDE.md §9). If this document starts restating any of the
above, it has grown wrong.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 4.2 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | §8 index rewritten: one line saying what each ADR DECIDED, so a reader opens one only for the reasoning. ADR-038 moved out of the list — superseded by ADR-039 |
| 4.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Corrected the flow diagram: back works from the report too, and Sign & Close does not sign — only Sign & finish does |
| 4.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Rewritten as the single entry point: 481 → ~200 lines, a user story and worked example per step, and a reading-order index. Three overlapping `living` docs frozen to `record`; four `living` documents described the same screen, which is what made the set unreadable |
| 3.4 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Sign & Close opens the report; signing happens there |
| 3.0 | 2026-08-29 | Sarvesh-SocialAngel (AI-assisted) | Rewritten in plain English with a user story and example per section |
| 1.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
