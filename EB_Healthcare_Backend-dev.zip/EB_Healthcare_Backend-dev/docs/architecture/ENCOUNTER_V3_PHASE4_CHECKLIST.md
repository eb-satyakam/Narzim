# Encounter V3 — Phase 4: orphan session recovery

**Doc status:** record · **Created:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 3.0

> **Frozen as evidence on 2026-09-01.** The current description of the encounter
> screen is [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md). This document is kept for
> what Phase 4 delivered, plus a Frappe Cloud rollout plan its own text marks as design only, not executed.
>
> It is a dated snapshot, so it is expected to fall out of date and is never
> "corrected" (CLAUDE.md §9). Four `living` documents were describing the same
> screen, which is what made the set unreadable; only one describes it now.

Phase 4 closed 146 AI sessions that had been left `Recording` forever, and added
a scheduled sweep so it cannot happen again. **Steps 0-7 are done on
`marley.local`.** What is left is the combined exit verification and a Frappe
Cloud rollout that has never been run.

Trimmed from 1,841 lines on 2026-08-31. The seven completed steps each carried
its full HOW, PRECONDITIONS and verification transcript -- appropriate while
they were being worked through one at a time, and 1,600 lines of build log
afterwards. Each step's outcome is summarised below and its detail is in the
revision history and in git. Nothing unexecuted was removed.

## THE PROBLEM

A recording session had no way to end except a physician pressing Stop. Close
the tab, lose the network, walk out of the room, and the row stayed `Recording`
for good.

**USER STORY.** A clinician records a consultation, is called to another room,
and closes the laptop -> **the system leaves** `AI Encounter Session` at
`Recording` with no `ended_at` -> **the database actually contains** a session
that looks live weeks later, so Phase 3's "one active session per encounter"
rule blocks that patient's next recording -> **consequence:** the next visit
cannot be recorded at all, and nobody can see why.

**EXAMPLE.** Measured on `marley.local` before Phase 4:

    total sessions                    146
    still `Recording`                 134     <- 92%
    legitimately `Stopped`             12
    transcript segments            14,187

134 of 146 sessions were orphans. Not an edge case -- the normal outcome.

## WHAT PHASE 4 DID

| Step | Outcome |
| --- | --- |
| 0 | Fresh `marley.local` backup, verified by gzip integrity, table coverage and row-count cross-check |
| 1 | `backfilled` added to `close_reason` via a scoped DocField-only patch. Zero rows touched, proven by byte-identical `MAX(modified)` before and after |
| 2 | The exact 134-session migration set frozen and recorded. Diffed byte-for-byte against Phase 3's own list: zero drift |
| 3 | All 134 recovered, one row at a time, through `doc.save()`. `ended_at` set explicitly first, so `_stamp_timing()` could not fabricate `now()` |
| 4 | 17 post-migration checks pass read-only. `Recording` = 0, `Stopped` = 146, totals unchanged, `Version` count +134 exactly |
| 5 | `tasks.py` (new) + a 15-minute cron + `close_reason=hard_cap` + `AI Settings.enable_orphan_sweep`, default OFF |
| 6 | 15-case test plan on `test.marley.local`. Three test-harness bugs found and fixed -- none in `tasks.py` |
| 7 | One deterministic sweep tick on `marley.local`: zero exceptions, zero mutations, `Version` count unchanged |

**Why `ended_at` is evidence-derived and never `now()`:** a session that really
ended at 14:12 must not be recorded as ending whenever the migration happened to
run. `ended_at` comes from the last transcript segment, or from `started_at` for
a session with no segments. Otherwise the record would assert a duration nobody
measured.

**Why the sweep ships OFF.** `enable_orphan_sweep` defaults to `0`. A scheduled
job that closes clinical sessions should be switched on deliberately, per site,
after someone has watched one tick do nothing.

## Beyond Phase 4 — Frappe Cloud Production Rollout Plan (design only, NOT executed)

**This section is not part of the numbered Phase 4 steps above and carries
no approval from anything decided so far.** It exists because you asked
for a genuine production design, and `marley.local` — however carefully
treated — is not production (ADR-005 names Frappe Cloud as the actual
deployment target). Nothing here has been run. No production system has
been touched, queried, or logged into. This plan requires its own
separate, explicit approval, almost certainly in a session well after this
checklist's own exit verification, and should be revisited (not assumed
still accurate) whenever that time comes, since real time will have passed
and this repo will have changed.

**What's genuinely available to build on, and what isn't — checked, not
assumed:**

| Asked for | Status |
|---|---|
| Sentry / error alerting | **Not integrated anywhere in this repo.** CLAUDE.md names it only as a normative rule ("Sentry has PHI scrubbing rules configured *before any PHI flows*") — a requirement for a future state, not a description of a present one. Confirmed via a full repo + site-config search: zero DSN, zero package reference, zero init call. |
| A backend production-environment doc | **Does not exist.** The frontend repo has its own `docs/platform/PRODUCTION_ENV.md` (Vercel-specific); nothing analogous exists here for the Frappe Cloud backend. |
| A deploy-to-Frappe-Cloud CI workflow | **Does not exist.** All three existing GitHub Actions workflows (`bruno-auth.yml`, `install-uninstall.yml`, `unit-tests.yml`) are test-only; none deploy anywhere. Frappe Cloud deployment, whenever it happens, is presumably the platform's own git-push-triggered mechanism — a hosting-provider feature this repo doesn't configure or document. |
| A prior scheduled-job pattern to be consistent with | **None existed before this Phase 4's own change.** `hooks.py`'s `scheduler_events` was fully commented out; the cron entry added in Step 5 is the first of its kind in this app. |
| A documented error/alerting convention | **None exists.** No team process for backend error notification is written down anywhere in this repo. |

**This changes what the plan below can honestly recommend: it designs
around the infrastructure that actually exists (`frappe.log_error()`, the
Desk `Error Log` list, System Manager access), and explicitly names what
would need to be built separately (real alerting, a deploy pipeline, a
production-env doc) rather than assuming any of it is already in place.**

### Schema migration (Frappe Cloud)

**What's different from `marley.local`:** there is no direct `bench`
shell access to a Frappe Cloud site the way there is here — schema changes
reach a Frappe Cloud site through the platform's own deploy mechanism
(pushing the tracked branch, then either an automatic or dashboard-
triggered "Deploy" which runs the app's migration as part of bringing the
new code online), not through hand-run `reload-doctype`/`bench migrate`
invocations.

- The two schema changes (`close_reason` gains `hard_cap`; `AI Settings`
  gains `enable_orphan_sweep`) are already fully additive and non-breaking
  — no existing field is altered, no existing data is reinterpreted. This
  is the same property every schema change across Phases 3–4 has held to,
  and it's what makes a normal deploy (rather than a hand-authored
  migration patch) sufficient here.
- Per this project's own branching policy (`dev → pre → main`), the code
  should reach `pre` first — ideally with `pre` carrying data realistic
  enough that a genuine, naturally-occurring orphan session might exist
  there, which would be the first real opportunity to observe an actual
  end-to-end closure (something even `marley.local`'s Step 7 above cannot
  provide, per its own stated honest limit).
- **Explicit gate:** the code deploying is not the same event as the
  feature activating. `enable_orphan_sweep` defaults to `0` in the
  DocType JSON itself — deploying the code changes nothing until a human
  separately flips the flag (next section). This is the same
  deploy-before-constrain principle Phase 3 used for `active_key`'s index.

### Feature-flag enablement (Frappe Cloud)

- **Recommended mechanism: a System Manager toggles `AI Settings ›
  Session › Enable Orphan Sweep` directly in the Desk UI**, on the target
  site, after confirming schema has landed. This is deliberately *not* a
  data-migration patch that flips it automatically — a brand-new,
  first-of-its-kind scheduled job touching real patient encounter records
  should have its very first production activation be a deliberate, human,
  logged action, not something bundled into a deploy.
- **Immediately after enabling, before trusting it:** confirm via Desk
  (`AI Settings` form) that the value actually shows enabled — the same
  "verify it actually persisted, don't assume" discipline used for every
  flag/schema check throughout this project.
- **Sequencing:** enable on `pre` first (if a `pre` environment exists with
  its own scheduler running), observe for a meaningful period (long enough
  to plausibly see a real tick fire and, ideally, a real orphan close),
  before enabling on `main`/production.

### Scheduler verification (Frappe Cloud)

- Frappe Cloud provisions and runs the scheduler infrastructure for every
  site automatically — there is no separate cron/worker setup this repo
  needs to configure. What must be **confirmed**, not assumed, on the
  actual target site:
  1. `System Settings.enable_scheduler` is on for that site (should
     already be true — the AI Copilot's other existing behavior already
     depends on it).
  2. The new job (`remedisys_healthcare_ai.tasks.sweep_orphan_sessions`)
     appears in the `Scheduled Job Type` list after deploy — this is how
     Frappe surfaces that `hooks.py`'s cron entry was actually picked up.
  3. That job's `last_execution`/`stopped` fields (visible on the
     `Scheduled Job Type` document) show real, recent runs at
     roughly-15-minute intervals once deployed — the direct evidence that
     the registration is live, independent of whether the flag is on.
- Given no CI or scripted mechanism exists to check this automatically
  (per the table above), this is a **manual Desk check**, to be performed
  by whoever executes this rollout, immediately after deploy and again
  after enabling the flag.

### Rollback plan (Frappe Cloud)

Three distinct rollback layers, cheapest and safest first:

1. **Flag rollback — the primary, expected mechanism, zero deploy
   required.** Toggle `enable_orphan_sweep` back to unchecked in Desk.
   Takes effect on the very next tick (the flag is read fresh every run,
   never cached across ticks — confirmed by design in `tasks.py`). This is
   the entire reason the flag exists: an instant kill switch that requires
   no code change, no redeploy, no platform involvement.
2. **Code rollback — only if the scheduler registration itself needs
   removing** (e.g., a bug in the registration/dispatch mechanism itself,
   not in the sweep's logic, which the flag already covers). Revert the
   deployed commit/branch through the same git-based mechanism Frappe
   Cloud deploys from. Expected to essentially never be needed given the
   flag's coverage.
3. **Data rollback — only for a genuine incorrect closure that already
   happened.** Never a full-site restore for this — a full restore would
   also discard every legitimate clinical action recorded since the
   backup, which is a vastly worse outcome than one mis-closed session.
   The correct recovery is a **manual, human-reviewed correction** of the
   specific document: reopen it (`status` back to `Recording`, clear
   `ended_at`/`close_reason`) only after a person has confirmed from the
   evidence (transcript segments, `Version` history) that it was
   genuinely still a live session — mirroring the same "never fabricate,
   always evidence-derived" discipline this whole phase has followed for
   closing sessions in the first place, now applied to reopening one.
   Frappe Cloud's own automated backups remain the last-resort net behind
   all of this, not the first response.

### Monitoring (Frappe Cloud)

**Honest starting point: there is no alerting integration to plug into
today.** The plan below is what to rely on until real alerting exists, not
a description of something already wired up.

- **Interim (available now):** every failed closure calls
  `frappe.log_error()` (confirmed present in `tasks.py`), which lands in
  the `Error Log` doctype — visible and searchable in Desk. Every
  successful closure logs an info-level line via
  `frappe.logger("remedisys.sessions")` (session, encounter, run id,
  timestamps — no PHI, per Rule 10 and Section I of the Step 5 design).
  Until real alerting exists, this means **someone has to go look** —
  recommend a manual `Error Log` check (filtered on the log title prefix
  `hard_cap sweep failed`) on a defined cadence (e.g., daily) for at least
  the first week after production enablement, tapering once the mechanism
  has demonstrated it runs cleanly over time.
- **Recommended future work, explicitly out of scope for this design:**
  wiring `frappe.log_error()` calls to a real alerting channel (Sentry, if
  it's ever actually integrated per CLAUDE.md's stated intent, or
  something simpler like a scheduled digest job). Not proposed as part of
  Phase 4 — flagging it here so the gap is visible rather than silently
  assumed away.
- **What "healthy" looks like, for whoever performs this check:** the
  `Scheduled Job Type` document's execution history shows regular
  ~15-minute runs, the `Error Log` shows zero `hard_cap sweep failed`
  entries (or a very small, explainable number matching known transient
  conditions), and the count of sessions with `close_reason=hard_cap`
  grows slowly and plausibly over time rather than spiking (a spike would
  suggest either a real outage upstream, worth investigating on its own
  merits, or a bug in the sweep's own candidate-selection query).

### Safety checks (Frappe Cloud)

- **Confirm the flag is OFF immediately after deploy, before any human
  enables it** — the single most important check, and the direct
  real-world test of the "deploy is not the same as activate" principle
  above. If it were ever found ON immediately post-deploy without anyone
  having enabled it, that is a real bug (a wrong default in the JSON, or a
  migration that copied a value from another environment) and must be
  treated as a STOP condition, not explained away.
- **A `pre`-environment soak period before `main`**, per the branching
  policy, long enough to plausibly observe a real closure — this is the
  closest available substitute for the true end-to-end proof that neither
  `test.marley.local`'s synthetic fixtures nor `marley.local`'s
  currently-empty `Recording` set can provide.
- **This entire section requires a separate, explicit, future approval.**
  Nothing here is authorized by anything decided in this Phase 4
  checklist. Re-verify every fact in the "what's genuinely available"
  table above before acting on this plan, since this repo, this app's
  deploy tooling, and any alerting/monitoring setup may all have changed
  by the time this is actually executed.

### Frappe Cloud deployment considerations (general)

- Frappe Cloud abstracts away direct server/database access the way this
  project has had throughout Phases 3–4 on `marley.local` and
  `test.marley.local` — no `bench execute` shell access, no direct
  `mysql`/`mariadb` queries against the production database from outside
  the platform's own tooling. Every verification step above is phrased as
  a Desk-UI or platform-dashboard action for exactly this reason.
- App updates deploy via the branch Frappe Cloud tracks (per this
  project's `dev → pre → main` policy) — pushing the approved commit is
  necessary but not sufficient; an explicit deploy (automatic or
  dashboard-triggered, depending on how the site is configured) is what
  actually brings the new code and schema online.
- **Never test, audit, or experiment against the real production site**
  (a standing rule for this whole project, unrelated to and independent of
  this specific feature) — every verification step named above is
  something to perform *on* the real site as a deliberate, approved
  production action when the time comes, never as exploratory testing.

---

## Exit verification — all of Phase 4, together

- [ ] **Done**

- [ ] Zero sessions remain `Recording` from Step 2's original frozen set
      (barring any that a physician's own Stop legitimately closed in the
      interim — accounted for, not silently ignored).
- [ ] Every `backfilled` row's `ended_at` is evidence-derived, spot-checked
      against its own segments (or `started_at` for zero-segment rows) —
      never `now()`-adjacent.
- [ ] The one-time migration is idempotent — re-running it changes nothing.
- [ ] The hard-cap sweep is live on `marley.local`, gated by
      `enable_orphan_sweep`, and has been observed to correctly skip a
      session still within its TTL.
- [ ] No transcript segment was modified anywhere in Phase 4.
- [ ] `marley.local` total session count and total segment count unchanged
      from pre-Phase-4 (146 / 14,187, or whatever Step 2's fresh re-audit
      recorded as the true starting point).
- [ ] Nothing staged or committed without a separate, explicit approval —
      same rule as every prior phase.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | **Step 7 executed on `marley.local` — all 7 numbered Phase 4 steps now complete.** Fresh backup taken first; schema landed (`hard_cap`, `enable_orphan_sweep`) via the same scoped techniques as Step 6; flag enabled via scoped `set_value`; one deterministic tick run with zero exceptions and zero mutations (0 currently-`Recording` sessions, exactly as the design predicted); `Version` count unchanged confirms zero documents touched, not just zero status changes; 43/43 regression tests pass. Only the combined exit verification and the separate, still-unapproved Frappe Cloud rollout plan remain |
| 1.9 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Step 7 DESIGN ONLY — retitled from the misleading "Production/local verification" (`marley.local` is not production); full HOW/PRECONDITIONS rewritten with an honest limit stated (0 current `Recording` sessions on `marley.local`, so this step can prove clean no-op behavior but not a real closure). Added a genuinely separate "Beyond Phase 4 — Frappe Cloud Production Rollout Plan" section covering schema migration, feature-flag enablement, scheduler verification, a three-layer rollback plan, monitoring, safety checks, and deployment considerations — explicitly grounded in a verified fact check (no Sentry, no backend deploy CI, no existing alerting convention in this repo) rather than assumed infrastructure. Nothing executed; `marley.local` unchanged |
| 1.8 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Step 6 complete — full 15-case test plan run on `test.marley.local`; schema (`hard_cap`, `enable_orphan_sweep`) landed there only via the established scoped-patch/reload-doctype techniques; flag enabled via `frappe.db.set_value` after a full `doc.save()` hit an unrelated pre-existing `MandatoryError`, then returned to OFF after testing. Three test-harness bugs found and fixed (boundary clock drift, wrong Version-count assumption, a test-setup-not-committed issue that let a correct production rollback wipe uncommitted fixtures) — all root-caused to the test script, none to `tasks.py`. All 43 regression tests still pass; `marley.local` confirmed completely unaffected |
| 1.7 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Step 5 implemented — finalization approach and `ended_at` rule approved; `tasks.py` (new), `hooks.py` scheduler registration, `close_reason=hard_cap`, `AI Settings.enable_orphan_sweep` all landed. Found and fixed a real bug before landing: `get_single_value` throws when a field isn't in live meta yet, which every site currently is — replaced with a direct `Singles` table read, verified empirically safe on `test.marley.local` (clean no-op) and by read-only precondition check on `marley.local`. Neither site's schema touched; 43/43 regression tests still pass; `ruff` clean |
| 1.6 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 5 DESIGN ONLY — three previously-open decisions resolved (`close_reason=hard_cap`, `enable_orphan_sweep` feature flag default off, 15-minute cron cadence); full A–L design analysis added (scheduler architecture verified against Frappe's own scheduler source, target query, finalization mechanism comparison recommending a dedicated internal function over `stop_session()`, `ended_at` rule, concurrency/idempotency/failure-isolation/scale/observability analysis, 15-case test plan, rollout sequence); corrected stale "needs a decision" phrasing left over from the original v1.0 draft now that those items are resolved. No code, schema, or scheduler configuration implemented |
| 1.5 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 4 complete — all 17 post-migration/regression checks pass read-only: counts, the 134 `backfilled` rows individually correct, the original 12 pre-Phase-4 `Stopped` sessions provably untouched, Phase 3's four active-session invariants still hold, 43/43 regression tests pass on `test.marley.local`, scheduler config confirmed unchanged. Zero database, DocType, or code modification this step |
| 1.4 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 3 complete — 134-session historical orphan recovery performed on `marley.local` via `doc.save()` only, one row at a time, fully pre/post guarded; `ended_at` set explicitly before save to prevent `_stamp_timing()` from fabricating `now()`; `active_key` cleared automatically by Phase 3's existing controller logic, never touched directly; all 11 post-migration assertions pass (`Recording`=0, `Stopped`=146, totals unchanged, zero mismatches, zero out-of-scope modifications, `Version` count +134 exactly) |
| 1.3 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 2 complete — read-only re-audit; exact 134-session migration set frozen and fully recorded (name, encounter, patient, session_user, started_at, consent, current/calculated ended_at, calculated close_reason, segment count); hard-cap rule confirmed (TTL=65 min via `_ttl_for_session`'s grace formula); all 134 confirmed past the cap, 0 within it; frozen set diffed byte-for-byte identical against Phase 3's own 134-row list — zero drift; no row/schema/scheduler change |
| 1.2 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 1 complete — `backfilled` close_reason option landed on `marley.local` via a scoped DocField-only metadata patch (same technique as Phase 3's `duplicate_resolved`); Frappe's validation acceptance proven via an unsaved in-memory probe on a real terminal session; zero rows touched, proven via byte-identical `MAX(modified)` timestamps on both `AI Encounter Session` and `AI Transcript Segment` before/after; `active_key` schema and scheduler config (`hooks.py` MD5, absence of `tasks.py`) confirmed unchanged |
| 1.1 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 0 complete — fresh `marley.local` backup taken and fully verified (filename, size, gzip integrity, table coverage, row-count cross-check against the dump's own tuples); live counts unchanged before/after (146/14,187/134/12) |
| 1.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Initial draft — checklist form of Phase 4 (orphan session recovery), re-verified against live `marley.local` state rather than the design doc's stale §8.1 numbers; identified `idle_timeout_seconds` as a dead, dangerous-if-used scaffold field; corrected the hard-cap threshold to include the TTL grace period (65 min, not 60); confirmed no scheduler infrastructure exists in this app yet; flagged three decisions (ongoing sweep's close_reason, feature-gate, frequency) for explicit approval before Step 5 implementation |
