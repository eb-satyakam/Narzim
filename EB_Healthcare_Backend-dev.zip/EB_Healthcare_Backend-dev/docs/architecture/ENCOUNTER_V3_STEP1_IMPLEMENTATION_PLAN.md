# Encounter V3 — Step 1 (Capture): design and implementation plan

**Doc status:** record · **Created:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.4

> **Frozen as evidence on 2026-09-01.** The current description of the encounter
> screen is [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md). This document is kept for
> how Step 1 (Capture) was built — consent, the session state machine, duplicate prevention, orphan recovery and transcript persistence.
>
> It is a dated snapshot, so it is expected to fall out of date and is never
> "corrected" (CLAUDE.md §9). Four `living` documents were describing the same
> screen, which is what made the set unreadable; only one describes it now.

Design of record for the ambient-capture screen and its session lifecycle, with
phased implementation behind verification gates.

- **Audit this is built on:** [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md)
- **Decision record:** [ADR-050](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md)
- **Compliance posture:** [`compliance/HIPAA_READINESS.md`](../compliance/HIPAA_READINESS.md) §4
- **Research trail:** [`ENCOUNTER_UX_RESEARCH.md`](ENCOUNTER_UX_RESEARCH.md)

Every figure was read from the running `marley.local` site on 2026-08-26.
Nothing was measured against production.

**Labels:** **VERIFIED** (read from code or DB) · **UNVERIFIED** (believed, not
proven) · **GAP** · **CONTRADICTION** (documentation disagrees with code).

**We do not claim this system is HIPAA compliant.** Jurisdiction is Mexico
(LFPDPPP · NOM-024-SSA3-2010, ADR-007/ADR-018). HIPAA Security Rule concepts are
used here as an engineering benchmark only.

---

## 1. Executive summary

**What Step 1 does.** Asks for consent, then records the consultation. Audio
streams from the browser directly to Deepgram; text comes back and is stored as
`AI Transcript Segment` rows against an `AI Encounter Session`. It also offers an
**offline path** that skips capture entirely and goes straight to the encounter
form.

```
Doctor ─► Consent gate ─► mic ─► [browser] ══TLS══► Deepgram
                                      │                 │
                                      │            transcript text
                                      ▼                 ▼
                          AI Encounter Session ◄── AI Transcript Segment
                                      │                 │
                                      └── on encounter submit ──► AI Encounter Record
```

**Already correct** (do not break): V3's consent gate — one code path to
`start()`, and it is a click; the audio boundary; document-level server-side
authorization; append-only idempotent transcript writes; token minting before the
state transition; the offline path.

**Broken:** 141 of 144 sessions stuck in `Recording`; a duplicate-session race;
pause and mute invisible to the record; a third undeclared transcript copy in
`tabVersion`; `read` permission authorizing PHI writes; the UI able to imply
saved transcript that was lost.

**What we are fixing** — phases in §20. Phase 1 (truthful UI + consent) is
**complete**; Phase 2 (provider-failure safety) is **written but unverified**.

**Out of scope** — §23.

---

## 2. Current system architecture

### 2.1 Flow, as built — VERIFIED

```
/encounters/[id]/page.tsx
  │  NEXT_PUBLIC_FEATURE_ENCOUNTER_V2 (build-time module constant)
  ├─ false ─► EncounterV1Page ─► EncounterScreen ─► CopilotHost ─► CopilotPanel
  │                                                 (consent gate restored 2026-08-26)
  └─ true  ─► EncounterV3Route ─► EncounterFlowV3 ─► CaptureStep
                                        │
                                  use-recording.ts
                                   grant()  ← the ONLY caller of start()
                                        │
                                  useCopilot ─► RealCopilotProvider
                                        │
     1. getUserMedia                    :225   ← BEFORE any session exists
     2. POST /api/ai/session            :239   ─► sessions.start_session
     3. new WebSocket → Deepgram        :495   ← audio leaves here, direct
     4. MediaRecorder 250 ms chunks     :475
                                        │
     transcript back over the same socket
        ├─ POST /api/ai/session/segments        ─► segments.append_segment
        └─ POST /api/ai/session/sync-transcript ─► segments.sync_transcript  (20 s)
```

### 2.2 Responsibilities

| Layer | Owns |
|---|---|
| **Browser** | Microphone, `MediaRecorder`/PCM worklet, the Deepgram socket, pause/mute (client-only), sequence-number assignment, the 20 s autosave timer, token rotation, `pagehide` beacon |
| **Frontend (Next.js)** | Consent UI and gate, BFF route handlers under `/api/ai/*`, no PHI persistence of its own except V1's `localStorage` draft (GAP-13) |
| **Backend (Frappe)** | Session lifecycle and state machine, consent gate enforcement, Deepgram token minting, transcript persistence and idempotency, authorization |
| **Database** | `AI Encounter Session` (state), `AI Transcript Segment` (authoritative transcript), `AI Encounter Record` (derived archive), `tabVersion` (change history) |
| **Deepgram** | Speech-to-text. Receives audio; returns text |

### 2.3 What does NOT happen — VERIFIED

- **Raw audio is not persisted by Remedisys.** `new WebSocket` appears once and
  targets Deepgram. No audio upload endpoint, no blob field, no file write, no
  object storage, no audio in `localStorage`/`IndexedDB`/cookies.
  `retain_audio = 0`, `audio_retention_days = 0`.
- **The Deepgram API key never reaches the browser** — `mint_session_token` reads
  `frappe.conf` server-side and returns a short-lived scoped token.
- **No patient identifier is sent to Deepgram in the request params** (model,
  language, punctuate, numerals, endpointing, diarize/multichannel, `keyterm` =
  the clinic's drug catalogue).
- **No transcript text in logs or analytics** on the capture path — `:912` is
  annotated *"Counts only — no transcript text (Rule 10)"*.
- **No automatic recording** on either surface, as of 2026-08-26.
- **No reconnect.** A dead socket is not reopened.
- **No purge.** Nothing deletes transcript.

---

## 3. Data model

| DocType | Purpose | PHI | Transcript | Authoritative |
|---|---|---|---|---|
| `AI Encounter Session` | One capture session; state machine, consent, timing | Indirect (links patient) | No | Yes, for session state |
| `AI Transcript Segment` | One spoken line | **Yes** | **Yes** | **Yes — the source of truth** |
| `AI Encounter Record` | Per-encounter archive + cost rollup, written on submit | **Yes** | **Derived copy** (`transcript_json`) | No |
| `AI SOAP Draft` | Generated SOAP, versioned | Yes | No (holds suggestions) | Yes, for a draft. **0 rows** |
| `Patient Encounter` (core) | The clinical record | **Yes** | No | Yes, clinically |
| `tabVersion` (core Frappe) | Change history | **Yes** | **Incidental copy** | No |

**Key fields.** Session: `encounter`, `patient`, `practitioner`, `session_user`,
`status`, `close_reason`, `consent_obtained`, `consent_obtained_at`, `started_at`,
`ended_at`, `duration_seconds`, `deepgram_model`, `llm_model`, `audio_retained`,
`error_code`, `error_message`. Segment: `session`, `encounter`,
`sequence_number`, `speaker` (doctor|patient|unknown|system), `speaker_label`,
`is_final`, `text`, `start_ms`, `end_ms`, `confidence`, `deepgram_segment_id`.

`track_changes = 1` on all four AI doctypes — VERIFIED.

### 3.1 Transcript data lineage — three copies inside Remedisys

```
Spoken audio (transient, never persisted by us)
      │
      ▼
  Deepgram  ── vendor boundary (§17)
      │  text
      ▼
┌─────────────────────────────────┐
│ AI Transcript Segment           │  AUTHORITATIVE · 14,187 rows
│ append-only · track_changes=1   │  live write path
└───────┬─────────────────┬───────┘
        │                 │
        │ on Patient      │ on any UPDATE
        │ Encounter       │ (speaker correction,
        │ submit          │  sync_transcript)
        ▼                 ▼
┌──────────────────┐  ┌──────────────────────────────┐
│ AI Encounter     │  │ tabVersion                   │
│ Record           │  │ **UNDECLARED COPY**          │
│ .transcript_json │  │ 53 of 81 rows contain `text` │
│ DERIVED · 82 rows│  │ old AND new value verbatim   │
│ bounded 5000 segs│  │ core table, no classification│
└──────────────────┘  └──────────────────────────────┘
```

**Copy 3 is the finding that matters.** `services/encounter_ai_record.py`'s
docstring already names copy 2 and its consequences — *"the copy is not covered
by `ComplianceProfile.transcript_retention_days`… A data-subject erasure request
has to reach this row as well."* **Nothing names copy 3.** It grows with every
speaker correction and is reachable by no erasure path.

Also in transit, not stored as transcript: LLM prompts (2,441 `AI Prompt Log`
rows; `raw_response` is **empty for every encounter/copilot purpose** — VERIFIED).

---

## 4. Security / HIPAA engineering model

Technical controls only. Organizational and vendor items are separated in §17
and §24.

| Concept | Current | Gap | Target | Implementation |
|---|---|---|---|---|
| **Access control** (§164.312(a)) | `frappe.has_permission("Patient Encounter", "read", doc=…)` on every session/segment endpoint — real, doc-level, server-side | **`read` authorizes a PHI write**; `stop_session` does not check session ownership | Write operations require write permission; stop requires ownership or an admin capability | Phase 7 |
| **Audit controls** (§164.312(b)) | `track_changes` on 4 doctypes; 147 session + 81 segment versions | Cannot reconstruct stop (141/144), pause, mute, or failure. `Failed`/`Closed` have no producer | Every lifecycle event reconstructable | Phases 4, 6 |
| **Integrity** (§164.312(c)) | Append-only segments; idempotent on `(session, sequence_number)`; sealed sessions reject writes | Persistence failures are swallowed; UI can imply saved | No silent loss; watermark surfaced | Phase 5 |
| **Authentication** | Bearer JWT (`eb_frappe_jwt`); no `allow_guest` | — | Unchanged | — |
| **Transmission security** (§164.312(e)) | Browser→Deepgram TLS; key server-side; short-lived scoped token | Vendor terms unverified | Unchanged technically | §17 (non-code) |
| **Workstation / browser** | V3 stores no PHI client-side | **V1 writes the full `enc` draft to `localStorage`.** A commit removing it exists in the frontend **working tree only** — it is NOT on `dev`, so read this row as still true of the deployed screen | Clinical PHI server-side only | Phase 7 |
| **Retention / disposal** | Nothing deletes transcript | Two contradictory declared values, both inert; 3 copies; no erasure path | Indefinite **by decision**, with an erasure *mechanism* that exists | Phase 7 + a separate ADR |
| **Vendor boundary** | Audio to Deepgram; no identifiers in params | Retention/contract unknown to code | Unchanged technically | §17 |

---

## 5. Consent design

### 5.1 Target flow — matches current V3 code

```
Encounter opens
   └─► GET active session (READ ONLY — creates nothing, grants nothing)
   └─► Consent gate rendered; mic control disabled and says why
          │
    ┌─────┴──────┐
"They agreed"  "They declined"
    │               └─► local state only. No mic. No session. No Deepgram.
    ▼
 getUserMedia                     ← fails here ⇒ no session, no consent record
    ▼
 start_session(consent_obtained=1)
    ├─ mint Deepgram token FIRST  ← fails here ⇒ session stays Draft
    └─ Draft → Recording, stamp consent_obtained_at + started_at
    ▼
 Deepgram socket ─► Recording
```

### 5.2 Invariants

| ID | Invariant | Status |
|---|---|---|
| **C1** | No `AI Encounter Session` may enter `Recording` without `consent_obtained` | **VERIFIED, enforced server-side** in `_validate_consent_gate` |
| **C2** | No microphone capture before consent | **VERIFIED** — `getUserMedia` is reached only from `grant()`; tested, `__micAsked = false` on page load |
| **C3** | No Deepgram audio before consent | **VERIFIED** — the socket opens inside `start()` only |
| **C4** | Declining creates no session | **VERIFIED** — tested, 0 `start_session` calls |
| **C5** | An existing session is never treated as consent | **VERIFIED** — `consent` is written in exactly one place, `grant()` |
| **C6** | Page load performs no write | **VERIFIED** — only `get_active_session`, a read |

**Challenge to the ordering.** C2 as stated ("no mic before consent") is
satisfied, but note the *actual* order inside `grant()` is **mic first, session
second**. That is deliberate and correct: a denied microphone throws before any
`consent_obtained = 1` is written, so a failed start cannot leave a false consent
record. **Do not "fix" this ordering** — reversing it would create exactly the
artefact we are trying to eliminate. The 13 sessions with `consent_obtained = 1`
and zero segments show what a consent record with nothing behind it looks like.

---

## 6. Recording session state machine

### 6.1 Why session state and connection state are separate

Session state is **durable and server-owned**. Connection state is **ephemeral
and browser-owned** — the server never observes the Deepgram socket, because the
socket is browser-to-vendor (ADR-009). Conflating them produced the current
defect: the socket dying is treated as a session event by the UI (error banner)
and as a non-event by the database.

```
SESSION   Draft ─► Recording ─► Stopped ─► Closed        (server, durable)
                       └─────► Failed  ─► Closed
CONNECTION  Connected ⇄ Reconnecting ─► Disconnected     (browser, ephemeral)
```

### 6.2 Transition table

`_ALLOWED_TRANSITIONS` (VERIFIED): `Draft: {Recording, Closed}` ·
`Recording: {Stopped, Failed}` · `Stopped: {Closed}` · `Failed: {Closed}` ·
`Closed: {}`.

| From | Event | To | Server action | Client action | Audit event |
|---|---|---|---|---|---|
| — | first `start_session` (no consent) | `Draft` | insert | — | `owner`, `creation` |
| `Draft` | consent granted | `Recording` | stamp `consent_obtained` + `_at`, `started_at`; mint token first | open socket, start recorder | `consent_obtained_at` |
| `Draft` | token mint fails | `Draft` | throw; no transition | show "AI unavailable" | — |
| — | mic denied | *no session* | none (never called) | throw | — |
| `Recording` | physician Stop | `Stopped` | `close_reason=physician_stop`, `ended_at`, `duration_seconds` | flush → sync → stop | timing fields |
| `Recording` | tab close / navigate | `Stopped` | `close_reason=system_close` | `sendBeacon` | timing fields |
| `Recording` | **Deepgram/socket failure** | `Failed`* | `close_reason=error` | flush → sync → stop, teardown mic | timing + reason |
| `Recording` | pause / resume | `Recording` (unchanged) | none | gate audio, KeepAlive | **`system` segment (Phase 6)** |
| `Recording` | mute / unmute | `Recording` (unchanged) | none | `track.enabled` | **`system` segment (Phase 6)** |
| `Recording` | browser crash / laptop off / network loss | `Stopped`/`Failed` | **sweep or hard cap (Phase 4)** | none possible | `close_reason` |
| `Recording` | server request fails | `Recording` | — | error shown | **sweep is the only backstop** |
| `Stopped`/`Failed` | admin close | `Closed` | — | — | Version row |

\* Phase 2 currently sends `close_reason=error` while the doctype transition
lands on `Stopped`. **Decision needed:** either target `Failed` (semantically
right — the session did fail) or keep `Stopped` + `close_reason=error`. See §24
Q3.

### 6.3 Paused is NOT a session state — justified

The current system accepts transcript writes **only** while `status = Recording`:
`append_segment` returns `{"status": "sealed"}` and the browser drops the segment
otherwise (VERIFIED). A `Paused` status would therefore make every late final
arriving during a pause **silently discarded**. That is a data-loss path
introduced to record information that a `system` segment records for free.

**Confirmed: do not add a `Paused` session state.**

---

## 7. Session ownership / duplicate prevention

### 7.1 The race — VERIFIED

```
Request A: get_value(active session for encounter+user) → None ┐
Request B: get_value(active session for encounter+user) → None ┘ both pass
Request A: doc.insert() → AIES-…144
Request B: doc.insert() → AIES-…145      ← no constraint stops it
```

`_get_or_create_draft` (`api/ai/sessions.py:227-241`) is a non-atomic
read-then-insert. `SHOW INDEX` confirms **no unique constraint**. Four confirmed
pairs, same `session_user`, **63–160 ms apart**:

```
00146: 23:32:59.521920 / .680352 (158 ms)   00149: 13:47:39.549967 / .662988 (113 ms)
00147: 03:29:22.743905 / .871631 (128 ms)   00151: 09:49:51.476956 / .540169 ( 63 ms)
```

Trigger: `CopilotHost`'s auto-start re-armed `startedRef` on teardown to survive
a StrictMode mount→unmount→remount, producing two `start()` calls milliseconds
apart. **That effect was deleted in Phase 1**, so the *observed* trigger is gone —
but the race is still reachable from two tabs, a retried request, or two devices.

**CONTRADICTION.** `sessions.py`'s docstring says it *"Refuses to create a second
active session for the same (encounter, logged-in user)"*. **The code is
authoritative: it does not.** The docstring must be corrected or the code made
true. This plan makes the code true.

### 7.2 Frappe / MariaDB behaviour — VERIFIED, and this corrects an earlier warning

I previously warned that a unique index over a field cleared to `''` would break
`Stop`, and that warning was carried into the phase instructions. **Reading
Frappe's source shows it is wrong for `unique` fields specifically.**

`frappe/model/base_document.py::get_valid_dict`:

```python
elif (fieldtype in datetime_fields and value == "") or (
    getattr(df, "unique", False) and cstr(value).strip() == ""
):
    value = None
```

Frappe **deliberately converts an empty value to `None` when the docfield is
marked `unique`** — exactly to avoid the empty-string collision. And
`frappe/database/mariadb/schema.py:85` emits
`ADD UNIQUE INDEX IF NOT EXISTS <fieldname>`. MariaDB permits multiple `NULL`s in
a UNIQUE index.

**How inactive sessions avoid violating the unique constraint:** on every
terminal transition the controller sets `active_key = None`; Frappe writes SQL
`NULL` (either directly, or via the coercion above if it is ever set to `""`);
MariaDB allows unlimited `NULL` rows in the unique index. Any number of
`Stopped`/`Failed`/`Closed` sessions can coexist on one encounter.

**Two conditions, both mandatory, or the guarantee silently fails:**

1. The docfield **must** carry `unique: 1` in the doctype JSON. The coercion is
   keyed on `df.unique`. Adding a unique index via a raw patch *without* setting
   the docfield property leaves the coercion off and reinstates the original bug.
2. The docfield **must not** be `not_nullable`. That branch replaces `None` with
   a non-null default (`get_not_null_defaults`), which would collide.

Both must be asserted by a test that reads SQL directly: `SELECT COUNT(*) …
WHERE status != 'Recording' AND active_key IS NOT NULL` must be `0`.

### 7.3 Target invariant — APPROVED 2026-08-26

| ID | Invariant |
|---|---|
| **S1** | At most one `AI Encounter Session` per encounter may be non-terminal |
| **S2** | The constraint is enforced by the database, not by the caller |
| **S3** | A concurrent loser **reattaches**; it never surfaces an error |
| **S4** | Every terminal transition clears `active_key` to SQL `NULL` |

**Key is `encounter` alone, not `encounter + session_user`.** VERIFIED reason:
`HLC-ENC-2026-00002` and `00053` each have sessions from **two different users**,
both `Recording`. Keying on user makes that legal. One consultation, one capture.

**Structural reason this is guaranteed to recur, not just a data coincidence:**
ADR-039 lets *any* practitioner sign an encounter, not only the one originally
assigned — a covering physician finishing a colleague's note is a designed
workflow here. "A different clinician opens an encounter someone else already
started recording on" is therefore a first-class scenario this product's own
continuity-of-care model produces, not an edge case to defend against.

**Field spec, exact and non-negotiable — every property below is required or the
NULL guarantee in §7.2 silently fails:**

| Property | Value | Why it's mandatory |
|---|---|---|
| `fieldtype` | `Data` | Not `Link` — a second `Link` to `Patient Encounter` would double the rename/delete-cascade checks `encounter` already performs, and would pick up an unwanted second ordinary index if `search_index` is set by convention |
| `unique` | `1` | **This is what makes Frappe write SQL `NULL` instead of `''` for a cleared value** (§7.2). A unique index added by raw SQL *without* this DocType property does not get the coercion and silently reinstates the bug it was meant to fix |
| `not_nullable` | unset / `0` | If set, `get_valid_dict` replaces `None` with a non-null default instead of writing `NULL`, which collides |
| `read_only` | `1` | Server-set only, per §7.5 below — no caller sets this field directly |

### 7.4 Existing duplicates must be cleaned first — scope and rule, APPROVED

Adding the index while the 6 live duplicate-active groups exist will **fail at
index creation**. Order is not negotiable: inventory → decide authoritative →
clean → backfill → constrain (full order in §21).

**Six groups, twelve active rows, confirmed by direct query — not the four
originally suspected.** Two distinct causes, both closed by the same fix:

| Encounter | Cause | Gap between the pair |
|---|---|---|
| `00146`, `00147`, `00149`, `00151` | Client race (StrictMode double-mount — trigger removed in Phase 1) | 63–160 ms, **same user** |
| `00002`, `00053` | Cross-clinician gap in the old `encounter + session_user` lookup | 1 day and 24 days, **different users** |

**Deterministic cleanup rule, APPROVED:**
1. Exactly one side has transcript segments → keep it, close the other.
2. Both sides have meaningful transcript data → **do not auto-resolve** — manual
   review, and this plan has not encountered a case that meets this bar.
3. Neither side has any transcript data → use creation timestamp / other
   lifecycle evidence, and flag if still ambiguous.
4. **Never delete either session.** The loser is closed, never removed —
   deleting a session row would orphan any segment still pointing at it.

**Resolution table, all six groups, APPROVED — including `00149`:**

| Encounter | Keep | Close | Evidence |
|---|---|---|---|
| `00002` | AIES-00002 | AIES-00004 | 3 segments vs 0 |
| `00053` | AIES-00049 | AIES-00143 | 264 segments vs 0 |
| `00146` | AIES-00134 | AIES-00133 | 38 segments vs 0 |
| `00147` | AIES-00136 | AIES-00135 | 18 segments vs 0 |
| `00149` | AIES-00138 | AIES-00137 | **1 segment vs 0 — auto-resolved under rule 1** (exactly one side has any segments; this is not the "both meaningful" case rule 2 exists for) |
| `00151` | AIES-00145 | AIES-00144 | 27 segments vs 0 |

`00149` is **not held for a separate manual-approval gate** — holding it would
block the unique index for all six groups over a row whose loser has zero
segments regardless of the call. It is auto-resolved under the same rule as the
other five, with a distinct note attached to the record of the decision:
*"single-segment margin, reviewed post-hoc."*

**`close_reason` for every row closed by this migration: `duplicate_resolved` —
APPROVED, a new value, not a reuse of `system_close`.** `system_close` already
means "the unload beacon ended this session cleanly"; reusing it for
"administratively closed because it was a duplicate" would make both facts
unrecoverable from the same value six months later, in a document that is a
clinical-adjacent record. Adding this value is a DocType Select-options change —
proposed here, **not made** in this turn.

### 7.5 Controller enforcement — APPROVED design

`active_key` is set and cleared **inside `validate()`**, not left to any
caller (`sessions.py`, a future Phase 4 sweep, or an admin action) to remember:

```python
def _stamp_active_key(self) -> None:
    if self.status in _ACTIVE_STATUSES:      # {"Draft", "Recording"} — same set
        self.active_key = self.encounter     # already used to gate get_active_session
    else:
        self.active_key = None
```

called from `validate()` alongside the existing `_stamp_timing`/`_stamp_consent`.
This covers every transition in §6.2 without any call site needing to touch the
field directly — consistent with `read_only: 1` in the field spec above.

### 7.6 Server-side race handling — APPROVED design

`_get_or_create_draft` becomes:

```python
def _get_or_create_draft(encounter, user):
    existing = frappe.db.get_value(
        "AI Encounter Session",
        filters={"encounter": encounter, "status": ("in", list(_ACTIVE_STATUSES))},
        fieldname="name",
    )  # encounter-scoped — no session_user in the filter (§7.3)
    if existing:
        return frappe.get_doc("AI Encounter Session", existing), "reattached"

    doc = frappe.get_doc({"doctype": "AI Encounter Session",
                           "encounter": encounter, "session_user": user})
    savepoint = f"ai_session_{frappe.generate_hash(length=8)}"
    frappe.db.savepoint(savepoint)
    try:
        doc.insert(ignore_permissions=False)
        return doc, "created"
    except frappe.UniqueValidationError as e:
        cause = e.args[-1] if e.args else None
        if not (cause and "active_key" in str(cause)):
            raise                                   # a DIFFERENT constraint — must surface
        frappe.db.rollback(save_point=savepoint)
        winner = frappe.db.get_value(
            "AI Encounter Session",
            filters={"encounter": encounter, "status": ("in", list(_ACTIVE_STATUSES))},
            fieldname="name",
        )
        if not winner:
            raise                                   # defensive — should be impossible
        return frappe.get_doc("AI Encounter Session", winner), "reattached"
```

**Not invented.** The savepoint pattern is Frappe's own established idiom for
this exact situation — `core/doctype/scheduled_job_type/scheduled_job_type.py`
does the identical `savepoint` → `insert` → `except UniqueValidationError` →
`rollback(save_point=...)` sequence. The key-name check works because
`mariadb/schema.py` names the unique index after the field itself, so the
string `"active_key"` appears in the raw MariaDB duplicate-entry error —
checked, not assumed.

**APPROVED: only this specific constraint is converted to a reattach.** Any
other `UniqueValidationError` (there is none today, but a future field could add
one) re-raises unchanged and surfaces as a real error — never silently absorbed.

**Deployment order — APPROVED, and this reverses the literally-dictated 8-then-9
order:** the code above must be live **before** the unique index exists. With no
constraint yet, `except frappe.UniqueValidationError` simply never fires — the
new code is inert, not risky, to ship first. Reversing the order (index first,
handler second) creates a real window where a genuine race produces a raw,
unhandled database error in front of a clinician — precisely the failure this
whole phase exists to prevent.

**API response — additive, non-breaking:** `start_session` returns one new
field, `reattached: bool`, alongside the unchanged `name/status/channel/deepgram`.
Old callers ignoring it are unaffected.

**Realtime — APPROVED, matching an existing pattern rather than inventing one.**
`stop_session` already calls `publish_to_encounter(event="session.stopped", ...)`
so a second open tab updates without polling. The reattach path publishes
`session.reattached` the same way, so the tab whose insert lost the race can
update live instead of only finding out on a manual refresh — the same
mechanism, applied to the new outcome.

### 7.7 Tracked follow-up, not a Phase 3 blocker — cross-clinician stop authorization

**APPROVED as a documented P1, explicitly not fixed in this phase.** Phase 3
makes "Dr. B reattaches to Dr. A's session" a *designed*, routine outcome rather
than an accidental one. `session_user` stays whichever clinician created the
row — read-only, set once, unchanged by reattachment. §14 already found that
`stop_session` performs no ownership check: any user who can read the encounter
can stop *any* session on it, regardless of `session_user`. That gap existed
before Phase 3 and is not made larger by it — but it stops being a rare
accident and becomes the routine shape of the "two clinicians, one encounter"
story the moment this ships, which is why it now needs an answer rather than
staying theoretical. Tracked in §14's target row and in the Phase 3 gate (§21);
**Phase 3 does not weaken or touch existing authorization to ship this design.**

---

## 8. Orphan session recovery

### 8.1 Current state — VERIFIED, do not modify yet

141 `Recording` · 3 `Stopped` · 0 `Draft`/`Failed`/`Closed`. All 144 have
`started_at`; 141 have no `ended_at`; **3** have a duration. Oldest open
2026-07-25 07:38:22; newest 2026-08-26 09:49:53. 13,699 of 14,187 segments belong
to open sessions.

| Bucket | Sessions |
|---|---|
| abandoned > 7 days | 125 |
| stale < 7 days | 1 |
| stale < 1 day | 2 |
| never received a segment | 13 |
| **active < 15 min** | **0** |

### 8.2 Truthful audit semantics — the central constraint

We must not fabricate history. The distinction the audit trail has to carry:

| Claim | When we may make it | Evidence |
|---|---|---|
| "Recording stopped at T" | Only when something observed the stop | `physician_stop`, or `system_close` from the beacon |
| "Recording was last observed at T; we closed it administratively" | The orphan case — **this is all we know** | last segment `creation`/`end_ms` |

`ended_at` must therefore be **evidence-derived, never `now()`**:

```
ended_at = MAX(segment.creation) for that session          ← last observed activity
        └─ if the session has no segments: started_at      ← duration 0, which is TRUE
```

For a session that started 2026-07-25, `now()` would invent a month of recording.

`close_reason`: the Select permits `physician_stop | idle_timeout | error |
system_close` only. **None of these means "closed by administrative backfill".**
Two honest options:

- **(a)** `system_close` + the administrative nature recorded in the Version
  comment the migration writes. No schema change; slightly imprecise.
- **(b)** Add a `backfilled` option in the same patch. Precise; a schema change.

**Recommendation: (b).** A one-off event that touches 141 clinical-adjacent rows
should be labelled for what it was, and "system_close" already means something
else (the unload beacon). Guessing later which `system_close` rows were real is
exactly the ambiguity this plan exists to remove.

**Transcript preservation:** the migration touches only session rows. No segment
is modified or deleted. Segments remain linked and readable.

**Mechanism:** through `doc.save()`, not raw SQL — so `_validate_transition`
proves each transition is legal, `_stamp_timing` computes duration the same way
every future session will, and 141 `tabVersion` rows make the backfill itself
auditable. Raw SQL would silently mutate 141 rows with no trail, which is the
opposite of the goal. Idempotent: a re-run must find nothing.

---

## 9. Hard cap / idle / heartbeat

### 9.1 Transcript inactivity ≠ recording inactivity

A twenty-minute silent examination produces no segments and is a normal
consultation. **Closing on transcript inactivity would end a live session**, and
the consequence is worse than a wrong status: `append_segment` rejects writes to a
non-`Recording` session, so **everything said afterwards is silently discarded**.

**Rule: transcript inactivity may never, on its own, be treated as proof that
recording stopped.**

### 9.2 Options assessed

| Signal | What it actually proves | Verdict |
|---|---|---|
| **Hard cap** `started_at + max_session_minutes` | The Deepgram token TTL is derived from this setting, so past it the session **cannot** be validly recording | **Implement first.** No new field, no client cooperation, cannot close a live session |
| **Heartbeat → `last_activity_at`** | A browser is still attached and capturing | **The correct primary signal.** Defer to Phase 9 — needs a field, an endpoint and a client timer |
| Segment arrival bumping `last_activity_at` | Someone is talking | Useful **secondary**, free once the field exists |
| Connection state | Nothing server-side — the server cannot see the socket | **Not usable as a server signal** |
| `pagehide` beacon | A clean exit | Already implemented; covers 1 of ~6 paths |

### 9.3 Step 1 now vs deferred

- **Now (Phase 4):** hard cap sweep + the one-time migration. Together these
  close 100% of today's orphans with zero risk of ending a live consultation.
- **Deferred (Phase 9):** heartbeat, `last_activity_at`, and only then a tighter
  idle window.

This inverts an earlier recommendation of mine (generous idle threshold first).
The reason is §9.1: an idle rule can end a live session; a hard cap cannot.

---

## 10. Transcript persistence

### 10.1 Current — VERIFIED

Two paths: `append_segment` per final segment, idempotent on
`(session, sequence_number)`; `sync_transcript` full reconcile every **20 s**
(`AUTOSAVE_INTERVAL_MS = 20000`) and after speaker edits, which normalises, sorts,
drops empty rows and coerces unknown speakers. A segment arriving after a clean
stop returns `sealed` and is dropped — explicit, not an error. Sequence numbers
are **client-assigned**.

Both writes are wrapped in bare `catch {}` — deliberately, under Rule 7
(persistence must not block Stop or the SOAP flow).

### 10.2 The defect: silence extended to the user

Rule 7 correctly says a persistence failure must not block the clinical flow. It
does **not** say the physician should not be told. Today a failed window is
invisible: the UI shows the transcript it holds in memory, not what the server
has. There is precedent in this same file — the comment at `:910` records that
"Fix speakers" 500ing on every call *"looked identical to a working save until the
page was reloaded and the old speakers came back."*

### 10.3 Invariants

| ID | Invariant | Assessment |
|---|---|---|
| **T1** | A session cannot be finalized before the final transcript flush is attempted | **Correct, and already true on both paths.** `stop()` does flush → sync → stop (3a, 3a-ii, 3b), and Phase 2's `_finalizeAfterProviderFailure()` mirrors that order deliberately, because `append_segment` refuses a non-`Recording` session |
| **T2** | Closing the session must not silently discard accepted transcript data | **Correct as worded** — note "accepted". Data never accepted (a failed request during an outage) is *lost*, not discarded, and no ordering fixes that; only reconnect+buffering would, which is Phase 9 |
| **T3** (new) | The UI must never assert "saved". It reports the **persisted watermark**; if the watermark trails at Stop, the physician is told before moving on | Phase 5 |

The information already exists and is thrown away: `sync_transcript` returns
`{updated, created, deleted}` and `real-provider.ts:915` already inspects it.

---

## 11. Pause / mute

| | Pause | Mute |
|---|---|---|
| Mechanism | `pcmPaused` gate, or `recorder.pause()`; KeepAlive started so Deepgram does not drop an idle socket | `track.enabled = false` — track stays live, emits **silence** |
| Audio sent | No | Silence |
| Socket | Open, KeepAlive | Open, billed |
| Segments | None | None |
| Session status | `Recording` (unchanged) | `Recording` (unchanged) |
| In the DB today | **Nothing** | **Nothing** |
| UI today | "Paused" | **No control at all** |

**They are genuinely different mechanisms and identically invisible in the
record** — and both indistinguishable from a quiet room.

**Design:** `system` transcript segments (`capture_paused`, `capture_resumed`,
`capture_muted`, `capture_unmuted`) + a `paused_seconds` Int on the session.
`speaker` already accepts `system` and `append_segment` already validates it, so
the event trail costs **no schema change**; only `paused_seconds` does.

**`duration_seconds = wall-clock − paused_seconds` is correct**, for both audit
and cost: during a pause we send KeepAlive control frames, not audio, so the
vendor bills approximately nothing and wall-clock would overstate spend.

**One interaction to fix in the same phase.** `_collect_asr_usage` falls back to
`MAX(end_ms)` when a session has no duration. `end_ms` is a timeline offset from
session start and therefore **includes** paused time. Once `paused_seconds`
exists, the fallback must subtract it, or the two paths disagree.

**Mute must not ship before the indicator (§19).** A muted session otherwise
looks exactly like a recording session that captured nothing.

---

## 12. Multi-tab / session ownership

Tab B calling `get_active_session` **reattaches to Tab A's session** (the filter
is `encounter + session_user + status in {Draft, Recording}`). Both can then send
segments, and because sequence numbers are client-assigned from each tab's own
count, they overlap — the server's idempotency dedupe on
`(session, sequence_number)` **silently drops the loser**, presenting as missing
transcript rather than an error.

**`active_key` does not solve this.** It prevents a second *session*; it does
nothing about two clients writing to *one* session, and arguably makes collision
likelier by guaranteeing they share one. **Do not let the Phase 3 fix be mistaken
for a Phase 12 fix.**

**Future options:** a session **lease** (owner token issued at `start_session`,
required by `append_segment`, renewed by the heartbeat — shares a prerequisite
with §9, so design them together), or **server-assigned sequence numbers**, which
removes collisions entirely but changes the write contract.

**Not a production blocker** for a single-clinician-per-encounter pilot. It is a
blocker for any workflow where a nurse and a doctor open the same encounter.

---

## 13. Prior session

| Stage | Status |
|---|---|
| Calculated | **Yes** — `use-recording.ts:96`, set when the fetched session is `Recording`/`Draft` |
| Fetched | Yes — from `get_active_session` |
| Passed to UI | **No** |
| Rendered | **No** |

**CONTRADICTION.** `use-recording.ts:95` states the prior session *"is disclosed
in the gate rather than quietly adopted"*. The second half is true; **the first is
false**. Code is authoritative: it is not disclosed.

Note: the dead `ConsentGate` in `recording-ui.tsx` — a second, unrendered consent
implementation — **already contains** the disclosure UI. Reuse its markup; do not
write a third.

**Target UX:** one line inside the consent card — *"A recording session for this
encounter is already open (started 14:32). Continuing will attach to it."*
Consent is still required; the fact is disclosed, never used as consent (C5).

---

## 14. Access control

| Operation | Current check | Correct? |
|---|---|---|
| Session read (`get_active_session`) | `has_permission(Patient Encounter, read, doc)` | **Yes** |
| Transcript read (`get_encounter_transcript`) | same | **Yes** |
| Session create (`start_session`) | same (read) | Debatable — creating a session is a write |
| **Transcript append** (`append_segment`) | same (**read**) | **NO — a read permission authorizes writing PHI** |
| **Transcript sync** (`sync_transcript`) | same (**read**) | **NO — same** |
| **Stop session** (`stop_session`) | read on the encounter, **no ownership check** | **NO — user A can stop user B's session. See below — P1, tracked via §7.7** |

> Can an authenticated but unauthorized clinician read another patient's
> transcript by manipulating IDs?

**No — VERIFIED.** Every endpoint resolves to the encounter and performs a
document-level permission check server-side. `append_segment` resolves
`session → encounter` before checking. No `allow_guest`, no frontend-only gate.

**Target:** read stays `read`; append/sync require `write`; stop requires session
ownership or an explicit administrative capability.

**P1 follow-up, elevated by Phase 3 — APPROVED as tracked, not fixed here.**
This gap predates Phase 3. What changes is its likelihood of mattering: Phase 3
(§7.7) makes "a different clinician than the one who started the session is now
operating it" a *designed*, routine outcome rather than an accident, because the
active-session invariant is now encounter-wide. Phase 3 does not touch or weaken
this authorization path to ship — it is called out here so Phase 7 picks it up
with the right priority, not because Phase 3 needs it resolved first.

---

## 15. Audit model

**Reconstructable today:** who consented and when · who started and when · who
edited transcript / corrected speakers · who signed · model/tokens/cost per LLM
call (with `prompt_hash` populated on 1,252 of 1,270 rows, so the hashing
mechanism works).

**Not reconstructable:** when recording stopped (141/144) · pause · resume · mute ·
unmute · failures (`Failed` and `error_code` have no producer) · duration (3/144) ·
whether consent was genuinely obtained (144/144 say yes; the removed V1 path
proves the field untrustworthy for historical rows).

**Is `track_changes` enough? No — and the reason is structural, not coverage.**
`track_changes` records *state deltas on documents*. Pause, resume, mute,
reconnect and close-by-sweep are **events**: there is no field whose change
represents them, so no amount of change-tracking can capture them.

**Mechanism: `system` transcript segments.** Append-only, timestamped, ordered
with the speech they interleave with, already permission-checked and already
audited — and **no new doctype**, per the standing rule against unnecessary ones.

Boundaries: document state → `tabVersion`; capture events → `system` segments; AI
decisions → the `AI Recommendation Log` that CLAUDE.md cites 7× and **which does
not exist** (out of scope here; §23).

---

## 16. Retention / data lineage

**LOCKED: transcript retained indefinitely. Audio not stored by Remedisys. No
deletion is implemented in this plan.**

**"Indefinite" and "undeletable" are different, and the distinction is the whole
point of this section.** Indefinite = no scheduled expiry. Undeletable = no
mechanism to remove a specific record on request. We are choosing the first. We
must not accidentally ship the second, because `mx.py` declares
`right_to_erasure = True` (LFPDPPP Art. 16 ARCO — *cancelación*) and a right with
no mechanism is a claim we cannot honour.

| Item | Position |
|---|---|
| Authoritative transcript | `AI Transcript Segment` |
| Derived copy | `AI Encounter Record.transcript_json`, written on submit, bounded at 5,000 segments |
| Incidental copy | **`tabVersion`** — undeclared until this document |
| Configured retention | `mx.py` = 90 days · `AI Settings` = 2555 · **both inert** |
| Enforcement | None. No purge function exists; `scheduler_events` commented out |
| UI claim | **None** — removed 2026-08-26 |
| Access control | §14 gaps apply, and matter more the longer data is kept |
| Backup | Frappe Cloud provides backups; no documented tested restore, and no position on how backups interact with a future erasure |
| Future erasure | Must reach **all three** copies. Not implemented |

**Deliverables (Phase 7, documentation-led):** an ADR recording indefinite
retention and superseding `mx.py`'s 90; a single authoritative configuration with
`0`/`null` **explicitly defined in code** to mean no expiry (today `0` means
nothing, and the next engineer could read it as "delete immediately"); a data
classification; and an enumerated erasure path.

---

## 17. Deepgram boundary

```
Browser ──audio, TLS──► Deepgram ──text──► Remedisys
```

**What our code proves:** audio never enters Remedisys; the API key never reaches
the browser; tokens are short-lived and scoped per session; no patient identifier
is in the request params; `retain_audio = 0`.

**What our code does NOT prove:** Deepgram's own retention, its subprocessors, its
contractual terms, or BAA status. No `no_store`-style parameter is sent.

**Precision that matters:** "no identifiers in the params" is not "no PHI to
Deepgram". **The audio itself is PHI** — it contains everything said aloud,
including names. This is the most direct PHI disclosure in the product.

**Therefore the UI must say "not stored by Remedisys", never "never stored."**
Implemented in Phase 1.

**Non-code, and tracked separately (§24):** vendor terms/BAA; the `mx.py`
subprocessor register currently naming `groq`/`anthropic` while live traffic goes
to **Deepgram/OpenAI** (PHI-1 violation, already flagged in CLAUDE.md, still open).

---

## 18. Error / logging / PHI — capture path only

| Channel | Finding |
|---|---|
| Browser console | WS code/reason and **counts only**; `:912` annotated *"Counts only — no transcript text (Rule 10)"* |
| Server logs | `sessions.py` logs `session=`/`code=`; `segments.py` logs `session=`/`sequence_number=`/`status=` — identifiers, no content |
| Error monitoring | No PHI on this path |
| Analytics | One event: `ai.copilot_opened {surface}` |
| API errors | Server messages are generic permission/validation strings |
| `AI Prompt Log.raw_response` | **Empty for every encounter/copilot purpose** — Copilot Chat 0/293, Review Details 0/85, Transcribe 0/8, Patient Clinical Summary 0/1270 |

**Capture path is clean.** Out of scope but recorded: `raw_response` **is**
populated for lab purposes (up to 41,780 characters), which does not share the
capture path — separate ticket.

Minor readability hazard: `use-encounter-v3.ts:87` defines a local helper named
`track`, shadowing the analytics import name. Not a leak; worth renaming.

---

## 19. Target architecture

```
CONSENT  (single entry point — the only path to capture)
  consent card: recording · transcription · right to decline
                "audio not stored by Remedisys" · PRIOR SESSION disclosed
        │  the only caller of start()
        ▼
  getUserMedia ──► start_session
                    ├─ active_key = <encounter>   Data, unique:1, NULL when terminal
                    ├─ encounter-scoped, NOT encounter+user (ADR-039 continuity of care)
                    ├─ UniqueValidationError on "active_key" ⇒ REATTACH, never an error
                    │  (any OTHER integrity error still surfaces — §7.6)
                    ├─ publishes session.reattached for the losing tab (§7.6)
                    ├─ token minted BEFORE the transition
                    └─ Draft → Recording, consent stamped

AUDIO   browser ═══TLS═══► Deepgram        (unchanged — verified correct)

RECORDING
  ├─ transcript: append_segment + 20 s sync
  │    └─ persisted WATERMARK surfaced; never the word "saved"
  ├─ capture events: system segments (paused/resumed/muted/unmuted)
  ├─ paused_seconds accumulated
  └─ lifecycle: hard cap now · heartbeat later

CONNECTION ≠ SESSION
  Connected | Reconnecting | Disconnected      browser, ephemeral
  Draft | Recording | Stopped | Failed | Closed  server, durable
  socket dies ⇒ flush transcript FIRST ⇒ stop_session(error)

TERMINATION — three layers, most reliable first
  1. scheduled sweep: hard cap                [server only — needs no client]
  2. socket death ⇒ error                     [tab alive]
  3. pagehide ⇒ sendBeacon ⇒ system_close     [clean exit]
  every terminal transition: ended_at · duration · active_key = NULL

INDICATOR — ONE derived state in TopBar, visible on all three steps
  recording · paused · muted · reconnecting · stopped

ACCESS   read ⇒ read · append/sync ⇒ WRITE · stop ⇒ ownership

RETENTION  indefinite BY DECISION, with an erasure mechanism that exists,
           covering: AI Transcript Segment · AI Encounter Record · tabVersion
```

---

## 20. Implementation phases

Order changed from the user's draft in one place, with reason.

Status corrected 2026-08-31 — this table still read "not started" for four
phases whose own checklists record their exit verification as passed. Each
phase's evidence is its checklist, linked below; those are `record` documents
and are deliberately frozen.

| Phase | Scope | Status |
|---|---|---|
| **0** | Architecture + documentation (this file) | complete |
| **1** | Truthful UI · remove automatic recording · restore consent gate | **complete, verified** |
| **2** | Provider-failure safety: socket close ⇒ flush ⇒ finalize | **complete** — landed with the V1 consent revert, 2026-08-31 |
| **3** | Session integrity: duplicate inventory → cleanup → `active_key` → unique index → concurrent reattach | **complete** — [checklist](ENCOUNTER_V3_PHASE3_CHECKLIST.md), all 6 exit checks pass. The reattach path was still dead on arrival and was fixed 2026-08-31 (REPEATABLE READ snapshot) |
| **4** | Orphan recovery: one-time migration + hard-cap sweep | **steps 0-7 complete** — [checklist](ENCOUNTER_V3_PHASE4_CHECKLIST.md). 134 sessions recovered. Combined exit verification and the Frappe Cloud rollout remain |
| **5** | Transcript reliability: watermark, final flush, retry visibility | **complete** — [checklist](ENCOUNTER_V3_PHASE5_CHECKLIST.md) |
| **6** | Audit: pause/resume/mute events, `paused_seconds`, ASR fallback fix | **complete** — [checklist](ENCOUNTER_V3_PHASE6_CHECKLIST.md), with one post-exit defect recorded in its §19.8 |
| **7** | Access control (read/write split, ownership) + retention/lineage docs + ADR | partial — retention decided in [ADR-051](../adr/adr-051-transcript-retention-indefinite-single-source.md); access split not started |
| **8** | UX hardening: global indicator, prior-session disclosure, failure UX | not started |
| **9** | Future: heartbeat, multi-tab lease, reconnect | not started |

**Why Phase 4 precedes Phase 5 and 6.** Both were tempting to pull forward — the
watermark is the finding most likely to reach a patient. But Phase 4 is what stops
the bleeding: every day without it adds orphan rows, and the migration gets larger
and its evidence staler. Phase 5 and 6 improve a system that is at least
accounting for its own sessions.

**Why the indicator (Phase 8) must precede any mute UI (Phase 6's exposure).** A
muted session with no indicator is indistinguishable from a failed one. If mute is
exposed in Phase 6, the indicator moves into Phase 6 with it.

---

## 21. Phase gates

**Phase 1** — *complete.*
Entry: none. Implementation: 3 false retention claims removed; `CopilotHost`
auto-start deleted (not env-gated); `CopilotPanel.consented` default `false`.
Tests: 4 Playwright tests pass — no retention period on screen; page load creates
no session and requests no mic (`__micAsked = false`); declining creates neither;
consent creates **exactly one** session. DB: baseline 144 sessions / 14,187
segments captured before testing. Exit: **met**, with one carve-out — V1's runtime
behaviour is unverified because `NEXT_PUBLIC_FEATURE_ENCOUNTER_V2` is build-time
and `true`; confirming V1's consent screen renders requires a dev-server restart
with the flag off. Static proof: exactly one `.start()` call site remains in the
encounter tree. Rollback: revert 4 files; no data written.

**Phase 2** — *blocked on its own gate.*
Entry: Phase 1 exit met. Implementation: `_finalizeAfterProviderFailure()` —
teardown capture, cancel timers, **flush + sync transcript first** (because
`append_segment` refuses a non-`Recording` session), then
`stop_session(close_reason="error")`; re-entrancy guarded.
**Current status: the test did not exercise the path** — 0 stop calls and no
"connection lost" message, which suggests the harness failed to intercept the real
socket rather than a code defect, but that is **not proven**.
Exit criteria: a forced provider-side close produces exactly one
`stop_session(close_reason="error")`; the session has `ended_at` and a plausible
`duration_seconds`; segment count is **unchanged or higher** (never lower); the
physician sees the error; and a network-loss test confirms the documented
limitation (no close — Phase 4 covers it). Rollback: revert one method and one
call site; no schema change.

**Phase 3** — *design APPROVED 2026-08-26; implementation not started.*
Entry: Phase 2 exit met; the six-group duplicate inventory captured and each
pair's authoritative row decided (§7.4 — done, in this document).
Implementation, in the approved order (deploy-before-constrain, §7.6):
1. Deploy `_get_or_create_draft`'s savepoint + `UniqueValidationError` handling
   (§7.6) — inert with no unique index yet, safe to ship first.
2. Add the `active_key` field to the DocType (§7.3's exact spec) and the
   controller's `_stamp_active_key()` (§7.5) — not yet backfilled.
3. Run the migration: close the 6 losers in §7.4's table with
   `close_reason="duplicate_resolved"`, via `doc.save()` (never raw SQL), with a
   pre-run DB snapshot.
4. Backfill `active_key` on the remaining 140 rows per their status.
5. Run the four assertions in §11 of this doc — all must pass.
6. Add the unique index (schema sync / `bench migrate`).
7. Deploy the `session.reattached` realtime publish (§7.6).
Tests: two concurrent `start_session` calls ⇒ one row created, one reattached,
no error surfaced to either caller; `SELECT COUNT(*) WHERE status NOT IN
('Draft','Recording') AND active_key IS NOT NULL` = 0; stop-then-record-again on
the same encounter succeeds; two *different users* on one encounter converge to
one session (closes both root causes in §7.4, not only the same-user race).
Non-blocking for this gate: §7.7's stop-authorization follow-up (tracked, not
fixed here) and Phase 4's general orphan sweep (explicitly not a dependency —
§7.4's migration is self-contained). DB: snapshot before the migration in step
3 — that step is the only one in Phase 3 that is not reversible in place.
Rollback: steps 1–2 and 6–7 revert cleanly (code/schema only); step 3's closures
are the one irreversible-without-backup action.

**Phase 4** — cannot start until Phase 3 exit met (the index must exist, or the
sweep can create fresh duplicates while closing old ones). Tests: a session past
the hard cap closes; one inside it does not; a session with a 2-minute-old segment
is untouched; the migration is a no-op on re-run; `Recording` count = 0; every
closed row has `ended_at <= now()`. **DB snapshot mandatory — this phase is the
only one that is not reversible in place.**

**Phases 5–9** — gates defined at entry, following the same shape.

---

## 22. Test matrix

| Area | Case | Phase | Status |
|---|---|---|---|
| Consent | agree ⇒ one session, recording starts | 1 | ✅ |
| Consent | decline ⇒ no session, no mic | 1 | ✅ |
| Consent | page load ⇒ no session, no mic | 1 | ✅ |
| Consent | refresh before consent ⇒ still asked | 1 | ☐ |
| Consent | navigate away before consent ⇒ nothing created | 1 | ☐ |
| Recording | normal start / normal stop ⇒ `physician_stop`, duration | 2 | ☐ |
| Recording | pause / resume ⇒ system segments, `paused_seconds` | 6 | ☐ |
| Recording | mute / unmute ⇒ system segments | 6 | ☐ |
| Failure | Deepgram socket close ⇒ `error`, `ended_at`, no segment loss | 2 | ⚠ not exercised |
| Failure | network loss ⇒ documented limitation, sweep covers | 2/4 | ☐ |
| Failure | token mint failure ⇒ stays `Draft`, no consent record | 1 | ☐ |
| Failure | mic denied ⇒ no session at all | 1 | ☐ |
| Failure | browser crash / tab close ⇒ `system_close` | 2/4 | ☐ |
| Concurrency | double-click start ⇒ one session | 3 | ☐ |
| Concurrency | two simultaneous `start_session` ⇒ one row, reattach | 3 | ☐ |
| Concurrency | two tabs ⇒ no sequence collision | 9 | ☐ |
| Transcript | segment save · duplicate ⇒ dedupe · reconciliation | 5 | ☐ |
| Transcript | final flush before finalize (both paths) | 2/5 | ☐ |
| Transcript | persistence failure ⇒ watermark trails, physician told | 5 | ☐ |
| Security | unauthorized read refused | 7 | ☐ |
| Security | read-only user cannot append | 7 | ☐ |
| Security | user A cannot stop user B's session | 7 | ☐ |
| Lifecycle | orphan closed by hard cap; live session untouched | 4 | ☐ |
| Lifecycle | migration idempotent; `Recording` = 0 | 4 | ☐ |

---

## 23. Out of scope

SOAP generation and `AI SOAP Draft` (0 rows; and `generate_soap_draft` is
**ungated** by `enable_soap_generation` — separate ticket) · Step 2 · Step 3 ·
encounter signing · prescribing · lab workflow · the 23% unattributed speakers ·
`raw_response` PHI in lab prompt logs · the `AI Recommendation Log` decision ·
`patientDraft` re-verification · production deployment, production Frappe and the
production database.

### 23.1 Findings from the 2026-08-26 field-level audit — OUT OF SCOPE for Phase 3

These five surfaced during the read-only field-level data-model audit that
preceded Phase 3 implementation. All are **evidence-backed and real**, none is
a contradiction of the approved Phase 3 design, and **none is being changed by
Phase 3.** Recorded here so they are not lost when the audit conversation
scrolls away. **No code, DocType, index, or database row has been modified for
any of them.**

**FINDING-A — `AI Transcript Segment` has 8 existing `(session, sequence_number)`
duplicate collisions.** · *Separate transcript-idempotency/integrity problem.*
`SHOW INDEX FROM tabAI Transcript Segment` confirms **no composite unique
constraint** — `session` and `sequence_number` each carry only a plain
`Non_unique=1` index. `append_segment`'s guard is a `frappe.db.exists()` check
followed by a separate `.insert()`: the identical check-then-act shape as the
session-level race Phase 3 fixes, one level down and never previously flagged
for this table. Live collisions today:

| Session | Colliding `sequence_number`s |
|---|---|
| `AIES-2026-00117` | 3, 4, 5 |
| `AIES-2026-00131` | 138, 139, 140, 141, 144 |

Why it is *not* folded into Phase 3: Phase 3 was scoped and approved
specifically around `active_key` and session-level uniqueness. Segment-level
idempotency is a different table, a different constraint, and a different
migration (8 colliding groups whose *transcript text* would need comparing —
materially more delicate than closing an empty duplicate session). Phase 9's
multi-tab / server-assigned-sequence-number work (§12) is the natural home;
it should absorb this finding rather than Phase 3 growing to meet it.

**FINDING-B — Physician-role write permission on transcript correction is
unverified.** The `Physician` role's DocPerm on `AI Transcript Segment` grants
`create/print/read/report` but **not `write`** (doctype JSON). `sync_transcript`
(the "Fix speakers" correction path) calls `doc.save(ignore_permissions=False)`
on existing rows, which requires `write`. No test catches this: `FrappeTestCase`
runs as **`Administrator`**, which `frappe/permissions.py:107-108` short-circuits
to "Allowed everything because user is Administrator", and the suite's own
`_allow_perm()` helper patches only `segments.frappe.has_permission` (the
encounter-read gate), not the DocPerm check inside `.save()`. **This may mean
"Fix speakers" has never worked for a real Physician-role user.** Needs one
targeted manual test as a real Physician account — independent of Phase 3, and
not a reason to delay it.

**FINDING-C — A signed/submitted `Patient Encounter` can still have a
`Recording` AI session.** Structural, not just a data anomaly: nothing in the
AI session lifecycle reads `docstatus` or `status` at all. `_require_encounter_read`
is `has_permission("Patient Encounter", "read", …)`, and Frappe's default read
model is not docstatus-sensitive; the one custom permission hook
(`overrides/patient_portal_perms.py`) is scoped entirely to patient-portal
row-ownership and returns `True` for every non-portal user. `hooks.py`'s
`Patient Encounter.on_submit` list runs two clinical handlers plus
`encounter_ai_record.capture_on_submit` — **nothing that touches
`AI Encounter Session`.** Live examples: `HLC-ENC-2026-00053` and
`HLC-ENC-2026-00149` are both `docstatus=1` with an open `Recording` session.
Needs a separate lifecycle decision ("should signing terminate capture?") — a
product question, not a duplicate-prevention one.

**FINDING-D — Six `AI Encounter Session` scaffold fields have zero writers.**
`deepgram_model` · `llm_model` · `prompt_versions` · `audio_retained` ·
`error_code` · `error_message`. All 0/146 populated (`audio_retained` is `0` on
every row, i.e. the untouched schema default). Established by exhaustive search,
**not** inferred from empty values: a `.field = ` assignment grep across every
`.py` returned nothing; a bare-field-name grep found matches only on the
unrelated **`AI Settings`** doctype; frontend TypeScript has zero references.
`error_code`/`error_message` are dead specifically because the `Failed` status,
though permitted by `_ALLOWED_TRANSITIONS`, has no producer anywhere.
**KEEP ALL SIX UNCHANGED.** They read as reasonable forward intent
(per-session model/prompt provenance for reproducibility) that was scaffolded
and never wired. Marked as **future schema/observability cleanup candidates
only** — not deprecated, not removed, not touched by Phase 3.

**FINDING-E — `AI Transcript Segment.deepgram_segment_id` is wired server-side
but never populated.** 0/14,187 rows. Unlike FINDING-D this is **not** a missing
writer: `append_segment` accepts the parameter and passes it straight into the
insert, so the server-side plumbing is exercised on every single call — **the
browser never sends a non-null value.** A frontend gap, not a dead field.
**Keep unchanged**; recorded as a future traceability improvement (it would let
a mislabelled turn be traced back to Deepgram's own segment id).

---

## 24. Open questions

| # | Question | Why it matters | Decides | Can engineering proceed? |
|---|---|---|---|---|
| **Q1** | Is a transcript a **clinical record** under NOM-024 (≥5 years), or working material? | Determines whether a future erasure mechanism may lawfully delete, and how *cancelación* applies | Legal/compliance | **Yes** for Phases 1–6. Blocks the Phase 7 ADR |
| **Q2** | Which retention configuration is authoritative — `mx.py` or `AI Settings`? | Two live values disagree 28×; both inert. A future purge would read one | Product + legal | **Yes.** Blocks Phase 7 |
| **Q3** | On provider failure, should the session land on `Failed` or `Stopped` + `close_reason=error`? | `Failed` is semantically right and already in the state machine with no producer; `Stopped` is what Phase 2 currently produces | Engineering (this plan recommends `Failed`) | **Yes** — Phase 2 works either way; decide before Phase 4 counts them |
| **Q4** | Add a `backfilled` `close_reason`, or reuse `system_close` for the 141? | Audit truthfulness of a one-off touching 141 rows | Product + engineering (this plan recommends adding it) | **Yes.** Blocks Phase 4 |
| **Q5** | Is a nurse + doctor on one encounter a supported workflow? | Decides whether multi-tab/multi-user ownership (§12) is a production blocker or Phase 9 | Product | **Yes.** Changes Phase 9's priority only |

---

## 25. Challenge: our decisions assessed

**1. Is indefinite transcript retention technically safe?**
**Under the HIPAA Security Rule, yes** — it governs how PHI is protected, not how
long it is kept. But two caveats, and the second is a real objection.
*(a)* It raises the stakes on the §14 access-control gaps: keeping more, forever,
while a `read` permission can write PHI, is the wrong pair of decisions to hold at
once. *(b)* **RECOMMENDATION: CHANGE THIS** — not the retention decision, but its
scope. Shipping indefinite retention while `mx.py` declares
`right_to_erasure = True` and no erasure mechanism exists makes a declared patient
right unimplementable. Either commit to building the mechanism (Phase 7) or change
the profile to stop claiming the right. Do not ship the contradiction silently.

**2. Is "no Remedisys audio storage" the correct architecture?**
**Yes, and it is the strongest control in Step 1.** It removes the highest-risk
data class from our estate entirely, and it is *enforced by architecture*, not
policy. Keep it. Only the wording needed correcting, which Phase 1 did.

**3. Is `active_key` + unique constraint the correct duplicate-prevention model?**
**Yes — and I was wrong to warn against it on empty-string grounds.** Frappe's
`get_valid_dict` explicitly coerces an empty value to `None` **when the docfield
is `unique`**, and MariaDB permits multiple `NULL`s in a unique index. My earlier
caution was carried into the phase instructions and is now corrected in §7.2. Two
conditions are mandatory: the docfield must carry `unique: 1` (the coercion is
keyed on it), and must not be `not_nullable`. **One change to the proposal: key on
`encounter` alone, not `encounter + session_user`** — two users are already
recording the same encounters in the live data.

**4. Is a hard session cap enough initially?**
**Yes, and it is the right first move** — it closes 100% of today's orphans, needs
no new field, and cannot end a live consultation. **RECOMMENDATION: CHANGE THIS**
relative to my own earlier advice — I previously recommended a generous
transcript-idle threshold first. That was wrong: an idle rule can close a live
silent examination, and because `append_segment` rejects non-`Recording` sessions,
everything said afterwards would be **silently discarded**. Cap first, heartbeat
later, idle rule only once the heartbeat exists.

**5. Should pause be a system event rather than a session state?**
**Yes — and the justification is stronger than "less invasive".** A `Paused`
status would make late finals arrive as `sealed` and be dropped. Your instinct is
right for a reason worth writing down.

**6. Is system-event transcript storage the right audit mechanism?**
**Yes, for capture events.** Append-only, timestamped, interleaved with the speech
it describes, already permission-checked, already audited, no new doctype. One
caution: sequence numbers are client-assigned, so a `system` segment consumes a
number in the same space as speech — the event writer must take the next sequence
exactly as a speech segment does, or it will collide and be silently dropped.

**7. Step-1 security gaps not in your list**
`tabVersion` holding verbatim transcript PHI (the third copy) · `read` permission
authorizing PHI writes · `stop_session` lacking an ownership check · V1's
`localStorage` clinical draft (removal written, **not merged** — see §4) · **13 sessions with `consent_obtained = 1` and zero
segments** — the consent field is not even internally consistent · no idle-session
timeout in the clinical UI (§164.312(a) automatic logoff), which matters more on a
shared tablet holding an indefinitely retained corpus.

**8. What I would NOT implement from the current plan**
- **Reconnect (Phase 9)** — not yet, deliberately. Buffering PHI in memory across
  an outage adds a new exposure to fix a UX annoyance, and today's message is
  honest.
- **A `Paused` session state** — already excluded; noting it so it does not
  return.
- **A new audit DocType** — `system` segments cover it.
- **Any purge or deletion** — correctly out of scope; and "indefinite" plus "no
  erasure mechanism" is a decision to make explicitly (see 1), not by default.
- **Mute UI before the indicator** — shipping mute with no visible state creates
  a session that looks broken rather than muted.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | §4 and §25.7: V1's `localStorage` clinical draft is labelled as still present on `dev`. A commit removing it sits in the frontend working tree, and an unqualified "fixed" here would retire a Phase 7 item that no deployment has |
| 1.3 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | §20 phase table corrected — it still read "not started" for phases 3, 4, 5 and 6 whose own checklists record passed exit verification, and "UNVERIFIED" for phase 2 which has since landed. Each phase now links its evidence. A living document asserting four phases had not begun is the exact failure `Doc status: living` exists to prevent |
| 1.2 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Added §23.1 — five findings from the read-only field-level data-model audit, all explicitly OUT OF SCOPE for Phase 3 and all left unchanged: segment `(session, sequence_number)` collisions, unverified Physician write permission on transcript correction, signed-encounter lifecycle, six zero-writer session scaffold fields, and the never-populated `deepgram_segment_id`. Phase 3 scope unchanged |
| 1.1 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Phase 3 design APPROVED and finalized (§7): exact `active_key` field spec, the six-group duplicate table incl. `00149` auto-resolved (not held for manual gate), `duplicate_resolved` close_reason, the savepoint/`UniqueValidationError` reattach code, deploy-before-constrain order, `session.reattached` realtime publish, and the cross-clinician stop-authorization P1 tracked via §14. Phase 3's gate (§21) rewritten to the approved 7-step order; explicitly decoupled from Phase 4 |
| 1.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Initial version — Step 1 design of record, phase plan and gates; corrects the earlier `active_key` empty-string warning and the idle-before-cap ordering |
