# Invoice list — item summary field

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.2

## What

Adds one new field, `items_summary`, to the Sales Invoice list rows returned by
`list_patient_invoices` and `list_all_invoices`
(`remedisys_healthcare_ai/api/v1/billing/api.py`) — a short, human-readable string built from the
invoice's own line items (e.g. `"General consultation, Tempra 500 mg"`), truncated to the first
three item names with a `"+N more"` suffix beyond that.

## Why

`EB_Healthcare_Frontend`'s Billing screen was restyled to the Narzim design mock
(`EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`), whose Invoices table has a
permanent **Items** column — not an optional/selectable one — showing what the invoice was for at a
glance, alongside Patient/Method/Amount/Status. No existing field on the Sales Invoice list response
carries this: `_LIST_FIELDS` (`api.py:42-61`) has no line-item data at all, since the Sales Invoice
list query never touches the `Sales Invoice Item` child table today. The frontend cannot render a
column with no data source, and fabricating it client-side (guessing from `remarks` or the status
badge) would put fictional clinical/billing content on screen — Sarvesh/Divyanshu's session on this
task confirmed the correct fix is a real backend field, not a workaround, since we're already
touching this endpoint's response shape for the same restyle effort (ADR-098, ADR-099).

## Plan

New batched helper, `_item_summaries(rows)`, in `api/v1/billing/api.py`, placed beside `_payment_methods`
(`api.py:299`) and following its exact convention (see `_payment_methods_for_invoices`,
`api.py:243`, and `_apply_appointment_fallback`'s own `Sales Invoice Item` query, `api.py:359`, for
the child-table access pattern already established in this file):

```python
def _item_summaries(rows: list[dict]) -> dict[str, str]:
    names = [r["name"] for r in rows if r.get("name")]
    if not names:
        return {}

    grouped: dict[str, list[str]] = {}
    for it in frappe.get_all(
        "Sales Invoice Item",
        filters={"parent": ["in", names]},
        fields=["parent", "item_name"],
        order_by="parent, idx",
        limit_page_length=0,
    ):
        if it.get("item_name"):
            grouped.setdefault(it["parent"], []).append(it["item_name"])

    summaries: dict[str, str] = {}
    for name, item_names in grouped.items():
        shown = item_names[:3]
        extra = len(item_names) - len(shown)
        text = ", ".join(shown)
        if extra > 0:
            text += f" +{extra} more"
        summaries[name] = text
    return summaries
```

- One batched `frappe.get_all` call per page (same cost class as `_payment_methods`), keyed by the
  page's invoice names — no N+1.
- `_serialize_invoice(...)` gains a new optional parameter `item_summaries: dict | None = None` and
  returns `"items_summary": (item_summaries or {}).get(row.get("name") or "", "")` alongside the
  existing `mode_of_payment` line.
- Both `list_patient_invoices` (api.py:436) and `list_all_invoices` (api.py:592) call
  `_item_summaries(rows)` in the same place they already call `_practitioner_names(rows)` /
  `_payment_methods(rows)`, and pass the result into `_serialize_invoice`.
- `_serialize_invoice` is the single shared serializer for both endpoints — giving the field to only
  one of its two callers would mean two different response shapes for the same doctype's list row,
  which is exactly the drift `_build_invoice_filters`'s own docstring already warns against for
  filter logic. Both get it.
- No new endpoint, no new request parameter, no permission change: `Sales Invoice Item` is a child
  table of `Sales Invoice`, so read access follows the parent document's own Sales Invoice read
  permission already enforced by `require_permission("Sales Invoice", "read")` at the top of each
  endpoint.

## Amendment — duplicates and the overflow count (v1.1)

A user screenshot showed `"Consulatation fee, Consulatation fee"` — two line items, same name. And
the v1.0 code wrote `" +N more"` in English into the string, which the Spanish UI would show as-is.
`_item_summaries` now returns `(summary, more_count)`: identical names collapse to one entry with a
line count (`"Consulatation fee ×2"`; `×` reads the same in both languages), capped at three distinct
names, and the number of further distinct names goes out as `items_more_count`. The frontend renders
`billingPage.itemsMore` ("+{count} more" / "+{count} más"). The plan's code block above is the v1.0
shape, kept as written.

## Risks

- **Scale:** one extra batched query per page (typically ≤100 rows per `page_size`), same shape and
  cost as the existing `_payment_methods` call. No N+1.
- **PHI:** item/product names (e.g. "General consultation", "Tempra 500 mg") are billing catalog
  data, not patient-identifying data. Nothing here differs from what `_LIST_FIELDS` (patient name,
  amounts) already returns on the same response.
- **Upgrade safety (BE-1):** read-only `frappe.get_all` against a core child doctype, no core file
  touched.
- **Response-shape stability:** additive key only (`items_summary`); no existing key renamed or
  removed, so existing frontend consumers of these two endpoints are unaffected until they choose to
  read the new field.

## Verification

- Live end-to-end via `bench --site remedisis.localhost console`: call `list_all_invoices()` /
  `list_patient_invoices(patient=...)` directly and confirm `items_summary` is present and
  non-empty for at least one real invoice with line items, and `""` for an invoice with none.
- Confirm the existing response shape (`practitioner_name`, `mode_of_payment`, etc.) is unchanged
  aside from the new key.
- `python3 -m py_compile` on the modified file.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Duplicates collapse with a count; overflow returned as `items_more_count` for frontend translation |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
