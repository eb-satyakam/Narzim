# Encounter V3 — Phase 6 Implementation Checklist (Pause/Resume/Mute Audit)

**Doc status:** record · **Created:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 3.1

Design authority: [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
§11 ("Pause / mute") and phase-table row 6 (§20): *"Audit: pause/resume/mute
events, `paused_seconds`, ASR fallback fix — not started."* This is that
entry-time elaboration, kept concise per instruction. Labels used
throughout: **[VERIFIED]** (read in actual code/DocType this session),
**[DESIGN DOC]** (from §11, cited not re-derived), **[RECOMMENDATION]**
(proposed here), **[DECIDED]** (confirmed by you this turn). Nothing
executed — no code, schema, migration, or test changed.

---

## 1. Problem

**[VERIFIED]** Pause and mute produce **zero** trace today. `pause()`
(`real-provider.ts:731`) only calls `recorder.pause()`/gates PCM and starts
Deepgram KeepAlive; `setMuted()` (`:978`) only flips `track.enabled`.
Neither writes a segment, changes `status`, or touches the database.
`duration_seconds` is raw wall-clock, silently including any paused time.

## 2. User story

Dr. Bracamontes pauses 12 minutes mid-visit, resumes, then stops. The UI
correctly shows "Paused" then "Recording encounter" — but the database
records one session whose `duration_seconds` includes those 12 silent
minutes, with nothing anywhere indicating a pause ever happened.

## 3. Example (hypothetical — no real session exists yet)

```
00:00 started_at; 00:00–14:00 speech
14:00 Pause  -> capture_paused
14:00–26:00  silence, KeepAlive only
26:00 Resume -> capture_resumed
26:00–30:00 speech; 30:00 Stop -> ended_at

Today:      duration_seconds = 30:00 (wrong by 12:00)
After Ph.6: paused_seconds = 12:00; duration_seconds = 18:00 (correct)
```

## 4. Current vs. expected behavior

| | Today | After Phase 6 |
|---|---|---|
| Pause/resume in DB | Nothing | `system` segments `capture_paused`/`capture_resumed` |
| Mute in DB / UI | Nothing / no control in V3 | Unchanged — deferred (§8) |
| `paused_seconds` | Doesn't exist | New field, server-derived |
| `duration_seconds` | Wall-clock | Wall-clock − `paused_seconds` |
| ASR fallback | Includes paused time (§7) | Paused time subtracted |

## 5. Frontend scope

**[VERIFIED gaps]** `Speaker` type (`types.ts:10`) lacks `"system"`. Four
`mapSpeaker` helpers (`real-provider.ts:1072`-area ×3 write sites, plus
`_hydrateTranscript`'s reverse-direction one) all collapse anything
non-doctor/patient to `"unknown"` — **would silently mislabel a system
segment on write and on reload** if not fixed, all four. `_buildTranscript()`
(`:1379`) has no filter — a system segment would leak into the LLM prompt.
`use-copilot.ts`'s `onTranscript` → UI transcript list has no filter either
— a pause event would render as a garbled turn. `pause()`/`resume()` have
no duplicate-call guard today (`resume()` partially checks recorder state;
`pause()` doesn't, and neither does `pcmMode`).

**[RECOMMENDATION]** Fix all four `mapSpeaker` sites; filter `speaker ===
"system"` out of `_buildTranscript()` and the UI-facing transcript state;
add a `capturePaused` flag to make repeated pause calls a no-op.

## 6. Backend scope

**[VERIFIED]** `AI Transcript Segment.speaker` already has `system` as a
Select option; `append_segment`'s `_ALLOWED_SPEAKERS` already includes it
(`api/ai/segments.py:36`). **No write-path validation change needed.**
`AI Encounter Session` has no `paused_seconds` field. `duration_seconds` is
computed in exactly one place: `_stamp_timing()`,
`ai_encounter_session.py:75` — `time_diff_in_seconds(ended_at, started_at)`,
only when not already set.

## 7. Schema change

**[VERIFIED current / RECOMMENDATION]** One new field only:
`AI Encounter Session.paused_seconds` (Int, `read_only: 1`, default `0`).
No change to `AI Transcript Segment`. **No migration created this turn** —
an eventual backfill (`paused_seconds = 0` for existing rows) is a
separate, later, explicitly-authorized step (§13 item 4).

## 8. Pause/resume system events

**[VERIFIED + DECIDED]** Four events per §11: `capture_paused`,
`capture_resumed`, `capture_muted`, `capture_unmuted`. **Mute stays fully
deferred to Phase 8 — decided this turn**, per the design doc's own
explicit gate (`STEP1_IMPLEMENTATION_PLAN.md:951-953`, quoted verbatim):
*"Why the indicator (Phase 8) must precede any mute UI... If mute is
exposed in Phase 6, the indicator moves into Phase 6 with it."* Phase 8
has not been audited; pulling its scope in unseen would be invented scope.
Pause has no such dependency (it already has a visible "Paused" state) and
proceeds on its own. This phase implements `capture_paused`/
`capture_resumed` only.

`pause()` also fires from the 2-minute silence auto-pause watchdog
(`use-copilot.ts`) — **[VERIFIED]** — so an auto-pause becomes audit-visible
too, which is intended, not a side effect to suppress.

**Reload-mid-pause UI restoration — [DECIDED]: stays deferred.** It is a
pre-existing gap (the UI never restores a "paused" state from a hydrated,
unmatched `capture_paused` segment), Phase 6 does not worsen it, and it
causes no data corruption — an unmatched pause is still correctly recorded
and still correctly counted in `paused_seconds` (§9's open-interval rule)
even if the *UI* doesn't visually resume into "Paused" after a reload.

## 9. `paused_seconds`

**[DECIDED, both this turn]**
- **Calculated server-side**, not trusted from the client — derived from
  persisted `capture_paused`/`capture_resumed` segment pairs (survives
  crash/reload; no separate counter to drift).
- **One shared backend helper** computes it, called from both
  `_stamp_timing()` and the ASR fallback (§11) — not duplicated logic.

Sum `(resume.start_ms − pause.start_ms)` across every matched pair,
ordered by `sequence_number`. An unmatched trailing pause (Stop while
paused) counts as open until session end — otherwise stopping mid-pause
would under-report paused time. This directly handles multiple pause/resume
cycles by construction (a sum over N pairs, not one subtraction).

## 10. `duration_seconds`

**[VERIFIED / RECOMMENDATION]** One-line change, `ai_encounter_session.py:75`:
```python
self.duration_seconds = int(time_diff_in_seconds(self.ended_at, self.started_at)) - self.paused_seconds
```
computed via the shared helper (§9) immediately before this line, inside
the same `_stamp_timing()` hook. Phase 4's hard-cap sweep saves through
this same hook — no separate fix needed there.

## 11. ASR fallback (`_collect_asr_usage`)

**[VERIFIED mechanism] [OPEN QUESTION on the exact math]** The fallback
(`services/encounter_ai_record.py:165`) uses `MAX(end_ms)` only when every
session on the encounter has `duration_seconds` still `0`. §11 asserts
`end_ms` "includes paused time" because it's "a timeline offset from
session start." **I could not independently verify this** — `_handleMessage`
sets `tStart`/`tEnd` purely from Deepgram's own `msg.start`/`msg.duration`
with zero frontend wall-clock math, so whether a paused gap shows up in the
*next* segment's timestamp is Deepgram's own server-side behavior, outside
this codebase's visibility.

**No live/controlled Deepgram test was run this turn** — doing so needs a
real recording session with a real pause, which isn't a quick check;
per instruction, marking this **OPEN QUESTION** and moving on rather than
spending time on it. **Recommendation:** implement the fallback fix
(subtract the shared helper's per-encounter paused total from `MAX(end_ms)`)
but treat it as unverified until a real empirical pause/resume test is run
during implementation, before relying on the resulting number.

## 12. Sequence-number safety — the most important check, done fresh

**[VERIFIED, this turn, precisely]** `sequence_number` is never a stored
property — it is **recomputed from array position** every send, at exactly
three sites: `real-provider.ts:1072`, `:1169`, `:1254` (`sequence_number: i`
or `startIdx + i`). The only other counter in the file, `segSeq`
(`:162`), is used **exclusively** for local UI `id` strings
(`seg-${++this.segSeq}`) — confirmed it is never sent to the backend as
`sequence_number`. There is exactly **one** place that determines sequence
numbers.

**Collision risk exists only if system events use a second, independent
counter** — the design doc's own §10 Q6 warns of exactly this ("the event
writer must take the next sequence exactly as a speech segment does, or it
will collide and be silently dropped," landing as a false `"duplicate"`
per `append_segment`'s existing idempotency check). **The safe strategy
(recommended, requires no new counter): push system segments into the
same `finalSegments` array speech segments already use, in arrival order,
never inserted retroactively.** The existing array-index computation then
assigns their `sequence_number` automatically, identically to how it
already handles speech — zero new allocation logic needed.

## 13. Risks

1. **[VERIFIED]** All four `mapSpeaker` sites silently mislabel `"system"`
   → `"unknown"` if not fixed — the single most load-bearing gap found.
2. **[VERIFIED]** No filter exists to keep system segments out of the
   LLM-facing transcript or the visible UI turn list.
3. **[OPEN QUESTION]** §11's `end_ms`-includes-paused-time claim is
   unverified from code; the ASR fallback fix's exact correctness depends
   on it.
4. **[RECOMMENDATION noted as risk]** An eventual backfill migration for
   existing sessions' `paused_seconds = 0` is a separate, later,
   explicitly-authorized step — not scoped or scheduled here.
5. **[VERIFIED]** No duplicate-pause guard exists today — without adding
   one, a double pause-call could double-write `capture_paused`.

## 14. Test strategy (not written this turn)

**Backend:** `_stamp_timing()` multi-cycle `paused_seconds` accumulation;
unmatched-trailing-pause counts as open; shared helper agreement between
`_stamp_timing()` and the ASR fallback; regression on existing 13
`test_segments.py` tests.
**Frontend:** `mapSpeaker` round-trip (write and `_hydrateTranscript`
read) preserves `"system"`; `_buildTranscript()`/UI-transcript filter
exclusion; duplicate-pause no-op; sequence-number-by-array-position proof
with a mixed speech+system array (the §12 collision-prevention proof).
**Playwright:** pause→resume→Stop produces the expected mocked
`/api/ai/session/segments` payload with both system segments in order;
existing Phase 5 scenarios unaffected (system segments never appear in the
visible transcript).

## 15. Implementation Steps 0 → Exit

| # | Step |
|---|---|
| 0 | Confirm §11's Deepgram timestamp behavior empirically, if not already done, before finalizing the ASR fallback's exact math |
| 1 | Frontend: `Speaker` type + fix all 4 `mapSpeaker` sites |
| 2 | Frontend: emit `capture_paused`/`capture_resumed` in `pause()`/`resume()`, guarded against duplicates |
| 3 | Frontend: filter system segments from `_buildTranscript()` and the UI transcript state |
| 4 | Backend: add `paused_seconds` field |
| 5 | Backend: shared pause-duration helper; wire into `_stamp_timing()` |
| 6 | Backend: wire the same helper into `_collect_asr_usage`'s fallback |
| 7 | Tests (§14) |
| Exit | Full verification against §16 |

Mute is explicitly not a step here (§8).

## 16. Acceptance criteria

- **AC1:** One `capture_paused` + one `capture_resumed` per cycle, `system`
  speaker surviving persistence and reload.
- **AC2:** `paused_seconds` correctly sums multiple cycles, not just one
  subtraction.
- **AC3:** Unmatched trailing pause still counts.
- **AC4:** `duration_seconds` reduced by exactly `paused_seconds`, including
  via Phase 4's hard-cap path.
- **AC5:** ASR fallback agrees with the primary path (pending §11's open
  question).
- **AC6:** System segments never appear in the LLM transcript, visible
  transcript, or turn count.
- **AC7:** No duplicate system segments from a repeated pause call.
- **AC8:** No Phase 3/4/5 regression.
- **AC9:** No mute UI or mute segment-writing ships in this phase.

## 17. Open decisions

Four of the five original open items are now **[DECIDED]** (§8, §9) —
only the Deepgram empirical question remains genuinely open:

1. **[OPEN]** §11's Deepgram `end_ms`-includes-paused-time claim — proceed
   on the assumption for now (as recommended, §11), confirmed to require
   an empirical check during implementation before final reliance.
2. **[DECIDED]** `paused_seconds` computed server-side from segment pairs.
3. **[DECIDED]** One shared backend helper for the pause-duration math.
4. **[DECIDED]** Mute stays deferred to Phase 8.
5. **[DECIDED]** Reload-mid-pause UI restoration stays deferred (no data
   corruption risk).
6. Still needs your confirmation: the eventual `paused_seconds` backfill
   migration is a separate, later, explicitly-authorized step (§7, §13.4).

## 18. Implementation record

**Step 1 — frontend `Speaker` type + `mapSpeaker` fixes.** [VERIFIED, done]
Files: `Healthcare_next_app/src/components/narzim/encounter/copilot/types.ts`
(`Speaker` union gained `"system"`) and `real-provider.ts` (all 4 `mapSpeaker`
closures — hydrate, sync, persist, autosave — now pass `"system"` through
instead of collapsing it to `"unknown"`; the unrelated `_mapSpeaker` private
method, which maps Deepgram's numeric diarization index and never produces
`"system"`, was correctly left untouched). 198/198 Vitest, clean lint/type-
check on touched files. Not staged/committed.

**Step 2 — `capture_paused`/`capture_resumed` system events.** [VERIFIED, done]
`real-provider.ts`: new `capturePaused` boolean (the single source of truth
for "did recording actually just transition into/out of paused", independent
of `pcmMode` vs. recorder internals) gates `pause()`/`resume()` so a repeated
call is a no-op; new private `_appendSystemSegment(event)` pushes a
`speaker: "system"`, `text: "capture_paused" | "capture_resumed"` entry
directly into `finalSegments` — the SAME array speech segments use, so
`sequence_number` (recomputed as array position at every send site, per §12)
needed no new allocation logic and cannot collide with a speech segment's
number. Confirmed no race is possible: `pause()`/`resume()` and the WS
`_handleMessage` handler are both fully synchronous with no `await` before
their `finalSegments.push`, and JS's single-threaded event loop guarantees
only one of them runs at a time. tStart/tEnd for a system event is a zero-
duration marker at the most recently known Deepgram-timeline position (the
last segment's `tEnd`, or 0 before any speech) — same timescale speech
segments use, for §9's future `paused_seconds` reader.

Tests added (`real-provider.test.ts`, describe "pause()/resume() — Phase 6
Step 2"): single `capture_paused`/`capture_resumed` emission, duplicate-call
no-op for both, resume-without-pause no-op, a 2-cycle ordered-event sequence,
a mixed system+speech array producing strictly-increasing unique sequence
numbers through the real `_persistTranscript()` send path, and a full
system+speech send-payload shape check. Result: 8/8 new, 206/206 full Vitest
suite, clean lint, clean type-check on touched files (one pre-existing,
unrelated `e2e/encounter-submit.spec.ts` type error predates this work).

**Known, expected, temporary gap carried into Step 3:** system segments are
not yet filtered out of `_buildTranscript()` or the UI-facing transcript
list — a physician would currently see a "System: capture_paused" line and
it would reach the LLM prompt. This is explicitly Step 3's job (§5,
§15 step 3), out of scope for Step 2, and is called out here so it isn't
mistaken for an oversight before Step 3 lands.

**Step 3 — filter system segments out of the LLM/UI-facing transcript.**
[VERIFIED, done] `real-provider.ts`'s `_buildTranscript()` now filters
`speaker !== "system"` before building the "Doctor: ...\nPatient: ..."
string sent to `/api/ai/suggest` and `generateSoapDraft()`. `use-copilot.ts`'s
`onTranscript` callback (the single place that feeds the `transcript` React
state) now returns early on `seg.speaker === "system"` — this covers the
visible turn list, the "N turns" counter, the `formatTranscript()`/
`getTranscript()` path the encounter chat agent reads (both derive from the
same `transcript` state), and the hydration replay path (`_hydrateTranscript`
calls the same `transcriptCbs`), all from one filter point. It also
correctly does not restart the silence watchdog on a pause/resume event
(pausing is not "somebody spoke").

Tests added: 2 new (`_buildTranscript()` excludes system lines; returns `""`
when only system segments exist, no speech yet). Full suite: 208/208
(198 + Step 2's 8 + Step 3's 2). Lint clean; type-check clean except the
same pre-existing, unrelated `e2e/encounter-submit.spec.ts` error.
**Not separately unit-tested:** the `use-copilot.ts` `onTranscript` filter —
this repo has no hook-test harness (`real-provider.test.ts` tests the
provider directly; no `renderHook`/testing-library setup exists for hooks),
and no existing Playwright spec exercises pause/resume against the visible
transcript. The change itself is a one-line early-return guard, structurally
identical to the now-tested `_buildTranscript()` filter.

**`resegregateSpeakers()` fix — approved and implemented.** [VERIFIED, done]
The discovered gap (worse than first stated once traced fully: `_syncTranscript()`'s
full-reconcile semantics mean the old wholesale-replace would have gotten the
already-**persisted** `capture_paused`/`capture_resumed` rows **deleted from
the backend**, not merely dropped from memory) is fixed in `real-provider.ts`:
`resegregateSpeakers()` now splits `finalSegments` into `speechSegments` /
`systemSegments` up front; only `speechSegments` text is sent to
`/api/ai/resegregate`; the rebuilt speech turns are merged back with the
untouched `systemSegments` (sorted by `tStart` — system segments keep their
real timestamps, rebuilt speech keeps its existing interpolated timestamps)
into the new `this.finalSegments`; `_syncTranscript()` therefore now sends
the system rows too, so they are no longer deleted; `persistedCount` is set
to the FULL merged length (not speech-only), so the next autosave tick can't
mistake the untouched system rows for new segments; and the method's return
value (which the caller uses to wholesale-replace the UI-visible transcript)
stays speech-only, preserving Step 3's guarantee that a system segment never
reaches the UI.

5 tests added: no system text sent to the resegregate API; system segments
survive in `finalSegments` post-rebuild; `_syncTranscript()`'s payload
includes both system rows (proving they won't be reconcile-deleted); the
returned array is speech-only; `persistedCount` equals the full merged
length. Result: 5/5 new, 213/213 full Vitest suite, clean lint, clean
type-check on touched files (same pre-existing unrelated
`e2e/encounter-submit.spec.ts` error).

**Step 4 — backend `paused_seconds` field + shared pause-duration helper.**
[VERIFIED, done] Pre-coding verification of `_stamp_timing()` (required
before writing anything): it runs on **every** `validate()` call (every save
of the doc), but `started_at`/`ended_at`/`duration_seconds` are each
write-once, guarded by `not self.<field>` — `duration_seconds` is only ever
actually computed the single time a save both sets `ended_at` for the first
time AND finds `started_at` already present, i.e. exactly the terminal-status
transition. Step 4 does **not** wire anything into `_stamp_timing()` —
`paused_seconds` stays at its schema default (`0`) on every session until
Step 5 adds that write, mirroring the same write-once pattern.

Added: `AI Encounter Session.paused_seconds` (Int, `read_only: 1`, default
`0`, in `column_break_t1` next to `duration_seconds`) —
`remedisys_healthcare_ai/doctype/ai_encounter_session/ai_encounter_session.json`.
Local dev site (`marley.local`) migrated to add the column; confirmed via
`DESCRIBE` that every existing row got `0` with **no backfill patch** — a
patch would only exist to derive historical values, which was explicitly out
of scope, and `patches.txt` in this repo is reserved for data patches, never
schema-only field additions (Frappe's own migrate handles the DDL).

New shared helper: `services/pause_duration.py` —
`calculate_paused_seconds(segments, *, started_at=None, ended_at=None)`, a
pure function (sorts defensively by `sequence_number`, filters to
`speaker == "system"` itself so callers can pass a full segment list), plus
`calculate_session_paused_seconds(session)`, a thin `frappe.get_all` wrapper.
Deliberately the single place Step 5 (`_stamp_timing`) and Step 6
(`_collect_asr_usage`) will both call, per requirement 5.

Algorithm: walks system segments in `sequence_number` order tracking one
open-pause anchor; a `capture_resumed` closes it (`resume.start_ms −
pause.start_ms`, accumulated across every cycle); a second `capture_paused`
before any resume is ignored (the earlier anchor holds — the reload-mid-pause
duplicate case); an orphan `capture_resumed` with nothing open is ignored;
any unrecognized system-event text (future Phase 8 mute events) is ignored
without erroring. **Trailing/unmatched pause** (session ends while still
paused): closed using only real, persisted evidence —
`time_diff_in_seconds(ended_at, started_at)` (wall clock) minus the open
pause's `start_ms` (audio timeline), clamped at `max(0, ...)`. This is an
approximation (`started_at` is stamped before the Deepgram WS handshake even
begins, so true audio t=0 lags it slightly), disclosed in the docstring: the
bias is small, one-directional (over-estimates the trailing pause by that
same lag), and never negative or invented — satisfying requirement 4 without
guessing a value. If a session is terminal but missing `started_at` (should
not happen), the trailing pause is left uncounted rather than closed with no
evidence. This mechanism resolved the ambiguity requirement 4 flagged without
needing to stop and ask: the requirement's own wording ("evidence-derived
timestamps") named the resolution — `started_at`/`ended_at` are real,
persisted facts, not invented ones — and the one candidate alternative (using
each segment's Frappe `creation` timestamp) was rejected in the docstring for
a worse, unbounded error (persistence lags the real event by up to a full
20s autosave interval, or until Stop).

**Worked example** (also codified as a test): pause at audio-timeline 10s,
resume at 12s (cycle 1 = 2s); pause at 20s, resume at 23s (cycle 2 = 3s);
a third pause at 30s with the session then Stopped 6s of wall-clock later
(trailing = 6s, no matching resume). Total `paused_seconds` = 2 + 3 + 6 = **11**.

15 tests added in `tests/ai/test_pause_duration.py` (pure-function, no DB —
mirrors the existing `TestDeepgramTtlBound` pattern): no pause, empty input,
one cycle, multiple cycles, trailing pause closed via session end, trailing
pause left uncounted while the session is still open, trailing pause left
uncounted with no `started_at`, duplicate pause ignored, duplicate/orphan
resume ignored, chronological ordering enforced regardless of input order,
orphan resume before a valid pair doesn't corrupt it, an unrecognized system
event doesn't crash or corrupt the calc, speech segments ignored even when
interleaved, and the worked example above. Plus 1 integration test
(`TestCalculateSessionPausedSecondsIntegration`) against real fixtures,
proving the `frappe.get_all` filter/order actually round-trips persisted
rows. Result: 15/15 new, and the full `tests/ai/` regression suite —
165/165 (up from the pre-existing 150; no other test directory in the repo
references `AI Encounter Session`, confirmed by grep) — all passing. `ruff`
clean on every touched file (one pre-existing, unrelated import-order
warning on `ai_encounter_session.py` predates this work — confirmed via
`git status` that file's `.py` was never touched, only its `.json`). `mypy`
is not installed in this environment — could not run it; noted rather than
skipped silently.

Confirmed: no historical session was backfilled (every existing row's
`paused_seconds` is the schema default `0`, verified via `DESCRIBE`, not
computed); Steps 5 (`duration_seconds`) and 6 (`_collect_asr_usage`) remain
completely untouched; mute/unmute not implemented; no production/Frappe
Cloud change — the only environment touched was the local `marley.local`
dev site's schema, migrated the same way any local schema addition is.

**Step 5 — wire the Step 4 helper into `_stamp_timing()`'s `duration_seconds`.**
[VERIFIED, done] `ai_encounter_session.py`'s `_stamp_timing()`, inside the
existing write-once `if self.started_at and self.ended_at and not
self.duration_seconds:` block (unchanged condition — still fires exactly
once, at the terminal-status transition, per Step 4's verification): now
calls `calculate_session_paused_seconds(self)` (passing `self` directly, so
the helper's `isinstance(session, str)` branch is skipped and no extra
`frappe.get_doc` round-trip happens), stores the result on
`self.paused_seconds`, then sets
`self.duration_seconds = max(0, wall_clock_seconds - self.paused_seconds)`
in place of the old bare `int(time_diff_in_seconds(...))`. `started_at`/
`ended_at`'s own write-once auto-stamping is untouched — only the
`duration_seconds` line's right-hand side changed.

**Failure isolation (a judgment call within scope, not a stop-worthy
conflict):** the helper call is wrapped in `try/except Exception` — a
segment-query failure logs an error (`session={name}` only, no PHI, per
Rule 10) and degrades `paused_seconds` to `0` rather than blocking the
session from reaching its terminal status. `_stamp_timing()` runs on every
save and previously did only local field arithmetic with no failure surface
at all; adding a live DB query here without a fallback would have made a
transient segment-table issue capable of blocking Stop entirely, which is
disproportionate for AI-subsystem bookkeeping (mirrors the Rule-7-style
best-effort pattern already used elsewhere in this codebase, e.g.
`services/encounter_ai_record.py`'s `capture_on_submit`).

**Regression note (accepted, not a new class of risk):** on the `Failed`
terminal path only (`_finalizeAfterProviderFailure()`'s unconditional close,
Phase 5), the backend session can close before all segments — including a
trailing system segment — are persisted, so `paused_seconds`/
`duration_seconds` may under-count on that specific unhappy path. This
already existed for transcript completeness generally before Phase 6; it is
not introduced by this wiring, and Rule 7 explicitly accepts degraded
fidelity over blocking on AI-adjacent failures.

6 tests added in `tests/ai/test_encounter_session_paused_seconds.py`
(integration, real fixtures — `services.pause_duration`'s calculation logic
is already exhaustively unit-tested in Step 4; these are controller-wiring
tests only): unpaused session (`paused_seconds=0`, `duration_seconds`
unchanged from pre-Step-5 behavior — regression), one cycle subtracted,
multiple cycles accumulate, trailing unmatched pause closed and subtracted,
duration clamped at 0 when a pathological matched pair's audio-timeline gap
exceeds the wall-clock session length, and write-once behavior preserved
across a later unrelated save (Stopped → Closed). Result: 6/6 new, full
`tests/ai/` regression — **171/171** (up from 165). `ruff` clean on every
touched file (the file's
pre-existing I001 import-order warning was fixed as part of touching this
file's import block this step, since it was no longer purely pre-existing
once a new import was added to that same block). `mypy` still not
installed in this environment — noted, not run.

Confirmed: Step 4's helper behavior itself was not modified (only imported
and called); Step 6 (`_collect_asr_usage`) untouched; mute/unmute not
implemented; no historical backfill (this only affects future terminal
transitions, computed at save time — no existing row was touched, no
migration run for this step).

**Step 6 — wire the helper into `_collect_asr_usage`'s `MAX(end_ms)`
fallback.** [VERIFIED, done] `services/encounter_ai_record.py`'s
`_collect_asr_usage()`: the primary path (`SUM(duration_seconds)` across
every session on the encounter) needed **no change** — since Step 5, each
closed session's own `duration_seconds` is already net of that session's
pause time, so the SUM is already correct. The fallback only runs when that
SUM is `<= 0`; since `duration_seconds` can never be negative, reaching the
fallback means **every** session on the encounter has `duration_seconds ==
0`, i.e. none has been through Step 5's terminal finalization yet. The raw
`MAX(end_ms)` figure therefore still includes any pause/resume cycle already
completed mid-session. Fix: fetch every `AI Encounter Session` name for the
encounter and sum `calculate_session_paused_seconds(name)` across all of
them, then `seconds = max(0.0, seconds - paused_seconds)` — the same shared
helper Step 5 uses, applied across sessions the same way the pre-existing
`MAX(end_ms)` already merges sessions (one already-accepted cross-session
approximation, not a new one). A never-closed session's own *trailing*
pause is correctly NOT subtracted here — the helper's trailing branch only
fires once `ended_at` exists, which a still-recording session by definition
lacks; only completed pairs are known and subtracted. No new try/except was
added — the whole function already wraps every step in one try/except that
degrades to `{"minutes": 0.0, "cost_usd": 0.0}` on any error (this module's
docstring: "Rule 7 is absolute here... every step is wrapped"), so the new
DB calls inherit that same existing Rule 7 protection for free.

7 tests added in `tests/ai/test_collect_asr_usage.py` (no pre-existing
coverage of this function existed at all, confirmed by grep before writing
— these establish baseline + Step 6 together): no sessions/no segments,
primary-path regression (closed session's Step-5 duration used unchanged),
fallback with no pause (regression, unchanged from pre-Step-6), fallback
subtracts one completed cycle, fallback sums paused time across two
sessions on the same encounter, fallback clamps at 0 on a deliberately
pathological input (`end_ms` decoupled from `start_ms` — real Deepgram data
can't produce this, since a resume's own `end_ms` would itself set a new
furthest point), and a never-closed session's trailing pause correctly not
subtracted. Result: 7/7 new, full `tests/ai/` regression — **178/178** (up
from 171). `ruff` clean on every touched file after one fix (an implicit-
`Optional` default-arg annotation in the new test file). `mypy` still not
installed in this environment — noted, not run.

Confirmed: Step 4/5 code unmodified; no historical backfill; mute/unmute
not implemented; nothing staged, committed, or pushed.

**Phase 6 status after Step 6:** all six planned implementation steps
(§15) are now done — `Speaker`/`mapSpeaker` (1), `capture_paused`/
`capture_resumed` emission (2), UI/LLM transcript filtering (3, plus the
discovered `resegregateSpeakers()` fix), `paused_seconds` field + shared
helper (4), `duration_seconds` wiring (5), ASR fallback wiring (6). Still
open: §17 item 1 (the Deepgram `end_ms`-includes-paused-time claim, still
unverified — no live/controlled test has been run at any point in this
phase) and §17 item 6 (the eventual `paused_seconds` backfill migration for
pre-Phase-6 historical sessions, explicitly deferred and not authorized).
Mute stays deferred to Phase 8 per the original gate. Nothing in Phase 6 has
been staged, committed, or pushed at any step.

## 19. Step 7 — comprehensive testing, empirical verification, and Exit
readiness

### 19.1 Empirical Deepgram `end_ms` probe — §11/§17 item 1, RESOLVED

**[VERIFIED, empirical, this session]** A real streaming session was run
against production Deepgram (never marley.local — this hits Deepgram's own
API, not this app's backend or database; no `AI Encounter Session`/
`AI Transcript Segment` row was created) using two real macOS-TTS speech
clips (~3.5s each) and a genuine 8-second no-audio gap in between during
which only Deepgram `KeepAlive` control messages were sent — **exactly**
what `real-provider.ts`'s `pause()` does (no audio bytes, KeepAlive only;
`_rotateSocket`'s and `pause()`'s own comments already documented this
mechanism, this is the first time its effect on Deepgram's own clock was
actually measured).

**Result, unambiguous:**
```
seg1 final: start=0.0  duration=3.5   (matches seg1's real file length, 3.5067s)
[ 8-second no-audio gap — KeepAlive only, matching pause() exactly ]
seg2 first result: start=3.5           <- picks up EXACTLY where seg1 left off
```
Deepgram's own `start`/`duration` fields are a pure function of **audio
bytes actually received** — the 8-second gap contributed **zero** to
Deepgram's internal clock. **§11's claim ("end_ms includes paused time,
because it's a timeline offset from session start") is FALSIFIED.** The
opposite is true: `end_ms` already excludes paused time, because pausing
stops the audio feed at the source and Deepgram's clock only advances with
bytes received.

**Secondary finding, also new:** Deepgram held seg1's utterance open
through the entire gap and did not emit its **final** result until *after*
seg2's audio started arriving (t=16.8s, well past the gap's end at t=15.0s)
— a pause can delay a pre-pause utterance's final past the resume point.
Assessed and NOT treated as a defect: `sequence_number` is array-position
at persist time, so a late-arriving pre-pause final simply lands at a later
array index than the `capture_paused`/`capture_resumed` markers already
pushed synchronously by `pause()`/`resume()`. This has zero effect on
anything Phase 6 computes: Step 4's helper filters to `speaker=="system"`
before doing anything, entirely blind to where speech segments land in the
array; Step 3 already filters all system segments out of the physician-
facing/LLM transcript, so a system marker's position relative to a delayed
speech final is never visible either. The one real, honestly-disclosed
consequence: a `capture_paused` segment's own `tStart` (stamped from "the
last already-known segment's tEnd" — see Step 2's code comment) can lag the
true pause moment by however long the in-flight, not-yet-finalized
utterance was — a pre-existing, already-disclosed approximation (Step 2:
"no independent wall clock exists"), now measured to potentially be several
seconds rather than assumed near-zero. Recorded as a known precision
caveat on `paused_seconds`, not a correctness defect — fixing it would
require adding a live wall-clock timestamp source to the frontend provider,
a design change beyond Step 7's testing scope.

### 19.2 Genuine defect found and fixed: Step 6's ASR-fallback subtraction

**Root cause:** Step 6 subtracted `paused_seconds` from `_collect_asr_usage`'s
`MAX(end_ms)` fallback, reasoning from §11's (now-falsified) claim that
`end_ms` included paused time. Since the probe proves the opposite — the
raw `end_ms` figure was **already** net of pause time — Step 6's
subtraction was a **double-subtraction**: it under-reported actual
Deepgram-processed (and presumably billed) audio by the paused amount,
exactly backwards from the goal of an accurate cost estimate.

**Fix:** reverted `services/encounter_ai_record.py`'s fallback to trust
Deepgram's own `MAX(end_ms)` figure directly, with no `paused_seconds`
adjustment (restoring the pre-Step-6 formula). Removed the now-unused
`calculate_session_paused_seconds` import from this file. The primary path
(`SUM(duration_seconds)`) needed no change — it is wall-clock derived
(`started_at`/`ended_at`), completely independent of Deepgram's own clock,
and converges to the same correct audio-duration figure for an unrelated,
still-valid reason: pausing stops the audio feed at the source, so
wall-clock active time and Deepgram-processed audio time agree by
construction.

**Tests corrected** in `tests/ai/test_collect_asr_usage.py` — three tests
that asserted the (now-disproven) subtraction were rewritten to assert the
corrected behavior instead of being weakened or deleted:
`test_fallback_does_not_subtract_a_completed_pause_resume_cycle` (was
"...subtracts...") and `test_fallback_across_multiple_sessions_ignores_pause_events`
(was "...sums paused_seconds across sessions...") now prove pause markers
present in the segment set do **not** change the fallback's output; the
former `test_fallback_never_goes_negative` (which existed only to exercise
the now-removed subtraction's clamp) was replaced with
`test_a_system_segments_own_end_ms_still_participates_in_the_max`, which
confirms a system segment's own `end_ms` still legitimately contributes to
the raw `MAX(end_ms)` query — true before Phase 6 and unchanged by it,
since that SQL never filtered by speaker. Net: 6 tests in this file
(was 7 — one redundant clamp test removed, its replacement covers a real
behavior the old one didn't).

### 19.3 Full Step 7 test-plan execution

| Area | Result |
|---|---|
| Backend: `services/pause_duration.py` (pure + integration) | 15/15 pass |
| Backend: `paused_seconds`/`duration_seconds` controller wiring | 6/6 pass |
| Backend: `_collect_asr_usage` (corrected) | 6/6 pass |
| Backend: full `tests/ai/` regression (incl. Phase 3/4 invariants — consent gate, `_ALLOWED_TRANSITIONS`, `active_key` uniqueness, all exercised by the unchanged `test_sessions.py`/`test_segments.py`) | **177/177 pass** (was 178 before the one net test-count change in §19.2) |
| Backend: `ruff` on every touched file | clean |
| Backend: `mypy` | not installed in this environment — not run, noted rather than skipped silently |
| Backend: schema/DocType verification | `paused_seconds` column confirmed present via `DESCRIBE tabAI Encounter Session` on `marley.local`, `int(11) NOT NULL DEFAULT 0` |
| Backend: no-mute regression | grep-confirmed zero mute code changes anywhere in Phase 6; `setMuted`/`toggleMute` unchanged from pre-Phase-6 |
| Frontend: full Vitest suite | **213/213 pass** |
| Frontend: `tsc --noEmit` | clean except one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts` (confirmed via `git status` — untouched by Phase 6) |
| Frontend: `eslint` on the 4 actually-touched Phase 6 files | clean, zero warnings |
| Frontend: `eslint` on the wider `copilot/` directory | 1 pre-existing error + 6 warnings, all in `CopilotPanel.tsx` (confirmed via `git status` — untouched by Phase 6, a V1-only component) |
| Frontend: no-mute regression (UI) | grep-confirmed zero mute references anywhere in `v3/steps.tsx`, `v3/encounter-flow.tsx`, `v3/chrome.tsx` |
| Frontend: Playwright (`copilot-phase5-persistence.spec.ts` + `copilot-rule7.spec.ts` + new `copilot-phase6-pause-resume.spec.ts`) | **10/10 pass** (after fixing a stale test-fixture login, §19.4, and a test-synchronization bug in the new spec, §19.7) |

### 19.4 Environment blocker — resolved, Playwright now run

Next.js 16 refuses a second dev-server instance for the same project
directory regardless of port; `playwright.config.ts` tried to launch its
own instance on :3001 and was refused because PID 15249 (`next-server
v16.2.7`) already held the project on :3000. On your explicit instruction
the process was killed (`kill -TERM 15249`, confirmed both :3000 and :3001
free before proceeding) and the suite was run.

**Second, genuine environment/fixture problem found and diagnosed (not a
Phase 6 code defect):** both spec files' hardcoded practitioner login
(`luis.gomez@narzim.com`) no longer exists on `marley.local` at all —
confirmed via a read-only `bench console` query
(`frappe.db.get_value("User", "luis.gomez@narzim.com", ...)` → `None`),
causing all 9 tests to fail identically on `Login failed: 401` before
reaching any Copilot code. Diagnosed rather than worked around: verified a
replacement candidate through the same read-only protocol used earlier in
this phase — `admin@narzim.com` exists, `enabled=1`, holds `EB_Practitioner`
(plus `EB_Front Desk`/`EB_Healthcare Admin`/`EB_Nurse` — a stacked role set
that is itself evidence this is a seed/test account, not a real
single-role clinician), and is linked to a real `Healthcare Practitioner`
(`HLC-PRAC-2026-00006`) — the same account already verified and used
earlier in this session's Phase 5 work. Updated both spec files' hardcoded
`PRACTITIONER_EMAIL`/`PASSWORD` constants (a stale-fixture fix, the same
category as the earlier V1→V3 locator fixes — not a new credential
introduced, and not a production credential).

**Result after the fix: 9/9 pass** (`copilot-phase5-persistence.spec.ts`
8/8 + `copilot-rule7.spec.ts` 1/1), ~1.7 minutes total, no Phase 5/Rule 7
regression from any Phase 6 change. `playwright-report/` was restored to
its exact pre-existing committed state afterward (`git checkout --
playwright-report/` + removed the run's own untracked screenshot data) —
the standing instruction not to let ad hoc runs during this work alter
those tracked files.

**No pause/resume-specific Playwright coverage exists** (confirmed: neither
spec exercises pause/resume) — this is unaffected by the above and remains
a disclosed gap for Exit Verification (§19.6).

### 19.5 Phase 6 acceptance criteria (§16) — status

- **AC1** (system events survive persistence/reload): met — Steps 2/3, unit-tested.
- **AC2** (multi-cycle `paused_seconds` sums correctly): met — Step 4, unit-tested.
- **AC3** (unmatched trailing pause counts): met — Step 4, unit-tested; empirical probe (§19.1) did not change this design, only the (unrelated) ASR-fallback question.
- **AC4** (`duration_seconds` reduced by exactly `paused_seconds`): met — Step 5, unit-tested.
- **AC5** (ASR fallback agrees with the primary path): **now genuinely met**, but by NOT subtracting in the fallback — §19.1/§19.2 showed the primary path's wall-clock-minus-pause model and the fallback's Deepgram-native model already agree on their own, each for a different, independently-correct reason.
- **AC6** (system segments never appear in the LLM/UI transcript): met, **after a
  correction found live post-Exit** (§19.8) — Step 3 only filtered the live
  Copilot pipeline; a second, separate archive-fetch path
  (`useEncounterTranscript` → `use-encounter-v3.ts`) rendered
  `capture_paused` as a visible "CLINICIAN" turn whenever the live
  session's own transcript was still empty (e.g. before Start on a
  reopened encounter) — exactly the state neither the unit tests nor
  `copilot-phase6-pause-resume.spec.ts` exercise, since that spec starts
  recording immediately. Now fixed and confirmed in a real browser.
- **AC7** (no duplicate system segments from repeated pause): met — Step 2, unit-tested.
- **AC8** (no Phase 3/4/5 regression): met — 177 backend + 213 frontend unit/integration tests, plus **10/10 Playwright** (Phase 5 persistence suite + Rule 7 + the new Phase 6 pause/resume E2E, §19.7), all green with every Phase 6 change in place.
- **AC9** (no mute UI/segment-writing ships): met — verified by grep, zero mute changes anywhere in Phase 6.

### 19.7 Pause/resume Playwright coverage — added

New file `e2e/copilot-phase6-pause-resume.spec.ts` (modeled on
`copilot-phase5-persistence.spec.ts`'s mocking pattern): drives the real
Pause → Resume → Stop UI flow in a real browser and asserts (1) the toggle
button's label and the "Paused"/"Recording encounter" status text flip
correctly on each click — proof the button is actually wired to
`provider.pause()`/`resume()`, not just internally consistent; (2) neither
system marker ever renders as a visible transcript line; (3) the real
`/api/ai/session/segments` request Stop sends contains `capture_paused`
then `capture_resumed`, both `speaker: "system"`, alongside the real
`doctor` speech segment — proving the full chain (click → provider →
`finalSegments` → the real fetch) end-to-end, which no unit test can.

**A genuine bug was found and fixed while stabilizing this test — in the
test's own synchronization, not in the app.** First version waited for the
"Ready to record" label as the Stop-completion signal and failed
non-deterministically (confirmed via targeted instrumentation, reverted
afterward): `use-copilot.ts`'s `stop()` sets React state to `"processing"`
synchronously the instant Stop is clicked, before `provider.stop()` (and
therefore `_persistTranscript()`'s fetch) has even been awaited, and
`v3/steps.tsx`'s `CaptureStep` has no distinct rendering for `"processing"`
— it falls through to the same "Ready to record" label the true idle and
`"ended"` states also use. The label could therefore become visible before
the segments request was even sent, let alone resolved, making the
following assertion see a still-null captured body on a real, reproducible
fraction of runs. Fixed by waiting for the actual
`page.waitForResponse(...)` matching `/api/ai/session/segments` instead of
any UI label. Verified stable: 8/8 consecutive standalone runs plus a clean
pass in the full 10-test combined suite after the fix (0/8 clean before it).
No application code changed for this fix — `real-provider.ts`/
`use-copilot.ts` behave correctly as designed; only the test's wait
condition was wrong.

### 19.8 Genuine defect found live, post-Exit: system segments leaked through a second, untested transcript path

**Found by the user in a real browser** (a live `HLC-ENC-2026-00316` session,
reproduced after a hard refresh — ruled out as a stale-bundle false alarm
before investigating further), not by any automated check.

**Root cause.** Step 3 filtered `capture_paused`/`capture_resumed` out of
exactly one path: the live Copilot pipeline's `onTranscript` callback
(`use-copilot.ts`). `v3/encounter-flow.tsx`'s `liveTurns` has a **second
transcript source** that path never touched:
```ts
const liveTurns = rec.transcript.length > 0
  ? rec.transcript.map(...)
  : data.transcript;   // <- a completely separate, unfiltered fetch
```
`data.transcript` comes from `useEncounterTranscript` (`use-encounter-v3.ts`
→ `/api/ai/encounter-transcript`) — a one-shot archive read of the same
persisted `AI Transcript Segment` rows, used whenever the live session's
own `transcript` state is still empty. That is exactly the state of a
*reopened, not-yet-started* encounter — consent reset, mic locked — which
is precisely the screen the user was looking at. Neither the unit tests
(which call `provider.pause()` directly, bypassing this hook entirely) nor
`copilot-phase6-pause-resume.spec.ts` (which starts recording immediately,
so `rec.transcript` is never empty) exercise this path — a real, disclosed
gap in Step 7's test coverage, not something either suite was wrong to
miss without knowing this second path existed.

**Fix.** `use-encounter-v3.ts:134` — added `.filter((s) => s.speaker !==
"system")` before the existing per-segment mapping, the identical rule
Step 3 already applies on the live path. The "N turns" counter
(`steps.tsx`) reads off this same array, so it corrected itself
automatically (4 → 3) with no separate change.

**Verified:** `eslint` clean, Vitest 213/213, `tsc` clean (same one
pre-existing unrelated error). Confirmed fixed in the live browser after a
hard refresh — "Transcript 3 turns," `capture_paused` no longer visible.
No unit/e2e test added for this specific path in this pass — recorded as
remaining work below rather than silently claimed as covered.

### 19.6 Exact remaining work before Exit Verification

1. Decide §17 item 6: the historical `paused_seconds` backfill migration
   for pre-Phase-6 sessions — still explicitly deferred, not authorized.
2. `mypy` could not be run in this environment for any Phase 6 step —
   decide whether that gate is required before Exit or waived for this repo state.
3. `copilot-phase5-persistence.spec.ts`/`copilot-rule7.spec.ts`'s
   practitioner login constant was updated from a now-deleted account to
   `admin@narzim.com` (§19.4) — a durable fix to the test fixture, not a
   temporary override; nothing further needed here, noted for completeness.
4. No automated test covers the `useEncounterTranscript`/`data.transcript`
   archive-fetch path fixed in §19.8 (a reopened, not-yet-started
   encounter with prior `capture_paused`/`capture_resumed` segments) — the
   fix is verified live in a real browser only. Add a unit test on
   `use-encounter-v3.ts`'s mapping, and/or a Playwright test that opens an
   encounter with a persisted pause pair *without* starting a new
   recording, before treating this path as durably covered.

## 20. Exit Verification

**Historical `paused_seconds` backfill:** confirmed still deferred, not
authorized. No migration written, no backfill run. Every existing
`AI Encounter Session` row keeps `paused_seconds = 0` (the schema default)
until it next reaches its own terminal transition under the new code.

**`mypy` — confirmed not a CI gate in this repo.** Checked all three
workflow files (`unit-tests.yml`, `install-uninstall.yml`,
`bruno-auth.yml`) and `tests/ci/run_unit_tests.sh`: none run `mypy` or
`ruff`; `unit-tests.yml` runs exactly `bench run-tests` (the
`FrappeTestCase` suite). CLAUDE.md §9 lists `mypy` among aspirational
per-PR requirements, but nothing in this repository's actual CI enforces
it — this is a pre-existing documentation/reality gap, not something Phase
6 introduced or can close. Recorded as an environment limitation
(the tool is not installed in this session's sandbox either); **does not
block Phase 6 Exit**, per your explicit decision.

**Full verification run (single pass each, no repeat loops):**

| Check | Result |
|---|---|
| Backend `tests/ai/` (full suite) | 177/177 pass |
| Frontend Vitest (full suite) | 213/213 pass |
| Playwright: Phase 5 persistence + Rule 7 + Phase 6 pause/resume | 10/10 pass |
| `ruff` on all backend files touched this phase | clean |
| `eslint` on all frontend files touched this phase | clean |
| `tsc --noEmit` | clean (one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts`, confirmed untouched by this phase) |
| `python3 scripts/check_md_headers.py` / `check_md_links.py` | all compliant, 0 broken links |
| No-mute regression | confirmed by grep: zero mute references in `v3/steps.tsx`/`encounter-flow.tsx`/`chrome.tsx`; zero mute-related lines in the `real-provider.ts` diff; `setMuted`/`toggleMute`/`muted` passthrough exists exactly as it did before Phase 6, untouched |
| Schema | `AI Encounter Session.paused_seconds` present, `int(11) NOT NULL DEFAULT 0`, on local `marley.local` only — no production/Frappe Cloud change |

**Complete diff inspected, unrelated changes separated.** Backend repo has
a number of pre-existing modified/untracked files from before and outside
this phase's work (`CLAUDE.md`, `docs/README.md`, `docs/STATUS.md`,
`docs/adr/README.md`, `docs/architecture/ENCOUNTER_FROM_SCRATCH.md`,
`docs/architecture/README.md`, `docs/audit/practitioner/README.md`,
`docs/adr/adr-045-...`, `docs/architecture/ENCOUNTER_UX_RESEARCH.md`,
`docs/architecture/ENCOUNTER_V3.md`,
`docs/architecture/ENCOUNTER_V3_PHASE5_CHECKLIST.md`, `docs/compliance/`,
`prompts/2026-08-25-encounter-progressive-disclosure.md`) — none of these
were touched by this session; confirmed by cross-checking against every
file this session actually wrote or edited. They are excluded from the
proposed Phase 6 commit below.

**Proposed Phase 6 commit contents:**

Backend (`remedisys_healthcare_ai`):
- `remedisys_healthcare_ai/doctype/ai_encounter_session/ai_encounter_session.json` (modified)
- `remedisys_healthcare_ai/doctype/ai_encounter_session/ai_encounter_session.py` (modified)
- `services/encounter_ai_record.py` (modified)
- `services/pause_duration.py` (new)
- `tests/ai/test_pause_duration.py` (new)
- `tests/ai/test_encounter_session_paused_seconds.py` (new)
- `tests/ai/test_collect_asr_usage.py` (new)
- `docs/architecture/ENCOUNTER_V3_PHASE6_CHECKLIST.md` (new)

Frontend (`Healthcare_next_app`):
- `src/components/narzim/encounter/copilot/real-provider.ts` (modified)
- `src/components/narzim/encounter/copilot/real-provider.test.ts` (modified)
- `src/components/narzim/encounter/copilot/types.ts` (modified)
- `src/components/narzim/encounter/copilot/use-copilot.ts` (modified)
- `e2e/copilot-phase5-persistence.spec.ts` (modified — stale login fixture fix)
- `e2e/copilot-rule7.spec.ts` (modified — stale login fixture fix)
- `e2e/copilot-phase6-pause-resume.spec.ts` (new)

**Remaining risks, carried forward, not blocking:**
1. Deepgram's exact billing granularity (audio-duration vs. connection-time) remains unverified beyond what §19.1's probe answered (the `end_ms` clock question) — `_collect_asr_usage` trusts the pre-existing audio-duration assumption, unchanged from before Phase 6.
2. A `capture_paused` segment's `tStart` can lag the true pause moment when Deepgram holds a not-yet-finalized utterance open across the pause (§19.1) — a precision caveat on `paused_seconds`, not a correctness defect.
3. On the `Failed` session path only, not all segments may be persisted before close, so `paused_seconds` can under-count on that specific unhappy path (§18) — pre-existing characteristic, not new.
4. Historical backfill and the reload-mid-pause UI restoration remain deferred by explicit decision, not oversight.

**Exit Verification: PASSED.** No genuine correctness/data-loss/design
defect found during this pass. Nothing staged, committed, or pushed.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.1 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §19.8: genuine post-Exit defect, found live by the user in a real browser (not by any automated check) — `capture_paused`/`capture_resumed` leaked through a second, untested transcript path (`useEncounterTranscript`/`data.transcript`, the archive fallback used before a reopened encounter's recording starts). Fixed in `use-encounter-v3.ts`; confirmed live after a hard refresh. AC6 amended; §19.6 gets a 4th remaining-work item (no automated test covers this path yet) |
| 3.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §20 Exit Verification: historical backfill confirmed deferred; `mypy` confirmed absent from all 3 CI workflows (aspirational-only per CLAUDE.md §9, not a Phase 6 blocker); full single-pass verification (177 backend + 213 frontend + 10 Playwright, all green); no-mute regression confirmed; complete diff inspected and unrelated pre-existing files separated from the proposed Phase 6 commit. Doc status promoted draft → living. Exit Verification PASSED |
| 2.9 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §19.7: added `e2e/copilot-phase6-pause-resume.spec.ts` — real-browser Pause/Resume/Stop E2E proof. Found and fixed a genuine test-synchronization bug (waited on an ambiguous "Ready to record" label instead of the real `/segments` response) — not an app defect; verified 8/8 stable after the fix. AC6/AC8 updated to 10/10 Playwright |
| 2.8 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §19.4: on explicit approval, killed the blocking PID and ran Playwright — hit a second genuine environment issue (the hardcoded practitioner login no longer exists on `marley.local`), diagnosed via read-only bench console check, fixed with a verified replacement test account (`admin@narzim.com`). Phase 5 persistence + Rule 7: 9/9 pass, no regression. `playwright-report/` restored to its exact committed state afterward. AC6/AC8 and §19.6 updated accordingly |
| 2.7 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §19 Step 7: ran a real empirical Deepgram probe (§19.1) that FALSIFIED §11's "end_ms includes paused time" claim — Deepgram's clock does not advance during a no-audio gap. Found and fixed the resulting genuine defect (§19.2): reverted Step 6's `_collect_asr_usage` subtraction (a double-subtraction that under-reported ASR usage), corrected 3 tests. Ran the full Phase 6 test plan (§19.3): 177/177 backend, 213/213 frontend Vitest, schema/no-mute/Phase-3-4-invariants all verified. Playwright blocked on a pre-existing port-3000 process not started this session (§19.4) — reported, not forced. Acceptance criteria reassessed (§19.5); remaining work before Exit listed (§19.6) |
| 2.6 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §18: Step 6 — wired `calculate_session_paused_seconds()` into `_collect_asr_usage`'s never-closed-session `MAX(end_ms)` fallback, summed across every session on the encounter, clamped at 0. All six Phase 6 implementation steps now complete. 7 new tests, 178/178 `tests/ai/` regression. Open: §17's Deepgram `end_ms` question and the historical backfill decision |
| 2.5 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §18: Step 5 — wired `calculate_session_paused_seconds()` into `_stamp_timing()`'s write-once `duration_seconds` finalization (`duration_seconds = max(0, wall_clock - paused_seconds)`), with a defensive try/except degrading to `paused_seconds=0` on a query failure so Stop can never be blocked by AI-bookkeeping trouble. 6 new controller-wiring tests, 171/171 `tests/ai/` regression |
| 2.4 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §18: Step 4 (backend) — added `AI Encounter Session.paused_seconds` (schema only, unwired, default 0, no backfill) and the shared `services/pause_duration.py` helper (pure `calculate_paused_seconds()` + DB wrapper `calculate_session_paused_seconds()`), resolving the trailing-pause ambiguity via evidence-derived `started_at`/`ended_at` per requirement 4 rather than stopping to ask. 15 new tests + 1 integration test, 165/165 `tests/ai/` regression, local `marley.local` migrated |
| 2.3 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §18: fixed the discovered `resegregateSpeakers()` gap on explicit approval — system segments now excluded from the LLM resegregation prompt, merged back into `finalSegments` post-rebuild (no longer deleted by `_syncTranscript()`'s full-reconcile), `persistedCount` corrected to the full merged length, UI-facing return value stays speech-only. 5 tests added, 213/213 full suite |
| 2.2 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | §18: Step 3 (filter system segments out of `_buildTranscript()` and the UI-facing transcript state) implemented and verified. Discovered and reported (not fixed) a `resegregateSpeakers()` gap: no system-segment filter, and it wholesale-replaces `finalSegments`, which would leak audit text into the LLM resegregation prompt and silently delete unpersisted pause/resume audit entries |
| 2.1 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §18 Implementation record: Step 1 (`Speaker`/`mapSpeaker` fixes) and Step 2 (`capture_paused`/`capture_resumed` system events, tests, verification) both implemented and verified; Steps 3+ still pending |
| 2.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Condensed from v1.0 per instruction to move quickly. Re-verified the sequence-number mechanism fresh and precisely (§12 — the most important check). Recorded four decisions as DECIDED (server-side `paused_seconds`, shared helper, mute deferred, reload-mid-pause UI deferred). Marked the Deepgram `end_ms` claim as OPEN QUESTION — no live/controlled test run, per instruction not to spend excessive time on it. No code, schema, migration, or test changed |
| 1.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Initial full read-only Phase 6 design/checklist |
