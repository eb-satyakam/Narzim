# Encounter UX research — the next version

**Doc status:** record · **Created:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.1

> **Frozen as evidence on 2026-09-01.** The current description of the encounter
> screen is [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md). This document is kept for
> the research that led to the three-step decision, now recorded in ADR-054.
>
> It is a dated snapshot, so it is expected to fall out of date and is never
> "corrected" (CLAUDE.md §9). Four `living` documents were describing the same
> screen, which is what made the set unreadable; only one describes it now.

> **Superseded in part — this is now research plus an as-built record.** The 3-step flow shipped on
> 2026-08-26 behind `NEXT_PUBLIC_FEATURE_ENCOUNTER_V2`. Where this document's recommendations were
> followed, deviated from, or dropped is recorded in [§ As built](#as-built--what-shipped-2026-08-26)
> at the end. The single-screen structure sketched under
> [Recommended screen structure](#recommended-screen-structure) was **not** built — see
> [ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md).
>
> The shipped design is documented in
> [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md).

**Evidence labels used throughout:** **CONFIRMED** (verified in code/DB/tests) · **PARTIAL** ·
**PLANNED** · **UNKNOWN** · **INTERPRETATION** (my UX judgement, not a fact).

---

## Executive summary

The Encounter should stop being a **form that a doctor fills** and become **one clinical document
with two lenses over it** — a conversation lens and a record lens — that the doctor moves between
freely and commits once.

The single most consequential recommendation in this document: **build two working steps, not
three.** The proposed Step 3 ("Fill Encounter") should not exist as a step. It is a data-plumbing
task created by our own architecture — the SOAP draft and the Patient Encounter being different
shapes — and it does not correspond to anything a clinician does. Making the doctor perform it
turns our schema problem into their workflow problem.

Two facts drive that conclusion:

1. **The attached design already agrees.** Its steps are `Capture → Review → Save`, and its own copy
   reads *"The note refines as you speak. Open it any time to review, edit, and approve."* There is
   no generate moment and no fill moment in it. Its third step is **committing**, not filling. The
   attached design and the written brief disagree with each other, and **the design is the better of
   the two.**
2. **We already have a graveyard of "transfer" steps.** `hpi`, `physical_examination`, `plan` and
   `notes` are **0 of 131** populated (**CONFIRMED**); `vital_signs_note` is **0 of 75**
   (**CONFIRMED**); `AI SOAP Draft` is **0 rows** (**CONFIRMED**); 25 encounters sit open as drafts
   (**CONFIRMED**). Every place we have asked for a second deliberate act of data entry, the data is
   absent. A step whose only job is moving reviewed text into structured fields will be skipped, and
   skipping it will silently produce empty records.

If there is one document, the brief's hardest questions (§5: does changing the transcript invalidate
the SOAP? does changing the SOAP invalidate the Encounter?) **stop existing** rather than needing
answers. Three artifacts means three sources of truth and a staleness matrix between them. One
document with provenance per field has no staleness problem to design around.

---

## Current-state problems, and what actually causes them

The brief lists symptoms. These are the underlying causes.

| Symptom (from the brief) | Underlying cause | Evidence |
|---|---|---|
| Huge vertical page; 2.6 screens to sign | The note is a **printed page rendered on screen**. Letterhead, address, title block and ID all render before any field, with no `print:` variant | **CONFIRMED** — first input at y=539 of 900 (60% of the first screen); note is 2,189px in an 847px window |
| No effective step navigation | It was built, then removed for width, and its slot was given away | **CONFIRMED** — `SoapSidebar` (204 lines) + `soapSteps` (10 sections with `done`) exist and are never rendered; removed by `d525312` (2026-07-22, *"Remove SoapSidebar; widen page"*); the freed lane went to the AI panel on 2026-07-28 |
| AI Copilot feels disconnected | It is architecturally a **sibling of the note, not a participant in it**. It can only hand over suggestions at the end of a recording, and the accept path is off | **CONFIRMED** — `enable_suggestions = 0` live; suggestions only requested inside `stop()` |
| AI errors show as bare "Error" | The explanatory banner was deliberately deleted on 2026-07-29 as "confusing", but the word "Error" stayed | **CONFIRMED** — `CopilotPanel.tsx:32`; the provider computes a good message with the Deepgram close code and the panel discards it |
| Header timer is meaningless | It counts time since component mount | **CONFIRMED** — `session-clock.tsx` |
| "Today" has two meanings | Badge derives from **status**; KPI and filter tab derive from **date** | **CONFIRMED** — clicking the Today tab returns 0 rows while 7 elements are badged Today |
| Vitals completeness not communicated | Nothing renders completeness, and signing does not check it | **CONFIRMED** — `handleSignClick` validates chief complaint + vaccine-nurse only; 2 of 10 sections |
| Doctor moves between mental contexts | Conversation, draft and record are three places with no shared spine | **INTERPRETATION** |

**Two of the rows above, worked through** (per this repo's rule that a finding
without a user story and a real example isn't yet usable — CLAUDE.md §10):

> **Vitals completeness not communicated.**
>
> **USER STORY.** Dr. Bracamontes finishes a same-day sick visit, dictates
> chief complaint and plan, orders no vaccines, and — rushed — never opens
> the Vital signs section at all → **the system shows** nothing: no
> incomplete-section warning, no red dot, no disabled Sign button → he
> clicks **Sign** → `handleSignClick` (`encounter-screen.tsx:1433`) checks
> exactly two of `soapSteps`' ten sections — `hasChiefComplaint` and, only
> if any vaccine was ordered, that each has a recording nurse — finds both
> satisfied, and submits → **the database actually contains** a
> `Patient Encounter` with `docstatus = 1` (signed, locked) and every
> vitals field null → **consequence:** a permanently signed clinical
> record with no temperature, no weight, no blood pressure — for a
> pediatric visit, no growth-tracking data point — discovered only later,
> if at all, with nothing in the system distinguishing "vitals genuinely
> not indicated" from "vitals forgotten."
>
> **EXAMPLE.** `soapSteps` (`encounter-screen.tsx:681-702`) already computes
> `done` for all ten sections, including `{ key: "o", title: "Vital signs",
> done: Object.values(enc.vitals).some((v) => String(v).trim() !== "") }`
> — the exact boolean this gap needs. `handleSignClick` never reads it; it
> only gates on `hasChiefComplaint` (line 1437) and a per-vaccine nurse
> check (lines 1448-1460). The other eight sections, vitals included, can
> be entirely empty at signature time.

> **Doctor moves between mental contexts** *(INTERPRETATION — the user
> story below illustrates the judgement, it is not a reproduced defect)*.
>
> **USER STORY.** Mid-visit, the patient mentions a symptom the doctor
> wants to re-check before writing the plan → the doctor has to leave the
> SOAP draft, scroll up to the transcript panel, re-read several turns to
> find the mention, then scroll back down and re-find their place in the
> draft to keep writing → **the system shows** three independent surfaces
> — the live conversation transcript, the SOAP draft, and the record being
> assembled for signature — with no link from a drafted sentence back to
> the moment in the conversation that produced it → **the database
> actually contains** a transcript and a SOAP draft with no field-level
> provenance connecting the two (the same gap Rule 6's "AI writes as the
> logged-in physician" already lives with, one level up) → **consequence:**
> the doctor spends part of the visit re-navigating the tool instead of
> listening to the patient, and a rushed doctor is the one most likely to
> skip the re-check rather than lose the thread — which is exactly how the
> vitals gap above happens in practice, not a coincidence.

**Two further causes not in the brief, found during this research:**

- **The doctor is never told what is missing, and the system does not know either.** `soapSteps`
  computes exactly that and throws it away. This is the cheapest high-value fix in the whole
  document. (**CONFIRMED**)
- **Nothing listens to the realtime channel.** The backend publishes `session.stopped` and similar
  to an encounter channel; the frontend has no socket client at all — no `socket.io`, no
  `EventSource`, nothing in `package.json`. Any multi-device or nurse/doctor concurrency design must
  start by building this. (**CONFIRMED**)

---

## The doctor's mental model

The brief offers three candidate models. **None of them is right, because they are all linear.**

Observed reality of a consultation is a **loop**, not a pipeline. A doctor forms a hypothesis in the
first thirty seconds, then spends the visit testing it — asking, examining, revising. Documentation
is not a phase that follows the visit; it is a **residue** the visit leaves behind.

The model I recommend designing to:

```
        ┌──────────────── revise ────────────────┐
        ↓                                        │
  Orient  →  Converse  →  Decide  →  Commit ─────┘
 (who is    (talk, and    (name it,    (attest,
  this?)     examine)     order it)     once)
```

- **Orient** — seconds, not minutes. Age, sex, allergies, what happened last time, why they are here
  today. This must be *free* — no clicking.
- **Converse** — the doctor's attention belongs to the patient, not the screen. Everything the
  system does here must be passive.
- **Decide** — the only part that genuinely needs structured input, because a diagnosis and an order
  have to be machine-readable to reach a pharmacy and a lab.
- **Commit** — one deliberate act, with a truthful summary of what is being attested to.
- **Revise** — the loop back. Non-negotiable, and the reason a wizard is the wrong shape.

**Why this matters for the design:** documentation should be a *by-product* of Orient/Converse/Decide,
surfaced for verification at Commit. The failure mode of every EHR — and of our current screen — is
making documentation a fifth activity that competes with the other four.

---

## Competitive and industry research

**Reliability note:** the strengths and weaknesses below are **INTERPRETATION** from public
marketing material, published research, documentation and demos. I have not used these products
against real patients, and I have deliberately not attributed specific UI mechanics to specific
vendors where I am not certain. Where a claim is well documented publicly I say so; where it is my
reading, it is labelled.

### Ambient AI documentation (the category we are in)

**Abridge, Nabla, Suki, Microsoft DAX Copilot, Freed, Heidi Health** — publicly documented common
shape:

| Pattern | What it is | Publicly documented? |
|---|---|---|
| **Record → draft → review → push** | The clinician records, an AI drafts a note, the clinician reviews it, and it is then written into the EHR | Yes, across all six |
| **The draft is the deliverable** | The product's output is a *note*, and the structured EHR write is a downstream integration concern, often via HL7/FHIR | Yes |
| **Consent is an explicit gate** | A recording start affordance that states recording is happening | Yes |
| **Note refines during the encounter** | Rather than one generation at the end | Partially — claimed by several |

**The critical structural difference between them and us — and it is the crux of this document:**

Those products are **bolt-ons to somebody else's EHR**. They must produce a *note* and hand it over,
so a "review the draft, then push it" step is unavoidable for them: the push crosses a system
boundary.

**We own both sides.** There is no boundary to cross. Copying their three-phase shape would import a
constraint we do not have, and pay for it with a step our doctors would have to perform by hand.
This is the strongest argument against the proposed Step 3, and it is an argument from *our*
architecture, not from theirs.

### Established EHRs

- **Epic** — publicly documented: SmartTools (SmartPhrases/SmartText) for templated text, and a
  navigator/activity list for moving through an encounter. **INTERPRETATION:** the navigator concept
  — a persistent list of the parts of this encounter with completion state — is the single most
  transferable idea for us, and is essentially what `SoapSidebar` already implements. Widely
  documented weakness: click burden and note bloat.
- **Oracle Health / Cerner, MEDITECH** — **INTERPRETATION:** strong structured capture, and
  documentation burden is the most consistently reported clinician complaint in the usability
  literature.
- **athenahealth, Tebra** — **INTERPRETATION:** ambulatory-focused, lighter-weight; closer to our
  clinic size than Epic's inpatient model.

### What to take, what to leave

**Take:** the persistent navigator with completion state (Epic-like). Consent as an explicit gate.
The note refining during the visit rather than at the end. Propose-then-approve for every AI write.

**Leave:** the record → review → push pipeline. We do not need the push. Also leave note templating
that inflates length — our `hpi`/`plan` fields are already empty; the answer is not more fields.

---

## The proposed 3-step workflow, assessed

### What is strong

- **Naming the phases is right.** A doctor genuinely is in one of two modes: *with the patient* or
  *finishing the record*. Making that visible is good.
- **Capture as a distinct place is right.** It is where consent belongs, and consent is currently our
  worst defect.
- **A stated review moment is right and safety-critical.** An AI-drafted clinical note must have an
  explicit human verification point.

### What is confusing or wrong

1. **Step 3 should not exist.** Reasons in the Executive summary. It is data plumbing, not clinical
   work, and every previous "transfer" step we shipped is empty.
2. **"Generate SOAP" as a discrete event is the wrong mental model** — and the attached design
   already avoids it. If generation is an event, the doctor waits for it, and a failed generation
   becomes a blocked workflow. If the draft accretes continuously, a failure degrades to *"the draft
   is thinner than it could be"*, which is survivable. (Our Rule 7 already says an AI failure must
   never block the physician; a discrete generate step contradicts Rule 7 structurally.)
3. **Validation placed at the end only.** Missing vitals should be visible from the first minute, not
   revealed at the signing gate when the patient has left the room.
4. **"SOAP" is the wrong noun for the doctor-facing UI.** It is a documentation format, not a stage
   of care. **INTERPRETATION:** name the lens after what it is for — *the note* — and keep SOAP as
   the internal structure.

### Direct answers to the brief's questions

| Question | Answer |
|---|---|
| Should Step 3 exist separately? | **No.** Two working steps + a commit action |
| Should SOAP and Encounter be the same workspace? | **Yes — the same *document*, not merely the same workspace.** This is the core recommendation |
| Should doctors be able to skip steps? | **Yes, always.** Manual-only documentation must remain a first-class path, not a fallback |
| When should AI generation happen? | **Continuously during capture**, plus an explicit re-run the doctor can trigger |
| When should structured data be written? | **Continuously**, into the existing autosaving Encounter draft, as suggestions are accepted. Never in a separate transfer step |
| When should validation happen? | **Continuously** (ambient, non-blocking) and **summarised at commit** (deliberate) |
| What stays visible across steps? | Patient identity + allergies, the completeness spine, the Copilot, save state |
| What should be progressive disclosure? | See the Progressive disclosure section |

---

## Recommended information architecture

**One document. Two lenses. One commit.**

```
Encounter (ONE autosaving document — the Patient Encounter draft)
│
├── Persistent spine .......................... always visible, every lens
│   ├── Patient identity strip ................ name · age · sex · MRN · ALLERGIES
│   ├── Completeness rail ..................... the 10 sections, done/current/missing
│   ├── Save state ............................ saving / saved / retrying / offline
│   └── Copilot ............................... lens-aware, always reachable
│
├── LENS 1 — Conversation ..................... "I am with the patient"
│   ├── Consent gate .......................... blocks recording, not the visit
│   ├── Recording controls .................... start / pause / resume / stop
│   ├── Live transcript ....................... speaker-attributed, correctable
│   └── Draft-forming indicator ............... "note is taking shape · N items"
│
├── LENS 2 — Record ........................... "I am finishing the note"
│   ├── Narrative ............................. summary · complaint · HPI · exam
│   ├── Structured ............................ vitals · symptoms · diagnoses
│   ├── Orders ................................ rx · labs · procedures · therapies · vaccines
│   └── Closing ............................... review details · follow-up
│
└── COMMIT .................................... one deliberate act
    └── Attestation summary ................... what is in the note, what is missing,
                                                what the AI wrote that you have not read
```

**Why "lens" and not "step":** a lens is a way of looking at one thing; a step is a stage you leave
behind. Switching lenses must be free and instant in both directions, must never be gated on
completion, and must never move data. Both lenses read and write **the same draft**.

**What this buys us, concretely:** the brief's §5 staleness questions dissolve. There is no
"downstream AI-generated content" to invalidate, because the transcript, the draft and the record
are not three artifacts — the transcript is *evidence*, the record is the *document*, and the AI's
contribution is a *provenance flag on individual fields of that document*.

---

## Interaction design

### Navigation

The completeness rail is the spine and is present in both lenses. It reports `N of 10`, marks each
section done / current / missing, and jumps on click. It **does not hide sections** — see the
Progressive disclosure section for why hiding is dangerous here.

Lens switching is a single control, always in the same place, with no confirmation and no data
movement. **INTERPRETATION:** a doctor interrupted mid-sentence must be able to get to the record
lens and back in under a second, because interruption is the normal case in a clinic, not the
exception.

### Editing

Every field keeps direct inline editing. This is the path that must never regress: it is the only
one that works with no AI, no microphone and no network.

### AI writes

**One rule, no exceptions: the AI proposes, the doctor disposes.** No AI-originated value ever
appears in the document as committed content without an explicit human accept. We already implement
this correctly (`onAcceptSuggestion`, `aiFlags`) — the requirement is to keep it while making
accepting cheap.

### Commit

A **review drawer**, not a modal and not a wizard step. Reasons in the Signing section.

---

## Copilot strategy

The Copilot should be **one continuous conversation that knows which lens you are in**, not three
different assistants.

| Lens | It can see | It should be good at |
|---|---|---|
| Conversation | transcript so far, patient context, draft-in-progress | *"What did she say about the fever?"* — recall without breaking eye contact |
| Record | everything above + the full current draft | *"What's missing?"* · *"Rewrite the assessment"* |
| Commit | everything above + validation state | *"What am I about to sign?"* |

**Design positions:**

1. **Persistent rail, not floating.** A floating assistant over a clinical document occludes exactly
   the content being discussed. We already learned this: the panel reports `0` layout inset
   specifically so it never pushes the form.
2. **Structured actions, not prose, for anything that writes.** Every Copilot action that touches the
   document must arrive as an accept/dismiss proposal. The plumbing exists
   (`chat-actions-mapping.ts` → `ClinicalSuggestion`).
3. **Fix the offer/affordance gap.** Currently the AI writes *"I can add symptomatic treatment
   recommendations if you like"* and the only way to accept is to type prose. Whenever the model
   offers an action, that offer must render as a button.
4. **Never show a bare error.** The provider already computes a specific cause; surface it, with a
   recovery action.
5. **Explainability is a link, not a paragraph.** Every AI-authored value should be able to answer
   *"why do you say that?"* by pointing at the transcript lines it came from. We store
   `sequence_number`, `start_ms` and `end_ms` per segment already, so this is achievable.

---

## Voice editing strategy

The brief's instinct is correct and I want to sharpen why.

**The risk is not that the model mishears. It is that a clinic room contains a patient, a parent and
a doctor all talking, and an always-listening editor cannot know which speech is addressed to it.**
A misheard *transcription* is visible and correctable. A misheard *command* silently changes a
medical record.

### Required interaction

```
Push-to-talk (held or explicit start/stop, scoped to one section)
   ↓
Show what was heard ................ verbatim, editable
   ↓
Show the proposed change ........... as a DIFF against current text
   ↓
Accept · Edit · Reject ............. explicit, no default action, no timeout
   ↓
Undo remains available ............. until commit
```

### Non-negotiables

- **Scoped, never global.** "Edit with voice" is invoked *on a section*. A global voice editor that
  can touch any field is not safe in a room with background speech.
- **Never auto-apply.** No confidence threshold high enough. There is no acceptable false-positive
  rate for silently editing a clinical record.
- **Diff, not replacement.** Show what changes, not just the new text.
- **Distinguish dictation from instruction.** *"The fever started yesterday evening"* (content) and
  *"change the assessment to viral URI"* (instruction) are different acts. **UNKNOWN:** whether one
  model call can separate these reliably enough — this needs a spike before committing to the
  feature. Recommended mitigation: two explicit affordances (*Dictate* vs *Instruct*) rather than
  inferring intent.
- **Full audit.** Voice-originated edits get their own provenance value, distinct from typed and from
  AI-suggested. If a record is ever disputed, "the doctor said this out loud and approved the
  transcription" must be reconstructible.

**INTERPRETATION:** voice editing is the highest-risk feature in this brief and the least essential
to the core problem. It should ship last, behind its own flag, after the two-lens model is proven.

---

## AI provenance

We already have the right primitive: `aiFlags` with `ai` → `edited` transitions, and a `freshFields`
glow. It needs to become a first-class, persisted, four-state model.

| State | Meaning | Must be visible |
|---|---|---|
| `human` | The doctor typed it | No marker (this is the default and needs no decoration) |
| `ai_suggested` | Proposed, **not** in the document | Distinct, clearly *pending* |
| `ai_accepted` | AI-authored, human accepted, **unread in detail** | Yes — this is the important one |
| `ai_edited` | AI-authored, human changed it | Yes, and it counts as reviewed |
| `voice_applied` | Voice instruction, human approved | Yes, if voice editing ships |
| `record` | Carried from the patient's existing record | Yes — distinct from all of the above |

**The state that matters most is `ai_accepted`.** A doctor clicking Accept on six suggestions in four
seconds has not read them. The commit summary must be able to say *"4 AI-written fields you have not
edited"*, which the existing `aiTotal`/`aiReviewed` counters in the unrendered `SoapSidebar` already
compute.

**Persistence gap (CONFIRMED):** `aiFlags` is React state only. It does not survive reload and is not
stored on the encounter. For provenance to be auditable — and NOM-024 may require it, see open
decisions — it must be persisted server-side. **This is the one genuinely new backend requirement in
this document.**

---

## Progressive disclosure

**A warning first, and it is a clinical-safety point rather than a UX preference.**

Progressive disclosure normally means *hide what is not needed now*. In a document a clinician
**attests to**, hiding is not neutral: content the doctor never saw is content they cannot have
verified, and signing already validates only 2 of 10 sections (**CONFIRMED**). Aggressive collapsing
would make an incomplete note *easier* to sign.

So: **disclose progressively for input, never for review.** Before commit, everything in the
document must have been presented.

| Tier | Content | Rationale |
|---|---|---|
| **Always visible** | Patient identity + **allergies**; completeness rail; save state; consent/recording state; Copilot entry | Allergies are always visible because a prescribing error is the highest-severity failure on this screen |
| **Visible, collapsed when empty** | The 10 sections, each showing its count | Zero-height when empty, one line when not — cheap, and honest about what exists |
| **On demand** | Full patient history; previous encounters; lab trends; transcript | Needed sometimes, never needed *now* |
| **Secondary panel** | Transcript archive, provenance detail, audit trail | Evidence, not workspace |
| **Copilot only** | Arbitrary questions about this patient or visit | Unbounded; a UI cannot enumerate it |
| **Removed from the working view entirely** | Clinic letterhead, address, logo, title block | **This is 60% of the first screen (CONFIRMED).** It belongs on the printed/PDF output, not in the editor |

**The letterhead is the biggest single above-fold win available** and it is nearly free: it is
already rendered by a separate report component for print.

---

## Responsive strategy

| Width | Layout | Copilot | Rail | Notes |
|---|---|---|---|---|
| **1440 desktop** | Two lanes: document + Copilot | Persistent right rail | Horizontal, sticky | Target |
| **1280 laptop** | Two lanes, narrower Copilot | Persistent, narrower | Horizontal, sticky | Copilot has a minimum useful width; below it, switch to drawer rather than squeeze |
| **1024 tablet** | **One lane**; Copilot becomes a drawer | Drawer over content | Horizontal, sticky, scrolls | **CONFIRMED problem today:** the AI rail keeps its width here and metadata wraps mid-value (*"DOB 09 / Oct 2014"*). A tablet in a clinic is a real device, not a shrunk desktop |
| **402 mobile** | One lane, one section at a time | Full-screen sheet | Compact `N of 10` + jump menu | **INTERPRETATION:** mobile is for *reviewing and capturing*, not for finishing a note. Recording and transcript review must work; full documentation need not. Say this explicitly rather than shipping a form nobody can use |

**Rule:** the completeness rail and the identity/allergy strip survive at every width. They are the
last two things to go, because they are what makes the screen safe.

---

## States and edge cases

The brief asks for 21 states. Grouping them by what the doctor must be able to tell:

**Recording lifecycle** — ready · consent required · connecting · recording · paused
(auto vs manual, and it must say which) · stopping · completed.
*Requirement:* the difference between "not recording because you have not started" and "not recording
because it broke" must be unmistakable. Today both can read as `Error` (**CONFIRMED**).

**Transcript** — empty · arriving · attributed · **unattributed** · correcting · sealed.
*Requirement:* surface unattributed turns honestly. **CONFIRMED:** 23% of stored turns are `unknown`,
because `SPEAKER_MAP` has exactly two slots (0→doctor, 1→patient) and any third voice falls through
to `unknown` — in a paediatric clinic the third voice is usually the parent. There is also a
`fallback-nowords` path that labels a turn `doctor` unconditionally.

**Draft** — none · forming · formed · stale (transcript advanced since) · failed · re-running.
*Requirement:* "failed" degrades to a thinner draft, never to a blocked screen.

**Editing** — clean · dirty · saving · saved · save failed/retrying · offline · conflict (another
device or a nurse).
*Requirement:* **CONFIRMED gap** — the conflict state cannot currently be detected at all, because
nothing listens to the realtime channel.

**Commit** — incomplete (with a list) · ready · committing · signed · cancelled · amend requested.
*Requirement:* the doctor sees what is missing *before* they reach for the button.

**Session** — returning to a draft · resuming a live recording · another clinician holds it.
*Requirement:* **CONFIRMED** — 137 of 137 sessions are stuck in `Recording` with no `ended_at`,
because `dispose()` deliberately does not stop the session (documented tradeoff, 2026-07-25). Any
"resume" design must first make sessions terminate.

---

## Recommended screen structure

```
┌────────────────────────────────────────────────────────────────────────────┐
│ ← Nelly Romina Martin Salas · F · 11 · MRN-…156   ⚠ No known allergies     │  identity + allergies
│                                    [Conversation | Record]   ✓ Saved  Sign │  lens switch · state · commit
├────────────────────────────────────────────────────────────────────────────┤
│ 3 of 10 ▓▓▓░░░  ● Summary ● Vitals ● Dx ○ Plan ○ Rx ○ Labs ○ … (scrolls)   │  completeness rail (~34px)
├──────────────────────────────────────────────────┬─────────────────────────┤
│                                                  │  Narzim AI              │
│   ACTIVE LENS                                    │  (lens-aware)           │
│                                                  │                         │
│   Conversation:                                  │  · recall               │
│     consent · controls · live transcript         │  · what's missing       │
│     "note forming · 6 items"                     │  · proposals as         │
│                                                  │    accept/dismiss       │
│   Record:                                        │                         │
│     narrative → structured → orders → closing    │  [ask…]                 │
│                                                  │                         │
└──────────────────────────────────────────────────┴─────────────────────────┘
```

**Deliberate differences from today:**

1. **Letterhead gone** from the working view (print/PDF only) — reclaims ~430px of first screen.
2. **Allergies promoted into the always-visible strip** — highest-severity risk, currently ~500px
   down inside a history panel.
3. **Sign in the header**, reachable from anywhere, gated by the rail rather than by scroll position.
4. **The rail is the spine**, present in both lenses.
5. **Autofocus the first empty field** on load. **CONFIRMED:** focus is `BODY` today — the doctor must
   click before typing.
6. **The timer either states what it measures or is removed.** Recording elapsed is meaningful; time
   since page mount is not.

---

## Design principles

1. **The patient outranks the screen.** Anything that needs attention during the conversation is
   mis-designed.
2. **One document, many lenses.** Never two artifacts that can disagree.
3. **The AI proposes, the doctor disposes.** No exceptions, no confidence threshold.
4. **A failing AI must degrade, never block.** (Existing Rule 7 — restated because a discrete
   "generate" step would violate it structurally.)
5. **Never hide what will be attested to.** Progressive disclosure for input, not for review.
6. **Say the true thing or nothing.** No unlabelled timer, no word "Error" without a cause, no
   badge that means two things.
7. **Provenance is permanent.** Who wrote each field survives reload, and survives signing.
8. **Every offer is an affordance.** If the AI can do it, there is a button.
9. **Allergies are never more than one glance away.**
10. **Manual documentation is first-class.** No microphone, no network, no AI — still a complete
    clinical record.
11. **Completeness is continuous.** Never revealed for the first time at the signing gate.
12. **Commit is deliberate and honest.** It states what is present, what is missing, and what the AI
    wrote that the doctor has not read.

---

## Recommendation

**Build the two-lens single-document model, behind a feature flag, in this order:**

1. **Consent gate + session termination.** Not UX polish — it is the compliance floor, and the
   Capture lens has nowhere honest to stand without it.
2. **The spine:** identity + allergies strip, completeness rail (render the existing `soapSteps`),
   truthful save state.
3. **Letterhead to print-only, autofocus, sign in header.** Largest measured win for the least code.
4. **Lens switch** over the existing sections — no data movement, no new artifact.
5. **Continuous drafting + accept/dismiss inline**, replacing end-of-recording generation.
6. **Persisted provenance**, then the commit review drawer that uses it.
7. **Voice editing last**, behind its own flag, after a spike on dictation-vs-instruction.

### The trade-off I am accepting, stated plainly

The two-lens model is **harder to build** than the three-step wizard. A wizard is three routes with
local state; two lenses over one document means shared state, a real provenance model, and no
convenient boundary to hide behind.

I recommend it anyway because the wizard's simplicity is **borrowed from the wrong place**: it is
simple for us and complex for the doctor, who must perform the transfer step and then reason about
whether their three artifacts still agree. Given the evidence that our previous transfer steps are
0-populated, I do not believe the wizard's third step would be used, and a step that is skipped
silently produces empty records.

### Does the attached design fit?

**Yes — and it is closer to this recommendation than the written brief is.** Adopt its `Capture →
Review → Save` shape and its continuous-drafting copy. Three changes before it can ship:

1. **"HIPAA" is the wrong jurisdiction.** Our primary market is Mexico (**LFPDPPP / NOM-024**).
2. **"audio retained 30 days" contradicts our actual policy and our code.** **CONFIRMED:**
   `audio_retention_days = 0`, `retain_audio = 0`, enforced in `integrations/deepgram.py`; audio never
   reaches Frappe at all (ADR-009). Telling a patient we keep audio for 30 days when we keep none is
   a consent defect in the *safe* direction, but it is still false.
3. **"v3 · 94% confident" needs to mean something or go.** **UNKNOWN** what such a number would be
   computed from. A precise-looking confidence score on a clinical draft invites exactly the
   rubber-stamping this design should prevent. Recommend replacing it with what we can actually
   substantiate: *"8 sections drafted · 4 not yet reviewed by you"*.

---

## Implementation preparation

### Feature flag (per instruction, 2026-08-25)

`.env.local` already documents a convention — `NEXT_PUBLIC_FEATURE_AI_WORKFORCE` and
`src/lib/feature-flags.ts` — but **CONFIRMED: neither the module nor any consumer exists.** This work
would establish it.

```
# .env.local
NEXT_PUBLIC_FEATURE_ENCOUNTER_V2=true      # local: on. preview/production: unset until approved
```

**Structure the flag so the old path is one deletion, per the "remove old design code easily"
requirement:**

```
src/components/narzim/encounter/
├── v1/                     ← today's screen, moved wholesale, untouched
├── v2/                     ← the two-lens implementation
└── index.tsx               ← reads the flag, renders one or the other
```

Deleting v1 later is then `rm -rf v1` plus removing one branch in `index.tsx`. Branching *inside*
`encounter-screen.tsx` would make the old code impossible to extract cleanly — that is the mistake to
avoid.

### Component architecture

`encounter-screen.tsx` is **6,630 lines / 288KB with ~40 components (CONFIRMED)**. v2 should not
inherit that. Suggested split: `EncounterShell` (spine + lens switch) · `ConversationLens` ·
`RecordLens` · `sections/*` (one file per clinical section, reusing today's bodies) ·
`CommitDrawer` · `CopilotRail`.

### State architecture

One `useEncounterDraft` owning the document, provenance and save state — the single writer. Lenses
are views over it and hold no clinical state of their own. Keep the existing debounced autosave +
localStorage backup; it works (**CONFIRMED**).

### APIs that can be reused as-is

**Almost everything.** `save_draft`, `complete_encounter`, `cancel_encounter`, `book_follow_up`, all
search/create master endpoints, `start_session` / `stop_session` / `refresh_deepgram_token`,
`append_segment` / `sync_transcript`, `review-details`, the suggestion endpoints, the report/PDF
path. The AI session and segment layers are **CONFIRMED tested — 30 of 30 passing.**

### Backend changes actually required

1. **Persisted field provenance** — the one genuinely new requirement.
2. **Realtime consumer** (frontend) for the channel the backend already publishes to.
3. **Session termination** — end-on-unload beacon and/or an `idle_timeout` sweep. `close_reason`
   already defines `idle_timeout` with no producer; a sweep needs `scheduler_events` uncommented.
4. **`vital_signs_note` write path** (frontend-only; the backend already accepts it).
5. **Speaker map beyond two speakers** — needs a product decision before code.

### Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Rebuilding a working clinical screen breaks something silently | **High** | The flag; and **un-skip the test suite first** — **CONFIRMED: 35 of 38 encounter tests skip on hardcoded seed IDs and the run still reports OK** |
| Two lenses drift into two sources of truth | High | Single writer; lenses hold no clinical state |
| Continuous drafting increases LLM cost/latency | Medium | Debounce; measure before shipping |
| Cheap accept-all invites rubber-stamping | **High (clinical)** | Commit summary counts unreviewed AI fields; never a bulk accept-all |
| Voice editing mutates records from ambient speech | **High (clinical)** | Push-to-talk, section-scoped, diff + approve, ships last |
| Provenance migration for 144 existing encounters | Low | Backfill as `human`; only new writes carry real provenance |

### Open product decisions

Carried forward and still unresolved (see [`ENCOUNTER_FROM_SCRATCH.md`](ENCOUNTER_FROM_SCRATCH.md)
D1–D9), plus new ones from this research:

| # | Decision | Blocks |
|---|---|---|
| D2 | What the 137 existing consent rows represent | The consent gate, and whether a disclosure is owed |
| **U1** | Does NOM-024 require field-level authorship in the record? | Whether persisted provenance is a *requirement* or an *improvement* |
| **U2** | Three-speaker attribution — doctor / patient / guardian? | The transcript model and `SPEAKER_MAP` |
| **U3** | Is mobile "review + capture only" acceptable? | The responsive scope |
| **U4** | Does missing vitals *block* signing or *warn*? | The commit gate — clinical, needs a clinician |
| **U5** | Ship voice editing at all, given the risk? | Roadmap scope |

---

## As built — what shipped 2026-08-26

The 3-step flow (Capture → Review SOAP → Fill Encounter) shipped behind
`NEXT_PUBLIC_FEATURE_ENCOUNTER_V2` at `/encounters/[id]`. Decision:
[ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md).
Design: [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md).

### Followed

| Recommendation | As built |
|---|---|
| Consent must be asked, not assumed | Consent is a question on the capture page, in front of the mic it unlocks. `useCopilot` is driven directly; `CopilotHost`'s auto-start is not used |
| Show what is *not recorded*, from the record | "Not recorded (N)" panel on steps 2 and 3, derived from the encounter, never invented |
| No fabricated insights, no confidence scores | Nothing fabricated is rendered; FE-17 added to the frontend constitution |
| Documenting by hand must not be second-class | "Offline encounter" is offered always, not only on failure, and reaches the same signature |
| Allergies must distinguish "none recorded" from "none" | "None **recorded** — ask before prescribing" |
| Sign is a commit, and must say what it commits | "Before you sign" — blocks / not recorded / what you are attesting to |

### Deviated

| Recommendation | What shipped, and why |
|---|---|
| **One document, one screen, two lenses** | **A 3-step flow.** Chosen by the product owner on 2026-08-25 and confirmed final. The single-screen prototype was deleted rather than parked (ADR-054, alternative 1) |
| Completeness rail ("3 of 10") | Not built. Reduced to step cards plus the "Not recorded" panel. A progress count over fields that are 0–1% populated would score noise |
| A v3-owned component layer | **Inverted.** Step 3 renders V1's own components and saves through V1's own payload builder. Rebuilding them drifted within a day (ADR-054, alternative 2) |

### Not yet built

Voice editing, the Copilot proposal/accept loop, AI provenance that survives a
reload, and progressive disclosure beyond the step split. Tracked in
[`ENCOUNTER_V3.md`](ENCOUNTER_V3.md) §8.

### Corrections to this document's own findings

- §Session states "137 of 137 sessions are stuck in `Recording`". Re-measured on
  `marley.local` 2026-08-26: **141 of 144**, three Stopped, oldest open since
  2026-07-25. The cause is unchanged and now also recorded as GAP-2 in
  [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md).
- `enable_soap_generation` is **1** on this site, not 0 — SOAP drafting is
  enabled and unused. `enable_suggestions` is 0.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.1 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added a worked USER STORY + EXAMPLE (CLAUDE.md §10) for the "vitals completeness not communicated" and "doctor moves between mental contexts" rows |
| 2.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Added "As built"; recorded the 3-step decision (ADR-054) superseding the single-screen structure; corrected the stuck-session count to 141/144 |
| 1.0 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Created — UX research for the next Encounter version |
