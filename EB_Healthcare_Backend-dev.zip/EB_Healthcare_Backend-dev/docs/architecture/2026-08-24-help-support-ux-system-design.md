# Help & Support — UX and system design specification

**Doc status:** living · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.6

> The approved design for Remedisys Help & Support. Normative until built, then corrected against
> reality — not a proposal.
>
> **Inputs:** the product decisions taken 2026-08-24 (thread + auto-capture; central eBasics triage;
> per-user visibility; native fields; PHI Option 2 — strip identifiers, keep the shape).
> **Evidence it rests on:** [engineering audit](../audit/2026-08-24-help-support-form-audit.md) ·
> [customer-experience audit](../audit/2026-08-24-help-support-customer-experience-audit.md) ·
> [integration plan](../planning/2026-08-24-helpdesk-integration-plan.md) (owns the validated native
> path and the deploy gate) · [known issues](../KNOWN_ISSUES.md) (owns the test-harness constraint).
>
> **No code has been written against this document.**

---

## A. Executive summary

> **BUILD STATUS — 2026-08-25. Phase 1 is complete; Phase 2 is complete except notifications.**
> Built and verified on `marley.local`, not planned:
>
> | | |
> |---|---|
> | Wide panel | Home · My requests · Thread · Composer |
> | Severity | mapped to native `priority` + `ticket_type`; the SLA follows, so *patient care is affected* moved a response target from 18:00 to 10:30 |
> | Status | Helpdesk's own word, verbatim (D9) |
> | Endpoints | create · list · thread · reply, all through Helpdesk's own methods |
> | Attachments | on the first message and on replies |
> | Settings | declared in `scripts/helpdesk_settings_spec.json` and checkable |
>
> **50 backend tests · 168 frontend tests · Bruno 15/15.**
>
> **Not built, and deliberately.** Automatic context capture (§K/§L) — gated on the open PHI
> decision D8; the UI section for it was removed rather than left showing values the request does not
> carry. Notifications (§P) and SLA presentation (§Q). Custom fields on Helpdesk doctypes, now locked
> against by D10. Everything in Phase 3. Where this document describes those, it describes intent,
> not code.
>
> **Four defects were fixed that no plan predicted**, each found by reading a live row rather than by
> review: a ticket linked to the reporter's patient record carrying an MRN (§K.1), agent replies
> emailed out of the estate (Z14), a request filed without detail having no opening message, and
> severity being collected and silently discarded.

Remedisys staff will report problems from inside the EHR and follow them to resolution without ever
leaving it. Frappe Helpdesk remains the system of record; Remedisys owns the entry point, the
evidence, and the loop back to the clinician.

The shipped slice creates a real `HD Ticket` and stops there. This design adds the two things that
make it a support desk rather than a suggestion box: **a severity the clinician can mean** — including
*patient care is affected* — and **a thread they can come back to**.

| | Shipped today | This design |
|---|---|---|
| Severity | none (all `Medium`) | four options mapped to native priority + SLA |
| Context | none | sanitized module, route shape, version, browser, client errors |
| Clinic | not carried | structured field, so central triage can filter |
| After sending | nothing | your requests · thread · replies · notifications · status |
| Visibility | own tickets only | unchanged — own tickets only; eBasics agents see all |
| PHI | screenshots warned about | identifiers never auto-captured, by construction |

**Six of the audit's twenty-four gaps need no new backend at all** — `priority`, `ticket_type`,
`sla`/`response_by` and `feedback` are native fields the form does not yet surface. That is where
Phase 1 gets its value-for-effort.

### A1 · Approved product decisions

The register. **Locked** means agreed and not to be reopened while building; **open** means the
design must not depend on one answer.

| # | Decision | State |
|---|---|---|
| D1 | UX shape: thread + auto-capture, inside Remedisys, no redirect to `/helpdesk` | **Locked** |
| D2 | eBasics is the central support organisation for every clinic | **Locked** |
| D3 | **No individual agent is assigned. Tickets are created unassigned and sit in a central queue that authorised eBasics agents claim from** | **Locked** — see below |
| D4 | Normal staff see only their own tickets; eBasics agents see all | **Locked** |
| D5 | `customer` stays empty; clinic travels as structured metadata | **Locked** |
| D6 | Native Helpdesk fields wherever possible — `priority`, `ticket_type`, SLA, `feedback` | **Locked** |
| D7 | Severity includes a first-class *patient care is affected* option, mapped to native priority | **Locked** · **built** |
| D8 | **PHI handling — how much context may be captured and what may reach eBasics** | **OPEN** |
| D10 | **No custom fields on Helpdesk doctypes.** Whatever a ticket needs to carry travels in native fields or in the description body | **Locked** — see below |
| D9 | **Ticket status is Helpdesk's own, verbatim — `Open`, `Replied`, `Resolved`, `Closed`. No second vocabulary** | **Locked** — see below |

#### D10 · No custom fields on Helpdesk doctypes (locked)

Remedisys adds **no** Custom Field to `HD Ticket` or any other Helpdesk doctype. Verified 2026-08-25:
`fixtures/custom_field.json` contains none for any `HD *` doctype, and no support code creates one.

This supersedes the five fields proposed in §M (`custom_clinic`, `custom_module`,
`custom_route_shape`, `custom_app_version`, `custom_client_agent`). Anything a ticket must carry goes
in a native field or in the description body — the zero-customization interim already described in
§8 — and the loss is real and accepted: context in prose can be read but not **filtered**, so central
triage cannot slice by clinic or module without opening tickets.

Why it is worth accepting anyway: a custom field on a vendored doctype is a fixture that must exist
before any code reads it, which is the exact failure that took down the lab list
([release record](../release/2026-08-24-pre-to-main.md)); it is another schema change riding on an
app we do not own and cannot control across upgrades; and it makes the Remedisys and Helpdesk data
models entangled in a way that a description block does not.

#### D9 · Helpdesk's status is the single source of truth (locked)

The clinician sees the same status word the agent sees in `/helpdesk`. Remedisys
maintains **no mapping, synonym or friendlier restatement** of it.

An earlier build translated `Open` → "Waiting for support" and `Replied` →
"Waiting for you". That reads better in isolation and is worse in practice: the
agent and the clinician then use different words for the same fact and disagree
the moment they speak to each other. It also silently dropped any status a clinic
adds to `HD Ticket Status`, because a map only knows the values it was written
for.

Consequences: the API returns `row.status` unchanged; the UI type is a plain
string, not a four-value union; known values are localised (`Abierta` for
`Open` in `es-MX` — localisation, not relabelling) and an unknown status renders
**as-is** rather than as a wrong guess. Friendlier explanatory copy may be added
later as *secondary* text beside the status, never in place of it.

#### D3 · No individual assignment (locked)

Tickets are created **unassigned**: no default assignee, no named eBasics employee, no automatic
Assignment Rule that targets an individual. Authorised eBasics Helpdesk Agents see the central queue
and claim work from it.

**No support person's identity may be hard-coded anywhere** — not in code, not in a fixture, not in
config, not in this document. The design must therefore never depend on knowing who an agent is.

| Consequence | Requirement |
|---|---|
| Ticket creation | leaves `_assign` and `agent_group` unset — already true of the shipped code, verified on tickets `0005`–`0007` |
| Routing | none at creation. Assignment is a human act in `/helpdesk` |
| Notifications | addressed to the **reporter** only. Nothing notifies "the assignee", because there is none |
| UI copy | never names a person. "Someone will respond", never "Ana will respond" |
| Data model | no `assigned_to`-shaped field of our own; if assignment is needed later it is Helpdesk's native `_assign` |
| Future model | team, shift or on-call rotation must be addable **without touching this design** — which is why nothing here reads an assignee |

> ⚠️ **Configuration risk, found 2026-08-24.** Helpdesk ships two **enabled** Assignment Rules —
> `Product Experts - Support Rotation` and `Billing - Support Rotation`. Both teams currently have no
> users, so nothing is assigned. **Adding a single user to either team would begin auto-assigning
> tickets to that individual**, silently violating D3. Before go-live those rules must be disabled, or
> deliberately left member-less with the reason recorded. This is Helpdesk-side configuration, not
> code, so no test can catch it — it belongs on the deployment checklist.

---

## B. Product goals

| # | Goal | Measured by |
|---|---|---|
| G1 | A clinician can report a problem in under 20 seconds, mid-consult | time from panel open to sent |
| G2 | A ticket arrives actionable — no "which screen were you on?" round trip | share of tickets whose first agent action is a clarifying question |
| G3 | Patient-care-affecting problems are unmistakable and prioritised | Urgent tickets responded to within SLA |
| G4 | A clinician can always answer "what happened to my request?" | share of tickets whose reporter returns to the thread |
| G5 | No patient identifier ever leaves the clinic through a support ticket | audit of captured context; zero identifiers in `custom_route_shape` |
| G6 | eBasics can triage across clinics without opening each ticket | tickets filterable by clinic, severity and module |

**Non-goals.** Replacing phone escalation for emergencies. Becoming a clinical incident-reporting
system (that is a regulated artefact and a separate decision). Agent-side UI — eBasics works in
`/helpdesk`, which we do not modify.

---

## C. User journey

```mermaid
journey
    title Clinician reports a problem mid-clinic
    section Notices
      Something breaks on the encounter screen: 2: Clinician
      Opens Help & Support from the same screen: 4: Clinician
    section Reports
      Sees relevant help first: 4: Clinician
      Picks how bad it is: 5: Clinician
      Types one line: 4: Clinician
      Confirms the screenshot: 4: Clinician
      Sends: 5: Clinician
    section Waits
      Sees when someone will respond: 5: Clinician
      Gets on with the patient: 5: Clinician
    section Resolves
      Notified that support replied: 5: Clinician, Agent
      Answers in the thread: 4: Clinician
      Marks it resolved: 5: Clinician
```

The design optimises the **Reports** row for speed and the **Resolves** row for trust. Those are
different problems and today neither is solved.

---

## D. Information architecture

```
Help & Support  (wide right panel, invoked from the sidebar user menu on any clinic screen)
│
├── Help (default)                     existing route-keyed content, unchanged
│   └── "Still need help?" → Your requests
│
├── Your requests                      NEW · Phase 2
│   ├── open tickets, newest first     status · severity · last activity
│   ├── resolved (collapsed)
│   └── [ New request ]
│
├── Request thread                     NEW · Phase 2
│   ├── header: subject · status · severity · reference
│   ├── messages, oldest first         clinician + agent, attachments inline
│   ├── captured context (collapsed)   what was sent, plainly readable
│   └── composer: reply · attach · mark resolved
│
└── New request  (Composer)            Phase 1 replaces today's form
    ├── How bad is it?                 4 options → native priority
    ├── What happened?                 one line + optional detail
    ├── Evidence                       screenshot (confirm) · file · paste/drop
    ├── Captured automatically         reviewable, removable
    └── footer: expected response · [ Send request ]
```

**One panel, four views, one entry point.** No new sidebar item, no redirect to `/helpdesk` — a
clinician never sees a second product.

---

## E. Screen-by-screen UX

### E1 · Composer (Phase 1)

```
┌─ New request ──────────────────────────────────── ✕ ─┐
│ ← Your requests                                       │
│                                                        │
│ How bad is it?                                         │
│ ┌────────────────────┐ ┌────────────────────┐         │
│ │ ?  I have a        │ │ ⚠  Something isn't │         │
│ │    question        │ │    working         │         │
│ └────────────────────┘ └────────────────────┘         │
│ ┌────────────────────┐ ┌────────────────────┐         │
│ │ ⛔ My work is      │ │ 🚑 Patient care is │         │
│ │    blocked         │ │    affected        │         │
│ └────────────────────┘ └────────────────────┘         │
│                                                        │
│ What happened?                                         │
│ [ Prescription drawer will not save              ]     │
│ [ optional: what you expected, what happened     ]     │
│                                                        │
│ Evidence                                               │
│ ┌──────────────┐  [ 📷 Capture screen ]                │
│ │ [thumbnail]  │  [ 📎 Attach a file ]                 │
│ │  ✕ remove    │  or paste / drop                      │
│ └──────────────┘                                       │
│                                                        │
│ Sent automatically  ▾                                  │
│   Module: Encounters · Page: /encounters/:id            │
│   App 2026.08.24 · Chrome 141 · macOS 15                │
│   2 client errors        [ don't send this ]            │
│                                                        │
│ ─────────────────────────────────────────────────────  │
│ Someone will respond within 4 hours                    │
│                                    [ Send request ]    │
└────────────────────────────────────────────────────────┘
```

**Deliberate choices.**
- **Severity is first and is four large targets**, not a dropdown. It is the field that changes what
  happens to the ticket, and a mid-consult user should hit it in one tap.
- **`🚑 Patient care is affected` is visually distinct** (danger tone) and never pre-selected.
- **Subject is one line with a live counter** at 140 (audit `B7`); the detail field is optional,
  because requiring prose is what stops people reporting.
- **Captured context is shown, collapsed, and removable** — the honest version of auto-capture. The
  clinician can always see exactly what leaves the clinic.
- **The SLA sentence sits next to the Send button**, where the question "when will someone look at
  this?" is actually asked.

### E2 · Your requests (Phase 2)

```
┌─ Your requests ─────────────────────────────── ✕ ─┐
│                                    [ New request ] │
│ ● Prescription drawer will not save                │
│   ⛔ Blocked · Open · agent replied 1h ago      ›  │
│ ● Lab list slow to load                            │
│   ⚠ Not working · Waiting on you · 2d           ›  │
│ ─────────────────────────────────────────────────  │
│ Resolved (3)                                    ▾  │
└────────────────────────────────────────────────────┘
```

`Waiting on you` is computed, not stored — the last message is from an agent. It is the single most
useful line in the list, because a stalled ticket is nearly always waiting on the reporter.

### E3 · Request thread (Phase 2)

Header carries subject, status pill, severity and the reference. Messages oldest-first, attachments
inline as thumbnails. Captured context is a collapsed block at the bottom of the first message.
Composer: reply, attach, and a `Mark resolved` affordance that maps to native feedback + status.

---

## F. Empty, loading and error states

| Surface | State | Behaviour |
|---|---|---|
| Your requests | empty | "You haven't sent any requests yet." + `New request`. Never a bare empty list |
| Your requests | loading | three skeleton rows, no spinner-only screen |
| Your requests | failed | "Your requests could not be loaded." + Retry — the pattern the Activity timeline already uses, for the reason it exists: a failed fetch must never look like "you have none" |
| Thread | loading | skeleton messages |
| Thread | failed | inline error + Retry, draft reply preserved |
| Composer | not permitted | the panel says support is not enabled for this account and to ask the clinic administrator (shipped) |
| Composer | offline / send failed | the request stays on screen with everything attached, an inline error, and Retry. **Never clears the form** |
| Composer | file rejected | inline, naming the file and the reason (too large / type not allowed / PDF could not be read) |
| Composer | sending | Send disabled with a spinner; per-file progress once attachments exceed 1 MB |
| Whole panel | Helpdesk unreachable | "Support is temporarily unavailable. Please call the clinic's support line." Rule 7 shape: the EHR itself is never affected |

---

## G. Ticket lifecycle

```mermaid
stateDiagram-v2
    [*] --> Open : clinician sends<br/>priority + SLA set
    Open --> Replied : agent replies<br/>notify clinician
    Replied --> Open : clinician replies<br/>SLA clock resumes
    Open --> Resolved : agent resolves
    Replied --> Resolved : agent resolves
    Resolved --> Open : clinician reopens<br/>"still broken"
    Resolved --> Closed : clinician confirms<br/>optional feedback
    Resolved --> Closed : auto after N days<br/>no response
    Closed --> [*]
    note right of Open
        Native HD Ticket Status values.
        We add no statuses of our own.
    end note
```

All four states are Helpdesk's shipped `HD Ticket Status` records (`Open`, `Replied`, `Resolved`,
`Closed`). Auto-close after N days needs a value for N — see §Z.

---

## H. Clinician workflow

```mermaid
flowchart TD
    A["Problem on any clinic screen"] --> B["Sidebar user menu → Help"]
    B --> C{"Answer in the<br/>route help?"}
    C -->|yes| D["Self-served — no ticket"]
    C -->|no| E["Your requests"]
    E --> F{"Already<br/>reported?"}
    F -->|yes| G["Open the thread<br/>add information"]
    F -->|no| H["New request"]
    H --> I["Pick severity"]
    I --> J["One line: what happened"]
    J --> K["Capture screen / attach / paste"]
    K --> L["Review what is sent automatically"]
    L --> M["Send"]
    M --> N["Reference + expected response"]
    N --> O["Notification when support replies"]
    O --> P["Reply in thread"]
    P --> Q{"Fixed?"}
    Q -->|yes| R["Mark resolved"]
    Q -->|no| P
```

The path to `D` is deliberately on the way to everything else: deflection is free only if it is not a
detour.

---

## I. eBasics agent workflow

Agents work entirely in `/helpdesk`, which we do not modify. What this design owes them:

| Need | How it is met |
|---|---|
| Know the clinic without asking | `custom_clinic` on the ticket, filterable and in list view |
| Know severity without reading | native `priority`, set from the clinician's choice |
| Know the screen | `custom_module` + `custom_route_shape` |
| Know the build | `custom_app_version` — answers "are they on a stale deploy?" first, not fifth |
| Reproduce | screenshot + `custom_client_errors` |
| Reply to the clinician | native reply; the clinician is notified in the EHR |
| Route by team | native `agent_group` + Assignment Rules |

**How work reaches an agent (D3).** It does not. Tickets land in one central, unassigned queue and
an agent **claims** what they pick up. There is no routing step and no owner until a human takes one.

```
New ticket  →  central queue (unassigned)  →  agent claims  →  agent replies  →  resolved
                     ▲                              │
                     └────── nothing auto-assigns ──┘
```

**Triage view eBasics should configure** (Helpdesk-side configuration, no code): the queue filtered to
unassigned + open, grouped by `priority`, with columns for clinic, module, status and `response_by`.
Urgent and patient-care tickets sort first. Claiming is Helpdesk's native assign action.

**What must NOT be configured:** any Assignment Rule that assigns an individual — see the D3
configuration risk above.

---

## J. Permission model

```mermaid
flowchart TD
    subgraph Clinic["Clinic staff — Website Users"]
        S1["Doctor / Nurse / Front desk<br/>EB_* role + HD Customer"]
    end
    subgraph EB["eBasics support"]
        A1["Support agent<br/>Agent role"]
    end
    subgraph HD["Helpdesk"]
        T1["HD Ticket — own"]
        T2["HD Ticket — colleague's"]
        T3["HD Ticket — another clinic's"]
    end

    S1 -->|"read + reply"| T1
    S1 -.->|"BLOCKED"| T2
    S1 -.->|"BLOCKED"| T3
    A1 -->|"read all — is_agent bypass"| T1
    A1 --> T2
    A1 --> T3

    style T2 stroke-dasharray: 4
    style T3 stroke-dasharray: 4
```

**Rules, all verified against the shipped code:**

1. Staff hold exactly one Helpdesk role: **`HD Customer`**, `desk_access = 0`. Granted by
   `services/support.py::ensure_support_role` at provisioning and by the backfill patch. Never
   `Agent`, and never `Agent Manager` — which implies `System Manager`, i.e. read access to every
   patient record.
2. **`customer` stays empty.** Helpdesk scopes a non-agent to
   `contact == user OR raised_by == user OR owner == user OR customer IN get_customers(user)`. With
   `customer` empty the last clause never matches, so a clinician sees only their own tickets. Clinic
   is carried as metadata precisely so that visibility is never used to achieve grouping.
3. **eBasics agents see everything** via `is_agent()`, which bypasses the scope entirely. They
   therefore need no customer linkage — which is what makes rule 2 free.
4. **Defence in depth:** our `list_my_tickets` filters on `raised_by`/`owner` explicitly rather than
   relying only on Helpdesk's criteria, so a future upstream change cannot silently widen it.
5. Every endpoint checks permission **before** any write, as the shipped `create_support_ticket` does.

---

## K. PHI and data-minimization model

> ⚠️ **This section is OPEN (D8), not locked.** What follows is the current **working rule** —
> Option 2, strip identifiers and keep the shape — specified in enough detail to build against and to
> argue with. It is deliberately not closed: how much context may be captured, and how much of it may
> reach a central vendor, depends on Z1 (the processor agreement) and on a clinical-risk view nobody
> has given yet. **Treat every rule below as reversible**, and do not let anything outside this
> section assume it is settled. The one property that should survive any answer is the *mechanism* —
> capture is decided by an allow-list, so tightening or loosening it is a table edit, not a rewrite.

> **Status 2026-08-24: nothing here is implemented, and the UI that displayed it has been
> removed.** The composer briefly showed a "Sent automatically" block; it was deleted rather than
> left showing values the request does not actually carry. No sanitizer exists, no context is
> collected, and no context field is sent. This section remains the intended design.

### K.1 · The Contact linkage (resolved)

Helpdesk's `set_contact` resolves a ticket's `contact` by email match. In a clinic
a staff member is often also a patient, so that resolves to their **patient**
Contact — whose name can carry an MRN (observed: `sarvesh patient 2-MRN-2026-0000171`,
linked to `Patient MRN-2026-0000171`). Central triage means an eBasics agent would
see it. **No capture, sanitizer or screenshot is involved** — it happens inside
Helpdesk on a field this design never sets, which is why no allow-list could catch it.

`create_support_ticket` now clears `contact` and `customer` after insert.
Clearing rather than substituting a staff Contact, because
`validate_portal_contact` rejects any contact that is not `get_session_contact()`,
and that resolves by `{"user": …}` — which on a real site matches both the patient
Contact and a clean one, picked arbitrarily. Winning that race means editing
patient master data. An empty contact is a state Helpdesk supports: its own
`api.get_one` falls back to `raised_by`, so the agent sees the staff email, which
is the correct identity for a support request.

**Working rule — PHI Option 2, strip identifiers, keep the shape.** Automatic capture must never
contain a patient name, MRN, encounter id, patient id, diagnosis, medication or clinical note.

```
SAFE      Module: Encounters · Page: /encounters/:id · App 2026.08.24 · Chrome 141
NOT SAFE  /encounters/HLC-ENC-2026-00144 · /patients/MRN-2026-0000162
```

**Enforced by construction, not by discipline.** The sanitizer is an **allow-list**: the client maps
`location.pathname` against a fixed table of known route patterns and emits the pattern, never the
path. An unrecognised route degrades to its module name alone.

| Real path | Emitted |
|---|---|
| `/encounters/HLC-ENC-2026-00144` | `Encounters` · `/encounters/:id` |
| `/patients/MRN-2026-0000162` | `Patients` · `/patients/:id` |
| `/patients/MRN-.../labs/HLC-LAB-...` | `Patients` · `/patients/:id/labs/:id` |
| something unmapped | `Unknown` · *(no path)* |

Allow-list, not a regex strip, because **fail-closed matters more than fidelity**: a deny-list ships a
new identifier the moment a route is added, and nobody notices.

**Client errors** get the same treatment: error name plus first message line, run through an
identifier scrubber (`MRN-…`, `HLC-…-…`, long digit runs), capped at 3 errors × 200 characters. A
message that still matches an identifier pattern after scrubbing is dropped entirely.

**Screenshots are never automatic.** The clinician presses Capture, sees a preview, and confirms — a
screenshot of the EHR is a screenshot of PHI, and consent must be an action, not a setting. Redaction
is Phase 3; until it exists the preview plus the warning is the control.

**Clinic metadata is included and is business-sensitive, not PHI.** Central triage requires it.
Whether it may cross to eBasics under a processor agreement is §Z's first open question.

**Logs** carry ticket name and counts only — never body, filename, or context. Rule 10, unchanged.

---

## L. Automatic context-capture rules

| Field | Source | Rule |
|---|---|---|
| Module | route allow-list | always |
| Route shape | route allow-list | pattern only; unmapped → omitted |
| App version | build constant | always |
| Browser / OS | `navigator.userAgent`, parsed | family + major version only |
| Locale | active `next-intl` locale | `en` / `es-MX`, so agents know the reply language |
| Clinic | session company | always; business-sensitive |
| Captured at | client clock + timezone | always |
| Client errors | in-memory ring buffer, last 3 | scrubbed, capped, dropped if still identifier-shaped |
| Screenshot | explicit capture | only on confirm |
| Encounter / patient id | — | **never** |

The ring buffer is client-side and session-scoped; nothing is persisted in the browser. What is sent
is exactly what the panel displays.

---

## M. Native Helpdesk field mapping

**Severity → priority.** One severity engine, Helpdesk's.

| Clinician sees | `priority` | `ticket_type` | Intent |
|---|---|---|---|
| I have a question | `Low` | `Question` | training / how-to |
| Something isn't working | `Medium` | `Bug` | degraded, has a workaround |
| My work is blocked | `High` | `Incident` | cannot complete a task |
| **Patient care is affected** | **`Urgent`** | `Incident` | clinical impact now |

All four priorities and all four types are already seeded. SLA response targets come from the
`Default` SLA per priority and are configured Helpdesk-side, not in code.

> **Built 2026-08-24** (`create_support_ticket(subject, description, severity)`). Measured effect,
> same option tapped in the same UI:
>
> | | before wiring (`0010`) | after wiring (`0011`) |
> |---|---|---|
> | priority | `Medium` | **`Urgent`** |
> | ticket_type | `Unspecified` | **`Incident`** |
> | response due | 18:00 | **10:30** |
>
> Seven and a half hours earlier, because the SLA follows priority natively — no date is set by us.
> An omitted severity defaults to `not_working` so an older caller is unaffected; an unrecognised
> value is **rejected with 400, never downgraded**, since silently turning "patient care is affected"
> into `Medium` is the exact failure the parameter exists to prevent.

**Other native fields:** `subject`, `description`, `status`, `sla` / `response_by` / `resolution_by`,
`feedback` (Mark resolved), `raised_by` / `contact` / `owner` (set by Helpdesk from the session),
`via_customer_portal`.

**`agent_group` and `_assign` are deliberately left unset** (D3). Remedisys never writes either, and
no Assignment Rule may fill them with an individual. They remain available for a future team or
on-call model without any change here.

**Custom fields — NOT built. Superseded by D10 (2026-08-25).** The table below records what was
proposed and is retained only so a future reader knows the option was considered and rejected, not
overlooked. Context travels in the description body instead; triage loses the ability to filter by
clinic or module, which is the accepted cost.

| Field | Type | Why |
|---|---|---|
| `custom_clinic` | Link → Company | triage across clinics |
| `custom_module` | Data | group tickets by area |
| `custom_route_shape` | Data | reproduce without asking |
| `custom_app_version` | Data | rule out stale builds first |
| `custom_client_agent` | Data | browser-specific defects |

Client errors and locale ride in the description block; they are read, not filtered.

> **Deploy consequence.** Custom fields are fixtures, so they exist only after `bench migrate`. This
> is the exact failure mode already recorded in the [integration plan §10](../planning/2026-08-24-helpdesk-integration-plan.md)
> and the [release record](../release/2026-08-24-pre-to-main.md): code that selects a field the
> database lacks takes down the whole list. Any read path must tolerate their absence.

---

## N. Frontend and backend responsibilities

| Concern | Owner |
|---|---|
| Panel, views, severity control, states | frontend |
| Route allow-list + sanitizer + error ring buffer | **frontend** — only the client knows the route, and sanitizing before transmission is the whole point |
| Screenshot capture, preview, confirm | frontend |
| Draft persistence | frontend, `sessionStorage`, cleared on send |
| Multipart forwarding, auth | BFF route |
| Severity → priority/type mapping | **backend** — the mapping is policy and must be identical for every client |
| Second-line sanitizer check | backend, defence in depth: reject a context payload containing an identifier pattern |
| Ticket create / list / thread / reply / feedback | backend, over native Helpdesk methods |
| Notifications on agent reply | backend hook |
| Permission enforcement | backend, always |

**Sanitize on the client, verify on the server.** Neither alone is enough: the client is the only
place with the truth, the server is the only place we control.

---

## O. API contract

BFF routes under `/api/support/*`; each forwards to one whitelisted method with the user's Bearer JWT.
No new authentication anywhere.

| BFF | Method | Backend | Phase |
|---|---|---|---|
| `/api/support/availability` | GET | `get_support_availability` | shipped |
| `/api/support/tickets` | POST | `create_support_ticket` | **built, severity wired** |
| `/api/support/tickets` | GET | `list_my_tickets` | **built** |
| `/api/support/tickets/[id]` | GET | `get_ticket_thread` | **built** |
| `/api/support/tickets/[id]/replies` | POST | `reply_to_ticket` | **built** |
| `/api/support/tickets/[id]/feedback` | POST | `resolve_my_ticket` | P2 — not built |

**`create_support_ticket` — extended, backward compatible**

```
severity : "question" | "not_working" | "blocked" | "patient_care"   (default "not_working")
subject  : str, required, ≤ 140
detail   : str | None, ≤ 5000                     ← body cap, audit E2
context  : JSON | None  { module, route_shape, app_version, client_agent,
                          locale, clinic, captured_at, client_errors[] }
file     : multipart, 0..5                        ← unchanged
→ 201 { ticket, subject, priority, status, response_by }
```

`response_by` is returned so the panel can state the expectation without a second call.

**`list_my_tickets`** → `{ tickets: [{ name, subject, status, priority, severity, last_activity_on,
waiting_on: "you"|"support", unread }], total }` — `waiting_on` computed from the last message's
sender.

**`get_ticket_thread`** → `{ ticket: {...}, messages: [{ author_kind: "you"|"support", body,
attachments[], sent_on }], context: {...} }`. Attachment URLs are private `File` URLs, fetched
through the BFF like every other private file.

**`reply_to_ticket`** wraps Helpdesk's own `create_communication_via_contact` — the customer-side reply
already exists natively; we add no messaging model.

Errors keep the shipped envelope: `401` unauthenticated · `403` no support role · `400` validation ·
`404` not your ticket · `429` rate limited · `502` upstream. `404` rather than `403` for another
user's ticket, so ticket existence is not disclosed.

---

## P. Notification model

```mermaid
sequenceDiagram
    participant Agent as eBasics agent (/helpdesk)
    participant HD as Helpdesk
    participant Hook as Remedisys hook
    participant Notif as Notification (/notifications)
    participant Clin as Clinician (EHR)

    Agent->>HD: reply on HD Ticket
    HD->>HD: Communication (sent)
    HD-->>Hook: after_insert
    Hook->>Hook: reference is HD Ticket?<br/>recipient = raised_by
    Hook->>Notif: "Support replied to your request"<br/>subject only, never the body
    Notif-->>Clin: bell + /notifications
    Clin->>Clin: opens thread in Help & Support
```

- Reuses the existing `/notifications` surface. No email from Remedisys; Helpdesk's own email stays
  off until §Z's decision.
- **Notification text carries the ticket subject and reference, never the reply body** — a support
  reply can quote a chart.
- Events that notify: agent replied · status changed to Resolved · Urgent ticket acknowledged.
- Notifications are per-reporter only, consistent with §J.

---

## Q. SLA presentation

`response_by` is set on every ticket today and shown nowhere. This design surfaces it in three places
and nowhere else:

| Where | Copy |
|---|---|
| Composer footer, before sending | "Someone will respond within 4 hours" — derived from the SLA for the chosen severity, so it **updates as the clinician changes severity** |
| Confirmation | "Request **0042** sent. Someone will respond by 14:30 today." |
| Thread header | "Response due 14:30" while `Open`; nothing once replied |

Rules: relative for the composer ("within 4 hours"), absolute once a real ticket exists. Never a
countdown — a ticking clock on a clinician's screen is pressure without purpose. If the SLA is missing
or breached, say "as soon as possible" rather than a negative number.

---

## R. Attachment workflow

```mermaid
flowchart TD
    A["Clinician: Capture screen / Attach / Paste / Drop"] --> B{"Type + size<br/>allowed?"}
    B -->|no| C["Inline error naming the file and the reason"]
    B -->|yes| D["Thumbnail + remove, in the panel"]
    D --> E["Send: multipart to BFF"]
    E --> F["Backend: allow-list + count + size re-checked"]
    F --> G["Staged as private File rows — unattached"]
    G --> H["helpdesk api.new(doc, attachments)"]
    H --> I["Re-parented to the description Communication"]
    I --> J["Also attached to the HD Ticket"]
    J --> K["Agent sees it in /helpdesk under the sender's own filename"]
```

Verified properties of this path, all already true: files are **private**; the sender's **filename is
preserved** even when Frappe dedupes identical bytes; a shared physical file is **safe to delete**
because Frappe reference-counts; **PDFs are parsed** by Frappe and a malformed one is refused, so the
UI must say so readably.

Limits: 5 files, 10 MB each (`max_file_size`, unset → 10 MB). Client shows size and rejects early;
server re-checks. Raising the ceiling requires nginx `client_max_body_size` in the same change.

---

## S. Future voice and screen recording (Phase 3)

**Voice note.** No backend work: `webm`/`m4a`/`ogg`/`wav` are already accepted and were verified
end-to-end. `MediaRecorder` with `audio/webm;codecs=opus`, `audio/mp4` fallback for Safari, a 3-minute
cap, waveform + replay before sending, and an explicit stop — never a hot mic. Opus at ~24 kbps keeps
3 minutes near 0.5 MB, well inside the ceiling; raw `wav` would exceed it in under two.

**Screen recording.** `getDisplayMedia`, and it needs more care than voice because the clinician may
share a window containing another patient's chart. Required: an explicit consent step naming that
risk, a **mandatory preview before sending**, a hard 60-second cap, and no audio unless separately
chosen. If preview and redaction cannot both be delivered, ship voice and defer recording.

**Annotation and redaction.** Canvas over the screenshot: box, arrow, and an opaque redact tool.
Redaction must **rasterise** — never a CSS overlay that a recipient can remove.

**Deflection.** Search across the existing help content and `/guide` above the Composer entry, with
the top matches shown before the New request affordance.

---

## T. Accessibility

- **Focus:** moves to the panel heading on open, to the first severity option in the Composer, to the
  reply box in a thread, and returns to the invoking control on close.
- **Announcements:** `aria-live="polite"` for send success, status changes and load failures;
  `role="alert"` for validation errors (shipped). Today's success state announces nothing — audit `D1`.
- **Severity control:** a labelled `radiogroup`, arrow-key navigable, not four buttons.
- **Attachments:** a labelled list with a count; each remove button names its file.
- **Escape** closes the panel, but with an unsent draft it asks first — losing a report to a stray key
  is audit `B6` and `C23`.
- Full keyboard operation, visible focus rings, AA contrast including the danger tone on
  `Patient care is affected`, and no meaning carried by colour alone — each severity has an icon and a
  label.
- Copy stays plain in both locales; every string goes through the catalogues.

---

## U. Mobile and responsive behaviour

| Width | Panel |
|---|---|
| ≥ 1280 px | right panel, 560 px |
| 768–1279 px | right panel, 480 px |
| < 768 px | full-screen sheet, one view at a time, back navigation between them |

- Touch targets ≥ 44 px; severity becomes a single-column stack.
- **Paste does not exist on mobile** — the primary affordances become Camera and Photos, and Capture
  screen is hidden where unsupported rather than shown broken.
- Long threads virtualise; the reply box is sticky above the keyboard.
- The existing 360 px drawer is **not** a target width for this panel; it is the width the
  customer-experience audit identified as too narrow.

---

## V. Analytics and events

Consistent with the app's existing `track()` usage (`encounter.signed`, `prescription.created`).
**No PHI, no subject text, no filenames** — the ticket reference and shape only.

| Event | Properties |
|---|---|
| `support.panel_opened` | `module` |
| `support.deflected` | `module`, `article_id` |
| `support.request_started` | `module` |
| `support.request_sent` | `ticket`, `severity`, `ticket_type`, `attachment_count`, `has_screenshot`, `context_removed`, `seconds_to_send` |
| `support.request_failed` | `reason_code` |
| `support.thread_opened` | `ticket`, `waiting_on` |
| `support.reply_sent` | `ticket` |
| `support.resolved_by_user` | `ticket`, `feedback` |

`seconds_to_send` measures G1; `context_removed` tells us whether clinicians trust the capture — if it
is frequently removed, the capture is wrong.

---

## W. Security considerations

| Risk | Control |
|---|---|
| PHI in auto-captured context | allow-list sanitizer, client-side, verified server-side (§K) |
| PHI in a screenshot | explicit capture + preview + confirm; redaction in Phase 3 |
| PHI in a support reply notification | notification carries subject and reference only |
| Attachment exposure | `is_private = 1`; served only through the authenticated BFF |
| Ticket enumeration | `404`, not `403`, for another user's ticket |
| Privilege creep | `HD Customer` only; `Agent Manager` never granted — it implies `System Manager` |
| Cross-clinic leakage | `customer` empty; clinic carried as metadata; agents see all by role, by design |
| Unbounded ticket creation | rate limit per user per hour (audit `E1`) — **not yet implemented** |
| Oversized payloads | 5 files × 10 MB, body cap 5000 chars, server-enforced |
| Stored XSS via description | escaped before it reaches the Text Editor field (shipped, verified) |
| Malicious PDF | Frappe parses and refuses malformed PDFs; error surfaced readably |
| PHI in logs | ticket name and counts only (Rule 10, shipped) |

---

## X. Acceptance criteria

**Phase 1 — Composer**
1. A clinician can send a request choosing one of four severities; the ticket carries the mapped
   native `priority` and `ticket_type` per §M.
2. `Patient care is affected` produces `priority = Urgent`.
3. The ticket carries clinic, module, route shape, app version and browser.
4. **No captured field contains a patient name, MRN, encounter id or patient id** — asserted by a test
   that submits from `/patients/MRN-2026-0000162` and `/encounters/HLC-ENC-2026-00144` and inspects
   the stored ticket.
5. An unmapped route degrades to module only, never a raw path.
6. The composer states the expected response time before sending, and it changes with severity.
7. Subject shows a live counter and cannot be silently truncated.
8. A failed send preserves everything the user entered.
9. The clinician can see and remove the captured context before sending.
10. `en` and `es-MX` in parity; no hardcoded strings.
11. **A ticket is created unassigned** — `_assign` and `agent_group` both empty (D3) — asserted by a
    test, so a future Assignment Rule cannot change this unnoticed.
12. No support person's name, email or user id appears anywhere in the code, fixtures, catalogues or
    UI copy.
23. Backend tests pass **on `test.marley.local`** with a visible `Ran N tests` line — see
    [known issues](../KNOWN_ISSUES.md) for why not `marley.local`.

**Phase 2 — Thread**
24. Your requests lists only the caller's own tickets; a colleague's is not listed and returns `404`
    when addressed directly.
13. The thread shows both sides' messages with attachments.
14. A clinician can reply, and the reply appears to the agent in `/helpdesk`.
15. An agent reply produces exactly one notification to the reporter, containing no reply body.
16. `waiting_on` correctly reflects who owes the next message.
17. A clinician can mark a request resolved; native status and feedback are updated.
18. Every list and thread surface has distinct empty, loading and error states (§F).

**Phase 3 — Advanced evidence**
19. A voice note records, previews and attaches, capped at 3 minutes.
20. A screenshot can be annotated and redacted, with redaction rasterised.
21. Screen recording requires explicit consent and a preview before sending.
22. Help search appears above New request and `support.deflected` fires when it is used.

---

## Y. Implementation phases

| Phase | Scope | Backend | Frontend | Gate |
|---|---|---|---|---|
| **1** ✅ | Composer: severity → priority/type, counter, better errors. *Context capture and SLA display dropped from this phase — D8 and §Q* | `create_support_ticket` extended. **No custom fields — D10** | severity control, wide panel | criteria 1–13 |
| **2** ◐ | Thread: your requests, detail, replies, status, attachments. **Notifications and `resolve_my_ticket` remain** | `list_my_tickets`, `get_ticket_thread`, `reply_to_ticket` built | three views, states | criteria 14–20 |
| **3** ☐ | Voice, annotate/redact, screen recording, deflection | none for voice | recorder, canvas editor, `getDisplayMedia`, search | criteria 21–24 |

**Cross-cutting, still outstanding:** the rate limit (audit `E1`) and frontend component tests
(audit `G1`) were both scoped to ship with Phase 1 and did **not**. Recording that plainly rather
than quietly moving the goalposts — they are the two things this phase owes.

**Sequenced this way** because Phase 1 is the cheapest change to what agents receive and needs no new
UI patterns; Phase 2 is the largest and is what earns clinician trust; Phase 3 is craft that is
worthless if 1 and 2 are wrong.

---

## Z. Open questions

| # | Question | Blocks | Owner |
|---|---|---|---|
| Z1 | **Does a data-processing agreement cover clinic metadata and support attachments reaching eBasics?** Central triage means one vendor sees material from every clinic | Nothing technically; it is the compliance basis for the whole design | Sarvesh (security/compliance) |
| Z2 | Who is on call for `Urgent` / patient-care tickets, and within what target? The SLA sentence is a promise | Phase 1 copy | gaurav (product) |
| Z3 | Should `Patient care is affected` also trigger something out-of-band (phone, SMS, on-call)? A ticket may be too quiet for a clinical impact | Phase 1 | gaurav + Sarvesh |
| Z4 | Auto-close after how many days without a reply? | Phase 2 | gaurav |
| Z5 | Enable Helpdesk's own email intake and email notifications? Content leaves the estate if so | Phase 2 notifications | Sarvesh |
| Z6 | Retention for support screenshots and recordings — do they follow the clinical retention policy or a shorter one? | Phase 3 | Sarvesh |
| Z7 | Is a satisfaction rating wanted, or is Mark resolved enough? | Phase 2 (criterion 17) | gaurav |
| Z8 | Should `helpdesk` join `.github/helper/site_config.json`'s `install_apps`? Until it does, CI provisions a site without it and a green CI run silently skips the support module | test confidence for every phase | Sarvesh |
| Z9 | Do we need a screen-recording consent record, or is in-session consent sufficient? | Phase 3 | Sarvesh |
| Z10 | **PHI handling (D8) — is the Option 2 working rule the final one?** How much context may be captured, and how much may reach a central vendor | §K, and acceptance criteria 4–5 | Sarvesh + gaurav |
| Z11 | When a future assignment model arrives, is it by **team**, by **shift**, or by **on-call rotation**? Not needed to build, and the design must not presume | nothing today — deliberately | gaurav |
| ~~Z13~~ | ~~A support ticket auto-links to a patient Contact~~ — **RESOLVED 2026-08-24.** `create_support_ticket` detaches the auto-resolved `contact` (and `customer`) after insert, and a dated patch cleared the 11 staff tickets already carrying one. Helpdesk's own reader falls back to `raised_by`, so the agent still knows who reported it. See §K.1 | — | closed |
| ~~Z14~~ | ~~Agent replies leave the estate by email~~ — **RESOLVED 2026-08-25.** Disabled through Helpdesk's own switches by patch, leaving the shared outgoing account intact for staff and patient invitations. A reply is still recorded on the ticket and still shown in the thread; only the email is suppressed | — | closed |
| Z12 | Who may claim from the central queue — every eBasics agent, or a subset? Affects only Helpdesk-side role configuration | go-live | Sarvesh |

**Locked (see §A1):** UX shape · central eBasics triage · **no individual assignment** · per-user
visibility · `customer` empty · native fields · severity includes patient care.

**Explicitly still open:** PHI handling (D8/Z10) and the future assignment model (Z11).

---

## Appendix 1 — End-to-end architecture

```mermaid
flowchart TD
    subgraph Browser["Clinician's browser"]
        UI["Help & Support panel<br/>your requests · thread · composer"]
        SAN["Route allow-list sanitizer<br/>+ client-error buffer"]
        CAP["Screenshot capture<br/>explicit + preview"]
    end
    subgraph Vercel["Remedisys BFF — Next.js"]
        R1["/api/support/availability"]
        R2["/api/support/tickets"]
        R3["/api/support/tickets/[id]"]
        R4["/api/support/tickets/[id]/replies"]
    end
    subgraph Frappe["Frappe site"]
        SUP["api/v1/support<br/>create · list · thread · reply"]
        SVC["services/support.py<br/>access rule · severity mapping"]
        HOOK["hook: agent replied → notification"]
        HD["Frappe Helpdesk — system of record"]
        T["HD Ticket + Communication + File"]
        NT["Notification → /notifications"]
    end
    AG["eBasics agent in /helpdesk"]

    UI --> SAN --> R2
    CAP --> R2
    UI --> R1
    UI --> R3
    UI --> R4
    R1 --> SUP
    R2 --> SUP
    R3 --> SUP
    R4 --> SUP
    SUP --> SVC
    SUP -->|"native methods only"| HD
    HD --> T
    T --> HOOK --> NT --> UI
    AG --> HD
```

## Appendix 2 — Attachment and context flow

```mermaid
sequenceDiagram
    participant C as Clinician
    participant P as Panel
    participant B as BFF
    participant S as api/v1/support
    participant F as Frappe File
    participant H as Helpdesk

    C->>P: pick severity, type one line
    P->>P: sanitize route → module + shape
    P->>P: scrub client errors
    C->>P: Capture screen
    P->>C: preview
    C->>P: confirm + review captured context
    C->>P: Send
    P->>B: multipart: severity, subject, detail, context, files
    B->>S: forward with Bearer JWT
    S->>S: permission check, re-validate, re-check sanitizer
    S->>F: stage files as private, unattached
    S->>H: api.new(doc + priority + type + custom fields, attachments)
    H->>H: SLA, status, raised_by, re-parent files
    H-->>S: ticket
    S-->>B: 201 ticket + response_by
    B-->>P: reference + expected response
    P-->>C: "Request 0042 sent. Response by 14:30."
```

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.6 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Phase 1 marked complete and Phase 2 partial, against what is actually built; records the two Phase 1 commitments that did not ship (rate limit, component tests) rather than moving them |
| 1.5 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Locked **D10** — no custom fields on Helpdesk doctypes; §M's five proposed fields are superseded and context travels in the description body, accepting the loss of filterable triage |
| 1.4 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | **Z14 resolved** — Helpdesk's outgoing email disabled by patch; ticket content no longer leaves the estate by mail |
| 1.3 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | **Z13 resolved** — the auto-resolved patient Contact is detached at creation and backfilled by patch; §K.1 records the mechanism and why clearing beat substituting |
| 1.2 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Brought in line with what is built: locked **D9** (Helpdesk's status verbatim, no second vocabulary), marked severity wiring and the create/list/thread/reply endpoints as built with the measured SLA effect, recorded that the context-capture UI was **removed** pending D8, and added **Z13** (ticket auto-links to a patient Contact carrying an MRN) and **Z14** (agent replies email out) |
| 1.1 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Added the decision register (§A1) and locked D3: no individual assignment — tickets are created unassigned into a central queue agents claim from, and no support identity is hard-coded. Records the enabled default Assignment Rules as a go-live configuration risk. **Reopened PHI handling (D8/Z10)**: §K is now the working rule, not a settled decision |
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Specification for the approved direction: thread + auto-capture, central eBasics triage, per-user visibility with `customer` empty, native field mapping, PHI Option 2 with an allow-list sanitizer, three phases with acceptance criteria, and nine open questions |
