# FAC decision, in short

**Doc status:** record · **Created:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-11 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.4

> Team summary. The full evidence is in [`FAC_EVALUATION.md`](FAC_EVALUATION.md) (25 sections).
> This page is the part you need to make the decision. Every number here was measured on
> `marley.local` on 2026-09-10, not estimated.
>
> **The verdict is section 9, at the end.** Read 1 to 8 for the evidence, or jump to 9 for the
> answer.

---

## 1. The question and the answer

**Question.** Should we use Frappe Assistant Core (FAC) as the tool layer for our production AI,
the copilot a doctor uses in the Encounter screen?

**Answer. No.** We already have the right tool layer. It is faster, it is safer, and it is ours.

**One exception.** FAC is *optional* for developer work on a bench with no real patients. That is a
tooling choice, not an architecture choice, and it carries no weight in the production answer.

---

## 2. What each thing is

| Thing | What it is |
|---|---|
| **Our tools** (`services/ai_tools.py`) | 36 tools we wrote. 13 read, 23 write. Each one typed, permission-checked, and limited in how much it can return |
| **FAC** | A third-party Frappe app with 24 generic tools: get, list, create, update, delete, search, report |
| **The production AI** | The copilot in the Encounter screen. The model and the tool loop run **inside Frappe**, not in the frontend |

---

## 3. The story that shows it, in one screen

**USER STORY.** Dr. Ana has a 4-year-old in the room. The chart records an allergy to **"Sulfa"**.
She says to the copilot: *"add sulfamethoxazole for the ear infection."*

| | With our tools (today) | With FAC's generic tools |
|---|---|---|
| Model calls | `add_medication` | `create_document` on `Drug Prescription` |
| Allergy check | `_allergy_conflict` runs. "Sulfa" matches "sulfamethoxazole" on the 5-character prefix rule | **nothing runs** |
| **The system shows** | a blocked suggestion, with the conflict spelled out | "Document created" |
| **The database actually contains** | nothing yet. A suggestion is not a row | a live `Drug Prescription` row, with `drug_code` empty and `bill_this` unset |
| Doctor review | required before anything is written | **never happened.** There was no suggestion to review |
| **Consequence** | the wrong drug never reaches the chart | **a 4-year-old with a sulfa allergy has a sulfa drug on the pharmacy list, approved by nobody**, and a billing row the invoice screen cannot price |

The model is the same in both columns. The difference is that our safety checks live **inside the
tool**, and FAC's generic tools have nowhere to put them.

> The allergy pairing above is illustrative. The mechanism is real and verifiable:
> `_allergy_conflict` at `services/ai_tools.py:374`, and `_ALLERGY_PREFIX_MIN_LEN = 5` with the
> comment naming "sulfa" as the case it exists for.

## 4. How our tool pipeline works, in six steps

The story above shows the outcome. This is the mechanism behind it, which is what FAC has no place
for. Dr. Ana says *"add amoxicillin 250 mg, three times a day, for seven days."*

1. The model calls `add_medication`. It is the only way in; there is no generic write tool.
2. `_allergy_conflict` checks the drug against the child's allergy list, same-family matches
   included.
3. `_rx_already_present` checks the encounter for the same drug at the same strength.
4. The tool returns a **suggestion**. It does not write to the database. It cannot: there are zero
   database writes in the whole tool layer.
5. Dr. Ana sees it in the review panel with confidence and reasoning, and accepts it.
6. Only then does `save_draft` write the row, resolve `drug_code`, and set the billing flag for this
   company.

Steps 2, 3, 4 and 6 have no equivalent anywhere in FAC's 24 tools. That is the whole argument.

## 5. Speed. Measured, same clinical question

Loading one patient's clinical context: encounter, medications, chart overview, allergies.

| | Our tools | FAC generic tools |
|---|---|---|
| Calls needed | **4** | **6** |
| Time | **45.6 ms** | 77.6 ms |
| Data returned | **3,449 bytes** | 335,722 bytes |
| Tokens sent to the model | **1,027** | **104,551** |

**FAC returns 102x more tokens for the same answer.** Two of its six calls did the damage: listing
vital signs cost 36,026 tokens, and listing the patient's encounters cost 67,091.

### First, in plain language: what a token is, and why JSON is expensive

A model does not read letters or words. It reads **tokens**, which are small pieces of text. You pay
per token, and the model's memory is limited in tokens. So "how many tokens" is really "how much of
the model's attention did we spend".

**Example 1. The same fact, written two ways.**

Write it as a human would:

```
Paracetamol, 1 week
```

The model sees **7 tokens**: `Par` `acetam` `ol` `,` `␣` `1` ` week`  (the `␣` is a space, which
costs a token of its own)

Now write the same fact as JSON, which is what an API returns:

```json
{"drug_name": "Paracetamol", "period": "1 Week"}
```

The model sees **16 tokens**: `{"` `drug` `_name` `":` ` "` `Par` `acetam` `ol` `",` ` "` `period`
`":` ` "` `1` ` Week` `"}`

**Same information, more than twice the tokens.** Every `{`, `"`, `:` and field name costs a token.

This is also why an earlier version of this page was wrong. It said "~862 vs ~83,930 tokens, 97x",
from a quick `bytes ÷ 4` estimate. That shortcut works for prose and **undercounts JSON by about
20%**. Counted properly it is 1,027 vs 104,551, so **102x**: the earlier figure was conservative,
not exaggerated.

**Example 2. One prescription row, asked for two different ways. This is the whole argument.**

A generic tool asks for **every field** (`fields: ["*"]`), because it does not know which ones
matter. One row comes back like this:

```json
{"name":"3d3ldqa2mm","owner":"Administrator","creation":"2026-09-05 14:22:01.123456",
 "modified":"2026-09-05 14:22:01.123456","modified_by":"Administrator","docstatus":0,"idx":1,
 "drug_code":"Paracetamol","drug_name":"Paracetamol","dosage":null,"period":"1 Week",
 "comment":null,"parent":"HLC-ENC-2026-00684","parentfield":"drug_prescription",
 "parenttype":"Patient Encounter","doctype":"Drug Prescription"}
```

That is **124 tokens** for one prescription. (Wrapped above so it fits the page; counted as the
single line the API actually returns.) Look at what the doctor actually needs from it: the drug name,
the dose, the duration. Everything else is bookkeeping: who created the row, when it was modified,
its internal id, its parent table name.

Our tool asks only for the fields the question needs:

```json
{"drug_name":"Paracetamol","dosage":null,"period":"1 Week"}
```

That is **18 tokens**. Same clinical meaning.

| One prescription row | Tokens |
|---|---|
| Generic, all fields | **124** |
| Ours, named fields only | **18** |
| | **6.9x difference** |

**Now multiply.** A generic call is made with `limit_page_length: 200`, so it can return 200 rows:

| 200 rows | Tokens |
|---|---|
| Generic | **24,800** |
| Ours | 3,600 |
| Our own budget (Rule 5) | 4,000 |

**One generic call on one table is already six times over our whole patient-context budget.** Now
recall the real measurement: the generic approach made **two** such calls, on Vital Signs and on
Patient Encounter, and those two alone cost 36,026 and 67,091 tokens.

That is the entire token argument. It is not that FAC is badly built. It is that a generic tool
cannot know which three fields out of sixteen the doctor needed, so it sends all sixteen, for every
row it is allowed to return.

### How the numbers were counted, and the per-call breakdown

Counted with **`tiktoken`, encoding `o200k_base`** (what current GPT models use; production is
`gpt-5-mini`), on the exact JSON response bodies. Re-runnable in three lines:

```python
import tiktoken
enc = tiktoken.get_encoding("o200k_base")
tokens = len(enc.encode(response_body))
```

| Ours (4 calls) | Tokens | | Generic (6 calls) | Tokens |
|---|---|---|---|---|
| `get_encounter` | 498 | | `get_document` Patient Encounter | 926 |
| `get_patient_medications` | 292 | | `get_document` Patient | 292 |
| `get_patient_chart_overview` | 213 | | `list_documents` Drug Prescription | 212 |
| `list_allergies` | 24 | | `list_documents` Lab Test | 4 |
| | | | `list_documents` **Vital Signs** | **36,026** |
| | | | `list_documents` **Patient Encounter** | **67,091** |
| **Total** | **1,027** | | **Total** | **104,551** |

The last two rows are 98% of the generic total, for the reason Example 2 above shows: all fields,
up to 200 rows.

Two honest notes on this section:

- Our 45.6 ms was measured **over HTTP**, the slow way. In production these tools run in-process
  inside Frappe, so the real figure is lower. FAC would add about 5 ms per call, up to 20 per turn.
- **Speed is not the main argument.** 30 ms either way is invisible next to an LLM call. The token
  number is the one that matters.

### Why the token number is a safety issue, not a cost issue

Our rule (Rule 5) gives the AI a **4,000 token** budget for patient context. That is not a
preference, it is what keeps the model focused on the right facts.

| Reading one patient's encounter history | Tokens (counted) |
|---|---|
| FAC generic, all of it | **302,056** |
| Ours, bounded to 3 visits (`_DEFAULT_PREV_ENCOUNTERS`) | **810** |

That is **373x**, and **76x over our own budget**. The worst patient on the site has 1,002
encounters, which is test data, so here is a realistic case instead: a chronic patient with 40
visits costs **10,800 tokens**, still **2.7x over budget**, from one tool call.

The ratio is the point, not the big number. **373x** came out identical whether measured with the
rough estimate or the real tokenizer, so it does not depend on how tokens are counted.

When the budget is blown, the context gets cut off silently, and the model gives a confident
answer based on part of the record. That is the risk.

---

Verified on `HLC-ENC-2026-00684` and its patient, 2026-09-10. Sizes only. No patient content
was printed or stored anywhere.

## 6. Security. Both directions, because our own tools were also checked

A senior reviewer asked whether the evaluation had actually looked at security **inside our custom
tools**, rather than just assuming they are safe. Fair point. So they were counted.

### What our tools do well. Verified by reading the file, not by assuming

| Check | Result |
|---|---|
| Read tools with a permission check | **13 of 13** |
| Write permission check | Document-level: `frappe.has_permission("Patient Encounter", "write", doc=encounter)` at `api/v1/ai/api.py:1095`. A doctor without write access is never even **offered** a write tool |
| `ignore_permissions` used anywhere | **0** |
| Raw SQL in the tool layer | **0** |
| Database writes in the tool layer | **0**. Write tools return suggestions only |
| Cross-patient access | Structurally impossible. `execute_tool(name, args, *, encounter, patient, ...)` requires both, so reaching another patient is a code error, not a policy someone can forget |

### Where our tools are genuinely weak. These are real, and they are ours to fix

1. **5 of 23 write tools are auto-applied by the frontend** before the doctor reviews them
   (`encounter-screen.tsx:3217-3263`). The backend is clean; the bypass is in the UI. Already logged
   as a top-priority fix. **FAC would not fix this. It would make it the normal behaviour.**
2. **We cannot reconstruct why the AI suggested something.** Our audit log stores tool *names* only,
   never arguments or results, because it must not hold patient data. So the safety of the log costs
   us the explanation. **This is the one thing FAC would genuinely fix**, and section 6 says why we
   still should not use it for that.
3. **The model chooses which tool to call.** A malicious instruction hidden in patient text could
   influence that choice. Today the worst outcome is a bad suggestion that a doctor must accept.
   With a generic write tool available, the worst outcome becomes a database write.

### Where FAC is weaker

| Item | FAC | Ours |
|---|---|---|
| Tool arguments stored | **Yes** | No |
| **Tool results stored** | **Yes**, `output_data`, kept **180 days** by default | No |
| Redaction | Hides passwords and tokens. Has **no concept of patient data** | Nothing is stored, so nothing to redact |
| Who can read those records | System Manager and the **Auditor** role | not applicable |
| Covered by our data-erasure process | **No.** It is a new copy of patient data outside it | not applicable |
| Delete tool | `delete_document`, calls `frappe.delete_doc(..., force=True)`, no list of protected DocTypes, no confirmation step | No delete tool exists |
| Licence | AGPL-3.0, in a commercial clinical product | MIT, ours |

The one that matters most: **FAC writes patient data into a second store for 180 days, and its
redaction was built to hide passwords, not patients.** That breaks four of our own written rules.

---

## 7. The tool-building question, which is the one that decides it

Two versions of this get asked, and they have different answers. Both end in the same place.

### 7a. "With FAC, do we avoid building tools?" No. Not for this product.

FAC's 24 tools are `get_document`, `list_documents`, `create_document`, `update_document`,
`delete_document`, `submit_document`, the search family, the report family, dashboards, and (off by
default) SQL and Python. **None of them contains a single clinical rule.**

Everything that makes our copilot safe would still have to be written by us:

| What we need | Is it in FAC's 24 tools? |
|---|---|
| Check a drug against the child's allergies, including same-family matches | **No** |
| Refuse a duplicate prescription that differs only in spelling or strength | **No** |
| Return at most 8 labs and 3 previous visits, so the context budget holds | **No** |
| Propose a change for the doctor to review instead of writing it | **No** |
| Guarantee the tool can only touch this encounter and this patient | **No** |
| Resolve the drug code and set the billing flag for this company | **No** |

So the promise "no tool writing needed" is true for a plain ERPNext question such as "list unpaid
invoices for this customer". **It is not true for an Encounter.** We would write all 36 tools
either way. FAC's own `assistant_tools` hook exists because FAC's authors know this: a domain app is
expected to bring its own tools.

**That single fact removes the main reason anyone wanted FAC here.**

### 7b. "Then could FAC at least host our 36 tools?" Yes, and that makes it redundant

**Technically, yes.** FAC has a hook, `assistant_tools`, that lets any Frappe app register its own
tools inside FAC. We could register all 36 of ours there.

**But then look at what FAC is actually contributing:**

| | Comes from |
|---|---|
| The 36 tools | **us**, unchanged |
| The safety checks | **us**, unchanged |
| The bounded reads | **us**, unchanged |
| The permission and scoping rules | **us**, unchanged |
| MCP transport | FAC |
| An audit log that stores patient data for 180 days | FAC |
| An AGPL-3.0 licence wrapped around our clinical code | FAC |

So FAC would add a transport we do not need in production (the tool loop is already in-process), an
audit log we are not allowed to use, and a licence question on our own code. **Adding our tools to
FAC does not make FAC useful. It makes FAC redundant.**

And the reverse, mixing both tool sets, is worse rather than safer. If the model can see both
`add_medication` (safe, reviewed) and `create_document` (writes immediately), it will sometimes pick
the second, most likely when the first refuses. Refusal is exactly when a generic fallback looks
attractive to a model and is most dangerous to a patient.

---

## 8. Comparison, on one screen

| | Our tools | FAC in production |
|---|---|---|
| Clinical safety checks | Built into every tool | None. Would move to the prompt |
| Can the AI write to the chart directly | **No**, suggestions only | **Yes**, immediately |
| Tokens for one patient context | **1,027** | **104,551** |
| Context budget respected | Yes, limits are in code | No, the limit becomes the model's choice |
| Patient data stored in an audit log | No | Yes, 180 days by default |
| Cross-patient reach | Impossible by design | Whatever the user can read |
| Delete tool exposed | No | Yes, with force |
| Licence | MIT | AGPL-3.0 |
| Explains why the AI suggested something | **No** (our gap) | Yes, by storing patient data |
| Answers questions no tool was written for | **No** (by design) | Yes |

FAC wins **2 of 10 rows**. Both are better solved on our own roadmap: one new tool for the first,
and a proper provenance record, with consent and a retention period, for the second.

---

---

## 9. ⬛ BOTTOM LINE

> **The belief we started with was: "with FAC we do not have to build tools."**
> **That belief is wrong for Remedisys. In FAC we would still build every tool ourselves.**
> Once that falls, FAC's whole case falls with it.

| # | The statement | Verdict | The evidence |
|---|---|---|---|
| 1 | **In FAC you still have to build tools.** For Encounter and Remedisys we would definitely have to build them | **CORRECT** | FAC ships 24 tools: get, list, create, update, delete, submit, search, report, dashboard. **Not one of them knows what an allergy is.** Every clinical rule we need would still be ours to write. FAC's own `assistant_tools` hook exists precisely because generic tools are not enough for a domain app |
| 2 | **So why add FAC's extra layer?** | **CORRECT** | It adds a network hop inside Frappe, a second audit store, and an AGPL-3.0 licence, and contributes **zero** clinical capability |
| 3 | **It does not maintain PHI properly** | **CORRECT** | `Assistant Audit Log.output_data` stores tool **results** for **180 days** by default. Its redaction was built to hide passwords, not patients. It sits outside our data-erasure path |
| 4 | **It is less secure** | **CORRECT, for a clinical workload** | Generic `create_document` / `update_document` write straight to the chart with no allergy check, no duplicate check and no doctor review. `delete_document` calls `frappe.delete_doc(..., force=True)` with no protected-DocType list |
| 5 | **It is not faster than my custom tools** | **CORRECT, measured** | Same clinical context: ours **4 calls, 45.6 ms, 1,027 tokens**. Generic **6 calls, 77.6 ms, 104,551 tokens**. **102x more tokens** for the same answer, counted with `tiktoken` |
| 6 | **It is best only for Claude Code and ChatGPT-style clients, not for our product AI** | **CORRECT** | Those clients ask questions nobody planned for, so a wide generic surface helps them. Our clinical copilot asks a fixed set of questions about one patient, where a narrow surface **is** the safety feature |

### Two precisions, so the argument cannot be picked apart

**1. Say "for Remedisys", not "in FAC you can never avoid building tools".**
FAC's 24 generic tools genuinely work out of the box for plain ERPNext questions such as "list
unpaid invoices". That is real, and it is why FAC exists. The point is narrower and stronger:
**for a clinical domain, those generic tools are exactly what we are not allowed to expose**, so
they save us nothing and we build all 36 tools regardless. Stated that way, nobody can answer it.

**2. Our production AI does not run in Next.js.**
Next.js only proxies. `/api/ai/*` calls `ask_copilot` (`api/v1/ai/api.py:1038`), and the model plus
the tool loop both run **inside Frappe**, capped at 20 tool steps. So the correct sentence is
"FAC suits an **external, general-purpose** AI client exploring a Frappe site; it does not suit our
**in-product clinical copilot**." Saying "the Next.js LLM" invites someone to correct you on a
detail that does not change the conclusion.

**Also worth saying out loud, because it is the strongest version of point 5:** FAC is not slow.
One hop costs about 5 ms. It is slow **for this job** because a generic tool needs more calls and
returns far more data than the question needed. That is a design mismatch, not bad code.

---


> Team summary. The full evidence is in [`FAC_EVALUATION.md`](FAC_EVALUATION.md) (25 sections).
> This page is the part you need to make the decision. Every number here was measured on
> `marley.local` on 2026-09-10, not estimated.

---

### What to do

1. **Production: do not use FAC.** Our tool layer is faster on this workload, sends 102x fewer tokens,
   cannot write to the chart without a doctor, cannot reach another patient, and stores no patient
   data in a log. FAC reverses all five.
2. **Development: FAC is optional and, as of today, unnecessary.** A 200-line helper script
   (`scripts/dev/frappe_probe.sh`) already covers reading and schema checks in about 0.2 s per call.
3. **Our tools are not perfect, and the review found three real weaknesses.** The most serious is a
   frontend bypass on 5 write tools, which is ours to fix and which FAC would make worse. The most
   useful finding is that we cannot reconstruct the AI's reasoning, and that deserves a proper fix.
4. **Open item, unrelated to this recommendation but still open:** FAC 2.5.1 is installed on
   `remedisys.localhost`, against ADR-030 which rejects it by name. It should be removed, or the ADR
   should be superseded. This evaluation supports removing it.

**One line for the team:** *we already built the tool layer FAC sells, ours is bounded and cannot
write to a patient's chart without a doctor's approval, and swapping it for a generic one would cost
102x the tokens and every safety check we have.*

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-11 | Sarvesh-SocialAngel (AI-assisted) | Added a plain-language explanation of what a token is, with two tiny worked examples counted with the real tokenizer: the same fact as prose (7 tokens) versus as JSON (16), and one prescription row generic (124) versus ours (18). Makes the 102x headline understandable without reading the method section. |
| 1.3 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Recounted every token figure with `tiktoken` (`o200k_base`) instead of a `bytes / 4` estimate, and added the method plus a per-call breakdown so the totals are checkable. The estimate undercounted JSON by about 20%, so the headline moves from 97x to **102x**: the earlier claim was conservative, not overstated. The 373x context ratio is unchanged. |
| 1.2 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Added the user story and the worked example (CLAUDE.md §10 requires both). Restructured so the verdict sits at the end as §9 "Bottom line" where a bottom line belongs, with the story early as §3 and the duplicate example folded into §5. |
| 1.1 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Added the BOTTOM LINE block at the top, confirming the six-point review conclusion, with the two precisions needed to make it unarguable: scope the tool-building claim to a clinical domain, and stop calling the production model "the Next.js LLM" since it runs inside Frappe. |
| 1.0 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Short team-facing summary of `FAC_EVALUATION.md` v2.0. Adds the measured speed and payload comparison for one real clinical context, a security audit of our own tool layer (asked for in review), and the direct answer to whether FAC could host all 36 of our tools. |
