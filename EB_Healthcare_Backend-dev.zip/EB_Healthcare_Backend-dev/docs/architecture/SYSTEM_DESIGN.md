# Remedisys — Backend System Design

**Doc status:** living · **Created:** 2026-05-19 by Sarvesh-SocialAngel · **Updated:** 2026-09-23 by Nishant · **Version:** 1.2

**Stack:** Frappe v16 · ERPNext Healthcare · MariaDB 11 · Redis 7
**Deployment:** Frappe Cloud
**Jurisdiction:** Mexico — LFPDPPP + NOM-024-SSA3-2012
**Last updated:** 2026-06-19

---

## 1. Full-Stack Architecture

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#0f172a', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'clusterBkg': '#0f172a', 'clusterBorder': '#334155'}}}%%

graph TB
    subgraph BROWSER["  🖥️  Browser  "]
        direction LR
        NX["Next.js BFF\n(Vercel)\nhttpOnly cookie only\ntokens never in browser"]:::frontend
    end

    subgraph FRAPPE_CLOUD["  ☁️  Frappe Cloud  "]
        direction TB

        subgraph BUILTIN["  Built-in Frappe  "]
            OAUTH["🔐 Frappe OAuth2\nPOST /oauth2/get_token\nPOST /oauth2/revoke_token\nGET  /oauth2/openid_profile"]:::oauth
            RESOURCE["📦 Frappe Resource API\nGET|POST|PUT /api/resource/*\nPatient · Appointment · Encounter\nVital Signs · Lab Test · Medication"]:::resource
        end

        subgraph CUSTOM["  remedisys_healthcare_ai  "]
            direction LR
            AUTH_API["🔵 api/v1/auth\nget_current_user()"]:::apidone
            CORE_API["🔵 api/v1/\npatients · appointments\nencounters · vitals\nlabs · prescriptions\nbilling · providers\ndashboard · notifications\ninsurance · clinical"]:::apistub
            AI_API["🔴 api/ai/ — LOCKED\nsessions · segments\nrealtime · auth"]:::ailocked
            SVC["🟢 services/\nbusiness logic layer\n(all stubs — Phase 1+)"]:::svclayer
        end

        DB[("🗄️ MariaDB 11+\nFrappe ORM")]:::db
        RD[("⚡ Redis 7+\ncache + queue")]:::cache
    end

    subgraph FUTURE["  🌐  AI Phase — Future  "]
        DG["Deepgram\nstreaming ASR"]:::future
        AC["Anthropic Claude\nSOAP generation"]:::future
    end

    NX -->|"Authorization: Bearer token\nHTTPS only"| OAUTH
    NX -->|"Authorization: Bearer token"| RESOURCE
    NX -->|"Authorization: Bearer token"| AUTH_API
    NX -->|"Authorization: Bearer token"| CORE_API
    AUTH_API --> SVC
    CORE_API --> SVC
    SVC -->|"frappe.get_doc()\nfrappe.get_all()"| DB
    AI_API -.->|"RQ background jobs"| RD
    AI_API -.->|"HTTPS · future"| DG
    AI_API -.->|"HTTPS · future"| AC

    classDef frontend fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    classDef oauth fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
    classDef resource fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef apidone fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef apistub fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:1px,stroke-dasharray:4
    classDef ailocked fill:#1c1917,stroke:#6b7280,color:#9ca3af,stroke-width:2px,stroke-dasharray:6
    classDef svclayer fill:#1e3a5f,stroke:#475569,color:#94a3b8,stroke-width:1px,stroke-dasharray:4
    classDef db fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
    classDef cache fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef future fill:#1c1917,stroke:#57534e,color:#a8a29e,stroke-width:2px,stroke-dasharray:6
```

---

## 2. Authentication Integration

> Full flows with sequence diagrams: `Healthcare_next_app/docs/AUTHENTICATION.md`

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'noteBkgColor': '#1e3a5f', 'noteTextColor': '#93c5fd'}}}%%

sequenceDiagram
    autonumber
    actor U as 👤 User
    participant FE as 🖥️ Next.js BFF
    participant OA as 🔐 Frappe OAuth2
    participant CA as 🟢 get_current_user()
    participant DB as 🗄️ MariaDB

    U->>FE: POST /api/auth/login { email, password }
    FE->>OA: POST /oauth2/get_token (password grant)
    OA->>DB: verify credentials + roles
    DB-->>OA: ✅ valid
    OA-->>FE: { access_token, refresh_token, expires_in }
    FE->>CA: GET /api/method/...get_current_user<br/>Authorization: Bearer token
    CA->>DB: get User + roles + practitioner profile
    DB-->>CA: user doc
    CA-->>FE: { name, email, roles, practitioner }
    Note over FE: Build NextAuth session<br/>Store tokens server-side<br/>Set httpOnly cookie
    FE-->>U: Set-Cookie (httpOnly) → redirect to role dashboard
```

### OAuth2 Client Required

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'lineColor': '#475569'}}}%%

flowchart LR
    A(["Frappe Desk\n→ Integrations\n→ OAuth Client\n→ New"]):::step

    A --> B["App Name: Remedisys Web\nGrant Type: Authorization Code\nScopes: all openid\nRedirect: https://app.remedisys.mx/api/auth/callback\n          http://localhost:3000/api/auth/callback"]:::config

    B --> C["Copy to .env.local:\nFRAPPE_CLIENT_ID=...\nFRAPPE_CLIENT_SECRET=..."]:::env

    classDef step fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
    classDef config fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    classDef env fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
```

### CORS Configuration (one-time, no code change)

```json
// sites/common_site_config.json  (dev)
{ "allow_cors": "http://localhost:3000" }

// sites/<site>/site_config.json  (prod — Frappe Cloud dashboard)
{ "allow_cors": "https://app.remedisys.mx" }
```

---

## 3. API Endpoint Inventory

### Built-in Frappe OAuth2 (zero custom code)

| Action | Method | Endpoint |
|---|---|---|
| Login | POST | `/api/method/frappe.integrations.oauth2.get_token` |
| Refresh token | POST | `/api/method/frappe.integrations.oauth2.get_token` |
| Logout | POST | `/api/method/frappe.integrations.oauth2.revoke_token` |
| User info | GET | `/api/method/frappe.integrations.oauth2.openid_profile` |

### Custom — `remedisys_healthcare_ai`

All custom endpoints follow this pattern:
```
POST /api/method/remedisys_healthcare_ai.api.v1.<module>.api.<function_name>
```

| Module | Method | Status | Returns |
|---|---|---|---|
| **auth** | `get_current_user` | ✅ Built | `{ name, email, roles[], practitioner }` |
| **patients** | `list_patients` | ✅ Built | paginated list; batch-enriched guardian/billing/vitals (no N+1) |
| **patients** | `get_patient` | ✅ Built | full patient record |
| **patients** | `create_patient` | ✅ Built | new patient (CURP uniqueness, minor guardian enforcement) |
| **patients** | `update_patient` | ✅ Built | partial update with merge semantics |
| **patients** | `add/remove/update_guardian` | ✅ Built | guardian Contact/Address CRUD |
| **patients** | `get_patient_chart_overview` | ✅ Built | Patient 360 overview tab |
| **patients** | `get_patient_visits` | ✅ Built | Patient 360 visits (vitals, diagnoses, meds per encounter) |
| **patients** | `get_patient_medications` | ✅ Built | Patient 360 medications tab |
| **patients** | `get_patient_immunizations` | ✅ Built | Patient 360 immunizations |
| **patients** | `get_patient_clinical_activity` | ✅ Built | Patient 360 activity feed |
| **appointments** | `list_appointments` | ✅ Built | paginated appointment list with invoice enrichment |
| **appointments** | `get_appointment` | ✅ Built | single appointment detail |
| **appointments** | `book_appointment` | ✅ Built | new appointment (practitioner conflict check) |
| **appointments** | `book_appointment_for_patient` | ✅ Built | atomic: new/existing patient + appointment + optional payment; savepoint rollback |
| **appointments** | `book_appointment_with_payment` | ✅ Built | appointment + Sales Invoice + Payment Entry |
| **appointments** | `cancel_appointment` | ✅ Built | cancel with reason |
| **appointments** | `check_in_patient` | ✅ Built | status → Checked-in |
| **appointments** | `reschedule_appointment` | ✅ Built | change date/time |
| **appointments** | `update_status` | ✅ Built | role-gated via `_ROLE_ALLOWED_STATUSES` |
| **appointments** | `get_available_slots` | ✅ Built | practitioner slot grid (holiday/leave/capacity aware) |
| **encounters** | `create_encounter` / `start_encounter` | ✅ Built | new encounter (idempotent from appointment) |
| **encounters** | `get_encounter` | ✅ Built | full record with child tables |
| **encounters** | `complete_encounter` | ✅ Built | validates + submits + auto-submits linked vitals |
| **encounters** | `save_draft` | ✅ Built | merges SOAP JSON into `encounter_comment`; replaces child tables |
| **encounters** | `cancel_encounter` | ✅ Built | delete if draft, cancel if submitted |
| **encounters** | `search_complaints` / `create_complaint` | ✅ Built | chief complaint lookup + create |
| **encounters** | `search_diagnoses` / `create_diagnosis` | ✅ Built | ICD-10 lookup + create |
| **encounters** | `search_treatment_plan_templates` | ✅ Built | template lookup |
| **dashboard** | `get_dashboard_data` | ✅ Built | KPIs + room queue (waiting/vital/practitioner/checkout); role-scoped |
| **providers** | `list_providers` / `get_provider` | ✅ Built | practitioner list + profile |
| **vital_signs** | `create_vital_signs` / `update_vital_signs` | ✅ Built | BMI + BP auto-calculated server-side |
| **vital_signs** | `list_vital_signs` / `get_vital_signs` | ✅ Built | list + detail |
| **labs** | `list_lab_templates` | ✅ Built | template catalog |
| **labs** | `list_patient_labs` | ✅ Built | patient lab orders |
| **labs** | `get_lab_test` | ✅ Built | single test with results |
| **labs** | `create_lab_order` | ✅ Built | new lab order linked to encounter |
| **immunizations** | full schedule management | ✅ Built | Mexico EPI, administer, update, delete (1,176 lines) |
| **clinical** | `list/add/update/remove_allergy` | ✅ Built | allergy CRUD (idempotent, case-insensitive) |
| **clinical** | `list/add/update/remove_condition` | ✅ Built | conditions CRUD |
| **billing** | `list_all_invoices` / `list_patient_invoices` | ✅ Built | clinic-wide + per-patient invoice lists |
| **billing** | `list_payment_entries` | ✅ Built | payment receipts list |
| **billing** | `create_invoice` / `record_payment` | ✅ Built | invoice creation + payment collection |
| **insurance** | `list_policies` / `create_claim` | 🔲 Phase 3 | empty stub — not started |
| **notifications** | `list_notifications` / `mark_read` / `get_unread_count` / `mark_all_read` + WhatsApp inbox | ✅ Built | Delivery rebuilt 2026-08-25 — SSE live channel, FCM out-of-app push, one `notify()` chokepoint. See [`../PUSH_NOTIFICATIONS.md`](../PUSH_NOTIFICATIONS.md) |
| **patient_portal/notifications** | `list_my_notifications` / `get_my_notification_count` / `mark_read` / `mark_all_read` | ✅ Built | The patient's own feed, session-scoped. Backs the portal bell |
| **push** | `register_device` / `unregister_device` | ✅ Built | FCM device tokens. Portal wired; EHR deliberately deferred |
| **reports** | 16 report endpoints | 🔲 Phase 4 | module does not exist yet |

### API Pattern — Custom Methods Only

> **The frontend never calls Frappe's built-in `/api/resource/` endpoints.**
> All data access goes through our custom whitelisted methods in `api/v1/`.
> This ensures every request is permission-checked and goes through the service layer.

```
✅ POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.list_patients
✅ POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.book_appointment

❌ GET /api/resource/Patient            ← never use this
❌ POST /api/resource/Patient Appointment  ← never use this
```

---

## 4. ERPNext Healthcare — DocTypes Used

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569'}}}%%

erDiagram
    PATIENT {
        string name
        string patient_name
        string sex
        date dob
        string blood_group
        string patient_details
        string mobile
        string email
    }

    PATIENT_APPOINTMENT {
        string name
        string patient
        string practitioner
        string department
        date appointment_date
        time appointment_time
        string status
        string notes
    }

    PATIENT_ENCOUNTER {
        string name
        string patient
        string practitioner
        date encounter_date
        string chief_complaint
        string diagnosis
        string encounter_detail
        string status
    }

    VITAL_SIGNS {
        string name
        string patient
        string encounter
        float bp_systolic
        float bp_diastolic
        float pulse
        float temperature
        float weight
        float height
    }

    LAB_TEST {
        string name
        string patient
        string practitioner
        string template
        date date
        string status
    }

    MEDICATION {
        string name
        string item_name
        string dosage_form
        string strength
    }

    PATIENT ||--o{ PATIENT_APPOINTMENT : "has"
    PATIENT ||--o{ PATIENT_ENCOUNTER : "has"
    PATIENT_ENCOUNTER ||--o{ VITAL_SIGNS : "records"
    PATIENT_ENCOUNTER ||--o{ LAB_TEST : "orders"
    PATIENT_ENCOUNTER ||--o{ MEDICATION : "prescribes"
```

---

## 5. Custom DocTypes (AI Phase)

> These doctypes are installed and **ready**. Their APIs are locked until the AI phase resumes.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569'}}}%%

erDiagram
    AI_SETTINGS {
        bool enable_ambient_documentation
        bool enable_soap_generation
        string llm_model
        float llm_temperature
        bool retain_audio
        int audio_retention_days
    }

    AI_ENCOUNTER_SESSION {
        string name
        string encounter
        string session_user
        string status
        bool consent_obtained
        datetime consent_obtained_at
        datetime started_at
        datetime ended_at
        int duration_seconds
        string deepgram_session_id
        string model_version
    }

    AI_TRANSCRIPT_SEGMENT {
        string name
        string session
        string encounter
        int sequence_number
        string speaker
        string text
        float start_ms
        float end_ms
        float confidence
    }

    AI_SOAP_DRAFT {
        string name
        string session
        string encounter
        int version
        text subjective
        text objective
        text assessment
        text plan
        bool accepted_by_physician
        datetime accepted_at
    }

    AI_PROMPT_LOG {
        string name
        string session
        string prompt_version
        string model
        int tokens_in
        int tokens_out
        float cost_estimate_usd
        int latency_ms
        string error_code
    }

    AI_ENCOUNTER_SESSION ||--o{ AI_TRANSCRIPT_SEGMENT : "has segments"
    AI_ENCOUNTER_SESSION ||--o{ AI_SOAP_DRAFT : "generates"
    AI_ENCOUNTER_SESSION ||--o{ AI_PROMPT_LOG : "logs"
```

---

## 6. Permissions Model

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569'}}}%%

flowchart TD
    REQ(["Incoming API Request\nAuthorization: Bearer token"]):::request

    REQ --> FRAPPE["Frappe validates token\nSets frappe.session.user"]:::frappe

    FRAPPE --> PERM["require_permission(doctype, perm)\nutils.py — every api/v1/ method"]:::perm

    PERM --> CHECK{frappe.has_permission\n?}

    CHECK -->|"✅ allowed"| SVC["Delegate to services/\nbusiness logic"]:::good
    CHECK -->|"❌ denied"| ERR["frappe.throw(PermissionError)\n403 to frontend"]:::bad

    subgraph ROLES["Frappe Role → DocType Access"]
        R1["Front Desk\nPatient · Appointment · Billing"]:::role
        R2["Nurse\nPatient · Vital Signs · Lab Test"]:::role
        R3["Practitioner\nAll clinical DocTypes + Encounter"]:::role
        R4["System Manager\nAll DocTypes"]:::role
    end

    SVC --> DB[("MariaDB\nFrappe ORM")]:::db

    classDef request fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
    classDef frappe fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    classDef perm fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef good fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef bad fill:#450a0a,stroke:#ef4444,color:#fca5a5,stroke-width:2px
    classDef role fill:#0f172a,stroke:#334155,color:#94a3b8,stroke-width:1px
    classDef db fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
```

---

## 7. Request / Response Standard

### Successful response

```json
{
  "message": {
    "data": [ ... ],
    "total": 42,
    "page": 1,
    "page_size": 20
  }
}
```

### Error response (Frappe standard)

```json
{
  "exc_type": "PermissionError",
  "message": "You do not have permission to perform this action."
}
```

### HTTP status codes

| Code | Meaning |
|---|---|
| 200 | Success |
| 400 | Validation error (bad input) |
| 401 | Not authenticated (token expired or invalid) |
| 403 | Permission denied (valid user, wrong role) |
| 404 | DocType / document not found |
| 500 | Unexpected server error |

---

## 8. Environment Variables

### Frappe backend (Frappe Cloud dashboard)

```
# Set in Frappe Cloud → Site Config or common_site_config.json
allow_cors = https://app.remedisys.mx

# SMTP for transactional email (configured in Frappe Email Account)
```

### Frontend `.env.local` (Healthcare_next_app)

```
FRAPPE_URL=http://marley.local:8003          # dev
FRAPPE_URL=https://your-site.frappe.cloud   # prod

FRAPPE_CLIENT_ID=<from Frappe OAuth Client>
FRAPPE_CLIENT_SECRET=<from Frappe OAuth Client>

NEXTAUTH_URL=http://localhost:3000           # dev
NEXTAUTH_URL=https://app.remedisys.mx       # prod
NEXTAUTH_SECRET=<random 32-char string>
```

---

## 9. Multi-Team Ownership Map

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'clusterBkg': '#0f172a'}}}%%

graph TB
    subgraph FE_TEAM["  🖥️  Frontend Team — Healthcare_next_app  "]
        direction LR
        FE1["src/app/ — routes"]:::fe
        FE2["src/components/ — UI"]:::fe
        FE3["src/lib/api/ — Frappe client hooks"]:::fe
        FE4["docs/ — frontend docs"]:::fe
    end

    subgraph BE_TEAM["  ⚙️  Backend Team — remedisys_healthcare_ai  "]
        direction LR
        BE1["api/v1/ — whitelisted methods"]:::be
        BE2["services/ — business logic"]:::be
        BE3["tests/ — pytest suites"]:::be
        BE4["docs/ — backend docs"]:::be
    end

    subgraph SHARED["  🔐  Shared — review required  "]
        SH1["utils.py"]:::shared
        SH2["hooks.py"]:::shared
        SH3["fixtures/"]:::shared
    end

    subgraph AI_LOCKED["  🔴  AI Team — Locked (Phase 5+)  "]
        AI1["api/ai/"]:::locked
        AI2["integrations/deepgram.py"]:::locked
        AI3["integrations/anthropic.py"]:::locked
        AI4["doctype/ai_*/"]:::locked
    end

    FE3 -->|"Bearer token calls"| BE1
    BE1 -->|"delegate"| BE2

    classDef fe fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:1px
    classDef be fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:1px
    classDef shared fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef locked fill:#1c1917,stroke:#6b7280,color:#9ca3af,stroke-width:1px,stroke-dasharray:4
```

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 1.1 | 2026-08-25 | Ashutosh (AI-assisted) | notifications module corrected from "empty stub — not started" to built; patient_portal/notifications and push modules added |
| 1.0 | 2026-05-19 | Sarvesh | Initial version (header backfilled from git history) |
