# Invoices tab — exact totals independent of page size

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.3

## What

Fixes a confirmed, live-verified bug: the Billing screen's Invoices tab showed "6,540.00 MXN
outstanding" in its own summary text while the header KPI chip (fed by a different, correct backend
aggregate — adr-099) showed "7,340.00 MXN" for the same clinic, at the same moment. Adds two
aggregate fields to `list_all_invoices` — `billed_total`, `outstanding_total` — computed server-side
over every invoice matching the request's filters, not just the page returned. The frontend stops
summing its own fetched rows for these two numbers and raises how many rows it fetches in one page,
so today's real dataset (240 invoices) is fully covered again.

## Why

Root-caused live, not guessed from the screenshot: `list_all_invoices` is always called with a fixed
`page_size: 100` and no further server paging — the frontend fetches once, then paginates, sorts and
sums entirely client-side. That was correct while every clinic's invoice count stayed under 100. It
no longer is: this site has 240 submitted invoices. The 140 beyond the newest 100 (by
`posting_date desc`) are invisible to the "All N" count, the outstanding/billed summary text, and to
paging through the table itself — only server-side search can still reach them, since search is a
request parameter, not a filter applied to an already-fetched page.

**Why not full server-side pagination (page/page_size sent on every page turn), matching how
Patients already works?** Investigated and rejected for now: three of this table's filters —
practitioner, payment method, and the due-date range — are applied **client-side only**, on top of
whatever page was fetched (`billing-client.tsx::invFiltered`). `list_all_invoices` has no backend
parameter for any of the three. Turning on true server pagination while leaving those three
client-side would make them return near-empty results most of the time — a fetched page of 20 rows
rarely contains many matching one particular practitioner — trading today's bug for a worse one.
Doing this correctly means extending the backend with all three filters first, a materially larger
change than the one this document covers. Recorded as a real follow-up, not silently dropped — see
adr-102's Alternatives section.

## Plan

**Correction before implementation:** the original plan (below, kept for the record) also raised
`page_size` to 1000. Checked before writing the code and dropped — `page_size = min(100, ...)` is not
particular to this endpoint; it's a hard cap repeated verbatim in ~20 list endpoints across this app
(`clinical_notes`, `company`, `labs`, `immunizations`, `prescriptions`, `vital_signs`, `tasks`, …).
Overriding it for invoices alone would be a real, cross-cutting inconsistency, not a small fix, and
is out of scope here. **This means the row-visibility side of the bug (invoices beyond the newest 100
are still unreachable by paging through the table) is NOT fixed by this change.** What IS fixed
completely: the two money figures, because the new aggregate fields are computed server-side over
every matching invoice regardless of page size — they were never bounded by the 100-row fetch to
begin with once computed this way.

**Backend** (`api/v1/billing/api.py::list_all_invoices`, plus `utils.py::set_list_response`):
- `set_list_response` gains an optional `extra: dict | None = None` parameter, merged into the
  top-level response alongside the existing `data`/`pagination` keys. Backward compatible — 48
  existing call sites that omit it are unaffected.
- `list_all_invoices` computes `billed_total` (`SUM(grand_total)`) and `outstanding_total`
  (`SUM(outstanding_amount)`) via one aggregate `frappe.get_list` call reusing the SAME
  `filters`/`or_filters` `_build_invoice_filters` already returns for the paginated query — no
  duplicated filter logic to drift out of sync, and the same permission-respecting `get_list` path
  (not `get_all`) the row query already uses. Independent of `page`/`page_size` entirely.

**Frontend** (`billing-client.tsx`):
- `billedInView`/`outstandingInView` read `invResult.billed_total`/`invResult.outstanding_total`
  (exact, server-computed, unbounded by page size) instead of summing `invFiltered` client-side
  (previously silently partial once the 100-row fetch stopped covering every matching invoice).
- `page_size` is unchanged, per the correction above. `totalRows`/the "All N" pill/the ability to
  page through every invoice remain capped at what the 100-row fetch contains — a real, known,
  separate limitation, not addressed by this change.

## Risks

- **Scale of the new aggregate query:** one extra `SUM` per list request, same cost class as the
  dashboard revenue aggregates (adr-099) — cheap, no N+1.
- **Row-visibility ceiling, addressed by a follow-up the same day, not by adr-102 itself.** This
  document originally left the "only the newest 100 invoices are visible" problem open, deliberately,
  because fixing it via true server-side pagination needs backend filters this repo doesn't have yet
  for practitioner/payment-method/due-date-range. The user asked directly for it to be fixed anyway
  after seeing the consequences (an Overdue invoice reading as 0, "All 87" undercounting a real 240).
  Resolved with a **different, smaller mechanism** than full server pagination: a new frontend hook,
  `useAllInvoices` (`use-billing.ts`), loops `list_all_invoices` page by page — still capped at 100
  rows *per request*, matching every other list endpoint (see the "why not raise page_size" section
  above, unchanged) — until every matching invoice is fetched, capped at 20 pages (2,000 rows) as a
  hard safety ceiling. This does NOT touch the backend cap or add new filter parameters; it just
  stops treating "the first page" as "the whole list" on the one screen that needs the whole list.
  Consequence: `invoices`/`active`/`invFiltered` in `billing-client.tsx` are now the TRUE full
  matching set again, so the practitioner/payment-method/due-date-range filters and the client-side
  fallback sum (used whenever a status filter is active — see below) are correct across the whole
  dataset, not just page 1.
- **Two real bugs found by re-verifying after the fix was reported as still broken, not assumed
  fixed:**
  1. The aggregate summed returns it should have excluded (the frontend always requests
     `include_returns=true`, but the original client-side sum explicitly excluded them) — measured
     live as a real 1,000 MXN discrepancy, fixed by forcing `is_return: 0` on the aggregate query
     independent of the row query's own `include_returns`.
  2. The Next.js BFF route and the shared `frappeFetchList` helper both destructured only
     `{ data, pagination }` from the Frappe response, silently dropping the two new fields before
     they ever reached the browser — the backend was correct and verified, but nothing using it
     through the actual browser code path could see that. `frappeFetchList` gained an optional
     `Extra` generic; the billing route now requests and forwards the two fields.

## Verification

- Live on `remedisis.localhost`: `billed_total`/`outstanding_total` compared against direct SQL for
  the same filter set.
- Frontend: `tsc`/`i18n:check`/ESLint against the two modified files' established baselines.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Row-visibility fixed same-day via a new `useAllInvoices` frontend hook (page-size cap untouched); two real bugs found and fixed on re-verification (returns wrongly included in the aggregate; the BFF route silently dropped the new fields) |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Before implementation: dropped the page_size raise — `min(100, ...)` is a repo-wide cap in ~20 endpoints, not billing-specific; scope narrowed to the two aggregate fields only |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
