# Roles & Permissions — Remedisys

**Doc status:** living · **Created:** 2026-06-10 by Invincible · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

> **Single source of truth for roles, API access, and master data setup.**
> Frontend enforces UI visibility. Backend enforces data access.
> Both layers must align with this document.
>
> Last updated: 2026-06-10

---

## 1. Role Definitions

### 1.0 Frappe User Type — MANDATORY

**All Narzim frontend users must be created as `Website User` type in Frappe. No exceptions.**

| Frappe User Type | Frappe Desk access | API (`@frappe.whitelist()`) | Narzim frontend |
|---|---|---|---|
| `Website User` | ❌ Blocked | ✅ Works with Bearer JWT | ✅ All Narzim users |
| `System User` | ✅ Full access | ✅ Works | ❌ Never for clinic staff |

`System User` / `System Manager` are reserved for engineers and Frappe system administrators only. No doctor, nurse, receptionist, or clinic admin should ever be created as `System User`.

> **Why this matters:** A `System User` can reach Frappe Desk, run SQL, install apps, and modify roles. A `Website User` is sandboxed to only what the Next.js BFF exposes. Using `Website User` makes the attack surface as small as possible.

**Implication for admin CRUD:** `frappe.client.insert/save/delete` typically require `System User` type. All admin master data write operations (companies, departments, service units, etc.) **must be implemented as custom `@frappe.whitelist()` methods** on the backend — never as direct `frappe.client.*` calls.

---

### 1.1 Frappe Role Names → Frontend Role IDs

The backend returns Frappe role names from `get_current_user`. The frontend maps these to internal `RoleId` values. **Both must stay in sync.**

All roles below are assigned to `Website User` type accounts. All are **custom roles** created in ERPNext — no reliance on ERPNext Healthcare built-in role names.

| Frappe Role (custom) | Frontend RoleId | Display label | Badge | Replaces ERPNext built-in |
|---|---|---|---|---|
| `Clinic Admin` | `admin` | Admin | AD | `System Manager` |
| `Practitioner` | `practitioner` | Practitioner | DR | `Physician` |
| `Nurse` | `nurse` | Nurse | RN | `Nurse` (name already matches — keep) |
| `Frontdesk` | `frontdesk` | Front desk | FD | `Healthcare Receptionist` / `Front Desk` |
| `Clinic Staff` | `clinic_staff` | Clinic Staff | CS | — (new) |

> **`Physician` legacy mapping:** `deriveFrontendRole()` temporarily maps both `"Physician"` and `"Practitioner"` → `practitioner` during migration. Remove the `"Physician"` entry once all existing users are reassigned to the `"Practitioner"` role.

### 1.2 Role Capabilities Matrix

| Capability | Front Desk | Nurse | Practitioner | Clinic Staff | Admin |
|---|:---:|:---:|:---:|:---:|:---:|
| Book appointment | ✅ | ❌ | ❌ | ✅ | ✅ |
| Check in patient | ✅ | ❌ | ❌ | ✅ | ✅ |
| Mark ready for practitioner | ❌ | ✅ | ❌ | ✅ | ✅ |
| Start/run encounter | ❌ | ❌ | ✅ | ❌ | ❌ |
| Record vitals | ❌ | ✅ | ✅ | ✅ | ❌ |
| Order labs | ❌ | ❌ | ✅ | ❌ | ❌ |
| Write prescriptions | ❌ | ❌ | ✅ | ❌ | ❌ |
| Collect payment | ✅ | ❌ | ❌ | ✅ | ✅ |
| View invoices | ✅ | ❌ | ❌ | ✅ | ✅ |
| Reschedule / cancel | ✅ | ❌ | ❌ | ✅ | ✅ |
| Mark no-show | ✅ | ❌ | ❌ | ✅ | ✅ |
| View allergy / clinical alerts | ❌ | ✅ | ✅ | ✅ | ✅ |
| Access admin settings | ❌ | ❌ | ❌ | ❌ | ✅ |
| Manage master data | ❌ | ❌ | ❌ | ❌ | ✅ |
| View reports | ❌ | ❌ | ❌ | ❌ | ✅ |

### 1.3 Default Route After Login

| Role | Redirects to |
|---|---|
| `admin` | `/dashboard` |
| `frontdesk` | `/queue` |
| `nurse` | `/queue` |
| `practitioner` | `/appointments` |
| `clinic_staff` | `/dashboard` |

---

## 2. API Access Matrix

### Who can call what

`✅` = allowed · `❌` = blocked (403) · `—` = not applicable to this role

| Endpoint | Front Desk | Nurse | Practitioner | Clinic Staff | Admin |
|---|:---:|:---:|:---:|:---:|:---:|
| **Auth** | | | | | |
| `POST /api/auth/login` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `GET /api/auth/me` | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Patients** | | | | | |
| `GET /api/patients` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `GET /api/patients?id=` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `POST /api/patients` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `PATCH /api/patients` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `POST /api/patients/guardian` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `DELETE /api/patients/guardian` | ✅ | ❌ | ❌ | ✅ | ✅ |
| **Appointments** | | | | | |
| `GET /api/appointments` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `GET /api/appointments?id=` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `POST /api/appointments` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `PATCH /api/appointments` (status) | ✅ | ✅ | ❌ | ✅ | ✅ |
| `POST /api/appointments/cancel` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `POST /api/appointments/check-in` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `GET /api/appointments/slots` | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Encounters** | | | | | |
| `GET /api/encounters` | ❌ | ✅ | ✅ | ✅ | ✅ |
| `POST /api/encounters` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `PATCH /api/encounters` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `POST /api/encounters/complete` | ❌ | ❌ | ✅ | ❌ | ❌ |
| **Vitals** | | | | | |
| `POST /api/vitals` | ❌ | ✅ | ✅ | ✅ | ❌ |
| `GET /api/vitals` | ❌ | ✅ | ✅ | ✅ | ✅ |
| **Labs** | | | | | |
| `POST /api/labs` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `GET /api/labs` | ❌ | ✅ | ✅ | ✅ | ✅ |
| **Prescriptions** | | | | | |
| `POST /api/prescriptions` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `GET /api/prescriptions` | ❌ | ✅ | ✅ | ✅ | ✅ |
| **Billing** | | | | | |
| `GET /api/billing` | ✅ | ❌ | ❌ | ✅ | ✅ |
| `POST /api/billing/payment` | ✅ | ❌ | ❌ | ✅ | ✅ |
| **Providers** | | | | | |
| `GET /api/healthcare/practitioners` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `GET /api/healthcare/practitioners?id=` | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Dashboard** | | | | | |
| `GET /api/dashboard` | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Admin — Master Data** | | | | | |
| `GET/POST /api/admin/*` | ❌ | ❌ | ❌ | ❌ | ✅ |

### How to enforce on the backend

**Website Users have no module permissions by default.** Frappe checks DocType-level permissions before executing any `frappe.get_doc()` / `frappe.get_all()` inside a whitelisted method — even when the Bearer token is valid. Without explicit DocType permissions on the role, every backend call that touches a DocType will throw `PermissionError`.

**Who sets these up:** A Frappe system admin configures permissions via **Role Permissions Manager** (`/app/role-permission-manager`) or via fixtures in `remedisys_healthcare_ai/fixtures/`.

**ERPNext Healthcare built-in roles** (`Physician`, `Nurse`, `Healthcare Receptionist`) already come with reasonable default permissions for Healthcare DocTypes installed by the module. Verify and extend as needed.

**`Clinic Admin`** and **`Clinic Staff`** are custom roles — their DocType permissions must be set up from scratch.

Required DocType permission table:

| Frappe DocType | Physician | Nurse | Healthcare Receptionist | Clinic Staff | Clinic Admin |
|---|---|---|---|---|---|
| Patient | Read | Read | Read+Write+Create | Read+Write+Create | All |
| Patient Appointment | Read+Write | Read+Write | All | All | All |
| Patient Encounter | All | Read+Write | — | Read | All |
| Vital Signs | Read | All | — | Read+Write | All |
| Lab Test | All | Read | — | Read | All |
| Prescription | All | Read | — | Read | All |
| Sales Invoice | — | — | Read | Read | All |
| Payment Entry | — | — | Read+Write+Create | Read+Write+Create | All |
| Healthcare Practitioner | Read | Read | Read | Read | All |
| Healthcare Service Unit | Read | Read | Read | Read | All |
| Appointment Type | Read | Read | Read | Read | All |
| Company | — | — | — | — | Read+Write+Create |
| Department | — | — | — | — | All |
| Insurance Payor | — | — | Read | Read | All |
| Medication | — | — | — | Read | All |
| User | — | — | — | — | Read+Write+Create |

> **Recommended approach:** Export these as JSON fixtures to `remedisys_healthcare_ai/fixtures/custom_perms.json` so permissions are version-controlled and reinstalled automatically on `bench migrate`. Never rely on manual clicks in production.

### How to enforce on the frontend BFF

Each BFF route handler should check the user's `RoleId` after calling `getAccessToken()`:

```ts
// Pattern for role-gated BFF routes
export async function POST(req: Request) {
  const token = await getAccessToken()
  if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 })

  const session = await getSession()
  const role = session?.user?.role   // RoleId derived at login

  // Gate: only practitioner can create encounters
  if (!["practitioner"].includes(role)) {
    return Response.json({ error: "Forbidden" }, { status: 403 })
  }

  // ... proceed to Frappe call
}
```

---

## 3. Admin Master Data Setup

Admin must configure these before the clinic can operate. All are accessible only with the `admin` role.

### 3.1 Setup Order (dependency chain)

```
1. Companies / Branches       ← everything else links to a company
2. Departments                ← practitioners are assigned to departments
3. Healthcare Service Units   ← rooms/areas where appointments happen
4. Appointment Types          ← visit types (Vaccination, Consultation, etc.)
5. Practitioner Schedules     ← when each practitioner works
6. Staff & Users              ← create user accounts, assign Frappe roles
7. Insurance Payers           ← insurers / coverage plans
8. Medications                ← drug master list for prescriptions
```

### 3.2 Master Data APIs

> **IMPORTANT:** All write operations use custom `@frappe.whitelist()` backend methods.
> `frappe.client.insert/save/delete` require `System User` type and must never be called for `Website User` accounts.
> Read operations (`GET`) may use `frappe.client.get_list` via `frappeFetch` since that is read-only and works for Website Users with the correct DocType read permission.

#### Companies / Branches

```
GET    /api/admin/companies        → frappe.client.get_list (Company)
POST   /api/admin/companies        → remedisys_healthcare_ai.api.v1.admin.api.create_company
PATCH  /api/admin/companies        → remedisys_healthcare_ai.api.v1.admin.api.update_company
DELETE /api/admin/companies?id=    → remedisys_healthcare_ai.api.v1.admin.api.delete_company

Response shape (single company):
{
  "name": "Chavitos Clinic",
  "abbr": "CC",
  "country": "Mexico",
  "default_currency": "MXN",
  "email": "admin@chavitos.health",
  "phone_no": "+52 999 123 4567",
  "company_logo": null
}
```

#### Departments

```
GET    /api/admin/departments       → frappe.client.get_list (Department)
POST   /api/admin/departments       → remedisys_healthcare_ai.api.v1.admin.api.create_department
PATCH  /api/admin/departments       → remedisys_healthcare_ai.api.v1.admin.api.update_department
DELETE /api/admin/departments?id=   → remedisys_healthcare_ai.api.v1.admin.api.delete_department

Response shape:
{
  "name": "Pediatrics",
  "company": "Chavitos Clinic",
  "department_name": "Pediatrics"
}
```

#### Healthcare Service Units (Rooms)

```
GET    /api/admin/service-units     → frappe.client.get_list (Healthcare Service Unit)
POST   /api/admin/service-units     → remedisys_healthcare_ai.api.v1.admin.api.create_service_unit
PATCH  /api/admin/service-units     → remedisys_healthcare_ai.api.v1.admin.api.update_service_unit
DELETE /api/admin/service-units?id= → remedisys_healthcare_ai.api.v1.admin.api.delete_service_unit

Response shape:
{
  "name": "SU-CONSULT-1",
  "service_unit_name": "Consultation Room 1",
  "company": "Chavitos Clinic",
  "service_unit_type": "Out-patient",
  "overlap_appointments": false,
  "service_unit_capacity": 1
}
```

#### Appointment Types (Visit Types)

```
GET    /api/admin/appointment-types     → frappe.client.get_list (Appointment Type)
POST   /api/admin/appointment-types     → remedisys_healthcare_ai.api.v1.admin.api.create_appointment_type
PATCH  /api/admin/appointment-types     → remedisys_healthcare_ai.api.v1.admin.api.update_appointment_type
DELETE /api/admin/appointment-types?id= → remedisys_healthcare_ai.api.v1.admin.api.delete_appointment_type

Response shape:
{
  "name": "Vaccination",
  "default_duration": 15,
  "color": "#10B981",
  "billing_item": "Consultation Fee"
}
```

#### Staff & Users

```
GET    /api/admin/staff     → remedisys_healthcare_ai.api.v1.admin.api.list_staff
POST   /api/admin/staff     → remedisys_healthcare_ai.api.v1.admin.api.create_staff_user
PATCH  /api/admin/staff     → remedisys_healthcare_ai.api.v1.admin.api.update_staff_user
DELETE /api/admin/staff?id= → remedisys_healthcare_ai.api.v1.admin.api.disable_staff_user
```

> All staff created as **Website User** type. `create_staff_user` must set `user_type = "Website User"` explicitly.

Response shape (staff member):
{
  "name": "doctor@clinic.mx",
  "full_name": "Dr. Carlos García",
  "email": "doctor@clinic.mx",
  "role": "practitioner",            ← frontend RoleId
  "frappe_roles": ["Physician"],     ← actual Frappe roles
  "department": "General Medicine",
  "practitioner": "HP-0001",         ← null for non-doctor roles
  "enabled": true
}
```

#### Insurance Payers

```
GET    /api/admin/insurance     → frappe.client.get_list (Insurance Payor)
POST   /api/admin/insurance     → remedisys_healthcare_ai.api.v1.admin.api.create_insurance_payor
PATCH  /api/admin/insurance     → remedisys_healthcare_ai.api.v1.admin.api.update_insurance_payor
DELETE /api/admin/insurance?id= → remedisys_healthcare_ai.api.v1.admin.api.delete_insurance_payor

Response shape:
{
  "name": "IMSS",
  "insurance_company_name": "Instituto Mexicano del Seguro Social",
  "payer_id": "IMSS-001",
  "default_coverage": 80.0,
  "contact": "contacto@imss.gob.mx"
}
```

#### Medications (Drug Master)

```
GET    /api/admin/medications     → frappe.client.get_list (Medication)
POST   /api/admin/medications     → remedisys_healthcare_ai.api.v1.admin.api.create_medication
PATCH  /api/admin/medications     → remedisys_healthcare_ai.api.v1.admin.api.update_medication
DELETE /api/admin/medications?id= → remedisys_healthcare_ai.api.v1.admin.api.delete_medication

Response shape:
{
  "name": "Paracetamol 250mg",
  "drug_name": "Paracetamol",
  "strength": "250mg",
  "dosage_form": "Tablet",
  "default_dosage": "1 tablet every 8 hours",
  "is_antibiotic": false
}
```

### 3.3 Admin Setup Screen Flow

The frontend `/settings` page (admin only) should guide through the setup order:

```
Settings
├── 🏥 Clinic Setup
│   ├── Branches          → /api/admin/companies
│   └── Departments       → /api/admin/departments
├── 🗓️ Scheduling Setup
│   ├── Service Units     → /api/admin/service-units
│   └── Visit Types       → /api/admin/appointment-types
├── 👥 Staff Setup
│   └── Staff & Roles     → /api/admin/staff
├── 💊 Clinical Setup
│   └── Medications       → /api/admin/medications
└── 🏦 Billing Setup
    └── Insurance Payers  → /api/admin/insurance
```

Each section shows a setup completion indicator so admin knows what's still missing.

---

## 4. Role Name — Fix Required

**Current state (broken for practitioners):**

```ts
// src/lib/auth/roles.ts — current
if (roles.includes("Practitioner")) return "practitioner";  // ← maps "Practitioner"
```

```python
# auth/api.py — actual Frappe role returned
"roles": ["Physician", "System User"]  # ← returns "Physician"
```

**Fix options — choose one:**

**Option A** — Rename Frappe role (backend change):
Create a new Frappe role called `"Practitioner"` in ERPNext, assign to doctor users.
Pros: frontend stays clean. Cons: needs backend migration + re-assigning existing users.

**Option B** — Map both names (frontend change):
```ts
// src/lib/auth/roles.ts
if (roles.includes("Practitioner") || roles.includes("Physician")) return "practitioner";
```
Pros: no backend change, backwards compatible. Cons: two names for the same role.

**Recommendation: Option B** — safest, no data migration needed. Add "Physician" acceptance now, remove it after all users are migrated to the new role name.

---

## 5. Open Decisions

| # | Decision | Options | Owner | Status |
|---|---|---|---|---|
| 1 | Frappe role name: `Physician` vs `Practitioner` | ✅ **Resolved:** Create custom `"Practitioner"` role. Legacy `"Physician"` kept in `deriveFrontendRole()` during migration. | — | ✅ Resolved |
| 2 | Admin staff creation | ✅ **Resolved:** custom API only — `Website User` accounts cannot use `frappe.client.insert`. Backend team must build `api/v1/admin/api.py`. | — | ✅ Resolved |
| 3 | Frappe user type for all clinic accounts | ✅ **Resolved:** `Website User`. No frontend user is ever `System User`. | — | ✅ Resolved |
| 4 | Clinic Staff role: keep as combined FD+Nurse or split? | Keep · Split | Product owner | ❓ Open |
| 5 | Multi-clinic: one login with clinic switcher or separate login per clinic? | Switcher · Separate | Product owner | ❓ Open |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-10 | Sarvesh | Initial version (header backfilled from git history) |
