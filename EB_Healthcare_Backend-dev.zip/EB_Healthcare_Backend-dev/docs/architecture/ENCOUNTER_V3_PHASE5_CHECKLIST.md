# Encounter V3 — Phase 5 Implementation Checklist (Transcript Persistence Reliability)

**Doc status:** record · **Created:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.5

Design authority: [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
§10 (Transcript persistence), §4's Integrity row, and §22's transcript test-matrix
rows. **Unlike Phase 3/4, this design doc never fully specified Phase 5** — its
own phase table gives it one line ("Transcript reliability: watermark, final
flush, retry visibility — not started") and §21 explicitly defers detail:
*"Phases 5–9 — gates defined at entry, following the same shape."* This
checklist **is** that entry-time definition.

**Status as of v2.5: Phase 5 (Steps 1–6) is implemented, tested, and formally
exit-verified — see §22.** `Doc status` moved from `draft` to `living` at
v2.5 for exactly that reason: everything below now describes the system as
it actually is (implemented, approved, exit-verified), not a proposal
awaiting review. Earlier revisions (recorded in full below and in the
Revision history) were genuinely `draft` at the time they were written —
v1.0 was a pure read-only audit, and v2.0–v2.4 progressively resolved scope,
proposed and then revised the physician-facing UX design (§19), and recorded
each implementation/testing pass as it happened, including a genuine defect
found and fixed during exit verification (§22.1). That history is kept
rather than rewritten, per this repo's documentation conventions.

---

## 1. Scope — read-only audit, this turn and last

### 1.1 What was inspected (cumulative, v1.0 + v2.0)

- **Backend:** `remedisys_healthcare_ai/api/ai/segments.py` (`append_segment`,
  `sync_transcript`) read in full. `api/ai/sessions.py`'s
  `get_encounter_transcript` read. `AI Transcript Segment`'s DocType JSON read
  in full. 13 existing tests in `tests/ai/test_segments.py` enumerated.
- **Frontend** (`/Users/apple/Healthcare_next_app`), read in full or by targeted
  section, nothing assumed from the design doc's prose alone:
  - `src/components/narzim/encounter/copilot/real-provider.ts` (1,403 lines) —
    `_persistTranscript`, `_autosaveTranscript`, `_syncTranscript`,
    `_hydrateTranscript`, `persistedCount`, `segSeq`, `start()`, `stop()`,
    `_finalizeAfterProviderFailure()`, `_rotateSocket` (retry precedent).
  - `src/components/narzim/encounter/copilot/use-copilot.ts` — the `stop`
    `useCallback`, its `state` machine, its `error`/`setError` mechanism.
  - The `.stop()` call chain, traced by grep: `use-copilot.ts` →
    `CopilotHost.tsx` → `v3/use-recording.ts` → `RecordingControls.tsx`.
  - The three Next.js BFF routes between the provider and the backend:
    `src/app/api/ai/session/segments/route.ts`,
    `.../sync-transcript/route.ts`, `.../active/route.ts` — all read in full.
  - Existing UX components, read directly (not only via subagent report):
    `src/components/narzim/encounter/v3/recording-ui.tsx` (`ConsentGate`,
    `FailureBanner`) and `src/components/narzim/patient-chart/dialogs.tsx`
    (`ConfirmRemoveDialog`).
- **Database:** `marley.local`, read-only — Finding A's 8 duplicate rows
  re-confirmed unchanged; 146 sessions / 14,187 segments / 0 `Recording`,
  unchanged since Phase 4's exit.

### 1.2 Confirmed unchanged from Phase 3/4's own audits

- Finding A (8 existing `(session, sequence_number)` duplicates, no composite
  unique index) — **re-verified live, identical to Phase 3's original count**:
  `AIES-2026-00117` seq 3/4/5 (3 rows) and `AIES-2026-00131` seq
  138/139/140/141/144 (5 rows) = 8. **Assigned to Phase 9 by your explicit
  instruction this turn** — not touched, not migrated, not deduplicated here.
- `marley.local` current state unchanged since Phase 4's exit.

---

## 2. The problem — WHAT / WHY / HOW / WHEN

**WHAT.** The system can silently lose transcript text, or silently corrupt
which segments are considered saved, without telling anyone. Three call
sites in `real-provider.ts` treat a failed persistence attempt — a thrown
network error, a normal HTTP response with a non-2xx status, or an
unrecoverable resume — as if it had succeeded. The UI keeps showing whatever
transcript it holds in memory, which can silently diverge from what the
server actually has.

**WHY.** Rule 7 ("AI failure must not break healthcare") correctly says a
persistence failure must not block the clinical flow — Stop, SOAP
generation, signing the encounter must all keep working. It does **not** say
the physician should never be told, and it does not require lying about
persistence state to keep the flow moving. The design doc's own §10.2 cites
direct precedent already living in this exact file: "Fix speakers" 500'd on
every call and "looked identical to a working save until the page was
reloaded and the old speakers came back" — a real, shipped incident, fixed
2026-07-31 for that one call site only (`_syncTranscript`). That partial fix
is the proof this needs a general fix, not another one-off patch.

**HOW (the mechanism, verified in code).** Three call sites, three distinct
defects, all sharing the same underlying pattern — `fetch()` resolving with a
non-2xx status is not the same as `fetch()` throwing, and nothing here
checks `res.ok`:

1. **`_autosaveTranscript()`** (the 20-second background save) —
   **unconditionally advances the watermark** after `fetch()` resolves,
   regardless of status. A failed autosave permanently marks its segments as
   saved; they are never retried. **This is the bug you explicitly flagged as
   critical.**
2. **`_persistTranscript()`** (the flush at Stop and at provider-failure
   finalize — the most safety-critical call site) — never checks the
   response status **at all**, and never updates the watermark in either
   direction. Worse than #1 in one sense (no watermark tracking whatsoever
   at the one moment persistence truth matters most) and better in another
   (it doesn't actively mislabel — it just says nothing).
3. **`_hydrateTranscript()`** (resume/reload) — **new finding this turn,
   found while tracing the complete flow as instructed.** On any hydrate
   failure (non-2xx response or thrown exception), it silently returns,
   leaving `persistedCount` and `segSeq` at their fresh-instance default of
   `0`. Backend `sequence_number` is array-index-derived at every call site
   (confirmed by grep — `segSeq` is never sent to the backend; it is only
   used to build a local UI `id` string), so the next segment recorded after
   a failed hydrate is sent with `sequence_number: 0`, colliding with
   whatever was already persisted at that index before the reload.
   `append_segment`'s idempotency check (`frappe.db.exists()`) then reports
   this new, different segment as a `duplicate` of the old one and silently
   discards it. **This is a total, silent loss of every newly recorded
   segment after a failed resume — more severe than the autosave bug**,
   because the autosave bug loses a bounded window of segments while this
   loses everything from that point forward, indefinitely, with the UI
   showing the new content as if it were fine (Deepgram's WebSocket keeps
   delivering finals into memory regardless of what the backend did with
   them).

A fourth, related but non-defect observation: the Next.js BFF route
`src/app/api/ai/session/segments/route.ts` already computes an accurate
per-batch `{persisted, duplicate, sealed, failed}` count from the real
backend responses (looping per segment, calling `append_segment`, catching
per-segment failures into `counts.failed`) and returns it as the response
body — but neither `_persistTranscript` nor `_autosaveTranscript` ever calls
`.json()` on the response to read it. The signal needed to fix this already
exists at every layer; it is discarded specifically at these two call sites.

**WHEN.** Live today, not hypothetical. Every recording session that has hit
a network blip or a transient server error during autosave, or a failed
hydrate on resume, has been exposed to this invisibly since those mechanisms
shipped. No incident is confirmed to have been *caused* by it (unlike the
caught Fix-speakers bug), but nothing would catch one if it happened — which
is exactly the gap T3 exists to close.

**USER STORY.** Dr. Bracamontes is recording a 20-minute consultation. At
minute 12 the clinic Wi-Fi drops for four seconds — long enough for one
20-second autosave tick's `fetch()` to fail. **The system shows** nothing —
no banner, no console the physician would ever open — the transcript panel
keeps scrolling normally because Deepgram's WebSocket (a separate connection)
keeps delivering finals into memory. **The database actually contains** a
gap: the segments pending at that tick are marked "persisted" in the
browser's own bookkeeping (`persistedCount` advanced anyway) but were never
written to `AI Transcript Segment`, and are never retried, because the next
tick only sends segments *after* the wrongly-advanced watermark.
**Consequence:** Dr. Bracamontes signs the encounter believing the transcript
is complete; the SOAP draft is generated correctly from the in-memory
transcript (which still has the missing lines); but the persisted, auditable
record — the one a covering clinician or an auditor reads later — has a
silent hole, with nothing in the UI, the logs, or the database indicating one
exists.

A second, worse story for the resume bug: Dr. Bracamontes's laptop sleeps
mid-encounter; she reopens the tab. `_hydrateTranscript()`'s request happens
to fail (a token refresh race, a transient 500). The UI shows the prior
transcript from `finalSegments` in memory correctly hydrated by the
component, recording resumes, she keeps talking. **Every segment she records
from this point on** is silently discarded as a "duplicate" by the backend.
At Stop, `_persistTranscript()` sends the same colliding sequence numbers
again, gets `duplicate` back for all of them, and (per defect #2) checks
nothing. The encounter is signed with a transcript and SOAP draft that look
complete on screen but whose second half was never saved.

**EXAMPLE.** The exact code proving defect #1, read directly:
```ts
// _autosaveTranscript(), real-provider.ts:1091-1102
try {
  await fetch("/api/ai/session/segments", { method: "POST", ... });
  // Advances the watermark whether or not the request actually succeeded —
  // fetch() does not throw on a non-2xx response, and this never checks
  // res.ok, and never reads the {persisted,duplicate,sealed,failed} body
  // the route below already computes.
  this.persistedCount = Math.max(this.persistedCount, snapshotCount);
} catch {
  // Only a *thrown* exception is ever seen.
}
```
The signal being thrown away, read directly from the BFF route:
```ts
// src/app/api/ai/session/segments/route.ts
const counts = { persisted: 0, duplicate: 0, sealed: 0, failed: 0 };
for (const seg of segments) {
  try {
    const res = await frappeFetch<AppendResult>(
      "remedisys_healthcare_ai.api.ai.segments.append_segment",
      { token, body: { session: body.session, ...seg } },
    );
    if (res.status === "persisted") counts.persisted += 1;
    else if (res.status === "duplicate") counts.duplicate += 1;
    else if (res.status === "sealed") counts.sealed += 1;
  } catch {
    counts.failed += 1;
  }
}
return Response.json(counts);
```
Compare to `_syncTranscript()` (real-provider.ts:964-1003), the one call site
already fixed 2026-07-31, which checks `res.ok` and the response body and
logs a warning on failure — proving the fix pattern already exists in this
same file. Even there, the warning only reaches `console.warn`, never a
physician-visible component.

**Expected behavior after Phase 5.** The UI never implies "saved" beyond
what the server has actually confirmed. Mid-recording, a failed autosave
shows a clear, non-blocking, physician-visible warning within one cycle and
keeps retrying without touching the watermark. At Stop, if anything is
unconfirmed, the physician sees a blocking dialog and must explicitly
acknowledge before the encounter moves past Stop. A failed resume can no
longer cause new content to be silently discarded as a false duplicate.

---

## 3. Existing functionality vs. new Phase 5 work

### 3.1 Already correct, not touched by this phase

- **`append_segment`'s idempotency** and **`sync_transcript`'s reconcile
  semantics** — already correct, already tested
  (`test_duplicate_sequence_is_idempotent`, `test_late_final_after_stop_returns_sealed`,
  `test_creates_and_deletes_to_match_corrected_length`).
- **The backend, and the Next.js BFF layer in front of it, already return
  everything a real watermark needs on success or failure** —
  `append_segment` → `{name, sequence_number, duplicate, status}`;
  `sync_transcript` → `{status, updated, created, deleted}`; the BFF's own
  `segments/route.ts` → `{persisted, duplicate, sealed, failed}` per batch.
  **Confirmed this turn, having traced the complete frontend flow as
  instructed: no backend or BFF response-shape change is needed.** The
  design doc's §10.3 says it directly: *"The information already exists and
  is thrown away."* This is now independently verified, not assumed.
- **`get_encounter_transcript(encounter)`** — read-only, encounter-scoped,
  returns every final segment regardless of session. Confirmed present and
  usable as a resume/reload fallback (§13); its precision for session-scoped
  reconciliation is the one residual implementation detail to confirm
  in-code before Step 5, not a backend gap (§7.2 resolved this as
  "assume sufficient unless proven otherwise").
- **`_syncTranscript()`'s `res.ok` check and status validation** (added
  2026-07-31) — the reference pattern this fix extends everywhere else.
- **Existing UX components, verified directly this turn** — see §11 and §12.
  `FailureBanner` (`v3/recording-ui.tsx:79-122`) and `ConfirmRemoveDialog`
  (`patient-chart/dialogs.tsx:12-58`) are real, in active use, and structurally
  fit both halves of your UX requirement without inventing anything new.

### 3.2 New Phase 5 work — frontend only, `Healthcare_next_app`

- **`_autosaveTranscript()`** — stop advancing `persistedCount`
  unconditionally; advance it only for the leading contiguous range the
  server actually confirmed. (§10, §11)
- **`_persistTranscript()`** — add the same `res.ok`/body check
  `_syncTranscript` already has; make its result inspectable by its caller
  so Stop can know whether anything is unconfirmed. (§10, §12)
- **`_hydrateTranscript()`** — never fall back to a bare `persistedCount = 0`
  on failure; retry, and if still unresolved, block new-segment sequencing
  behind an explicit, surfaced "could not verify" state rather than silently
  risking collision. (§10, §13)
- **`stop()`** — currently `Promise<void>`; needs to expose enough for its
  caller (`use-copilot.ts`) to know if the transcript is fully confirmed at
  the moment Stop completes. (§12)
- **A physician-facing UI signal** — does not exist today in any form; built
  from the two existing patterns identified in §11/§12, not invented fresh.
- **`use-copilot.ts`'s `stop` callback** — the integration point for the new
  blocking Stop-time state.

---

## 4. Files, DocTypes, APIs, and tests involved

| Kind | Item | Role |
|---|---|---|
| Backend API | `remedisys_healthcare_ai/api/ai/segments.py` — `append_segment`, `sync_transcript` | Unchanged contract; confirmed sufficient |
| Backend API | `remedisys_healthcare_ai/api/ai/sessions.py` — `get_encounter_transcript` | Resume/reload fallback source; contract confirmed present, precision to be confirmed in-code at Step 5 |
| DocType | `AI Transcript Segment` | Finding A (plain index, no composite unique constraint) — Phase 9's scope, not touched |
| Backend tests | `tests/ai/test_segments.py` (13 tests) | No change anticipated |
| Frontend (BFF) | `Healthcare_next_app/src/app/api/ai/session/segments/route.ts` | Already computes `{persisted,duplicate,sealed,failed}` — no change needed, just needs to be *read* by its caller |
| Frontend (BFF) | `.../session/sync-transcript/route.ts` | Already correct pattern (returns `status`/`reason`); no change needed |
| Frontend (BFF) | `.../session/active/route.ts` | Resume-path read; confirmed shape, candidate input to §13's fix |
| Frontend | `.../copilot/real-provider.ts` | `_persistTranscript`, `_autosaveTranscript`, `_hydrateTranscript`, `persistedCount`, `stop()` — the actual defects and the fix |
| Frontend | `.../copilot/use-copilot.ts` | `stop` `useCallback` — integration point for the new blocking Stop-time state |
| Frontend (UX, reused) | `.../v3/recording-ui.tsx` — `FailureBanner` | Reused pattern for the non-blocking mid-recording warning |
| Frontend (UX, reused) | `.../patient-chart/dialogs.tsx` — `ConfirmRemoveDialog` | Reused pattern for the blocking Stop-time dialog |
| Frontend (UX, call site) | `.../v3/encounter-flow.tsx` | Existing `FailureBanner` invocation site; new banner instance likely added alongside it |
| Frontend tests | Playwright suite (pattern from Phase 1) | New tests needed (§14); none exist today for this behavior |
| Scheduler | None | Confirmed no relationship to Phase 4's `sweep_orphan_sessions` |

---

## 5. Dependencies on Phase 3 and Phase 4

- **None functionally block Phase 5.** Phase 5 does not read or write
  `active_key`, does not touch session status transitions, and does not
  interact with the hard-cap sweep.
- **Indirect dependency, worth naming:** Phase 4's `_finalize_hard_capped_session`
  and Phase 2's `_finalizeAfterProviderFailure()` both derive `ended_at` from
  `MAX(AI Transcript Segment.creation)`. If this phase changes when a segment
  counts as "confirmed persisted," that evidence-derivation logic should be
  re-examined for consistency during implementation — a review item, not a
  known break.

---

## 6. Migration, schema, and impact risk

- **No schema/migration risk for the core fix** — confirmed this turn, not
  assumed: every backend and BFF response the fix needs already exists with
  its current shape (§3.1). `get_encounter_transcript`'s exact sufficiency
  for session-scoped resume is the one item still to confirm in-code, not a
  schema question.
- **Production/Frappe Cloud impact vs. local/test, per your decision that
  this is a frontend-only initiative:**
  - **Backend:** zero production impact — no migration, no new field, no
    scheduler change, no `marley.local`/`test.marley.local` change of any
    kind. Confirmed by this turn's scope decision (§7).
  - **Frontend:** ships through `Healthcare_next_app`'s own Vercel pipeline —
    a separate repo, separate deploy, separate review process, outside this
    backend repo's `dev → pre → main` flow and CI. Tracked here for
    project-level traceability only, per your explicit instruction.
- **Data-loss risk from not doing this phase:** ongoing and already real —
  every day without the fix is another day a transient failure or a failed
  resume can silently drop content, unlike Phase 4's now-static backlog.

---

## 7. Scope and design decisions — resolved 2026-08-27, superseding v1.0's open questions

The four questions v1.0 raised were answered explicitly. Recorded here as
decisions, not options:

**7.1 — Repo scope: RESOLVED, frontend-only.** Phase 5 is implemented
entirely in `Healthcare_next_app`. This checklist stays in the backend repo
as the design record, for the same project-traceability reason Phase 3/4's
checklists live here. No backend implementation happens under Phase 5 unless
§7.2's assumption turns out to be wrong.

**7.2 — Backend sufficiency: RESOLVED, assumed sufficient, now independently
verified.** `append_segment` and `sync_transcript` are assumed sufficient.
Per your instruction, the complete frontend flow was traced before writing
this down — autosave, response handling, non-2xx handling, the watermark,
retry behavior, stop/finalization, and resume/reload hydration were all read
directly (§1.1, §2, §3.1). **No backend gap was found.** The three defects
found are all frontend-side failures to use information the backend and BFF
already provide. If implementation surfaces a genuine gap (most likely
candidate: `get_encounter_transcript`'s session-precision at Step 5), the
instruction stands — implementation stops and the exact gap is reported
before any backend file is touched.

**7.3 — Physician UX: RESOLVED, both halves reuse existing components.**
- Non-blocking, mid-recording: `FailureBanner`'s pattern
  (`v3/recording-ui.tsx:79-122`) — verified directly this turn: a `kind`-keyed
  inline Tailwind banner (icon, title, body, single retry action), already
  rendered inline in the normal flow at `v3/encounter-flow.tsx`. The fix adds
  a sibling variant/instance for "transcript not yet confirmed saved,"
  matching this exact shape — no new visual language.
- Blocking, at Stop: `ConfirmRemoveDialog`'s pattern
  (`patient-chart/dialogs.tsx:12-58`) — verified directly this turn: a
  `createPortal`-to-`document.body` backdrop+centered card, with
  title/name/description, a cancel action, and a primary action that
  disables itself while `saving`. The fix builds a sibling component
  following this exact structure — portal, backdrop, title + explanation +
  explicit acknowledgment action — with copy specific to "some of this
  transcript is not yet confirmed saved," not a generic destructive-action
  dialog. No shadcn `AlertDialog` exists in this codebase (confirmed by
  grep) and none is introduced — this stays consistent with how confirms are
  already built app-wide.
- `sonner` (toast library, in `package.json`, used elsewhere) is
  **deliberately not used here** — the copilot/recording surface has its own
  established banner/dialog idiom (`FailureBanner`, `ConsentGate`,
  hand-rolled confirms) and mixing in toast for just this one feature would
  itself be inventing a new interaction model in a surface that already has
  one.

**7.4 — Finding A / Phase 9 boundary: RESOLVED, stays at Phase 9.** The 8
existing duplicate rows and the missing composite unique index are not
touched, cleaned, migrated, or modified during Phase 5. Phase 5's dedupe
coverage stays entirely at the application level (already correct, §3.1).

---

## 8. Findings recorded, nothing removed or fixed yet

- **Finding A (Phase 3, re-verified, Phase 9's to fix, not Phase 5's):** 8
  `(session, sequence_number)` duplicate rows, unchanged, on `marley.local`.
- **Finding B (v1.0): `_autosaveTranscript`'s watermark-advances-on-failure
  bug.** The bug you explicitly flagged as critical. §2, §10.
- **Finding C (v1.0): `stop()` returns no persistence-state information to
  its caller.** An interface gap, not a bug per se — a precondition for T3.
  §3.2, §12.
- **Finding D (new, v2.0): `_hydrateTranscript`'s resume/reload
  sequence-number collision.** Found while tracing the complete frontend
  flow as instructed. More severe than Finding B — causes total, ongoing,
  silent loss of newly recorded content after a failed resume, not a bounded
  window. §2, §13.
- **Finding E (new, v2.0): the Next.js BFF `segments/route.ts` already
  computes `{persisted, duplicate, sealed, failed}` per batch, and this is
  never read by `real-provider.ts`.** Not a bug in the route itself — a
  wasted, already-correct signal at the exact layer the fix needs it from.
  §2, §10.
- Everything in §3.1 is recorded as-is — not proposed for removal or rework.

---

## 9. Exact root cause (single-paragraph, for the report)

All three defects (Findings B, C, D) reduce to one root cause: `fetch()`
resolving with a non-2xx HTTP status is not a thrown exception in the
browser, and every affected call site's `try { await fetch(...) } catch {}`
pattern only reacts to a thrown exception — never to `res.ok`, never to the
response body. Both the Frappe backend and the Next.js BFF layer in front of
it already compute and return an accurate success/failure signal
(`status`/`duplicate` per segment; `{persisted, duplicate, sealed, failed}`
per batch); the frontend provider simply never parses it. `_syncTranscript()`
is the one call site fixed for this exact reason on 2026-07-31, proving the
pattern and the fix are already known-good in this codebase — Phase 5 is
applying that same pattern to the other two call sites, closing the
`_hydrateTranscript` collision this created a second way, and — per your
explicit instruction — making the resulting truth visible to the physician
instead of stopping at a console log.

---

## 10. Proposed fix — watermark truth/logic, not a UI bolt-on

Per your explicit instruction, this is a fix to what `persistedCount` (the
watermark) *means*, not a warning layered on top of its current, wrong
semantics.

- **Definition, made precise:** the watermark is the count of leading
  segments the server has **confirmed** — `res.ok === true` **and** a
  per-segment/per-batch status of `persisted` or `duplicate` (for
  `append_segment`-based calls) or `synced` (for `sync_transcript`). Nothing
  else ever advances it. Not "the fetch resolved." Not "the fetch didn't
  throw."
- **`_autosaveTranscript()` and `_persistTranscript()`** both read the BFF's
  `{persisted, duplicate, sealed, failed}` body already computed and
  returned. Because the route processes segments in order and only the
  leading contiguous run can be trusted as confirmed if a later one failed
  mid-batch, the watermark advances only through the last confirmed segment
  in that leading run — never past a `failed` entry, and never on `res.ok
  === false` or a thrown exception.
- **`sealed`** is its own terminal case, not "confirmed" and not silently
  retried forever either: it means the session already closed server-side,
  so that segment can never be written. This must be surfaced distinctly
  (§12) rather than folded into either "saved" or "still pending."
- **`_hydrateTranscript()`** must not treat "hydrate failed" as
  equivalent to "there was nothing to hydrate." See §13.

This is deliberately a logic change inside the provider, before any UI is
touched — the UI in §11/§12 reports this corrected truth; it does not
compensate for the old, wrong truth.

---

## 11. Retry and watermark rules

> **Extended by §19 (2026-08-27 UX safety review).** The mid-recording banner
> needs a debounce (show only after 2 consecutive failed cycles, not the
> first) and a distinct, more urgent treatment for `sealed` than for
> `failed` — see §19.1. Read §19 before implementing Step 4.

1. The watermark advances only per §10's definition — never optimistically.
2. Segments at or past the watermark are always included in the next
   autosave batch automatically — no separate retry-queue data structure is
   needed, because "unconfirmed" already means "not yet past the watermark,"
   and the existing "send everything from `persistedCount` onward" batching
   already resends them on the next natural 20-second tick.
3. Resending an already-persisted segment is safe and already tested
   server-side (`test_duplicate_sequence_is_idempotent`) — retries need no
   dedup logic of their own.
4. The non-blocking banner (§7.3) exposes a manual **"Retry now"** action
   that simply invokes `_autosaveTranscript()` immediately, out of the
   normal 20-second cadence — not a new retry/backoff mechanism. Unlike
   `_rotateSocket`'s bounded `ROTATE_RETRIES = 2`, autosave retries are
   uncapped: each tick is a cheap, idempotent, natural retry, so a count
   limit adds no safety and only risks giving up on real content.
5. A `sealed` result is never retried (the session is closed; retrying
   cannot succeed) and is never marked confirmed — it is reported to the
   physician as a distinct "could not be saved — recording already ended"
   state at Stop-time review, not silently dropped and not equated with
   "saved."

---

## 12. Stop/Finish behavior

> **Superseded in part by §19 (2026-08-27 UX safety review).** Point 3 below
> ("requires an explicit acknowledgment action") is revised: §19 recommends an
> **acknowledged block** (always offers "Continue without confirming" as a
> real, working escape hatch alongside "Retry saving"), not an unconditional
> hard block with no way to proceed short of a successful retry. Read §19
> before implementing Step 5.

1. `stop()`'s call sequence (flush recorder → release mic → close socket →
   `_persistTranscript()` → `_syncTranscript()` → `stop_session` API →
   transcript build → suggestions) is unchanged in order. What changes is
   that `_persistTranscript()` and `_syncTranscript()` now produce an
   inspectable result instead of a fire-and-forget `void`.
2. `stop()` returns enough for its caller to know, at the moment persistence
   finished attempting: how many segments are confirmed vs. how many remain
   unconfirmed (failed, or `sealed`-rejected).
3. `use-copilot.ts`'s `stop` callback (its natural integration point,
   confirmed by reading it directly) checks this result before transitioning
   `state` to `"ended"`. If anything is unconfirmed, it instead renders the
   new blocking dialog (§7.3, built on `ConfirmRemoveDialog`'s pattern) —
   the dialog states plainly that some transcript content is not confirmed
   saved, distinguishes "will retry" (failed) from "cannot be saved" (sealed)
   if both are present, and requires an explicit acknowledgment action before
   the state machine is allowed to advance to `"ended"`.
4. Per Rule 7, this blocking dialog blocks only the **UI's own transition to
   "recording finished"** — it never blocks the underlying `stop_session`
   API call, the transcript build, or suggestion fetching, none of which
   depend on the dialog being dismissed. The physician can still leave with
   a manually-typed note if they choose; they simply cannot be shown a false
   "saved/complete" state first.

---

## 13. Resume/reload behavior

1. `_hydrateTranscript()`'s failure path is the fix target (Finding D). On
   failure, it must not default `persistedCount`/`segSeq` to `0` and proceed
   as if nothing was ever recorded.
2. Proposed shape: retry the hydrate fetch with a bounded attempt count,
   mirroring the existing `_rotateSocket` retry-with-limited-attempts
   precedent already in this file (distinct from autosave's uncapped
   retries in §11 — a broken initial hydrate is a startup precondition, not
   an ongoing background save, so a bound here is appropriate).
3. If hydrate retries are exhausted, `start()` must not silently continue as
   though `persistedCount = 0`. Two options, to be finalized against
   `get_encounter_transcript`'s exact session-scoping precision at
   implementation time (the one residual item from §7.2):
   - **(a)** Fall back to `get_encounter_transcript(encounter)` as a
     secondary source of truth for the true persisted count, if its
     per-session precision is confirmed sufficient; or
   - **(b)** If (a) cannot be confirmed sufficient, block new recording
     behind a physician-facing warning stating the prior transcript for this
     session could not be verified, requiring acknowledgment before
     continuing — the same blocking-dialog pattern as §12, reused rather
     than a second new component.
4. Either way, no new segment is ever assigned a `sequence_number` derived
   from an unverified `persistedCount` — this is the actual regression fix
   for Finding D, and is what the test in §14 verifies directly.

---

## 14. Test plan

Frontend-only, in `Healthcare_next_app` (exact test runner/tooling to be
confirmed at implementation time — not yet verified in this pass):

1. `_autosaveTranscript` with a mocked non-2xx response → watermark
   unchanged; the same segments are included in the next autosave call.
2. `_autosaveTranscript` with a mocked thrown network error → same
   assertion as (1).
3. `_autosaveTranscript` with a mocked partial-failure BFF body
   (`{persisted: 2, failed: 1}` for a 3-segment batch) → watermark advances
   only past the 2 confirmed segments, not all 3.
4. `_persistTranscript` at Stop with a mocked failing response → the value
   `stop()` returns/exposes reflects "not fully confirmed."
5. **Regression test for Finding D:** `_hydrateTranscript` failure on
   resume, followed by a new recorded segment → assert the new segment's
   `sequence_number` does not collide with an already-persisted pre-reload
   sequence number, and that the segment is not silently reported
   `duplicate` by the backend.
6. Playwright, Stop-time blocking dialog: simulate a trailing watermark at
   Stop → assert the dialog renders, blocks the `"ended"` transition, and an
   explicit acknowledgment click is required to proceed.
7. Playwright, non-blocking banner: simulate one autosave failure
   mid-recording → assert the `FailureBanner`-pattern warning renders
   without interrupting the recording UI, and the "Retry now" action
   triggers an immediate autosave attempt.
8. Confirm no regression in the 13 existing `test_segments.py` backend tests
   (expected: none, since no backend contract changes).

---

## 15. Acceptance criteria

- **AC1:** No test or manual scenario advances the watermark past a segment
  the server did not confirm (`res.ok` true and status
  `persisted`/`duplicate`/`synced`).
- **AC2:** A non-2xx or thrown response during autosave never blocks
  recording (Rule 7 preserved) but produces a non-blocking, physician-visible
  warning within one autosave cycle (~20s).
- **AC3:** At Stop, if anything is unconfirmed when `_persistTranscript`/
  `_syncTranscript` finish, a blocking dialog appears and an explicit
  acknowledgment is required before the UI shows "ended."
- **AC4:** A resumed/reloaded session cannot silently lose newly recorded
  content to a `sequence_number` collision with pre-reload segments (Finding
  D's regression test passes).
- **AC5:** No existing Phase 3/4 test regresses; no backend contract change
  is required — or, if implementation finds one is genuinely needed,
  implementation stops and the exact gap is reported before any backend
  file is touched, per your explicit instruction.
- **AC6:** All new physician-facing copy goes through the i18n message
  catalog — no hardcoded strings (Frontend Rule 10).
- **AC7:** Finding A's 8 duplicate rows remain untouched; no schema,
  migration, or backfill runs as part of this phase.

---

## 16. Rollback plan

- Frontend-only change, deployed through `Healthcare_next_app`'s own Vercel
  pipeline — rollback is a standard revert/redeploy of the prior build; no
  data migration to undo, since §6 confirms no schema change is needed.
- The fix is strictly more conservative than today's behavior — it can only
  cause the watermark to advance *later* than it does today, never earlier,
  so the worst-case regression is redundant `append_segment` calls, which
  the backend already handles idempotently (`status: "duplicate"`, tested).
  Not a data-loss or corruption risk in either direction.
- Recommend shipping the Stop-time blocking dialog behind a feature flag
  from the start (not as a follow-up), given how safety-critical Stop is: if
  the blocking dialog produces false positives in real use, the flag can
  fall back to banner-only (non-blocking) without a full revert of the
  underlying watermark-truth fix, which should stay regardless.

---

## 17. Proposed step shape

| # | Step | WHAT | Status |
|---|---|---|---|
| 0 | Pre-flight | Baseline current frontend behavior (existing Playwright coverage if any) and confirm test tooling in `Healthcare_next_app`, mirroring Phase 3/4's evidence discipline | Not run as a separate step — superseded by the direct test-tooling confirmation in §18.3 (Vitest, already in use in this repo) |
| 1 | Fix `_autosaveTranscript`'s watermark bug (Finding B) | §10 — read the BFF response body; advance only through confirmed leading segments | **Done — 2026-08-27, §18** |
| 2 | Fix `_persistTranscript` (Finding C) | §10, §12 — same check; make its result inspectable by `stop()`'s caller | **Done — 2026-08-27, §18** |
| 3 | Fix `_hydrateTranscript`'s collision risk (Finding D) | §13 — retry, then fallback/block; regression test from §14.5 | **Done — 2026-08-27, §18** |
| 4 | Build the non-blocking banner | §19.1 (revised from §11/§7.3) — new `TranscriptPersistBanner`/`HydrationUncertainNotice`, not a `FailureBanner` variant | **Done — 2026-08-27, §20** |
| 5 | Build the blocking Stop-time dialog | §19.3 (revised from §12/§7.3) — acknowledged block, built on `src/components/ui/dialog.tsx`, not `ConfirmRemoveDialog`'s pattern; wired into `use-copilot.ts`'s `stop` callback behind a feature flag | **Done — 2026-08-27, §20** |
| 6 | Tests | §14 + §19.8 | 9 new unit tests (191/191 passing) + 3 new Playwright scenarios written, unexecuted — §20.4 |
| Exit | Combined verification against §15's acceptance criteria | Same rigor as Phase 3/4 | AC1–AC7 hold per §20.5; e2e execution and production flag rollout remain open, not code gaps |

---

## 18. Implementation record — Steps 1–3 (2026-08-27)

Implemented on your explicit instruction ("Implement approved Phase 5 Steps
1–3 only"), strictly frontend-only, no backend/BFF/schema/database file
touched, no commit, no push. This section is the record of what was actually
done and verified — §10–§13 above stated the design; this states the result.

### 18.1 Exact files changed

| File | Change |
|---|---|
| `Healthcare_next_app/src/components/narzim/encounter/copilot/real-provider.ts` | Modified — 214 insertions / 34 deletions |
| `Healthcare_next_app/src/components/narzim/encounter/copilot/real-provider.test.ts` | New — 14 tests |

No other file in either repo was modified by this implementation.

### 18.2 What changed, per step

**Step 1 — `_autosaveTranscript()` (Finding B).** Previously advanced
`persistedCount` unconditionally right after `fetch()` resolved, with no
`res.ok` check — the bug you explicitly flagged as critical. Now reads the
BFF's `{persisted, duplicate, sealed, failed}` response body and only
advances the watermark when the **entire batch** reports zero `failed` and
zero `sealed`. The route returns aggregate counts only, not which specific
segment failed, so a partial failure holds the whole batch rather than
guess which lines actually succeeded — safe and cheap, since a resend of an
already-saved segment simply comes back `duplicate` (already idempotent,
already tested server-side). If a batch reports `sealed > 0` (the session
already closed server-side — e.g. the hard-cap sweep, or `stop()` completing
from another tab), the autosave timer is stopped outright, since nothing
further can ever succeed for that session.

**Step 2 — `_persistTranscript()` (Finding C).** Previously had no response
check at all — the Stop-time flush, the single most safety-critical call
site, tracked nothing. Same `res.ok`/counts check added. The method now
returns a `TranscriptPersistOutcome` (`{attempted, confirmed, failed,
sealed}`) instead of `void`, and stores it on the instance, readable via a
new `getTranscriptPersistOutcome()` getter. Scoped deliberately to "make the
result inspectable" (Step 2's own wording) and no further: `stop()`'s
`Promise<void>` signature and the shared `CopilotProvider` interface are
untouched, so no other implementer or caller is affected, and nothing yet
*consumes* the new getter — that wiring is Step 5's job.

**Step 3 — `_hydrateTranscript()` (Finding D).** Previously, any hydrate
failure silently left `persistedCount`/`segSeq` at their fresh-instance
default of 0, so a subsequently recorded segment's array-index-derived
`sequence_number` could collide with an already-persisted pre-reload
segment at the same index — silently discarded server-side as `duplicate`.
Now retries on failure (bounded: 2 retries at 1,500ms, mirroring
`_rotateSocket`'s existing retry precedent in this same file) before giving
up. If still unresolved after retries, a new `hydrationUncertain` flag is
set (readable via `isTranscriptHydrationUncertain()`) instead of silently
assuming "confirmed empty." `_autosaveTranscript()` and `_persistTranscript()`
both check this flag first and refuse to send anything while it is true —
closing the collision path at its root: no new segment is ever sent with a
`sequence_number` derived from an unverified watermark.

### 18.3 Newly discovered during implementation: `_syncTranscript()` data-loss risk, and its guard

Not anticipated by the v2.0 checklist. `_syncTranscript()` performs a full
reconcile against the backend — it **deletes** any already-persisted row not
present in the exact segment set it sends. If `_hydrateTranscript()` never
resolved, `finalSegments` holds only post-reload content (nothing was ever
replayed from the server), so calling `_syncTranscript()` in that state would
have told the backend "this is the complete, correct transcript" and caused
it to **delete every pre-reload segment the server actually has** — a
data-loss failure mode worse than the duplicate-discard bug Finding D
originally described. `_syncTranscript()`'s guard clause now also checks
`hydrationUncertain` and refuses to run while it is true, for exactly the
same reason `_autosaveTranscript`/`_persistTranscript` refuse to send.
Recorded here as a finding surfaced by implementation, not folded silently
into Finding D's original description.

### 18.4 Tests

**New:** `real-provider.test.ts` — 14 unit tests (Vitest, `node` environment,
no DOM/WebSocket/MediaRecorder needed since these call the private
persistence methods directly), covering every item in §14's test plan that
falls within Steps 1–3's scope: non-2xx response, thrown network error,
partial-batch failure, full-batch success, sealed-stops-the-timer, the
hydration gate on both `_autosaveTranscript` and `_persistTranscript`,
hydrate retry-then-exhaustion, hydrate retry-then-success, the
`_syncTranscript` data-loss guard, and the Finding D collision regression
test itself (§14.5: after exhausted hydrate retries, a newly recorded
segment is verified to never reach `fetch()` at all). **All 14 pass.**

**Full existing suite:** `npx vitest run` → **182/182 pass** (168
pre-existing + 14 new). Zero regressions.

### 18.5 TypeScript

`npx tsc --noEmit -p tsconfig.json` → **one error, pre-existing and
unrelated**:
```
e2e/encounter-submit.spec.ts(237,53): error TS2345: Argument of type
'string | null' is not assignable to parameter of type
'string | number | boolean'.
```
Verified pre-existing, not introduced by this work: `git stash`'d this
turn's changes and re-ran `tsc --noEmit` — the identical single error
reproduced against the unmodified branch. **Zero new type errors** from
either changed file.

### 18.6 ESLint

`npx eslint src/components/narzim/encounter/copilot/real-provider.ts
src/components/narzim/encounter/copilot/real-provider.test.ts` → **clean, no
output, zero warnings or errors.**

### 18.7 Explicit confirmation — no backend/BFF/schema/database change

- **Backend (`remedisys_healthcare_ai`, Frappe/Python):** zero files
  modified. No DocType JSON, no API method, no migration, no patch.
- **BFF (`Healthcare_next_app/src/app/api/**`):** zero files modified —
  `segments/route.ts`, `sync-transcript/route.ts`, and `active/route.ts` are
  all unchanged from §3.1's "already sufficient" finding, confirmed again by
  simply not touching them.
- **Schema / database:** zero migrations, zero patches, zero writes to
  `marley.local`, `test.marley.local`, or any Frappe Cloud site.
- **Backend gap check (per your explicit instruction to stop and report
  before touching backend code if one were found):** none was found. Every
  fix in Steps 1–3 consumes information the backend and BFF already return;
  none required a new field, a new endpoint, or a changed response shape.

### 18.8 Git status at the end of this implementation turn

`Healthcare_next_app`:
```
 M src/components/narzim/encounter/copilot/real-provider.ts
?? src/components/narzim/encounter/copilot/real-provider.test.ts
```
`remedisys_healthcare_ai` (this repo): unchanged from before this
implementation turn — only this checklist file itself changes as part of
recording the above.

Nothing staged, nothing committed, nothing pushed, in either repo.

---

---

## 19. Steps 4–5 UX safety review (2026-08-27, read-only — no code changed)

Requested before implementing Steps 4–5: a read-only UX/integration review of
the proposed physician-facing design (§7.3, §11, §12, §15) against the
existing `FailureBanner`, `ConfirmRemoveDialog`, `use-copilot.ts`,
`encounter-flow.tsx`, and the Stop call chain — verified directly, not
re-asserted from v2.0's design. This section records the findings and the
resulting design revision. **Nothing in Steps 1–3's implementation changed.**

### 19.1 Mid-recording banner — revised

- **Debounce, not immediate.** Show the `retrying` banner only after **2
  consecutive** autosave cycles report `failed > 0` (~40s), not the first —
  a single transient blip (the common case) should stay silent, matching
  `_syncTranscript`'s own incident history. Silence never claims success, so
  this does not weaken "never show saved falsely."
- **`sealed` is immediate and distinct, not a variant of `retrying`.** No
  debounce, no "Retry" action (retrying a sealed session is provably
  futile), different copy ("this recording can no longer be saved — stop
  and start a new recording").
- **New finding: `sealed` mid-recording is more dangerous than the original
  design treated it.** Step 1 (already implemented) correctly stops the
  autosave timer on a fully-sealed batch, but nothing stops **capture** —
  mic, WebSocket, and the "Listening" UI all continue normally. A physician
  can keep talking into a session that can never save another word, with
  only a banner (easy to miss) as the signal. Step 4 must give this a
  distinctly serious treatment, not fold it into the same banner as a
  transient failure.
- **`FailureBanner`'s existing `kind="ai"` must not be reused for this.** It
  already means "connection dropped entirely" (`provider.onError`) — a
  different failure class from "connected fine, persistence is lagging."
  Conflating them removes a distinction physicians need. Build a sibling
  variant, not a new `kind` value on the existing lookup.
- **Push, not poll.** `getTranscriptPersistOutcome()` (Step 2) is pull-only.
  Step 4 should add a subscription (e.g. `onPersistStatus`, mirroring the
  existing `onTranscript`/`onSuggestions`/`onError` pattern in `provider.ts`)
  rather than a new polling timer.
- **Accessibility gap in the reused pattern:** `FailureBanner` has no `role`
  or `aria-live` today — needs `role="status" aria-live="polite"` so a
  screen-reader user is told about a state change without recording being
  interrupted.
- **i18n gap in the reused pattern:** `FailureBanner` and `ConsentGate`
  (`recording-ui.tsx`) are fully hardcoded English strings today — verified
  directly, not assumed. This is a pre-existing Frontend Rule 10 violation.
  **New Step 4 copy must use `useTranslations`; it must not copy this
  file's existing non-compliant pattern.** Optionally, since Step 4 already
  touches this file, migrating the two existing strings at the same time is
  a low-cost cleanup worth offering — not mandatory to Step 4's scope.

### 19.2 Stop-time behavior — verified safe, with one important correction

- **Verified, not just asserted: `stop_session`, transcript build, and
  suggestion fetch are not blocked by the dialog.** Traced directly —
  `RealCopilotProvider.stop()` runs flush → close socket →
  `_persistTranscript()` → `_syncTranscript()` → `stop_session` →
  transcript build → `Promise.allSettled([...suggestion halves])` all
  **inside its own promise**, before `use-copilot.ts`'s `stop()` callback
  ever inspects the outcome. A dialog gated on that outcome sits strictly
  after every clinical/AI action `stop()` performs — it cannot block them.
- **Verified, not just assumed: the encounter's own Save/Sign flow never
  reads copilot state.** `grep -rn "copilot\.state\|rec\.state"
  encounter-screen.tsx` (excluding SOAP/suggestion lines) returns zero
  matches. Gating `state === "ended"` only affects `generateSoap()`'s guard
  and `CopilotPanel.tsx`'s `isEnded`-driven review sections — never
  charting, saving, or signing.
- **New finding: there is no automatic retry after Stop.** `stop()` clears
  `autosaveTimer` before `_persistTranscript()` even runs, and
  `_persistTranscript()` is a one-shot attempt. "Still retrying" is not a
  real state Stop can observe — the one attempt has already finished by the
  time any dialog would show. The dialog's "Retry saving" action must
  explicitly re-invoke `_persistTranscript()`, not wait for a tick that will
  never come.
- **`failed` vs. `sealed` at Stop must render differently**, matching
  §19.1's mid-recording distinction: `failed` offers "Retry saving";
  `sealed` does not (nothing to retry), and states plainly the content
  cannot be recovered into this session.

### 19.3 The core UX safety question — disagreement with the original proposal, and the recommended alternative

**Disagreement, stated explicitly:** v2.0 §12's "requires an explicit
acknowledgment action before the state machine is allowed to advance," read
as *only a successful retry counts as acknowledgment* (an unconditional hard
block), is **not** the safest production design. Given §19.2's finding that
there is no background retry after Stop, an unconditional block has no
guaranteed resolution — a physician facing a genuine outage (clinic-wide
Wi-Fi down, a backend incident) would be stuck with no way to finish that
encounter and move to the next patient. That risk is worse than the
disclosed, recoverable transcript gap Phase 5 exists to make visible.

**Recommended design: an *acknowledged block*, not an unconditional hard
block.**
- Modal, focus-trapped, not casually dismissible (no accidental
  backdrop-click or Escape "cancel").
- Always offers two actions, visually unequal in weight:
  - **Primary — "Retry saving"**: re-invokes `_persistTranscript()`; on
    success the dialog closes and `state` advances to `"ended"`.
  - **Secondary, clearly de-emphasized — "Continue without confirming"**:
    explicit copy naming the unconfirmed count and stating nothing else
    about the encounter is affected; clicking it is itself the required
    conscious acknowledgment, and forces the state transition. Recommend
    recording this acknowledgment somewhere discoverable (e.g. against the
    session), not just accepting it silently.
  - For `sealed`, omit "Retry saving" entirely (§19.2) — only "Continue,"
    with copy explaining why retrying cannot help.
- This preserves every original invariant (never show a false "saved,"
  blocking, explicit acknowledgment required) while removing the one
  failure mode — an un-escapable modal during a real outage — that an
  unconditional hard block would introduce.

This revises §12's proposed shape; §12 itself is left as originally written
(with a pointer to this section) so the record of what was first proposed
is preserved, per this repo's documentation conventions.

### 19.4 Hydration uncertainty — a real, currently-open gap

- **Confirmed: nothing surfaces `hydrationUncertain` today.** Steps 1–3 were
  deliberately logic-only. A physician whose resume/reload hydration failed
  continues recording with zero visible indication — the exact
  "unknowingly continue into an unverified state" risk this review was
  asked to check for. Not yet closed; this is Step 4/5's job.
- **New finding: hydration has no periodic retry, unlike autosave.** It
  runs once at `start()` (with 2 bounded retries) and never again for that
  provider instance's lifetime — `ensureProvider()` memoizes the instance,
  and `finalSegments` is never cleared by `stop()`, so a same-page
  Stop-then-Start does not re-trigger it. **Step 5 needs a new, explicit,
  physician-triggered "retry verification" action** (`_hydrateTranscript`
  is currently private) — there is no other recovery path today.
- **Recommended treatment:** more prominent than the mid-recording banner,
  not less — this fails once and stays failed, where an autosave blip
  usually self-heals. Show a blocking-inline notice (reusing `ConsentGate`'s
  existing pattern of replacing the recording UI region, not a modal) the
  moment `start()` resolves with `isTranscriptHydrationUncertain() ===
  true`, offering "Try again" or an explicit "Record anyway — the previous
  transcript for this session could not be verified," with the latter
  staying visibly flagged for the rest of that recording session.
- Confirmed safe to block *starting capture* here (unlike Stop): Rule 7
  protects the encounter form, not the AI copilot itself (its own text:
  "AI sidebar shows a clear 'AI unavailable' state — no JS errors block
  Encounter save") — verified via §19.2's grep that Save/Sign never depends
  on copilot state.

### 19.5 State machine — dangerous transitions identified

1. **`sealed` while `CopilotSessionState` stays `"recording"`** — the state
   machine has no representation for "capturing, but nothing further can
   ever save." The single most important gap this review found (§19.1).
2. **A stale "unconfirmed" dialog outliving its own truth** — checked, not
   reachable: `_persistTranscript()`/`_syncTranscript()` fully resolve
   before the Stop-time check runs (§19.2), so a late-arriving success
   cannot race a dialog already showing a failure.
3. **Resuming recording while the Stop dialog is open** — checked, not
   currently possible: `RecordingControls.tsx` hides all controls while
   `state === "processing"`, and no "un-stop" affordance exists anywhere in
   the traced call chain. Step 5 must not introduce one, including via a
   dialog "Cancel"/close action.
4. **Two warnings stacking** — the mid-recording banner must hide once
   `state` leaves `"recording"`/`"paused"`, so it cannot render
   simultaneously with the Stop-time dialog. Not guaranteed by any existing
   code; must be an explicit condition in Step 4/5's implementation.

### 19.6 Feature flag — recommendation only, not added

- **Step 4 (banner): no flag.** Purely additive, non-blocking, low blast
  radius — ship directly.
- **Step 5 (Stop dialog): yes, a flag.** Changes a previously-instantaneous,
  safety-critical flow. Matches CLAUDE.md's "feature flags default OFF in
  production, enabled per-environment → per-clinic → globally" convention.
- **Where it should live: a frontend-only environment variable** (e.g.
  `NEXT_PUBLIC_COPILOT_STOP_CONFIRMATION_ENABLED`), read in
  `use-copilot.ts`'s `stop()` callback — **not** a new `AI Settings` backend
  field, which would be a schema change outside this phase's agreed
  frontend-only scope (§7.1/§7.2) and would require the "stop and report"
  step before touching backend code.
- **Safest default: OFF.** With the flag off, Step 4's banner still fully
  applies; Stop behaves exactly as it does today. Enable per-environment
  after a bake-in period once the acknowledged-block design (§19.3) is
  confirmed not to produce false positives.
- Not added this turn, per instruction — recorded here for Step 5's
  implementation to pick up.

### 19.7 Accessibility and i18n — findings

- **`ConfirmRemoveDialog` (`patient-chart/dialogs.tsx`) is not an accessible
  dialog** — verified directly: a hand-rolled `createPortal` div with no
  `role="dialog"`, no `aria-modal`, no focus trap, no initial-focus
  management, no Escape handling, no focus return on close. Acceptable for
  a lower-stakes "delete this contact?" confirm; not an acceptable
  foundation for a new safety-critical dialog.
- **A better foundation already exists and was not in the original
  proposal:** `src/components/ui/dialog.tsx`, built on
  `@base-ui/react/dialog` — provides focus trapping, `role="dialog"`/
  `aria-modal`, Escape handling, focus return, and `DialogTitle`'s
  auto-`aria-labelledby` out of the box. **Recommendation: build Step 5's
  dialog on this primitive**, styled to visually match
  `ConfirmRemoveDialog`'s layout (icon + title + description + footer
  actions — the actual reusable *pattern*), rather than reusing
  `ConfirmRemoveDialog`'s implementation. Escape must be intercepted so it
  cannot silently resolve to "continue" — it should do nothing, or map
  explicitly to the same secondary action, never a hidden third path.
- **`FailureBanner` needs `role="status" aria-live="polite"`** (§19.1) — has
  neither today.
- **All new Step 4/5 copy must go through `useTranslations`** — confirmed
  the two existing components proposed for reuse do not (§19.1) — this must
  not be inherited into new code.

### 19.8 Testing — scenarios for Steps 4–5 (in addition to §14)

**Unit:** debounce logic (1 failed tick → no signal; 2 consecutive → exactly
one signal); `sealed` fires its distinct signal immediately, no debounce;
Stop-time `confirmed:false` withholds `state:"ended"`; `confirmed:true`
allows it; "Retry saving" re-invokes `_persistTranscript()` and unblocks on
success; "Continue anyway" forces the transition and (if implemented)
records the acknowledgment; `sealed`-at-Stop never offers a retry action;
hydration "retry verification" clears `hydrationUncertain` on success.

**Playwright:** 2 consecutive failed autosaves → banner appears, recording
uninterrupted, "Retry now" doesn't pause capture; `sealed` mid-recording →
distinct banner, no retry button; failing persist at Stop → dialog renders,
focus trapped, Tab cycles inside it, Escape does not silently dismiss;
"Retry saving" then success → dialog closes, review UI becomes available;
"Continue without confirming" → reaches "ended" despite the gap;
hydration-uncertain on resume → blocking-inline notice before active
recording, both recovery paths verified; flag off → Stop behaves exactly as
today even with a simulated failure; full keyboard-only pass through the
dialog; accessibility scan (axe-core or equivalent) on both the banner and
the dialog.

### 19.9 Recommendation summary

**Agree with:** the truth-level watermark logic (implemented, Steps 1–3),
never showing a false "saved," reusing existing patterns over inventing new
ones, and requiring explicit acknowledgment when persistence is unconfirmed.

**Disagree with, specifically:** an unconditional hard-blocking Stop dialog
with no way to proceed short of a successful retry (§19.3) — given §19.2's
finding that Stop has no background retry, this risks blocking a
physician's ability to finish an encounter during a genuine outage, which is
a worse outcome than the disclosed gap Phase 5 exists to surface.

**Recommended instead:** an acknowledged block (§19.3) — modal,
focus-trapped, always offering both "Retry saving" and an explicit,
de-emphasized "Continue without confirming" — plus the `sealed`-mid-recording
severity fix (§19.1), the hydration-uncertain surfacing and manual retry
path (§19.4), the accessible-dialog-primitive correction (§19.7), and the
i18n/aria gaps in the components originally proposed for reuse (§19.1,
§19.7). None of this has been implemented. Awaiting approval before Step 4/5
work begins.

---

## 20. Implementation record — Steps 4–5 (2026-08-27)

Implemented on your explicit approval of §19's acknowledged-block design
("Yes, go with the acknowledged-block design — implement Steps 4–5"),
strictly frontend-only, no backend/BFF/schema/database file touched, no
commit, no push. Builds directly on Steps 1–3 (§18) — the watermark-truth
logic and the `hydrationUncertain` gate were not modified.

### 20.1 Exact files changed

| File | Change |
|---|---|
| `copilot/types.ts` | New `TranscriptPersistOutcome`, `PersistBannerStatus` types (moved here from being local to `real-provider.ts`, so `provider.ts` and `use-copilot.ts` can share them) |
| `copilot/provider.ts` | `CopilotProvider` interface extended: `getTranscriptPersistOutcome`, `isTranscriptHydrationUncertain`, `onPersistStatus`, `onHydrationUncertain`, `retryAutosaveNow`, `retryHydration`, `retryTranscriptPersist` — confirmed `RealCopilotProvider` is the interface's only implementer before extending it |
| `copilot/real-provider.ts` | Debounced persist-status tracking (§19.1: 2 consecutive failures → `"retrying"`; any `sealed` → immediate `"sealed"` + timer stopped; success → `"healthy"`), pushed via `onPersistStatus`; `hydrationUncertain` changes now pushed via `onHydrationUncertain`; three thin retry-wrapper methods |
| `copilot/use-copilot.ts` | New state (`persistStatus`, `hydrationUncertain`/`hydrationAcknowledged`/`hydrationRetrying`, `stopConfirmation`), subscriptions wired in `ensureProvider()`, `stop()` rewritten to implement the acknowledged block behind the feature flag, new action callbacks |
| `v3/use-recording.ts` | Passthrough of all new fields/actions, matching its existing style |
| `v3/recording-ui.tsx` | New: `TranscriptPersistBanner`, `HydrationUncertainNotice`, `HydrationUncertainFlag`, `StopUnconfirmedDialog` |
| `v3/encounter-flow.tsx` | Banner/notice rendered gated on `state === "recording" \|\| "paused"` (§19.5 point 4); dialog rendered at the component's top level, outside the `step === "capture"` block, so switching steps cannot sidestep it |
| `src/lib/feature-flags.ts` | New `FEATURE_COPILOT_STOP_CONFIRMATION`, following this repo's existing flag convention exactly (see §20.3) |
| `.env.example` | New flag documented — not tracked by git in this repo (`.env*` is gitignored by design here; pre-existing, unrelated to this work) |
| `messages/en.json`, `messages/es.json` | New `encounter.copilot.persistBanner` / `.stopConfirm` / `.hydrationUncertain` keys, both locales |
| `copilot/real-provider.test.ts` | +9 unit tests |
| `e2e/copilot-phase5-persistence.spec.ts` | New — 3 Playwright scenarios |

No backend, BFF route, DocType, migration, or database file touched.

### 20.2 Step 4 — mid-recording banner, as built

- `TranscriptPersistBanner` (new component, not a `FailureBanner` variant —
  per §19.1's finding that `kind="ai"` already means something different):
  renders only for `"retrying"`/`"sealed"`; `role="status" aria-live="polite"`
  so it announces without interrupting.
- Debounce implemented exactly per §19.1: `_registerAutosaveFailure()`
  increments `consecutiveAutosaveFailures`; only the 2nd consecutive failure
  (or later) escalates to `"retrying"`. A single blip stays silent
  (`console.warn` only, from Steps 1–3).
- `sealed` fires immediately, no debounce, and also stops the autosave timer
  (Steps 1–3 behavior, unchanged) — the banner offers no retry action for it,
  matching §19.1's "retrying it is provably futile" finding.
- `HydrationUncertainNotice`/`HydrationUncertainFlag`: shown immediately
  (no debounce — hydration has no periodic retry, §19.4) whenever
  `hydrationUncertain` is true; collapses to a small persistent flag once the
  physician clicks "Record anyway", tracked by `hydrationAcknowledged` and
  reset only when a fresh uncertain episode begins.
- "Retry now" (banner) and "Try again" (notice) both call thin provider
  wrappers (`retryAutosaveNow`/`retryHydration`) that touch only
  `fetch()`/bookkeeping — never the recorder, socket, or mic — confirmed by
  reading the implementation, not assumed.
- i18n: all new copy goes through `useTranslations("encounter.copilot...")`;
  none of it copies `FailureBanner`/`ConsentGate`'s pre-existing hardcoded-
  string pattern (§19.1's flagged gap) — those two components were left as
  found, not retrofitted, since that cleanup was offered as optional, not
  required, in §19.1.

### 20.3 Step 5 — Stop-time acknowledged block, as built

- `stop()` (in `use-copilot.ts`) now reads
  `provider.getTranscriptPersistOutcome()` after `provider.stop()` resolves.
  If `FEATURE_COPILOT_STOP_CONFIRMATION` is off, or the outcome is
  `confirmed`, behavior is byte-for-byte what it always was — straight to
  `"ended"`.
- If on and unconfirmed: `state` holds at `"processing"` (already hides all
  recording controls, per `RecordingControls.tsx`) and `stopConfirmation` is
  set, rendering `StopUnconfirmedDialog`.
- **Acknowledged block, not a hard block (§19.3), built as designed:** the
  dialog always offers "Continue without confirming" (`Button variant="ghost"`
  — visually de-emphasized, never the default-focused action) alongside
  "Retry saving" (`Button` default variant) — omitted only when
  `sealed > 0 && failed === 0` (nothing left to retry). "Retry saving" calls
  `retryTranscriptPersist()`, which re-invokes `_persistTranscript()`
  directly — confirmed necessary because Stop's autosave timer is already
  cleared before the flush runs, so nothing would retry this on its own
  (§19.2's finding).
- **Accessibility (§19.7), a real correction from the original v2.0
  proposal:** built on `src/components/ui/dialog.tsx`'s Base UI primitive,
  not `ConfirmRemoveDialog`'s hand-rolled pattern — real focus trap
  (`modal` default), `role="dialog"`/`aria-modal`, `DialogTitle`'s
  auto-`aria-labelledby`. Dismissal via outside-click/Escape is deliberately
  disabled (`onOpenChange={() => {}}`, `disablePointerDismissal`, and
  `showCloseButton={false}`) so the only way through is one of the two
  explicit buttons — never a hidden third path that would count as neither
  retry nor acknowledgment.
- **Feature flag (§19.6), landed exactly as recommended:** `false`/unset by
  default. Discovered mid-implementation that this repo already has an
  established convention for this
  (`src/lib/feature-flags.ts` — `NEXT_PUBLIC_FEATURE_<AREA>` env var,
  `FEATURE_<AREA>` export, an `enabled()` helper requiring the exact string
  `"true"`, documented "read at the boundary, never inline") — an initial
  inline `process.env` read was corrected to follow it once found, rather
  than inventing a second pattern.
- **Verified, not just carried forward from §19.2's read-only claim:** the
  full 191-test Vitest suite plus a direct `grep` still show
  `encounter-screen.tsx` never references copilot/`rec` state, and
  `RealCopilotProvider.stop()`'s internal sequence (flush → persist → sync →
  `stop_session` → transcript → suggestions) is unchanged — the acknowledged
  block sits strictly after all of it.
- **Best-effort acknowledgment note, not a durable audit record:** clicking
  "Continue without confirming" logs `console.warn` with the failed/sealed
  counts (no PHI, Rule 10) — explicitly NOT the durable, queryable record
  §19.3 recommended, since that would need a new backend field, out of this
  phase's frontend-only scope. Flagged here as a residual item for a future
  phase, not silently dropped.

### 20.4 Tests

**New unit tests (Vitest, extending `real-provider.test.ts`):** 9 tests —
persist-status debounce (silent on 1 failure, `"retrying"` on the 2nd,
no re-fire on a 3rd), `sealed` firing immediately and stopping the timer,
`"healthy"` firing on recovery, unsubscribe correctness,
`onHydrationUncertain` firing true after exhausted retries and false on a
later successful retry, no-refire-on-unchanged-value, and the three retry
wrapper methods. **Full suite: 191/191 pass** (182 from Steps 1–3 + 9 new).

**New Playwright spec (`e2e/copilot-phase5-persistence.spec.ts`), modeled
directly on the existing `copilot-rule7.spec.ts` precedent (fake media
devices, routed `/api/ai/session` + `page.routeWebSocket()`, no real
backend/Deepgram):**
1. 2 consecutive failed `/api/ai/session/segments` responses show the
   retrying banner (1 alone does not); recording stays visibly "Listening"
   throughout; "Retry now" doesn't interrupt it; the banner clears once a
   manual retry confirms.
2. A `sealed` response shows the sealed banner immediately, with no retry
   button, while recording continues.
3. A guaranteed-unconfirmed Stop shows the dialog; Escape does not dismiss
   it; "Continue without confirming" reaches "Ended". Self-skips unless the
   dev server was started with the flag on (build-time-inlined, cannot be
   toggled per-test the way the route mocks are).

**Not executed by this implementation** — no live `npm run dev` + backend
was available in this session. Written to the same standard as the existing
suite so they can be run directly (`npx playwright test
e2e/copilot-phase5-persistence.spec.ts`) once one is. This is an honest gap,
not claimed as passing.

### 20.5 Verification

- **TypeScript:** `npx tsc --noEmit` clean — only the same pre-existing,
  unrelated `e2e/encounter-submit.spec.ts` error already isolated in §18.5.
- **ESLint:** zero issues on every file touched, verified individually and
  by grepping a whole-project `eslint .` run's 414 pre-existing issues for
  these paths (no matches) — none of that pre-existing debt is this work's.
- **i18n parity:** `npm run i18n:check` passes — 5931 keys, en/es aligned.
- **Acceptance criteria (§15), reassessed:** AC1–AC2 held already from Steps
  1–3 and are now also visibly surfaced (AC2's UI half). AC3 (blocking at
  Stop) is met by the acknowledged-block design, a deliberate, approved
  revision of AC3's original unconditional-block wording — see §19.3 for why.
  AC4–AC7 unaffected, still holding. The one open item is operational, not a
  code gap: e2e execution and a bake-in period before the Step 5 flag is
  enabled anywhere.

### 20.6 Explicit confirmation — no backend/BFF/schema/database change

Identical disposition to §18.7: zero Frappe files, zero BFF route files,
zero migrations, zero database writes. Verified by `git status` in the
backend repo showing no change from before this turn.

### 20.7 Git status at the end of this implementation turn

`Healthcare_next_app`:
```
 M src/components/narzim/encounter/copilot/provider.ts
 M src/components/narzim/encounter/copilot/real-provider.ts
 M src/components/narzim/encounter/copilot/types.ts
 M src/components/narzim/encounter/copilot/use-copilot.ts
 M src/components/narzim/encounter/v3/encounter-flow.tsx
 M src/components/narzim/encounter/v3/recording-ui.tsx
 M src/components/narzim/encounter/v3/use-recording.ts
 M src/lib/feature-flags.ts
 M messages/en.json
 M messages/es.json
?? e2e/copilot-phase5-persistence.spec.ts
?? src/components/narzim/encounter/copilot/real-provider.test.ts
```
`remedisys_healthcare_ai` (this repo): unchanged except this checklist file.
Nothing staged, committed, or pushed in either repo.

---

## 21. Step 6 — Playwright execution attempts (2026-08-27, factual record only)

Two execution attempts against a live `marley.local` backend + a freshly
started, flag-enabled `Healthcare_next_app` dev server (port 3001). Neither
reached Phase 5's actual UI code (banner/dialog/hydration notice) — both
stopped at the shared login/fixture helper every one of these Copilot e2e
specs uses, including the pre-existing, unmodified `copilot-rule7.spec.ts`.
**Phase 5 is not classified as failed** — its code has not yet been
exercised by any test run.

### 21.1 Attempt 1 — stale practitioner fixture (401)

`e2e/copilot-phase5-persistence.spec.ts` (as committed) and
`copilot-rule7.spec.ts` both hardcode `luis.gomez@narzim.com` /
`Admin@123`. Reproduced directly against both the app's `/api/auth/login`
and Frappe's own `/api/method/login`: `401 Invalid credentials` /
`AuthenticationError`. Read-only investigation checked every account
documented in `docs/access/SEED_USERS.md` (9 accounts, two credential
sets) against the live `marley.local` site — **all 9 also returned 401**.
Root cause: that doc's seed script targets a site named
`remedisys.localhost`; the site actually running is `marley.local`
(`sites/currentsite.txt`) — a naming mismatch, not a wrong assumption in
the doc itself. **Classification: environment/setup issue** (stale
fixture/doc, not a Phase 5 or test-authoring defect).

### 21.2 Credential resolution — dedicated E2E test account, password reset

Per explicit authorization, all pre-change checks passed (account exists,
holds `EB_Practitioner`, enabled, `.test`-domain/"E2E Support"-named with
no linked clinical Practitioner record, `marley.local` confirmed
non-production) before a temporary password was set on
`e2e_support@remedisys.test` — the only field changed, verified identical
on every other field before/after. The credential was passed to Playwright
via an ephemeral env var (spec files temporarily read
`process.env.E2E_PRACTITIONER_EMAIL`/`PASSWORD` with their original
literal as fallback, then were reverted — `git diff` confirms zero net
change to both files). The password was never written to disk or printed,
and was reset again to a fresh, unrecorded value immediately after the run.

### 21.3 Attempt 2 — authentication succeeded; a deeper, distinct fixture gap found (400)

With the dedicated E2E credential, login succeeded (`HTTP 200` from
`/api/auth/login`, confirmed also via `/api/method/eb_frappe_jwt.api.get_token`).
**4 run, 0 passed, 4 failed, 0 skipped, ~2.3s** — all four now fail one
step later, at the shared `POST /api/encounters` fixture call, with an
identical error reproduced directly:
```
{"error":"Select the practitioner who will see this patient."}  HTTP 400
```
Traced to `remedisys_healthcare_ai/api/v1/encounters/api.py::create_encounter`
(~line 1139): the caller has the `EB_Practitioner` **role** but no linked
`Healthcare Practitioner` **document** — confirmed via the pre-change
read-only account check (`linked_healthcare_practitioner: null`). No
Playwright scenario reached Phase 5's UI. No browser console/runtime
errors were captured (no page ever loaded). **Classification:
environment/setup issue** — a fixture-linkage gap, not a Phase 5 defect;
the identical failure hits the unmodified `copilot-rule7.spec.ts` at the
same line.

### 21.4 What would unblock this

A practitioner test account needs both the `EB_Practitioner` role **and**
a linked `Healthcare Practitioner` document (or an explicit `practitioner`
argument passed at encounter-creation time). Linking one to
`e2e_support@remedisys.test` was not attempted — it is a further data
change beyond this turn's specific authorization (a password reset only)
and needs its own explicit go-ahead.

### 21.5 A subsequent, valid credential unblocked full execution

Using `admin@narzim.com` (a generic "Healthcare Admin" utility identity, not
a named clinician, already linked to an active Healthcare Practitioner
record — you supplied this credential directly, no reset performed) plus
two further, genuine test-fixture fixes (a stale V1 UI locator in both spec
files, since the actually-served page is the V3 flow's inline consent gate,
not V1's pill-based `CopilotHost`/`CopilotPanel`; and an incomplete
WebSocket mock that never sent any simulated Deepgram transcript), the full
suite finally executed against real UI code. This is recorded in full
below (§22) alongside the genuine implementation defect that execution
then surfaced and fixed.

---

## 22. Retry-saving lifecycle fix, and Phase 5 Exit Verification (2026-08-27)

### 22.1 The defect Step 6 execution found

Once the suite actually reached Phase 5's Stop-time dialog, a genuine
implementation defect surfaced: **"Retry saving" could close the dialog
without ever making a server request.**

**Root cause.** `RealCopilotProvider.stop()` unconditionally called
`stop_session` and nulled `this.sessionId` at step 3b, regardless of
whether step 3a's persistence flush was confirmed. Once nulled, every
subsequent `_persistTranscript()` call — including via
`retryTranscriptPersist()` — hit its own legitimate "nothing to persist"
guard (`!this.sessionId`, meant for the genuine "nothing was ever
recorded" case) and returned `{confirmed: true}` without sending a
request. A deeper layer beyond that: merely preserving `sessionId` would
not have been sufficient either, because `stop_session` itself transitions
the backend session to `Stopped`, and `append_segment` refuses writes
(`sealed`) once it isn't `Recording` — so a "real" retry after an
unconditional close would always have come back sealed, never able to
genuinely succeed.

**The lifecycle fix.** `stop()` now captures `_persistTranscript()`'s real
outcome and calls the session-close step (extracted into
`_closeBackendSession(closeReason)`) **only if confirmed**. If unconfirmed,
`sessionId` deliberately stays alive — the backend session stays
`Recording` — specifically so `retryTranscriptPersist()` can reach
`append_segment` for real, and it closes the session itself **only once
that retry actually confirms**. A new `finalizeUnconfirmedStop()` closes
the session when the physician explicitly clicks "Continue without
confirming," so an acknowledged-but-unconfirmed stop still closes out
(Phase 4's promise) without ever representing that as confirmed
persistence. `_finalizeAfterProviderFailure()` (the WS-drop path — no
dialog exists there) keeps closing unconditionally, unchanged. In
`use-copilot.ts`, the feature-flag-off path now calls
`finalizeUnconfirmedStop()` immediately on an unconfirmed outcome — the
flag-off equivalent of an instant "Continue without confirming," so "flag
off = exactly today's behavior" holds from the physician's point of view
while the session still never lingers open. If the physician abandons the
tab mid-dialog (neither retries-to-success nor clicks Continue), the
session stays `Recording` until Phase 4's existing orphan-sweep hard-cap
reclaims it — the same backstop already covering any other abandoned
session, not a new gap, and bounded rather than indefinite. **No
backend/schema change was needed or made** — the fix is entirely about
*when* the frontend calls the existing `/api/ai/session/stop` endpoint.

**Files changed:** `real-provider.ts` (extracted `_closeBackendSession`;
`stop()` gates it on confirmed outcome; `retryTranscriptPersist()` now
performs a real attempt and closes only on success; new
`finalizeUnconfirmedStop()`); `provider.ts` (interface: added
`finalizeUnconfirmedStop()`); `use-copilot.ts` (flag-off path and
`acknowledgeStopUnconfirmed()` both now call `finalizeUnconfirmedStop()`);
`real-provider.test.ts` (+7 unit tests, direct calls to the real `stop()`/
`retryTranscriptPersist()`/`finalizeUnconfirmedStop()`, not simulated
state); `e2e/copilot-phase5-persistence.spec.ts` (2 existing Stop/retry
tests strengthened with explicit `/segments` and `/session/stop` call
counters proving the exact request sequence, not just the resulting UI
state — the test that originally exposed the bug now passes genuinely).

### 22.2 Formal Exit Verification (2026-08-27, this record)

Re-run fresh, in full, as the closing verification pass — not carried
forward from the fix turn's own results:

| Check | Result |
|---|---|
| Full Vitest suite | **198/198 pass** |
| Full Phase 5 Playwright suite | **8/8 pass**, ~1.5 min |
| `copilot-rule7.spec.ts` regression | **1/1 pass** |
| Combined run (both spec files together) | **9/9 pass**, 1.6 min |
| Retry saving makes a real persistence request | Confirmed — explicit `/segments` call-count assertions (unit + Playwright), both before and after the retry click |
| Failed retry keeps the dialog open | Confirmed — the exact test that originally exposed the bug (`Retry saving failing again...`) now passes genuinely |
| No false `confirmed: true` path remains | Confirmed structurally — `sessionId` is only ever nulled after a confirmed outcome or an explicit acknowledgment, never preemptively; regression-tested directly |
| Hydration recovery | Confirmed — notice appears after exhausted retries, "Try again" clears it, recording never interrupted |
| Sealed behavior | Confirmed — immediate (no debounce), no retry offered, never treated as confirmed, session never closed from a sealed-only outcome |
| Continue without confirming | Confirmed — settles explicitly, closes the backend session as an acknowledgment, never represented as confirmed persistence |
| Escape/backdrop cannot silently dismiss the dialog | Confirmed — both dedicated tests pass; dialog remains fully functional afterward |
| Browser console/runtime errors | None unexpected — the one logged warning during this run was the hydration test's own scripted failure, correctly surfaced by design |
| Backend/schema/database changes | **Zero** — confirmed via `git status` in the backend repo before and after, unchanged from the start of this phase |

### 22.3 Acceptance criteria (§15), final disposition

- **AC1** (watermark never advances past unconfirmed): **Met** — Steps 1–3.
- **AC2** (non-blocking warning within one autosave cycle): **Met** — Step 4.
- **AC3** (blocking dialog, explicit acknowledgment before "ended"): **Met
  as revised in §19.3** — an *acknowledged* block (always offers a working
  "Continue without confirming" alongside "Retry saving"), not the
  originally-worded unconditional hard block. This was a deliberate,
  reviewed, and approved revision (§19.3), not a shortfall: an
  unconditional block had no guaranteed resolution once discovered that
  Stop has no background retry, and risked leaving a physician unable to
  finish an encounter during a genuine outage.
- **AC4** (resume/reload collision protection): **Met** — Steps 1–3.
- **AC5** (no Phase 3/4 regression; no backend contract change): **Met** —
  zero backend files touched across the entire phase; confirmed repeatedly.
- **AC6** (i18n, no hardcoded strings): **Met** — `npm run i18n:check`
  passed after every catalog change; new components' copy paths verified
  directly.
- **AC7** (Finding A untouched): **Met** — no schema, migration, or
  backfill ran at any point in this phase.

### 22.4 Exit declared

Phase 5 (Steps 1–6, including the Retry-saving lifecycle fix and this
formal exit verification) meets its acceptance criteria and is ready to be
committed as its own change, pending your explicit approval of the staging
list.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.5 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | **Doc status moved from `draft` to `living`** — Phase 5 approved. Added §22: the Retry-saving lifecycle fix found during Step 6 execution (root cause: `stop()` closed the backend session before the caller could see whether persistence was confirmed, so every retry hit a false-success guard; fixed by deferring session-close until persistence is confirmed, an explicit retry confirms, or the physician explicitly acknowledges via "Continue without confirming" — no backend/schema change) and the formal, freshly-re-run Phase 5 Exit Verification: 198/198 Vitest, 8/8 Phase 5 Playwright, 1/1 `copilot-rule7.spec.ts`, 9/9 combined, zero backend/schema/database changes throughout. Recorded AC1–AC7's final disposition, including AC3's approved revision from an unconditional hard block to the acknowledged-block design (§19.3). Phase 5 exit declared |
| 2.4 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §21: factual record of two Step 6 Playwright execution attempts. Attempt 1 failed at login (401) — every account in `docs/access/SEED_USERS.md` confirmed stale against the live `marley.local` site (doc targets a differently-named `remedisys.localhost` site). A dedicated E2E credential (`e2e_support@remedisys.test`, pre-verified as a genuine test account with no linked clinical Practitioner record) had its password reset under explicit authorization, used only ephemerally, then re-reset to an unrecorded value; spec-file env-var overrides used for the run were fully reverted. Attempt 2: authentication succeeded, but all 4 tests then failed one step later at `POST /api/encounters` with `"Select the practitioner who will see this patient."`, traced to the account holding the `EB_Practitioner` role without a linked `Healthcare Practitioner` document. Neither attempt reached Phase 5's UI code — Phase 5 is explicitly not classified as failed. No implementation code, test file, or unrelated data left changed |
| 2.3 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §20: implementation record for Steps 4–5 (approved and executed this turn, on §19's acknowledged-block design, frontend-only). Documents the debounced mid-recording banner (`TranscriptPersistBanner`, `HydrationUncertainNotice`/`Flag`) and the Stop-time acknowledged-block dialog (`StopUnconfirmedDialog`, built on `src/components/ui/dialog.tsx`'s accessible primitive rather than `ConfirmRemoveDialog`'s, gated by the new `FEATURE_COPILOT_STOP_CONFIRMATION` flag which follows this repo's existing `src/lib/feature-flags.ts` convention). Records 9 new unit tests (191/191 passing) and 3 new Playwright scenarios written but not executed (no live dev server/backend this session) — an honest gap, not claimed as passing. Records a corrected implementation detail (an initial inline `process.env` read was replaced with the established flag convention once found) and a residual limitation (the Stop-dialog acknowledgment is logged via `console.warn`, not a durable audit record — would need a backend field, out of scope). Updated §17's step table with per-step status. Clean TypeScript/ESLint/i18n-parity results recorded. No backend/BFF/schema/database file touched |
| 2.2 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §19: read-only UX/integration review for Steps 4–5, requested before implementation. Verified directly (not re-asserted) that Stop's clinical/AI actions and the encounter's Save/Sign flow are unaffected by a Stop-time gate. Found three new gaps: `sealed` mid-recording leaves capture running with only a banner as signal; Stop has no background retry so "still retrying" isn't reachable and "Retry saving" must re-invoke persistence explicitly; hydration-uncertain has no periodic retry and needs a new manual recovery action. **Disagreed with v2.0 §12's unconditional hard-blocking Stop dialog** and recommended an acknowledged-block design instead (always offers a working "Continue without confirming" alongside "Retry saving"), to avoid a physician being unable to finish an encounter during a genuine outage. Identified that `ConfirmRemoveDialog` is not an accessible dialog (no focus trap/ARIA/Escape handling) and recommended building on `src/components/ui/dialog.tsx`'s Base UI primitive instead; identified that `FailureBanner`/`ConsentGate` are hardcoded-English, non-i18n-compliant, and must not be copied forward. Recommended a frontend-only env-var feature flag for Step 5, default OFF, not added yet. Added pointer notes in §11/§12 to this section. No implementation code changed |
| 2.1 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added §18: implementation record for Steps 1–3 (approved and executed this turn, frontend-only). Documents the exact watermark/persistence fixes for Findings B, C, and D; the newly-discovered `_syncTranscript()` data-loss risk found during implementation and its guard; 14 new unit tests plus the full 182/182 passing suite; a pre-existing, unrelated TypeScript error explicitly isolated and confirmed via `git stash`; a clean ESLint run; explicit confirmation of zero backend/BFF/schema/database changes; and the resulting git status. Updated §17's step table with per-step status. No implementation code changed by this revision — documentation only |
| 2.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Resolved all four v1.0 open questions per your explicit decisions (frontend-only scope, backend assumed sufficient and now verified, UX reuses `FailureBanner`/`ConfirmRemoveDialog`, Finding A stays Phase 9). Traced the complete frontend flow including resume/reload and found a third, more severe defect (`_hydrateTranscript`'s sequence-number collision, Finding D) and a wasted-signal finding (BFF `segments/route.ts` already computes `{persisted,duplicate,sealed,failed}`, never read). Added exact root cause, a truth-level (not UI-bolt-on) proposed fix, retry/watermark rules, Stop/Finish behavior, resume/reload behavior, test plan, acceptance criteria, and rollback plan. Verified `FailureBanner` and `ConfirmRemoveDialog` directly by reading their source, not only via subagent report. No code, schema, or data changed |
| 1.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Initial read-only Phase 5 planning pass. Audited current backend and frontend code directly; found `_autosaveTranscript`'s watermark bug beyond what the design doc's prose described. Confirmed Phase 3's Finding A unchanged. Identified four open questions requiring explicit decisions before Step 0. No code, schema, or data changed |
