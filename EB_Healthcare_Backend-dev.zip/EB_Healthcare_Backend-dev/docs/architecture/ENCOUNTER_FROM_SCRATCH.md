# Patient Encounter — Ground-Up Design

**Doc status:** superseded · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-29 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.0

> **SUPERSEDED by [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md).** This was an early
> design that was not built. The screen that shipped is the 3-step flow, and
> it reuses V1's components instead of rebuilding the fields (see
> [ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md)).
> Kept for history only. Do not use it to decide anything.

> **PARTIALLY SUPERSEDED 2026-08-26.** This draft's top-level architecture — a
> single dual-lens screen, and rebuilding the encounter's fields rather than
> reusing V1's — was considered and explicitly **rejected** in
> [ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md)
> in favour of a 3-step flow that renders V1's own components. What actually
> shipped is [`ENCOUNTER_V3.md`](ENCOUNTER_V3.md) (steps 2–3) and
> [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
> (step 1). **Do not cite this document as the target design** — two other
> documents did, and both have been corrected (`STATUS.md`,
> `audit/practitioner/README.md`).
>
> Sections below that describe *behaviour*, not screen architecture —
> §6 Safety validators, §7 Pediatric requirements, §3 Target data model,
> §10 Provenance and audit, §11 Retention and compliance — were **not**
> rejected by ADR-054 and remain open, unimplemented proposals. Read this as a
> `draft` per its status: proposed, not yet agreed, and not a substitute for
> the two documents above on anything they cover.

**Status:** Draft for review · **Date:** 2026-08-20 · **Owner:** engineering
**Evidence base:** [`docs/audit/practitioner/screens/03-encounter-deep-audit.md`](../_archive/audit-screens/practitioner/03-encounter-deep-audit.md)
**Scope:** the complete Patient Encounter — data model, lifecycle, AI contract, safety validators,
pediatric requirements, UX, API surface, and the migration path from what exists today.

> This document specifies the encounter **as it should be**, designed from first principles for a
> pediatric clinic in Mexico, and then maps every part of it onto what already exists. It is not a
> rewrite proposal: roughly 70 % of the target design is already built and correct. The value is in
> naming the other 30 % precisely, and in fixing the parts that are built *wrong* rather than missing.

---

## 0. Contents

1. [Design principles](#1-design-principles)
2. [What we keep, change, add, delete](#2-what-we-keep-change-add-delete)
3. [Target data model — every doctype, every field](#3-target-data-model)
4. [The encounter lifecycle](#4-the-encounter-lifecycle)
5. [The AI contract](#5-the-ai-contract)
6. [Safety validators — the specification](#6-safety-validators)
7. [Pediatric requirements](#7-pediatric-requirements)
8. [UX specification](#8-ux-specification)
9. [API surface](#9-api-surface)
10. [Provenance and audit](#10-provenance-and-audit)
11. [Retention and compliance](#11-retention-and-compliance)
12. [Migration path](#12-migration-path)
13. [Acceptance criteria as user stories](#13-acceptance-criteria)
14. [Explicitly out of scope](#14-explicitly-out-of-scope)
15. [Open decisions](#15-open-decisions)

---

## 1. Design principles

These are the rules the design is derived from. Every later section traces back to one of them.

| # | Principle | Consequence in this design |
|---|---|---|
| **P1** | **The note is the product. Everything else serves it.** | The note gets the screen's primary lane and the first-class data model. AI, transcript and chat are supporting surfaces |
| **P2** | **Nothing is displayed as clinical fact unless it came from the record.** | No synthesised, hashed, seeded or placeholder clinical data may render at any time, in any environment. A missing value renders as "—", never as a plausible one |
| **P3** | **Clinical data lives in queryable fields, not in a JSON blob.** | Chief complaint, HPI, examination, plan and review details become real custom fields. You cannot report on, index, or safely migrate a blob |
| **P4** | **A validator is code. A prompt is not a validator.** | Every safety claim in the UI must be backed by a deterministic function with a unit test. If no validator exists, no claim is displayed |
| **P5** | **AI proposes. The practitioner decides. The system records both, and the difference.** | A verdict (`accepted` / `edited` / `rejected`) is persisted server-side for every proposal, with the before and after values |
| **P6** | **Consent is an act, not a default.** | Recording begins only after an explicit act, once per encounter. The attestation records what actually happened |
| **P7** | **A field that cannot be reviewed must not be written.** | If a field has no input control and no place on the report, no writer — human or AI — may target it |
| **P8** | **Fail loudly, never silently.** | No `.catch(() => {})` on a persistence path. No row silently filtered out of a save. No value silently demoted |
| **P9** | **Pediatrics is the default, not a variant.** | Every threshold, range and dose calculation takes age (and where relevant sex and weight) as a required input |
| **P10** | **Upgrade-safe (Rule 1).** | Custom fields via fixtures, new custom doctypes, hooks and overrides. No core edits, ever |
| **P11** | **The signed record is immutable and amendable.** | `docstatus 1` is final. Corrections go through a linked amendment, never an in-place edit or a void-and-retype |
| **P12** | **Bounded by construction.** | Every retrieval has an explicit limit and an explicit token budget, both enforced in code and logged |

---

## 2. What we keep, change, add, delete

### 2.1 Keep as-is (already correct)

| Component | Why |
|---|---|
| `Patient Encounter` + its 6 child tables as the clinical spine | Core composition, order-layer spawn on submit, `docstatus` as the finality authority |
| `Vital Signs` as a separate submittable document | Correct: vitals are nurse-authored, independently timestamped, and auto-submitted with the encounter |
| `AI Encounter Session` as a separate lifecycle | Correct separation. Do **not** add sign states to it |
| `AI Transcript Segment` append-only, with `speaker_label` + `deepgram_segment_id` | Raw-label provenance already done |
| `AI Encounter Chat Message` with `actions_json` | The verbatim proposal record |
| `AI Encounter Record` captured on submit | The per-visit AI archive |
| Deepgram transport (`real-provider.ts`) | Keepalive, rotation, wake lock, crash-safe flush — leave it alone |
| The 13 read tools and the 6 `remove_*` tools | Bounded, conservative, correct |
| `add_vaccine`'s catalog-match-only discipline | **The template for every other master-touching tool** |
| Deterministic duplicate guards (`_rx_already_present`, `_order_already_present`) | Right approach, right reasoning |
| `book_follow_up` producing a request, not an appointment | Correct division of labour, honest UI copy |
| `_flag_lab_for_review` | The review-flag pattern to generalise |

### 2.2 Change (built, built wrong)

| Component | Change |
|---|---|
| SOAP storage | Blob → **real custom fields** (P3) |
| `_serialize_drug_rx` | Return **every** field the writer accepts. Add a contract test that asserts read ⊇ write |
| `save_draft` | Accept and verify `modified` (optimistic concurrency) |
| Autosave error handling | Surface the server's message; stop after N failures with a blocking banner |
| Rx validation | Inline, before save. Never filter rows out of a payload |
| `set_patient_summary` | Server-side **append/merge**, never overwrite |
| Vital thresholds | Age/sex-aware lookup, not literals |
| Growth chart | Real WHO LMS curves, or no curves |
| `_create_medication_master` | Admin approval queue; no `ignore_permissions` |
| AI session lifecycle | Make `Stopped` reachable; record duration |
| Consent | Explicit act, once per encounter |
| Catalog injection | Bounded, budgeted, logged |
| Summary retrieval | Bounded and budgeted, or an ADR that supersedes Rule 5 |

### 2.3 Add (missing)

| Component | Purpose |
|---|---|
| `AI Suggestion Verdict` (new doctype) | The missing provenance link — proposal, verdict, before/after |
| `Pediatric Vital Range` (new doctype) | Age/sex-banded normal ranges, seeded and versioned |
| `Growth Standard` (new doctype) | WHO LMS coefficients for weight/height/BMI/head circumference |
| `Allergy Cross Reactivity` (new doctype) | Allergen → cross-reactive class |
| Custom fields on `Vital Signs` | `head_circumference`, plus computed percentile/z-score per metric |
| Encounter amendment endpoint | Use core `amended_from` |
| `scheduler_events` | Retention purges that actually run |

### 2.4 Delete

Everything listed as **REMOVE** in the audit's §13. The largest single item is the `patHash`
synthetic-data layer; the rest is orphaned or dead-scaffolding code.

---

## 3. Target data model

Notation for every field: **PURPOSE → WRITER → READER → SOURCE OF TRUTH → CLASS**.
Class: `clinical/legal` · `operational` · `ai-metadata` · `derived`.

### 3.1 `Patient Encounter` — the clinical record

Core fields used unchanged: `patient`, `appointment`, `company`, `encounter_date`,
`encounter_time`, `practitioner`, `medical_department`, `status`, `docstatus`, `amended_from`,
and the six child tables.

Custom fields (all added via `fixtures/custom_field.json`, prefix `custom_`, per Rule 1):

| Field | Type | Purpose → Writer → Reader → Source of truth | Class |
|---|---|---|---|
| `custom_chief_complaint` | Small Text | The visit's reason in one line → `save_draft` from the physician's input or an accepted AI proposal → note, report, list, AI context → **this field** | clinical/legal |
| `custom_hpi` | Text | History of present illness → `save_draft`, **only when the UI renders an input for it** → note, report, AI context → **this field** | clinical/legal |
| `custom_physical_exam` | Text | Examination findings → `save_draft` from a rendered input → note, report → **this field** | clinical/legal |
| `custom_plan_narrative` | Text | Treatment-plan prose, distinct from the order rows → `save_draft` → note, report → **this field** | clinical/legal |
| `custom_review_details` | Text | What was discussed with the family → `save_draft`, AI-drafted at sign, physician-confirmed → note, report, patient handout → **this field** | clinical/legal |
| `custom_encounter_end` | Datetime | Consultation end for duration reporting → `complete_encounter` → reports → **this field** | operational |
| `custom_encounter_done_by` | Link (Practitioner) | Who actually signed (ADR-039) → `complete_encounter` → report attribution → **this field** | clinical/legal |
| `custom_bill_flags_json` | Small Text | Per-order `bill_this` intent (ADR-025) → `save_draft` → `_stamp_billing_optout` → **this field** | operational |
| `custom_vaccine_orders_json` | Small Text | Vaccine orders pending nurse administration (ADR-019/020) → `save_draft` → `_create_encounter_immunizations` → **this field** | operational |

**Why keep two JSON fields?** `bill_flags` and `vaccine_orders` are *operational intent* parallel to
child rows, not clinical narrative. They are never reported on, never searched, and never displayed
as prose. P3 applies to clinical data; these are the two legitimate exceptions, and they are named
so it is obvious which is which.

**`encounter_comment` after migration:** retained, read-only, never written again. It is the
historical home of the five clinical fields above for the 131 existing encounters.

**Fields to hide from the form** (present in core, unused here, all measured at 0 population):
`patient_sex`, `patient_age`, `google_meet_link`, `source`, `referring_practitioner`,
`insurance_policy`, `insurance_coverage`, `insurance_payor`, `coverage_status`, `inpatient_record`,
`inpatient_status`, `emergency_record`, `submit_orders_on_save`, `symptoms_in_print`,
`diagnosis_in_print`, `codification_table`.

### 3.2 Child tables — the contract

The **read serializer must return every field the writer accepts.** This is the single rule that
prevents the audit's DL-1 class of bug, and it gets a contract test.

| Table | Fields we write | Fields core stamps | Read serializer must return |
|---|---|---|---|
| `Drug Prescription` | `medication`, `drug_code`, `drug_name`, `strength`, `strength_uom`, `dosage_form`, `dosage`, **`interval`**, **`interval_uom`**, `period`, `comment` | `medication_request` | **all 11 we write** + `name` + `bill_this` |
| `Lab Prescription` | `lab_test_code`, `lab_test_name`, `lab_test_comment` | `service_request`, `invoiced`, `lab_test_created` | all 3 + `name` + `bill_this` |
| `Procedure Prescription` | `procedure`, `procedure_name`, `date`, `practitioner`, `comments` | `service_request`, `procedure_created` | all 5 + `name` + `bill_this` |
| `Therapy Plan Detail` | `therapy_type`, `no_of_sessions`, `interval` | `service_request` | all 3 + `name` + `bill_this` |
| `Patient Encounter Symptom` | `complaint` | — | `complaint` |
| `Patient Encounter Diagnosis` | `diagnosis` | — | `diagnosis` |

**Test to add:** for each table, assert that the set of keys returned by the serializer is a superset
of the set of keys accepted by `_apply_*`. This single test makes DL-1 unrepeatable.

### 3.3 `Vital Signs` + new custom fields

| Field | Type | Purpose → Writer → Reader → Source of truth | Class |
|---|---|---|---|
| existing 8 numerics | — | unchanged | clinical |
| `vital_signs_note` | Small Text | Observations that are not numbers → **the encounter's vitals note input (currently discards)** → note, report → **this field** | clinical |
| `custom_head_circumference` | Float (cm) | Pediatric growth monitoring → nurse/physician input → growth chart, percentile calc → **this field** | clinical |
| `custom_weight_percentile` | Float | Computed weight-for-age percentile → **`services/growth.py` at save time** → chart, note, AI context → derived from `Growth Standard` | derived |
| `custom_height_percentile` | Float | as above | derived |
| `custom_bmi_percentile` | Float | as above, **only for age ≥ 24 months** | derived |
| `custom_hc_percentile` | Float | as above, **only for age ≤ 36 months** | derived |
| `custom_growth_standard_version` | Data | Which standard produced the percentiles → `services/growth.py` → audit → **this field** | ai-metadata / audit |

**Why store the percentile rather than compute it on read?** Because it is a clinical judgement
recorded at a point in time. If the standard is later corrected, the historical note must still show
what the clinician saw. `custom_growth_standard_version` makes that auditable.

### 3.4 `AI Encounter Session` — corrected lifecycle

Fields unchanged. **The state machine must actually run:**

```
Draft ──consent given──► Recording ──stop/pause-timeout/navigate-away──► Stopped
  │                          │                                              │
  │                          └──provider error──► Failed                     │
  └──abandoned without consent──────────────────────────────────────────► Closed
```

| Field | Fix required |
|---|---|
| `consent_obtained`, `consent_obtained_at` | Written only from a real act (§5.1) |
| `status` | Must reach `Stopped`. Today 137/137 are stuck in `Recording` |
| `ended_at`, `duration_seconds`, `close_reason` | Must be populated. Today all 0 |
| `error_code`, `error_message` | Populate on provider failure |

**Do not add** `SIGNED` or `COMPLETED`. `Patient Encounter.docstatus` is the sole authority on
finality (P11).

**Uniqueness:** add a unique constraint or a `frappe.db.get_value(..., for_update=True)` on
`(encounter, session_user, status in (Draft, Recording))` to close the duplicate-session race
(4 occurrences observed).

### 3.5 `AI Suggestion Verdict` — **new doctype, the missing link**

One row per AI proposal that reached the physician. This is what makes P5 real and what §7 of the
audit found entirely absent.

| Field | Type | Purpose → Writer → Reader → Source of truth | Class |
|---|---|---|---|
| `encounter` | Link | Scope → created with the proposal → provenance report | ai-metadata |
| `patient` | Link | Scope, derived from the encounter server-side | ai-metadata |
| `session` | Link (AI Encounter Session) | Which recording produced it | ai-metadata |
| `chat_message` | Link (AI Encounter Chat Message) | The turn it came from | ai-metadata |
| `suggestion_id` | Data | Client-stable id, for idempotent verdict updates | ai-metadata |
| `target` | Data | Field path, e.g. `orders.rx`, `diagnoses`, `vitals.temp` | ai-metadata |
| `tool_name` | Data | Which of the 36 tools emitted it | ai-metadata |
| `proposed_value_json` | Text | **What the AI proposed**, verbatim | ai-metadata |
| `evidence_json` | Text | The `reasoning` array and the transcript spans cited | ai-metadata |
| `model`, `prompt_version`, `prompt_hash` | Data | Which model/prompt produced it | ai-metadata |
| `verdict` | Select | `pending` / `accepted` / `edited` / `rejected` / `superseded` | **the point of the doctype** |
| `verdict_at` | Datetime | When the physician decided | ai-metadata |
| `verdict_by` | Link (User) | **Who** decided | clinical/legal |
| `final_value_json` | Text | **What was actually in the field at sign time** | ai-metadata |
| `reject_reason` | Small Text | Optional, free text — the highest-value training signal there is | ai-metadata |
| `safety_flags_json` | Text | Which validators fired on this proposal, and their outcome | clinical |

**Writer:** created `pending` by the API when a proposal is returned; updated by an explicit
`record_suggestion_verdict` call from the UI on accept/edit/reject; `final_value_json` stamped by
`complete_encounter`.
**Reader:** the provenance view, the evaluation pipeline, the auditor.
**Source of truth:** for "what did the AI say and what did the doctor do about it" — this doctype.

**Retention:** follows the encounter, not the prompt log. It contains clinical values, so it is
covered by the clinical-record retention period, not the 365-day log period.

### 3.6 `Pediatric Vital Range` — **new doctype**

Replaces the four hardcoded literals. Seeded from a published source, versioned, and editable by a
clinical admin.

| Field | Type | Notes |
|---|---|---|
| `metric` | Select | `temperature` / `heart_rate` / `respiratory_rate` / `spo2` / `bp_systolic` / `bp_diastolic` |
| `age_min_months`, `age_max_months` | Int | Inclusive band |
| `sex` | Select | `Any` / `Male` / `Female` (BP needs sex; HR/RR do not) |
| `height_percentile_band` | Select | `Any` / `p5` / `p50` / `p95` — BP only |
| `normal_low`, `normal_high` | Float | The reference band |
| `alert_low`, `alert_high` | Float | Outside this = flag |
| `critical_low`, `critical_high` | Float | Outside this = escalate |
| `source` | Data | e.g. "PALS 2020", "AAP 2017 BP" — **shown in the UI tooltip** |
| `version`, `effective_from` | Data / Date | Auditability |

**Consumer:** one function, `services/vitals_ranges.py::classify(metric, value, age_months, sex, height_pct)`
→ `normal | alert | critical | no_reference`. **`no_reference` renders as "—", never as normal** (P2).

### 3.7 `Growth Standard` — **new doctype**

WHO LMS coefficients. Without this, the growth chart must not draw curves (P4).

| Field | Type | Notes |
|---|---|---|
| `standard` | Select | `WHO-2006` (0–5 y) / `WHO-2007` (5–19 y) |
| `metric` | Select | `weight_for_age` / `height_for_age` / `bmi_for_age` / `hc_for_age` / `weight_for_length` |
| `sex` | Select | `Male` / `Female` |
| `age_days` (or `length_cm`) | Int / Float | The x-axis key |
| `l`, `m`, `s` | Float | The LMS triplet |

**Consumer:** `services/growth.py::percentile(metric, sex, age_days, value)` → `(percentile, z_score)`
plus `curve(metric, sex, age_range, percentiles=[3,15,50,85,97])` → the real curves the chart draws.

### 3.8 `Allergy Cross Reactivity` — **new doctype**

| Field | Type | Notes |
|---|---|---|
| `allergen` | Data | Normalised allergen term, e.g. `penicillin` |
| `cross_class` | Data | e.g. `beta-lactam` |
| `member_pattern` | Data | Regex or normalised name matched against the proposed drug |
| `severity` | Select | `absolute` / `caution` |
| `note` | Small Text | What the clinician should consider |
| `source` | Data | Citation |

**Seed minimum for a pediatric clinic:** beta-lactams (penicillins ↔ amoxicillin/ampicillin ↔
cephalosporins, with the correct generation caveats), sulfonamides, NSAIDs, macrolides.
**Consumer:** `services/allergy_check.py::conflicts(drug_name, allergies, patient_age_months)`,
called by `_tool_add_medication` **and** by `save_draft` (so a manually-typed drug is checked too —
today only the AI path is).

### 3.9 `Patient` — allergies must stop being free text

Today `Patient.allergies` is free text and contains `"a"`, `"s"`, `"dssdv"` on the live site. The
allergy validator cannot be better than its input.

**Change:** a child table `Patient Allergy` with `allergen` (Link to a real `Allergy` master),
`reaction`, `severity`, `recorded_on`, `recorded_by`, `source` (`this-clinic` / `reported` /
`external`), `verified` (Check). The free-text field is migrated and then retired.

**This also removes the need for the fabricated provenance in `use-clinical-record.ts`** — the real
fields carry the real answers to "who recorded this, when, and can I trust it".

---

## 4. The encounter lifecycle

### 4.1 States

```
                    ┌─────────────────────────────────────────────┐
                    │  Appointment (or walk-in)                    │
                    └───────────────────┬──────────────────────────┘
                                        ▼
   ┌────────────────────── DRAFT (docstatus 0) ───────────────────────┐
   │  created idempotently from the appointment                        │
   │  editable by nurse (vitals, intake) and practitioner (everything) │
   │  optimistically locked: every write carries `modified`             │
   │  autosaved; every failure is surfaced                              │
   └───────────────┬──────────────────────────────┬────────────────────┘
                   │ practitioner signs           │ practitioner cancels
                   ▼                              ▼
      SIGNED (docstatus 1)                CANCELLED (docstatus 2)
      immutable; orders spawned                  voided, auditable
                   │
                   │ correction needed
                   ▼
      AMENDED — a NEW encounter with `amended_from` set, signed separately.
      Both documents remain readable. Nothing is ever edited in place.
```

### 4.2 What is persisted at every step

| Step | Enters | Changes | Persisted | Client-only | Can be lost? | Source of truth | Audit |
|---|---|---|---|---|---|---|---|
| Create | appointment, patient | encounter created | `Patient Encounter` draft | — | no | the encounter | `creation`, `owner` |
| Load | encounter id | — | — | form state | no | the encounter | — |
| Consent | practitioner's explicit act | session `Draft`→`Recording` | `AI Encounter Session.consent_obtained{,_at}` | — | no | the session | version-tracked |
| Record | audio | segments appended | `AI Transcript Segment` | interim lines | interim only | segments | append-only |
| Document | keystrokes | draft fields | encounter custom fields + child tables, every ≤2 s | nothing clinical | **no** (P8) | the encounter | `track_changes` |
| Vitals | numbers + note | `Vital Signs` draft | all 8 numerics **+ the note** | — | no | Vital Signs | docstatus |
| AI propose | transcript + context | — | `AI Encounter Chat Message` + `AI Suggestion Verdict` (`pending`) | — | no | the verdict row | model, prompt hash |
| AI review | accept/edit/reject | field value | `AI Suggestion Verdict.verdict` + `verdict_by` + `verdict_at` | — | **no** (P5) | the verdict row | who + when |
| Validate | field values | — | `safety_flags_json` on the verdict | — | no | validator output | which rule, which version |
| Sign | practitioner intent | `docstatus` 0→1 | encounter + orders + `final_value_json` + `AI Encounter Record` | — | no | the encounter | signer stamped |
| Amend | correction | new encounter | new doc with `amended_from` | — | no | the newest signed doc | full chain |

### 4.3 Signing rules

| Rule | Behaviour |
|---|---|
| Who may sign | Any practitioner with a linked `Healthcare Practitioner` record (ADR-039). The actual signer is stamped in `custom_encounter_done_by` |
| Who may cancel | The assigned practitioner only (ADR-038) |
| Blocking validations | Chief complaint present. **Every incomplete order row is complete or explicitly removed** — never silently dropped |
| Non-blocking validations | Missing diagnosis, missing plan, unresolved AI suggestions — warned, listed, overridable with one click |
| Never blocking | AI availability, transcript availability, review-details generation (Rule 7) |
| Signature stamp | Date and time are captured **at submit**, stored, and rendered from storage — never `new Date()` at render |

---

## 5. The AI contract

### 5.1 Consent

```
Encounter opens
   └─► AI panel shows: "Start AI assistant"      ← nothing is recording
        └─► practitioner clicks
             └─► consent card: the exact wording the clinic is registered to use,
                 with the patient/guardian named
                  ├─ "Consent given"   → POST session { consent_obtained: true }
                  │                      → status Recording, mic opens
                  └─ "No consent"      → session stays Draft, mic never opens,
                                         note continues normally
```

Rules:
- Once per encounter, remembered for the duration of that encounter (not per page load).
- `consent_obtained: true` may only ever be sent from the branch above. The BFF must not default it.
- A declined consent is a **recorded fact**, not an absence: the session stays `Draft` and is closed
  with `close_reason = "consent_declined"`.

### 5.2 The proposal pipeline

```
TRANSCRIPT ──► digest (deterministic, no LLM) ──► CONTEXT
                                                    │
   bounded + budgeted:                              │
     patient: age, sex, weight                      │
     allergies (structured)                         │
     active medications (structured)                │
     this visit's chief complaint                   │
     prior summary — IN A SEPARATE, LABELLED SLOT   │
     catalogs — capped, ranked by relevance         │
                                                    ▼
                                              MODEL (allowlisted)
                                                    │  ≤N tool iterations
                                              TOOL REGISTRY
                                          read: bounded queries
                                          write: emit proposals only
                                                    ▼
                                         PROPOSAL  +  VALIDATORS RUN HERE
                                                    │
                                     AI Suggestion Verdict (pending)  ✅ persisted
                                                    ▼
                                          PRACTITIONER REVIEW
                                    accept / edit / reject  (+ optional reason)
                                                    │
                                     verdict persisted server-side      ✅
                                                    ▼
                                            FIELD VALUE
                                                    ▼
                                              SIGN → final_value_json stamped ✅
```

### 5.3 Hard rules for the AI layer

| # | Rule |
|---|---|
| A1 | A write tool returns a proposal. It never touches the database. *(Already true — keep it true.)* |
| A2 | **No tool, and no accept action, may create or modify a master record.** Master creation goes to an admin approval queue with the AI's inference shown as a suggestion, exactly as `add_vaccine` already refuses to do it |
| A3 | Every proposal that reaches the physician creates an `AI Suggestion Verdict` row before it is rendered |
| A4 | A proposal may not be auto-applied to a field the physician has already touched. `stream/touched-state.ts` already implements this rule correctly — wire it to every path, not just the cached one |
| A5 | Validators run on the **proposal**, and again on the **final value** at sign. Both outcomes are stored |
| A6 | Confidence is either a measured quantity or absent. A constant is never displayed |
| A7 | Prior-visit context occupies a separate, labelled slot and may never be the source of a current-visit value. Enforce structurally, not by prompt wording |
| A8 | Cumulative patient summary is **append/merge server-side**. The model proposes an addition, never a replacement paragraph |
| A9 | The AI may not target a field that has no input control and no place on the report (P7) |
| A10 | Every context assembly logs its token count and what it dropped. No silent truncation |

### 5.4 Tool registry, corrected

| Group | Tools | Change |
|---|---|---|
| Read (13) | unchanged | Add document-level permission checks for defence in depth |
| Draft writes (17) | `add_*` / `remove_*` for symptom, diagnosis, lab, procedure, therapy, vaccine, vital, chief complaint, review details, follow-up | Each creates a verdict row (A3); each runs validators (A5) |
| Medication write (1) | `add_medication` | **No master creation.** Unmatched drug → proposal marked `needs_catalog_entry`, routed to the admin queue. Interval UOM comes from the model or is absent — never hardcoded |
| Patient-level writes (4) | `add_allergy`, `add_patient_medication`, `add_medical_history`, `add_surgical_history` | Keep the review panel. Allergies write to the structured child table (§3.9) |
| Summary write (1) | `set_patient_summary` | **Replace with `append_patient_summary`** (A8) |

---

## 6. Safety validators

Each is a named function with a unit test, a version, and a displayed source. The UI may only show a
safety claim that maps to one of these.

| ID | Validator | Signature | Fires on | Blocking? |
|---|---|---|---|---|
| **V1** | Allergy direct match | `allergy_direct(drug, allergies)` | proposal + save + sign | Warn |
| **V2** | Allergy cross-reactivity | `allergy_cross(drug, allergies, age_months)` using `Allergy Cross Reactivity` | proposal + save + sign | **Block on `absolute`**, warn on `caution` |
| **V3** | Duplicate medication | `rx_duplicate(encounter, drug, strength)` *(exists)* | proposal | Warn |
| **V4** | Dose completeness | `rx_complete(row)` — form, strength, dose, frequency, duration all present | save + **sign** | **Block at sign** |
| **V5** | Weight-based dose range | `dose_per_kg(drug, dose, weight_kg, age_months)` against a seeded range table | proposal + sign | Warn; block if >2× the max |
| **V6** | Age appropriateness | `drug_age_ok(drug, age_months)` — a seeded contraindicated-by-age list | proposal + sign | **Block** on the seeded list |
| **V7** | Vital classification | `classify(metric, value, age_months, sex, height_pct)` → `normal / alert / critical / no_reference` | on entry | Display only |
| **V8** | Growth percentile | `percentile(metric, sex, age_days, value)` | on vitals save | Display + store |
| **V9** | Vaccine schedule | already implemented (Mexico EPI) | proposal | Warn |
| **V10** | Lab reference completeness | a template with no UOM/range cannot auto-flag results *(exists as a review tag)* | on result entry | Warn |

**What is deliberately *not* a validator:** drug–drug interactions. There is no licensed interaction
database in the stack, and a partial one is more dangerous than none. Until one is licensed, the UI
must make no interaction claim at all — no card, no checklist, no empty warning box.

---

## 7. Pediatric requirements

| Requirement | Design |
|---|---|
| Age is a required input to every threshold | `classify()` takes `age_months`. With no DOB it returns `no_reference`, and the UI shows "—" |
| Respiratory rate has a rule | `Pediatric Vital Range` rows for `respiratory_rate` across all age bands. **This is the highest-value single row set in the whole design** |
| BP is age/sex/height-aware | AAP 2017 tables keyed on age, sex and height percentile |
| Heart rate is age-banded | PALS bands |
| Temperature is age-aware | A neonate's 37.6 °C is not a 9-year-old's 37.6 °C — `critical_*` differs by band |
| BMI only ≥ 24 months | Below that, weight-for-length is the measure |
| Head circumference | New field + WHO curve to 36 months |
| Growth charts | Real LMS curves at p3/p15/p50/p85/p97, labelled with the standard and version. **If `Growth Standard` has no rows for that metric/sex/age, draw no curves and say so** |
| Weight-based dosing | `Drug Prescription` gains `custom_dose_per_kg` and `custom_dose_basis_weight_kg`, so mg/kg is structured data, not prose in a comment |
| Weight is mandatory before prescribing | Warn (not block) if a prescription is written with no weight recorded in this encounter |
| Pediatric forms | Syrup/drops/suspension already in `Dosage Form`. Strength comes from the catalog, never from a model |

### Worked examples the design must handle correctly

| Patient | Vitals | Required behaviour |
|---|---|---|
| Newborn, 3.2 kg | HR 140, RR 45, T 37.6 | HR **normal**, RR **normal**, T **critical** (neonatal fever). Weight plotted on a real WHO curve near p50 |
| 2-month-old, 5.5 kg | RR 62, SpO₂ 94 | RR **critical**, SpO₂ **alert**. Weight ~p50, not "below p3" |
| 2-year-old, 12 kg | BP 118/76 | **Alert** — above the 95th centile for age/sex/height. Today this renders black |
| 9-year-old, 28 kg | HR 105, RR 22 | HR **normal for age**, RR normal. Weight ~p50 on a real curve |
| 15-year-old, 55 kg | BP 128/82 | **Alert** — adult-adjacent thresholds legitimately apply at this age, via the same table |

---

## 8. UX specification

### 8.1 Layout

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ ← Encounter · Patient name · MRN · 2 y 3 m ·  [● Saved]  [Sign & close]      │
├────────────────────────────────────────────┬─────────────────────────────────┤
│  PROGRESS RAIL        THE NOTE             │  AI ASSISTANT                    │
│  (mount the one       (primary lane)       │                                  │
│   already written)                         │  ┌────────────────────────────┐  │
│                                            │  │ Start AI assistant          │  │
│  ● Complaint      ── Chief complaint *     │  │ (consent card on click)     │  │
│  ● Vitals         ── HPI                   │  └────────────────────────────┘  │
│  ○ Examination    ── Vitals  [4 flagged]   │                                  │
│  ● Assessment     ── Examination           │  Transcript                      │
│  ● Plan           ── Assessment / dx       │  ─────────────────────           │
│  ○ Orders  3      ── Plan (narrative)      │  Proposals (3)                   │
│  ○ Follow-up      ── Orders  ▸ Rx 2        │   ▸ Dx: viral URI                │
│  ● Review                    ▸ Labs 1      │       [Accept] [Edit] [Reject]   │
│                   ── Follow-up             │   ▸ Rx: paracetamol ⚠ V5         │
│  4 of 8 complete  ── Review details        │                                  │
│                                            │  Ask anything…                   │
└────────────────────────────────────────────┴─────────────────────────────────┘
```

### 8.2 Interaction rules

| Rule | Detail |
|---|---|
| **Visit type first** | An optional picker (Well-child / Fever / Cough / Vaccination / Follow-up) applies a treatment-plan template — which already fills Rx, labs, procedures and therapies in one action — and chooses which sections are visible by default |
| **Sections with content are open** | Never collapse a section that holds data |
| **Validation is continuous** | The rail shows completeness live. The chief-complaint indicator turns green on entry. Sign is never a validation surprise |
| **One-click sign** | Review details are generated in the background when diagnosis and plan settle, not at the click. No fixed animation. The report *is* the confirmation |
| **Save state is honest** | `Saved` / `Saving…` / **`Not saved — <server message>`** with a Retry button. After 3 failures, a blocking banner |
| **No two-button traps** | Vitals and follow-up commit on blur. Nothing needs rescuing at submit |
| **Destructive actions are separated** | Cancel lives in an overflow menu, never adjacent to Sign |
| **Every string is translated** | `es-MX` + `en-US`. Zero hardcoded user-visible text, including weekday names on the printed note |
| **Missing data reads as missing** | "—", never a plausible substitute (P2) |
| **AI is visibly optional** | Every AI surface can be collapsed, and the note occupies the full width when it is |

### 8.3 Target interaction cost for a simple visit

| Step | Today | Target |
|---|---|---|
| Open encounter | 2 serial fetches, 25 calls | 1 combined fetch, ≤10 calls |
| Chief complaint | search + pick | unchanged |
| Vitals | 8 fields (nurse-prefilled) | unchanged, now with real flags |
| Diagnosis | search + pick | unchanged |
| Plan + orders | expand ×5, then add | visit-type template = 1 action |
| Follow-up | open, set, click Schedule | set (commits on blur) |
| **Sign** | **5 interactions + 2 waits** | **1 click + 1 confirmation** |

---

## 9. API surface

All under `api/v1/encounters/` unless noted. Custom whitelisted methods only.

| Method | Change |
|---|---|
| `create_encounter` | unchanged (idempotent by appointment) |
| `get_encounter` | **return every field the writer accepts** (§3.2); add the contract test |
| `save_draft` | **accept `modified`**; return `409` with both versions on mismatch; never silently drop rows; return validator results |
| `complete_encounter` | stamp signature datetime; stamp `final_value_json` on every verdict row; keep the existing order-spawn |
| `cancel_encounter` | unchanged |
| **`amend_encounter`** *(new)* | create a new draft with `amended_from` set, copying the signed content; require a reason |
| **`record_suggestion_verdict`** *(new)* | `(suggestion_id, verdict, final_value, reject_reason?)` → updates `AI Suggestion Verdict` |
| **`get_encounter_provenance`** *(new)* | the full AI chain for one encounter, for audit and review |
| `book_follow_up` | unchanged |
| `api/ai/sessions.start_session` | unchanged — it is already correct. Only the caller changes |

---

## 10. Provenance and audit

For every AI-influenced field, the following must be answerable from the database alone:

| Question | Answered by |
|---|---|
| What did the AI see? | `AI Transcript Segment` + `AI Encounter Record.transcript_json` + the logged context token count |
| What did it conclude? | `AI Encounter Chat Message.content` |
| What did it propose? | `AI Suggestion Verdict.proposed_value_json` |
| On what evidence? | `AI Suggestion Verdict.evidence_json` |
| Which tools, with what arguments? | `AI Prompt Log.tools_detail_json` — **wire the existing `redact_tool_args` / `tool_result_shape`** |
| Which validators fired? | `AI Suggestion Verdict.safety_flags_json` |
| What did the practitioner do? | `verdict` + `verdict_by` + `verdict_at` |
| Why did they reject it? | `reject_reason` |
| What was finally recorded? | `final_value_json` + the encounter itself |
| Who signed? | `custom_encounter_done_by` |
| Was consent obtained? | `AI Encounter Session.consent_obtained{,_at}` — **written only from a real act** |
| How long was the recording? | `duration_seconds` — **make `Stopped` reachable** |

**Rule 10 stays intact:** `AI Prompt Log` holds shapes, hashes, counts and costs.
`AI Suggestion Verdict` holds clinical values, is permissioned as clinical data, and follows the
clinical retention period — not the log's.

---

## 11. Retention and compliance

Today: `scheduler_events` is commented out, so nothing is ever purged, and
`AI Settings.transcript_retention_days = 2555` contradicts `ComplianceProfile` (90 mx / 30 in).

| Artefact | Retention authority | Purge job |
|---|---|---|
| Audio | never stored (`retain_audio = 0`) | n/a |
| `AI Transcript Segment` | **`ComplianceProfile`** — one authority, not two | daily |
| `AI Encounter Record.transcript_json` | same period as the segments (the audit's own docstring flags this gap) | daily |
| `AI Prompt Log` | `prompt_log_retention_days` | daily |
| `AI Prompt Log.raw_response` when it is load-bearing for lab extraction | **move it out** — extracted values belong on the lab record, not in a log | migration |
| `AI Suggestion Verdict` | clinical-record retention | with the encounter |
| Clinical record | jurisdictional (`audit_retention_years`) | never auto-purged |

**Actions:** resolve the two-authority conflict in favour of `ComplianceProfile`; uncomment and
implement `scheduler_events`; add a data-subject-erasure path that reaches both the source rows and
the `AI Encounter Record` copy.

---

## 12. Migration path

Ordered so that nothing depends on something later, and each step is independently shippable.

| # | Step | Depends on |
|---|---|---|
| M1 | **Delete the fabrication layer.** Pure deletion, no schema change, no migration | — |
| M2 | **Restore consent.** Three-file revert plus a consent card | — |
| M3 | **Fix the read serializers** + add the read ⊇ write contract test | — |
| M4 | **Persist the vitals note** (the field already exists on `Vital Signs`) | — |
| M5 | Add the 5 clinical custom fields; **dual-write** them alongside the blob | M3 |
| M6 | Backfill from the 131 existing blobs; switch reads to the fields; stop writing the blob | M5 |
| M7 | Build the HPI / examination / plan inputs (the fields now exist and are reviewable — P7) | M6 |
| M8 | Seed `Pediatric Vital Range`; replace the four hardcoded literals with `classify()` | — |
| M9 | Seed `Growth Standard`; replace `bandPath` with real curves — **or** remove the curves until M9 lands | — |
| M10 | `Patient Allergy` child table; migrate the free text; retire the field | — |
| M11 | Seed `Allergy Cross Reactivity`; add V2 to both the AI and the manual save path | M10 |
| M12 | Add `AI Suggestion Verdict`; create rows on proposal; add `record_suggestion_verdict` | — |
| M13 | Wire `tools_detail_json` using the existing, already-tested helpers | — |
| M14 | Optimistic concurrency on `save_draft` (`modified` in, 409 out) | — |
| M15 | Master-creation approval queue; remove `ignore_permissions` from the AI path | — |
| M16 | Make `Stopped` reachable; add the session uniqueness constraint | — |
| M17 | `amend_encounter` on core `amended_from` | — |
| M18 | Bound and budget the catalog injection and the patient summary; log what was dropped | — |
| M19 | Implement `scheduler_events` retention; resolve the retention-authority conflict | — |
| M20 | UX: mount the rail, fix the sign tail, inline validation, dead buttons, i18n | M3, M6 |
| M21 | Split `encounter-screen.tsx` along the section boundaries the rail already defines | M20 |

**M1–M4 are the "stop the line" set** and touch no schema.

---

## 13. Acceptance criteria

Each is a user story with a testable outcome. These are the definition of done for this design.

1. **Consent.** *As a physician, when I open an encounter, nothing is recording.* When I click
   "Start AI assistant" I see a consent card naming the patient; only after I confirm does the mic
   open and `consent_obtained = 1` get written. If I decline, the session is stored as
   `close_reason = consent_declined` and the note works normally.
2. **No fabricated data.** *As a physician, every value on the chart came from the record.* A patient
   with no recorded allergies shows an empty allergy list, not a hash-generated one. A growth chart
   with no seeded standard shows the child's plotted points and **no curves**, with a note saying why.
3. **Growth.** *As a pediatrician, I can read growth accurately.* A 2-month-old at 5.5 kg plots near
   the 50th centile of a real WHO weight-for-age curve for their sex, and the chart names the
   standard and version.
4. **Respiratory rate.** *As a pediatrician, an abnormal RR is flagged.* A 2-month-old at RR 62 shows
   **critical**; a newborn at RR 45 shows normal. The tooltip names the source table.
5. **Blood pressure.** *As a pediatrician, pediatric hypertension is flagged.* A 2-year-old at
   118/76 shows **alert**, not normal.
6. **Prescription integrity.** *As a physician, what I prescribed is what is stored.* I set
   amoxicillin q8h × 7 days, reload the page, and still see q8h. `get_encounter` returns
   `interval` and `interval_uom`.
7. **No silent drops.** *As a physician, an incomplete prescription cannot vanish.* If I try to sign
   with a drug missing its duration, signing is blocked, the row is highlighted, and it is named in
   the error.
8. **Vitals note.** *As a nurse, my note is saved.* I type an observation under the vitals, reload,
   and it is still there.
9. **Save honesty.** *As a physician, I am told when saving fails.* A validation failure shows the
   server's message and a Retry button; three failures show a blocking banner. I never lose twenty
   minutes silently.
10. **Concurrency.** *As a nurse and a doctor working the same encounter, neither of us loses work.*
    A stale write returns 409 and the UI offers a merge rather than overwriting.
11. **Allergy safety.** *As a physician prescribing amoxicillin to a child with a documented
    penicillin allergy, I am stopped.* V2 fires with `absolute` severity and names the cross-class
    and its source — on the AI path **and** when I type the drug myself.
12. **Formulary integrity.** *As a clinic admin, no AI can add a drug to my formulary.* An unmatched
    AI-proposed drug appears in an approval queue showing the inferred strength/form for me to
    confirm, correct or reject. Nothing enters `Medication` until I act.
13. **Provenance.** *As an auditor, I can reconstruct any AI-influenced value.* For a given signed
    encounter I can see, per field: what was proposed, on what evidence, which validators fired,
    what the practitioner did, when, who they were, and what was finally recorded.
14. **Rejection memory.** *As a physician, a suggestion I rejected does not come back.* Re-running
    Analyze does not re-propose it, on any path, on any device.
15. **Signature integrity.** *As a compliance officer, a reprinted note shows the original signature
    date.* A June encounter printed in August shows June.
16. **Amendment.** *As a physician who signed a note with a typo, I can correct the record without
    voiding it.* Amending produces a new linked, separately-signed document; both remain readable.
17. **Sign speed.** *As a physician who has finished deciding, signing takes one click.* No blocking
    AI call, no fixed animation, no separate acknowledgement.
18. **AI optional.** *As a physician on a day when the AI provider is down, nothing blocks me.* The
    panel says unavailable; documenting and signing are unaffected (Rule 7).
19. **Retention.** *As a DPO, configured retention actually happens.* Transcripts past the
    `ComplianceProfile` period are purged by a scheduled job, in both the source rows and the
    `AI Encounter Record` copy.
20. **Complete note.** *As a covering practitioner reading a colleague's signed note, I can
    understand the visit.* Chief complaint, HPI, examination, assessment and plan are all present
    and all were reviewable by the person who signed.

---

## 14. Explicitly out of scope

Deferred deliberately, with the reason recorded so it is not re-litigated:

| Item | Why not now |
|---|---|
| Drug–drug interaction checking | No licensed database. A partial implementation is worse than none |
| "Similar historical cases" / cohort insights | No cohort data, no retrieval method, and PHI aggregation concerns |
| Displayed confidence scores | Only when measured. A constant misleads |
| Vector search / embeddings / RAG | Structured retrieval must be bounded and budgeted first |
| Streaming Analyze | Reverted for a good reason; needs verified nginx behaviour |
| Autonomous or multi-turn agents | No supervision signal until verdicts are persisted |
| IPD / emergency encounter flows | OPD-only product today; the dead core fields stay hidden |
| Insurance on the encounter | Phase 3 not built; the four fields stay hidden |
| Outcome-based AI evaluation | Needs verdicts (M12) plus outcome capture |

---

## 15. Open decisions

These need a human answer before the relevant migration step.

| # | Decision | Blocks |
|---|---|---|
| D1 | **Is the OpenAI data-processing agreement in place?** `integrations/openai.py:12-15` says the provider must stay off until it is; the live config runs it | Nothing technical; everything legal |
| D2 | **What do the 137 existing `consent_obtained = 1` rows mean**, and does any of that audio-derived transcript need to be handled? | M2 |
| D3 | **Which vital-range source** do we standardise on (PALS / AAP / NOM), and who signs off clinically? | M8 |
| D4 | **WHO-2006 + WHO-2007, or CDC** for growth, and is Mexico's NOM-031 preferred? | M9 |
| D5 | **Rule 5:** amend the constitution to permit full-record retrieval, or bound the summary? | M18 |
| D6 | **`raw_response`:** move extracted lab values onto the lab record, or keep the log load-bearing and change its retention? | M19 |
| D7 | **Do we keep `AI SOAP Draft` and `generate_suggestions`** (0 rows, 0 calls) or delete them? | M21 |
| D8 | **Do HPI / examination / plan get inputs** (M7), or do we delete the fields and accept a chief-complaint-plus-orders note as the product? | M7 |
| D9 | Does a signed encounter's amendment require a co-signer or a reason code, per NOM-024? | M17 |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Marked partially superseded by ADR-054 (top-level screen architecture only); corrected two stale "target design" citations elsewhere that pointed here as if decided |
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial ground-up design derived from the forensic audit |
