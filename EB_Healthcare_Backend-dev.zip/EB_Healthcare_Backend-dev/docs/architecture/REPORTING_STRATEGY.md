# Reporting Strategy — Custom APIs, Insights, and Data Freshness

**Doc status:** living · **Created:** 2026-08-25 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-03 by Anant Sharma (AI-assisted) · **Version:** 1.3

> **Scope.** Why clinical reporting is served by our own whitelisted APIs, why Frappe
> Insights is **not** the reporting engine for product screens, what Insights *is*
> sanctioned for, and how each report is classified by **staleness tolerance** —
> which is what actually drives the caching policy.
>
> **Status of the decision:** proposed here, **not yet ratified**. Ratify as
> **`adr-047-reporting-engine-custom-apis-not-insights`** before treating it as
> binding. (Written as ADR-045 when 044 was the highest; `dev` then took 045 twice
> and 046, so this was renumbered to 047 before it was ever merged or cited. One of
> those two 045s — the lab-upload one — was itself renumbered to
> [`adr-052-one-call-per-upload-with-bounded-recovery`](../adr/adr-052-one-call-per-upload-with-bounded-recovery.md)
> on 2026-08-29, so 045 now means only the push-notifications ADR.)
>
> **One fact, one owner** (`CLAUDE.md` §9): the endpoint *contract* is owned by
> [`docs/reports/API.md`](../reports/API.md); phase status by
> [`docs/STATUS.md`](../STATUS.md). This document owns only the **strategy** — the
> engine choice, the freshness tiers, and the caching rule. It does not restate
> response schemas.

---

## 1. Decision in one paragraph

Clinical and operational reporting is served by **our own whitelisted methods** in
`api/v1/<module>/report.py`, consumed by the Next.js frontends through the BFF.
**Frappe Insights is not used for any product screen.** Insights is retained as an
**internal analyst sandbox** for ad-hoc questions nobody has written an endpoint for,
and it is **not enrolled with any user and not authorised against clinical tables**.
Report performance is fixed by **optimising the queries** — SQL aggregation, indexes,
bounded scans, and a staleness-tier cache — **not** by adopting a BI tool or a
separate warehouse.

---

## 2. Why custom report APIs

### WHAT

Seventeen whitelisted endpoints across eight `report.py` files, each sitting beside
the `api.py` that owns its doctype. Roughly 2,150 lines. Every one begins with
`require_permission(<doctype>, "read")` and `require_roles(...)`, resolves its window
through the shared `resolve_report_window()`, and returns the standard envelope with a
`meta` block.

### WHY

Four properties that a generic BI tool cannot provide, in descending order of importance:

1. **Permission honesty.** `report_practitioner_scope()` **overrides** whatever
   practitioner filter the caller passed, forcing a plain `EB_Practitioner` onto their
   own linked practitioner. This is the control that stops one doctor reading another
   doctor's queue. It is a deliberate, code-level invariant — not a configuration
   setting somebody can toggle.
2. **The locked API contract.** `CLAUDE.md` §3 requires that *all* data access go
   through `api/v1/<module>/api.py`. A reporting path that composes its own SQL is the
   exact bypass that rule exists to prevent.
3. **Honesty about missing data.** Where a data source does not exist, the backend
   returns `null` and the screen renders `—`. Given this codebase's documented history
   of fabricated clinical numbers (see `docs/audit/practitioner/`), never emitting a
   confident-looking wrong number is a safety property, not a nicety.
4. **One auth surface.** The browser never talks to Frappe directly (ADR-010). Reports
   ride the same JWT/BFF path as every other screen.

### HOW

```
Next.js screen → BFF route handler → whitelisted method
   → require_permission + require_roles
   → report_practitioner_scope()      # mandatory scope override
   → resolve_report_window()          # period → [start, end]
   → frappe.get_all / SQL aggregate
   → { data: {...}, meta: {...} }
```

### WHEN

Built during Phase 4. The layout diverged from the contract — `REPORTS_API.md` §1
specified a single `api/v1/reports/api.py`; the implementation put a `report.py` beside
each module instead. **The divergence is endorsed**: it keeps each report's permission
check next to the API that owns the doctype, which is what makes property (1) reviewable.
`REPORTS_API.md` §1 should be corrected to match.

---

## 3. Why NOT Frappe Insights for product screens

Insights v3.12.6 is installed on the local bench. It is a capable BI tool. It is the
wrong tool for **this** job, for reasons measured on this site — not assumed.

| # | Reason | Evidence |
|---|---|---|
| 1 | **It would not make anything faster.** Product screens call `api/v1/*/report.py`. Insights is a separate Vue app at `/insights` against the same MariaDB. Adopting it changes zero milliseconds unless the 17 screens are *replaced* | Architectural; see §5 for where the time actually goes |
| 2 | **It bypasses the service layer.** Composes its own SQL via Ibis against a `Site DB` data source | `insights_query_v3.py:186` (`ibis.to_sql`); §3 of `CLAUDE.md` |
| 3 | **Default-permissive against clinical data.** A `Site DB` source is auto-created on migrate; **1,015 tables indexed, 38 clinical** — `tabPatient Medical Record`, `tabDiagnosis`, `tabVital Signs`, `tabPatient Assessment` | `insights_data_source_v3.py:49-61`; measured on `remedisys.localhost` |
| 4 | **Parallel permission model.** `Insights Team`, gated by one `enable_permissions` flag — currently **off**, meaning *"accessible to all insights users"* | `permissions.py:26` |
| 5 | **PHI in logs.** `Insights Query Execution Log` stores the **raw SQL text**. A filter on a patient name writes that name into a log row — a direct **Rule 10** breach | doctype has an `sql` Code field, written on every execution |
| 6 | **PHI at rest, new locations.** Warehouse tables land in `sites/<site>/private/files/*.duckdb`, batched through temporary **parquet** files — outside every retention rule we have written | `data_warehouse.py:118-181`, `connectors/duckdb.py:15-18` |
| 7 | **Second UI outside the BFF.** Its Vue app is served *by Frappe*, contradicting ADR-010 | ADR-010 |
| 8 | **No clinical validator.** A hand-built join silently yields a plausible wrong number, with no `stub_fields`-style honesty contract | — |

### Two things Insights is NOT guilty of

Stated for fairness, because both were suspected and both are false:

- **No AI / text-to-SQL.** Zero `openai` / `anthropic` / `llm` references in v3.12.6's
  Python. The `sql-ai` work is on an unreleased branch. **No Rule 4 or ADR-030 conflict.**
- **It does have an audit trail.** `Insights Query Execution Log` records SQL, data
  source, timing, plus Frappe's `owner`/`creation`. The defect is that the trail
  *contains PHI* (reason 5), not that it is absent.

### Correcting a tempting split

A natural-sounding division is *"operational → our API, analytics → Insights."* Applied
literally it is **wrong**, because the analytics half **already exists as working,
permission-scoped endpoints**:

| Report often assigned to Insights | Already built |
|---|---|
| Revenue analysis | `billing/report.py::get_revenue_by_provider` |
| Patient growth | `providers/report.py::get_patient_volume` |
| Doctor performance | `providers/report.py::get_utilization_rate`, `dashboard/report.py::get_my_performance` |
| Appointment trends | `appointments/report.py::get_daily_patient_flow` |
| Management dashboard | `dashboard/report.py::get_reports_overview` |

Moving these to Insights would **delete working permission scoping and replace it with a
default-permissive model**. That is a regression, not a division of labour.

---

## 4. What Insights IS for

**Sanctioned:** ad-hoc exploration, on a developer or analyst bench, of questions nobody
has written an endpoint for — *"which practitioners have the worst no-show rate on
Mondays among patients who arrived via insurer X?"* Today that is a backend ticket and a
deploy. In Insights it is ten minutes. It is also a good way to **prototype** the
aggregations for the reports still owed (`REPORTS_API.md` §6 gaps B and E) before
writing them into `report.py`.

**Not sanctioned, pending `adr-047-reporting-engine-custom-apis-not-insights`:** any clinic/production site; any role grant; any
clinical table.

**Current posture — latent, not controlled.** Zero users hold `Insights User` or
`Insights Admin`, so only Administrator can reach it. **That is an accident of a fresh
install, not a decision.** Granting one role today would expose all 38 clinical tables.

**If it is ever promoted to a clinic site, all five must hold:**

1. ADR resolving the §3 service-layer and ADR-010 BFF conflicts explicitly.
2. `enable_permissions = 1`, with a team scoped to non-clinical tables.
3. Clinical tables removed from `Site DB`, or replaced with de-identified views.
4. Retention + encryption decision for `private/files/*.duckdb` and parquet temp files.
5. SQL scrubbed or hashed in `Insights Query Execution Log` (Rule 10).

---

## 5. Report classification — by staleness tolerance

### Why not "real-time vs historical"

**Nothing here is real-time.** There is no streaming or server push for reports; every
figure is an on-demand read. Calling a report "real-time" invites a polling loop that
re-runs a full scan every few seconds.

The axis that actually determines behaviour is **staleness tolerance**: how wrong may
this number be before someone makes a bad decision? That single question sets the cache
TTL, the refresh affordance, and whether polling is ever acceptable.

### The rule that falls out of it

> **A closed date range is immutable.** Last month's no-show rate cannot change. It can
> be cached for a long time. A window that includes *today* can change with the next
> check-in, so it cannot.

This is a better caching rule than "historical vs live", because it is a property of the
**request**, not of the report. `get_no_show_analysis` for *last month* is permanently
cacheable; the same endpoint for *this month* is not.

### Tiers

| Tier | Meaning | Tolerance | Cache | Refresh |
|---|---|---|---|---|
| **0 — Live operational** | Drives a clinical or front-desk action **now** | ~0–30 s | none, or 15 s | Manual button + focus refetch |
| **1 — Open period** | Analytical, window includes today | ~60 s | 60–120 s keyed on user+params | Manual button |
| **2 — Closed period** | Analytical, window entirely in the past | hours | 15 min+ (data is immutable) | None needed |

### Classification of every endpoint

**Tier 0 — Live operational** (`dashboard/api.py`, *not* `report.py`):

| Endpoint | Serves |
|---|---|
| `get_dashboard_data` | Today: appointments, checked-in, waiting, completed, cancelled |
| `get_command_center` | Live room queue / who is where |

These are correctly **already separate** from the report layer. `dashboard/report.py`'s
own docstring states the distinction: *"an aggregate snapshot, distinct from the
operational Today dashboard in api.py."*

**Tier 1 or 2 — all seventeen `report.py` endpoints**, tier decided per request by
whether the window includes today:

| Module | Endpoints |
|---|---|
| `appointments` | `get_daily_patient_flow`, `get_no_show_analysis`, `get_queue_wait_times`, `get_check_in_rates` |
| `billing` | `get_payment_methods`, `get_outstanding_balances`, `get_revenue_by_provider` |
| `encounters` | `get_diagnosis_trends`, `get_encounter_summaries`, `get_avg_visit_time` |
| `providers` | `get_patient_volume`, `get_utilization_rate` |
| `dashboard` | `get_reports_overview`, `get_my_performance` |
| `clinical` | `get_chronic_care` |
| `immunizations` | `get_immunization_rates` |
| `insurance` | `get_claims_status` |

**One deliberate exception.** `get_outstanding_balances` is a **balance as of now**, not a
period aggregate. Treat it as Tier 1 even for a closed window — money moves after the
period ends.

### Frontend rules that follow

- **Tier 0:** refresh on window focus and on an explicit button. Poll no faster than
  30 s, and only while the screen is visible.
- **Tier 1 / 2:** load once per parameter change. **Never poll.** Give a Refresh button
  and show `meta.generated_at` so the user can see how old the figure is.
- Two identical closed-window requests must never hit the database twice.

---

## 6. Performance — the real bottleneck, measured

Reporting slowness is a **query-shape** problem, not an engine problem. Measured on
`remedisys.localhost` (627 patients / 111 practitioners / 119 appointments):

| Report | Time |
|---|---|
| `get_chronic_care` | 95.8 ms |
| `get_utilization_rate` | 37.9 ms |
| `get_queue_wait_times` | 4.7 ms |
| `get_no_show_analysis` | 1.7 ms |

**Same answer, two ways** — unbounded fetch + Python loop (what `report.py` does today)
versus SQL `GROUP BY`:

| Rows | Fetch-all + Python | SQL `GROUP BY` | Speedup |
|---|---|---|---|
| 1,027 | 2.2 ms | 1.9 ms | 1.1× |
| 8,183 | 37.8 ms | 9.9 ms | **3.8×** |

Marginal cost **4.62 ms/1k rows** versus **1.21 ms/1k**, and the gap widens: the Python
path is O(rows transferred), the SQL path returns O(groups).

### Four defects to fix, in priority order

1. **No SQL aggregation anywhere.** 33 `frappe.get_all(limit_page_length=0)` calls,
   zero `GROUP BY`. `REPORTS_API.md` §7 asked for the opposite.
2. **`get_chronic_care` is unbounded.** `clinical/report.py:70` scans *every* patient
   with `medical_history` set, ignoring the report window, then parses free text per row.
   O(total patients), forever.
3. **Three unindexed filter columns:** `Patient Appointment.custom_checked_in_at` (a
   filter in **two** reports), `Patient Encounter.practitioner`, `Sales Invoice.status`.
4. **Unbounded `IN()`.** `get_queue_wait_times` builds `{"appointment": ["in", appt_ids]}`.
   At 20k appointments that is a 20,000-element `IN` list — slow, and it risks
   `max_allowed_packet`.

Plus: **the 60–120 s cache specified in `REPORTS_API.md` §7 was never implemented.**

### Projection — 5,000 patients / 500 practitioners

**ESTIMATE, not measured.** Assumes ~4 visits/patient/year → ~20,000 appointments/year.

| Report, 1-year window | Estimate |
|---|---|
| `get_no_show_analysis` | ~90 ms |
| `get_utilization_rate` | ~0.2–0.4 s |
| `get_queue_wait_times` | ~0.4–2 s |
| `get_chronic_care` | ~0.8–3 s |

Sluggish but usable at one year; genuinely painful at three years (~60k appointments), or
on the `/reports` landing page which loads several at once. **UNVERIFIED** until a
synthetic-volume benchmark is run.

### USER STORY

A clinic admin opens `/reports/clinical/chronic-care-management` in year 3 → **the system
shows** a spinner for four seconds with no progress indicator → they assume it hung and
click again → **the database actually receives** a second full scan of 5,000 `tabPatient`
rows, because there is no cache and no request dedup → **consequence:** load doubles under
exactly the condition that caused it, and the page reads as broken.

---

## 7. Options considered

| Approach | Pros | Cons |
|---|---|---|
| **A. Optimise `report.py` in place** — SQL aggregation, 3 indexes, tiered cache, bound `chronic_care`, kill the `IN()` (**chosen**) | Measured 3.8× and widening; no new infrastructure; no PHI duplication; every permission guarantee preserved; ~1–2 days | Gives no ad-hoc exploration |
| B. Insights + DuckDB warehouse as the reporting engine | Genuinely fast columnar analytics; ad-hoc for free | Duplicates PHI; stale by refresh interval; parallel permission model; **does not speed up the existing 17 screens**; needs an ADR |
| C. Nightly pre-aggregated summary doctypes in our app | Near-instant reads; stays inside `api/v1`; no new dependency | Stale by up to a day; new doctypes need an ADR; more code to own |
| D. Accept current performance | No work | Degrades monotonically as data grows |

**Chosen: A.** B loses because it answers a query-optimisation problem with a
data-duplication architecture, and would leave the product screens exactly as slow —
its cost is paid in PHI surface, its benefit lands somewhere else. C is the correct
**second** step if A proves insufficient beyond ~3 years of data, and it keeps
everything inside the service layer that B abandons; it is not first because it trades
freshness for speed we have not yet proven we need. D loses because the trend only
moves one way.

**What would falsify this choice:** if profiling after A still shows multi-second
aggregate reports at realistic volume, C becomes correct. If the actual demand turns out
to be clinicians self-serving novel clinical questions, then the premise shifts and B
deserves a real hearing — with the five controls in §4.

---

## 8. Target architecture

```
        Next.js frontends  (remedisys-ai-ehr · patient-portal)
                          │  Bearer JWT, BFF — browser never hits Frappe (ADR-010)
                          ▼
        ┌───────────────────────────────────────────────┐
        │   api/v1/<module>/  —  whitelisted methods    │
        │   require_permission + require_roles          │
        │   report_practitioner_scope()  (mandatory)    │
        ├──────────────────────┬────────────────────────┤
        │  api.py              │  report.py             │
        │  Tier 0 — live       │  Tier 1/2 — analytical │
        │  no cache            │  cache by window class │
        └──────────┬───────────┴───────────┬────────────┘
                   │                       │
                Redis                   MariaDB
             (tiered TTL)          (SQL aggregation + indexes)

    ─────────────────────────────────────────────────────────
        Frappe Insights  —  analyst bench ONLY, not a product
        surface.  No role grants.  No clinical tables.
        Promotion to a clinic site requires `adr-047-reporting-engine-custom-apis-not-insights` + §4's five controls.
```

---

## 9. Next actions

| # | Action | Owner | Priority |
|---|---|---|---|
| 1 | Ratify this document as **`adr-047-reporting-engine-custom-apis-not-insights`** | Sarvesh | P0 |
| 2 | Bound `get_chronic_care` by the report window | backend | P0 |
| 3 | Add indexes: `custom_checked_in_at`, `Patient Encounter.practitioner`, `Sales Invoice.status` (fixtures — Rule 1 safe) | backend | P0 |
| 4 | Rewrite hot aggregations as SQL `GROUP BY` | backend | P1 |
| 5 | Replace the `IN(appt_ids)` with a JOIN/subquery | backend | P1 |
| 6 | Implement the tiered cache from §5 | backend | P1 |
| 7 | Benchmark at 20k synthetic appointments to replace §6's estimates | backend | P1 |
| 8 | Wire `meta.partial` into a "data not available" banner (currently dead metadata) | frontend | P2 |
| 9 | Correct `REPORTS_API.md` §1 (module layout) and its stale "no implementation yet" intro | docs | P2 |
| 10 | Correct `CLAUDE.md` §12 — Reports is built; `get_average_visit_time` is `get_avg_visit_time` | docs | P2 |

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-03 | Anant Sharma (AI-assisted) | Endpoint-contract link repointed again after `REPORTS_API.md` was renamed to `API.md`; no change to the strategy itself |
| 1.2 | 2026-09-02 | Anant Sharma (AI-assisted) | Link to the endpoint contract repointed after the reporting documents moved to `docs/reports/`; no change to the strategy itself |
| 1.1 | 2026-08-29 | Sarvesh-SocialAngel (AI-assisted) | Number-history note updated: the lab-upload ADR-045 was renumbered to 052 on 2026-08-29, so 045 now means only the push-notifications ADR |
| 1.0 | 2026-08-25 | Anant Sharma (AI-assisted) | Initial version — custom-API rationale, Insights exclusion with measured evidence, staleness-tier classification, performance findings |
