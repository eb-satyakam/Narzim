# Frappe Assistant Core (FAC) Evaluation for Remedisys

**Doc status:** record · **Created:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.3

> **PRIMARY QUESTION (v2.0).** "Should Remedisys use FAC in production for the Frontend LLM?"
> The Frontend LLM is the clinician-facing production AI: the Narzim copilot a doctor uses
> inside the Encounter screen. **Answer: no.** Section 25 is the evaluation, and it is now the
> section that decides this document.
>
> **SECONDARY QUESTION.** "Does FAC give enough developer-speed benefit to justify using it for
> Claude Code, and if so, where?" **Answer: optional, and currently unnecessary.** Sections 3,
> 11, 21 and 22 are the evaluation. Claude Code is a **developer tool**. It is not the
> production LLM, and nothing about its convenience is an argument for a production dependency.
>
> **Terminology, fixed in v2.0.** "Frontend LLM" names the production, in-product, clinician-facing
> model. It is *surfaced* in the Next.js frontend, but the model call and the tool loop both
> execute **server-side inside Frappe** (§2.10). The frontend holds no LLM SDK and makes no
> provider call: **VERIFIED**, `package.json` has no AI dependency and no file under `src/`
> references `api.openai.com`, `api.anthropic.com`, `openai`, `@ai-sdk`, `generateText` or
> `streamText`.
>
> **How to read the labels.**
> - **VERIFIED** = read from this codebase, or measured on this machine, or read from
>   FAC source on GitHub. A file path, a line number, or a number is attached.
> - **INFERENCE** = a conclusion drawn from verified facts. It could be wrong.
> - **RECOMMENDATION** = a judgement call. It is a choice, not a fact.
>
> **Short version for the team: [`FAC_DECISION_SUMMARY.md`](FAC_DECISION_SUMMARY.md)** (the story,
> the measured numbers, the security audit of our own tools, and the verdict). This file is the full
> evidence behind it. **The bottom line here is §26, at the end**; the detailed verdicts are §20 and
> §25.
>
> Prompt archive: [`prompts/2026-09-10-fac-architecture-evaluation.md`](../_archive/prompts/2026-09-10-fac-architecture-evaluation.md)

---

## 1. Executive Summary

### 1.1 Findings

Seven findings decide this. Five of them were already in our own repo. Findings 1, 2, 3, 6 and 7
bear on the **production** question; 4 and 5 bear only on the **developer** question.

1. **FAC was already evaluated and rejected once, by name.** ADR-030 (2026-07-23) rejected
   Frappe_Assistant_Core on two grounds: AGPL-3.0 for a commercial product, and raw SQL,
   arbitrary Python and generic CRUD handed to a language model over patient data.
   **VERIFIED** [`docs/adr/adr-030-llm-curated-tool-access.md:27-36`](../adr/adr-030-llm-curated-tool-access.md).

2. **It was then installed anyway, as a deliberate override, and the contradiction is
   still open.** FAC 2.5.1 went onto `remedisys.localhost` on 2026-08-27, adding 9 DocTypes
   and 25 packages. The work log records the next step as "ADR-030 is now contradicted by
   the running system. Either supersede it with a new ADR recording the decision to permit
   FCA, or remove FCA." That has not been done.
   **VERIFIED** [`WORK_LOG.md:2858-2935`](../../WORK_LOG.md), [`CHANGELOG.md:950-978`](../../CHANGELOG.md).

3. **We already have the tool layer FAC would sell us.** `services/ai_tools.py` is 1,727
   lines holding a curated registry of about 36 typed, permission-checked, bounded tools,
   and it already exports both OpenAI and Anthropic tool schemas. Its own docstring says
   "A future MCP server (if ever built) would enumerate this same TOOL_REGISTRY."
   **VERIFIED** [`remedisys_healthcare_ai/services/ai_tools.py:1-16, 1690, 1703`](../../remedisys_healthcare_ai/services/ai_tools.py).

4. **The current developer path to Frappe is not slow.** Measured on this machine today
   against the running dev site: an authenticated HTTP method call takes **85 ms**, a real
   child-table read takes **78 ms**, a JWT costs **1,483 ms once**, and a `bench execute`
   round trip costs **2,839 ms**. FAC cannot beat 85 ms, because FAC runs inside the same
   Frappe process and adds a hop plus MCP framing on top of it. **VERIFIED** (§11).

5. **There is one real gap, and it is about schema, not speed.** The static DocType JSON
   for Patient Encounter lists 39 fields. The live site has 3 Custom Fields and 1 Property
   Setter on top of it that the file does not show. Reading schema from files is
   quietly incomplete. **VERIFIED** (§11.4). One HTTP call closes that gap today, without FAC.

6. **The thing FAC would actually add is convenience, and it arrives attached to
   liabilities we already wrote rules against.** FAC's audit DocType stores `input_data`
   and `output_data`, so on a PHI site the tool arguments and tool results are persisted
   into a DocType for 180 days by default, with redaction that targets credentials, not
   patient data. **VERIFIED** (§14).

7. **The production LLM does not run in the frontend, so "FAC for the Frontend LLM" means FAC
   inside Frappe.** The Next.js layer holds no model SDK and makes no provider call; it proxies
   to `ask_copilot`, which runs the model and a capped 20-iteration tool loop in-process against
   `TOOL_REGISTRY`. **VERIFIED** (§2.10). This changes the shape of the production question:
   adopting FAC there would not remove a hop, it would **add** one, on every tool call, from a
   Frappe worker back into the same Frappe site.

### 1.2 The two verdicts, kept apart

**PRODUCTION (the Frontend LLM): NO. Do not use FAC.** This is not a close call, and it does not
rest on FAC being poor software. It rests on five things that are properties of our system, not
opinions about theirs:

1. **We already have the tool layer, and it is the right shape.** `services/ai_tools.py` holds
   about 36 typed, bounded, permission-checked tools, wired into the live copilot at
   `api/v1/ai/api.py:1111-1143`. FAC would not add a capability; it would replace a narrow surface
   with a wide one.
2. **Clinical safety is enforced in the tool layer, not in the model.** Our write tools never
   touch the database. They emit suggestions into the physician-review draft (Rule 6). FAC's
   `update_document`, `submit_document` and `delete_document` write immediately, generically,
   across all DocTypes, with `force=True` available and no DocType allowlist.
3. **PHI.** FAC's audit DocType stores `output_data`, so every tool result is persisted for 180
   days by default, with redaction aimed at credentials rather than patient data. Ours stores
   tool **names** only. On a production clinical site that difference is the whole of Rule 10,
   PHI-4, PHI-6 and PHI-8.
4. **Token usage and bounded context.** Our reads are capped in code (`_MAX_LABS = 8`,
   `_MAX_PREV_ENCOUNTERS = 5`, `_MAX_TRANSCRIPT_CHARS = 6000`). A generic `get_document` returns
   the whole record. With up to 20 tool iterations per turn (`_MAX_TOOL_ITERATIONS = 20`,
   `integrations/openai.py:2502`), unbounded reads are a context-budget failure, not a nuisance.
5. **Architecture.** The tool loop runs **in-process** in Frappe. Routing it through FAC turns
   every tool call into a loopback HTTP request from a Frappe worker into the same Frappe site,
   up to 20 times per copilot turn. §25.6.

**DEVELOPMENT (Claude Code): OPTIONAL, and currently unnecessary.** Permissible only on a bench
with no real patient data, `core` plugin only, write tools disabled, and never as the only path
to an answer. As of 2026-09-10 a 200-line helper (`scripts/dev/frappe_probe.sh`) closed three of
FAC's four remaining developer benefits, so the operative recommendation is **do not install it
now**. §21, §22, §24.1.

**The two must not be traded against each other.** A developer convenience is never a reason to
put a dependency in a clinical request path. That separation is the point of §23.

---

## 2. Our Current Architecture

### 2.1 The two repositories

```
/Users/apple/Healthcare_next_app          Next.js 16 clinic/staff app (frontend + BFF)
/Users/apple/marley-bench                 Frappe bench
  apps/frappe, erpnext, healthcare        vendored, never edited
  apps/eb_frappe_jwt                      MIT, JWT auth (ADR-011)
  apps/remedisys_healthcare_ai            our app, MIT, all customisation
```

**VERIFIED.** `apps/` listing, and `required_apps = ["frappe", "erpnext", "healthcare",
"eb_frappe_jwt"]` in [`hooks.py:20`](../../remedisys_healthcare_ai/hooks.py). Our app licence
is MIT ([`license.txt`](../../license.txt)).

### 2.2 The request path in production

```
Browser (React 19)
   |  fetch("/api/...")  same origin, httpOnly cookie rm_access
   v
Next.js route handler          src/app/api/**/route.ts        267 files
   |  Authorization: Bearer <JWT>
   v
Frappe HTTP  /api/method/remedisys_healthcare_ai.api.v1.<domain>.api.<method>
   |
   v
Our whitelisted method         531 @frappe.whitelist functions
   |  require_permission / require_roles, then set_response / set_list_response
   v
Frappe ORM  ->  MariaDB
```

**VERIFIED.**
- 267 `route.ts` files under `src/app/api/`.
- 531 `@frappe.whitelist` occurrences under `remedisys_healthcare_ai/`.
- The only outbound client is `src/lib/api/client.ts`,
  whose first line is "Base Frappe API client, all API files use this, never fetch() directly."
- Auth is Bearer JWT, never a session cookie: `if (token) headers["Authorization"] = "Bearer " + token`
  with the comment "eb_frappe_jwt Bearer auth (ADR-011), never a session cookie".

### 2.3 Authentication, exactly

1. `POST /api/auth/login` calls `getToken(email, password, "web")`, which calls
   `eb_frappe_jwt.api.get_token` (whitelisted `allow_guest=True`).
2. The role is checked **before** any cookie is minted. `deriveFrontendRole` plus
   `isAllowedStaffLogin` reject anyone without an `EB_` staff role, returning `no_valid_role`.
3. Tokens are stored in two `httpOnly`, `SameSite=Strict` cookies, `rm_access` and
   `rm_refresh`. The file says why: "browser JS cannot read them. This blocks XSS token
   theft. SameSite=Strict blocks CSRF at the cookie level, no CSRF token needed."
4. Every route handler starts with `const token = await getAccessToken()` and returns 401
   when it is missing.

**VERIFIED** `src/app/api/auth/login/route.ts`,
`src/lib/auth/cookies.ts`,
`apps/eb_frappe_jwt/eb_frappe_jwt/api.py:146,224,253,314,339`.

**INFERENCE.** The browser never holds a Frappe credential it can read, and never talks to
Frappe directly. That property is the reason §8 and §9 come out the way they do.

### 2.4 The response contract

Our methods do not return Frappe's `{ message: T }` envelope. They use
`set_response()` and `set_list_response()` ([`utils.py:348,376`](../../remedisys_healthcare_ai/utils.py)),
so the frontend has two matching fetchers and a stated rule about which to use.
`client.ts` says it plainly: "Use plain frappeFetch only for third-party Frappe apps
(e.g. eb_frappe_jwt) that still use the standard return-value pattern." The frontend
constitution goes further and titles the section "Which fetcher, the wrong one causes
SILENT DATA LOSS" (`CLAUDE.md:182`).

Shapes:

```
set_response       -> { status: "success", data: T }            | { status: "error", error: { code, message } }
set_list_response  -> { status: "success", data: T[], pagination: { total, page, page_size } }
```

**VERIFIED.**

### 2.5 The Encounter flow, read and write

| Step | Frontend | BFF route | Frappe method |
|---|---|---|---|
| List encounters | Encounters worklist | `GET /api/encounters` | `...encounters.api.list_encounters` |
| Open one | Encounter screen | `GET /api/encounters/[id]` | `...encounters.api.get_encounter` |
| Start from appointment | Check-in | `POST /api/encounters/start` | `...encounters.api.start_encounter` |
| Create | New encounter | `POST /api/encounters` | `...encounters.api.create_encounter` |
| **Save draft (autosave)** | `v3/use-encounter-save.ts` | `PATCH /api/encounters/[id]` | `...encounters.api.save_draft` |
| Sign / complete | Sign dialog | `POST /api/encounters/[id]/complete` | `...encounters.api.complete_encounter` |
| Cancel | Cancel dialog | `POST /api/encounters/[id]/cancel` | `...encounters.api.cancel_encounter` |
| Rx search | Medication picker | `GET /api/encounters/medications` | `...prescriptions.api.list_medications` |
| Allergy add | Allergy tri-state | `POST /api/encounters/allergies` | `...encounters.api.create_allergy` |
| Diagnoses, complaints, surgical history | pickers | `/api/encounters/{diagnoses,complaints,surgical-history}` | `search_*` / `create_*` |
| Treatment plan template | plan picker | `/api/encounters/treatment-plans/[name]` | `get_treatment_plan_template` |

**VERIFIED.** 17 route files under `src/app/api/encounters/`; `save_draft` is reached from
`src/app/api/encounters/[id]/route.ts:52`; the encounter API module is 92,814 bytes with
`save_draft` at [`api/v1/encounters/api.py:1549`](../../remedisys_healthcare_ai/api/v1/encounters/api.py).

Patient-level clinical data lives in separate, deliberately narrow methods:

- `clinical.api`: `list_allergies`, `add_allergy`, `update_allergy`, `remove_allergy`, and the
  same four for conditions, all funnelled through `_require_clinical_write(patient)`
  ([`api/v1/clinical/api.py:95`](../../remedisys_healthcare_ai/api/v1/clinical/api.py)).
- `patients.api`: `get_patient_chart_overview`, `get_patient_medications`,
  `get_patient_immunizations`, `get_patient_visits`, `get_patient_clinical_activity`, plus a
  set of `_batch_*` helpers that fan a list screen out in one call instead of N.
- `prescriptions.api`: `list_patient_prescriptions`, `list_medications`, `get_item_preview`.
- `api/ai/patient_clinical_summary.py`: `get_patient_clinical_summary` and
  `generate_patient_clinical_summary` (ADR-029).

**VERIFIED.** `_fmt_encounter(doc_or_dict, full=False)` at `encounters/api.py:343` is the
single serializer for an encounter, and `_serialize_drug_rx` / `_serialize_lab_rx` at
lines 192 and 225 serialize prescription rows.

### 2.6 Permissions

- `require_permission(doctype, perm, doc=None)` and `require_roles(*allowed)` at
  [`utils.py:138,167`](../../remedisys_healthcare_ai/utils.py) are the gate in every method.
- Encounter writes add domain gates: `_require_assigned_practitioner_or_admin`,
  `_require_cancel_authorized_practitioner`, `_require_any_practitioner`
  (`encounters/api.py:1807,1836,1883`).
- DocPerms for `EB_` roles are rebuilt from a spec on **every** install and migrate:
  `after_install` and `after_migrate` both point at
  `patches.v0.rebuild_eb_role_permissions.execute` ([`hooks.py:106-108`](../../remedisys_healthcare_ai/hooks.py)),
  with a comment explaining that this makes permissions reset-safe.

**VERIFIED.**

### 2.7 Observability

`withFrappeDebug` wraps every route handler, and `logFrappeCall` records every upstream
call. Two things about it matter for this evaluation:

- It is **hard-disabled in production**: `process.env.FRAPPE_DEBUG === "true" && process.env.NODE_ENV !== "production"`,
  with the comment "even if FRAPPE_DEBUG=true is misconfigured in a prod environment, hard-disable".
- It **redacts PHI by shape, not just by name**. Named PHI fields (`transcript`, `prompt`,
  `history`, `audio_b64`) are replaced outright, and *any* string longer than 80 characters
  is replaced with `<redacted, N chars>` because "Long strings are far more likely to be
  clinical prose than a safe short value".

**VERIFIED** `src/lib/api/frappe-debug.ts`.
This is the standard FAC's own audit log will be measured against in §14.

### 2.8 Tests

- Frontend: 81 spec files in `e2e/`, of which 21 are encounter or nurse-encounter specs,
  including `encounter-round-trip.spec.ts`, `encounter-vitals-note-persist.spec.ts` and
  `copilot-phase5-persistence.spec.ts`. **VERIFIED.**
- Backend: 30 test packages under `remedisys_healthcare_ai/tests/`, including
  `tests/encounters/test_encounters.py`. **VERIFIED.**
- A Bruno HTTP collection exists for manual API checks (`bruno/` with per-domain `.bru`
  files and `run-tests.sh`). **VERIFIED.**

### 2.9 The rules that constrain any answer

These are ours, already accepted, and they decide most of this document.

| Rule | Text, shortened | Source |
|---|---|---|
| Rule 4 | "LLMs never see the database." Chain is LLM, tool call, Python function, Frappe REST, DB. | `CLAUDE.md:201` |
| Rule 5 | Never dump full history. Hard token budget. | `CLAUDE.md:209` |
| Rule 6 | Physician in control. AI never auto-applies. | `CLAUDE.md:219` |
| Rule 10 | No PHI in logs, ever. | `CLAUDE.md:288` |
| PHI-6 | Minimum necessary. Widening what a tool can read is an ADR decision, not a convenience. | `CLAUDE.md:9.9` |
| PHI-8 | Still no PHI in logs, Sentry, analytics, or prompts-as-debug. | `CLAUDE.md:9.9` |
| ADR-030 | Curated tool registry allowed. Raw SQL, arbitrary Python, generic unscoped CRUD forbidden. FAC named and rejected. | `docs/adr/adr-030-llm-curated-tool-access.md` |
| ADR-047 | Reporting is custom APIs, not a generic query engine. | `docs/adr/adr-047-...md` |

**VERIFIED.**

---

### 2.10 The production AI runtime, precisely (added v2.0)

This subsection exists because the phrase "Frontend LLM" invites a wrong picture, and the wrong
picture leads to a wrong answer about FAC.

**The picture people expect:**

```
Browser  ->  Next.js  ->  LLM provider          (an LLM running "in the frontend")
```

**What the code actually does. VERIFIED:**

```
Doctor's browser
   |  copilot UI: src/components/narzim/encounter/copilot/real-provider.ts
   |  fetch("/api/ai/suggest"), fetch("/api/ai/chat"), ...
   v
Next.js route handler        src/app/api/ai/*/route.ts      NO model call here
   |  frappeFetch(... "remedisys_healthcare_ai.api.v1.ai.api.ask_copilot")
   v
Frappe whitelisted method    api/v1/ai/api.py:1038  ask_copilot
   |  tools  = ai_tools.build_openai_tools(allow_write=...)      api.py:1111
   |  loop   = integrations/openai.py:2578, capped at 20          openai.py:2502
   |  each call -> ai_tools.execute_tool(...)                     api.py:1143
   v
TOOL_REGISTRY  (in-process Python)  ->  Frappe ORM  ->  MariaDB
   |
   +--> OpenAI gpt-5-mini, via services/llm.py::get_llm_client()
```

Evidence, item by item:

| Claim | Evidence |
|---|---|
| The frontend holds no LLM SDK | `package.json` has no `openai`, `@anthropic-ai/*`, `ai`, or `@ai-sdk/*` dependency |
| The frontend makes no provider call | No file under `src/` matches `api.openai.com`, `api.anthropic.com`, `from "openai"`, `@ai-sdk`, `generateText`, `streamText` |
| The AI routes proxy to Frappe | `src/app/api/ai/chat/route.ts:52` calls `...api.v1.ai.api.ask_copilot`; `suggest/route.ts:33` calls `generate_suggestions`; `encounter-chat/route.ts:33` calls `get_encounter_chat`; `narzim-assistant/send-stream/route.ts:39` streams from `send_message_stream` |
| The tool loop is server-side and in-process | `api/v1/ai/api.py:1111-1143` builds the tool schemas and calls `ai_tools.execute_tool` directly |
| The loop is capped | `_MAX_TOOL_ITERATIONS = 20` at `integrations/openai.py:2502`, consumed by the `for` loop at 2578 |
| Both providers are wired to the same registry | `integrations/openai.py:2651` and `integrations/anthropic.py:819`, both `ask_copilot_agent(..., call_tool)` |

The one genuine exception is audio: the browser streams **direct to Deepgram** (ADR-009) and audio
never reaches Frappe. That is ASR, not the LLM, and FAC has nothing to do with it.

**Why this matters for the FAC question. INFERENCE.** Three consequences follow, and each one
reappears in §25:

1. FAC in production would sit **inside** Frappe, next to the code that would call it. It is not
   a proxy that replaces a hop; it is a hop added to an in-process function call.
2. The frontend is a **surface**, not a runtime. There is no place in the frontend for an MCP
   client to live without first putting a model there, which would be a much larger change than
   adopting FAC.
3. The thing FAC would actually be competing with is `TOOL_REGISTRY` plus `execute_tool`, which is
   a Python dispatch table. That is the comparison §25 makes.

---

## 3. How Claude Code Works Today Without FAC

### 3.1 There is no MCP server for Frappe. At all.

**VERIFIED.**
- No `.mcp.json` in `/Users/apple/Healthcare_next_app` or `/Users/apple/marley-bench`.
- `~/.claude.json` has exactly one global MCP server, `postman`. The only project-level
  server on this machine is `atlassian-mcp-server`, scoped to `/Users/apple/frappe-bench-v16`.
- The `ide` MCP server is configured but failed to connect this session
  ("WebSocket is not open"), which is the same failure recorded on 2026-09-02 in
  [`docs/CLAUDE_CODE_COMMANDS.md:87`](../CLAUDE_CODE_COMMANDS.md).

So today Claude Code reaches Frappe through exactly three doors, and no others.

### 3.2 Door 1: read the source on disk

```
Claude Code  ->  Read / Grep / Glob  ->  .py and .json files
```

This is how schema, hooks, permissions and method bodies get answered now. It is instant
and free. Its limit is that files describe the *code*, not the *site*: see §11.4.

### 3.3 Door 2: `bench` in a shell

```
Claude Code  ->  Bash  ->  bench --site marley.local execute <dotted.path> --kwargs '{...}'
```

Pre-approved in this repo. `apps/remedisys_healthcare_ai/.claude/settings.local.json`
allows `Bash(bench *)`, and `marley-bench/.claude/settings.local.json` allows
`Bash(bench --site marley.local console)`. **VERIFIED.**

Cost measured today: **2,839 ms** for one `frappe.client.get_count` on Patient Encounter,
which returned 1,272. Most of that is Python and Frappe boot, paid again on every call.
**VERIFIED** (§11.1).

### 3.4 Door 3: HTTP with a JWT

```
Claude Code  ->  Bash curl  ->  eb_frappe_jwt.api.get_token         (once, 1,483 ms)
             ->  Bash curl  ->  /api/method/<method> + Bearer token  (85 ms each)
```

**VERIFIED** today against `http://localhost:8003`, which is `FRAPPE_URL` in
`.env.local` and responded 200 to `frappe.ping`. `Healthcare_next_app/.claude/settings.local.json`
pre-approves exactly one `get_token` curl, for `Administrator`.

### 3.5 The real friction, named honestly

It is not latency. It is these four things.

1. **Per-command permission prompts.** `~/.claude/settings.json` has 154 allow rules, and
   a large block of them are single-use `bench --site v16.localhost execute 'frappe.db.sql'
   --kwargs '{"query": "SELECT ..."}'` strings with hand-escaped quotes. Each new query is a
   new string, so it is a new prompt. That is the shape of a workflow that was approved one
   question at a time. **VERIFIED.**
2. **Quoting.** A SQL string inside JSON inside single quotes inside a zsh command is a
   known source of wasted turns. The same allow list shows the escaping needed.
3. **Token plumbing.** Every fresh shell needs a token again, because shell state does not
   persist between tool calls.
4. **No schema-of-record.** Nothing in doors 1 to 3 tells Claude "here is the field list as
   the site sees it" without composing a query first.

**INFERENCE.** Items 1, 2 and 3 are solved by a five-line shell helper plus a handful of
wildcard allow rules. Item 4 is solved by one metadata call. None of the four needs a new
Frappe app. This is the yardstick FAC has to beat.

---

## 4. What FAC Actually Is

In one sentence: **FAC is a Model Context Protocol server that lives inside a Frappe site
and lets an outside AI client read and write that site through named tools.**

It is not an application backend. It is not a frontend gateway. It is a door built for
assistants.

### 4.1 What FAC exposes

24 tools on current `main`, grouped in plugins. **VERIFIED** from the repo README and the
`plugins/core/tools/` directory listing.

| Group | Tools |
|---|---|
| Documents | `get_document`, `list_documents`, `create_document`, `update_document`, `delete_document`, `submit_document` |
| Search | `search`, `search_documents`, `search_doctype`, `search_link`, `fetch` |
| Reports | `report_list`, `report_requirements`, `generate_report` |
| Workflow | `get_pending_approvals`, `run_workflow` |
| Schema | `get_doctype_info` |
| Analytics | `run_python_code`, `run_database_query`, `analyze_business_data` |
| Files | `extract_file_content` |
| Dashboards | `create_dashboard`, `create_dashboard_chart`, `list_user_dashboards` |

Plugins are toggled by `Assistant Core Settings.enabled_plugins_list`, whose **default is
`["core"]`**. So `run_database_query` and `run_python_code` are in the `data_science`
plugin and are **off until switched on**. **VERIFIED** from
`assistant_core/doctype/assistant_core_settings/assistant_core_settings.json`. That is a
fairer picture than "FAC gives an LLM SQL", and the evaluation must say so.

### 4.2 Where FAC sits

```
   AI client (Claude Code, Claude Desktop, ChatGPT, any MCP client)
        |
        |  MCP over Streamable HTTP, protocol version 2025-06-18
        |  OAuth 2.0, dynamic client registration on by default
        v
   Frappe site  ->  frappe_assistant_core app  ->  tool function  ->  Frappe ORM  ->  MariaDB
```

**VERIFIED.** `mcp_transport_type` defaults to `StreamableHTTP` and
`mcp_protocol_version` to `2025-06-18` in Assistant Core Settings;
`enable_dynamic_client_registration` defaults to 1; `frappe_assistant_core/mcp/server.py`
is a POST-only Werkzeug handler registered through Frappe's whitelist, resolving the user
from Frappe's own request context.

### 4.3 Why MCP is involved

MCP solves a boring but real problem: an AI client needs to **discover** what it can do
without being recompiled. Three properties matter.

1. **Self-description.** The client asks "what tools do you have?" and gets names, one-line
   descriptions and JSON schemas. No hand-written docs to go stale.
2. **Structured results.** Results come back as typed JSON, not as text a model must parse
   out of a terminal.
3. **One connection, many calls.** Auth is done once at connect time, not per shell.

**INFERENCE.** Property 3 is the one that maps onto our friction list in §3.5, items 1 and 3.

### 4.4 What FAC does better than a plain API

Not power. **Discoverability and uniformity.** A REST API answers "here is the data" if you
already know the URL. FAC answers "here is what exists, here is its shape, now here is the
data", in one protocol, for any DocType, without anyone writing an endpoint first.

### 4.5 What FAC records

Every call writes an `Assistant Audit Log` row. Fields, read from the DocType JSON:
`action`, `tool_name`, `source_app`, `user`, `status`, `error_type`, `execution_time`,
`timestamp`, `target_doctype`, `target_name`, `client_id`, `session_id`, `ip_address`,
`input_data` (Code), `output_data` (Code), `output_truncated` (Check), `error_message`,
`traceback`. Read permission is System Manager (full) and Auditor (read).
**VERIFIED.** This matters a great deal, and §14 is about it.

---

## 5. Where FAC Is Normally Used

The normal shape is **a human with an AI client, doing work that is exploratory rather than
transactional**.

| Caller | Typical intent | Why FAC fits |
|---|---|---|
| Developer in Claude Code | inspect, verify, debug a site | wants any DocType, unknown in advance |
| Business user in Claude Desktop | "show me last month's unpaid invoices" | wants an answer, not an app |
| Analyst | ad hoc reporting | wants report execution and aggregation |
| Ops or support engineer | "why did this document fail?" | wants error logs and one document at a time |
| An internal assistant an ERP team builds | company-wide Q and A over ERPNext | wants generic coverage cheaply |

Common thread: **the set of questions is not known when the software is written**. That is
exactly when a generic tool beats a purpose-built endpoint, and exactly when a
purpose-built endpoint cannot be written in advance.

The opposite shape is a clinical screen, where the set of questions is fixed, the payload
is regulated, and the response shape is a contract. That is our production path.

---

## 6. Real Examples of FAC Usage

### Example A. Claude Code developer checks one document

```
Developer: "Check Patient Encounter HLC-ENC-2026-00684."

Claude Code
   |  MCP tools/call  get_document { doctype: "Patient Encounter", name: "HLC-ENC-2026-00684" }
   v
FAC  ->  frappe.get_doc  (permission-checked as the connected user)
   v
JSON document back into the model's context
```

**Why it is useful.** One structured call replaces "find the method, compose the curl, mint
a token, parse the envelope". The model receives fields, not a screen.

**The catch for us.** For a Patient Encounter, that JSON *is* PHI, and it lands in two
places at once: the model's context, and `Assistant Audit Log.output_data`. See §14.

### Example B. AI assistant over ERPNext

```
User: "Show me unpaid invoices for Acme Corp."

AI  ->  FAC list_documents { doctype: "Sales Invoice",
                             filters: { customer: "Acme Corp", status: "Unpaid" },
                             fields: [...] }
    ->  Frappe  ->  rows
```

**Why it is useful.** Nobody had to build an "unpaid invoices for a customer" endpoint. The
generic tool plus the model's understanding of the schema covers a long tail of questions
that would never justify their own API.

### Example C. Schema discovery

```
AI: "What fields exist on Patient Encounter?"

FAC get_doctype_info  ->  Frappe metadata (frappe.get_meta)  ->  field list
```

**Why it is useful, concretely for us.** Frappe's live metadata includes Custom Fields and
Property Setters. The DocType JSON on disk does not. On our site that difference is 3 fields
and 1 property override, invisible in the file. **VERIFIED** (§11.4). A model that reads only
the file will write code against a schema that is not the site's schema.

### Example D. Report execution

```
Admin: "Run the Accounts Receivable report for last month."

FAC report_list -> report_requirements -> generate_report  ->  Frappe report engine
```

**Why it is useful.** Frappe reports already encode logic. Executing an existing report is
safer and cheaper than asking a model to re-derive it in SQL.

### Example E. Failure triage on a non-PHI system

```
Engineer: "Why did this submission fail?"

FAC get_document on the failing doc, then list_documents on Error Log
```

**Why it is useful.** Two structured calls, no shell, no quoting.

### Example F. Workflow and approvals

```
Manager: "What is waiting on me?"   ->  FAC get_pending_approvals  ->  run_workflow
```

**Why it is useful.** The tool speaks the domain of the workflow engine, so the model does
not need to know which DocType stores the state.

### 6.1 Where FAC is the wrong abstraction

1. **A production clinical screen.** The Encounter needs a fixed contract, not discovery.
   §8 develops this.
2. **Anything a browser touches.** MCP is not a browser protocol, and the browser must never
   hold a Frappe credential. §9 develops this.
3. **Domain-invariant writes.** `update_document` on `Patient Encounter` would set fields
   without `_require_assigned_practitioner_or_admin`, `_stamp_billing_optout`,
   `_derive_chief_complaint_if_missing`, or the immunization creation in
   `_create_encounter_immunizations`. A generic write is a write around our rules.
   **VERIFIED** those functions exist at `encounters/api.py:1807, 1909, 151, 1731`.
4. **PHI-bearing free-text search.** Prompt injection carried in patient text plus a
   generic query tool is the exact risk ADR-030 was written about.
5. **High-volume machine-to-machine traffic.** MCP is a session protocol for an assistant,
   not a data plane for a UI at scale.

---

## 7. FAC vs Next.js BFF

They are not competitors. They answer different questions.

| | Next.js BFF | FAC |
|---|---|---|
| Who calls it | a browser, on one origin | an AI client, over MCP |
| Caller identity | a logged-in clinician, via `httpOnly` cookie | an OAuth client acting as a Frappe user |
| Question shape | fixed and known at build time | unknown until asked |
| Response shape | a typed contract the UI compiles against | whatever the DocType holds |
| Failure budget | a doctor is waiting | a developer is reading |
| Success measure | correctness and predictability | coverage and discoverability |

**INFERENCE.** A BFF exists to make a small number of calls boringly predictable. FAC exists
to make a large number of calls possible without predicting them. Swapping one for the other
gives up the property that made each worth having.

---

## 8. Why FAC Should Not Sit Behind the BFF

The proposal:

```
Browser  ->  Next.js  ->  BFF  ->  FAC  ->  Frappe        (proposed)
Browser  ->  Next.js  ->  BFF  ->  Frappe                 (today)
```

The honest first question is not "is this bad?" but **"what would it buy?"**

### 8.1 What it would buy

One thing, and only one: our BFF could reach DocTypes and fields for which no whitelisted
method exists, without writing a method. For example, a screen that wants
`Property Setter` rows or a rarely-used ERPNext field would not need a new endpoint.

**INFERENCE.** That benefit is real but small, because writing the method is not the
expensive part. There are already 531 of them, and the pattern is mechanical: a route
handler of about 20 lines plus a whitelisted function.

### 8.2 What it would cost, item by item

The user asked for each of these specifically.

**1. Extra network hop.** Today: BFF to Frappe, one hop, measured at 85 ms.
With FAC: BFF to FAC (HTTP) then FAC to Frappe internals. FAC runs *inside* Frappe, so the
extra cost is MCP framing plus session setup, not a second machine. The point is not that it
is slow. **The point is that it can never be faster than the call it wraps.** **VERIFIED**
by measurement (§11.1) plus FAC's in-process design (§4.2).

**2. MCP protocol overhead.** MCP is a session protocol. It expects initialize, then
`tools/list`, then `tools/call`. A stateless Next.js route handler on serverless has no good
place to keep that session. Either it re-initializes per request, which is pure waste, or it
holds state that Vercel's execution model does not promise to keep.
**INFERENCE**, from FAC's transport being Streamable HTTP with session ids
(`frappe.local.assistant_session_id`) and from our routes being `export const dynamic = "force-dynamic"`
handlers.

**3. OAuth and session handling.** FAC authenticates MCP clients with OAuth 2.0 and dynamic
client registration. We authenticate with `eb_frappe_jwt` Bearer tokens (ADR-011). Putting
FAC in the path means the BFF must hold a *second* kind of credential, for the same user,
against the same site. Two credential systems for one identity is the classic place where a
permission bug hides. **VERIFIED** that both systems exist and differ.

**4. Authentication duplication.** Concretely: `rm_access` (our JWT) authenticates the
clinician to the BFF. Then something must authenticate the BFF to FAC. If that is a service
account, **we have just lost per-user permissions**, and every Frappe permission check now
evaluates the service account instead of the doctor. If it is per-user OAuth, we must run an
OAuth dance per clinician, in addition to the JWT they already have. Neither is good.
**INFERENCE.**

**5. Authorization.** Our domain gates live in the whitelisted methods
(`_require_assigned_practitioner_or_admin`, `_require_cancel_authorized_practitioner`,
`_require_clinical_write`). FAC's generic tools call `frappe.has_permission` and then act.
Routing through FAC would put a code path in production that can write an Encounter field
**without** passing the assigned-practitioner check. **VERIFIED** that our gates exist and
that `update_document` is generic across DocTypes.

**6. Latency.** See item 1. Adds; never subtracts.

**7. Error handling.** `frappeErrResponse` maps Frappe status codes into the exact set the
UI expects, `[400, 401, 403, 404, 409, 417, 422]` pass through and everything else becomes
502, and `frappeErrMessage` digs the human sentence out of `_error_message` and
`_server_messages`. The file records why: preferring `exc_type` once turned "Patient
MRN-2026-0000002 already exists" into the single word "Patient" in the UI. An MCP tool
result is `{ content, isError }`. **All of that mapping would have to be rebuilt from a
weaker signal.** **VERIFIED** `client.ts:28-90`.

**8. Observability.** We would lose the thing described in §2.7. `logFrappeCall` records the
exact dotted method name per call, and PHI is redacted by shape. With FAC in the path the
BFF's log says `tools/call` and the interesting detail moves into
`Assistant Audit Log.input_data` and `output_data`, which is a different system, with
different retention, and no PHI-shaped redaction. **VERIFIED** both sides.

**9. Debugging.** Today a failing screen is traced by grepping one dotted method name across
both repos. With FAC, the method name no longer exists; the call is `update_document` with
arguments. Grep stops working. **INFERENCE.**

**10. Type safety.** Today `frappeFetchSet<Encounter>` types the payload, and `src/types/`
holds the shapes. A generic document tool returns "the DocType, whatever it holds", so the
frontend types become a hope rather than a contract. **VERIFIED** by the generic signatures.

**11. Predictable response schemas.** `set_response` and `set_list_response` are a contract
with a pagination envelope. FAC has no equivalent, because it cannot: it does not know what
your screen needs. **VERIFIED.**

**12. API versioning.** Our methods live under `api/v1/`. That is a version we control. A
generic CRUD surface versions with **the DocType**, which is owned by ERPNext and Healthcare
upstream. A Healthcare release that renames a field would then change our API. **VERIFIED**
that the path is `api/v1/` and that Healthcare is a vendored upstream app.

**13. Domain validation.** The largest item. `save_draft` is not a setter. Around it sit
`_apply_drug_prescriptions`, `_apply_lab_prescriptions`, `_apply_procedure_prescriptions`,
`_apply_therapies`, `_derive_chief_complaint_if_missing`, `_link_vitals_to_encounter`,
`_create_encounter_immunizations`, `_stamp_billing_optout` and the bill-flag helpers
`_bill_defaults_for_company`, `_as_bill_flag`, `_bill_flags_for`, `_attach_bill_flags`.
A generic `update_document` on the same DocType runs **none** of them.
**VERIFIED** at `encounters/api.py:506, 646, 685, 726, 151, 961, 1731, 1909, 249, 268, 284, 294`.

**14. Clinical safety.** Follows from 13. A prescription written without
`_apply_drug_prescriptions` can miss the duplicate-Rx identity check
(`_rx_already_present`, `_rx_identity`, `_rx_strength` at lines 656, 608, 599) and the
allergy conflict logic (`_allergy_conflict`, `ai_tools.py:374`). Those are not conveniences.
**VERIFIED.**

**15. Maintainability.** Two ways to write the same field is worse than one way, even when
both work, because the next bug has two places to hide.

### 8.3 The architectural reason, in one paragraph

A BFF is a **narrowing** layer. Its whole value is that it accepts only the calls the product
makes, in the shapes the product uses, with the checks the domain requires. FAC is a
**widening** layer. Its whole value is that it accepts calls nobody anticipated. Putting a
widening layer inside a narrowing layer deletes the narrowing. What is left is a clinical
product whose write path is "any field on any DocType", audited in a different system, typed
by hope. The problem is not that FAC is low quality. It is that the two layers have opposite
purposes, and composing them keeps the costs of both and the benefit of neither.
**INFERENCE**, built on the verified items above.

### 8.4 The one case that would justify it

**RECOMMENDATION.** If we ever needed a genuine ad hoc query surface *inside the product*,
for example an admin "explore any record" console for internal staff on a non-PHI DocType,
then a FAC-backed route would be the right tool, isolated to that screen, with its own role
gate, and never on a clinical DocType. That is a specific reason. "It would save writing
endpoints" is not.

---

### 8.5 Why not call FAC directly from Next.js

#### 8.5.1 The three options

```
Option 1   Browser  ->  Next.js BFF  ->  FAC  ->  Frappe
Option 2   Browser  ->  FAC  ->  Frappe
Option 3   Browser  ->  Next.js BFF  ->  Frappe          <-- what we have
```

**Option 3 is correct. Option 2 is the worst of the three. Option 1 is §8.**

#### 8.5.2 A real Encounter story

Dr. Ana opens Encounter `HLC-ENC-2026-00684` for a patient with a Paracetamol prescription.
She changes the frequency, the screen autosaves, and she later signs the encounter.

**Option 3, today.** VERIFIED path:

```
1  Browser PATCH /api/encounters/HLC-ENC-2026-00684      cookie rm_access, httpOnly, SameSite=Strict
2  Route handler: token = getAccessToken(); 401 if absent
3  frappeFetchSet("...encounters.api.save_draft", { token, body })
4  Frappe: require_permission -> _require_assigned_practitioner_or_admin
          -> _apply_drug_prescriptions (dedupe, drug_code, bill flags)
          -> _derive_chief_complaint_if_missing
5  set_response -> { status: "success", data }
6  Route returns typed JSON; withFrappeDebug logs one line, PHI redacted
```

**Option 2, browser to FAC.** What has to change:

- The browser needs a credential FAC accepts. That means an OAuth token reachable by page
  JavaScript, which is the exact thing `cookies.ts` was written to prevent: "Both are
  httpOnly, browser JS cannot read them. This blocks XSS token theft." Any XSS on the
  clinical screen now leaks a live Frappe credential. **VERIFIED** rule, **INFERENCE** on the
  consequence.
- Cross-origin. Today the app is same-origin, and `SameSite=Strict` alone stops CSRF with no
  token. Talking to Frappe from the page means CORS, a second origin, and re-solving CSRF.
  **VERIFIED** by the comment in `cookies.ts`.
- The save becomes `update_document`, so steps 4's domain gates and helpers do not run.
  Duplicate prescriptions and allergy conflicts stop being caught server-side.
- PHI moves into the browser's view of a generic API and into `Assistant Audit Log` per
  keystroke-batch, instead of into one narrow method call.
- Retries and caching leave our control. Today the BFF owns them; `/api/encounters?fetch_all=1`
  pages a backend that clamps `page_size` to 100, with `MAX_PAGES` as a runaway guard, because
  a caller once silently lost 100 encounters. **VERIFIED** `src/app/api/encounters/route.ts`.
- Observability splits in two, and the half with the detail is the half with the PHI.

#### 8.5.3 The properties, scored

| Property | Option 1 (BFF to FAC) | Option 2 (Browser to FAC) | Option 3 (today) |
|---|---|---|---|
| Browser security | ok, browser still isolated | **bad**, readable credential | good, `httpOnly` + Strict |
| OAuth complexity | high, two systems | high, in the client | none extra |
| User identity | risk of service account | per user, exposed | per user, JWT, server-held |
| Session management | MCP session in a stateless route | in the page | cookies plus refresh lock |
| MCP fit | poor | very poor | not needed |
| PHI exposure | audit log plus hop | audit log plus browser | narrow, redacted |
| Permission boundary | generic tools bypass domain gates | same, plus client-side | domain gates enforced |
| Predictable clinical API | lost | lost | contract |
| Caching | unclear owner | none | BFF owns it |
| Retries | unclear owner | none | BFF owns it |
| Observability | split | split, worse | one line per call |

**VERIFIED** for Option 3's column; **INFERENCE** for the other two.

#### 8.5.4 Answer

**RECOMMENDATION.** Keep Option 3. It is not "because FAC is not for frontends". It is
because the browser must never hold a credential it can read, and because a clinical write
must pass through code that knows what a prescription is.

---

## 9. Generic FAC Tools vs Remedisys Custom Tools

The question was: prove it from architecture, and do not assume custom tools win.

### 9.1 The same task, both ways

Task: an AI needs a patient's clinical context.

**Generic tools:**

```
list_documents  Patient Encounter   filters {patient}          -> ids
get_document    Patient Encounter   each id                    -> full docs, all fields
list_documents  Drug Prescription   parent in ids              -> rows
get_document    Patient                                        -> allergies, history free text
list_documents  Lab Test            filters {patient}          -> ids
list_documents  Normal Test Result  parent in ids              -> values
list_documents  Vital Signs         filters {patient}          -> rows
                                    ... then the model assembles it
```

Seven or more round trips, each returning whole documents, and the *model* decides what
matters. Every intermediate document is fully in context.

**Our tool today:** `ai_tools.py` already has `_tool_get_previous_encounters`,
`_tool_get_patient_labs`, `_tool_get_lab_analysis`, `_tool_get_encounter_state`, and
`patients.api.get_patient_chart_overview` / `get_patient_medications` /
`get_patient_clinical_activity`. **VERIFIED** at `ai_tools.py:39, 74, 209, 296` and
`patients/api.py:2164, 2349, 2640`.

```
get_encounter_state(encounter)      -> one bounded, shaped context
get_patient_labs()                  -> at most 8 tests, at most 6 results each
get_previous_encounters(n)          -> default 3, max 5
```

The bounds are constants in the file: `_MAX_LABS = 8`, `_MAX_LAB_ITEMS_PER_TEST = 6`,
`_MAX_PREV_ENCOUNTERS = 5`, `_DEFAULT_PREV_ENCOUNTERS = 3`, `_MAX_TRANSCRIPT_CHARS = 6000`.
**VERIFIED** `ai_tools.py:28-32`.

### 9.2 Why the domain tool wins here, from architecture

| Property | Generic | Domain-specific | Evidence |
|---|---|---|---|
| Call count | 7 or more | 1 to 3 | above |
| Latency | serial round trips | one server-side assembly | `_batch_*` helpers already do this for list screens, `patients/api.py:480-880` |
| Tokens | whole documents | bounded projections | Rule 5 budget, the `_MAX_*` constants |
| Duplicated reasoning | the model re-derives "what is relevant" every call | decided once, in reviewed code | ADR-030 |
| Domain validation | none | `_allergy_conflict`, `_rx_already_present` | `ai_tools.py:374, 656` |
| Permission enforcement | role and doc level via `has_permission` | plus `_require_clinical_write`, `_require_encounter_read` | `clinical/api.py:95` |
| Response shape | DocType-shaped | contract-shaped | `set_response` |
| Testability | you test the model's assembly | you test a function | `tests/encounters/` |
| Observability | tool name plus arguments | one named method per intent | `frappe-debug.ts` |
| Clinical safety | a full patient record can enter context | minimum necessary | PHI-6 |
| Accidental exposure | fields nobody asked for arrive anyway | projection is explicit | PHI-6 |

**VERIFIED** for the evidence column. **INFERENCE** for the ranking.

The sharpest single line: a generic `get_document` on `Patient` returns **every** field,
including ones the question did not need. PHI-6 says "an AI call receives the narrowest
patient context that answers the question". A generic getter cannot satisfy PHI-6, because
narrowing is not a thing it does.

### 9.3 The honest case against custom tools

This is real and should not be soft-pedalled.

1. **More code to own.** `ai_tools.py` is 1,727 lines. That is 1,727 lines of our
   maintenance, forever. **VERIFIED.**
2. **Maintenance follows upstream.** A Healthcare field rename breaks our tool, and
   we fix it. A generic tool would have kept working.
3. **Versioning.** Each tool is an interface. Changing its output shape is a breaking change
   for the prompt and the frontend both.
4. **Duplication.** `get_patient_medications` exists in `patients/api.py` and a related
   read exists in the copilot registry. Two places to keep true.
5. **Development effort.** A generic surface covers a long tail for free. Ours covers only
   what we wrote.
6. **The long tail is genuinely uncovered.** Nothing in our 531 methods answers "how many
   Property Setters are on Patient Encounter". We had to compose a query for that today.

### 9.4 When is a custom tool worth writing?

**RECOMMENDATION.** Write one when **two or more** of these hold:

1. The call happens on a **hot, repeated path** (an Encounter open, a worklist load).
2. It needs **domain rules** a generic write would skip (dedupe, allergy conflict, billing
   flags, practitioner gates).
3. It touches **PHI** and must be narrowed to minimum necessary (PHI-6).
4. It needs a **stable response shape** something else compiles or renders against.
5. It replaces **three or more** generic calls with one.
6. It must be **unit tested** as a rule, not as a model behaviour.

Do **not** write one when: the question is one-off, exploratory, developer-facing, on a
non-PHI DocType, or when the answer is "read the schema". Those are exactly the cases a
generic tool serves better, and writing an endpoint for them is waste.

---

## 10. Do We Actually Need Custom Tools?

The real question behind this section is the reverse: **if our tools already expose what
Claude needs, what does FAC add?** Three architectures, judged on that.

### 10.1 Architecture A. Claude Code to our existing methods

```
Claude Code  ->  curl + JWT  ->  531 whitelisted methods  ->  Frappe  ->  MariaDB
```

**Benefits.**
- Zero new software. Works today, measured at 85 ms per call.
- Every call passes our permission gates and returns our contract.
- The dotted method name in the log is greppable in both repos.
- No AGPL, no new DocTypes, no new packages.
- Exercises the **same** code the product uses, so a passing check means the product works.
  That last property is worth more than it sounds: verifying through a different path can
  pass while the product is broken.

**Disadvantages.**
- No discovery. Claude must find the method by grepping, which it does well but not free.
- No live schema tool. The Custom Field gap in §11.4 is real.
- Token plumbing per shell.
- Nothing covers the long tail (arbitrary DocTypes, Property Setters, Error Log queries)
  without composing a call by hand.

**VERIFIED** benefits and disadvantages, from §2, §3 and §11.

### 10.2 Architecture B. Claude Code to FAC generic tools

```
Claude Code  ->  MCP/OAuth  ->  FAC 24 generic tools  ->  Frappe  ->  MariaDB
```

**Benefits.**
- Discovery for free. `tools/list` then `get_doctype_info` answers schema questions from the
  **site**, not from files.
- One auth handshake per session instead of a token per shell.
- Structured JSON results instead of parsed shell output.
- Covers the whole long tail, including DocTypes nobody wrote a method for.
- Report execution (`generate_report`) with no new code.

**Disadvantages.**
- AGPL-3.0 enters the app graph (§14.4).
- 9 DocTypes and 25 extra Python packages on the site. **VERIFIED** `WORK_LOG.md:2895-2897`.
- `Assistant Audit Log` stores `input_data` and `output_data`, so on a PHI site the patient
  data flows into a second store (§14.1).
- `delete_document` exists, calls `frappe.delete_doc(..., force=True)` when asked, has no
  DocType allowlist and no confirmation step. **VERIFIED** from
  `plugins/core/tools/delete_document.py`.
- Generic `update_document` can write an Encounter field without our domain gates (§8.2.13).
- It verifies through a **different path** than the product uses, so a green result does not
  prove the product's path works.
- It contradicts an accepted ADR unless the ADR is superseded first.

### 10.3 Architecture C. Claude Code to FAC to custom Remedisys FAC tools

```
Claude Code  ->  MCP/OAuth  ->  FAC  ->  our tools registered via hooks  ->  Frappe
```

FAC supports this: external Frappe apps contribute tools through the `assistant_tools` and
`assistant_skills` hooks. **VERIFIED** from FAC's README ("Tools travel with apps and survive
upgrades").

**Benefits.**
- Our domain tools, discoverable over a standard protocol, with no transport code of our own.
- FAC handles OAuth, session, framing and the audit row.
- Generic and domain tools sit side by side, so exploration and precision both work.

**Disadvantages.**
- **We would be writing code whose purpose is to plug into an AGPL-3.0 application.**
  Whether that makes our app a derivative work is a legal question, not an engineering one,
  and it is precisely the question ADR-030 flagged. **INFERENCE**, and a lawyer's call.
- Our tools would run inside FAC's audit path, so their arguments and results land in
  `Assistant Audit Log` too. For a clinical tool that is PHI at rest in a new place (PHI-4
  asks whether the erasure path covers it; today it does not).
- We inherit FAC's release cycle for our own developer tooling.
- The generic tools do not go away just because we added good ones. The weakest tool sets
  the risk level.

### 10.4 So what does FAC actually add, precisely?

Stripped of everything available elsewhere, FAC's unique contribution to our stated goal is
**four** things:

1. **Live schema from the site**, including Custom Fields and Property Setters
   (`get_doctype_info`). Real gap, measured in §11.4.
2. **Tool discovery**, so the model does not grep to find the entry point.
3. **One auth per session** instead of a token per shell.
4. **Report execution** without new code.

Everything else on FAC's list we either have (permission-checked reads, structured
responses, audit) or do not want (generic CRUD, SQL, Python execution).

**INFERENCE.** Items 1 to 4 are worth real developer minutes. Items 1 to 3 are also
obtainable from about 150 lines of our own MIT code, because `ai_tools.py` already emits
tool schemas (`ai_tools.py:1690, 1703`) and Frappe already has `frappe.get_meta`. Item 4 is
obtainable with one whitelisted wrapper around `frappe.desk.query_report.run`.

### 10.5 Do we need custom FAC tools?

**RECOMMENDATION. No, not now.** For the developer goal, the generic `get_document`,
`list_documents`, `search_doctype` and `get_doctype_info` are *enough*, because a developer
asking "did this save?" wants the raw row, not a clinical projection. Custom tools earn
their keep when a **model is doing clinical reasoning**, and that path already exists in
`ai_tools.py` and does not use FAC.

**INFERENCE.** Adding custom FAC tools would be building the second copy of a registry we
already have, inside a licence we already flagged, for a use case that does not need it.

---

## 11. Speed & Developer Productivity

### 11.1 Measured, on this machine, today

All three against the running dev site (`http://localhost:8003`, `marley.local`, which
answered `frappe.ping` with 200).

| Operation | Measured | Note |
|---|---|---|
| `bench --site marley.local execute frappe.client.get_count` | **2,839 ms** | returned 1,272 Patient Encounters |
| `eb_frappe_jwt.api.get_token` | **1,483 ms** | once per shell, token length 1,840 |
| `/api/method/frappe.client.get_count` with Bearer | **85 ms** | same result, 1,272 |
| `/api/method/frappe.client.get_list` on Drug Prescription, 3 rows | **78 ms** | real child-table read |
| `/api/method/frappe.ping` with Bearer, 6 samples | **5.6 ms median** (4.8 min, 65.7 first call) | transport plus auth only, no query work |

**VERIFIED.** Numbers are from this session, single runs except the last, warm site. They are not
a benchmark suite; they are the right order of magnitude and the ranking is stable.

**Correction, v2.0.** The 85 ms figure is a *read with real query work* against a 1,272-row table,
not the cost of the HTTP hop. Isolated with `frappe.ping`, an authenticated loopback round trip is
about **5 ms**. This matters for honesty in two directions. It makes the developer story slightly
better than stated (§21), and it makes the anti-FAC latency argument in production **weaker** than
a careless reading of §8.2 would suggest: a co-located FAC would add milliseconds per tool call,
not tens of milliseconds. §25.6 therefore argues the production case on worker capacity and token
budget rather than on raw latency, which is where the real cost sits.

**INFERENCE.** FAC runs in the same Frappe process, so an equivalent FAC `list_documents`
lands in the same 80 ms to 200 ms band, plus MCP framing. **FAC cannot make the network part
faster. There is nothing left to win there.**

### 11.2 Where FAC genuinely saves time

| Cost today | With FAC | Why |
|---|---|---|
| Find the method by grepping 531 candidates | `tools/list` | discovery is a protocol feature |
| Compose curl, escape JSON inside quotes | typed tool arguments | no shell layer |
| One permission prompt per new command string | one MCP approval per tool | the 154-rule allow list is the evidence |
| Mint a token per shell | one OAuth handshake per session | session, not process |
| Read a DocType JSON and hope it is complete | `get_doctype_info` | live metadata, §11.4 |
| Re-derive a report in SQL | `generate_report` | the report already exists |

**VERIFIED** for the "cost today" column (§3.5). **INFERENCE** for the size of the saving.
Realistically this is **seconds to a minute per investigation**, and its real value is fewer
interrupted turns, not fewer milliseconds.

### 11.3 What FAC does not make faster. At all.

None of these touch Frappe, so nothing about FAC changes them.

- `pnpm build` and Next.js or Turbopack compilation.
- Playwright, all 81 e2e specs.
- BFF route testing.
- Browser testing and screenshots.
- TypeScript typechecking and ESLint.
- Backend `pytest` runs.
- `bench migrate` and asset builds.

**INFERENCE**, but a safe one: FAC is a read/write door into a site. It is not a build tool.

**This matters for expectation-setting.** If the felt slowness in a session is
"build, test, browser", FAC changes nothing about it.

### 11.4 The schema gap, measured

```
Patient Encounter, static file  apps/healthcare/.../patient_encounter.json   ->  39 fields
Patient Encounter, live site    Custom Field where dt="Patient Encounter"    ->   3 fields
                                Property Setter where doc_type=...           ->   1 override
```

The 3 custom fields are `custom_encounter_done_by` (Link), `custom_encounter_end`
(Datetime), `custom_patient_email` (Data). **VERIFIED** by query today.

**INFERENCE.** Any answer built only from the JSON file is incomplete by three fields and one
override on this DocType alone. This is the strongest single technical argument for a live
metadata tool. It is not, however, an argument for FAC specifically: the query that produced
those numbers was one HTTP call and took 78 ms.

### 11.5 Four approaches, compared before recommending (CLAUDE.md hard rule)

| # | Approach | Effort | Speed gain | Risk | New licence | Verifies the product's own path |
|---|---|---|---|---|---|---|
| 1 | Status quo plus a probe script and wildcard allow rules | ~1 hour | most of the friction, gone | none | none | yes |
| 2 | FAC on a **PHI-free** bench, `core` plugin only, dev machines only | ~half a day | items in 11.2, all of them | low | AGPL, dev only | no |
| 3 | FAC on the real dev site (what happened on 2026-08-27) | done already | same as 2 | **high**, PHI into audit rows and model context | AGPL on a PHI site | no |
| 4 | Our own MIT read-only MCP server over `TOOL_REGISTRY` plus `frappe.get_meta` | ~2 days | items 1 to 3 of §10.4 | low | none | yes, same code path |
| 5 | FAC behind the BFF, in production | weeks | negative | severe | AGPL in production | no |

**RECOMMENDATION.** Do 1 now. Do 2 if a throwaway bench is acceptable. Plan 4 as the durable
answer, which is the route ADR-030 already permits. Reject 3 and 5.

---

## 12. User Stories

### Story 1. Developer checks persistence

> "Did the prescription frequency actually save?"

**Without FAC, today. This was run for real while writing this document.**

```
1  source a 6-line probe script (mints one JWT)                      1,483 ms, once
2  curl frappe.client.get_list  Drug Prescription
      fields [parent, drug_name, dosage, period], limit 3               78 ms
3  read the answer
```

Actual output:

```json
{"parent":"HLC-ENC-2026-00684","drug_name":"Paracetamol","dosage":null,   "period":"1 Week"}
{"parent":"HLC-ENC-2026-00663","drug_name":"Paracetamol","dosage":"0-1-0","period":"1 Week"}
{"parent":"HLC-ENC-2026-00647","drug_name":"DRUG-PARACETAMOL-3","dosage":"TID","period":"3 Day"}
```

**VERIFIED.** The question was answered in one call, and the answer even shows the failure
case: on `HLC-ENC-2026-00684`, `dosage` is `null` while `period` is set.

**With FAC.**

```
1  MCP tools/call  list_documents { doctype: "Drug Prescription",
                                   filters: { parent: "HLC-ENC-2026-00684" },
                                   fields: [...] }
2  read the answer
```

**Which is faster.** FAC saves **one** step, the token step, and saves composing the curl.
The network time is the same. **INFERENCE.** The honest verdict: FAC is *slightly* faster
here, and a probe script closes almost all of the gap. On a first-ever question about an
unfamiliar DocType, FAC's advantage is larger, because `get_doctype_info` tells it the field
names without a grep.

### Story 2. Developer investigates schema

> "What fields exist on Patient Encounter?"

**Without FAC.** Read `apps/healthcare/.../patient_encounter.json`. Instant, free, and
**incomplete by 3 fields and 1 property override** (§11.4). To be correct, a second query
against `Custom Field` and `Property Setter` is needed, and remembering to do that is the
actual failure mode.

**With FAC.** `get_doctype_info` reads `frappe.get_meta`, which merges Custom Fields and
Property Setters by construction. One call, correct by default.

**Verdict.** **This is FAC's best story.** Not because it is faster, but because it is
*right by default* where the file-reading habit is quietly wrong. **VERIFIED** gap,
**INFERENCE** on FAC closing it.

### Story 3. Developer debugs an API

> "The database contains the medication but the frontend shows empty."

The bug can live in six places:

```
1  Frappe method returns nothing              -> FAC helps: call the method, see the payload
2  Serializer drops the field                 -> FAC helps a little: compare raw doc vs method output
3  set_response vs set_list_response mismatch -> FAC does NOT help: it never uses our envelope
4  wrong fetcher in the frontend              -> FAC does NOT help: TypeScript problem
5  BFF param mapping wrong                    -> FAC does NOT help: it is not in the BFF path
6  React state or render                      -> FAC does NOT help at all
```

**Where FAC stops.** Cases 3, 4, 5 and 6 are the majority of "DB has it, screen does not"
bugs in this codebase, and all four live **above** Frappe. The frontend constitution's own
warning, "Which fetcher, the wrong one causes SILENT DATA LOSS", describes case 4, and FAC
has no view of it. **VERIFIED** `Healthcare_next_app/CLAUDE.md:182`.

The right tool for cases 3 to 5 already exists and is ours: `FRAPPE_DEBUG=true` makes every
upstream call visible in the terminal and in the `x-frappe-calls` response header.
**VERIFIED** `frappe-debug.ts`.

### Story 4. Doctor opens an Encounter

> Doctor: "Open patient encounter."

**Should this call FAC? No.** Reasons, in order of weight:

1. `get_encounter` runs `_link_vitals_to_encounter`, `_fmt_encounter`,
   `_resolve_done_by_names` and the bill-flag helpers. A generic getter runs none of them.
   **VERIFIED** `encounters/api.py:961, 343, 304, 249`.
2. The UI compiles against `Encounter` from `src/types`. A generic getter has no contract.
3. The doctor's identity is a JWT in an `httpOnly` cookie. FAC wants an OAuth client.
4. If FAC is down, the Encounter must still open. Rule 7 says an AI dependency must never
   block a clinical action. Putting FAC in the read path makes an assistant tool a
   dependency of care. **VERIFIED** `CLAUDE.md:248`.

That last point is decisive on its own.

### Story 5. AI clinical assistant

> The assistant needs patient context, medications, allergies, labs, previous encounters.

**Generic FAC route.** Seven or more calls, whole documents, model assembles, whole records
in context, every argument and result written to `Assistant Audit Log`. Fails Rule 5
(bounded context), PHI-6 (minimum necessary) and PHI-8 (no PHI in logs).

**Our route, which already exists.** `ask_copilot` over `TOOL_REGISTRY`: bounded reads
(`_MAX_LABS = 8`), permission checks per tool, write tools that emit suggestions instead of
DB writes, and `AI Prompt Log` recording tool **names** only, no arguments and no results.
**VERIFIED** `ai_tools.py` docstring and constants, ADR-030.

**Verdict.** Domain tools win outright here, and this is not a hypothetical: it is shipped.
The interesting cost is the flip side, recorded in our own constitution: because
`AI Prompt Log` stores tool names only, *why* the AI recommended something cannot be
reconstructed. **VERIFIED** `CLAUDE.md` Rule 6 warning block. FAC's `input_data` and
`output_data` would solve that reconstruction problem, by storing exactly the PHI our rules
forbid storing. That is the trade in one sentence.

### Story 6. Admin analytics

> "How many encounters were created last month?"

Three ways:

1. **FAC `run_database_query`.** One SELECT with a `GROUP BY`. Fast to ask.
   But: System Manager only, `frappe.db.sql` bypasses Frappe's permission engine, no
   row-level filtering, nothing scopes to a patient. **VERIFIED** from
   `plugins/data_science/tools/run_database_query.py` (SELECT-only, keyword blocklist,
   1,000-row cap, `frappe.db.sql(query, as_dict=True)`).
2. **FAC `list_documents` with filters.** Goes through the permission engine. Safe. Awkward
   for aggregation.
3. **Our reporting APIs.** ADR-047 already decided this: reporting is custom APIs, not a
   generic query engine. `encounters/report.py` is 25,030 bytes of exactly this.
   **VERIFIED.**

**Verdict.** For a **developer** asking once, on a **PHI-free** bench, option 1 is genuinely
convenient. For anything a person will read twice, option 3 is already our decided answer.
Option 1 on a PHI site is the specific thing ADR-030 forbids.

---

## 13. Failure Modes

For each: what happened, what Claude sees, what Claude might wrongly conclude, and how we
prevent it.

### 13.1 Serializer mismatch

- **What happened.** `_fmt_encounter` renames or omits a field the raw doc has.
- **Claude sees.** With FAC: the raw document, field present. Screen still empty.
- **Wrong conclusion.** "The data is there, so the frontend is broken." The serializer is
  broken, and it sits between them.
- **Prevention.** Always compare **both**: the raw doc and the method output. Never conclude
  from the raw row alone. **RECOMMENDATION.**

### 13.2 Permission mismatch

- **What happened.** FAC is connected as Administrator. The doctor's role is `EB_Practitioner`.
- **Claude sees.** Data returned successfully.
- **Wrong conclusion.** "Permissions are fine." They are fine *for Administrator*.
- **Prevention.** Verify permissions as the **role under test**, never as Administrator.
  Our DocPerm spec is the source of truth and is rebuilt on every migrate
  (`hooks.py:106-108`). This failure is already live in our history: a non-System-Manager
  creating a user silently loses the `EB_Practitioner` grant
  ([memory: EB role-grant constraint]). **VERIFIED.**

### 13.3 Stale data

- **What happened.** A read happens inside an uncommitted transaction, or before a background
  job runs.
- **Claude sees.** Old values.
- **Wrong conclusion.** "The save failed."
- **Prevention.** Know that `bench console` needs an explicit commit
  ([memory: local dev server]) and that HTTP reads see committed state only. Re-read after a
  short pause before declaring a save broken. **RECOMMENDATION.**

### 13.4 Wrong DocType

- **What happened.** Vitals are on `Vital Signs`, not on `Patient Encounter`. Allergies are a
  text field on `Patient`, not a child table. Vaccines are not a child table either (ADR-019).
- **Claude sees.** Empty result on the DocType it guessed.
- **Wrong conclusion.** "The data was never saved."
- **Prevention.** Use `get_doctype_info` or the DocType JSON `Table` fields first. On
  Patient Encounter those are exactly five: `codification_table`, `drug_prescription`,
  `lab_test_prescription`, `procedure_prescription`, `therapies`. **VERIFIED** today.

### 13.5 Wrong patient

- **What happened.** A generic query with a loose filter, for example
  `patient LIKE 'Joy%'`, which appears verbatim in our own allow list history.
- **Claude sees.** Rows for the wrong person, and they look plausible.
- **Wrong conclusion.** Anything at all, and it is now a clinical error.
- **Prevention.** Filter on the primary key, never on a name. Generic tools make loose
  filters easy, which is a genuine argument against them on a PHI site.
  **VERIFIED** that such filters exist in `~/.claude/settings.json`.

### 13.6 Generic CRUD bypassing domain validation

- **What happened.** `update_document` sets `Drug Prescription.dosage` directly.
- **Claude sees.** Success.
- **Wrong conclusion.** "Writes work, so the feature works." The dedupe, the allergy
  conflict check, the bill flags and the practitioner gate never ran.
- **Prevention.** **Never write through a generic tool on a clinical DocType.** If FAC is
  adopted for development, it should be read-only in practice, and on a PHI-free bench in
  principle. **RECOMMENDATION**, resting on the verified helper list in §8.2.13.

### 13.7 OAuth failure

- **What happened.** The MCP OAuth handshake fails, or dynamic client registration is off.
- **Claude sees.** A connection error, no tools.
- **Wrong conclusion.** "The site is down." The site is fine; the door is shut.
- **Prevention.** Keep door 3 (curl plus JWT) working and documented, so there is always a
  path that does not depend on FAC. **RECOMMENDATION.**

### 13.8 MCP failure

- **What happened.** The MCP transport drops mid-session. Our `ide` server does this
  routinely: "WebSocket is not open", both on 2026-09-02 and in this session. **VERIFIED.**
- **Claude sees.** Tools vanish.
- **Wrong conclusion.** "The capability does not exist."
- **Prevention.** Treat an MCP failure as a connection failure, not a missing capability.
  Fall back to curl. **RECOMMENDATION.**

### 13.9 FAC unavailable

- **What happened.** `server_enabled` is off, or the app is not installed on that site.
- **Claude sees.** 404 or a disabled response.
- **Wrong conclusion.** If FAC were the only verification path: "I cannot check the
  database." That is exactly the dependency Rule 7 forbids creating.
- **Prevention.** FAC is an **accelerator, never the only path**. **RECOMMENDATION.**

### 13.10 BFF failure

- **What happened.** The route handler maps a parameter wrong, or picks the wrong fetcher.
- **Claude sees.** With FAC: correct data in Frappe. Broken screen.
- **Wrong conclusion.** "Backend is fine, so this is a UI bug", when it is a BFF bug, which
  is neither.
- **Prevention.** Reproduce through `/api/...` with the real cookie, not only against
  Frappe. `FRAPPE_DEBUG=true` plus the `x-frappe-calls` header is the tool for this.
  **VERIFIED** that it exists.

### 13.11 Clinical safety issue

- **What happened.** A tool-driven write puts an order on a signed encounter, or a duplicate
  prescription slips past `_rx_already_present`.
- **Claude sees.** Success.
- **Wrong conclusion.** "The safety check passed." It never ran.
- **Prevention.** Writes go through domain methods only. Rule 6 and ADR-030 both say this.
  Note the standing gap already recorded in our own constitution: 5 of 23 write tools are
  auto-applied by the frontend before review (`encounter-screen.tsx:3217-3263`). Adding a
  second generic write path while that is open would compound it. **VERIFIED** `CLAUDE.md` Rule 6.

### 13.12 PHI leakage

- **What happened.** `get_document` on `Patient` returns the whole record. It goes into the
  model's context and into `Assistant Audit Log.output_data`.
- **Claude sees.** Helpful data.
- **Wrong conclusion.** "Reading is harmless." Reading created two new copies of PHI, in two
  systems, one of which (the model context) leaves the site.
- **Prevention.** PHI-free bench for FAC. Field projections, never whole-document reads, when
  a real patient is involved. **RECOMMENDATION.** See §14.

### 13.13 Audit-log exposure

- **What happened.** `Assistant Audit Log` accumulates `input_data` and `output_data` rows
  for 180 days by default, readable by System Manager and by the Auditor role.
- **Claude sees.** Nothing. That is the problem: this failure is silent.
- **Wrong conclusion.** "Audit logging is a compliance feature, so it helps us." It helps
  only if what it stores is allowed to be stored. Ours deliberately stores tool names only,
  for exactly this reason.
- **Prevention.** If FAC ever runs on a PHI site, `audit_log_retention_days` must be set
  deliberately, the Auditor role reviewed, and the store added to the erasure path (PHI-4).
  Better: no PHI site. **VERIFIED** field list and default; **RECOMMENDATION** on the fix.

---

## 14. Security / PHI / HIPAA

Everything in this section is separated into FACT, INFERENCE and RECOMMENDATION, because the
question is legal as well as technical and the two must not be blurred.

### 14.1 What FAC logs

**FACT**, read from FAC source on `main` (GitHub, `buildswithpaul/Frappe_Assistant_Core`),
2026-09-10:

| Item | Finding | Source |
|---|---|---|
| Audit DocType | `Assistant Audit Log` | `assistant_core/doctype/assistant_audit_log/assistant_audit_log.json` |
| `input_data` | stored, `Code` field, tool arguments serialized to JSON | same, plus `utils/audit_trail.py` |
| `output_data` | **stored**, `Code` field, tool results | same |
| Output cap | `_OUTPUT_DATA_MAX_BYTES = 50_000`, truncation flagged by `output_truncated` | `utils/audit_trail.py` |
| Redaction | keys matching sensitive patterns become `***REDACTED***` | `utils/audit_trail.py` |
| Target | `target_doctype`, `target_name` | DocType JSON |
| User | `user` (Link to User) | DocType JSON |
| IP | `ip_address`, plus `client_id`, `session_id` | DocType JSON |
| Retention | `audit_log_retention_days`, default **180** | `assistant_core_settings.json` |
| Access control | System Manager full, **Auditor read** | DocType JSON permissions |
| Disable switch | none found for audit logging itself | `utils/audit_trail.py` |
| Cleanup job | not visible in `audit_trail.py` | same |
| Transport | Streamable HTTP, MCP protocol `2025-06-18` | `assistant_core_settings.json` |
| Auth | OAuth 2.0, dynamic client registration default on | same, plus `utils/oauth_compat.py` |

**FACT.** The redaction is **credential-shaped, not PHI-shaped**. It looks for sensitive
*key names* such as tokens and passwords. It has no concept of a patient name, a diagnosis
or a transcript. Compare our own `frappe-debug.ts`, which redacts named PHI fields **and**
any string over 80 characters precisely because clinical prose is long.

### 14.2 Could real PHI enter each place?

| Place | Could PHI enter? | Basis |
|---|---|---|
| FAC tool arguments | **Yes.** A patient id is PHI-adjacent; a search string can be a patient name. | FACT plus INFERENCE |
| `Assistant Audit Log.output_data` | **Yes, directly.** `get_document` on `Patient` or `Patient Encounter` returns clinical fields, and the result is stored. | FACT |
| Claude Code's context | **Yes.** That is the point of the tool: the document is returned to the client. | FACT |
| The model provider | **Yes**, whatever the client sends onward leaves the site. | INFERENCE |
| Our `AI Prompt Log` | No. It stores tool names only. | FACT, ADR-030 |
| Our BFF terminal logs | No. Redacted by name and by length, and hard-off in production. | FACT, `frappe-debug.ts` |

**INFERENCE.** On a site with real patients, running FAC means accepting that PHI can be
written into a new DocType and read out to an AI client. On our dev sites that is not
theoretical: `remedisys.localhost` held **634 patients** when FAC was installed
(**FACT**, `CHANGELOG.md`), and `marley.local` holds **1,272 Patient Encounters** today
(**FACT**, measured).

### 14.3 Against our own rules

| Rule | Status under FAC on a PHI site |
|---|---|
| Rule 4 (LLMs never see the DB) | Violated if `data_science` is enabled. `frappe.db.sql` on an LLM-authored string is the definition of the thing Rule 4 forbids. |
| Rule 5 (no full history dumping) | Violated by whole-document reads. There is no context budget in a generic getter. |
| Rule 10 / PHI-8 (no PHI in logs) | Violated by `output_data`. |
| PHI-1 (subprocessor register) | An AI client reading PHI out of the site is arguably a new processing path. The active `ComplianceProfile` does not name it. |
| PHI-4 (one erasure path) | `Assistant Audit Log` is a second store of duplicated PHI, and it is not in any erasure path we have. |
| PHI-6 (minimum necessary) | A generic getter cannot narrow. |
| ADR-030 | Explicitly rejects this app by name. |

**FACT** for the rule texts and for FAC's behaviour. **INFERENCE** for the mapping between
them. The mapping is not close to a judgement call: five of seven are direct.

### 14.4 Licence

**FACT.** FAC is AGPL-3.0. Section 13 is titled "Remote Network Interaction; Use with the GNU
General Public License", and begins "Notwithstanding any other provision of this License, if
you modify the Program, your modified version must prominently offer all users interacting
with it remotely through a computer network ... an opportunity to receive the Corresponding
Source". Our app is MIT (`license.txt`).

**INFERENCE, and only that.** Section 13's obligation is written around **modified** versions.
Three positions follow, and they are genuinely different:

1. Installing unmodified FAC on an internal developer bench, never network-served to users, is
   the **lowest-risk** case.
2. Serving a product over a network whose Frappe site has FAC installed raises the question of
   what "the Program" covers. Frappe apps share a process.
3. Writing our own tools **into FAC's plugin hooks** is the highest-risk case, because that is
   the position where a derivative-work argument is easiest to make.

**RECOMMENDATION.** This is a lawyer's question, not an engineer's. Do not resolve it in a
commit message. Until it is answered, keep FAC off any site that serves users, which happens
to be the same conclusion the PHI analysis reaches independently.

### 14.5 On the word "HIPAA"

**FACT.** Our own position is already written down: HIPAA is adopted as "an engineering
standard for technical safeguards only", jurisdiction default is Mexico
(LFPDPPP and NOM-024-SSA3-2010), and the gap analysis lives in
`docs/compliance/HIPAA_READINESS.md` (`CLAUDE.md` §9.9).

**We therefore do not claim FAC is HIPAA compliant or non-compliant.** Compliance is a
property of a deployed system with contracts, not of a package on GitHub. What can be said
without over-reaching:

- **FACT.** FAC provides per-call audit rows with user, IP, timestamp, target document,
  arguments and results. Several audit-control expectations are met by that design.
- **FACT.** Those same rows store clinical content, and our own rules forbid storing it there.
- **INFERENCE.** A BAA-style relationship with the AI client's provider would be required
  before any PHI reached it. Our `ComplianceProfile` mechanism exists for exactly this and
  does not currently name such a path.

### 14.6 Being fair to FAC

The evaluation would be dishonest without this paragraph.

- **FACT.** The SQL tool is SELECT-only, has a keyword blocklist, caps at 1,000 rows and is
  gated on System Manager. Those are real guardrails, and our own 2026-08-27 work log says so.
- **FACT.** `enabled_plugins_list` defaults to `["core"]`, so SQL and Python execution are
  **off** until someone turns them on.
- **FACT.** `FAC Tool Configuration` and `FAC Tool Role Access` (`role`, `allow_access`)
  exist, so individual tools can be gated per role.
- **FACT.** `read_only_db.py`, `execution_limits.py` and `code_execution_subprocess.py` exist
  in `utils/`, which indicates the project takes isolation seriously.
- **FACT.** `output_data` is capped at 50,000 bytes and credential-shaped keys are redacted.

**INFERENCE.** FAC is a competently built app that is being asked, here, to do a job it was
not designed for: operate safely inside a regulated clinical dataset. The mismatch is the
dataset, not the code quality.

---

## 15. Development vs Production

### 15.1 The two paths, drawn

```
DEVELOPMENT  (a developer is waiting, questions are unknown, data must not be real)

   Claude Code
        |  MCP over Streamable HTTP, OAuth, read-oriented tools
        v
   FAC  ->  Frappe  ->  MariaDB          <-- PHI-FREE bench only, seeded/anonymised data
        ^
        |  fallback that must always work
   curl + JWT, bench execute, Read/Grep on source


PRODUCTION  (a doctor is waiting, questions are fixed, data is real)

   Doctor's browser
        |  same origin, httpOnly + SameSite=Strict cookie
        v
   Next.js route handler  (auth, params, mapping, retries, redacted logging)
        |  Authorization: Bearer <eb_frappe_jwt>
        v
   remedisys_healthcare_ai  api/v1/<domain>.api.<method>
        |  require_permission -> domain gates -> domain helpers -> set_response
        v
   Frappe  ->  MariaDB

   The Frontend LLM (production clinical AI) is a loop INSIDE this column:
       ask_copilot -> TOOL_REGISTRY -> Frappe ORM       (section 2.10)
   It is not a separate runtime, and it is the thing section 25 evaluates.

   NO FAC anywhere in this column.
```

### 15.2 Why the two paths must differ

Five reasons, each independent.

1. **Different questions.** Development questions are unknown in advance, so discovery pays.
   Production questions are fixed, so a contract pays.
2. **Different failure budget.** A broken dev tool costs a developer minutes. A broken
   clinical read blocks care. Rule 7 exists for this.
3. **Different data.** A dev bench can hold anonymised data. Production holds PHI. The whole
   PHI analysis in §14 collapses to nothing on a PHI-free bench, and to a great deal on a
   real one.
4. **Different auditors.** Dev-tool audit rows are noise. Clinical audit rows are evidence,
   and ours are deliberately content-free.
5. **Different licences in scope.** AGPL §13 turns on network-serving users. A developer
   laptop does not serve users.

**INFERENCE**, built on the verified facts above. This is the same shape as every sane
system: a debugger is not shipped inside the product.

---

## 16. Architecture Comparison

Scale: **good**, **ok**, **poor**, **bad**. "Custom Tools" means our existing
`TOOL_REGISTRY` plus the 531 whitelisted methods, reached however.

**v2.0.** A column has been added for the question that actually matters, **FAC as the tool layer
for the production Frontend LLM**. It is scored from §25, where every cell has a measurement or a
file reference behind it.

| Capability | Current System | FAC for Claude Code (PHI-free bench) | FAC behind BFF | **FAC for the production Frontend LLM** | Custom Tools |
|---|---|---|---|---|---|
| Raw speed | good, ~5 ms per hop, 85 ms with query work | good, same process plus framing | poor, adds a hop | **poor**, ~5 ms x up to 20 hops per turn | good, in-process call |
| Token usage per turn | not applicable | not applicable | not applicable | **bad**, 373x measured on the worst record, 2.7x over budget on a plausible one | good, bounded by `_MAX_*` constants |
| Developer speed | ok, friction is prompts and quoting | **good**, discovery plus one auth | poor | not applicable | ok |
| Simplicity | good, one client, one contract | ok, one new app | bad, two protocols | poor, two tool layers or a rewrite | good |
| Developer experience | ok | **good** | poor | not applicable | ok |
| Schema inspection | ok, `probe meta` reads live metadata | **good**, live metadata | ok | not applicable | ok |
| DB inspection | ok, needs a composed call | **good** | not applicable | not applicable | ok |
| API verification | **good**, exercises the real path | poor, different path | poor | poor | good |
| Generic CRUD | none by design | good, and that is the risk | bad | **bad**, `delete_document` force=True, no allowlist | none by design |
| Type safety | **good**, typed fetchers plus `src/types` | poor | poor | poor, DocType-shaped results | good |
| Security | good, server-held JWT | ok on a PHI-free bench | bad | bad, generic writes on clinical DocTypes | good |
| PHI handling | good, redacted by name and length | **bad on a PHI site**, fine on a clean one | bad | **bad**, `output_data` retained 180 days by default | good, bounded, names-only audit |
| Permissions | good, role plus domain gates | ok, role plus doc level only | poor | **poor**, no subject scoping | good, encounter and patient mandatory |
| Clinical safety | good, domain helpers always run | not applicable if read-only | bad | **bad**, no allergy or duplicate checks, no review step | good |
| Maintainability | good, one path | ok, plus an upstream app | bad | poor, AGPL upstream in a clinical path | ok, 1,727 lines ours |
| Scalability | good | not a data plane | poor | **poor**, nested requests against 25 workers | good |
| Testing | good, 81 e2e plus 30 test packages | ok | poor | poor, model choice is the boundary | good, tools unit-testable |
| Observability | **good**, per-method line, PHI-safe | ok, audit rows, PHI-unsafe | poor, split | ok, richer rows but PHI-unsafe | good, names-only |
| Failure isolation | good | **good**, dev only, fallback exists | bad, product depends on it | **bad**, Rule 7: an AI dependency in a clinical path | good |
| Licence exposure | none, MIT | AGPL, dev only | AGPL in production | AGPL in production | none |
| Contradicts an ADR | no | yes, until ADR-030 is superseded | yes | **yes**, ADR-030 head on | no |

**VERIFIED** for the Current System column. **INFERENCE** for the rest.

Read the table by row, not by column total.

- **For Claude Code on a clean bench**, FAC wins two rows and draws a third: DB inspection,
  developer experience, and schema inspection (which our own `probe meta` now also covers). That
  is the whole case for it, and §21 shows the case is now thin.
- **For the production Frontend LLM**, FAC loses or draws **every single row**. There is no cell
  in that column where it is the better choice, and eight of them are marked bad. §25.

---

## 17. Recommended Architecture

```
+---------------------------- DEVELOPMENT ----------------------------------+
|                                                                          |
|   Claude Code                                                            |
|      |                                                                   |
|      |  (1) always available, never removed                              |
|      +--> Read / Grep on source          instant, free                   |
|      +--> curl + JWT via probe script    85 ms per call                  |
|      +--> bench execute                  2.8 s per call, for jobs/patches|
|      |                                                                   |
|      |  (2) optional accelerator, PHI-FREE bench only                    |
|      +--> MCP ---> FAC (core plugin only, data_science OFF)              |
|                      |                                                   |
|                      v                                                   |
|              Frappe (dev site, anonymised data)  ->  MariaDB             |
|                                                                          |
|   Rule: FAC is never the only path to an answer.                         |
+--------------------------------------------------------------------------+

+---------------------------- PRODUCTION -----------------------------------+
|                                                                          |
|   Doctor's browser                                                       |
|      |  httpOnly + SameSite=Strict cookie, same origin                   |
|      v                                                                   |
|   Next.js BFF        src/app/api/**/route.ts                             |
|      |  Bearer JWT (eb_frappe_jwt, ADR-011)                              |
|      v                                                                   |
|   remedisys_healthcare_ai   api/v1/<domain>.api.<method>                 |
|      |  require_permission -> domain gates -> helpers -> set_response    |
|      v                                                                   |
|   Frappe  ->  MariaDB                                                    |
|                                                                          |
|   THE FRONTEND LLM (production clinical AI) keeps its own path, unchanged:|
|                                                                          |
|     Doctor's browser  (copilot UI)                                       |
|        |  fetch("/api/ai/suggest" | "/api/ai/chat")                      |
|        v                                                                 |
|     Next.js /api/ai/*   proxy only, NO model call here                   |
|        |  Bearer JWT                                                     |
|        v                                                                 |
|     Frappe  ask_copilot   (api/v1/ai/api.py:1038)                        |
|        |  in-process Python call per tool, loop capped at 20             |
|        v                                                                 |
|     TOOL_REGISTRY  (36 typed, bounded, permission-checked tools)         |
|        |     writes emit SUGGESTIONS, never DB mutations (Rule 6)        |
|        v                                                                 |
|     Frappe ORM  ->  MariaDB          + OpenAI gpt-5-mini via llm.py      |
|                                                                          |
|   FAC appears nowhere in this box. Not as a replacement for the registry,|
|   and not alongside it. See section 25.                                  |
+--------------------------------------------------------------------------+
```

### 17.1 The single most important line

**FAC, if adopted at all, is a developer instrument on a bench with no real patients. It is not
part of the product, it is not the tool layer for the Frontend LLM, and it is not the only way to
answer a question.**

The two paths differ because the callers differ. A developer asking an unplanned question benefits
from a wide, generic surface. A clinical model acting on a real child needs a narrow one, and the
narrowness is the safety feature (§25.3, §25.7).

---

## 18. Adoption Plan

Ordered by value per hour. Steps 1 and 2 are worth doing regardless of what is decided about
FAC, which is itself a finding.

### Step 1. Close the ADR contradiction. Half an hour. Do this first.

FAC 2.5.1 is installed on `remedisys.localhost` in direct contradiction of an accepted ADR,
and has been since 2026-08-27. Pick one:

- **Remove it** from that site, and ADR-030 stands as written; or
- **Write a new ADR** (next free number after ADR-062) recording the decision to permit FAC for development only, superseding
  ADR-030's blanket rejection while keeping its ban on SQL, Python and generic CRUD in
  PHI-bearing flows.

**RECOMMENDATION:** a new ADR, scoped exactly as in §17. Our own work log already says why:
"A merged ADR that the live site disproves is worse than either outcome on its own, because it
teaches readers that ADRs in docs/adr/ describe intentions rather than reality."

### Step 2. Take the free developer-speed wins. About one hour. No FAC needed.

1. Commit the probe script (the one used in §12, Story 1) as
   `scripts/dev/frappe_probe.sh`, so a token and a call are one line, not five.
2. Add **wildcard** allow rules instead of per-command strings, for example
   `Bash(bench --site marley.local execute *)` and a probe-script rule. The 154-rule list in
   `~/.claude/settings.json` is the evidence that per-command approval does not scale.
3. Add a schema helper that reads `frappe.get_meta`, not the JSON file, so the Custom Field
   gap in §11.4 stops being a trap.
4. Record `FRAPPE_DEBUG=true` in the debugging section of the docs as the first move for any
   "DB has it, screen does not" bug, because §12 Story 3 shows FAC does not help there.

**INFERENCE.** These four remove three of the four friction items named in §3.5, at
essentially no risk.

### Step 3. If FAC is wanted, install it correctly. Half a day.

Preconditions, all of them:

1. A **separate PHI-free bench** or site. Seeded or anonymised data only. Not
   `remedisys.localhost`, not `marley.local`.
2. `enabled_plugins_list` stays `["core"]`. `data_science` stays off, so no
   `run_database_query` and no `run_python_code`.
3. Use `FAC Tool Configuration` and `FAC Tool Role Access` to disable `delete_document`,
   `create_document`, `update_document` and `submit_document`. Read-only in practice.
4. `audit_log_retention_days` set deliberately, and reviewed.
5. Never on a site reachable by patients or clinicians.
6. Watch for the `bench get-app` trap that already bit us once: it rewrites `sites/apps.txt`
   from folder names and silently dropped `healthcare`. Back up `apps.txt` first, and do not
   trust the exit code of a piped `bench` command. **VERIFIED** `WORK_LOG.md:2866-2890`.

### Step 4. Build the durable answer. About two days, when it is worth it.

An MIT, read-only MCP server in our own app, over the registry we already have.

```
Claude Code  ->  MCP  ->  remedisys_healthcare_ai/mcp/  ->  TOOL_REGISTRY (ai_tools.py)
                                                        ->  frappe.get_meta  (schema)
                                                        ->  api/v1 read methods
```

Why this is the better end state: it is the route **ADR-030 already permits** ("An MCP
interface as a transport over the SAME registry"); `ai_tools.py` already emits tool schemas
at lines 1690 and 1703; it stays MIT; the audit story stays ours and stays content-free; and
crucially **it verifies through the same code the product uses**, which FAC never can.

**RECOMMENDATION.** Do not start Step 4 until Steps 1 and 2 are done and someone has felt the
remaining friction for a week. It may turn out that Steps 1 and 2 were enough.

---

## 19. Risks & Mitigations

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| 0a | **FAC adopted as the Frontend LLM's tool layer**, and a generic write reaches the chart with no allergy check and no physician review | would follow directly from adoption | **severe, clinical** | Do not adopt in production. Rule 6 and ADR-030 already forbid it; §25.3 and §25.8 give the mechanism |
| 0b | **Context budget blown by an unbounded generic read**, producing a confident partly-informed suggestion | high, and silent | **severe, clinical** | Bounds stay in code (`_MAX_*`), not in a tool argument. Measured 373x / 76x over budget, §25.7 |
| 0c | **A developer convenience is used as the argument for a production dependency** | this is how it usually happens | high | Keep the two verdicts structurally apart (§20.1.a versus §20.1.b, §23) |
| 1 | PHI reaches `Assistant Audit Log` on a real site | high if installed on a PHI site | severe | PHI-free bench only (§18 Step 3.1) |
| 2 | PHI reaches the model provider through a generic read | high | severe | PHI-free bench; field projections, never whole documents |
| 3 | AGPL obligations reach our MIT product | unclear, and that is the problem | severe | keep FAC off user-serving sites; get a legal answer before anything else |
| 4 | A generic write bypasses a domain rule | medium | severe (clinical) | disable write tools; never write clinical DocTypes generically |
| 5 | `data_science` plugin switched on later "just to check something" | medium | severe | write it into the ADR; audit `enabled_plugins_list` in review |
| 6 | Claude concludes the product works because FAC's path worked | **high** | high | §13.1 and §13.10; always verify through `/api/...` too |
| 7 | FAC becomes the only path, then breaks | medium | medium | keep doors 1 to 3 documented and working (§17) |
| 8 | The bench breaks during install, as on 2026-08-27 | medium | medium | back up `sites/apps.txt`; verify every app imports; do not trust piped exit codes |
| 9 | Upstream churn in an AGPL dependency we do not control | medium | low on a dev bench | pin the version; dev only |
| 10 | Two tool registries drift apart | medium if custom FAC tools are written | medium | do not write custom FAC tools (§10.5) |
| 11 | The ADR contradiction stays open and ADRs stop being trusted | **already happening** | high | §18 Step 1, this week |

---

## 20. Final Verdict

### 20.1 The choice

> **v2.0 restructure.** This section used to answer one question. It now answers two, and they must
> not be merged. **The production answer is the important one.**

#### 20.1.a Production, the Frontend LLM: A. Do not use FAC.

**Should Remedisys use FAC in production for the Frontend LLM? No.** Not replacing
`TOOL_REGISTRY`, and not alongside it. §25 is the evidence. The four reasons that would each be
sufficient on their own:

1. **Clinical safety.** Our write tools perform zero DB mutations and emit suggestions into
   physician review. FAC's write generically and immediately, with no allergy check
   (`_allergy_conflict`), no duplicate check (`_rx_already_present`), and no review step.
2. **Token budget, measured.** A generic read of one patient's encounter history on this site is
   **302,056 tokens** against our bounded **810**. That is 373x, and 76x the Rule 5 budget of
   4,000. On a plausible 40-encounter chronic patient it is still 2.7x over budget.
3. **PHI.** `Assistant Audit Log.output_data` stores tool results for 180 days by default, with
   credential-shaped redaction, readable by the Auditor role, in no erasure path. Ours stores tool
   names. That is Rule 10, PHI-4, PHI-6 and PHI-8 in one field.
4. **Subject scoping.** `execute_tool(name, args, *, encounter, patient, ...)` makes cross-patient
   access a type error. A generic tool cannot express that, so for a System Manager it reaches every
   patient on the site.

FAC wins 2 of 10 production dimensions: long-tail reach, and reconstructable provenance. Both are
answered better by our own roadmap, with one new curated tool and the provenance record that is
already a P0 item. Neither is a reason to adopt FAC.

#### 20.1.b Development, Claude Code: B. Optional, and currently unnecessary.

**B. Use FAC only for Claude Code development.** With one hard condition and one caveat. **This is
a tooling preference, not an architecture decision, and it carries no weight in 20.1.a.**

> **v1.1 amendment, same day.** After §21 to §24, read this as **B in its weakest form:
> OPTIONAL, and currently unnecessary.** The caveat below stopped being hypothetical: the ninety
> minutes of free work was done on 2026-09-10, and it closed three of FAC's four benefits. So the
> operative recommendation today is **do not install FAC**, and revisit only against the four
> triggers in §24.1.

- **Condition.** Only on a bench or site with **no real patient data**, with `core` as the
  only enabled plugin and write tools disabled. On a PHI-bearing site the answer is **A, do
  not use FAC**, and that includes `remedisys.localhost` as it stands today with 634 patients.
- **Caveat.** Do §18 Steps 1 and 2 first. They cost about ninety minutes, carry no risk, and
  remove most of the friction FAC is being considered for. If the remaining friction is small
  after that, **A** becomes the right answer by default, and nothing is lost.

**Not C** (production): §8, §8.5 and now §25, which is the decisive one. **Not D** (FAC after
custom tools): the custom tools already exist and are wired into the live copilot, so they remove
the reason to add FAC for clinical work rather than create it. **E** (optional secondary interface)
is the correct **long-term** shape for *developer* access, but the interface should be **ours**
(§18 Step 4, §22.2 "B-dev"), not FAC.

### 20.2 The eleven questions, answered directly

**1. Where should FAC be used?**
At most, on a developer machine, against a PHI-free Frappe site, as an MCP server for Claude Code,
for reading and inspecting: schema, documents, errors, reports. **Nowhere in the product**, and
specifically not as the tool layer for the Frontend LLM. As of 2026-09-10 even the developer case is
covered by `scripts/dev/frappe_probe.sh`, so the practical answer is "nowhere yet".

**2. Where should FAC NOT be used?**
**As the tool layer for the Frontend LLM, our production clinical AI (§25).** Also: in the browser;
in the Next.js BFF; in any production request path; on any site holding real patient data; as a
write path to a clinical DocType; and as the only way to check something.

**3. Why should FAC not sit inside our BFF unless there is a specific reason?**
Because a BFF's value is narrowing and FAC's value is widening, and nesting them keeps both
costs and neither benefit. Concretely: it would need a second credential system beside
`eb_frappe_jwt`, it would destroy `frappeErrResponse`'s status mapping and
`frappeFetchSet<T>`'s typing, it would move the interesting log detail from a PHI-redacted
terminal line into a PHI-storing DocType, it would let an Encounter field be written without
`_require_assigned_practitioner_or_admin` or `_apply_drug_prescriptions`, and it would version
our API with upstream Healthcare DocTypes instead of `api/v1/`. A specific reason would look
like "an internal-only explore-any-record console on non-PHI DocTypes". "It saves writing
endpoints" is not a reason; we have 531 and the pattern is 20 lines.

**4. Why might custom Remedisys tools be better than generic FAC tools for clinical
workflows?**
Because a clinical read is not a document fetch. One `get_encounter_state` replaces seven
generic calls, returns a bounded projection (`_MAX_LABS = 8`, `_MAX_PREV_ENCOUNTERS = 5`),
satisfies PHI-6's minimum-necessary rule which a whole-document getter cannot, runs the
allergy conflict and duplicate-Rx checks, enforces `_require_clinical_write` on top of role
permissions, returns a shape the UI compiles against, and can be unit tested as a rule rather
than hoped for as a model behaviour. The disadvantages are real too: 1,727 lines we maintain,
upstream renames that break us, and a long tail we simply do not cover.

**5. Do we actually need custom FAC tools?**
No. For developer work the generic read tools are the point, and for clinical work we already
have `TOOL_REGISTRY`. Writing tools into FAC's plugin hooks would duplicate a registry we own
and put our code inside an AGPL app, which is the worst version of the licence question.

**6. What can FAC do for Claude Code that our current system cannot do efficiently?**
Four things, and they are the entire case: live schema including Custom Fields and Property
Setters, which our file-reading habit gets **wrong** by 3 fields and 1 override on Patient
Encounter alone; tool discovery, so the entry point is not found by grepping 531 methods; one
authentication per session instead of a 1,483 ms token per shell; and executing an existing
Frappe report without new code.

**7. What can our current system do better than FAC?**
Verify the product's actual path, which is the only kind of verification that proves anything.
Type the payload. Map errors to the exact statuses the UI expects. Log every call with PHI
redacted by name **and** by length, and hard-off in production. Enforce domain rules on every
write. Keep every credential server-side. Stay MIT. Stay one system.

**8. What would we lose by not using FAC?**
Convenience, mostly. Some minutes per investigation, the discovery step, and the schema-safety
net. Nothing that blocks a task, and nothing a developer cannot get from one HTTP call and a
probe script.

**9. What would we risk by using FAC?**
On a PHI-free bench: an AGPL dependency on developer machines, 25 packages, 9 DocTypes, an
open ADR contradiction, and the ever-present temptation to switch `data_science` on. On a PHI
site: patient data written into `Assistant Audit Log.output_data` for 180 days by default with
credential-shaped redaction only, whole patient records entering a model's context, a generic
`delete_document` with `force=True` and no DocType allowlist, and direct conflict with Rules
4, 5 and 10 and with PHI-1, PHI-4, PHI-6 and PHI-8.

**10. What is the best approach for Remedisys right now?**
This week, in this order: (a) resolve the ADR-030 contradiction, ideally by writing a new ADR
scoped to development only; (b) spend an hour on the probe script, wildcard allow rules, a
`get_meta` schema helper, and writing `FRAPPE_DEBUG=true` into the debugging playbook;
(c) only then decide whether FAC on a throwaway PHI-free bench is still worth half a day.
Do not touch production. Do not install FAC on any site with patients.

**11. What could the architecture evolve into later?**
An MIT, read-only MCP server inside `remedisys_healthcare_ai`, enumerating the same
`TOOL_REGISTRY` the copilot uses, plus a live-metadata tool. ADR-030 already permits exactly
this, and `ai_tools.py` already emits the schemas for it. That gives us MCP's discovery and
one-auth ergonomics with our own licence, our own audit rules, and, uniquely, verification
through the same code path the product runs. If that ships, FAC has no remaining role here.

### 20.3 One paragraph, if only one is read

**Production first.** The Frontend LLM already has the right tool layer, and it is ours: 36 typed
tools whose reads are capped in code, whose writes cannot touch the database, and whose every call
is scoped to one encounter and one patient by the function signature. Replacing that with FAC's 24
generic tools would cost 373x more context on the worst record on this site, would write patient
data into a 180-day audit log our erasure path does not reach, would let a model write a
prescription with no allergy check and no physician review, and would put an AGPL dependency in a
clinical request path that Rule 7 says must never depend on an AI component. FAC wins two
production dimensions out of ten, and our own roadmap answers both better. **So: no FAC in
production.**

**Developer tooling, separately and much less importantly.** Our developer path to Frappe is
already fast: about 5 ms per authenticated hop, 85 ms for a real read, measured today.
What is slow is composing calls, approving them one at a time, and reading schema from files
that are quietly incomplete. FAC fixes the second and third of those, and it arrives carrying
AGPL-3.0, generic delete and update tools, and an audit DocType that stores tool results,
which on a site with 634 patients is PHI at rest in a new place. So use it, if at all, exactly
where those costs are zero: a developer's PHI-free bench, read-only, never in the product, and
never as the only way to check an answer. And do the ninety minutes of free work first,
because it may be all that was needed.

---

---

## 21. Incremental Value Test

> Added in v1.1, 2026-09-10. This section replaces "is FAC useful?" with the only question that
> should decide it: **what does FAC provide that we do not already have, or cannot get with a
> small amount of our own code?**
>
> Important context for reading this section: on 2026-09-10, after the body of this paper was
> written, `scripts/dev/frappe_probe.sh` was written and tested. Several rows below changed
> verdict because of it. That is the honest answer to the incremental-value question: the gap FAC
> was being considered for was mostly a **missing 200-line helper**, not a missing architecture.

### 21.1 The rule applied

A capability counts as a **FAC benefit** only if all four are true:

1. It is not already available in our stack.
2. MCP alone (without FAC) would not give it.
3. Our `TOOL_REGISTRY` would not give it.
4. A small script, helper, or one whitelisted method would not give it.

If any one of those fails, it is not a reason to add an architectural dependency.

### 21.2 Task by task

Cost figures are measured (§11.1). "probe" means `scripts/dev/frappe_probe.sh`.

| Task | Current workflow | FAC workflow | Extra FAC benefit | Can existing code solve it? | Verdict |
|---|---|---|---|---|---|
| **DocType discovery** | `probe rows "DocType" '{"module":"Healthcare"}' '["name"]'`, or Grep the app tree | `search_doctype`, `tools/list` | Slightly better phrasing. Nothing you cannot ask for | **Yes**, already shipped | **Existing is enough** |
| **Live schema discovery** | `probe meta "Patient Encounter"` reads `frappe.get_meta`, so Custom Fields and Property Setters are merged | `get_doctype_info` | **None any more.** This was FAC's single strongest row before 2026-09-10 | **Yes**, one whitelisted endpoint we already had | **Existing is enough (newly)** |
| **Document inspection** | `probe doc "Patient Encounter" HLC-ENC-2026-00684` | `get_document` | None. Same REST resource underneath | **Yes** | **Existing is enough** |
| **Database verification** | `probe count`, `probe rows` (78 ms to 85 ms) | `list_documents`, or `run_database_query` if `data_science` is on | Aggregation in one SELECT, at the cost of bypassing the permission engine | **Yes** for filtered reads; aggregation belongs in a report API (ADR-047) | **Existing is enough** |
| **Child-table inspection** | `probe child "Drug Prescription" "Patient Encounter" <name>`, which supplies `parent` **and** `parenttype` for you | `list_documents` with hand-written filters | None. The forgettable part (`parenttype`) is now encoded in the helper | **Yes** | **Existing is enough** |
| **Persistence verification** | One `probe child` call. This is Story 1, and it found a real `dosage: null` | One `list_documents` call | Saves composing the call, which the helper already saves | **Yes** | **Existing is enough** |
| **API debugging** | `FRAPPE_DEBUG=true` prints every upstream call with its dotted method, body, status and duration; `x-frappe-calls` header in the browser | FAC has no view of our BFF at all | **Negative.** FAC cannot see the layer where these bugs live | **Yes**, and only ours can | **Existing is strictly better** |
| **Permission inspection** | `probe rows "Custom DocPerm" '{"parent":"Patient Encounter"}'`; source of truth is `patches/v0/eb_docperm_spec.json` | `list_documents` on the same table | None. FAC has no permission-introspection tool | **Yes** | **Existing is enough** |
| **Authentication** | One cached token, 40 minutes, one prefix allow rule | One OAuth handshake per session | **None any more.** The token cache removed the per-shell cost | **Yes**, newly | **Existing is enough (newly)** |
| **API response inspection** | `probe call <dotted.method> '{...}'` returns our real `set_response` envelope | FAC never calls our methods, so it never sees our envelope | **Negative.** FAC cannot verify the contract the frontend compiles against | **Yes**, and only ours can | **Existing is strictly better** |
| **Backend code understanding** | Read and Grep on 534 Python files. Instant, free | Not a code tool | None | **Yes** | **Existing is enough** |
| **Running backend methods** | `probe call` for whitelisted methods; `bench execute` (2.8 s) for anything needing app context, patches or jobs | Cannot run a whitelisted method at all; only its own tools | **Negative** | **Yes** | **Existing is strictly better** |
| **Creating test data** | `scripts/seed/`, `bench execute` | `create_document`, generic across DocTypes | Faster to type, and it **skips every domain helper** (`_apply_drug_prescriptions`, bill flags, immunization creation) | **Yes**, and the seed path is the only one that produces valid clinical data | **Existing is strictly better** |
| **Modifying data** | Domain method via `probe call`, or `bench execute` | `update_document`, `submit_document`, `delete_document` with `force=True` | Faster, and unsafe. This is failure mode 13.6 | **Yes** | **Existing is strictly better** |
| **Running tests** | `pytest`, `bench run-tests` | Not a test runner | None | **Yes** | **Not applicable to FAC** |
| **E2E verification** | 81 Playwright specs | Cannot drive a browser | None | **Yes** | **Not applicable to FAC** |
| **Frontend debugging** | React DevTools, `FRAPPE_DEBUG`, the `x-frappe-calls` header | No view of the frontend | None | **Yes** | **Not applicable to FAC** |

**Tally.** Of 17 developer tasks: **existing is enough on 9**, **existing is strictly better on 6**,
**not applicable to FAC on 3** (with overlap where "not applicable" is also "existing is enough").
**FAC provides a unique, unmatched benefit on zero of the 17**, as of 2026-09-10.

### 21.3 The four candidate benefits, put through the five questions

These were the four surviving benefits named in §10.4. Each is now tested properly.

**Benefit 1. Live schema including Custom Fields and Property Setters.**

1. Unique to FAC? **No.** It is `frappe.get_meta`, which Frappe exposes already.
2. Could MCP give it without FAC? **Yes**, trivially.
3. Could `TOOL_REGISTRY` give it? **No**, and this matters. See §22.2.
4. Could a small helper solve it? **Yes. It already did, today**: `probe meta`, about 30 lines
   plus a formatter, verified to show all three `custom_*` fields on Patient Encounter.
5. Justify a dependency? **No.**

**Benefit 2. Tool discovery, so the entry point is not found by grepping.**

1. Unique to FAC? **No.** Discovery is an MCP property, not a FAC property.
2. Without FAC? **Yes**, any MCP server does this.
3. From `TOOL_REGISTRY`? **Partly.** It already emits tool schemas
   (`build_openai_tools`, `build_anthropic_tools`), so the descriptions exist. But its tools are
   clinical, not developer-facing.
4. Small helper? **Partly.** A helper cannot self-describe to the model the way MCP does. This is
   the one place where MCP as a protocol has a genuine edge over a shell script.
5. Justify a dependency? **Not FAC specifically.** It justifies *MCP*, which is a different
   decision. See §22.
 
**Benefit 3. One authentication per session.**

1. Unique to FAC? **No.**
2. Without FAC? Yes.
3. From `TOOL_REGISTRY`? Not applicable.
4. Small helper? **Yes. Solved today** by a 40-minute token cache. Measured: the second and later
   calls in a session cost about 0.2 s total, with no token step.
5. Justify a dependency? **No.**

**Benefit 4. Executing an existing Frappe report.**

1. Unique to FAC? **No.**
2. Without FAC? Yes.
3. From `TOOL_REGISTRY`? No.
4. Small helper? **Yes**, one whitelisted wrapper around `frappe.desk.query_report.run`, callable
   with `probe call`. Perhaps 15 lines.
5. Justify a dependency? **No.** And ADR-047 already decided that reporting is custom APIs.

**INFERENCE, and this is the finding of §21.** Every one of FAC's four benefits fails question 4.
Three of them were closed today, in about an hour, with code we own under MIT. What is left is not
a capability gap. It is a **protocol** preference, and that is Part 21's subject.

---

## 22. FAC vs MCP vs Our Tool Registry

The five things in this discussion are routinely collapsed into each other. They are not the same
kind of thing at all.

| # | Thing | What it actually is | Who owns it |
|---|---|---|---|
| 1 | **FAC** | A Frappe **app** that ships an MCP server plus 24 generic tools | third party, AGPL-3.0 |
| 2 | **MCP** | A **protocol** for a client to discover and call tools. Carries no tools of its own | open spec, no owner |
| 3 | **Remedisys `TOOL_REGISTRY`** | A **clinical** tool set, encounter-scoped and bounded, for the in-product copilot | us, MIT |
| 4 | **Frappe REST / whitelisted methods** | The **transport and the API**: 531 of our methods, plus Frappe's own | us plus upstream |
| 5 | **Claude Code** | The **client**. Speaks shell, files, HTTP, and MCP | Anthropic |

The single most common error in this debate is treating 1 and 2 as one item. **You can have MCP
without FAC.** FAC is one implementation of an MCP server; the protocol is free.

### 22.1 The three architectures

```
A   Claude Code  ->  FAC  ->  Frappe
       one dependency, 24 generic tools, AGPL, generic CRUD included

B   Claude Code  ->  MCP  ->  Remedisys TOOL_REGISTRY  ->  Frappe
       our tools, our licence, discoverable ... but see 22.2

C   Claude Code  ->  probe script / bench / Read+Grep  ->  Frappe
       zero new dependencies, what exists today
```

### 22.2 Architecture B has a defect that must be said plainly

`TOOL_REGISTRY` **cannot serve developer questions**, and not for a small reason. Its dispatcher
signature is:

```python
def execute_tool(name, args, *, encounter: str, patient: str, transcript: str, ctx: dict) -> dict:
```

**VERIFIED** at `remedisys_healthcare_ai/services/ai_tools.py:1707`. Every tool call requires **an
encounter and a patient**. That is deliberate: ADR-030 says tools must "scope to the subject of the
turn ... no cross-patient access". It is exactly the right design for a clinical copilot, and it
makes the registry useless for "list the DocTypes in the Healthcare module" or "show me the
Property Setters on Patient Encounter", because those questions have no patient.

**INFERENCE.** So "expose `TOOL_REGISTRY` over MCP" does **not**, on its own, replace FAC for
developer work. The thing that would replace FAC is **MCP over a small, separate developer tool
set** (`get_meta`, `get_doc`, `list_rows`, `call_whitelisted_method`), which is the four probe
subcommands with an MCP envelope around them. Call that **B-dev** to keep it distinct:

```
B-dev   Claude Code  ->  MCP  ->  remedisys dev tools (get_meta, get_doc, list_rows, call_method)
                                     ->  Frappe
```

This correction matters because it changes what "build our own MCP server" costs. It is not
"wrap the registry we already have"; it is a small new read-only tool set, plus the wrapping.
Still MIT, still about two days, but let us be accurate about it.

### 22.3 Scored

| Dimension | A. FAC | B. MCP over TOOL_REGISTRY | B-dev. MCP over dev tools | C. Scripts today |
|---|---|---|---|---|
| Developer experience | good | **poor**, wrong tools for the job | **best** | good, after the probe script |
| Safety | ok, only if writes disabled | good | good, read-only by design | **best**, nothing new exposed |
| Correctness | ok, different path from the product | good | **best**, same methods the product calls | **best** |
| Schema awareness | good | **none**, no metadata tool | good | good, `probe meta` |
| Domain awareness | **none**, generic CRUD | **best**, clinical rules built in | ok | good, our methods |
| Maintainability | upstream app we do not control | ours | ours | **best**, 200 lines |
| Implementation effort | half a day, plus a licence review | pointless, wrong shape | about two days | **done** |
| PHI safety | **worst**, `output_data` retains results | good, bounded reads | good | **best**, no new store |
| Future flexibility | limited by an AGPL upstream | limited to clinical questions | **best** | limited, shell only |

### 22.4 The question asked directly

> "If MCP can expose our existing TOOL_REGISTRY directly, does FAC become unnecessary?"

**Three-part answer.**

1. **For clinical AI work: FAC was already unnecessary**, and `TOOL_REGISTRY` is why. That is
   settled, shipped, and governed by ADR-030.
2. **For developer work: exposing `TOOL_REGISTRY` over MCP does not make FAC unnecessary**,
   because the registry demands an encounter and a patient. This is the correction §22.2 makes.
3. **What does make FAC unnecessary for developer work is either B-dev or, already today, C.**
   As of this afternoon, C covers 15 of the 17 tasks in §21.2 as well as or better than FAC, and
   the other 2 are things FAC cannot do at all.

**RECOMMENDATION.** FAC is unnecessary. Not because MCP is unnecessary, and not because generic
tools are worthless, but because everything we actually wanted from it is four subcommands and a
token cache, and we now have both. If the MCP protocol's discovery ergonomics later prove worth
having, build **B-dev**, which ADR-030 permits and which keeps the licence, the audit rules and
the code path ours.

---

## 23. Three Runtimes, Three Separate Recommendations

One universal answer about FAC would be wrong, because the three runtimes in this system have
different callers, different data, and different consequences of failure.

### 23.1 Runtime A. Claude Code development

```
Claude Code  ->  FAC / MCP  ->  Frappe (dev site)
```

- **Caller:** a developer, through an AI client.
- **Data:** whatever the dev site holds. On `marley.local` that is 1,272 encounters and 306
  patients (**VERIFIED**, measured 2026-09-10), which is why "dev site" is not automatically
  "safe site".
- **Failure cost:** minutes.

**RECOMMENDATION: OPTIONAL, and currently unnecessary.** Permitted only on a bench with no real
patient data, `core` plugin only, write tools disabled, and never as the only path. As of
2026-09-10 the probe script covers this runtime's needs (§21.2), so the honest recommendation is
**do not install it now**, and revisit only if MCP's discovery ergonomics turn out to matter, in
which case build **B-dev** (§22.2) rather than adopting FAC.

### 23.2 Runtime B. The Frontend LLM, our production clinical AI

**This is the runtime that matters most, and §25 is its full evaluation.** "Frontend LLM" names
the clinician-facing production model. It is surfaced in the frontend and **executes server-side**
(§2.10), so it is not a separate runtime from Frappe; it is a loop inside it.

```
Doctor  ->  Next.js /api/ai/*  ->  Frappe ask_copilot
                                      ->  TOOL_REGISTRY (typed, bounded, permission-checked)
                                      ->  Frappe ORM  ->  MariaDB
```

- **Caller:** an LLM, acting inside a physician's session.
- **Data:** live PHI, always.
- **Failure cost:** a wrong clinical suggestion, an unreviewed write, or a PHI disclosure.

**RECOMMENDATION: NO. Firmly, and now with numbers.** ADR-030 governs it, the registry is
shipped, its reads are bounded (`_MAX_LABS = 8`, `_MAX_PREV_ENCOUNTERS = 5`), its write tools
emit suggestions rather than DB writes, and its audit rows are content-free by design. FAC would
replace all four of those properties with generic CRUD, whole-document reads, and an audit row
that stores results. Measured cost of the third of those: **373x** more context on the worst
record on this site, and **2.7x** over the Rule 5 budget on a plausible chronic patient (§25.7).
FAC wins 2 of 10 dimensions here, and both are better answered by our own roadmap (§25.10).

One caveat worth keeping visible, because it is the genuine cost of our choice: because
`AI Prompt Log` stores tool **names** only, *why* the AI recommended something cannot be
reconstructed. That gap is already recorded under Rule 6 in `CLAUDE.md`. FAC's `input_data` and
`output_data` would close it, by storing precisely the PHI our own rules forbid storing. The
right fix is a purpose-built, consent-aware provenance record, not a generic audit log.

### 23.3 Runtime C. Doctor application runtime

```
Doctor  ->  Next.js  ->  BFF  ->  remedisys api/v1 methods  ->  Frappe
```

- **Caller:** a clinician, in a browser, with an `httpOnly` cookie.
- **Data:** live PHI.
- **Failure cost:** care is blocked.

**RECOMMENDATION: NO. Absolutely not**, and for reasons that do not depend on FAC's quality:
Rule 7 forbids making an assistant tool a dependency of a clinical action; a generic write skips
`_require_assigned_practitioner_or_admin` and `_apply_drug_prescriptions`; the typed contract the
UI compiles against would be lost; and the browser would need a credential it can read. §8 and
§8.5 carry the full argument.

### 23.4 Why the three answers differ, in one line each

- **A** tolerates a generic tool because the questions are unknown and, on a clean bench, nothing
  is at stake.
- **B**, the Frontend LLM, cannot tolerate a generic tool because the caller is a model, the data
  is PHI, and the bounds are what make Rule 5 true rather than aspirational.
- **C** cannot tolerate a generic tool because a doctor is waiting and the write must obey
  clinical rules.

---

## 24. Decision Matrix

`YES` = needed or recommended. `NO` = not needed, or actively wrong. `OPTIONAL` = defensible under
stated conditions, not required.

| Use case | FAC needed? | FAC useful? | Existing system enough? | Recommended |
|---|---|---|---|---|
| **Claude Code schema inspection** | NO | OPTIONAL | **YES** | `probe meta`. Reads `frappe.get_meta`, so Custom Fields and Property Setters are merged. This was FAC's best row until the helper existed |
| **Claude Code DB verification** | NO | OPTIONAL | **YES** | `probe count` / `rows` / `child`, 78 ms to 85 ms measured. `child` supplies `parenttype`, the part people forget |
| **Claude Code debugging** | NO | NO | **YES** | `FRAPPE_DEBUG=true` plus the `x-frappe-calls` header. Most such bugs live above Frappe, where FAC has no view at all |
| **Claude Code backend development** | NO | OPTIONAL | **YES** | Read and Grep on 534 files, then `probe call` to check a real method. FAC cannot call our whitelisted methods |
| **Frontend LLM: clinical reads** | NO | NO | **YES** | `TOOL_REGISTRY`, 36 bounded tools, ADR-030. Measured: a generic read of one patient's encounters is **373x** our bounded read, and 76x the Rule 5 budget (§25.7) |
| **Frontend LLM: clinical writes** | NO | NO | **YES** | Our write tools emit suggestions and never mutate the DB (Rule 6). FAC's `update_document` / `create_document` write immediately, with no allergy or duplicate check (§25.3, §25.8) |
| **Frontend LLM: long-tail questions** | NO | **YES, genuinely** | **YES**, by design | One of only two rows where FAC really wins. PHI-6 makes the narrowness deliberate: the answer is one new curated tool, recorded in an ADR, not a generic surface (§25.10 Benefit A) |
| **Frontend LLM: AI provenance** | NO | **YES, genuinely** | **NO**, this is a real gap | The second row FAC wins. `AI Prompt Log` stores tool names only, so *why* the AI recommended something cannot be reconstructed. Fix with the purpose-built provenance record already P0 in the AI master plan, not with a 180-day PHI audit log (§25.10 Benefit B) |
| **Encounter persistence** | NO | NO | **YES** | `save_draft` and its domain helpers. A generic `update_document` writes the field and skips the rules |
| **Doctor UI** | NO | NO | **YES** | Next.js plus typed fetchers. Rule 7: an assistant tool must never be a dependency of care |
| **BFF** | NO | NO | **YES** | 267 route handlers, one client, `frappeErrResponse` status mapping. Adding FAC narrows nothing and loses the typing |
| **Production API** | NO | NO | **YES** | 531 whitelisted methods under `api/v1/`, versioned by us rather than by upstream DocTypes |
| **Admin analytics** | NO | OPTIONAL | **YES** | Report APIs per ADR-047. FAC's SQL tool is convenient but bypasses the permission engine and scopes to no patient |

**Every row: FAC needed = NO.** Existing system is enough on every row but one.

Two things changed in v2.0 and both are worth saying plainly:

1. **The four "OPTIONAL, useful" rows are all developer-facing**, on a clean bench. None of them
   is a production reason. A developer convenience never justifies a dependency in a clinical
   request path.
2. **One row honestly answers "existing system enough: NO"**, and it is Frontend LLM provenance.
   FAC would close that gap. It would close it by storing patient data in a generic 180-day audit
   log, which is why the recommendation is to close it properly instead. This is the single most
   useful thing FAC surfaced in the whole evaluation, and it is a finding about **our** design, not
   an argument for theirs.

### 24.1 What would change these answers

**RECOMMENDATION.** Revisit if any of these becomes true, and not otherwise:

1. A legal opinion clears AGPL-3.0 for our app graph **and** a PHI-free bench exists.
2. The developer question volume grows enough that MCP's discovery ergonomics measurably beat a
   shell helper. Build **B-dev** first in that case.
3. We need Frappe report execution often enough that a 15-line wrapper is not sufficient.
4. FAC gains a PHI-aware redaction layer for `output_data` and a per-DocType allowlist for its
   write tools. Both are upstream changes we do not control.


---

---

## 25. The Production Question: FAC vs TOOL_REGISTRY for the Frontend LLM

> Added in v2.0, 2026-09-10, and this is now the section that decides the document.
>
> **Question: should Remedisys use FAC in production, as the tool layer for the Frontend LLM?**
>
> Everything before §25 was written around a developer-tooling question. That was the wrong
> centre of gravity. Claude Code is a tool we use to build the product. The Frontend LLM is
> **part of the product**, it runs against live patients, and a mistake there reaches a child.

### 25.1 What the question actually asks

Because the model and the tool loop both run inside Frappe (§2.10), "FAC for the Frontend LLM"
cannot mean "the frontend talks to FAC". It can only mean one of two things:

- **P1. Replace the tool layer.** `ask_copilot` stops calling `ai_tools.execute_tool` and instead
  calls FAC's tools over MCP.
- **P2. Add to the tool layer.** `TOOL_REGISTRY` keeps its 36 tools and FAC's generic tools are
  offered to the model alongside them.

P2 sounds safer than P1. It is not, and §25.9 explains why: with a generic write tool present, the
model's *choice* becomes the safety boundary, and the weakest tool sets the risk level.

### 25.2 The two architectures, drawn

**Today. VERIFIED, §2.10.**

```
Doctor  ->  Next.js /api/ai/*  ->  Frappe ask_copilot  (api/v1/ai/api.py:1038)
                                        |
                                        |  1 in-process Python call per tool, up to 20 per turn
                                        v
                                   TOOL_REGISTRY  (36 typed tools, bounded, permission-checked)
                                        |
                                        v
                                   Frappe ORM  ->  MariaDB

   writes: none. Write tools return a ClinicalSuggestion into the physician-review draft.
   audit:  AI Prompt Log, tool NAMES + tokens + latency. No arguments, no results, no PHI.
```

**With FAC (P1). What would change:**

```
Doctor  ->  Next.js /api/ai/*  ->  Frappe ask_copilot
                                        |
                                        |  1 loopback HTTP + MCP round trip per tool,
                                        |  up to 20 per turn, worker to worker
                                        v
                                   FAC MCP server  (same Frappe site, StreamableHTTP)
                                        |
                                        v
                                   24 generic tools  ->  Frappe ORM  ->  MariaDB

   writes: immediate and generic (update_document, submit_document, delete_document).
   audit:  Assistant Audit Log, input_data AND output_data, 180-day default retention.
```

The second diagram is the first diagram with a network hop, a second audit store, and the
safety properties removed. That is the whole of §25 in one sentence, and the rest is evidence.

### 25.3 Clinical safety

**The property we have.** Write tools in `TOOL_REGISTRY` **never touch the database**. Each returns
a suggestion item in the same shape `generate_suggestions` emits, so it flows through the physician
review draft. **VERIFIED**, `services/ai_tools.py:1-16` docstring, and confirmed by the audit note
in `CLAUDE.md`: "`ai_tools.py` contains zero DB mutations, verified".

Concrete safety logic that lives in that layer, not in the prompt:

| Check | Where | What it prevents |
|---|---|---|
| `_allergy_conflict(drug_name, allergies)` | `ai_tools.py:374` | Suggesting a drug the patient reacts to, including same-family matches via a 5-character prefix rule (`_ALLERGY_PREFIX_MIN_LEN`, e.g. "sulfa") |
| `_rx_already_present`, `_rx_identity`, `_rx_strength` | `ai_tools.py:656, 608, 599` | Duplicate prescriptions that differ only in spelling or strength formatting |
| `_order_already_present`, `_order_dup_keys` | `ai_tools.py:839, 814` | Duplicate lab, procedure and therapy orders |
| `allow_write` gate on schema build | `api/v1/ai/api.py:1111` | A caller without encounter write permission is never even **offered** a write tool |

**What FAC offers instead.** `update_document` and `submit_document`, generic across DocTypes, with
`frappe.has_permission` as the only check. **VERIFIED** from FAC source. No allergy logic, no
duplicate detection, no suggestion pipeline, no physician review step, and no concept of an
encounter being signed.

**INFERENCE.** Under FAC, "the AI must not write to the chart without review" stops being a
property of the code and becomes a property of the prompt. Rule 6 would be enforced by asking the
model nicely. We already know how that ends: our own constitution records that 5 of 23 write tools
are auto-applied by the frontend before review (`encounter-screen.tsx:3217-3263`), and that gap
exists **even with** a backend that refuses to write. Removing the backend's refusal would make it
structural rather than a bug.

**Verdict on clinical safety: FAC is a clear regression.**

### 25.4 PHI

| Property | TOOL_REGISTRY (today) | FAC |
|---|---|---|
| Tool arguments stored? | No | **Yes**, `input_data` |
| Tool results stored? | No | **Yes**, `output_data`, capped at 50,000 bytes, truncation flagged |
| Retention | not applicable | `audit_log_retention_days`, default **180** |
| Redaction | not applicable, nothing is stored | credential-shaped **keys** only, no PHI concept |
| Who can read it | not applicable | System Manager (full), **Auditor** (read) |
| In an erasure path? | not applicable | **No.** A new PHI store outside PHI-4 |
| What our audit does hold | model, prompt version, tokens, latency, cost, and tool **names** | as above, plus the clinical content |

**VERIFIED** on both sides: FAC's DocType JSON and `utils/audit_trail.py`; our ADR-030 and the
Rule 6 note in `CLAUDE.md`.

**The rules this breaks, in production, with real patients:**

- **Rule 10 / PHI-8**, no PHI in logs. `output_data` is a log of clinical content.
- **PHI-4**, duplicated PHI must be reachable by one erasure path. It would not be.
- **PHI-1**, every subprocessor that receives patient data is named in the active
  `ComplianceProfile`. The profile does not name an MCP audit store.
- **PHI-6**, minimum necessary. §25.8.

**Verdict on PHI: FAC is disqualifying in production**, unless upstream adds PHI-aware redaction
for `output_data`, which is not in our control.

### 25.5 Permissions

Both check permissions. They do not check the same things.

| Layer | TOOL_REGISTRY | FAC |
|---|---|---|
| Role and DocType | `require_permission(doctype, perm)` in each read tool | `frappe.has_permission` in each tool |
| Row level | `_require_encounter_read`, `_require_clinical_write(patient)` | inherited from Frappe only |
| Subject scoping | **encounter and patient are mandatory arguments** of `execute_tool` (`ai_tools.py:1707`) | none. A tool can name any document |
| Cross-patient reach | structurally impossible in v1 tools | possible wherever the user has read permission |
| Offered-tool gating | `allow_write` removes write tools from the schema | `FAC Tool Role Access` can gate a tool by role |
| SQL path | none, banned | `run_database_query` bypasses the permission engine entirely (`frappe.db.sql`), System Manager gate, no row filtering |

**VERIFIED** on both sides.

The decisive line is the third row. `execute_tool(name, args, *, encounter, patient, ...)` makes
cross-patient access a **type error**, not a policy. ADR-030 wrote that on purpose: tools must
"scope to the subject of the turn ... no cross-patient access". A generic tool cannot express that
constraint, because it does not know what a turn is about.

An Administrator or System Manager using the copilot is where this becomes sharp. Our tools still
only reach the one encounter and one patient of the turn. FAC's tools would reach everything that
user can read, which for a System Manager is every patient on the site.

**Verdict on permissions: FAC is weaker in the dimension that matters, subject scoping.**

### 25.6 Latency and worker capacity

Being fair first: **latency is the weakest argument against FAC here**, and §11.1's v2.0 correction
says why. An authenticated loopback round trip is about **5 ms** (median of 6 samples), not 85 ms.
Twenty of those is roughly **100 ms** added per copilot turn, plus MCP framing. Against an LLM turn
that takes seconds, that is not a user-visible regression.

The real cost is **worker capacity**, and it is structural:

- `gunicorn_workers` is **25**. **VERIFIED**, `sites/common_site_config.json`.
- `ask_copilot` already occupies one worker for the whole turn, because the tool loop is
  synchronous.
- Under FAC, each tool call becomes a **second, nested request into the same site**, so a single
  copilot turn can hold one worker while demanding up to 20 more, one at a time.

**INFERENCE.** With N doctors in concurrent copilot turns, the site needs N workers held plus N
in flight for the nested calls. At 25 workers this degrades under a load that today it absorbs, and
in the worst case it self-deadlocks: every worker is holding a turn and waiting for a nested call
that has no worker left to serve it. In development this is worse rather than better, because
`Procfile` runs `bench serve`, a single dev server.

**Verdict on latency and capacity: latency is a minor cost, and the nested-request pattern is a
real architectural cost that our current in-process design does not have.**

### 25.7 Token usage. Measured.

This is where the generic approach fails hardest, and the numbers are from this site today.

**Single document, generic versus ours:**

| Payload | Bytes | Tokens (counted, `tiktoken` `o200k_base`) |
|---|---|---|
| `get_document` on Patient Encounter (33 top-level keys) | 2,998 | **926** |
| our `get_encounter` serialized (`_fmt_encounter`) | 1,739 | **498** |
| `get_document` on Patient (33 top-level keys) | 1,060 | **292** |
| our `get_patient_medications` | 941 | **292** |

**VERIFIED**, measured 2026-09-10 on `HLC-ENC-2026-00684` and its patient, sizes only, no content
printed. Counted with `tiktoken` encoding `o200k_base`, the tokenizer current GPT models use, not
estimated from bytes. On one document generic costs about **1.9x** ours. That alone would not decide
anything.

**Lists are where it breaks. Same site, same day:**

| Scenario | Bytes | Tokens (counted) |
|---|---|---|
| generic: `get_document` on **all** encounters of the busiest patient (1,002 of them) | 1,007,703 | **302,056** |
| ours: bounded to 3 (`_DEFAULT_PREV_ENCOUNTERS`) | 2,688 | **810** |

**VERIFIED.** Ratio: **373x**. Rule 5's context budget is **4,000 tokens**, so the unbounded read is
**76x the budget** and larger than the model's context window.

The ratio is robust: **373x** is the same whether counted with `tiktoken` or estimated as
`bytes / 4`, so it does not depend on the tokenizer. The absolute numbers do: `bytes / 4`
undercounts JSON by roughly 20%, because keys, braces and quotes tokenize densely, which is why the
counted figures here are higher than an earlier draft's estimates.

**Honesty about that number.** 1,002 encounters on one patient is almost certainly seeded test
data, not a real clinic figure. So take a plausible real case instead: average encounter payload on
this site is about 896 bytes, so a chronic pediatric patient with **40** encounters costs 35,840
bytes, counted at **10,800 tokens**. Still **2.7x over the Rule 5 budget**, from one tool call,
before the transcript is added.

**INFERENCE.** Bounds are the feature. `_MAX_LABS = 8`, `_MAX_LAB_ITEMS_PER_TEST = 6`,
`_MAX_PREV_ENCOUNTERS = 5`, `_MAX_TRANSCRIPT_CHARS = 6000` are not tuning parameters, they are what
makes Rule 5 true. A generic tool has a `limit` argument, so the bound becomes **the model's
choice** rather than the system's guarantee. With a 20-iteration loop, one bad choice per turn is
enough to blow the budget, and the failure is silent: a truncated context produces a confident,
partially-informed clinical suggestion.

**Verdict on token usage: FAC is a serious regression, measured at 373x on the worst real record
and 2.7x over budget on a plausible one.**

### 25.8 Domain validation

`save_draft` is the clearest case. It is not a field setter. Around it sit, all **VERIFIED** at
`api/v1/encounters/api.py`:

```
_apply_drug_prescriptions        :506    dedupe, drug_code resolution, bill flags
_apply_lab_prescriptions         :646
_apply_procedure_prescriptions   :685
_apply_therapies                 :726
_derive_chief_complaint_if_missing:151
_link_vitals_to_encounter        :961
_create_encounter_immunizations  :1731
_stamp_billing_optout            :1909
_bill_defaults_for_company       :249    per-company Internal/External order tagging
```

Plus the authorisation gates `_require_assigned_practitioner_or_admin:1807`,
`_require_cancel_authorized_practitioner:1836`.

A generic `update_document` on Patient Encounter runs **none** of them. It sets the field and
returns success.

**USER STORY, the shape our own constitution requires.** Dr. Bracamontes asks the copilot, "add
amoxicillin 250 mg three times a day for seven days".

- **Today:** the model calls `add_medication`. `_allergy_conflict` runs against the patient's
  allergy list. `_rx_already_present` runs against the encounter's existing rows. The tool returns a
  **suggestion**, which appears in the review panel with confidence and reasoning. Dr. Bracamontes
  accepts it. Then `save_draft` runs `_apply_drug_prescriptions`, which resolves `drug_code` and
  stamps the bill flags for this company.
- **Under FAC:** the model calls `update_document` on the encounter's `drug_prescription` table,
  or `create_document` on `Drug Prescription`. **The database now contains** a prescription row
  with no allergy check performed, possibly duplicating a row already there, with no `drug_code`
  resolved and no bill flag stamped, and it was never shown for review because there was no
  suggestion to review. **Consequence:** a pharmacy line for a child that no clinician approved,
  and a billing row that the invoice drawer cannot price.

**Verdict on domain validation: FAC bypasses it by construction.**

### 25.9 Generic CRUD risk, including why P2 does not fix it

The tempting compromise is P2: keep our tools, add FAC's, let the model choose. Three reasons it
does not work.

1. **The weakest tool sets the risk.** A model with both `add_medication` (safe, reviewed) and
   `create_document` (direct write) available will sometimes pick the second, especially when the
   first refuses. Refusal is exactly when a generic fallback is most attractive to a model and most
   dangerous to a patient.
2. **Prompt injection has a target.** Our tool arguments come only from the model's structured
   function call, and ADR-030 requires that tool args are never interpolated from patient text.
   But the *choice* of tool is model-driven, and patient free text is in the context: a transcript,
   an uploaded lab report, a chat message. With a generic write tool present, injected text has
   something worth aiming at. Today the worst an injection achieves is a bad suggestion a physician
   must accept.
3. **`delete_document` exists.** It calls `frappe.delete_doc(..., force=True)` when asked, has no
   DocType allowlist, and no confirmation step. **VERIFIED** from FAC source. There is no version of
   "offered to a clinical model in production" that makes that acceptable, and disabling it per-role
   is a configuration that one migration or one upgrade can quietly reset.

**Verdict: P2 is not a safer P1. It is P1 with a slower failure mode.**

### 25.10 The honest case FOR FAC in production

The evaluation is worthless if it will not state the other side. There are three genuine benefits,
and each is real.

**Benefit A. Reach beyond 36 tools.** `TOOL_REGISTRY` answers only what it was written to answer.
A clinician asking "has this child ever had a reaction recorded at another clinic in this company"
gets nothing if no tool covers it. FAC's generic tools would cover the long tail with no new code.

*Why it still loses:* PHI-6 makes that a feature, not a defect. "Widening what a tool can read is a
compliance decision, recorded in an ADR, not a convenience." The correct response to a missing
capability is one new curated tool, reviewed like any code. That is a day of work, not an
architecture change.

**Benefit B. Reconstructable AI provenance.** Our own Rule 6 records a live gap: `AI Prompt Log`
stores tool names only, so *why* the AI recommended something cannot be reconstructed, and
`AI Recommendation Log` does not exist. FAC's `input_data` and `output_data` would close that gap
immediately.

*Why it still loses:* it closes it by storing PHI in a generic 180-day audit log with
credential-shaped redaction, readable by the Auditor role, outside any erasure path. That trades a
traceability gap for a disclosure risk. The right fix is the purpose-built, consent-aware
provenance record already named as P0 in `docs/ai/REMEDISYS_AI_MASTER_PLAN.md` §13. **This is the
one place where FAC identifies a real hole in our design**, and it deserves to be recorded as such.

**Benefit C. Report execution for analytics.** `generate_report` runs an existing Frappe report
with no new code.

*Why it still loses:* ADR-047 already decided reporting is custom APIs, and
`api/v1/encounters/report.py` is 25,030 bytes of that decision. A 15-line wrapper around
`frappe.desk.query_report.run` covers the rest.

### 25.11 Four approaches, compared before recommending

Required by `CLAUDE.md` §10, and this is an irreversible, safety-relevant decision, so it is
written out.

| Approach | Pros | Cons |
|---|---|---|
| **A. FAC replaces TOOL_REGISTRY (P1)** | one dependency covers the long tail; no tool-writing; provenance in audit rows | loses every safety property in §25.3; PHI in `output_data`; no subject scoping; 373x token risk; nested worker calls; AGPL in production; contradicts ADR-030 |
| **B. FAC alongside TOOL_REGISTRY (P2)** | keeps the safe tools; long-tail reach when needed | weakest tool sets the risk (§25.9); injection gains a target; `delete_document` reachable; two audit stores; all of A's PHI and licence costs |
| **C. Keep TOOL_REGISTRY, extend it when a real gap appears (chosen)** | every §25 property preserved; bounds and scoping stay structural; one audit story; MIT; ADR-030 already governs it | long tail uncovered until someone writes a tool; ~1,727 lines of ours to maintain; upstream renames are our problem |
| **D. Keep TOOL_REGISTRY and add a purpose-built provenance record** | C, plus it closes the one real hole FAC exposed (Benefit B), with consent and retention designed in | more work than adopting FAC's audit log; needs an ADR and a retention decision |

**Chosen: C now, D next.** Specifically why each other option loses:

- **A loses** because it removes properties we can prove we have, in exchange for a capability
  PHI-6 says we should not want. The measured 373x token figure and the "zero DB mutations"
  guarantee are not tradeable against convenience.
- **B loses** because a generic write tool cannot be made safe by being optional. Its risk is that
  the model may choose it, and that risk exists from the moment it is offered.
- **D is not rejected**, it is sequenced. It is the correct answer to Benefit B, and it is already
  a P0 in the AI master plan. It is not a reason to adopt FAC; it is what adopting FAC would be a
  shortcut around.

### 25.12 Answer

> **Should Remedisys use FAC in production for the Frontend LLM?**
>
> **No.** Not as a replacement for `TOOL_REGISTRY`, and not alongside it.

Summarised in one table, with the dimensions asked for:

| Dimension | Winner | Margin | Evidence |
|---|---|---|---|
| Clinical safety | TOOL_REGISTRY | decisive | zero DB mutations; allergy and duplicate checks; suggestion pipeline |
| PHI | TOOL_REGISTRY | decisive | `output_data` versus tool names only |
| Permissions | TOOL_REGISTRY | clear | encounter and patient are mandatory arguments |
| Domain validation | TOOL_REGISTRY | decisive | 9 helpers plus 2 gates that generic CRUD skips |
| Latency | TOOL_REGISTRY | small | ~5 ms per hop, x20 per turn; in-process today |
| Worker capacity | TOOL_REGISTRY | clear | nested requests against 25 workers |
| Token usage | TOOL_REGISTRY | decisive | 373x measured; 2.7x over budget in a plausible case |
| Generic CRUD risk | TOOL_REGISTRY | decisive | `delete_document` with `force=True`, no allowlist |
| Long-tail reach | **FAC** | real | 24 generic tools versus 36 specific ones |
| Provenance reconstruction | **FAC** | real | `input_data` and `output_data`, at PHI cost |

FAC wins two rows out of ten. Both are answered better by our own roadmap: a new curated tool for
the first, and the purpose-built provenance record for the second.

**RECOMMENDATION.** ADR-030 stands, for production, exactly as written. If anything, this section
strengthens it with numbers ADR-030 did not have: 373x on context, 5 ms x 20 on hops, and the
`execute_tool` signature as proof that subject scoping is structural rather than aspirational.

---

---

## 26. ⬛ Bottom line

**FAC does not save us from building tools.** Its 24 tools are generic CRUD, search and report.
Not one of them knows what an allergy is, what a context budget is, or that a clinical write must
be reviewed by a doctor first. For an Encounter we would write all 36 of our tools anyway, which
is why FAC's own `assistant_tools` hook exists.

Once that is clear, the rest follows: **an extra layer that adds no clinical capability, stores
patient data in a 180-day audit log, exposes generic write and delete tools, and needs 6 calls and
335,722 bytes where ours needs 4 calls and 3,449 bytes.**

**FAC is a good fit for an external, general-purpose AI client** (Claude Code, Claude Desktop,
ChatGPT) exploring a Frappe site, where the questions are unplanned and a wide surface helps.
**It is a bad fit for our in-product clinical copilot**, where the questions are known, the data
is PHI, and a narrow surface is the safety feature.

**Where the detail lives:** §25 for the production evaluation, §21 and §22 for the developer
question, §14 for PHI, §24 for the row-by-row decision matrix. The two-page version for the team is
[`FAC_DECISION_SUMMARY.md`](FAC_DECISION_SUMMARY.md).

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.3 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Recounted every token figure with `tiktoken` (`o200k_base`) rather than a `bytes / 4` estimate. The estimate undercounted JSON by about 20%, so absolute figures rise (269,239 to 302,056; 721 to 810) while the decisive **373x** ratio is unchanged, and the over-budget multiple corrects from 67x to **76x**. Every earlier token claim was conservative. |
| 2.2 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Moved the bottom line to the end as §26, where a bottom line belongs, leaving a one-line pointer at the top. Content unchanged. |
| 2.1 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Added the BOTTOM LINE block at the top. Its content is the finding that decides the document and had been buried: FAC's 24 generic tools contain no clinical rule, so adopting it would not remove any of our 36 tools. FAC's own `assistant_tools` hook is the upstream admission of this. |
| 2.0 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | **Reframed around the production question after a correction from the user: Claude Code is not the production LLM; the Frontend LLM (the clinician-facing copilot) is.** Added §2.10 (the verified production AI topology: the frontend holds no model SDK, the loop runs in-process in Frappe) and §25 (FAC vs TOOL_REGISTRY for the Frontend LLM, across clinical safety, PHI, permissions, domain validation, latency, worker capacity, token usage and generic CRUD, with measured numbers). Executive summary now carries two separate verdicts. §16 gained a production column, §17's diagram now shows the real AI path, §23.2 and §24 renamed to the Frontend LLM, §20 split into production and developer answers. Corrected §11.1: the 85 ms figure was a read with query work; the HTTP hop itself is ~5 ms, which weakens the latency argument and moves the production case onto token budget and worker capacity. Production verdict: **do not use FAC**. Developer verdict unchanged. |
| 1.1 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Added §21 incremental-value test (17 tasks, the four benefits put through five questions), §22 FAC vs MCP vs TOOL_REGISTRY (with the correction that the registry is encounter-scoped and so cannot serve developer questions), §23 three runtimes with separate recommendations, §24 decision matrix. Verdict strengthened from "B with conditions" to "B optional and currently unnecessary", because the probe script closed three of FAC's four benefits the same day. |
| 1.0 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Initial evaluation. Inspected both repos, measured the live dev site, read FAC source on GitHub main. Verdict: B, development only, PHI-free bench only. |
