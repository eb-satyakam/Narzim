# Remedisys — Backend Architecture

**Doc status:** living · **Created:** 2026-06-04 by Sarvesh-SocialAngel · **Updated:** 2026-09-23 by Nishant · **Version:** 1.1

**Stack:** Frappe v16 · ERPNext Healthcare · MariaDB 11 · Redis 7
**Deployment:** Frappe Cloud
**Jurisdiction:** Mexico — LFPDPPP + NOM-024-SSA3-2012

---

## 1. System Overview

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e3a5f', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'secondaryColor': '#1e293b', 'tertiaryColor': '#0f172a'}}}%%

graph TB
    FE(["🖥️ Next.js\n(Vercel)"]):::frontend
    MB(["📱 Mobile App\n(Future)"]):::future

    subgraph FC["☁️  Frappe Cloud"]
        subgraph APP["remedisys_healthcare_ai"]
            API["🔵 api/v1/\nEntry Points"]:::apilayer
            SVC["🟢 services/\nBusiness Logic"]:::svclayer
            AI["🔴 api/ai/\nAI Phase — Locked"]:::ailayer
        end
        DB[("🗄️ MariaDB 11+")]:::db
        RD[("⚡ Redis 7+")]:::cache
    end

    EXT["🌐 External\nDeeepgram · Anthropic\n(AI Phase — Future)"]:::future

    FE -->|"Bearer Token · HTTPS"| API
    MB -.->|"Bearer Token · HTTPS\nFuture"| API
    API -->|"delegate"| SVC
    SVC -->|"Frappe ORM"| DB
    AI -.->|"RQ Jobs"| RD
    AI -.->|"HTTPS"| EXT

    classDef frontend fill:#1e3a5f,stroke:#3b82f6,color:#e2e8f0,stroke-width:2px
    classDef apilayer fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    classDef svclayer fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef ailayer fill:#3b1a1a,stroke:#ef4444,color:#fca5a5,stroke-width:2px,stroke-dasharray:5
    classDef db fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
    classDef cache fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef future fill:#1c1917,stroke:#57534e,color:#a8a29e,stroke-width:2px,stroke-dasharray:5
```

---

## 2. Two-Layer Architecture

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e3a5f', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569'}}}%%

flowchart TD
    FE(["🖥️ Frontend — Next.js"]):::frontend

    subgraph L1["  LAYER 1 — api/v1/  "]
        direction LR
        L1R["✅ require_permission()\n✅ call service\n✅ return response\n❌ no frappe.get_doc()\n❌ no business logic\n❌ max 5 lines per method"]:::rules
    end

    subgraph L2["  LAYER 2 — services/  "]
        direction LR
        L2R["✅ all validation\n✅ all business rules\n✅ frappe.get_doc()\n✅ frappe.get_all()\n✅ DB operations\n❌ no @frappe.whitelist()"]:::rules
    end

    UT["🟠 utils.py\nrequire_permission() · paginate()"]:::utils

    DB[("🗄️ MariaDB\nFrappe ORM")]:::db

    FE -->|"Authorization: Bearer"| L1
    L1 -->|"delegate after permission check"| L2
    L1 -.->|"shared helpers"| UT
    L2 -->|"frappe.get_doc() / get_all()"| DB

    classDef frontend fill:#1e3a5f,stroke:#3b82f6,color:#e2e8f0,stroke-width:2px
    classDef rules fill:#0f172a,stroke:#334155,color:#94a3b8,stroke-width:1px,text-align:left
    classDef utils fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef db fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px

    style L1 fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    style L2 fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
```

---

## 3. Request Flow — Book Appointment

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#e2e8f0', 'activationBkgColor': '#1e3a5f', 'sequenceNumberColor': '#e2e8f0'}}}%%

sequenceDiagram
    autonumber
    actor FE as 🖥️ Frontend
    participant API as 🔵 api/v1/appointments/api.py
    participant SVC as 🟢 services/appointments.py
    participant DB as 🗄️ MariaDB

    FE->>API: book_appointment(patient, practitioner, date, time)
    Note over API: require_permission() ✓<br/>3 lines max

    API->>SVC: AppointmentService.book(...)
    Note over SVC: validate inputs<br/>check slot available<br/>apply business rules

    SVC->>DB: frappe.get_all() — check slot
    DB-->>SVC: slot available ✓

    SVC->>DB: frappe.get_doc().insert()
    DB-->>SVC: appointment created ✓

    SVC-->>API: {name, status: "Open"}
    API-->>FE: {name, status: "Open"}
```

---

## 4. Developer Ownership

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e3a5f', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'clusterBkg': '#0f172a'}}}%%

graph LR
    subgraph D1["👤 Dev 1 — Patients"]
        P1["api/v1/patients/api.py"]:::blue
        P2["services/patients.py"]:::blue
        P3["tests/patients/"]:::blue
    end

    subgraph D2["👤 Dev 2 — Appointments"]
        A1["api/v1/appointments/api.py"]:::green
        A2["services/appointments.py"]:::green
        A3["tests/appointments/"]:::green
    end

    subgraph D3["👤 Dev 3 — Encounters · Prescriptions"]
        E1["api/v1/encounters/api.py"]:::orange
        E2["services/encounters.py"]:::orange
        E3["api/v1/prescriptions/api.py"]:::orange
        E4["services/prescriptions.py"]:::orange
    end

    subgraph D4["👤 Dev 4 — Clinical · Labs"]
        C1["api/v1/clinical/api.py"]:::purple
        C2["services/clinical.py"]:::purple
        C3["api/v1/labs/api.py"]:::purple
        C4["services/labs.py"]:::purple
    end

    subgraph D5["👤 Dev 5 — Billing · Insurance"]
        B1["api/v1/billing/api.py"]:::red
        B2["services/billing.py"]:::red
        B3["api/v1/insurance/api.py"]:::red
        B4["services/insurance.py"]:::red
    end

    subgraph SH["🔐 Shared — Team Review Required"]
        SH1["utils.py"]:::shared
        SH2["hooks.py"]:::shared
    end

    subgraph AILK["🔴 AI Team — Locked"]
        AI1["api/ai/"]:::locked
        AI2["services/deepgram.py"]:::locked
        AI3["tests/ai/"]:::locked
    end

    classDef blue fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:1px
    classDef green fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:1px
    classDef orange fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:1px
    classDef purple fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:1px
    classDef red fill:#450a0a,stroke:#ef4444,color:#fca5a5,stroke-width:1px
    classDef shared fill:#1c1917,stroke:#d97706,color:#fcd34d,stroke-width:2px
    classDef locked fill:#1c1917,stroke:#6b7280,color:#9ca3af,stroke-width:1px,stroke-dasharray:4
```

---

## 5. API Versioning Strategy

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569'}}}%%

flowchart TD
    C(["🔄 API Change Needed"])

    C --> Q{What type?}

    Q -->|"Add new method"| G1["✅ Add to api/v1/\nNot a breaking change"]:::good
    Q -->|"Add optional field"| G2["✅ Add to api/v1/\nNot a breaking change"]:::good
    Q -->|"Remove a field"| B1["🔴 Create api/v2/\nfeature/api.py"]:::breaking
    Q -->|"Rename a field"| B1
    Q -->|"Change field type"| B1

    B1 --> CO["v1 + v2 coexist\nFrontend migrates at its own pace\nv1 deprecated, not deleted"]:::info

    classDef good fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef breaking fill:#450a0a,stroke:#ef4444,color:#fca5a5,stroke-width:2px
    classDef info fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
```

---

## 6. How to Add a New API

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#3b82f6'}}}%%

flowchart LR
    S1["📝 Step 1\nWrite service logic\n───────────\nservices/appointments.py\nclass AppointmentService:\n  def cancel(appointment, reason):\n    ...all logic here"]:::step1

    S2["🔌 Step 2\nExpose via whitelist\n───────────\napi/v1/appointments/api.py\n@frappe.whitelist()\ndef cancel_appointment(...):\n  require_permission(...)\n  return Service.cancel(...)"]:::step2

    S3["🧪 Step 3\nWrite test\n───────────\ntests/appointments/\ntest_appointments.py\nclass TestCancel\n  (FrappeTestCase)"]:::step3

    S4["🚀 Step 4\nFrontend calls\n───────────\nPOST /api/method/\nremedisys_healthcare_ai\n.api.v1.appointments\n.api.cancel_appointment"]:::step4

    S1 --> S2 --> S3 --> S4

    classDef step1 fill:#14532d,stroke:#22c55e,color:#86efac,stroke-width:2px
    classDef step2 fill:#1e3a5f,stroke:#3b82f6,color:#93c5fd,stroke-width:2px
    classDef step3 fill:#431407,stroke:#f97316,color:#fdba74,stroke-width:2px
    classDef step4 fill:#2e1065,stroke:#a855f7,color:#d8b4fe,stroke-width:2px
```

---

## 7. Folder Structure

```
remedisys_healthcare_ai/
│
├── api/
│   ├── v1/                    ← 🔵 Layer 1 — Entry Points
│   │   ├── patients/api.py
│   │   ├── appointments/api.py
│   │   ├── encounters/api.py
│   │   ├── clinical/api.py
│   │   ├── labs/api.py
│   │   ├── prescriptions/api.py
│   │   ├── billing/api.py
│   │   ├── insurance/api.py
│   │   ├── providers/api.py
│   │   ├── dashboard/api.py
│   │   ├── notifications/api.py
│   │   ├── auth/api.py
│   │   └── ai/api.py
│   └── ai/                    ← 🔴 AI Phase (locked)
│       ├── auth.py
│       ├── realtime.py
│       ├── segments.py
│       └── sessions.py
│
├── services/                  ← 🟢 Layer 2 — Business Logic
│   ├── patients.py
│   ├── appointments.py
│   ├── encounters.py
│   ├── clinical.py
│   ├── labs.py
│   ├── prescriptions.py
│   ├── billing.py
│   ├── insurance.py
│   ├── providers.py
│   ├── dashboard.py
│   ├── notifications.py
│   └── deepgram.py            ← AI phase
│
├── tests/                     ← 🧪 One folder per feature
│   ├── patients/
│   ├── appointments/
│   ├── encounters/
│   ├── clinical/
│   ├── labs/
│   ├── prescriptions/
│   ├── billing/
│   ├── insurance/
│   ├── providers/
│   ├── dashboard/
│   ├── notifications/
│   └── ai/
│
├── utils.py                   ← 🟠 Shared helpers
├── hooks.py                   ← Frappe registration
├── locale/es.po               ← Spanish translations
└── remedisys_healthcare_ai/   ← Frappe module
    ├── doctype/
    └── fixtures/
```

---

## 8. Key Rules

| Rule | Description |
|---|---|
| 🚫 No core modification | Never edit Frappe / ERPNext / Healthcare core files |
| 🚫 No PHI in logs | IDs only — never patient names, DOBs, clinical content |
| ✅ Permission on every method | Every `api/v1/` method calls `require_permission()` first |
| ✅ Logic only in services | `api/v1/` delegates — `services/` decides |
| 🚫 No `frappe.db.sql()` | Use `frappe.get_all()` and `frappe.get_doc()` only |
| 🔒 AI files locked | Do not modify `api/ai/` until AI phase resumes |

---

## 9. Testing

```bash
# All tests
bench --site marley.local run-tests --app remedisys_healthcare_ai

# Single feature
bench --site marley.local run-tests --app remedisys_healthcare_ai \
    --module remedisys_healthcare_ai.tests.appointments.test_appointments

# CI gates
bash tests/ci/install_uninstall_test.sh
```

---

## Docs

| File | Purpose |
|---|---|
| `CLAUDE.md` | Engineering rules and locked assumptions |
| `ROADMAP.md` | Product plan — every screen and feature |
| `docs/architecture/BACKEND_ARCHITECTURE.md` | This file — code patterns, folder structure, developer ownership |
| `docs/README.md` | Backend docs index — start here |
| `docs/planning/PLANNING.md` | Current state, what is built, what to build next |
| `docs/architecture/SYSTEM_DESIGN.md` | Full system design — auth, API inventory, DocTypes, permissions |
| `docs/flows/WORKFLOWS.md` | End-to-end workflows — auth, booking, encounter, labs, billing |
| `docs/planning/PHASES.md` | Backend build phases with Gantt + dependency chain |
| `docs/adr/` | Architecture Decision Records |
| `Healthcare_next_app/docs/AUTHENTICATION.md` | Auth flows (frontend repo — full OAuth2 + NextAuth sequence diagrams) |
| `Healthcare_next_app/docs/SYSTEM_DESIGN_FRONTEND.md` | Frontend system design (frontend repo) |
| `docs/architecture/FRONTEND_CONTRACT.md` | Response shape contract, endpoint inventory, screen→API map — read before implementing any method |
| `docs/architecture/ROLES_AND_PERMISSIONS.md` | **Role → API access matrix** — which Frappe roles can call which endpoints, DocType permission table, admin master data setup order, role name mapping (Physician vs Practitioner). |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 1.0 | 2026-06-04 | Sarvesh | Initial version (header backfilled from git history) |
