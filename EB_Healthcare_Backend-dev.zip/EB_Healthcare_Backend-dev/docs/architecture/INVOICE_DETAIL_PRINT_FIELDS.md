# Invoice detail — fields for the printed invoice

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.0

## What

Adds read-only fields to `get_patient_invoice` (`remedisys_healthcare_ai/api/v1/billing/api.py`) so
the frontend's invoice view — which is also the printed invoice — can match the Narzim design's
invoice page: issue time, per-item category and source, the patient's phone, the visit(s) the
invoice bills, who issued it, and who took each payment and when.

## Why

The user supplied the mock's invoice print (`Narzim-EHR-09-29-2026_04_38_PM.png`) and approved both
the frontend layout and these backend fields. Each field exists on the source records already; the
endpoint simply never returned it:

| New field | Source |
|---|---|
| `posting_time` | `Sales Invoice.posting_time` |
| `items[].item_group`, `reference_dt`, `reference_dn` | `Sales Invoice Item` (same fields `_apply_appointment_fallback` already reads) |
| `patient_mobile` | `Patient.mobile` |
| `visits[]` — `appointment`, `appointment_type`, `appointment_date` | Patient Appointments referenced by line items |
| `issued_by` | full name of `Sales Invoice.owner` |
| `payment_entries[].received_by`, `received_at` | full name of `Payment Entry.owner`, `Payment Entry.creation` |

**`visits` is a list** because one invoice can bill several appointments — verified on
`ACC-SINV-2026-01040`, which references four.

## Plan

All in `get_patient_invoice` and `_invoice_payment_entries`; one extra query for visits (batched
over the invoice's referenced appointments), one `get_value` for the phone. Full names via
`frappe.utils.get_fullname`. No new endpoint, parameter, doctype or permission; additive keys only.

## Risks

- **PHI:** `patient_mobile` is new patient data on this response. It is the patient's own invoice,
  already gated by `require_permission("Sales Invoice", "read", doc=name)` and the patient-customer
  scope guard. Staff names (`issued_by`, `received_by`) are not PHI. No visit reason or clinical note
  is returned — deliberately (minimum necessary, PHI-6): a billing document doesn't need them.
- **Scale:** single-invoice endpoint; two small extra queries.
- **Categories are raw ERPNext item groups** (e.g. "Sub Assemblies" on this site) — printed as-is.

## Verification

Live on `remedisis.localhost`, 2026-09-29, via a standalone `frappe.init` script calling
`get_patient_invoice` as Administrator:

- `ACC-SINV-2026-01106`: `posting_time` 15:53:37, `issued_by` "Anant Sharma", one visit
  (`HLC-APP-2026-00736`, General Consultation, 2026-09-29); items carry `item_group` ("Services",
  "Surgical Supply", "Sub Assemblies") and sources (Patient Appointment / Medication Request); its
  payment `ACC-PAY-2026-00812` has `received_by` "Anant Sharma", `received_at` 2026-09-29 15:53:39.
- `ACC-SINV-2026-01040`: **four** visits returned, confirming the list shape is needed.
- `patient_mobile`: empty for both — their patients have no mobile (14 of 116 on this site do).
  Returned (set, 14 characters) for `ACC-SINV-2026-01033`, whose patient has one. The number itself
  was never printed during verification.
- Every pre-existing key still present. `py_compile` clean.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
