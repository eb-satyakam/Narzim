# Dashboard revenue KPIs — clinic-wide scope, not today's-appointments-only

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.4

## What

`get_dashboard_data`'s `revenue` block (`api/v1/dashboard/api.py`) returns three figures —
`collected_today_mxn`, `pending_mxn`, `pending_count`. This changes how the first two (and the
count's basis) are computed: from *today's appointments that happen to have a linked invoice* to a
*direct, clinic-wide Sales Invoice aggregate*, permission-scoped the same way the rest of this
function already is.

## Why

`EB_Healthcare_Frontend`'s Billing screen was restyled to match a Claude Design mock
(`docs/architecture/BILLING_NARZIM_RESTYLE.md` in that repo). The mock's own header KPIs —
"Collected today" / "Uncollected" — are computed from the mock's fictional data as: today's
collections, and *everything currently outstanding, clinic-wide* — not scoped to any particular
day's appointments. The live backend's existing computation is narrower: it only sums the `paid`/
`outstanding` fields of appointments whose own `appointment_date` is today and that already have a
linked invoice (`api/v1/dashboard/api.py:879-912`). Verified live: every invoice visible in the
current site's data is dated 2026-09-17 through 2026-09-21 — none today (2026-09-29) — so the
existing computation correctly returns 0.00 MXN for both figures. That is not a bug; it is a real
data gap, but it also means these figures never actually match the concept they claim to represent —
"today's collections" should include a late-billed invoice for an older visit, and "uncollected"
should not hide old debt just because it isn't tied to today's schedule.

**Confirmed safe to change:** neither figure is currently rendered anywhere in production. The only
other reference is `mission-control-client.tsx`'s `DEMO_DASH` fixture (`USE_DEMO_QUEUE = false`,
i.e. disabled). Grep-verified before writing this doc.

## Plan

In `remedisys_healthcare_ai/api/v1/dashboard/api.py`, inside `get_dashboard_data`, replace the
appointment-walk-derived `pending_mxn`/`collected_today_mxn`/`pending_count` with a direct query
against Sales Invoice:

- **`collected_today_mxn`** — `SUM(paid_amount)` across submitted, non-return Sales Invoices whose
  `posting_date` = `target_date`.
- **`pending_mxn`** — `SUM(outstanding_amount)` across submitted, non-return Sales Invoices with
  `outstanding_amount > 0`, no date restriction (clinic-wide, matching the mock's "Uncollected").
  **Changed in v1.3 (2026-09-29, explicit request): now also `posting_date = target_date`** — the
  header KPI row reads as "today", so "Uncollected" means what is still owed from today's billing.
  Live: 5,500.00 MXN / 1 invoice today, against 7,340.00 MXN / 4 invoices all-time. The all-time
  figure is still visible on the Invoices tab's own summary line (adr-102), so nothing is lost. See
  adr-099 v1.3.
- **`pending_count`** — count of those same outstanding invoices. Redefined from "appointments with
  an outstanding balance" to "invoices with an outstanding balance" — consistent with the new basis;
  unused anywhere today (see above), so nothing downstream depends on the old definition.

**Company scoping (the actual risk here):** this is a multi-company platform
(`services/billing.py::_batch_outstanding_balance` exists specifically because "a card must not
report the other clinic's debt"). `get_dashboard_data` currently resolves no explicit `company` —
its existing appointment-based computation relies entirely on Frappe's own permission engine
auto-scoping the `frappe.get_all("Patient Appointment", ...)` call to whichever companies the caller
has permission to see. The new invoice aggregate uses `frappe.get_all(..., fields=["sum(...) as
total"])` — the ORM path, not raw `frappe.db.sql` — for exactly this reason: it goes through
Frappe's standard permission-condition injection automatically, matching the existing (implicit)
scoping behavior of the rest of this function, with no new company parameter to thread through and
no risk of the raw-SQL-bypasses-permissions trap `_batch_outstanding_balance`'s own docstring warns
about.

**Not changed:** `appt_billing`, `_attach_billing`, `_attach_patient_pending`, and everything they
feed (the per-row `outstanding_mxn`/`patient_*` fields on queue cards) — those serve a different,
still-correct purpose (per-appointment and per-patient billing state on the board) and stay exactly
as they are.

## Correction (v1.2)

The Plan above is the v1.0 design and had two errors, corrected in code and recorded in
adr-099 v1.2: "collected today" summed only `Sales Invoice.paid_amount` (0 for every non-POS invoice,
which is settled by a Payment Entry), and the claim that `frappe.get_all` goes through permission
injection is false — it forces `ignore_permissions=True`. Collected today is now POS `paid_amount`
plus Payment Entry allocations received on the date; all aggregates use `frappe.get_list`. Live
result: 11,800.0 (was 0.0).

## Risks

- **Scale:** two aggregate queries (`SUM`) instead of a per-appointment walk. Cheaper, not more
  expensive — no N+1, no full-row fetch.
- **Permission behavior depends on Frappe's own get_all permission injection actually being correct
  for this doctype/site's User Permission configuration** — the same assumption the rest of this
  function already silently depends on; not a new risk introduced by this change.
- **Observability:** no PHI in these aggregates (they touch Sales Invoice amount fields only, no
  patient-identifying data), consistent with Rule 10.

## Verification

**A real gotcha found and fixed while building this, not just a plan-time assumption:** the first
implementation used string-form SQL functions in `fields` (`"sum(paid_amount) as total"`), matching
`_batch_outstanding_balance`'s raw-SQL style. Frappe v16's query builder rejects this outright
(`frappe/database/query.py::_validate_select_field` — `ValidationError: SQL functions are not
allowed as strings in SELECT`), confirmed live via `bench --site remedisis.localhost console` before
this doc's implementation was considered done. Fixed to the dict syntax the error message itself
names (`{"SUM": "paid_amount", "as": "total"}`) — function-name keys are case-sensitive uppercase
(`frappe/database/query.py::FUNCTION_MAPPING`), `"as"` is checked case-insensitively for the alias.

**Live end-to-end verification performed** (not just syntax-checked) via `bench console` against the
`remedisis.localhost` dev site, calling the real `get_dashboard_data()`:
- `collected_today_mxn: 0.0` — correct: no Sales Invoice is posted with today's date on this site.
- `pending_mxn: 1940.0`, `pending_count: 4` — real, non-zero, clinic-wide outstanding across 4
  invoices. This is the concrete proof the new basis actually surfaces data the old (appointment-
  scoped) computation could not, since no appointment exists for today either.
- Confirmed the rest of the response (`queue_summary`, `checkout`, `appointments`, etc.) is
  unaffected — same keys, same row counts, before and after.
- `python3 -m py_compile` clean. `ruff`/`mypy` are not installed in this sandbox — noted rather than
  skipped silently; this repo's own PR checklist (`CLAUDE.md` §9) still expects them to run in CI.
- No automated test currently exercises this endpoint's `revenue` block (checked: no existing test
  references `collected_today_mxn`/`pending_mxn`).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.3 | 2026-09-29 | Divyanshu (AI-assisted) | `pending_mxn`/`pending_count` scoped to `posting_date = target_date` (today only), on request |
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Correction: Payment Entry receipts now count as collected; `get_all` → `get_list` for permission scoping |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Recorded the string-vs-dict SQL function syntax gotcha and the live end-to-end verification results |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
