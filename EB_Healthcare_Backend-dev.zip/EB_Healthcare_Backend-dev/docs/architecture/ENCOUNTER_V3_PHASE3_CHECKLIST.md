# Encounter V3 — Phase 3 Implementation Checklist (Duplicate Session Integrity)

**Doc status:** record · **Created:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.10

Design authority: [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
§7 and §21 — every decision below was approved there on 2026-08-26. This file
does not re-argue anything; it exists to be checked off, one step at a time.

**How to use this file:** work top to bottom — the order is not arbitrary, see
each item's WHEN. Change `- [ ]` to `- [x]` on an item's checkbox line once it
is done and verified, not once it is merely written. Leave a one-line note under
an item if reality diverged from the plan (a different row count, a test that
needed adjusting) — that note is itself part of the record.

**Current status (2026-08-26): PHASE 3 COMPLETE.** All 7 implementation
steps are complete and the combined exit verification (6 checks) has passed.
Step 6's unique index on `active_key` is already live on `marley.local` —
"at most one active session per encounter" is a database guarantee there,
not just a migration-time fact. Current verified counts on `marley.local`:
**146** `AI Encounter Session` rows, **14,187** `AI Transcript Segment` rows,
**134** `Recording`, **12** `Stopped`. The six known duplicates are closed,
the losing side of a real race gets a live `session.reattached`
notification, and consent gating / transcript persistence are confirmed
unaffected. **No Phase 3 implementation work remains.** One caveat carried
forward, not resolved here: Phase 2's frontend provider-failure finalization
has no test harness in this backend-only phase and remains unexercised, as
already recorded before Phase 3 began. Two items explicitly out of scope and
tracked separately: §7.7's cross-clinician stop-authorization follow-up (P1,
Phase 7) and Phase 4's general orphan sweep. Nothing is staged or committed.

---

## Scope — confirmed by the 2026-08-26 field-level data-model audit

**Confirmed unchanged from the approved design** (the audit found no reason to
revise any of it): `active_key` stays the Phase 3 mechanism · uniqueness stays
**encounter-wide**, not `encounter + session_user` · `unique: 1` stays on the
**Frappe DocType field itself** (not a manually-created index — the field
property is what triggers Frappe's empty-string→SQL-`NULL` coercion) · **no
"apparently unused" field is removed by Phase 3.**

**Five findings are explicitly OUT OF SCOPE and must not expand Phase 3.** Full
evidence for each is in
[`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
§23.1. Recorded here so they survive in the execution document too:

| | Finding | Disposition |
|---|---|---|
| **A** | `AI Transcript Segment` has **8 existing `(session, sequence_number)` collisions** (`AIES-2026-00117` seq 3/4/5; `AIES-2026-00131` seq 138/139/140/141/144) with no composite unique index | Separate transcript-idempotency/integrity problem. Natural home is Phase 9's sequence-number work. **Not Phase 3.** |
| **B** | `Physician` role has no `write` DocPerm on `AI Transcript Segment`, but `sync_transcript` needs it. Tests run as `Administrator`, which bypasses DocPerm entirely, so nothing catches it | Needs one targeted manual test as a real Physician. **Not Phase 3.** |
| **C** | A signed encounter (`docstatus=1`) can still hold a `Recording` session — nothing in the AI lifecycle reads `docstatus`. Live: `HLC-ENC-2026-00053`, `HLC-ENC-2026-00149` | Needs a separate product/lifecycle decision. **Not Phase 3.** |
| **D** | Six `AI Encounter Session` scaffold fields have zero writers: `deepgram_model`, `llm_model`, `prompt_versions`, `audio_retained`, `error_code`, `error_message` | **KEEP UNCHANGED.** Future schema/observability cleanup candidates only. **Not Phase 3.** |
| **E** | `AI Transcript Segment.deepgram_segment_id` — server-side plumbing works and runs on every call; the browser never sends a value | **KEEP UNCHANGED.** Future traceability improvement. **Not Phase 3.** |

**No code, DocType, index, or database row has been or will be changed for
findings A–E as part of Phase 3.**

---

## 0. Pre-flight — database snapshot

- [x] **Done**

**Verification note (2026-08-26 14:37 local):**
- **Site confirmed:** `marley.local` (the only real site in this bench besides
  `test.marley.local`; explicitly targeted with `bench --site marley.local
  backup`, not the bench default). **Not production** — no reference to
  `chavitosclinic.frappe.cloud` anywhere under `sites/`; DB host is
  `127.0.0.1`, local dev only.
- **Backup mechanism:** the environment's standard one, `bench backup`
  (Frappe 5.29.1), as preferred by the plan.
- **Artifacts:**
  `sites/marley.local/private/backups/20260826_143746-marley_local-database.sql.gz`
  (6,891,586 bytes / 6.6 MiB) and its matching
  `20260826_143746-marley_local-site_config_backup.json`.
- **Coverage confirmed inside the dump:** `CREATE TABLE` present for both
  `tabAI Encounter Session` and `tabAI Transcript Segment` (1 each, as
  expected); `INSERT INTO` rows present for both. A tuple count on the
  session table's insert statements matches the live row count.
- **Live counts at backup time, for the record:** 146 `AI Encounter Session`
  rows, 14,187 `AI Transcript Segment` rows — this is what the artifact above
  should restore to, and what a restore should be checked against later.
- **Integrity check:** `gzip -t` on the artifact — not corrupt.
- **Restorability — partially verified, and I'm flagging the gap rather than
  hiding it.** I attempted to prove the dump is actually restorable by
  restoring it into a throwaway, isolated database (never touching the real
  `marley.local` DB) so row counts could be compared directly. That attempt
  failed on `CREATE DATABASE ... Access denied` — the site's DB user is
  correctly scoped to its own database only, with no privilege to create a
  new one, so I could not complete a live restore test, and I did not attempt
  to escalate credentials to work around it. **What is verified:** the
  artifact exists, is not corrupt, and structurally contains both required
  tables with row-bearing data matching the live counts. **What is not yet
  verified:** an actual end-to-end restore. If a real restore rehearsal is
  wanted before Step 3's migration runs, it needs either a DB credential with
  `CREATE DATABASE` (to restore into a scratch database) or a separate
  scratch MariaDB instance — say so and I'll run it; I'm not blocking Step 0
  on it since it goes beyond this step's stated acceptance criteria.
- **Nothing else touched:** no session row was changed (only `SELECT COUNT`
  and read-only inspection of the offline `.gz` file ran against the real
  database); no DocType, schema, or index was modified; the failed
  `CREATE DATABASE` attempt created nothing to clean up.

**WHAT.** Take a full backup/snapshot of the `marley.local` database before
step 3 (the migration) runs. Nothing else in this checklist needs one — this is
the only step that mutates real session rows.

**WHY.** Step 3 changes `status`/`close_reason`/`ended_at` on 6 real session
documents. Every other step here is either pure code, a schema addition with no
data rewrite, or reversible by re-running an idempotent patch. This one is not:
if the migration's evidence-derivation turns out wrong for a row, the fix is
"restore the snapshot," not "run an inverse script."

**HOW.** Whatever this environment's standard backup mechanism is (Frappe
Cloud's own snapshot, or a `mysqldump` of `tabAI Encounter Session` and
`tabAI Transcript Segment` at minimum) — taken immediately before step 3, not
at the start of this checklist, so it reflects the state step 1–2 actually left
behind.

**WHEN.** Immediately before step 3. Steps 1–2 don't need it.

**USER STORY.** An engineer runs the Phase 3 migration on a Tuesday afternoon →
the migration closes `AIES-2026-00143` as a duplicate of `AIES-2026-00049` → a
week later someone points out `00143` actually belonged to a *different*
encounter's follow-up visit that the evidence didn't capture → **without a
snapshot**, the only way back is to hand-reconstruct one session's
`status`/`ended_at`/`close_reason` from memory and the Version log; **with
one**, it's a restore of the exact pre-migration row.

**EXAMPLE.** The row this checklist is actually resolving, so there's something
concrete to check the backup against afterward:
```
AIES-2026-00143 · encounter HLC-ENC-2026-00053 · Recording · 0 segments
→ after step 3: Stopped · close_reason=duplicate_resolved
```

---

## 1. Deploy the race-handling code

- [x] **Done**

**Verification note (2026-08-26):**
- **File changed:** `remedisys_healthcare_ai/api/ai/sessions.py` only. +120/−16.
- **What landed:** `_find_active_session()` (new, **encounter-scoped** — the
  `session_user` filter is gone) · `_is_active_key_conflict()` (new, narrow
  guard) · `_get_or_create_draft()` now returns `(doc, reattached)` with the
  savepoint + `UniqueValidationError` → reattach path · `_envelope()` gained an
  additive `reattached: bool` · `start_session()` unpacks and forwards it.
- **False docstring corrected.** `start_session` claimed it *"Refuses to create
  a second active session for the same (encounter, logged-in user)"* — untrue,
  and the audit proved it. Now states the encounter-wide rule it actually
  implements.
- **Deliberate asymmetry documented in code**, not left as a puzzle:
  `get_active_session` keeps its `session_user` filter on purpose (resuming
  *your own* recording; returning a colleague's session there would replay
  their transcript into your consent gate before you answered it). A comment in
  the docstring says so and points at `_find_active_session`.
- **Tests: 30 pass, 0 fail** — `tests.ai.test_sessions` (17) and
  `tests.ai.test_segments` (13). Run against **`test.marley.local`**, never the
  live-data site.
- **Live DB untouched, verified before *and* after the test run:** 146
  `AI Encounter Session`, 14,187 `AI Transcript Segment`, 140 `Recording` —
  identical both times.
- **Pre-existing findings, not introduced here:** `ruff` reports one `I001`
  import-order error on this file; confirmed pre-existing by stashing the change
  and re-running. `ignore_permissions=False` on `doc.insert()` was already in
  the code and was preserved verbatim — it *enforces* permissions (Frappe skips
  the check only on a truthy value), it does not bypass them.
- **Inert until step 6, by design.** No field has `unique: 1` on this doctype
  yet, so `UniqueValidationError` cannot fire and the `except` branch is
  unreachable today. The encounter-scoped lookup, however, is live now — and it
  alone closes the `00002`/`00053` cross-clinician cause (different users, 1 and
  24 days apart), which the millisecond-race fix never touched.
- **Not done here:** the `session.reattached` realtime publish is **step 7**,
  deliberately not folded in.

**WHAT.** `api/ai/sessions.py::_get_or_create_draft` gets the savepoint +
`except frappe.UniqueValidationError` + reattach logic specified in the plan's
§7.6. The lookup query drops `session_user` from its filter — encounter-scoped,
not user-scoped.

**WHY.** This is deployed **before** the unique index exists on purpose (plan
§7.6, "deploy-before-constrain"). With no constraint yet, the new
`except` branch simply never fires — the code is inert, not risky, to ship
first. Reversing the order would leave a real window where a genuine
concurrent request hits a raw database error in front of a clinician, which is
the exact failure this whole phase exists to prevent.

**HOW.** Exact code in the plan doc §7.6 — savepoint before `.insert()`,
catch only when `"active_key"` appears in the underlying MariaDB error message,
re-raise anything else, re-fetch and return the winner on a genuine race.

**WHEN.** First. Has no dependency on the field existing yet (§7.5) — the two
can ship together or this one first; it does not depend on the index (step 6)
existing at all.

**USER STORY.** Two browser tabs for the same encounter both click "They
agreed" within the same 100ms window → **the system shows** both requests
resolving successfully, no error banner in either tab → **the database
actually contains** one session document, referenced by both responses →
**consequence:** the race that produced `00146`/`00147`/`00149`/`00151`'s
63–160ms duplicate pairs can no longer create a second row, even without the
unique index yet, once the field is added in step 2 and the index in step 6 —
this step alone doesn't yet make the *guarantee*, but it's the code path that
uses the guarantee once it exists.

**EXAMPLE.** Before this step, `_get_or_create_draft` filters on
`{"encounter": encounter, "session_user": user, "status": ("in", ACTIVE)}`.
After: `{"encounter": encounter, "status": ("in", ACTIVE)}` — no `session_user`.
This one-line filter change is what closes the `00002`/`00053` cross-clinician
gap (different users, 1 and 24 days apart) — a case the millisecond-race fix
alone does not touch.

---

## 2. Add the `active_key` field and controller enforcement

- [x] **Done**

**Verification note (2026-08-26), on `test.marley.local` only:**

- **Schema, from `information_schema` / `SHOW INDEX`, not the JSON:**
  `active_key varchar(140)`, `IS_NULLABLE=YES`, `COLUMN_DEFAULT=NULL`,
  `COLUMN_KEY=UNI`. `SHOW INDEX`: `Key_name=active_key`, `Non_unique=0`,
  `Null=YES`. Raw DDL: `` UNIQUE KEY `active_key` (`active_key`) ``. Produced
  entirely by `bench migrate` from the DocType's `unique: 1` — **no manual
  `CREATE INDEX`/`ALTER TABLE` was ever run.**
- **Lifecycle, each state independently verified against the stored column
  (not the in-memory doc):** Draft → `active_key = encounter` · Recording →
  unchanged · Stopped → SQL `NULL` (explicitly confirmed **not** `''`, via
  `active_key IS NULL` returning true and `active_key = ''` returning
  SQL-unknown) · Failed → `NULL` · Closed → `NULL`.
- **Multiple terminal sessions on one encounter:** three sessions
  (Stopped/Stopped/Closed) on the same encounter — all three `NULL`, no
  constraint violation.
- **Different encounters hold different keys:** two encounters, both
  `Recording` simultaneously, distinct `active_key` values, both succeeded.
- **Database rejects a genuine duplicate active session — the critical test,
  proven twice.** Driven through the real lifecycle (a fresh `Draft` insert on
  an encounter that already has an active session), not by forcing an invalid
  status: `frappe.exceptions.UniqueValidationError: ('AI Encounter Session',
  '<name>', IntegrityError(1062, "Duplicate entry '<encounter>' for key
  'active_key'"))`. Confirmed the rejected row never exists as a table row.
  **Finding beyond the stated bar:** rejection fires at the second `Draft`
  insert itself, not only at the `Recording` transition — because `Draft` is
  also in `_ACTIVE_STATUSES` — matching invariant S1 exactly ("at most one
  **non-terminal** session per encounter").
- **Test suites, run individually and then together in one process:**
  `tests.ai.test_segments` 13/13 · `tests.ai.test_sessions` 17/17 ·
  `test_ai_encounter_session` (`TestAIEncounterSession` + `TestActiveKey`)
  13/13 — **43/43**. Also confirmed inside a full `--app` run (184 tests,
  34 pre-existing unrelated failures in other modules — billing, clinical
  documents — untouched and unrelated to Phase 3): every one of the 43
  AI-session/segment/active_key tests still shows `✔` in that shared run,
  which is the strongest available proof of no cross-test interference.
- **Two real regressions found and fixed as their own approved, scoped
  turns — not silently:** the class-shared-encounter pattern in
  `tests/ai/test_segments.py` and, subsequently, the identical pattern in
  `test_ai_encounter_session.py` (`TestAIEncounterSession`, pre-existing, and
  `TestActiveKey`, written for this step). Root cause in both: `FrappeTestCase`
  rolls the database back **once per test class**
  (`frappe/deprecation_dumpster.py:631`,
  `cls.addClassCleanup(_rollback_db)`), not per test method, so a session one
  test method left `Draft`/`Recording` was still present for the next —
  harmless before `active_key` existed, a genuine constraint violation after.
  Fix: a fresh `Patient Encounter` per test method instead of one shared at the
  class level. No production code, no `active_key` behaviour, and no unique
  constraint were touched by either fix.
- **`test.marley.local` residue:** zero, for every entity this step created,
  confirmed by direct name/timestamp queries after cleanup. (A full `--app`
  test run, done only to attempt a combined-suite check, incidentally left 22
  `Patient` rows from unrelated pre-existing test modules — `CreateCI` /
  `BadGenderCI` / `Summary Test`, confirmed to have zero link to any AI
  Encounter Session — deleted via `frappe.delete_doc`, not raw SQL.)
- **`marley.local`, before and after every step of this verification:** 146
  `AI Encounter Session` / 14,187 `AI Transcript Segment` / 140 `Recording` /
  `active_key` column count `0` — identical throughout, including after the
  test-fixture regression fixes.
- **Production code scope:** `git status` shows only the two test files
  (`test_segments.py`, `test_ai_encounter_session.py`) as newly modified this
  session beyond what Steps 1–2 already produced. `sessions.py`, the DocType
  JSON, and the controller are unchanged from where Step 2 left them.

**WHAT.** Add `active_key` to the `AI Encounter Session` DocType:
`fieldtype: Data`, `unique: 1`, `read_only: 1`, no `not_nullable`. Add
`_stamp_active_key()` to the controller, called from `validate()`.

**WHY.** `unique: 1` on the DocType field itself is not optional styling — it
is the specific property Frappe's `get_valid_dict` checks before writing SQL
`NULL` instead of `''` for a cleared value (plan §7.2). A unique index added by
raw SQL without this field property silently reinstates the exact bug this
phase exists to fix. `read_only: 1` matters too: nothing outside the
controller should ever set this field directly, or the "cleared on every
terminal transition" guarantee has a second, unenforced writer.

**HOW.** Field spec and controller method are both written out verbatim in the
plan doc §7.3 and §7.5.

**WHEN.** After step 1 (harmless either order, but the field must exist before
step 3's migration writes to it, and step 1's code should already be live so
there is no gap once the field starts getting real values). Before step 3.

**USER STORY.** A session transitions `Recording → Stopped` via the physician's
own Stop button → **the system shows** nothing different to the physician —
this is invisible plumbing → **the database actually contains**
`active_key = NULL` on that row, set by `_stamp_active_key()` inside the same
`validate()` call that already stamps `ended_at` → **consequence:** the
encounter is now free for a future session to activate, with no caller —
today's `sessions.py`, a future Phase 4 sweep, an admin action — needing to
remember to clear the field itself.

**EXAMPLE.**
```python
def _stamp_active_key(self) -> None:
    if self.status in _ACTIVE_STATUSES:      # {"Draft", "Recording"}
        self.active_key = self.encounter
    else:
        self.active_key = None
```
No unique index exists yet at this point in the checklist — this step only
makes the field exist and get populated correctly. The constraint itself is
step 6.

---

## 3. Run the migration — close the six known duplicates

- [x] **Done**

**Verification note (2026-08-26), on `marley.local` — the first step to
mutate real session rows:**

- **Fresh backup taken first, as required, and not repeated:**
  `sites/marley.local/private/backups/20260826_160655-marley_local-database.sql.gz`
  (6,891,670 bytes, `gzip -t` clean) plus its `site_config_backup.json`. Row
  counts inside the dump (146 sessions, 14,187 segments) matched the live DB
  exactly before any change — verified by counting tuples in the dump's own
  `INSERT` statements, not assumed.
- **Safety Rules 1–3, re-verified against the live database before touching
  anything:** exactly six encounters had more than one active
  (`Draft`/`Recording`) session system-wide — no more, no fewer, matching the
  approved table exactly, name for name, segment count for segment count.
  `00149` re-confirmed as genuinely "exactly one side has segments" (1 vs 0) —
  Rule 1, not the Rule 2 manual-review case.
- **A real blocker was found before any row was touched, reported, and fixed
  only after explicit approval — not guessed around.** `close_reason` had no
  `duplicate_resolved` option on `marley.local`: confirmed in both the DocType
  JSON and the live `tabDocField` row via `information_schema`. Frappe's
  `_validate_selects()` (`frappe/model/base_document.py:1101`) would have
  thrown `ValidationError` on every one of the six saves. Root cause: the
  design plan itself flags this exact gap (§7.4: *"proposed here, not made in
  this turn"*) — Step 2 was scoped to `active_key` only and never touched it.
  Four resolution options were presented; approved: append
  `duplicate_resolved` to `close_reason`'s options — nothing else touched.
- **How the fix was applied, deliberately not via `bench migrate` or
  `reload-doctype`.** Either would re-sync the *entire* doctype's schema,
  which at this moment also includes Step 2's un-migrated `active_key` field —
  triggering exactly what this step was told not to do (add the column,
  create the index). Instead: (1) the DocType JSON on disk was updated
  (`options` line only, the repo's source of truth), and (2) on `marley.local`
  specifically, only the matching `tabDocField` row's `options` column was
  patched via `frappe.db.set_value` (a scoped ORM write, not a session
  lifecycle change), followed by `frappe.clear_cache(doctype=...)`. Confirmed
  immediately after: `active_key` column count `0`, index count `0`,
  `DocField` count `0` — untouched. A read-only dry run (`get_valid_dict()` on
  an in-memory, unsaved mutation of one loser) additionally proved
  `active_key` would not be written even though the controller still sets it
  as a Python attribute — the live meta doesn't know the field exists, so it
  never reaches `get_valid_dict()`'s output.
- **All six resolved through `doc.save()`, never raw SQL, each individually
  gated.** Before every save: re-read `status` (must still be `Recording`),
  segment count (must still be `0`), and that loser/winner share the same
  encounter — the run would have aborted with zero further rows touched on
  any mismatch; none occurred. After every save: re-read `status`,
  `close_reason`, `ended_at`, `session_user`, `started_at`, `consent_obtained`
  from the database (not the in-memory doc) and confirmed each against its
  pre-save value where the plan requires it to be unchanged.
- **Evidence-based `ended_at`, per §8.2 — every loser had 0 segments, so
  `ended_at = started_at` (`duration_seconds = 0`) for all six, never `now()`.**
- **Post-migration assertions, all read directly from `marley.local`:**
  remaining duplicate-active groups → `0`. Six losers → `Stopped` /
  `duplicate_resolved` / `ended_at` populated → `6`. Six winners still
  `Recording` → `6`. Total `AI Encounter Session` → **146** (unchanged). Total
  `AI Transcript Segment` → **14,187** (unchanged; `0` segment rows show any
  `modified` timestamp in this run's window — none touched). `Recording`
  status count → **134** (140 − 6, exactly as projected). Rows with
  `close_reason='duplicate_resolved'` → **6**, none outside the approved set.
  No session outside the six was modified in this run's time window.
- **Before/after, all six:**

  | Encounter | Winner | Loser | Winner status | Loser status | Loser `ended_at` | Loser `close_reason` | Winner segs | Loser segs |
  |---|---|---|---|---|---|---|---|---|
  | `HLC-ENC-2026-00002` | AIES-2026-00002 | AIES-2026-00004 | Recording | Stopped | 2026-07-27 05:22:42.539963 | duplicate_resolved | 3 | 0 |
  | `HLC-ENC-2026-00053` | AIES-2026-00049 | AIES-2026-00143 | Recording | Stopped | 2026-08-25 18:19:34.061699 | duplicate_resolved | 264 | 0 |
  | `HLC-ENC-2026-00146` | AIES-2026-00134 | AIES-2026-00133 | Recording | Stopped | 2026-08-16 23:33:00.733001 | duplicate_resolved | 38 | 0 |
  | `HLC-ENC-2026-00147` | AIES-2026-00136 | AIES-2026-00135 | Recording | Stopped | 2026-08-17 03:29:23.609916 | duplicate_resolved | 18 | 0 |
  | `HLC-ENC-2026-00149` | AIES-2026-00138 | AIES-2026-00137 | Recording | Stopped | 2026-08-19 13:47:40.614349 | duplicate_resolved | 1 | 0 |
  | `HLC-ENC-2026-00151` | AIES-2026-00145 | AIES-2026-00144 | Recording | Stopped | 2026-08-26 09:49:52.538099 | duplicate_resolved | 27 | 0 |

  `00149`'s note per §7.4: single-segment margin, reviewed post-hoc — auto-
  resolved under Rule 1, not held for manual review.
- **Diverged from the plan's stated HOW** — a note per this file's own
  instructions. §"HOW" above describes "a patch under `patches/v0/`"; what
  actually ran was a one-time, guarded, ad hoc script (`bench execute`) doing
  the identical `doc.save()` sequence, deleted immediately after (no trace in
  `git status`). It was not registered in `patches.txt` because it is not
  repeatable or idempotent-by-design the way a real migration patch is meant
  to be — it targets six specific, already-resolved rows and would do nothing
  useful on a second run. If this needs to exist as a formal patch for
  Frappe Cloud deployment later, that is a separate, explicit task.
- **Nothing else touched:** `git status --porcelain` on the repo root shows
  only the `close_reason` options line changed beyond what Steps 1–2 already
  produced; the temporary script and its scratch `__init__.py`/`__pycache__`
  were deleted and leave no trace. Nothing staged, nothing committed.

**WHAT.** A one-time, idempotent patch that closes exactly the 6 loser rows in
the table below, through `doc.save()` (never raw SQL), each with an
evidence-derived `ended_at` and `close_reason = "duplicate_resolved"`.

| Encounter | Keep (untouched) | Close | Evidence |
|---|---|---|---|
| `00002` | AIES-2026-00002 | AIES-2026-00004 | 3 segments vs 0 |
| `00053` | AIES-2026-00049 | AIES-2026-00143 | 264 segments vs 0 |
| `00146` | AIES-2026-00134 | AIES-2026-00133 | 38 segments vs 0 |
| `00147` | AIES-2026-00136 | AIES-2026-00135 | 18 segments vs 0 |
| `00149` | AIES-2026-00138 | AIES-2026-00137 | 1 segment vs 0 — **auto-resolved**, noted below |
| `00151` | AIES-2026-00145 | AIES-2026-00144 | 27 segments vs 0 |

**WHY.** Two things must both be true for this to be safe, and both were
checked, not assumed: (1) going through `doc.save()` — not `UPDATE` — means
`_validate_transition` proves `Recording → Stopped` is a legal move, and
`tabVersion` records the closure, making the migration itself auditable; (2)
`ended_at` must be evidence-derived (`MAX(segment.creation)` for the loser,
falling back to its own `started_at` when it has zero segments — all 6 losers
here have zero, so `ended_at = started_at`, `duration_seconds = 0`, which is
the truth) — never `now()`. This session's own earlier testing already produced
a 24-hour phantom duration by stamping `now()` on a day-old session; that
artefact is the concrete reason this rule is non-negotiable, not a
hypothetical.

`00149` gets no separate manual-approval gate. Holding it back would block the
unique index (step 6) for all six groups over a row whose loser has zero
segments regardless of the outcome. It is closed under the same rule as the
other five, with a distinct note attached to the Version/patch log:
*"single-segment margin, reviewed post-hoc."*

**HOW.** A patch under `patches/v0/` (per this repo's migration convention),
touching exactly the 6 named rows, run once against `marley.local` after the
snapshot in step 0.

**WHEN.** After steps 1–2 (the field and its controller enforcement must exist
so the closure also correctly sets `active_key = NULL`, not just `status`).
Before step 4 (backfill) and step 6 (index) — the index cannot be created while
any encounter still has two active rows.

**USER STORY.** A record-keeper six months from now opens `AIES-2026-00133`
(the loser on `00146`) to understand why it was closed → **the system shows**
`close_reason = duplicate_resolved` and a Version entry naming the winner
`AIES-2026-00134` → **the database actually contains** `ended_at = started_at`,
`duration_seconds = 0` — an honest statement that this session captured
nothing, not a fabricated multi-minute recording → **consequence:** the audit
trail answers "why was this closed" precisely, instead of the ambiguous
`system_close` (which already means "the browser tab closed cleanly" and would
have blurred two different facts into one value).

**EXAMPLE.** The row this checklist keeps coming back to, before and after:
```
BEFORE:  AIES-2026-00143  Recording  active_key=<not yet added>  segs=0
AFTER:   AIES-2026-00143  Stopped    active_key=NULL  close_reason=duplicate_resolved
         ended_at = started_at (2026-08-25 18:19:34)  duration_seconds = 0
```

---

## 4. Backfill `active_key` on the remaining rows

- [x] **Done**

**Verification note (2026-08-26), on `marley.local`:**

- **A schema-preparation sub-step ran first, gated separately ("Step 3.5")** —
  the backfill cannot write a field that doesn't exist in the live metadata,
  and `active_key` was completely absent from `marley.local` (column, index,
  and `DocField` all `0`) going into this step; Step 2 had only ever reached
  `test.marley.local`. Resolved by temporarily setting `active_key.unique: 0`
  in the DocType JSON, running a scoped `bench --site marley.local
  reload-doctype "AI Encounter Session"` (not a full `bench migrate`) to add
  the column **only** — confirmed after: `varchar(140)`, `IS_NULLABLE=YES`,
  no index (`SHOW INDEX` empty, `information_schema.statistics` count `0`) —
  then restoring the JSON to `unique: 1` without migrating again, so the repo
  reflects the true intended end-state while the live site's `DocField` still
  reads `unique=0` until step 6 actually adds the constraint. All 146 rows
  read `active_key = NULL` immediately after (the column's own default),
  session row counts (146 / 14,187 / 134 `Recording` / 12 `Stopped`) unchanged
  throughout.
- **Pre-mutation safety re-check, immediately before the first write:** site
  confirmed `marley.local`, non-production; 0 active-duplicate groups;
  status counts matched the approved analysis exactly (`Recording=134`,
  `Draft=0`, total=146); 134 active rows re-queried fresh at the point of
  mutation, matching the approved count exactly.
- **Backfill method: Approach A only** — `frappe.get_doc(name).save()` for
  each of the 134 active rows, with nothing set manually on the loaded
  document; `validate()`'s existing `_stamp_active_key()` derives
  `active_key = encounter` from `status` alone, the same logic that will
  govern every future save. No `frappe.db.set_value`, no raw SQL, no
  `ignore_permissions=True` — confirmed by inspecting the script before it
  ran, not merely intended.
- **Per-row gating, exactly as required:** before each save, re-read
  `status` and `encounter` from the database and require them to still match
  the pre-flight snapshot; after each save, re-read `active_key`, `status`,
  `encounter`, `session_user`, `started_at`, `ended_at`, `consent_obtained`,
  and `close_reason` from the database and require every field except
  `active_key` to be byte-identical to its pre-save value. All 134 rows
  passed both gates; **zero failures, zero partial state** — the
  fail-and-report-without-continuing path was written but never triggered.
- **The 12 terminal rows were deliberately not re-saved** — a scope decision,
  not an oversight, recorded here so it's visible rather than silent: they
  already read `active_key = NULL` as the column's own default the moment it
  was added in the schema-prep sub-step above, which is exactly their target
  state, and this step's own WHAT text scopes the backfill to rows not
  already correct. Verified read-only instead: all 12 still `active_key IS
  NULL`, and the six `duplicate_resolved` rows from step 3 specifically still
  read `status=Stopped`, `close_reason=duplicate_resolved`, `active_key=NULL`
  — unmodified.
- **All ten post-backfill assertions pass:** active rows missing
  `active_key` → `0`; terminal rows with a non-null `active_key` → `0`;
  duplicate `active_key` values → `0` rows; `active_key` mismatched against
  its own `encounter` → `0`; active session count → **134**; non-null
  `active_key` count → **134**; unique `active_key` count → **134** (all
  three match, as required); terminal `NULL` count → **12**; total sessions
  → **146** (unchanged); total segments → **14,187** (unchanged). No session
  outside the 134 intended rows received a non-null `active_key` (checked
  directly, count `0`).
- **Independent cross-check, not one of the ten but done anyway:** `tabVersion`
  entries against `AI Encounter Session` created since this work began
  (2026-08-26 16:00) = **140** — exactly 6 (step 3) + 134 (step 4), confirming
  no extra writes occurred beyond the intended set.
- **Nothing else touched:** the temporary script and its scratch
  `__init__.py`/`__pycache__` were deleted immediately after, leaving no
  trace in `git status`. Nothing staged, nothing committed.

**WHAT.** For every row *not* touched by step 3 (134 of the original 140
`Recording` rows, plus the 6 pre-existing `Stopped` rows), set `active_key`
according to its current `status` — the same `_stamp_active_key()` logic,
triggered by a `doc.save()` pass over every remaining row.

**WHY.** Adding the field (step 2) does not retroactively populate existing
rows — a new column starts `NULL` for everything until something writes to it.
Without this step, the 134 winners (each now the sole active row on its
encounter after step 3) would still show `active_key = NULL`, which is
indistinguishable from "terminal" — the exact opposite of what they are.

**HOW.** A patch that iterates every `AI Encounter Session` row and calls
`doc.save()` once (which now runs through the step 2 controller logic and sets
the field correctly) — no direct SQL write to `active_key`, so the same
audit/version guarantee from step 3 applies here too.

**WHEN.** After step 3 (must run against the *post-migration* state, or a
loser row not yet closed would incorrectly receive `active_key = encounter`
and immediately collide with its own winner). Before step 5's assertions and
step 6's index.

**USER STORY.** After step 3, encounter `00146` has exactly one active row
(`AIES-00134`, the winner) → this backfill runs → **the system shows** nothing
to any user, this is invisible → **the database actually contains**
`active_key = "HLC-ENC-2026-00146"` on `AIES-00134` and `active_key = NULL` on
every terminal row on that encounter → **consequence:** the encounter is now
in the exact shape the unique index (step 6) expects — one non-null key,
everything else `NULL`.

**EXAMPLE.** Projected totals, traced by hand against the actual 146-row
dataset, not asserted blind: `Recording` 140 → **134** (6 closed in step 3);
`Stopped` 6 → **12** (the 6 pre-existing plus the 6 new closures). No row is
created or destroyed — only `active_key` gets populated on all 146.

---

## 5. Run the database assertions

- [x] **Done**

**Verification note (2026-08-26), on `marley.local`, all four read-only:**

| # | Assertion | Result | Verdict |
|---|---|---|---|
| 1 | Every active row has a real key | `0` | PASS |
| 2 | Every terminal row is SQL `NULL`, not `''` | `0` | PASS |
| 3 | No two rows share a non-null key | `0` rows | PASS |
| 4 | A non-null key matches its own row's encounter | `0` | PASS |

All four ran as plain `SELECT` statements — nothing else was touched. This is
the gate: step 6 (the unique index) is now safe to run whenever explicitly
approved, since the data is already in the exact shape the index will
enforce. Not run in this turn.

**WHAT.** Four read-only checks, all of which must return zero rows before
step 6 is safe to run:

```sql
-- Every active row has a real key
SELECT COUNT(*) FROM `tabAI Encounter Session`
WHERE status IN ('Draft','Recording') AND (active_key IS NULL OR active_key = '');

-- Every terminal row is SQL NULL, not ''
SELECT COUNT(*) FROM `tabAI Encounter Session`
WHERE status IN ('Stopped','Failed','Closed') AND active_key IS NOT NULL;

-- No two rows share a non-null key
SELECT active_key, COUNT(*) FROM `tabAI Encounter Session`
WHERE active_key IS NOT NULL GROUP BY active_key HAVING COUNT(*) > 1;

-- A non-null key actually matches its own row's encounter
SELECT COUNT(*) FROM `tabAI Encounter Session`
WHERE active_key IS NOT NULL AND active_key != encounter;
```

**WHY.** This is the step that turns "I believe the migration worked" into
"I checked." The third assertion specifically is the one that would fail if
step 3 or step 4 missed a row — it's the direct SQL statement of the invariant
this entire phase exists to establish.

**HOW.** Run as plain read-only queries against `marley.local` after steps 3–4,
before step 6. Any non-zero result means stop and diagnose — do not proceed to
the index with an unresolved assertion failure.

**WHEN.** After step 4, strictly before step 6. This is the gate, not a
formality.

**USER STORY.** An engineer is about to run the schema migration that adds the
unique index → runs these four queries first → **the system shows** `0` on all
four → **the database actually contains** exactly one non-null `active_key` per
encounter that has an active session, and `NULL` everywhere else → **the
engineer proceeds to step 6 knowing, not hoping, that index creation will
succeed** rather than discovering a leftover duplicate mid-deploy.

**EXAMPLE.** If assertion 3 returned `active_key='HLC-ENC-2026-00053', COUNT=2`
at this point, it would mean step 3 failed to close `AIES-00143` — the exact
row this checklist has tracked from the start — and step 6 must not run until
that's fixed.

---

## 6. Add the unique index

- [x] **Done**

**Verification note (2026-08-26), on `marley.local`:**

- **Before:** `active_key` column present (from step 3.5), no index
  (`information_schema.statistics` count `0`), live `DocField.unique = 0`
  (deliberately left that way in step 3.5, pending this step). Data already
  proven index-ready by step 5's four assertions.
- **Mechanism:** the same scoped `bench --site marley.local reload-doctype
  "AI Encounter Session"` used in step 3.5 — not a full `bench migrate` —
  now picking up the DocType JSON's `unique: 1` (restored on disk since step
  3.5, never changed since) and syncing both the `DocField` metadata and the
  actual table constraint in one pass.
- **After, verified from `information_schema`/`SHOW INDEX`/raw DDL, not the
  JSON:** `SHOW INDEX` → `Key_name=active_key`, `Non_unique=0`, `Null=YES`,
  `Index_type=BTREE`; `information_schema.statistics` count `1`;
  `tabDocField.unique` now `1` (in sync with the JSON); raw
  `SHOW CREATE TABLE` → `` UNIQUE KEY `active_key` (`active_key`) ``. Column
  type unchanged: `varchar(140) DEFAULT NULL`.
- **Data integrity confirmed unchanged across the operation:** 146 total
  sessions, 14,187 segments, 134 `Recording`, 12 `Stopped`, 134 non-null
  `active_key` values, 134 unique — identical to the pre-index snapshot.
  Step 5's four assertions re-run **after** the index exists — all four
  still `0`/`0 rows`.
- **Zero session documents touched:** `tabVersion` entries against `AI
  Encounter Session` since this work began (2026-08-26 16:00) remained at
  **140** — the same count as before this step, confirming the schema sync
  wrote no document, only the table structure.
- **The invariant is now a database guarantee, not a migration-time fact** —
  the actual purpose of this step, per its own WHY below.
- Nothing staged, nothing committed.

**WHAT.** Schema sync (`bench migrate`) picks up `unique: 1` on the
`active_key` field and emits `ADD UNIQUE INDEX IF NOT EXISTS active_key
(active_key)` against `tabAI Encounter Session`.

**WHY.** This is the step that converts the invariant from "true right now,
by migration" into "enforced going forward, by the database, regardless of
which code calls it." Everything before this step is preparation; this is the
guarantee.

**HOW.** Standard schema sync. At 146 rows this is effectively instantaneous —
no online-schema-change tooling or phased rollout is needed at this scale.

**WHEN.** Only after step 5's four assertions all pass. Never before step 1
(the race-handling code must already be live, or a real concurrent request
between index-creation and code-deployment would surface a raw database error
to a clinician instead of a clean reattach).

**USER STORY.** A future request tries to create a second `Recording` session
for an encounter that already has one → **the system shows** the requesting
tab a normal, successful "recording" state — no error, because step 1's
`except frappe.UniqueValidationError` catches it and reattaches → **the
database actually contains** exactly one `Recording` row for that encounter,
because the second `INSERT` was rejected at the storage layer before it ever
committed → **consequence:** the duplicate-session bug this whole phase was
written to fix cannot recur, by construction, not by discipline.

**EXAMPLE.** The literal SQL Frappe emits, verified from
`frappe/database/mariadb/schema.py:85` rather than assumed:
```sql
ALTER TABLE `tabAI Encounter Session`
  ADD UNIQUE INDEX IF NOT EXISTS active_key (`active_key`);
```

---

## 7. Deploy the `session.reattached` realtime event

- [x] **Done**

**Verification note (2026-08-26), code-only change:**

- **File changed:** `remedisys_healthcare_ai/api/ai/sessions.py` only — one
  `publish_to_encounter` call, placed specifically in the
  `except frappe.UniqueValidationError` branch of `_get_or_create_draft`,
  **not** in the plain top-of-function `existing = _find_active_session(...)`
  branch. That branch also returns `reattached=True`, but it's an ordinary
  resume (or the cross-clinician case, possibly days later) — not a live race
  — so firing a new realtime event there would be noise unrelated to what
  this step is for.
- **Verified against a genuine forced collision on `test.marley.local`**
  (never `marley.local`), using the real live `active_key` unique index —
  not a mocked exception. A first session was inserted normally; a second
  `_get_or_create_draft` call had its *first* `_find_active_session` lookup
  faked to `None` (simulating the real race window where both requests'
  initial checks run before either has inserted), forcing it into the insert
  path, where it genuinely collided on the unique index
  (`IntegrityError(1062, "Duplicate entry ... for key 'active_key'")`). The
  *second*, post-rollback lookup was left real, so it found the actual
  winner — exactly as a real retry would. Result: `reattached=True`, same
  session name as call 1, and `publish_to_encounter` invoked **exactly
  once** with `event="session.reattached"`, the correct `encounter`, and
  `message={"session": <winner>}`. One test-script bug was found and fixed
  along the way — an overly broad mock had also faked the post-rollback
  lookup, incorrectly tripping the `if not winner: raise` safety branch;
  fixing the mock (not the production code) resolved it.
- **No regression:** `tests.ai.test_sessions` 17/17, `tests.ai.test_segments`
  13/13, `test_ai_encounter_session` 13/13 — all still pass.
- **Pre-existing `ruff` I001** on this file, same as noted in step 1 —
  confirmed unaffected by this change.
- **`test.marley.local` residue:** zero — the scratch `Patient`/`Patient
  Encounter`/`AI Encounter Session` created for the forced-collision test
  were deleted in the script's own cleanup; temporary script and scratch
  `__init__.py`/`__pycache__` deleted after, no trace in `git status`.
- **`marley.local` untouched by this step** — this is a pure code change; no
  session row, schema, or data on either site was modified.
- Nothing staged, nothing committed.

**WHAT.** When `_get_or_create_draft` resolves a race by reattaching, publish
`publish_to_encounter(encounter=doc.encounter, event="session.reattached",
message={"session": doc.name})` — mirroring the existing
`publish_to_encounter(event="session.stopped", ...)` call already in
`stop_session`.

**WHY.** Without this, the *losing* tab in a two-tab race gets a correct answer
from the API (it reattaches successfully, no error) but its own UI has no live
signal that anything happened — it would only notice on a manual refresh. This
uses a mechanism that already exists in the codebase for an analogous case
(`session.stopped`), rather than inventing a new one.

**HOW.** One `publish_to_encounter` call added inside the reattach branch of
step 1's code, after the winner is fetched.

**WHEN.** Can ship alongside step 1, or any time after — it has no dependency
on the field, the migration, or the index. Listed last only because it is the
lowest-priority piece of this phase: the invariant holds without it.

**USER STORY.** A physician has the same encounter open in two browser tabs and
clicks "They agreed" in both, seconds apart → tab A creates the session; tab B's
request reattaches to it → **the system shows** tab B a live update the moment
the reattach resolves, not after a manual reload → **the database** is
unaffected by this step — it's a notification, not a state change →
**consequence:** the physician sees consistent state across both tabs without
needing to know a race even happened.

**EXAMPLE.** The existing pattern this copies, verbatim from `stop_session`:
```python
publish_to_encounter(
    encounter=doc.encounter,
    event="session.stopped",
    message={"session": doc.name, "duration_seconds": doc.duration_seconds or 0,
              "close_reason": close_reason},
)
```

---

## Exit verification — all of Phase 3, together

- [x] **Done**

Run once every item above is individually checked off. This is the
plan-doc §21 exit gate, restated here as one last combined pass.

**Site split, deliberate:** two of the six checks are pure read-only queries
against `marley.local` (the real invariant that matters). The other four
require actually calling `start_session`/`stop_session`, which mutates
whatever session rows they touch — consistent with every prior step in this
phase, those ran against `test.marley.local` only, never `marley.local`.

- [x] **Two concurrent `start_session` calls on the same encounter → one row
      created, one reattached, neither caller sees an error.** Verified on
      `test.marley.local` against the real live `active_key` index (same
      forced-collision technique proven in step 7): `call1.reattached=False`,
      `call2.reattached=True`, both returned the same session name, exactly
      **1** row exists for that encounter, neither call raised. PASS.
- [x] `SELECT COUNT(*) FROM tabAI Encounter Session WHERE status NOT IN
      ('Draft','Recording') AND active_key IS NOT NULL` = `0`. Run read-only
      against **`marley.local`** → **`0`**. PASS.
- [x] **Stop a session, then start a new one on the same encounter →
      succeeds.** Verified on `test.marley.local`: `start_session` (Recording)
      → `stop_session` (`status=Stopped`) → `start_session` again on the same
      encounter → new session created, `reattached=False`, different name from
      the first, no error. PASS.
- [x] **Two different users on the same encounter converge to one session.**
      Verified on `test.marley.local` with a genuine second `User` document
      (not a mock) and a real `frappe.set_user` switch: user A creates the
      session; user B calls `start_session` on the same encounter and gets
      `reattached=True`, the same session name, exactly **1** row for that
      encounter, and — checked specifically — `session_user` on that row
      stayed user A's, proving convergence does not silently reassign
      ownership. This is the check that closes the `00002`/`00053` cause
      itself (different users, 1 and 24 days apart), not just the
      millisecond race. PASS.
- [x] **`Recording` count dropped by exactly 6 from pre-migration, no other
      status count changed unexpectedly.** Run read-only against
      **`marley.local`**: `Recording` 140 → **134** (−6); `Stopped` 6 → **12**
      (+6, exactly the six closures); `Draft`/`Failed`/`Closed` unchanged at
      `0`. PASS.
- [x] **Consent gating (Phase 1) and transcript persistence unaffected —
      regression, not a new feature test.** Re-ran fresh on
      `test.marley.local`: `tests.ai.test_sessions` 17/17, `tests.ai.test_segments`
      13/13, `test_ai_encounter_session` 13/13 — 43/43, no change from every
      prior run this phase. **Caveat, stated rather than glossed over:**
      "provider-failure finalization" (Phase 2's `_finalizeAfterProviderFailure()`)
      is frontend JS with no harness in this backend-only Phase 3 session — this
      exit check confirms the backend contract it depends on
      (`stop_session(close_reason="error")`) is unaffected, not the frontend
      flow itself, which the design plan's own Phase 2 entry already recorded
      as unexercised before Phase 3 began.
- **Cleanup:** all scratch `Patient`/`Patient Encounter`/`AI Encounter
  Session`/`User` records created for these checks were deleted in-script;
  confirmed zero residue on `test.marley.local`. Temporary script deleted, no
  trace in `git status`. **`marley.local` confirmed unchanged by this
  verification pass:** 146 sessions, 14,187 segments — identical to before.

**Not required for this exit gate, tracked separately:** §7.7's cross-clinician
stop-authorization follow-up (P1, Phase 7) and Phase 4's general orphan sweep —
neither is a dependency of Phase 3 completing.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.10 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Documentation-only fix from a full-checklist review: (1) replaced the self-contradicting "Current status" paragraph — it opened with "PHASE 3 COMPLETE" but its stale trailing sentences still claimed the `active_key` unique index didn't exist and Step 6 hadn't started; rewritten as one clean, internally consistent statement with current verified counts (146/14,187/134/12); (2) corrected the original Step 3 planning table's example session names from the stale short format (`AIES-00002`) to the actual naming series established by execution (`AIES-2026-00002`). No code, schema, data, or test changed |
| 1.9 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | **Phase 3 exit verification complete — all 6 combined checks pass.** Two read-only checks against `marley.local` (post-migration `active_key`/status invariants); four behavioral checks (concurrent reattach, stop-then-restart, cross-user convergence, regression) against `test.marley.local` only, per this phase's established site-safety split. `marley.local` confirmed unchanged (146/14,187) after the pass. **Phase 3 is now complete.** |
| 1.8 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 7 complete — `session.reattached` realtime publish added to `_get_or_create_draft`'s race-caught branch only (not the plain resume branch); verified against a genuine forced collision on the live `active_key` index on `test.marley.local`, not a mocked exception; 43/43 relevant tests still pass; `marley.local` untouched (code-only change). All 7 Phase 3 implementation steps now complete; combined exit verification not yet run |
| 1.7 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 6 complete — unique index on `active_key` created on `marley.local` via the same scoped `reload-doctype` used in step 3.5 (not `bench migrate`); verified from `information_schema`/`SHOW INDEX`/raw DDL; data unchanged (146/14,187/134/12); step 5's four assertions re-pass with the constraint live; zero session documents touched (`Version` count unchanged at 140). "At most one active session per encounter" is now a database guarantee on `marley.local` |
| 1.6 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 5 complete — all four database assertions from §5 pass read-only on `marley.local` (every active row keyed, every terminal row `NULL`, no duplicate key, key matches own encounter); data is now in the exact shape step 6's unique index will enforce |
| 1.5 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 4 complete — `active_key` backfilled on the 134 active rows on `marley.local` via `doc.save()` only, each row gated pre/post-save; required a separately-gated schema-preparation sub-step first (column added without the unique index, via scoped `reload-doctype`, since `active_key` didn't exist on `marley.local` at all going in); all 10 post-backfill assertions pass; 12 terminal rows deliberately left unsaved since already `NULL` by the column's own default; 140 `Version` entries confirm exactly the intended write set (6 + 134), nothing more |
| 1.4 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 3 complete — six approved duplicate losers closed on `marley.local` itself (first step to mutate real session rows), after a fresh pre-migration backup; a genuine mid-step blocker (`close_reason="duplicate_resolved"` not yet a legal Select value) found, reported with 4 options, and fixed by explicit approval via a scoped DocField-only metadata patch (no `active_key`/index/schema sync); all post-migration assertions pass; `marley.local` row counts unchanged (146/14,187), `Recording` 140→134 |
| 1.3 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 2 complete — `active_key` field + unique index verified on `test.marley.local` (schema, full lifecycle, cross-encounter, DB-level duplicate rejection, NULL-vs-empty-string); two test-fixture regressions found and fixed in scoped follow-up turns (`test_segments.py`, `test_ai_encounter_session.py`), root cause `FrappeTestCase`'s per-class rollback; 43/43 relevant tests pass individually and inside one combined process run; `marley.local` proven unchanged throughout |
| 1.2 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Step 1 complete — race-handling code deployed in `api/ai/sessions.py` (encounter-scoped lookup, savepoint + `UniqueValidationError` reattach, additive `reattached` field); 30 tests pass on the test site; live DB verified untouched |
| 1.1 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Added the scope-confirmation section: the field-level audit's five out-of-scope findings (A–E), and explicit confirmation that `active_key`, encounter-wide uniqueness, `unique: 1` on the DocType field, and "remove no unused field" all stand unchanged. Step 0 marked complete |
| 1.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Initial version — checklist form of the approved Phase 3 design, one item per implementation step, each with WHAT/WHY/HOW/WHEN, a user story, and a concrete example |
