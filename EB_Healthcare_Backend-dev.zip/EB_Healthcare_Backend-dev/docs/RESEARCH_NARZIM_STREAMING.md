# Research — Streaming NarzimGPT Replies Token by Token

**Doc status:** record · **Created:** 2026-08-27 by Ashutosh (AI-assisted) · **Updated:** 2026-08-27 by Ashutosh (AI-assisted) · **Version:** 1.1

**This is a `record` — a dated snapshot of the investigation, with live measurements taken on
2026-08-27 against `mysite.localhost`.** It is not maintained. Per `../CLAUDE.md` §9, it reading
out-of-date later is correct behaviour, not a defect.

**Outcome: approach A was implemented the same day.** The decision is owned by
[`adr/adr-048-narzim-streaming-sse-not-background-jobs.md`](adr/adr-048-narzim-streaming-sse-not-background-jobs.md);
the shipped behaviour is owned by the code and its 14 tests. §9's open questions were resolved —
see §10 below.

---

## 1. The request

> "when i ask something in narzim gpt then it thinks then prints whole data at once not line by
> line like modern chat ai's work like chatgpt, deepseek etc so i want that in narzim gpt"

Restated precisely, because the wrong reading leads to the wrong build: the ask is to **reduce
time-to-first-token**, so text appears as the model generates it. It is *not* a request to animate
a reveal of an answer that has already fully arrived — that would leave the wait unchanged and only
decorate it. §7 approach C covers why that distinction matters.

## 2. What happens today

Four independent buffers sit in series. Removing any one of them changes nothing.

| # | Layer | Location | What blocks |
|---|---|---|---|
| 1 | Provider call | `integrations/openai.py::_call_with_tools` (~line 840) | `requests.post(...)` without `stream=True` — returns only when the last token has been generated |
| 2 | Provider adapter | `integrations/openai.py::answer_general_question` | returns a finished `dict` (`text`, `model`, `tokens_in/out`, `cost_usd`, `latency_ms`) |
| 3 | Service + API | `services/narzim_assistant.py:229` → `api/v1/narzim_assistant/api.py:49` | persists the reply, then returns a dict which Frappe serialises as one JSON body |
| 4 | BFF | EHR `src/app/api/ai/narzim-assistant/send/route.ts:51` | `await res.json()` — waits for the complete body before responding to the browser |

The panel (`components/narzim/narzim-ai/narzim-chat-panel.tsx`) then shows `send.isPending` as
`Thinking…` for the entire duration and renders the reply only after a thread refetch. Its own
header comment states the constraint plainly: *"the backend only ever answers with the assistant
reply once the whole exchange has already landed, so only the user's own turn is ever optimistic
here, never the reply."*

### 2.1 Active configuration at the time of measurement

Read from `AI Settings` on `mysite.localhost`, not assumed:

| Setting | Value |
|---|---|
| `llm_provider` | **OpenAI** (`anthropic_api_key` is not configured on this site at all) |
| `openai_model` | `gpt-5-mini` |
| `_is_reasoning_model()` | **True** (`model.startswith("gpt-5")`) |
| `openai_reasoning_effort` | `low` |
| `narzim_assistant_max_tokens` | `350` |
| `_effective_max_tokens()` | `3350` (350 + `_REASONING_TOKEN_HEADROOM` of 3000) |

The provider matters: the Anthropic adapter is the more obvious file to read first and is the
**wrong one**. Both adapters need the same change, but only OpenAI is exercised today.

## 3. Measurements

Live streaming calls to `gpt-5-mini`, `reasoning_effort=low`, `max_completion_tokens=3350` —
the same parameters the app itself sends. Wall-clock from request start.

| Prompt | First content token | Total | Wait removed |
|---|---|---|---|
| `"What is RAG?"` | **2.33s** | 12.31s | 9.98s — **81.1%** |
| `"What is RAG? Explain in deep detail…"` | **4.75s** | 45.90s | 41.15s — **89.6%** |

The second row is the case in the report: 46 seconds of `Thinking…`, then everything at once.
Streaming turns that into 4.75 seconds of `Thinking…` followed by 41 seconds of visible progress.

Supporting detail from the same runs:

- **2,661 content deltas** on the long answer. The transport must handle a few dozen small
  messages per second, not a handful.
- **`reasoning_tokens` was only 64 (short) and 256 (long)** at `effort=low`. Reasoning is *not*
  the bottleneck — worth establishing, because a reasoning model raises the fair question of
  whether a dead period before the first token is unavoidable. At this effort it costs well under
  a second. Raising `openai_reasoning_effort` would change that.
- `content-type: text/event-stream` — the provider already speaks SSE. No format invention needed.

### 3.1 Incidental finding: the 350-token length cap is not doing its job

`_narzim_max_tokens()` returns 350, added on 2026-08-01 in response to "too slow, too long"
feedback, with the documented intent of capping *answer length*. On a reasoning model
`_effective_max_tokens()` raises the request to 3350, and OpenAI's `max_completion_tokens` is a
**single shared budget across reasoning and content — it does not reserve**. With reasoning
spending only 64–256 tokens, content is free to use roughly 3,100.

Measured: the long answer produced **12,623 characters**, far beyond what a 350-token cap implies.

So the intended cap is roughly 9× looser than designed whenever a `gpt-5*` model is selected. This
is a real and separate lever on the same complaint — a working cap would make answers shorter
*and* faster. It is **recorded here, not fixed**, because shortening answers is a product decision
and was not what was asked for.

## 4. Can a Frappe whitelisted method stream at all?

Yes. This was the expected blocker and it is not one.

**Evidence in the framework** (`frappe` 16.31.0):

- `frappe/handler.py:57` and `frappe/api/__init__.py:64` both contain
  `if isinstance(data, Response): return data` — *"method returns a response object, pass it on"*.
  A whitelisted method may return a `werkzeug.wrappers.Response` and the framework will not touch
  it.
- `frappe/utils/response.py::build_response` has **no** streaming type — every branch assigns
  `response.data`, a complete buffer. So the ordinary return path can never stream; returning a
  `Response` directly is the only route.
- `frappe/app.py::process_response` (line 249) only sets headers — cache-control, CORS, cookies,
  rate-limit. No buffering, no compression.

**Verified empirically** rather than inferred, because the teardown ordering is the part that
would silently break it. `frappe/app.py::after_response_wrapper` (line 76) wraps the WSGI app in a
`ClosingIterator` whose close callbacks include `frappe.destroy`. A direct werkzeug test confirms:

```
is_streamed: True
generator ran at construction time?  NO — lazy
ordering: iterator-returned-to-wsgi-server -> yield-0 -> yield-1 -> yield-2 -> frappe.destroy
```

`frappe.destroy` fires **after** the last yield, so `frappe.local` and the database connection are
still alive inside the generator. This is what makes it possible to persist the assistant message
at the end of the stream.

Two further pieces of luck, both checked:

- Both adapters use raw `requests.post`, not a vendor SDK, so `stream=True` + `iter_lines()` is
  sufficient. No new dependency.
- `answer_general_question` returns **plain text**, unlike the lab extractors which are
  schema-locked structured output. There is no partial-JSON problem. The panel renders with
  `whitespace-pre-wrap` and no markdown library, so appending a delta is a plain string append.

## 5. Traps

Each of these is a silent failure, not a loud one.

1. **`sync_database()` runs before the body is iterated.** `frappe/app.py:151` commits in the
   `else` branch of `application()`, which completes when the `Response` object is *returned* —
   before WSGI pulls the first chunk. Any write inside the generator must therefore call
   `frappe.db.commit()` itself. Get this wrong and replies stream perfectly to the screen and are
   never saved.

2. **The empty-response guard cannot stay where it is.** `openai.py::_call` raises `ValueError`
   when `message.content` is blank (finish_reason `length`, exhausted reasoning budget). Streaming
   only knows this at the end — by which time HTTP 200 and the headers are long gone. The error has
   to travel as a terminal SSE `error` event and be rendered by the panel, not as a status code.

3. **Production nginx buffers proxied responses.** This bench has no `config/nginx.conf` and serves
   via `bench serve` (werkzeug), so streaming will work locally and appear broken on the server.
   Needs `X-Accel-Buffering: no` on the response. This is the same class of environment-difference
   bug that cost a day on the notification SSE handshake — see `PUSH_NOTIFICATIONS.md` §4.

4. **`gunicorn_workers: 25`, `background_workers: 1`.** A streaming response occupies a gunicorn
   worker for the full generation — up to ~46s measured. At 25 workers and single-digit concurrent
   NarzimGPT users this is affordable, but it is a real capacity change and the number to watch.
   The single background worker is what rules out §7 approach B.

5. **Cost and usage accounting must survive.** `AI Narzim Assistant Message` carries `tokens_in`,
   `tokens_out` and `cost_usd`, and `get_usage_summary()` reports on them. OpenAI only sends usage
   when `stream_options: {"include_usage": true}` is set, in a final chunk that has an empty
   `choices` array — easy to skip past with a naive delta loop.

## 6. Non-goals

- **The encounter copilot** (`ask_copilot_agent`) is a separate path with tool-calling, where
  streaming interacts with the tool loop and is materially harder. Explicitly out of scope.
- **Markdown rendering.** The panel currently prints raw text, which is why the report's bullets
  appear as literal `-` characters. Worth doing, unrelated to streaming, and cheaper to reason
  about separately.
- **Shortening answers.** See §3.1 — recorded, not actioned.

## 7. Approaches considered

Per `../CLAUDE.md` §10, four were weighed.

### A — SSE end to end *(recommended)*

Frappe returns a streaming `Response` of `text/event-stream`; the BFF forwards `upstream.body`
unmodified; the panel consumes it with a fetch reader and appends deltas to local state. A final
event carries `message_name`, token counts and cost.

- **For:** the standard shape every comparable product uses; one round trip; the code path is
  genuinely open (§4); no new infrastructure; the existing `Stop` button maps cleanly onto aborting
  the fetch, which closes the generator.
- **Against:** holds a gunicorn worker for the generation (trap 4).

### B — Background job publishing chunks over socket.io

Reuse the realtime relay built on 2026-08-25 for notifications: enqueue the LLM call, have the
worker `publish_realtime` each delta, let the EHR's existing SSE bridge forward them.

- **For:** frees the web worker; generation survives the client navigating away.
- **Against:** **`background_workers: 1`** — one concurrent stream site-wide, queued behind
  notification and email jobs. Also inserts four hops per delta (worker → redis → socketio node →
  Next.js SSE route → browser) for a payload measured at 2,661 deltas, and needs sequence numbers,
  room auth and replay-on-reconnect. Rejected on the worker count alone.

### C — Client-side typewriter over the existing blocking call

Keep everything, animate the reveal.

- **For:** ~20 lines, no backend risk.
- **Against:** the user still waits the full 46s on `Thinking…`, then watches a fast animation. It
  does not reduce time-to-first-token by a single millisecond — it misrepresents progress. Rejected
  as answering a question that was not asked.

### D — Chunked plain text without SSE framing

- **For:** the simplest possible transport.
- **Against:** no channel for `message_name`, usage, cost, or a mid-stream error (trap 2, trap 5).
  Rejected.

## 8. Implementation sketch for approach A

Ordered so each step is independently verifiable.

1. **Provider adapters** — add a streaming sibling to `_call`, e.g.
   `stream_call(*, system, user, max_tokens, temperature) -> Iterator[str]`, using
   `requests.post(..., stream=True)` and `iter_lines()`. Set
   `stream_options={"include_usage": True}`. Yield content deltas; capture the final usage chunk.
   Needed in `integrations/openai.py` first (the active provider) and
   `integrations/anthropic.py` for parity — its event names differ
   (`content_block_delta`, not `choices[].delta`).
2. **Adapter API** — `answer_general_question_stream(history, message)`, yielding text and
   finishing with the same metadata dict the blocking version returns, so §5 trap 5 is structural
   rather than remembered.
3. **Service** — a streaming `send_message` in `services/narzim_assistant.py` that yields deltas,
   then persists the `AI Narzim Assistant Message` and **commits explicitly** (trap 1).
4. **API** — a new whitelisted `send_message_stream` returning
   `Response(generator, mimetype="text/event-stream")` with `X-Accel-Buffering: no` (trap 3) and
   `Cache-Control: no-cache`. Keep the existing `send_message` untouched so the change is
   reversible and the fallback is real.
5. **BFF** — a route that forwards `upstream.body` straight through, preserving the abort signal.
   No `await res.json()`.
6. **Panel** — consume the reader, append deltas, keep `Thinking…` only until the first delta
   arrives, then swap to live text. `Stop` aborts the fetch.

Verification at each layer: a direct `curl` against the Frappe endpoint should print tokens
progressively; a `curl` against the BFF should do the same; anything that prints all at once
identifies exactly which hop is still buffering.

## 9. Open questions

| Question | Why it matters |
|---|---|
| Keep persisting and costing the streamed reply? | Recommended yes — `get_usage_summary()` depends on it. Adds the final-event machinery in step 2. |
| What should `Stop` mean server-side? | Aborting the fetch closes the generator, but a partial reply has been generated and paid for. Persist the partial text, or discard it? |
| Should the reasoning phase be labelled? | `Thinking…` is literally accurate for the first ~2–5s on a reasoning model, and could stay as a distinct state before text begins. |

## 10. Resolved on implementation (2026-08-27)

All three §9 questions were settled during the build, and two things were found that the
investigation had not predicted.

| §9 question | Resolution |
|---|---|
| Persist and cost the streamed reply? | **Yes.** The terminal `done` event returns the same keys the blocking call returns, so the two paths cannot drift structurally. Verified live: `tokens_in/out = 899/1730`, `cost_usd = 0.003685` recorded on both the message row and the linked `AI Prompt Log`. |
| What should `Stop` mean? | **Persist the partial answer.** The text was generated, paid for, and already read. Verified: a stream killed at 6s kept 1,662 characters, with `AI Prompt Log.error = "client stopped the stream"` so partial rows stay distinguishable. |
| Label the reasoning phase? | **Kept as `Thinking…`, but only until the first token.** It is literally accurate for that window; after the first delta the text itself is the progress indicator, so a separate `waiting` flag ends it. |

### Two findings not predicted by this research

1. **Only the OpenAI adapter had the streaming method, and `llm_provider` is switchable at runtime
   from AI Settings with no code change.** Selecting Anthropic would have raised `AttributeError` at
   the user. Both adapters now implement it, and the service also degrades to the blocking call for
   any adapter that lacks it, rather than raising.

2. **Anthropic's stream shape differs from OpenAI's in three ways that each cost a silent bug** —
   deltas arrive as `content_block_delta.delta.text`; usage is split across `message_start`
   (input) and `message_delta` (output) rather than one final chunk; and `stop_reason` is
   `"max_tokens"` where OpenAI says `"length"`. The adapter normalises all three so the service
   layer stays provider-agnostic.

### Measured result

| Prompt | Before | First token after | Wait removed |
|---|---|---|---|
| `"What is RAG?"` | 12.31s | 2.33s | 81.1% |
| `"explain in deep"` | 45.90s | 4.75s | **89.6%** |

Re-verified through the real endpoint over HTTP after the refactors: 2.48s to first token against
19.24s total across 1,593 deltas — 87.1% of the wait removed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-27 | Ashutosh (AI-assisted) | Added §10: open questions resolved, the two unpredicted findings (provider parity, Anthropic event shape), and the measured outcome |
| 1.0 | 2026-08-27 | Ashutosh (AI-assisted) | Initial investigation: four-buffer analysis, live TTFT measurements on gpt-5-mini, proof that Frappe passes a streaming `Response` through, five traps, four approaches |
