# Clinical Command Center (formerly Live Queue) — How It Works

**Doc status:** living · **Created:** 2026-09-09 by Divyanshu (AI-assisted) · **Updated:** 2026-09-10 by Divyanshu (AI-assisted) · **Version:** 1.12

**Status of the build: Done, backend and frontend, exercised live in a real browser — see §8.** Backend
verified with 6/6 reassign tests (`test_reassign_availability_guard.py`) and 11/11 Queue Stage Log tests
(`test_queue_stage_log.py`, 3 of them going through the real API endpoints rather than a manual hook call —
see the correction below) passing live against `remedisis.localhost`, plus a live manual verification of
the "keep original fee" checkbox (§3) confirming `Patient Appointment.paid_amount` stays at the original
fee and no invoice is created; frontend verified with a clean typecheck, a clean lint diff (3 pre-existing
lint errors and 23 pre-existing warnings elsewhere in `mission-control-client.tsx`, untouched by this work,
and not this feature's to fix), and i18n parity (6978 keys, en↔es aligned).

**Correction, 2026-09-09 — the first real browser use of this feature found three live bugs, all fixed the
same day** (superseding this section's earlier "not yet exercised in a running browser" note, and the "Done
— 8/8 passing" claim §8 made for Queue Stage Log): the reassign control was invisible on a Nursing Room
card for any role but Nurse; Queue Stage Log never actually tracked a real room transition made through the
real check-in/status/cancel endpoints (only through a manual test-only hook call); and the appointment
drawer's "Paid" figure double-counted a refunded delta invoice. Full root cause for each is in
ADR-063 §5 and [WORK_LOG — 2026-09-09](../WORK_LOG.md); not restated here.
This document was written ahead of implementation, alongside
[`adr-063-clinical-command-center-reassign-and-stage-logging.md`](adr/adr-063-clinical-command-center-reassign-and-stage-logging.md).
See §8 for the build checklist as the single place progress is tracked.

**This document owns the mechanism.** The decision and rejected alternatives are owned by ADR-063; this
document does not restate them.

## 1. Scope

| In scope | Out of scope |
|---|---|
| Reassigning the practitioner directly from a card in Arriving Soon / Waiting Room / Nursing Room | Reassigning once a Patient Encounter exists (Practitioner Room / Checkout) — stays locked, unchanged |
| Recording how long each visit spends in each of the five rooms, for later reporting | Live, minute-by-minute display of every card's current duration on the board itself (may follow later — the data this needs is a side effect of this build, but the board UI itself is unchanged here except for the tips panel) |
| Encounter authoring time, read off the Practitioner Room row | A second, separate encounter-timing mechanism — deliberately not built (§4) |
| Short, role-specific tips built from data already on the board | An LLM-generated or open-ended tips system (see ADR-063 decision 3 alternatives) |
| Renaming "Live Queue" to "Clinical Command Center" in the UI | Renaming or touching the separate, existing admin "Command Centre" tab |

## 2. The screen today, unchanged by this work

Five columns, each populated by a rule already in production (`api/v1/dashboard/api.py:203-241`):

```
arriving_soon        Patient Appointment.status == "Open"
waiting_room         Patient Appointment.status == "Confirmed"
nursing_room         Patient Appointment.status == "Checked In"
practitioner_room     a Draft Patient Encounter exists
checkout              a submitted Patient Encounter exists
```

This ADR/doc does not change this rule. Everything below either reads it (the stage-log hooks watch for
these same transitions) or adds a control alongside it (reassignment, tips) — none of it replaces it.

## 3. Inline reassignment

**Final design — a 3-step picker, not a single pick-and-confirm.** The first cut built here checked whether
a candidate could take the appointment's *original* slot; rejected on sight the same day ("show the list of
all practitioner and as we select than show the all available slot user select the slot and than
reassign"). What's actually built:

```
Staff clicks the practitioner's name/avatar on a queue card
   (only rendered on Arriving Soon / Waiting Room / Nursing Room cards)
                              │
                              ▼
STEP 1 — GET /api/appointments/{id}/reassignment-candidates
   → get_reassignment_candidates(appointment)   [read-only, no billing computation]
      Every ACTIVE practitioner except the current one — plain list, nothing
      about fee shown or computed here (see "do not show fee differ" below;
      the fee appears exactly once, in step 3)
      → {practitioner, practitioner_name}
                              │  staff picks a candidate
                              ▼
STEP 2 — useAvailableSlots(candidate, "", appointment_date, {requireServiceUnit:false})
   → get_available_slots(candidate, date)   [EXISTING, unmodified — same function the
                                              normal booking screen's own slot picker uses]
      Already merges holidays/leave, self-declared Unavailable, real bookings, and
      ADR-062 Available overrides — the picker just filters to slots.available===true
                              │  staff picks an open time — may differ from the original time
                              ▼
STEP 3 — useReschedulePaymentPreview(appointment, candidate, appointment_type, paymentTiming)
   → preview_reschedule_payment(...)   [EXISTING, unmodified — the SAME hook
                                         NewAppointmentDialog's reschedule mode uses]
      If adjustment.type !== "None": shows the amount, a Pay Now/Pay Later
      toggle (usePaymentMethods for the mode-of-payment select), and a refund
      note — identical copy/layout to the reschedule drawer's own payment step
                              │  staff confirms (picks a payment method first, if Pay Now)
                              ▼
        POST /api/appointments/{id}/reschedule-with-payment
   → reschedule_appointment_with_payment(appointment, new_practitioner, new_appointment_date,
                                          new_appointment_time, payment_timing, mode_of_payment)
      [EXISTING, unmodified endpoint — NOT reassign_appointment]
      Settles whatever the delta actually is: nothing if same fee, an
      additional payment (now or deferred to checkout) if higher, an
      immediate refund via Credit Note if lower
                              │
                              ▼
              Card re-renders with the new practitioner and (possibly) new time
```

**Fee-difference revision, same day — "go with payment too as we are doing in the reschedule."** The
design above originally stopped at step 1: a different fee marked a candidate unavailable outright, per the
explicit instruction at the time ("only show slots where the fee is unchanged"). That was superseded the
same day by a follow-up instruction to settle the difference instead, the same way the Appointments screen's
own reschedule drawer already does. Put to the product owner as an explicit either/or — keep the 3-step
picker and add a payment step inside it, or replace the picker with the full `RescheduleDialog`
(`NewAppointmentDialog`, `dialogMode="reschedule"`) outright — the answer was **"keep in same modal only."**
So the picker's shape is unchanged (still doctor → slot → confirm); what changed is that step 3 no longer
assumes "nothing owed." `get_reassignment_candidates` stopped gating on fee at all (`available` is now a real
error signal only); the dialog gained the payment block described above, built by calling the exact same
hooks (`useReschedulePaymentPreview`, `usePaymentMethods`, `useRescheduleWithPayment`) and reusing the exact
same `newAppt` i18n copy `NewAppointmentDialog` already ships for this — so the money math, and the words
describing it, cannot drift between the two dialogs. One new user-facing string was added at this point:
`queue.reassignFeeDiffers` ("Fee differs"), the step-1 badge. **Removed again the same day — see below.**

**"Do not show fee differ," same day, reversing the step-1 badge above.** The fee-difference revision put
the fee in two places: a "Fee differs" hint at step 1, and the real preview at step 3. The product owner's
next instruction removed the first of those — the fee is shown exactly once, in step 3, not previewed twice
in two different shapes. `get_reassignment_candidates` was simplified back to a plain listing: no
`_reschedule_quote` call per candidate, no `available`/`reason`/`same_fee`/`fee_incl_tax` fields, no
per-candidate try/except (nothing left there can fail candidate-by-candidate), and `original_practitioner`
is now read with a single `frappe.db.get_value` instead of loading the full `Patient Appointment` document,
since nothing else in the function needed it. `QueueReassignDialog`'s step-1 rows lost the ✓/✗ icon, the
disabled state, and the badge — every candidate is now a plain, always-clickable row; step 3's payment block
is unaffected and remains the only place the fee appears. `queue.reassignFeeDiffers` was removed from both
locales as unused. See ADR-063 §1's revision table for the earlier "why keep the picker instead of the full
reschedule drawer" reasoning, which this change does not revisit.

**"Keep the original fee" checkbox, same day — the emergency-reassignment case.** Scenario: front desk books
with a cheaper doctor, that doctor becomes unavailable (an emergency, not the patient's choice), the patient
is moved to whoever else is free, who may charge more — "patient may deny to pay more," and the clinic
caused the increase, not the patient. Step 3 gained a checkbox, shown only when the move would otherwise
cost more (`delta > 0 || deferred > 0` — never for a refund, which already favors the patient). Checked, it
sends `fee_override = preview.old.fee` to `reschedule_appointment_with_payment` — the SAME parameter front
desk already uses to negotiate a rate at booking, no backend change. This is not merely "defer to
checkout" (that was considered and rejected — the higher fee would still eventually be billed, which does
not solve "may deny to pay more"): with the fee pinned back to what it was, there is nothing left to charge,
ever. Verified live: reassigning a never-invoiced 500-fee appointment to a 2000-fee practitioner with
`fee_override=500` leaves `Patient Appointment.paid_amount` at `500.0` (not `2000.0`) and creates no Sales
Invoice — the technical response still says `adjustment.type="Deferred"`, `amount=500.0`, which reads like a
charge in isolation but is exactly the amount already owed, restated (see the `_reschedule_quote`/`old_paid`
note above for why this endpoint's numbers read this way for a never-invoiced appointment). The frontend
hides the "Additional amount due" badge when checked (it reads off the un-overridden preview and would
otherwise show a stale number) and shows a plain "will be billed {old fee}, same as before" note instead.
Two new i18n keys, `queue.reassignKeepOriginalFee`/`queue.reassignKeepOriginalFeeNote` — genuinely new
copy, since `NewAppointmentDialog`'s reschedule mode has no equivalent waiver concept to reuse.

Two already-existing, already-tested backend pieces cover steps 2 and 3 entirely — this took almost no new
backend code beyond step 1's fee check and two safety-net fixes (below). `reassign_appointment` (the
title/availability fixes described next) is **no longer what commits a reassignment from this screen** —
it stays as-is for whatever else calls it directly, but the Live Queue picker now always goes through
`reschedule_appointment_with_payment`.

The only new frontend code is the trigger and the 3-step dialog body. **Corrected during implementation:**
`QUEUE_ACTION_CAP` (`mission-control-client.tsx:566`) turned out to be dead code — defined but never
actually referenced anywhere in the file, confirmed by grep before building anything on top of it. The
reassign control is gated by `canActOnRoom`/`ROOM_ROLES` instead (`mission-control-client.tsx:672,663`) —
the mechanism every other room control on this screen actually uses — restricted to a new
`REASSIGNABLE_ROOMS` set matching `_REASSIGNABLE_STATUSES` exactly.

**Correctness fix #1, 2026-09-09 — `reassign_appointment` was not actually "unmodified."** Reported live by
the product owner from a real reassignment (`HLC-APP-2026-00326`): the Desk heading stayed on the OLD
practitioner's name after reassigning. Root cause: core's `title` field ("{patient} with {practitioner}",
`set_title()`) only recomputes inside `validate()`, and `reassign_appointment` writes through
`frappe.db.set_value` — not `doc.save()` — specifically because `practitioner` is `set_only_once` in core
and a real save would reject the change. So `validate()` never runs, and neither does `set_title()`.
**Fixed:** `title` is now computed the same way and written into the same `db.set_value` call that already
refreshed `practitioner_name`. Also had zero check that the new practitioner could actually take the slot —
**fixed** by calling `assert_bookable` + `doc.validate_overlaps()` (in-memory-only mutation, never saved)
before the swap.

**Correctness fix #2, found while wiring step 3 above — the exact same gap existed in
`reschedule_appointment_with_payment`.** It had no `assert_bookable` call at all for the target practitioner
(core's own `validate_overlaps()` WAS already covered here, indirectly, since this function's write path
goes through a real `doc.save()`, unlike `reassign_appointment`'s raw `db.set_value`). **Fixed** the same
way, but gated to only run when the slot is actually moving (a bare fee/payment-timing adjustment on an
already-valid, already-booked slot must not be retroactively rejected just because availability data
changed for that slot *after* it was booked).

**Fee-parity bug, found writing the FIRST test for step 1, back when step 1 still computed a fee at all:**
the naive approach — checking `quote["adjustment"]["type"] == "None"` — was wrong. `adjustment` answers "is
money owed given what has already been PAID," not "did the fee change." For a never-invoiced appointment
(every Arriving Soon/Waiting Room card, before checkout), nothing paid yet reads as the *entire new fee*
being owed, regardless of whether the fee actually moved. Comparing `quote["old"]["fee_incl_tax"]` against
`quote["new"]["fee_incl_tax"]` directly was the fix at the time — moot now that step 1 does no fee
computation at all ("do not show fee differ," below), kept here as the historical record of a real bug, not
a description of current code.

**Test-hygiene finding, unrelated to the feature but worth recording:** this test file's fixtures were
leaking past `tearDown` on every run, even ones reporting 0 failures — `frappe.db.commit()` (added earlier
to survive the `handle_api_errors`-rollback gotcha) also defeats `FrappeTestCase`'s own rollback-based
isolation, so `tearDown`'s explicit deletes are the *only* safety net, and one silently-failing delete
(a transient Frappe race between a `User` and its auto-created `Contact`) meant real leftovers every time.
Fixed with a random per-`setUp` suffix (makes cross-run collisions structurally impossible) plus a
one-time delete retry.

**Current tests** (after the "do not show fee differ" revision below): `tests/appointments/test_reassign_availability_guard.py`, 6 total, all passing live on `remedisis.localhost` — excludes the current
practitioner from candidates, asserts a wildly-different-fee candidate still appears with exactly
`{practitioner, practitioner_name}` and no billing side-channel (`test_candidates_do_no_fee_computation` —
replaced the two fee-semantics tests the earlier revision added, which asserted fields that no longer
exist), refreshes title/practitioner_name on a real reassign, blocks `reassign_appointment` when the new
practitioner is self-declared-unavailable, blocks it on a genuine double-booking, and blocks
`reschedule_appointment_with_payment` the same way. The 12 pre-existing mock-based tests
(`test_visibility_reassign.py`) were re-verified unaffected. New BFF route:
`src/app/api/appointments/[id]/reassignment-candidates/route.ts` (step 1 only — steps 2 and 3 reuse
`/api/appointments/slots`, `/api/appointments/[id]/reschedule-payment-preview`, and
`/api/appointments/[id]/reschedule-with-payment`, all pre-existing — the payment-preview route was already
built for the Appointments screen's own reschedule drawer and had never been used by the Live Queue
picker until the (now-reversed) fee-difference revision).

## 4. Queue Stage Log — per-room timing

**One row per visit per room-stay.** Written directly, never via the parent `Patient Appointment` document
(see ADR-063 for why — write-volume at this app's real scale was the deciding factor).

```
DOCTYPE: Queue Stage Log
  appointment    Link -> Patient Appointment      required
  room           Select: arriving_soon | waiting_room | nursing_room
                          | practitioner_room | checkout
  practitioner   Link -> Healthcare Practitioner   snapshot at time of entry
  company        Link -> Company                   from Patient Appointment.company
                                                     (verify populated; else practitioner's
                                                     custom_company, same convention as
                                                     get_command_center)
  encounter      Link -> Patient Encounter, null    ONLY set on the practitioner_room row
  entered_at     Datetime                           required
  exited_at      Datetime, null                     set when the visit leaves this room
  duration_min   Int, null                          computed once, on exit — a plain calculation,
                                                     nothing configurable, no "delayed" judgment
```

**Why the Practitioner Room row doubles as the encounter timer.** `practitioner_room` already *means* "a
Draft encounter exists" — so this row's own `entered_at` (Draft created) and `exited_at` (submitted) already
answer "how long did the encounter take." The only field this row needs beyond every other row is which
encounter (`encounter`) — not a second pair of timestamps. **Limitation, stated plainly:** this is wall-clock
time from open to submit, not active authoring time — an interruption counts. Say so wherever this figure is
shown in a report.

**Write points — two different doctypes drive room changes, so two different hooks:**

```
Patient Appointment.on_update   (status transition detected)
    Open → Confirmed:      close arriving_soon row, open waiting_room row
    Confirmed → Checked In: close waiting_room row, open nursing_room row
    → Closed/Checked Out:   close checkout row (final — no next room)

Patient Encounter.after_insert  (Draft created)
    close nursing_room row, open practitioner_room row (encounter = new doc name)

Patient Encounter.on_submit     (signed)
    close practitioner_room row, open checkout row
```

Both are added as `hooks.py` doc-event handlers, matching the existing convention already used for
`Complaint`/`Diagnosis`/etc. (`hooks.py:191-196`) — kept as separate, independent handlers so one failing
does not silently stop the other, per this codebase's own stated rationale for that list
(`hooks.py:258-263`).

**Closing a row** (on any of the above transitions): set `exited_at = now()` and
`duration_min = round((exited_at - entered_at) / 60)`. That is the entire calculation — **no delay
threshold, no `delayed` field, no site_config key.** Earlier drafts of this design included a configurable
per-room threshold generalizing `remedisys_checkin_grace_minutes` (`appointments/report.py:1490-1510`);
dropped on the product owner's explicit instruction. This table records what happened, not a judgment about
whether it took too long. If that's wanted later, it's a separate decision, not assumed here.

**Deletion.** `Patient Appointment.on_trash` deletes every `Queue Stage Log` row referencing that
appointment — an explicit rule, not automatic the way a child table's cascade would be (ADR-063 Alternative
2 explains the trade).

## 5. Reporting

`get_queue_stage_breakdown` in `api/v1/appointments/report.py` (same file, same filter convention as
`get_queue_wait_times`: `period`/`date_from`/`date_to`/`practitioner`/`department`/`company`), **plus a new
`room` filter**:

- Omit `room` → full breakdown, average/median minutes per room.
- Pass `room="nursing_room"` → only that room's numbers, everything else ignored.

Surfaces as one more card on the existing Reports screen, Operations section, next to "Queue Wait Times" —
not a new section. A single visit's own room-by-room timing is available directly from its
`Queue Stage Log` rows without going through the report (e.g. for answering "how long was this one patient
in Waiting Room today" on the spot).

**This does not change `get_queue_wait_times`.** That report's one coarse number (arrival → seen) keeps
working exactly as it does today; this is a new, finer-grained sibling, not a replacement.

## 6. Role-based tips

A dismissible panel on the Live Queue screen, computed from data already visible on the board — current
per-room counts today, and (once §4 is live) each open row's running `entered_at` vs. now, for a live "this
card has been here N minutes." Filtered per role via the existing `RoleId`/`Capabilities` plumbing already
used throughout `mission-control-client.tsx`.

**Superseded 2026-09-10 by ADR-064 (narrowly, not a reversal of the rule-based mechanism):** what shows in
the panel is still 100% deterministic Python — ADR-063's original decision that tip *selection* is never an
LLM's call still stands. What changed is the panel's collapsed one-line summary is now allowed to be
LLM-**phrased** (not LLM-decided) from those same deterministic numbers, on click only, never polled. Full
mechanism: [`docs/OPERATIONAL_SUGGESTIONS.md`](OPERATIONAL_SUGGESTIONS.md) §3. Decision + alternatives:
[`adr-064-queue-tips-llm-summary.md`](adr/adr-064-queue-tips-llm-summary.md).

**Starting rule set — expected to grow, not a closed list:**

- Nurse/Admin: which room currently has the most patients waiting, or the single longest-waiting card right
  now — a live number, not a threshold comparison.
- Front Desk/Admin: actionable state already on screen today (e.g. Payment Pending count on Arriving Soon
  cards) — no new data needed.
- Admin: which room is today's slowest, once §4's data exists.

**Not this screen — see the separate cross-clinic practitioner workload suggestion** in
`docs/OPERATIONAL_SUGGESTIONS.md` §4, which shares this exact mechanism but is a distinct feature (different
data, different audience, screen not yet decided) — not part of the Live Queue board.

## 7. The rename

`queue.liveQueueTitle` in `messages/en.json`/`messages/es.json`, rendered at
`mission-control-client.tsx:1670`, plus any other literal "Live Queue" text found by a grep sweep at
implementation time. **Known, accepted risk:** this reads as the same feature as the separate, existing
admin-only "Command Centre" tab to anyone who has seen both — the product owner was told this and chose the
full name anyway (ADR-063 Context).

## 8. Build order

Backend first, end to end, then frontend against a working backend. Mark each row `Done` as it lands — this
table is the single place build status lives for this feature.

**Backend — `remedisys_healthcare_ai`**

| # | File | Work | Status |
|---|---|---|---|
| 1 | `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/queue_stage_log/` | `Queue Stage Log` doctype: fields per §4, `DocPerm` rows (read: System Manager/Front Desk/Nurse/Practitioner; write: service-layer only via `ignore_permissions`). `track_changes: 0` — deliberate: this is high-volume operational telemetry, not a precious audit record, and a Version-log row per close would double the writes this design exists to minimize | **Done** — migrated, table verified live on `remedisis.localhost` |
| 2 | `services/queue_stage_log.py` | `on_appointment_stage_changed`, `on_encounter_created`, `on_encounter_submitted`, `on_appointment_trash` — the four hook handlers, plus `_open_row`/`_close_open_row`/`_current_room` primitives. Every handler swallows its own exceptions (Rule 7) | **Done** |
| 3 | `hooks.py` | Confirmed no collision: `Patient Encounter` had no `after_insert`; `on_submit` (3 existing handlers) and `Patient Appointment.on_update` (2 existing handlers) both got a 4th/3rd entry appended, not replaced; `Patient Appointment.on_trash` was empty, added fresh | **Done** |
| 4 | `api/v1/appointments/report.py` | `get_queue_stage_breakdown(period, date_from, date_to, practitioner, department, company, room=None)`, mirroring `get_queue_wait_times`'s filter convention | **Done** |
| 5 | `tests/appointments/test_queue_stage_log.py` | 8 tests: appointment creation opens arriving_soon, status transitions close/open correctly, re-saving the same status doesn't duplicate a row, terminal statuses close without opening a new room, a Draft encounter opens practitioner_room with the right `encounter` link, submitting closes practitioner_room and opens checkout, deleting an appointment cascades, the report's `room` filter isolates one room. **Correction, found in live browser testing:** all 8 manually called `run_method("on_update")` after their own `db.set_value` — proving the hook function correct but never proving it fires in production, where `check_in_patient`/`update_status`/`cancel_appointment` all bypass `doc.save()` the same way. 3 more tests added, going through the real endpoints — see §1 "Status of the build" correction above and ADR-063 §5 | **Done — 11/11 passing**, run via `bench --site remedisis.localhost console` (the documented workaround) |

**Frontend — `EB_Healthcare_Frontend`**

| # | File | Work | Status |
|---|---|---|---|
| 5.5 | `src/app/api/reports/[report]/route.ts` | Registered `queue-stage-breakdown` → `get_queue_stage_breakdown`; added `room` to the forwarded `PARAM_KEYS` (same pattern as `kpi`/`page`/`page_size`) | **Done** |
| 6 | `mission-control-client.tsx` | **Plan deviation, found during implementation:** `QUEUE_ACTION_CAP` and the `canDoAction` import are both dead code — defined/imported but never actually referenced anywhere in this file (confirmed by grep before wiring anything into them). Built `QueueReassignDialog` (new component) + a new `REASSIGNABLE_ROOMS` set (arriving_soon/waiting_room/nursing_room, matching the backend's `_REASSIGNABLE_STATUSES` exactly). Triggered by clicking the practitioner name/avatar on a card (a `role="button"` span, not a nested `<button>` — the whole card is already one); picker excludes the current practitioner. **Superseded by the 1.5/1.6 revisions (§3):** the commit step no longer POSTs to `/api/appointments/[id]/reassign` — it goes through the 3-step picker's own `reassignment-candidates` → `slots` → `reschedule-payment-preview` → `reschedule-with-payment` sequence instead. Not a shared component with the Appointments screen's own (still-disabled) `ReassignDialog` — deliberately separate, see the code comment for why. **Correction, found in live browser testing (2026-09-09):** initially gated by `canActOnRoom`/`ROOM_ROLES` — the room-*ownership* check every other room control uses (e.g. `ROOM_ROLES.nursing_room = ["nurse"]` only) — which silently hid the control from Front Desk in Nursing Room even though the backend allows it. Reassignment is its own, room-independent permission; fixed by switching to `mergeCapabilities(userRoles).reassign` (`Capabilities.reassign`, already matching the backend's `_REASSIGN_ROLES` — this was the intended gate all along, per Context, just never wired up) | **Done — typechecked, linted, i18n-verified, and now exercised live in a browser** |
| 7 | `QueueTipsPanel` *(new, inside mission-control-client.tsx rather than a separate file — small enough not to warrant one)* | Role-filtered tips computed from data already on the dashboard payload (`wait_minutes`, `outstanding_mxn`, `longest_waiting` — all already returned by `get_dashboard_data`, no new backend call). **Scope note:** does not yet read live Queue Stage Log per-card durations — that would need a new way to expose "how long has this specific open row been open" to the frontend, not attempted in this pass; the three starting rules use data already available today | **Done — first pass** |
| 8 | `messages/en.json`, `messages/es.json` | `queue.liveQueueTitle` → "Clinical Command Center" / "Centro de Mando Clínico"; new keys for the reassign dialog, the tips panel, and the new report page. The step-3 payment block added by the fee-difference revision (§3) reuses `NewAppointmentDialog`'s existing `newAppt` payment-step copy verbatim and added no keys of its own — it briefly added one step-1 badge key, `queue.reassignFeeDiffers`, since removed by the "do not show fee differ" revision | **Done — i18n parity verified (6976 keys, en↔es aligned)** |
| 9 | Reports screen | New `/reports/queue-stage-breakdown` page (KPI tiles + bar chart + a room filter local to this report), registered in the Operations section of `/reports`. `ReportParams` gained an optional `room` field for this one report only | **Done — typechecked** |

## 9. Known gaps — honest, not hidden

- **Now exercised in a running browser (2026-09-09) — and it's exactly what found the three bugs corrected
  throughout this document and ADR-063 §5.** Static checks (backend tests, frontend typecheck/lint/i18n)
  had all been green for hours while the reassign control was actually broken for Front Desk in Nursing
  Room and Queue Stage Log was silently not tracking any real room move — neither gap was visible from the
  static checks alone. The tips panel and the new report page have still not been separately exercised in
  a browser session; do that before calling those two done for a user, not just done on paper.
- **Tips panel (§7/§6) now reads live Queue Stage Log data — built and unit-tested 2026-09-10, revised
  same day after live product-owner feedback, not yet browser-verified.** ADR-064 /
  `docs/OPERATIONAL_SUGGESTIONS.md` §3: a small plain-text bar (`QueueInsightBar`, not a separate panel)
  now sits inline in the Live Queue header, between the title and the search box — one LLM-phrased
  summary line, one refresh button, no pills. The first build used dismissible pill badges on their own
  row below the header; seeing that live, the product owner asked for plain text in the header instead,
  and for the content to actually differ by role rather than showing everyone the same thing — both are
  now true (`_resolve_audience()` on the backend; a role with nothing relevant, e.g. Practitioner, gets no
  summary and no LLM call at all). Backend 7/7 tests green; frontend typecheck/lint/i18n clean but not yet
  exercised in a real browser — do that before calling this done for a user.
- **Two pieces of pre-existing dead code were found, not removed.** `QUEUE_ACTION_CAP` and the `canDoAction`
  import in `mission-control-client.tsx` are both unused by anything in that file (confirmed by grep,
  independently of this feature). Left in place — removing dead code nobody asked about is out of scope for
  this task, but it's worth a cleanup pass sometime, since a future reader could reasonably assume it's live
  wiring the way this ADR originally, incorrectly, did.
- **The Appointments screen's own disabled `ReassignDialog` trigger remains unexplained and untouched**
  (Context, and the `git log -S` finding from scoping: commit `e0f5d79a`, no reason recorded). This feature
  does not depend on it and does not reverse it.
- **"Reassign" from this screen can now also change the appointment's time, not only the practitioner** —
  a deliberate, requested change (§3's 3-step redesign), but worth naming explicitly: a card's visible time
  can move as a side effect of a "reassign" action, which is a different mental model than the original
  ADR-018 "coverage swap, same slot" concept `reassign_appointment` was built around. The board itself
  already refreshes both fields correctly (`onDone` → `refreshQueue`), so this is a documentation note about
  what the feature now *means*, not an unverified behavior.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.12 | 2026-09-10 | Divyanshu (AI-assisted) | §9: the pill-based tips panel was replaced, same day, with a plain-text `QueueInsightBar` in the header row, after the product owner saw the first build live and asked for both a UI simplification and genuine role-based content (not the same summary for everyone) |
| 1.11 | 2026-09-10 | Divyanshu (AI-assisted) | §9: the live-Queue-Stage-Log gap is closed — backend built + 9/9 tests green, frontend built + typecheck/lint/i18n clean, neither yet exercised in a browser |
| 1.10 | 2026-09-10 | Divyanshu (AI-assisted) | §6 updated: the tips panel's collapsed summary line may now be LLM-phrased (never LLM-decided), per ADR-064 — narrowly supersedes this doc's earlier "Rule-based, not LLM-generated" framing. Full mechanism moved to new companion doc `docs/OPERATIONAL_SUGGESTIONS.md`, which also covers a separate, not-yet-built cross-clinic workload suggestion that is out of scope for this screen |
| 1.9 | 2026-09-09 | Divyanshu (AI-assisted) | §1/§8/§9 corrected after the first real browser use of this feature found three live bugs: reassign control invisible in Nursing Room for non-Nurse roles (fixed: `canActOnRoom` → `Capabilities.reassign`/`mergeCapabilities`); Queue Stage Log's "8/8 passing" never actually proved the hook fires through the real endpoints, and in production it didn't (`check_in_patient`/`update_status`/`cancel_appointment`/`_cascade_cancel_appointment` all bypass `doc.save()`; fixed with explicit hook calls + 3 new real-endpoint tests, now 11/11); appointment drawer's "Paid" figure summed a since-refunded delta invoice's face value (`_billing_for` now nets Credit Notes out). Full detail: ADR-063 §5 |
| 1.8 | 2026-09-09 | Divyanshu (AI-assisted) | §3 "keep the original fee" checkbox: for the emergency-reassignment case (cheaper doctor unavailable, patient moved to a pricier one, patient should not be forced to pay the difference), step 3 gained a checkbox that sends `fee_override` = the old fee to `reschedule_appointment_with_payment` (existing param, no backend change) — no extra charge exists now or at checkout. Rejected "just defer to checkout" (still bills the higher fee eventually). Verified live: `Patient Appointment.paid_amount` after is the old fee, not the new doctor's default, and no invoice is created. 2 new i18n keys |
| 1.7 | 2026-09-09 | Divyanshu (AI-assisted) | §3 "do not show fee differ": removed 1.6's step-1 "Fee differs" badge — `get_reassignment_candidates` simplified back to a plain `{practitioner, practitioner_name}` list (no per-candidate `_reschedule_quote`/try-except, `original_practitioner` via `db.get_value` not a full doc load); `QueueReassignDialog` step-1 rows lost their icons/disabled-state/badge; removed the now-unused `queue.reassignFeeDiffers` key. The fee now appears exactly once, in step 3. Two fee-semantics tests replaced by one shape-invariant test; 6 tests re-run green |
| 1.6 | 2026-09-09 | Divyanshu (AI-assisted) | §3 fee-difference revision: superseded 1.5's "only show slots where the fee is unchanged" — `get_reassignment_candidates` no longer gates on fee (`available` is a real error signal only; `same_fee`/`fee_incl_tax` are non-blocking hints), and `QueueReassignDialog` gained a step 3 that settles the delta the same way the Appointments screen's reschedule drawer already does, reusing its exact hooks (`useReschedulePaymentPreview`, `usePaymentMethods`, `useRescheduleWithPayment`) and copy rather than duplicating them. Chosen over replacing the picker with the full reschedule drawer, on an explicit either/or put to the product owner ("keep in same modal only"). 2 of 7 backend tests updated for the new semantics; all 7 re-run green |
| 1.5 | 2026-09-09 | Divyanshu (AI-assisted) | §3's 1.4 design (check the original slot) rejected same day and rebuilt as a real 3-step picker: pick doctor (fee-parity filtered) → see their real open slots (existing `get_available_slots`, unmodified) → pick a slot → commit via `reschedule_appointment_with_payment` (existing, unmodified — not `reassign_appointment`). Fixed a real fee-comparison bug (`quote["adjustment"]` answers a different question than "did the fee change"), closed the same `assert_bookable` gap in `reschedule_appointment_with_payment` that 1.3 closed in `reassign_appointment`, and hardened the test file's fixture cleanup after diagnosing silent cross-run leaks |
| 1.4 | 2026-09-09 | Divyanshu (AI-assisted) | §3 extended: new read-only `get_reassignment_candidates` shows every candidate's availability for the exact slot in the picker itself (✓/✗ + reason), before the user commits to a choice — reuses the identical `assert_bookable`/`validate_overlaps` checks as the real reassignment, so the two can never disagree. New BFF route, `QueueReassignDialog` rewritten from a plain dropdown to an annotated list. 4 more tests (7 total in the file). **Superseded by 1.5 the same day** |
| 1.3 | 2026-09-09 | Divyanshu (AI-assisted) | §3 corrected again: `reassign_appointment` was not actually "unmodified" as first claimed — two real defects found live via a real reassignment (`HLC-APP-2026-00326`) and fixed the same day: the Desk title never refreshed after reassignment (stayed on the old practitioner's name permanently), and reassignment performed no availability/double-booking check on the new practitioner at all. Both fixed; 3 new live tests passing, 12 pre-existing tests re-verified unaffected |
| 1.2 | 2026-09-09 | Divyanshu (AI-assisted) | Implementation complete, backend and frontend — §8 checklist fully marked Done, verified (8/8 backend tests passing live, clean frontend typecheck/lint/i18n). Corrected §3: `QUEUE_ACTION_CAP` turned out to be dead code, not the real per-room gate — the reassign control actually uses `canActOnRoom`/`ROOM_ROLES`. Added §9 Known gaps (browser not exercised, tips panel doesn't yet use live Queue Stage Log data, two dead-code findings left in place, the Appointments-screen disabled reassign trigger remains unexplained) |
| 1.1 | 2026-09-09 | Divyanshu (AI-assisted) | Dropped the per-room delay threshold and `delayed` field, on the product owner's explicit instruction — §4 now only calculates and stores `duration_min`, no site_config key; §6's tip rule and §8's checklist updated to match; fixed a stale §5 cross-reference (build order is §8, not §5) |
| 1.0 | 2026-09-09 | Divyanshu (AI-assisted) | Initial version, written alongside ADR-063 before implementation |
