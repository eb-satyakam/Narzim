# Code Value — What It Is, In Simple Language

**Doc status:** living · **Created:** 2026-09-22 by galaxydestroyer001 · **Updated:** 2026-09-22 by galaxydestroyer001 · **Version:** 1.0

**Applies to:** Healthcare app (`apps/healthcare`), Marley Health site

> **Short answer if you're in a hurry:** it's the master list of allowed status/priority dropdown options, taken from the HL7 FHIR standard. We use **Status** (it works automatically). We do **not** use **Intent** or **Priority** — both are empty on every record. See **§6** and **§7**.

---

## 1. The one-line answer

**Code Value is the master list of allowed dropdown options for medical statuses and priorities.**

That's it. It's a settings table that says *"these are the only valid answers"*. Nothing more mysterious.

---

## 2. What you see on the screen

Each row = **one allowed option**. Rows are grouped by **Code System**, which is just the category name.

| Code System | The question it answers | How many options |
|---|---|---|
| **Medication Request Status** | What's happening with this prescription? | 9 |
| **Intent** | Is this an order, a plan, or just a suggestion? | 9 |
| **Request Status** | What's happening with this lab / procedure order? | 7 |
| **Priority** | How urgent is it? | 4 |

**29 rows total** on this site. That's the whole table — it's small on purpose.

### The columns explained

| Column | What it means | Example |
|---|---|---|
| **Code System** | The category / which dropdown it belongs to | `Medication Request Status` |
| **Code Value** | The value stored in the database (machine-readable) | `on-hold` |
| **Display** | What the human sees on screen | `On Hold` |
| **Definition** | The official meaning, so nobody guesses | "Actions implied by the request are to be temporarily halted…" |
| **ID** | Auto-built as `code value + code system` | `on-hold-Medication Request Status` |

---

## 3. The actual options (all 29)

### Medication Request Status — for prescriptions

| Code Value | Display | Means |
|---|---|---|
| `draft` | Draft | Not actionable yet — still being written |
| `active` | Active | Actionable, patient should be taking it |
| `on-hold` | On Hold | Temporarily paused, may resume |
| `completed` | Completed | Everything the request asked for has happened |
| `stopped` | Stopped | **Permanently** halted, before it finished |
| `ended` | Ended | No longer active, patient should stop taking it |
| `cancelled` | Cancelled | Withdrawn **before** any dose was given |
| `entered-in-error` | Entered in Error | Wrong patient / shouldn't exist — treat as void |
| `unknown` | Unknown | The source system doesn't know |

> **on-hold vs stopped vs ended vs cancelled** trips people up. Quick rule:
> **on-hold** = pause (might come back) · **stopped** = killed mid-way · **ended** = finished its life naturally · **cancelled** = never even started.

### Request Status — for lab tests and procedures

| Code Value | Display | Means |
|---|---|---|
| `draft` | Draft | Created but not ready to act on |
| `active` | Active | In force, ready to be acted upon |
| `on-hold` | On Hold | Temporarily paused |
| `completed` | Completed | Fully performed, nothing further needed |
| `revoked` | Revoked | Terminated before it was completed |
| `entered-in-error` | Entered in Error | Should never have existed |
| `unknown` | Unknown | Source system doesn't know |

### Priority — how urgent

| Code Value | Means |
|---|---|
| `STAT` | Immediately — highest possible priority |
| `ASAP` | As soon as possible — higher than urgent |
| `Urgent` | Promptly — higher than routine |
| `Routine` | Normal priority |

### Intent — what kind of request this is

| Code Value | Means |
|---|---|
| `Proposal` | A suggestion. The author has no authority to make it happen |
| `Plan` | An intention, but nobody is authorised to act yet |
| `Order` | A real request **and** authorisation to act |
| `Original Order` | The first authorisation in a chain |
| `Reflex Order` | Auto-generated follow-up (e.g. abnormal result triggers another test) |
| `Filler Order` | The performing party's view of the order |
| `Instance Order` | One specific occurrence of a broader order |
| `Directive` | A legally binding instruction from the patient |
| `Option` | One choice among several in a larger plan |

> **Why Intent matters:** it's the difference between *"I think we should do an MRI"* and *"Do the MRI."* Same screen, completely different legal and clinical weight.

---

## 4. Where these are wired in

The Status / Intent / Priority dropdowns on these screens all pull from Code Value:

| Doctype | Fields that use Code Value |
|---|---|
| **Service Request** (lab + procedure orders) | Status, Intent, Priority |
| **Medication Request** (prescriptions) | Status, Intent, Priority |
| **Drug Prescription** | Intent, Priority |
| Observation, Observation Template, Observation Reference Range | various |
| Insurance Claim Coverage, Patient Insurance Coverage, Item Insurance Eligibility | various |
| Lab Prescription, Procedure Prescription, Therapy Plan Detail | various |

So when a doctor marks a prescription **On Hold**, the system does **not** store the text "On Hold". It stores a link to the row `on-hold-Medication Request Status`.

⚠️ **"Wired in" is not the same as "being used."** The fields exist on these doctypes, but only **Status** actually carries data today. See **§6**.

---

## 5. Why this exists (the real reason)

These values weren't invented at Marley Health. They come from **HL7 FHIR** — the international standard for healthcare data.

You can see it in the setup code (`apps/healthcare/healthcare/setup.py`) — each Code System is seeded with its official URL:

| Code System | Official FHIR URL |
|---|---|
| Intent | `http://hl7.org/fhir/request-intent` |
| Priority | `http://hl7.org/fhir/request-priority` |
| Request Status | `http://hl7.org/fhir/request-status` |
| Medication Request Status | `http://hl7.org/fhir/CodeSystem/medicationrequest-status` |

**Three reasons that matters:**

1. **No typos, no drift.** "On Hold", "on hold", "ON-HOLD" and "Onhold" can't all exist in your data. One row, one meaning, forever.
2. **Other systems understand you.** A lab, an insurer, or a government registry that speaks FHIR reads `on-hold` and knows exactly what you mean — no mapping spreadsheet, no phone call.
3. **Reports stay honest.** "How many active prescriptions?" has one correct answer because "active" has one definition.

---

## 6. Are we actually using it? — **partly**

Checked against the live site (`mysite.localhost`), not assumed.

| Field | Reality today |
|---|---|
| **Status** — Service Request | ✅ **In use.** All 15 records = `active-Request Status` |
| **Status** — Medication Request | ✅ **In use.** All 19 records = `active-Medication Request Status` |
| **Intent** | ❌ **Empty on every record** — all Service Requests, Medication Requests and prescriptions |
| **Priority** | ❌ **Empty on every record** — same |

**Short version: Status works. Intent and Priority are dead fields.**

### Why Status works — nobody had to build it

The upstream Healthcare app drives it automatically as a state machine:

| When | Status becomes | Code |
|---|---|---|
| Service Request created | `draft-Request Status` | `service_request.py:36` |
| Lab Test created against it | `active-Request Status` | `lab_test.py:35` |
| Lab Test submitted | `completed-Request Status` | `lab_test.py:30` |
| Clinical Procedure started / finished | `active` → `completed` | `clinical_procedure.py:55, 203` |
| Amended | `revoked` / `stopped` | `service_request.py:39` |

We get this for free. **Don't hand-edit Status** — writing to it directly desyncs it from the Lab Test / Clinical Procedure lifecycle.

### Why Intent and Priority are empty

Nothing sinister. They are **not required**, have **no default**, and **no screen asks for them** — not the staff EHR, not the portal, not any backend service. The only `priority` fields Remedisys code touches are Task and Issue priorities, which are an unrelated Frappe field.

They're blank because nobody is filling them in.

---

## 7. How this helps us (and what we're leaving on the table)

### 7.1 Priority — biggest win, smallest effort

`STAT / ASAP / Urgent / Routine` already exist, unused. Turn it on and we get:

- **A lab queue that sorts by urgency** — STAT bloods jump the line instead of queueing behind routine ones
- **A real SLA tile** — "no urgent order older than X minutes"
- **A signal the AI can use** — today when a doctor says *"get this urgently"*, that urgency lives in the transcript text and then evaporates. Nothing structured captures it

Cost: one dropdown on the order screen, defaulted to `Routine`.

### 7.2 Intent — separates "thinking about it" from "do it"

Today every order is implicitly an `Order`. There is no way to record *"I'm considering an MRI"* as a `Plan` or a `Proposal` — it's either a real order or it doesn't exist at all.

This lines up directly with the AI copilot: its 23 write tools produce **suggestions, not orders**. `Intent` is the standards-blessed field for exactly that distinction — an AI-suggested lab could be written as `Proposal`, and a doctor accepting it promotes it to `Order`. We currently model that with a separate draft table instead.

Also useful later: `Reflex Order` is the correct code for an auto-generated follow-up test (abnormal result triggers another test) — a real lab workflow we will hit.

### 7.3 It's the FHIR export we don't have to build twice

Every value carries its official HL7 URL. Mexico's NOM-024-SSA3 and India's ABDM both push toward standardised exchange.

Filling these fields **now** makes a future export a mapping exercise. Leaving them blank makes it data archaeology — you cannot retrofit priority onto 50,000 historical orders that never captured it.

### 7.4 What I'd actually do

| Priority | Action | Effort |
|---|---|---|
| **Do now** | Add **Priority** to the order-creation screen, default `Routine` | Small — one dropdown |
| **Do now** | Fill the blank **Display** values on the Intent and Priority rows | Trivial — 13 rows, cosmetic but staff-facing |
| **Think about** | Use **Intent** to mark AI-suggested vs doctor-confirmed orders | Design decision, touches the copilot |
| **Leave alone** | **Status** — it already works. Don't write to it by hand | — |

---

## 8. The safety flags on each row

| Flag | What it does |
|---|---|
| **Custom** | Marks a row **your clinic added** (not from the standard) |
| **Immutable** | This row must not be edited — it's a standard definition |
| **Experimental** | Not settled yet, don't rely on it |
| **Complete** | The code system has all its values loaded |
| **Version** | Which version of the standard this came from |

---

## 9. Rules of thumb

**✅ Do**

- Read the **Definition** column before picking a status you're unsure about.
- If you genuinely need an option that doesn't exist, **add a new row with `Custom` ticked**. That's exactly what the flag is for.
- Keep **Display** filled in for new rows — it's what staff see.

**❌ Don't**

- **Don't edit the existing rows.** Changing what "completed" means silently breaks every report, every integration, and every past record that used it.
- **Don't delete rows.** Old records still point at them. Deleting orphans real patient data.
- **Don't add a duplicate** with slightly different spelling. Check the list first.
- **Don't hand-edit Status** on a Service Request or Medication Request. The Healthcare app owns that lifecycle (§6) and manual writes desync it.

---

## 10. Two things that look like bugs but aren't

**1. Some rows show an odd Display value**

Intent and Priority rows have an **empty Display field**, so the list view falls back to showing the ID instead — that's why you see `STAT-Priority` rather than just `STAT`. Cosmetic only. Filling in Display fixes it.

**2. Intent and Priority are blank everywhere**

Not a data-loss bug — no screen ever asks for them. See **§6**.

**3. "20 of 29" at the top**

That's just pagination. Click **Load More**, or the `100` button at the bottom, to see all 29.

---

## 11. Related tables (don't confuse them)

| Doctype | What it's for |
|---|---|
| **Code System** | The category itself — name, official URI, FHIR flag. The parent of Code Value |
| **Code Value** | ← **this one.** The individual allowed options |
| **Code Value Set** | A named bundle of codes for one purpose |
| **Codification Table** | A *different* thing — the child table that attaches **ICD / diagnosis / procedure codes** to a Diagnosis, Lab Test, Medication or Clinical Procedure. Medical coding, not status dropdowns |

**Short version:** Code Value = *statuses and priorities*. Codification Table = *ICD-style medical codes*. Different jobs.

---

## 12. Where to look in the code

| Thing | Path |
|---|---|
| Doctype definition | `apps/healthcare/healthcare/healthcare/doctype/code_value/` |
| Naming logic | `code_value.py` → `code_value + version + code_system` |
| Where the 29 rows get seeded | `apps/healthcare/healthcare/setup.py` (~line 931 onward) |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | galaxydestroyer001 | Initial version (header backfilled from git history) |
