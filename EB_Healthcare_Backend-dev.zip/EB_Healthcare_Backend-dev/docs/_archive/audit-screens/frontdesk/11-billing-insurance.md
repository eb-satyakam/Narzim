# Front Desk → Billing (Insurance tab) + Patient Insurance

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified 2026-07-18** — IN1/IN2/IN3 decided; IN4/IN5 deferred · **Area:** Money · **Screen 11/14** · [index](README.md)

> **Build batch (2026-07-18, all FE):** IN3 remove phantom form fields (copay/deductible/group/holder) → **then** IN1 unhide the patient insurance CRUD sub-tab · IN2 remove the dead hub Insurance tab. **Deferred:** IN4 Insurance Claim (backend), IN5/BK1 insurance booking.
**Role:** `EB_Front Desk` (frontend `frontdesk`).
**Frontend:** billing hub `InsuranceTab()` (in `billing-client.tsx:351`) · patient-chart `insurance-tab.tsx` (376 lines).
**Professional lens:** insurance is where the desk records a family's policy and sees how bills split with the payor. The surprising finding: a **real, wired insurance-management CRUD UI exists** — but it's **hidden**, and the billing hub shows a **fake placeholder** where it should be. This isn't "not built"; it's "built, then switched off."

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| List patient policies | Patient Insurance Policy | `insurance.get_patient_insurance_policies` | via `usePatientInsurance` |
| Save (create/update) policy | Patient Insurance Policy | `insurance.save_patient_insurance_policy` | via `useSaveInsurancePolicy` |
| Delete policy | Patient Insurance Policy | `insurance.delete_patient_insurance_policy` | via `useDeleteInsurancePolicy` |
| Payor list | Insurance Payor (+ plans) | `insurance.list_insurance_payors` | via `useInsurancePayors` |

## 2. REAL vs MOCK vs MISSING — two surfaces
### A. Billing hub → Insurance tab
| Element | State | Evidence |
|---|---|---|
| Insurance payor breakdown | 🔴 **MOCK PLACEHOLDER** | `InsuranceTab()` is a hardcoded empty state ("Available when Insurance Payor is linked to Payment Entries", billing-client.tsx:351–359) — no data, no wiring, **hardcoded English** |

### B. Patient chart → Insurance sub-tab (`insurance-tab.tsx`)
| Element | State | Evidence |
|---|---|---|
| List policies | 🟢 **REAL (but HIDDEN)** | `usePatientInsurance(patient.mrn)` → `get_patient_insurance_policies` |
| Payor typeahead | 🟢 REAL | `useInsurancePayors` → `list_insurance_payors` |
| Save policy (create/update) | 🟢 REAL | `useSaveInsurancePolicy` → `save_patient_insurance_policy` |
| Delete policy | 🟢 REAL | `useDeleteInsurancePolicy` → `delete_patient_insurance_policy` |
| i18n + currency | 🟢 REAL | `useTranslations` + `useCurrency` |
| **Tab visibility** | 🔴 **HIDDEN** | Insurance sub-tab commented out in `patient-screen.tsx` (screen 4, C-note) — so this working UI renders for no one |
| **Form ↔ backend parity** | 🟠 **MISMATCH** | form collects `groupNumber`, `holder`, `copay`, `deductible`, `deductibleMet` (L281–293) but `save_patient_insurance_policy` only persists `insurance_payor`, `policy_number`, `insurance_plan`, `effective_date`, `expiry_date` — **the extra fields are not saved** |

## 3. Actions & wiring
- **Patient insurance-tab:** full CRUD (list/add/edit/delete) — all real mutations, currently unreachable (hidden).
- **Billing hub Insurance tab:** nothing — static placeholder.
- **Claims:** none anywhere (backend has no `Insurance Claim` surface either — core capability unused; see core-map).

## 4. Permissions
- Backend insurance endpoints have no explicit FD block; policy CRUD is reachable for FD once the tab is unhidden. Aligned once enabled.

## 5. Alignment with core
- The policy CRUD maps to core `Patient Insurance Policy` (+ payor/plan) — real, aligned.
- **Big unused core capability:** the invoice **split → payor Journal Entry** works (booking/checkout), but the **`Insurance Claim` revenue cycle** (aggregate covered amounts → bill payor → reconcile payor payment) is entirely absent from the UI *and* our API — the single largest untapped core feature (core-map §3, charter G3). The billing hub's "payor breakdown" placeholder is exactly where that would live.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **IN1** | **Working insurance CRUD is hidden.** A real, wired policy management UI (`insurance-tab.tsx`) exists but its sub-tab is commented out (`patient-screen.tsx:84-85, 638-639` — "hidden for now, kept for easy re-enable"). Verified still hidden 2026-07-18. | Built-but-hidden (G3) | **High** | ✅ **DECIDED (2026-07-18): unhide the patient insurance sub-tab.** Do it **after IN3** (the form was likely hidden because it saved fields that vanished). FE. |
| **IN2** | **Billing hub Insurance tab is a fake placeholder** ("Insurance payor breakdown — Available when Insurance Payor is linked to Payment Entries" — dead dashed box). Verified 2026-07-18. | Mock (FD2) | **High** | ✅ **DECIDED (2026-07-18): remove the dead hub Insurance tab.** Insurance management lives in the patient chart (IN1). The real payor-breakdown/claims view returns with IN4. FE. |
| **IN3** | **Form ↔ backend parity mismatch:** UI collects copay/deductible/group/holder, but neither `save_patient_insurance_policy` **nor the core `Patient Insurance Policy` doctype** has those fields (verified 2026-07-18 — native fields are payor/policy_number/insurance_plan/date/expiry only). Data silently dropped. | Data integrity | **Med-High** | ✅ **DECIDED (2026-07-18): remove the phantom inputs.** Per "prefer existing / custom field only when unavoidable" — claiming is deferred (IN4), so no custom fields for unused data. Trim form to what persists (payor, policy number, plan, effective/expiry). Revisit at IN4. FE. |
| **IN4** | **No Insurance Claim flow** — can't bill a payor or reconcile their payment (core feature unused). | Missing (G3/core) | Med | ⏸ **DEFERRED (2026-07-18)** — big backend hand-off (surface native `Insurance Claim`); market-dependent; rank vs. cash-drawer. The hub payor-breakdown view returns with this. |
| **IN5** | Insurance booking path is dead (BK1) — even a saved policy can't drive an insured booking today. | Cross-screen | Med | ⏸ **DEFERRED (2026-07-18)** — pairs with BK1. **IN1 is its prerequisite** (now being done); remaining BK1 work is forwarding the policy id at booking. |

## 7. CRUD / states
- **Patient insurance-tab (when enabled):** full CRUD, real states.
- **Billing hub Insurance tab:** static placeholder, no states.

## 8. Recommended options (curated)
Insurance is the most "built but disconnected" area — the fix is mostly *connect what exists*, not build new.
- **Unhide the patient insurance CRUD (IN1)** and **replace the fake hub tab (IN2)** — turns a dead area into a working one with little new code.
- **Fix form parity (IN3)** — stop collecting fields that don't save (add them to backend *or* drop them).
- **Then couple to booking (IN5)** so a recorded policy actually splits a bill.
- **Insurance Claim (IN4)** is the big-ticket, deferred item — decide against cash-drawer priority.
- **NOT recommended:** building a *second* insurance UI in the billing hub — reuse the patient policy component; the hub tab should show payor-level *breakdown/claims*, not duplicate policy entry.

## 9. Open questions for product owner
1. **IN1/IN2:** Unhide the existing patient insurance CRUD and replace the placeholder hub tab — confirm both, and why they were disabled.
2. **IN3:** For the extra fields (copay, deductible, group, holder) — add them to the backend policy doctype, or remove from the form?
3. **IN4:** Is payor claiming (Insurance Claim) in scope for this market, and where does it rank against the cash-drawer backend?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
