# Front-Desk Audit — Decision Sheet

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**One place to lock scope.** Every gap from the 14 screen audits, ranked, each with a recommendation and a **Decision** column to fill in (`✅ do` / `⏸ defer` / `❌ skip` / notes). Once decided, the per-screen docs' `_pending_` entries get updated to match.

**Legend:** FE = frontend-only · BE = backend hand-off (see `BACKEND_HANDOFFS.md`) · ADR = needs a decision record first.
**How to use:** go tier by tier; Tier 0/1 are the ones that change the product. Tiers 3–4 are mostly free FE wins — batch-approve unless you disagree.

> **Decision column is PRE-FILLED with the engineer's recommendation (`▶ REC:`), not a final call.** Override any of them. Recommendation legend: **W1** = do in Week-1 FE batch · **A** = build track A · **B** = build track B (parallel) · **✅** = do (sequenced) · **⏸** = defer · **❌** = skip. Two open gating questions remain at the bottom — those need *your* answer before Track A/B start.

---

## Recommended plan (the `▶ REC:` marks, sequenced)
**Week 1 — FE only, no backend, ships a "finished" feel + de-risks:**
remove fake AI (C1/C5) · **hide the cash mock** (CD1 interim) · wait-time + revenue KPI (D1/D2) · age+guardian + real pagination + push filters (P1/P2/P4) · guardian+address at registration (R1/R2) · list Confirm/Check-in + real age + reassign (A1/A3/A2) · unhide insurance CRUD + remove unsupported inputs (IN1/IN3) · unhide notifications + Messages nav (N1/N3) · currency fix (CO2/BP2) · real payment methods (CO4) · arrival stamp (D4).

**Track A (backend, start ADR now):** Cash / Shift (CD1 / FD-BH-1) — the critical build.
**Track B (backend, parallel):** Sales Invoice Editor (9b / FD-BH-2, closes 5 gaps) + Work Feed (FD-BH-4, powers D3+MW1).
**Then (sequenced ✅):** receipts (FD-BH-8 → C2/CO3/BP3) · insurance bundle (BK1/IN2/BK3 + parity) · void/partial (FD-BH-3) · edit-appointment (FD-BH-12) · calendar interactivity (CAL1/3/4) · i18n batch (A4/BK5/D8/N6) · polish batch.
**Deferred ⏸:** reminders (N4 — Phase 4, *pull forward if no-shows hurt*) · Insurance Claims (IN4/FD-BH-7) · calendar drag + month view.
**Skipped ❌:** patient-list bulk checkboxes (P5 — remove).

---

## Tier 0 — Critical (money integrity / trust)
| # | Screen | Finding (short) | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| CD1 | Cash Drawer | Entire cash/shift is localStorage mock — not persisted/auditable/reconciled | **Build real backend** (FD-BH-1) | BE+ADR | **▶ REC: W1 hide mock now + start ADR → A (build first big backend)** |
| C1 | Patient Chart | Fabricated "High Readmission Risk" AI banner shown to front desk (fake + phase violation) | **Remove now** from live chart | FE | **▶ REC: W1 — remove immediately (trust + phase violation)** |
| C5 | Patient Chart | AI insights/recommendations are `patHash` mock on a live screen | **Gate behind Phase-5 flag** (hide) | FE | **▶ REC: W1 — hide behind Phase-5 flag** |

## Tier 1 — High (core function missing / broken)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| 9b | Billing | No Sales Invoice Editor (create with tax, add/remove lines) | **Build** editor + `create_invoice(items[],tax)` (FD-BH-2) | BE+FE | **▶ REC: B (2nd big build — closes 5 gaps)** |
| BK1 | Booking | Insurance booking dead (option hidden + policy never sent) | **Fix end-to-end** (FD-BH-6) | FE+BE | **▶ REC: ✅ with insurance bundle (after W1)** |
| IN1 | Insurance | Working policy CRUD is hidden | **Unhide** the patient insurance tab | FE | **▶ REC: W1 — unhide (confirm why disabled)** |
| IN2 | Insurance | Billing hub Insurance tab is a fake placeholder | **Replace** with real payor breakdown / route to CRUD | FE | **▶ REC: ✅ route to CRUD now; payor breakdown with FD-BH-7** |
| IN3 | Insurance | Form collects copay/deductible/group/holder the backend drops | **Add BE fields or remove inputs** (FD-BH-6) | BE/decision | **▶ REC: W1 remove unsupported inputs now; add BE fields later if needed** |
| D3 / MW1 | Dashboard / My Work | No front-desk work feed (no-shows/unconfirmed/follow-ups/balances) — UI scaffolding, no data | **Build feed** `get_frontdesk_worklist` (FD-BH-4) — powers both | BE+FE | **▶ REC: B (parallel — build once, use twice)** |
| A1 | Appointments List | No Confirm / Check-in in the list (must detour to dashboard/chart) | **Add both** to row menu (real `check_in_patient`) | FE | **▶ REC: W1** |
| CO1 | Checkout | No partial payment (full total only) | **Allow amount ≤ total** (FD-BH-11) | FE(+BE verify) | **▶ REC: ✅ soon (money correctness)** |
| CO2 | Checkout | Currency hardcoded `$`/es-MX, cents stripped | **Use `useCurrency` + decimals** | FE | **▶ REC: W1 (money-display bug)** |
| BP1 | Payments | No day-end reconciliation (totals by method) | **Add daily summary** (precursor to CD1) | FE(+BE) | **▶ REC: ✅ lightweight summary in W1; full close with CD1** |
| BI2 | Billing | No void/cancel of a submitted invoice | **Add void** (FD-BH-3) [policy] | BE+ADR | **▶ REC: ✅ with Invoice Editor (B); decide void-vs-credit-note** |
| BK2 / 7b | Booking | No edit-appointment (only reschedule/cancel) | **Add edit for safe fields** (FD-BH-12) | BE+FE | **▶ REC: ✅ after A/B** |
| N4 | Notifications | No automated appointment reminders (manual only) | **Wire scheduler + batch remind** (FD-BH-5) | BE+FE | **▶ REC: ⏸ Phase 4 — PULL FORWARD if no-shows are the pain (see Q)** |
| D1 | Dashboard | Real wait-time in payload, not shown | **Render wait + overdue cue** | FE | **▶ REC: W1** |
| P1 | Patient List | Pagination capped at 100 (misses #101+) | **Real pagination** | FE | **▶ REC: W1** |
| P2 | Patient List | Age & guardian not shown (in payload) | **Add columns** | FE | **▶ REC: W1** |
| R1 | Registration | No guardian capture (pediatric — no parent on file) | **Add guardian block** | FE | **▶ REC: W1** |

## Tier 2 — Medium (workflow completeness)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| C2 | Patient Chart | Print Receipt is a toast stub | Wire real receipt (FD-BH-8) | BE+FE | ▶ REC: ✅ with FD-BH-8 receipt |
| D2 | Dashboard | No money-to-collect visibility (KPI off) | Re-enable revenue KPI + checkout balance | FE | ▶ REC: W1 |
| P3 | Patient List | Balance amount not shown | Add outstanding column (FD-BH-9) | BE+FE | ▶ REC: ✅ (needs FD-BH-9 field) |
| P4 | Patient List | today/new/sex/status filtered client-side over ≤100 | Push filters to server | FE | ▶ REC: ✅ with P1 pagination |
| R2 | Registration | No address capture | Add address block | FE | ▶ REC: ✅ with R1 (guardian) |
| R3 / BK6 | Registration/Booking | No duplicate-patient guard | Dup check (FD-BH-10) | BE+FE | ▶ REC: ✅ (FD-BH-10) — decide warn-vs-block |
| R5 | Registration | No post-create follow-through (open chart/book) | Add success actions | FE | ▶ REC: ✅ |
| A2 | Appointments List | Reassign built but commented out | Confirm why → re-enable | FE | ▶ REC: W1 (confirm why first) |
| A3 | Appointments List | Age hardcoded "—" | Carry real age | FE | ▶ REC: W1 |
| CAL1 | Calendar | Read-only (no book/click-through/drag) | Add click-through + click-to-book | FE | ▶ REC: ✅ click-through+book; drag deferred |
| CAL3 | Calendar | No practitioner filter | Add filter | FE | ▶ REC: ✅ |
| CAL4 | Calendar | 200-event cap | Range-based fetch | FE | ▶ REC: ✅ |
| BK3 | Booking | Mock insurance provider list | Wire `list_insurance_payors` | FE | ▶ REC: ✅ with insurance bundle |
| BK4 | Booking | Discount only on pay_now | Send on all timings | FE | ▶ REC: ✅ |
| CO3 | Checkout | No printed receipt | FD-BH-8 | BE+FE | ▶ REC: ✅ with FD-BH-8 |
| CO4 | Checkout | Payment methods hardcoded | Use `usePaymentMethods` | FE | ▶ REC: W1 |
| CO5 | Checkout | No discount at checkout | Add discount (permissioned) | FE | ▶ REC: ✅ with Invoice Editor |
| CO6 / BI1 | Checkout/Billing | No ad-hoc line / No "New Invoice" | Covered by editor 9b (FD-BH-2) | BE+FE | ▶ REC: ✅ (Invoice Editor B closes both) |
| BI3 | Billing | Refund full-only, paid-only | Partial/line credit note (FD-BH-3) | BE | ▶ REC: ✅ with FD-BH-3 |
| BI4 | Billing | Status counts client-side over 100 | Server-side counts | FE | ▶ REC: ✅ |
| BP2 | Payments | Currency hardcoded `$` | Use `useCurrency` | FE | ▶ REC: W1 (with CO2) |
| BP3 | Payments | No payment receipt | FD-BH-8 | BE+FE | ▶ REC: ✅ with FD-BH-8 |
| BP4 | Payments | No payment reversal | FD-BH-3 | BE | ▶ REC: ✅ with FD-BH-3 |
| IN4 | Insurance | No Insurance Claim flow (core unused) | Surface claims (FD-BH-7) — large | BE | ▶ REC: ⏸ defer (not this quarter) |
| N1 | Notifications | Notifications UI dead-coded off (backend real) | Unhide bell/panel | FE | ▶ REC: W1 |
| N2 | Notifications | No `/notifications` page | Add page or repoint link | FE | ▶ REC: ✅ |
| N3 | Notifications | WhatsApp inbox has no sidebar nav | Add Messages nav item | FE | ▶ REC: W1 |
| C3 | Patient Chart | "New Invoice" button commented out | Wire (via editor 9b) | FE | ▶ REC: ✅ with Invoice Editor |
| C4 | Patient Chart | No refund in-chart | Decide placement | FE | ▶ REC: ✅ (route to Billing refund) |
| A4 | Appointments List | Entire screen hardcoded English | i18n migrate | FE | ▶ REC: ✅ i18n batch |
| BK5 | Booking | 3 dialogs hardcoded English | i18n migrate | FE | ▶ REC: ✅ i18n batch |

## Tier 3 — Low (polish / hygiene / i18n)
| # | Screen | Finding | Recommendation | Decision |
|---|---|---|---|---|
| D4 | Dashboard | "Check in" sets Confirmed, no arrival stamp | Route through `check_in_patient` (FE) | ▶ REC: W1 (arrival integrity) |
| D5 | Dashboard | Placeholder demographics (sex "M", age "—") | Carry real data (FE) | ▶ REC: ✅ polish batch |
| D6 | Dashboard | Today-only, no look-ahead | Add date nav (FE) | ▶ REC: ✅ (pairs with reminders) |
| D7 | Dashboard | Not live (no polling/socket) | Add refresh (FE) | ▶ REC: ✅ polling (socket later) |
| D8 | Dashboard | Hardcoded "Home" + chip labels | i18n (FE) | ▶ REC: ✅ i18n batch |
| P5 | Patient List | Dead selection checkboxes | Add bulk action or remove (FE) | ▶ REC: ❌ remove checkboxes (no bulk need now) |
| P6/P7 | Patient List | Hardcoded msg count `0`; unused `IS_DEV` | Cleanup (FE) | ▶ REC: ✅ cleanup |
| R4 | Registration | CURP validation MX-only | Jurisdiction-driven ID (FE) | ▶ REC: ✅ when India goes live (ADR-018) |
| R6/R7 | Registration | Gender hardcoded; no photo | Minor (FE) | ▶ REC: ⏸ low (photo defer; genders from API) |
| CAL2 | Calendar | Misleading cursor-pointer on static cards | Wire or remove pointer (FE) | ▶ REC: ✅ (resolved by CAL1) |
| CAL5/6 | Calendar | No month view; hardcoded title/AM-PM | Optional / i18n (FE) | ▶ REC: ⏸ month defer; ✅ i18n |
| BK7/BK8 | Booking | Email unvalidated; service unit auto | Validation / expose unit (FE) | ▶ REC: ✅ email now; unit when multi-unit |
| CO7 | Checkout | Raw error on concurrent checkout | Friendly conflict msg (FE) | ▶ REC: ✅ polish batch |
| BI5/BP-audit | Billing/Payments | No refund/void reason | Capture reason (FD-BH-13) | ▶ REC: ✅ with FD-BH-3 |
| BP5 | Payments | No method filter | Add filter (FE) | ▶ REC: ✅ with BP1 summary |
| N5/N6 | Notifications | `/messages` ungated; panel English | Route gate + i18n (FE) | ▶ REC: ✅ (gate with N3; i18n batch) |
| MW2/MW3 | My Work | Client-only dismiss; minor literals | Minor (FE) | ▶ REC: ⏸ accept dismiss; ✅ i18n |
| A7 | Appointments List | Hand-rolled toasts | Use shared toast (FE) | ▶ REC: ✅ polish batch |

---

## Decisions that unlock the most
1. **CD1 (cash ADR)** — critical risk; blocks day-end + honest money tracking.
2. **9b / FD-BH-2 (invoice editor)** — one build closes 9b, BI1, CO5, CO6, BK2-invoice.
3. **FD-BH-4 (work feed)** — one build closes D3 + MW1.
4. **FD-BH-6 (insurance)** — unhide + parity + booking makes the whole insurance area live.
5. **FD-BH-8 (receipt)** — one artifact closes C2, CO3, BP3.
6. **Remove fake AI (C1/C5)** — trivial, and it's a phase-rule violation shipping today.

## Two gating questions — DECIDED (engineer's call; override if wrong)
1. **Cash Drawer (CD1) vs Sales Invoice Editor (9b) first? → CASH FIRST (Track A).** Reasoning: it's the only *Critical* item and a *risk* problem, not a feature. A live money-tracker that persists nothing is a liability the moment a clinic trusts it; the existing invoice generators already cover the common billing cases, so the editor is high-value but not risk-bearing. Cash also needs the ADR (now drafted, ADR-023), so its clock starts first. Invoice Editor = Track B in parallel. **Override trigger:** if this pilot clinic takes almost no cash, flip them.
2. **New screens in scope for front desk?** edit-appointment (7b) → **✅ yes** (safe pre-invoice fields). day-end reconciliation → **✅ yes** (falls out of CD1/ADR-023). receipts → **✅ yes** (FD-BH-8). work feed → **✅ yes** (FD-BH-4, powers dashboard too). reminders → **⏸ Phase 4** — *pull forward only if no-shows are the measured pain*; needs WhatsApp account config (settings BH-14) first, so it's sequenced after the cash/editor builds regardless.

_Counts: Tier 0 = 3 · Tier 1 = 17 · Tier 2 = ~30 · Tier 3 = ~20. ~13 need backend (FD-BH), 3 need an ADR; the rest are frontend._

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
