# Front Desk → Patient Registration

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — **re-verified 2026-07-18** (R1/R2/R5/R7 implemented since audit; R3/R8/guardian-for-minors decided; R4 deferred; R6 backlog) · **Area:** Patients · **Screen 3/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · gated `frontdesk`/`admin` (`canRegister`).
**Frontend:** `src/components/narzim/patients/register-patient-dialog.tsx` (434 lines) — modal launched from Patient List + empty-state CTA.
**Professional lens:** registration is the family's first record. In pediatrics the patient is a **child**; the **guardian** is who you contact, bill, and get consent from. A registration that captures a child but not their parent is half a record. Validation here is genuinely good — but the field set is thin and omits the two things a front desk needs most: **guardian and address**.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Create patient | Patient (+ auto Customer via core `link_customer_to_patient=1`; Contact/Address on save) | `patients.create_patient` | `/api/patients` (via `useCreatePatient`) |
| Gender options | Gender | (hardcoded in UI; `get_genders` exists but unused) | — |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Create patient (8 fields) | 🟢 **REAL** | `useCreatePatient` → `create_patient`; real success/error toasts. |
| Mobile validation (country code + libphonenumber) | 🟢 **REAL** | `isValidMobile`, `formatMobileInput`, `toStoredMobile`; stored as `"+52 …"`. Better than settings screens' cosmetic validation. |
| Email validation | 🟢 REAL | zod `.email()` (real, fires on submit via RHF). |
| CURP validation (Mexico) | 🟢 REAL but 🟡 **jurisdiction-hardcoded** | `^[A-Z0-9]{18}$` → `uid`. No India (Aadhaar) variant despite ADR-018 two-market. |
| Age preview from DOB | 🟢 REAL | months/years display (pediatric-aware: "3 mo" / "5 yrs"). |
| **Guardian capture** | 🔴 **MISSING** (backend accepts `guardians[]`) | dialog collects no parent — a new child has no contact/consent party until you add one later in Patient 360. |
| **Address capture** | 🔴 **MISSING** (backend accepts `address`) | no address at registration — matters for records, billing, reminders. |
| Allergies / medical history | 🔴 MISSING (backend accepts) | arguably nurse's job; but allergy at intake is safety-relevant. |
| Photo/image | 🔴 MISSING (backend accepts `image`) | no upload. |
| Duplicate detection | 🔴 **MISSING** | no "possible duplicate" check on name+DOB or mobile — front desk can silently create a second record for the same child. |
| Gender options | 🟡 hardcoded 3 (Male/Female/Other) | backend validates against Gender doctype; `get_genders` endpoint exists but unused. |
| Post-create follow-through | 🔴 MISSING | success = toast + close; no "open chart" / "book now" — a walk-in registration dead-ends. |

## 3. Field-by-field parity (dialog vs `create_patient`)
Backend accepts ~40 args across demographics, contact, billing, personal/social history, allergy/medical/surgical, risk factors, **relations, guardians, address**. The dialog sends **8**.

| Dialog field | Backend arg | Control | Validation | Note |
|---|---|---|---|---|
| First name * | `first_name` | text | required (zod) | ✅ |
| Last name | `last_name` | text | — | ✅ |
| Gender * | `gender` | 3-button toggle | required | hardcoded options; backend checks Gender doctype |
| DOB | `dob` | date (max today) | — | + age preview |
| Mobile | `mobile` | country-select + tel | libphonenumber | ✅ strong |
| Email | `email` | email | zod email | ✅ |
| Blood group | `blood_group` | select | validated server-side | clinical — see G-priority note |
| CURP | `uid` | text (18, upper) | CURP regex | MX-only |
| **— (none)** | `guardians` | — | — | 🔴 not collected |
| **— (none)** | `address` | — | — | 🔴 not collected |
| — | `allergies`, `medical_history`, `image`, risk factors, `marital_status`, `occupation` | — | — | not collected (mostly fine for FD) |

**Priority mismatch:** the form captures **blood group** (clinical, rarely front-desk data) but not the **guardian** (the exact thing a pediatric front desk needs). That's inverted for the role.

## 4. Permissions
- Dialog only rendered when `canRegister` (`frontdesk`/`admin`) — button + empty-state CTA both hidden otherwise, so no create-UI for a create-denied role. Backend `create_patient` re-checks `frappe.has_permission("Patient","create")` (Rule 6). Aligned.

## 5. Alignment with core
- `create_patient` inserts real `Patient`; with `link_customer_to_patient=1` core auto-creates the Customer on save (the billing join). Aligned — no custom customer logic needed.
- Guardians/address, when sent, map to core Contact/Address (per `add_guardian`/address handling) — the capability exists; the UI just doesn't use it here.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **R1** | **No guardian capture at registration.** Backend accepts `guardians[]`; dialog omits it. A newly registered child has no parent/consent/contact party until separately added in Patient 360. | Missing | **High** | ✅ **IMPLEMENTED (verified 2026-07-18)** — collapsible, **repeatable** guardian block: name, relation (allowlist Father/Mother/Guardian/Legal Guardian/Grandparent…), phone, email, per-guardian address, primary-guardian selection. Backend `_create_guardian` builds Contact + linked Address. **NEW DECISION (2026-07-18): require a primary guardian for minors** — FE already derives age from DOB; if age < 18 and no guardian, require one (strong warn/block). FE-only. |
| **R2** | **No address capture.** Backend accepts `address`; dialog omits it. | Missing | **Med-High** | ✅ **IMPLEMENTED (verified 2026-07-18)** — optional Address block added (Street/Line1, Line 2, City, State, Postal, Country). Residual: State/City free-text (inconsistency risk); Country hardcoded "Mexico" (ties to R4). |
| **R3** | **No record-level duplicate detection.** Same child can be registered twice. Only guard today is **CURP uniqueness** (`create_patient` throws `DuplicateEntryError` on matching `uid`) — and CURP is optional; no name+DOB / mobile check. (`overrides/patient_duplicate_check.py` handles a *different* case: linking an existing website-user/email account, not detecting a duplicate patient record.) | Data integrity | **Med-High** | ✅ **DECIDED (2026-07-18, FE) — warn-and-allow.** On name+DOB (and/or mobile) blur, call the **existing** `list_patients` search; if a match, show inline "possible existing patient →" with a link to the chart. Does not block submit. Reuses an existing endpoint — small FE. |
| **R4** | **CURP validation is MX-only**, hardcoded. India (ADR-018) has no equivalent ID validation; Country is hardcoded "Mexico", dial +52. | i18n/jurisdiction | Med | ⏸ **DEFERRED (2026-07-18)** — revisit when India go-live is imminent; then drive Country / ID-label / ID-regex / dial-code from the compliance profile (`mx`=CURP, `in`=Aadhaar/none). |
| **R5** | **No post-create follow-through** — walk-in registration ends at a toast; natural next step (open chart / book appointment) is missing. | Workflow | Med | ✅ **IMPLEMENTED (verified 2026-07-18)** — success card offers **photo upload** + `router.push` to the new patient's chart. (Optional future: add a "Book appointment" shortcut on the success card.) |
| **R6** | Gender options hardcoded (3) instead of `get_genders`. (Blood-group-over-guardian priority now resolved — guardian block exists per R1.) | Parity/priority | Low | _backlog_ — source genders from `get_genders`. Minor; not in this batch. |
| **R7** | No photo upload though backend accepts `image`. | Missing | Low | ✅ **IMPLEMENTED (verified 2026-07-18)** — photo upload on the post-create success card. |
| **R8** | **False required markers.** Last Name (`register-patient-dialog.tsx` L835) and DOB (L902) render a red `*`, but both are `optional` in zod (L282/L284) **and** in backend `create_patient` (only `first_name` + `gender` enforced). A child can be registered with **no DOB** despite the marker — a pediatric safety gap (age/weight dosing) and a UX lie. | Correctness/safety | **High** | ✅ **DECIDED (2026-07-18) — make DOB actually required** (add `.min(1)` in zod + `if not dob: frappe.throw` in `create_patient`), keep its `*`. **Last Name: keep optional, remove the `*`.** |

## 7. CRUD / states
- **From this screen:** Create only (correct — edit/delete live in Patient 360).
- **States:** submit button shows spinner + disabled while pending; cancel disabled during submit; success/error toasts. Solid. No inline duplicate/mobile-exists feedback (R3).
- **Validation quality:** real (zod + libphonenumber + CURP regex) — a clear cut above the settings screens' cosmetic `type=email`.

## 8. Recommended options (curated)
Registration should capture **who the child is + who to contact + where they are** — then hand off to the next action.
- **Add Guardian block** (R1) — the single most important addition; pediatric registration without a parent is incomplete.
- **Add Address block** (R2) — records/billing/reminders need it.
- **Duplicate check before create** (R3) — prevents the most common real-world FD data error.
- **Post-create actions** (R5) — "Open chart" / "Book appointment" so a walk-in flows straight into a visit.
- **Jurisdiction-driven national ID** (R4) — CURP for MX, Aadhaar/none for IN.
- **NOT recommended:** full clinical intake here (allergies, meds, surgical/social history, risk factors) — that's **nurse intake / Patient 360**, not front-desk registration. Keep this form fast: identity → contact → address → go. Allergy is the one arguable exception (safety) — decide with product.

## 9. Open questions for product owner — RESOLVED (2026-07-18)
1. ~~**R1:** Guardian required or optional?~~ → **Required for minors** (age < 18 from DOB); optional for adults. Guardian block already implemented.
2. ~~**R3:** Duplicate policy / match key?~~ → **Warn-and-allow** on **name+DOB (and/or mobile)** via existing `list_patients` search; CURP stays a hard-unique backend guard.
3. ~~**R6:** Blood group placement?~~ → Moot — guardian now present alongside blood group, so priority is no longer inverted. Blood group stays; gender-from-API is backlog.

## 10. Build batch (2026-07-18 decisions)
- **R8** DOB required (zod `.min(1)` + backend throw); drop the false `*` on Last Name. *(FE + tiny BE)*
- **R3** Duplicate warn-and-allow — name+DOB/mobile blur → `list_patients` search → inline "possible existing patient" link. *(FE only)*
- **R1** Require primary guardian when age < 18. *(FE only)*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
