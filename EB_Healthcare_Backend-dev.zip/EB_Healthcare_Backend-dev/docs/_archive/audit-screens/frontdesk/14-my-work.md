# Front Desk → My Work / Inbox

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Work · **Screen 14/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `inbox` (visible in nav for all roles).
**Frontend:** `src/components/narzim/inbox/work-inbox-client.tsx`, `todo-detail-client.tsx`.
**Professional lens:** "My Work" should be the desk's proactive checklist — *who to call (no-shows), who to remind (unconfirmed), which follow-ups to book, which balances to chase.* The screen is **real and well-built as a generic to-do/tasks/notes tool** — but the **front-desk operational feed doesn't exist**: those categories are UI scaffolding with no data behind them.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Inbox feed | ToDo, Task, Nursing Task, Clinical Procedure | `tasks.get_my_tasks` | `/api/my-work` |
| Open encounters (clinical notes) | Patient Encounter | `list_encounters(status=Open)` | `/api/encounters` |
| Tasks CRUD | ToDo | `list_todos`, `create_todo`, `update_todo`, `delete_todo` | `/api/my-work/todos` |
| Notes CRUD | Note | `list_notes`, `create_note`, `update_note`, `delete_note` | `/api/my-work/notes` |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| **Inbox feed** (todos/tasks/nursing/procedures/open-notes) | 🟢 **REAL** | `useMyWorkFeed` → `get_my_tasks`; deterministic mapping, not fabricated |
| **Tasks tab** (create/edit/delete, assign, priority, due date) | 🟢 REAL CRUD | `useMyTodos` + `create/update/delete_todo`; optimistic |
| **Notes tab** (debounced autosave CRUD) | 🟢 REAL CRUD | `useMyNotes` + note CRUD |
| **Todo detail** (`/inbox/todos/[name]`) | 🟢 REAL | save/delete/status/priority/assignee; edit gated on ownership |
| My Work sidebar badge | 🟢 REAL | `useMyWorkCount` (feed + open encounters) |
| i18n | 🟢 REAL | `useTranslations("myWork")` (minor literals) |
| Nav visibility | 🟢 REAL | in `buildNav` for all roles |
| **Front-desk operational feed** (no-shows to call, unconfirmed to remind, follow-ups to book, balance due, insurance verify, rooming, vitals queue) | 🔴 **MISSING (scaffolding only)** | those `ItemType`s exist only in `TYPE_CFG` display map (`work-inbox-client.tsx:67–86`); the feed only ever contains todo/task/nursing_task/clinical_procedure/clinical-note — **no data source populates the FD categories** |
| Non-todo item "done" checkbox | 🟡 client-only | local `doneIds` dismiss, not persisted (expected for non-todo) |

## 3. Actions & wiring
- **Todos/notes:** full real CRUD with optimistic updates + autosave — genuinely solid.
- **Feed items:** "Mark Done" real for todos; other types deep-link (real navigation) with a client-only dismiss.
- **The proactive front-desk work** (call no-shows, remind unconfirmed, book follow-ups, chase balances) has **no feed** — a front desk gets *their assigned ToDos + open encounters*, not an operational worklist. This is the same gap as dashboard **D3**.

## 4. Permissions
- `get_my_tasks` scoped to the current user; todos/notes user-owned. Route `inbox` open to all authenticated. Aligned (user-scoped by nature).

## 5. Alignment with core
- ToDo/Note/Task are Frappe-native; feed reads real assignments. Aligned. The missing FD feed would need new backend queries (no-shows from Patient Appointment, unconfirmed from status, balances from Sales Invoice, follow-ups from the follow-up ToDos) — the data all exists, it's just not aggregated into this feed.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **MW1** | **No front-desk operational feed.** The categories that make "My Work" useful to a front desk (no-shows to call, unconfirmed to remind, follow-ups to book, balances to chase, insurance to verify) are display config with **no data source**. | Missing (D3, FD2) | **High** | _pending_ — backend hand-off: aggregate real sources into the feed (appointments by status, outstanding invoices, follow-up ToDos). Same feed powers dashboard D3. |
| **MW2** | Non-todo "done" is a client-only dismiss (not persisted). | Minor | Low | _pending_ — acceptable for deep-link items; document, or persist a dismissal. |
| **MW3** | Minor hardcoded strings ("Search staff…", "Save", "No staff found"). | i18n | Low | _pending_ — catalogs. |

## 7. CRUD / states
- **From this screen:** full CRUD on ToDos + Notes; read on the aggregated feed. States, optimistic updates, autosave all real — one of the more complete screens.

## 8. Recommended options (curated)
- **Build the front-desk operational feed (MW1)** — the one real gap, and the highest-value: it turns "My Work" from a generic to-do list into the desk's proactive worklist, and it's the **same backend feed the dashboard needs (D3)** — build once, use twice.
- **NOT recommended:** adding more manual to-do features — the CRUD is already good. The value is in *auto-populating* the operational categories from real clinic state, not more manual entry.

## 9. Open questions for product owner
1. **MW1:** Approve a backend "front-desk work feed" aggregating no-shows / unconfirmed / follow-ups / balances / insurance-to-verify? (Powers both this screen and the dashboard to-do panel, D3.)
2. What are the exact categories and their source queries the desk wants first?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
