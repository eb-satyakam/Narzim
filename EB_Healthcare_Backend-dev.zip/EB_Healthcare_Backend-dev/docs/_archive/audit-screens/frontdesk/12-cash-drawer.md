# Front Desk → Cash Drawer / Shift

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified post-pull 2026-07-18** — CD1 CRITICAL, **decided: ADR → native POS (Option A)**; CD2/CD3/CD4 decided; interim = hide mock · **Area:** Money · **Screen 12/14** · [index](README.md)

> **Decision (2026-07-18): needs an ADR, then a real backend on native ERPNext POS (Option A — not the custom-doctype Option B).** Rationale: aligned with the app's core-first billing philosophy (`services/billing.py`: "Rule 1: call core, never patch/reimplement") and the core-map. **Live-verified premise correction:** no POS Profile, all invoices `is_pos=0`, POS Opening/Closing Entry unused — so Option A requires POS Profile setup + converting checkout to `is_pos=1` sessions (real rework; the deliberate exception to "minimum changes"). **Interim: hide the mock Cash Drawer** (a fake money-tracker is worse than none). CD2: drop mock PIN session, use authenticated user.
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `cash` + `cash-drawer-sheet`.
**Frontend:** `lib/narzim/shift.ts`, `lib/narzim/session.ts`, `app/(clinic)/cash/cash-client.tsx`, `components/narzim/cash/*`.
**Professional lens:** the cash drawer is where the front desk is personally accountable for money — open with a float, collect through the day, count and reconcile at close. This screen **looks** like it does all that. **It does none of it for real.** Everything is browser `localStorage` with a mock login. This is the single **highest-risk surface in the entire audit** (charter G1, backend B2).

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Shift open/close/float/transfers | **none** | **none** | 🔴 **no `/api/cash` route exists** |
| "Staff on terminal" session | none | none | mock `sessionStorage` (`session.ts`) |

There is **no backend at all.** Confirmed: no `/api/cash` route, `shift.ts` header comment literally says *"All data lives in localStorage."*

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Open shift + opening float | 🟡 **MOCK** | `open-shift-dialog.tsx` → `localStorage`; fake `setTimeout(...300)` instead of an API call |
| Cash collected rolls into drawer | 🟡 **MOCK** | computed client-side from `localStorage`, **not** from real Payment Entries |
| Drawer transfers (petty cash out) | 🟡 MOCK | `transfer-drawer-dialog.tsx` → `localStorage` (`TRANSFERS_KEY`) |
| Close shift + expected-vs-actual variance | 🟡 MOCK | `close-shift-dialog.tsx` → `localStorage` |
| "Who's on the terminal" identity | 🟡 MOCK | `session.ts` PIN session in `sessionStorage` — separate from real auth |
| Shift widget | 🟡 MOCK | renders only if the mock session exists |
| Persistence / multi-user / audit | 🔴 **NONE** | per-browser only; clearing cache erases the cash record |

## 3. Actions & wiring
Every action (open shift, transfer, close shift, count) writes to `localStorage`. **None** touch the server. The "collected" figures are **not reconciled against real `Payment Entry` rows** — so the drawer total is a fiction disconnected from the money the clinic actually took (which lives in Billing → Payments, screen 10).

## 4. Permissions
- Route `cash` allowed for `frontdesk`. But there's no server authority because there's no server call — the "permission" is cosmetic.

## 5. Alignment with core
- **Zero alignment.** ERPNext has a native **POS Profile + POS Opening Entry + POS Closing Entry** model (and every checkout invoice is already `is_pos=1`) — the exact primitives this screen needs — and **none are used.** This is the starkest "beside, not with, core" divergence in the app (core-map / backend B2).

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **CD1** | **Entire cash/shift subsystem is mock** — localStorage + mock session, no backend, not reconciled, not multi-user, not auditable. Verified fully intact post-pull 2026-07-18 (no `/api/cash`; `shift.ts` = localStorage; no backend module). | Mock / integrity (FD7, G1, B2) | **Critical** | ✅ **DECIDED (2026-07-18): ADR → build on native ERPNext POS (Option A).** Adopt **POS Profile + POS Opening/Closing Entry** — aligned with the app's core-first billing (`services/billing.py`: "call core, never reimplement") and the core-map's ✅-uses-core stance. Rejected Option B (custom Cash Shift doctype) as ♻️ reimplement-over-core. **Interim: hide the mock Cash Drawer** until the backend lands. |
| **CD2** | **Mock PIN session** (`session.ts`) parallel to real auth — a second, fake identity layer. | Mock / security posture | High | ✅ **DECIDED (2026-07-18): remove** — derive "who's on the till" from the authenticated user (ties to Login PIN parking). |
| **CD3** | **Collected totals not reconciled to real payments.** | Integrity | High | ✅ **DECIDED (2026-07-18): reconcile via native POS Closing Entry**, which aggregates the `is_pos=1` invoices/payments of the open POS session (see CD-premise below). Real `Payment Entry` remains the money source (ties BP1). |
| **CD4** | No shift handover / multi-cashier support. | Missing | Med | ✅ **DECIDED (2026-07-18): part of the cash ADR** — native POS opening entry is per user+profile, giving multi-cashier for free. |
| **CD-premise** | 🆕 **Audit premise was wrong** — it assumed "checkout invoices are already `is_pos=1` so POS reconciliation is free." Live site (2026-07-18): **no POS Profile exists**, **all 9 Sales Invoices are `is_pos=0`**, POS Opening/Closing Entry have **0 records**. | Correction | — | ⚠️ **Scope note:** Option A is NOT free — the ADR/build must (a) create a POS Profile per terminal/clinic and (b) make checkout emit **`is_pos=1`** POS invoices tied to an **open POS session**. Real rework on the (otherwise solid) checkout flow. This is the deliberate exception to "minimum changes." |

## 7. Recommended approach (this screen needs a decision, not just fixes)
The right fix is **an ADR first**, then build on core:
1. **ADR:** adopt ERPNext **POS Profile + POS Opening/Closing Entry** vs. custom shift doctypes. (Recommend POS Entry — it's native, ties to the `is_pos=1` invoices we already create, and gives reconciliation for free.)
2. **Backend:** `api/v1/cash` — open shift (float), record drawer transfers, close shift (count + variance), all persisted + audited, reconciled against `Payment Entry`.
3. **Frontend:** replace the `localStorage` layer with the real API; derive cashier identity from the authenticated user (drop `session.ts`).
4. **Interim honesty:** until then, either hide the Cash Drawer or badge it clearly as non-persistent — do not present a fake drawer total as real.

**NOT recommended:** patching the localStorage version to "feel" more real — that deepens the integrity problem. This is the one screen where the answer is "stop and build the backend."

## 8. Open questions for product owner
1. **CD1:** Approve an ADR for cash/shift (POS Opening/Closing Entry vs custom doctypes)? This is the highest-value, highest-risk item in the front-desk audit.
2. **Interim:** hide the Cash Drawer, or keep it visible with a clear "not persisted yet" label, until the backend lands?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
