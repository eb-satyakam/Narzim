# Front Desk → Appointments List

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Appointments · **Screen 5/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `appointments` (allowed).
**Frontend:** `src/app/(clinic)/appointments/appointments-client.tsx` (940 lines).
**Professional lens:** the appointments list is the front desk's schedule ledger — filter the day, find a booking, and *act on it* (confirm, check in, reschedule, cancel, reassign). The list, filters, and KPI strip are real. But the row menu is thin — it can only **reschedule/cancel**, not **confirm or check in** — so the desk's most common actions force a detour to the dashboard or chart.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Appointment list | Patient Appointment | `appointments.get_appointments(date?, limit, sort)` | `/api/appointments` |
| Reschedule | Patient Appointment | `reschedule_appointment` | `/api/appointments/[id]/reschedule` |
| Cancel | Patient Appointment | `cancel_appointment` | `DELETE /api/appointments/[id]` |
| Reassign (built, hidden) | Patient Appointment | `reassign_appointment` | `/api/appointments/[id]/reassign` |
| Practitioner filter | Healthcare Practitioner | `get_providers` | `/api/providers` |

**Hooks:** `useAppointments`, `useRescheduleAppointment`, `useCancelAppointment`, `useReassignAppointment`, `usePractitioners`. **Table:** shared `DataTable` (list) + card grid + mobile card list.

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| List (today/tomorrow/week/custom/all), search, status + practitioner filters | 🟢 **REAL** | `useAppointments(apiParams)`; filters client-side over the fetched set. |
| Date-mode tabs + counts | 🟢 REAL | derived from live list. |
| KPI strip (Total / Confirmed / Checked-in / Completed / No-show) | 🟢 REAL | from filtered live rows (L530–536). |
| Reschedule | 🟢 REAL | `useRescheduleAppointment` (L450). |
| Cancel (with reason) | 🟢 REAL | `useCancelAppointment` (L463). |
| List/grid/mobile views | 🟢 REAL | shared DataTable + card layouts. |
| **Check-in from the list** | 🔴 **MISSING** | row menu has only Reschedule + Cancel (L349–375). No `useCheckInPatient`. |
| **Confirm from the list** | 🔴 **MISSING** | no confirm action, though `Confirmed` is a KPI + filter value. |
| **Reassign provider** | 🟠 **BUILT-BUT-HIDDEN** | dialog+handler+hook all present; menu item **commented out** (L357–367, "temporarily disabled per request"). Charter G5. |
| **Inline "Book" button** | 🔴 MISSING | relies on the global "+ New Appointment" header; no list-level Book CTA. |
| **Age in row** | 🟡 **MOCK** | `mapApiAppt` hardcodes `age:"—"` (L…), rendered as `{mrn} · {age}` → always "—". Pediatric age never shows. |
| All UI strings | 🟡 **HARDCODED ENGLISH** | title, menu labels, toasts, status labels — no `next-intl` in this file (unlike patients-client). |
| Pagination | 🟠 **CAPPED** | fetch bounded: 200/day, 500 for week/all; "all dates" = 500 most recent only. Paged client-side. |

## 3. Actions & wiring
| Action | In list? | Wired? | Note |
|---|---|---|---|
| Reschedule | ✅ | ✅ real | dialog + mutation |
| Cancel (reason) | ✅ | ✅ real | confirm dialog |
| Reassign provider | ❌ (commented) | (would be real) | G5 — one-line re-enable |
| **Confirm** | ❌ | — | must go to dashboard/chart |
| **Check in** | ❌ | — | must go to dashboard/chart |
| Book | ❌ (global header only) | ✅ real (elsewhere) | no list CTA |
| Completed/Cancelled rows | "No actions available" | ✅ | correct |

Row click → *(verify target: patient chart vs appointment detail)*.

## 4. Permissions
- Route `appointments` allowed for `frontdesk`. `canReassign = mergeCapabilities(roles).reassign` (true for FD) — but the action is commented out regardless.
- Backend status transitions gated by `_ROLE_ALLOWED_STATUSES`; reschedule/cancel/reassign all permitted for `EB_Front Desk`.

## 5. Alignment with core
- Reads/writes the real Patient Appointment; reschedule/cancel re-run core validations. Aligned.
- **Because check-in isn't here**, the list can't be the place arrival is stamped — consistent with (but compounding) the dashboard's check-in gap (D4). The desk has no single screen that both lists the day *and* checks people in.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **A1** | **No Confirm / Check-in in the list.** The schedule ledger can't perform the two most frequent front-desk actions; user must switch to the dashboard queue or open the chart. | Missing / workflow | **High** | _pending_ — add Confirm + Check-in to the row menu (hooks exist: `useUpdateAppointmentStatus`, `useCheckInPatient`; check-in must call real `check_in_patient`). FE-only. |
| **A2** | **Reassign provider commented out** despite working hook/dialog/handler + capability. | Built-but-hidden (G5) | **Med** | _pending_ — confirm *why* it was disabled ("per request"), then re-enable (1 line) or document the reason. |
| **A3** | **Age hardcoded `"—"`** in the row (rendered next to MRN). Pediatric age never shows though DOB is available. | Mock (FD4) | Med | _pending_ — carry real age into `mapApiAppt` (payload/patient has DOB). |
| **A4** | **Entire screen hardcoded English** — no `next-intl`. Bilingual violation, worse than patient list. | i18n (FD6) | Med | _pending_ — migrate to message catalogs. |
| **A5** | **No inline Book button** on the list. | Missing | Low-Med | _pending_ — add a list-level "Book appointment" CTA (dialog exists). |
| **A6** | **Fetch capped** (200/day, 500 week/all); "all dates" only shows 500 most recent. | Scale | Low-Med | _pending_ — real pagination or explicit "showing recent N" (mirrors patient-list P1). |
| **A7** | Reschedule/cancel toasts are hand-rolled `setTimeout` (L445), not the app toast system. | Consistency | Low | _pending_ — use the shared toast. |

## 7. CRUD / states
- **From this screen:** Read (list) + Update (reschedule) + Cancel. No confirm/check-in (A1), no create (booking is elsewhere).
- **States:** `isLoading`/`isError` handled; completed/cancelled rows correctly show "No actions available". Date counts + KPI strip live.

## 8. Recommended options (curated)
The list should let the desk **run the day without leaving it**.
- **Add Confirm + Check-in to the row menu** (A1) — the single highest-value fix; makes the list self-sufficient. Check-in must stamp arrival via `check_in_patient`.
- **Re-enable Reassign** (A2) — coverage for provider absence; already built.
- **Show real age** (A3) and **add an inline Book CTA** (A5).
- **NOT recommended:** clinical actions (start encounter, vitals) in the appointments list — those are queue/chart actions for clinical roles. Keep this list to schedule management: confirm · check-in · reschedule · reassign · cancel · book.

## 9. Open questions for product owner
1. **A1:** Add Confirm + Check-in to the appointments list row menu? (Recommend yes — it's the front desk's home screen for the schedule.)
2. **A2:** Why was Reassign disabled "per request" — safe to re-enable, or is there a pending backend/UX concern?
3. Row click destination — should it open the **patient chart** or an **appointment detail** view? (Confirm current behavior.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
