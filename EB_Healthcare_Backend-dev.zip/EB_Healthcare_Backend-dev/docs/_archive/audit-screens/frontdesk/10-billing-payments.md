# Front Desk → Billing (Payments tab)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified post-pull 2026-07-18** — BP2 resolved; BP1/BP3/BP5 decided; BP4 deferred · **Area:** Money · **Screen 10/14** · [index](README.md)

> **Build batch (2026-07-18, all FE):** BP1 client-side daily reconciliation (per-method totals for date) · BP5 method filter chips · BP3 payment receipt → shared `InvoicePrintModal`. **Deferred:** BP4 payment reversal (backend).
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `billing` → Payments tab.
**Frontend:** `src/app/(clinic)/billing/billing-client.tsx` (Payments section + `payColumns`).
**Professional lens:** the Payments tab is the money-in ledger — every payment the clinic took, by whom, how, against which invoice. It's a clean, real, read-only list. The gap is what a front desk needs it *for*: **day-end reconciliation** (cash vs card totals) and a **payment receipt** — neither exists, and it hardcodes the currency symbol.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Payments list | Payment Entry | `billing.list_payment_entries` | `/api/billing/payments` via `usePayments` |

Columns: payment no · date · patient (party_name/party + MRN) · linked invoice(s) · method · amount · status.

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Clinic-wide payments list | 🟢 **REAL** | `usePayments` → `list_payment_entries` |
| Patient + linked invoice(s) per payment | 🟢 REAL | `party_name`/`mrn`, `invoices[]` with "+N" badge |
| Method + status chips | 🟢 REAL | `mode_of_payment`, `paymentStatusBadge` |
| Search + date range | 🟢 REAL | server-side (shared with Invoices) |
| Capped notice ("showing latest X of Y") | 🟢 REAL | `payCapped` rendered (L688) |
| i18n | 🟢 REAL | `useTranslations` |
| **Amount currency** | 🟡 **HARDCODED `$`** | `${paid_amount.toLocaleString()}` (L562) — ignores `useCurrency()` (wrong for INR ₹); *inconsistent with the Invoices tab in the same file* |
| **Method filter** | 🔴 MISSING | backend `list_payment_entries` supports `mode_of_payment` filter; UI has only search+date |
| **Day-end reconciliation** (cash/card totals) | 🔴 **MISSING** | no per-method daily totals; the closest surface to "collected today" is just a flat list |
| **Payment receipt** (print/PDF) | 🔴 MISSING | no per-payment receipt (G7) |
| **Reverse/void a payment** | 🔴 MISSING | a mis-keyed payment can't be reversed here (only invoice-level refund) |
| Row actions | 🔴 NONE | view-only ledger |

## 3. Actions & wiring
**None** — the Payments tab is entirely read-only. No receipt, no reversal, no per-method rollup, no export (the CSV export is Invoices-only).

## 4. Permissions
- Route `billing` allowed; `list_payment_entries` allows `EB_Front Desk`. Read-only, aligned.

## 5. Alignment with core
- Reads core Payment Entry directly. Aligned. But note: because there's **no POS shift/till** (B2/G1), this list is the *only* record of cash taken — and it's not grouped or reconciled, so "how much cash is in the drawer right now" can't be answered here. That's the reconciliation gap the mock Cash Drawer (screen 12) pretends to fill.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **BP1** | **No day-end reconciliation.** No per-method totals (Cash today / Card today / Transfer today); the Payments tab even shows the **same invoice-level KPIs as the Invoices tab** (they don't change on tab switch). Front desk can't close the day from real data. | Missing (ties G1/B2) | **High** | ✅ **DECIDED (2026-07-18): lightweight client-side daily summary now.** Per-method totals (Cash/Card/Transfer/total) for the selected date, computed client-side over the loaded set (date filter already exists; payload has method+date+amount). No new backend. Precursor to the real cash/shift backend (screen 12 / cash ADR). |
| **BP2** | **Currency hardcoded `$`** on the amount column. | i18n/money bug | Med | ✅ **RESOLVED (verified 2026-07-18, post-pull)** — amount now `money(paid_amount, currency)` via `useCurrency()`. |
| **BP3** | **No payment receipt** (print/PDF) per payment. | Missing (G7) | Med | ✅ **DECIDED (2026-07-18): shared receipt** — reuse the `InvoicePrintModal` being wired for CO3/C2/BI6. FE. |
| **BP4** | **No payment reversal/void.** A wrong payment can't be corrected from here. | Missing | Med | ⏸ **DEFERRED (2026-07-18)** — backend hand-off (reverse Payment Entry); same class as BI2 void. |
| **BP5** | **No method filter** though backend supports it. | Missing | Low | ✅ **DECIDED (2026-07-18): add method filter chips** (pairs with BP1 — "show today's Cash → see the total"). FE. |

## 7. CRUD / states
- **From this screen:** Read only. No create/update/void/export.
- **States:** loading + capped notice handled; i18n present. Clean but minimal.

## 8. Recommended options (curated)
The Payments tab should power **day-end close**, not just list rows.
- **Daily reconciliation summary (BP1)** — totals by method for the selected date, so the desk can count the drawer against the system. This is the single most valuable addition and the honest precursor to a real cash-drawer backend (vs the mock, screen 12).
- **Fix currency (BP2)** and add **payment receipt (BP3)**.
- **Method filter (BP5)** for quick "show me today's cash".
- **NOT recommended:** free-form payment editing — reversal should be an explicit, audited void (BP4), not an edit. Keep the ledger immutable.

## 9. Open questions for product owner
1. **BP1:** Add a day-end reconciliation summary here now (totals by method), or defer entirely to the cash-drawer/shift backend (screen 12 + ADR)? (Recommend a lightweight summary now — it's real data and closes a daily need.)
2. **BP4:** Should payment reversal exist, and under what permission?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
