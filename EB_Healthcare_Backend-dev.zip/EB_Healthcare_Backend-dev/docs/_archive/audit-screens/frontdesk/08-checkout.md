# Front Desk → Checkout (consolidated POS)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified post-pull 2026-07-18** — CO2/CO4 resolved upstream; CO1/CO3/CO5/CO7/CO8/CO9 decided; CO6 deferred · **Area:** Money · **Screen 8/14** · [index](README.md)

> **Build batch (2026-07-18, all FE — backend already supports):** CO1 partial payment (`collect_payment`) · CO3 receipt → existing `InvoicePrintModal` · CO5 discount field → `create_pos_invoice` (no cap, per backend — conscious risk) · CO7 friendly conflict + refresh · CO8 date/practitioner per cart line · CO9 default to Cash.
**Role:** `EB_Front Desk` (frontend `frontdesk`) · triggered from chart Billing tab + dashboard checkout room.
**Frontend:** `src/components/narzim/patient-chart/checkout-dialog.tsx` (301 lines) — ADR-017.
**Professional lens:** checkout is the moment the visit becomes money — gather every un-billed charge (consulta, vaccine, lab, procedure), make **one** bill, take payment, hand over a receipt. This is the **most complete money surface in the app**: the cart is real and server-validated. The holes are at the register edges — **hardcoded currency/methods, no partial payment, no discount, no printed receipt.**

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Billables cart | Patient Appointment / Encounter / Lab Test / Clinical Procedure / Immunization | `billing.get_patient_billables` | `/api/billing/pos` (GET) via `usePatientBillables` |
| Create consolidated invoice (+ optional settle) | Sales Invoice (+ Payment Entry) | `billing.create_pos_invoice` | `/api/billing/pos` (POST) via `useCreatePosInvoice` |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| **Server cart** — all un-billed services, grouped (consultation/vaccine/lab/procedure/encounter) | 🟢 **REAL** | `usePatientBillables` → `get_patient_billables` |
| Line selection (all checked by default) | 🟢 REAL | `selected` set, per-line toggle |
| **One consolidated invoice + optional payment** | 🟢 **REAL** | `create_pos_invoice`; server re-validates cart (anti-tamper — client sends only refs, rates from server) |
| Collect-now toggle | 🟢 REAL | `collectNow`; full amount settled |
| Receipt view (grand total + outstanding) | 🟢 REAL (on-screen) | `receipt` state after success |
| Loading / error / empty states | 🟢 REAL | distinct, translated |
| i18n | 🟢 **REAL** | uses `useTranslations` throughout (unlike booking dialogs) |
| **Payment methods** | 🟡 **HARDCODED** | `METHODS` = Cash/Card/Bank transfer (L77–81), not `usePaymentMethods` (charter G11) |
| **Currency format** | 🟡 **HARDCODED `$` + `es-MX` + 0 decimals** | `fmtMoney` (L30–31) ignores `useCurrency()`; shows `$` for any currency (wrong for INR ₹) and **strips cents** (₱1,700.50 → "$1,701") |
| **Partial payment** | 🔴 **MISSING** | `paid_amount: total` always (L106) — collect-now is all-or-nothing; can't take a part-payment (backend `collect_payment` supports partial) |
| **Discount at checkout** | 🔴 MISSING | `create_pos_invoice` supports `discount_amount`/`discount_percentage`; dialog exposes no discount field |
| **Ad-hoc / off-menu line** | 🔴 MISSING | can only bill server-discovered billables; no way to add a certificate/misc item (ties G6) |
| Line qty edit | 🔴 MISSING (by design) | rate/qty from server (correct for anti-tamper) |
| **Printed/downloadable receipt** | 🔴 MISSING | receipt is on-screen only → "Close"; no print/PDF (ties G7 + C2) |

## 3. Actions & wiring
- **Checkout:** `handleCheckout` → `create_pos_invoice` with selected line refs (+ method/amount if collecting). Real, server-validated, one invoice. Success → on-screen receipt.
- Concurrent-checkout safety: backend re-validates and the second submit fails safely on "already invoiced" (per billing trace) — no double-bill, but the UI would surface it as a raw error.

## 4. Permissions
- `collectPayment` capability true for FD; reachable from chart Billing tab + dashboard checkout room. Backend `create_pos_invoice`/`collect_payment` gate + run under caller. Aligned.

## 5. Alignment with core
- **Strong core alignment:** billables via core `get_healthcare_services_to_invoice`; one Sales Invoice with `reference_dt/dn` back-links; core `on_submit → set_invoiced` provides the double-bill guard. This is the "build *with* core" exemplar (core-map). The `is_pos=1` invoice, however, has **no POS Opening/Closing Entry** behind it (backend B2 / cash-drawer G1) — the payment is real but not reconciled to a till.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **CO1** | **No partial payment at checkout.** Collect-now settles the full total only (`paid_amount: total`, checkout-dialog.tsx:126); a family paying part must be handled elsewhere. | Missing | **High** | ✅ **DECIDED (2026-07-18): add partial payment.** Editable amount ≤ total; show resulting outstanding. Backend `collect_payment` already supports it. FE. |
| **CO2** | **Currency hardcoded `$`/`es-MX` + cents stripped.** | i18n / money bug | **High** | ✅ **RESOLVED (verified 2026-07-18, post-pull)** — `fmtMoney` now uses payload currency, narrowSymbol, 2 decimals. |
| **CO3** | **No printed/downloadable receipt.** Receipt is on-screen only. | Missing (G7/C2) | **Med-High** | ✅ **DECIDED (2026-07-18): wire to the existing `InvoicePrintModal`** (same fix as chart C2). No new backend. |
| **CO4** | **Payment methods hardcoded** instead of `usePaymentMethods`. | Mock (G11) | Med | ✅ **RESOLVED (verified 2026-07-18, post-pull)** — now `usePaymentMethods` (real ERPNext Modes of Payment). |
| **CO5** | **No discount at checkout** though `create_pos_invoice` supports it. | Missing | Med | ✅ **DECIDED (2026-07-18): expose discount (amount/%), forward to `create_pos_invoice` — policy "as per backend".** Backend imposes **no discount cap and no special permission** beyond `Sales Invoice: create` (verified billing/api.py:205, services/billing.py) — front desk already qualifies. So no artificial FE cap. **Conscious risk noted:** no server-side cap → a 100% discount is possible without approval; adding a cap later is a deliberate backend change (role check or core Item `max_discount`), out of scope now. |
| **CO6** | **No ad-hoc line.** Off-menu items can't be billed at checkout. | Missing (G6) | Med | ⏸ **DEFERRED (2026-07-18)** — revisit with the dedicated invoice/editor flow (charter G6 / RECOMMENDED_SCREENS 9b). If added, rate must come from a real Item (keep anti-tamper). |
| **CO7** | Concurrent/failed checkout surfaces a raw backend error ("already invoiced"). | UX | Low | ✅ **DECIDED (2026-07-18): friendly conflict message + refresh cart.** FE. |
| **CO8** | **Cart lines are indistinguishable** — multiple same-name services (e.g. 5× "Emergency Consultation $800") show no date/practitioner, so front desk can't tell which visit each charge is or safely deselect one. (New, live-verified 2026-07-18.) | Clarity / data integrity | **Med** | ✅ **DECIDED (2026-07-18): show date (+ practitioner) per cart line.** Payload already carries the source ref. FE. |
| **CO9** | **Default payment method is "Bank Draft"** (alphabetical `METHODS[0]`), not the clinic default. (New, live-verified 2026-07-18.) | UX | Low | ✅ **DECIDED (2026-07-18): default to Cash** when present, else first. FE. |

## 7. CRUD / states
- **From this screen:** Create (one invoice) + optional payment. No edit/void here (correct — corrections live in Billing/refund).
- **States:** loading/error/empty/receipt all handled and translated — the most polished states of any FD screen. Full-amount-only settle (CO1).

## 8. Recommended options (curated)
Checkout should close the visit cleanly: right total → flexible payment → receipt.
- **Partial payment (CO1)** and **real currency/decimals (CO2)** — the two that affect money correctness; do first.
- **Receipt print (CO3)** — the tangible artifact a family expects.
- **Real payment methods (CO4)** and **optional discount (CO5)** for consistency with booking + collect dialogs.
- **NOT recommended:** editable line rates/qty at checkout (breaks the anti-tamper design — rates must come from server masters). Ad-hoc lines (CO6) are fine *if* they draw rate from a real Item, not free-typed. Keep the integrity guarantee.

## 9. Open questions for product owner
1. **CO1:** Support partial payment at checkout (family pays part, rest stays outstanding)?
2. **CO5:** Is checkout-time discount allowed, and if so who may apply it / up to what limit?
3. **CO6:** Should ad-hoc/miscellaneous charges be billable at checkout, or only via a dedicated invoice flow (charter G6)?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
