# Front Desk → Patient Chart 360

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-08-14 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified post-pull 2026-07-18** — C1a/C3/C6 resolved by upstream; C1b/C2/C5 decided; C4 pending · **Area:** Patients · **Screen 4/14** · [index](README.md)

> **Build batch (2026-07-18):** C1b restrict FD to non-clinical tabs (keep allergy alert) · C2 wire Print Receipt → existing `InvoicePrintModal` · C5 gate ⌘K "AI" group behind Phase-5 flag. All FE-only, no backend.
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `patients/[id]`.
**Frontend:** `patient-chart-client.tsx` + `patient-screen.tsx` (container/gating) → `overview-frontdesk.tsx`, `appointments-tab.tsx`, `billing-tab.tsx`, `edit-patient-sheet.tsx`, `patient-contacts-section.tsx`, `patient-actions-menu.tsx`.
**Professional lens:** the chart is where the front desk answers "who is this family, what's their visit today, what do they owe, how do I reach them?" — and edits demographics/guardian. The front-desk-facing pieces (overview, appointments, billing, edit) are **real and well-wired**. The concern is the opposite of the other screens: front desk is shown **too much** — every clinical tab plus a **fabricated AI risk banner**.

## 1. Tab gating — the headline
Gating: `src/lib/narzim/chart-permissions.ts`. For `frontdesk`: `sections:{}`, `subtabs:{}` → **nothing restricted.** Front desk sees every tab not globally commented out.

**Front-desk visible tabs:** Overview (Summary/Appointments/Contact/Tasks) · Clinical (**Vitals, Lab Test, Medications, Immunizations, History, Documents**) · Financial (Billing) · Messages.
- **Overview component:** `FrontDeskOverview` (overview-tab.tsx:311) — role-correct.
- **Contrast:** nurse *hides* Financial + Summary; practitioner = full. So **front desk has the same clinical tab surface as a doctor** — only the *overview card* differs.

**Globally hidden for everyone** (code-commented, not role-based): Encounters, Conditions, Referrals, Insurance sub-tab.

## 2. REAL vs MOCK vs MISSING (front-desk-facing)
| Surface | State | Hook / endpoint | Note |
|---|---|---|---|
| **Overview — Today's appt + next visit** | 🟢 REAL | `useAppointments({patient})` | filters today + Confirmed/Checked-in |
| Overview — reschedule row | 🟢 REAL | `useRescheduleAppointment` | |
| Overview — Total invoices + Outstanding | 🟢 REAL | `useInvoices({patient})` | summed `outstanding_amount` |
| Overview — Insurance payor/active | 🟢 REAL | `usePatientInsurance` | |
| **Appointments tab** — confirm / check-in / reschedule / cancel / book / rebook | 🟢 REAL | `useUpdateAppointmentStatus`, `useCheckInPatient`, `useCancelAppointment`, delegated book | full lifecycle wired; check-in uses **real `check_in_patient`** (unlike dashboard, cf. D4) |
| Appointments (Timeline) — invoice from appointment | 🟢 REAL | `NewInvoiceSheet` (create) / `InvoicePreviewSheet` (view) / `CollectPaymentDialog` (collect) | **Updated 2026-08-14** — was a binary "has invoice? See Invoice : Create Invoice" (`CreateInvoiceDialog`/`InvoicePrintModal`, both now deleted); the row action is now driven off `appt.billing.status`: `Unbilled` → **Create Invoice** (opens the consolidated drawer, `appointment` prescope); `Pending` (Unpaid/Partly Paid) → **See Invoice** *and* **Collect Payment** side by side; `Paid`/`Refunded` → **See Invoice** only. "See Invoice" now opens the same rich Invoice Preview drawer as the Billing hub (letterhead, line items, totals, its own embedded Collect/Refund/Print) instead of the old plain print/download modal. |
| **Billing tab** — list / summary / collect / PDF | 🟢 REAL | `useInvoices`, `useCollectPayment` (via `CollectPaymentDialog`), `InvoicePrintModal` (Download) | **Updated 2026-08-14** — `checkout-dialog.tsx` and `collect-invoice-payment-dialog.tsx` are deleted; POS checkout ("Pay now", chart top bar) and ad-hoc invoicing now go through the consolidated `NewInvoiceSheet` (`patient` prescope — builds from the real unbilled-services cart). The row-level **Collect Payment** button opens `collect-payment-dialog.tsx` — a compact "Record Payment" dialog extracted from the Billing hub's own `CollectButton`, not the invoice-building drawer, since collecting on an already-existing invoice is a quick action, not a cart-building flow. |
| **Edit patient** (demographics) | 🟢 REAL | `useUpdatePatient` → `update_patient` | gated `frontdesk`/`admin`; dirty-only submit |
| **Guardian / contacts edit** | 🟢 REAL | `PatientContactsSection` → guardian endpoints | *the guardian capture missing at registration (R1) exists here* |
| Photo upload | 🟢 REAL | `PatientPhotoDialog` | gated frontdesk/admin/practitioner |
| Actions menu | 🟢 REAL (thin) | New Appointment + ⌘K only; Start Encounter hidden for FD | correct |
| **Print Receipt** (overview) | 🔴 **MOCK** | none — `onFlash("Printing receipt…")` (overview-frontdesk.tsx:227) | toast stub, no print |
| **"New Invoice" button** (billing) | 🟠 **COMMENTED OUT** | — (billing-tab.tsx:239–244 "hidden until wired") | matches charter G6 |
| **Refund** | 🔴 MISSING | none | no refund UI in chart billing |
| **AI risk banner** ("High Readmission Risk") | 🔴 **MOCK, and shown to FD** | `patHash`-derived (patient-screen.tsx:495,544) | fabricated clinical judgment visible to a non-clinical role |
| Ask-Narzim insights / recommended actions | 🔴 MOCK | `INSIGHT_POOL` via `patHash`; hardcoded strings | AI cosmetics (Phase 5) leaking into the live chart |
| Command palette `rx`/`lab`/`imaging` | 🟡 stub | `onFlash("Opening…")` / "coming soon" | |
| `checkout-dialog` money format | 🟡 hardcoded `es-MX` | ignores `useCurrency()` | drifts from real currency |

## 3. Actions & wiring (front desk)
Appointment lifecycle, billing (collect/checkout/print), invoice-from-appointment, demographic + guardian + photo edit — **all REAL and wired**. Clinical actions correctly denied: Add Vitals (needs `markReady`), Start Encounter (needs `startEncounter`/practitioner) are hidden for FD. The completed-appointment "report" deep links are cosmetic — every row opens the same generic `EncounterReportModal`.

## 4. Permissions — the concern
- **Front desk is not restricted from any clinical tab.** `chart-permissions.ts` leaves `frontdesk` wide open, so FD reads **Vitals, Lab results, Medications, Immunizations, clinical History** — the same clinical surface as a doctor. Backend read-permission on those doctypes ultimately governs data return, but the *UI intent* is "front desk = non-clinical" (charter §1), and this contradicts it.
- **A fabricated "High Readmission Risk" banner renders for FD.** Even setting aside that it's fake (`patHash`), surfacing a clinical risk judgment to a non-clinical role is a design/PHI-posture problem.
- Edit/photo correctly gated to `frontdesk`/`admin`; Start Encounter correctly denied.

## 5. Alignment with core
- Demographics/guardian edits go through `update_patient` + guardian endpoints (real Patient/Contact/Address). Billing via core Sales Invoice / Payment Entry / POS. Appointment check-in here uses the **real `check_in_patient`** (stamps `custom_checked_in_at`) — the correct path the dashboard bypasses (D4). Aligned.
- History tab does **not** use core's `Patient Medical Record` timeline (cf. core-map "timeline ignored") — it's the hand-rolled feed.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **C1a** | **Fabricated "High Readmission Risk" AI banner** rendered on the live chart. | Phase violation / fake | **High** | ✅ **RESOLVED (verified 2026-07-18, post-pull)** — banner now gated off for all roles (`chart-permissions.ts` `showRiskBanner:false`); does not render. (Mock `INSIGHT_POOL` code still present but inert — see C5.) |
| **C1b** | **Front desk sees all clinical tabs** — no gating for `frontdesk` (`sections:{}`): Lab Test, Medications, Immunizations, growth chart, Allergies/Medical/Surgical history all visible to a non-clinical role. | Role scope / PHI posture | **High** | ✅ **DECIDED (2026-07-18): restrict.** Front desk → non-clinical tabs only (Summary-lite, Timeline, Documents, Billing, Messages); **hide** Lab Test / Medications / Immunizations / clinical-history panels / growth chart. **Keep the allergy alert visible** (safety). Data-minimization (LFPDPPP/DPDPA). FE-only (`chart-permissions.ts`). |
| **C2** | **Print Receipt is a toast stub** (`overview-frontdesk.tsx:229` → `onFlash(t("printReceipt"))`). i18n sweep translated the stub but did not wire a real receipt. | Mock (FD1) | **Med-High** | ✅ **DECIDED (2026-07-18): wire to the existing `InvoicePrintModal`** already used on the appointments/billing surfaces — no new backend. |
| **C3** | **"New Invoice" button commented out** (billing tab). No ad-hoc invoice from the chart. | Built-but-hidden (charter G6) | Med | ✅ **RESOLVED (verified 2026-07-18)** — no longer commented out in `billing-tab.tsx`. Then **Decided/Resolved (2026-08-14)** — Decided/Resolved (2026-08-14)** — same fix as [09-billing-invoices.md#BI1](09-billing-invoices.md): the chart's top-bar **"Pay now"** button now opens the consolidated `NewInvoiceSheet` (`patient` prescope), building from the real unbilled-services cart. No separate billing-tab button was added — one ad-hoc-invoice entry point per screen was judged enough. |
| **C4** | **No refund** in chart billing (refund exists on the Billing hub, not here). | Missing | Med | _pending_ — decide whether refund belongs in-chart. |
| **C5** | **AI palette surfaces** — chart ⌘K still exposes "Ask Narzim AI" + "Generate Risk Report" (`command-palette.tsx:48-49`, ungated); `INSIGHT_POOL` mock present. Insight *cards* are gated off, but these commands are not. | Mock / phase violation | Med | ✅ **DECIDED (2026-07-18): gate the entire ⌘K "AI" group behind the Phase-5 flag** — removed from front desk now; returns when AI ships. |
| **C6** | `checkout-dialog` hardcoded `es-MX` currency, dropping cents. | i18n/currency drift | Low | ✅ **RESOLVED (verified 2026-07-18, post-pull)** — now dynamic currency + 2 decimals via company currency. |
| **C7** | Completed-appointment "report" links are cosmetic (all open the same modal). | UX | Low | _pending_ — deep-link or drop the distinct labels. |
| **C8** | **Timeline row gave no way to collect a partial/outstanding balance** — an invoiced-but-unpaid appointment showed only "See Invoice", so front desk had to leave the chart (Billing hub) to collect. | Missing | Med | **Fixed (2026-08-14)** — row action is now conditional on `appt.billing.status`; a `Pending` invoice shows **See Invoice + Collect Payment** together (see row 2 update above). |
| **C9** | **Billing tab's "Outstanding" KPI could show a negative amount** (e.g. "-172 MXN"). Caused by summing `outstanding_amount` over the returns-included invoice set used for the "Collected" KPI — an unsettled credit note carries a *negative* outstanding (money the clinic owes the patient, a refund payable), which is a different concept from a receivable and was netting against real balances. | Correctness | Med | **Fixed (2026-08-14)** — "Outstanding" now sums over the returns-excluded invoice list, so it only ever reflects what the patient owes. |

## 7. CRUD / states
- **From this screen (FD):** Read (all tabs) · Update (demographics, guardian, photo) · appointment status mutations · billing collect/checkout/create-from-appointment. No patient delete (correct).
- **States:** overview/appointments/billing all have real hooks with loading/empty handling; edit sheet is dirty-only submit with real update.

## 8. Recommended options (curated)
- **Fix the role posture first (C1):** decide FD clinical visibility and **strip the fake AI/risk banner** — this is the one item that's both a phase-rule violation and a data-trust problem.
- **Real receipt (C2)** — the front desk's job includes handing over proof of payment.
- **Guardian editing is here and real** — good; that makes the registration gap (R1) recoverable, but registration should still capture it up front.
- **NOT recommended:** giving FD clinical *edit* (vitals/labs/meds) — read context may be acceptable, editing is not; keep those denied. Don't add more AI widgets — remove the ones already leaking.

## 9. Open questions for product owner
1. **C1:** Should front desk *read* clinical tabs (vitals/labs/meds/immunizations/history) for context, or be restricted to Overview/Appointments/Billing/Contact/Messages? And confirm the **fabricated risk banner must be removed** from the live chart now.
2. **C2:** Where should the printable **payment receipt** live — chart overview, billing tab, or both?
3. **C5:** Confirm all AI insight/recommendation surfaces get gated behind the Phase-5 flag (per CLAUDE.md "no AI before Phase 5").

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
