# Front Desk → Patient List

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — P1-P4/P6/P7 fixed (2026-07-09); P5 (bulk actions) pending a product decision · **Area:** Patients · **Screen 2/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `patients` (allowed).
**Frontend:** `src/app/(clinic)/patients/patients-client.tsx` (619 lines).
**Professional lens:** the patient directory is how the front desk **finds a family fast** (walk-in or phone) and answers "who is this, how do I reach them, do they owe us?". For a pediatric clinic the family contact is the **guardian**, and the child's **age** is core identity. The list is real and cleanly built — but it renders far less than the backend gives it, and its pagination silently caps at 100.

## 1. Doctype / API mapping
| Element | DocType(s) | API method | BFF route |
|---|---|---|---|
| Patient directory | Patient (+ Patient Appointment, Patient Encounter, Sales Invoice, Contact for guardian) | `patients.get_patients` / `list_patients` | `/api/patients` |
| Favorites (heart) | Patient `_liked_by` (Frappe like) | `toggle_favorite_patient` / `list_favorite_patients` | `/api/patients/favorites`, `/api/patients/[id]/favorite` |
| Register (dialog) | Patient | `patients.create_patient` | `RegisterPatientDialog` → `/api/patients` |

**Hooks:** `usePatients(apiParams)`, `usePatientFavorites`, `useToggleFavoritePatient`. **Table:** shared `DataTable` (checkbox select, sortable cols, column show/hide, paging + total) — the standard list component.

## 2. REAL vs MOCK vs MISSING (the headline)
| Element | State | Evidence |
|---|---|---|
| Patient list (rows, search, status/sex/balance filters) | 🟢 **REAL** | `usePatients` → `list_patients`; server-side search (name/MRN/mobile) + `filter_balance_due`. |
| Favorites (per-user star, server-persisted) | 🟢 **REAL** | Frappe `_liked_by` via `toggle_favorite_patient`. |
| Register patient (gated frontdesk/admin) | 🟢 **REAL** | `RegisterPatientDialog` → `create_patient`; button hidden for non-creators (avoids 403). |
| Loading / error / empty states | 🟢 **REAL** | distinct spinner / error / "no patients" vs "no results". Good. |
| **Age & guardian in the row** | 🔴 **MISSING (payload has both)** | backend returns `age`, `dob`, `guardian`; columns render neither. Pediatric-critical. |
| **Balance amount** (when balance filter on) | 🔴 **MISSING (payload capable)** | can filter to "owes money" but the list shows **no amount owed**. |
| **Next appointment** | 🔴 MISSING (payload has `nextAppointment`) | not shown; useful for "are they due in?". |
| Real server pagination | 🟠 **CAPPED** | `apiParams` hardcodes `page:1, page_size:100`; DataTable paginates *within* those 100. Patients beyond 100 never load. |
| `today` / `new` quick filters | 🟠 **CLIENT-SIDE** | filtered in JS over the loaded ≤100 rows (`p.activity?.kind`, `p.isNew`) — backend supports `filter_today`/`filter_new` but they're **not passed**. Inconsistent with `balance` (which is server-side). |
| Message count per row | 🟡 **MOCK** | hardcoded `0` (L294) — dead. |
| Row **selection checkboxes** | 🟡 **DEAD UI** | `selectedRows`/`toggleRow` tracked but **no bulk-action bar consumes them** — selecting does nothing. |

## 3. Fields — backend returns vs list renders
Backend `list_patients` returns per row: `mrn, name, first/last, sex, age, dob, status, mobile, phone, email, blood_group, image, guardian, activity, nextAppointment, lastVisit, isNew, lastEncounter`.

| Field | In payload | Shown in list? | Note |
|---|---|---|---|
| name + NEW badge + avatar | ✅ | ✅ | good |
| status (Active/Inactive/Deceased) | ✅ | ✅ | mapped Disabled→Inactive |
| mobile / phone | ✅ | ✅ | falls back phone |
| email | ✅ | ✅ | |
| MRN | ✅ | ✅ | mono |
| lastVisit.date | ✅ | ✅ | |
| **age** | ✅ | ❌ | **pediatric identity — should show** |
| **guardian** (primary contact) | ✅ | ❌ | **who the front desk actually calls** |
| **balance / outstanding** | ✅ (filter) | ❌ | filterable but amount not shown |
| nextAppointment | ✅ | ❌ | |
| sex | ✅ | ❌ (filter only) | fine as filter |
| blood_group | ✅ | ❌ | clinical; fine to omit for FD |

## 4. Actions & wiring
| Action | Wired? | Note |
|---|---|---|
| Search (debounced 300ms) | ✅ server-side | name/MRN/mobile |
| Filters: sex, status | ✅ (client over page) | sex/status filtered in JS, not passed to API |
| Filter: balance due | ✅ server-side | passed as `filter_balance_due` |
| Filters: today, new, favorites | ✅ client-side | over loaded rows only |
| Row click → Patient 360 | ✅ | `/patients/[mrn]` |
| Favorite toggle | ✅ real mutation | |
| Register patient | ✅ real | gated |
| Message icon | ❌ | hardcoded 0, no handler |
| Checkbox select | ❌ | no bulk actions |

## 5. Permissions
- Route `patients` allowed for `frontdesk`. Register gated to `frontdesk`/`admin` via `canRegister` (`rolesOverlap`) — button + empty-state CTA both hidden otherwise. **Correctly avoids the settings-audit P1 mismatch** (no create-UI for a create-denied role).
- Backend `list_patients` gates `require_permission("Patient", "read")`; `create_patient` gates create.

## 6. Alignment with core
- Reads the real `Patient` doctype; `isNew` derived from real encounter history; balance-due from real submitted Sales Invoices. Aligned.
- Favorites use Frappe's native like mechanism (not a custom table) — clean, upgrade-safe.

## 7. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **P1** | **Pagination capped at 100.** `page_size:100, page:1` hardcoded; list can't reach patient #101+. Search mitigates but filtering/browsing a clinic with >100 patients silently misses records. | Scale/correctness | High | ✅ **FIXED (2026-07-09)** — real server pagination: `patientList` accumulates across pages via a `fetchMorePatients()` Load More (mirrors the Appointments fix), backend total drives `hasMore`. |
| **P2** | **Age & guardian not shown** though both are in the payload. Pediatric front desk can't see the child's age or the parent to call, at a glance. | Missing (FD3) | High | ✅ **FIXED (2026-07-09)** — Age shown inline with patient name/identity; Guardian is its own column (desktop) / grid cell (mobile). FE-only, no backend change needed (already in payload). |
| **P3** | **Balance amount not shown.** Can filter to "balance due" but not see how much each owes. | Missing (FD3) | Med | ✅ **FIXED (2026-07-09)** — added `_batch_outstanding_balance` (sum of `outstanding_amount` across submitted invoices per patient) to `list_patients`, exposed as `balanceDue`; rendered as a Balance column/cell. |
| **P4** | **today/new/sex/status filter client-side over ≤100 rows** — inconsistent with server-side balance filter; combined with P1, results are incomplete. | Correctness | Med | ✅ **FIXED (2026-07-09)** — `search`/`gender`/`status`/`filter_today`/`filter_new`/`filter_balance_due`/`filter_favorites` all pushed server-side now; added `filter_favorites` + `sort_by`/`sort_dir` to the backend (previously only `search`/`filter_balance_due` were sent). "Deceased" status and "Other" gender remain guarded no-ops — no backend representation exists for either (see `statusApiParam`/`genderApiParam` in `patients-client.tsx`). |
| **P5** | **Selection checkboxes do nothing** — no bulk-action bar. | Dead UI | Low-Med | _pending_ — either add bulk actions (e.g. export, message) or remove the checkboxes. Decide intent. |
| **P6** | **Message count hardcoded `0`** (L294). | Mock (FD1) | Low | ✅ **FIXED (2026-07-09)** — removed the fake message icon/column entirely rather than leave a misleading always-zero count. |
| **P7** | `IS_DEV` const declared (L31) but unused; minor dead code. | Cleanup | Low | ✅ **FIXED (2026-07-09)** — removed. |
| **P8** | **Search placeholder is misleading.** Reads "Search by Patient Name" but the search is already server-side **name + MRN + mobile** (§2/§4). Front desk searches by phone/MRN constantly and won't know it works. | Copy/i18n | Low | ✅ **DECIDED (2026-07-18, FE)** — change placeholder to "Search name, MRN, or mobile" (match the Dashboard search wording) via catalog key. |
| **P9** | **MRN format inconsistent in the list** — mix of `MRN-2026-00001` (5-digit), `MRN-2026-0000006` (7-digit), and `HLC-PAT-2026-00002`. Naming-series drift (ties to `patches/.../set_patient_mrn_naming_series.py`); looks unprofessional. | Data/naming | Low | _pending_ — settle on one Patient naming series + consistent padding; existing records may need a backfill patch. BE. |

## 8. CRUD / states
- **From this screen:** Read (list) + Create (register) + favorite toggle. Update/Delete happen in Patient 360, not here (correct).
- **Empty/loading/error:** all three handled and distinct (spinner / `errorLoad` / `noPatients` vs `noResults`) — better than several settings screens. Register CTA in empty state, gated.
- **Sort:** desktop DataTable owns interactive sort; mobile default `modified desc`. Client-side over the loaded page (ties to P1).

## 9. Recommended options (curated)
Job of the directory: **find → contact → money → act.** Deepen the row, don't broaden the screen.

**Tier 1 — free (payload already has it, FE-only):**
- **Age + Guardian columns** (P2) — the child's identity and the person you call.
- **Outstanding balance** column/badge (P3) — makes the directory a collections tool.
- **Next appointment** column — `nextAppointment` already ships.
- **Row hover quick-actions** — *Book · Call/WhatsApp · Checkout* — act without a trip through Patient 360 (dialogs already exist elsewhere; wire them here).

**Tier 2 — small backend:**
- **Real pagination + total** (P1) — correctness fix, should ride along with any new columns (a richer list that still hides patient #101+ is more misleading, not less).
- **Server-side today/new/sex/status filters** (P4) — API already supports them.

**Deliberately NOT adding:**
- **Clinical columns** (allergies, blood group, conditions) — belong in Patient 360 / clinical roles; noise here.
- **Saved queries / tags / cohorts** — that's Reports/CRM, not a front-desk lookup.
- **Inline demographics edit** — editing belongs in registration / Patient 360; inline invites accidental changes.
- **Bulk actions** — only *export* or *bulk WhatsApp* make sense, and only if wanted (P5); otherwise remove the dead checkboxes.

## 10. Open questions for product owner
1. **P1:** Real pagination now, or is a 100-cap acceptable for pilot clinic size? (Affects P4 correctness too.)
2. **P2/P3:** Add Age, Guardian, and Balance columns to the default view — or make them optional via the DataTable column show/hide?
3. **P5:** Are bulk actions (export list, bulk WhatsApp) wanted, or should selection be removed?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
