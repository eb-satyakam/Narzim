# Front Desk → Dashboard (Home / Mission Control)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Home · **Screen 1/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `dashboard` (allowed).
**Frontend:** `src/app/(clinic)/dashboard/page.tsx` → `src/components/narzim/dashboard/mission-control-client.tsx` (1451 lines).
**Professional lens:** on arrival the front desk needs to answer — *How's the day shaping up? Who's here and where? Who's waited too long? What must I act on (calls, confirmations, money)?* The live queue answers #2; #1/#3/#4 are largely disabled or faked.

## 1. Doctype / API mapping
| Element | DocType(s) | API method | BFF route |
|---|---|---|---|
| Live Queue (5 rooms) + revenue + practitioner counts | Patient Appointment, Patient Encounter, Vital Signs, Sales Invoice | `dashboard.get_dashboard_data(date, practitioner)` | `/api/dashboard` |
| Stat-strip / schedule sheet (today's appts) | Patient Appointment | `appointments.get_appointments(date, practitioner)` | `/api/appointments` |
| Practitioner filter dropdown | Healthcare Practitioner | `providers.get_providers` | `/api/providers` (via `usePractitioners`) |
| Row action: Check-in/Confirm/Move | Patient Appointment | `appointments.update_status` | `/api/appointments/[id]` |
| Row action: Move to practitioner / Open encounter | Patient Encounter | `encounters.start_encounter` | `/api/encounters` |
| Row action: Record vital | Vital Signs | `vital_signs.create_vital_signs` | `/api/vital-signs` |
| Row action: Cancel | Patient Appointment | `appointments.cancel_appointment` | `DELETE /api/appointments/[id]` |
| Row action: Collect (Checkout room) | Sales Invoice / Payment Entry | via `CreateInvoiceDialogById` → billing | `/api/billing/*` |

**Hooks:** `useDashboard`, `useAppointments`, `usePractitioners`, `useUpdateAppointmentStatus`, `useCancelAppointment`, `useStartEncounter`, `useCreateVitalSigns`. Date is hardcoded to `new Date()` (today only).

## 2. REAL vs MOCK vs MISSING (the headline)
| Element | State | Evidence |
|---|---|---|
| **Live Queue — 5 rooms** (Arriving/Waiting/Nursing/Practitioner/Checkout) | 🟢 **REAL** | `LiveQueueRooms` reads `dash.*` from `get_dashboard_data`; rows + counts real. |
| Queue row **actions** (check-in, move, start encounter, vital, collect, reschedule, cancel) | 🟢 **REAL** | `handleAction` (L679–730) → real mutations, role-gated per room. |
| **Role stat strip** chips (Scheduled/Checked in/In room/Checkout/Seen/Cancelled) | 🟢 **REAL** | derived from live appts + `dash.practitioner_room`/`dash.checkout` (L209–262). |
| Practitioner multi-select filter | 🟢 REAL | `usePractitioners` (L1302). |
| Collect-payment dialog (Checkout room) | 🟢 REAL | `CreateInvoiceDialogById` (L1418). |
| **KPI cards** (In Clinic / Revenue Pending / No Shows) | 🔴 **DISABLED** | `KpiRow` commented "until real data wired" (L1384–1390). |
| **Alert strip** (critical waits, allergy flags) | 🔴 **DISABLED** | commented (L1371); `buildAlerts` unused. |
| **My Work** panel (no-shows / unconfirmed / insurance) | 🔴 **DISABLED + was MOCK** | commented (L1397–1401); `buildWorkItems` (L907–945) is hardcoded ("Rx renewal 9 days overdue", "5 appointments unconfirmed"). |
| **Daily briefing** modal | 🔴 DISABLED | commented (L1426–1437). |
| **Longest-wait** KPI | 🔴 DISABLED | commented inside KpiRow (L423–435). |
| **Today's Schedule** sheet | 🟠 **UNREACHABLE?** | `AllAppointmentsSheet` rendered (L1440) but no visible caller sets `allApptsOpen=true` — appears to have no trigger. *Verify.* |
| Wait-time per row + "overdue" cue | 🔴 **MISSING (payload has it)** | `get_dashboard_data` returns `wait_minutes`/`delayed`; row (L786–795) shows only time+id+practitioner. |
| Placeholder demographics | 🟡 **MOCK** | `apptToPatient` (L1208): `age:"—"`, `sex:"M"`, `allergies:[]`, `guardian:""`; schedule visit type via `patHash` (L1109). |

## 3. Actions & wiring — label vs effect
| Room | Action label | Actually does | OK? |
|---|---|---|---|
| Arriving Soon | **Check in** | `update_status → "Confirmed"` (L681–686) — **does NOT call `check_in_patient`, does NOT stamp `custom_checked_in_at`** | ⚠️ **FD5** label≠effect; arrival time never captured via dashboard |
| Waiting Room | Move to nurse | `update_status → "Checked-in"` (L687–692) | ✅ (but this is the status that *should* mean front-desk check-in) |
| Nursing Room | Move to practitioner | `start_encounter` (idempotent) (L695–699) | ✅ |
| Practitioner Room | Open encounter | `start_encounter` → route to `/encounters/[id]` | ✅ (nurse can open draft, not sign — ADR-022) |
| Nursing | Record vital | `create_vital_signs` → `/patients/[id]?tab=vitals` | ✅ |
| Checkout | Collect | opens real collect/invoice dialog | ✅ |
| Any | Reschedule / Cancel | `RescheduleDialog` / `cancel_appointment` | ✅ |

The `queue.comingSoon` toast fallback (L728) catches any unmapped action — all FD-relevant ones are mapped.

## 4. Permissions
- Route `dashboard` allowed for `frontdesk`; room visibility gated by `ROOM_ROLES` (L530): front desk owns **arriving_soon, waiting_room, checkout**; sees but can't act on nursing/practitioner rooms.
- Row actions filtered by `QUEUE_ACTION_CAP` × `canDoAction` (L799–805) — e.g. `collect` needs `collectpayment`, hidden if already invoiced with nothing owed.
- Backend: status transitions gated by `_ROLE_ALLOWED_STATUSES` (front desk may set Confirmed/Checked In/Checked Out/Cancelled/No Show). Aligned.

## 5. Alignment with core
- Queue placement (nursing/practitioner/checkout) is **derived server-side** from the linked Encounter docstatus + Vital Signs — sensible, real.
- **Native check-in queue NOT used:** status writes go through `update_status` (→ `frappe.db.set_value`), so core `set_position_in_queue()` never runs; the dashboard queue is a Marley construct, not core's `position_in_queue`. (Matches core-map divergence #1. The row even carries `position_in_queue` from the payload but it's not used for ordering.)

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **D1** | **Wait-time computed by backend, not shown.** `get_dashboard_data` returns real `wait_minutes`/`delayed` per row; UI renders none of it and shows no "overdue" cue. | Missing (FD3) | **High** | _pending_ — recommend: render wait + red cue on queue rows. **Frontend-only** (data already there). |
| **D2** | **No money-to-collect visibility.** Revenue-pending KPI disabled; Checkout room shows patients but not total outstanding, and per-row `outstanding_mxn` isn't surfaced. | Missing/Disabled | **High** | _pending_ — surface checkout total + per-row balance (payload has `outstanding_mxn`). FE-only. |
| **D3** | **No actionable task list.** My Work disabled (and was hardcoded): no no-shows-to-call, unconfirmed-to-remind, insurance-to-verify, follow-ups-to-book. | Disabled + Mock (FD2/FD1) | **High** | _pending_ — needs a real "front-desk work" feed (backend list + wired panel). Likely **backend hand-off** (FD-BH). |
| **D4** | **"Check in" doesn't record arrival & mislabels.** Maps to `Confirmed`, bypasses `check_in_patient`, no `custom_checked_in_at` stamp. | Data integrity (FD5) | **Med-High** | _pending_ — route dashboard check-in through `check_in_patient`; align labels. FE-only. |
| **D5** | **Placeholder demographics** (`sex:"M"`, `age:"—"`, empty allergies/guardian; fake visit type). Pediatric front desk can't see age/reason in the queue. | Mock (FD4) | Medium | _pending_ — carry real age/DOB/visit-type/guardian into queue+sheet rows (extend payload if needed). |
| **D6** | **Today-only, no look-ahead.** Hardcoded `new Date()`; can't prep/confirm tomorrow from here. | Missing | Medium | _pending_ — add date nav. FE-only (API takes `date`). |
| **D7** | **Not live.** No polling/websocket; queue updates only on the acting user's own mutations. | Missing | Medium | _pending_ — add polling or socket refresh for a shared board. |
| **D8** | **Hardcoded English** — header `title="Home"` (L1328) + stat-strip chip labels (L251–256). Bilingual violation. | i18n (FD6) | Low | _pending_ — move to catalogs. FE-only. |
| **D9** | **No per-card status chip.** Queue cards show name/time/practitioner but not the appointment/encounter state, so the friendly column label is the only status cue; it also doesn't match the raw status shown on the appointment-detail screen. | UX/consistency | Med | ✅ **DECIDED (2026-07-18, FE)** — render a status chip on **each card**, friendly column header kept. Chip text: Arriving Soon → raw status (`Open`/`Scheduled`), Waiting Room → `Confirmed`, Nursing Room → `Checked In`, Practitioner Room → `In Progress` (draft encounter), Checkout → `Completed` (submitted encounter). Chip **color reuses the column dot color**; text label always present (color-blind safe — color never the only signal). Payload already carries `status`/`custom_status`. FE-only. |
| **D10** | **"Checked In" is remapped to mean "in the Nursing Room."** ERPNext "Checked In" conventionally means *arrived at the clinic*; here it drives the Nursing column. Internally consistent but will mislead a new dev, a report, or an integration. | Semantics | Low-Med | ✅ **DECIDED (2026-07-18)** — **keep** the current "Checked In = Nursing Room" mapping. Required follow-through: a one-line code comment at the bucketing site (`api/v1/dashboard/api.py`) + a tooltip on the Nursing column, so the non-standard meaning is documented. (Distinct from D4, which is about *where arrival time is stamped*.) |
| — | **Stale code comment (not UX):** `dashboard/api.py` line ~166 says Arriving Soon is `"Open" only`, but the code (line ~361) buckets `("Open", "Scheduled")`. Fix the comment. | Doc bug | Low | _noted — backend comment fix, do alongside D10's comment work._ |

## 7. CRUD / states
- **From this screen:** read (queue/appointments) + status mutations + start-encounter + vital + collect. No create/delete of records here (booking is the global "+ New Appointment").
- **Empty:** each room shows a translated empty string; whole board hidden until `dash` loads (`{dash && …}` L1394).
- **Loading:** per-row busy scoped to the acting row (`isRowBusy`, L736) — good, no whole-board spinner.
- **Error:** action errors toast; **queue load error** path not distinct from empty (confirm — potential FD list-error-as-empty, cf. settings P11).
- **Live refresh:** manual invalidation only (D7).

## 8. Open questions for product owner
1. **D3:** Should the front-desk "work list" (no-shows to call, unconfirmed to remind, insurance to verify) be a real backend feed? If yes, it's a backend hand-off — what are the source queries?
2. **D4:** Is the dashboard "Check in" meant to be *confirm* (contacted/expected) or *arrival* (physically here)? The clinic needs a real arrival timestamp — where should it be stamped?
3. **Today's Schedule sheet (D-verify):** is it meant to be reachable (was there a header/CTA trigger removed)?

## 9. Recommended dashboard options (what to add — curated)

A front-desk dashboard earns its keep by answering four questions fast: **how's the day going · who's here and waiting · what money is open · what must I chase.** Add only what sharpens one of those. Most of Tier 1 is **already in the `get_dashboard_data` payload** and just isn't rendered — surface it before building anything new.

**Tier 1 — should have, FE-only (data already exists):**
- **Wait time + overdue flag per queue row** (`wait_minutes`/`delayed`) — the single most useful reception signal. (D1)
- **Day KPI strip** — Expected · Arrived · In room · Seen · No-show — re-enable `KpiRow` with the counts already computed. (D3)
- **Money band** — Collected today · Pending at checkout · # at checkout (`revenue` + row `outstanding_mxn`). (D2)
- **Longest-wait callout**, tap → open patient (turns wait data into one action).
- **Date nav (Today / Tomorrow)** — reception confirms tomorrow every afternoon; API already takes `date`. (D6)
- **Real quick actions** — New appointment · Register patient · Search.

**Tier 2 — high value, needs backend:**
- **Work/to-do panel** — no-shows to call · unconfirmed to remind · overdue balances arrived · follow-ups to book. Replaces the fake `buildWorkItems`; needs real queries. (D3 → FD-BH)
- **Batch "send reminders" for tomorrow's unconfirmed** — directly attacks no-show rate (ties to reminders gap G9).
- **Unread WhatsApp badge** — wire existing `notifications.get_whatsapp_conversations`.
- **Live refresh** (poll/socket) — it's a shared board. (D7)

**Deliberately NOT adding (scope discipline):**
- **Clinical widgets** (abnormal labs, unsigned notes, Rx renewals) — belong to Nurse/Doctor, not front desk. Currently in the fake `buildWorkItems`; remove, don't wire.
- **Charts / trends / analytics** — that's the Reports screen. A dashboard is for *today's action*, not BI.
- **A load-time briefing modal** — interrupts shift start; a quiet stat strip is better.

**Layout (eye path: date → day health → money → my to-do → live room):**
```
[ Today ▸ Tomorrow ]                    [ + New appt ] [ + Register ] [ Search ]
KPI:   Expected 24 · Arrived 6 · In room 3 · Seen 11 · No-show 2 · ⏱ Longest 32m
Money: Collected ₱8,400 · Pending checkout ₱4,300 (3)
── To-do (5) ─────────────── │ ── LIVE QUEUE (rows: name · age · reason · ⏱ wait) ──
```

**Bottom line:** surface what already ships (Tier 1, near-free) and add one real work feed (Tier 2 to-do). That takes the screen from "a good live queue" to "run the whole morning from here" — without turning it into a BI page.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
