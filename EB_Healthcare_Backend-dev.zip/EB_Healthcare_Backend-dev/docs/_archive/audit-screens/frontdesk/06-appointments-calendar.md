# Front Desk → Appointments Calendar

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Appointments · **Screen 6/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `appointments/calendar`.
**Frontend:** `src/app/(clinic)/appointments/calendar/calendar-client.tsx` (284 lines).
**Professional lens:** a calendar is where a front desk *sees the shape of the day/week and acts on it* — spot a gap, click to book it, drag to move a visit, click a card to open the patient. This one **renders beautifully but does nothing on click.** It's a read-only picture of the schedule (charter G4).

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Calendar events | Patient Appointment | `appointments.get_appointments(limit:200)` | `/api/appointments` |
| Practitioner legend colors | Healthcare Practitioner | `get_providers` | `/api/providers` |

**Hooks:** `useAppointments({ limit: 200 })`, `usePractitioners`. Day/Week grid, hour rows, appointments colored per practitioner with concurrent events laid side-by-side.

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Day / Week grid with real appointments | 🟢 **REAL** | `useAppointments`; cards positioned by time, colored by practitioner. |
| Concurrent-event side-by-side layout | 🟢 REAL | equal-column layout (L242–246) — nicely handled. |
| Prev/next period, Today, view-mode toggle | 🟢 REAL | `prevPeriod`/`nextPeriod`/`setViewMode`. |
| Practitioner color legend | 🟢 REAL | from `usePractitioners`. |
| Loading / error / empty states | 🟢 REAL | translated, distinct. |
| **Click a card → open appointment/patient** | 🔴 **MISSING** | card has `cursor-pointer` + `hover:opacity-90` but **no `onClick`** (L249–259) — a *misleading affordance*: looks clickable, isn't. |
| **Click empty slot → book** | 🔴 MISSING | slot cell has `hover:bg-slate-50/50` but no handler (L219–226). |
| **Drag to reschedule** | 🔴 MISSING | no drag handlers. |
| **Practitioner filter** | 🔴 MISSING | legend shows colors but can't filter to one provider (the *list* screen can). |
| Month view | 🔴 MISSING | day/week only (hour-grid). |
| Header title | 🟡 hardcoded | `AppHeader title="Calendar"` (L88); hour AM/PM labels hardcoded (L206). Rest uses `useTranslations`. |
| Fetch cap | 🟠 **CAPPED** | `limit:200` — a busy week can exceed 200 and silently drop events. |

## 3. Actions & wiring
**None.** The calendar exposes zero mutations and zero navigation from its content. Every action a front desk would want from a calendar — book, open, reschedule, filter — is absent. The only interactivity is date navigation and the day/week toggle.

## 4. Permissions
- Route allowed for `frontdesk`. No actions → no permission surface. (Backend fully supports book/reschedule/reassign for FD — the calendar just doesn't call them.)

## 5. Alignment with core
- Read-only over real Patient Appointments. No divergence — but a large **under-use of core**: every action the calendar should offer (get_available_slots, book_appointment, reschedule_appointment) exists server-side and is wired *on other screens*, just not here (core-map: "calendar under-uses core", charter G4).

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **CAL1** | **Calendar is read-only** — no click-to-book, no click-through, no drag-reschedule. The desk's most natural scheduling surface can't act. | Missing / under-use (G4) | **High** | _pending_ — phase it: (1) click card → open appointment/patient + quick actions; (2) click empty slot → book at that time; (3) drag-to-reschedule later. All backend endpoints exist. |
| **CAL2** | **Misleading affordance** — cards use `cursor-pointer`/hover but have no handler, so they *look* interactive and aren't. | UX | Med | _pending_ — either wire the click (CAL1) or remove the pointer styling until wired. |
| **CAL3** | **No practitioner filter** on the calendar (the list has one). Hard to read one provider's day in a multi-provider clinic. | Missing | Med | _pending_ — add a practitioner filter (legend → filter). |
| **CAL4** | **200-event cap.** A busy week can exceed it; events silently missing. | Scale | Med | _pending_ — fetch by the visible range (`date`/range params) instead of a flat 200. |
| **CAL5** | No month view (day/week only). | Missing | Low | _pending_ — optional; month is useful for look-ahead. |
| **CAL6** | Hardcoded "Calendar" title + AM/PM labels. | i18n (FD6) | Low | _pending_ — move to catalog. |

## 7. CRUD / states
- **From this screen:** Read only. No create/update/delete, no navigation from content.
- **States:** loading/error/empty all handled and translated — the polished part of the screen.

## 8. Recommended options (curated)
Make the calendar *do* what a calendar is for, in order of value:
- **Click a card → open the appointment/patient** with quick actions (confirm/check-in/reschedule/cancel) (CAL1 step 1) — highest value, lowest effort.
- **Click an empty slot → book** at that time/practitioner (CAL1 step 2) — turns the calendar into a booking surface (`get_available_slots` + `book_appointment` exist).
- **Practitioner filter** (CAL3) and **range-based fetch** (CAL4).
- **Drag-to-reschedule** (CAL1 step 3) — nice, do last.
- **NOT recommended:** building a second full booking dialog just for the calendar — reuse the existing `NewAppointmentDialog` pre-filled with the clicked slot. Don't duplicate booking logic.

## 9. Open questions for product owner
1. **CAL1:** How far to take calendar interactivity — read+click-through only, or full click-to-book + drag-reschedule? (Recommend at least click-through + click-to-book.)
2. **CAL5:** Is a month view wanted, or are day/week sufficient for front-desk use?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
