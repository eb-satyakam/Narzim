# Front Desk — Recommended Screen Inventory + the Sales Invoice Editor gap

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Purpose:** answers two product-owner questions — (1) *"we have no Sales Invoice screen to see tax / create an invoice / add & remove lines"* (correct — documented below), and (2) *"what screens should the frontend have?"* — the complete recommended front-desk screen set, with what exists vs. what's missing.
**Companion to:** the per-screen audits `01`–`14` and `../FRONTDESK_CHARTER_AND_GAPS.md`.

---

## Part 1 — The Sales Invoice Editor gap (confirmed, both sides)

### What exists today
| Capability | Method | What it does | Limit |
|---|---|---|---|
| Invoice from appointment | `create_appointment_invoice` | 1 line = consultation fee | single line only |
| Consolidated checkout | `create_pos_invoice(patient, lines)` | picks from **server-discovered** billables | `lines` are **references**, not arbitrary items |
| View invoice | `get_patient_invoice` | returns items **+ taxes** | **read-only** (print modal) |

### What's missing — a true **Sales Invoice Editor**
Neither frontend nor backend supports building/editing an invoice:
- ❌ **Add an arbitrary line item** (pick any Item, set qty + rate)
- ❌ **Remove / edit a line** before submit
- ❌ **Apply a tax template** (Sales Taxes and Charges Template) and **see the computed tax breakdown** while editing
- ❌ **Line-level discount** / invoice-level discount in an editor
- ❌ **Save as draft** then submit
- ❌ **Edit before submit** (correct a mistake without cancel+rebook)

**Backend gap:** `create_pos_invoice` takes billable *references* only; there is **no method that accepts arbitrary `items[] {item_code, qty, rate}` + a tax template**. Tax today comes from Item/Company defaults, never user-chosen.
**Frontend gap:** no editor screen — only fixed generators (appointment/checkout) + a read-only print modal.

### Recommendation — add a **Sales Invoice Editor** screen (new)
- **Frontend:** `/billing/invoices/new` (and `/billing/invoices/[id]/edit` while draft) — patient picker, add/remove line items (Item searchable dropdown → qty/rate), tax-template selector with live tax + grand-total breakdown, discount, Save Draft / Submit.
- **Backend hand-off (FD-BH):** a whitelisted `create_invoice(patient, items[], taxes_template?, discount?, is_pos?)` building a core Sales Invoice from arbitrary lines; keep the anti-tamper rule (rates default from Item Price, overridable only with permission). Reuse core tax calc.
- **Ties together:** charter **G6** (no ad-hoc invoice), **BI1** (no New Invoice button), **CO5/CO6** (no discount/ad-hoc line at checkout), **BK2** (no edit-appointment invoice). One editor closes all of them.

> This is the biggest *functional* billing gap after the cash drawer. The clinic can currently only bill what the system already discovered — never a certificate, a product, a manual adjustment, or a tax-inclusive custom invoice.

---

## Part 2 — Recommended front-desk screen inventory

Legend: ✅ exists & real · 🟠 partial / built-but-hidden · 🔴 missing · 🆕 recommended new

### A. Screens that should exist — status vs. audit
| # | Screen | Should exist? | Today | Key gap (see) |
|---|---|---|---|---|
| 1 | **Dashboard / Live Queue** | ✅ yes | ✅ real (queue) | KPIs/wait/to-do off (D1–D3) |
| 2 | **Patient List** | ✅ yes | ✅ real | age/guardian/balance not shown, 100 cap (P1–P3) |
| 3 | **Patient Registration** | ✅ yes | ✅ real | no guardian/address/dupe (R1–R3) |
| 4 | **Patient Chart 360** | ✅ yes | ✅ real | over-exposed + fake AI banner (C1) |
| 5 | **Appointments List** | ✅ yes | ✅ real | no confirm/check-in in list (A1) |
| 6 | **Appointments Calendar** | ✅ yes | 🟠 read-only | no book/click/drag (CAL1) |
| 7 | **Book / Reschedule / Cancel** | ✅ yes | ✅ real | insurance dead, no edit (BK1–BK2) |
| 7b | **Edit Appointment** | ✅ yes | 🔴 missing | only reschedule exists (BK2) |
| 8 | **Checkout (POS)** | ✅ yes | ✅ real | no partial/receipt, currency (CO1–CO3) |
| 9 | **Billing — Invoices** | ✅ yes | ✅ real | no New Invoice / void (BI1–BI2) |
| 9b | **Sales Invoice Editor** (create/edit + tax + add/remove lines) | ✅ yes | 🔴 **missing** | **Part 1 above** |
| 10 | **Billing — Payments** | ✅ yes | ✅ real | no day-end reconciliation (BP1) |
| 11 | **Billing — Insurance / Policies** | ✅ yes | 🟠 built-but-hidden + placeholder | unhide CRUD, fix parity (IN1–IN3) |
| 12 | **Cash Drawer / Shift** | ✅ yes | 🔴 **mock (localStorage)** | needs ADR + backend (CD1) |
| 13 | **Notifications / WhatsApp inbox** | ✅ yes | 🟠 (audit pending) | bell hidden; inbox backend exists |
| 14 | **My Work / Inbox** | ✅ yes | 🔴 (audit pending) | real work feed missing (D3) |

### B. Screens a complete front desk needs that aren't in the current set
| Screen | Why the front desk needs it | Status |
|---|---|---|
| **Sales Invoice Editor** (9b) | bill anything: certificate, product, manual/tax-inclusive invoice, correct a draft | 🆕 recommended (Part 1) |
| **Edit Appointment** (7b) | fix wrong type/notes/fee without cancel+rebook | 🆕 recommended (BK2) |
| **Day-End / Shift Reconciliation** | count drawer vs system, close the day (real, not mock) | 🆕 recommended (BP1 + CD1) |
| **Receipt / Document print** | hand family proof of payment (invoice + payment receipt) | 🆕 recommended (G7, CO3, BP3, C2) |
| **Appointment reminders / confirmations** | reduce no-shows (batch WhatsApp for tomorrow) | 🆕 recommended (G9) |
| **Refunds & Adjustments** (partial/void) | correct overcharges cleanly | 🆕 recommended (BI2/BI3, needs backend) |
| **Global Search** (patient/appt/invoice) | jump to anything fast (⌘K exists partially) | 🟠 partial |
| **Provider day view / availability** | "who's free when" for walk-ins | 🟠 (calendar under-uses this) |

### C. Explicitly NOT front-desk screens (correct to exclude)
- Clinical authoring (encounter notes, vitals entry, prescriptions, lab results) → Nurse/Doctor.
- Insurance **claims adjudication** back-office → later phase / admin (backend not built).
- Reports / analytics dashboards → Reports module (admin / `can_view_reports`).
- Settings / master data / staff admin → Healthcare Admin (settings audit).

---

## Part 3 — Priority order (money-integrity first)
1. **Cash Drawer backend (CD1)** — ADR, then real POS Opening/Closing Entry. *(highest risk)*
2. **Sales Invoice Editor (9b) + New Invoice (BI1)** — the biggest functional billing hole; unlocks tax, ad-hoc, discount, edit. *(highest functional value)*
3. **Insurance: unhide CRUD + fix parity + wire booking (IN1–IN3, BK1)** — connect what's already built.
4. **Receipts (G7)** and **day-end reconciliation (BP1)** — daily front-desk needs.
5. **Currency/i18n fixes (CO2, BP2, A4, BK5)** — correctness + bilingual rule.
6. **Dashboard surface-the-data (D1–D3), calendar interactivity (CAL1), list confirm/check-in (A1)** — mostly FE-only quick wins.

## Open questions for product owner
1. Approve the **Sales Invoice Editor** (screen 9b) + its backend `create_invoice(items[], tax_template)` method?
2. Confirm the recommended new screens (7b edit-appointment, day-end reconciliation, receipts, reminders) are in scope for the front-desk role.
3. Priority call: **Cash Drawer backend** vs **Sales Invoice Editor** first? (Both are large; the rest are mostly FE.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
