# Front Desk → Book / Edit / Reschedule / Cancel

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — **decisions locked 2026-07-18** · IN: BK2/BK4/BK6/BK7/step-labels · DEFER: BK1/BK3/BK5/BK8 (see §10) · **Area:** Appointments · **Screen 7/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`) · booking is the core of the appointments area.
**Frontend:** `new-appointment-dialog.tsx` (4-step wizard) · submitters `command-palette.tsx` + `patient-chart-client.tsx` · `reschedule-dialog.tsx` · cancel dialog (in `appointments-client.tsx`).
**Backend:** `book_appointment_for_patient` (api.py:1190) · `reschedule_appointment` · `cancel_appointment`.
**Professional lens:** booking is the front desk's highest-frequency, highest-stakes action. This flow is the **best-engineered surface in the app** — a real 4-step wizard, real slots, and a genuinely atomic book→invoice→pay transaction. Two real holes: **insurance booking is doubly broken**, and **there's no way to edit a booking** (only reschedule/cancel).

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Book (existing or new patient, atomic) | Patient Appointment (+ Patient, Sales Invoice, Payment Entry) | `book_appointment_for_patient` | `POST /api/appointments/book` |
| Available slots | Patient Appointment / schedule | `get_available_slots` | `/api/appointments/slots` |
| Reschedule | Patient Appointment | `reschedule_appointment` | `/api/appointments/[id]/reschedule` |
| Cancel | Patient Appointment | `cancel_appointment` | `DELETE /api/appointments/[id]` |
| Types / departments / practitioners / payment methods | Appointment Type, Medical Department, Healthcare Practitioner, Mode of Payment | `useAppointmentTypes`, `useAdminDepartments`, `usePractitioners`, `usePaymentMethods` | various |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| 4-step wizard (Patient → Schedule → Payment → Confirm) | 🟢 **REAL** | `NewAppointmentDialog` |
| Existing-patient search | 🟢 REAL | `usePatientSearch` |
| **New patient inline** (name/sex/dob/phone/email) | 🟢 REAL | → `new_patient` param; backend creates atomically |
| Real available slots (capacity/overlap badges) | 🟢 REAL | `useAvailableSlots` → `get_available_slots` |
| Visit type / department / practitioner | 🟢 REAL | Appointment Type, Department (show_in_portal), Practitioner filtered by dept |
| Consultation fee (prefill + override) | 🟢 REAL | from `op_consulting_charge`; editable → `paid_amount` |
| Discount (amount/%) | 🟢 REAL (pay_now only) | converted to amount client-side |
| **pay_now** (invoice + settle, atomic) | 🟢 REAL | `invoice_and_settle` in the booking savepoint |
| **pay_later** | 🟢 REAL | default; books only |
| Reschedule (real slot grid, not free-type) | 🟢 REAL | `useAvailableSlots` for new date; same practitioner |
| Cancel (reason captured) | 🟢 REAL | predefined reasons → appended to notes |
| **Insurance payment timing** | 🔴 **DISABLED + BROKEN** | option commented out (dialog:766); even if re-enabled, submitter sends only `{payment_timing:"insurance"}` (command-palette:116) — **drops policy/provider/copay**, so `insurance_policy` never reaches backend |
| **Edit appointment** (type/notes/fee/service unit) | 🔴 **MISSING** | no general edit; only reschedule (date/time) + cancel + reassign(hidden) |
| Insurance provider list | 🟡 **MOCK** | hardcoded MX insurers (dialog:810), not `list_insurance_payors` |
| New-patient duplicate guard | 🔴 MISSING | no check before create (cf. R3) |
| MRN preview | 🟡 MOCK (display) | `generateMrn()` (dialog:59) — backend assigns the real one |
| Mode of payment | 🟢 REAL (+ fallback) | `usePaymentMethods`; hardcoded fallback list (dialog:277) |
| All three dialogs' strings | 🟡 **HARDCODED ENGLISH** | booking dialog + reschedule + cancel largely not `useTranslations` |

## 3. Actions & wiring
- **Book:** `onConfirm` → `appointmentsApi.book` → `book_appointment_for_patient`. **Atomic** — single `savepoint("booking_txn")`, all-or-nothing across patient + appointment + invoice + payment. Fee override sent on all timings; discount sent **only on pay_now**; `discount_percentage` never sent (pre-converted).
- **Reschedule:** real mutation, real slot grid, same-practitioner only (practitioner read-only).
- **Cancel:** real mutation, optional reason.
- **Reassign:** built but menu item commented out (A2/G5).

## 4. Permissions
- `newAppt` capability true for FD; booking reachable from global header, ⌘K, chart, and (should be) list/calendar. Backend `book_appointment_for_patient` runs under the caller; status matrix permits FD. Aligned.

## 5. Alignment with core
- Booking composes core Patient Appointment + core invoice/payment builders; atomic wrapper is app-level. Slots come from our **port** of core availability (`get_available_slots`) — behaves like core but carries the drift risk (core-map ♻️).
- Insurance: the backend `book_appointment_for_patient` has a real `insurance` branch (and core auto-creates coverage when `show_payment_popup=0`, which is our live mode) — but the **frontend never sends the policy**, so the insured path is dead end-to-end from the UI.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **BK1** | **Insurance booking doubly broken:** timing option commented out (`new-appointment-dialog.tsx:1272`, path moved) AND submitters send bare `{payment_timing:"insurance"}` (command-palette:117, patient-chart-client:312) — drop provider/copay, and **no `insurance_policy` id is ever captured** (only a provider-name string). Verified still broken 2026-07-18. | Disabled + bug (charter G3) | **High** | ⏸ **DECIDED (2026-07-18): DEFER + GUARD.** Coupled to Insurance screens (11) + needs a real Patient Insurance Policy id — not minimum-change. Keep the option disabled; add a code comment at `:1272` so it is not re-enabled while half-wired. Fix end-to-end during the Insurance-screen pass (real `useInsurancePayors` hook now exists — wire then). |
| **BK2** | **No edit-appointment.** Wrong visit type / notes / reason / fee can't be corrected — only reschedule (date/time) or cancel+rebook. Verified 2026-07-18: only whitelisted mutations are `update_status` (status), `reschedule_appointment` (date/time), `cancel_appointment` — **no general update method exists.** | Missing | **High** | ✅ **DECIDED (2026-07-18): IN.** Add one new whitelisted `update_appointment(appointment, appointment_type?, reason_for_visit?, notes?, paid_amount?)` — writes **existing** fields only (no doctype change), **guarded to pre-invoice** (reject once `ref_sales_invoice` is set), same role/status checks as reschedule. FE: an "Edit" action alongside Reschedule/Cancel. |
| **BK3** | **Mock insurance provider list** (hardcoded MX insurers) instead of `list_insurance_payors`. | Mock (FD1) | Med | _pending_ — wire the real payor list (pairs with BK1). |
| **BK4** | **Discount only on pay_now; a pay_later booking can't carry a discount** — it's dropped. `create_invoice_from_appointment` already accepts+applies `discount_amount`/`discount_percentage`, but pay_later creates no invoice at booking. | Bug | Med | ✅ **DECIDED (2026-07-18): discount on ALL timings, carried on the Sales Invoice — no custom field.** Constraint: **no discount field added to Patient Appointment** (prefer existing fields). Design: for **pay_later**, create the Sales Invoice **at booking** (unpaid/outstanding, discount applied to the SI's **native** `discount_amount`/`additional_discount_percentage`), instead of deferring to checkout. Reuses `create_invoice_from_appointment`; discount lives on the SI where the fields already exist. **(FE)** send discount on all timings. **Tradeoff accepted:** invoice exists pre-visit → on cancel/reschedule/no-show, cancel or credit the SI (extra lifecycle logic). **Revises ADR-012** ("pay_later = no invoice") — needs a one-line superseding ADR note. |
| **BK5** | **All three dialogs hardcoded English** (booking + reschedule + cancel). Largest i18n debt in the FD surface. | i18n (FD6) | Med | _pending_ — migrate to catalogs. |
| **BK6** | **No new-patient duplicate guard** in the inline create. | Data integrity (cf. R3) | Med | _pending_ — duplicate check before booking a brand-new patient. |
| **BK7** | New-patient **email not format-validated**; fee can be 0; no `discount > fee` guard beyond clamp. | Validation | Low-Med | _pending_ — add email validation + booking-total sanity checks. |
| **BK8** | **Service unit never surfaced** (auto `serviceUnits[0]`). Fine single-unit; wrong for multi-unit clinics. | Missing | Low-Med | _pending_ — expose service-unit choice when >1. |

## 7. CRUD / states
- **From this flow:** Create (book, incl. new patient) · Update (reschedule) · Cancel. **No general Update** (BK2).
- **States:** step gating on Patient + Schedule steps; payment/confirm always valid (fee can be 0). Atomic submit with rollback — strong. Reschedule/cancel have confirm dialogs.
- **Validation:** new patient requires name + dob + valid phone; email unchecked (BK7).

## 8. Recommended options (curated)
- **Fix insurance end-to-end (BK1 + BK3)** — the single most important booking gap; today no insured family can be booked. Re-enable the timing option, forward the policy, use the real payor list.
- **Add edit-appointment (BK2)** for safe pre-invoice fields (type, notes, fee) so a mistake isn't cancel+rebook.
- **Discount on all timings (BK4)** and **duplicate guard (BK6)**.
- **i18n the three dialogs (BK5).**
- **NOT recommended:** surfacing the full backend param set (referring practitioner, video conferencing, procedure/therapy templates, inpatient) in the front-desk booking dialog — those are clinical/scheduling-admin concerns. Keep FD booking to: who · when · what type · pay how. Add service-unit only when clinics actually run multiple units.

## 9. Open questions — RESOLVED (2026-07-18)
1. ~~**BK1** insurance now or defer?~~ → **Defer + guard** (coupled to Insurance screens 11; needs a real policy id).
2. ~~**BK2** edit fields?~~ → **type, reason_for_visit, notes, paid_amount** — pre-invoice only. Practitioner change stays "reassign"; service unit deferred (BK8).
3. ~~**BK4** discount on pay_later?~~ → **Yes, on all timings**, carried on the **Sales Invoice** (invoice-at-booking, no custom field).

## 10. Build batch (2026-07-18 decisions)
**FE-only (reuse existing backend):**
- **BK6** new-patient duplicate guard — reuse `list_patients` search (same warn-and-allow as Registration R3).
- **BK7** email validation + `discount > fee` guard on booking totals.
- **Wizard step labels** — 2/3/4 → Schedule · Payment · Confirm.
- **BK4 (FE part)** — send discount on all timings.

**Backend (no core-doctype changes):**
- **BK4** — pay_later creates the Sales Invoice at booking (unpaid), discount on SI native fields; handle SI cancel/credit on cancel/reschedule/no-show. Revises ADR-012 (add superseding note).
- **BK2** — new `update_appointment(...)` whitelisted method, existing fields, pre-invoice-guarded.

**Deferred / batched:** BK1 (defer+guard → Insurance pass), BK3 (real payor list → with BK1), BK5 (i18n → app-wide batch), BK8 (service unit → multi-unit clinics only).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
