# Front-Desk Frontend Build Plan — Phase A (FE-only, no backend)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Decision (2026-07-09):** build the remaining front-desk **frontend** screens first. This plan lists only work that needs **no backend change** — the data is already in the payload or the UI is built-but-hidden. Backend-blocked items (Sales Invoice Editor, cash drawer, work-feed) are **out of this phase** — see `BACKEND_HANDOFFS.md` / `DECISION_SHEET.md`; kick those backends off in parallel.

**Rules (CLAUDE.md §13):** use the existing API as the reference — do **not** invent backend behavior; follow existing component/i18n patterns; every user-visible string goes through the message catalogs (`es-MX` + `en-US`); preserve existing flows.

**Repo:** `Healthcare_next_app` · branch: `feat/frontdesk-phase-a` (off `origin/dev`).

> ## ⚠️ Re-validation against `dev` (2026-07-09) — READ THIS FIRST
> The three role audits were run on an older branch (`feat/shared-data-table`); **`dev` has moved ahead.** Statuses below were re-verified against current `dev` code:
> - **§0 — DONE ✅** (this branch): AI risk banner + insights off for all roles.
> - **§1 — D1 + D2 DONE ✅** (this branch): wait-time on rows + money band. D4/D6/D8 still open (D4 deferred — room-model semantics decision).
> - **§2 — ALREADY DONE on `dev` ✅** (not us): **P1** real pagination (`fetchMorePatients`/`serverTotal`), **P2** age + guardian columns rendered, **P4** server-side filters (gender/status/today/new/balance/favorites) — "mirrors the Appointments fix." Only **P5** dead checkboxes / **P6-P7** cleanup remain (trivial, optional; don't touch speculatively — bulk actions may be in-flight). **Do NOT rebuild §2.**
> - **§3–§6 — ALL STILL OPEN** (verified below with file:line), except **A4 PARTIAL**. This is the real remaining Phase-A work.

---

## 0. PRE-REQ (do first, ~1hr, not front-desk-specific)
**Remove the fabricated AI/risk surfaces** — safety + "no AI before Phase 5" violation, shipping live.
- **File:** `src/lib/narzim/chart-permissions.ts` — set `showRiskBanner:false`, `showAiInsights:false` for **all** roles (frontdesk/nurse/practitioner/admin/clinic_staff).
- **Also:** `patient-screen.tsx` — ensure the `patHash` risk banner + Ask-Narzim insight pool are gated off (behind a Phase-5 flag, not rendered).
- **Accept:** no "High Readmission Risk" / AI insight renders for any role.

---

## 1. Dashboard — surface what the payload already returns
> **Status:** D1 ✅ done · D2 ✅ done (this branch) · D4 ⏸ deferred (room-model semantics — see below) · D6/D8 ⬜ open.
`src/components/narzim/dashboard/mission-control-client.tsx` + `dashboard/api.py` already returns the data.

| # | Item | Change | Data source (already present) | Accept |
|---|---|---|---|---|
| D1 | **Wait-time + overdue cue** on queue rows | render `wait_minutes` + red cue when `delayed` on each `DashboardQueueRow` | `get_dashboard_data` → row `wait_minutes`/`delayed` | a waited patient shows "32m" + red |
| D2 | **Money band** (Collected today · Pending at checkout · #) | re-enable a slim revenue strip; sum checkout `outstanding_mxn` | `dash.revenue` + checkout rows `outstanding_mxn` | band shows real ₱ totals |
| D4 | **Check-in stamps arrival** | route "Check in" action through `useCheckInPatient` (not `updateStatus→Confirmed`); relabel correctly | `check_in_patient` (exists) | check-in sets "Checked In" + `custom_checked_in_at` |
| D6 | **Date nav (Today/Tomorrow)** | add toggle; pass `date` to `useDashboard`/`useAppointments` | API already takes `date` | can view tomorrow |
| D8 | i18n header + chip labels | move `"Home"` + chip labels to catalog | — | language switch changes them |

---

## 2. Patient List — ✅ ALREADY DONE on `dev` (do NOT rebuild)
`src/app/(clinic)/patients/patients-client.tsx` (814 lines on dev; was 619 when audited).

| # | Item | Status (verified on `dev`) |
|---|---|---|
| P1 | Real pagination | ✅ **DONE** — `fetchMorePatients` + `serverTotal` + `hasMoreServer` (L208-220) |
| P2 | Age + Guardian columns | ✅ **DONE** — `p.age` (L558, L707) + `p.guardian` (L583, L715); type has both |
| P4 | Server-side filters | ✅ **DONE** — `apiParams` (L180-192) sends gender/status/today/new/balance/favorites |
| P5 | Dead selection checkboxes | ⬜ open (trivial) — **do not touch speculatively**; select-all exists (L618), bulk actions may be in-flight |
| P6/P7 | msg-count `0` / unused `IS_DEV` | ⬜ open (cosmetic) — confirm still present before removing |

---

## 3. Patient Registration — capture guardian + address
`src/components/narzim/patients/register-patient-dialog.tsx` — `create_patient` already accepts `guardians[]` + `address`.
> **Re-validated on `dev`: ALL OPEN.** R1 open (payload L156-165 has no `guardians`) · R2 open (no `address`) · R5 open (onSuccess L168-173 = toast+close only) · R6 open (genders hardcoded L259-261).

| # | Item | Change | Data source | Accept |
|---|---|---|---|---|
| R1 | **Guardian block** | add guardian fields (name, relation, mobile, is_primary) → send as `guardians` | `create_patient(guardians=…)` accepts it | new child has a primary guardian on file |
| R2 | **Address block** | add optional address fields → send as `address` | `create_patient(address=…)` | address saved |
| R5 | **Post-create actions** | on success, offer "Open chart" / "Book appointment" | existing routes/dialogs | walk-in flows into a visit |
| R6 | Genders from API | use `get_genders` instead of hardcoded 3 | endpoint exists | options from backend |

*(R3 duplicate-check is BE — defer to FD-BH-10.)*

---

## 4. Appointments List — make it self-sufficient
`src/app/(clinic)/appointments/appointments-client.tsx` — hooks exist; screen is hardcoded English.
> **Re-validated on `dev`:** A1 open (row menu L366-392 = reschedule+cancel only; `useCheckInPatient` exists but not imported) · A2 open (reassign still commented, L375-385) · A3 open (`mapApiAppt` L67-86 sets no `age`) · A4 **PARTIAL** (`useTranslations("appointmentsPage")` used for stats/toolbar L22,404; row-menu + dialog strings still hardcoded) · A5 open (no Book button).

| # | Item | Change | Data source | Accept |
|---|---|---|---|---|
| A1 | **Confirm + Check-in in row menu** | add both to `ActionMenu`; Check-in via `useCheckInPatient` (real arrival stamp) | `update_status`, `check_in_patient` | can confirm + check-in from the list |
| A2 | **Re-enable Reassign** | uncomment the menu item (L357–367); hook/dialog already exist | `reassign_appointment` | reassign works (confirm why it was disabled first) |
| A3 | **Real age** | carry `age` into `mapApiAppt` (stop hardcoding "—") | appt/patient DOB | age shows next to MRN |
| A4 | i18n | migrate the whole screen to `useTranslations` | — | bilingual |
| A5 | Inline Book CTA | add a list-level "Book appointment" button | existing dialog | book from the list |

---

## 5. Checkout & Billing — fix money display + methods
`checkout-dialog.tsx`, `billing-client.tsx`.
> **Re-validated on `dev`: ALL OPEN.** CO2 open (`fmtMoney` hardcodes `$`/es-MX/0-dp, checkout-dialog L30-31) · CO4 open (hardcoded Cash/Card, L74,78-79; no `usePaymentMethods`) · BP2 open (Payments amount col hardcodes `$`, billing-client L791,862) · BI4 open (client-side counts; `filterParams` L407-412 sends no `status`).

| # | Item | Change | Data source | Accept |
|---|---|---|---|---|
| CO2 | **Fix currency** (checkout) | replace hardcoded `$`/`es-MX`/0-decimals with `useCurrency()` + proper decimals | `useCurrency` exists | ₱/₹ correct, cents preserved |
| CO4 | **Real payment methods** (checkout) | use `usePaymentMethods` (not hardcoded Cash/Card/Transfer) | `get_payment_methods` | methods from ERPNext |
| BP2 | **Fix currency** (payments tab) | same `useCurrency` fix | — | correct symbol |
| BI4 | Server-side status counts | pass `status` to `list_all_invoices` for accurate tab counts | endpoint supports it | counts correct at scale |

---

## 6. Insurance & Notifications — unhide what's built
> **Re-validated on `dev`: ALL OPEN.** IN1 open (insurance sub-tab commented in `patient-screen.tsx` L89-90, render L710-711) · IN2 open (`InsuranceTab()` placeholder, billing-client L373-381) · N1 open (bell/panel gated `{false && …}`, app-sidebar L505-506) · N3 open (no Messages entry in `buildNav`, L314-355).
| # | Item | Change | Data source | Accept |
|---|---|---|---|---|
| IN1 | **Unhide insurance CRUD** | re-enable the patient-chart insurance sub-tab (already wired to `save/delete/list` + payors) | endpoints exist | can record/edit a policy |
| IN3 | Remove unsupported inputs | drop copay/deductible/group/holder fields the backend doesn't persist (or leave until BE adds them) | — | no silently-dropped fields |
| IN2 | Route hub Insurance tab → CRUD | replace the placeholder with a link/embed of the real policy UI | — | no dead "coming soon" tab |
| N1 | **Unhide notifications** | remove `{false &&}` guard on the bell/panel (`app-sidebar.tsx:506`) | `list_notifications` etc. wired | bell shows unread + panel works |
| N3 | Messages nav entry | add a "Messages" sidebar item for WhatsApp-capable roles | inbox exists | discoverable, not widget-only |
| N6 | Notif panel i18n | move panel strings to catalog | — | bilingual |

---

## Remaining execution order (after re-validation)
- ~~§0 fake-AI removal~~ ✅ done · ~~§1 D1/D2~~ ✅ done · ~~§2 Patient List~~ ✅ already on dev.
1. **§4 Appointments** — A1 (confirm/check-in in row menu), A2 (re-enable reassign), A3 (real age), A4 (finish i18n of menu/dialogs), A5 (Book button)
2. **§3 Registration** — R1 guardian, R2 address, R5 post-create actions, R6 genders-from-API
3. **§5 Checkout/Billing** — CO2 currency, CO4 real methods, BP2 currency, BI4 server counts
4. **§6 Insurance/Notifications** — IN1 unhide insurance CRUD, IN2 replace placeholder, N1 unhide notifications, N3 Messages nav
5. **§1 leftovers** — D4 (after room-model decision), D6 date nav, D8 chip i18n
6. **§2 leftovers** — P5/P6/P7 cleanup (only if confirmed dead)

**One decision blocks nothing here except D4** (dashboard "check in" semantics). Everything in §3–§6 is unambiguous and buildable now.

## Explicitly OUT of Phase A (backend-blocked — parallel track)
- Sales Invoice Editor (create-with-tax/add-remove lines) → FD-BH-2
- Cash drawer / shift → ADR-023 + FD-BH-1
- Front-desk work-feed → FD-BH-4
- Receipts → FD-BH-8 · void/partial → FD-BH-3 · duplicate check → FD-BH-10 · reminders → FD-BH-5 · insurance booking wiring → FD-BH-6

## Definition of done (each item)
Real data (no `patHash`/hardcode) · strings in catalogs (`es-MX`+`en-US`) · existing component patterns · loading/empty/error states preserved · `tsc` clean · no backend change.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
