# Front Desk → Login

**Doc status:** record · **Created:** 2026-09-03 by Invincible · **Updated:** 2026-09-03 by Invincible · **Version:** 1.0

**Status:** ✅ audited — L1–L5 logged, decisions below · **Area:** Auth · **Screen 0/14** · [index](README.md)
**Role:** unauthenticated (all roles enter here) · route `(auth)/login`.
**Frontend:** `src/app/(auth)/login/page.tsx` → BFF `POST /api/auth/login` → `eb_frappe_jwt.api.get_token` (ADR-011 Bearer JWT; browser never holds the token).
**Professional lens:** the first screen every clinic user sees. It must be fast, honest, and accessible under clinic lighting — and it must not make claims the product can't back. Visual craft is good (split layout, teal brand, password show/hide, language switcher, forgot-password). The problems are two false trust claims and one parked feature.

## 1. Doctype / API mapping
| Element | DocType(s) | API method | BFF route |
|---|---|---|---|
| Email + password login | User / (eb_frappe_jwt) | `eb_frappe_jwt.api.get_token` | `POST /api/auth/login` |
| Forgot password | User | `forgot-password` flow | `/api/auth/forgot-password` |
| Language switcher (EN/ES) | — (next-intl) | client-side locale | — |

## 2. REAL vs MOCK vs MISSING (the headline)
| Element | State | Evidence |
|---|---|---|
| Email/password login → JWT | 🟢 **REAL** | BFF `/api/auth/login` → `get_token`; verified end-to-end (ADR-011). |
| Password show/hide, forgot-password, language switch | 🟢 **REAL** | present and wired. |
| **"AI-Enabled" trust badge** | 🔴 **FALSE CLAIM** | AI is Phase 5 — not built (CLAUDE.md). Advertises a capability that does not exist. Same class as chart C1 (fabricated AI on a live screen). |
| **"HIPAA Ready" trust badge** | 🔴 **FALSE / WRONG-JURISDICTION CLAIM** | Locked jurisdiction is India + Mexico (LFPDPPP / NOM-024-SSA3-2010; DPDPA 2023 / ABDM). HIPAA is US; US is deferred (ADR-018/ADR-007). A public regulatory claim the product does not meet. |
| Trust-badge legibility | 🟠 **A11y** | light-gray text over photo, below WCAG AA — the security signals are the least readable element. |
| **PIN quick-login** (`(auth)/pin`) | 🔴 **NON-FUNCTIONAL STUB** | keypad calls `/api/auth/verify-pin`, which **does not exist**; no PIN anywhere in backend (no `User` field, none in eb_frappe_jwt, no `tabUser` column — verified live). Staff identity kept in client `sessionStorage`. Ported from `lib/narzim/data.ts` mock. |
| Stray empty `<input type="text">` before email | 🟢 **cleanup** | nameless input; confuses screen readers / password managers — confirm intentional (autofill/honeypot) or remove. |
| Tenant branding ("Narzim" logo) | 🟡 **verify** | confirm dynamic per tenant (white-label) vs hardcoded. |

## 3. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **L1** | "AI-Enabled" badge on the login page. **Corrected 2026-09-03:** the original reason given here — "AI is Phase 5" — was wrong; CLAUDE.md's 2026-08-13 amendment records AI as in production (18 doctypes, 63 whitelisted methods, live Copilot), so the capability claim was accurate. The badge still does not belong on a login page: it advertises an internal build phase to whoever is signing in, and sits beside L2. | False claim | **High** | ✅ **DO (FE) — remove now.** Add back only when AI ships. |
| **L2** | "HIPAA Ready" badge — false / wrong-jurisdiction regulatory claim. | Legal/compliance | **High** | ✅ **DO (FE) — remove now.** Replace with a true label per deployment (NOM-024 / LFPDPPP / DPDPA) or drop. |
| **L3** | Trust-badge contrast below WCAG AA. | A11y | Med | ✅ **DO (FE)** — solid chip background / darkened gradient behind remaining badges. |
| **L4** | PIN screen is a non-functional stub; no backend PIN exists. | Missing/Mock | Med | ⏸ **PARKED** — net-new backend, not a minimum change. When built: hashed `pin_hash` (+`pin_set_on`) **custom field on User** (approved integration point), rate-limited, never plaintext. Clarify first: primary auth vs shared-terminal quick-unlock on top of a real JWT session. |
| **L5** | Stray nameless text input + confirm tenant-dynamic logo. | Cleanup/verify | Low | _pending_ — confirm/remove input; confirm logo is per-tenant. |

## 4. Deliberately NOT adding (scope discipline)
- **SSO / signup / social login** — a clinical login stays minimal and fast. ⚪️
- Optional FE-only nicety (not required): pre-fill last email via localStorage for shared terminals.

## 5. Cross-screen link
- L1/L2 are the login instance of theme **"fabricated / false claims on live screens"** (cf. chart **C1/C5**). Batch with the Week-1 "remove fake AI" FE pass.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Invincible | Initial version (header backfilled from git history) |
