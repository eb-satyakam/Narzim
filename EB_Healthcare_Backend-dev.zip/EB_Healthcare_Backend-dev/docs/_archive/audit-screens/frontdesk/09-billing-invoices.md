# Front Desk → Billing (Invoices tab)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-08-14 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ **re-verified post-pull 2026-07-18** — BI1 resolved, BI4 mitigated; BI5/BI7 decided; BI2/BI3 deferred (backend) · **Area:** Money · **Screen 9/14** · [index](README.md)

> **Build batch (2026-07-18):** BI7 per-row View/Print → existing `InvoicePrintModal` (FE) · BI5 refund reason → credit-note `remarks` (small BE param) · BI8 tooltip/overdue styling (FE). **Deferred:** BI2 void, BI3 partial refund (backend hand-offs).
**Role:** `EB_Front Desk` (frontend `frontdesk`) · route `billing` (allowed).
**Frontend:** `src/app/(clinic)/billing/billing-client.tsx` (824 lines) — one file, three tabs: **Invoices** (this screen), Payments (screen 10), Insurance (screen 11).
**Professional lens:** the billing hub is where the front desk answers "what have we invoiced, who owes us, how much did we collect?" and acts (collect, refund). The Invoices tab is a **mature, carefully-accounted screen** — real data, honest cap notice, correct refund handling. Its gaps are structural: **no way to create an invoice here, and refund is full-only (no void, no partial).**

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Clinic-wide invoice list (+ returns) | Sales Invoice | `billing.list_all_invoices` | `/api/billing` via `useInvoices` |
| Collect payment | Payment Entry | `billing.collect_payment` | `/api/billing/collect` via `useCollectPayment` (in `CollectButton`; the same compact dialog was extracted 2026-08-14 as `components/billing/collect-payment-dialog.tsx` so Patient Chart's Billing tab and Timeline rows can trigger it externally — see [04-patient-chart.md](04-patient-chart.md)) |
| Refund (credit note) | Sales Invoice (`is_return`) | `billing.create_credit_note` | `/api/billing/refund` via `useCreateCreditNote` (in `RefundButton`) |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Clinic-wide invoice list | 🟢 **REAL** | `useInvoices({page_size:100, include_returns:true})` |
| KPIs — Collected / Outstanding | 🟢 **REAL + careful** | refunded originals + credit notes excluded so totals reflect money *kept* (L419–424) |
| Status tabs (All / Pending / Paid / Refunded) with counts | 🟢 REAL | client-side grouping over fetched set |
| Search + date range | 🟢 REAL | server-side (`search`/`date_from`/`date_to`) |
| **Collect payment** (per row) | 🟢 REAL | `CollectButton` → `useCollectPayment`; gated `balance>0 && !return && !Draft/Cancelled` |
| **Refund / credit note** | 🟢 REAL | `RefundButton` → `useCreateCreditNote`; gated `Paid && !return` |
| CSV export | 🟢 REAL | client-side blob |
| **Capped notice** ("showing latest X of Y") | 🟢 **REAL** | `invCapped` rendered (L683–685) — *honest about the 100 cap, unlike patient list* |
| i18n + currency | 🟢 REAL | `useTranslations` + `useCurrency` (unlike checkout CO2) |
| Refund status handling (returns vs "Credit Note Issued") | 🟢 REAL | sophisticated status recompute (L456–470) |
| **"New Invoice" button** | 🔴 **MISSING** | no create entry point on the hub (charter G6); invoices only from appointment/checkout |
| **Void / cancel invoice** | 🔴 MISSING | only refund; backend has no void either (B3) |
| **Partial / line refund** | 🔴 MISSING | credit note is full-invoice only (B4); refund gated to fully-paid |
| Status grouping completeness | 🟠 client-side over 100 | All/Pending/Paid/Refunded counts reflect the loaded page (cap surfaced, though) |

## 3. Actions & wiring
| Action | Wired? | Gating |
|---|---|---|
| Collect payment | ✅ real | `balance>0`, not return, not Draft/Cancelled |
| Refund (credit note) | ✅ real | `Paid` and not a return |
| CSV export | ✅ real | current filtered rows |
| Filter by status / search / date | ✅ real | search+date server-side; status client-side |
| **Create invoice** | ❌ | no button (G6) |
| **Void invoice** | ❌ | not supported anywhere |

## 4. Permissions
- Route `billing` allowed for `frontdesk`; `invoices`/`collectPayment` capabilities true. Backend `list_all_invoices`/`collect_payment`/`create_credit_note` explicitly allow `EB_Front Desk` (and block `EB_Practitioner` by design). Aligned.

## 5. Alignment with core
- Reads core Sales Invoice; collect via core Payment Entry; refund via core `make_return_doc`. The KPI accounting (excluding reversed originals) mirrors core's net-receipts reality. Strong alignment.
- **Full-refund-only** and **no void** are inherited from the backend (B3/B4) — the UI faithfully reflects what core-via-our-API allows; the gap is real but not a frontend fabrication.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **BI1** | **No "New Invoice" on the hub.** Ad-hoc/miscellaneous invoices can't be raised outside appointment/checkout. | Missing (G6) | **Med-High** | **Decided (2026-08-14)** — the New Sales Invoice drawer (`new-invoice-sheet.tsx`, `create_sales_invoice`) becomes the single entry point for creating an invoice AND collecting on an existing one, reachable from this hub, Patient Chart, and the Dashboard. Replaces `checkout-dialog.tsx`, `collect-invoice-payment-dialog.tsx`, and `create-invoice-dialog.tsx` (repointed, not duplicated); `collect-payment-dialog.tsx` is deleted outright as a drifted duplicate with a live id-confusion bug. |
| **BI2** | **No void/cancel of a submitted invoice.** A mistaken invoice can only be reversed by a full credit note, and only once fully paid. No `void` method exists in the backend (verified 2026-07-18). | Missing (B3) | **Med-High** | ⏸ **DEFERRED (2026-07-18)** — keep **full credit note** as the correction path (a legitimate model). Void is a real backend build; revisit only if a clinic needs pre-payment cancel. |
| **BI3** | **Refund is full-invoice only** (`create_credit_note(invoice, mode_of_payment)` — no line/amount param); refund gated to fully-paid invoices. | Missing (B4) | Med | ⏸ **DEFERRED (2026-07-18)** — backend hand-off; revisit if overcharge correction is needed. |
| **BI4** | **Status grouping is client-side over the loaded page.** | Correctness | Med | 🟡 **MITIGATED (post-pull)** — page size now selectable to 2500; counts accurate within the loaded set. Server-side counts still ideal at extreme scale — low priority. |
| **BI5** | Refund captures **no reason/audit note** (Refund dialog is a bare confirm; `create_credit_note` takes no reason). | Audit | Low-Med | ✅ **DECIDED (2026-07-18): capture a reason.** Add an optional reason field; pass it into the credit note's **`remarks`** (small `create_credit_note` param — existing SI field, no doctype change). |
| **BI6** | **Collecting on a new invoice is full-or-nothing.** `create_sales_invoice`'s Collect Now step always settled the entire grand total (or none) — no way to collect a deposit/partial amount at invoice-creation time, unlike `create_pos_invoice`/`create_vaccination_invoice`/`create_ad_hoc_invoice`, which already support `min(paid_amount, outstanding)`. Not previously tracked here since no one had proposed partial payment before. | Missing | Med-High | **Decided (2026-08-14)** — `create_sales_invoice` settles `min(paid_amount, outstanding_amount)` like its siblings; the drawer gains an editable "Amount to collect" field (defaults to full total, editable down to any amount). |
| **BI7** | 🆕 **No per-row view/print of an existing invoice.** Only action is Refund; front desk can't reprint a past invoice/receipt from the hub. (Live-verified 2026-07-18.) | Missing | **Med** | ✅ **DECIDED (2026-07-18): add a per-row View/Print** wired to the existing `InvoicePrintModal` (same modal as CO3/C2). FE-only. |
| **BI8** | 🆕 **Minor:** Refund-disabled state has no tooltip; a past-due Unpaid invoice still shows "Unpaid", not "Overdue". | UX | Low | _batch_ — add a disabled-reason tooltip; surface Overdue styling. FE. |

## 7. CRUD / states
- **From this screen:** Read (list) + collect payment + refund + export. **No create, no void** (BI1/BI2).
- **States:** loading handled; **capped notice** shown when total exceeds the page — a good pattern the other list screens should copy. i18n + currency correct.

## 8. Recommended options (curated)
- ~~**New Invoice on the hub (BI1)**~~ — **decided**, see BI1/BI6 above.
- **Void invoice (BI2)** — the safe correction for a mistake before payment; needs a backend decision (void vs credit note).
- **Server-side status counts (BI4)** so the tab counts are trustworthy at scale.
- **Refund reason (BI5)** for audit.
- **NOT recommended:** letting front desk edit a submitted invoice's line items/amounts — that's what void + reissue is for; editable posted invoices break the audit trail. Keep corrections to void/credit-note.

## 9. Open questions for product owner
1. ~~**BI1:** Add ad-hoc "New Invoice" to the billing hub?~~ **Answered 2026-08-14** — yes, via the consolidated New Sales Invoice drawer (BI1/BI6); it bills from the real unbilled-services cart (`get_patient_billables`), not a curated list.
2. **BI2/BI3:** Void policy — do we add invoice void and/or partial refund, or is full-credit-note the deliberate correction path? (Backend hand-off either way.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
