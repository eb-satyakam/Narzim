# Front Desk → Notifications + WhatsApp Messages

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Comms · **Screen 13/14** · [index](README.md)
**Role:** `EB_Front Desk` (frontend `frontdesk`).
**Frontend:** notifications bell/panel in `app-sidebar.tsx`; WhatsApp `/messages` (`messages-client.tsx` + `conversation-*`), plus the global floating `ChatWidget`.
**Professional lens:** comms is how the desk keeps families informed and fields their replies. The **backends are fully real** — but the notifications UI is **dead-coded off**, and the WhatsApp inbox has **no sidebar entry** (reachable only via a floating widget or direct URL). Working plumbing, hidden taps.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Notifications list / unread / mark read | Notification Log | `list_notifications`, `get_unread_count`, `mark_read`, `mark_all_read` | `/api/notifications` |
| WhatsApp conversations / thread | (WhatsApp message log) | `get_whatsapp_conversations`, `get_whatsapp_conversation` | `/api/whatsapp/conversations[/id]` |
| Reply / template / start / media / close / assign | — | `send_whatsapp_reply`, `send_whatsapp_template`, `start_whatsapp_conversation`, `send_whatsapp_media`, `close_whatsapp_conversation`, `assign_whatsapp_conversation` | `/api/whatsapp/*` |

## 2. REAL vs MOCK vs MISSING
### A. Notifications (bell/panel)
| Element | State | Evidence |
|---|---|---|
| Data layer (list/unread/mark) | 🟢 **REAL** | `useNotifications(20)`, `useUnreadCount`, `useMarkRead`, `useMarkAllRead` → all 4 backend methods |
| **Bell + panel UI** | 🔴 **HIDDEN** | wrapped in `{false && (...)}` (`app-sidebar.tsx:506`, "hidden in UI for now, keep logic intact") — never renders |
| Dedicated `/notifications` page | 🔴 **MISSING** | panel footer links to `/notifications` (L600) but no such route exists; only a `status:"planned"` tile |
| Nav visibility | 🔴 none | not in `buildNav` |
| i18n | 🟡 hardcoded EN | panel strings literal (L527–604) |

### B. WhatsApp Messages (`/messages` + ChatWidget)
| Feature | State | Hook → backend |
|---|---|---|
| Conversation list (polls 15s) | 🟢 REAL | `useWaConversations` → `get_whatsapp_conversations` |
| Thread (polls 10s) | 🟢 REAL | `useWaThread` → `get_whatsapp_conversation` |
| Send reply (24h window gated) | 🟢 REAL | `useWaReply` → `send_whatsapp_reply` |
| Send template (any time) | 🟢 REAL | `useWaSendTemplate` → `send_whatsapp_template` |
| Start conversation | 🟢 REAL | `useWaStartConversation` → `start_whatsapp_conversation` |
| Media send / view (SSRF-guarded) | 🟢 REAL | `useWaSendMedia` → `send_whatsapp_media` |
| Close / assign | 🟢 REAL | `useWaClose` / `useWaAssign` |
| i18n | 🟢 REAL | `useTranslations("clinic.messages")` (tiny literal exceptions) |
| **Sidebar nav entry** | 🔴 MISSING | no "Messages" in `buildNav`; only a `planned` tile |
| **Route gate** | 🟠 none | `/messages` not in `route-access.ts` → open to any authenticated user |
| **Actual FD access** | 🟠 via floating `ChatWidget` | global widget (Threads = WhatsApp, Team = internal chat); non-WhatsApp roles get a silent-empty list |
| Mock data / patHash | 🟢 none | fully real, session-window gating real |

## 3. Actions & wiring
- **Notifications:** all actions real but unreachable (hidden).
- **WhatsApp:** full messaging lifecycle real and reachable (widget/URL) — the most complete comms surface. No automated/scheduled **appointment reminders** though (only manual templates) — charter G9.
- **Team chat** (`/api/messages/*`, `messages.api`) is a separate, also-real internal chat (ChatWidget "Team" tab).

## 4. Permissions
- WhatsApp/notifications backends allow staff; front desk gets the real inbox via the widget. No hard route gate on `/messages` (open to authenticated) — cosmetic, backend governs data.

## 5. Alignment with core
- Notification Log + WhatsApp messaging are app/integration features (frappe_whatsapp) — real. **Missing:** the native **appointment reminder scheduler** (`send_appointment_reminder`, sets `reminded`) is not configured — reminders are all manual (core-map, G9).

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **N1** | **Notifications UI dead-coded off** (`false &&`) despite a fully working backend + hooks. Front desk sees notifications nowhere. | Built-but-hidden (FD2) | **Med-High** | _pending_ — unhide the bell/panel (or build `/notifications`); confirm why disabled. |
| **N2** | **No `/notifications` page** though the panel links to it. | Missing | Med | _pending_ — add the page or repoint the link. |
| **N3** | **WhatsApp inbox has no sidebar nav** — discoverable only via floating widget / direct URL. | Discoverability | Med | _pending_ — add a "Messages" nav item for roles with WhatsApp access. |
| **N4** | **No automated appointment reminders/confirmations** — only manual templates. | Missing (G9) | Med | _pending_ — configure the native reminder scheduler + a batch "remind tomorrow's unconfirmed" action (ties dashboard D3). |
| **N5** | `/messages` not in `route-access.ts` (open to any authenticated user). | Access hygiene | Low | _pending_ — add explicit role gate. |
| **N6** | Notification panel hardcoded English. | i18n (FD6) | Low | _pending_ — catalogs. |

## 7. Recommended options (curated)
- **Unhide notifications (N1)** + add the page (N2) — the backend is done; this is pure UI enablement.
- **Give WhatsApp a nav entry (N3)** so families' replies are visible, not buried in a widget.
- **Automated reminders (N4)** — the highest-value comms addition for reducing no-shows.
- **NOT recommended:** building a new messaging system — both WhatsApp and team chat already exist and are real; connect and surface them, don't rebuild.

## 8. Open questions for product owner
1. **N1/N3:** Unhide notifications and add a Messages nav entry — confirm, and why they were hidden.
2. **N4:** Turn on automated appointment reminders/confirmations (scheduler + batch action)? This is the main no-show lever.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
