# Practitioner → Prescriptions / Medications

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 4/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` (+ admin) · route `/medications` (physician-exclusive) + `/prescriptions` + chart Medications tab.
**Frontend:** `medications-client.tsx`, `prescriptions/page.tsx`, `medications-tab.tsx`.
**Backend:** `api/v1/prescriptions/api.py` (list_medications, list_patient_prescriptions, get_item_preview) + drug orders via the encounter.
**Professional lens:** prescribing is one of the physician's two unique powers. The clinically-real path (prescribe inside the signed encounter → Medication Request) works. But the **two standalone medication screens are fake/empty** — the doctor's dedicated drug surfaces don't use the real backend.

## 1. Doctype / API mapping
| Element | DocType | API method | State |
|---|---|---|---|
| Prescribe (in encounter) | Patient Encounter `drug_prescription` → Medication Request (on sign) | `save_draft` + `complete_encounter` | 🟢 real |
| Patient's med list (chart tab) | Medication Request / drug prescriptions | `get_patient_medications` / `update_medication_status` | 🟢 real |
| Medication master/formulary | Medication (Item) | `list_medications` | 🟡 exists, **not used by the screen** |
| Drug item preview | Item | `get_item_preview` | exists |

## 2. REAL vs MOCK vs MISSING
| Surface | State | Evidence |
|---|---|---|
| **Prescribe inside encounter** | 🟢 **REAL** | drug lines → `drug_prescription` → **Medication Request spawns on sign** (screen 03) |
| **Chart Medications tab** (view meds, stop/resume) | 🟢 **REAL** | `usePatientMedications` + `useUpdateMedicationStatus` → `update_medication_status` |
| **`/medications` screen** (physician-only route) | 🔴 **FULLY MOCK** | `medications-client.tsx` uses `MEDICINE_MASTER` (hardcoded array, L306) — **0 API calls** (`grep apiFetch/api` = 0); ignores the real `list_medications` |
| **`/prescriptions` screen** | 🔴 **PLACEHOLDER** | static "Prescription management is coming in a future release" (prescriptions/page.tsx) |
| Weight-based dosing (pediatric) | 🔴 MISSING | no weight-based dose calc despite pediatric scope (ROADMAP screen 11) |
| Drug interaction / allergy check | 🔴 MISSING | no safety validators at prescribe time (Phase-5 per CLAUDE.md, but note the gap) |
| Formulary search at prescribe | 🟠 verify | confirm the encounter Rx picker uses real `list_medications` vs a local list |

## 3. The split — what's real vs fake
- **Clinically real:** the *actual prescribing* (encounter drug line → Medication Request on sign) and the *patient med list* (chart tab) are wired to the backend. A prescription written and signed **does** become a real order and shows on the chart. Good.
- **Fake/empty:** the two *dedicated medication screens* — `/medications` (a mock formulary/reference from `MEDICINE_MASTER`) and `/prescriptions` (coming-soon). So the physician's standalone "manage medications / see all my prescriptions" surfaces don't work; prescribing only happens *inside an encounter*.
- **Consequence:** there is **no standalone prescribe** (e.g. a phone refill without an encounter) and **no real drug reference** — the `/medications` route a doctor would open shows fabricated data.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **PM1 (PR2)** | **`/medications` is fully mock** (`MEDICINE_MASTER`, 0 API calls) — physician-only route shows a fabricated formulary | Mock (FD1) | **High** | _pending_ — wire to real `list_medications`, or remove the route until built. A fake drug reference is dangerous. |
| **PM2 (PR3)** | **`/prescriptions` is a coming-soon placeholder** — no standalone prescription management / refill | Missing | **Med-High** | _pending_ — decide: build standalone Rx management (list patient prescriptions via `list_patient_prescriptions`, refills) or remove the nav until ready. |
| PM3 | **No pediatric weight-based dosing** | Clinical (pediatric) | Med | _pending_ — the flagship pediatric feature (ROADMAP 11); backend hand-off (dose calc from latest weight). |
| PM4 | **No drug-interaction / allergy check at prescribe** | Clinical safety | Med (Phase 5) | _pending_ — safety validators are Phase-5 per CLAUDE.md; note the gap, don't build early. But a basic *allergy* cross-check (non-AI) is worth considering now. |
| PM5 | Confirm the encounter Rx picker uses real `list_medications` (not another local list) | Integrity | Med | _pending_ — verify the drug search inside the encounter is backend-backed. |

## 5. Alignment with core
- Prescribing composes core: `drug_prescription` → Medication Request (order layer) on encounter submit (ADR-019). Med list reads real prescriptions. Aligned where it's real.
- The mock `/medications` screen is *beside* the backend — `list_medications` exists and is ignored. The fix is to use what's already there.

## 6. Recommended options (curated)
- **PM1 first:** wire `/medications` to `list_medications` (real formulary) or pull the route. A physician opening a fake drug list is a safety/trust problem.
- **PM5:** confirm/ensure the in-encounter Rx picker is backend-backed (this is the path that actually matters).
- **PM3 weight-based dosing:** the real pediatric differentiator — worth prioritizing for this product.
- **NOT recommended:** building AI drug-interaction checks before Phase 5 (per CLAUDE.md) — but a deterministic allergy cross-check is fair game now (PM4).

## 7. Open questions for product owner
1. **PM1:** Wire `/medications` to the real formulary, or remove the route until it's built? (It's mock today.)
2. **PM2:** Is standalone prescription management / refill-without-encounter in scope, or is prescribing intentionally encounter-only?
3. **PM3:** Prioritize pediatric weight-based dosing now? (Flagship feature, needs a dose-calc backend.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
