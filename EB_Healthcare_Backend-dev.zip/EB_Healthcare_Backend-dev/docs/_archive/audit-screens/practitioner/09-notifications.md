# Practitioner → Notifications / Messages

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Comms · **Screen 9/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner`. Shared comms surface; carries the shared N-series gaps.

## 1. REAL vs MOCK vs MISSING
| Element | State | Note |
|---|---|---|
| Notifications data layer | 🟢 REAL | shared backend |
| **Notifications bell/panel** | 🔴 HIDDEN (`false &&`) | shared N1 — doctor gets no in-app alerts (abnormal result ready, encounter to sign) |
| Team chat (ChatWidget) | 🟢 REAL | internal staff chat — the doctor's real comms lane |
| WhatsApp patient inbox | 🟠 role-degraded | patient messaging is front-desk-owned; may empty for the doctor |
| Messages sidebar nav | 🔴 MISSING (shared N3) | |

## 2. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| PN1 (N1) | **Notifications hidden** — doctor gets no alert for abnormal result / note-to-sign / consult reply | Med-High | _pending_ — unhide; physician-relevant events should notify (pairs with clinical inbox PW1). |
| PN2 | Team chat is the doctor's real lane; WhatsApp is patient-facing | — | _pending_ — confirm; ensure Team chat discoverable. |

## 3. Recommended
- **Unhide notifications (PN1)** — a doctor should be pinged when an abnormal result is ready or a note needs signing. Backend real, UI off.
- **NOT recommended:** default patient WhatsApp inbox for the doctor — patient messaging is front-desk's; Team chat + notifications are the physician's channels.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
