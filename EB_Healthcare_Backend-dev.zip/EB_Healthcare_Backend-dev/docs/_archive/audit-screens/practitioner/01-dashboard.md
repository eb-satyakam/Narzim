# Practitioner → Dashboard ("what I see first")

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Home · **Screen 1/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `dashboard` (shared `mission-control-client.tsx`, practitioner subset).
**Professional lens:** a doctor opening the app asks one thing — *"Who is in front of me, and what must I know to treat them safely, now?"* Not the clinic's whole day (front desk), not queue mechanics (nurse). The physician dashboard should collapse to **the next ready patient + their real clinical context + what's waiting on my signature.**

## 1. What a doctor should see first (clinical priority)
1. **My patients, ready now** — the ones the nurse prepped + marked ready / in my room. One tap → open encounter. *(This is the doctor's real worklist, not all appointments.)*
2. **Safety flags on the ready patient — before I enter the room** — allergies, active problems, current meds, abnormal vitals just recorded. **Must be REAL** (a fake allergy / mis-bound vital is worse than none).
3. **My clinical inbox — what's waiting on my decision** — unsigned encounters, **abnormal labs awaiting my finalize/review**, refills, follow-ups I owe. The un-actioned result is the doctor's biggest liability.
4. **My panel / follow-ups** — longitudinal care (chronic, post-op checks due). Secondary.

**A doctor does NOT want first:** revenue/money view, room-transfer mechanics, whole-clinic schedule, ops KPIs.

## 2. What ships today vs that need
| Need | State | Evidence |
|---|---|---|
| Practitioner-room queue (who to see) | 🟢 REAL | `mission-control-client` practitioner room; "open encounter" → draft/sign |
| One-tap into the encounter | 🟢 REAL | `start_encounter` → `/encounters/[id]` |
| **Safety flags before the room** | 🔴 **FABRICATED (PR1)** | overview `showRiskBanner:true`/`showAiInsights:true` → `patHash` mock "High Readmission Risk" shown to the doctor; real allergy alert rides alongside fake data |
| **Clinical inbox** (unsigned notes / abnormal results / refills) | 🔴 **MISSING** | no physician work-feed (shared D3/MW1); the doctor's #1 need is absent |
| My panel / follow-ups due | 🔴 MISSING | not surfaced |
| Wait-time on room rows | 🔴 MISSING (payload has it) | shared D1 |
| Money/revenue prominence | 🟠 **role-bleed (PR4)** | `collectPayment=true` for physician; money shouldn't lead the clinical dashboard |
| KPIs / alert strip / My Work panel | 🔴 disabled | commented out (shared D-series) |

## 3. The gap, in one line
A doctor should open to *"your next ready patient → what's clinically true about them → what's waiting on your signature."* Today they open to a **front-desk-shaped ops board with fabricated clinical cues layered on top.**

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **PD1 (PR1)** | **Fabricated AI safety cues** (risk banner + insights) shown to the physician on the dashboard/overview | Safety / phase | **Critical** | _pending_ — remove/hide until real (Phase 5); a doctor must not triage on fake data. |
| **PD2** | **No physician clinical inbox** — unsigned notes, abnormal labs to review, refills, follow-ups | Missing | **High** | _pending_ — physician variant of the work-feed (PR-BH): `docstatus=0` encounters I own, abnormal Lab Tests awaiting finalize, follow-ups assigned to me. |
| **PD3** | **Dashboard is ops-shaped, not clinical** — no "my ready patients" focus, money surfaced (PR4) | Role fit | **Med-High** | _pending_ — a practitioner view: ready-patients + safety + inbox; de-emphasize money/ops. |
| PD4 | Wait-time hidden (D1); disabled KPIs; not live (D7); placeholder demographics — incl. **age** (dosing) | Mixed | Med | _pending_ — shared dashboard fixes; age matters for the doctor too. |
| PD5 | `collectPayment=true` for physician (PR4) | Role scope | Med | _pending_ — confirm intended (small-clinic doctor-collects) vs remove (role-bleed). |

## 5. Recommended options (curated)
- **PD1 first:** strip fabricated AI/risk cues for the doctor — non-negotiable; the physician is the worst audience for fake clinical data.
- **PD2 clinical inbox:** the single highest-value physician addition — surface unsigned notes + abnormal results awaiting review. Build as the practitioner slice of the shared work-feed (FD-BH-4 / NU-BH-5 family).
- **PD3:** shape the practitioner dashboard around *ready patients + safety + inbox*, not ops/money.
- **NOT recommended:** more KPIs or a revenue view for the doctor — that's admin/front-desk. Keep the clinical surface clinical.

## 6. Open questions for product owner
1. **PD2:** Confirm the physician clinical-inbox categories: **unsigned encounters · abnormal labs awaiting finalize · refill requests · follow-ups due.** Source queries?
2. **PD5:** Should a physician collect payment (PR4), or is that front-desk-only? (Today it's on.)
3. **PD3:** Do we build a distinct practitioner dashboard layout, or keep the shared board with a clinical section added?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
