# Practitioner → My Work (clinical inbox)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Work · **Screen 8/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `inbox`.
**Frontend:** `work-inbox-client.tsx`; `useMyWorkFeed` → `tasks.get_my_tasks` + open encounters.
**Professional lens:** for the doctor this should be **the clinical inbox** — the single most important physician surface after the encounter itself: unsigned notes, abnormal results to review, refills, follow-ups. Today it's a generic task/todo/notes tool with **open encounters** wired but the rest of the clinical categories missing.

## 1. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| **Open encounters in feed** (unsigned/in-progress I own) | 🟢 REAL | `useMyWorkClinicalNotes` → `/api/encounters?status=Open&practitioner=me` |
| Todos / notes CRUD | 🟢 REAL | shared inbox |
| Assigned tasks | 🟢 REAL | `get_my_tasks` |
| **Abnormal labs awaiting my finalize** | 🔴 MISSING | not in the feed (the biggest physician-liability item) |
| **Refill requests** | 🔴 MISSING | no refill concept (ties PM2) |
| **Follow-ups I owe** | 🟠 partial | follow-up ToDos exist (front desk books them); confirm the doctor's own follow-ups surface |
| Proactive clinical categories | 🔴 MISSING | display config only, no data (shared D3/MW1) |

## 2. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| **PW1** | **No "abnormal results awaiting my review" in the inbox** — the doctor's #1 liability item | **High** | _pending_ — physician work-feed (PR-BH): un-finalized/abnormal Lab Tests I own + unsigned encounters (partly real) + follow-ups. |
| PW2 | Refill requests missing (ties PM2) | Med | _pending_ — depends on standalone Rx decision. |

## 3. Recommended
- **Physician clinical inbox (PW1)** — the highest-value doctor addition across the whole audit: never lose an abnormal result or an unsigned note. Build as the practitioner slice of the shared work-feed (FD-BH-4 / NU-BH-5 / PR-BH-1 — one backend, role-filtered).
- **NOT recommended:** more manual todo features — the value is auto-surfacing clinical due-items (unsigned notes, abnormal labs), not manual entry.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
