# Practitioner → Patient Chart 360 (full clinical)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Patients · **Screen 2/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `patients/[id]`.
**Frontend:** `patient-chart-client.tsx` → full clinical chart + overview.
**Professional lens:** the chart is the doctor's complete clinical picture — every tab, full authoring. Access is correctly unrestricted. The defining problem: the **AI/risk surfaces are fabricated and explicitly ON for the physician** — the one role that must trust its data.

## 1. Tab gating (practitioner, verified)
`chart-permissions.practitioner`: `sections:{}`, `subtabs:{}` → **full access to every tab** (Vitals, Labs, Meds, Immunizations, History, Documents, Billing, Messages). Overview flags: `showClinicalStats:true`, `showAllergyAlert:true`, **`showRiskBanner:true`, `showAiInsights:true`**.

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Full clinical tabs | 🟢 REAL | vitals/labs/meds/immunizations/history — see screens 03–06 |
| Allergy alert | 🟢 REAL | `showAllergyAlert` from real allergies |
| Clinical stats | 🟢 REAL | `showClinicalStats` |
| Med list (view/stop/resume) | 🟢 REAL | `usePatientMedications` / `update_medication_status` |
| Billing tab (doctor can collect — PR4) | 🟢 REAL | `collectPayment=true` → chart billing/collect |
| **Risk banner** | 🔴 **FABRICATED, ON (PR1)** | `showRiskBanner:true` → `patHash` "High Readmission Risk" shown to the physician |
| **AI insights / recommendations** | 🔴 **FABRICATED, ON (PR1)** | `showAiInsights:true` → `patHash`/hardcoded, pre-Phase-5 |
| History = core Patient Medical Record? | 🟠 no | hand-rolled feed, not the native timeline (core-map) |

## 3. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **PC1 (PR1)** | **Risk banner + AI insights fabricated AND explicitly ON for practitioner** | Safety / phase | **Critical** | _pending_ — set `showRiskBanner:false`/`showAiInsights:false` until real (Phase 5). The doctor is the worst audience for fake clinical data. |
| PC2 (PR4) | Doctor can collect payment from chart | Role scope | Med | _pending_ — confirm intended vs role-bleed. |
| PC3 | History feed ≠ core Patient Medical Record (partial/hand-maintained) | Completeness | Med | _pending_ — consider backing on native timeline (core-map recommendation). |

## 4. Recommended
- **PC1 first** — flip the fabricated AI/risk flags off for the physician; this is the single most important practitioner fix and a phase-rule violation shipping today.
- **NOT recommended:** removing clinical tabs from the doctor — full access is correct for the signer.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
