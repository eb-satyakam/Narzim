# Practitioner → Labs (review + finalize)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 5/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `/labs` + chart Lab tab.
**Backend:** `api/v1/labs/api.py`.
**Professional lens:** the physician's lab role is **review + finalize** — read the values the nurse entered, interpret against reference ranges, and sign off (`submit_lab_result`). Finalize authority is correctly the doctor's. The gap is surfacing *which* results need review (the clinical-inbox problem) and abnormal-flagging.

## 1. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| View lab results + result rows | 🟢 REAL | `get_lab_test`, `list_patient_lab_tests` |
| **Finalize result (physician-only)** | 🟢 **REAL + gated** | `submit_lab_result` = "physician finalizes"; verified **`EB_Practitioner` holds `Lab Test submit:1`** in `eb_docperm_spec.json` (correct) |
| Enter/correct values | 🟢 REAL | `record_result` (shared with nurse) |
| Trends | 🟢 REAL | `get_lab_trends` |
| **"Results awaiting my review" worklist** | 🔴 MISSING | no inbox of un-finalized abnormal results (the PD2 clinical-inbox gap) |
| Abnormal-flag / reference-range cues | 🟠 verify | confirm abnormal values are visually flagged for the reviewing doctor |

## 2. Safety note (paired with nurse NL1)
The finalize gate is correct **for the physician** (they hold submit). But the nurse audit found **`EB_Nurse` AND `EB_Front Desk` also hold `Lab Test submit`** (NL1 / NU-BH-3) — so non-physicians can *also* finalize. The fix is on the nurse/FD side (remove their submit); the physician's grant is right.

## 3. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| PL1 (PD2) | No "abnormal results awaiting my finalize" worklist | **High** | _pending_ — physician clinical-inbox (PR-BH work-feed): un-finalized + abnormal Lab Tests. |
| PL2 | Abnormal-flag surfacing at review — verify | Med | _pending_ — confirm reference-range/abnormal cues render for the doctor. |
| PL3 (NL1) | Nurse/FD can also finalize (fix on their side, NU-BH-3) | High | _pending_ — cross-ref; physician grant is correct. |

## 4. Recommended
- **Surface results-to-review (PL1)** — a doctor must never lose an abnormal result; this is the highest-value lab add for the physician.
- **NOT recommended:** removing the physician's finalize grant — that's correct. Fix the *over-grant* to nurse/FD instead.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
