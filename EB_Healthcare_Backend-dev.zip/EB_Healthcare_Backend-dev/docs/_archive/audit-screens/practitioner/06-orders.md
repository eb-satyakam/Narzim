# Practitioner → Orders (labs / procedures / therapies from the encounter)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 6/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · ordering happens **inside the encounter** (`encounter-screen.tsx`), not a standalone screen.
**Backend:** encounter child tables → Service Request (on sign); `search_medications`/`search_diagnoses`/procedure & therapy template lookups in `encounters/api.py`.
**Professional lens:** the doctor orders labs/procedures/therapies as part of documenting the visit; on **sign**, each becomes a Service Request (the actionable order). This is real and correctly core-composed. There is no standalone "orders" screen — ordering is encounter-bound.

## 1. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Order labs / procedures / therapies (in encounter) | 🟢 REAL | `lab_test_prescription` / `procedure_prescription` / `therapies` child tables (encounter-screen L83–100) |
| Template/search lookups | 🟢 REAL | `search_diagnoses`, procedure/therapy template search, `search_medications` |
| **On sign → Service Request per order** | 🟢 REAL (core) | native `on_submit` order layer (ADR-019) |
| Standalone orders screen | 🔴 N/A (by design) | orders are encounter-bound; no separate surface |
| Order status tracking (ordered → collected → resulted) | 🟠 partial | Service Request `status`/`billing_status` exist; confirm the doctor can *see* order progress post-sign |
| Referral out (Service Request → external) | 🟠 verify | `create_patient_referral` exists (encounters); confirm surfaced |

## 2. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| PO1 | **No post-sign order tracking** for the doctor (did my ordered lab get collected/resulted?) | Med-High | _pending_ — surface Service Request progress on the chart / clinical inbox. |
| PO2 | Referral-out flow surfaced? (`create_patient_referral`) | Med | _pending_ — verify the doctor's referral path (see FLOWS_REFERRAL_OUT.md). |

## 3. Recommended
- **Order tracking (PO1)** — a doctor needs to know their orders are progressing; ties to the clinical inbox (PD2).
- **NOT recommended:** a standalone orders module separate from the encounter — encounter-bound ordering is the correct clinical model; don't fragment it.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
