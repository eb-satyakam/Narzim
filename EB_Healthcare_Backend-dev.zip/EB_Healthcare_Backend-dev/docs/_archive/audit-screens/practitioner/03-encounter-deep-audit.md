# Encounter Workflow — Forensic Code Audit

**Doc status:** record · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

**Status:** ✅ complete · **Date:** 2026-08-20 · **Area:** Clinical · [practitioner index](../../../audit/practitioner/README.md)
**Supersedes the findings of:** [03-encounter.md](03-encounter.md) (2026-07-09) — that audit's `REAL/MOCK/MISSING`
table is now stale in both directions (AI is live; some things it called real are fabricated).
**Method:** code-first. Every claim below was verified against the code on `dev` @ the 2026-08-20 pull,
or against the live `marley.local` database, or both. Nothing was accepted from `CLAUDE.md`, from
comments in the code, or from the earlier audit without independent verification.

## How to read this document

| Label | Meaning |
|---|---|
| **CONFIRMED** | Proved from code *and* (where applicable) from data or a live call |
| **PARTIALLY TRUE** | The mechanism is real; the stated scope or impact was overstated |
| **FALSE** | Investigated and did not reproduce |
| **UNVERIFIED** | Cannot be settled from the code/DB alone — needs a person or a test |

Row counts are from `marley.local` on 2026-08-20: **144 Patient Encounters**, 131 with a SOAP blob.

> ### One-line summary
> The backend spine (identity, permissions, order-layer composition, Deepgram transport) is sound.
> Sitting on top of it are (a) a **live synthetic-data layer** that renders fabricated clinical
> information to physicians, (b) a **consent bypass** that writes a false attestation into the
> compliance record, and (c) **four subsystems that are fully built, tested, and not connected to
> anything** — including the one that would have delivered AI provenance.

---

## 1. Executive verdict

### 1.1 What is fundamentally sound — do not touch

| Area | Evidence |
|---|---|
| Patient identity in the AI path | `patient` is derived server-side from the encounter (`api/v1/ai/api.py:805`), never from the request. No cross-patient path exists through the 36 tools. |
| Encounter permission gates | `_require_encounter_read` checks the specific document; `complete_encounter` requires `submit` permission **and** `_require_any_practitioner`. Double-enforced FE+BE. |
| Deepgram transport | KeepAlive vs the 10 s idle close, token rotation 60 s before TTL, `WeakSet` to tell intentional closes from drops during rotation, Screen Wake Lock with visibility re-acquire, 20 s crash-safe flush. 13,631 segments persisted. |
| Backend consent gate | `api/ai/sessions.py::start_session` correctly refuses to mint a Deepgram token without consent and leaves the session in `Draft`. The gate is right; the client defeats it. |
| Deterministic dedupe in the tool layer | `_rx_already_present` / `_order_already_present`, with the correct reasoning stated in code: *"Prompt adherence cannot carry this; the check has to be deterministic."* |
| Vaccine catalog discipline | `add_vaccine` refuses to auto-create and refuses ambiguous matches. **This is the pattern the rest of the tool layer should copy.** |
| Cost instrumentation (OpenAI path) | `_pricing_for_model` prefix-matching after discovering every logged cost had silently used the gpt-5 fallback; cached input billed at 0.1× after measuring 46 % cached tokens over 302 calls. |
| Order-layer composition | Native `on_submit` spawns Medication Request (212) + Service Request (67). No core patching. |

### 1.2 What is fundamentally broken

1. **A live synthetic-data layer renders fabricated clinical information to practitioners.**
   Not mock screens — fabricated *provenance* wrapped around real clinical data, plus a growth chart
   that claims to plot WHO percentiles and plots three straight lines.
2. **Consent is asserted by the client and never asked.** 137 of 137 sessions carry
   `consent_obtained = 1` with a timestamp. Zero sessions have ever been in `Draft`.
3. **Half of the SOAP note has no storage in practice.** `hpi`, `plan`, `notes` and
   `physical_examination` appear in **0 of 131** encounter blobs.
4. **The provenance machinery is built, tested and unwired.** `tools_detail_json` is populated on
   0 of 1,897 log rows; its helper functions are imported only by their own unit tests.
5. **Read/write asymmetry silently destroys prescription data** (proved live in §4.1).
6. **No retention purge exists at all.** `scheduler_events` is entirely commented out
   (`hooks.py:312-328`), so every configured retention period is decoration.

### 1.3 Biggest five risks

| # | Risk | Class | Section |
|---|---|---|---|
| **R1** | Fabricated WHO growth percentiles + fabricated clinical-record provenance shown as fact | Clinical safety | §9.1, §13 |
| **R2** | Recording without consent, with a false affirmative consent attestation | Legal / regulatory | §10.4 |
| **R3** | An LLM authors drug strength into the permanent formulary, with no review flag | Clinical safety | §6.3 |
| **R4** | `_serialize_drug_rx` omits the dosing interval → silent erase on reopen | Data integrity | §4.1 |
| **R5** | Pediatric vitals judged against adult thresholds; respiratory rate has no rule at all | Clinical safety | §9.2 |

---

## 2. Complete DocType map

### 2.1 `Patient Encounter` — standard ERPNext Healthcare, 61 fields, 3 custom

Format: **FIELD → PURPOSE → WRITER → READER → SOURCE OF TRUTH → RISK**.
"Populated" = rows out of 144 with a non-empty value, measured directly.

#### Identity and scope

| Field | Purpose | Writer | Reader | Source of truth | Pop. | Class | Risk |
|---|---|---|---|---|---|---|---|
| `patient` | Patient identity | `create_encounter` | everything; AI `ctx`; report | **this field** | 144 | A | Critical identity. Correctly the anchor for AI patient scoping |
| `patient_name` | Display | core on save | report, list | `Patient.patient_name` | 144 | I (derive) | Snapshot can diverge from Patient after a rename |
| `patient_sex` | Display | *nobody* | *nobody* | `Patient.sex` | **0** | **E — DEAD** | FE computes sex from the Patient record instead (`patientSexLabel`) |
| `patient_age` | Display | *nobody* | *nobody* | `Patient.dob` | **0** | **E — DEAD** | FE computes age from dob (`calcAgeFromDob`) |
| `custom_patient_email` | Notify/report | fixture default | — | `Patient.email` | 127 | **D — duplicate** | Second copy of a mutable contact detail |
| `appointment` | Link to the booking | `create_encounter` | header, vitals binding, `AI Encounter Record` | `Patient Appointment` | 133 | A | 11 encounters are walk-ins with no appointment |
| `appointment_type` | Core mandatory (`reqd=1`) | core default | *nobody clinical* | — | 144 | B | Required by core, carries no clinical meaning here |
| `company` | Multi-clinic scoping | `create_encounter` | `_bill_defaults_for_company`, `useClinicFacilities` | **this field** | 144 | A | Drives Internal/External order tagging and billing defaults |
| `title` | Core display string | core | — | derived | 144 | I | — |

#### Timing and authorship (legal)

| Field | Purpose | Writer | Reader | Source of truth | Pop. | Class | Risk |
|---|---|---|---|---|---|---|---|
| `encounter_date` | Visit date | `create_encounter` | note header, ordering, list | **this field** | 144 | A | **Legal.** Correctly used by the note header (`_encDate`) |
| `encounter_time` | Visit time | `create_encounter` | ordering | **this field** | 144 | A | Legal |
| `custom_encounter_end` | Consultation end | `complete_encounter` | duration reporting | **this field** | 116 | C | Custom field |
| `practitioner` | Assigned clinician | `create_encounter` | `canCancel` gate, report | **this field** | 144 | A | **Legal.** ADR-038: only the assigned practitioner may cancel |
| `custom_encounter_done_by` | Who actually signed | `complete_encounter` | report attribution | **this field** | 19 | A | **Legal.** ADR-039. Low count because the field is recent |
| `practitioner_name` | Display | core | report | `Healthcare Practitioner` | 144 | I | — |
| `medical_department` | Department | `create_encounter` | note header | Practitioner | 137 | C | — |
| `status` | Open/Ordered/Completed/Cancelled | `complete_encounter`, core | list, KPIs, dashboard | **this field** | 144 | A | Distinct from `docstatus`; both are consulted |
| `amended_from` | Core amendment link | **nobody** | **nobody** | — | **0** | **F** | **The core amendment mechanism exists on the doctype and has no API, no UI, and zero rows.** See §10.3 |

#### The clinical content

| Field | Purpose | Writer | Reader | Source of truth | Pop. | Class | Risk |
|---|---|---|---|---|---|---|---|
| `encounter_comment` | **The entire SOAP note, as a JSON blob** | `save_draft` | `get_encounter`, `complete_encounter`, `_create_encounter_immunizations` | **this field** | 131 | **B — wrong design** | JSON in a `Small Text`. Not queryable, not indexable, not reportable. Max observed 2,926 B, avg 1,474 B — **no size risk**. See §2.2 |
| `symptoms` (child) | Complaints | `save_draft` | note, AI, chief-complaint derivation | child table | 279 rows / 122 enc | A | Link to `Complaint`; free-text creation allowed → catalog growth |
| `diagnosis` (child) | Diagnoses | `save_draft` | note, AI, report | child table | 144 rows / 97 enc | A | **Legal.** 47 encounters have no diagnosis — permitted by design |
| `drug_prescription` (child) | Prescriptions | `save_draft` | note, Medication Request | child table | 223 rows / 62 enc | A | **Legal.** See §4.1 |
| `lab_test_prescription` (child) | Lab orders | `save_draft` | Service Request | child table | 32 rows / 18 enc | A | — |
| `procedure_prescription` (child) | Procedures | `save_draft` | Service Request | child table | 15 rows / 12 enc | A | — |
| `therapies` (child) | Therapy referrals | `save_draft` | Therapy Plan | child table | 17 rows / 16 enc | A | — |
| `codification_table` (child) | ICD coding | **nobody** | **nobody** | — | **0 rows** | **E — DEAD** | ICD coding happens inside the `Diagnosis` master string instead |
| `physical_examination` | — | — | — | — | n/a | **Misleadingly named** | **It is a `Column Break`, not a data field.** `save_draft` accepts a `physical_examination` parameter which goes into the JSON blob, not here |

#### Dead / never-used fields (all measured at 0)

| Field | Why it exists | Verdict |
|---|---|---|
| `insurance_policy`, `insurance_coverage`, `insurance_payor`, `coverage_status` | Core insurance | **E — DEAD.** Phase 3 insurance not built |
| `inpatient_record`, `inpatient_status`, `emergency_record` | Core IPD/ER | **E — DEAD.** OPD-only product |
| `google_meet_link` | Core telehealth | **E — DEAD** |
| `referring_practitioner` | Referrals | **E — DEAD.** Referral flow cancelled 2026-06-18 |
| `source` | Direct/Referral/External | **E — DEAD.** All 144 hold the default `"Direct"` |
| `submit_orders_on_save` | Core behaviour toggle | **E — DEAD** |
| `symptoms_in_print` | Print toggle | **G — UI-only, stored in DB.** 0 set |
| `diagnosis_in_print` | Print toggle | **G — UI-only.** 144 at default 1, read by nothing of ours |

**Recommendation:** none of these should be *deleted* (they are core fields — Rule 1), but the
Desk form and any API surface should stop exposing them, and `codification_table` should be hidden.

### 2.2 `encounter_comment` — the real SOAP store

Measured across all 131 non-empty blobs by parsing each one.

| Blob key | Present in | **Non-empty in** | Verdict |
|---|---|---|---|
| `bill_flags` | 131 | 130 | **A** — operational. Per-table `bill_this` booleans (ADR-025) |
| `vaccines` | 130 | **1** | Feature has been used exactly once |
| `chief_complaint` | 127 | 127 | **A** — the only narrative field that exists |
| `education` (= "Review Details") | 120 | 120 | **A** — AI-generated, physician-confirmed at sign |
| `hpi` | **0** | **0** | **E — DEAD.** Written by nothing, ever. See §4.5 |
| `plan` | **0** | **0** | **E — DEAD. The "P" of SOAP does not exist in any encounter** |
| `notes` | **0** | **0** | **E — DEAD.** `save_draft` accepts it; the FE never sends it |
| `physical_examination` | **0** | **0** | **E — DEAD. The "O" narrative does not exist** |
| `diagnosis` (flat string) | **0** | **0** | **F — LEGACY.** Superseded by the child table |

> **This is the single most important structural finding in the audit.** The signed clinical note
> consists of: chief complaint + review details + structured diagnosis/order rows. There is no
> history of present illness, no physical examination, and no treatment-plan narrative in any of
> the 144 encounters in the database.
>
> **Why `plan` is empty:** the Treatment Plan section's `with-plan` branch is
> *search-only, no free-text textarea* (`encounter-screen.tsx:5144`). A plan is expressed as an
> applied template, which expands into orders. The narrative field is never filled.
>
> **Why `hpi` is empty:** it has state (`:541`), a save path (`:139`) and a load path (`:1108`) —
> and **no input control anywhere in the UI**, and no place on the printed report.

### 2.3 Child table field detail

Fields our app writes are marked ✍; fields core stamps are marked ⚙; the rest are never touched.

**`Drug Prescription` (17 fields)** — 223 rows
`medication`✍ `drug_code`✍ `drug_name`✍ `strength`✍ `strength_uom`✍ `dosage_form`✍
`dosage`✍ `interval`✍ `interval_uom`✍ `period`✍ `comment`✍ · `medication_request`⚙
· never used: `dosage_by_interval`, `number_of_repeats_allowed`, `intent`, `priority`, `update_schedule`

Population: `period` 223/223 (`reqd=1`), `drug_code` 223/223, `medication` 223/223,
`strength_uom` 223/223, `dosage` 216/223, `comment` 167/223, `strength` 154/223,
**`interval` 110/223**, `interval_uom` 223/223.

> ⚠️ **113 rows carry an `interval_uom` with no `interval`** — a semantically broken
> "every NULL hours". Cause: `_tool_add_medication` hardcodes `"interval_uom": "Hour"`
> (`services/ai_tools.py:754`) whether or not the model supplied an interval.

**`Lab Prescription` (10)** — 32 rows
`lab_test_code`✍ `lab_test_name`✍ `lab_test_comment`✍ · `service_request`⚙ `invoiced`⚙ `lab_test_created`⚙
· never used: `observation_template`, `patient_care_type`, `intent`, `priority`

**`Procedure Prescription` (15)** — 15 rows
`procedure`✍ `procedure_name`✍ `date`✍ `practitioner`✍ `comments`✍ · `service_request`⚙ `procedure_created`⚙ `invoiced`⚙
· never used: `department`, `no_of_sessions`, `interval`, `appointment_booked`, `patient_care_type`, `intent`, `priority`

**`Therapy Plan Detail` (8)** — 17 rows
`therapy_type`✍ `no_of_sessions`✍ `interval`✍ (days→seconds) · `service_request`⚙
· never used: `sessions_completed`, `patient_care_type`, `intent`, `priority`

**`Patient Encounter Symptom` (1)** — `complaint` · 279 rows
**`Patient Encounter Diagnosis` (1)** — `diagnosis` · 144 rows

### 2.4 `Vital Signs` — standard, 75 rows (7 draft / 68 submitted)

| Field | Writer | Pop. | Class |
|---|---|---|---|
| `patient`, `encounter` | `flushTypedVitals` | 75, **75** | A — binding is sound |
| `appointment` | `flushTypedVitals` | 72 | A |
| `temperature` | FE | 11 | A |
| `pulse` | FE | 9 | A |
| `respiratory_rate` | FE | 9 | A — **and it has no abnormal rule anywhere** |
| `custom_oxygen_saturation` | FE | 9 | A — custom field |
| `bp_systolic` / `bp_diastolic` | FE | 5 / 5 | A |
| `height` / `weight` | FE | 62 / 73 | A |
| `bmi` | core auto-calc | 60 | **B** — computed for infants, where it is not a valid measure |
| `vital_signs_note` | **nobody** | **0** | **E — DEAD, and there is a bound, editable textarea for it.** See §4.2 |

**Missing entirely:** head circumference, weight/height percentile, z-score. `scripts/seed/seed_vital_signs_templates.py:28-30` seeds
`head_circumference`, `wt_percentile` and `ht_percentile` as *template* field keys with units and
ranges — none of them exist on the `Vital Signs` doctype the encounter writes to.

### 2.5 AI DocTypes — 18 installed, row counts measured

| DocType | Fields | Rows | Verdict |
|---|---|---|---|
| `AI Encounter Session` | 18 | **137** | Live. **See §2.6 — the state machine has one state** |
| `AI Transcript Segment` | 12 | **13,631** | Live. Has `speaker_label` + `deepgram_segment_id` (raw-label persistence done) |
| `AI Prompt Log` | 34 | **1,897** | Live. See §2.7 |
| `AI Encounter Chat Message` | 19 | **456** | Live. Holds `actions_json` — the only verbatim record of AI proposals |
| `AI Encounter Record` | 19 | **81** | Live. Written by `hooks.py:229` → `capture_on_submit` |
| `AI Patient Clinical Summary` | 23 | **169** | Live. One per patient, regenerated in place |
| `AI Patient Chat Message` | — | 133 | Live (patient-chart chat) |
| `AI Narzim Assistant Message` | — | 38 | Live (general assistant) |
| `AI Lab Panel Extraction Panel` | — | 41 | Live |
| `AI SOAP Draft` | 16 | **0** | **E — the entire SOAP-draft subsystem is dead.** See §13 |
| `AI Usage Counter` | — | **0** | **E — dead scaffolding** |
| `AI Prompt Template` | — | **0** | **E — dead scaffolding.** Seeded, never read at runtime |
| `AI Subscription Plan` (+ `...Company`, `...Seat`) | — | **0** | **E — dead scaffolding** |
| `AI Settings` (Single) | 28 | 1 | Live. See §2.8 |

**Not installed, but referenced by `CLAUDE.md` Rule 6 and `ROADMAP.md` (7 citations):**
`AI Recommendation Log`. It does not exist. The nearest real thing is
`AI Encounter Record.suggestions_json`, which captures **proposals only** — never a physician verdict.

### 2.6 `AI Encounter Session` — field-level

| Field | Purpose | Writer | Pop. | Verdict |
|---|---|---|---|---|
| `encounter`, `patient`, `practitioner`, `session_user` | scoping | `_get_or_create_draft` | all | A |
| `status` | lifecycle | `start_session`, `stop_session` | **137/137 = `Recording`** | **B — the machine has never left one state** |
| `consent_obtained` | LFPDPPP consent | `start_session` | **137/137 = 1** | **See R2. Zero sessions have ever been `Draft`** |
| `consent_obtained_at` | consent timestamp | `start_session` | 137/137 | Timestamp of an event that never occurred |
| `close_reason` | why it ended | `stop_session` | **0** | **E — DEAD** |
| `started_at` | — | controller | 137 | A |
| `ended_at`, `duration_seconds` | recording length | `stop_session` | **0** | **E — DEAD. The audit trail cannot say how long any consultation was recorded** |
| `error_code`, `error_message` | failure capture | never | **0** | E — DEAD |
| `audio_retained` | audio policy | controller | **0** | **A — correct.** Matches `retain_audio = 0` |
| `deepgram_model`, `llm_model`, `prompt_versions` | provenance | controller | — | C — useful |

**Duplicate sessions:** 133 distinct encounters hold a session; **4 encounters have 2** created
~1 second apart (e.g. `AIES-2026-00137` and `-00138` on `HLC-ENC-2026-00149` at 13:47:40 and
13:47:41). Cause: two concurrent `start_session` calls both miss the existence check in
`_get_or_create_draft` (no unique constraint). **Impact measured: zero** — no encounter has
transcript segments spanning more than one session.

### 2.7 `AI Prompt Log` — field-level

1,897 rows. Purposes: Patient Clinical Summary **1,217 (64 %)** · Copilot Chat 293 · Patient Lab
Summary 112 · Copilot Review Details 85 · Lab Chat 70 · Multi-Panel Extraction 52 · Report Lab
Summary 40 · Narzim Assistant Chat 19 · Copilot Transcribe 8 · Thread Title 1.

| Field | Pop. | Verdict |
|---|---|---|
| `tools_used` | 282 | C — tool **names** only |
| `tools_detail_json` | **0** | **E — DEAD. `redact_tool_args` / `tool_result_shape` (`services/ai.py:439,468`) are imported only by `tests/ai/test_observability.py`. Nothing in production writes this field.** This is the missing provenance link |
| `raw_response` | 190 | **Conflicted.** Holds the model's clinical output *and* is load-bearing: `lab_extraction.py:421,468` and `imaging_extraction.py:158` read it back as the source of extracted lab values |
| `cost_estimate_usd` | 1,831 | **1,217 of these (64 %) are computed with the wrong pricing** — §5.4 |
| `prompt_hash` | 1,518 | A |
| `encounter` / `patient` | 386 / 1,834 | A |
| `error` | 34 | C |
| `detected_panels` | present in `meta`, **absent from the DB columns** | **UNVERIFIED schema drift** |

**Notably absent:** no `Copilot Suggestions` purpose exists in 1,897 rows → `generate_suggestions`
has **never been invoked** on this site (consistent with `enable_suggestions = 0`).

### 2.8 `AI Settings` — which flags are actually consumed

Live values and consumer counts (grep over the backend, excluding tests and JSON):

| Flag | Live value | Consumers | Verdict |
|---|---|---|---|
| `enable_ambient_documentation` | **1** | yes | Live — gates recording; **this is what makes the consent bypass active** |
| `enable_suggestions` | **0** | yes | Genuinely gates. Live-suggestion path dormant |
| `enable_safety_validators` | **0** | **0 (reported only)** | **E — DEAD SWITCH.** Read at `api/v1/ai/api.py:410`, typed at `app/api/ai/flags/route.ts:8`, consumed nowhere in either repo |
| `enable_soap_generation` | 1 | 3 | Gates a subsystem with 0 rows |
| `enable_analyze_cache` | 1 | 2 | Live |
| `enable_lab_extraction` | 1 | 23 | Live |
| `llm_provider` | **OpenAI** | yes | See §5.5 |
| `openai_model` | `gpt-5-mini` | yes | Live |
| `openai_reasoning_effort` | `low` | yes | Live |
| `llm_context_token_budget` | 5000 | 8 | **Not applied to the patient-summary or catalog-injection paths** |
| `llm_temperature` | 0.2 | 1 | Ignored on gpt-5 models (`_is_reasoning_model` omits it) |
| `idle_timeout_seconds` | 300 | **0** | **E — DEAD.** The FE hardcodes `SILENCE_LIMIT_MS = 2 min` |
| `max_session_minutes` | 60 | 6 | Live |
| `retain_audio` / `audio_retention_days` | 0 / 0 | 7 | A — correct |
| `transcript_retention_days` | **2555** | 4 (definitions only) | **No purge implemented.** And it **contradicts** `ComplianceProfile.transcript_retention_days` = 90 (mx) / 30 (india) |
| `soap_draft_retention_days` | 2555 | **0** | **E — DEAD** |
| `prompt_log_retention_days` | **365** | **0** | **E — DEAD. The 365-day purge does not exist, so `raw_response` clinical content is retained indefinitely** |

> **`hooks.py:312-328` — `scheduler_events` is entirely commented out.** There is no scheduled job
> of any kind in this app. **Every retention period configured anywhere is decoration.** 13,631
> segments of doctor–patient conversation and 190 rows of model clinical output are retained forever.

---

## 3. End-to-end data flow

```
PATIENT CHART
   │ Start / open /encounters/[id]
   ▼
useEncounter(id) ─────────────────────────────► READ (call 1)
   │ ⚠️ WATERFALL — the patient fetch cannot begin until this resolves
   ▼
usePatient(encounter.patient) ────────────────► READ (call 2)
   │
   ▼
EncounterScreen mounts                          25 API calls; 7 endpoints >1×
   │                                            (encounter ×3, followup ×2,
   │                                             rx-options ×2, ai/flags ×2,
   │                                             clinic-settings ×2, auth/me ×2)
   │
   ├─► CopilotHost mount effect: copilot.start()      ◄── NO CLICK, NO CONSENT
   │      ├─ getUserMedia({audio:true})
   │      ├─ POST /api/ai/session { consent_obtained: TRUE }   ← hardcoded
   │      │     └─ AI Encounter Session: Recording, consent_obtained=1  ✅ PERSISTED
   │      ├─ Deepgram token minted (rotated 60 s before TTL)
   │      └─ WS audio ──► Deepgram ──► AI Transcript Segment    ✅ PERSISTED (forever)
   │
   ├─► resume-load: encountersApi.get(id) → _fmt_encounter(full=True)
   │      └─ ⚠️ DROPS interval + interval_uom → FE sets both to ""   ❌ CLIENT STATE
   │
   └─► readLocalDraft() ← unencrypted PHI in localStorage; WINS over the server
   │
   ▼
DOCTOR DOCUMENTS  (enc = React state)               persisted?
   ├─ chiefComplaint / symptoms ......... blob + child   ✅
   ├─ vitals (8 numbers) ................ Vital Signs    ✅
   ├─ vitals NOTES textarea ............. NOWHERE        ❌ SILENT LOSS
   ├─ diagnoses ......................... child table    ✅
   ├─ hpi ............................... no input       ❌ 0/131
   ├─ physical exam ..................... no input       ❌ 0/131
   ├─ plan (narrative) .................. no input       ❌ 0/131
   ├─ orders (rx/lab/proc/therapy) ...... child tables   ✅
   └─ vaccines .......................... blob           ✅ (used once)
   │
   ▼  debounced 2 s after the last keystroke
AUTOSAVE ─► save_draft (PATCH) ─► child tables REPLACED wholesale
   │   ⚠️ no `modified` check → last-write-wins across tabs
   │   ❌ interval: undefined → stored frequency erased
   │   ⚠️ non-catalog dosage → folded into `comment`, structured field blanked
   │   ❌ rx rows missing dosage_form|period → SILENTLY DROPPED
   │   ⚠️ .catch(() => setAutoSaveState("error")) → error text discarded, retries every 8 s
   ▼
AI CHAT / ANALYZE  (optional; 293 chat turns logged)
   POST /api/ai/chat → ask_copilot → ≤20 tool round-trips
   │   context: age, allergies, meds, chief complaint, prior patient summary,
   │            + 6 UNBOUNDED master catalogs (556 entries live)
   │   write tools return suggestion objects — NO DB write   ✅
   │   BUT accepting one may call create_master → INSERT Medication + Item
   │        with ignore_permissions=True and LLM-inferred strength   ❌
   └─► actions applied IMMEDIATELY to the form; reply appends "✦ actions applied"
        aiFlags[target] = "ai"      ← REACT STATE ONLY, never persisted   ❌
        rejections → localStorage only, and only honoured on the CACHED path ❌
   │
   ▼
SIGN
   ├─ validate chief complaint         ← FIRST validation happens HERE
   ├─ validate vaccine nurse           ← hard gate on a path used once
   ├─ prepareDraftForSign: save_draft + flushTypedVitals      (2 round trips)
   ├─ POST /api/ai/review-details      ← BLOCKING LLM CALL
   ├─ modal: physician reads/edits Review Details
   ├─ complete_encounter → doc.submit()      ✅ docstatus 0→1  = LEGAL RECORD
   │     ├─ core on_submit → Medication Request (212) + Service Request (67)  ✅
   │     ├─ _stamp_billing_optout                                            ✅
   │     ├─ auto-submit draft Vital Signs                                    ✅
   │     └─ _create_encounter_immunizations → Patient Vaccine + Nursing Task  (0 ever)
   ├─ hooks.py:229 capture_on_submit → AI Encounter Record                   ✅
   │        transcript_json + chat_json + suggestions_json (PROPOSALS ONLY)
   ├─ setTimeout(2800 ms)              ← hardcoded animation
   ├─ report overlay
   └─ "Acknowledge & finish"
   │
   ▼
SIGNED — read-only. No amend API. `amended_from` exists, 0 rows.
Correction path today = cancel_encounter (void) + re-document.
```

---

## 4. Data-loss findings

### 4.1 DL-1 — Prescription dosing interval erased on reopen · **CONFIRMED (proved live)**

**Chain, all four links verified:**

| Link | File | Behaviour |
|---|---|---|
| Write keeps it | `api/v1/encounters/api.py:597-620` | `_apply_drug_prescriptions` persists `interval` + `interval_uom`; `doc.set("drug_prescription", [])` replaces the table |
| **Read drops it** | `api/v1/encounters/api.py:191-203` | `_serialize_drug_rx` returns 11 keys; neither field is among them |
| FE blanks it | `encounter-screen.tsx:1060-1061` | resume-load hardcodes `interval: ""`, `interval_uom: ""` |
| Autosave writes NULL | `encounter-screen.tsx:1180-1202` | fires 2 s after any keystroke, re-sends the whole array |

**Live proof** — calling the real serializer against real data (`HLC-ENC-2026-00003`):

```
DB row:      Budesonida  interval=12  interval_uom="Hour"  dosage="0-0-1"  period="4 Week"
API returns: name, drug_code, medication, drug_name, dosage_form, dosage,
             period, strength, strength_uom, comment, bill_this
interval present in API row?      False
interval_uom present in API row?  False
```

**User story.** Dr. Bracamontes prescribes amoxicillin **every 8 hours for 7 days**, is called to
another room, comes back and reloads the tab. The frequency field is blank — one small field among
forty, and he does not notice. He types one character in Review Details. Two seconds later autosave
writes `interval = NULL`. He signs. The Medication Request that reaches the pharmacy says
"amoxicillin, 7 days", with no frequency.

**Scope — stated honestly.** 110 of 223 rows currently hold an interval, so this is not universal.
How many have already been silently cleared is **not recoverable retroactively**. The mechanism is
**CONFIRMED**; the blast radius is **UNVERIFIED**.

**Severity: P0.** **Fix:** add two keys to `_serialize_drug_rx`, read them in the FE. Ten minutes.

### 4.2 DL-2 — The vitals NOTES box discards everything typed into it · **CONFIRMED with data**

`encounter-screen.tsx:3823-3831` is a bound, editable `<textarea value={newNote}>` with a
placeholder. `flushTypedVitals` (`:212-256`) sends exactly 8 numeric fields. `grep newNote` returns
6 hits, every one a read or a render. `Vital Signs.vital_signs_note` is populated on **0 of 75** rows.

**User story.** The nurse types *"child crying throughout, BP taken on second attempt, mother
reports poor feeding ×2 days"* under the vitals. The header says **Saved**. The doctor signs. The
text never existed.

**Severity: P0** — a field that lies about persisting is worse than a missing field.

### 4.3 DL-3 — Prescriptions silently dropped before every save · **CONFIRMED**

`encounter-screen.tsx:135`:

```ts
const validRx = enc.orders.rx.filter((r) => r.dosage_form && r.period);
```

Rows missing either field are excluded from **every** payload, including the sign-time save. No
warning, no inline error, no gate — while a vaccine missing its nurse gets a hard `frappe.throw`.

**User story.** The doctor adds "Salbutamol inhaler", picks the strength, and skips the duration
select. The row sits on screen with a delete button next to it, looking saved. He signs. It is not
in the note, not in the Medication Request, and not on the printed prescription the parent carries out.

**Severity: P0.**

### 4.4 DL-4 — Structured dosage silently demoted to prose · **CONFIRMED**

`api/v1/encounters/api.py:582-586`. A `dosage` that is not a `Prescription Dosage` master value is
appended to `comment` and the structured field blanked — deliberately, to stop one bad value 400-ing
the entire autosave. The trade-off is right; there is **no user-visible signal**. Live: `dosage`
216/223, `comment` 167/223.

**Severity: P1.**

### 4.5 DL-5 — `hpi` is a write-only field the AI can populate · **PARTIALLY TRUE (latent)**

`hpi` is a valid `SuggestionTarget` (`copilot/types.ts:74`), written by `applySuggestionToEnc`
case `"text"`, saved by `buildSaveDraftPayload:139` — and has **no input control** and **no place on
the printed report** (`encounter-report.tsx` renders `plan` and `education` only).

**Structurally**, AI narrative can enter the signed clinical record with no possibility of physician
review. **Historically it has not**: `hpi` appears in **0 of 131** blobs. This is a latent
Rule 6 violation, not a live one. The earlier audit implied it was live — that was wrong.

**Severity: P1** (close the path or build the field).

### 4.6 DL-6 — No optimistic concurrency; child tables replace · **mechanism CONFIRMED, impact UNVERIFIED**

`save_draft` (`:1487`) re-reads the document inside the request and overwrites it. The client never
sends `modified`, so Frappe's own `TimestampMismatchError` protection can never fire. Autosave runs
every 2 s from every open tab, and child tables use replace semantics. ADR-022's nurse→doctor
handoff is exactly the collision case.

**User story.** The nurse adds vitals and a lab order from her tab. The doctor's tab, opened five
minutes earlier, autosaves 2 s later and replaces the whole `lab_test_prescription` table. The lab
order is gone. No error is shown to either of them.

**No corruption evidence was recoverable from the data.** **Severity: P1.**

### 4.7 DL-7 — Autosave failure is one grey word, retried forever · **CONFIRMED**

`:1197` and `:1222`: `.catch(() => setAutoSaveState("error"))` — the exception message is discarded.
`save_draft` throws readable errors ("Medication 'X' not found", "drug_code is required",
"UOM 'mg' not found"); none of them reach the physician. The retry effect re-fires every 8 s
indefinitely.

**User story.** A chat-added drug fails Link validation. The doctor charts for twenty minutes. The
only signal is a small grey word in the header. Nothing has persisted since the first failure.

**Severity: P1.**

### 4.8 DL-8 — Unencrypted PHI in `localStorage`, retained after abandonment · **CONFIRMED**

`:103-127`. `narzim:encounter-draft:<id>` holds chief complaint, diagnoses and prescriptions.
`clearLocalDraft` runs only on a successful save/sign/cancel, so an abandoned encounter leaves PHI
on the workstation indefinitely. A local draft also **wins over the server** on load (`:1122`).
Rejected AI suggestions are stored here too (`stream/touched-state.ts`).

**Severity: P1** on a shared clinic machine.

### 4.9 DL-9 — The signature block prints render time, not sign time · **CONFIRMED**

`:1884-1889` uses `formatClinicalDate(new Date())` and `formatClinicalTime(new Date())`. The note
*header* correctly uses the encounter date (`_encDate`, `:1567-1571`); the **signature** does not.

**User story.** A June encounter is reprinted in August for an insurer. The document shows an August
date beside the practitioner's name and signature line.

**Severity: P1** (legal document integrity).

### 4.10 DL-10 — Two-button traps rescued at submit · **CONFIRMED**

`sign()` silently commits typed-but-unsaved vitals (`:1404`) and an opened-but-unbooked follow-up
(`:1420`). The in-code comments call them traps. A form that needs rescuing at submit time has the
wrong affordance. **Severity: P2.**

### 4.11 Investigated and NOT reproduced

| Claim | Verdict | Why |
|---|---|---|
| Transcript split across duplicate sessions | **FALSE** | 4 encounters have 2 sessions; **0** have segments spanning more than one |
| `encounter_comment` blob overflow | **FALSE** | Max observed 2,926 B against a ~65 KB column |
| Vitals mis-bound to the wrong encounter (NV1/B1, July audit) | **FALSE — appears fixed** | `Vital Signs.encounter` populated 75/75, `appointment` 72/75 |

---

## 5. AI data-flow findings

### 5.1 Every AI operation, mapped

| Operation | Input | Context | Model | Tools | Output → UI | Persisted |
|---|---|---|---|---|---|---|
| Ambient capture | mic audio | — | Deepgram `nova-3`, `language=multi`, `diarize=true` | — | live transcript | `AI Transcript Segment` (13,631) |
| `ask_copilot` (chat) | prompt + ≤6 prior turns + transcript | age, allergies, meds, chief complaint, prior summary, **6 unbounded catalogs** | `gpt-5-mini`, effort `low` | 36, ≤20 iterations | actions applied **immediately** | `AI Encounter Chat Message` (456), `AI Prompt Log` (293) |
| `analyze_encounter` | transcript | same | same | same | actions applied immediately | cached; `AI Prompt Log` |
| `generate_review_details` | encounter + transcript | — | same | — | blocking modal, editable | blob `education` (120/131), log (85) |
| `generate_suggestions` | transcript | + all 6 catalogs | same | none | — | **0 log rows — never invoked** |
| `generate_soap_draft` | transcript | — | same | — | — | **`AI SOAP Draft` = 0 rows — dead** |
| Patient Clinical Summary | **the entire patient record** | unbounded | same | — | chart header | `AI Patient Clinical Summary` (169); **1,217 log rows = 64 % of all AI calls** |
| Lab extraction | PDF / image | — | vision | — | review screen | `raw_response`, **read back as the data source** |

### 5.2 The agent loop

`integrations/openai.py:1306-1451`, `ask_copilot_agent_stream`. Bounded at
`_MAX_TOOL_ITERATIONS = 20` (raised 5 → 12 → 20), `max_completion_tokens = 700 + 3000` reasoning
headroom per trip. Honest failure mode: if the cap is hit while still calling tools, it returns
*"I've gathered some information but need you to ask again"* rather than looping. This is Rule 9
correctly implemented. The team's own measurement (from the streaming-revert commit `a711e66`):
**first clinical item at 11.68 s, full synchronous Analyze at 44 s.**

### 5.3 Unbounded catalog injection · **CONFIRMED + quantified**

`services/ai.py:168-243` — six resolvers, each a `frappe.get_all(...)` with **no limit**, injected
verbatim into every suggestion and agent prompt:

| Catalog | Live rows |
|---|---|
| `Complaint` | 195 |
| `Medication` | 175 |
| `Diagnosis` | 91 |
| `Lab Test Template` | 60 |
| `Therapy Type` | 19 |
| `Clinical Procedure Template` | 16 |
| **Total** | **556** — three of the six alone serialise to ~9,000 characters (~2,250 tokens) |

`llm_context_token_budget = 5000` is not applied to any of it. **All six doctypes are AI-creatable**,
so the loop is self-reinforcing: the AI proposes a near-duplicate → the physician accepts →
`create_master` inserts it → the catalog grows → every future prompt carries the duplicate as a
"valid entry to reuse exactly". Cost, latency and catalog entropy grow monotonically with use.

### 5.4 The dominant AI cost is measured with the wrong price list · **CONFIRMED**

`services/patient_clinical_summary.py:49-50` hardcodes **Claude Sonnet** pricing
(`$3 / $15` per Mtok) and applies it at `:2018` to `cost_estimate_usd` — while the site runs
`gpt-5-mini` (`$0.25 / $2.00`). Input is overstated ~12×, output ~7.5×, **in the same log row that
records `model = gpt-5-mini`**. This affects 1,217 of 1,897 rows (64 %).
`integrations/openai.py::_pricing_for_model` already solves this correctly and is not called.

### 5.5 Rule 5 is overridden by a code comment, not an ADR · **CONFIRMED**

`services/patient_clinical_summary.py:38-45`, verbatim:

> *"Use the patient's FULL record (product decision 2026-07-22): every related record feeds the
> summary, not a recent slice… **This deliberately relaxes ADR-029's bounded-slice stance (Rule 5).**
> …Everything else is unbounded (frappe.get_all limit=0 → all rows)."*

Eight gatherers run at `limit=_ALL`; only lab analyte rows are capped (`_LAB_ROW_CEILING = 1000`).
Rule 5 is one of the ten non-negotiables and specifies a hard 4,000-token context block. Whether or
not full-record retrieval is the right call, **a numbered constitutional rule should not be
superseded by a comment in a service file.** The file also contradicts itself: line 43 says
unbounded, line 471 says *"Each is a bounded recent slice (Rule 5)"* — both are true of different
builders, and even the "bounded" one has `_encounter_lines` at `limit=_ALL` (`:603`).

### 5.6 A recorded wrong-diagnosis event is mitigated by prompt text · **CONFIRMED**

`integrations/openai.py:1336-1350` records it in the code: on 2026-07-29 a prior visit's summary
("*queja principal de equimosis fácil*") was read as **this** visit's chief complaint on a **fever**
presentation, and the agent drafted a bruising diagnosis (R23.3) plus PT/INR + aPTT + CBC. The
control is now an emphatic ALL-CAPS paragraph in the context block. It works until a model update
stops obeying it. The structural fix — never put prior-visit prose in the same context slot as this
visit's data — is available and was not taken.

### 5.7 `set_patient_summary` overwrites cumulative history · **CONFIRMED**

`services/ai_tools.py:1107-1117`: *"OVERWRITES, unlike the other patient_draft fields which append."*
The prompt (`openai.py:1341-1348`) therefore hands the model the existing summary and instructs that
every clinical fact in it must be preserved — *"re-written in the Output language if it was recorded
in a different one"*. Nothing verifies that it was. The review panel shows the physician a new
paragraph and one **apply** button; there is no diff.

### 5.8 `AI Prompt Log.raw_response` is both an audit field and a clinical data store

Written at `api/v1/ai/api.py:662`; **read back** as the source of extracted lab values at
`lab_extraction.py:421,468` and `imaging_extraction.py:158`. The doctype docstring acknowledges it
holds "the model's clinical output". Rule 10 says prompt logs store hashes and token counts, not
raw content. This is a **deliberate, documented deviation** — and, like §5.5, not recorded in an ADR.
Combined with §2.8: `prompt_log_retention_days = 365` has **no implementation**, so the content is
retained indefinitely.

### 5.9 The OpenAI compliance conflict · **CONFIRMED as a documentation conflict; the fact is UNVERIFIED**

`integrations/openai.py:12-15`, verbatim:

> *"Gated: OpenAI must stay OFF (llm_provider=Claude) in any real environment until its own
> data-processing agreement + patient consent are in place (ADR-007 / M6 gate) — **PHI would
> otherwise leave to a third party without a legal basis.** This adapter is dev-usable only."*

Live: `llm_provider = OpenAI`, `openai_model = gpt-5-mini`. ADR-026 later opened an approved
allowlist, but requires "a data-processing-terms check against the active `ComplianceProfile`"
before a provider joins it. **No record of that check for OpenAI was found in the repo.** Either it
happened and this docstring is a landmine for the next engineer, or it did not. **Only a person can
settle this.**

### 5.10 Two API-key sources disagree

`_api_key()` (lab extraction) accepts `OPENAI_API_KEY` from the environment **or** `frappe.conf`.
`_call_with_tools` (the encounter Copilot) accepts **only** `frappe.conf` and throws
*"Add it to site_config.json."* `CLAUDE.md` §9 says "environment variables only".

---

## 6. Tool-by-tool audit — all 36 tools

`services/ai_tools.py`. **13 read + 23 write = 36** (matches `CLAUDE.md`).
**No write tool mutates the database** — verified by reading every executor. Every write returns a
suggestion object. The DB mutations happen elsewhere: `create_master` (§6.3) and the frontend.

### 6.1 Read tools (13) — all SAFE READ

| Tool | Data accessed | Bound | Permission check |
|---|---|---|---|
| `get_patient_labs` | Lab Test + Normal Test Result | 8 tests × 6 items | `require_permission("Lab Test","read")` |
| `get_previous_encounters` | **signed only** (`docstatus=1`) | ≤5 (default 3) | `require_permission("Patient Encounter","read")` |
| `get_current_transcript` | live or persisted transcript | 6,000 chars | — |
| `get_encounter_state` | the current draft | whole draft | — |
| `get_appointment_details` | Patient Appointment | 1 | — |
| `get_vaccine_catalog` | Immunization Template | all active | — |
| `get_lab_analysis` | stored AI lab summary | 1 | — |
| `search_medication_catalog` | Medication | query-scoped | — |
| `search_lab_catalog` | Lab Test Template | query-scoped | — |
| `search_diagnosis_catalog` | Diagnosis | query-scoped | — |
| `search_procedure_catalog` | Clinical Procedure Template | query-scoped | — |
| `search_therapy_catalog` | Therapy Type | query-scoped | — |
| `search_complaint_catalog` | Complaint | query-scoped | — |

**Good practice found:** `get_previous_encounters` was changed on 2026-07-29 to exclude unsigned
drafts (they were previously being presented to the model as settled clinical history), and it
**surfaces the withheld count** as `unsigned_drafts_excluded` rather than silently truncating.

**Caveat for all 13:** `require_permission` is **doctype-level**; patient scoping comes from the
closure. Mitigated because `patient` is derived from the encounter server-side
(`api/v1/ai/api.py:805`) and the entry point checks that specific encounter. Defence-in-depth only.

### 6.2 Write tools (23)

| Tool | Args | Persists | Approval | Creates master | Overwrites | Deterministic check | Class |
|---|---|---|---|---|---|---|---|
| `add_medication` | drug_name, dosage, interval, period, strength, strength_uom, comment | no | **applied immediately** | **YES — Medication + Item, LLM-inferred** | no | dup guard + `_allergy_conflict` | **HIGH RISK** |
| `add_lab` | lab_test_name, comment | no | applied immediately | **YES — flagged for review** | no | dup guard | REQUIRES APPROVAL |
| `add_diagnosis` | diagnosis | no | applied immediately | **YES — Diagnosis** | no | none | REQUIRES APPROVAL |
| `add_procedure` | procedure_name, comments | no | applied immediately | **YES** | no | dup guard | REQUIRES APPROVAL |
| `add_therapy` | therapy_type, no_of_sessions | no | applied immediately | **YES** | no | dup guard | REQUIRES APPROVAL |
| `add_symptom` | complaint | no | applied immediately | **YES — Complaint** | no | none | SAFE PROPOSAL |
| `add_vital` | vital, value | no | applied immediately | no | **yes, per field** | none | REQUIRES APPROVAL |
| `add_chief_complaint` | text | no | applied immediately | no | **yes (overwrites)** | none | REQUIRES APPROVAL |
| `add_review_details` | text | no | applied immediately | no | **yes** | none | SAFE PROPOSAL |
| `add_vaccine` | name | no | applied immediately | **NO — by design** | no | **exact-then-substring; refuses ambiguity** | **SAFE PROPOSAL — the model to copy** |
| `remove_medication` | match | no | applied immediately | no | removes 1 | **no-op unless exactly 1 match** | SAFE PROPOSAL |
| `remove_lab` / `remove_diagnosis` / `remove_procedure` / `remove_therapy` / `remove_symptom` / `remove_vaccine` | match | no | applied immediately | no | removes 1 | same conservative rule | SAFE PROPOSAL |
| `add_patient_medication` | medication | no | patient-draft review panel | no | appends | none | REQUIRES APPROVAL |
| `add_allergy` | allergy | no | patient-draft review panel | no | appends | none | REQUIRES APPROVAL |
| `add_medical_history` | item | no | patient-draft review panel | no | appends | none | REQUIRES APPROVAL |
| `add_surgical_history` | item | no | patient-draft review panel | no | appends | none | REQUIRES APPROVAL |
| `set_patient_summary` | summary | no | review panel, **no diff** | no | **OVERWRITES cumulative history** | none | **HIGH RISK** |
| `add_follow_up` | in, type, note | no | applied immediately | no | field-wise | none | SAFE PROPOSAL |

### 6.3 SHOULD NOT EXIST in its current form

**`add_medication`'s master-creation path.** `api/v1/ai/api.py:120-219`, `_create_medication_master`:

```python
fields = get_llm_client().infer_medication_fields(
    name=name, dosage_forms=dosage_forms, strength_uoms=uoms, classes=classes
)
...
doc = frappe.get_doc({"doctype": "Medication", "generic_name": generic,
    "medication_class": fields["medication_class"], "dosage_form": fields["dosage_form"],
    "strength": strength_val, "strength_uom": fields["strength_uom"], ...
}).insert(ignore_permissions=True)
```

An LLM decides **strength**, **strength UOM**, **dosage form** and **medication class**, and the
result becomes a permanent formulary entry with a linked Item that every future prescription can pick.
`ignore_permissions=True` also contravenes the standing project rule against code-level permission
bypasses.

**Three internal precedents make this an inconsistency rather than an oversight:**

1. `_create_lab_master` calls `_flag_lab_for_review` (`:367`), which tags the record and comments
   *"Auto-created from an AI clinical suggestion. AI-inferred, UNVERIFIED… A physician/admin must
   confirm the UOM and reference range before results are clinically interpreted."*
   **Medications get no tag, no comment, no review queue.**
2. `add_vaccine` refuses to auto-create at all, because *"a vaccine needs a linked Item + dose
   schedule that only an admin sets up"* (`ai_tools.py:1134`). Strength, form and class are the same
   class of admin-owned structured data.
3. The code itself records a correctness incident from a weaker version of this check
   (`:135-139`): a request for "Paracetamol 650 mg" was silently resolved onto a pre-existing
   "Suppository Paracetamol 250 mg".

**`set_patient_summary`.** Overwrite semantics force an LLM to be the integrity mechanism for the
patient's cumulative history. See §5.7.

### 6.4 Smaller defects in the tool layer

| Finding | Evidence |
|---|---|
| `"confidence": 0.6` is a **hardcoded literal** on every medication suggestion — the number the UI displays measures nothing | `ai_tools.py:766` |
| `interval_uom` hardcoded `"Hour"` regardless of whether an interval was supplied → 113 rows with a dangling UOM | `ai_tools.py:754` |
| The tool spec teaches the model `strength_uom: "mg \| g \| mL \| IU"` while the DB validates against `UOM` names (`"Milligram"`) — a latent hard 400 on any path that skips master creation | `ai_tools.py:1358` vs `encounters/api.py:588-592` |
| `_order_dup_keys` does a full catalog scan per proposed order (`limit_page_length=0`) with substring comparison in Python — O(catalog) per tool call, up to 20 calls | `ai_tools.py:816-838` |
| `execute_tool`'s catch-all returns `f"Tool {name} failed: {exc}"` **to the model** and logs `frappe.get_traceback()` — a plausible PHI path into `Error Log`. **UNVERIFIED** — needs one test | `ai_tools.py:1722-1727` |

---

## 7. AI provenance — can the chain be reconstructed?

Target chain: **AI saw → concluded → proposed → evidence → doctor accepted/edited/rejected →
doctor changed → final value → signed record.**

| Link | Persisted? | Where | Gap |
|---|---|---|---|
| AI saw (transcript) | ✅ | `AI Transcript Segment` (13,631) + `AI Encounter Record.transcript_json` | — |
| AI saw (context) | ⚠️ partial | `prompt_hash` (1,518 rows) identifies the prompt, not the context values | Cannot reconstruct which catalog/summary values were sent |
| AI concluded (reply) | ✅ | `AI Encounter Chat Message.content` (456) | — |
| AI proposed | ✅ | `AI Encounter Chat Message.actions_json`; `AI Encounter Record.suggestions_json` (81) | — |
| AI evidence / reasoning | ⚠️ partial | the `reasoning` array on each suggestion (often the boilerplate *"Added to the draft at the physician's explicit request via chat."*) | Not real evidence |
| Tool calls | ⚠️ names only | `AI Prompt Log.tools_used` (282) | — |
| **Tool arguments + results** | ❌ | `tools_detail_json` — **0 of 1,897** | **The helpers exist, pass tests, and are imported only by their tests** |
| **Doctor accepted** | ❌ | nowhere | `aiFlags["ai"]` is React state; `buildSaveDraftPayload` never sends it |
| **Doctor edited** | ❌ | nowhere | `aiFlags["edited"]` is React state, lost on unmount |
| **Doctor rejected** | ❌ | `localStorage` only | `setStatus` (`use-copilot.ts:443-445`) is a one-line `setSuggestions`; no network call |
| Before/after values | ❌ | nowhere | No diff is captured at any point |
| Model, model version | ✅ | `AI Prompt Log.model`, `AI Encounter Chat Message.model` | — |
| Timestamps | ✅ | `creation` on every row | — |
| Practitioner identity | ✅ | `session_user`, `practitioner`, `custom_encounter_done_by` | — |
| Final signed record | ✅ | `Patient Encounter` at `docstatus=1` | — |

**Verdict.** The chain is reconstructible up to the proposal, and **breaks completely at the
physician's verdict**. You can diff `suggestions_json` against the final note offline, but you
cannot distinguish "the doctor accepted this" from "the doctor never looked at it", and a rejection
leaves no trace outside one browser's `localStorage`.

**Two additional wrinkles:**
- Rejections are only applied on the **cached** Analyze path (`NarzimAIChatBar.tsx:677` —
  `data.cached === true ? filterRejectedActions(raw, rejections) : raw`), so a fresh Analyze
  re-proposes everything the physician already declined.
- `track("ai.suggestion_accepted", { accepted: true })` fires inside `applyCopilotSuggestion`
  (`encounter-screen.tsx:860`), which is also the **auto-fill** path. The acceptance metric is
  structurally inflated.

---

## 8. Clinical safety audit — validators vs claims

Separated as requested into **prompt check** / **deterministic validator** / **DB constraint** /
**human review**.

| Safety rule | Prompt | Deterministic validator | DB constraint | Human review | Verdict |
|---|---|---|---|---|---|
| Allergy name match | yes | **YES** — `_allergy_conflict` | no | yes | Implemented, narrow |
| **Allergy cross-reactivity** | no | **NO** | no | yes | **NOT IMPLEMENTED** |
| Drug–drug interactions | yes | **NO** | no | yes | **PROMPT-ONLY — NOT A SAFETY CONTROL** |
| Contraindications | yes | **NO** | no | yes | **PROMPT-ONLY** |
| Pediatric dosing | yes | **NO** | no | yes | **PROMPT-ONLY** |
| Weight-based dosing | no | **NO** | no | — | **NOT IMPLEMENTED** — and there is no structured field for it |
| Age appropriateness | yes | **NO** | no | yes | **PROMPT-ONLY** |
| **Medication strength** | no | **NO — an LLM authors it** | no | **no** | **NOT IMPLEMENTED** |
| Medication form | no | LLM-inferred | `Dosage Form` link | no | Partial |
| Frequency | no | **NO** | none | no | **NOT IMPLEMENTED** + erased by DL-1 |
| Duration | no | must be a `Prescription Duration` | **YES (`reqd=1`)** | yes | **Implemented** |
| Duplicate medications | yes | **YES** — `_rx_already_present` | no | yes | **Implemented — good** |
| Vitals plausibility | no | **NO** | no | yes | NOT IMPLEMENTED |
| Pediatric vital thresholds | no | **adult constants** | no | yes | **SAFETY THEATRE** |
| **Respiratory rate** | no | **NO RULE AT ALL** | no | yes | **NOT IMPLEMENTED** |
| SpO₂ | no | `< 95` flat | no | yes | Crude, directionally safe |
| Blood pressure | no | **`> 140 / 90`** | no | yes | **SAFETY THEATRE in pediatrics** |
| Temperature | no | `> 37.5` flat | no | yes | Crude |
| BMI | no | computed at every age | no | yes | **Wrong instrument under 2 y** |
| **Growth percentiles** | no | **fabricated straight lines labelled "WHO percentiles"** | no | yes | **SAFETY THEATRE — worst finding** |
| Vaccine catalog | yes | **YES** — refuses ambiguous matches | Template link | yes | **Best-in-repo** |
| Labs | yes | exact-match-first, then auto-create + review flag | no | yes | Acceptable |
| Diagnosis | yes | none | Link validation | yes | Weak |
| Follow-up | no | none | ToDo | yes | Fine |

### 8.1 `_allergy_conflict` traced by hand · `services/ai_tools.py:374-419`

Matches on whole-word containment in either direction, plus a shared ≥5-character prefix. For a
documented **penicillin** allergy and a proposed **amoxicillin 500 mg**:

- `\bpenicillin\b` in `"amoxicillin 500mg"` → **no**
- `\bamoxicillin\b` in `"penicillin"` → **no**
- prefix: `"amoxi"` vs `"penic"` → **no**

**No hit.** The most common and most consequential cross-reactivity in pediatrics passes silently.
The docstring is honest about it: *"NOT a clinical authority (no real cross-reactivity database)."*

It also records that live `Patient.allergies` free-text values include **`"a"`, `"s"` and
`"dssdv"`** — the input to the only medication safety check is unreliable by construction, because
allergies are stored as free text with no catalog constraint.

### 8.2 What "safety theatre" means here

Three surfaces display a safety judgement that no validator produced:

1. The **abnormal-vital flag** on temp / HR / SpO₂ / BP, using adult constants (§9.2).
2. The **growth chart's WHO percentile curves**, which are geometry (§9.1).
3. `AI Settings.enable_safety_validators`, which an operator would reasonably read as a master
   switch for clinical validation, and which **gates nothing** (§2.8).

---

## 9. Pediatric audit

### 9.1 Fabricated WHO growth percentiles — **the worst finding in this audit**

`src/components/narzim/patient-chart/vitals-tab.tsx`, rendered in the Vitals tab **and** the
Overview tab.

```ts
// :122-124 — the "percentile" definitions
weight: { yRange: [2, 24],    bands: { p3: -3,   p50: 0, p97: 3   } },
height: { yRange: [0.4, 1.3], bands: { p3: -0.1, p50: 0, p97: 0.1 } },
bmi:    { yRange: [12, 22],   bands: { p3: -2,   p50: 0, p97: 2   } },

// :350-354 — how a "percentile curve" is drawn
const bandPath = (off: number) => {
  const start = ((refYMin + refYMax) / 2) * 0.85 + off;
  const end   = ((refYMin + refYMax) / 2) * 1.15 + off;
  return `M ${X(x0)},${Y(start)} L ${X(x1)},${Y(end)}`;   // a STRAIGHT LINE
};
```

The weight "p50 curve" is a straight diagonal from **11.05 kg to 14.95 kg** across whatever date
range happens to be on screen. There is **no age input, no sex input, and no growth standard**.
The three lines are identical for a newborn and a 15-year-old.

The labels assert the opposite:

```
chart.vitals.growthSub         = "{metric} · WHO percentiles · plotted from recorded visits"
chart.vitals.legendPercentiles = "3rd · 50th · 97th percentile"
```

**Zero percentile / LMS / z-score code exists in either repository** (grepped both).

| Patient | Real value | What the chart implies |
|---|---|---|
| Newborn | 3.2 kg | Far below the "p3 line" (starts at 8.05 kg) — every newborn reads as severely underweight |
| 2-month-old | 5.5 kg | Below "p3" — reads as failure to thrive |
| 2-year-old | 12 kg | Between "p3" and "p50" — reads reassuring regardless of truth |
| 9-year-old | 28 kg | Above the top of `yRange` (24 kg) — reads as >97th percentile for a normal child |
| 15-year-old | 55 kg | Off the chart entirely, still labelled WHO |

**This is a clinical misread generator.** It answers the central question of pediatric practice —
is this child growing normally — with geometry, under an authoritative label.

**Fix (P0):** either remove the three band paths and the two labels, or implement real WHO LMS
tables keyed on age and sex. **Never ship one without the other.**

### 9.2 Adult vital thresholds applied to children

`encounter-screen.tsx:3592-3596` and `:3620`, duplicated in the read-only branch at `:3712-3717`
and `:3730`:

```ts
(key === "temp" && parseFloat(val) > 37.5) ||
(key === "hr"   && parseInt(val) > 110)    ||
(key === "spo2" && parseInt(val) > 0 && parseInt(val) < 95)
// ...and separately:
const bpWarn = parseInt(newVitals.sys) > 140 || parseInt(newVitals.dia) > 90;
```

| Threshold | Newborn | 2-month | 2-year | 9-year | 15-year |
|---|---|---|---|---|---|
| `hr > 110` | HR 140 is normal → **false alarm on every healthy neonate** | 130 normal → false alarm | 110 borderline | 95 fine | 105 is tachycardic → **missed** |
| **RR: no rule exists** | 45 normal | **62 = distress → SILENT** | 35 | 22 | 16 |
| `sys>140 \|\| dia>90` | — | — | **118/76 is >99th pct → rendered black** | 125/80 severe → **missed** | roughly right |
| `temp > 37.5` | 37.6 in a neonate warrants a sepsis workup; styled identically to a 9-year-old | | | | |
| BMI | computed | computed | **not a valid measure under 2 y** | ok | ok |

**Respiratory rate is the single most age-dependent vital in pediatrics and the earliest sign of
respiratory distress. It is in `VITAL_KEYS` and absent from the `warn` expression.**

### 9.3 Other pediatric gaps

| Item | Status |
|---|---|
| Head circumference | Seeded as a template field key with a range (`seed_vital_signs_templates.py:28`); **not a field on `Vital Signs`**. Not capturable |
| Weight / height percentile | Seeded as template field keys (`:29-30`); no storage, no calculator |
| Z-scores | Do not exist |
| Weight-based dosing | No structured field. `dosage` is a fixed catalog ("1-0-1", "BID"); mg/kg has nowhere to live except free-text `comment` |
| Weight / height units | metres and kg, consistently. **No unit-confusion defect found** ✅ |
| Pediatric medication forms | `Dosage Form` master includes syrup/drops/inhaler ✅ — but strength is LLM-authored (§6.3) |
| Vaccine schedule | Mexico EPI implemented (~1,176 lines) — and `Immunization` = **0 rows**, `Patient Vaccine` = **0 rows**. Never exercised, yet a missing nurse **blocks signing** |

---

## 10. Clinical record integrity and audit trail

### 10.1 What is what

| Concept | Where | Mutable? |
|---|---|---|
| **The legal record** | `Patient Encounter` at `docstatus = 1`, its child tables, and the `encounter_comment` blob | No — `save_draft` rejects `docstatus != 0` (`:1489`) |
| Draft | `docstatus = 0` | Yes, by any writer, with replace semantics and no version check |
| AI session data | `AI Encounter Session` + segments + chat + `AI Encounter Record` | Separate lifecycle ✅ |
| Cancelled | `docstatus = 2` | `cancel_encounter`; UI forces read-only (`isCancelled`) |

### 10.2 Correct separation ✅

`CLAUDE.md`'s and the user's requirement that the AI session must not *be* the encounter is
**already satisfied**: `AI Encounter Session` is a distinct doctype with its own status field,
consent fields and timing, linked by `encounter`. Recommendation: **do not** add `SIGNED` /
`COMPLETED` states to it — `docstatus` is the authority on finality, and duplicating it would create
two sources of truth.

### 10.3 Amendment · **PARTIALLY TRUE (earlier audit said "does not exist")**

`Patient Encounter.amended_from` (`Link → Patient Encounter`, read-only) **exists on the doctype** —
Frappe's native amendment mechanism. It has **0 rows**, **no API method** (`grep amend` over
`api/` returns only comments), and **no UI**. The only correction path exposed today is
`cancel_encounter` (void) followed by re-documentation.

### 10.4 Consent · **CONFIRMED, and stronger than previously reported**

Three code sites form the chain:

| Site | Code | Effect |
|---|---|---|
| `copilot/CopilotHost.tsx:74-108` | mount effect calls `copilot.start()` | Recording begins with no click. Comment: *"TEMPORARY DEV SHORTCUT (2026-07-25, explicit user instruction — 'dont need consent')… MUST be reviewed/reverted… before any real clinical use"* |
| `copilot/CopilotPanel.tsx:101-108` | `const [consented, setConsented] = React.useState(true)` | The consent screen never renders |
| `app/api/ai/session/route.ts:34` | `consent_obtained: true` | Hardcoded. Comment: *"The UI's consent modal already gates every path that reaches here, so consent_obtained is always true"* — a premise that stopped being true on 2026-07-25 |

The backend then correctly stamps `consent_obtained = 1` and `consent_obtained_at = now()`.

**Data confirms the behaviour, not just the code:**

| Measurement | Value |
|---|---|
| Sessions | 137 |
| `status = Recording` | **137 (100 %)** |
| `status = Draft` (the no-consent state) | **0** |
| `consent_obtained = 1` | **137 (100 %)** |
| `consent_obtained = 0` | **0** |
| `consent_obtained_at` set | 137 |
| Distinct encounters with a session | **133 of 144 (92 %)** |
| Sessions holding transcript segments | 126 |

If consent were genuinely being requested, some sessions would sit in `Draft` and far fewer than
92 % of encounters would have one. **The system writes an affirmative, timestamped consent
attestation for a consent that was never requested** — which is worse than a missing field, because
it will survive an audit unchallenged.

### 10.5 Violations of "AI proposes → practitioner reviews → signs → auditable"

| # | Violation | Evidence |
|---|---|---|
| 1 | **No review step on the Analyze path.** Actions are applied to the form immediately; the reply appends "✦ actions applied" afterwards | `NarzimAIChatBar.tsx:523-525` → `fillFormFromSuggestions` (`encounter-screen.tsx:983`) |
| 2 | **Verdicts never persisted** (§7) | `use-copilot.ts:443-445` |
| 3 | **`tools_detail_json` never written** (§7) | 0/1,897 |
| 4 | **Signature date is render time** | `:1884-1889` |
| 5 | **Session lifecycle inert** — no `ended_at`, no duration; the trail cannot say how long recording ran | 137/137 `Recording` |
| 6 | **Latent:** AI can write `hpi` into the signed record with no UI to review it | §4.5 — 0 occurrences to date |
| 7 | **No retention enforcement** — `scheduler_events` commented out | `hooks.py:312-328` |

**Resolved since the July audit:** the Rule 6 auto-write of AI patient history was removed by commit
`c9f1126`, and `encounter-screen.tsx:3207-3215` now carries an explicit comment forbidding its
return. `CLAUDE.md` is **stale** on this point — it still lists the gap as live.

---

## 11. RAG / history / patient summary

| Component | Exists? | Evidence |
|---|---|---|
| Structured patient data | **YES** | 8 gatherers in `patient_clinical_summary.py` |
| Patient-wide summary | **YES** | `AI Patient Clinical Summary`, 169 rows |
| Previous-encounter prose | **YES** | `get_previous_encounters` (signed only) + `existing_summary` in the agent context |
| Keyword / structured retrieval | **YES** | 6 catalog search tools |
| **Vector search / embeddings** | **NO** | Zero embeddings, no vector store, no pgvector — deliberate (`transcript_digest.py:14-16`) |
| Guidelines corpus | **NO** | — |
| External medical knowledge | **NO** | Model weights only |
| Historical cohort data | **NO** | — |

**Answers to the specific questions:**

- **Is the LLM receiving previous-encounter prose?** Yes — via `get_previous_encounters` and the
  `existing_summary` line in the context block.
- **Can previous-visit information be confused with the current complaint?** **Yes, and it already
  has** (§5.6). The control is prompt text.
- **Is patient history bounded?** Chat context: yes (`_CHAT_PER_SOURCE_CAP = 15`), except
  `_encounter_lines` at `limit=_ALL`. Stored summary: **no** — 8 unbounded gatherers, labs capped at
  1,000 rows.
- **What is the token budget?** `llm_context_token_budget = 5000` exists and is **not enforced** on
  either the summary or the catalog injection.
- **Is the summary generated by the LLM?** Yes, and it **overwrites**.
- **Can the LLM delete facts from the cumulative summary?** **Yes** — nothing verifies preservation.
- **Is there a real RAG system?** No.

---

## 12. Practitioner UX audit

**Measured** (Playwright, authenticated as `EB_Practitioner`, `/encounters/HLC-ENC-2026-00148`):
**25 API calls, 7 endpoints called more than once** — the encounter itself **3×**, `followup` ×2,
`rx-options` ×2, `ai/flags` ×2, `clinic-settings` ×2, `auth/me` ×2 — plus a serial waterfall
(`useEncounter` → `usePatient`). Zero console errors, zero failed requests, zero 4xx/5xx.

| # | Friction | Evidence |
|---|---|---|
| UX-1 | **"Start" on the encounter list is inert** — `onClick={e => { e.stopPropagation(); }}` and nothing else. It also *blocks* the row navigation, so the list's primary CTA is worse than absent | `encounters-client.tsx:318-325` |
| UX-2 | **"New" has no `onClick` at all** | `:232` |
| UX-3 | **Only 100 of 144 encounters are reachable.** `page_size: 100`, then client-side "Load More" over the fetched page; search filters only those 100. `fetch_all` exists in the params type and is unused | `:117`, `:145-155` |
| UX-4 | **The sign tail is 5 interactions and 2 waits after the clinical decision** — blocking LLM call → modal → submit → **hardcoded 2,800 ms** → report → "Acknowledge & finish" | `:1500-1510`, `:1456` |
| UX-5 | **The first validation is the Sign click** — chief complaint and vaccine-nurse, then scroll-and-flash for 5 s | `:1476-1499` |
| UX-6 | **All five order sections start collapsed**, even when they already contain data | `:4781` |
| UX-7 | **The progress rail is written and unmounted.** `SoapSidebar` (`:2337`, ~200 lines, **24 shipped i18n strings**) is imported by nothing; `hideStep` is defined and never called, so `hiddenSteps` is permanently empty | `:600`, `:2337` |
| UX-8 | **Consequence of UX-7:** `lastSectionRef` is only set by `showStep`, which now fires only on validation failure — so `encounter.abandoned.last_section` is effectively always `"unknown"`. **The drop-off telemetry was killed by the dead navigation** | `:604`, `:583` |
| UX-9 | **Destructive red "Cancel" sits immediately left of "Sign & close"** | `:1937-1958` |
| UX-10 | **12 hardcoded user-visible strings** in a bilingual app: `Print Report` ×2, `Cancel`; plus 9 in the list screen (4 filter tabs, 4 KPI labels, "New", "Start", "All", "No encounters match this filter") | `:1643, :1918, :1942`; `encounters-client.tsx:35-38, 191-194, 232, 278, 322` |
| UX-11 | **`ai-risks` command-palette action is a dead button** — falls through to `default: onFlash("coming soon")` | `command-palette.tsx:49` |
| UX-12 | **Admins cannot sign in the UI** although `complete_encounter` permits them (`_require_any_practitioner` + admin) | `encounters/[id]/page.tsx:38` |
| UX-13 | **The AI panel shows "Error" on a site with recording disabled**, and auto-starts on one where it is enabled — the physician never chooses | `CopilotHost.tsx:74-108` |

---

## 13. Dead code, orphans and contradictions

| Item | Size | Evidence | Action |
|---|---|---|---|
| `patHash` **synthetic clinical-data layer** | — | `lib/narzim/chart-utils.ts:1-3` — *"Deterministic seeding (patHash) keeps synthesised per-patient data stable"* | **REMOVE** |
| ↳ fabricated **AI insights**, live | `patient-screen.tsx:143-159, 182, 226` | `getInsights` picks 2 of 7 clinical strings by `patHash(id,99)`: *"Hgb 9.8 g/dL at last CBC — below range"*, *"Height growth below 25th percentile — review"*, *"MMR booster overdue — last given Jun 2025"*. Reachable via ⌘K → "Ask Narzim AI"; the palette entry has **no `roleFilter`** | **REMOVE (P0)** |
| ↳ fabricated **recommended actions**, live | `patient-screen.tsx:239` | Three hardcoded strings: *"Schedule MMR booster — overdue"*, *"Repeat CBC to monitor Hgb trend"*, *"Review salbutamol compliance"* | **REMOVE (P0)** |
| ↳ fabricated **clinical-record provenance**, live | `use-clinical-record.ts:40-84` | Real allergy/condition **names** wrapped in invented orgs (*Sunrise Children's Hospital*, *Hospital Ángeles*), invented clinicians (*Dr. Priya Nair*, *Dr. Renata Cruz*, *Lourdes Méndez, RN*, *Dr. Miguel Soto*), hash-derived dates against a hardcoded `REC_TODAY = 2026-05-27`, and an invented clinical annotation | **REMOVE (P0)** |
| ↳ external items **cannot be deleted** | `use-clinical-record.ts:113` | `filter(x => x.id !== id \|\| x.external)` — and no API call fires for them | **REMOVE with the above** |
| ↳ fabricated **growth percentiles**, live | `vitals-tab.tsx:122-124, 350-354` | §9.1 | **REMOVE or IMPLEMENT (P0)** |
| ↳ fabricated **risk banner** | `patient-screen.tsx:570-572, 610-626` | Computed from `patHash(id,42)`; **gated off for all 7 roles** (`chart-permissions.ts:37-77`) → unreachable | **REMOVE** (dead) |
| ↳ `bloodGroupFor` | `chart-utils.ts:74` | Imported at `patient-screen.tsx:13`, **never called** | **REMOVE** |
| ↳ `profLicFor` — fabricated professional licence *"shown on the letterhead signature block"* | `chart-utils.ts:79` | Defined, **no caller** | **REMOVE before anyone wires it** |
| ↳ `hasInsuranceFor` / `insuranceFor` / `guardianDetailFor` / `RELATIONS` | `chart-utils.ts:88-110` | Fabricators; no live caller found | **REMOVE** |
| `SoapSidebar` + `soapSteps` + `hideStep` + 24 i18n keys | ~200 lines | Unmounted (§12 UX-7) | **RECONNECT** |
| `stream/conflict-manager.ts`, `stream/useAnalyzeStream.ts` | 508 lines | Imported by nothing. Cite `services/analyze_events.py` and `docs/ai/AI_ANALYZE_STREAMING_DESIGN.md`, both deleted by `a711e66` / `a369151` | **REMOVE** |
| `stream/touched-state.ts`, `stream/merge-engine.ts` | 343 lines | Only `filterRejectedActions` + `TouchedState` are used, and only on the **cached** Analyze path. Their rule — *"A field or row the physician has touched is IMMUTABLE to the stream"* — is the correct fix for §10.5-1 | **RECONNECT** |
| `redact_tool_args`, `tool_result_shape` | `services/ai.py:439,468` | Imported **only** by `tests/ai/test_observability.py`; `tools_detail_json` 0/1,897 | **RECONNECT — this is the provenance fix** |
| `enable_safety_validators` | — | Reported, never consumed | **RECONNECT or REMOVE** |
| `idle_timeout_seconds`, `soap_draft_retention_days`, `prompt_log_retention_days` | — | 0 consumers each | **RECONNECT or REMOVE** |
| `AI SOAP Draft` + `generate_soap_draft` + `accept/discard_soap_draft` + `soapDraft`/`generateSoap` in `use-copilot` | ~16 fields + 4 endpoints + FE state | **0 rows** | **REMOVE or justify** |
| `generate_suggestions` + `suggest-v2.txt` + `_focus_directive` | ~120 lines | **0 log rows ever** | **DECIDE** |
| `AI Usage Counter`, `AI Prompt Template`, `AI Subscription Plan` ×3 | 5 doctypes | 0 rows | **REMOVE** |
| `Codification Table` on the encounter form | — | 0 rows | **REFACTOR** — hide |
| ~130 lines of commented `autoFill` with fabricated clinical content | `encounter-screen.tsx:1229-1320` | Fake diagnoses and Rx in a production file | **REMOVE** |
| `sleep()` helper | `:1227` | Used only by the above | **REMOVE** |
| Dead encounter fields | 15 fields | §2.1 | **REFACTOR** — stop exposing |
| Blob keys `hpi`, `plan`, `notes`, `physical_examination`, `diagnosis` | 5 keys | 0/131 each | **DECIDE: build the input or delete the key** |
| `detected_panels` | — | In `meta`, absent from DB columns | **INVESTIGATE (UNVERIFIED)** |
| `scheduler_events` | 17 lines | Fully commented out → no retention anywhere | **RECONNECT** |

### Documentation that contradicts production code

| Document | Claim | Reality |
|---|---|---|
| `CLAUDE.md` Rule 6 note | 5 write tools auto-apply to the Patient record | **Fixed** by `c9f1126`. Stale |
| `CLAUDE.md` Rule 6 note | `AI Recommendation Log` is where the AI contribution is tracked | Doctype does not exist; `AI Encounter Record` partially covers it |
| `CLAUDE.md` §3 | Vector DB: "None, and deliberately so" | **Correct** ✅ |
| `integrations/openai.py:12-15` | OpenAI must stay OFF until a DPA exists | `llm_provider = OpenAI` live |
| `services/patient_clinical_summary.py:471` | "Each is a bounded recent slice (Rule 5)" | Line 43 of the same file says the opposite |
| `AI Settings.transcript_retention_days` = 2555 | 7-year retention | `ComplianceProfile` says 90 (mx) / 30 (in); **neither is enforced** |
| `docs/audit/practitioner/screens/03-encounter.md` | "AI Voice Scribe: disabled (correct)" | AI has been live since ~2026-07-23 |

---

## 14. Verdict on the previous audit (2026-08-20, same day, chat-only)

| Claim | Verdict | Reasoning |
|---|---|---|
| Consent bypass | **CONFIRMED — understated** | 3 code sites + 137/137 sessions consented, 0 in Draft, 133/144 encounters |
| LLM-authored medication masters | **CONFIRMED** | Plus: no review flag, while labs have one and vaccines refuse entirely |
| Prescription frequency loss | **PARTIALLY TRUE** | Mechanism **proved live**; "erases every prescription's frequency" was an overstatement — 110/223 rows still hold one. Scope UNVERIFIED |
| Pediatric vitals thresholds | **CONFIRMED** | And it missed the worse one — fabricated WHO percentiles |
| HPI write-only / AI writes invisibly | **PARTIALLY TRUE** | Path confirmed; **0 of 131** blobs contain `hpi`. Latent, not live |
| Vitals note discarded | **CONFIRMED** | 0/75 |
| No concurrency control | **CONFIRMED (mechanism)** / impact **UNVERIFIED** | No corruption recoverable from data |
| Autosave error swallowed | **CONFIRMED** | |
| AI provenance missing | **PARTIALLY TRUE, was OUTDATED** | `AI Encounter Record` **does** exist (81 rows). The real gap is `tools_detail_json` = 0 and no verdicts |
| Rejections not persisted | **CONFIRMED** — and worse: honoured only on the cached path | |
| Confidence meaningless | **CONFIRMED** | `"confidence": 0.6` literal |
| "Similar cases" unsafe | **CONFIRMED** | No vector store, no cohort data, 144 encounters |
| OpenAI compliance | **CONFIRMED as a documentation conflict**; the DPA fact is **UNVERIFIED** | |
| Patient-summary overwrite | **CONFIRMED** | |
| Unbounded catalog injection | **CONFIRMED + quantified** | 556 entries |
| `enable_safety_validators` dead | **CONFIRMED** | |
| Orphaned streaming code | **CONFIRMED + explained** | Backend reverted by `a711e66`; client left behind |
| Signing friction | **CONFIRMED** | |
| Split transcript across sessions | **FALSE** | 0 encounters affected |
| Blob size risk | **FALSE** | Max 2,926 B |
| "No amendment path" | **PARTIALLY TRUE** | `amended_from` exists on the doctype; no API, no UI, 0 rows |
| July audit's PE1/PR1 (fake AI shown to the doctor) | **PARTIALLY FIXED** | Risk banner gated off ✅; **fabricated insights still render** ❌ |

---

## 15. Prioritised implementation plan

Ordered by clinical risk + data integrity + legal/audit risk + practitioner impact.
**Not** by implementation effort.

### P0 — stop the line

| # | Action | Why |
|---|---|---|
| P0-1 | **Remove the fabrication layer**: `getInsights`/`INSIGHT_POOL` + `insight0-6`/`action0-2`; `useClinicalRecord`'s invented orgs/authors/dates/annotations; the p3/p50/p97 bands **or** the "WHO percentiles" labels; `profLicFor`; `bloodGroupFor`; the dead risk banner | Fabricated clinical data shown to the decision-maker. Pure deletion |
| P0-2 | **Restore consent**: revert `CopilotHost.tsx:74-108`, `CopilotPanel.tsx:101-108`, `api/ai/session/route.ts:34`; thread real consent through the BFF. Then decide what the 137 existing `consent_obtained=1` rows mean | Regulatory, and a false attestation |
| P0-3 | **Medication masters**: remove `ignore_permissions=True`, add the `_flag_lab_for_review` equivalent, or make medications catalog-match-only like vaccines | An LLM authoring pediatric drug strengths |
| P0-4 | **Rx interval**: add `interval` + `interval_uom` to `_serialize_drug_rx`; read them in the FE; audit existing rows | Silent clinical data loss |
| P0-5 | **Pediatric vitals**: age/sex/height-aware thresholds; add a respiratory-rate rule; drop BMI under 2 y. **Needs a clinician, not just an engineer** | Alarm fatigue + missed distress |
| P0-6 | **Vitals note**: persist `vital_signs_note` or remove the textarea | A field that lies about saving |
| P0-7 | **Rx silent drop**: validate `dosage_form`/`period` inline; never filter rows out of a save | Prescriptions vanishing at sign |

### P1 — integrity and compliance

P1-8 persist AI verdicts (accept/edit/reject) and wire `tools_detail_json` ·
P1-9 optimistic concurrency on `save_draft` (send and check `modified`) ·
P1-10 surface autosave errors ·
P1-11 `set_patient_summary` → server-side append/merge ·
P1-12 stamp the signature at sign time ·
P1-13 allergy cross-reactivity table (start with the beta-lactams) ·
P1-14 amendment API on `amended_from` ·
P1-15 find out why 137/137 sessions never reach `Stopped` ·
P1-16 enforce `llm_context_token_budget`; cap catalog injection ·
P1-17 fix the summary cost model (call `_pricing_for_model`) ·
P1-18 **implement retention** — uncomment `scheduler_events` and reconcile the 2555 vs 90/30 conflict ·
P1-19 ADRs for the Rule 5 relaxation and the `raw_response` deviation ·
P1-20 answer the OpenAI DPA question ·
P1-21 constrain `Patient.allergies` to a catalog.

### P2 — workflow

P2-22 sign tail (background review-details, drop the 2.8 s, fold Acknowledge into the report) ·
P2-23 inline validation with a header chief-complaint indicator ·
P2-24 mount the progress rail ·
P2-25 fix the dead "Start" / "New" / `ai-risks` buttons ·
P2-26 remove the 100-row list cap; server-side search ·
P2-27 dedupe the 7 duplicated calls and the encounter→patient waterfall ·
P2-28 auto-open sections that hold data ·
P2-29 separate Cancel from Sign ·
P2-30 the 12 hardcoded strings.

### P3 — architecture cleanup

P3-31 delete everything in §13 marked REMOVE · P3-32 split the 6,625-line component ·
P3-33 decide `AI SOAP Draft` and `generate_suggestions` · P3-34 collapse 5 copies of pricing logic ·
P3-35 investigate the `detected_panels` drift · P3-36 hide the 15 dead encounter fields.

### P4 — future AI

P4-37 structured HPI / exam / plan schema · P4-38 outcome-linked evaluation ·
P4-39 real interaction checking against a licensed database · P4-40 revisit streaming only with
verified nginx behaviour.

---

## 16. User stories

1. **Growth chart.** A pediatrician plots a 2-month-old's 5.5 kg against a "WHO p3 line" that starts
   at 8.05 kg, concludes the baby is failing to thrive, and orders a workup. The line is
   `((2+24)/2)*0.85 − 3`.
2. **Fabricated provenance.** A physician sees *"Penicilina — recorded at Hospital Ángeles by
   Dr. Renata Cruz, 14 Feb 2025"* with the annotation *"Parent reports the reaction has been milder
   since 2025. Recommend re-test before next surgical clearance."* She prescribes amoxicillin partly
   on the strength of it. The hospital, the clinician, the date and the annotation are all
   hash-generated.
3. **Undeletable allergy.** The same physician tries to remove an allergy she knows is wrong. It is
   index 0 and marked `external: true`, so `removeItem` filters it back in and no API call fires.
   It cannot be deleted from the UI.
4. **Frequency loss.** Amoxicillin q8h × 7 days → reload → the frequency field is blank → one
   keystroke elsewhere → autosave writes `interval = NULL`. The pharmacy receives "7 days".
5. **Consent.** A doctor opens a chart to check last week's weight. The microphone opens (permission
   was granted weeks ago, so no prompt). Four minutes of her conversation with a colleague about a
   different child are transcribed and stored indefinitely. The compliance record states the
   guardian consented at 10:42:03.
6. **Vitals note.** The nurse writes *"child crying throughout, BP on 2nd attempt, poor feeding
   ×2 days"*. The header says Saved. Nothing was.
7. **Dropped prescription.** Salbutamol is added without a duration. The row is visible with a
   delete button. It is not in the note, not in the Medication Request, and not on the printed Rx.
8. **Formulary pollution.** "Paracetamol" with no strength during a 7 kg infant's visit → the LLM
   infers a 500 mg tablet → a permanent formulary entry → three weeks later another doctor types
   "parace…", picks the top hit, and prescribes 500 mg to a toddler.
9. **Silent autosave failure.** A chat-added drug fails Link validation. Twenty minutes of charting
   persists nothing; the only signal is one small grey word.
10. **Respiratory rate.** A 2-month-old presents at RR 62. No rule exists for RR. The row renders
    exactly like a normal value, next to a temperature that *is* flagged.
11. **Fabricated insights.** ⌘K → "Ask Narzim AI" shows *"Hgb 9.8 g/dL at last CBC — below range"*
    and *"MMR booster overdue — last given Jun 2025"* for a patient with neither. Two of seven
    strings, selected by `patHash(id, 99)`.
12. **Signature date.** A June encounter is reprinted in August for an insurer and shows August
    beside the practitioner's signature.
13. **Sign tail.** The decision is made. Five clicks and two waits remain, none of them required to
    make the note legally final, while the child's mother waits.
14. **Concurrent tabs.** The nurse adds a lab order. The doctor's older tab autosaves two seconds
    later and replaces the child table. The lab order is gone; neither sees an error.
15. **Summary rewrite.** `set_patient_summary` regenerates the paragraph in English and
    *"reacción a penicilina en 2024"* does not survive the rewrite. The review panel offers one
    **apply** button and no diff.
16. **Vaccine gate.** A doctor cannot sign because a vaccine row is missing a nurse — on a feature
    that has produced zero `Immunization` and zero `Patient Vaccine` records in the system's history.
17. **Missing history.** A covering practitioner opens a colleague's signed note to understand a
    presentation. There is a chief complaint, a diagnosis and orders — no HPI, no examination, no
    plan narrative, because none of those fields has an input control.

---

## 17. Do NOT build yet

| Feature | Why not, specifically |
|---|---|
| **"Similar historical cases" / cohort insights** | No vector store, no cohort data, 144 encounters. Would aggregate other patients' PHI into a decision surface. And §13 shows the codebase can ship synthetic clinical data by accident |
| **Numeric confidence scores** | The field already exists as the literal `0.6` |
| **Medication safety checklist card** (allergy / interaction / contraindication / dose) | Three of the four have no implementation. An unticked box reads as "cleared" |
| **Streaming Analyze** | Correctly reverted (`a711e66`) because buffered streaming fails silently. Do not revive without verifying nginx |
| **Autonomous or multi-turn agents** | Verdicts are not persisted, so there is no supervision signal to learn from |
| **Any RAG / embeddings** | Structured retrieval is not yet bounded or budgeted; adding semantic retrieval on top compounds §5.3 and §5.5 |
| **A 12-state AI session machine** | The current one has never left `Recording`. Fix the lifecycle before enlarging it |
| **Outcome-based AI evaluation / learning loop** | Needs P1-8 first. Today there is no record of what the physician accepted, edited or rejected |
| **Growth-percentile-driven AI insights** | There are no real percentiles to drive them |

---

## 18. Verification method

Everything above is reproducible.

**Code:** `dev` @ the 2026-08-20 pull, both repos (`remedisys_healthcare_ai`, `Healthcare_next_app`).
Files read in full: `encounter-screen.tsx` (6,625), `encounters-client.tsx`, `encounters/[id]/page.tsx`,
`encounter-types.ts`, `copilot/*` (`use-copilot` 615, `real-provider` 1,329, `CopilotHost`,
`CopilotPanel`, `field-mapping`), `NarzimAIChatBar.tsx` (1,356), `stream/*` (851),
`use-clinical-record.ts`, `chart-utils.ts`, `vitals-tab.tsx`, `patient-screen.tsx`,
`command-palette.tsx`, `chart-permissions.ts`, BFF routes under `api/ai/*` and `api/encounters/*`,
`messages/en.json`; backend `api/v1/encounters/api.py` (~2,300), `api/v1/ai/api.py` (1,778),
`api/ai/sessions.py`, `services/ai_tools.py` (1,727), `services/ai.py`,
`services/patient_clinical_summary.py` (2,038), `services/encounter_ai_record.py`,
`integrations/openai.py` (1,539), `hooks.py`.

**Database:** `marley.local`, read-only queries plus one read-only call to
`_fmt_encounter(doc, full=True)` on `HLC-ENC-2026-00003` to prove §4.1. All 61 `Patient Encounter`
fields were counted individually; all 131 SOAP blobs were parsed and their keys tallied.

**Browser:** Playwright against `localhost:3000`, authenticated as an `EB_Practitioner`, loading
`/encounters` and `/encounters/HLC-ENC-2026-00148` while recording every console message, request
failure and response status.

**No production system was touched.** Per project policy all work was on local/staging only.

**State changed by this audit:** one — the `admin@narzim.com` password on `marley.local` was set to
`admin@123` to obtain a practitioner session. No code was modified.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial forensic audit — 18 sections, code + live-DB verified |
