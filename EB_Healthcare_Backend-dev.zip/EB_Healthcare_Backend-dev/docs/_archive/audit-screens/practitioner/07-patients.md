# Practitioner → Patient List / My Panel

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Patients · **Screen 7/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `patients`. Shared directory (`patients-client.tsx`).

## 1. Practitioner lens
- Same directory as front desk/nurse — search/filter real; **no Register** (`canRegister` = frontdesk/admin only) — correct.
- **No "my panel" filter** — a doctor can't filter to *their own* patients (the ones they manage/have encounters with). The list is clinic-wide only.

## 2. REAL vs MOCK vs MISSING
| Element | State | Note |
|---|---|---|
| Directory + search + filters | 🟢 REAL | shared |
| Age shown | 🔴 MISSING (payload has it) | clinically relevant (dosing) — shared P2 |
| **"My patients" filter** | 🔴 MISSING | can't scope to the doctor's own panel |
| Pagination cap 100 | 🟠 shared P1 | |
| Register | 🔒 hidden (correct) | |

## 3. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| PP1 | **No "my panel" filter** (patients this practitioner manages) | Med-High | _pending_ — add a practitioner-scoped filter (patients with an encounter/appointment by me). |
| PP2 | Age not shown (shared P2) | Med | _pending_ — add column. |
| PP3 | Pagination cap (shared P1) | Med | _pending_ — real pagination. |

## 4. Recommended
- **"My panel" filter (PP1)** — a doctor thinks in terms of *their* patients; give them that scope. Everything else = the shared Patient List audit.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
