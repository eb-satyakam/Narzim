# Backend hand-offs from the Practitioner audit (PR-BH)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

Changes that can't be done frontend-only, from the 9-screen practitioner audit. Patient-safety first. Verified against the backend 2026-07-09. `PR-BH-*`; shared items reuse `FD-BH-*` / `NU-BH-*`.

| # | From | Change | Type | Priority | Notes |
|---|---|---|---|---|---|
| **PR-BH-1** | Dashboard PD2 · My Work PW1 · Labs PL1 · Orders PO1 | **Physician clinical inbox / work-feed.** Whitelisted `get_practitioner_worklist()` returning: **unsigned encounters** I own (`Patient Encounter docstatus=0, practitioner=me`), **abnormal labs awaiting my finalize** (`Lab Test docstatus=0` + abnormal + mine), **follow-ups I owe**, **refill requests**, and **order progress** (Service Requests I raised: collected/resulted). Role-filtered variant of the shared work-feed (FD-BH-4 / NU-BH-5). | **API method (shared)** | **High** | The single highest-value physician surface. Partly exists: open-encounters feed is already wired; the abnormal-labs + order-progress slices are net-new. Never lose an un-actioned result. |
| **PR-BH-2** | Medications PM1 (PR2) | **Wire `/medications` to `list_medications`** (real formulary) or remove the route. Today it renders `MEDICINE_MASTER` (hardcoded, 0 API calls). If kept, the in-encounter Rx picker must also use `list_medications` (verify PM5). | **FE wiring / API verify** | **High** | Mostly FE (endpoint exists) — but confirm the encounter Rx search is backend-backed, not another local list. A fake drug reference is a safety/trust defect. |
| **PR-BH-3** | Medications PM2 (PR3) | **Standalone prescription management** — decide + build: `list_patient_prescriptions` (exists) surfaced as a real `/prescriptions` screen, plus refill-without-encounter if in scope. Or remove the placeholder route. | **API + screen (or decision)** | Med-High | Today `/prescriptions` is a coming-soon stub; prescribing is encounter-only. |
| **PR-BH-4** | Medications PM3 | **Pediatric weight-based dosing.** Dose calculation from the patient's latest weight (Vital Signs) for a given drug — the flagship pediatric feature (ROADMAP 11). | **API method** | Med | Needs latest-weight lookup + per-drug mg/kg rules. Real product differentiator. |
| **PR-BH-5** | Patients PP1 | **"My panel" filter** on `list_patients` — scope to patients with an encounter/appointment by the calling practitioner. | **API param** | Med | Lets a doctor see their own panel, not clinic-wide only. |
| **PR-BH-6** | Encounter PE3 | **Amend-after-sign** path — confirm/expose a core amendment flow for a signed (docstatus=1) Patient Encounter (correction with audit trail), or document cancel+re-document as the intended path. | **API verify + decision** | Med | Compliance: signed notes need a correction mechanism. |

## Cross-references (fixes owned by other audits, but they affect the physician)
- **PR1 / PD1 / PE1 / PC1 — fabricated AI risk banner + insights ON for practitioner** → **FRONTEND-ONLY** (flip `chart-permissions.practitioner.overview.showRiskBanner`/`showAiInsights` to false until Phase 5). *Critical, but not a backend hand-off.*
- **NV1 / NU-BH-1 — vitals mis-binding** → the doctor signs whatever the nurse bound; fixed by the nurse hand-off.
- **NL1 / NU-BH-3 — nurse + front desk also hold `Lab Test submit`** → fixed on their side; the physician's finalize grant is correct.

## Backend-alignment check (verified)
- **PR-BH-1** feasible — `get_my_tasks` + open-encounters feed already exist; abnormal-labs/order-progress are additive queries.
- **PR-BH-2** — `list_medications` exists and is ignored by the mock screen; mostly FE.
- **PR-BH-3** — `list_patient_prescriptions` exists (backend ready); needs a real screen.
- **PR-BH-5** — `list_patients` already supports filters; add a practitioner scope.
- Physician `Lab Test submit` grant confirmed present (correct).

## Grouping for planning
- **Safety/trust (do first):** the FE AI-flag flip (PR1 — not a hand-off but critical), PR-BH-2 (real formulary).
- **Highest clinical value:** PR-BH-1 (clinical inbox).
- **Product:** PR-BH-4 (weight-based dosing), PR-BH-3 (standalone Rx), PR-BH-5 (my panel), PR-BH-6 (amend).

_Spec only. Nothing implemented._

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
