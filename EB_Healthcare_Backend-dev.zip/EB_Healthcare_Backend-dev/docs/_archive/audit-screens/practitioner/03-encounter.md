# Practitioner → Encounter authoring + Sign

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 3/9** · [index](../../../audit/practitioner/README.md)
**Role:** `EB_Practitioner` · route `/encounters/[id]`.
**Frontend:** `encounter-screen.tsx` (`canSign=true` for practitioner); hooks `start_encounter` / `save_draft` / `complete_encounter`.
**Backend:** `api/v1/encounters/api.py`.
**Professional lens:** this is the physician's core act — document, order, diagnose, **sign.** Signing is the moment the note becomes the legal record and spawns the order layer. Authoring + sign are real and correctly gated. The risks are what feeds the decision (fake AI, mis-bound vitals) and what the order layer does downstream.

## 1. Doctype / API mapping
| Element | DocType | API method |
|---|---|---|
| Open/own encounter | Patient Encounter (docstatus 0) | `start_encounter` / `create_encounter` |
| Author draft (SOAP + orders) | Patient Encounter + child tables | `save_draft` |
| **Sign / complete** (0→1) | Patient Encounter | `complete_encounter` |
| On submit → order layer | Service Request + Medication Request + Therapy Plan | core `on_submit` |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Author SOAP (chief complaint, notes) | 🟢 REAL | merged to `encounter_comment` blob |
| **Orders in encounter** (Rx / labs / procedures / therapies) | 🟢 REAL | mapped to `drug_prescription` / `lab_test_prescription` / `procedure_prescription` / `therapies` child tables (encounter-screen L60–100) |
| Diagnosis / symptoms | 🟢 REAL | child tables |
| **Sign (physician-only)** | 🟢 **REAL + gated** | `canSign = practitioner || admin`; backend `_require_assigned_practitioner_or_admin` — double-enforced |
| **On sign → Service/Medication Requests + Therapy Plan spawn** | 🟢 REAL (core) | native `on_submit` order layer (ADR-019) |
| Read-only after submit | 🟢 REAL | `readOnly = docstatus===1` |
| **Fabricated AI risk banner + insights** | 🔴 **PR1 (SAFETY)** | `chart-permissions.practitioner.overview` → `showRiskBanner:true`, `showAiInsights:true`; `patHash`-mock rendered to the decision-maker |
| **Vitals the doctor signs may be mis-bound** | 🔴 **NV1/B1 inherited** | if the nurse's vitals cross-linked (walk-in / 2 same-day visits), the doctor signs a note with the wrong vitals |
| AI Voice Scribe | 🔴 disabled (correct) | commented out (Phase 5) |

## 3. The sign boundary (deep dive)
- **Sign is real and physician-only** — verified both layers (FE `canSign`, BE `_require_assigned_practitioner_or_admin`). Good: Rule 6 holds for encounter finalization.
- **What sign triggers:** core `on_submit` creates one Service Request per lab/procedure/therapy line + one Medication Request per drug + a Therapy Plan. So the physician's signature is what turns *orders written in the note* into *actionable order documents*. This is correct core composition — but it means the **prescription only becomes "real" on sign** (see medications screen 04: there's no standalone Rx surface, so an unsigned draft = no medication request yet).
- **Amendment:** once signed (docstatus 1), the note is read-only; correcting it requires a core amendment flow — confirm the physician has a path to amend a signed encounter (or that cancel+re-document is the intended correction).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **PE1 (PR1)** | **Fake AI risk banner + insights shown to the physician** — the exact audience who must trust clinical data, seeing `patHash` fabrication; also a Phase-5 violation | Safety / phase | **Critical** | _pending_ — remove/hide fabricated AI surfaces for practitioner (flip `showRiskBanner`/`showAiInsights` off until real, Phase 5). |
| **PE2 (NV1)** | **Doctor signs vitals that may be mis-bound** (inherits nurse NV1/B1) | Safety | **High** | _pending_ — fixed by NU-BH-1 (vitals binding); until then the signed note can carry wrong vitals. |
| PE3 | **Amend-after-sign path** unclear | Clinical / compliance | Med | _pending_ — confirm the physician can amend a signed encounter (correction with audit trail) vs cancel+redo. |
| PE4 | Encounter authoring i18n / autosave-vs-explicit-save, nurse+doctor concurrent edit (shared NE2) | UX | Med | _pending_ — confirm concurrency behavior. |

## 5. Alignment with core
- Composes core Patient Encounter + native order-layer spawn on submit (ADR-019). The draft-save fights core's premature appointment-close (`_restore_appointment_status_if_draft`). Aligned — strong.

## 6. Recommended options (curated)
- **PE1 first (remove fake AI for the doctor)** — a physician cannot be shown fabricated risk/insights; it's both a trust and a phase-rule failure, and the doctor is the worst audience for it.
- **PE2 (vitals binding)** rides on the nurse fix (NU-BH-1).
- **NOT recommended:** loosening the sign gate or adding AI clinical suggestions before Phase 5. The sign boundary is correct — protect it.

## 7. Open questions for product owner
1. **PE1:** Confirm the AI risk banner + insights are removed for the practitioner until the real Phase-5 AI ships. (Recommend yes — hard requirement.)
2. **PE3:** What's the correction path for a signed encounter — core amendment, or cancel + re-document?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
