# Practitioner Audit — Decision Sheet

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

Every gap from the 9 practitioner screens, ranked, with a `▶ REC:` to accept/override. Physician-in-control + real-clinical-data first. FE = frontend-only · BE = backend (`BACKEND_HANDOFFS.md`). Verified against backend 2026-07-09.

## Tier 0 — Critical (safety / physician trusts fake data)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| PR1 (PD1/PE1/PC1) | Chart/Encounter/Dashboard | **Fabricated AI risk banner + insights explicitly ON for the physician** (`patHash` mock, pre-Phase-5) | Flip `showRiskBanner`/`showAiInsights` **off** for practitioner until real | FE | ▶ REC: **W1 — remove now** (worst audience for fake clinical data + phase violation) |
| PR2/PM1 | Medications | **`/medications` is fully mock** (`MEDICINE_MASTER`, 0 API calls) — physician-only fake formulary | Wire to `list_medications` or remove route (PR-BH-2) | FE | ▶ REC: **W1 — wire or pull** |
| NV1 (inherited) | Encounter | Doctor signs vitals that may be mis-bound (nurse NV1/B1) | Fixed by NU-BH-1 | BE | ▶ REC: ✅ via nurse fix |

## Tier 1 — High (core physician function)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| PD2/PW1/PL1 | Dashboard/MyWork/Labs | **No physician clinical inbox** (unsigned notes, abnormal results to review, refills, follow-ups) | Build `get_practitioner_worklist` (PR-BH-1) | BE+FE | ▶ REC: ✅ **highest clinical value** — one shared work-feed, role-filtered |
| PM5 | Medications | Confirm in-encounter Rx picker uses real `list_medications` | Verify/fix | FE | ▶ REC: ✅ verify (the path that matters) |
| PN1/N1 | Comms | Notifications hidden — no alert for abnormal result / note-to-sign | Unhide bell/panel | FE | ▶ REC: W1 |
| PD3 | Dashboard | Ops-shaped, not clinical (no "my ready patients" focus, money surfaced) | Shape practitioner view around ready-patients + safety + inbox | FE | ▶ REC: ✅ after inbox |

## Tier 2 — Medium (completeness / role scope)
| # | Screen | Finding | Recommendation | Decision |
|---|---|---|---|---|
| PM2/PR3 | Medications | `/prescriptions` placeholder; no standalone Rx/refill | Build over `list_patient_prescriptions` or remove nav (PR-BH-3) | ▶ REC: ✅ decide scope |
| PM3 | Medications | No pediatric weight-based dosing | Dose calc from latest weight (PR-BH-4) | ▶ REC: ✅ flagship pediatric feature |
| PP1 | Patients | No "my panel" filter | Practitioner-scoped list (PR-BH-5) | ▶ REC: ✅ |
| PO1 | Orders | No post-sign order tracking | Surface Service Request progress (in inbox) | ▶ REC: ✅ with PR-BH-1 |
| PE3/PR-BH-6 | Encounter | Amend-after-sign path unclear | Confirm core amendment vs cancel+redo | ▶ REC: ✅ verify |
| PC2/PR4/PD5 | Chart/Dashboard | Physician `collectPayment=true` (role-bleed?) | Confirm intended vs remove | ▶ REC: decide (recommend remove — money is front-desk) |
| PL2 | Labs | Abnormal-flag surfacing at review — verify | Confirm reference-range cues | ▶ REC: ✅ verify |

## Tier 3 — Low / shared
| # | Screen | Finding | Decision |
|---|---|---|---|
| PP2/PP3/PD4 | Patients/Dashboard | Age not shown (dosing), pagination cap, wait-time hidden | ▶ REC: W1/✅ shared FE fixes |
| PC3 | Chart | History feed ≠ core Patient Medical Record | ▶ REC: ⏸ consider native timeline |
| PO2 | Orders | Referral-out surfaced? | ▶ REC: verify |
| PN2 | Comms | Team chat = doctor's lane; confirm | ▶ REC: confirm |

---

## Do we need MORE options for the practitioner?
**No new *screens* — the physician surface is scoped right; it needs to be made REAL and given a clinical inbox.** The doctor's flow (chart → encounter → order → prescribe → sign → finalize) all exists; the failures are fake data and a missing inbox, not missing features.
- **Add (completes the role):** the **clinical inbox** (unsigned notes + abnormal results), a **real formulary**, **weight-based dosing**, a **"my panel"** filter.
- **Make real (not add):** the AI/risk cues (remove until Phase 5), `/medications` (wire), `/prescriptions` (build or drop).
- **Deliberately NOT adding:** ops KPIs / revenue view for the doctor, AI clinical suggestions before Phase 5, a standalone orders module (encounter-bound is correct), patient WhatsApp inbox by default.
- **Remove, don't add:** physician `collectPayment` (PR4) — money is front-desk's job.

**One-line:** the doctor doesn't need more surfaces — they need the ones they have to show **true data** and to **never lose an un-signed note or an abnormal result**.

## Decisions that unlock the most
1. **PR1 (flip fake AI off)** — trivial FE, closes a Critical safety + phase violation across 3 screens.
2. **PR-BH-1 (clinical inbox)** — the highest-value physician build; shared work-feed backend, role-filtered (also serves nurse NU-BH-5 + FD FD-BH-4).
3. **PR-BH-2 (real `/medications`)** — kill the mock formulary.

## Open questions for product owner
1. **PR1:** Confirm AI risk/insights are off for the physician until Phase 5. (Hard requirement.)
2. **PR4:** Should a physician collect payment, or is that front-desk-only?
3. **PR-BH-1:** Confirm clinical-inbox categories (unsigned encounters · abnormal labs to finalize · refills · follow-ups · order progress).
4. **PM3:** Prioritize pediatric weight-based dosing?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
