# Nurse → Encounter Draft (open / save, no sign)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 7/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `/encounters/[id]` (nurse-allowed).
**Frontend:** `encounter-screen.tsx` (shared; `canSign` prop gates signing); hooks for `start_encounter` / `save_draft`.
**Backend:** `api/v1/encounters/api.py` — `start_encounter` / `create_encounter` / `save_draft` / `complete_encounter`.
**Professional lens:** the nurse preps the note — she opens the draft, records what she can, and hands off; **the physician signs.** This is the ADR-022 boundary, and it is **correctly enforced on both sides** — the strongest safety story in the nurse audit.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Open/create draft encounter | Patient Encounter (docstatus 0) | `start_encounter` / `create_encounter` | `/api/encounters` |
| Save draft (SOAP + child tables) | Patient Encounter | `save_draft` | `PATCH /api/encounters/[id]` |
| **Sign / complete** (submit 0→1) | Patient Encounter | `complete_encounter` | `POST …/complete` |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Open draft from dashboard/queue | 🟢 **REAL** | `start_encounter` (idempotent); nurse "move to practitioner" / "open encounter" (ADR-022) |
| **Save draft** (SOAP blob + child tables) | 🟢 **REAL** | `save_draft` — `require_permission("Patient Encounter","write")`, **only docstatus=0** |
| Draft content: chief complaint / SOAP, drug / lab / procedure / therapy / symptoms / diagnosis child tables | 🟢 REAL | merged into `encounter_comment` blob + child tables |
| Vaccines in draft (ADR-019) | 🟢 REAL | stored in the SOAP blob (not a child table) |
| **Sign button — hidden for nurse** | 🟢 **REAL (safety)** | `canSign = roles.includes("practitioner") || "admin"` (encounters/[id]/page.tsx:22) → **false for nurse**; Sign renders only `!readOnly && !signed && canSign` |
| **Backend sign gate** | 🟢 **REAL (safety)** | `complete_encounter` → `_require_assigned_practitioner_or_admin(doc)` raises `PermissionError` for a nurse → **double-gated (FE + BE)** |
| Read-only after submit | 🟢 REAL | `readOnly = docstatus === 1` |
| AI Voice Scribe | 🔴 disabled | commented out (encounter-screen.tsx:1212, "not part of current release") — correct (Phase 5) |

## 3. The ADR-022 boundary (deep dive — this is the safety centerpiece)
Verified on both layers:
- **Frontend:** `canSign` is derived purely from role (`practitioner || admin`). A nurse reaching the encounter (via `canEditEncounterDraft`) sees the **Save Draft** button but **not Sign**. `save_draft` is allowed; sign is not rendered.
- **Backend:** even if the FE were bypassed, `complete_encounter` calls `_require_assigned_practitioner_or_admin` and throws `PermissionError` unless the caller is the assigned practitioner (or admin). So a nurse **cannot** submit the encounter by any path.
- **On submit (physician only):** service requests + medication requests + therapy plan spawn (the order layer) — the nurse never triggers this.
**Verdict:** physician-in-control (Rule 6) is genuinely enforced here — not just a UI hide. This is the model the labs finalize-gate (NL1) should match.

## 4. Permissions
- Nurse: Patient Encounter **create + write** (draft), **no submit** (the `_require_assigned_practitioner_or_admin` gate). Route `/encounters` nurse-allowed. Correct.

## 5. Alignment with core
- Composes core Patient Encounter; draft-save fights core's premature appointment-close (`_restore_appointment_status_if_draft`) — the app-level workaround for a core side-effect (Rule 1, can't edit core). Encounter → order-layer spawn on submit is native core (ADR-019). Aligned.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| NE1 | **What can a nurse edit in the draft vs the physician?** Today the nurse can write into *all* draft sections (diagnosis, drug prescription, etc.), not just intake/vitals. | Role scope | **Med** | _pending_ — decide whether the nurse's draft-write should be scoped (intake/symptoms/vitals) vs full SOAP. She can't *sign*, but she can *author* diagnosis/Rx text a physician might rubber-stamp. |
| NE2 | Draft autosave vs explicit save; concurrent nurse+physician on same draft | UX / concurrency | Med | _pending_ — confirm behavior if nurse and physician open the same draft (last-write-wins?). |
| NE3 | Vaccines live in the SOAP blob (ADR-019), not a child table | Data shape | Low | _pending_ — accepted per ADR-019; note for reporting. |

## 7. Recommended options (curated)
- **Scope the nurse's draft-write (NE1)** — the one real decision: prep is intake (symptoms, vitals, history), not authoring diagnosis/prescription. Even without sign power, letting a nurse pre-fill the clinical decision fields invites rubber-stamping. Recommend limiting nurse-editable draft sections.
- **NOT recommended:** any path that lets a nurse complete/submit — the double-gate is correct; keep it. Don't add AI scribe before Phase 5 (correctly disabled).

## 8. Open questions for product owner
1. **NE1:** Should the nurse's encounter-draft editing be **scoped to intake** (symptoms/vitals/history) rather than the full SOAP incl. diagnosis/prescription? (Recommend scoped — prep, not clinical authoring.)
2. **NE2:** Desired behavior when nurse + physician edit the same draft concurrently?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
