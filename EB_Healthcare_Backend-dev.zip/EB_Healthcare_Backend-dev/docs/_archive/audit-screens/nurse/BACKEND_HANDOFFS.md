# Backend hand-offs from the Nurse audit (NU-BH)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

Changes that **cannot be done frontend-only**, from the 10-screen nurse audit. Each cites the screen/gap. **Nothing implemented — spec only.** Patient-safety items rank first.

IDs are `NU-BH-*`. Shared items reuse the front-desk `FD-BH-*` where the same backend serves both.

| # | From | Change | Type | Priority | Notes |
|---|---|---|---|---|---|
| **NU-BH-1** | Vitals NV1 / core B1 | **Fix vitals→encounter binding.** Tighten `_link_vitals_to_encounter` (encounters/api.py): require appointment scoping; when the encounter has **no appointment** (walk-in), do **not** auto-link every same-patient/same-day vitals — link only vitals with no appointment *and* refuse the auto-link when **>1 candidate encounter exists that day** (surface for manual selection). Add an explicit `link_vitals(vital_signs, encounter)` for the manual case. | **API fix + method** | **Critical (safety)** | The top item in the whole nurse audit. Wrong vitals can land on a note the physician signs. Verified in the heuristic (guard skipped when `enc.appointment` is falsy). |
| **NU-BH-2** | Vitals NV2 | **Real pediatric growth percentiles.** Replace the hardcoded chart bands with age/sex-normalized percentile + z-score computation against a real standard (WHO 0–5 + CDC 2–20, or Mexican NOM-031/NOM-008). Whitelisted `get_growth_percentiles(patient)` returning per-measurement percentile/z-score, or ship the reference tables the FE plots against. | **API + reference data** | **High (clinical)** | Growth monitoring is a primary pediatric nurse function; fabricated bands are clinically misleading. Jurisdiction: MX default, IN per ADR-018. |
| **NU-BH-3** | Labs NL1 | **Lock the labs finalize gate — CONFIRMED BUG.** Remove `submit` on **Lab Test** from `EB_Nurse` **and `EB_Front Desk`** via a DocPerm patch; keep `write`. Finalize (`submit_lab_result`) must be physician/admin only. | **DocPerm patch** | **High (safety) — CONFIRMED** | Verified in `remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json`: **`EB_Nurse` has `submit:1`** on Lab Test (and so does **`EB_Front Desk`** — a non-clinical role finalizing labs). `submit_lab_result`'s "physician finalizes" is only a code comment; the grant makes it bypassable. Rule 6 is **not enforced today.** Patch via a new migration (ADR-004: never hand-edit the spec). |
| **NU-BH-4** | Labs NL2 / core NU2 | **Converge the lab creation path.** Standardize on the Service-Request-anchored flow; either deprecate direct `create_lab_order` or add a guard so a direct order + an SR for the same template/patient/day cannot both spawn a Lab Test. | **API guard/decision** | Med-High | Prevents duplicate/orphan Lab Tests for one order (dual-path risk). |
| **NU-BH-5** | Dashboard ND2 / My Work NW1 (= FD-BH-4 nurse variant) | **Nurse clinical work-feed.** Extend the front-desk work-feed method (FD-BH-4) with a nurse role filter returning: checked-in-without-vitals, immunizations-due-by-age (EPI schedule vs DOB), labs-to-draw / awaiting-result, drafts-to-prep. | **API method (shared)** | **High** | One backend, role-filtered; powers both the nurse dashboard chips (ND2) and My Work (NW1). |
| **NU-BH-6** | Immunizations NI1 | **Allergy/contraindication check at administration.** Surface the patient's allergies (+ basic contraindication flags) at the point of recording a vaccine dose — read from clinical allergies; warn before record. | **API field/verify** | Med-High (safety) | A nurse should see allergies before injecting. May be FE reading existing allergy data + a warn step. |
| **NU-BH-7** | Immunizations NI2 | **Vaccine lot / expiry / manufacturer capture.** Confirm whether `Immunization` stores lot number, expiry, manufacturer; add fields (custom fields via fixtures, Rule 1) if missing. | **Doctype fields (verify)** | Med | Recall traceability / regulatory (NOM). |
| **NU-BH-8** | Encounter NE1 | **Scope nurse draft-write.** Decide + enforce which encounter draft sections a nurse may edit (intake: symptoms/vitals/history) vs physician-only (diagnosis, drug/procedure prescription). Enforce server-side in `save_draft` by role, not just UI. | **API + decision** | Med | She can't *sign*, but authoring diagnosis/Rx invites rubber-stamping. Prep ≠ clinical authoring. |

## Backend-alignment check (verified 2026-07-09)
Every hand-off was checked against the actual backend — all align; two are **cheaper than first flagged**, one is a **confirmed bug**:
- **NU-BH-3 — CONFIRMED bug** (not a "verify"): `EB_Nurse` + `EB_Front Desk` both hold `Lab Test submit`. Rule 6 unenforced. DocPerm patch needed.
- **NU-BH-5 — feasible, partly exists:** `tasks.get_my_tasks` already returns assigned Nursing Tasks; the immunization **schedule/due-by-age is backend-computed** (`_dose_age_fields`, age_months). So "vaccines-due" leans on existing logic; only the *proactive* queries (checked-in-without-vitals, labs-to-draw) are net-new.
- **NU-BH-6 — cheaper than flagged:** `clinical.list_allergies(patient)` already exists — the allergy check at administration is mostly FE reading it + a warn step, not new backend.
- **NU-BH-1/2/4/7/8** — as specced; NU-BH-2 (growth curves) is the only one needing new reference data.

## Grouping for planning
- **Patient-safety (do first):** NU-BH-1 (vitals binding), NU-BH-3 (labs finalize perm), NU-BH-6 (allergy check), NU-BH-8 (draft scope).
- **Clinical accuracy:** NU-BH-2 (growth curves), NU-BH-4 (lab path), NU-BH-7 (lot/expiry).
- **Operations:** NU-BH-5 (nurse work-feed — shared FD-BH-4).

## Frontend-only (NOT hand-offs)
Wire the "record vitals" overview CTA (NC1) · **remove the fabricated AI risk banner if it renders for nurse (NC2)** · unhide notifications (NN1) · add check-in/mark-ready to the appointments list (NA1) · Age column on patient list (NP1) · i18n (NC3/NI3/NA2/NN3).

_Spec only. Updated as decisions are made._

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
