# Nurse → Patient Chart 360 (nurse view)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Patients · **Screen 3/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `patients/[id]`.
**Frontend:** `patient-chart-client.tsx` / `patient-screen.tsx` → `overview-nurse.tsx` + clinical tabs.
**Professional lens:** the nurse's chart is a clinical prep view — vitals, meds, allergies, immunizations, a handoff checklist. Gating is **correct** (financial hidden), and the nurse overview is purpose-built. Gaps: one toast-stub action, i18n, and the shared fake-AI banner risk.

## 1. Tab gating (nurse, verified)
`chart-permissions.ts`: nurse **hides `financial` section + `summary` subtab** → lands on Appointments; sees **Vitals, Lab Test, Medications, Immunizations, History, Documents** + **`overview-nurse`**. No billing (correct — money is front-desk). This is the right inverse of the front-desk chart (which over-exposed clinical + showed a fake risk banner).

## 2. overview-nurse — REAL vs MOCK
| Element | State | Evidence |
|---|---|---|
| **Vitals grid** (BP/HR/Temp/SpO₂/Wt/RR) | 🟢 REAL | from `patient.vitals` |
| **Handoff checklist** (vitals recorded · meds verified · allergies confirmed · last encounter reviewed) | 🟢 REAL (derived) | from `usePatientMedications`, `useEncounters`, allergies, vitals |
| "Patient checked in — record vitals before handoff" prompt | 🟢 REAL (gated) | shows when checked-in + no vitals |
| **"Record vitals" action** | 🔴 **TOAST STUB** | `onClick={() => onFlash?.("Opening vitals intake…")}` — doesn't open vitals intake (cf. FD Print-Receipt stub) |
| i18n | 🟡 **hardcoded English** | grid labels + prompt text literal (no `useTranslations`) |
| Clinical tabs (Vitals/Labs/Meds/Immunizations/History) | 🟢 REAL | see screens 04–06 |
| **Fabricated AI risk banner** | 🔴 **shared C1 risk** | if the `patHash` risk banner renders for nurse too, same phase-violation as FD C1 — verify + remove |

## 3. Permissions
- Financial hidden; clinical visible; nurse can edit vitals (screen 04) + draft (screen 07), record labs/immunizations. No billing. Aligned — clean clinical scope.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| NC1 | **"Record vitals" is a toast stub** — the nurse's primary overview CTA doesn't work | Mock (FD1) | **High** | _pending_ — wire it to the vitals intake (screen 04 entry). |
| NC2 | **Fabricated AI risk banner** may render for nurse (shared C1) | Mock / phase violation | **High** | _pending_ — verify + remove (same as FD C1/C5). |
| NC3 | **overview-nurse hardcoded English** | i18n (FD6) | Med | _pending_ — catalogs. |
| NC4 | Handoff checklist is display-only (no persist / no "mark done") | UX | Low | _pending_ — optional: persist checklist state. |

## 5. Recommended options (curated)
- **Wire the "record vitals" CTA (NC1)** — the overview's main nurse action is dead; fix first.
- **Remove the fake AI banner (NC2)** if it renders for nurse — same trust/phase issue as FD.
- **NOT recommended:** exposing financial/billing on the nurse chart — correctly hidden; keep it.

## 6. Open questions for product owner
1. Confirm the fabricated risk banner does/doesn't render for nurse — remove either way (C1/C5).
2. Should the handoff checklist persist (auditable "vitals done / allergies confirmed"), or stay a visual aid?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
