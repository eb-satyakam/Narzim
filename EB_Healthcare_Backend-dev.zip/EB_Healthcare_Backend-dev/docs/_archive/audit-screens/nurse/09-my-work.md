# Nurse → My Work / Nursing Tasks

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Work · **Screen 9/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `inbox`.
**Frontend:** `work-inbox-client.tsx`; hooks `useMyWorkFeed` → `tasks.get_my_tasks`.
**Professional lens:** for the nurse this is the closest thing to a real worklist — and unlike the front-desk case, **nursing tasks are actually in the feed**. The gap is the *proactive clinical* categories (vitals-pending, vaccines-due, labs-to-draw) that a nurse plans her room around.

## 1. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| **Nursing tasks in the feed** | 🟢 **REAL** | `feedData.nursing_tasks` mapped to inbox items; dedicated "Nursing Task" filter |
| Todos (create/edit/delete/assign) | 🟢 REAL CRUD | `useMyTodos` |
| Notes (autosave CRUD) | 🟢 REAL CRUD | `useMyNotes` |
| Clinical procedures / open encounters in feed | 🟢 REAL | from `get_my_tasks` + open encounters |
| i18n | 🟢 REAL | `useTranslations("myWork")` |
| **Proactive clinical worklist** (vitals-pending, vaccines-due today, labs-to-draw) | 🔴 **MISSING** | the operational `ItemType`s are display-only config with no data source (shared D3/MW1) — nurse variant absent |

## 2. What's better than the front-desk case
The front-desk My Work had **no** operational feed at all; the nurse at least gets **real assigned nursing tasks** (from `get_my_tasks`). So the nurse worklist is partially real — it shows what's *assigned*, just not what's *clinically due* (vitals not yet taken, immunizations due by age, pending lab draws).

## 3. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| NW1 | **No proactive clinical worklist** — vitals-pending / vaccines-due / labs-to-draw not surfaced (shared D3/MW1) | Missing | **High** | _pending_ — the front-desk work-feed backend (FD-BH-4) needs a **nurse variant**: patients checked-in-without-vitals, immunizations due by age, submitted lab orders awaiting result/collection. Powers dashboard ND2 too. |
| NW2 | Non-task "done" is client-only dismiss (shared MW2) | Low | _pending_ — accept for deep-links. |

## 4. Recommended options (curated)
- **Nurse work-feed variant (NW1)** — the single highest-value nurse addition: turn My Work + dashboard chips into an actionable clinical worklist. One backend (FD-BH-4, role-filtered), two surfaces.
- **NOT recommended:** more manual todo features — the CRUD is fine; the value is auto-populating clinical due-items from real state (appointments without vitals, EPI schedule, pending labs).

## 5. Open questions for product owner
1. Confirm the nurse work-feed categories: **checked-in-without-vitals · immunizations-due-by-age · labs-to-draw/awaiting-result · drafts-to-prep.** Source queries for each?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
