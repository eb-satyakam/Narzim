# Nurse → Lab Collection / Results

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 5/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `/labs` (nurse-allowed) + chart Lab tab.
**Frontend:** `lab-center-tab.tsx`, `lab-result-entry-dialog.tsx`, `lab-order-dialog.tsx`, `lab-panel-upload-view.tsx`; hooks `use-labs.ts`.
**Backend:** `api/v1/labs/api.py` (+ `services/labs.py`).
**Professional lens:** the nurse orders/collects and **enters** results; the physician **finalizes** them (Rule 6). The write/finalize split is correctly modeled in the API. The risks are the dual creation path (duplicate/orphan Lab Tests) and confirming the finalize gate is actually enforced by permission, not just intent.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| Pending lab orders (worklist) | Service Request (Lab) | `list_pending_lab_orders` | `/api/labs` |
| Order a lab (direct) | Lab Test | `create_lab_order` | `/api/labs/panel-create-order` |
| Record result values (draft) | Lab Test + result rows | `record_result` | `/api/labs/results` |
| Record imaging (free-text) | Lab Test.descriptive_result | `record_imaging_result` | `/api/labs/imaging-result` |
| **Finalize** result (submit 0→1) | Lab Test | `submit_lab_result` | `/api/labs/submit` |
| Trends | Lab Test history | `get_lab_trends` | — |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Pending lab worklist (SR-anchored) | 🟢 **REAL** | `list_pending_lab_orders` → submitted Service Requests awaiting results |
| Record result values (nurse, **does not finalize**) | 🟢 **REAL** | `record_result` writes onto a Draft Lab Test; "does not finalize — Rule 6"; `lab-result-entry-dialog.tsx` wired |
| Imaging free-text result | 🟢 REAL | `record_imaging_result` (ADR-019 G14b) |
| Order a lab | 🟢 REAL | `create_lab_order` from template |
| Panel upload/extraction | 🟢 REAL | `lab-panel-upload-view.tsx` + panel routes |
| **Finalize = physician only** | 🟢 REAL (intent) | `submit_lab_result` = "physician finalizes"; `require_permission("Lab Test","submit")` |
| i18n | 🟢 REAL | `useTranslations("chart.labs")` |
| **Dual creation path** | 🟠 **duplicate/orphan risk (NU2)** | `create_lab_order` (direct Lab Test) **and** `record_result` (creates Lab Test from Service Request via `ensure_lab_test_for_service_request`) — two ways to get a Lab Test for one order |
| **Finalize permission actually denied to nurse?** | 🟠 **VERIFY (safety)** | the API gates on `Lab Test submit` perm; Rule 6 holds **only if nurse's DocPerm lacks `submit`**. If nurse has submit, she could finalize her own reading. Needs DocPerm confirmation. |

## 3. Actions & wiring (nurse)
| Action | Wired? | Note |
|---|---|---|
| See pending orders | ✅ real | SR-anchored worklist |
| Collect / order lab | ✅ real | `create_lab_order` |
| Enter result values | ✅ real | `record_result` — **draft only** (correct) |
| Enter imaging report | ✅ real | free-text |
| **Finalize / approve** | 🔒 physician | nurse should NOT — verify DocPerm |

## 4. Permissions & safety
- Nurse: `Lab Test write` (record). Finalize is `Lab Test submit` (physician). **The Rule-6 boundary depends on the DocPerm spec denying nurse `submit`** — the API check is correct, but enforcement = the grant. **Open safety item: confirm `EB_Nurse` has write but NOT submit on Lab Test.**

## 5. Alignment with core
- SR-anchored path composes core (Service Request → Lab Test → result → approve). The **direct `create_lab_order`** bypasses the Service Request layer — that's the NU2 dual-path divergence (front-desk OPD trace). Both produce a core Lab Test, but reconciliation of "one order → one Lab Test" isn't guaranteed across the two paths.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **NL1** | **Confirm nurse cannot finalize** (`Lab Test submit` denied in DocPerm). If she can, Rule 6 is bypassable. | Safety / perm | **High** | _pending_ — audit `EB_Nurse` DocPerm on Lab Test; grant write, deny submit. Backend hand-off **NU-BH-3** if not already so. |
| **NL2 (NU2)** | **Dual creation path** (direct vs SR-anchored) → possible duplicate/orphan Lab Test for one order | Integrity | **Med-High** | _pending_ — converge on the SR-anchored path (or add a guard so a direct order + an SR for the same template can't both spawn a Lab Test). |
| NL3 | Result entry / worklist reachability for nurse in the UI (confirm the nurse's route to `lab-result-entry-dialog` from `/labs`) | UX | Med | _pending_ — verify the nurse's click-path to enter a pending result. |
| NL4 | Abnormal-flag / reference-range surfacing at entry (does the nurse see abnormal cues while entering?) | Clinical UX | Med | _pending_ — confirm reference ranges/abnormal flags render during result entry. |

## 7. Recommended options (curated)
- **Lock the Rule-6 boundary (NL1)** — the one safety item: nurse records, physician finalizes; prove it in DocPerm, not just the comment.
- **Converge the lab creation path (NL2)** to avoid duplicate Lab Tests.
- **NOT recommended:** letting the nurse approve/finalize results, even as a "convenience" — that's the physician's clinical sign-off (Rule 6).

## 8. Open questions for product owner
1. **NL1:** Confirm nurses must never finalize a lab result (physician-only). (Recommend yes — Rule 6.)
2. **NL2:** Standardize on the Service-Request-anchored lab flow and deprecate direct `create_lab_order`, or keep both with a dedup guard?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
