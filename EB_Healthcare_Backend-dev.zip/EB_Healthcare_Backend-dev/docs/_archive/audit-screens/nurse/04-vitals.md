# Nurse → Vitals Entry

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 4/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · via Patient Chart → Vitals tab (and dashboard "Record vital" → `/patients/[id]?tab=vitals`).
**Frontend:** `src/components/narzim/patient-chart/vitals-tab.tsx` + `VitalsInlineCard`; hooks `use-vital-signs.ts`.
**Backend:** `api/v1/vital_signs/api.py` (create/update/submit), encounter link in `encounters/api.py::_link_vitals_to_encounter`.
**Professional lens:** vitals are the nurse's core clinical output and the visit's baseline. Entry + BMI/BP are real and correct. **Two real problems: vitals can bind to the wrong encounter (safety), and the pediatric growth chart is fake percentiles** — for a pediatric clinic, growth monitoring is a primary nurse function.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| List patient vitals | Vital Signs | `list_vital_signs` | `GET /api/vital-signs?patient` |
| Create (draft) | Vital Signs | `create_vital_signs` | `POST /api/vital-signs` |
| Update | Vital Signs | `update_vital_signs` | `PATCH /api/vital-signs/[id]` |
| Submit (0→1) | Vital Signs | `submit_vital_signs` | `POST /api/vital-signs/[id]/submit` |
| Encounter backfill | Vital Signs.encounter | `_link_vitals_to_encounter` (on encounter create) | — |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| Vitals entry (weight/height/temp/RR/HR/BP) | 🟢 **REAL** | `useCreateVitalSigns` → `create_vital_signs`; create-then-**submit immediately** (vitals-tab L200–203) |
| BMI auto-calc | 🟢 **REAL + consistent** | FE `weight/height²` (L72) == backend `_calc_vitals` (height in metres) |
| BP string ("120/80 mmHg") | 🟢 REAL | backend `_calc_vitals` |
| History table (date/age/weight/height/BMI/temp/BP/HR/visit) | 🟢 REAL | `usePatientVitals` |
| i18n | 🟢 REAL | `useTranslations("chart.vitals")` |
| **Encounter binding** | 🔴 **SAFETY GAP (NU1/B1)** | `_link_vitals_to_encounter` matches **patient + signs_date**; for a **no-appointment (walk-in) encounter** the appointment-scoping guard is skipped → links *any* same-patient/same-day unlinked vitals → **wrong-encounter cross-link** |
| **Pediatric growth chart percentiles** | 🔴 **FAKE** | `bands: {p3:-3, p50:0, p97:3}` etc. (L149–151) are **hardcoded offsets**, not real WHO/CDC weight/height/BMI-for-age curves; no z-score/percentile computed |
| **Age-for-percentile / z-score** | 🔴 MISSING | growth monitoring needs age-normalized curves; none exist |
| Correct-after-submit | 🟠 limited | vitals submit immediately; fixing a mistake means updating a submitted doc |
| Vitals bound to bare patient (no appt/enc) | 🟠 weak | only `patient` required; joins a visit solely via the NU1 heuristic |

## 3. The two clinical problems (deep dive)

### NU1 — Vitals can bind to the wrong encounter (patient-safety)
Verified in `_link_vitals_to_encounter`: it selects `Vital Signs` by `{patient, signs_date}` and links unlinked rows to the new encounter. The guard *"if encounter has an appointment and the vitals row has a **different** appointment, skip"* only fires **when the encounter has an appointment**. For a **walk-in encounter created with `patient` only (no appointment)**, the guard is bypassed → it grabs **every** same-patient, same-day unlinked vitals. A child with a morning well-visit and an afternoon sick-visit (or any two same-day encounters) can have vitals attached to the wrong one. Bare-patient vitals (no appt, no enc) rely entirely on this date match.
**Impact:** wrong vitals on a clinical note the physician signs. This is the top nurse-audit item.

### NU2-growth — Fake pediatric percentiles
The growth chart's percentile bands (`p3/p50/p97`) are static offset constants, not real WHO/CDC growth standards, and no age-normalized percentile or z-score is computed. In pediatrics, plotting weight/height/BMI-for-age against real curves is a **primary nurse/clinical monitoring function** — a fabricated curve is clinically misleading (a "normal-looking" band that means nothing).

## 4. Permissions
- Nurse has Vital Signs create/write/submit; reachable via chart Vitals tab + dashboard "Record vital". Aligned. No physician gate needed (vitals are the nurse's to record).

## 5. Alignment with core
- Composes core `Vital Signs` (patient/appointment/encounter links, BMI/BP mirror `vital_signs.js`). Aligned.
- The encounter link is our **backfill heuristic**, not a core-guaranteed binding — that's the NU1 weakness (ties backend **B1**, core-map). Vitals are auto-submitted by `complete_encounter` too, but the *link* is the risk.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **NV1 (NU1/B1)** | **Vitals mis-bind to wrong encounter** on no-appointment / multi-same-day-visit cases | Safety / integrity | **Critical** | _pending_ — tighten `_link_vitals_to_encounter`: require appointment scoping; **refuse to auto-link when >1 candidate encounter exists that day** (surface for manual pick instead). Backend hand-off **NU-BH-1**. |
| **NV2** | **Fake growth-chart percentiles** — hardcoded bands, no real WHO/CDC curves or z-score | Clinical accuracy | **High** | _pending_ — implement real age/sex-normalized percentiles (WHO 0–5 / CDC 2–20, or Mexico NOM equivalent). Backend/data hand-off **NU-BH-2**. Until then, **label the bands as illustrative** or hide them. |
| NV3 | **Correct-after-submit** friction (vitals auto-submit) | UX | Med | _pending_ — allow amend of a recent submitted Vital Signs (or a short draft window). |
| NV4 | Bare-patient vitals (no appt/enc) allowed | Integrity | Med | _pending_ — require appointment or encounter context at entry (pairs with NV1). |

## 7. Recommended options (curated)
- **Fix NV1 first (safety):** never auto-cross-link; scope to appointment, and on ambiguity make the nurse choose the encounter. This is the single most important nurse-audit fix.
- **NV2 real growth curves:** the highest-value *clinical* feature for a pediatric nurse — plot against real WHO/CDC/NOM percentiles with z-score. Don't ship fabricated bands.
- **NOT recommended:** adding more vitals fields before fixing binding + percentiles — accuracy and correct attribution beat breadth. Don't let the nurse enter clinical interpretation (that's the physician's) — vitals capture only.

## 8. Open questions for product owner
1. **NV1:** On an ambiguous same-day match, should the system **block auto-link and prompt the nurse to pick the encounter**, or hard-scope to appointment only? (Recommend prompt-on-ambiguity.)
2. **NV2:** Which growth standard — WHO (0–5) + CDC (2–20), or the Mexican NOM-031/NOM-008 curves? (Jurisdiction: MX default, IN per ADR-018.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
