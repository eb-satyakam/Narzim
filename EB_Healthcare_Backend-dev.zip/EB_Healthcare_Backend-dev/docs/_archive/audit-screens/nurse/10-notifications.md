# Nurse → Notifications / Messages (shared)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Comms · **Screen 10/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`).
**Professional lens:** comms for the nurse is mostly the same shared surface as front desk — with one caveat: the WhatsApp inbox degrades to empty for non-WhatsApp roles, so the nurse may see little there. This screen carries the shared N-series gaps.

## 1. REAL vs MOCK vs MISSING (nurse)
| Element | State | Note |
|---|---|---|
| Notifications data layer | 🟢 REAL | `list_notifications`/unread/mark — shared with FD |
| **Notifications bell/panel** | 🔴 HIDDEN (`false &&`) | shared N1 — nurse sees notifications nowhere |
| WhatsApp inbox (ChatWidget) | 🟠 role-degraded | real for WhatsApp-assigned roles; **for a nurse the conversation list may silently empty** (`silent403`) — she is not a messaging role by default |
| Team chat (ChatWidget "Team" tab) | 🟢 REAL | internal staff chat (`messages.api`) — usable by nurse |
| Messages sidebar nav | 🔴 MISSING (shared N3) | widget/URL only |
| i18n | mixed | WhatsApp real; notif panel English (shared N6) |

## 2. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| NN1 | **Notifications UI hidden** (shared N1) — nurse gets no in-app alerts (e.g. abnormal lab ready, task assigned) | **Med-High** | _pending_ — unhide bell/panel; nurse-relevant events (task assigned, lab result posted) should notify. |
| NN2 | **Team chat is the nurse's real comms** (WhatsApp is patient-facing, often FD-owned) | — | _pending_ — confirm nurse relies on Team chat; ensure it's discoverable. |
| NN3 | No sidebar Messages entry (shared N3); notif panel i18n (N6) | Low | _pending_ — shared fixes. |

## 3. Recommended options (curated)
- **Unhide notifications (NN1)** — a nurse needs to know when a task is assigned or a result is ready; the backend is real, the UI is switched off.
- **NOT recommended:** giving the nurse the patient WhatsApp inbox by default — patient messaging is front-desk-owned; Team chat is the nurse's lane.

## 4. Open questions for product owner
1. Which events should notify a nurse in-app (task assigned · lab result posted · immunization due)? (Drives what to surface once the bell is unhidden.)
2. Is the nurse expected to use the patient WhatsApp inbox at all, or Team chat only?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
