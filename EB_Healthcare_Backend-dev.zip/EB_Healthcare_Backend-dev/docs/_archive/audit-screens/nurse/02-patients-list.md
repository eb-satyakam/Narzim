# Nurse → Patient List (nurse lens)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Patients · **Screen 2/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `patients`. Shared screen with front desk (`patients-client.tsx`); nurse lens differs only in create rights.

## 1. What's different for the nurse
- **Same directory** (`usePatients` → `list_patients`), search, filters, favorites — all **REAL**.
- **No Register button:** `canRegister = rolesOverlap(roles, ["frontdesk","admin"])` → **false for nurse** (correct — patient creation is front-desk/admin). Nurse gets a read-only directory to *find* a patient, not create one.
- Row click → Patient 360 (nurse overview).

## 2. REAL vs MOCK vs MISSING
| Element | State | Note |
|---|---|---|
| Directory + search + filters + favorites | 🟢 REAL | shared with FD |
| Register patient | 🔒 hidden (correct) | nurse lacks Patient create |
| Age shown | 🔴 MISSING (payload has it) | **matters more for nurse** — age drives dosing/vitals (shared P2) |
| Pagination cap 100 | 🟠 shared P1 | |
| Guardian / balance columns | 🔴 not shown | balance irrelevant to nurse; guardian useful |

## 3. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| NP1 | **Age not shown** — clinically relevant for the nurse (dosing/vitals) | **Med-High** | _pending_ — add Age column (shared with FD P2; higher nurse value). |
| NP2 | Pagination cap 100 (shared P1) | Med | _pending_ — real pagination. |
| NP3 | Balance/guardian columns | Low | _pending_ — balance N/A for nurse; guardian optional. |

Everything else = the front-desk Patient List audit (`../../frontdesk/screens/02-patients-list.md`), minus create. No nurse-specific defects beyond the shared ones.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
