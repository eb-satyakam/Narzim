# Nurse Audit — Decision Sheet

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

Every gap from the 10 nurse screens, ranked, with a recommendation (`▶ REC:`) to accept or override. Patient-safety first (this is a clinical role). FE = frontend-only · BE = backend hand-off (`BACKEND_HANDOFFS.md`) · verified against backend 2026-07-09.

## Tier 0 — Critical (patient safety / trust)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| NV1 | Vitals | Vitals mis-bind to wrong encounter (walk-in / 2 same-day visits) | **Fix binding** (NU-BH-1): scope to appt; refuse auto-link on ambiguity | BE | ▶ REC: ✅ **first** — top safety item |
| NL1 | Labs | **CONFIRMED:** nurse (+ front desk) can *finalize* lab results — Rule 6 unenforced | **DocPerm patch** (NU-BH-3): remove `Lab Test submit` from EB_Nurse + EB_Front Desk | BE | ▶ REC: ✅ **now** — small patch, real bug |
| NC2 | Chart | Fabricated AI risk banner may render for nurse (phase violation) | **Remove** from live chart (shared C1/C5) | FE | ▶ REC: W1 — remove immediately |

## Tier 1 — High (clinical accuracy / core function)
| # | Screen | Finding | Recommendation | Effort | Decision |
|---|---|---|---|---|---|
| NV2 | Vitals | Fake pediatric growth-chart percentiles (hardcoded bands) | **Real WHO/CDC/NOM percentiles + z-score** (NU-BH-2) | BE+data | ▶ REC: ✅ — primary pediatric-nurse feature; until then label bands "illustrative" |
| NC1 | Chart | "Record vitals" overview CTA is a toast stub | **Wire to vitals intake** | FE | ▶ REC: W1 — main nurse CTA is dead |
| NW1/ND2 | My Work / Dashboard | No proactive clinical worklist (vitals-pending / vaccines-due / labs-to-draw) | **Nurse work-feed** (NU-BH-5 = FD-BH-4 nurse variant) | BE+FE | ▶ REC: ✅ — one backend, two surfaces. **Update 2026-07-10:** *partially* addressed — the `/nursing` worklist (NT1) now shows real *assigned* Nursing Tasks with Start/Complete; the *proactive clinical due-item* feed (checked-in-without-vitals / vaccines-due-by-age / labs-to-draw) is **still missing**. Remaining scope = the computed feed, not the task list. |
| NI1 | Immunizations | No allergy/contraindication check before dosing | **Allergy check at administration** (NU-BH-6 — allergies endpoint exists) | FE(+verify) | ▶ REC: ✅ — cheap, safety |
| NN1 | Comms | Notifications UI hidden (nurse gets no task/lab-ready alerts) | **Unhide bell/panel** (shared N1) | FE | ▶ REC: W1 |

## Tier 2 — Medium (completeness / integrity)
| # | Screen | Finding | Recommendation | Decision |
|---|---|---|---|---|
| NL2 | Labs | Dual lab creation path (duplicate/orphan) | Converge on SR-anchored (NU-BH-4) | ▶ REC: ✅ |
| NE1 | Encounter | Nurse can author diagnosis/Rx in draft (rubber-stamp risk) | Scope draft-write to intake (NU-BH-8) | ▶ REC: ✅ decide scope |
| NA1 | Appointments | No check-in/mark-ready in the list | Add nurse queue-advance to list (shared A1) | ▶ REC: ✅ with A1 |
| ND1 | Dashboard | Wait-time hidden (shared D1) | Render wait + overdue | ▶ REC: W1 |
| ND3/NP1 | Dashboard/Patients | Age hidden (clinical need) | Add age to rows/list (shared D5/P2) | ▶ REC: W1 |
| NI2 | Immunizations | Lot/expiry/manufacturer capture — verify | Add fields if missing (NU-BH-7) | ▶ REC: ✅ verify → add |
| NV3 | Vitals | Correct-after-submit friction | Allow amend of recent submitted vitals | ▶ REC: ⏸ later |
| NT2 | Nursing tasks | Healthcare Activity screen exists but is admin-gated (`/settings`) — nurse can't reach it | Accept admin-only (masters = clinic config); expose to nurse only if activity mgmt is a nurse job | ▶ REC: ✅ accept admin-only |

## Tier 3 — Low (polish / i18n)
| # | Screen | Finding | Decision |
|---|---|---|---|
| NC3/NI3/NA2/NN3 | multiple | Hardcoded English (overview-nurse, immunization status labels, appts, notif panel) | ▶ REC: ✅ i18n batch |
| ND5 | Dashboard | Stray reschedule/cancel actions may render on nursing rows | ▶ REC: verify → remove |
| NC4 | Chart | Handoff checklist not persisted | ▶ REC: ⏸ optional |
| NW2 | My Work | Client-only dismiss | ▶ REC: ⏸ accept |
| NI4 | Immunizations | MX EPI only | ▶ REC: ⏸ IN per ADR-018 |
| NT3 | Nursing tasks | My Work nursing "done" is a client-only dismiss, not a real status change (= NW2) | Deep-link the inbox card to `/nursing` (single source of truth) rather than a second status-write path | ▶ REC: ✅ deep-link |
| NT4 | Nursing tasks | Nursing Checklist Templates not surfaced | Admin-config auto-generation; defer | ▶ REC: ⏸ later |

---

## Closed since first pass (2026-07-10)
| # | Screen | Was | Now | Evidence |
|---|---|---|---|---|
| NT1 | Nursing tasks | 🔴 no nursing-task workflow UI (`update_nursing_task_status` uncalled) | ✅ **BUILT** — `/nursing` worklist with Start/Complete (todo/in-progress/done), whitelisted BFF, required-linked-doc handled | FE `feat/nursing-worklist` `6c22a9a`; not yet on `main` |

---

## Do we need MORE options for the nurse? (deep answer)
**Mostly no — the nurse surface is scoped correctly; it needs *fixing and completing*, not *widening*.** The role's job is clinical intake + queue advancement + encounter prep, and every screen for that exists. The high-value additions are **completing** existing surfaces, not new screens:

**Worth adding (they complete the role):**
- **Nurse clinical worklist** (NW1) — the biggest gain: *who needs vitals · vaccines due by age · labs to draw · drafts to prep.* Turns passive chips into an actionable room plan. (Backend mostly exists — schedule is computed, tasks feed is real.)
- **Real growth curves** (NV2) — the one genuinely *new* clinical capability a pediatric nurse needs and doesn't have (today's is fake).
- **Allergy check at immunization** (NI1) — safety, cheap.
- **In-app notifications** (NN1) — "lab result ready / task assigned" belongs to the nurse.

**Deliberately NOT adding (scope discipline):**
- **No billing/checkout/cash** for the nurse — correctly denied; money is front-desk. Don't add.
- **No signing / finalizing** (encounter or labs) — that's the physician (Rule 6). The *fix* is removing the accidental Lab Test submit grant (NL1), not adding more finalize power.
- **No scheduling** (book/reschedule/cancel) — front-desk's job; the nurse only advances the clinical queue.
- **No new clinical-authoring surfaces** — narrow the draft (NE1), don't broaden it.
- **No AI scribe** before Phase 5 (correctly disabled).

**One-line:** the nurse doesn't need *more room* — she needs the room she has to be **accurate (vitals binding, growth curves), safe (labs perm, allergy check), and actionable (work-feed)**. Adding options beyond that dilutes a deliberately narrow clinical role.

## Decisions that unlock the most
1. **NU-BH-1 vitals binding** — the critical safety fix.
2. **NU-BH-3 labs DocPerm** — small patch, closes a confirmed Rule-6 hole (nurse *and* front desk).
3. **NU-BH-5 nurse work-feed** — one backend (shared FD-BH-4), powers dashboard + My Work.
4. **NU-BH-2 growth curves** — the one real new clinical feature.

## Open questions for product owner
1. **NV2:** which growth standard — WHO+CDC or Mexican NOM-031/008? (MX default, IN per ADR-018.)
2. **NE1:** scope nurse encounter-draft editing to intake only (symptoms/vitals/history), yes/no?
3. **NL1:** confirm nurse + front desk should NOT finalize labs (physician-only) — patch the DocPerm.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
