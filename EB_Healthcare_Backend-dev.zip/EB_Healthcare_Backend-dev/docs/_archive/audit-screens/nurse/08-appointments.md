# Nurse → Appointments (check-in / mark ready)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Appointments · **Screen 8/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `appointments` + chart Appointments tab.
**Professional lens:** the nurse uses appointments to see who's coming and advance the clinical queue (check-in → mark ready). She does **not** book, reschedule, cancel, or bill. Gating is correct; the screen inherits the shared list gaps.

## 1. What the nurse can do (verified caps)
- **Can:** `checkIn`, `markReady` (advance clinical queue), open/save encounter draft (ADR-022), record vitals from the chart Appointments tab.
- **Cannot:** `newAppt`, `confirm`, `rescheduleCancel`, `reassign`, `noShow`, `collectPayment`, `invoices` — all false. So the appointments **list row menu** (reschedule/cancel) is effectively empty for the nurse; her actions are queue-advancement, not schedule management.

## 2. REAL vs MOCK vs MISSING
| Element | State | Note |
|---|---|---|
| Appointments list / filters / KPI strip | 🟢 REAL | shared with FD (`appointments-client.tsx`) |
| Check-in / mark ready (chart Appointments tab) | 🟢 REAL | `useCheckInPatient` / status → real `check_in_patient` |
| Add vitals from appt row | 🟢 REAL | gated on `markReady` (nurse true); `useCreateVitalSigns` |
| Book / reschedule / cancel | 🔒 hidden | nurse caps false (correct) |
| Confirm/Check-in **in the list** row menu | 🔴 MISSING (shared A1) | list has no check-in even for FD; nurse also lacks it there — must use dashboard/chart |
| Age in row | 🟡 hardcoded "—" (shared A3) | matters for nurse |
| i18n | 🟡 hardcoded English (shared A4) | |

## 3. Gaps & decisions
| # | Finding | Priority | Decision |
|---|---|---|---|
| NA1 | **No check-in / mark-ready in the appointments list** — nurse must go to dashboard queue or chart (shared A1) | **Med-High** | _pending_ — add nurse queue-advance actions to the list row menu (check-in/mark-ready), mirroring the FD A1 fix. |
| NA2 | Age hardcoded (shared A3); i18n (A4) | Med-Low | _pending_ — shared fixes. |

## 4. Recommended options (curated)
- **Add check-in / mark-ready to the list (NA1)** so the nurse can advance the queue from the schedule, not only the dashboard.
- **NOT recommended:** giving the nurse booking/reschedule — correctly denied; scheduling is front-desk.

Everything else = the front-desk Appointments audit (`../../frontdesk/screens/05-appointments-list.md`) through the nurse's narrower capability set.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
