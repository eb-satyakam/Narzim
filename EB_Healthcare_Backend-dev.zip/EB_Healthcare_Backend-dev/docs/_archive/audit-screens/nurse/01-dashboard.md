# Nurse → Dashboard (Nursing Room)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Home · **Screen 1/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · route `dashboard`.
**Frontend:** `src/app/(clinic)/dashboard/page.tsx` → `mission-control-client.tsx` (shared with front desk; nurse sees a different room/chip/action subset).
**Professional lens:** the nurse's dashboard is her **worklist** — who's checked in and waiting for vitals, who's in her room, who to move to the provider. The live queue is real and role-scoped correctly. The same decision-support gaps as the front-desk dashboard apply (wait-time hidden, no work feed, not-live), now through the nursing rooms.

## 1. Nurse view — rooms, chips, actions (verified)
**Rooms the nurse owns (`ROOM_ROLES`):** `waiting_room` (shared w/ front desk), `nursing_room` (nurse), `practitioner_room` (shared w/ practitioner — ADR-022 lets nurse open/save a draft, not sign). She sees but can't act on `arriving_soon` / `checkout` (front-desk rooms).

**Stat chips (non-ops view, `RoleStatStrip`):** Waiting for vitals · In room · With doctor · Seen today (vs front desk's Scheduled/Checked-in/Checkout/Cancelled).

**Nurse action defaults (`permissions-store` ACTION_DEFAULTS.nurse, verified):** `checkin · vitals · movetoroom · movetoprocedure · startencounter · readycheckout` = true; `sendbacktonurse · collectpayment` = false.
- **ADR-022 nuance:** `startencounter=true` **here in the store** (gates the dashboard "open encounter" → opens/saves the draft) while `startEncounter=false` in `mergeCapabilities` (gates *signing* elsewhere). So the nurse can open the draft, not finalize it.

## 2. REAL vs MOCK vs MISSING (nurse-relevant)
| Element | State | Evidence |
|---|---|---|
| Live queue — nurse rooms (waiting / nursing / practitioner) | 🟢 **REAL** | `useDashboard` → `get_dashboard_data`; placement derived server-side |
| **Record vital** (nursing room) | 🟢 **REAL** | `createVitalSigns.mutateAsync({patient, appointment})` → redirect `/patients/[id]?tab=vitals` |
| **Move to practitioner** (nursing → practitioner room) | 🟢 REAL | `startEncounter.mutateAsync(appt)` — creates the draft encounter shell (idempotent), vitals auto-attach |
| **Open encounter** (practitioner room, ADR-022) | 🟢 REAL | `startEncounter` → `/encounters/[id]` (nurse opens draft, can't sign) |
| Move to waiting / check-in advances | 🟢 REAL | `updateStatus` mutations |
| Nurse stat chips | 🟢 REAL | derived from live appts + `dash.practitioner_room` |
| **Wait-time / overdue cue per row** | 🔴 MISSING (payload has it) | shared gap **D1** — `wait_minutes`/`delayed` returned, not rendered |
| **Nurse work feed** (waiting-for-vitals list, immunizations due, lab draws pending) | 🔴 MISSING | My Work has no nursing feed (shared **D3/MW1**); the chips count but don't list actionable items |
| KPI cards / Alert strip / My Work panel | 🔴 DISABLED | commented out (shared D-series) |
| Live refresh | 🟠 not live | manual invalidation only (shared D7) |
| Placeholder demographics (age/sex) in rows | 🟡 MOCK | `apptToPatient` hardcodes age "—", sex "M" (shared D5) — **matters more for a nurse** (pediatric dosing/vitals need age) |

## 3. Actions & wiring (nurse)
| Room | Action | Wired? | Note |
|---|---|---|---|
| Waiting | Move to nursing / check-in | ✅ real | advances queue |
| Nursing | **Record vital** | ✅ real | → vitals tab (the nurse's core action) |
| Nursing | **Move to practitioner** | ✅ real | creates draft encounter (ADR-022) |
| Practitioner | Open encounter | ✅ real | opens draft; **sign blocked** (safety) |
| — | Collect payment | 🔒 hidden | `collectpayment=false` — correct (money is front-desk) |
| — | Reschedule / cancel | 🔒 hidden | nurse caps false — correct |

**Verify:** `nursing_room` ROOM_DEF lists `actReschedule`/`actCancel`; nurse lacks those caps so they should filter out via `canDoAction` — confirm they don't render for nurse (potential stray action).

## 4. Permissions
- Route `dashboard` allowed. Rooms gated by `ROOM_ROLES`; actions double-gated by `QUEUE_ACTION_CAP × canDoAction`. Backend: nurse has Patient Appointment write (status) + Patient Encounter create (draft) + Vital Signs write. The **sign gate** (`complete_encounter` = assigned practitioner) is the safety boundary — nurse can't cross it from here. Aligned.

## 5. Alignment with core
- Same as front-desk dashboard: placement derived from Encounter docstatus + Vital Signs; **native `position_in_queue` not used** (our own queue). The nurse's "move to practitioner" correctly triggers the real `start_encounter` (core Patient Encounter draft) — good core composition.
- **NU1 (safety) surfaces here indirectly:** "record vital" creates a Vital Signs linked to the *appointment*; the encounter link is backfilled later by the same-day heuristic (B1) — see screen 04.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| ND1 | **Wait-time hidden** (shared D1) — nurse can't see who's waited longest for vitals | Missing (FD3) | **High** | _pending_ — render wait + overdue on nursing-room rows (payload has it). FE. |
| ND2 | **No nurse work feed** (shared D3/MW1) — chips count "waiting for vitals" but there's no actionable list (incl. immunizations due, lab draws) | Missing | **High** | _pending_ — the front-desk work feed (FD-BH-4) should have a **nurse variant** (vitals-pending, vaccines-due, labs-to-draw). |
| ND3 | **Placeholder age/sex in queue rows** (shared D5) — a nurse needs **age** for weight-based dosing & vitals interpretation | Mock (FD4) | **Med-High** | _pending_ — carry real age/DOB into rows. Higher priority for nurse than FD. |
| ND4 | Not live (shared D7); disabled KPIs/alerts (D-series); i18n literals (D8) | Mixed | Med-Low | _pending_ — shared with FD dashboard fixes. |
| ND5 | Stray reschedule/cancel actions may render on nursing rows (verify `canDoAction` filters them for nurse) | Correctness | Low | _pending_ — confirm; remove if leaking. |

## 7. Recommended options (curated)
- **Nurse work feed (ND2)** — the highest-value nurse addition: *waiting for vitals · vaccines due today · labs to draw · drafts to prep*. Build as the nurse slice of FD-BH-4.
- **Wait-time (ND1)** and **real age (ND3)** — free FE wins; age matters clinically for the nurse.
- **NOT recommended:** exposing billing/checkout on the nurse dashboard — correctly hidden; keep money off the nurse surface.

## 8. Open questions for product owner
1. Should the work feed have a **nurse variant** (vitals-pending / vaccines-due / labs-to-draw) alongside the front-desk one? (Recommend yes — same FD-BH-4 backend, role-filtered.)
2. Confirm age/DOB in queue rows is acceptable to surface for the nurse (pediatric clinical need) — any PHI-minimization concern?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
