# Nurse → Immunizations (administration)

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Area:** Clinical · **Screen 6/10** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`) · Patient Chart → Immunizations tab.
**Frontend:** `immunizations-tab.tsx`; hooks `useImmunizations`, `useCreateImmunization`.
**Backend:** `api/v1/immunizations/api.py` (custom `Immunization` doctype).
**Professional lens:** in a pediatric clinic, immunization is a core nurse function — administer the dose on the Mexico EPI schedule, record it, and close the task. This is one of the **cleaner clinical surfaces**: real schedule grid, real recording, real task handoff (ADR-020). Gaps are polish + billing linkage, not correctness.

## 1. Doctype / API mapping
| Element | DocType | API method | BFF route |
|---|---|---|---|
| List administered doses | Immunization | `list_immunizations` | `/api/immunizations?patient` |
| Record administered dose | Immunization | `create_immunization` (+ `create_immunization_record`) | `POST /api/immunizations` |
| Update dose | Immunization | `update_immunization` | `PATCH …` |
| Schedule (EPI, age-based) | schedule data | (schedule endpoint / computed) | — |

## 2. REAL vs MOCK vs MISSING
| Element | State | Evidence |
|---|---|---|
| **Record administered dose** | 🟢 **REAL** | `useCreateImmunization` → `create_immunization`; fields: patient, vaccine, date_administered, administered_by, **supply** (In-house/external), administration_site, scheduled_dose_label |
| **EPI schedule grid** (given / overdue / due / future by age_months) | 🟢 **REAL** | `GridView` computes status per dose against `ageMonths` |
| Administered history | 🟢 REAL | `useImmunizations` |
| **Nurse task handoff (ADR-020)** | 🟢 **REAL** | recording the dose **closes the nurse's administration task** (`create_immunization_record` completes it) |
| i18n | 🟠 partial | tab uses `useTranslations` but **status labels hardcoded English** ("Overdue" / "Due now" / "Not yet due", L58–60) |
| **Billing linkage** | 🟢 REAL (backend) | billable via `reference_dt="Immunization"` on Sales Invoice Item (front-desk checkout picks it up) — nurse records, front desk bills |
| Vaccine catalog source | 🟢 REAL | vaccine = Item; rate from Item Price (selling) |
| Contraindication / allergy check at administration | 🔴 MISSING | no allergy/contraindication prompt before recording a dose |
| Lot number / expiry / manufacturer capture | 🟠 verify | confirm whether lot/expiry are captured (regulatory/traceability need) |

## 3. Actions & wiring (nurse)
| Action | Wired? | Note |
|---|---|---|
| View schedule + due/overdue | ✅ real | age-based EPI grid |
| Record administered dose | ✅ real | supply, site, dose label |
| Close administration task | ✅ real | ADR-020 handoff on record |
| Bill the vaccine | 🔒 front desk | nurse records; billing is FD checkout (correct separation) |

## 4. Permissions
- Nurse has Immunization create/write; reachable via chart Immunizations tab. Billing stays with front desk (`invoices=false` for nurse). Aligned — clean role split.

## 5. Alignment with core
- `Immunization` is a **custom doctype** (not core Healthcare) with a Mexico-EPI schedule; billable via the standard `reference_dt/dn` Sales Invoice Item link. Aligned with the app's billing spine. ADR-020 defines the nurse-administration handoff. Good composition.

## 6. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **NI1** | **No allergy / contraindication check** before recording a dose | Clinical safety | **Med-High** | _pending_ — surface the patient's allergies + basic contraindication flags at administration (read from clinical allergies). |
| **NI2** | **Lot / expiry / manufacturer** capture — verify presence | Traceability / regulatory | Med | _pending_ — confirm; add if missing (recall traceability, NOM/regulatory). |
| NI3 | **Status labels hardcoded English** ("Overdue"/"Due now"/"Not yet due") | i18n (FD6) | Low | _pending_ — move to catalog. |
| NI4 | Schedule standard = Mexico EPI only | Jurisdiction | Low | _pending_ — India schedule per ADR-018 when that market activates. |

## 7. Recommended options (curated)
- **Allergy/contraindication prompt at administration (NI1)** — the one clinical-safety add; a nurse should see allergies before injecting.
- **Lot/expiry capture (NI2)** if absent — required for recall traceability.
- **NOT recommended:** giving the nurse the billing of vaccines here — the record→FD-checkout separation is correct; keep it.

## 8. Open questions for product owner
1. **NI1:** Add an allergy/contraindication check at the point of administration?
2. **NI2:** Are vaccine lot number + expiry + manufacturer captured today? If not, are they required for this jurisdiction?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
