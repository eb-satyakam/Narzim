# Nurse → Nursing Tasks & Healthcare Activities

**Doc status:** record · **Created:** 2026-07-10 by Invincible · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — **refreshed 2026-07-10** (NT1/NT2 built since first pass) · **Area:** Clinical · **Screen 11/11** · [index](../../../audit/nurse/README.md)
**Role:** `EB_Nurse` (frontend `nurse`).
**Origin:** surfaced 2026-07-09 when the team was creating a **Healthcare Activity** in the raw Frappe **Desk** (`localhost:8003/app/healthcare-activity/new-…`) — a tell-tale that this workflow had no frontend. Added as screen 11 after the initial 10-screen pass.
**Professional lens:** nursing tasks are the nurse's checklist — the discrete steps (record vitals, administer injection, pre/post-op checks) generated from templates. A **Healthcare Activity** is the *definition* (a type of task); a **Nursing Task** is an *instance* the nurse drives Requested → In Progress → Completed.

> **What changed since the first pass (2026-07-09 → 2026-07-10):** the two headline gaps below were **built** in response to this audit. This file is refreshed to current reality; the residual gaps are narrower. Frontend evidence is on the unmerged branches `feat/nursing-worklist` (`6c22a9a`) and the Nursing Activities settings screen (`a53af13`) — not yet on `main`.

## 1. Healthcare Activity — what it is
Core master doctype defining a **type of nursing task**: `activity` (name), `role` (who performs it), `description`, `task_doctype` (the doc it produces, e.g. Vital Signs), `activity_duration`. **Consumers:** `Nursing Task` (`activity` link) and `Nursing Checklist Template Task`. So a Healthcare Activity is the *definition*; a Nursing Task is an *instance*.

## 2. Backend — FULLY BUILT (`api/v1/nursing/api.py`, 556 lines)
| Method | Purpose |
|---|---|
| `list_healthcare_activities(search)` | list the activity masters |
| `create_healthcare_activity(...)` | create an activity |
| `get_healthcare_activity` / `update_healthcare_activity` / `delete_healthcare_activity` | full CRUD |
| `list_nursing_tasks(...)` | list nursing tasks (worklist) |
| `get_nursing_task(name)` | one task |
| `create_nursing_task(...)` / `update_nursing_task(...)` | create / edit |
| `submit_nursing_task(name)` | submit (Draft→Requested) |
| **`update_nursing_task_status(name, status)`** | **the workflow: Requested → In Progress → Completed** (stamps `task_start_time`/`task_end_time`/`task_duration`; requires `task_document_name` when `task_doctype` is set) |
| `cancel_nursing_task(name)` | cancel |
| `create_vaccine_administration_task(...)` | ADR-020 vaccine handoff |

Core lifecycle (`nursing_task.py`): Requested → In Progress (stamps start) → Completed (stamps end + duration) → (or Cancelled). All reachable via the API above. **No backend work is needed for this screen — it was complete from day one.**

## 3. Frontend — NOW WIRED (was fully absent)
| Surface | State | Evidence |
|---|---|---|
| **`/api/nursing/tasks` BFF** (list) | 🟢 **BUILT** | `src/app/api/nursing/tasks/route.ts` → whitelisted `list_nursing_tasks` |
| **`/api/nursing/tasks/[name]/status` BFF** (advance) | 🟢 **BUILT** | `route.ts` → whitelisted `update_nursing_task_status` (passes `status`, `task_document_name`, `notes`) |
| Nursing hooks | 🟢 **BUILT** | `src/hooks/use-nursing.ts` — `useNursingTasks` + `useUpdateNursingTaskStatus` |
| **Nursing worklist screen** (`/nursing`) | 🟢 **BUILT** | `nursing-client.tsx` — todo / in-progress / done tabs; **Start** and **Complete** call `update_nursing_task_status`; handles the required-linked-doc rejection with a clear toast. Nav item added for all clinical roles (`buildNav`, `isClinical`). |
| **Healthcare Activity management screen** | 🟠 **BUILT, but nurse can't reach it** | `src/app/(clinic)/settings/healthcare-activities/` + `src/app/api/admin/healthcare-activities/route.ts`. Wired **correctly** via the whitelisted `list/create_healthcare_activity` methods (**not** `/api/resource/` — no C-4 violation). But it lives under `/settings`, which `route-access.ts` gates to **admin only** → the nurse cannot open it. |
| Nursing tasks in **My Work** (inbox) | 🟠 **READ-ONLY DISPLAY** | fed by `tasks.get_my_tasks` (aggregator), not `list_nursing_tasks`. "Done" is still a **client-only dismiss** (`doneIds` Set in `work-inbox-client.tsx`) — no status write. Same finding as screen 9 **NW2**. |

## 4. The gap, now
The nursing-task **workflow is closed**: a nurse can open `/nursing`, see her tasks bucketed, and drive Start → Complete against the real backend. What remains is narrow:
1. The **Healthcare Activity** master screen exists but is **admin-gated** — configuring activities is now a *clinic-admin* task, not a Desk drop. (Acceptable *if* activity management is intended to be admin-only — see open question.)
2. **My Work** still shows nursing tasks read-only with a client-only dismiss, now that the real worklist lives at `/nursing`. Low stakes, but the two surfaces disagree on what "done" means.

## 5. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| **NT1** | Nursing-task workflow UI (Start/Complete via `update_nursing_task_status`) | ~~Missing~~ → ✅ **BUILT** | ~~High~~ | **DONE** (`feat/nursing-worklist` `6c22a9a`). Closes the original screen-11 gap. Verify it appears in the nurse's nav server-side and the worklist is patient/encounter-scoped where relevant. |
| **NT2** | Healthcare Activity management screen | ~~Missing~~ → 🟠 **BUILT, gated** | Med | _pending_ — screen exists and is wired via whitelisted methods, but under admin-only `/settings`. **Decide:** is Healthcare Activity management an **admin** task (leave as-is — no nurse access needed) or a **nurse** task (expose under a nurse-reachable route)? Recommendation: **admin-only is correct** — masters are clinic config, not per-visit nurse work. |
| **NT3** | My Work nursing "done" is a client-only dismiss, not a real status change (= screen 9 **NW2**) | Integrity | Low | _pending_ — now that `/nursing` owns the real transitions, either (a) route the inbox nursing card's action to `update_nursing_task_status(Completed)`, or (b) make the inbox card **deep-link to `/nursing`** and drop the fake dismiss. Recommendation: **(b)** — one source of truth for the transition. |
| **NT4** | Nursing Checklist Templates not surfaced | Missing | Low | _pending_ — optional; templates auto-generate tasks on procedure/lab/therapy. Admin-config, defer. |

## 6. Recommended
- **NT1 — confirm and keep.** The highest-value fix already landed; just verify nav visibility + scoping, then let it ride to `main` with the branch.
- **NT2 — accept admin-only** (masters are clinic config). No nurse route needed; the Desk dependency is already gone.
- **NT3 — deep-link, don't double-implement.** Point the inbox nursing card at `/nursing` rather than adding a second status-write path. Removes the client-only-dismiss lie.
- **NOT recommended:** any backend work — it was complete throughout. This screen was always a pure **frontend + BFF wiring** gap, and it is now largely closed.

## 7. Open questions for product owner
1. **NT2 routing:** confirm Healthcare Activity management is an **admin/clinic-config** task (current placement), not a nurse task. If nurses must manage activities, we need a nurse-reachable route.
2. **NT3:** should the My Work nursing card **complete the task in place**, or **deep-link to `/nursing`** (recommended) so `/nursing` stays the single place a task transitions?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
