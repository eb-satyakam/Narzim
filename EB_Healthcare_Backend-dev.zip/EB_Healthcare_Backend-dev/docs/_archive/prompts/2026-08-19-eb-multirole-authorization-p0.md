# 2026-08-19 — EB Role authorization: multi-role P0 (backend + frontend)

**Doc status:** record · **Created:** 2026-08-19 by Sarvesh-SocialAngel · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

Branch (backend): `fix/eb-multirole-authorization` — cut from `pre`, PR into `dev`
Branch (frontend): `fix/eb-multirole-capability-gating`
Audit: `docs/security/EB_ROLE_AUTHORIZATION_AUDIT.md`
Plain-English reference: `docs/security/EB_ROLE_AUTHORIZATION.md`

## The task as given

Audit EB Role architecture across the whole application — explicitly *not* only
Front Desk — and fix the P0 where holding `EB_Patient` turned a staff account into
a patient-portal-only account.

The governing principle, stated by the user:

> EB Roles are additive. One EB Role must not remove, replace, or override another
> valid EB Role.

Constraints, in the order they were given:

1. Keep the P0 architecture.
2. Do **not** use "every `EB_*` except `EB_Patient`" as staff detection.
3. Keep an explicit, security-reviewed staff-role set.
4. **Verify `EB_Finance` before including it.**
5. Do **not** add Medication Request READ yet.
6. Investigate the `get_all` permission bypass instead.
7. Write the failing multi-role tests **before** finalizing the fix.
8. Keep `EB_Clinic Staff` — and later `EB_Finance` — inactive, not deleted.
9. Fix G-8 and G-9 as separate multi-role bugs.
10. Run backend tests if bench is available; otherwise clearly report unrun.
11. Do **not** fix G-11 or G-12 in this P0.
12. Do **not** commit until all verification results are reported.

Plus, mid-way: use the **current Patient Portal code** as the source of truth, not
`EB_Healthcare_PatientPortal/docs/audit/PATIENT_PORTAL_AUDIT.md`, which may be
stale — and report any conflict rather than silently following the doc.

And for the frontend: the same User may hold multiple EB Roles, but the UI must
respect the current application context. Do not gate on
`roles.includes("EB_Patient")` alone, and do **not** gate on `roles.length === 1`.

## The defect

`overrides/patient_portal_perms.py::_is_patient_portal_user` asked the wrong
question:

```python
return user != "Administrator" and "EB_Patient" in frappe.get_roles(user)
```

"Does this user hold `EB_Patient`?" is not "should this user be narrowed to their
own Patient row?". The two differ for every account holding more than one EB role.
A nurse registered as a patient of the clinic was row-scoped to a single Patient
across all 11 hooked doctypes — and because Frappe applies this through
`permission_query_conditions`, it presented as **empty lists, not a permission
error**, which is why it went unnoticed.

The frontend had the mirror-image bug, gating on role identity and role *count*:

```ts
canRecordVitals = !(roles.length === 1 && roles[0] === "frontdesk")
isFrontDeskOnly =   roles.length === 1 && roles[0] === "frontdesk"
```

Both read `false` for a front-desk agent who is also a patient (length 2), so
adding `EB_Patient` silently **granted** clinical-history edit rights.

## Two mistakes the constraints caught

**`EB_Finance` (constraint 4).** I put it in the staff-exemption set reasoning
"it holds nothing today, so listing it is harmless." The opposite is true:
exempting a role *un-scopes* the `EB_Patient` grants its holder still has, because
Frappe unions role permissions before the hook runs and a `has_permission` hook
can only deny — it cannot subtract one role's grant. A role granted nothing would
therefore have gained a clinic-wide patient view. Both future roles are now
excluded, with an import-time `assert` so activating one cannot happen by editing
a single tuple.

**Live DB vs the spec.** I reported `eb_docperm_spec.json` contents as the live
database state and claimed no staff role had any row on `WhatsApp Conversation`.
The user disproved it with a screenshot of Role Permissions Manager showing
`EB_Front Desk` with Read+Write+Create. The audit now carries a correction notice,
a §6b live matrix queried from the database, and **G-10** for the spec/DB drift.

## What was changed

| File | Change |
|---|---|
| `overrides/patient_portal_perms.py` | Explicit `_ACTIVE_STAFF_EB_ROLES` / `_FUTURE_INACTIVE_EB_ROLES`, import-time `assert`, `_holds_any_role()` querying `Has Role` (not `frappe.get_roles`, which returns every role for Administrator) |
| `api/v1/appointments/api.py` | `ignore_permissions` → `skip_staff_authorization` (it is not a blanket bypass); `_NEVER_FROM_REQUEST` subtracted from `book_appointment_with_payment`'s signature-derived allow-list |
| `api/v1/patient_portal/api.py` | `book_my_appointment` authorizes itself and passes `skip_staff_authorization=True` |
| `patches/v0/eb_docperm_spec.json` | `Patient Appointment`/`EB_Patient` `create` → 0; `WhatsApp Message`/`EB_Patient` all flags → 0, **row retained** |

Two privilege expansions were closed by **removing** grants rather than accepting
them. The `WhatsApp Message` row is retained deliberately: deleting the key would
leave the live row untouched forever, because the reconciler only visits doctypes
present in the spec. My first edit made exactly that mistake.

`skip_staff_authorization` deliberately skips **both** checks together —
`require_permission` and `_enforce_practitioner_self_booking`. The latter is a
staff rule ("you may not assign work to a colleague"); in the portal the
practitioner is the provider the *patient* chose, so applying it there would stop
a practitioner who is also a patient from booking with anyone but themselves.

The rename introduced a live injection risk I then had to close: `get_newargs`
strips only `ignore_permissions` and `flags` **by name**, so any other parameter
name is reachable from a request. Recorded as G-12.

## Tests written

- `tests/patient_portal/test_multirole_authorization.py` — 15 tests. Asserts
  **equality**, not "greater than zero": adding `EB_Patient` must change staff
  visibility by nothing at all.
- `tests/patient_portal/test_portal_scoping_guardrails.py` — 9 AST/call-graph
  tests, so a future portal endpoint cannot ship unscoped.
- `tests/patient_portal/test_portal_booking_e2e.py` — 7 tests that book for real.
  Every other test asserts a *capability*; if `skip_staff_authorization` were
  wired wrongly, portal booking would be broken in production and all of them
  would still be green.
- Frontend `src/lib/narzim/roles.test.ts` (8) and
  `e2e/eb-multirole-capability-gating.spec.ts` (3).

30 of these failed against pre-fix code; all pass after.

## Verification

Full results in `docs/security/EB_ROLE_AUTHORIZATION_AUDIT.md` §MR-12. Summary:

- True A/B with the code stashed **and** `bench migrate` re-run so the database
  reverted too: 618 → 649 tests (+31, exactly the new ones), **0 new failures**,
  the same 79 pre-existing failures test-for-test.
- Live browser→BFF→JWT→Frappe run: Nurse+Patient **denied** staff booking (403),
  Front Desk+Patient **allowed** (201), portal booking works for both, a body
  naming another patient is ignored, dual-role staff see all 174 patients while
  the portal still resolves them to their own MRN.
- The browser test was itself proven capable of failing; an earlier apparent pass
  was a stale Next.js dev-compile, not a result.

## Deliberately not done

G-11, G-12, the Medication Request READ grant, and the `WhatsApp Conversation`
spec/DB drift (G-10). `EB_Finance` and `EB_Clinic Staff` remain defined and
inactive.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
