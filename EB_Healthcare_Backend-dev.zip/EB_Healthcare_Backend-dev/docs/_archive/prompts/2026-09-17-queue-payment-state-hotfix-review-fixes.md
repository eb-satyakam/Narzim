# Queue payment state hotfix — review fixes before merge

**Doc status:** record · **Created:** 2026-09-17 by Sarvesh-SocialAngel · **Updated:** 2026-09-17 by Sarvesh-SocialAngel · **Version:** 1.0


## Context

Divyanshu opened two PRs on branch `hotfix/queue-payment-state`, both targeting `main`.

- Backend: `EB_Healthcare_Backend` PR #428
- Frontend: `EB_Healthcare_EHR` PR #494

They fix a real bug. A queue card on the Clinical Command Center showed a green
"Paid" while the drawer for the same appointment showed money still owed. The
card read only that appointment's own invoice. The drawer read the patient's
wider position.

A code level risk review found the billing logic sound but the delivery unsafe.
The work below fixes what the review found. It does not change the approved
business behaviour.

## Scope of this change

### Must fix (all in scope)

1. **Dashboard performance.** The board called the full per patient billing
   flow once per patient, including a draft Sales Invoice build. It ran over
   the whole day's appointment list, on a 30 second poll.
2. **Company isolation.** The new outstanding queries filtered on customer
   only. On a multi company site a card could show, and collect against,
   another clinic's invoice.
3. **Error logging.** `frappe.log_error` wrote an Error Log row per failing
   patient per poll, and discarded the real traceback.
4. **Payment semantics.** "Partly paid" was inferred from
   `grand_total - outstanding_amount`, which counts write offs and credit
   notes as money collected.
5. **Frontend stale amount.** The new collect dialog used the dashboard
   snapshot, up to 30 seconds old, instead of the invoice's current balance.
6. **Permissions.** Patient wide balances and invoice ids were returned to any
   role that can read Patient Appointment, which includes `EB_Patient`.

### Should fix (in scope, straightforward)

7. Pass the collect invoice's own currency to the dialog, and emit it from the
   backend.
8. Use `patient_outstanding_invoice_count` in the UI, or drop it.

### Explicitly out of scope

- The Government waiver / POS Profile fix stays exactly as authored. The
  in memory `mode_of_payment = None` stays. The persisted `"Government"` marker
  stays. Its regression test stays.
- No unrelated refactoring.
- The 30 second dashboard refresh interval stays unchanged.

## Design

### Before

`get_dashboard_data` → `_attach_patient_pending` → `get_patients_total_pending`
→ for every distinct patient on the board, `get_patient_total_pending`, which
runs `get_patient_billables` (ten elevated clinical scans plus a
`frappe.set_user` round trip), then builds and discards an unsaved Sales
Invoice to get a tax correct unbilled total.

Cost grows linearly with the number of patients with an appointment that day.

### After

The board needs a payment *state*, not a tax correct amount. The card renders
only a chip: Paid, Partly paid, Due, or Payment pending. It never prints the
board's number. The exact amount is shown in the drawer, which fetches one
patient at a time through the unchanged `get_patient_total_pending`.

So the board now computes:

- `patient_invoiced_outstanding_mxn` — exact, from batched SQL, company scoped.
- `patient_has_unbilled` — a batched existence probe over the same billable
  flags the clinical scans filter on.
- `patient_payment_partial` — from real submitted Payment Entry allocations.
- `patient_collect_*` — the invoice a collect action should settle.

Query count is constant in the number of patients.

### Deliberate direction of error

The unbilled probe can report work that the full cart would drop, for example
a medication whose Item is disabled. That yields a "Due" where the exact answer
is "nothing to collect". It can never do the opposite. The board never says
"Paid" over money owed, which is the bug being fixed. The drawer remains exact.

## Rules followed

- All changes stay inside `remedisys_healthcare_ai` (RULES.md).
- Permission gaps are closed with an explicit role boundary, not with
  `ignore_permissions` or another bypass.
- No commit, no push, no merge without explicit approval.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-17 | Sarvesh-SocialAngel | Initial version (header backfilled from git history) |
