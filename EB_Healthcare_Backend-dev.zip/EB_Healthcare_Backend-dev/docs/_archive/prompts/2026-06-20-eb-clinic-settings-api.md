# 2026-06-20 — EB Clinic Settings: API layer (settings + permissions)

**Doc status:** record · **Created:** 2026-06-22 by Sarvesh-SocialAngel · **Updated:** 2026-06-22 by Sarvesh-SocialAngel · **Version:** 1.0

## Context
The `EB Clinic Settings` doctype (per-Company, created 2026-06-18) and the
`after_submit` order-channel tagging hook exist and work. But the API layer was
never updated when `Remedisys Clinic Settings` (Single) was renamed/deleted:

- `api/v1/admin/settings.py` → `_SETTINGS_DOCTYPE = "Remedisys Clinic Settings"`
- `api/v1/admin/permissions.py` → same

Both call `frappe.get_single(...)` on a doctype that no longer exists, so:
- `get_clinic_settings` / `update_clinic_settings` are broken
- `get_role_permissions` / `update_role_permissions` are broken
- The 4 facility flags (has_internal_pharmacy/lab/therapy/procedures) are not
  exposed to the frontend at all — there is no way to control the external flow
  from the app.

## Decision
Repoint both API modules at the per-Company `EB Clinic Settings`:
- Resolve company from arg → user default → Global Defaults.default_company
- Reads: safe-default fallback (reuse doctype helper `get_clinic_settings`)
- Writes: get-or-create the per-company doc
- Add the 4 facility flags to `_serialize_settings` + `update_clinic_settings`

## Files changed
- `api/v1/admin/settings.py`
- `api/v1/admin/permissions.py`
- `hooks.py` — **bug fix:** the order-tagging handler was registered under
  `Patient Encounter."after_submit"`, which is NOT a real Frappe doc event, so it
  never fired. Changed to `"on_submit"`. Healthcare creates the Medication/Service
  Requests in its own `on_submit` (`patient_encounter.py:33`); app `doc_events`
  run after the controller method, so the orders already exist when our hook runs.

## Verified end-to-end on marley.local (2026-06-20)
Company "Narzim", real Patient Encounter submit with drug + lab + procedure +
therapy orders, then data cleaned up:

| Scenario | Flags | Medication Request `custom_order_channel` | Service Request `source` |
|---|---|---|---|
| EXTERNAL | all 0 | External | External Referral |
| INTERNAL | all 1 | Internal | Direct |

Settings API get/update round-trips all 4 facility flags per-company.

NOTE: the live web server needs `bench restart` to pick up the hooks.py change
(the bench console test cleared cache and verified the new event fires).

## Backward compatibility
BFF GET/PATCH `/api/admin/clinic-settings` call with no `company` arg → resolves
the default company. New optional `company` arg supports multi-clinic later.

## Frontend follow-up (separate task)
- Extend `ClinicSettings` type with the 4 facility booleans
- Add a "Facilities" toggle section to the Settings page
- These flags drive the post-sign external referral / print-slip flow

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-22 | Sarvesh | Initial version (header backfilled from git history) |
