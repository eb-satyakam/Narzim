# Treatment Plan Template — admin CRUD (metadata + service items + medications)

**Doc status:** record · **Created:** 2026-06-26 by Sarvesh-SocialAngel · **Updated:** 2026-06-26 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-26
**Phase:** Phase 3/4 admin catalog
**Area:** `api/v1/admin/catalog.py` (backend), new admin page (frontend)

## Context

Admin CRUD for ERPNext Healthcare `Treatment Plan Template` so a clinic can define
reusable plans. Agreed scope (supersedes the earlier "no drugs" Option B — user
asked to include medications): metadata + the `items` service table + the `drugs`
medication table. Observation Template type dropped. Full-page form (like the
Medication form). No `/api/resource/` — custom whitelisted methods only.

## Doctype contract (Healthcare core, read-only to us)

`Treatment Plan Template` (autoname `field:template_name`):
- metadata: template_name (reqd), medical_department, description, goal, gender,
  patient_age_from, patient_age_to, disabled
- `items` → `Treatment Plan Template Item` (child): `type` (Link DocType) +
  `template` (Dynamic Link) + qty + instructions. type ∈ {Lab Test Template,
  Clinical Procedure Template, Therapy Type} (desk also allows Observation
  Template — excluded here).
- `drugs` → `Drug Prescription` (child): medication (Link Medication), drug_name,
  dosage (Prescription Dosage), **period (Prescription Duration, reqd=1)**,
  **dosage_form (Dosage Form, reqd=1)**, interval, interval_uom, comment.

## Required-field handling on drug rows

`period` and `dosage_form` are mandatory. The backend derives them from the chosen
Medication's prescribing defaults (dosage_form, default_prescription_duration,
default_prescription_dosage, default_interval, default_interval_uom) when the row
omits them, and throws a clear error if still missing. Frontend prefills the same
on medication pick.

## Plan

Backend (`catalog.py`, exported in `api.py`):
- `list_treatment_plan_templates()` — metadata rows (read).
- `get_treatment_plan_template(name)` — full doc incl. items + drugs (read).
- `create_treatment_plan_template(...)` / `update_...` / `delete_...`.
- Helpers `_build_tpt_item_rows`, `_build_tpt_drug_rows`, `_fmt_treatment_plan_template`.

Permissions: add Treatment Plan Template (+ child Treatment Plan Template Item,
Drug Prescription) and any picker master not already granted (Therapy Type,
Clinical Procedure Template, Gender, Medical Department) to eb_docperm_spec.json;
one re-apply patch. See [[project_eb_docperm_patch]].

Frontend: BFF route `/api/admin/treatment-plans`, hooks, list page, full-page
new/edit form, nav entry under Clinical Setup.

## Risks

- Permissions for the picker masters / child doctypes must be granted or save/list 403s.
- Delete guarded against LinkExistsError (plans may be referenced by encounters).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-26 | Sarvesh | Initial version (header backfilled from git history) |
