# 2026-06-18 — EB Clinic Settings Doctype + Encounter Order Channel Hook

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

## Context

Frappe Healthcare creates Medication Requests and Service Requests automatically
on Patient Encounter submit for every clinic, regardless of whether the clinic has
an internal pharmacy, lab, or therapy room. For external-only clinics this pollutes
billing queues with records that will never be fulfilled.

## Decision

- Rename `Remedisys Clinic Settings` (Single) → `EB Clinic Settings` (per-Company)
- Remove `issingle: 1` so each Company gets its own settings record
- `autoname = field:company` so settings are fetched by company name directly
- Add Facilities section: has_internal_pharmacy, has_internal_lab,
  has_internal_therapy, has_internal_procedures
- Keep existing settings fields (notifications, access, appearance)

## Order Channel Tagging

After Patient Encounter submits, our `after_submit` hook reads `EB Clinic Settings`
for the encounter's company and tags every created order:

- Medication Request → `custom_order_channel` = "Internal" or "External"
- Service Request (lab) → `source` = "Direct" or "External Referral"
- Service Request (procedure) → `source` = "Direct" or "External Referral"
- Service Request (therapy) → `source` = "Direct" or "External Referral"

## Why Per-Company (not Healthcare Settings)

Healthcare Settings is a Single doctype — one global record for the whole Frappe
site. For multi-clinic SaaS (Clinic A has pharmacy, Clinic B does not) a per-company
settings doctype is required.

## Future

When clinics mature: change `has_internal_pharmacy = 1` → going forward all new
Medication Requests are tagged "Internal" and appear in the pharmacy queue. Historical
"External" records stay out of the queue. Clean transition, no data migration.

## Files Changed

- `remedisys_healthcare_ai/doctype/eb_clinic_settings/` (new — replaces remedisys_clinic_settings)
- `remedisys_healthcare_ai/fixtures/custom_field.json` (add custom_order_channel on Medication Request)
- `remedisys_healthcare_ai/overrides/encounter_orders.py` (new hook handler)
- `remedisys_healthcare_ai/hooks.py` (add Patient Encounter after_submit)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
