# v9 Draft SOAP editing, regenerate/undo, Ask AI section-append, Rx conflicts

**Doc status:** record · **Created:** 2026-09-28 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-28 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

Implementation task, run against `origin/dev` on branch
`feature/v9-soap-draft-editing`. Preceded by two read-only investigations
(frontend repo `docs/qa/encounter-v3/12-...md` and `13-...md`) and a locked
9-point requirement set from the user (verbatim, condensed):

1. Draft SOAP: one directly-editable document (CC/HPI/Objective/Assessment/
   Plan), Assessment = free text + existing diagnosis rows, no accept/reject/
   tick workflow for text.
2. Ask AI reads the current Draft SOAP as primary context, and the original
   transcript when something is missing or needs verification. Transcript is
   never replaced by the SOAP.
3. Ask AI understands "Add X to <section>" commands, append-only, never
   overwrite, and never silently modifies clinical data — the doctor must
   explicitly apply an action.
4. SOAP generation must be a clinical summary, not copied transcript, and
   must not claim safety validation that doesn't exist.
5. Regenerate = full new Draft SOAP from current draft + transcript + new
   context. One browser-only Undo snapshot, one step back, touching nothing
   else (transcript/chat/Rx Pad/labs untouched).
6. Draft SOAP → Rx Pad extracts full structured orders (not just medicine
   names), preserving the order↔diagnosis/symptom relationship, resolving
   masters, never silently overwriting a doctor's own order, deduping.
7. Rx conflicts: same drug + same Rx = no duplicate. Same drug + different
   dose = keep the doctor's existing Rx, persist a system Ask AI message,
   never duplicate. Doctor's explicit chat instruction updates the existing
   row instead of adding a second one.
8. Safety: never say "Safety Passed" without a real validator. Keep the
   existing allergy/duplicate checks honestly labelled. No new interaction/
   dose engine invented.
9. Reuse existing recording/Deepgram/consent/speaker-correction/SOAP
   generation/Ask AI/persistence/master-resolution/versioning/audit
   infrastructure. Classic and v3 stay unchanged.

Frontend repo: `Healthcare_next_app`, branch `feat/encounter-v9-design`
(uncommitted Scribe step 1 work already on it). Backend repo: this one,
branch `feature/v9-soap-draft-editing` off `origin/dev`.

**Grounding found before writing code** (both change what "small" means):

- The free-text Assessment field already exists end-to-end: backend blob key
  `diagnosis` (`api/v1/encounters/api.py` `_parse_soap`/`save_draft`), v9
  Pad's `assessment` field (`pad-save-payload.ts:95` maps it to `diagnosis`),
  and an already-editable five-box "SOAP note" modal
  (`v9/screens/soap-note-modal.tsx`) that already writes straight into the
  Pad draft via the same setters typing uses. Requirement 1 is mostly built
  already — the remaining work is making AI generation/regeneration write
  into these same fields directly, and retiring the separate tick-box card
  review for text.
- `services/ai_tools.py::encounter_state` (read by the Ask AI agent) returns
  chief complaint, symptoms, diagnoses, meds, labs, vitals — **not** the
  free-text HPI/Objective/Plan/Assessment. Requirement 2/3 need this closed
  first, or the agent literally cannot see what's in the note.
- No prior code lets `generate_soap_draft` take "here's the current draft,
  extend it" — this is genuinely new backend + prompt work, not a frontend
  wire-up.

No PR opened yet; this branch stays local/pushed-for-review only after the
user asks for it (backend PR hard rule).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Sarvesh-SocialAngel (AI-assisted) | Session record; moved from `prompts/` to `docs/_archive/prompts/` per CLAUDE.md §8 |
