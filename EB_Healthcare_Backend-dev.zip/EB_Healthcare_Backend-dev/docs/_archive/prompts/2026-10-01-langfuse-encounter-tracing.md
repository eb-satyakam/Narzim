# Langfuse: trace the whole v9 encounter flow

**Doc status:** record · **Created:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## Prompt

> now i am working on encounter flow ... user friendly and trace all using lang graph .. check all
> setup is correct or not if not correct you have all the things go deeper .. as developer i can
> trace every thing.. to improve my encounter flow .. go deeper

"LangGraph" was read as Langfuse: LangGraph is an orchestration framework that `CLAUDE.md` §2
excludes, and the request was about tracing.

## Decisions taken with the user

1. Scope: all of A1–A7 (sessions, prompt names, trace input/output, background jobs, every app
   request, quality events, doc).
2. Branch: `feat/langfuse-encounter-tracing` from `origin/dev`, with `bench migrate` on
   `marley.local` (9 patches). The Bruno work was committed there first, on the user's request.
3. Session id: an opaque hash of the encounter, to keep the team's rule that no patient or
   encounter id is a trace attribute.

## Outcome

See [ADR-120](../../adr/adr-120-langfuse-encounter-tracing.md), `docs/grafana/LANGFUSE_LOCAL_TRACING.md`
v2.0 §7 for the measurements, and `WORK_LOG.md` 2026-10-01.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
