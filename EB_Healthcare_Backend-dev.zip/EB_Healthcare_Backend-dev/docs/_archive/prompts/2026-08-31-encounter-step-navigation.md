# Encounter V3 — step navigation rules and SOAP context

**Doc status:** record · **Created:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

Requirement stated by the product owner, written down before any code, then
checked against what the app does today.

> **Built and merged 2026-08-31.** Three of the four rules shipped. R2 shipped
> as something better than it was asked for, and the reason is in
> [§ What was built](#what-was-built) at the end. This document is now a record
> of the requirement and how it was answered, not a plan.

## The requirement, as stated

> "forward we can not go. but if i am at soap then i can back capture, if i am
> not change any thing i can go on capture, if i change any i can't go on
> capture. without click review the note.
>
> if i upload file ya fir i chat in narzim then i click on review, it takes as
> context and generate SOAP.
>
> first write my problem then check it and after that create SOAP."

## What that means, in rules

**R1 — No skipping forward.**
A later step may only be reached through the button that leads to it
("Review the note", "Continue to Fill Encounter"). Clicking a step card must
not jump ahead of where the clinician has actually got to.

*Why it matters:* Fill Encounter is where the record is signed. Reaching it
without a note means signing an encounter nobody drafted.

**R2 — Going back is allowed, but only while the note is untouched.**
From Review SOAP the clinician may return to Capture if they have NOT edited
the note. Once they have edited it, going back is blocked.

*Why it matters:* the edits are the clinician's own words. Anything that could
regenerate the draft over them destroys work they cannot recover.

**R3 — Uploads and chat are context for the note.**
If the clinician attaches a document or talks to Narzim during Capture, then
pressing "Review the note" must generate the SOAP with those included, not
from the transcript alone.

*Why it matters:* a clinician who tells Narzim something, or hands it a lab,
reasonably expects the note to know it. Today that work is discarded.

**R4 — Order of work.** Write the requirement, check it against the code,
then build. This document is step one.

## What the code does today — checked, not assumed

| Rule | Status | Evidence |
| --- | --- | --- |
| R1 no skipping forward | **NOT implemented** | `chrome.tsx` `StepCards`: every card is `onClick={() => onGo(s.key)}` with no `disabled` and no guard. Fill Encounter is reachable in one click from Capture, with no note and an empty transcript |
| R2 back only when clean | **NOT implemented** | Nothing compares the note against its generated version. `go()` is `setStep` plus marking the step reached |
| R3a uploaded files as context | **implemented today** | `services/ai.py::_resolve_attached_labs` → `build_encounter_context["attached_labs"]` → `generate_soap_draft` |
| R3b chat as context | **NOT implemented** | `api/v1/ai/api.py::generate_soap_draft(encounter, transcript)` builds `ctx` and calls the model with the transcript only. `AI Encounter Chat Message` rows are never read |

## One thing the check corrected

R2 assumes that going back to Capture and returning would regenerate the note
over the clinician's edits. **Today it would not:** `encounter-flow.tsx` guards
generation with `autoGenStarted`, a `useRef`, so the draft is generated once per
mount and navigation alone cannot re-run it.

The risk is real but narrower than stated, and it is worse than it looks. A ref
does not survive a page reload. So the sequence that actually destroys work is:

    edit the note -> reload the page -> return to Review SOAP -> regenerated

R2 as stated does not prevent that, because the block is lifted by the reload
along with the ref. Whatever is built must key on something persisted, not on a
ref — the same gap PHI-7 already names, and the same one that leaves a stale
`J06.9` diagnosis in the record after a reload.

## Open questions before building

1. **R2 blocks navigation.** Should going back be refused outright, or offered
   with a warning ("your edits will be kept, the note will not regenerate")?
   Refusing traps a clinician who genuinely needs to re-read the transcript.
2. **R3b scope.** The whole conversation, or only turns the clinician marked as
   relevant? A long chat pushes the transcript out of the model's attention, and
   Narzim's own replies are not evidence of anything said in the room.
3. **R1 and backwards.** Does "no skipping forward" also forbid jumping BACK two
   steps, e.g. Fill Encounter straight to Capture?

## What was built

Frontend `3ec1157`, `8fa7c6f` · backend `7ff4904`. Both merged to `dev`.

| Rule | Shipped | How |
| --- | --- | --- |
| **R1** no skipping forward | **Yes** | `chrome.tsx` `StepCards` now reads the `reached` set that `go()` already maintained and nothing consumed. A step not yet arrived at is `disabled`. Going BACK stays free |
| **R2** back only when clean | **Answered differently, and better** | See below |
| **R3a** uploaded files as context | already worked | unchanged |
| **R3b** chat as context | **Yes** | `services/ai.py` feeds the clinician's own chat turns into `generate_soap_draft`. Bounded at 12 turns / 1500 chars, most recent first |

### Why R2 was not built as stated

R2 asked to block going back once the note had been edited, because returning
would regenerate the draft over the clinician's words.

The check in the table above already found that navigation alone could not
re-run generation, and that a **reload** could. So blocking the back button
would have cost a clinician the ability to re-read the transcript while doing
nothing about the sequence that actually destroys work: edit, reload, return.

The fix went to the door instead of the corridor. **A note that already has
text is never regenerated.** The guard reads `initialText`, the note as loaded
from the server, so it survives a reload by definition. No new field, no schema
change, no `AI SOAP Draft` lookup. If any section carries text, either the AI
drafted it earlier or the clinician typed it. Both mean do not draft again.

Going back is therefore free, and leaving an edited note now **reassures**
rather than warns: the honest message is that the work is safe. Shown once,
then remembered.

That also settles open question 1 (refuse or warn: neither, the danger is gone)
and question 3 (jumping back two steps is allowed, because back is never
gated).

### What R3b deliberately leaves out

Narzim's own replies are excluded, and the filter is on `role` for that reason
rather than passing the whole thread. On `HLC-ENC-2026-00648` the assistant had
replied *"Assessment: Most likely viral pharyngitis…"*. Feeding that back would
let the model read its own guess as source material and amplify it, which is
the exact mechanism the two-lane split exists to prevent. Upload turns are
excluded too: their values already reach the note through
`_resolve_attached_labs` with the interpretation stripped, and the raw chat
text still carries the reading's own conclusions.

Chat turns are marked **TYPED**, not spoken, so the model does not attribute
them to the recording.

Open question 2 (whole conversation or marked turns) is answered by the cap
rather than by a marking UI: 12 turns, most recent first. A longer chat crowds
the transcript out of the model's attention.

## Status

**Done and merged.** One item left: nothing on screen tells the clinician which
chat turns were in scope. Tracked in
[`ENCOUNTER_V3.md`](../../architecture/ENCOUNTER_V3.md) §10.

## Revision history

| Version | Date | Author | Change |
| --- | --- | --- | --- |
| 1.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Recorded what shipped. R1 and R3b built as stated; R2 answered by never regenerating over an existing note, which also closes two of the three open questions. Status was still "Nothing implemented" a day after the work merged |
| 1.0 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Requirement captured and checked against the code. Not implemented. |
