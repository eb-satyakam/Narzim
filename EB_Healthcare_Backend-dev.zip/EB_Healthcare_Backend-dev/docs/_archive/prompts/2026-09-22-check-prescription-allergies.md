# Prescribing allergy check

**Doc status:** record · **Created:** 2026-09-22 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-22 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The request

Implement the backend half of a handoff written by the frontend session:
`check-prescription-allergies-backend-patch.md`. The frontend is already fully
built and calling this method
(`src/app/api/encounters/[id]/allergy-check/route.ts`,
`src/lib/api/allergy-check.ts`, `Healthcare_next_app` repo) — nothing on that
side changes once this ships.

## The problem

Prescribing has no safety check against what the record already knows.
Encounter → Prescription can send a drug the patient is recorded as allergic
to and nothing says so.

## Verifying the handoff before copying it

The handoff's own §2 correction was right and re-verified here: there is no
`Patient Allergy` doctype (`find . -iname "*patient*aller*"`, zero hits). The
real field is `Patient.allergies` — comma/semicolon-separated free text,
already parsed by `clinical/api.py::_read_items` /
`_FIELD_ALLERGIES`. Reused directly rather than re-splitting the field a third
way, so this check can never disagree with what Patient 360's own allergy list
shows for the same patient.

`Medication.generic_name` (Data) and `Medication.medication_class` (Link →
Medication Class) both exist, confirmed against
`healthcare/healthcare/doctype/medication/medication.json` — the frontend
sends only `medication`/`drug_name`, so the backend resolves those two itself.

**One thing in the handoff did not hold up: the `drugs` parameter type.** The
handoff assumed `drugs: str` — a JSON-encoded string, `json.loads`'d inside the
function, mirroring `ask_copilot`'s `history` param. Tracing the actual request
path proved that wrong for this endpoint specifically:

- The frontend route posts `{encounter, drugs}` as **one** JSON body
  (`JSON.stringify(body)` in `client.ts::frappeFetchDirect`), with `drugs`
  nested inline as a real array — unlike `ask_copilot`, which explicitly
  pre-encodes `history` with its own `JSON.stringify(history)` before that
  outer stringify (`labs.ts:246`), specifically so it arrives as a string.
- Frappe decodes the whole JSON body by type before a whitelisted method ever
  sees it (`frappe/app.py::make_form_dict`: `orjson.loads(request_data)` →
  `frappe.local.form_dict = frappe._dict(args)`), so `drugs` reaches
  `check_prescription_allergies` as an actual Python `list`.
- `json.loads(<a list>)` raises `TypeError`, which
  `except (json.JSONDecodeError, ValueError)` does not catch. Every real call
  would have fallen through to `handle_api_errors`'s catch-all and returned a
  bare 500 — the feature would have shipped broken behind a clean-looking
  patch.

Confirmed by reading `client.ts::frappeFetchDirect` and
`frappe/app.py::make_form_dict` directly, not by assumption.

**Fix, not a rewrite of the handoff's shape:** this file already has a helper
for exactly this ambiguity — `_parse_list()` (used seven times already, e.g.
`save_draft`'s `drug_prescription`/`therapies`), which accepts a list or a
JSON string. Swapped in place of the hand-rolled `json.loads` and the function
needed no other change to its request contract.

## Test coverage (§11: safety code is not allowed to ship untested)

`bench run-tests` is broken bench-wide in this repo (ERPNext `before_tests`
raises a Fiscal Year overlap), so the DB-backed option from the handoff's own
"Test suggestion" section wasn't viable today. Took its cheaper option
instead: extracted the matching decision (`_match_drug_against_allergies`) as
a pure function, separate from the `frappe.db` Medication lookup, and unit
tested it directly — 11 cases, run via `unittest` with no bench/DB dependency
(verified passing, see `tests/encounters/test_check_prescription_allergies.py`).
Two of the first-draft test cases encoded real allergy cross-reactivity
(Sulfa↔Sulfonamide, Penicillin↔Amoxicillin) that this naive substring matcher
was never meant to know — they failed on first run, correctly, and were
rewritten to use pairs that actually share a substring instead of silently
loosening what the matcher claims to do.

## Safety

Pure string matching against the patient's own recorded allergies, nothing
inferred. `checked: true` with an empty `conflicts` list means "nothing
matched" — never "safe to prescribe" (`AllergyCheckResult`'s own frontend doc
comment already enforces this distinction). No cross-reactivity claim
(penicillin/cephalosporin, sulfa/thiazide) — that needs clinical knowledge this
function does not have, and adding it silently would be worse than not having
the check at all. No new permission surface: reuses
`require_permission("Patient Encounter", "read", doc=encounter)`, the same
gate every other encounter-scoped read in this file already uses.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
