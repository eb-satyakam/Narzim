# Appointments list — server-side filters (search, date range, billing status)

**Doc status:** record · **Created:** 2026-07-09 by Sarvesh-SocialAngel · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Requested by:** Sarvesh (frontend-driven; user authorized backend edit explicitly)

## Goal
Make every Appointments-list filter server-side. Status + practitioner already are.
Add three params to `list_appointments` / `get_appointments` / `_list_impl` and wire the
BFF route + Next.js client to send them, then remove the client-side filter fallbacks.

See `docs/api/FRONTEND_API_GAP_CHECKLIST.md` → "Appointments list — server-side filter params".

## Scope
Backend: `remedisys_healthcare_ai/api/v1/appointments/api.py`
- `search` (str) — partial, case-insensitive across `patient_name` + `patient` (MRN/id) via `or_filters`.
- `date_from` + `date_to` (YYYY-MM-DD, inclusive) — range on `appointment_date`; keep exact `date` fast path.
- `billing_status` (Unbilled|Pending|Paid) — resolved from `ref_sales_invoice` + Sales Invoice
  `outstanding_amount`, mirroring `_billing_for`. Unbilled = no invoice; Pending = outstanding > 0;
  Paid = outstanding <= 0.
- `total` count must respect `or_filters` (search) — `frappe.db.count` ignores or_filters, so count via
  `len(get_all(pluck="name", limit_page_length=0))` when or_filters present.

BFF: `Healthcare_next_app/src/app/api/appointments/route.ts` — forward the new query params.
Client: `appointments-client.tsx` — send params via apiParams; delete the in-memory search/billing/date filters.
Types: `AppointmentListParams` gains `search?`, `date_from?`, `date_to?`, `billing_status?`.

## Known limitations / notes
- `billing_status` server-side uses the invoice link + outstanding; the legacy
  "invoiced flag + paid_amount but no ref_sales_invoice" fallback in `_billing_for` is NOT captured
  by the DB filter (rare — Paid appts normally carry a ref_sales_invoice).
- Pending/Paid pre-resolve invoice-name sets, then `ref_sales_invoice IN (...)`. Fine at clinic scale;
  revisit if the invoice table grows large (IN-list size).
- Cannot run Frappe/bench tests in this environment — backend needs a bench run + the existing
  appointments test suite before merge.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
