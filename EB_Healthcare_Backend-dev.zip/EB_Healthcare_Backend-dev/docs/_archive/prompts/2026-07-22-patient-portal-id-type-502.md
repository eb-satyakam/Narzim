# 2026-07-22 — Patient portal /api/auth/me 502 (root cause + fix)

**Doc status:** record · **Created:** 2026-07-22 by Sarvesh-SocialAngel · **Updated:** 2026-07-22 by Sarvesh-SocialAngel · **Version:** 1.0

## Symptom
premycare.narzim.com reported a ~9.1% error rate. Vercel runtime logs showed:

- `GET /api/auth/me` → **502** `[frappe] upstream error { status: 500, excType: 'An unexpected error occurred.' }`
- `POST /api/auth/login` → 401 `AuthenticationError` (normal — wrong password)
- unauthenticated `GET /api/*` → 401 (normal — pre-login probes)

The "9.1%" was misleading: the 401s are normal auth behavior. The real defect
is the 502 on `/api/auth/me`, which is **deterministic** for every authenticated
patient (and also breaks the login flow, since `login/route.ts` calls
`get_my_account` after a valid `get_token`).

## Root cause
`remedisys_healthcare_ai.api.v1.patient_portal.api.get_my_account` runs:

```python
frappe.db.get_value("Patient", patient,
    ["name","patient_name","first_name","last_name","sex","dob",
     "blood_group","uid","id_type","mobile","email","phone","language"],
    as_dict=True)
```

`id_type` is a **Custom Field** on Patient (`Patient-id_type`), created by patch
`add_patient_id_type_field_20260707`. On `pre-healthcare.m.frappe.cloud` that
Custom Field **did not exist**, so the raw SQL emitted `SELECT ... id_type ...
FROM tabPatient` → MySQL `Unknown column 'id_type'` → caught by
`utils.handle_api_errors`' generic `except Exception` → masked HTTP 500
"An unexpected error occurred." → frontend maps 500 → 502.

The trap: the patch **is marked done in Patch Log** (ran 2026-07-16) yet the
field is gone — it was created then later dropped (app uninstall/reinstall or
site clone removes the app's Custom Fields but leaves the done-patch record).
Because Frappe never re-runs a done patch, no redeploy restores the field.

## Fix
1. **Immediate (live site):** recreated the `Patient-id_type` Custom Field on
   `pre-healthcare.m.frappe.cloud` (exact definition from the original patch).
   Verified the 13-field query now returns 200.
2. **Durable (this repo):** new idempotent patch
   `patches/v0/ensure_patient_id_type_field_20260722.py` (new name → re-runs on
   every site at next migrate, recreating the field if absent). Registered in
   `patches.txt`.
3. **Recommended follow-ups (not yet applied):**
   - Harden `get_my_account` so a missing optional profile field degrades
     gracefully instead of 500-ing the whole auth bootstrap.
   - Verify/repair the same Custom Field on the true production site if it is a
     separate Frappe site from the pre site.

## Not affected
Staff portal (`api/v1/auth/api.py::get_current_user`) — reads notification prefs
and roles, never `Patient.id_type`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-22 | Sarvesh | Initial version (header backfilled from git history) |
