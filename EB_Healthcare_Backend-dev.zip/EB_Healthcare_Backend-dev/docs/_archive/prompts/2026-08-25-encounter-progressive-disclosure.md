# Prompt archive — 2026-08-25 — encounter progressive disclosure (approach B)

**Doc status:** record · **Created:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The ask

> "can we apply second design .? first we make ui ux then fix bug okey"

Read as: apply **approach B — progressive disclosure** from the four-option table
presented in the 2026-08-24 encounter UX walkthrough, and do the UI/UX work
**before** the confirmed-bug queue (which reorders the previously recommended
sequence, where consent came first). The reordering is the user's explicit
decision, recorded here as such.

## Why this is cheaper than the original estimate

The walkthrough estimated approach B at 2–3 days on the assumption it had to be
built. It does not. Investigation on 2026-08-25 found the whole navigation half
of B **already written and then disconnected**:

- `soapSteps` (`encounter-screen.tsx:621`) — 10 sections each with a `done`
  predicate. Computed on every render, **consumed nowhere**.
- `SoapSidebar` (`encounter-screen.tsx:2342`, 204 lines) — step list with
  per-step `done` state, `firstIncomplete` (the "current step" pointer),
  rich per-step subtitles ("2 vitals recorded", "3 medications", "No diagnoses
  yet"), click-to-scroll, an edit mode to hide/restore steps, and an
  "AI fields reviewed by you" progress meter. **Never rendered.**
- All 24 `encounter.sidebar.*` i18n keys present in **both** `en.json` and
  `es.json`.

Removed by `d525312` (2026-07-22, "Remove SoapSidebar; widen page to
max-w-[1080px]") — a **width tradeoff, not a rejection of the concept**. Six
days later `2026-07-28` gave the freed right lane to the AI panel, so the
original slot no longer exists.

## The constraint this creates

`encounter-screen.tsx:1662` pins two lanes at every breakpoint: note (left,
flexible) + Copilot/Narzim AI (right, fixed). There is no third lane. Any
navigator must live inside a lane or float above one — it cannot go back
where it was.

## What was done

(filled in as the work lands)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Created before starting work |
