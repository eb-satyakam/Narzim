# Prompt Archive — Bruno Auth Collection Setup

**Doc status:** record · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-05 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-04
**Phase:** Pre-Phase 1 — local dev tooling
**Scope:** Web auth only (mobile is future; AI is deferred)

## Task

Set up Bruno API collection to test all Frappe auth endpoints used by the
Next.js BFF. Allows the team to verify Frappe OAuth2 is working before wiring
up NextAuth.js in `remedisys-web`.

## What was done

- Verified existing `bruno/auth/web/` folder is complete and matches
  `docs/AUTHENTICATION.md` (5 requests: login, refresh-token, logout,
  user-info, get-current-user).
- Fixed `bruno/environments/local.bru`: corrected `email` to `Administrator`
  (Frappe admin user name, not an email address).
- Removed AI Bruno files that were created out of scope (AI is deferred to
  Phase 1+; not the current work).
- Created `docs/SYSTEM_DESIGN_FRONTEND.md` (was referenced in ROADMAP.md
  and ADR-010 but missing).
- Created `prompts/` directory (was referenced in memory rules but missing).

## Files touched

| File | Action |
|---|---|
| `bruno/environments/local.bru` | Fixed `email` value; removed AI vars |
| `bruno/ai/` | Deleted (out of scope) |
| `docs/SYSTEM_DESIGN_FRONTEND.md` | Created (was missing, referenced in plan) |
| `prompts/` | Directory created |

## Next

Set up Frappe OAuth2 client (`Remedisys Web` app in Frappe Desk) so the
Bruno login request actually works with `client_id` + `client_secret`.
See `docs/AUTHENTICATION.md` §10 for the setup steps.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
