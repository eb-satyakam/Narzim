# Wire enable_suggestions to actually gate the suggestions feature

**Doc status:** record · **Created:** 2026-07-22 by Sarvesh-SocialAngel · **Updated:** 2026-07-22 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-21
**Branch:** feature/ai_v3 (both repos)

## Problem
`AI Settings.enable_suggestions` existed and was returned by `get_ai_flags`,
but nothing enforced it: `generate_suggestions` never checked it, and no
frontend code branched on it (it appeared only in the flags TYPE). The real
gate for the whole AI sidebar is `enable_ambient_documentation`. So the flag
was misleading — flipping it did nothing.

## Goal
Make `enable_suggestions` specifically gate the clinical-suggestions feature
(transcript → ClinicalSuggestion[]), independent of recording/transcription
(which stays gated by `enable_ambient_documentation`). A clinic can then record
+ transcribe without AI suggestions if desired.

## Changes

### Backend (authoritative) — `api/v1/ai/api.py`
- Add `_suggestions_enabled()` (single source of truth, reads the flag) and
  `_require_suggestions_enabled()` — mirrors the established
  `lab_panel_extraction._require_enabled()` pattern (throws PermissionError
  when off).
- Call `_require_suggestions_enabled()` inside `generate_suggestions` (after
  auth + encounter-read). Scope is deliberately just `generate_suggestions`;
  SOAP has its own flag, chat/autopopulate are separate features.

### Frontend (clean skip so no doomed calls) — 3 files
- `encounter-screen.tsx`: the flags fetch already reads
  `enable_ambient_documentation`; also read `enable_suggestions` into state and
  pass it down.
- `CopilotHost.tsx`: new `suggestionsEnabled` prop, forwarded into the provider
  factory (`new RealCopilotProvider(suggestionsEnabled)`).
- `real-provider.ts`: constructor takes `enableSuggestions = true`; `stop()`
  skips the two suggestion fetches when false (recording/transcript unaffected).

## Rule 7
Even if the frontend calls when disabled, the backend throws and the existing
`_fetchSuggestionHalf` try/catch swallows it → no suggestions, encounter
unaffected. Defense-in-depth, not a hard break.

## Test / rollout note
After this, `generate_suggestions` REFUSES when `enable_suggestions` is off.
dev currently has it OFF → must turn it ON for the suggestions E2E. Update the
E2E checklist prerequisite accordingly.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-22 | Sarvesh | Initial version (header backfilled from git history) |
