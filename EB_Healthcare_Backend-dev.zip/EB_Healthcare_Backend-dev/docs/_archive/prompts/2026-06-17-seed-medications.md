# Seed OPD Medications (100 common drugs)

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-17
**Author:** gaurav (via Claude)

## Prompt / intent

User supplied a procedural `frappe`-console script that seeds ~100 common
medications (Healthcare `Medication` doctype) plus their prerequisite lookup
records, and asked: "make a seed and add this medicine in db".

## What was built

`remedisys_healthcare_ai/scripts/seed/seed_medications.py` — idempotent seed,
matching the house convention of `seed_vital_signs_templates.py`:

- Ensures prerequisites: Item Group `Drug`, UOMs, Medication Classes,
  Dosage Forms, Prescription Dosage, Prescription Duration.
- Seeds 100 `Medication` records, each with a deterministic SKU
  (`DRUG-<GENERIC>-<STRENGTH><UOM>-<FORM>`) on its `linked_items` row.
- `Medication.after_insert` auto-creates the linked `Item`.

## Key correctness fix vs. the raw script

`Medication.validate()` (healthcare core) **throws** when a record has
`linked_items` but no `price_list` AND no default Selling Price List exists.
The raw script set neither and swallowed the resulting exceptions into the
error log — meaning rows would silently never insert. The seed resolves a
price list once (Selling Settings default → `Standard Selling` fallback) and
stamps it on every Medication so `validate()` passes.

## Run

```
bench --site marley.local execute \
    remedisys_healthcare_ai.scripts.seed.seed_medications.run
```

Idempotent: re-running skips Medications that already exist.

## Notes / open items

- Linked items seeded with `is_billable = 0` (per source script). If these
  drugs must appear on pharmacy/OPD Sales Invoices, flip to `1` and set a
  `rate` so an Item Price is created. Ties into the direct-encounter billing
  discussion (consult item + prescribed drugs on the same invoice).
- `Vitamin D3` strength is `1000 Milligram` in the source data — almost
  certainly meant to be IU; left as-supplied, flag to clinical owner.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
