# Bruno: Rx Pad, Copy to Rx Pad and Ask AI scenarios

**Doc status:** record · **Created:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## Prompt (summary)

Extend `bruno/encounter-flow` on `feat/langfuse-encounter-tracing` so the real v9 flow is
reproducible past `save_draft`: SOAP → Copy to Rx Pad, Ask AI adding a medication, Ask AI against
an existing medication, Clear → Copy again, Ask AI medication + Clear + Copy, duplicate Copy,
strength conflict, and Langfuse correlation for each. Do not change application behaviour. Reuse the
production endpoints and request shapes the v9 frontend uses. Record what actually happens rather
than assuming it. Keep `folder.bru` secret handling; never commit passwords, tokens or keys.
Mark each case as expected PASS, current limitation, regression test, or needs a product decision.

## Approach

Copy to Rx Pad is a chain, not one endpoint: backend extraction, browser-side catalog resolution,
browser-side merge with a duplicate rule and a dose-conflict guard, then `save_draft`. Bruno calls
the same backend methods and reproduces the browser merge in one shared script
(`bruno/encounter-flow/rx-scenarios/lib/rxpad.js`), copied rule for rule from
`v9/data/scribe-apply.ts`, `copilot/field-mapping.ts`, `copilot/apply-suggestion.ts`,
`shared/logic.ts` and `v9/encounter-v9-route.tsx`, each cited in the file. Langfuse correlation reads
the local Langfuse API with the same opaque session id as `langfuse_trace.session_for()`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
