# Prompt archive — 2026-08-24 — lab list 502 (missing custom field) + release migrate gate

**Doc status:** record · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The ask

> "what is this lab record could not loaded fix it" (screenshot: Patient 360 → Activity tab,
> yellow banner *"Lab records could not be loaded."*, patient MRN-2026-0000162)
> → "problem kya hai?"
> → "any problem in pre or prod"
> → "yes add the migrate gate to release notes"

## Diagnosis

The banner is the timeline's per-source failure row (`activity-timeline-tab.tsx:903` →
`error.sourceFailed`), shown when `useLabTests()` errors. It exists deliberately: a 502 used to
render identically to "this patient has never had a lab".

Root cause was environment drift, not a code defect:

- ADR-044 (`50139ad`, 2026-08-21) added `Lab Test.custom_report_group`, shipped as a **Custom Field
  fixture** and selected unconditionally in `api/v1/labs/api.py::_LAB_LIST_FIELDS`.
- The developer site had the code but had never been migrated, so the column did not exist:
  `OperationalError (1054, "Unknown column 'custom_report_group' in 'SELECT'")` → 500 → BFF 502.
- Confirmed the fixture defines exactly one field missing from the local database; the other four
  `Lab Test` custom fields were present.

The right-hand Lab Summary panel kept rendering because it reads stored summaries and never touches
the column — which made the failure look lab-specific rather than migration-shaped.

## Fix applied

`bench --site marley.local execute frappe.utils.fixtures.sync_fixtures --args "['remedisys_healthcare_ai']"`

Verified: column present, Custom Field created, `list_patient_lab_tests(patient="MRN-2026-0000162")`
→ HTTP 200, 12 rows. No code or repository file changed for the fix itself.

## Environment exposure

- **`main` (production): not affected.** `origin/main` lacks ADR-044; its `_LAB_LIST_FIELDS` has no
  `custom_report_group`, so it cannot hit this. Exposure begins with the 2026-08-24 promote.
- **`pre`: carries the code** (`origin/pre` identical to `origin/dev`). Frappe Cloud runs migrate on
  every site update, so it is expected correct — not verified against pre's database in this session.

## Documentation written

- `docs/release/2026-08-24-pre-to-main.md` — new. The `pre` → `main` release record, ported from the
  two PR bodies, with a new **"Deploy gate — `bench migrate` must complete"** section: why it is
  release-blocking (clinic-wide, all-or-nothing loss of lab history), a generalised post-deploy check
  that diffs every fixture custom field against real columns, the remedy, and the rollback
  interaction.
- Provenance header on `prompts/2026-08-24-release-notes-pre-to-main.md` brought into §9 form so the
  header gate passes.

## Deliberate omissions

- `pre` and production databases were not queried; the exposure analysis is from git only.
- No hardening of `_LAB_LIST_FIELDS` itself. The latent fragility — one un-migrated custom field
  takes down a patient's whole lab history instead of degrading — was raised and left for a decision
  rather than changed unasked.
- Nothing committed or pushed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Archived: lab-list 502 diagnosis, fixture sync fix, and the release migrate gate |
