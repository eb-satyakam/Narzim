# Bruno collection: v9 encounter flow

**Doc status:** record · **Created:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

## Prompt

> can i run all flow using bruno .. login first then .. bruno me ek /encounter
> flow name ki folder banao and collection banao...

## What was asked

A Bruno folder, `bruno/encounter-flow/`, that runs the v9 encounter flow end to
end against a local bench, in order:

1. Log in (eb_frappe_jwt).
2. Create or reuse the encounter from an appointment.
3. Consent, start the scribe session.
4. Add transcript lines (stands in for Deepgram, which Bruno cannot drive).
5. Upload a lab report in Ask AI, ask a question.
6. Analyze: speaker check, SOAP draft, accept, write the SOAP text to the
   encounter with save_draft.
7. Read the encounter back, stop the session.

Copy to Rx Pad is left out on purpose ("woo bad me dekhe ge").

## Scope rules

- Calls Frappe directly with a Bearer token, like the rest of `bruno/`. The
  Next.js BFF is not in the path.
- Local bench only. Never production (standing rule).
- No edit to `environments/*.bru`. New values are runtime vars set by scripts.
- The Ask AI and Analyze steps call the LLM and cost tokens.

## Follow-up (same day): "go deep, check nothing is missing, explain in the README how to test"

The first version (21 steps) was checked against the backend code, method by
method. Gaps found and fixed in v2 (28 steps):

- **No vitals step.** The SOAP Objective reads recorded vitals. Added step 14.
- **`sync_transcript` skipped** after the speaker check. The app does it
  (numbered from 0). Added step 20.
- **Advice list on screen load** was missing. Added step 04.
- **Regenerate** (`current_draft`) was not tested. Added steps 25–26.
- **No negative tests.** Added 05 (no recording before consent, PHI-2) and 28
  (a line after stop is `sealed`).
- **Deepgram key prerequisite** was not documented. Without it, lines are
  `sealed` and the SOAP comes back empty.
- **Free text in JSON bodies** (line breaks, quotes) would break `{{var}}`
  interpolation. Those bodies are now built in `script:pre-request`.
- **Developer log** in every step (STATUS / SENT / KEY / ERROR / VAR SET),
  with secret masking.

Verified: `bru run` against a dead port (all 28 parse, pre-request scripts
run); every script checked for syntax and dry-run on a fake response with
Node (no errors, no secret in the logs). Not run against a real bench yet.

Finding worth a ticket: `generate_soap_draft` / `resegregate_transcript` only
check encounter READ permission, so a non-practitioner can generate a SOAP draft.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Follow-up: deep check against the code, v2 of the folder (28 steps) |
| 1.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
