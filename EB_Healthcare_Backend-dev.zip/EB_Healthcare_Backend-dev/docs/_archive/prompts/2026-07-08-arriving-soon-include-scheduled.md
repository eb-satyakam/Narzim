# Arriving Soon — include "Scheduled" status

**Doc status:** record · **Created:** 2026-07-08 by Sarvesh-SocialAngel · **Updated:** 2026-07-08 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-08
**Phase:** Phase 1 (Dashboard / room queue) — bug fix, no scope change
**Requested by:** Sarvesh Shahi

## Request

User (via dashboard screenshot): any appointment with status Open or Scheduled,
for today, should appear in the "Arriving Soon" card. Screenshot showed header
stat "1 Scheduled" but Arriving Soon card showed "No one expected right now".

## Root cause

`api/v1/dashboard/api.py` `get_dashboard_data()` room-bucket loop only pushed
appointments into `arriving_soon` when `raw_status == "Open"`. Appointments
with raw status `"Scheduled"` fell through every room bucket (they only
appeared in the flat `appointments` list and in the coarse `queue_summary`
counter, which already groups `Open`/`Scheduled`/`Confirmed` as `"confirmed"`
via `_ERP_TO_BUCKET`).

Date scoping was already correct — `target_date` defaults to `frappe_today()`,
so no additional "today" filter was needed.

## Change

`if raw_status == "Open":` → `if raw_status in ("Open", "Scheduled"):` in the
arriving_soon branch, matching the existing no-"advanced"-guard pattern used
for `Open`.

## Files touched

- `remedisys_healthcare_ai/api/v1/dashboard/api.py`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-08 | Sarvesh | Initial version (header backfilled from git history) |
