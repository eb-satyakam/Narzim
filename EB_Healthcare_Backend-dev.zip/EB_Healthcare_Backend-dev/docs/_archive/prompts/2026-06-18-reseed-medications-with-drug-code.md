# 2026-06-18 — Reseed Medications with National Drug Code

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

## Problem
Medications were seeded before `national_drug_code` was added to the MEDICATIONS list
in `seed_medications.py`. The idempotent skip logic (existing → skip) means re-running
the seed does NOT backfill the field on already-existing records.

## Request
Delete all existing Medication records (+ their linked Drug Items), then re-run the
seed so every record lands with `national_drug_code` populated.

## Output
`remedisys_healthcare_ai/scripts/seed/delete_and_reseed_medications.py`

## Approach
- Delete all Medication docs whose names match the seed's naming pattern
- Delete linked Items (SKU prefix `DRUG-`) to avoid orphan stock items
- Call `seed_medications.run()` to recreate everything cleanly
- Idempotent: safe to re-run; skip if no medications exist

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
