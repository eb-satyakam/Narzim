# 2026-07-31 — Copilot lane gating + the transcript "Error" state

**Doc status:** record · **Created:** 2026-07-31 by Sarvesh-SocialAngel · **Updated:** 2026-07-31 by Sarvesh-SocialAngel · **Version:** 1.0

Companion to [2026-07-31-admin-cannot-sign-encounter.md](2026-07-31-admin-cannot-sign-encounter.md)
(same session, tasks 2 and 3 of 3). Frontend-only —
`Healthcare_next_app`, no backend change.

## Prompts (verbatim intent)

> 2. "if i have not practioner role (transcript and chat will desable)"
> 3. "remove this arror from transcript" — screenshot: `Narzim AI · Error · 00:01 · 0 lines`
> then: "form ko center me kar do" (after the AI lane disappeared)

## Task 2 — gate the AI lane

Before: `canUseCopilot` was role-only
(`frontendRoles.includes("practitioner")`), and it gated **only** `CopilotHost`.
`NarzimAIChatBar` had no gate at all. Two consequences:

- A nurse or admin saw an empty 20% transcript box (CopilotHost null-returns
  when disabled) sitting above a fully working Narzim AI chat.
- `admin@chavitos.health` holds `EB_Practitioner`, so it passed the role check
  outright and got the full copilot on another practitioner's encounter.

After:

- `canUseCopilot = isPractitionerRole && canSign` — ownership, the same ADR-038
  rule as the Sign button. The copilot records a consultation and drafts into a
  note that carries the assigned practitioner's Cédula Profesional; a colleague
  or an admin reviewing that note has no business recording the room.
- The **entire** right lane (transcript + chat) is wrapped in `canUseCopilot`, so
  a non-owner gets no AI lane rather than a half-dead one.
- Note alignment follows the lane: `mr-auto` (snug against the lane, per the
  2026-07-28 request) while it renders, `mx-auto` once it is hidden — otherwise
  the note sat left with the lane's width as dead space (the "form ko center"
  follow-up).

Deliberately mounted conditionally: `canSign` is settled before EncounterScreen
renders (the page holds a loader until the encounter resolves), so the gate never
flips mid-session and never tears down a live recording — the hazard
CopilotHost's always-mounted comment warns about.

Accepted scope change: a nurse documenting a draft (ADR-022) and an admin both
lose the Narzim AI chat they had until today. That is the explicit instruction
("transcript and chat will desable"), not an oversight.

## Task 3 — the "Error · 00:01 · 0 lines" header

Diagnosed, not guessed. Two findings:

1. **Deepgram is healthy.** A probe (`scratchpad/dg_probe.py`, not committed)
   minted a token through `integrations/deepgram.py::mint_session_token` and
   opened the *same* WSS URL with the same `["Bearer", token]` subprotocol the
   browser uses: handshake 101, socket held open 12s, no close frame.
   `model=nova-3 language=multi diarize=1 multichannel=0`, 50 keyterms (at the
   cap), ttl 3900s. So the key, params and keyterm budget are all fine.

2. **`AI Settings.enable_ambient_documentation = 0` on marley.local** — and
   `encounter-screen.tsx` fetched that flag into `aiEnabled` (line 813), stated
   in its own comment that "recording/transcription is gated by
   enable_ambient_documentation (aiEnabled)" … and then never read the variable.
   TypeScript had been reporting it unused. So on a site with recording switched
   OFF the panel still auto-started a session, and the physician got a bare
   `Error` to interpret — a Rule 7 violation (an unavailable AI dependency must
   show a clear unavailable state).

Fix: `canRecord = canUseCopilot && (aiEnabled === true || readOnly)` now gates
the transcript box **and** its drag handle; chat is untouched by the flag (it is
a separate feature) and takes the whole lane when recording is off.

- `=== true`, not a truthy default: `aiEnabled` is `null` until the flag fetch
  lands, and an optimistic mount would start a session we might tear straight
  back down.
- `|| readOnly` keeps a signed encounter's ARCHIVED transcript reviewable even on
  a clinic that has since turned recording off (the host's auto-start effect is
  already readOnly-guarded, so nothing records there).

Also added, since it cost the whole investigation: the Deepgram close frame's
`code`/`reason` were being discarded in both the mid-session `close` handler and
the open-race `error` handler in `real-provider.ts`, so a socket that died one
second in left no evidence anywhere. They are now logged
(`[copilot] Deepgram socket closed {code, reason, wasClean}`) and folded into the
user-facing message. Codes, not content — no PHI (Rule 10).

## Still unverified

Whether in-browser recording works once
`enable_ambient_documentation` is switched on — that path was never reachable on
this site. If it errors again, the new console line names the close code
(1008 = param/policy rejection, 1011 = Deepgram server error, 4008/4009 =
timeouts, 1006 = network/no close frame).

## Follow-ups in the same session (UI polish)

- **Chevron removed from the docked lane** (`CopilotPanel.tsx`) — kept for the
  floating pill variant only. In column mode it was redundant (the transcript
  auto-expands when lines arrive) and with 0 lines it fell through to
  `handleClose`, which means nothing for a permanently docked lane.
- **AI lane styled as a floating card** (`encounter-screen.tsx`) — `my-3 mr-3`,
  `rounded-sm`, the note's own amber drop shadow, `overflow-hidden`, and the
  `border-l` dropped, so it matches the SOAP paper card instead of being a
  full-bleed column with sharp corners against the tan background. Height is
  `h-[calc(100%-1.5rem)]`, not `h-full`: the `my-3` gutter needs the 1.5rem back,
  and it must remain a DEFINITE height because the transcript box sizes itself as
  a percentage of the lane.

## Files changed

- `src/components/narzim/encounter/encounter-screen.tsx` — `canUseCopilot`
  (+ownership), new `canRecord`, lane + transcript-box gates, note centering,
  lane card styling.
- `src/components/narzim/encounter/copilot/real-provider.ts` — close-code
  diagnostics in the persistent `close`/`error` handlers and the open race.
- `src/components/narzim/encounter/copilot/CopilotPanel.tsx` — chevron scoped to
  the floating variant.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
