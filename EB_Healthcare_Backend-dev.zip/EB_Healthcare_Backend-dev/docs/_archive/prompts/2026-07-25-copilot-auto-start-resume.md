# AI Copilot — auto-start + resume-on-navigate (remove consent gate)

**Doc status:** record · **Created:** 2026-07-25 by Sarvesh-SocialAngel · **Updated:** 2026-07-25 by Sarvesh-SocialAngel · **Version:** 1.0

Date: 2026-07-25
Branch: feature/ai_v3
Repos: EB_Healthcare_Backend (remedisys_healthcare_ai) + EB_Healthcare_EHR (Healthcare_next_app)

## User request (verbatim intent, romanized Hindi/English)

- "JAISE HI MAI ENCOUTER PAGE PER AOO WAISE HI MERA AUDIO RECDOIN CHALU HO JAYE" —
  the moment I open the encounter page, recording must auto-start.
- "IS I MOVE ANOUTER PAGE IT RESUME" — if I navigate away and come back, the
  recording resumes.
- "JO AREAD SELECT KARA HAI USEM TRANSCRIPT SHOW KAROO" — on return, show the
  transcript already captured for this encounter.
- "START BUTTON HATAA DOO" — remove the Start Encounter button.
- "DONT NEED CONCENT" / "NHI CONECT NHI CHALYE REMOVE THIS" — remove the consent
  gate entirely (for now).
- "EXICUTE IT".

## Compliance note (documented, not silently dropped)

The "Start Encounter" button was the LFPDPPP verbal-consent confirmation
(Rule 10 / ADR-009, `AI Encounter Session.consent_obtained`). Removing it is a
**temporary dev shortcut** at the user's explicit, repeated instruction. Every
bypass is code-commented as such and MUST be reviewed/reverted (or replaced with
a proper "ask consent once at encounter creation") before real clinical use.

## Design

Resume uses the backend's already-documented "idempotent re-entry" path:
`start_session(consent=true)` reattaches to an existing Draft/Recording
`AI Encounter Session` for this (encounter, user) and mints a fresh Deepgram
token (`sessions.py` docstring). So one session stays `Recording` across
in-app navigations; recording continues appending; it closes only on explicit
Stop / "End & fill".

Changes:

1. Backend `api/ai/sessions.py` — new READ `get_active_session(encounter)`:
   returns the caller's active (Draft/Recording) session + its persisted
   `AI Transcript Segment` rows (ordered), so the browser can re-display the
   transcript on return. Permission-checked (Patient Encounter read). No new
   doctype, no migration.

2. Frontend route `app/api/ai/session/active/route.ts` — thin POST shim →
   `get_active_session` (mirrors `session/route.ts`).

3. Frontend `copilot/real-provider.ts`:
   - `start()` — on a FRESH mount (finalSegments empty; distinguishes from
     pause→resume which reuses the same instance) hydrate the prior transcript
     via `_hydrateTranscript()`: seed `finalSegments` + emit to the UI so the
     eventual "End & fill" transcript is complete and the panel shows history.
   - `dispose()` (unmount / navigate-away) — persist the transcript (so nothing
     is lost) and DO NOT stop the session, so the reattach path can resume it.
     Explicit Stop/End still close the session normally.

4. `copilot/CopilotHost.tsx` — auto-start on mount (done 2026-07-25).
5. `copilot/CopilotPanel.tsx` — `consented` defaults true so the consent screen
   never renders (done 2026-07-25).

## Known tradeoff (documented)

Leaving the session `Recording` on navigate-away means a session abandoned
without an explicit Stop/End stays `Recording` (no `ended_at`). Bounded by
Deepgram token TTL / `max_session_minutes`; acceptable for this dev-only
bypass. A production version should reinstate consent + a proper end-on-unload
(sendBeacon) or idle-timeout sweep.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-25 | Sarvesh | Initial version (header backfilled from git history) |
