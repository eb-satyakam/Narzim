# AI Copilot — dual-mic (multichannel) speaker separation

**Doc status:** record · **Created:** 2026-07-15 by Sarvesh-SocialAngel · **Updated:** 2026-07-15 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-15
**Repos:** both (`remedisys_healthcare_ai` backend, `Healthcare_next_app` frontend)
**Branch:** `feature/ai_v1` (both repos)
**Trigger:** live testing showed the AI Copilot still mislabels doctor vs patient even
after the TTL fix (see `2026-07-15-deepgram-ttl-field-name-bug.md`) and the switch to
`nova-3-medical`. User asked whether a different model would fix speaker detection.

## The question — verified against docs, not assumed

Would switching the Deepgram model improve who-is-labeled-doctor-vs-patient?

**No.** Speaker separation ("diarization") is a subsystem separate from the
transcription model. Confirmed against Deepgram's official docs:

- Diarization is compatible with all Nova models — it is not a per-model capability you
  upgrade by changing the model.
  ([docs/diarization](https://developers.deepgram.com/docs/diarization))
- For **live streaming**, only the **v1 diarizer** is available; the improved **v2
  diarizer is batch-only** and errors on a stream. So there is no "better diarizer"
  toggle for real-time either.
- Deepgram's own guidance: when you can capture speakers on separate channels, use
  **multichannel** instead of relying on diarization — with one person per channel,
  separation is deterministic rather than a voice-fingerprint guess.
  ([docs/multichannel-vs-diarization](https://developers.deepgram.com/docs/multichannel-vs-diarization))

Root situation: two people sharing one laptop mic is the hard case for diarization.
The user confirmed the real deployment will use an **isolated close-talk mic per person**
(headset/lapel) — exactly the setup where multichannel works.

Also noted: the config language is `es-MX` but testing was in English; a language
mismatch degrades both transcription and diarization, so single-mic tests looked worse
than production will.

## The fix — multichannel, channel 0 = Doctor, channel 1 = Patient

Verified response shape from
[docs/multichannel](https://developers.deepgram.com/docs/multichannel): in streaming,
each Results message carries `channel_index: [current, total]` (e.g. `[0,2]`, `[1,2]`);
only `multichannel=true` is needed (channel count detected from the audio container).

- **Backend** (`integrations/deepgram.py`): new default-OFF `AI Settings.deepgram_multichannel`
  flag (added via migration patch). When ON, `mint_session_token` sets
  `multichannel=true` and omits `diarize` (they are alternatives). Flag also surfaced on
  `/api/ai/flags` so the frontend can render the mic picker before a session exists.
- **Frontend** (`real-provider.ts`): when the session's returned `params.multichannel`
  is true, capture two mics via Web Audio — two `getUserMedia({deviceId})` → a
  `ChannelMergerNode` (doctor→ch0, patient→ch1) → `MediaStreamAudioDestinationNode` →
  one `MediaRecorder`. Message handling maps `channel_index[0]` → speaker deterministically,
  bypassing the per-word diarization path. Consent step gains two mic dropdowns.
- The single-mic + diarization path stays the default (flag OFF) and is unchanged.

## Decision: opus stereo first, PCM fallback → PCM was required

Initially shipped **webm/opus stereo** (reused the existing MediaRecorder chunking +
token-rotation infra, minimal diff), with a documented fallback to raw linear16 PCM if
testing showed channel bleed.

**Live testing showed it did not separate** — everything landed on Doctor. Root cause,
confirmed against Deepgram docs: multichannel live streaming does **not** read
per-channel data out of an opus/webm container; it requires raw interleaved
**linear16 PCM** with `encoding=linear16&channels=2&sample_rate=<n>&multichannel=true`
(see [docs/multichannel](https://developers.deepgram.com/docs/multichannel),
[docs/determining-your-audio-format-for-live-streaming-audio](https://developers.deepgram.com/docs/determining-your-audio-format-for-live-streaming-audio)).

So the fallback became the implementation:
- **Backend** declares `encoding=linear16`, `channels=2`, `sample_rate=48000` (constant
  `_MULTICHANNEL_SAMPLE_RATE`) in the multichannel branch.
- **Frontend** replaced `MediaRecorder(mergedStream)` with an **AudioWorklet** (loaded
  from an inline Blob module) that interleaves the 2-channel merged output to int16 and
  posts ~250ms PCM batches, forwarded to the Deepgram socket. The `AudioContext` is
  forced to exactly 48 kHz (matching the backend) and `resume()`d (a suspended context
  streams silence). Token rotation is simpler in PCM mode — chunks are self-contained,
  so rotation just swaps the socket (no webm-header restart). Single-mic path is
  unchanged (webm/opus + diarization).

Lesson reinforced: even a doc-verified response-shape (`channel_index`) isn't enough —
the transport/encoding constraints (raw PCM, not container) had to be checked too.

## Follow-up: model/language + raw capture (second-speaker not recognized)

Live two-mic testing: the operator's own voice transcribed, the second speaker's did
not. Two independent causes, both fixed:

1. **Model/language mismatch (doc-verified).** `AI Settings.deepgram_model` was
   `nova-3-medical`, which per
   [models-languages-overview](https://developers.deepgram.com/docs/models-languages-overview)
   is **English-only** (`en`, `en-US`, …), while `deepgram_language` was `es`. Anything
   non-English couldn't be transcribed. Switched to **`nova-2` + language `multi`**
   (nova-2 `multi` = Spanish + English) — a settings change, no code. Multichannel is
   model-agnostic so it still applies.
2. **Browser DSP gating the 2nd mic.** Both multichannel mics now open with
   `echoCancellation/noiseSuppression/autoGainControl: false` — the single-mic-call DSP
   defaults were suppressing the second speaker (treated as bleed/room noise) in a
   two-mic-one-room setup.

Added a non-PHI `console.debug` of `channel_index` in the multichannel handler to tell
"channel 1 silent" (mic/capture) apart from a parsing bug during testing.

## Lesson

Same as the TTL entry: don't switch models/build workarounds on an assumed cause —
check the vendor's docs for how the feature actually works. Here the docs made clear the
lever is capture topology (multichannel), not model choice, and gave the exact response
field (`channel_index`) to map channels to roles without guessing.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-15 | Sarvesh | Initial version (header backfilled from git history) |
