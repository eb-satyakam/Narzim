# 2026-09-23 — Splunk Observability Cloud (Free Edition) evaluation for Phase 1 observability

**Doc status:** record · **Created:** 2026-09-23 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-23 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

**Scope:** Phase 1 observability for Narzim + Remedisys, Guided Encounter only.

## Prompt (verbatim)

We are reconsidering Phase 1 observability for Narzim/Remedisys.

Current Phase 1 scope:
- Guided Encounter only
- Need complete technical tracing of one Encounter
- Admin/support should be able to search by encounter_id and understand what happened
- Trace: Encounter open -> consent -> AI session -> Deepgram -> recording -> transcript autosave -> token rotation -> SOAP generation -> encounter save -> sign
- Need frontend -> BFF/API -> Frappe/backend correlation
- Need latency, status, errors, warnings and failures
- Need session_id + encounter_id + trace_id correlation
- Need dashboards and alerts
- Must be PHI-safe: no transcript, audio, SOAP content, patient details, tokens, JWTs or LLM prompt/response in telemetry
- Telemetry must never block or break the Encounter flow
- We want maximum use of free tier initially and only move to paid when required
- We do NOT want to build a custom telemetry database or custom observability platform if an existing platform solves it.

We are considering Splunk Observability Cloud Free Edition for Phase 1.

Evaluate whether Splunk can fully satisfy Phase 1.

Please investigate the CURRENT Splunk 2026 capabilities and distinguish:
1. What Splunk Observability Cloud Free Edition provides.
2. What is NOT available in Free.
3. What requires paid plans.
4. Whether distributed tracing/APM works for our frontend -> BFF -> Frappe flow.
5. Whether OpenTelemetry can be our instrumentation layer.
6. Whether we can correlate encounter_id / session_id / trace_id across frontend, API and backend.
7. Whether we can create an Encounter-focused dashboard that a NON-TECHNICAL admin can understand.
8. Whether Admin can search an Encounter ID and see its complete timeline.
9. Logs + metrics + traces correlation.
10. Deepgram API/WebSocket timing and failures.
11. SOAP/LLM API timing and failures.
12. Frappe backend visibility.
13. Error tracking and alerting.
14. Vercel/Next.js frontend compatibility.
15. Whether Splunk requires an agent/collector and what the simplest architecture would be.
16. Whether we can use OTLP directly or need Splunk-specific instrumentation.
17. Free-tier limits relevant to our expected Guided Encounter usage.
18. What happens when we exceed the free tier.
19. Production healthcare/compliance considerations, especially HIPAA/BAA and whether Free Edition can be used for production healthcare telemetry.
20. Data retention in Free vs paid plans.
21. Any important limitations that would prevent Splunk from satisfying Phase 1.

Then give me a clear conclusion:
A. "Splunk fully satisfies Phase 1"
B. "Splunk satisfies Phase 1 with these limitations"
C. "Splunk does NOT satisfy Phase 1"

If B or C, identify exactly what is missing.

Also provide the recommended Phase 1 architecture if Splunk is selected:
Guided Encounter -> OpenTelemetry -> Splunk/OTLP ingestion -> Splunk Observability -> Admin dashboard

Do NOT recommend building a custom telemetry database unless Splunk genuinely cannot provide a required capability.

Finally, compare Splunk Free vs the minimum paid Splunk plan we would need, specifically for our Phase 1 requirements.

Be concrete. Do not give a generic Splunk overview.

## Outcome

**Conclusion C — Splunk does NOT satisfy Phase 1.** Three structural failures:

1. Splunk Observability Cloud stores no logs at all. Log Observer Connect only queries logs already
   held in Splunk Cloud Platform, a separate paid product. Requirement 9 cannot be met at any tier.
2. No BAA on Free Edition. Splunk's BAA page excludes free licences and voids any BAA signed against
   one.
3. No supported way to give a non-technical admin an encounter timeline.

Secondary limits: 8-day trace retention, `encounter_id` cannot be indexed, 10-minute span
accumulation window, 15-host free limit fits Vercel badly, $0 liability cap, no SLA, 30-day
inactivity termination.

Paying Splunk buys a BAA, an SLA and slightly longer retention. It does not fix failure 1 or 3.

Superseded by the Grafana design: [`docs/grafana/PHASE1_ENCOUNTER_TRACING.md`](../../grafana/PHASE1_ENCOUNTER_TRACING.md).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-23 | Sarvesh (AI-assisted) | Initial version. Splunk evaluation, conclusion C |
