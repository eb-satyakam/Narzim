# AI Settings — configurable OpenAI reasoning effort

**Doc status:** record · **Created:** 2026-07-21 by Sarvesh-SocialAngel · **Updated:** 2026-07-21 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-21
**Task:** Expose `reasoning_effort` (minimal/low/medium/high) as an admin-configurable
field in AI Settings, instead of hardcoding `"low"` in `integrations/openai.py`.

## Why

`reasoning_effort` was benchmarked live (2026-07-21) on easy + hard consultation
transcripts. Findings drove the default:

- Latency is dominated by output-token generation; reasoning models (gpt-5-*)
  spend 50%+ of completion tokens on hidden reasoning at the default ("medium")
  effort → 60–177s per suggestions call.
- On an **easy** strep case all effort tiers produced equivalent clinical output;
  `medium` was just slower/costlier.
- On a **hard/ambiguous** case (child on valproate, aspirin given, post-strep
  migratory arthritis — ARF vs serum-sickness vs JIA/SLE):
  - `minimal` (0 reasoning): thinner differential, and *suggested aspirin*
    against the physician's explicit "hold off" — too shallow for edge cases.
  - `low` (~900 reasoning tokens): caught all 5 clinical traps, richer
    differential, appropriately conservative, ~38s. **Sweet spot.**
  - `medium`: most complete differential + most sophisticated plan (benzathine
    penicillin for ARF) but 2.5x slower (86s).
- Danger-flag *recall* was robust at every gpt-5-mini tier. (A cross-model test
  showed gpt-4o-mini silently dropped safety flags on the hard case — hence we
  stay on gpt-5-mini; that is a separate decision, not this field.)

Default is therefore `low`. The field lets an admin move to `medium`/`high` for
harder case-mixes, or `minimal` for cost/speed on simple-triage deployments,
without a code change.

## Changes

1. `remedisys_healthcare_ai/doctype/ai_settings/ai_settings.json`
   - New Select `openai_reasoning_effort` (options minimal/low/medium/high,
     default `low`), placed after `openai_model`, `depends_on` OpenAI provider.
2. `integrations/openai.py`
   - `_call()` reads the setting for reasoning models; falls back to `low` if the
     field is absent/blank (upgrade-safe before migrate).

## Notes

- AI Settings is our own custom doctype (Rule 1 OK — no core edit). Additive
  Select field with a default; applied on `bench migrate`. Non-reasoning models
  (gpt-4o) ignore the field — `reasoning_effort` is only sent when
  `_is_reasoning_model()` is true.
- Anthropic has no equivalent knob; field is OpenAI-only.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-21 | Sarvesh | Initial version (header backfilled from git history) |
