# 2026-06-18 — Backfill National Drug Code on 183 Remaining Medications

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

## Problem
183 Medication records (71 bare-name generics + 112 cardiology-patch records)
have no `national_drug_code`. Our 100-record seed uses NDC-00001 → NDC-00100.

## Request
Assign NDC-00101 onward to all 183, sorted by name (deterministic).

## Output
`remedisys_healthcare_ai/scripts/seed/backfill_drug_codes.py`

## Approach
- Query `tabMedication` WHERE national_drug_code IS NULL OR ''
- ORDER BY name (deterministic, re-runnable)
- frappe.db.set_value per record (no validate/save overhead)
- Start counter at max existing NDC number + 1
- Idempotent: skip any record that already has a code

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
