# NH-135 — encounter read permission bug: investigation and fix plan

**Doc status:** record · **Created:** 2026-09-15 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-15 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

**Date:** 2026-09-15
**Session task:** Investigate Jira NH-135 ("Draft Encounter Shows 'This Encounter
Page Not Found' for Doctor"), find the real root cause, and plan a fix.
**User ask (verbatim):** "i want to work on this tickets ..." (NH-135), followed
by extended back-and-forth on diagnosis and a signing/reassignment policy
proposal.

## Starting state (checked, not assumed)

- Ticket fetched live via Atlassian Rovo MCP (connector was authorized
  mid-session): Bug, Highest priority, reporter/assignee sarvesh shahi,
  labels `AI-Encounter`/`bug`/`draft-encounter`, no prior comments.
- Backend repo `remedisys_healthcare_ai` at `/Users/apple/marley-bench/apps/remedisys_healthcare_ai`,
  frontend `Healthcare_next_app` at `/Users/apple/Healthcare_next_app`.

## False starts (recorded so they aren't repeated)

1. **First hypothesis (wrong):** doctor blocked from reading a colleague's
   draft via the `practitioner` User Permission cascade. Disproven by direct
   live impersonation test — `get_encounter`/`save_draft` both return 200 for
   a nurse-then-different-doctor draft handoff on `dev`.
2. **Branch-gap claim (wrong, corrected on the ticket):** compared local
   `pre`/`dev` branches without `git fetch` first, producing a fabricated
   "pre is 965 commits behind dev" claim, posted to Jira, then corrected once
   a fetch showed the real gap was 3 commits. Saved as
   `feedback_git_fetch_before_branch_compare.md` in memory — hard rule now:
   always fetch and diff against `origin/<branch>`, never bare local names.

## Real root cause (verified live, not guessed)

`custom_encounter_done_by` (ADR-039's "who actually signed" field) was meant
to be exempted from Healthcare core's automatic practitioner User Permission
lock by patch `exempt_encounter_practitioner_user_permission_20260807.py`
(Jira NH-49/52), but the field didn't exist in the DB yet when that
one-time patch ran, so it was silently skipped (`if not
frappe.get_meta(doctype).has_field(fieldname): continue`). Confirmed via
direct `frappe.has_permission()` tests on the dev bench: a doctor is blocked
from reading ~70 signed encounters (every one where the field is set), and
the same record silently disappears from the patient's chart list — not an
error, an empty-looking history. Nurse and Front Desk, having no Healthcare
Practitioner record, are unaffected — they can read what the treating doctor
cannot.

Fix value already sits in the repo, wrong:
`remedisys_healthcare_ai/fixtures/custom_field.json` →
`custom_encounter_done_by` → `"ignore_user_permissions": 0` (should be `1`).

## Decisions

1. Split into Part A (fix the read bug, isolated, do first) and Part B/C (a
   separately-agreed signing/reassignment policy change, superseding
   ADR-039 — only the assigned practitioner may sign/cancel; Front Desk and
   Admin only, not Nurse, may reassign a Draft encounter).
2. Jira NH-135 corrected via comment (root cause was wrong twice, corrected
   both times) rather than left misleading; status moved Cancelled → To Do →
   added to active sprint "NH S1 Release close-out" per user request.
3. Full plan written and approved: `/Users/apple/.claude/plans/optimized-forging-reef.md`.

## Next step

Execute Part A subtasks (A1 fixture fix → A2 frontend error-message fix →
A3 regression-guard test) one at a time per explicit user instruction, each
verified live before moving to the next.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-15 | Sarvesh-SocialAngel (AI-assisted) | Initial version — investigation and plan, as of the point Part A1 was still pending explicit go-ahead. See `WORK_LOG.md` 2026-09-16 for what actually happened next (A1 applied and verified live; the signing/reassign draft ADR is being revised before it's committed) — this record is frozen and left as-is per `Doc status: record`. |
