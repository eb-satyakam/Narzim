# Set up Jira for the Remedisys project

**Doc status:** record · **Created:** 2026-09-12 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-12 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

**Date:** 2026-09-12
**Session task:** Set up Jira as the issue tracker for Remedisys.
**User ask (verbatim):** "i want to setup jira for my this project."

## Starting state (checked, not assumed)

- Backend repo: `github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend`,
  current branch `docs/remedisys-v2-target-architecture`.
- Frontend repo: `/Users/apple/Healthcare_next_app` (separate repo).
- No Jira reference anywhere in the backend app. Grep for "jira" over all
  `.md`, `.json`, `.yml`, `.yaml`, `.py` files returned nothing.
- Work is tracked today in Markdown only: `ROADMAP.md` (956 lines),
  `WORK_LOG.md` (10,775 lines), `docs/KNOWN_ISSUES.md` (570 lines),
  `docs/STATUS.md` (128 lines), `docs/planning/`, `docs/adr/`.
- Branching policy in force: `dev` -> `pre` -> `main`.

## Scope question put to the user

Four possible meanings of "set up Jira", asked as one question:

1. Design the project structure in Markdown first, then create it in Jira.
2. Connect this Claude session to an existing Jira site (Atlassian MCP).
3. Bulk import a backlog from `ROADMAP.md` + `docs/KNOWN_ISSUES.md` by CSV.
4. Wire Jira into the git and PR workflow only.

## Decisions

1. **One Jira project, not one per product.** Key `NH`, name **Narzim Healthcare**,
   team-managed Scrum. Each repo becomes a component. Same few people work across
   backend, EHR and portal, so one backlog and one board. Splits later if a product
   gets its own team.
2. **Board columns mirror the branching policy:**
   `Backlog -> Ready -> In Progress -> In Review -> On Staging -> Done`,
   matching feature branch -> PR to `dev` -> `pre` -> `main`.
3. **Issue types:** Epic, Story, Bug, Task, Spike, Sub-task.
4. **Git link:** one "GitHub for Jira" install on the `eBasics-Services-P-Limited`
   org, covering every repo at once.
5. **`narzim-platform` dropped** (user, 2026-09-12). `/Users/apple/narzim` has no
   git remote and is not wanted in Jira.
6. **Advocase excluded.** `EB_Advocase_Frontend` and `EB_Advocase_Backend` are a
   different product, untouched for 2 months.
7. **`Remedisys-Frontend` excluded.** Untouched for 4 months.

## Components (final)

| Component | Repo | Last push | Git link |
|---|---|---|---|
| `backend` | `EB_Healthcare_Backend` | 19 hours ago | yes |
| `ehr-web` | `EB_Healthcare_EHR` | 17 hours ago | yes |
| `portal-web` | `EB_Healthcare_PatientPortal` | 1 day ago | yes |
| `portal-mobile` | `EB_Healthcare_Patient_MobileApp` | 1 day ago | yes |
| `marketplace` | `EB_Healthcare_Marketplace` | 11 days ago | yes |
| `auth-lib` | `eb_frappe_jwt` | 3 months ago | yes |
| `ehr-mobile` | `EB_Healthcare_EHR_MobileApp` | empty remote | blocked, see below |

## Findings worth keeping

- **`EB_Healthcare_EHR_MobileApp` is empty on GitHub.** `git ls-remote --heads`
  returns nothing. The local clone has 2 commits and `git status` reports
  `origin/main [gone]`. That work exists only on the user's Mac. Not pushed by
  Claude; the user decides.
- **`EB_Healthcare_Marketplace` is the marketplace** (user's own name for it).
  Next.js 15, package `narzim-next`, ~33 public routes under `src/app/(site)/`
  plus `/api/schedule` and `/api/availability` for Google Calendar demo booking.
  `/` is a client-side passkey gate. Its README is stale and still describes an
  HTML-to-Next conversion.
- **`EB_Healthcare_Patient_MobileApp`** is real, not a scaffold. Expo, package
  `mycare`, 6 commits to 2026-09-10, ships patient education, signup, messaging,
  tasks and a recovery check-in card.
- All healthcare repos in the org are **private**, including `eb_frappe_jwt`.

## Branch and commit convention (proposed)

```
branch   feature/NH-123-encounter-billing
commit   NH-123 add invoice hook to encounter submit
PR       [NH-123] Encounter consultation billing
```

## Work done

Wrote `docs/planning/JIRA_SETUP.md`, 2,839 lines, 33 sections, `draft` status.
Nothing created in Jira. No integration installed. No commit, no push.

Read first, per the user's instruction: `CLAUDE.md` (66 KB), `CONTRIBUTING.md`,
`docs/STATUS.md`, `docs/KNOWN_ISSUES.md`, `docs/planning/`, `docs/adr/` (64 ADRs),
`WORK_LOG.md` header and template, and git contributor history across both repos.

Mid-session the user supplied the real tracker: a Google Sheet, "Narzim / My Care -
Product & Engineering Task Tracker", id
`1Q8AlMdYzXeMn-88CjyYRB5wtD53ur6bMOGv0xtR49bc`. It became Section 33 of the spec.

## Sheet analysis (counted from the rows, 2026-09-12)

88 task rows, numbered 1 to 96, missing 7, 8, 19, 26, 48, 60, 62, 74.

| Status | Rows |
|---|---|
| Done | 57 |
| Not Started | 21 |
| In Progress | 4 |
| Baclog (sic) | 3 |
| Dev Complete | 2 |
| blank | 1 |

**The sheet's own summary block is stale and wrong**: it claims 34 total, 49 Done,
9 Not Started. Formulas were never extended past the original rows.

Other findings that shaped the design:

- `Notes / Blockers` is **empty on all 88 rows**. `Dependencies` has one value
  (`AWS`, row 37). A free-text blocker column owned by nobody.
- **No repository or component column exists at all.** Biggest migration gap,
  recorded as OD-10.
- Data quality degrades from row 40: `Category` starts holding the task title.
- `Estimated Time (Days)` is mostly not durations: `Done`, `Auto save`,
  `Need to discuss`, `after 3 august`, `Hot fix`. About 40 rows get no estimate.
- Release columns carry real delivery dates with no year, mixed with the literal
  word `Released`. Reconstructed into NH v1.0 to v1.5 (OD-9).
- Rows 63, 64, 65, 66 are all `Need to discuss`. They are Spikes, not Stories.

## Key design decisions

1. **Company-managed project**, not team-managed. Transition validators,
   conditions and per-type field contexts do not exist in team-managed, and every
   gate in the design depends on them.
2. **Two main workflows.** Requirement carries intake and approval; Story, Task,
   Bug and Spike carry delivery. One combined workflow would force a one-line bug
   fix through Senior Review.
3. **Requirement is a level-0 issue type, not an Epic**, so it can own an approval
   workflow. Costs weaker parent-child reporting. Recorded as OD-2.
4. **Blocked is the native Flagged field plus a linked Impediment issue, not a
   status.** A Blocked status loses the real stage and corrupts cycle time, and a
   status cannot carry an owner, a date or an escalation. Recorded as OD-3.
5. **Native time tracking only.** Original Estimate, Time Spent, Remaining
   Estimate. Hours, not story points. No money fields anywhere.
6. **Jira owns work state; the repo keeps owning decisions.** ADRs, CHANGELOG,
   WORK_LOG and STATUS keep their existing ownership per `CLAUDE.md` §9
   one-fact-one-owner. The `docs/KNOWN_ISSUES.md` overlap is a real conflict and
   is raised as OD-4 rather than resolved silently.
7. **20 human-filled custom fields**, 14 more written only by automation.
8. **No per-person metrics** on any dashboard or report. Aggregation is by
   component. Section 20 and 21.3 say what is deliberately excluded and why.
9. **Migration creates no Requirements.** 57 of 88 rows are already delivered;
   writing analysis and approval records for finished work would be fiction.

## Not done, deliberately

Jira project not created. GitHub for Jira not installed. No CSV generated yet.
No commit, no push. 14 open decisions (OD-1 to OD-14) left for the user.

## Section-by-section review, 2026-09-12

The user asked to review and finalise the design one section at a time, explicitly
approving or rejecting each, and stated that earlier answers approve nothing.
All fourteen sections were presented with what/why/example and **all fourteen were
approved as specified.** No alternative or trimmed option was taken at any point.

| # | Section | Outcome |
|---|---|---|
| 1 | Project and components | Approved. `NH`, company-managed, 10 components. |
| 2 | Issue types | Approved. All 11. |
| 3 | Workflows | Approved. Two main workflows plus Spike. |
| 4 | Custom fields | Approved. 34 after a correction. |
| 5 | Roles and permissions | Approved. 10 roles, 6 enforced rules. |
| 6 | GitHub integration | Approved. Key in branch, commit, PR. Prefix clean-up declined. |
| 7 | Blockers and dependencies | Approved. Flag + Impediment, no `BLOCKED` status. |
| 8 | Change Requests | Approved. 4-hour threshold kept. |
| 9 | QA and UAT | Approved. Separate stages. |
| 10 | Release management | Approved. Versions + 11-item readiness checklist. |
| 11 | Dashboards | Approved. All nine. Per-person stats option declined. |
| 12 | Reports | Approved. Twelve, three with a workaround. |
| 13 | Automation | Approved. 20 rules after a correction, phased over 4 weeks. |
| 14 | Migration | Approved. All 88 rows, four reconstructed versions. |

## Two self-corrections found during the review

1. **Custom fields, 38 to 34.** `Date Received`, `Planned Start`, `Resolved On` and
   `UAT Date` were all proposed as custom fields when Jira already provides
   `Created`, `Start date`, `Resolved` and the issue history.
2. **Automation, 16 to 20 rules.** `A-01` became unnecessary when `Date Received`
   was dropped. Five rules were missing entirely: nothing wrote `Reviewer`,
   `Review Date`, `QA Failures`, `Reopen Count`, `Blocked Since` or
   `Blocked Duration`, all of which the field matrix listed as automated.

Both were found by checking the document against itself during the review, not by
the user. Section 22 was rewritten; Section 31 gained a `31.0 Correction` note.

## Findings from the sheet that changed the design

- **The 31 August release slipped twice and nothing records the second slip.**
  16 rows targeted 31 August. 8 moved to 2 September, 8 moved to 7 September. As of
  2026-09-12, five days past that date, four of those eight are still `Not Started`
  (rows 5, 33, 34, 37). The sheet has only two date columns, so the second slip is
  invisible. This became the worked example in Sections 10 and 12.
- **Three rows record a scope change in the estimate column.** Row 14 asked for a
  save button; the estimate cell says `Auto save`, so what shipped was auto-save and
  nothing records who decided that. Row 2 says `3 days(only backend part )`. Row 18
  says `Done but can be improved more`. This became the worked example in Section 14
  of the doc (Change Requests).
- **Two statuses existed in the sheet and were never used**: `Blocked` (0 rows) and
  `In Review` (0 rows). Direct evidence for the Section 12 argument that a blocked
  *status* collects nothing.
- **`CONTRIBUTING.md` does not match the repos.** It documents `feature/`, `fix/`,
  `chore/` and plain Conventional Commits. The repos actually use `feat/` (most
  common), `feature/`, `fix/`, `docs/`, `revert/`, one `Enhance/NarzimGPTAI` and one
  `feature/practitioner_own_holiday`, and every commit carries a scope such as
  `feat(patients):`. Raised as OD-15; the clean-up was offered and declined, so the
  drift stands and the key is simply added to whatever prefix is used.

## Still open after the review

Eight decisions. Two block the build.

| # | Blocking? | Decision |
|---|---|---|
| OD-1 | **blocks Phase 3** | Which real person holds each of the 10 roles |
| OD-14 | **blocks Phase 1** | Who is the Jira site administrator, and does a site exist |
| OD-4 | no | Does Jira take over from `docs/KNOWN_ISSUES.md`. Needs an ADR. |
| OD-5 | no | Jira Standard or Premium. Nothing approved needs Premium. |
| OD-7 | no | Sprint length. Two weeks recommended. |
| OD-8 | no | Jira Service Management for clinic-facing support |
| OD-11 | no | `EB_Healthcare_EHR_MobileApp` has 2 unpushed local commits |
| OD-15 | no | Branch prefix drift, clean-up declined |

## Sections of the document never reviewed

The user's fourteen-item list did not cover these, so they stand as written and
unapproved: Section 15 Bug Management, 18 Production and Incident Management,
19 Developer Hours, 25 Naming Conventions, 26 Governance Rules (including the PHI
rule and the `KNOWN_ISSUES.md` conflict), 27 and 28 the worked examples,
29 Implementation Plan, 30 Open Decisions.

## State at the end of the session

`docs/planning/JIRA_SETUP.md` is `living`, version 2.0, 2,950 lines, **uncommitted**.
Nothing created in Jira. No integration installed. No CSV generated. No commit,
no push.

---

## Live build, same session

The user supplied a Jira API token and asked for the project to be created. It was,
along with a reduced version of the approved design. **Section 34 of
`docs/planning/JIRA_SETUP.md` is the authoritative record**; this is the session
narrative only.

### Two constraints found by probing, not assumed

1. **The site is on `jira-software: FREE`.** No custom fields, no custom workflows,
   no permission schemes, no extra issue types, automation capped at 100
   executions/month, 10-user cap (7 in use).
2. **`sarvesh@socialangel.org` has `CREATE_PROJECT` and `ADMINISTER_PROJECTS` but
   NOT site-wide `ADMINISTER`.** `GET /workflowscheme` returns 403.

Consequence: `POST /rest/api/3/project` was refused for **every** template.
The project was created via `POST /rest/simplified/latest/project`, the endpoint the
UI uses for self-service team-managed spaces. **The project is team-managed and
cannot be converted in place.**

### API discoveries worth not re-deriving

| Finding | Detail |
|---|---|
| Hidden but writable fields | Team-managed `createmeta` hides `priority`, `components`, `fixVersions`, `timetracking`. The REST API accepts and persists all four. Verified by probe issue, read back, deleted. |
| **Project-scoped statuses work without admin** | `POST /rest/api/3/statuses` with `scope.type=PROJECT` succeeds. This is what made the 10-column board possible. |
| Board columns are UI-only | `PUT /rest/agile/1.0/board/265/configuration` returns **405**. Statuses can be created by API; placing them on the board cannot. |
| Sprint name limit | Must be **under 30 characters**. `NH Sprint 1 - Release close-out` was rejected. |
| Jira's flag value is `Impediment` | `customfield_10021`, multi-checkbox, single allowed value. The Section 12 vocabulary exists natively. |
| Issue types and custom fields | Both 403 for this operator. Three separate probes. |
| User invite / email change | `POST /rest/api/3/user` returns "Administrator privileges are required". Cannot invite or change any email. |

### Built, in order

1. Project `NH` (id 10363), 10 components, 5 versions, 25 epics, **88 of 88 rows
   imported, zero failures**.
2. Second pass fixed five gaps: `releases`, `code` and `deployments` features were
   **disabled**; the sheet's `Sprint / Milestone` and `Start`/`Completion Date`
   columns had never been imported; the project had no description.
3. Requirement flow on the unused `Feature` type: template `NH-116`, six `req-*`
   labels, approval by attributed comment.
4. **10 statuses created, 1 deleted.** `In Code Review` duplicated the template's
   `In Review`; `DELETE /statuses?id=10565` returned 204.
5. Board columns placed by the user in the UI, correct left-to-right order.
6. **Sprint `NH S1 Release close-out`**, active, ends **2026-09-14 12:00 IST**,
   16 items.
7. **14 items moved from `Done` to `Release Ready`** on the user's explicit
   instruction ("done me mt karo release ready me rakhoo").
8. Blocker handling: NH-60 flag preserved, seven-field structured comment added,
   template `NH-117` created, filter 10271 updated, filter 10275 added.

### The most useful finding of the whole migration

The sheet holds 59 finished items (57 `Done` + 2 `Dev Complete`). **Only 43 were
ever stamped `Released`.** The other 16 were coded, marked done, and had no record
of reaching production. They are now the sprint.

`Done` in Jira now holds exactly those 43, so `Done` finally means shipped. Whether
the 14 in `Release Ready` are actually live or sitting on `pre` is an open question
for the team.

### Corrections made during the session

- Custom fields **38 → 34**: four already exist natively (`Created`, `Start date`,
  `Resolved`, issue history).
- Automation **16 → 20 rules**: one dropped with its field, five field-writers were
  missing entirely.
- Release Ready holds **9** NH v1.2 items, not the 8 stated verbally.
- "51 missing estimates" and "8 unassigned" were listed as cleanup in an audit and
  are **not defects**, the sheet had nothing to import in those cells.

### Still pending at session end

Token revoke · sheet freeze · GitHub for Jira install · name an owner for NH-60 ·
confirm whether the 14 are live · dashboards · "Storage full" warning.
Org admin needed for Ashutosh's email and for `ADMINISTER`.
Standard needed for issue types, fields, validators, permissions, automation.

**Nothing committed. Nothing pushed.**

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-12 | Sarvesh-SocialAngel (AI-assisted) | Added the live-build record: the two constraints found by probing (Free plan, no site-wide `ADMINISTER`), seven API discoveries worth not re-deriving, the eight things built in order, the 43-of-59 released finding, four corrections made during the session, and what remains pending. |
| 1.0 | 2026-09-12 | Sarvesh-SocialAngel (AI-assisted) | Initial version. Prompt archived before work started, then extended with the fourteen-section design review and its outcomes. |
