# Enable in-house pharmacy: make seeded drugs stock + sellable

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-17
**Author:** gaurav (via Claude)

## Intent

Patient may buy prescribed medicine **in our pharmacy** (billable, stock-tracked)
or **outside** (prescription only). Prescription is always written in the Patient
Encounter; billing happens only when dispensed in-house, as a separate Sales
Invoice — decided per line at the counter, not by a drug-level flag.

To make the in-house case (Case A) work, the seeded drug `Item`s must become
stock + sellable with a price, warehouse and income account. `seed_medications`
left them catalogue-only (`is_billable=0`, no stock, rate 0).

## What this seed does

`remedisys_healthcare_ai/scripts/seed/seed_pharmacy_stock.py` — idempotent.
For every Item in the `Drug` group (SKUs from `seed_medications.MEDICATIONS`):

- `is_stock_item=1`, `is_sales_item=1`, `is_purchase_item=1`
- Item Default (company **Narzim**): default warehouse **Pharmacy - N**,
  income account **VENTAS NACIONALES AL DETAL - N**, selling cost center
  **Pharmacy - N**
- Item Price on **Standard Selling** set to a placeholder rate by dosage form

Safe to flip `is_stock_item` because these Items have no stock ledger entries yet.

## Environment facts (marley.local)

- Company: Narzim (abbr N, MXN)
- Warehouse `Pharmacy - N` and cost center `Pharmacy - N` already exist
- No dedicated medicine-sales account → reused `VENTAS NACIONALES AL DETAL - N`

## Run

```
bench --site marley.local execute \
    remedisys_healthcare_ai.scripts.seed.seed_pharmacy_stock.run
```

## ASSUMPTIONS — confirm with owner

1. **Placeholder prices** (MXN): Tablet 5, Capsule 8, Syrup 45, Cream 60,
   Injection 90, default 10. Replace with real pharmacy prices.
2. **Income account** `VENTAS NACIONALES AL DETAL - N` chosen for medicine
   retail; accountant may want a dedicated cuenta. CFDI for medicine sale is a
   product (SAT clave ~51xx), separate from the consultation service CFDI.
3. All 100 drugs made stock items. Disable (`is_stock_item=0` / `disabled=1`)
   any you don't actually stock.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
