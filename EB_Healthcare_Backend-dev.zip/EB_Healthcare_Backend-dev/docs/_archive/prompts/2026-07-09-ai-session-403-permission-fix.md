# AI Copilot Sprint 4 — 403/502 debugging: EB_ docperm gap + error-passthrough gap

**Doc status:** record · **Created:** 2026-07-10 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Repos:** both (`remedisys_healthcare_ai` backend, `Healthcare_next_app` frontend)
**Branch:** `feature/ai_v1` (both repos, uncommitted at time of writing)
**Trigger:** user tested the just-shipped consent-recording rewiring (start_session
instead of the bare mint_deepgram_token) and hit `Session start failed: 403` on
`/api/ai/session`.

## Investigation

1. `sessions.py::_require_encounter_read()` calls `frappe.has_permission("Patient
   Encounter", "read", doc=encounter)` — didn't exist in the old bare-token-mint
   path. Prime suspect, but ruled out empirically: `bench console` confirmed
   `frappe.has_permission(..., user="amanop1210@gmail.com")` returns `True` for
   both doctype- and doc-level checks on this exact encounter.
2. Traced `start_session()` further — `_get_or_create_draft()` calls
   `frappe.get_doc({"doctype": "AI Encounter Session", ...}).insert(ignore_permissions=False)`.
   Checked that doctype's DocPerm table: only `System Manager` / `Physician` /
   `Healthcare Administrator` have any grant. `EB_Practitioner` (the only role
   this app's frontend ever assigns) has none.
3. Checked `eb_docperm_spec.json` (the EB_ RBAC rebuild spec, see
   `docs/adr/ADR-004-no-core-docperm.md` and the 2026-06-22 rebuild prompt) — zero
   entries for any of the 4 `AI *` doctypes. They were built during the
   Phase-5-locked era and never folded into the EB_ rebuild since nothing used
   them yet. `append_segment()` in `segments.py` has the identical
   `doc.insert(ignore_permissions=False)` pattern on `AI Transcript Segment` —
   same latent gap, not yet hit only because nothing calls it yet.

## Fix 1 — backend: `eb_docperm_spec.json` + new reapply patch

Added `EB_Practitioner` entries (following the exact existing convention —
`add_permission` + `update_permission_property`, self-healing, idempotent):

| Doctype | create | read | write | Notes |
|---|---|---|---|---|
| `AI Encounter Session` | 1 | 1 | 1 | practitioner starts/stops their own session |
| `AI Transcript Segment` | 1 | 1 | 1 | `append_segment()` has the same insert pattern |
| `AI SOAP Draft` | 0 | 1 | 1 | no create endpoint exists yet; **doctype doesn't actually exist on this site** — CLAUDE.md §7 claims "✅ Installed", it isn't. Spec entry is inert (rebuild script skip-guards missing doctypes) until it's actually built. |
| `AI Prompt Log` | — | — | — | intentionally no EB_ entry — audit-only, System Manager only |

New file: `patches/v0/reapply_eb_role_permissions_20260709.py` (calls
`rebuild_eb_role_permissions.execute()`, same as every prior dated reapply
patch). Appended to `patches.txt`. Ran `bench --site marley.local migrate` —
applied clean. Verified via `bench console`:
`has_permission("AI Encounter Session", "create"/"read"/"write", ...)` all
`True` post-migrate.

## Fix 2 — frontend: `client.ts` swallowed 417 into a generic 502

Once the 403 was fixed, retesting surfaced a `502 Bad Gateway` instead. Traced:
`sessions.py`'s `except deepgram.DeepgramError: frappe.throw(_("AI transcription
unavailable ({0}).").format(exc.code), frappe.ValidationError)` is the exact
Rule-7 "AI unavailable, degrade gracefully" path — but Frappe's `ValidationError`
returns HTTP **417** (confirmed via `grep http_status_code frappe/exceptions.py`,
then empirically reproduced end-to-end with a real HTTP call against the
running dev server using the test user's API key/secret — got `417` with the
full traceback body). `client.ts:31`'s `frappeErrResponse()` passthrough list
was `[400, 401, 403, 404, 409, 422]` — no 417 — so this well-formed,
code-carrying error collapsed into an opaque `502` with no code, defeating the
entire purpose of the `DeepgramError(code)` design.

**Fix:** added `417` to the passthrough list in
`Healthcare_next_app/src/lib/api/client.ts`, with a comment explaining it's
Frappe's own `ValidationError` status code (not a value chosen here), so a
future reader doesn't "clean up" what looks like an arbitrary magic number.

Required a Next.js dev server restart (`pnpm dev`) — editing a shared lib file
consumed by a route handler didn't trigger Turbopack's dev recompilation the
way editing the route file itself would have; the browser kept getting the
previous build's 502 behavior until the restart.

## Verification

- Backend: `has_permission()` checks re-run post-migrate, all `True`.
- Frontend: `npx tsc --noEmit` clean (one pre-existing, unrelated failure in
  `e2e/encounter-submit.spec.ts`); `npx eslint src/lib/api/client.ts` clean.
- End-to-end: user retested in browser. 403 → gone. 502 → gone, now correctly
  shows `417`.

## Fix 3 — frontend: `close_reason: "disposed"` not a valid Select option

After the Deepgram key was replaced (Member role, new key), a new error surfaced:
`POST /api/ai/session/stop` → `417 ValidationError` on `close_reason: "disposed"`.
`AI Encounter Session.close_reason` is a Frappe `Select` field with fixed options
`physician_stop` / `idle_timeout` / `error` / `system_close` — `"disposed"` isn't
one of them, so Frappe's own field validation rejected the save. This is a bug
introduced earlier this session (Sprint 4 error-states work) — picked a value
without checking the doctype's actual options.

**Fix:** `real-provider.ts` `dispose()` — changed to `close_reason: "system_close"`
(semantically closest: app/browser tore the session down, not a physician
Stop click, not a timeout, not an error).

This also confirms Fix 2 (417 passthrough) is doing its job — a real, specific
backend validation error surfaced in the Network tab instead of a blind 502.

## Fix 4 — frontend: WS subprotocol scheme was `"token"`, needed `"Bearer"`

With the Deepgram key now actually authorized, `start_session` minted a real
grant token, but the browser's WebSocket still failed to open (bare `error`
event, no status/body — normal browser behavior for a rejected WS upgrade).

Diagnosed by reproducing the exact handshake from `bench console` (mint a real
grant token via `/v1/auth/grant`, then send the WS upgrade request manually via
`requests.get(..., headers={"Sec-WebSocket-Protocol": "token, <token>", ...})`)
rather than guessing from the browser's opaque error:
- `Sec-WebSocket-Protocol: token, <access_token>` → `401 {"err_code":"INVALID_AUTH"}`
- `Sec-WebSocket-Protocol: Bearer, <access_token>` → `101 Switching Protocols`

The `/v1/auth/grant` endpoint mints a short-lived JWT `access_token` — distinct
from a raw project API key. Deepgram authenticates the two differently:
`Authorization: Token <api_key>` (→ WS subprotocol `"token"`) for raw keys,
`Authorization: Bearer <access_token>` (→ WS subprotocol `"Bearer"`) for grant
tokens. The original implementation used `"token"` for both.

**Fix:** `real-provider.ts` — `new WebSocket(wsUrl, ["Bearer", wsToken])`
(was `["token", wsToken]`). Verified against the real API before changing code,
not just from documentation recall.

## Verification (fixes 3 & 4)

- `npx tsc --noEmit` — clean (same one pre-existing, unrelated
  `e2e/encounter-submit.spec.ts` failure throughout this whole session).
- `npx eslint` — clean on both touched lines.
- End-to-end: user confirmed the full consent → recording → WebSocket-open flow
  now works in the browser.

## Resolved outside code — Deepgram key permission

The original Deepgram API key returned `403 {"err_code":"FORBIDDEN",
"err_msg":"Insufficient permissions."}` on `/v1/auth/grant` — valid key (not a
401) but wrong project role for grant-token minting. Fixed by creating a new
key in the Deepgram console with role **Member** (the role whose description
explicitly covers "use token-based authentication") and a 3-month expiration
per CLAUDE.md's quarterly-rotation rule, then swapping it into
`site_config.json`'s `deepgram_api_key`. Not a code change.

## Also flagged, not fixed here

CLAUDE.md §7's doctype table lists `AI SOAP Draft` as "✅ Installed" — it does
not exist on `marley.local`. Stale documentation, not in scope for this fix.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
