# 2026-06-05 — EB Frappe JWT

**Doc status:** record · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-05 by Sarvesh-SocialAngel · **Version:** 1.0

## Task
Build `eb_frappe_jwt` — a reusable standalone Frappe app providing JWT authentication
for all Social Angel Frappe projects (web + mobile).

## Approved Design

### Identity
- GitHub repo: `github.com/Social-Angel/EB_Frappe_JWT`
- Python package: `eb_frappe_jwt` (Frappe requires lowercase)
- App title: `EB Frappe JWT`

### Token Design
- Access token: JWT (HS256), 1 hour expiry, claims = { sub, iat, exp, roles, + project hook }
- Refresh token: opaque (32 bytes random, base64url), 30 days, stored hashed (SHA256)
- Secret: stored in `site_config.json` as `eb_jwt_secret`
- Refresh rotation: single-use (old token revoked on each refresh)

### Endpoints
- `POST /api/method/eb_frappe_jwt.api.get_token` — login, returns access + refresh
- `POST /api/method/eb_frappe_jwt.api.refresh_token` — silent refresh
- `POST /api/method/eb_frappe_jwt.api.revoke_token` — logout

### Doctype: EB JWT Token
- token_hash (SHA256 of refresh token, indexed)
- user (Link → User)
- expires_at (Datetime)
- revoked (Check)
- device (Data, optional)

### Custom Claims Hook
Each project can inject claims via:
```python
# hooks.py
jwt_payload_hook = "your_app.auth.get_jwt_payload"
```

### Integration
```python
required_apps = ["eb_frappe_jwt"]
```

### Branching
dev → pre → main (same as Remedisys policy)

## Files to Build
1. `utils.py` — sign_jwt, verify_jwt, hash_token
2. `doctype/eb_jwt_token/` — refresh token storage
3. `api.py` — get_token, refresh_token, revoke_token
4. `auth.py` — JWTHTTPRequest middleware
5. `hooks.py` — wire http_request + jwt_payload_hook
6. Update `remedisys_healthcare_ai` to use it
7. Update Next.js `auth.ts`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
