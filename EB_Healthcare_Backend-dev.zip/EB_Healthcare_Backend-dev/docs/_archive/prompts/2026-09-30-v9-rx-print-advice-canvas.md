# v9 Rx print: Advice lines and attached Canvas drawing reach the printed/PDF Rx

**Doc status:** record · **Created:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

Implementation task, run against `origin/dev` on branch
`docs/adr-104-rx-print-canvas-svg-rendering` (backend) and
`feat/v9-rx-print-advice-canvas` (frontend). Picked from a "what next"
menu after the v9 Service Request / Advice / Active-now work (PRs #467,
#469, #571, #572) all merged.

## What this closes

Plan item 5 in `docs/qa/encounter-v3/14-V9-ADVICE-CANVAS-CONNECT-PLAN.md`
("Rx print shows advice and attached drawings") was written 2026-09-29 but
never built — confirmed by grep: zero references to Advice or Canvas in
`encounter-report.tsx` before this task.

## User story

A doctor sees a patient with a sprained ankle. In the v9 Pad they write
Advice ("Rest 3 days, ice 20 min every 4 hrs, return if swelling worsens")
and draw a small ankle diagram on Canvas marking where to apply the brace,
then toggle "Attach to Rx". They click Print. Before this task, the PDF the
patient walks out with shows neither.

## The one real design fork

Advice is a plain string list — trivial. Canvas is not: `canvas_data` is
deliberately unsanitized HTML (ADR-097), safely displayed elsewhere only via
a `sandbox=""` iframe — but the print pipeline rasterizes the live DOM with
`html2canvas-pro`, which cannot capture into an iframe. ADR-097's own
Consequences section already named this exact situation ("a PDF export")
as an unsolved re-evaluation trigger, and named the safe fallback pattern
("a script inside an `<img>`-loaded SVG never executes, per spec").

Four approaches were presented to the user (extract-SVG-as-`<img>`;
parse-and-reinject-as-live-`<svg>`; make html2canvas capture the sandboxed
iframe; bring back a stored rasterized PNG). User picked the first,
matching the ADR's own pre-approved-safe pattern — recorded as ADR-104.

## Decisions locked (user, 2026-09-30)

1. Canvas print rendering: extract the `<svg>` from `canvas_data`, wrap as
   a `data:image/svg+xml` URI, render as a plain `<img>`. No backend change.
2. Build scope: both print surfaces this round — `SignedReportOverlay`
   (post-sign preview) and `EncounterReportModal` (reprint any past
   encounter, used from Overview/Pad history and patient-chart).
3. (Trivial, stated not asked) Only `attach_to_rx=true` canvases print —
   the field's own stated purpose.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
