# 2026-08-20 — Encounter forensic audit + ground-up redesign

**Doc status:** record · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## Ask
Two requests, in sequence.

1. Analyse the encounter flow where practitioners find it "critical and annoyed", find the gaps,
   and brainstorm UI/UX and flow — pushing back where the user's own proposed flow was wrong.
2. Then: a **complete, code-first forensic audit** of the encounter workflow across 17 phases —
   trusting nothing (not `CLAUDE.md`, not code comments, not the earlier audit), verifying every
   claim against current code and the live database, and grading every previous claim
   CONFIRMED / PARTIALLY TRUE / FALSE / OUTDATED / UNVERIFIED.
3. Finally: write it all up in detail, plus **everything from scratch for Patient Encounter**.

## Constraints observed
- No code changed. Read-only DB queries plus one read-only call to `_fmt_encounter`.
- Local/staging only — production (`chavitosclinic.frappe.cloud`) never touched.
- No subagents, no workflows (not requested).
- Rule 1 respected throughout the design: custom fields via fixtures, new custom doctypes, hooks.

## Method
- Read in full: `encounter-screen.tsx` (6,625), `encounters-client.tsx`, `encounters/[id]/page.tsx`,
  `copilot/*` (incl. `use-copilot` 615, `real-provider` 1,329), `NarzimAIChatBar.tsx` (1,356),
  `stream/*` (851), `use-clinical-record.ts`, `chart-utils.ts`, `vitals-tab.tsx`,
  `patient-screen.tsx`, `chart-permissions.ts`, `command-palette.tsx`, BFF routes, `messages/en.json`;
  backend `encounters/api.py` (~2,300), `ai/api.py` (1,778), `ai/sessions.py`, `ai_tools.py` (1,727),
  `services/ai.py`, `patient_clinical_summary.py` (2,038), `encounter_ai_record.py`,
  `integrations/openai.py` (1,539), `hooks.py`.
- Database: all 61 `Patient Encounter` fields counted individually; all 131 SOAP blobs parsed and
  keys tallied; child-table and AI-doctype row counts; session consent state; `AI Prompt Log` field
  population and purpose distribution.
- Browser: Playwright as an `EB_Practitioner` against `localhost:3000`, capturing console errors,
  request failures and response statuses on `/encounters` and `/encounters/HLC-ENC-2026-00148`.

## Headline findings
1. A live synthetic-data layer (`patHash`) still renders fabricated clinical information: AI
   "insights", fabricated provenance around real allergies, and a growth chart labelled
   "WHO percentiles" whose curves are straight lines.
2. Consent is asserted by the client and never asked — 137/137 sessions consented, 0 ever in Draft.
3. Half the SOAP note has no storage in practice: `hpi`/`plan`/`notes`/`physical_examination` are in
   0 of 131 encounters.
4. Four subsystems are built, tested and unwired — including `tools_detail_json`, the one that would
   have delivered AI provenance.
5. `_serialize_drug_rx` omits the dosing interval the writer persists — proved live.
6. No retention purge exists anywhere (`scheduler_events` commented out).

## Deliverables
- `docs/audit/practitioner/screens/03-encounter-deep-audit.md` — the as-is forensic record (18 sections).
- `docs/architecture/ENCOUNTER_FROM_SCRATCH.md` — the target design (15 sections, 21-step migration,
  20 acceptance criteria, 9 open decisions).
- `docs/audit/practitioner/README.md` — index row.
- `WORK_LOG.md` — entry.

## Self-corrections recorded
The audit grades my own earlier chat findings, including two as FALSE (split transcripts, blob size)
and three as PARTIALLY TRUE (Rx interval scope overstated, `hpi` latent not live, `amended_from`
exists so "no amendment path" was too strong).

## Environment change
`admin@narzim.com` password on `marley.local` set to `admin@123` (to obtain a practitioner session).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Prompt archive for the encounter forensic audit |
