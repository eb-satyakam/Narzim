# 2026-07-31 — "Fix speakers" corrected the UI but never the database

**Doc status:** record · **Created:** 2026-07-31 by Sarvesh-SocialAngel · **Updated:** 2026-07-31 by Sarvesh-SocialAngel · **Version:** 1.0

Third fix of the session — see also
[2026-07-31-admin-cannot-sign-encounter.md](2026-07-31-admin-cannot-sign-encounter.md)
and [2026-07-31-copilot-gating-and-transcript-error.md](2026-07-31-copilot-gating-and-transcript-error.md).

## Prompt (verbatim intent)

> "fix speaker karne ke bad wo transcript update hoti hai? ya nhi"
> "when i click on fix transcript … these update or not"
> "if i reload its show again `Doctor: Hello. Hello, Hello. I'm suffering from
> fever since last night. So what` but i fix speaker"

## Symptom

Clicking **Fix speakers** re-split and re-labelled the transcript in the panel.
Reloading the encounter brought back the original single `doctor` turn. Nothing
in the UI indicated a failure.

## Root cause

`AI Transcript Segment` carried **`set_only_once: 1` on `start_ms` and
`end_ms`**. The controller's own guards (`_enforce_append_only`, the
session-status check) correctly honour `flags.allow_transcript_correction`, but
`set_only_once` is enforced by Frappe core in `Document.validate_set_only_once()`,
which honours **no** bypass flag. Resegregate always interpolates fresh timings
across the rebuilt turns (`real-provider.ts:811`), so every correction tried to
change `end_ms` and every correction threw:

```
Value cannot be changed for End (ms)
  → remedisys_healthcare_ai.api.ai.segments.sync_transcript
```

Evidence gathered before touching anything:

- 3 × `resegregate-v1` rows in `AI Prompt Log` at 17:57:53 / 17:58:33 / 17:59:41
  (so the LLM re-split ran three times), and 3 matching error entries in
  `logs/frappe.log` + `tabError Log` with the traceback above.
- `AIES-2026-00102`'s segments unchanged, `modified == creation`.
- `logs/remedisys.segments.log` (written by `sync_transcript` on success) empty
  since 15 Jul — the success path had never once run.

**Why nobody noticed:** three layers swallowed it. `_syncTranscript()` had a bare
`catch {}` and never checked `res.ok`; the BFF route returned a fabricated
`{status: "sealed"}` on any exception — indistinguishable from a legitimately
sealed session. A 500 looked exactly like a save.

Second, independent bug found in the same path: a **per-line** speaker swap was
only ever in memory. `setSegmentSpeaker` mutated `finalSegments` and made no
request; the 20s auto-save and the end-of-session persist both go through
`append_segment`, which returns `duplicate` for an existing
`(session, sequence_number)` and keeps the stored speaker. So manual swaps were
lost too — the bulk button was merely the more visible half.

## Fixes

1. **`ai_transcript_segment.json`** — dropped `set_only_once` from `start_ms` and
   `end_ms` (kept on `session` and `sequence_number`, which the correction path
   never changes). Immutability is unchanged in policy: `_enforce_append_only`
   still holds every other write path append-only, and that is where the
   correction exemption was already deliberately scoped. No ADR — the policy
   ("scoped correction of the DRAFT transcript, sealed sessions refused") is the
   pre-existing documented design; only the enforcement layer moved off a core
   property that cannot express it. Applied with
   `bench --site <site> reload-doctype "AI Transcript Segment"`.
2. **`real-provider.ts`** — `_syncTranscript()` now checks `res.ok`, inspects the
   returned `status`, and `console.warn`s counts/status when a correction does not
   persist. Still never throws at the physician (Rule 7); it just stops lying.
3. **`real-provider.ts`** — per-line `setSegmentSpeaker` schedules a debounced
   (1.5s) `_syncTranscript()`, so manual swaps persist via the only endpoint that
   can change a stored speaker. Flushed before teardown in `dispose()` (before
   `disposed` is set, since `_syncTranscript` no-ops on a disposed provider) and
   in `stop()` **step 3a-ii**, ahead of the `/session/stop` call — after that the
   session is `Closed` and `sync_transcript` rightly refuses a sealed session.
4. **`sync-transcript/route.ts`** — returns `{status: "error", reason}` and logs
   server-side instead of faking `"sealed"`. Still resolves 200 so the encounter
   is never disrupted.

## Also fixed on the way

`tests/ai/test_segments.py` patched `remedisys_healthcare_ai.api.segments.…`,
a module that no longer exists (it moved to `api/ai/segments.py`). Every test
using `_allow_perm()` / `_mute_publish()` was erroring with `ModuleNotFoundError`
— 3 stale targets repointed, and the file's 9 existing tests run again.

## Verification

- Replayed the exact failing 17:59:41 payload against `sync_transcript` on
  `marley.local` as the encounter's practitioner:
  `{'status': 'synced', 'updated': 4, 'created': 1, 'deleted': 0}`, speakers
  correctly re-labelled — then rolled back, live data untouched.
- New `TestSyncTranscript` (4 tests: speaker+timing rewrite, create/delete to
  match a re-split, JSON-string payload, sealed-session refusal). Ran the whole
  file on `test.marley.local` via unittest (`bench run-tests` is broken here):
  **13 tests, 0 failures, 0 errors**, rolled back, no fixtures left behind.

## Note

The 4 rows already stored for `AIES-2026-00102` still hold their original
speakers. That session is still `Recording`, so a fresh **Fix speakers** click
now corrects them in place.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
