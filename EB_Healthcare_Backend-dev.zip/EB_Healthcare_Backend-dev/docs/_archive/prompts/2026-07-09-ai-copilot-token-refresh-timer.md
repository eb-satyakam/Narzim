# AI Copilot Sprint 4 — Deepgram token-refresh timer

**Doc status:** record · **Created:** 2026-07-10 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Branch:** `feature/ai_v1` (frontend repo only — no backend changes; the
server-side `refresh_deepgram_token` this wires up already existed, unused)
**Requested by:** Sarvesh — last remaining Sprint 4 hardening item, picked
after the 403/502/417 debugging chain (see
`2026-07-09-ai-session-403-permission-fix.md`) got the core recording flow
working end-to-end.

## Gap

`api/ai/sessions.py::refresh_deepgram_token(session)` mints a fresh Deepgram
grant token for an in-flight `Recording` session — built, but nothing
client-side ever called it. The Deepgram grant token's TTL is
`min(max_session_minutes*60 + 300, 7200)` (`_ttl_for_session`, capped at 2h) —
a long encounter would ride the original token past its TTL with no renewal,
risking a dropped WebSocket mid-consultation with no graceful recovery
(Rule 7: AI failure must not break healthcare, but a silent drop mid-encounter
is exactly the failure mode Rule 7 exists to prevent).

## Changes

- **New**: `src/app/api/ai/session/refresh/route.ts` — same shape as the
  existing `/stop` route, calls `sessions.refresh_deepgram_token`.
- **`real-provider.ts`**:
  - Replaced the single shared `closingIntentionally: boolean` with
    `expectedCloseSockets: WeakSet<WebSocket>`. Necessary, not cosmetic: token
    rotation means two sockets briefly coexist (old draining/closing while the
    new one is already live), and a shared boolean can't tell which socket a
    close/error event belongs to — a race the old design never had to handle
    since only one socket ever existed at a time.
  - Extracted `_connectSocket(url, token)` from `start()`'s inline WS-open
    logic — shared by both `start()` and the new rotation path so they connect
    identically. Its close/error listeners capture their own `ws` (not
    `this.ws`), so a rotated-out socket's own listeners still evaluate
    correctly even after `this.ws` has moved on.
  - `_scheduleRefresh(ttlSeconds)` — sets a timer for `ttlSeconds - 60s`
    (min 5s floor) that calls `_rotateSocket()`.
  - `_rotateSocket()` — calls `/api/ai/session/refresh`, opens a **new** WS
    with the fresh token via `_connectSocket`, swaps `this.ws` to it (audio
    keeps flowing uninterrupted — the recorder's `dataavailable` handler
    always reads the current `this.ws`), marks the **old** socket as an
    expected close, closes it gracefully, then schedules the next rotation off
    the new token's TTL.
  - Refresh failure (network blip, Deepgram down) is swallowed on purpose —
    Rule 7: the current connection is untouched and keeps running; if it later
    drops, the existing close-handler already surfaces the standard "AI
    connection lost" degradation. No new failure mode, no retry loop, no
    disruption to a still-healthy connection.
  - `stop()`/`dispose()` now clear `refreshTimer` up front (no dangling timer
    after the session ends) and mark the socket as an expected close via the
    WeakSet instead of the old boolean.

## Verification

- `npx tsc --noEmit` — clean (same one pre-existing, unrelated
  `e2e/encounter-submit.spec.ts` failure that's been present all session).
- `npx eslint` on all touched files — clean.
- **Not manually tested end-to-end** — would require running a real recording
  session for ~1 hour (the actual TTL) to observe a live rotation. Traced the
  logic by hand instead: audio continuity across the swap, the no-shared-flag
  race fix, and the Rule-7 failure path were all reasoned through explicitly
  rather than assumed. Flagging this gap honestly rather than claiming a test
  that wasn't run.

## Sprint 4 status after this

Remaining, not done: i18n audit (`encounter.copilot.*` keys in both
en.json/es.json), compliance badge (`NEXT_PUBLIC_COMPLIANCE_PROFILE=mx|in`
display), orphaned component cleanup (`FloatingChatBar.tsx`/`CopilotChat.tsx`
— built, zero imports anywhere, decide delete vs wire in).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
