# create_practitioner 403 — EB_Healthcare Admin cannot create User Permission

**Doc status:** record · **Created:** 2026-06-24 by Sarvesh-SocialAngel · **Updated:** 2026-06-24 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-24
**Triggered by:** Manual Bruno test of `admin.api.create_practitioner` as `admin@chavitos.health`.

## Symptom

`POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_practitioner`
returns **403 FORBIDDEN** for an `EB_Healthcare Admin`, and on retry **409**
(the email is now taken). Login itself succeeds (200).

## Root cause

`create_practitioner` inserts the Healthcare Practitioner, inserts the linked
Website User, then `doc.save()`s the practitioner to set `user_id`. Healthcare
core's `Healthcare Practitioner.on_update`
(`healthcare/.../healthcare_practitioner.py:71`) then calls
`frappe.permissions.add_user_permission("Healthcare Practitioner", name, user_id)`,
which **inserts a `User Permission` row**. That insert needs `create` on the
`User Permission` doctype — shipped only to `System Manager`.

`admin@chavitos.health` is an **`EB_Healthcare Admin`**, not System Manager
(per the RBAC model: all app users are Website Users on EB_ roles). So the
insert raises `PermissionError` → 403.

`eb_docperm_spec.json` already declares `create`/`delete` on `User Permission`
for `EB_Healthcare Admin`, but `rebuild_eb_role_permissions` had already run on
existing sites before that entry was added, so the grant never landed on
`marley2.local` (live `Custom DocPerm` for `User Permission` was empty). Same
shape as the lab-template-masters fix.

## Secondary bug — non-atomic writes

`utils.handle_api_errors` caught the `PermissionError` and returned 403 **without
`frappe.db.rollback()`**, so Frappe committed the partial writes. Result: an
orphaned Practitioner (`HLC-PRAC-2026-00035`) + User (`sarveshshahi12345@gmail.com`,
roles stripped) were left behind, blocking retries with a 409. The decorator's
own contract ("a Practitioner failure never leaves an orphaned User") was broken.

## Fix (chosen: grant the perm, no ignore_permissions)

Two options were considered: (A) grant `EB_Healthcare Admin` create/delete on
`User Permission` via `eb_docperm_spec.json` so the call runs through normal
permission checks, or (B) bypass with `ignore_permissions=True`. **Chose A** —
the call runs without any permission bypass; `create_practitioner` keeps its
plain `doc.save()`.

1. **`eb_docperm_spec.json`** — declares `create`/`delete` on `User Permission`
   for `EB_Healthcare Admin` (so linking a User to a Practitioner is allowed).
2. **`patches/v0/grant_user_permission_eb_perms.py`** — thin re-run of the
   idempotent `rebuild_eb_role_permissions` so the grant lands on existing sites.
   Registered in `patches.txt`.
3. **`utils.handle_api_errors`** — `frappe.db.rollback()` on every caught
   exception path, so a failed endpoint never commits partial state. This is the
   real cause of the orphans: the decorator swallowed errors without rolling back,
   and `reset_password()` (called while building the welcome-email link) commits
   mid-function, so any later failure left a committed User behind.
4. **Cleanup** — deleted the orphaned User + Practitioner on `marley2.local`.

## Follow-up bugs found during verification (also fixed)

5. **EB_Practitioner role stripped on insert.** Frappe removes any role the
   acting user does not itself hold (a non-System-Manager cannot grant a role),
   so the new login was created role-less and could not use the frontend. There
   is **no Custom DocPerm lever** for role-granting — it is hardcoded to
   System-Manager-or-self. Fix: `user_doc.insert(ignore_permissions=True)` in
   both `create_practitioner` and `update_practitioner` (the caller is already
   authorized via `require_permission` at the top). Verified: role now
   `['EB_Practitioner']`.

6. **Set-password welcome email never sent.** The ad-hoc `frappe.sendmail(template="new_user", …)`
   block was broken (`user_doc.reset_password()` doesn't exist on `User` →
   `AttributeError`; `new_user.html` also needs `site_url`/`created_by`), and the
   failure was swallowed by a bare `except`. **Final fix: reuse the existing
   portal-welcome flow** instead of a bespoke send — the same one the frontend
   "invite user" (`invite_staff`) uses. Extracted `_send_portal_welcome` +
   new `send_set_password_email(user_name, first_name, company=None)` into
   `_helpers.py`; `invite_staff` and both practitioner endpoints now call it.
   It generates the reset key, stores its hash, and emails the branded
   `portal_welcome.html` linking to the **Next.js `/set-password?key=…`** page
   (via `portal_app_url`). Verified: email `Sent`, link points at `/set-password`.

## Verification

Bruno login → create_practitioner as `admin@chavitos.health` → **201**, all
tests pass. Records verified: practitioner created (charges + charge item
correct), Website User created **with `EB_Practitioner` role**, `User Permission`
link present, and the set-password email **Sent**.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-24 | Sarvesh | Initial version (header backfilled from git history) |
