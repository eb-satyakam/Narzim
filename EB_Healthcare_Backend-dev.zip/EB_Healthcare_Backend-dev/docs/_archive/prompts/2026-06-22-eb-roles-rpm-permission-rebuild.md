# Rebuild EB_ role doctype permissions via Role Permission Manager (preserve Desk defaults)

**Doc status:** record · **Created:** 2026-06-22 by Sarvesh-SocialAngel · **Updated:** 2026-06-22 by Sarvesh-SocialAngel · **Version:** 1.0

Date: 2026-06-22
Author: gaurav (with Claude)
Phase: cross-cutting (RBAC / permissions hygiene)

## Context

The frontend authorizes via `EB_`-prefixed roles (7 roles; `desk_access = 0`).
Doctype permissions for those roles were stored as `Custom DocPerm` rows on 54
core/clinical doctypes. Investigation on `marley.local` found the override was
built **`EB_`-only** on 35 doctypes.

Because Frappe ignores a doctype's standard `DocPerm` the moment **any**
`Custom DocPerm` exists for it, the `EB_`-only overrides had **stripped 139
default-role permissions** (`System Manager`, `Physician`,
`Healthcare Administrator`, `Nursing User`, `Laboratory User`,
`Accounts Manager/User`, ERPNext HR/Stock/Sales roles). Only the literal
`Administrator` account still worked, because it bypasses all permission checks
— masking the breakage.

`meta.permissions` (the live runtime set) confirmed it, e.g.:
- `Medication` -> only `EB_Healthcare Admin, EB_Nurse, EB_Practitioner`
  (`System Manager`, `Physician` return `has_permission == False`).
- `Sales Invoice` -> only `EB_*` (Accounts roles gone).

## Goal

- All default Frappe + Marley/Healthcare roles behave **exactly as shipped** in
  Desk (not edited, just preserved).
- All `EB_` roles keep their existing frontend doctype permissions.
- Use the **Role Permission Manager** mechanism (which *is* `Custom DocPerm`),
  invoked through Frappe's official APIs so defaults are copied in automatically.
- Drop the legacy `rmd_Healthcare Admin` role (pre-`EB_` cruft, not a default).

## Mechanism note (important)

Role Permission Manager and `Custom DocPerm` are the same thing: the UI writes
`Custom DocPerm` rows. There is no way to grant a role doctype permissions via
Role Permission Manager without producing `Custom DocPerm`. The fix is to use it
**correctly** — Frappe's `add_permission()` runs `setup_custom_perms()` which
copies the doctype's standard perms into `Custom DocPerm` first, then adds the
new role. That copy is what preserves the defaults; the original hand-built
fixture skipped it.

## Plan

For each doctype that currently has any `EB_` `Custom DocPerm` row:

1. Back up current `Custom DocPerm` to scratchpad (rollback safety).
2. Capture the intended `EB_` rows: `(role, permlevel, {perm flags})`.
3. `reset_perms(doctype)` -> revert doctype to its pure shipped defaults.
4. For each captured `EB_` row: `add_permission(doctype, role, permlevel)`
   (copies defaults into Custom DocPerm on first call), then
   `update_permission_property(...)` per flag to match the captured `EB_` perms.
5. Delete any `rmd_Healthcare Admin` rows from the rebuilt `Custom DocPerm`.
6. `frappe.db.commit()`, clear cache.
7. Persist portably as a **migration patch** (NOT a fixture — see Outcome).

## Outcome (2026-06-22)

Applied to `marley.local` and verified: `total_stripped` went 139 -> 0,
`eb_only_doctypes` 35 -> 0, all `EB_` perms retained (138 rows), `rmd_` purged
from both `tabDocPerm` (24 orphan rows) and `Custom DocPerm`.

Findings during execution:
- `rmd_Healthcare Admin` is an **orphaned role** (Role record deleted; 24 stale
  `DocPerm` rows remained, broken link) -> purged.
- 2 `Custom DocPerm` parents were **dead doctypes** (`Healthcare Insurance
  Company` -> renamed to `Insurance Payor`; `Lab Test Group` removed) -> 3 dead
  `EB_` rows dropped.

Persistence decision: the old `fixtures/custom_docperm.json` filtered on
`role LIKE 'EB_%'`, so `export-fixtures` would only capture `EB_` rows and
re-introduce the EB_-only override (and the bug) on every fresh import.
Therefore:
- Deleted `fixtures/custom_docperm.json`.
- Removed the `Custom DocPerm` entry from `hooks.py` `fixtures`.
- Added `patches/v0/rebuild_eb_role_permissions.py` (registered in
  `patches.txt`, post_model_sync), driven by the canonical
  `patches/v0/eb_docperm_spec.json` (48 doctypes, 139 `EB_` rows, 6 roles;
  `EB_Patient` intentionally has none). The patch creates EB_ roles if missing,
  purges orphan roles, drops dead-parent perms, self-heals stripped overrides
  (reset only when defaults are missing), then re-applies `EB_` via
  `add_permission`/`update_permission_property`. Idempotent; verified self-heal
  by re-breaking `Medication` and re-running.

The patch reverts to each environment's own shipped defaults before re-adding
`EB_`, so defaults are environment-native (no frozen-fixture drift).

## Risks / tradeoffs

- **Frozen defaults (inherent):** any `Custom DocPerm` overrides standard, so the
  copied defaults are frozen at today's values. After a major ERPNext/Healthcare
  upgrade that changes default perms, re-run steps 3–4 to refresh. Unavoidable
  while `EB_` roles hold doctype permissions (the alternative — API-layer authz,
  no Custom DocPerm — was rejected because we want `EB_` doctype perms).
- `reset_perms` discards any *intentional* non-standard tweaks to default-role
  perms made via RPM. That is desired here ("defaults as shipped").
- Leaked `EB_` rows in standard `DocPerm` (`Allergy`, `Surgical History`,
  `EB Clinic Settings`) are left in place — harmless once Custom DocPerm is
  active (overridden); flagged for separate cleanup.
- `rmd_Healthcare Admin` Role record itself is left (only its perms dropped);
  full role deletion is a separate decision.

## Verification

- Re-run the audit: expect `total_stripped == 0` and `rmd_` absent from active perms.
- Spot-check `meta.permissions` for `Medication`, `Sales Invoice`, `Patient`:
  default roles present again, `EB_` retained, `rmd_` gone.

## Rollback

Restore from the scratchpad backup of `Custom DocPerm` (re-insert captured rows),
or `git checkout` the previous `custom_docperm.json` and `bench migrate`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-22 | Sarvesh | Initial version (header backfilled from git history) |
