# AI Copilot — Deepgram grant-token TTL bug: wrong JSON field name

**Doc status:** record · **Created:** 2026-07-15 by Sarvesh-SocialAngel · **Updated:** 2026-07-15 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-15
**Repos:** both (`remedisys_healthcare_ai` backend, `Healthcare_next_app` frontend)
**Branch:** `feature/ai_v1` (both repos)
**Trigger:** live browser testing of the AI Copilot's Progress Note feature surfaced a
transcript where every line was labeled "DOCTOR" regardless of who was actually
speaking, and intermittent "AI connection lost" errors mid-session.

## Investigation — the long way round

1. Confirmed the transcript garbling started only after roughly the same elapsed time
   in every session (~24-25s), not from the first words. Hypothesis: something tied
   to the recording's elapsed time, not audio quality.
2. Traced this to the app's proactive token-rotation logic (`real-provider.ts`'s
   `_scheduleRefresh`/`_rotateSocket`), which reconnects to Deepgram shortly before
   the current grant token's reported `expires_in` elapses.
3. Ran a direct empirical test (`bench console`, real `mint_browser_token()` call,
   real WebSocket via Python's `websocket-client`): opened a live connection and
   watched it. It errored `"ping/pong timed out"` and closed at t=31s — interpreted
   at the time as proof that Deepgram enforces a hard ~30s connection lifetime tied
   to the token's TTL.
4. Built two increasingly large fixes on that (wrong) premise:
   - A manual "push-to-talk" doctor/patient toggle (fully implemented, then
     explicitly abandoned by the user before landing — reverted to the last commit).
   - A dual-microphone architecture plan (two independent mic pipelines, one per
     role, to sidestep Deepgram's per-connection speaker-identity reset on
     reconnect) — fully designed as an ADR-style plan, not yet built, when the user
     asked for the assumption to be verified against Deepgram's actual documentation
     before building anything further.

## The actual root cause — found by reading the official docs, not assuming

Per Deepgram's [Token-Based Authentication guide](https://developers.deepgram.com/guides/fundamentals/token-based-authentication):
> "You only need the temporary token to be valid during the initial websocket
> connection to Deepgram's APIs. The websocket connection will then stay open as it
> would in any other case until you close it."

Per the [Grant Token API reference](https://developers.deepgram.com/reference/auth/tokens/grant),
the request body field controlling token lifetime is named **`ttl_seconds`**
(default 30s if omitted).

Our code (`integrations/deepgram.py`, both `mint_session_token` and
`mint_browser_token`) was sending the field as **`time_to_live_in_seconds`** — an
unrecognized key. Deepgram silently ignored it and fell back to its documented
default of 30 seconds, regardless of the value we actually requested (confirmed via
`bench console`: requesting 3900s, receiving back `expires_in: 30` every time).

**This one field-name typo is what actually caused the ~30s-per-connection
behavior** — not a Deepgram platform limit. The earlier "confirmed" 31-second
disconnect test was also independently flawed: it used `websocket-client`'s
`run_forever(ping_interval=5, ping_timeout=3)`, enabling that library's own
client-side WebSocket ping/pong heartbeat. The error string
`"ping/pong timed out"` is that library's own internal error when *its* pings
don't get timely pongs back — not a Deepgram-emitted error at all (Deepgram's real
inactivity error is a distinct `NET-0001`/code-1011 close, per the
[Audio Keep Alive doc](https://developers.deepgram.com/docs/audio-keep-alive)).
Two independent things were wrong at once, and they happened to produce a
consistent, plausible-looking, but wrong signal.

## Fix

`integrations/deepgram.py` — both call sites, one-line change each:
```python
# before
json={"scopes": ["usage:write"], "time_to_live_in_seconds": ttl_seconds, ...}
# after
json={"scopes": ["usage:write"], "ttl_seconds": ttl_seconds, ...}
```
Also corrected several comments (in this file and in `real-provider.ts`) that had
been written under the wrong assumption, so a future reader doesn't inherit the
same incorrect mental model of a hard Deepgram limit.

No push-to-talk feature, no dual-mic architecture, and no ADR were needed — this
supersedes both of those in-progress efforts.

## Verification

1. `bench console`: `mint_browser_token()` after the fix returns `ttl_seconds: 3900`
   for a `max_session_minutes: 60` setting, not 30 — confirms the field is now
   recognized and honored.
2. Corrected direct WebSocket longevity test (same method as before, this time
   **without** the client-side `ping_interval`/`ping_timeout` misconfiguration):
   opened a real connection with the long-lived token, sent Deepgram's documented
   `{"type": "KeepAlive"}` message every 5 seconds, and the connection stayed alive
   continuously through a full 60-second observation window — more than double the
   old apparent limit — closing only when the test script itself called `.close()`.
3. `npx tsc --noEmit` / `npx eslint` on the touched files (comment-only changes on
   the frontend side) — clean, no new errors.

## Lesson

Two lessons worth keeping: (1) a plausible, reproducible empirical test result can
still be wrong if the test harness itself has a flaw — cross-check surprising
findings against a second method (official docs, in this case) before building
substantial architecture on top of them; (2) "it looks like a hard platform limit"
is a hypothesis, not a conclusion, until the vendor's own documentation is actually
read for the specific field/behavior in question.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-15 | Sarvesh | Initial version (header backfilled from git history) |
