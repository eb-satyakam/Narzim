# 2026-07-23 — Encounter Copilot: agentic tool-calling assistant

**Doc status:** record · **Created:** 2026-07-24 by Sarvesh-SocialAngel · **Updated:** 2026-07-24 by Sarvesh-SocialAngel · **Version:** 1.0

## Ask
Upgrade the "Ask Narzim AI anything about this encounter" chat from a single-turn
read-only Q&A into an **agentic, tool-calling assistant** the physician can use to:
- Ask about THIS patient — labs, previous encounters, current doctor-patient
  transcript context, current encounter state.
- Ask the LLM what to prescribe / what workup to do.
- Tell the LLM to ACT — "add amoxicillin 500mg", add a lab / diagnosis /
  procedure / therapy / symptom to the current encounter.

## Decisions (user, 2026-07-23)
- **Write UX = direct draft-fill.** An action from the chat lands straight in the
  form draft with the ✦ AI badge, editable/removable — exactly like "End & fill".
  Nothing persists to the DB until the physician Saves/Signs (Rule 6 intact).
- **Scope v1 = read + write both.**
  - Read tools: patient labs, previous encounters, current transcript, current
    encounter state.
  - Write actions: add medication / lab / diagnosis / procedure / therapy / symptom.

## Architecture
Bounded tool-calling loop (NOT an autonomous multi-agent system — one deterministic
turn, capped tool iterations; Rule 9 compliant). Provider function-calling
(OpenAI active — gpt-5-mini; Anthropic mirrored).

Key reuse: **write tools never write the DB.** When the model "calls" add_medication
etc., the backend captures the args and returns them as `actions` — the SAME
`ClinicalSuggestion` objects the copilot already applies via `applyCopilotSuggestion`.
So chat writes flow through the existing direct-fill pipeline (draft, editable, AI
badge, allergy/interaction safety flags), and there is no new DB write path.

Chain (Rule 4): LLM → tool call → Python tool fn → Frappe (read) / suggestion object
(write) → physician review in draft → Save/Sign persists.

- `ask_copilot(encounter, prompt, history, transcript)` → `{ reply, actions[] }`.
- Read tools query Frappe: labs (labs/clinical api), previous encounters
  (encounters api), transcript (passed from client / AI Transcript Segment),
  current encounter (build_encounter_context).
- Every call logged to AI Prompt Log (Rule 9/10 — IDs + tokens, no PHI content).

## Files (planned)
- `prompts/ask-copilot-v2.txt` — agent system prompt + tool-use discipline.
- `services/ai.py` — tool schema builders + action-normalization to ClinicalSuggestion.
- `integrations/openai.py` (+ `anthropic.py`) — tool-calling loop on chat_reply.
- `api/v1/ai/api.py` — `ask_copilot` orchestration + read-tool executors.
- Frontend chat box — send prompt+history+transcript, render reply, apply `actions`
  through `applyCopilotSuggestion`.

## Constraints
Physician-in-the-loop (Rule 6), no PHI in logs (Rule 10), bounded loop (Rule 9),
no core edits (Rule 1). Not committed without permission.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-24 | Sarvesh | Initial version (header backfilled from git history) |
