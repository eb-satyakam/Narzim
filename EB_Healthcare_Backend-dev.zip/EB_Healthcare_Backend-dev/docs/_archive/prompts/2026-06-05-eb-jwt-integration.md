# 2026-06-05 — Integrate eb_frappe_jwt as the Remedisys auth mechanism

**Doc status:** record · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-05 by Sarvesh-SocialAngel · **Version:** 1.0

## Task

Replace the current fragmented authentication with `eb_frappe_jwt` Bearer JWT
across the backend (`remedisys_healthcare_ai`) and the Next.js frontend
(`Healthcare_next_app`). Execute the integration recorded in
`prompts/2026-06-05-eb-frappe-jwt.md` items 6–7.

## Why (current state, audited 2026-06-05)

Three layers disagree on auth:

| Layer | Actually does | Credential |
|---|---|---|
| Backend docs + Bruno + `get_current_user` | Frappe OAuth2 (`/oauth2/get_token`, password grant, client_id/secret) | `Authorization: Bearer <oauth jwt>` |
| Frontend (`auth.ts`) | Frappe session login (`/api/method/login`), scrapes `sid` cookie | `Cookie: sid=<sid>` |
| ADR-010 | Specifies SID stored in NextAuth session (BFF) | `Cookie: sid=` |
| `eb_frappe_jwt` (built, CI-green) | HS256 JWT + refresh rotation + 2FA + lockout | `Authorization: Bearer <jwt>` |

It only works today because `frappe.session.user` is populated from either a
Bearer token or a sid cookie, and `get_current_user` / `require_permission()`
read `frappe.session.user`. Problems: no token refresh (hard 24h expiry),
OAuth2 client creds in `.env.local` are dead, no 2FA / lockout on the real path,
and sid cookies cannot serve the planned mobile client (needs Bearer).

`eb_frappe_jwt` unifies all three onto the `Authorization: Bearer` contract the
architecture diagrams already assume — and the backend needs almost no change
because its `auth_hooks` sets `frappe.session.user`.

## Approved decisions (2026-06-05)

1. **Direction:** integrate `eb_frappe_jwt` Bearer across backend + frontend. ✅
2. **2FA scope:** ship **password-only Bearer first**; add the OTP second-step
   (`verify_otp`) as a follow-up. Backend already supports 2FA when enabled. ✅
3. **Process:** write ADR + integration plan MD first, get approval, **then**
   implement. ✅

## Deliverables (this session — docs only)

1. `prompts/2026-06-05-eb-jwt-integration.md` — this file.
2. `docs/adr/adr-011-auth-eb-frappe-jwt.md` — supersedes ADR-010 §3 (sid clause)
   and the Phase 0 OAuth2 mechanism.
3. `docs/AUTH_INTEGRATION_PLAN.md` — phased, file-by-file plan (backend +
   frontend), password-only first, 2FA later.

No code changes until the plan is approved.

## Out of scope

- 2FA frontend flow (deferred — backend-ready).
- Mobile client (future; Bearer makes it possible).
- Any change to `require_permission()` / service layer (unaffected).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
