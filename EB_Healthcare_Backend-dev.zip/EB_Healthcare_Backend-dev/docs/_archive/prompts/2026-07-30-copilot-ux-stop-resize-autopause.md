# AI Copilot UX: cancellable requests, resizable transcript, silence auto-pause

**Doc status:** record · **Created:** 2026-07-30 by Sarvesh-SocialAngel · **Updated:** 2026-07-30 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-30
**Repos:** `Healthcare_next_app` (frontend only — no backend change)
**Branch:** dev

## Request (verbatim intent)

Three UX improvements to the encounter AI Copilot, without breaking existing behaviour:

1. **Stop/Cancel for in-flight AI work.** While Analyze or Chat is running, the
   Send/Analyze button becomes **Stop**. Stop aborts the network request via
   `AbortController`, returns the UI to idle immediately, allows a new request
   right away, and shows **no error toast** for a user-initiated cancel. Keep any
   partial response.
2. **Vertically resizable Transcript panel.** Draggable handle between Transcript
   and AI Chat. Sensible min/max. Chat takes the remaining height. **Default must
   look exactly as it does today** (20% / 80%) until the user drags.
3. **Auto-pause after 2 minutes of speech silence.** Pause transcription, show a
   non-intrusive banner ("Transcript has been paused due to 2 minutes of
   inactivity.") plus a **Resume** button that continues without a page refresh.
   Reset the timer on speech. Do not run the timer when already paused/stopped.
   Ignore network delay and AI-processing state — only *speech* inactivity counts.

4. **Edit a sent chat message, like ChatGPT** (added mid-task: *"i have option to
   edit chat .. like chat gpt .."*). Hover a message you sent → Edit → the bubble
   becomes an inline editor; sending rewinds the thread to that turn and re-asks.

General: no unnecessary UI change, preserve design language, reusable and
duplicate-free, no leaked listeners/timers/controllers.

## Findings that shaped the implementation

- **Chat/Analyze do not stream.** Every AI call in `NarzimAIChatBar` is a single
  `await res.json()` (`/api/ai/chat`, `/api/ai/analyze`, `/api/ai/analyze-document`,
  `/api/ai/analyze-lab`). So "stop streaming" reduces to aborting the fetch —
  there is no token stream to tear down and no partial text to preserve. The
  doctor's own message stays in the thread, which is the only partial artefact.
- **Only one AI generation can be in flight at a time** — `handleSubmit`,
  `handleAnalyze` and `handleAnalyzeLab` all guard on `loading` / `analyzing` /
  `analyzingLab`. One shared `AbortController` ref is therefore sufficient and
  avoids a per-call-site controller zoo.
- **`real-provider.ts:1063` drops empty Deepgram results** (`if (!alt?.transcript?.trim()) return;`),
  so every `onTranscript` emission is genuine speech. That makes the existing
  transcript callback the correct, already-available silence signal — no new VAD,
  no audio-level metering, no extra Deepgram event wiring.
- The 20/80 split lives in `encounter-screen.tsx` (right lane), not in
  `CopilotPanel`, so the resize handle belongs to the lane that owns both boxes.

## Deliberate decisions

- **Drag direction is direct, not inverted.** The brief said "drag upward to
  increase transcript height", but the handle sits *below* the transcript, so
  direct manipulation means dragging **down** grows it. A splitter that travels
  opposite to the pointer reads as broken, so the handle follows the pointer.
  Flagged to the user; it is a sign flip if they want the literal wording.
- **Silence timer lives in `use-copilot.ts`**, beside the state machine that owns
  `pause`/`resume`/`state`, rather than in the panel — the panel stays a
  renderer. Implemented as a `lastSpeechAt` ref plus one interval keyed on
  `state === "recording"`, which cannot go stale and stops itself the moment the
  session is manually paused, stopped or errored.
- **Race guard on cancel.** Each request captures its own controller; the
  `finally` block only clears busy state when `abortRef.current === ctrl`, so an
  aborted request cannot reset the flags of a newer request the user just started.

- **Editing rewinds rather than branches.** Saving an edit drops the edited turn
  and everything after it, then re-sends — no version history, matching how the
  physician actually wants it (fix the question, get the right answer). Turns that
  carried an attachment are not editable: the `File` is gone after upload, so the
  document could not be re-analysed. Anything a superseded answer already filled
  into the encounter draft is deliberately left in place — those are
  physician-reviewable suggestions, and yanking clinical fields out from under the
  doctor is worse than letting them correct them knowingly.

## Correction made during the work

A `react-hooks/purity` **error** ("Cannot call impure function during render",
`Date.now()` in `handleSubmit`) appeared only after these edits — eslint is a CI
gate, so it had to go. My first guess (a render-evaluated ternary in `onClick`)
was wrong and the fix did nothing; verified by bisecting against the index
version. Root cause is the rule seeing the impure clock read inside a component
body once the handler is reachable from render. Fixed the way this codebase
already does it — a module-scope `msgId()` helper alongside the existing
`newThreadId()` (and `use-copilot`'s `chatId`). Bonus: the added counter removes a
latent duplicate-React-key bug for two bubbles pushed in the same millisecond.

## Known limitations (reported, not silently shipped)

Aborting the browser fetch does **not** cancel the backend LLM call. The Next.js
route handler's `frappeFetch` does not forward the abort signal, so the model
finishes and `ask_copilot_agent` still persists its `AI Encounter Chat Message`.
Consequence: a stopped reply can reappear when the thread is reopened from
History, and the tokens are still billed. Fixing this properly means threading
`request.signal` through the route handler into `frappeFetch` (and ideally a
server-side cooperative cancel), which is a separate backend/BFF change and is
out of scope for this UI task.

Same shape for editing: the superseded `AI Encounter Chat Message` rows are not
deleted server-side, so reopening the thread from **History** shows the original
question and answer as well as the edited pair. Making an edit truly destructive
(or properly branched) needs a backend delete/branch endpoint.

## Files touched

| File | Change |
|---|---|
| `copilot/use-vertical-resize.ts` | **new** — reusable pointer-driven vertical splitter hook (min/max clamp, viewport re-clamp, listener cleanup) |
| `copilot/use-copilot.ts` | silence tracking + `autoPaused` state; reset on start/resume; timer only while recording |
| `copilot/CopilotHost.tsx` | pass `autoPaused` through |
| `copilot/CopilotPanel.tsx` | inactivity banner + Resume button |
| `encounter-screen.tsx` | resize handle between the Copilot and chat boxes; chat becomes `flex-1` |
| `NarzimAIChatBar.tsx` | `AbortController` on all 4 AI calls, `Stop` on Send + Analyze, silent abort handling, unmount abort |
| `NarzimAIChatBar.tsx` | message editing: `sendTextTurn`/`runChatFetch` split so first-send and edited re-send share one path; inline editor; module-scope `msgId()` |
| `messages/en.json`, `messages/es.json` | `aiChat.stop`/`editMessage`/`saveEdit`/`cancelEdit`, `copilot.autoPausedBanner`/`resizeHandle` |

## Follow-up in the same session: duplicate uploads + multi-file

**Reported:** re-sending the same image inserted a new DB row each time
(*"if i upload same image muliple time ... it upload multple time in bd"*), and a
request to attach several files at once with a 10 MB ceiling.

**Root cause, reproduced on `marley.local`:** one PDF (content hash
`a2f029fa…`) had produced **three** `Patient Medical Record` rows
(`HLC-PMR-2026-00073/74/75`) plus three `File` rows for encounter
`HLC-ENC-2026-00121`. Frappe dedupes the *blob on disk* (reuses `file_url`) but
still writes a new `File` row, and `documents.upload_document` always inserted a
new PMR — so nothing anywhere was actually deduplicating the document.

**Fix:** `_find_patient_document_by_content()` matches on Frappe's own
`get_content_hash` (md5), so it is byte-exact — a renamed copy of the same scan is
caught, and two different reports sharing a filename are not. On a hit the endpoint
skips the insert, names the file in the reply, and still summarises it.

Scoped to the **patient**, not the encounter: PMR has no encounter link to filter
on (`reference_doctype`/`reference_name` already point at the File doc), and the
duplicate rows land in the patient's chart. Patient scope is strictly stronger —
it catches the same-encounter case plus re-uploads at later visits.

The query narrows to the patient's own PMR rows *first*, then matches the hash
inside that set. Hash-first with a cap would put the bound on the wrong axis: one
hash can be shared by many patients (a blank consent form), so a capped hash-first
scan could page past the patient's own copy and fail open into a duplicate insert.

**Multi-file:** `summarize_document(files: list[tuple[bytes, str]])` already
accepted a batch and puts every part in ONE vision request, so several pages read
as one document instead of N disconnected summaries. The endpoint now reads
`files.getlist("file")`, dedupes each file independently, and names unreadable
types in the reply rather than discarding the readable attachments beside them.
Limits: **10 MB per file** (`_MAX_ANALYZE_FILE_BYTES`, below documents.py's 25 MB
storage cap because these bytes also go to a vision model) and **5 files per
message** (`_MAX_ANALYZE_FILES`, Rule 5 — every part is billed as image tokens in
the same request). Mirrored client-side for instant feedback; the server remains
authoritative.

Verified against the live DB with the vision call stubbed and a rollback: 2 files
in → exactly **1** new PMR, duplicate named, both documents returned, one combined
summary; oversize and too-many both refused with clear messages; an unsupported
type named while the readable file still analysed; PMR count back to 5 after
rollback.

**Not done, needs your call:** the two stale duplicate rows already in the chart
(`HLC-PMR-2026-00074`, `HLC-PMR-2026-00075`) are untouched — deleting existing
patient records is not something to do unasked.

## Follow-up: thumbnails, duplicate cleanup, reload persistence

**Thumbnails (ChatGPT-style).** The sent bubble was joining every filename into
one `truncate`d string, so three attachments rendered as one ellipsis. The message
now carries `attachments: {name, previewUrl}[]`: images render as 16px-square
thumbnails above the text (as ChatGPT does — the image is what is being asked
about, so it leads), PDFs fall back to a name chip. The composer matches, with the
remove X on the tile corner.

Blob-URL ownership is the whole risk here, so it is explicit: every URL created
goes into one `previewUrlsRef` registry and is released on removal from the
composer, on "+" (new chat), and — as a catch-all — on unmount, so none can
outlive the component. `createObjectURL` runs in the event handler, **not** inside
the state updater: StrictMode double-invokes updaters in dev, which would allocate
two URLs per file and leak the one that never reached state. Sending deliberately
clears the composer *without* revoking — ownership transfers to the message, whose
bubble still renders those thumbnails.

**Duplicate cleanup (authorised).** Before deleting anything I checked the one real
hazard: Frappe can share a blob between `File` rows, so removing a duplicate row
could destroy the survivor's content. It did not apply — each of 73/74/75 had its
own `file_url` with `rows_sharing_this_url = 1`. Deleted `HLC-PMR-2026-00074` and
`HLC-PMR-2026-00075` plus their File rows (8 → 6 rows for the patient), then
verified `HLC-PMR-2026-00073` still reads its full 154,140 bytes.

A site-wide sweep found **one** remaining same-patient duplicate group on a
different patient (`MRN-2026-0000001`, `HLC-PMR-2026-00062/00063`). Left alone —
only 74/75 were authorised.

**Attachment turns vanished on reload.** `_persist_chat_turn` was only called from
the chat/analyze path, so an upload turn lived solely in browser state and was gone
after F5 — unlike every other kind of turn. The endpoint now takes `prompt` and
`thread` (forwarded through the composer and the BFF route) and persists both the
doctor turn and the assistant reading. Since the doctype has no attachments field,
the filenames go into the doctor's message text, so a reloaded thread does not show
a bare "analyze it" with no indication of what was attached. Thumbnails are not
restored: blob URLs for locally-picked files cannot outlive the page.

Verified by persisting a two-file turn and replaying it through
`get_encounter_chat` exactly as the reloaded UI does — 2 rows, correct thread,
`"anlize it\nAttached: scan_page1.png, scan_page2.png"` then the reading — with a
rollback so no test data remained.

## Final round: attachments survive reload, per-user AI language

**Attachments were dead text after reload.** Persisting the turn (previous round)
restored the *conversation* but not the *files* — the thumbnail was a `blob:` URL
that cannot outlive the page, so a reloaded thread showed an unopenable filename.
Fixed properly: a new `attachments_json` field on `AI Encounter Chat Message`
stores `[{name, file_url}]`, `get_encounter_chat` replays it, and the UI renders
images as real thumbnails and every attachment as a link — served through the
existing `/api/file?path=` proxy, which already attaches the bearer token so
PRIVATE patient files resolve and the browser never talks to Frappe directly
(API_RULES). No new endpoint was invented for this.

**AI output language is now per-user.** Product decision (2026-07-30): the
language belongs to the *person*, not the deployment — a bilingual clinic floor
shares one site, so an English-speaking and a Spanish-speaking clinician must each
be answered in their own language. `_user_language()` reads the signed-in user's
`User.language` and takes precedence in both `resolve_chat_language()` and
`resolve_suggestion_language()`; the AI Settings fields and the compliance profile
remain as fallbacks for users who have not set one. Explicitly NOT driven by
`site_config`, which would force one language on everybody.

Verified: `User.language` `es`→`es`, `en`→`en`, blank→falls back to the AI Settings
value, Guest→falls through without raising.

**Two of my own mistakes this round, both caught by testing rather than assumed
away:**
- A `sed`-style patch to `get_encounter_chat`'s field list silently no-opped
  (indentation mismatch) because I asserted only *some* of the replacements in that
  script. The replayed `attachments` came back empty and the test caught it. Every
  string patch in that script now carries an assert.
- I "verified" the new DB column as missing three times using
  `frappe.db.sql("desc ...", as_dict=True)` and reading `c.name` — MariaDB returns
  `Field`, so I was testing a list of `None`s. The column had existed since the
  first `reload_doc`. `frappe.db.get_table_columns()` is the correct check.

**Full encounter suite: 14/14 passing** — multi-file upload, content-hash dedupe
(only the non-duplicate inserted), one combined vision call per batch, duplicate
notice, turn persisted for reload, prompt+filenames retained, attachments replayed
with `file_url`, image ref present for thumbnails, assistant reading persisted,
10 MB cap, 5-file cap, no-file rejected, unreadable type named while readable files
still analysed, signed-encounter transcript archive readable (29 segments). Run
against the live DB with the vision call stubbed and a rollback, leaving no test
data.

## Consolidated AI record on sign (decision overrides my recommendation)

**Requested:** on encounter submit, write ONE record per encounter holding the
whole transcript, the whole chat and every suggestion as JSON.

**I advised against it and was overruled; building it was the user's call.** My
objection, recorded here so the trade is not lost:

1. It duplicates content that already lives in `AI Transcript Segment` and
   `AI Encounter Chat Message`, so the copy is **not** covered by
   `ComplianceProfile.transcript_retention_days` (90 mx / 30 in). When a transcript
   purge is finally implemented it must explicitly decide whether to purge this
   record too — otherwise the retention promise is honoured in one place and
   broken in the other. **This is still an open decision.**
2. A data-subject erasure request now has to reach this row as well.
3. It does not make the signed note safer: the note is the clinical record, the
   transcript is evidence. What actually protects it is *locking* the source rows
   on sign, which still does not happen (there was no `on_submit` hook at all).
4. Two copies can drift — "Fix speakers" rewrites live segments after signing and
   the snapshot would not follow, leaving two versions of what the patient said.

**Built:** `AI Encounter Record` (autoname `field:encounter`, so one per encounter
by construction), `services/encounter_ai_record.py`, a `Patient Encounter`
`on_submit` hook appended **last** in the existing list, and
`get_encounter_ai_record()` for a single-fetch read. Source rows are kept as the
live write path — streaming and chat replay depend on them — so this is a copy,
not a move.

Rule 7 is enforced hard: the hook swallows everything and records a partial
capture in `capture_error`, so signing a clinical encounter can never fail because
an AI record could not be gathered.

Verified on the signed encounter `HLC-ENC-2026-00120`: 29 segments, 5 chat turns,
4 suggestions, 237,392 in / 2,770 out tokens; re-running overwrites rather than
duplicating (1 row → 1 row); the read API returns everything and reports
`exists: False` for an encounter with no record; and both a bad encounter id and an
injected internal exception were swallowed without raising. Rolled back, no test
data left.

Also removed in this round: the `AI Settings.chat_language` /
`suggestion_language` override fields, now that language comes from
`User.language`. AI Settings is a Single, so the two stale `tabSingles` rows were
deleted; nothing reads them, so no patch is needed for existing deployments.

## Verification

- `npx tsc --noEmit` — clean (one pre-existing `e2e/encounter-submit.spec.ts`
  error is unrelated and untouched).
- `npx eslint` per file, compared against the **index** version as baseline:
  NarzimAIChatBar 0 (was 0), encounter-screen 19 (was 19), CopilotPanel 1 (was 1),
  CopilotHost/use-copilot/use-vertical-resize 0. No new findings introduced.
- `npx next build` — `✓ Compiled successfully`, 247/247 static pages.
- `en.json` / `es.json` key parity — no locale-only keys.
- Not committed: awaiting review per the standing no-commit-without-permission rule.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-30 | Sarvesh | Initial version (header backfilled from git history) |
