# 2026-07-31 — Refuse non-clinical chat attachments + fix the AI output language

**Doc status:** record · **Created:** 2026-07-31 by Sarvesh-SocialAngel · **Updated:** 2026-07-31 by Sarvesh-SocialAngel · **Version:** 1.0

Fourth and fifth fixes of the session. See also
[admin-cannot-sign](2026-07-31-admin-cannot-sign-encounter.md),
[copilot gating](2026-07-31-copilot-gating-and-transcript-error.md),
[fix-speakers persistence](2026-07-31-fix-speakers-not-persisting.md).

## A — "if i upload any non medical file in chat ai will tell this is non medical document"

### Symptom

The physician attached `Marley_Healthcare_AI_Master_Document.pdf` (our own product
blueprint) in the Narzim chat. The AI summarised it as a clinical document —
"Document: Documento maestro … Key findings: - Visión de producto …" — and the PDF
was filed into the patient's Documents under **Lab Reports**. A product spec for a
clinical AI is the hardest case for a keyword-based intuition: it is saturated with
clinical vocabulary while containing no patient's care record at all.

### Cause

Two separate gaps:

1. `document_summary_v1.txt` only told the model to bail out on an *unreadable or
   blank* document. A readable non-clinical file simply got the full clinical
   treatment.
2. `upload_and_analyze_document` filed each attachment **inside the per-file
   loop**, i.e. before anything had read it. The analysis ran afterwards, so no
   verdict could possibly influence what was already in the chart.

### Fix (user chose "detect AND don't file it")

- **`llm/prompts/document_summary_v2.txt`** (new) — a two-step prompt: classify
  first, summarise second. It states the test explicitly ("is this a record of one
  identifiable person's care?"), lists non-clinical examples including *software /
  product specification and design documents*, says to judge the file by what it
  IS and never by whether medical words appear in it, and resolves genuine
  ambiguity as NON-clinical because a wrongly filed document in a medical record is
  the more harmful error.
- **`is_medical` + `document_kind` added to `_DOCUMENT_SUMMARY_SCHEMA`** in BOTH
  providers (openai.py, anthropic.py — kept identical so switching
  `AI Settings.llm_provider` cannot change whether a file gets filed, ADR-026).
  Schema-locked rather than sniffing a sentinel phrase out of prose, which would be
  fragile across two languages and two providers. Both adapters default the flag to
  **False** (fail closed).
- **`_analyze_report_bytes`** now returns `(narrative, is_medical, document_kind)`,
  and an empty narrative is reported as non-clinical so an unusable response can
  never be the reason a file is stored as clinical.
- **`upload_and_analyze_document`** — reads and validates the files, analyses them,
  and only then calls the new `_file_pending_documents()`. Non-clinical batches log
  `attachment_not_filed encounter=… files=N kind=…` (kind and count only — a
  filename can carry a patient's name, Rule 10) and nothing enters the chart. The
  duplicate/unreadable notices moved into `_build_notices()` because
  `duplicate_names` is only known after filing.

### v3 — the line was drawn in the wrong place (same day)

v2 made the test "is this a record of one identifiable person's care?". That
correctly excluded the product blueprint, but it also refused a **stock X-ray**
the physician attached: the model answered "stock radiograph image … not a
patient's clinical document", where ChatGPT would simply have read the film. Two
things were wrong with it — an anonymous radiograph is still a radiograph (most
photographed films and clinical photos arrive with no identifiers at all), and
provenance is not content.

`document_summary_v3.txt` re-draws it on CONTENT: a medical image (x-ray, CT, MRI,
ultrasound, ECG trace, pathology/endoscopy image, or a photo of any of these), a
photograph of a clinical finding, or a clinical document is clinical — explicitly
"even when it carries no patient name, no date and no hospital markings, and even
when it is visibly a stock or library image". What stays non-clinical is content
that merely concerns healthcare as a subject: design/spec documents, brochures,
textbook pages, teaching slides, screenshots, receipts. Image readings must state
what is visible and what cannot be assessed (a single view without history
supports a description, not a diagnosis), and a stock/teaching image must be
flagged as such in one line before the sections. Both adapters default to v3.

### Verification

Against the real files, through the production vision path (v3):

| file | is_medical | document_kind |
|---|---|---|
| `istockphoto-177559095` (stock forearm x-ray) | **True** | forearm and wrist radiograph, iStock watermarked stock image |
| `Marley_Healthcare_AI_Master_Document.pdf` | False | internal technical product blueprint |
| `WM17S.pdf` (real Dr Lal PathLabs report) | True | laboratory test report (multiple panels) |
| WhatsApp screenshot of a backlog | False | project backlog spreadsheet |
| app home-screen screenshot | False | mobile app home screen screenshot |

The x-ray now gets a real reading — projection, structures, negative findings,
limitations ("single projection, watermark … occult fracture cannot be excluded")
— plus an Attention line that it is a stock image and must not be taken as the
patient's own study.

Chart-filing side, measured under v2 with the same gate (unchanged in v3):
product blueprint 3 → 3 documents; real lab report 3 → 4. Both rolled back.

Both rolled back. Plus `tests/ai/test_document_upload_gate.py` — 4 tests with the
LLM mocked (it asserts the GATE, not the model's judgement): non-clinical not
filed, clinical still filed, empty classification fails closed, and both chat
turns still persisted for a refused file (ADR-034). 4/4 pass.

### v4 — clinical quality of the image reading

An external clinical review of a Narzim reading of a truncal rash photo rated it
safety 10/10 but flagged five weaknesses. All five went into
`document_summary_v4.txt` (amended in place once, before any AI Prompt Log row
referenced it — see the observability gap below):

1. **Objective observation before interpretation** — new observation rules: sites,
   distribution, morphology, ALL colour change (erythematous / hypopigmented /
   hyperpigmented / depigmented can coexist), and explicit statement of relevant
   NEGATIVES (no vesicles, bullae, pustules, ulceration, crusting, purulence,
   necrosis, bleeding). A stated negative is clinically useful; an omitted one is
   not.
2. **Ranked differential** — a new `Differential considerations` section, numbered
   most-likely-first, each entry naming the visible feature that puts it there,
   plus "what cannot be judged from the image at all". Replaces an unordered list
   of equally weighted names.
3. **Specific limitations** — for a photograph: lighting, camera white balance and
   colour rendering, cosmetics/creams, recent sun exposure, and absence of
   palpation, scale texture and history. For imaging: single projection, obscured
   areas, findings not excludable on that view.
4. **Targeted investigations** — a new `Suggested investigations` section, grouped
   as routine then "If <suspicion> is suspected: <specific tests>", ordered to
   match the ranked differential, with the rule that generic "CBC and inflammatory
   markers" alone is not a useful recommendation. Verified output now names KOH
   prep + Wood's lamp, patch testing out of the acute phase, CBC with differential
   for eosinophilia plus LFT/renal, ANA and targeted serology, and biopsy with DIF.
5. **Symptomatic measures tied to an open diagnosis** — general measures may be
   mentioned, but empiric topical corticosteroids or antifungals must be deferred
   to clinical evaluation "because they can worsen some conditions and obscure the
   diagnosis in others". Still no prescribing or ordering (Rule 6).

Partially landed, deliberately left there: the reviewer's first point was that
prominent HYPOpigmentation was missed and should push a superficial fungal
eruption to the top. v4 adds a rule to name pale areas as hypopigmented rather
than reclassify them as "variable intensity of erythema", and a rule that every
prominent finding must be accounted for in the ranking (naming tinea versicolor
and post-inflammatory hypopigmentation as the examples for pigment loss). After
the change the model describes "some areas appearing paler between patches" and
ranks tinea versicolor 5th with its pigment rationale — up from absent. It was NOT
pushed to rank fungal first: on this photograph pale-versus-blanched is genuinely
arguable, and hardcoding one reviewer's ranking of one image into the prompt would
be overfitting with clinical consequences.

### Observability gap (found, not fixed)

`_analyze_report_bytes` → `summarize_document` writes **no AI Prompt Log row**.
Every other LLM path logs one (ask-copilot-v2, resegregate-v1, Patient Clinical
Summary all appear in the table); document summaries do not, so there is no record
of which prompt version/hash produced a given reading, nor its tokens or cost.
That conflicts with §9 ("Every LLM call logged … prompt_version, model, tokens,
cost, latency") and it is also why v4 could be amended in place without breaking
an audit trail. Worth a `log_prompt_call` at that call site.

### Open trade-off from v3

One flag drives both decisions: `is_medical` decides whether the file is READ and
whether it is FILED. So a stock x-ray is now also written into the patient's Lab
Reports, while its own Attention line tells the physician not to treat it as the
patient's study. Correct for the real case (a photographed film of this patient's
own x-ray must be filed), slightly odd for a stock test image. Splitting into
`is_clinical_content` (drives reading) and `is_patient_specific` (drives filing)
would resolve it — the model already distinguishes them in prose — and is deferred
until someone actually wants it.

### Cleanup outstanding

Two pre-fix uploads of the product spec are still filed in `MRN-YYYY-00024`'s
chart: `HLC-PMR-2026-00082` and `HLC-PMR-2026-00083`. Needs an explicit decision
before deleting patient chart rows.

## B — "jab user ka language english why response in spanish"

### Cause

`resolve_chat_language()` returns a language **code**. `User.language` is Frappe's
Language doctype *name* (`"en"`, `"es"`), and a ComplianceProfile's
`primary_language` is `"es-MX"` / `"en-IN"`. Four call sites tested
`"english" in resolve_chat_language().lower()` — which is False for every one of
those values. English output was therefore **unreachable**, whatever the user's
profile said:

- `api/v1/ai/api.py` — the chat apology on an AI-service failure
- `api/v1/ai/api.py` — the patient lab summary reader
- `api/v1/ai/api.py` — the uploaded-document summary
- `services/ai_tools.py` — the lab-summary tool

### Fix

New `services/ai.py::narrative_lang()` — matches on the `"en"` prefix, so it is
correct for a bare code (`en`), a regional tag (`en-IN`, `en-US`) and a label
(`English`); no other ISO 639-1 code starts with `en`. All four sites now call it.

The per-user precedence itself was already right and is unchanged (2026-07-30
decision): `User.language` → active `ComplianceProfile.primary_language` → `es-MX`.

### Verification

| user | User.language | resolve_chat_language() | narrative_lang() |
|---|---|---|---|
| amanop1210@gmail.com | `en` | `en` | **en** |
| admin@chavitos.health | `en` | `en` | **en** |
| Administrator | None | `es-MX` | es |

### Known gap (not fixed)

The Next.js app never writes `User.language` — its next-intl locale switcher is
purely client-side. So AI output language follows the **Frappe user profile** only;
switching the UI language does not change it. Either surface `User.language` on the
app's profile/settings screen or have the BFF pass the active locale.

## Environment note

`test.marley.local` is behind on migrations — it has no `AI Encounter Chat Message`
doctype (ADR-034), so the gate suite errors there and was run against
`marley.local` with a rollback instead. Worth a `bench --site test.marley.local
migrate` before relying on that site for tests.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
