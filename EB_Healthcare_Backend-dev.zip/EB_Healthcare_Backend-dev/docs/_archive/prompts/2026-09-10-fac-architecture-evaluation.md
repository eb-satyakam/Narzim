# Prompt Archive — FAC (Frappe Assistant Core) Architecture Evaluation

**Doc status:** record · **Created:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-10 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- Date: 2026-09-10
- Author: Sarvesh-SocialAngel (AI-assisted)
- Slug: fac-architecture-evaluation
- Scope: research only. No production code change requested.
- Output: docs research paper "Frappe Assistant Core (FAC) Evaluation for Remedisys"

## Goal stated by the user

"I want Claude Code to become faster and better at understanding, inspecting,
verifying, debugging and suggesting changes to my Frappe backend."

## Prompt (verbatim)

I want you to do a FULL, DEEP ARCHITECTURE RESEARCH of whether Frappe Assistant Core (FAC) should be used in our Remedisys project.

IMPORTANT:
Do not start with a conclusion.
First inspect our actual codebase, current architecture, Encounter flow, existing backend tools/API methods, authentication, BFF, Frappe bench, Claude Code configuration, and the actual FAC source/docs.
Then compare the alternatives using evidence.

PART 1 — Understand our current system (Next.js app/, api/, BFF handlers, lib/api, auth, Frappe client, Encounter flow, patient context, medications, allergies, diagnoses, treatment plans, autosave, persistence, read/write paths, tests/E2E; Frappe: remedisys_healthcare_ai, healthcare, eb_frappe_jwt, DocTypes, whitelisted methods, hooks, permissions, serializers, DB access; Claude Code: .claude/, settings, MCP config, verification workflow). Document exactly how Claude Code talks to Frappe today WITHOUT FAC.
PART 2 — What is FAC actually for? Where it sits, who calls it, why MCP, what it exposes, 5+ concrete examples, plus where FAC is NOT the right abstraction.
PART 3 — Why not put FAC behind the Next.js BFF? Compare Browser->Next->BFF->FAC->Frappe vs Browser->Next->BFF->Frappe across hop count, MCP overhead, OAuth/session, auth duplication, authorization, latency, error handling, observability, debugging, type safety, response schemas, versioning, domain validation, clinical safety, maintainability.
PART 4 — Why not call FAC directly from Next.js? Compare the three options; browser security, OAuth, identity, sessions, MCP, PHI, permission boundaries, predictable clinical APIs, caching, retries, observability. Use a real Encounter user story.
PART 5 — Generic FAC tools vs Remedisys domain tools. Prove from architecture, not assumption. Include disadvantages of custom tools. Answer: when is a custom tool worth creating?
PART 6 — Do we even need FAC if we have custom tools? Compare three architectures.
PART 7 — Six user stories (persistence check, schema, API debug, doctor opens encounter, AI clinical assistant, admin analytics).
PART 8 — Where FAC should live (dev vs prod paths, and why they differ).
PART 9 — Speed analysis. What FAC genuinely makes faster and what it does not.
PART 10 — Failure modes (13 listed) with what Claude sees, what it could wrongly conclude, and prevention.
PART 11 — Security + HIPAA/PHI. FAC's actual logging behaviour. Label FACT / INFERENCE / RECOMMENDATION.
PART 12 — Full comparison matrix.
PART 13 — Final decision A-E plus 11 exact questions.

Final deliverable: a 20-section research paper, simple language, diagrams, evidence from the real codebase and real FAC source, labelled VERIFIED / INFERENCE / RECOMMENDATION.

## Constraints applied

- CLAUDE.md sec.10: WHAT/WHY/HOW/WHEN, >=4 approaches before a recommendation.
- Simple English. Short sentences. No em-dashes.
- Research and documentation only. No change to app code.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-10 | Sarvesh-SocialAngel (AI-assisted) | Archived the FAC evaluation prompt. |
