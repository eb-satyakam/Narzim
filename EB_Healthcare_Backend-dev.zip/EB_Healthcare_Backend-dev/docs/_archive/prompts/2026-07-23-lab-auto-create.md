# 2026-07-23 — Lab Test Template auto-create for AI Copilot

**Doc status:** record · **Created:** 2026-07-23 by Sarvesh-SocialAngel · **Updated:** 2026-07-23 by Sarvesh-SocialAngel · **Version:** 1.0

## Ask
"auto-create nahi (settings-only) vi auto create karoo .. you can use setting apis ..
lab test template create karoo, last day I tested it working fine, why am I not using it today."

Make AI-suggested labs auto-create their master (like medications/procedures/therapies
already do) instead of being dropped when they have no exact catalog match. Use the
existing `create_lab_test_template` catalog API. Keep exact-match-first so the catalog
stays de-duplicated.

## What changed

### Backend — `api/v1/ai/api.py`
- `_SETTINGS_ONLY_MASTERS` reduced from `{"lab", "vaccine"}` to `{"vaccine"}`.
- `create_master` now routes `master_type="lab"` to new `_create_lab_master(nm)`:
  - Idempotent on `lab_test_name` (returns existing, `created=False`).
  - Else calls `catalog.create_lab_test_template(lab_test_name, department, lab_test_group,
    lab_test_template_type="Single", is_billable=False)`.
  - `_default_lab_dept_group()` mirrors an existing template's department + group
    (Pathology / Laboratory on this site); falls back to first Medical Department +
    "Laboratory" on a bare site.
  - Throws with the underlying error if creation silently fails.

### Prompt — `prompts/suggest-v2.txt`
- `orders.labs` `lab_test_name` rule relaxed: STRONGLY PREFER an exact catalog match
  (keeps catalog clean/de-duplicated); only when NO template reasonably fits, the model
  MAY propose a new standard, correctly-spelled lab name — it will be auto-created.

### Frontend — `encounter-screen.tsx`
- `createMasterIfNeeded` type union now includes `"lab"`.
- `orders.labs` branch rewritten from exact-match-or-skip to **match-or-create**:
  - Exact (case-insensitive) catalog match first, with the before-first-paren retry
    (tolerates "Complete blood count (CBC) with differential" → "Complete Blood Count").
  - On no match, `createMasterIfNeeded("lab", name)` auto-creates the template.
  - Every kept lab normalized to the manual-picker shape `{name, label, note, bill_this}`
    — fixes a latent bug where a raw AI item (only `lab_test_name`, no `name`) would save
    with an empty `lab_test_code`.
  - `skippedLabs` now only fires when creation genuinely fails (null id).

## Verification (bench console, marley.local)
- `create_master("lab", "Dímero D (prueba IA)")` → NEW (Pathology/Laboratory/Single,
  non-billable); `"Ferritina sérica"` → matched existing (idempotent).
- Anemia transcript (es-MX): AI proposed CBC / Ferritina / Vitamin B12 / Stool exam —
  all matched the existing catalog (de-dup working, no spurious creates).
- Pheochromocytoma transcript (deliberately exotic): AI proposed 3 specialized tests
  (plasma metanephrines, 24h urine catecholamines, RET/MEN2 genetic) — all correctly
  auto-created (`created=True`). Test templates cleaned up afterwards.
- Frontend `tsc --noEmit`: no new errors on the changed file.

## LLM-assisted UOM + reference range (added same day)
User asked why auto-created labs were all bare Single templates with no UOM/range. Mirrored
the medication LLM-inference pattern so the result structure is drafted, not left empty:
- `prompts/lab-fields-v1.txt` — infers template_type (Single vs Imaging), is_quantitative,
  lab_test_uom (constrained to this site's Lab Test UOM records), and a generic adult
  reference range. Prefers "" over a wrong value.
- `services/ai.py` — `build_lab_fields_message` + `parse_lab_fields` (hard-validates UOM
  against the allowed list, blanks UOM/range for Imaging, length-caps range).
- `integrations/openai.py` + `anthropic.py` — `infer_lab_fields(name, lab_uoms)`.
- `api/v1/ai/api.py` — `_create_lab_master` now calls `_infer_lab_fields_safe` (never fatal;
  degrades to a bare Single on any LLM failure), keyword imaging detection is a hard override,
  and every auto-created template is stamped with the **"AI Review Required"** tag + a comment
  recording exactly what the AI inferred (`_flag_lab_for_review`).

Type inference: `_IMAGING_NAME_HINTS` (ES+EN) → Imaging; else Single. Compound / Grouped /
Descriptive are NEVER auto-created (they need component/member/particular rows a bare name
can't supply) — those remain admin-created in Settings.

Verified: 5 novel rheumatology labs (ANA, anti-CCP, C3, C4, protein electrophoresis) created
with LLM UOM/range (e.g. C3 → g/L, 0.9–1.8; ANA → qualitative, "Negativo"), each tagged
"AI Review Required"; an ultrasound name auto-created as Imaging. When the model is unsure of
a range it returns "" rather than guessing.

## Caveat (accepted by user)
The AI-inferred UOM/range is a DRAFT for physician review — the "AI Review Required" tag +
comment flag it, and a physician/admin must confirm before a result is clinically
interpreted. The template is immediately orderable regardless.

## Out of scope — vaccinations stay settings-only
The user mentioned vaccinations earlier ("bhi"). NOT auto-created, deliberately:
- suggest-v2 has **no vaccines target** — the copilot never proposes vaccines today.
- `create_immunization_template` requires a pre-existing vaccine **Item**
  (`_validate_vaccine_item`) plus a **dose schedule** (age_months, milestones) that drives
  the Mexico EPI scheduling and inventory/billing. Guessing those from an AI name would
  corrupt the immunization schedule — unsafe in a way a bare lab template is not.
- Revisit only if vaccines become a copilot target AND a safe Item+schedule provisioning
  path is designed.

## Not committed
Awaiting explicit permission per repo policy (backend + frontend both on `feature/ai_v3`).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-23 | Sarvesh | Initial version (header backfilled from git history) |
