# Narzim AI — persistent encounter chat memory + Save & analyze

**Doc status:** record · **Created:** 2026-07-25 by Sarvesh-SocialAngel · **Updated:** 2026-07-25 by Sarvesh-SocialAngel · **Version:** 1.0

Date: 2026-07-25
Branch: feature/ai_v3
Repos: EB_Healthcare_Backend + EB_Healthcare_EHR

## User request

- Narzim AI must have full context of THIS encounter: the transcript (already
  wired) AND the entire chat/talk on this encounter, surviving reload.
- Store the chat and its AI suggestions, linked to the encounter (and via it
  the patient + appointment).
- A "Save & analyze" action: send the whole chat + transcript as one prompt →
  the agent generates ClinicalSuggestions filled into the encounter draft.
- "test it all process".

## Decisions (user-confirmed)

- Storage: NEW encounter-scoped doctype `AI Encounter Chat Message` (ADR-031).
- Save & analyze: analyze → suggestions into the draft (same fill pipeline as
  "End & fill"), and the chat is persisted.

## What already existed (verified)

- `ask_copilot` already receives the live transcript (param + get_current_transcript
  tool) and the last ~8 in-memory chat turns. So transcript context worked; the
  gap was PERSISTENCE (chat was in-memory only → lost on reload) and Save & analyze.
- `ai_patient_chat_message` is patient-portal-scoped (no encounter link) — not reusable.

## Plan

Backend (remedisys_healthcare_ai):
1. Doctype `AI Encounter Chat Message` — encounter (Link, reqd), patient/appointment/
   practitioner (fetched), session_user, role (doctor/assistant), content, actions_json,
   kind (chat/analysis), audit (model/tokens/latency). Physician + System Manager perms.
2. ADR-031 documenting the new doctype.
3. Persistence + context helpers; wire into `ask_copilot` (persist each turn; load
   prior turns from DB for context, capped per Rule 5).
4. `get_encounter_chat(encounter)` — replay persisted chat on the frontend.
5. `analyze_encounter(encounter, transcript)` — Save & analyze: full chat+transcript →
   agent → suggestions into draft; persisted as kind="analysis".

Frontend (Healthcare_next_app):
6. Load persisted chat into NarzimAIChatBar on mount (new route /api/ai/encounter-chat).
7. "Save & analyze" button → new route /api/ai/analyze → apply suggestions to draft.

## Rules honored

- Rule 5: context is capped (last N turns), not a full dump.
- Rule 6: write tools still emit suggestions into the draft, never DB writes.
- Rule 10: audit fields store tokens/model, content stored deliberately (chat replay
  is the feature) but no logs carry PHI.
- §9: new doctype gets an ADR (ADR-031).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-25 | Sarvesh | Initial version (header backfilled from git history) |
