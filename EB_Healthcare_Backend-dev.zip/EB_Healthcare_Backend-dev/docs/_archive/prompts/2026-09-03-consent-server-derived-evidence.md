# Consent becomes server-derived evidence (T-38)

**Doc status:** record · **Created:** 2026-09-03 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-03 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

Session task from `Healthcare_next_app/docs/qa/encounter-v3/05-FIX-PLAN.md`,
T-38 (Audit ID C-10, decision D4). Archived per the prompt-archive discipline
(`prompts/README.md` convention), written up after the work rather than
before it started — noted here rather than silently backfilled.

## The task, as given

> "T-38 — Consent ko server-derived evidence banana. v3 we are not taking in
> v1, understand." followed by, once the design was picked, "do 38".

In plain terms: make consent for AI recording something the server can
actually prove happened, not just something the client claims — for the
Guided (V3) encounter screen only, explicitly not Classic (V1).

## Two decisions this session made, not assumed

**1. What the consent record should capture.** Four options were put to the
requester: simple attestation (who/when/how, no wording version), a
versioned consent script, full re-consent per recording session, or a
log-only rollout with no enforcement yet. **Simple attestation was chosen** —
closes the real gap (a client claiming `consent_obtained: true`) without a
second, harder decision about where versioned script text would live.

**2. How to keep V1 working.** V1 and V3 share one chokepoint
(`RealCopilotProvider` -> `start_session`), and V1's own consent gate is
currently bypassed entirely by a dated dev shortcut in `CopilotHost.tsx`
("TEMPORARY DEV SHORTCUT... dont need consent", 2026-07-25 — a real,
separate finding, not fixed here). Making `start_session` unconditionally
require evidence would have broken every V1 recording as a side effect of a
V3-only task. Four options again: an opt-in flag defaulting to today's
behaviour, fixing V1's bypass in the same change, shipping the endpoint
without enforcement, or stopping to report the bypass first. **The opt-in
flag was chosen** (`require_consent_record`, default `False`) — V1's call
site is unaffected, confirmed by a zero-diff on `CopilotHost.tsx` and by a
live e2e test that opens Classic and asserts the new endpoint is never
called.

## What was built

- `record_consent(encounter, method)` — new whitelisted endpoint. Stamps
  `consent_by` (`frappe.session.user`) and lets the doctype's existing
  `_stamp_consent` set `consent_obtained_at` — neither is ever accepted as
  an argument, which is what makes this evidence rather than a second
  client-trusted flag.
- Two new fields on `AI Encounter Session`: `consent_by` (Link, User),
  `consent_method` (Select: `unverified` / `asked_and_agreed` / `declined`).
  `consent_obtained`/`consent_obtained_at` already existed and needed no
  change.
- `start_session(..., require_consent_record=False)` — when the new
  session-scoped flag is truthy, refuses to mint a token unless
  `consent_method == "asked_and_agreed"` already exists.
- Migration patch `flag_unverified_legacy_ai_session_consent_20260903` —
  labels every pre-existing row `unverified`. Does not attempt to guess the
  true historical status. Ran on the local bench: 263 rows flagged.
- Frontend (`Healthcare_next_app`, same task): new `/api/ai/session/consent`
  BFF route; `RealCopilotProvider` gained an opt-in constructor flag; V3's
  `use-recording.ts` `grant()` now calls `record_consent` first and only
  proceeds on real success; `decline()` records evidence best-effort.

## Verification

Backend: 40 tests via `bench console` (12 new), plus a live `curl` sequence
against the real local bench proving refuse-without-evidence ->
record-consent -> succeed-with-evidence -> V1's exact call shape unaffected.
Frontend: 3 new Playwright tests against the real UI and real backend.

Full writeup with the complete decision tables:
`Healthcare_next_app/docs/qa/encounter-v3/05-FIX-PLAN.md`, T-38 section.
Architecture record: `docs/adr/adr-056-consent-server-derived-evidence.md`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Sarvesh-SocialAngel (AI-assisted) | Initial version, written after the work merged. |
