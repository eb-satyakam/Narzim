# AI Scribe — Post-Design-Refactor Status + Pending Tasks

**Doc status:** record · **Created:** 2026-07-01 by Sarvesh-SocialAngel · **Updated:** 2026-07-01 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-01  
**Session task:** Re-read all AI scribe frontend components after Gaurav's design refactor; produce clear MD docs showing done / mock / pending so the team can pick up Sprint 1 immediately.  
**Prior plan doc:** `2026-06-30-ai-scribe-implementation-plan.md`

---

## What changed in the design refactor

The monolithic `AiScribeEncounter.tsx` was split into dedicated component files.
The root orchestrator still exists and owns all state. The new file layout is:

```
src/components/narzim/encounter/ai-scribe/
├── AiScribeEncounter.tsx   — root orchestrator, all state, all data hooks
├── CaptureStage.tsx        — stage 1: consent + record controls + live transcript
├── ReviewStage.tsx         — stage 2: progress rail + DocBody + floating Ask-AI
├── SavedStage.tsx          — stage 3: saved encounter full view
├── doc-body.tsx            — 10-section SOAP body (symptoms, vitals, meds, labs, …)
├── doc-tables.tsx          — MedTable, LabTable, LabRecTable, LifestyleBlock
├── scribe-ui.tsx           — shared primitives: Pill, SectionHeader, card, ghostBtn, fmtTime
├── scribe-types.ts         — TypeScript contracts (ScribeDoc, Lab, Med, LabRec, …)
└── scribe-data.ts          — ⚠️ ALL mock data — flagged Phase 1 → Phase 2 replacement
```

No files were deleted. Contracts (`scribe-types.ts`) and mock data (`scribe-data.ts`) are unchanged.
The real data hooks (`useEncounter`, `usePatientVitals`) and the real save (`approveAndSave`) remain in the root.

---

## What IS wired to real data (done)

| Piece | Where | Notes |
|---|---|---|
| `useEncounter(encounterId)` | `AiScribeEncounter.tsx` | TanStack Query → real Frappe encounter |
| `encounterToScribeDoc()` | `AiScribeEncounter.tsx` | Maps Frappe encounter shape to `ScribeDoc` |
| `usePatientVitals(mrn)` | `AiScribeEncounter.tsx` | Real vitals seeded into `ScribeDoc.vitals` |
| `approveAndSave()` | `AiScribeEncounter.tsx` | Calls `encountersApi.saveDraft()` → real Frappe write |
| TypeScript types | `scribe-types.ts` | Complete — `ScribeDoc`, `Lab`, `Med`, `LabRec`, `ScribeVitals`, `TranscriptLine`, `ScribeChatMessage`, `ScribeStage` |
| UI component shells | all stage files | All 3 stages render; consent, record controls, review rail, approve button |
| i18n | `en.json` / `es.json` | `aiScribe` namespace — all UI strings translated |

---

## What is MOCK (UI built, fake data behind it)

| Piece | Mock source | Replaces with |
|---|---|---|
| Live transcript | `DEMO_TRANSCRIPT` in `scribe-data.ts` | Groq Whisper ASR (Stage B) |
| Note generation | `_answer()` local fn in `AiScribeEncounter.tsx` | `generateNote()` → `api/v1/ai/api.py` (Stage A) |
| Lab recommendations | `makeDemoLabRecs()` | AI output from Claude response |
| Lifestyle programs | `makeDemoLifestyle()` | AI output from Claude response |
| Diet plan | `DEMO_DIET` | AI output from Claude response |
| AI confidence score | Hardcoded `"94%"` in `ReviewStage.tsx` | Field from Claude response |
| Saved view metadata | `DEMO_SAVED` (encounter ID, clinician, audit trail, attachments) | Real encounter data |
| Patient demographics gap-fill | `DEMO_PATIENT` | Real patient fields from `useEncounter` |
| Compliance badge in saved view | Hardcoded `"retained 30 d"` in `DEMO_SAVED.meta` | `NEXT_PUBLIC_COMPLIANCE_PROFILE` env → `ComplianceProfile.audio_retention_days` |

---

## What is PENDING (not built at all)

### Frontend — BFF layer

| File | What it does | Sprint |
|---|---|---|
| `src/lib/api/ai.ts` | Typed client: `generateNote(encounterId, text): Promise<ScribeDoc>`, `saveScribeDraft(encounterId, doc): Promise<void>` | 2 |
| `src/app/api/ai/generate/route.ts` | BFF POST: receives `{encounterId, textSummary}`, calls Frappe `generate_note`, returns `ScribeDoc` | 2 |
| `src/app/api/ai/transcribe/route.ts` | BFF POST: receives audio blob, forwards to Frappe `transcribe_audio`, returns transcript text | 3 |

### Frontend — wiring in components

| Task | File to modify | Sprint |
|---|---|---|
| Replace `_answer()` mock with real `generateNote()` call | `AiScribeEncounter.tsx` | 2 |
| Wire MediaRecorder (webm/opus) → assembled blob → POST to `/api/ai/transcribe` | `CaptureStage.tsx` + `AiScribeEncounter.tsx` | 3 |
| Feature flag gate: check `AI Settings.ai_scribe_enabled` before showing AI tab | `AiScribeEncounter.tsx` | 4 |
| Compliance badge: derive audio retention label from `NEXT_PUBLIC_COMPLIANCE_PROFILE` | `SavedStage.tsx` + `scribe-data.ts` | 4 |
| Error state: "AI unavailable" banner when BFF returns 503 | `ReviewStage.tsx` | 4 |

### Backend — Stage A (note generation)

| File | What it does | Sprint |
|---|---|---|
| `remedisys_healthcare_ai/services/ai.py` | `build_encounter_context(encounter_name) -> dict` (PHI-safe) + `log_prompt_call(...)` | 1 |
| `remedisys_healthcare_ai/integrations/anthropic.py` | `generate_soap_note(text_summary, ctx) -> dict` — Claude Sonnet 4.6, temp 0.2, max 1500 tokens, JSON output matching ScribeDoc | 1 |
| `prompts/soap-note-v1.txt` | Claude system prompt: patient age/sex/meds/allergies + doctor summary → ScribeDoc JSON | 1 |
| `remedisys_healthcare_ai/api/v1/ai/api.py` | `generate_note(encounter, text_summary)` + `save_scribe_draft(encounter, scribe_doc)` whitelisted methods | 1 |

### Backend — Stage B (audio)

| File | What it does | Sprint |
|---|---|---|
| `remedisys_healthcare_ai/integrations/groq.py` | `transcribe(audio_bytes: bytes) -> str` — Groq Whisper Large v3; bytes discarded immediately after response | 3 |
| `remedisys_healthcare_ai/api/v1/ai/api.py` | Add `transcribe_audio(audio_b64: str) -> str` whitelisted method | 3 |

---

## Sprint breakdown

### Sprint 1 — Backend Stage A (1 week, backend developer)

1. Write `services/ai.py` — `build_encounter_context()` + `log_prompt_call()`
2. Implement `integrations/anthropic.py` stub → real Claude call
3. Write `prompts/soap-note-v1.txt` — SOAP generation prompt
4. Expose `generate_note()` + `save_scribe_draft()` in `api/v1/ai/api.py`
5. Smoke test: POST to whitelisted method with real encounter ID, confirm ScribeDoc JSON back

### Sprint 2 — Frontend Stage A (1 week, frontend developer)

1. Write `src/lib/api/ai.ts`
2. Write `src/app/api/ai/generate/route.ts`
3. Wire `AiScribeEncounter.tsx`: capture stage submit → `generateNote()` → advance to review
4. Remove `DEMO_TRANSCRIPT` seed from initial state; show empty transcript until recording works
5. Manual test: type summary in capture, click "note ready", confirm real ScribeDoc in review

### Sprint 3 — Audio Stage B (1 week, frontend + backend)

1. Backend: `integrations/groq.py` + add `transcribe_audio()` to `api/v1/ai/api.py`
2. Frontend: `src/app/api/ai/transcribe/route.ts`
3. Frontend: wire `CaptureStage.tsx` start/pause/stop to real MediaRecorder
4. Frontend: on stop → assemble blob → POST `/api/ai/transcribe` → text populates summary → `generateNote()`
5. Manual test: full audio → transcript → note generation flow end-to-end

### Sprint 4 — Hardening (1 week)

1. Compliance badge: `NEXT_PUBLIC_COMPLIANCE_PROFILE=mx|in` → dynamic audio retention label
2. Feature flag gate in AiScribeEncounter
3. Error states: AI unavailable banner, retry button
4. PHI audit: confirm no patient name / DOB / MRN in any console.log, Sentry event, Next.js request log
5. Regression: existing encounter save flow unaffected when AI is unavailable

---

## Key constraints (unchanged)

- **Audio never stored** — `audio_retention_days=0` both markets. Process in-memory, discard.
- **Physician must approve** — `approveAndSave()` is gated on explicit physician click. AI never saves autonomously.
- **No streaming in Stage A** — synchronous JSON response (~2–3 s). SSE deferred.
- **PHI never in logs** — `build_encounter_context()` passes IDs and field names only; never content.
- **Model locked** — `claude-sonnet-4-6`. No model selection in UI.
- **ASR model locked** — Groq Whisper Large v3. Not Deepgram (deferred per CLAUDE.md; Groq is the current choice).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-01 | Sarvesh | Initial version (header backfilled from git history) |
