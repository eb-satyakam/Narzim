# 2026-06-18 — External Referral Flow (No In-House Pharmacy/Lab/Procedure)

**Doc status:** record · **Created:** 2026-06-18 by Sarvesh-SocialAngel · **Updated:** 2026-06-18 by Sarvesh-SocialAngel · **Version:** 1.0

## Context
Clinic has no internal pharmacy, no in-house lab, and no procedure room.
Doctor fills an encounter, selects a treatment plan template (e.g., cardiology) that
includes drugs + lab tests + procedures. On submit, all fulfillment must go outbound
via referral documents + tracking stubs.

## Task
Design the user story, end-to-end flow, and implementation spec for the
"referred out" encounter submission model in `remedisys_healthcare_ai`.

## Output
- `docs/FLOWS_REFERRAL_OUT.md` — user story + flow + status transitions + implementation notes

## Decisions made
- Stub model: create `Medication Order`, `Lab Test`, `Clinical Procedure` records with
  "Referred" status rather than print-and-forget, so result tracking (incl. ADR-013
  lab PDF ingestion) has an anchor document.
- All hooks and print formats live in `remedisys_healthcare_ai` only.
- Internal fulfillment queues (Stock Entry, Sample Collection) are never triggered.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
