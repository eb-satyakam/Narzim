# Forgot-password (self-service password reset) — 2026-06-24

**Doc status:** record · **Created:** 2026-06-24 by Sarvesh-SocialAngel · **Updated:** 2026-06-24 by Sarvesh-SocialAngel · **Version:** 1.0

## Context
Phase 4 (Operations) adjacent — auth/account recovery. Builds directly on the
user-invite welcome-email flow shipped earlier today (`2026-06-24-user-invite-portal-welcome-email.md`).
The invite flow already provides the key mechanism (`sha256_hash` of `random_string(32)`,
`last_reset_password_key_generated_on`), the `/set-password` landing, the
`/api/auth/set-password` BFF route, and the branded-email pattern.

## Goal
Unauthenticated user clicks "Forgot password?" on login → enters email → receives
a branded reset email → clicks link → lands on a dedicated `/reset-password` page →
sets a new password → logs in.

## Decisions (confirmed with user)
- **Landing page:** NEW dedicated `/reset-password` page (not reusing `/set-password`).
- **Eligibility:** enabled `Website User` carrying at least one `EB_` role. Others
  get the generic response but no email.
- **Link expiry:** 1 hour. Enforced via Frappe's global
  `System Settings.reset_password_link_expiry_duration = 3600` (was 1200 = 20 min).
  This expiry is GLOBAL — it also governs invite welcome links. Accepted: invite
  links now last 1h too, and forgot-password is the recovery path for expired invites.
- **Anti-enumeration:** `request_password_reset` always returns the same generic
  success regardless of whether the email exists / is eligible.
- **Rate limiting:** `@frappe.rate_limit` 5/hour keyed on the email argument.

## Files
### Backend (`remedisys_healthcare_ai`)
- `api/v1/auth/api.py` — add `request_password_reset(email)` (allow_guest, rate-limited)
  + `_send_password_reset()` helper (link → `<portal>/reset-password?key=<plaintext>`).
- `templates/emails/password_reset.html` — NEW branded template.

### Frontend (`Healthcare_next_app`)
- `src/app/(auth)/forgot-password/page.tsx` — NEW email-request page.
- `src/app/(auth)/reset-password/page.tsx` — NEW reset landing (mirrors set-password).
- `src/app/api/auth/forgot-password/route.ts` — NEW public BFF route → backend method.
- Reset page reuses existing `/api/auth/set-password` route (operation is identical).
- `src/app/(auth)/login/page.tsx` — add "Forgot password?" link.
- `src/proxy.ts` — add `/forgot-password`, `/reset-password`, `/api/auth/forgot-password`
  to `PUBLIC_PATHS`.
- `messages/en.json` + `messages/es.json` — `forgotPassword` + `resetPassword` namespaces.

### Config
- `bench --site marley2.local set-config -g`... actually System Settings field:
  set `reset_password_link_expiry_duration = 3600`.

## Risks
- Public `allow_guest` endpoint — mitigated by anti-enumeration + rate limiting.
- Global expiry shared with invite links — documented and accepted.
- No PHI in logs — log only email + outcome bucket, never the key.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-24 | Sarvesh | Initial version (header backfilled from git history) |
