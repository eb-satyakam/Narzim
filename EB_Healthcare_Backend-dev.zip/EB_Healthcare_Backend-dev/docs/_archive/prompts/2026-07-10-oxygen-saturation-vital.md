# Oxygen Saturation (SpO2) vital — fixture field + wire into every vitals screen

**Doc status:** record · **Created:** 2026-07-10 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-10
**Phase:** Phase 2 (Clinical Details) — extends `vital_signs` API + Next.js patient portal
**Requested by:** Sarvesh Shahi

## Request

User (via Patient Chart 360 → Doctor Overview screenshot): the "Oxygen Sat."
vitals card always shows "Not recorded" / "—". Add a custom field for oxygen
saturation on the Vital Signs doctype, ship it as a fixture, and wire it into
every screen that shows or captures vitals.

## Investigation

The "Oxygen Sat." card in `overview-tab.tsx` was dead UI — hardcoded
`value: "—"`, `status: "Not recorded"` literals, never reading real data.
Several other screens (`overview-nurse.tsx`, `visits-tab.tsx`,
`dashboard-types.ts`) referenced a `spo2` field that was also never populated
by any backend response. No scalar oxygen field existed on the `Vital Signs`
doctype; the app only had a generic `custom_readings` table fixture (Specialty
Readings) plus `Vital Signs Template` seeding — never consumed by any frontend
screen.

Per direction, added a **dedicated custom field** (not routed through
`custom_readings`), following the fixture-based extension pattern this app
already uses for custom doctype fields.

## Change

**Backend (`remedisys_healthcare_ai`, all changes inside the custom app):**
- `remedisys_healthcare_ai/fixtures/custom_field.json` — new Custom Field
  `Vital Signs.custom_oxygen_saturation` (Int, 0–100, `insert_after`
  `respiratory_rate`).
- `api/v1/vital_signs/api.py` — `_LIST_FIELDS`, `_serialize`,
  `create_vital_signs`, `update_vital_signs` now read/write/validate the new
  field (`_clean_oxygen_saturation`, 0–100 range check).
- `api/v1/patients/api.py` — `_chart_last_vitals()` raw SQL query didn't
  select the field at all (separate code path from `vital_signs/api.py`,
  feeds `Patient.vitals` via `get_patient_chart_overview`); added
  `custom_oxygen_saturation` to the SELECT and exposed it as `spo2` to match
  the existing frontend key convention. This alone wired Nurse Overview and
  the Visits tab's "Today's Vitals" tiles with zero frontend changes, since
  both already read `patient.vitals.spo2`.

**Frontend (`Healthcare_next_app`):**
- `types/vital-signs.ts` — `custom_oxygen_saturation` added to `VitalSigns`,
  `CreateVitalSignsPayload`, `UpdateVitalSignsPayload`.
- `overview-tab.tsx` (Doctor Overview) — Oxygen Sat. card now derives from
  real `latest.custom_oxygen_saturation`; kept its label hardcoded to match
  the five sibling cards in the same array (pre-existing, out-of-scope i18n
  gap for the whole file — flagged, not fixed here).
- `vitals-tab.tsx` — new SpO2 column in the history table; new field in both
  `RecordVitalsDialog` (create) and `VitalsInlineCard` (nurse draft editor,
  update); added `chart.vitals.cols/record/pending.spo2` i18n keys.
- `encounter-screen.tsx` — SpO2 added to the Objective-tab vitals capture
  grid (`VITAL_KEYS`, `EMPTY_VITALS`, prefill from draft VS, both save paths:
  `flushTypedVitals` and `onSaveVitals`), with a <95% warn threshold matching
  the existing pattern for other vitals.
- `encounter-report.tsx` / `encounter-types.ts` / `visits-tab.tsx` — `spo2`
  added to `EncVitals` and the printed report's `VITALS` list; added
  `encounter.vitals.spo2` i18n key.
- Dashboard: `dashboard-types.ts` already declared `CapturedVitals.spo2`, but
  it has zero consumers anywhere in the codebase — no widget renders any
  vitals field today. Left as-is; did not invent a new dashboard widget.

All new i18n keys added to both `messages/en.json` and `messages/es.json`.

## Files touched

- `remedisys_healthcare_ai/fixtures/custom_field.json`
- `remedisys_healthcare_ai/api/v1/vital_signs/api.py`
- `remedisys_healthcare_ai/api/v1/patients/api.py`
- `Healthcare_next_app/src/types/vital-signs.ts`
- `Healthcare_next_app/src/components/narzim/patient-chart/overview-tab.tsx`
- `Healthcare_next_app/src/components/narzim/patient-chart/vitals-tab.tsx`
- `Healthcare_next_app/src/components/narzim/encounter/encounter-screen.tsx`
- `Healthcare_next_app/src/components/narzim/encounter/encounter-report.tsx`
- `Healthcare_next_app/src/components/narzim/encounter/encounter-types.ts`
- `Healthcare_next_app/src/components/narzim/patient-chart/visits-tab.tsx`
- `Healthcare_next_app/messages/en.json`
- `Healthcare_next_app/messages/es.json`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
