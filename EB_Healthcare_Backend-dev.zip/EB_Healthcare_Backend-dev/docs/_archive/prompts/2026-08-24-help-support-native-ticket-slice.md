# Prompt archive — 2026-08-24 — Help & Support, thin vertical slice to a native HD Ticket

**Doc status:** record · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The ask

> "now move on task.. can we make UI first or not? add option support"

Read as: start implementing the Help & Support flow planned in
`docs/planning/2026-08-24-helpdesk-integration-plan.md`, and answer whether the UI can be built
before the backend. Answered: yes, low-risk here because the POC already pinned the contract to
three inputs — but a mocked Submit reads as "support works" when it does not.

**Chosen (user, via options):** thin vertical slice — subject + description + screenshot, wired
end to end to a real `HD Ticket`. Voice note, EHR context block and a my-tickets list are out.
**Placement (user):** inside the existing help drawer, not a new sidebar item.

## What already existed (found, not built)

`src/components/help/help-drawer.tsx` — a right-side 360px Sheet, mounted by `HelpProvider` in
`(clinic)/layout.tsx`, reachable from `app-sidebar.tsx:82-84`, i18n'd under the `help` namespace,
and already calling `usePathname()`. The entry point did not need creating, and the route context
the plan wants in §8 is available there for free.

## Findings that shaped the code

1. **Duplicate uploads share one disk path.** Two byte-identical private Files insert without error
   but return the same `file_url` (`/private/files/dup-probe-1.bin` for both) — verified, then rolled
   back. Helpdesk's `HD Ticket.on_trash` deletes its files, so deleting one ticket would break
   another ticket's attachment. The slice therefore salts each upload per request so every support
   attachment gets its own physical file.
2. **`handle_api_errors` rolls back on every error path**, so a failed ticket creation leaves no File
   rows in the database — but the bytes are already on disk. Orphaned-blob cleanup is noted, not
   built.
3. **Frappe parses every PDF** (`file.py:474` → `pdf_contains_js`) and refuses a malformed one; the
   guard returns a readable message rather than letting a 500 through.

## Deliberate omissions

- No voice recording, no context block, no my-tickets list — Phase 2/3 in the plan.
- No custom DocType, no Helpdesk modification, no synchronisation. `HD Ticket` stays the source of
  truth; Remedisys stores no ticket record.
- The four decisions in the plan §12 remain open; nothing here presumes an answer.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Archived the Help & Support slice prompt, the chosen build order, and the duplicate-file finding |
