# AI Copilot Sprint 4 — PHI audit

**Doc status:** record · **Created:** 2026-07-10 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Branch:** `feature/ai_v1` (frontend repo only — no backend changes)
**Requested by:** Sarvesh — next Sprint 4 item after consent recording + error states

## Scope

Rule 10: "No PHI in Logs, Ever" — checked every `console.log`/`frappe.logger`/Sentry call
reachable from the AI Copilot code paths (backend `services/ai.py`, `integrations/{deepgram,
anthropic,groq}.py`, `api/v1/ai/api.py`, `api/ai/{sessions,segments,realtime,auth}.py`;
frontend `components/narzim/encounter/copilot/*`, `app/api/ai/*`, `encounter-screen.tsx`).

## Findings

**Backend — clean, no changes needed.** Every log call checked logs only IDs, status codes,
sequence numbers, counts, or cost estimates:
- `services/ai.py::log_prompt_call` — explicitly logs the prompt *filename* (e.g.
  `suggest-v1.txt`), never prompt/transcript content. Docstring already states "No PHI is
  written — only IDs, counts, and cost estimates," and the code matches the claim.
- `integrations/deepgram.py` (2 calls) — `deepgram_token_minted session=... ttl=...` — IDs only.
- `api/ai/sessions.py` (2 calls) — `deepgram_mint_failed session=... code=...` — ID + stable
  error code only.
- `api/ai/segments.py` (3 calls) — `segment_dropped_sealed session=... sequence_number=...
  status=...` / `segment_duplicate_retry session=... sequence_number=...` — IDs only.

**No Sentry integration exists in either repo** (checked, zero matches for `sentry`/`Sentry.`) —
not a gap, just nothing to configure yet. Noting it so it's not silently forgotten if/when
Sentry is added later — the same PHI-scrubbing discipline needs to apply then.

**Frontend — real gap found and fixed.** `src/lib/api/frappe-debug.ts` is a shared, opt-in
debug logger (`FRAPPE_DEBUG=true` in `.env.local`, OFF by default) used by every BFF route via
`frappeFetch`/`frappeFetchList`/`frappeFetchSet` (confirmed: both call `logFrappeCall({...,
reqBody: body})` unconditionally). Its `redact()` function only stripped
`pwd/password/new_password/old_password/token/refresh_token` — it had **no PHI awareness at
all**. Enumerated every AI route's exact request body:

| Route | Body fields | PHI? |
|---|---|---|
| `/api/ai/chat` | `encounter, prompt, history` | `prompt`/`history` = physician Q&A, clinical content |
| `/api/ai/suggest` | `encounter, transcript` | `transcript` = full diarized encounter conversation |
| `/api/ai/transcribe` | `encounter, audio_b64` | raw audio, PHI-adjacent even as base64 |
| `/api/ai/session` | `encounter, consent_obtained` | IDs/booleans only — safe |
| `/api/ai/session/stop` | `session, close_reason` | IDs only — safe |
| `/api/ai/flags` | (empty) | safe |

If a developer ever enabled `FRAPPE_DEBUG=true` locally, the transcript/prompt/history/audio
would print to the terminal in full on every AI call. Not gated to production-only risk — Rule
10 draws no dev/prod distinction.

## Fix

`src/lib/api/frappe-debug.ts`:
- Added `PHI_FIELDS` set (`transcript`, `prompt`, `history`, `audio_b64`, `audioB64`) — these
  are redacted outright to `<redacted, N chars>` rather than truncated (even a prefix of a
  transcript is PHI).
- Added a length-based fallback: any string value over 80 chars gets the same redaction
  regardless of field name. This module is shared by every BFF route in the app, not just AI —
  a named allowlist would need updating every time a new clinical free-text field is added
  elsewhere (patient notes, encounter HPI/plan, etc.); the length heuristic closes that same
  class of gap without needing to enumerate every field across the whole app in this pass.
- The error-body log line (`errBody`) previously bypassed `redact()` entirely — a Frappe
  validation error can echo submitted values back in its message. Now redacted the same way as
  the request body.

## Verification

- `npx tsc --noEmit` — clean.
- `npx eslint src/lib/api/frappe-debug.ts` — clean.
- Not runtime-tested (would need `FRAPPE_DEBUG=true` + a real AI call + inspecting the terminal
  output to confirm the redacted shape looks right) — logic is straightforward enough that this
  wasn't done, but flagging the gap in verification honestly.

## Out of scope, worth knowing

The length-based fallback in this fix incidentally protects every other route's clinical
free-text fields too (patient medical history, encounter notes, etc.) if `FRAPPE_DEBUG` is ever
turned on — but a full non-AI PHI audit of every BFF route was not performed here; this fix is a
safety net, not a substitute for one.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
