# User Invite — Portal Welcome Email

**Doc status:** record · **Created:** 2026-06-24 by Sarvesh-SocialAngel · **Updated:** 2026-06-24 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-24  
**Scope:** Backend (`remedisys_healthcare_ai`) + Next.js frontend (`Healthcare_next_app`)

## Goal
When admin adds a user from the Next.js settings → Users page:
1. Frappe creates the user (Website User) with no default welcome email.
2. Backend generates a reset key and sends a **custom branded welcome email**.
3. Email button links to `<PORTAL_APP_URL>/set-password?key=<reset_key>` (env-variable based).
4. User lands on `/set-password` in Next.js, sets their password, logs in.

## Changes

### Backend (`remedisys_healthcare_ai`)
- `api/v1/admin/staff.py` — modify `invite_staff()`: add `company` param, suppress Frappe default email, generate reset key, call `_send_portal_welcome()`.
- `templates/emails/portal_welcome.html` — new branded HTML email template (dynamic company name via Jinja).
- Config: `bench --site marley.local set-config portal_app_url "http://localhost:3000"` (dev); update to real domain in prod.

### Frontend (`Healthcare_next_app`)
- `src/proxy.ts` — add `/set-password` + `/api/auth/set-password` to `PUBLIC_PATHS`.
- `src/app/(auth)/set-password/page.tsx` — new page: reads `?key=`, shows password form, calls `/api/auth/set-password`.
- `src/app/api/auth/set-password/route.ts` — unauthenticated proxy to Frappe `update_password`.
- `src/app/api/admin/users/route.ts` — pass `company` through in POST.
- `src/hooks/use-admin-users.ts` — add `company?: string` to `CreateUserInput`.
- `src/components/settings/users-section.tsx` — add company dropdown to invite form.
- `messages/en.json` + `messages/es.json` — add `company`/`companyPlaceholder` to `adminUsers`.

## Key decisions
- Reset key generated via `frappe.utils.random_string(32)` and saved with `frappe.db.set_value`.
- `portal_app_url` from `frappe.conf` — no code change needed when switching envs.
- Company name fetched from `Company` doctype by `name` (the Frappe docname).
- Email sending wrapped in try/except — fails silently with a logged error rather than blocking user creation.
- No Frappe core, ERPNext, Healthcare, or other vendored app edited.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-24 | Sarvesh | Initial version (header backfilled from git history) |
