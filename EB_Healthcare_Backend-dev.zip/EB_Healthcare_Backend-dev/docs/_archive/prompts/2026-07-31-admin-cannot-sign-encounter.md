# 2026-07-31 — Remove the admin override on encounter signing

**Doc status:** record · **Created:** 2026-07-31 by Sarvesh-SocialAngel · **Updated:** 2026-07-31 by Sarvesh-SocialAngel · **Version:** 1.0

## Prompt (verbatim intent)

> "i am login as admin why show save and sign button on this encounter — i can only
> save not sign (a different practitioner can not sign another practitioner's
> encounter)"
>
> Follow-up: "fix it admin also can not sign", "i am using admin@chavitos.health"

## Reported symptom

Logged in as `admin@chavitos.health` (`EB_Healthcare Admin` + `EB_Practitioner` +
`EB_Nurse` + `EB_Front Desk`), opening `HLC-ENC-2026-00126` whose assigned
practitioner is `sarvesh shahi` (`HLC-PRAC-2026-00001`). The footer offered
**Cancel + Sign & close encounter** instead of the save-only affordance a
non-assigned user is supposed to get.

## Root cause (two layers, both deliberate at the time)

1. Frontend — `src/app/(clinic)/encounters/[id]/page.tsx:35`
   `const canSign = isAdmin || isAssignedPractitioner;` — `isAdmin`
   short-circuits, so the encounter's practitioner is never compared. `canSign`
   gates the Sign **and** Cancel pair together (`encounter-screen.tsx:1768`).

2. Backend — `api/v1/encounters/api.py:1526` `_require_assigned_practitioner_or_admin`
   returns early for `EB_Healthcare Admin`, and `complete_encounter` uses it.
   So even with the button hidden the endpoint stayed open.

Why it actually submits for this user: `eb_docperm_spec.json` gives
`EB_Healthcare Admin` **`submit: 0`** on Patient Encounter, so a pure admin
would already 403 at `require_permission(..., "submit")`. `admin@chavitos.health`
also holds `EB_Practitioner` (submit: 1), which satisfies the docperm; the role
bypass then skipped the ownership check. The admin role bypass therefore
contradicted the docperm spec it sits next to.

## Why it must change

The rendered signature block carries the assigned practitioner's name, specialty
and **Céd. Prof. (MEX-CED-394018)**. An admin pressing Sign attests the note
under another clinician's professional licence — wrong under NOM-024-SSA3-2010.
Nothing about "administrator" implies a licence to attest a clinical note.

## Decision

ADR-038 — signing **and cancelling** are assigned-practitioner-only, no
clinic-admin override. Supersedes the 2026-07-02 decision for both actions. Only
the WhatsApp summary resend keeps the admin override (re-delivers an
already-signed note; alters no record).

Mid-task correction: the first cut kept cancel for admins ("administrative, no
licence attached"). The user rejected that — "cancel bhi nahi kar sakta" — so
both actions now share one rule. One rule is also easier to explain: the
clinician who saw the patient is the only one who finalises or voids their note.
Everyone else keeps `save_draft`, so nothing is stranded — the requested UI is
exactly the nurse's: a single **Save draft** button.

## Files changed

Backend (`apps/remedisys_healthcare_ai`)
- `remedisys_healthcare_ai/api/v1/encounters/api.py`
  - new `_require_assigned_practitioner(doc)` — linked practitioner must equal
    `doc.practitioner`; only the framework superuser `Administrator` is exempt.
  - `complete_encounter` + `cancel_encounter` switched to it; docstrings updated.
  - `_require_assigned_practitioner_or_admin` kept unchanged, now used only by
    `notifications.send_encounter_summary_whatsapp`; docstring narrowed.
- `remedisys_healthcare_ai/tests/encounters/test_encounters.py`
  - new `TestAdminCannotSignOrCancel` — admin 403 on both `complete_encounter`
    and `cancel_encounter` (asserted on the gate's own message so a DocPerm
    rejection can't pass for it), 200 on `save_draft`; assigned practitioner
    still signs and cancels.
  - stale `TestNurseDraftWrite` docstring corrected.
- `docs/adr/adr-038-encounter-signing-assigned-practitioner-only.md`

Frontend (`Healthcare_next_app`)
- `src/app/(clinic)/encounters/[id]/page.tsx` — `canSign` = assigned
  practitioner only (the `isAdmin` disjunct is gone; no new prop).
- `src/components/narzim/encounter/encounter-screen.tsx` — comments/prop doc
  updated; the save-only footer branch (already built for nurses) now also
  serves admins and non-assigned practitioners unchanged.
- stale comments in `mission-control-client.tsx` and `permissions-store.ts`.

## Not changed / notes

- `mission-control-client.tsx:2087` renders `<EncounterScreen>` with no
  `canSign` (default `true`), but `encounterFor` is never set to a non-null
  value — dead path. `queue.actOpenEncounter` routes to `/encounters/[id]`.
- Framework `Administrator` keeps the API escape: Frappe's superuser bypasses
  permissions everywhere and can submit the doctype straight from Desk, so a
  check there would be theatre. It is not an assignable clinic account, and the
  UI gives it no Sign button either (it has no linked practitioner).
- Pre-existing typo in `complete_encounter`'s docstring ("leave ti" stray text,
  ~line 1617) left alone — out of scope.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
