# Prompt archive — 2026-08-24 — release notes, `pre` → `main`

**Doc status:** record · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The ask

> "now switch in dev" → "git pull origin dev" → "backend also git checkout dev"
> "make a branch for help deck feature"
> "cmooit it"
> "make a proper release pre to main .. make open pr for main pre to main"
> "make a proper release not what feature we gave in this release =and what change we
> pushed what gap and error we solved .. pdf in a professional way"

Read as: produce a professional, distributable release document for the 2026-08-24
`pre` → `main` promotion, covering (a) features shipped, (b) changes pushed,
(c) gaps and defects closed. Output as PDF.

## What was done

1. Both repos switched to `dev` and fast-forwarded to `origin/dev`.
   - backend `b314e83`, frontend `8201342`.
2. Branch `feat/helpdesk-integration` cut off `dev` in both repos.
   - Backend commit `df5eb53` — the 2026-08-21 Frappe Helpdesk research plan plus
     regenerated doc indexes. All five documentation gates pass. Not pushed.
3. Release PRs opened, `pre` → `main`, both `MERGEABLE`:
   - backend `EB_Healthcare_Backend#346` — 125 commits, 388 files
   - frontend `EB_Healthcare_EHR#417` — 120 commits, 239 files
4. Release notes PDF generated from the actual commit range
   (`origin/main..origin/pre`), not from memory.

## Sources of truth used

- `git rev-list --left-right --count` for merge topology (no commit on `main` is
  absent from `pre`; no commit on `dev` is absent from `pre`).
- `git log origin/main..origin/pre --no-merges` for the feature and defect lists.
- `patches.txt` diff for the data migrations that run on deploy.

## Deliberate omissions

- Nothing was merged; `pre` and `main` were not written to directly.
- No test suite, build, or migration rehearsal was run — both PRs and the PDF say
  so explicitly rather than implying a green light.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Archived the release-notes prompt; provenance header brought into CLAUDE.md §9 form |
