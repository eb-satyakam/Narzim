# Patients list — server-side filters (mirrors the Appointments fix)

**Doc status:** record · **Created:** 2026-07-09 by Sarvesh-SocialAngel · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Requested by:** Sarvesh — "patient table also same as appointment... fix it" / "continue patient table fix like appointment"

## Goal
Same problem as Appointments had: most Patients-list filters only narrowed the
currently-loaded page instead of querying the backend. Push every filter +
sort server-side, and fix pagination to actually accumulate across pages
instead of a flat 100-row fetch with client-side slicing.

## Findings before implementing
- Backend `list_patients` already supported `search`, `status`, `gender`,
  `filter_today`, `filter_new`, `filter_balance_due` server-side — the
  frontend just wasn't sending most of them (only `search`/`filter_balance_due`
  were wired). Much less backend work needed than Appointments.
- `filter_favorites` had no backend param, but Frappe's `_liked_by` field
  (already used by `toggle_favorite_patient`/`list_favorite_patients`) made it
  a cheap addition — same `like` filter, added as an mrn_include intersection
  set (mirrors the existing `filter_balance_due` pattern).
- `list_patients` hardcoded `order_by="modified desc"` — no sort param existed
  at all, so column-header sort clicks only reordered the loaded page. Added
  `sort_by`/`sort_dir`, mapping frontend sortCol → DB column
  (name→patient_name, status→status, mrn→name, modified→modified).
- **Two dead, pre-existing filters, not introduced by this change:**
  - "Deceased" status — the `Patient.status` field only has Active/Disabled
    options in ERPNext Healthcare (confirmed against the doctype JSON); no
    custom field extends it. A patient can never actually carry that status.
    Sending it to the backend would throw `ValidationError`. Guarded in
    `statusApiParam()` — the UI option stays, still does nothing, exactly as
    before.
  - "Other" gender — backend `_SEX_MAP` only reverse-maps Male→M/Female→F;
    `ApiPatient.sex` is typed `"M" | "F" | null`. "O" can never appear in the
    data. Guarded in `genderApiParam()`, same no-op as before.
- `page_size` is hard-capped at 100 server-side (`min(100, ...)` in
  `list_patients`). The PAGE_SIZES selector (20/100/500/2500) now fetches in
  capped 100-row batches and accumulates via repeated Load More calls
  (mirrors Appointments' `fetchMoreAll`) instead of silently truncating.

## Scope
- Backend: `remedisys_healthcare_ai/api/v1/patients/api.py` — `list_patients`
  + `get_patients` alias gain `filter_favorites`, `sort_by`, `sort_dir`.
- BFF: `Healthcare_next_app/src/app/api/patients/route.ts` — forward `status`
  (backend already supported it, route didn't), `filter_favorites`, `sort_by`,
  `sort_dir`.
- Types: `PatientListParams` gains `status`, `filter_favorites`, `sort_by`,
  `sort_dir`.
- Frontend: `patients-client.tsx` — real `patientList` accumulator +
  `fetchMorePatients()` (mirrors `apptList`/`fetchMoreAll`), all filters +
  sort moved into `apiParams`, client-side `.filter()`/`.sort()` removed
  except the two guarded no-ops above.

## Known limitations
- Cannot run Frappe/bench tests in this environment — backend change needs a
  bench run before merge, same caveat as the Appointments backend PR.
- Total count query (`frappe.get_list(..., pluck="name", limit_page_length=0)`
  for or_filters) was already there pre-existing; unchanged.

## Round 2 — closing out docs/audit/frontdesk/screens/02-patients-list.md
User redirected to this pre-existing audit doc mid-session; it independently
confirmed P1 (pagination cap) and P4 (client-side filters) were exactly what
Round 1 above fixed. Additionally implemented the doc's "Tier 1 — free"
recommendations (data already in the payload or a cheap batch query):

- **P2 (Age + Guardian)** — both already shipped in the `list_patients`
  payload (`age`, `guardian`), just never rendered. FE-only: Age shown inline
  under the patient name; Guardian gets its own column (desktop) / grid cell
  (mobile).
- **P3 (Balance amount)** — did NOT exist in the payload (doc flagged this
  explicitly — "may need it added"). Added `_batch_outstanding_balance()`
  (sum of `outstanding_amount` across every submitted, non-return Sales
  Invoice per patient — same join shape as the existing `filter_balance_due`
  special filter, aggregated instead of existence-checked) to
  `remedisys_healthcare_ai/api/v1/patients/api.py`, exposed as `balanceDue`
  on each row. Rendered via `useCurrency()`/`formatMoney` (same pattern as
  `billing-tab.tsx`).
- **Next appointment** — already shipped (`nextAppointment`), merged into a
  combined "Last / Next visit" cell instead of a fully separate column, to
  avoid an overcrowded table (doc didn't mandate separate columns, just that
  the data be surfaced).
- **P6 (fake message count)** — removed the icon/column entirely rather than
  leave a misleading hardcoded "0". Building a real per-patient unread count
  is a distinct, larger feature (needs an actual messaging backend) —
  out of scope here.
- **P7** — removed the unused `IS_DEV` const.
- **P5 (dead selection checkboxes)** — left as-is. The doc's own open
  question #3 asks whether bulk actions are even wanted; not touched pending
  that product decision.

`_batch_patient_billing()` (pre-existing, in the same file) was found to be
dead code — defined, zero call sites. Left alone (out of scope); noted here
in case it's confusing during review.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
