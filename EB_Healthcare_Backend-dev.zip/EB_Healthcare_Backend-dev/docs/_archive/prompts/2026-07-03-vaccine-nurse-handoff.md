# Vaccine → Nurse Administration Handoff

**Doc status:** record · **Created:** 2026-07-03 by Sarvesh-SocialAngel · **Updated:** 2026-07-03 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-03
**Author:** gaurav (via Claude Code)
**Status:** In progress — Phase 1
**Related:** `docs/flows/IMMUNIZATION_PROCESS.md` (Flow G — "planned, not built"), `docs/adr/adr-019-encounter-native-binding.md`

## Problem

Today a doctor tags vaccines in the encounter SOAP note; at Sign & close the system
auto-creates the `Immunization` (administration) record — i.e. it assumes the shot was
**given in the room**. There is no way for a doctor to **order** a vaccine and hand it off
to a **nurse** to administer later. The "Add immunization" dialog already gates on
allergies / febrile temperature and requires an *assigned* vaccine ("No assigned vaccines
are due. Use 'Assign vaccine' first."), but nothing routes that assignment to a specific
nurse or gives the nurse a worklist.

## Goal

Model the real clinical flow: **doctor orders → (optionally) assigns a nurse → nurse
administers & records**, while preserving the existing "give in-room now" path.

## Decisions (confirmed with user)

1. **Nurse receives work via a worklist/queue** (reuse the existing "My Work" feed, which
   already scopes `Nursing Task` by assignee `user`). Not just a passive field.
2. **Doctor assigns inside the encounter note** (the existing Vaccinations section), not a
   separate standalone dialog.
3. **Per-vaccine choice** at Sign & close:
   - **Give now** → create `Immunization` immediately (doctor administered in-room). Current behaviour.
   - **Assign to nurse** → create `Patient Vaccine` (order) + `Nursing Task` for the chosen
     nurse; **no `Immunization` yet**. Nurse records it later.
4. **Add `encounter` link on `Immunization`** (Link → Patient Encounter), mirroring
   `Patient Vaccine.encounter`, for traceability now that the dose may be recorded outside
   the ordering visit.
5. **Deferred** path (nurse marks febrile/other → task stays open / re-due): fast-follow
   after the core loop.

## Existing building blocks (no rebuild needed)

- `Patient Vaccine` — the assignment/order record (`patient`, `immunization_template`,
  `status`, `assigned_by`→Practitioner, `appointment`, `encounter`).
- `Immunization` — the administration record (`administered_by`, `administration_site`,
  `lot_number`, `consent_obtained`, `appointment`; **no encounter link yet**). App-owned doctype.
- `Nursing Task` (Healthcare core) — `patient`, `activity`, `user` (single assignee),
  scheduling, status; full CRUD in `api/v1/nursing/api.py`; already aggregated by
  `get_my_tasks()` in `api/v1/tasks/api.py`. **Not linked to vaccines today.**
- Roles `EB_Nurse` / `EB_Practitioner` already exist and are distinct; nurse can
  create `Immunization`/`Patient Vaccine`, and cannot sign encounters.
- Encounter Vaccinations chips resolve free-text → template at Sign & close via
  `_create_encounter_immunizations()` (`api/v1/encounters/api.py`).

## Change list — Phase 1

0. **Schema:** add `encounter` (Link → Patient Encounter) to the `Immunization` doctype
   JSON, after `appointment`. Migrate.
1. **Link:** add a link field on `Nursing Task` → `Patient Vaccine` (Custom Field via
   fixture — `Nursing Task` is Healthcare core, so no core JSON edit).
2. **Encounter Sign & close** (`_create_encounter_immunizations`): branch per chip on
   give-now vs assign-nurse. Give-now → `Immunization` (stamp encounter). Assign-nurse →
   `Patient Vaccine` + `Nursing Task` (assigned to nurse, linked to Patient Vaccine).
3. **Encounter UI** (`encounter-screen.tsx` Vaccinations section): per-chip give-now /
   assign-nurse toggle + nurse picker (users holding `EB_Nurse`). Extend the payload.
4. **Nurse worklist:** surface vaccine `Nursing Task`s in `get_my_tasks`; "open task →
   Add immunization dialog pre-filled with the assigned vaccine."
5. **On record:** when the nurse saves the `Immunization`, copy `encounter` from the linked
   `Patient Vaccine`, reconcile the assignment, and **close the linked Nursing Task**.
6. **Docs:** update `IMMUNIZATION_PROCESS.md` Flow G (planned → built) and add an ADR for
   the give-now / assign-nurse decision.

## Fast-follow (Phase 2)

- Nurse **Deferred** status with reason + optional re-due date.
- Standalone walk-in / catch-up assignment (outside an encounter) — currently out of scope.
- All strings i18n (en / es-MX) — no hardcoded copy in the Next.js frontend.

## Constraints (project rules)

- All changes stay in `remedisys_healthcare_ai` (backend) and `Healthcare_next_app`
  (frontend); no edits to Frappe/ERPNext/Healthcare core — use Custom Fields / hooks / API.
- No git commit or push without explicit in-turn permission.
- Jurisdiction: Mexico (es-MX); no hardcoded UI strings in the Next.js app.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-03 | Sarvesh | Initial version (header backfilled from git history) |
