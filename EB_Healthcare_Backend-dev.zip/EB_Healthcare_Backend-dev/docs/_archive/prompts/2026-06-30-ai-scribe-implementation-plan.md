# AI Scribe — Full Implementation Plan (A-to-Z)

**Doc status:** record · **Created:** 2026-07-01 by Sarvesh-SocialAngel · **Updated:** 2026-07-01 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-30
**Session task:** Plan and implement the AI encounter scribe feature end-to-end.
**Phase gate note:** Phase 5 work, pulled forward by product owner.

## What is already built

### Frontend shell (Healthcare_next_app)
- `src/components/narzim/encounter/ai-scribe/AiScribeEncounter.tsx` — 2-stage modal (capture → review), seeds from real encounter via `useEncounter()` and `encounterToScribeDoc()`, seeds vitals from `usePatientVitals()`, `approveAndSave()` calls `encountersApi.saveDraft()` directly
- `src/components/narzim/encounter/ai-scribe/scribe-types.ts` — full TypeScript contracts: `ScribeDoc`, `Lab`, `Med`, `LabRec`, `ScribeVitals`, `TranscriptLine`, `ScribeStage`
- `src/app/(clinic)/encounters/[id]/page.tsx` — mounts AI scribe with floating "AI Encounter" tab button on right edge

### Backend doctypes (installed, remedisys_healthcare_ai)
- `AI Encounter Session` — state machine + consent gate
- `AI Transcript Segment` — append-only transcript segments
- `AI SOAP Draft` — SOAP draft versioning (accepted_by_physician flag)
- `AI Prompt Log` — every LLM call: prompt_version, model, tokens, cost, latency
- `AI Settings` (Single) — feature flags + model config

### Backend stub (api/ai/ — locked until now)
- `api/ai/sessions.py` — create/start/stop/refresh (stub)
- `api/ai/segments.py` — append_segment (stub)
- `api/ai/realtime.py` — publish_to_encounter (stub)
- `api/ai/auth.py` — channel auth + Groq token minting (stub)

## What to build — two stages

### Stage A: Text-first note generation (no audio, minimum viable scribe)

1. Implement `api/v1/ai/api.py` — two new whitelisted methods:
   - `generate_note(encounter, text_summary)` → returns `ScribeDoc` JSON
   - `save_scribe_draft(encounter, scribe_doc)` → saves to AI SOAP Draft + AI Prompt Log

2. Implement `integrations/anthropic.py`:
   - `generate_soap_note(text_summary, encounter_context) -> dict`
   - Input: patient age, chief complaint, active meds, allergies + doctor's typed summary
   - Output: strict JSON matching ScribeDoc shape
   - Prompt loaded from `prompts/soap-note-v1.txt`, hash recorded in AI Prompt Log
   - Model: `claude-sonnet-4-6` (locked)
   - No streaming for Stage A — synchronous response (~2-3 seconds, acceptable)

3. Build `services/ai.py` — business logic layer:
   - `build_encounter_context(encounter_name) -> dict` — fetch from Frappe without PHI in logs
   - `log_prompt_call(session, tokens_in, tokens_out, cost, latency, error)` — write AI Prompt Log row

4. Frontend: `src/lib/api/ai.ts` — typed client
   - `generateNote(encounterId, textSummary): Promise<ScribeDoc>`
   - `saveScribeDraft(encounterId, scribeDoc): Promise<void>`

5. Frontend: `src/app/api/ai/generate/route.ts` — BFF route handler
   - POST, auth via existing Bearer pattern
   - Calls Frappe whitelisted method, returns ScribeDoc

6. Wire `AiScribeEncounter.tsx`:
   - Capture stage submit → call `generateNote()` → advance to review stage
   - Replace any mock data with real response

### Stage B: Audio transcription (Groq Whisper)

1. Build `integrations/groq.py`:
   - `transcribe(audio_bytes: bytes) -> str`
   - Model: `whisper-large-v3` (Groq endpoint)
   - Never store audio bytes — process and discard immediately (audio_retention_days=0)

2. Add `transcribe_audio(audio_b64: str) -> str` to `api/v1/ai/api.py`

3. Frontend: `src/app/api/ai/transcribe/route.ts` — BFF handler
   - Receives audio blob from MediaRecorder, forwards to Frappe, returns transcript text

4. Wire `AiScribeEncounter.tsx` audio recording:
   - MediaRecorder (webm/opus) → assembled blob → base64 → POST to `/api/ai/transcribe`
   - Transcript text populates the text summary field → same `generateNote()` path as Stage A

## Key constraints

- **Audio never stored** — `audio_retention_days=0` per ComplianceProfile. Process in memory, discard.
- **Physician must approve** — `approveAndSave()` is gated on explicit click. AI never finalizes autonomously.
- **No streaming in Stage A** — SSE adds frontend complexity. Synchronous JSON response first. Re-evaluate after user feedback.
- **PHI never in logs** — `build_encounter_context()` passes field names and IDs to logs, never content.
- **Prompt versioning** — prompt file name includes version suffix `_v1`. AI Prompt Log records hash.
- **Model locked** — `claude-sonnet-4-6`. No model selection in UI.

## Environment variables needed

| Variable | Where | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | site_config.json | Already referenced in existing stub |
| `GROQ_API_KEY` | site_config.json | New for Stage B |

## Files to create/modify

### Backend
| File | Action |
|---|---|
| `remedisys_healthcare_ai/api/v1/ai/api.py` | Create — whitelisted methods |
| `remedisys_healthcare_ai/services/ai.py` | Create — business logic, context builder |
| `remedisys_healthcare_ai/integrations/anthropic.py` | Implement — was stub |
| `remedisys_healthcare_ai/integrations/groq.py` | Create — Groq Whisper client |
| `prompts/soap-note-v1.txt` | Create — SOAP generation prompt |

### Frontend
| File | Action |
|---|---|
| `src/lib/api/ai.ts` | Create — typed API client |
| `src/app/api/ai/generate/route.ts` | Create — BFF route handler |
| `src/app/api/ai/transcribe/route.ts` | Create — BFF route handler (Stage B) |
| `src/components/narzim/encounter/ai-scribe/AiScribeEncounter.tsx` | Modify — wire to real API |

## Claude SOAP prompt design (Stage A)

Input to Claude:
```
Patient: {age} y/o {sex}
Chief complaint: {chief_complaint}
Active medications: {med_list}
Known allergies: {allergy_list}

Doctor's clinical summary:
{text_summary}

Return a JSON object matching this exact schema: ...
```

Output: strict JSON, `ScribeDoc` shape. Temperature 0.2. Max tokens 1500.
Schema included in prompt (prevents hallucinated fields).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-01 | Sarvesh | Initial version (header backfilled from git history) |
