# 2026-08-17 — Activity timeline backend gaps: investigate, then fix only what is real

**Doc status:** record · **Created:** 2026-08-17 by Sarvesh-SocialAngel · **Updated:** 2026-08-17 by Sarvesh-SocialAngel · **Version:** 1.0

Branch: `feat/activity-timeline-api-gaps`
Request doc under test: `docs/api/ACTIVITY_TIMELINE_GAPS.md`
Frontend counterpart: `Healthcare_next_app/docs/backend-requests/activity-timeline-gaps.md`

## The task as given

Close the backend gaps behind Patient 360 → **Activity**, under these constraints:

- Inspect first, modify second. **Do not assume the request doc is correct** if the
  code says otherwise; verify every proposed change against the current implementation.
- Do not redesign the frontend. Do not introduce a merged Activity endpoint.
- Preserve backward compatibility: do not rename response fields; **add** rather than replace.
- No N+1 queries. Do not expose unnecessary User/Patient data.
- **Do not fabricate clinical timestamps.** Never label `creation` as a result or
  administration time.
- Deliver: what changed (exact paths), what deliberately did not, before/after JSON,
  `Schema changes: YES/NO`, query/performance proof, tests run, remaining frontend work.

Priorities as handed over: P1 `added_by_name`; P2 lab/immunization timestamps;
P3 lab report identity; P4 pagination/totals; P5 `education` (recommend NOT adding);
P6 merged endpoint (do not implement).

## What the investigation actually found

The request doc listed 8 gaps. Reading the code reduced them to **two** real backend
changes. The doc was wrong in three places — including in a doc I wrote myself:

| Priority | Doc claim | Code says | Outcome |
|---|---|---|---|
| P1 documents `added_by` | Returns a login email | Correct | **Fixed** |
| P2 immunizations | No exposed ordering timestamp | Correct — `creation` is used in `order_by` but not returned | **Fixed** |
| P2 labs | Backend gap | `_LAB_LIST_FIELDS` + `_serialize_lab_row` **already** return `result_date`, `submitted_date`, `creation`; `services/labs.py:603` already defines the precedence | **No change** — frontend work |
| P3 report identity | Add a report link on Lab Test | ADR-033 explicitly rejected this as "Alternative 1"; would need a superseding ADR | **No change** |
| P4 totals | Confirm a real total exists | `list_encounters` returns `frappe.db.count` (line 841); appointments likewise | **No change** — but encounters clamps `page_size` to 100, so the frontend's 200 is silently halved |
| P5 `education` | Probably leave lazy | Confirmed absent from `_LIST_FIELDS` | **No change**, deliberately |
| P6 merged endpoint | Not requested | — | **Not implemented** |

Two further corrections to the request doc, recorded so they are not repeated:

- It cited `administered_by_name` as the precedent for a bulk User lookup. It is not —
  that is a `fetch_from` on a **Healthcare Practitioner** link. The real precedent is
  `services/providers.py::_user_image_fallback`.
- `AI Lab Panel Extraction Panel` is a child table of **`AI Prompt Log`** — an audit
  record, not a clinical contract. It cannot serve as report identity.

## What was changed

1. `remedisys_healthcare_ai/services/documents.py` — new `_owner_full_names()` bulk
   helper (one deduped `User` query per page, `full_name` only); `added_by_name` added
   to `list_documents` rows and to the `upload_document` response. `added_by` untouched.
2. `remedisys_healthcare_ai/api/v1/immunizations/api.py` — `creation` added to `_FIELDS`
   and to `_fmt()`, documented as the **record-creation** time and explicitly not an
   administration time. `_fmt` is shared by list/get/create/update, so all four agree.

Schema changes: **NO**. No doctype JSON, no custom field, no patch, no fixture.

## Tests

New: `tests/documents/test_documents_added_by.py` (7),
`tests/immunizations/test_immunization_creation_field.py` (6). All 13 pass on
`test.marley.local`. The N+1 guard asserts the query count directly (5 documents,
3 owners → exactly 1 `User` query with a deduped `in` filter), because a per-row
lookup is invisible in a small fixture.

## Deliberately not done

No merged endpoint, no `education` in the list response, no lab-report identity field,
no `result_datetime` schema change, no frontend edits. The `page_size` 100 clamp is a
frontend correction and is reported, not silently patched.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-17 | Sarvesh | Initial version (header backfilled from git history) |
