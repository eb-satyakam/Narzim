# Country-specific AI suggestions (via ComplianceProfile)

**Doc status:** record · **Created:** 2026-07-23 by Sarvesh-SocialAngel · **Updated:** 2026-07-23 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-22
**Branch:** feature/ai_v3

## Goal
AI suggestions (medications, labs, and every section) should be tailored to the
deployment country — prefer drugs/formulations/lab panels standard and available
in that country's routine clinical practice. Source of country = the existing
`ComplianceProfile` (mx/in), set per-site via `remedisys_compliance_profile` in
site_config.json (user's choice — not a new AI Settings toggle; single source of
truth with jurisdiction/language).

## Changes (backend only)
1. `compliance/base.py` — new `country_name: str` field on ComplianceProfile.
   `mx.py` → "Mexico", `india.py` → "India". (Frozen dataclass; only 2
   instantiations, both updated; no field defaults so ordering is safe.)
2. `integrations/openai.py` + `anthropic.py` `generate_suggestions` user_message
   — inject `Country / clinical setting: {country} — recommend medications and
   labs appropriate to routine clinical practice and availability in {country}.`
3. `services/ai.py` — `_resolve_country()` + `build_autopopulate_context` adds
   `ctx["country"]`; `build_autopopulate_message` injects the same country line
   (omitted when country is empty).
4. Prompts — `suggest-v2.txt` and `encounter-autopopulate-v1.txt` gain a
   country-tailoring instruction (prefer country-standard drugs/labs; never
   suggest something unavailable there; for autopopulate it does NOT override
   master matching — still reuse an existing catalog id when one matches).

## AI Settings UI override (added 2026-07-22)
`AI Settings.suggestion_country` (Select: blank / Mexico / India) — a UI override
for the SUGGESTION country only. `services/ai.py::resolve_suggestion_country()`
resolves: AI Settings override → ComplianceProfile.country_name → "". Used by
generate_suggestions (openai + anthropic) and autopopulate. Blank = inherit the
compliance-profile country. **Scope-limited on purpose**: it does NOT change
legal jurisdiction / privacy law / retention / output language — those stay on
the deployment ComplianceProfile (site_config), so a UI admin can't silently
flip legal jurisdiction. Verified: blank→Mexico, "India"→India, blank→Mexico.

## Notes
- No doctype/migration change — ComplianceProfile is a Python dataclass loaded at
  runtime; the running server just needs the reloaded code.
- Output LANGUAGE stays separate (primary_language); country only guides which
  drugs/labs are appropriate.
- Verified: dev active profile = mx → country_name "Mexico"; _resolve_country()
  returns "Mexico"; generate_suggestions runs with the new line.
- Deferred/none: no AI Settings UI toggle (country is a per-site deployment
  config, consistent with how jurisdiction already works).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-23 | Sarvesh | Initial version (header backfilled from git history) |
