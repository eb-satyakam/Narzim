# Dev mic failure — `record_consent` missing on the deployed backend

**Doc status:** record · **Created:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The report

"Mic is not turning on in v3 on dev." Sites given:

- Frontend: `https://devehr.narzim.com` (Vercel)
- Backend: `https://dev-healthcare.m.frappe.cloud` (Frappe Cloud)

Reported symptom, confirmed by the user: **no microphone permission popup appears at all.**

## Root cause

The deployed backend does not have `remedisys_healthcare_ai.api.ai.sessions.record_consent`.

```
frappe.exceptions.ValidationError: Failed to get method for command
remedisys_healthcare_ai.api.ai.sessions.record_consent with module
'remedisys_healthcare_ai.api.ai.sessions' has no attribute 'record_consent'
```

HTTP 417. Reproduced directly against the live dev backend as `Administrator`.

This is a **frontend/backend deployment skew**, not a defect in either codebase.

- The frontend on Vercel has T-38 (server-derived consent evidence). `POST /api/ai/session/consent`
  returns 401 unauthenticated, so the BFF route is deployed.
- The backend has not been rebuilt since T-38 landed.

## Why the symptom looked like a microphone problem

The mic is never requested, because consent gates it:

```
grant()                                   use-recording.ts:227-263
  -> POST /api/ai/session/consent         use-recording.ts:250   <-- FAILS (417)
       (only on success)
  -> copilot.start()                      use-recording.ts:262   <-- never runs
       -> getUserMedia()                  real-provider.ts:396   <-- never runs
       -> POST /api/ai/session            (mints Deepgram token)
       -> new WebSocket(wss://api.deepgram.com)  real-provider.ts:861
```

The UI shows "Could not record consent. Check your connection and try again."
(`use-recording.ts:257`), which points the clinician at the network. The network was fine.

## Evidence gathered

Method probe against the deployed backend (`api.ai.sessions`):

| Method | Deployed | Added on `dev` |
|---|---|---|
| `get_active_session` | EXISTS | 2026-07-25 |
| `get_encounter_ai_record` | EXISTS | 2026-07-30 |
| `get_encounter_transcript` | EXISTS | 2026-07-30 |
| `refresh_deepgram_token` | EXISTS | 2026-06-04 |
| `start_session` | EXISTS | — |
| `stop_session` | EXISTS | — |
| **`record_consent`** | **MISSING** | **2026-09-03 (`e496eff`)** |

Branch state at time of investigation:

| Branch | Newest commit | Has `record_consent` |
|---|---|---|
| `dev` | 2026-09-03 `46a9e67` | yes |
| `pre` | 2026-06-26 `45c3e53` | no |
| `main` | 2026-08-13 `3a1f802` | no |

`dev` is 837 commits ahead of `pre` and 280 ahead of `main`. Because the deployed backend has
methods from 2026-07-30 that `pre` (2026-06-26) cannot have, the dev site is running `main` or a
`dev` build not rebuilt since roughly 2026-08-13.

Ruled out during the investigation:

- `Permissions-Policy` — the frontend sends `microphone=(self)`. Mic is allowed.
- CSP — present but `Content-Security-Policy-Report-Only` on every route checked. Blocks nothing today.
- AI feature flags — `AI Settings.enable_ambient_documentation = 1`, Deepgram `nova-3` / `multi` / diarize on.
- Missing `NEXT_PUBLIC_*` env var — no such variable gates the mic path; only server-side `FRAPPE_URL` does.
- AudioWorklet 404 — the worklet is an inline blob (`real-provider.ts:106-145`), no static asset to miss.
- Browser permission state — irrelevant, `getUserMedia` is never reached.

## Fix

Deploy current `dev` to `dev-healthcare.m.frappe.cloud`. No code change is required for this bug.

## Secondary findings (separate from the fix above)

1. **Error reporting masks the real cause.** `real-provider.ts:392-401` is a bare `catch {}` that
   turns every failure into "Microphone access denied", including a `TypeError` from an insecure
   context. `encounter-flow.tsx:2049-2052` hardcodes `FailureBanner kind="ai"`
   ("Transcription stopped — connection closed") for any `rec.error`. The `kind="mic"` variant at
   `recording-ui.tsx:42-47` is never used anywhere. A mic fault reports as a network fault and a
   deploy fault reports as a mic fault. This is what made the bug expensive to find.

2. **CSP landmine.** `csp.ts:107` is
   ``` `connect-src 'self'${IS_DEV ? " ws: wss:" : ""}` ```
   with `IS_DEV = process.env.NODE_ENV !== "production"` (`csp.ts:31`). Every Vercel build,
   including the dev deployment, runs `NODE_ENV=production`, so the `wss:` exception is off there.
   The header is Report-Only today (`csp.ts:144`) so nothing is blocked. The moment it is switched
   to enforcing, the direct browser socket to `wss://api.deepgram.com` (`real-provider.ts:861`) is
   blocked and the mic appears broken again. Deepgram must be added to `connect-src` before that
   switch.

3. **Doc drift.** `CLAUDE.md` §6 states `api/ai/auth.py` does "realtime channel auth + Deepgram
   token minting". It does not. That file has one whitelisted method, `subscribe_encounter_channel`,
   and no Deepgram code. Token minting is `integrations/deepgram.py::mint_session_token`, called
   from `api/ai/sessions.py`. `CLAUDE.md` §3 also cites the agent loop at
   `integrations/openai.py:1351`; it is now at `:2578` with the constant at `:2502`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-04 | Sarvesh-SocialAngel (AI-assisted) | Initial record |
