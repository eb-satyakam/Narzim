# Encounter V3 documentation — one living doc, the rest frozen

**Doc status:** record · **Created:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The request

> "new encounter flow documentation is not write ... i am confused if i read all
> document . i want simple presied small and reabal with user story and example
> any one can under stand"
>
> "we have large doc can you remove extra doc from new encounter flow... arrange
> in sequence"

## The problem, measured before changing anything

15 documents, 8,200 lines, for one flow. Four of them `living` and all
describing the same screen:

| Document | Lines | Status before |
|---|---|---|
| ENCOUNTER_V3.md | 481 | living |
| ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md | 1,242 | living |
| ENCOUNTER_V3_PHASE4_CHECKLIST.md | 297 | living |
| ENCOUNTER_UX_RESEARCH.md | 733 | living |

This breaks the rule already written in CLAUDE.md §9:

> One fact, one owner. A `living` document may not restate a fact another
> `living` document owns; it links instead.

Four documents claiming to be current, with different dates and different
amounts of detail, give a reader no way to tell which is true. That is the
confusion. Rewriting one file does not fix it.

## What the other three actually are

None is a description of the flow:

- **STEP1_IMPLEMENTATION_PLAN** — a build plan for finished work.
- **PHASE4_CHECKLIST** — its own text says "design only, NOT executed".
- **UX_RESEARCH** — the research that produced ADR-054. The decision now lives
  in the ADR.

A `record` is a dated snapshot. It is allowed to be stale and must never be
"corrected". Marking these `record` removes 2,272 lines from what a reader has
to treat as current, without deleting a word.

## What was done

1. `ENCOUNTER_V3.md` rewritten as the single entry point: the flow, the one
   rule, where the data lives, one section per step with a user story and a
   worked example, and a reading-order index for everything else.
2. The three documents above flipped to `Doc status: record`, each with a line
   at the top naming ENCOUNTER_V3.md as the current description.
3. Nothing deleted. §9 forbids deleting a superseded document, and a `record` is
   evidence of what was true on its date.
4. The seven encounter ADRs untouched. A merged ADR is never edited.

## Rejected

- **Deleting the long documents.** Asked for as "remove extra doc", and the
  intent — fewer things to read — is met by freezing them. Deleting would
  destroy the build evidence for Phases 3 to 6 and break §9.
- **An engineering appendix on the short doc.** An appendix is how a 200-line
  document becomes 500 again. The ADRs already hold the reasoning.
- **Renaming files into a numbered sequence.** Renames break every inbound link
  for a gain an index at the top of one document already delivers.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Initial version — the request, the measurement, and what was rejected |
