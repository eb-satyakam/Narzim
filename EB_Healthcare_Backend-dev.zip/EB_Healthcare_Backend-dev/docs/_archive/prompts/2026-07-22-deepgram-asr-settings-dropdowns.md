# Deepgram ASR — easy model/language switch + multilingual + keyterm boosting

**Doc status:** record · **Created:** 2026-07-22 by Sarvesh-SocialAngel · **Updated:** 2026-07-22 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-22
**Branch:** feature/ai_v3
**Context:** See `docs/ai/ASR_TRANSCRIPT_AUDIT.md` (Phase 1).

## Problem
Scottish-English transcribed poorly (config was `nova-3-medical` + `language=en`
— US clinical model + generic English). Also: patients speak English **or
Spanish (or other)** — so a single-accent `en-GB` config won't work (it can't
transcribe Spanish). And `deepgram_model` / `deepgram_language` were free-text
`Data` fields — no safe/easy way to switch.

## Decision (chosen from live-tested options)
**`nova-3` + `language=multi` + keyterm boosting.**
- `multi` = code-switching → English + Spanish + other all transcribed, each in
  its spoken language (live streaming kept).
- Trade-off: `multi` is nova-3 general only (no nova-3-medical-multi), so
  drug-name accuracy would drop — **recovered via keyterm prompting**: the drug
  catalog's generic names are sent to Deepgram as keyterm hints.
- `en-GB` (best for a lone Scottish accent) was rejected because it can't serve
  Spanish-speaking patients.

## Changes (all on our custom doctype / locked integration — Rule 1 OK)
1. `ai_settings.json`
   - `deepgram_model` `Data → Select`: nova-3-medical, nova-2-medical, nova-3, nova-2.
   - `deepgram_language` `Data → Select`: en, en-US, en-GB, es, es-MX, multi.
     (es-MX added — the legacy migrate_deepgram_language_to_es_mx patch set Mexico
     prod to es-MX, which Deepgram accepts; keep it valid, don't normalize away a
     deliberate setting.)
   - Field descriptions document the recommended pairings.
2. `patches/v0/normalize_deepgram_asr_select_values_20260722.py` (post_model_sync)
   - Clamps any deepgram_model/language NOT in the new Select option set to a safe
     default (model→nova-3, language→es-MX) so the Data→Select conversion never
     leaves an env blank/invalid. Idempotent; valid values (incl. es-MX)
     untouched. Verified on dev: seeded legacy en-IN → clamped to es-MX; nova-3
     untouched; logged in Patch Log.
3. `integrations/deepgram.py`
   - `_drug_keyterms()` — distinct, cleaned (paren/strength/'+' stripped)
     medication generic names, capped at `_KEYTERM_MAX = 50`.
   - `mint_session_token()` adds `keyterm=[...]` **only for nova-3\*** models
     (keyterm is nova-3-only; nova-2 uses `keywords`, which nova-3 rejects).
   - `_build_stream_url()` now `urlencode(..., doseq=True)` so a list keyterm
     becomes repeated `keyterm=a&keyterm=b` params.

## Deepgram keyterm limit (verified live)
Max **500 sub-word tokens** across all keyterms (not 500 terms). Our catalog:
~80 drug names pass, ~90 fail. Cap = **50** → well under the ceiling with margin
for catalog growth and long Spanish/medical names, so the /v1/listen WS URL can
never 400 and break the connection (Rule 7). Best-effort helper returns [] on
any failure → no keyterms rather than an error.

## Dev value (config, not code)
`nova-3` + `multi` set on dev for in-browser testing. The dropdown allows
one-click A/B against `nova-3-medical` + `en`. Prod default stays `es` (Mexico).

## Verification done
- Config-acceptance probes: all model×language combos accepted; keyterm accepted
  with nova-3+multi (nova-3 `keywords` correctly 400s); 50-keyterm live-shaped
  URL → 200 with all streaming params.
- True Scottish/multilingual + drug-name accuracy still needs an in-browser
  audio A/B (probe = acceptance, not quality).

## Out of scope (Phase 2)
ASR-provider switch (Deepgram ↔ Whisper large-v3), smart_format on the live
path, and wiring Whisper (batch) for the "best accent + multilingual" case.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-22 | Sarvesh | Initial version (header backfilled from git history) |
