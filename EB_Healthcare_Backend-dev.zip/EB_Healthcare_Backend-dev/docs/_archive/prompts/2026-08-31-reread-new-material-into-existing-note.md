# Re-reading new material into a note that already has text

**Doc status:** draft · **Created:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

Requirement found by using the screen, written down before the code. Approach A
of four was chosen by the product owner.

## The problem, as observed

The physician drafts a note, goes back to Capture, and new material arrives.
Three kinds, all reported live on `HLC-ENC-2026-00653`:

| New material | What reached the note |
|---|---|
| Speech: "Okay. My hands burn also." | offered by the gaps check |
| Vitals read aloud: temperature 36.17, weight 18 kg | nothing |
| A lab report uploaded in Narzim AI chat | nothing |

## Why it stopped working

It used to appear to work, and the product owner correctly identified the two
commits that ended it.

Before `fa3eea2`, three blob-only fields (`physical_examination`, `diagnosis`,
`notes` -- ADR-019) rendered EMPTY after a reload, because
`useState(initialText.physical_examination)` reads its argument once, before
the fetch returns. Before `3ec1157` there was no `noteAlreadyDrafted` guard, so
a reload remounted the component, reset `autoGenStarted`, and regenerated.

Together: a reload regenerated the whole note over fields that only LOOKED
empty. The lab landed in Objective. It also destroyed whatever the physician
had written there, every time, silently. One mechanism, both effects. The
behaviour was never a feature.

## The rule this must obey

New material may FILL an empty field. It may never REPLACE text that is
already there. Anything aimed at an occupied field is offered below it, and
reaches the note only on a click (Rule 6).

## What is built

1. A re-read action on Review SOAP. Re-runs `generate_soap_draft` with the full
   encounter context: transcript, attached lab documents, recorded vitals.
2. A suggestion for an EMPTY field fills it, exactly as the first draft does.
3. A suggestion for an OCCUPIED field becomes an offer under that field,
   instead of being consumed and dropped as it is today
   (`encounter-flow.tsx`: `consumed.push(s.id)` then `continue`).
4. Offers under a field carry their source, because a physician deciding
   whether to accept a sentence needs to know where it came from:
   - `said aloud` -- a verbatim transcript quote from `find_note_gaps`
   - `AI draft` -- composed text from a re-read. A lab sentence names its own
     source laboratory and result date inside the text, per `soap-v1.txt`.

## Deliberately NOT in scope

- **Occupied vitals.** A recorded vital still wins and is not offered. Vitals
  are edited in one place (Fill Encounter) and a second path to them needs its
  own decision.
- **A contradicting offer.** An offer that disagrees with the physician's text,
  rather than adding to it, is shown the same as any other. If that turns out
  to be common it needs a marker of its own.
- **Durable provenance.** Offers and their acceptance live in React state.
  PHI-7 wants this in the database. That is the follow-up (approach D, the
  material ledger), and this work is meant to give it real usage data.

## Rejected approaches

| | Approach | Why it lost |
|---|---|---|
| B | Widen `find_note_gaps` to take the lab text and vitals | a lab cannot be offered as verbatim quotes without becoming twelve chips of raw serotype lines; making it one useful sentence means composing, and a composing gaps check loses the property that lets it run with `enable_suggestions = 0` |
| C | Stop auto-filling; every section built from offers | a physician who must accept six offers is slower than one who types |
| D | Backend material ledger, per-item reflected/not-reflected state | the right end state and the only one that satisfies PHI-7, but it needs a doctype, a fingerprint scheme and a migration, and shows the physician nothing until all three land |

## What would falsify the choice

1. Physicians ignore the offers and retype. Then access to the material was
   never the problem, and D is needed sooner.
2. Re-reads routinely produce offers that CONTRADICT the physician's text. Two
   plausible versions of Objective stacked on each other is worse than the gap.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Initial version — requirement, cause, chosen approach A |
