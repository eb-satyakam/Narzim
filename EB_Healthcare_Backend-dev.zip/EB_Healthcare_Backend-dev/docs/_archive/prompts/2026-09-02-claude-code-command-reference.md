# 2026-09-02 — Claude Code command and shortcut reference

**Doc status:** record · **Created:** 2026-09-02 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-02 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

## The ask

> "tell me all short commands and / to make you work fast and effciently i dnt
> wan to use simple English i want liek be critci and all you already ahve to
> communicate with you"

then:

> "create md for all thses prompts with thier meaning"

Read as two things.

1. Enumerate every prefix, key, slash command, skill and CLI flag that makes the
   session faster. Not generic docs — the subset that applies to this bench.
2. Drop the simple-English constraint when talking in the terminal. Be direct
   and critical instead.

## What was produced

`docs/CLAUDE_CODE_COMMANDS.md`, v1.0, eight sections.

| § | Contents |
| --- | --- |
| 1 | Prompt prefixes: `/`, `@`, `!`, `#` |
| 2 | Key bindings, with `Ctrl+L` vs `/clear` called out |
| 3 | Built-in slash commands, grouped by context / session / config |
| 4 | Skills actually loaded on this machine, including the Vercel set |
| 5 | Why "always do X" belongs in a hook, not in a memory note |
| 6 | CLI flags, verified against `claude --help` |
| 7 | Custom commands — `~/.claude/commands/` is empty |
| 8 | The unresolved simple-English scope question |

## Verification

- **§6 CLI flags** — read directly from `claude --help` on this machine. Exact.
- **§4 skills** — read from the session's loaded skill list. Exact for this machine.
- **§3 slash commands, §2 keys** — build-dependent. Marked as such in the doc.
  `/help` is named as the authoritative source. Uncertain bindings carry ⚠️.

Nothing in the doc was asserted from memory without one of those three sources.

## Findings worth acting on

1. **`~/.claude/commands/` is empty.** Every standing rule — prompt archiving,
   the ADR byline, the four-approaches requirement — is retyped each session
   rather than encoded once. Three candidate commands are proposed in §7.
2. **`/fewer-permission-prompts` has never been run.** The no-changes-without-
   permission rule means approval is requested constantly, including for
   read-only calls that could be allowlisted. This is the cheapest available
   speedup.
3. **Preferences cannot enforce sequence.** A memory note saying "always archive
   the prompt first" is advice. A hook is enforcement. §5 lists three hooks that
   would make the standing rules structural.
4. **The `ide` MCP server failed to connect** this session
   (`WebSocket is not open. Cannot start transport.`). Configured, not missing.
5. **Vercel CLI is stale:** 58.4.4 installed, 59.11.2 current.

## Open

The scope of the simple-English override is undecided. Three options are laid out
in §8 of the doc. It was written to option 1 — dense in the personal tool
reference, unchanged in team-facing docs — as the reversible default, pending a
decision. Nothing in `docs/flows/`, `docs/adr/` or any other team-facing document
was touched.

## Files

- `docs/CLAUDE_CODE_COMMANDS.md` — new, 246 lines
- `prompts/2026-09-02-claude-code-command-reference.md` — this file

No code changed. Nothing staged, committed or pushed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
