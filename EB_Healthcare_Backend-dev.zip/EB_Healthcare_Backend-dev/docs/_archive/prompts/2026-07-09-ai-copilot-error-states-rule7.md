# AI Copilot Sprint 4 — Error states / Rule 7 hardening

**Doc status:** record · **Created:** 2026-07-10 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-09
**Branch:** `feature/ai_v1` (frontend repo only — no backend changes)
**Requested by:** Sarvesh — picked as the next Sprint 4 item after consent recording

## What Rule 7 requires

"AI unavailable must never break the encounter form" — the Patient Encounter must load, save,
and submit normally regardless of AI state.

## Investigation

1. **Confirmed already safe**: grepped `encounter-screen.tsx` for any Save/Submit button gated
   on `copilot.state` or `copilot.error` — zero matches. The encounter form was already fully
   decoupled from copilot state before this change.
2. **Found the real gap**: `CopilotProvider` (the interface both `MockCopilotProvider` and
   `RealCopilotProvider` implement) had `onTranscript`/`onSuggestions` but **no `onError` or
   disconnect hook at all**. In `real-provider.ts`, the WebSocket's `close` handler only ever
   resolved `resolveStop` (used by `stop()`'s own await) — it never distinguished "we closed
   this on purpose" from "Deepgram/network killed the connection out from under us". If the
   connection dropped mid-recording (revoked API key, network blip, Deepgram-side issue), the
   UI kept showing "recording" indefinitely with no new transcript ever arriving — not a crash,
   but a silent failure the physician would have no way to notice. `RecordingControls.tsx`
   already has a fully-built `state === "error"` UI (message + reset-to-idle) — it was just
   never triggered by this failure mode.

## Changes

- `provider.ts` — added `onError(cb: (message: string) => void): Unsubscribe` to the
  `CopilotProvider` interface. Fires only for unexpected failures, never for a normal `stop()`.
- `real-provider.ts`:
  - New `private closingIntentionally = false` flag, set to `true` right before the WS close
    call inside `stop()`. (`dispose()` doesn't need its own flag — it sets `this.disposed = true`
    as its very first line, and the close handler's guard already checks `disposed` too.)
  - The WS `close` listener now checks `wasIntentional = closingIntentionally || disposed`; if
    false, fires `errorCbs` with a physician-facing message.
  - Added a WS `error` listener with the same guard (an "error" event typically precedes an
    abnormal "close" — both may fire for one incident; harmless, `use-copilot.ts`'s handler is
    idempotent).
  - `onError()` method: standard Set-based subscribe/unsubscribe, cleared in `dispose()`
    alongside the other callback sets.
- `mock-provider.ts` — added a no-op `onError()` (the mock never fails mid-session).
- `use-copilot.ts` — `ensureProvider()` now subscribes to `p.onError(...)`: transitions
  `state` to `"error"` only from `"recording"`/`"paused"` (a failure reported after the session
  already ended has nothing left to degrade), and sets the message via the existing `error`
  state (already rendered by `RecordingControls.tsx` — no new UI needed).

## Verification

- `npx tsc --noEmit` — clean on all 4 touched files.
- `npx eslint` — clean on all 4 touched files. (2 pre-existing lint errors in `CopilotPanel.tsx`
  — a `react-hooks/static-components` violation, component defined during render — are
  unrelated; confirmed that file isn't in this change's diff at all.)
- Confirmed via grep, not just reasoning: no Save/Submit control anywhere checks copilot state.
- **Not manually tested** — would need to kill the Deepgram connection mid-recording (revoke
  the API key or drop network) against a real encounter and confirm the UI shows the error
  state while Save/Submit keeps working normally.

## Still open (Sprint 4, not done here)

PHI audit, i18n audit, compliance badge, orphaned `FloatingChatBar.tsx`/`CopilotChat.tsx`
cleanup, and the previously-noted missing token-refresh timer (`refresh_deepgram_token` exists
server-side, never called client-side — long encounters will still drop the WS when the token
expires, now at least surfacing as a visible error instead of a silent one).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
