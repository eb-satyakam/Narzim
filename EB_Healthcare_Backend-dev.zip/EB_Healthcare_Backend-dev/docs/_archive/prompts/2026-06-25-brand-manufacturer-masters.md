# Brand & Manufacturer masters — list + create API

**Doc status:** record · **Created:** 2026-06-26 by Sarvesh-SocialAngel · **Updated:** 2026-06-26 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-25
**Phase:** Phase 3/4 admin catalog (Medication linked-items polish)
**Area:** `api/v1/admin/catalog.py` (backend), Medication linked-item editor (frontend)

## Context

`Medication Linked Item.brand` and `.manufacturer` (Healthcare core child doctype)
are **Link** fields → ERPNext core `Brand` and `Manufacturer` masters. The
frontend linked-item editor currently exposes them as free-text inputs, which is
a latent bug: a value that isn't an existing master row fails Link validation on
save.

User decision: treat Brand and Manufacturer as master data — select an existing
one or create a new one inline (same UX as the Item picker). Backend API only,
**no Frappe `/api/resource/` endpoints** — custom whitelisted methods in our app.

## Master shapes (ERPNext core, read-only to us)

| Master | autoname | required | other fields |
|---|---|---|---|
| `Brand` | `field:brand` | `brand` | description, image |
| `Manufacturer` | `field:short_name` | `short_name` | full_name, website, country |

## Plan

Backend (`remedisys_healthcare_ai/api/v1/admin/catalog.py`, exported in `api.py`):
- `list_brands(query=None, limit=50)` — search the Brand master (read perm).
- `create_brand(brand, description=None)` — create, savepoint-guarded (create perm).
- `list_manufacturers(query=None, limit=50)` — search Manufacturer (read perm).
- `create_manufacturer(short_name, full_name=None)` — create (create perm).

All follow the existing `search_items` / `create_item` patterns: `@frappe.whitelist()`
+ `@handle_api_errors`, `require_permission`, `_clean`, savepoint on create,
`set_response`. Wrapping core doctypes via our app (Rule 1 — no core edits).

Frontend (separate, after backend lands): dedicated BFF routes `/api/admin/brands`
and `/api/admin/manufacturers` (custom methods, not the generic resource route),
hooks, and a search-or-create combobox replacing the two free-text inputs.

## Risks / follow-ups

- **Permissions (blocker):** `Brand`/`Manufacturer` ship perms for System Manager /
  Item Manager / Stock roles only. App admins are Website Users with EB_ roles, so
  `require_permission("Brand", "create")` will 403 until read+create are granted via
  the EB_ docperm migration patch (see [[project_eb_docperm_patch]]). Must be added
  for create to work in production.
- Duplicate names → `DuplicateEntryError` surfaced as 400.
- Deletion intentionally not exposed (masters are referenced by linked items).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-26 | Sarvesh | Initial version (header backfilled from git history) |
