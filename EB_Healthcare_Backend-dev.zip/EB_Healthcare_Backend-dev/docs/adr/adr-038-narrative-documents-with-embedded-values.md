# ADR-038: Narrative documents with embedded lab values get verbatim capture plus a bounded, audited values table

**Doc status:** living · **Created:** 2026-07-31 by Divyanshu · **Updated:** 2026-08-26 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Proposed
- **Date:** 2026-07-30
- **Supersedes:** —
- **Superseded by:** —

## Context

Multi-panel extraction (`services/lab_panel_extraction.py`) classifies each
physically distinct uploaded document independently as **tabular** or
**narrative** (`run_panel_extraction`, doc comment at line 134-140: "the model
classifies each physically distinct document independently (v4) rather than
forcing one classification onto the whole batch"). A narrative verdict sets
`AI Prompt Log.is_narrative_report = 1` (line 407) and, for a single narrative
document from a digital PDF, `_raw_with_text_layer` replaces the model's own
transcription with the PDF's deterministic text layer (`pdf_pages.py`, via
pypdf) — this is what makes genetic/pathology/imaging report capture complete
and reproducible (fixed 2026-07-25, see prior session notes; formalized
downstream by ADR-035, which teaches both stored summaries to read narrative
reports as a distinct, labelled context block).

That two-way classifier has no category for a **general clinical narrative
document that embeds a discrete values line inline in prose** — e.g. a
hospital discharge note ("Nota de Prealta") whose "Paraclínicos" section reads
`Laboratorios 21.07.26 Hb 10, Hto 31.4, plaq 511, leucos 8.8, neutros 72%,
PCR 1.07, procalcitonina 0.18, BUN 5.33, Calcio 8.8, cl 98.1, Cr 0.3,
fósforo 3.3, glucosa 90.3, magnesio 2, potasio 4.3, Na 141.7, Urea 11.4` —
one comma-separated sentence, no table, no units printed, no reference
ranges, inconsistent decimal delimiters (space vs. period).

Observed on a real upload (IMSS HGR 12 Mérida discharge note, reviewed
2026-07-30): the document was routed through the **tabular** path. Result:

- 2 of 17 embedded values extracted correctly (PCR, Glicemia basal).
- 1 value corrupted: `Nitrógeno ureico (BUN)` shown as `5`, source is `5.33`
  — the decimal was lost during token parsing.
- 1 value (`Creatinina`, source `Cr 0.3`) matched a template slot but was
  left blank there, while a bare, valueless `Cr` token was separately
  orphaned in "Needs review" — the number itself is unrecoverable from the
  UI as it stands.
- 13 values landed in "Needs review" with garbled, unrecognizable names —
  `Calao`, `d 98.1`, `toaforo`, `m1gnet10`, `N11141`, `potaslo` — token
  corruption from forcing prose through row-oriented matching.
- **Separately, and more materially:** none of the surrounding clinical
  content — admission history, hospital course, final diagnoses, imaging
  findings, discharge instructions, roughly 95% of the document — was
  captured anywhere. The tabular path only ever looks for analyte rows, so
  that content is discarded outright, not merely mis-parsed. Uploading this
  discharge note through the lab flow today is equivalent to throwing away
  the note and keeping two wrong numbers.

For comparison, the same document run through a generic LLM (ChatGPT, outside
this system) produced a clean 11-row table — but silently omitted 6 of the 17
real values (BUN, Calcio, cl, fósforo, magnesio, Urea) with no indication
anything was left out, and inferred units the source never states (`×10³/µL`,
`mmol/L`). That is a worse failure mode for a clinical system than today's
ugly-but-visible "Needs review" bucket: a confident, silently-incomplete
table is more dangerous than an ugly, visibly-incomplete one, because nothing
tells the reader to go check the source. It does, however, confirm that
clinicians want a readable values table out of a document like this, not
just prose — the question is how to produce one without Rule 6's guarantees.

Constraints: **Rule 5** (structured retrieval first, explicit logged
truncation, no full-history dump), **Rule 6** (AI suggestions always
visible, editable, rejectable — never silently completed or auto-applied),
**Rule 9** (deterministic pipelines, observable at every step), **Rule 10**
(no PHI in logs), **§9** (prompts are versioned files, hash + version
recorded per call). Current multi-panel default is
`multi_panel_extraction_v9.txt` (`integrations/llm.py:939`).

## Decision

Add a third per-document classification outcome —
**narrative-with-embedded-values** — alongside today's binary
tabular/narrative, and give it its own handling instead of falling through
to the tabular path by default.

1. **Classification gains a third state.** The multi-panel prompt already
   decides tabular vs. narrative per document; it gains a third signal: a
   narrative document that also contains a distinguishable list of discrete
   analyte-like tokens (name + numeric value, however loosely formatted).
   `AI Prompt Log.is_narrative_report` stays `1` for this case — it is still
   narrative for capture purposes — but a new flag marks that it also
   carries embedded values, so the frontend and the aggregate-summary
   gatherers (ADR-029/ADR-035) can tell the three shapes apart.

2. **Whole-document verbatim capture is unconditional.** Every
   narrative-with-embedded-values document goes through the existing
   text-layer override (`_raw_with_text_layer`) exactly like a pure narrative
   document — the discharge history, hospital course, diagnoses, imaging
   findings, and discharge plan are preserved in full, deterministically, at
   zero marginal LLM cost. This is the highest-value part of the fix: today
   that content is discarded, full stop.

3. **Embedded values become a separate, labelled, informational bucket —
   not a silent merge into "Detected tests."** The same catalog matcher
   already used for tabular candidates (name-first matching, ADR-032) runs
   against the embedded line, but its output is rendered under a distinct
   heading (e.g. "Values mentioned in this report") rather than folded into
   the discrete-order "Detected tests" panels a physician would associate
   with a real lab report. This keeps the physician's mental model honest:
   these are values *read out of a note*, not results of an ordered test.

4. **A completeness invariant is enforced in code, not just prompted.**
   The model must report how many analyte-like tokens it found in the
   embedded line; the pipeline asserts `len(extracted) + len(unmatched) ==
   reported_count` before marking the extraction complete. A mismatch is
   surfaced as a extraction warning (Rule 9 — observable failure), not
   silently dropped the way `Creatinina`/`Cr` was in the observed case. This
   is the direct fix for "a real value quietly disappears."

5. **No units are invented.** If the source line has no unit for a value,
   the bucket shows the bare number and flags "unit not stated in source" —
   it does not guess `mg/dL` or `mmol/L` the way the ChatGPT comparison did.
   A physician confirms or supplies the unit before anything is saved,
   consistent with Rule 6.

6. **Two pre-existing correctness defects are prerequisite fixes,
   independent of this ADR.** The decimal-truncation (`BUN 5.33` → `5`) and
   the matched-but-blank `Creatinina` slot are bugs in the current tabular
   matcher, not artifacts of misclassification — they would also corrupt a
   *real* tabular lab report with the same formatting quirks. They should be
   root-caused and fixed regardless of whether this ADR is accepted; exact
   location not yet traced (candidates: token/decimal splitting in the
   OCR-to-candidate step, and the `unmatched`/panel-row write path in
   `run_panel_extraction`'s Phase 2/3 bucketing).

## Alternatives Considered

1. **Status quo — force every document through the binary tabular/narrative
   classifier.**
   - Pros: zero work.
   - Cons: exactly the failure observed — corrupted values, a silently
     dropped result, and total loss of the surrounding clinical narrative.
     Rejected; the data loss alone is a safety-relevant gap, not a cosmetic
     one.

2. **Treat every such document as pure narrative; no structured values at
   all.**
   - Pros: simplest change — reuses the existing narrative path unmodified,
     eliminates the corruption by construction (no row-matching is ever
     attempted on prose), matches how genetic/pathology reports already
     work.
   - Cons: physicians lose any assistance recovering the 17 values from this
     document and would have to re-key all of them by hand — worse than
     what Single/Compound extraction already offers for an actual lab
     report, and a real usability regression for a document shape clinics
     will keep uploading through this flow whether or not it's "meant" for
     it.

3. **Narrative-with-embedded-values as a third classification, with a
   bounded, audited, separately-labelled values table (chosen).**
   - Pros: preserves the full clinical note (today's biggest loss), still
     offers value-recovery assistance without pretending it's a real lab
     order, and the completeness invariant makes "a value vanished" a loud
     failure instead of a silent one.
   - Cons: a new classification state and a new frontend surface to design
     and review; the completeness-invariant check adds a failure path the
     RQ job must handle cleanly (Rule 9 — must degrade to "extraction
     incomplete, review the source" rather than raising into the worker).

4. **Copy the generic-LLM approach — a best-effort table with no
   completeness guarantee.**
   - Pros: closest to what "looks done" fastest.
   - Cons: demonstrated above to silently drop 6 of 17 real values and
     invent units — directly against Rule 6's requirement that AI output
     never present a partial picture as complete. Rejected on safety
     grounds.

## Consequences

- **Code:** `services/lab_panel_extraction.py` — classification/bucketing
  gains the third state and the completeness-invariant check;
  `run_panel_extraction`'s narrative branch stays the single entry point for
  verbatim capture. New/bumped prompt version
  (`multi_panel_extraction_v10.txt`; the default *at the time of writing* was v9 —
  the prompt is versioned and has moved on since, and this ADR does not track it.
  See `integrations/llm.py::extract_multi_panel_report` for the live version)
  documenting the third classification and the
  "report your total token count" instruction the invariant checks against.
- **Schema:** `AI Prompt Log` needs a way to distinguish
  narrative-with-embedded-values from pure narrative — likely a new boolean
  or a value on the existing `is_narrative_report` field's sibling data,
  needs a short schema review before committing to a field name; any new
  field goes through `patches.txt`, no manual schema edit (§9), and any
  accompanying custom field goes in the **package-level**
  `fixtures/custom_field.json`.
- **Frontend (spec only — frontend is read-only per CLAUDE.md §13; this is a
  handoff, not an implementation):** `lab-order-dialog.tsx` needs a new,
  visually distinct "Values mentioned in this report" card, separate from
  "Detected tests" and "Needs review," rendered only when
  `is_narrative_report` is set alongside the new embedded-values marker.
- **Cost:** no new LLM call beyond the existing single multi-panel
  extraction pass — classification, verbatim capture, and value-bucketing
  all happen inside that one call plus the existing zero-cost text-layer
  override.
- **Not in scope:** the two prerequisite matcher bugs (decimal truncation,
  dropped Creatinina) are called out as parallel work, not solved by this
  ADR alone — the completeness invariant here catches *that a value went
  missing*, it does not by itself fix *why* the matcher mis-parsed it.
- **Re-evaluation triggers:** (a) this document shape turns out to be rare
  in real uploads — the third classification state adds complexity for
  little benefit, revisit; (b) the completeness-invariant check trips
  frequently in production — that signals the OCR/vision step is the real
  bottleneck, not the bucketing logic, and warrants its own investigation.

## Verification

- Re-running this exact discharge note (or an equivalent synthetic fixture)
  through the fixed pipeline: all 17 embedded values reconciled
  (`extracted + unmatched == reported_count`), none silently dropped; the
  full clinical narrative (history, hospital course, diagnoses, discharge
  plan) present and readable via the existing narrative-capture path; BUN
  and Creatinina either correct or explicitly flagged unmatched — never
  silently wrong or silently blank.
- `AI Prompt Log` rows for the new classification carry model/tokens/cost/
  prompt-hash only, no report content (Rule 10).
- A document that is pure narrative (no embedded values) and a document
  that is pure tabular are both unaffected — regression-checked against the
  existing genetic-report and standard-panel test fixtures.

## References

- ADR-032 (name-first analyte matching — reused for the embedded-values
  bucket)
- ADR-035 (narrative reports feed the patient-wide lab summary and clinical
  summary — the precedent for treating narrative content as a first-class,
  separately-labelled context block rather than folding it into tabular
  fields)
- ADR-028 (Lab Parameter master — the catalog the matcher runs against)
- Constitution Rule 5, Rule 6, Rule 9, Rule 10, §9
- `services/lab_panel_extraction.py` (`run_panel_extraction`,
  `_raw_with_text_layer`, `_pdf_text_layer`)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-26 | Divyanshu (AI-assisted) | Factual correction only, no decision changed: removed a moving-state claim ("current default is v9" — it is now v14). An ADR should not assert state that keeps changing; it is frozen while the code moves. Safe to amend because this ADR's Status is **Proposed**, never merged |
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
