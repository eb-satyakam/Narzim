# ADR-068: AI-drafted clinical replies on WhatsApp, approved by a clinician before sending

**Doc status:** living · **Created:** 2026-09-14 by Ashutosh (AI-assisted) · **Updated:** 2026-09-14 by Ashutosh (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-14
- **Supersedes:** `WHATSAPP_HIPAA_COMPLIANT.md` §5 **R-2** entirely, and **R-3** for this one path
- **Superseded by:** —

> **This ADR reverses two of the five rules the WhatsApp channel was designed around.** Each reversal
> was put to the product owner as a question with the trade-off stated, and answered deliberately on
> 2026-09-14. The arguments made *against* each are recorded below, because an ADR that only records
> the winning side is a press release.

## Context

A patient message matching no keyword currently receives a fixed fallback template. The request: an
AI reads the message and **composes** a reply — including clinical self-care guidance — which a
doctor or nurse approves or rejects before it is sent.

Research, options and the full decision table: [`docs/ai/WHATSAPP_AI_ASSISTED_REPLIES.md`](../ai/WHATSAPP_AI_ASSISTED_REPLIES.md).

### What the channel guaranteed before this

| Rule | Guarantee |
|---|---|
| **R-1** | Outbound is template-only; no clinic-originated free text |
| **R-2** | The clinic never originates clinical content — WhatsApp says *that* something happened, the portal says *what* |
| **R-3** | No send without a current, unrevoked consent record |

Meta has refused a Business Associate Agreement. Those three rules are what made "WhatsApp carries
nothing that matters" true rather than aspirational.

## Decision

**Build it as specified.** Specifically:

1. An inbound message matching no keyword produces an **`AI WhatsApp Reply Draft`**. Nothing is sent
   at that moment.
2. A **doctor or nurse** approves or rejects. There is no third option and no auto-approval — no
   timeout, no bulk action, no "approve all".
3. **Staff may never compose or edit free text.** Only the model writes. Approve or reject.
4. On approval the reply is sent **on WhatsApp**, as free text within Meta's 24-hour window.
5. This applies to **every** inbound sender, including numbers matching no patient.

### What this reverses, and what was argued against it

**R-2 — clinical content on WhatsApp.** A self-care suggestion is a clinical statement about a named
patient (named, since ADR-067), sent to a processor with no BAA. *Argued against:* the portal
already exists, is authenticated, and is where clinical detail belongs; delivering there costs the
patient one tap and keeps R-2 whole. *Decided:* WhatsApp directly, because that is where the patient
asked the question.

**R-3 — consent before sending.** An unknown number has no consent record. *Argued against:* a wrong
number is the realistic case — someone with no relationship to the clinic receives clinical advice.
A narrower option was offered (draft for everyone, clinical reply only to known consented patients).
*Decided:* clinical reply to everyone.

**ADR-066's fallback rationale.** That ADR created the fallback because *"silence is
indistinguishable from being heard"*. Sending nothing until approval reinstates that silence for
precisely the clinical messages where it matters most. *Argued against:* sending the fallback
immediately AND creating the draft costs nothing and loses no clinical control. *Decided:* nothing
before approval.

### What is NOT reversed

**R-1's substance holds, and arguably improves.** It removed *clinic-originated* free text — a staff
member typing whatever they judged right, unbounded and unauditable. That stays closed. What replaces
it is bounded by a prompt, checkable in code before a human sees it, attributable to a model and
prompt version, and refused by someone with no authorship bias. See the research doc §3.0.

**R-4 (jurisdiction) and R-5 (audit) are untouched.**

## Alternatives Considered

1. **Portal delivery, WhatsApp nudge.** Draft and approval exactly as specified; the approved reply
   posts to the existing portal chat and WhatsApp says "you have a reply".
   - Pros: R-2 and R-3 both hold. Clinical detail stays behind authentication. Runs on rails that
     already exist on both sides.
   - Cons: the patient reads it one tap later. **Rejected by the product owner** — the answer should
     be where the question was asked.

2. **Non-clinical replies only.** AI answers logistics; anything clinical returns "a clinician will
   review this".
   - Pros: no clinical fact reaches Meta, so R-2 is never engaged and WhatsApp delivery is
     defensible without any reversal.
   - Cons: does not answer the patient's actual question. **Rejected.**

3. **AI classifies, staff send a curated template.**
   - Pros: nothing reversed at all.
   - Cons: a fever message still gets "contact us", just better chosen. **Rejected.**

4. **AI drafts clinical replies, sent on WhatsApp, clinician-approved (chosen).**
   - Pros: the patient gets a real answer in the channel they used. Physician-in-the-loop is genuine
     — a clinician who did not write it must act before anything sends.
   - Cons: reverses R-2 and R-3. Clinical content about a named patient to a no-BAA processor.
     Irreversible per message.

## Consequences

**Safety controls that are not optional.** These are the conditions under which the decision above is
defensible at all:

1. **Never auto-send.** No timeout approval, no bulk approve, no default-approve.
2. **Red flags evaluated in CODE, not by the model** — chest pain, breathing difficulty, seizure,
   uncontrolled bleeding, infant under three months with fever, suicidal ideation. On a match the
   draft is suppressed and the inbox shows an urgent banner. **An LLM must not be what decides an
   emergency is not one.**
3. **No dosing, ever.** Not a drug name with a number, not "the usual dose". Forbidden in the prompt
   AND rejected by a post-check before a human sees the draft.
4. **Every draft records** the inbound message, model, prompt version, tokens and approver, so an
   approved message is reconstructable months later.
5. **The LLM call goes through `services/llm.py::get_llm_client()`** — never a direct provider call
   (ADR-026). OpenAI is already named in the `mx` ComplianceProfile, so no new subprocessor.

**Documentation, in the same change (PHI-5):** `WHATSAPP_HIPAA_COMPLIANT.md` §5 must stop claiming
R-2 and R-3 hold. A compliance document describing controls the code no longer enforces is the exact
failure PHI-5 exists to prevent, and this repository has already made that mistake once.

**Re-evaluation triggers:**

- **A US deployment.** This is defensible under LFPDPPP/DPDPA with consent; it is materially harder
  under HIPAA with no BAA. A `us` ComplianceProfile must revisit it.
- **A wrong-number incident** — clinical advice reaching someone with no relationship to the clinic.
- **An approved draft found to be clinically wrong.** The first one is the signal, not the tenth.
- **Meta signs a BAA**, which would remove most of the objection.

## Verification

1. No code path sends a draft without an `approved_by` set to a user holding a clinician role.
2. A draft containing a dose pattern is rejected before it reaches the inbox — asserted by test.
3. A red-flag message produces no draft and raises the urgent banner — asserted by test.
4. Every draft row carries model and prompt version.
5. `WHATSAPP_HIPAA_COMPLIANT.md` §5 no longer asserts R-2/R-3 unqualified.

## References

- [`docs/ai/WHATSAPP_AI_ASSISTED_REPLIES.md`](../ai/WHATSAPP_AI_ASSISTED_REPLIES.md) — research, options, decision table
- [`docs/security/WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) — §5 R-1…R-5
- [`ADR-066`](adr-066-whatsapp-keyword-auto-replies.md) — the fallback this narrows
- [`ADR-067`](adr-067-patient-name-in-whatsapp-templates.md) — the patient's name is already on this channel
- [`ADR-026`](adr-026-llm-provider-allowlist.md) · [`ADR-030`](adr-030-llm-curated-tool-access.md)
- [`CLAUDE.md`](../../CLAUDE.md) — Rule 6, Rule 7, Rule 9, §9.9

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-14 | Ashutosh (AI-assisted) | Initial version. Permits AI-drafted, clinician-approved clinical replies on WhatsApp, reversing R-2 and R-3 for this path and narrowing ADR-066's fallback; records the arguments made against each reversal and the five non-optional safety controls |
