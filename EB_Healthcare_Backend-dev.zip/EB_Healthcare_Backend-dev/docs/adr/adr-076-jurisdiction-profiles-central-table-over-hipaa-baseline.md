# ADR-076: Jurisdiction profiles become one central table over a HIPAA baseline, with the stricter of the two applied per field

**Doc status:** living · **Created:** 2026-09-18 by Divyanshu (AI-assisted) · **Updated:** 2026-09-18 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** **PROPOSED — awaiting Sarvesh-SocialAngel**, who authored ADR-018. No code moves until he agrees the shape.
- **Date:** 2026-09-18
- **Supersedes:** [ADR-018](adr-018-multi-jurisdiction-compliance.md) **points 1 and 5 only**. Points 2, 3 and 4 are kept and reaffirmed — see below.
- **Superseded by:** —
- **Related:** ADR-026 (LLM provider allowlist — the precedent that a vendor change needs review), CLAUDE.md §9.9 PHI-1 / PHI-3.

## Context

ADR-018 replaced a Mexico-only lock with pluggable compliance profiles. **That decision
was right and most of it still is.** Its points 2–4 have held well:

- point 2 — compliance-sensitive code reads `get_active_profile()` rather than
  branching on a jurisdiction string. Verified still true; there are no
  `if jurisdiction == "mx"` branches anywhere.
- point 3 — a deployment selects its market through `site_config.json`. Unchanged.
- point 4 — the frontend maps a profile code to display text. Unchanged.

Three things have changed since it was written.

### 1. The business requirement moved

ADR-018 point 5 says adding a market requires *"only: a new profile file + a new
Vercel deployment with the env var"*, and treats that as cheap. The requirement is
now **country expansion with no code change at all** — a clinic in a new country
should be onboardable without a release.

### 2. The compliance standard moved

The product now follows **HIPAA technical safeguards *and* local regulation**, not
local regulation alone. That has a mechanical consequence ADR-018 had no reason to
consider: where the two differ, the **stricter** applies — and the direction differs
per field (a longer retention is stricter; a shorter breach deadline is stricter).

Under that rule, two shipped values are already wrong:

| Field | Declared | HIPAA floor | Effective under "both" |
|---|---|---|---|
| `audit_retention_years` (mx) | 5 | 6 *(45 CFR 164.316(b)(2), TO BE CONFIRMED)* | **6** |
| `audit_retention_years` (in) | 3 | 6 | **6** |

⚠️ **The HIPAA figures in this ADR are proposed, not authoritative.** They need
confirming by whoever owns compliance before they are relied on.

### 3. Measurement: most of the register is not read by anything

Counted 2026-09-18 across the app, excluding `compliance/` itself and tests:

| Field | Readers |
|---|---|
| `llm_provider` | 10 — the only real enforcement |
| `primary_language` | 3 |
| `country_name`, `jurisdiction_code`, `audio_retention_days` | 1 each |
| **`privacy_law`, `healthcare_standard`, `display_badge`, `regulator`, `audit_retention_years`, `right_to_erasure`, `breach_notification_hours`, `consent_required`, `consent_type`, `ai_scribe_enabled`, `audio_provider`** | **0** |

**Eleven of nineteen fields are declared and never consulted** — including
`audio_provider`, the field naming who receives patient *audio*.

This matters more than the file layout. `right_to_erasure=True` is a statement that
patients may have their data deleted, which no code implements. CLAUDE.md PHI-3 names
exactly this failure, and NH-191 is a live instance of it.

## Decision

### The options

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | Keep one module per country (ADR-018 as written) | Reasoning lives beside each value; per-country git history | A new market needs a file **and** a resolver edit, so forgetting the second is a confusing runtime error. No side-by-side view — which is how India's 3-year retention went unnoticed against a 6-year floor. Needs a release |
| **B** | **One central table of jurisdictions, over a HIPAA baseline; an unconfigured country falls back to the baseline (chosen)** | One place to read and review, markets comparable side by side. A new country is a few lines, never a new module. **An unknown country is still safe**, because the floor applies. Who may receive PHI stays code-controlled | The per-value commentary now sits above a table rather than beside a field |
| **C** | A doctype, edited per site in the Desk | No developer needed for a new country | Anyone with Desk admin could change **who may receive patient data**, with no reviewer and no diff. And 50 Mexican clinics each entering the same legal facts guarantees drift |
| **D** | Full country facts in each site's `site_config.json` | Per-site, no release | **The facts are not per-site.** Every Mexican clinic answers to INAI in the same 72 hours; duplicating that across 50 sites means a law change is 50 edits |

### Chosen: B

**Why the others lose.** **A** is what exists, and its cost is no longer acceptable
against the new requirement — but note it is being changed because the *requirement*
moved, not because it was a poor decision in June. **C** loses on one specific field
class: the subprocessor list decides who receives PHI, and CLAUDE.md is explicit that
a wrong register is *"worse than none, because it will be relied on"*; a change to it
should require a reviewer. **D** loses on a point that is easy to miss — jurisdiction
facts are **product-level, not site-level**. Putting them per-site multiplies the same
truth by the number of clinics and invites them to disagree.

### The shape

```
HIPAA baseline (code)      the floor. Applies to every deployment.
        +
jurisdiction table (data)  local law: labels, regulator, deadlines, language
        =
effective profile          per field, whichever is STRICTER
```

- `site_config.json` keeps selecting the market, exactly as ADR-018 point 3 says.
- **An unrecognised jurisdiction code no longer raises** — it resolves to the HIPAA
  baseline. A clinic in a country nobody has configured yet still operates safely,
  and local specifics can be added afterwards. This is the change that makes
  "expand without a release" true rather than merely convenient.
- **Who may receive patient data stays in code**: `llm_provider`, `audio_provider`,
  `retrieval_providers`, `url_fetch_allowed`. The table may *select* from an approved
  set; it may not introduce a vendor. A new country is data; a new vendor is a review
  (ADR-026).

### The rule that comes with it

**A compliance field must have a reader.** A field that no code consults is either a
missing feature or dead weight, and today nobody can tell which. Without this rule,
B would deliver a tidier register of promises that still nothing keeps — which is a
worse outcome than A, because it would look better while meaning the same.

Each of the eleven unread fields gets a decision: implement it, or delete it.

## Consequences

- `compliance/profiles/mx.py` and `india.py` collapse into rows of a shipped table.
  No behaviour change for either market on day one, apart from the corrected
  retention values.
- `get_active_profile()` keeps its signature. Callers are unaffected — the four real
  consumers (`registration_form_extraction`, `services/ai.py` ×3,
  `patient_communication_consent`) need no change.
- A `stricter_of()` helper encodes the per-field direction (max for durations, min
  for deadlines, OR for rights). It is the only place that logic lives, and it is
  testable: a jurisdiction row **cannot** weaken the baseline.
- The frontend mapping (ADR-018 point 4) is unaffected.
- **Nothing in this ADR authorises a HIPAA compliance claim.** CLAUDE.md forbids it,
  and this changes nothing about that: "built to HIPAA technical safeguards" is the
  accurate phrasing, and no Business Associate Agreement status is asserted here.

⚠️ **Open, and blocking a related claim:** `docs/compliance/HIPAA_READINESS.md` records
BAAs as `MISSING · BLOCKING` and CLAUDE.md §11 says none is on file, while the team
states one is signed with the LLM vendors. One of those is stale. It needs the
signer's name and date, which only a person can supply, and it is not resolved by
this ADR.

## What would falsify this choice

- If jurisdiction facts turn out to genuinely vary **per clinic** rather than per
  country, D becomes right and B is wrong.
- If the eleven unread fields are deleted rather than implemented, the register
  shrinks to about six fields and the structural question stops mattering — A would
  be fine again at that size.
- If a regulator requires the register to be editable by a compliance officer without
  engineering involvement, C becomes necessary despite its cost, and the mitigation
  would be an approval workflow on the doctype rather than free editing.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-18 | Divyanshu (AI-assisted) | Initial proposal — supersedes ADR-018 points 1 and 5; adds the HIPAA baseline with stricter-of-the-two, and the rule that a compliance field must have a reader |
