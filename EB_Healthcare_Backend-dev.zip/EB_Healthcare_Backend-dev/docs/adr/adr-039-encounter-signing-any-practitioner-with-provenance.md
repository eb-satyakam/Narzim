# ADR-039: Any practitioner may sign an encounter; a new field records who actually did

**Doc status:** living · **Created:** 2026-08-10 by Divyanshu · **Updated:** 2026-08-10 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-08-07
- **Supersedes:** ADR-038's SIGNING restriction only (`docs/adr/adr-038-encounter-signing-assigned-practitioner-only.md`).
  ADR-038's CANCELLING restriction is explicitly **unchanged** — this ADR does
  not touch `cancel_encounter` or `_require_assigned_practitioner` as used
  there.
- **Superseded by:** —

## Context

ADR-038 restricted both `complete_encounter` (sign) and `cancel_encounter` to
the practitioner named in the encounter's own `practitioner` field, with no
admin override, because the signed note renders that practitioner's name and
licence as the one attesting to the visit — letting anyone else submit it
would forge that attestation.

ADR-038's own "Re-evaluation trigger" named the exact case that has now come
up: *"a clinic reporting notes stranded unsigned because the authoring
practitioner is unavailable"* — a covering practitioner picking up a
colleague's encounter (shift handoff, sick leave, a doctor stepping in
mid-clinic). Under ADR-038 that note is stuck in Draft until the originally
assigned practitioner is reachable, which is workflow-blocking for a routine
clinic-coverage scenario.

The forgery risk ADR-038 was guarding against is about **provenance**, not
about matching a scheduling field: a signed note is fine as long as it
honestly names whoever actually signed it. The `practitioner` field conflates
two different things — "who this visit was originally assigned/booked to" and
"who is professionally attesting to the clinical content" — and ADR-038 had
to treat them as one because there was nowhere else to record the second one.

## Decision

**Any practitioner may complete (sign) an encounter. A new field,
`custom_encounter_done_by` (Link → Healthcare Practitioner), records who
actually did it, and the signed report displays that practitioner — never
the originally assigned one, if they differ. Cancelling is untouched: still
assigned-practitioner-only, per ADR-038.**

1. New Custom Field on Patient Encounter: `custom_encounter_done_by` (Link,
   Healthcare Practitioner, read-only, no_copy, system-managed — mirrors
   `custom_encounter_end`'s pattern). Fixture:
   `remedisys_healthcare_ai/fixtures/custom_field.json` (package-level; the
   module-level copy is not the one Frappe loads).
2. `complete_encounter` drops `_require_assigned_practitioner(doc)` in favor
   of a new, looser `_require_any_practitioner(doc)`: the caller must still
   be linked to *some* Healthcare Practitioner record (Nurse/Front Desk still
   cannot sign — ADR-022 unaffected), but it no longer has to be the
   encounter's own assigned one. It returns the caller's Practitioner name.
3. Before `doc.submit()`, `custom_encounter_done_by` is stamped with that
   returned practitioner — same pattern already used for
   `custom_encounter_end` (set pre-submit so it persists with the document,
   guarded with `hasattr` until the fixture is migrated on a given site).
   `practitioner` itself is left untouched — it keeps meaning "originally
   assigned."
4. `cancel_encounter` keeps calling `_require_assigned_practitioner(doc)`
   exactly as ADR-038 left it. Voiding a colleague's record is a different,
   more destructive action than finishing your own coverage shift, and
   nothing here changes the case for keeping it assigned-only.
5. Frontend: `canSign` in `[id]/page.tsx` drops the
   `user.practitioner.name === encounter.practitioner` comparison — it now
   only requires the caller to hold the practitioner role and have a linked
   Practitioner record at all. `cancelEncounter`'s own gate (wherever it is
   separately checked) is untouched.
6. The signed report / print view reads `encounter_done_by_name` (resolved
   server-side alongside `encounter_done_by`) instead of the assigned
   `practitioner_name`, so the name and any future licence-number display on
   the note always match whoever actually signed.

## Alternatives Considered

1. **Keep ADR-038 as-is; solve stuck notes via reassignment.** ADR-038 itself
   suggested this ("the supported route is reassignment under the
   practitioner who actually saw the patient"). Rejected here because
   reassignment requires an explicit UI/workflow of its own and still
   presumes there is time to do it before signing — routine coverage
   (a colleague finishing a note between patients) doesn't have that
   friction budget, and reassignment permanently overwrites who the visit
   was originally booked under, which loses information this ADR's field
   preserves instead.
2. **Admin-only override, per ADR-038's Alternative 4 (countersigner
   model).** Narrower than what was asked for (only helps when an admin is
   available, not for peer coverage), and ADR-038 already rejected it as
   disproportionate without a real signal to build it. This ADR is that
   signal, generalized: any practitioner, not just an admin, and the
   provenance is a field rather than a second signature line.
3. **Overwrite `practitioner` itself with the signer instead of adding a
   field (chosen against).** Simpler — no fixture, no new field — but
   destroys the record of who the visit was originally assigned to, which
   both scheduling history and the "did the assigned doctor actually see
   this patient" audit trail depend on. Rejected in favor of keeping both
   fields with distinct meanings.

## Consequences

- Any practitioner (linked Healthcare Practitioner record, any specialty)
  can now sign any Draft encounter. Nurses, Front Desk, and a user with no
  linked Practitioner record still cannot — `_require_any_practitioner`
  keeps that bar.
- `practitioner` = originally assigned/booked practitioner (unchanged
  meaning). `custom_encounter_done_by` = who actually signed. They are the
  same value in the common case (the assigned doctor signs their own note)
  and diverge only on genuine coverage.
- Cancelling remains assigned-practitioner-only — a signed note still can
  only be voided by the practitioner named in `practitioner`, regardless of
  who actually completed it. (Open question, not resolved here: whether
  cancel should instead check `custom_encounter_done_by` once it's set. Left
  as assigned-only for now since no coverage scenario for *voiding* has been
  reported, matching this ADR's narrow scope.)
- Existing already-signed encounters have no `custom_encounter_done_by`
  (field didn't exist yet) — the signed-report display must fall back to
  `practitioner_name` when it's empty, not show a blank signature line.
- Files: `remedisys_healthcare_ai/fixtures/custom_field.json`,
  `api/v1/encounters/api.py`,
  `tests/encounters/test_encounters.py`,
  `Healthcare_next_app/src/app/(clinic)/encounters/[id]/page.tsx`,
  `Healthcare_next_app/src/components/narzim/encounter/encounter-screen.tsx`,
  `Healthcare_next_app/src/components/narzim/encounter/encounter-report.tsx`.
- Requires `bench migrate` (or fixture import) on every site to actually
  create the Custom Field — editing the fixture JSON alone does not touch a
  running site's database.

## Verification

- Existing `TestAdminCannotSignOrCancel` (ADR-038) must still pass for
  **cancel** — an `EB_Healthcare Admin` + `EB_Practitioner` user who is not
  the assigned practitioner still gets 403 from `cancel_encounter`.
- New test: a practitioner who is NOT the assigned one successfully signs a
  Draft encounter via `complete_encounter`, and the returned/reloaded
  document's `custom_encounter_done_by` equals the caller's Practitioner,
  while `practitioner` is unchanged.
- New test: a Nurse (no `EB_Practitioner` role / no linked Practitioner)
  still gets a permission error from `complete_encounter` — signing is
  "any practitioner," not "any authenticated user."
- Manual: sign an encounter as a covering practitioner; confirm the printed/
  signed report names the covering practitioner, not the originally
  assigned one.

## References

- ADR-038 — encounter signing/cancelling restricted to assigned practitioner
  (superseded here for signing only; its Re-evaluation Trigger names exactly
  this scenario)
- ADR-022 — nurse encounter draft write (unaffected — still save-only)
- Constitution §4 Rule 6 (physician in control), §12 fixtures path
  (package-level `fixtures/custom_field.json`, not the module-level copy)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-10 | Sarvesh | Initial version (header backfilled from git history) |
