# ADR-121: The Refund dialog shows the figure the server would pay, not its own calculation

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

The billing page's Refund dialog worked out a partial refund in the browser
(`components/billing/refund-dialog.tsx`):

- each line's discount and its share of the invoice discount;
- each line's tax percentage;
- rounding to the currency's unit.

It also split cash back from a waiver reversed. This was a careful copy of the server's rules
(`create_credit_note`, `_apply_partial_return_items`, `_prorate_invoice_discount`), but still a
second implementation. Any drift would show the clerk one figure and pay another: several taxes on
one item, a tax template that is not a plain percentage, a new rounding rule.

The appointment Refund dialog already avoided this with a server plan (ADR-114). The billing
dialog did not.

## Decision

The server answers "what would this refund be?" with the same code that issues the refund.

1. `create_credit_note` is split. The checks and the in-memory return document move into
   `_refundable_residue` and `_build_credit_note`. The refund saves that document;
   `credit_note_preview` builds it, calls `calculate_taxes_and_totals`, and reads its totals.
   It never saves.
2. New read-only endpoint `api/v1/billing/api.py::preview_credit_note` (Sales Invoice read; patient
   invoices only). It returns `{credit_total, cash_back, waiver_reversed, balance_withdrawn, base,
   item_discount, subtotal, invoice_discount, tax, rounding}`.
3. The dialog asks again whenever the selection changes, shows those figures, and holds Confirm
   while the answer is loading. Its own calculation is shown only until the answer arrives, or
   when the preview cannot be fetched, so a backend without the endpoint cannot block refunds.

## Alternatives Considered

1. **Keep the browser calculation; add tests that it matches.**
   - Pros: no new endpoint.
   - Cons: two implementations still. A test can only cover the setups someone thought of, and the
     drift cases are exactly the ones nobody thought of.

2. **Server preview built by the refund's own code (chosen).**
   - Pros: one implementation, so the figure shown is the figure paid. It reuses what the
     appointment refund already does. Read-only, with no schema change.
   - Cons: a round trip per selection change; Confirm waits for it.

3. **Show no amount until after the refund.**
   - Pros: nothing to drift.
   - Cons: the clerk confirms blind, and PHI-5's spirit says not to promise what we cannot state.

4. **Submit the refund as a draft, show it, then submit or discard.**
   - Pros: the exact document.
   - Cons: it writes a draft Credit Note on every look. Drafts can be left behind, and a draft holds
     a naming-series number.

## Consequences

- **Backend:**
  - `services/billing.py`: `_refundable_residue`, `_build_credit_note`, `credit_note_preview`.
    `create_credit_note` uses the first two; its behaviour is unchanged (all suites pass).
  - `api/v1/billing/api.py`: `preview_credit_note`.
- **Frontend:**
  - `app/api/billing/refund/preview/route.ts`;
  - `useRefundPreview`;
  - `types/billing.ts::RefundPreview`;
  - `refund-dialog.tsx`.
- **Tests:** new `tests/billing/test_credit_note_preview.py`. Each case previews, then refunds,
  and requires the two to agree to the cent.

## Verification

- `test_credit_note_preview.py`: 5 of 5, covering:
  - a full refund;
  - a partial refund with an invoice discount;
  - a part-waived refund;
  - an unpaid invoice (refused);
  - the endpoint.
- The reschedule and billing suites (153) fail only where `dev` already fails.

## References

- [ADR-114](adr-114-appointment-line-owns-its-money.md): the appointment refund plan, the same idea.
- [ADR-119](adr-119-a-rounding-residue-is-not-a-debt-or-a-waiver.md): rounding rules the preview applies.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted by the product owner ("yes") |
