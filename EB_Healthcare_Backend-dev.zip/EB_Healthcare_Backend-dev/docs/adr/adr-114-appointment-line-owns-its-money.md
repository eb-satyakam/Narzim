# ADR-114: Reschedule, cancel and refund act only on the appointment's own invoice line

**Doc status:** living · **Created:** 2026-09-30 by Divyanshu (AI-assisted) · **Updated:** 2026-09-30 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

A cheaper reschedule refunds the fee difference by returning an invoice line in full quantity at a
reduced rate (`services/billing.py::_create_reschedule_refund`). ERPNext returns each unit once, so
the line is used up and a later cancellation cannot refund the remainder (ACC-SINV-2026-00760:
1,000 paid, −420 returned 1 of 1 units). The line chosen is the first with quantity left, not the
appointment's (`services/billing.py:1998`). Cancelling an appointment with an unpaid invoice cancels
the whole invoice, including other lines (`api/v1/appointments/api.py:2470`). Invoices can carry
several appointments of one patient plus vaccines and medicines (22 such invoices on the dev site).
Full analysis and the 27 cases: [design note](../flows/RESCHEDULE_CANCEL_REFUND_LINES.md).

## Decision

Treat each appointment's invoice line as the only place its money lives. A reschedule replaces
that line, a cancellation refunds or removes that line, and no other line changes.

1. A cheaper reschedule returns the appointment's line in full, raises a replacement invoice for
   the new fee, pays it from that Credit Note, and pays out only the difference.
2. The line is always found by `reference_dn`, never by position.
3. Cancelling a paid appointment opens the Refund dialog with only its current line pre-selected.
4. Cancelling an unpaid appointment removes only its line when the invoice has others.
5. Legacy invoices whose line is already used up get a separate, accountant-approved
   "refund remaining" path — not built; it waits on that approval.
6. Revenue totals that count invoices at face value leave replacement invoices out; they re-bill
   money the original invoice already billed.

## Alternatives Considered

1. **Replace the appointment's line on reschedule (chosen).**
   - Pros: a later cancel is an ordinary refund; each appointment's money is on one line; uses
     ERPNext returns and reconciliation.
   - Cons: two invoices per cheaper reschedule; revenue totals must skip the replacement. The
     reconciliation step was proven on this bench (Frappe v16) before building.

2. **Add a value-based "refund remaining" (journal entry) for every case.**
   - Pros: fixes legacy invoices too; smaller change to the reschedule flow.
   - Cons: a second kind of refund in the books and reports; needs accountant sign-off; leaves the
     wrong-line bug (P2) in place. Kept only for the legacy invoices.

3. **Return a fraction of the line's quantity on reschedule (0.42 of 1).**
   - Pros: smallest change; the line keeps 0.58 refundable.
   - Cons: rejected by ERPNext for "Must be Whole Number" UOMs, which consultation items use.

4. **Leave it; handle cancellations by hand in Desk.**
   - Pros: no work.
   - Cons: front desk cannot do it; money owed to patients depends on someone with accounting
     access noticing.

## Consequences

- Code: `services/billing.py`, `api/v1/appointments/api.py`, `Appointment Reschedule Refund` gains a
  replacement-invoice field (patch, BE-9), tests in `tests/appointments/test_reschedule_payment.py`;
  revenue reports to be verified against the replacement invoice.
- Re-evaluate if ERPNext cannot allocate a Credit Note against a new invoice on this version, or if
  the accountant rejects the journal-entry path for legacy invoices.

## Verification

- A test: pay a two-line invoice, reschedule cheaper, cancel — the vaccine line is untouched and
  the full remaining fee is refunded.
- A test: cancel one appointment on an unpaid shared invoice — the other lines stay owed.

## References

- [Design note: reschedule, cancel and refund lines](../flows/RESCHEDULE_CANCEL_REFUND_LINES.md)
- [Reschedule delta invoice fix](../RESCHEDULE_DELTA_INVOICE_FIX.md)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-30 | Divyanshu (AI-assisted) | Accepted and implemented; decision 6 (revenue exclusion) added after the report check found the double count |
