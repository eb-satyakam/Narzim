# ADR-075: Narzim GPT becomes patient-aware through explicitly linked, permission-checked ids — the free-text patient-name block stays

**Doc status:** living · **Created:** 2026-09-17 by Divyanshu (AI-assisted) · **Updated:** 2026-09-17 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — decision taken 2026-09-17. Not yet implemented.
- **Date:** 2026-09-17
- **Supersedes:** the blanket patient-blindness of `services/phi_input_guard.py::assert_no_patient_identifier` **as applied to** `narzim_assistant.send_message`, and `prompts/narzim-assistant-v3.txt`'s opening claim of no record access. Both are **narrowed, not deleted** — see Decision.
- **Superseded by:** —
- **Drives:** [PR #493](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/493) (`EB_Healthcare_EHR`, frontend) and its `docs/backend-requests/NARZIM_GPT_FEATURE_HANDOFF.md`.
- **Inventory of what exists vs. what this needs:** [`docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md`](../ai/NARZIM_GPT_BACKEND_INVENTORY.md).
- **Related:** ADR-050 (domain scope gate — **unchanged and still enforced**), ADR-030 (curated tool registry; no raw SQL/Python/CRUD), ADR-026 (LLM provider allowlist), ADR-028 (Narzim as central AI platform).

## Context

Narzim GPT — the general assistant at `api/v1/narzim_assistant/` — is deliberately,
architecturally patient-blind. Three independent mechanisms enforce it, and they were
built that way on purpose:

1. **A hard input block, before transmission.** `services/narzim_assistant.py:444` calls
   `assert_no_patient_identifier(message)` as the *first* statement of `send_message` —
   ahead of document extraction, the scope gate, and any persistence. The comment above it
   states the reasoning plainly: the system prompt already tells the model to decline such
   questions, but that is *"a content control operating AFTER transmission — the provider
   has the name by the time the model decides not to use it."*
   `services/phi_input_guard.py:144` then raises `PermissionError` with user-facing copy
   reading, verbatim: *"Narzim GPT has no access to patient records, so nothing was sent and
   nothing was saved."*
2. **The system prompt.** `prompts/narzim-assistant-v3.txt` line 1: *"You have no access to
   any database, tool, patient record, or encounter — everything you need to answer is given
   to you directly in this conversation."*
3. **A separate assistant owns chart access.** The encounter copilot (`api/v1/ai/api.py`)
   holds the 38-tool `TOOL_REGISTRY` and runs inside a Patient Encounter, where
   `frappe.has_permission("Patient Encounter", "write", doc=encounter)` is already
   established and drives `allow_write`.

PR #493 adds **"Link patient"** and **"Link visit"** pickers to the Narzim GPT composer and
sends `context: {patient, encounter}` on every turn. Pointed at today's backend this does not
degrade gracefully — it **throws on every turn that names a patient**, and silently discards
the context on every turn that does not.

The product question was put to the team on 2026-09-17 and answered: **Narzim GPT may do
everything in that PR, patient access included.**

This ADR records that decision and — more importantly — the *shape* of it: precisely what is
relaxed, and what is emphatically not.

## Decision

**Narzim GPT becomes patient-aware and read-only, through explicitly linked ids, and only
through explicitly linked ids.**

1. **Identity arrives as a structured id, never as free text.** The pickers send
   `context.patient` / `context.encounter` (`Patient.name`, `Patient Encounter.name`). The
   chat message body remains the place where a patient must *not* be named.
2. **`assert_no_patient_identifier` is narrowed, not removed.** It keeps running on every
   turn. When `context.patient` is set, identifiers belonging to **that** patient are
   permitted in the message text; **every other patient's identifiers still throw**. With no
   context linked, behaviour is byte-for-byte what it is today.
   *Rationale:* the failure this guard exists to prevent is an **unauthorised** patient's data
   reaching a provider. A clinician who has already opened a patient through a
   permission-checked picker is not that failure. A clinician typing a *different* patient's
   name still is.
3. **Permission is checked server-side on the id, every turn.** A linked `patient` /
   `encounter` is authorised with `require_permission(...)` before a single tool runs. The
   picker is a convenience; it is never the authorisation.
4. **Read-only, via the existing registry.** Context turns call
   `ask_copilot_agent(..., tools=build_openai_tools(allow_write=False))`. No new tool
   implementations, and **no write tool is ever offered**. Narzim GPT must never write an
   encounter, a chart, or any clinical record. ADR-030 holds unchanged: no raw SQL, no
   arbitrary Python, no generic CRUD.
5. **A patient-only tool subset is required — and it is larger than feared.** Verified in
   code on 2026-09-17: **12 of the 15 read tools work with a patient and no encounter.**
   `get_previous_encounters` and `get_current_medications` reference `encounter` only as an
   exclusion filter (`{"name": ("!=", encounter)}`), so an empty string excludes nothing and
   they behave correctly. Only three genuinely require a visit and must be withheld when none
   is linked: `get_current_transcript`, `get_encounter_state`, `get_appointment_details` —
   the last two call `require_permission("Patient Encounter", "read", doc=encounter)` and
   `frappe.get_doc(...)`, which throw on `""`.
6. **A new prompt for context turns.**
   > **Correction, 2026-09-17 (implementation):** this clause originally named the
   > file `narzim-assistant-v4.txt`. That number was taken by the markdown prompt
   > before this was built, so the context prompts are
   > `narzim-assistant-context-v1.txt` (and `-v2` when markdown is on) — a separate
   > lineage, because v1–v4 are versions of the *no-data-access* prompt and both
   > lineages stay in use for different turns. **The decision is unchanged; only
   > the filename is.**

   v3's opening line — *"You have no access to any database, tool, patient record, or
   encounter"* — becomes false the moment a chart is linked, so a context turn cannot use it.
   v3 (and v4) stay in use for context-free turns, which is most of them. Note the frontend
   handoff's "prompt v2" is wrong twice over: v2 already exists and is superseded, and
   production loads v3.
7. **ADR-050's domain scope gate is untouched.** Clinical / platform / conversational only.
   Linking a patient does not widen which *topics* Narzim answers.
8. **The refusal copy changes with the code.** PHI-5 forbids stating in the UI something the
   code does not do; the text promising *"no access to patient records"* becomes false the
   moment this ships and must be rewritten in the same change.

## Alternatives considered

| Approach | Pros | Cons |
|---|---|---|
| **A. Keep Narzim blind; route patient questions to the encounter copilot** | Zero new risk; the split already works; no prompt, guard or doctype change | Rejects a shipped, stakeholder-approved UI; forces the clinician into an encounter to ask about a patient who may have no open visit; leaves PR #493's pickers dead on arrival |
| **B. Explicit-link-only, read-only, id-based (chosen)** | Keeps the pre-transmission guard that actually prevents leakage; authorisation is a real server-side permission check; reuses the audited 38-tool registry unchanged; degrades to exactly today's behaviour when nothing is linked | Needs a patient-only tool subset, a context-mode prompt, and new refusal copy — the largest of the code changes here |
| **C. Drop `assert_no_patient_identifier` entirely** | Simplest to build; a clinician can just type a name | Removes the only control operating *before* transmission. The guard's own comment explains why a prompt cannot do this job. Unacceptable under PHI-6 and Rule 10 |
| **D. Merge Narzim GPT into the encounter copilot** | One assistant, one prompt, one tool path, no duplication | The copilot is encounter-scoped by construction (`allow_write` derives from encounter write-permission); Narzim's whole value is answering *without* a visit. Far larger migration than the feature warrants, and would put 23 write tools one config mistake away from a general chat box |

**Why B, specifically.** C loses the one control that runs before anything is transmitted —
which is exactly why the guard sits on line 444 and not in the prompt. A is a refusal to build
agreed product, and its cost is borne by clinicians, not by us. D dissolves the distinction
that makes Narzim useful outside a visit and drags write tools into a general chat surface.

**What would falsify this choice:** if the patient-only tool subset had turned out to be very
small — roughly six tools or fewer — context answers would be too thin to be worth the safety
change, and routing to the encounter copilot (A) would be the better product. **This was
measured rather than assumed: the subset is 12 of 15, so the decision stands.** Re-open it if
that number falls below six as tools are added.

## Consequences

- `AI Narzim Assistant Message` gains `context_patient`, `context_encounter`,
  `sources_requested`, `sources_used`, `urls`, `library_doc_ids`, `template_used`,
  `reply_format`, plus a `references` child table. A Narzim thread can now contain
  PHI-derived answers, so its **retention and erasure path must cover it (PHI-4)** — today
  the threads are assumed PHI-free.
- `send_message_stream` (SSE) shares the contract and **must receive the same changes**, or
  the streaming and non-streaming paths diverge. The frontend handoff does not mention it.
- Context turns are subject to the minimum-necessary budget:
  `AI Settings.llm_context_token_budget` applies, with truncation logged (Rule 5 / PHI-6).
- Every context turn is an LLM call and must log to `AI Prompt Log` with prompt version and
  the context prompt's SHA (§9). Tool **names** only — never arguments or results (Rule 10).
- The new doctypes this PR also introduces (`AI Chat Template`, `AI Chat Template Section`,
  `AI Source Cache`, `AI Source Reference`, `AI Template Edit Session`) are **not decided by
  this ADR**. In particular, **Clinical Web (PubMed/NCBI, guideline hosts, arbitrary URL
  fetch) requires its own ADR and a `ComplianceProfile` update under PHI-1 before any
  outbound call is built** — a subprocessor the profile does not name must be refused.
- Tests required before this ships:
  - an unlinked turn still refuses a foreign patient identifier (today's behaviour intact);
  - a linked turn permits that patient's identifiers and still refuses a different patient's;
  - a linked id the session user cannot read is refused with `PermissionError`;
  - **no write tool is ever present** in the tools array for any Narzim turn;
  - a patient linked with no encounter offers 12 tools and none of the three visit-bound ones.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-17 | Divyanshu (AI-assisted) | Factual correction to §6 — the context prompt is `narzim-assistant-context-v1/v2`, not `v4` (that number went to the markdown prompt). Decision unchanged |
| 1.0 | 2026-09-17 | Divyanshu (AI-assisted) | Initial version — records the 2026-09-17 decision to make Narzim GPT patient-aware via linked, permission-checked ids |
