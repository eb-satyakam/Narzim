# ADR-101: Invoice detail returns the fields the printed invoice needs

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-29
- **Supersedes:** —
- **Superseded by:** —

## Context

The frontend's invoice view doubles as the printed invoice, and was redesigned to the Narzim mock's
invoice page (`EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`, Round 21). That
page shows an issue time, items grouped by category with a source line, the patient's phone, the
visit, who issued the invoice, and who took each payment. `get_patient_invoice` returned none of
these, though every one is already stored. Detail: `docs/architecture/INVOICE_DETAIL_PRINT_FIELDS.md`.

## Decision

Add read-only fields to `get_patient_invoice`: `posting_time`, `patient_mobile`, `issued_by`,
`visits[]`, per-item `item_group` / `reference_dt` / `reference_dn`, and per-payment `received_by` /
`received_at`. `visits` is a list — one invoice can bill several appointments.

## Alternatives Considered

1. **Frontend-only, show what already exists.**
   - Pros: no backend change.
   - Cons: no category grouping, no visit, no issue time, no "issued by" — the layout the user
     approved would be half empty. Rejected by the user, who chose both parts.
2. **Frontend fetches the extras itself** (Patient, Appointment, User per invoice).
   - Pros: no backend change.
   - Cons: impossible by design — the browser never calls Frappe directly (BFF, ADR-010), and every
     read must go through a whitelisted, permission-checked method. It would mean new BFF routes and
     methods for Patient/Appointment reads just to print an invoice, a wider surface than this.
3. **A separate `get_invoice_print` endpoint.**
   - Pros: keeps the detail response small.
   - Cons: two endpoints describing the same invoice would drift (the preview and the print are the
     same component). The extra fields are cheap.
4. **Extend `get_patient_invoice` (chosen).**
   - Pros: one response for view and print; additive, optional keys; existing consumers unaffected;
     same permission check and scope guard as today.
   - Cons: adds `patient_mobile` to the response — recorded below.

## Consequences

- `api/v1/billing/api.py`: `get_patient_invoice` and `_invoice_payment_entries` change; additive keys.
- `patient_mobile` joins the response, behind the existing Sales Invoice read permission and
  patient-customer guard. No visit reason or clinical content is added (PHI-6).
- Categories print as the clinic's own item-group names.

## Verification

- Live on `remedisis.localhost` — see the design doc's Verification section, updated with results.

## References

- `docs/architecture/INVOICE_DETAIL_PRINT_FIELDS.md`
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md` (Round 21)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
