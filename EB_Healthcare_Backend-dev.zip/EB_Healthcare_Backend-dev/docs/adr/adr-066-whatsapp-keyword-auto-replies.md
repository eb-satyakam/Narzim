# ADR-066: Build WhatsApp keyword auto-replies in-house, template-only

**Doc status:** living · **Created:** 2026-09-11 by Ashutosh (AI-assisted) · **Updated:** 2026-09-11 by Ashutosh (AI-assisted) · **Version:** 3.0

- **Status:** Accepted
- **Date:** 2026-09-11
- **Supersedes:** —
- **Superseded by:** —

> **Accepted 2026-09-11.** The open question about `cancel` has been answered: all three keywords
> send a portal link, and the direct-cancel keywords are retired. That answer depended on a defect
> found while writing this ADR and **now fixed** — portal cancellation notified nobody. See
> **Why `cancel` becomes a link after all**.

---

## Context

### What was asked for

Management requires a "WhatsApp chatbot". After scoping with the team, the requirement is
**auto-replies only** — no AI, no conversation memory, no patient data lookup:

| Patient sends | Clinic replies |
|---|---|
| `book` | a link to book in the portal |
| `cancel` | a link to cancel in the portal |
| `reschedule` | a link to reschedule in the portal |
| anything else | "this number is not monitored — call the clinic" |

### The third-party option was evaluated and rejected

[`frappe_whatsapp_chatbot`](../Discuss_frappe_whatsapp_chatbot.md) was downloaded, read, and
rejected without ever being installed. Two independent reasons: its **Commons Clause** licence
forbids inclusion in a product that is sold, and two of its technical defects (no consent check;
`commit()`/`rollback()` inside our transaction) cannot be turned off by configuration. That
evaluation is the input to this ADR, not a part of it.

### What already exists — and this is the part that reshapes the decision

**A keyword auto-reply mechanism is already live in this codebase.** It was not written for this
requirement and nobody raised it during scoping, but it has been running in
`integrations/whatsapp/chat_api.py` since before this discussion started.

`on_whatsapp_message_created` (line 158) does this on every inbound message:

```python
intent = _parse_intent(doc.get("message") or "")
if intent == "confirm":
    _handle_confirm(patient, company, conv_name)
elif intent == "cancel":
    _handle_cancel(patient, company, conv_name)
```

with the keyword sets at lines 20-21:

```python
_CONFIRM_KEYWORDS = {"1", "confirm", "confirmar", "si", "sí", "yes", "ok"}
_CANCEL_KEYWORDS  = {"2", "cancel", "cancelar", "no"}
```

So the question is **not** "should WhatsApp ever reply to a patient". It already does. The real
questions are narrower and more answerable: *which keywords do we add, what do the replies contain,
and what happens to everything that matches nothing*.

### Four constraints that bound the design

1. **R-1 (template-only outbound)** from
   [`WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) §5 is **enforced in
   code**, not merely written down. `phi_policy.refuse_free_form()` throws a `PermissionError`, and
   `send_chat_message()` calls it as its first statement. Free text is genuinely unreachable for a
   clinic-originated send.
2. **The existing auto-replies already comply with R-1** — `_handle_confirm` sends the
   `appt_confirm_ack_v1` template, `_handle_cancel` sends `appt_cancel_ack_v1`. Neither sends free
   text. This is the precedent we extend.
3. **R-3 (no send without recorded consent)** and **R-5 (every send audited)** are unchanged and
   must hold for anything new.
4. **Meta template creation is blocked today** — the `Narzim Care` display name is
   `PENDING_REVIEW`, and new templates cannot be approved until it clears.

---

## Decision

**Build the feature in `remedisys_healthcare_ai`, by extending the intent mechanism that already
exists, and reply with pre-approved Meta templates rather than free text.**

Concretely:

1. **Do not install `frappe_whatsapp_chatbot`**, and delete it from the bench so it cannot be
   installed by accident.

2. **Extend `_parse_intent()`** with the new keywords rather than adding a second, parallel
   responder. One inbound message must have exactly one place that decides what happens to it.

3. **Replies are templates, not free text.** R-1 is **not amended by this ADR.** This was the
   central choice and **Alternatives Considered** #1 explains why free text was rejected even though it would
   ship sooner.

4. **Keywords move into a doctype**, `Remedisys WhatsApp Auto Reply`
   (`keyword`, `language`, `template_name`, `enabled`), so staff can add wording without a
   deployment. The hardcoded `_CONFIRM_KEYWORDS` / `_CANCEL_KEYWORDS` sets migrate into it, so
   there is one list rather than two.

5. **All three keywords — `book`, `cancel`, `reschedule` — reply with a portal link**, and the
   direct-cancel keywords (`cancel`, `cancelar`, `no`, `2`) are retired from `_handle_cancel`. See
   **Why `cancel` becomes a link after all** below.

6. **An unmatched-message fallback is added**, and it is the most important part of this ADR for
   patient safety (see **The fallback** below).

7. **Ordering inside the handler is fixed and testable**, because getting it wrong is how a patient
   who opted out receives a message:

   ```
   inbound message
     → 1. STOP-word check  → revoke consent → SEND NOTHING, STOP HERE
     → 2. consent check (R-3)
     → 3. keyword match    → send the mapped template
     → 4. no match         → send the safety fallback (rate-limited)
   ```

8. **The portal URL is resolved per environment, never hardcoded** — see below.

### The link is configuration, not a constant

The reply has to contain a portal link, and the obvious implementation — writing
`https://mycare.narzim.com` into the approved Meta template — is wrong. A template's text is fixed
at approval time, so a hardcoded URL means a staging or local environment either points patients at
production or needs its own separately-approved template.

**The mechanism already exists and is already used.** `api/v1/admin/_helpers.py:180` resolves
frontend URLs from `site_config.json` for welcome and password-reset links:

| Key | Frontend | Local value |
|---|---|---|
| `patient_portal_url` | patient portal | `http://localhost:3003` |
| `portal_app_url` | staff EHR | `http://localhost:3000` |

Both keys were **absent from this site and were added on 2026-09-11**; before that,
`_portal_base_url()` silently fell back to a hardcoded `http://localhost:3003` — a pre-existing
defect affecting welcome and password-reset emails, recorded in `docs/KNOWN_ISSUES.md`. Setting the
keys retires that fallback here.

Three consequences that shape the implementation:

- **Use `patient_portal_url_configured()`, not `_portal_base_url()`.** The former returns `None`
  when unset; the latter substitutes a localhost default. A patient must never be sent a
  `localhost` link, so an unconfigured site sends **no link** rather than a broken one. The
  helper's own docstring already directs new callers this way.
- **The URL must be a template VARIABLE, and the body may not end with one.** Meta rejected three
  of our templates previously for exactly this. So `Puedes reservar tu cita aquí: {{1}}` is
  refused, and the URL has to sit mid-sentence:
  `Puedes reservar tu cita en {{1}} — inicia sesión para elegir tu horario.`
- **`phi_policy.py::_ALLOWED_PATHS` must gain the URL explicitly.** It currently permits five
  variables. A portal URL is not PHI, but widening that allowlist is a deliberate, reviewed act —
  it is the control that stops a variable carrying patient data to Meta, and it must not be
  widened as a side effect.

> **Known limitation, not a defect.** A `localhost` URL cannot be opened by the patient's phone.
> Locally you can verify that the right message goes to the right number with the right wording;
> clicking through needs a tunnel (ngrok/cloudflared) with `patient_portal_url` pointed at it.

### Why `cancel` becomes a link after all

The requirement asks for `cancel` → *"here is a link where you can cancel"*. My first reading
called that a regression, because `_handle_cancel()` (chat_api.py:745) already cancels the
appointment outright, sends an ack template, and **notifies the front desk**. Trading that for a
portal login looked like a step backwards.

Investigating the portal changed the conclusion. There are three cancellation paths, and they did
not behave alike:

| Path | Cancels? | Clinic notified? |
|---|---|---|
| Staff cancels in the EHR | yes | yes — `notify_cancelled()` |
| Patient texts `cancel` | yes | yes |
| **Patient cancels in the portal** | yes | **no — nobody was told** |

`cancel_my_appointment` cancels through core's `update_status()`, which writes the column with
`frappe.db.set_value`. That bypasses the document lifecycle, so the `Patient Appointment`
`on_update` hook never fired and **neither the in-app notification nor the WhatsApp template
reached anyone**. The staff path had hit the identical trap and solved it with an explicit
`notify_cancelled()` call; the portal was never given one.

**That defect is now fixed** (`api/v1/patient_portal/api.py`), with tests. Booking and rescheduling
from the portal needed no change — they go through `doc.insert()` / `doc.save()`, so the hook
already fired for them.

With the portal notifying correctly, the objection disappears and the link becomes the better
design:

- **One consistent behaviour.** All three keywords do the same thing — easy to explain to patients,
  easy to test, and no keyword that silently mutates clinical data.
- **It removes a live hazard.** `_CANCEL_KEYWORDS` contains `"no"`, and `_handle_cancel` has no
  confirmation step, so a patient replying "no" to any message cancels their next appointment.
  Routing through the portal makes that impossible.
- Nothing is lost but typing convenience, and the patient was going to sign in anyway to see which
  appointment they were cancelling.

> **Consequence to schedule:** retiring the direct-cancel path also retires
> `appt_cancel_ack_v1` and `_notify_front_desk_cancellation` from the WhatsApp path. The front desk
> still gets its notification — through `notify_cancelled()` on the portal cancel — but this must be
> verified before the keywords are removed, not assumed.

### How a message is matched — whole-word contains, reversed from exact

The first implementation required the message to **equal** a keyword. It was
wrong in the obvious case: asked what *"hey reschedule my appointment"* would do,
the answer was **nothing** — it fell through to the fallback. People write
sentences, and a bot that only understands bare words does not meet them there.
Changed 2026-09-11 on that report.

Matching is now **whole-word contains**, with two guards that raw substring
matching would not give:

| Message | Reply | Why |
|---|---|---|
| `hey reschedule my appointment` | reschedule | the point of the change |
| `quiero reagendar mi cita` | reschedule | same, in Spanish |
| `can I book an appointment?` | book | |
| `my bookkeeping is fine` | **fallback** | `book` is not a whole word here |
| `cancelar` vs `cancel` | separate rows | `\b` is Unicode-aware, so "cancel" does not match inside "cancelar" — the two keywords stay independent instead of one shadowing the other |
| `i want to reschedule not cancel` | **fallback** | two intents; see below |
| `hola` | fallback | |

**Ambiguity is answered by the fallback, never by a guess.** A message containing
two keywords that point at *different* templates has no honest single answer, and
guessing would send a cancellation link to someone explicitly saying they do not
want to cancel. Several keywords meaning the *same* thing is not ambiguous and
answers normally. Exact equality is still tried first: it is the common case and
cannot be ambiguous.

> **Known limitation, accepted.** Negation is not understood: *"please don't
> cancel my appointment"* matches `cancel` and replies with a cancellation link.
> The reply is a **link, not an action** — nothing is cancelled, and the patient
> simply does not use it — so the cost is a slightly confusing message rather than
> a clinical event. Detecting negation reliably across two languages is a real NLP
> problem, and Rule 9 says pipelines over agents. Revisit only if it is reported.

### The fallback, and the one narrow exception to R-3

Every inbound message that matches no keyword gets **no reply at all** today.

**USER STORY.** A mother texts the clinic number at 21:40: *"mi hijo tiene fiebre de 40"* → **the
system does** nothing; the message lands in a staff inbox nobody is reading until 08:00 → **the
database correctly contains** her message and an unread count → **she sees** a delivered tick and
reasonably concludes she has told the clinic about a child with a 40 °C fever.
**Consequence:** hours lost, because silence is indistinguishable from being heard.

The fallback exists to close that gap, and its text is the single most important string in the
feature. It must say the number is **not monitored** and give the clinic phone number.

**The exception.** R-3 refuses any send without a current consent record. The fallback is sent
**regardless of consent**, because:

- the patient initiated the exchange, so Meta's 24-hour window is open;
- it carries **zero PHI** — it is the same sentence for every recipient, including wrong numbers;
- it is a safety message whose entire purpose is to say *we are not listening*; and
- the alternative is silence, which is the harm being fixed.

**It is not sent when the message was a STOP word.** Replying to an opt-out is the one thing this
channel must never do — which is why the STOP check is step 1 and terminates the pipeline.

This is a deliberate, recorded, narrow carve-out from R-3, not an oversight. It is the only place
this ADR touches R-3.

#### The wording — and a claim we nearly made that was false

The first draft of this message said *"this number is not monitored."* **That is untrue.**
`chat_api.py::_notify_whatsapp_inbox()` raises an in-app notification to *every* WhatsApp staff
member, into a shared inbox any of them can pick up. The team does see inbound messages.

Writing "not monitored" would have been the mirror image of PHI-5 — telling a patient something
about our own behaviour that the code contradicts. What is actually true is narrower:

| | Reality |
|---|---|
| Does the team see it? | **Yes** — shared staff inbox, all WhatsApp staff notified |
| Can we reply about their health here? | **No** — Meta has signed no BAA (R-1, R-2) |
| Is it immediate, or for emergencies? | **No** — nobody watches it out of hours |
| Where can we talk properly? | **The patient portal**, which has monitored chat (`send_my_chat_message`) |

Agreed wording (`auto_reply_not_monitored_v1`), decided 2026-09-11:

> **es** — ¡Gracias por escribirnos! Nuestro equipo verá tu mensaje. Para ver tus citas o
> escribirnos de forma segura, entra a {{1}} y te respondemos ahí. Si es urgente, busca atención
> médica.
>
> **en_US** — Thanks for your message! Our team will see it. To view your appointments or message
> us securely, sign in at {{1}} and we'll reply there. If it's urgent, please seek medical care.

Three properties this wording has deliberately:

- **It contains no clinic phone number.** There isn't one on record (`Company.phone_no` is empty),
  and the portal is a better destination anyway: it is monitored, authenticated, and the one place
  we are permitted to discuss clinical detail.
- **It redirects to a channel that can actually answer.** "We're not listening" with nowhere to go
  is worse than silence; the portal's own chat is monitored by staff.
- **It keeps a safety line without pretending to be an emergency service.** "Si es urgente, busca
  atención médica" needs no phone number and does not promise a response time we cannot meet.

#### A separate live defect, and the rule that came out of trying to fix it

The enabled `Appointment Cancelled` template reads *"...Llámanos al {{3}} para reagendar"*, where
`{{3}}` is `company.phone_no` — which is empty, and `notifications.py` renders a missing value as
`""`. So a patient whose appointment was just cancelled is told **"Call us at&nbsp;&nbsp; to
reschedule."** It may not send at all, since Meta rejects empty parameters; unconfirmed, because the
template has never fired on any site.

The obvious fix — reword our config to *"Entra a {{3}} para agendar una nueva cita"* and point
`{{3}}` at `portal.url` — **was attempted on 2026-09-11 and reverted the same day**, because it
made things worse:

> **What the patient receives is META's approved template text.** Our `message_body` only mirrors
> it, for the Settings preview and the inbox snippet. The variables are **positional**. So changing
> our copy first left Meta's approved sentence still reading *"Llámanos al {{3}}"* while `{{3}}` had
> become a URL — producing **"Call us at http://localhost:3003 to reschedule."** Worse than the
> blank it was meant to fix.

**The rule, which applies to every template change including this ADR's own:**

```
change the template AT META  →  wait for approval  →  update our config to match
```

Never the other way round. `tests/whatsapp/test_portal_url_variable.py` now asserts that every
config's `message_body` equals its approved Meta template text, so this drift fails a test rather
than reaching a patient.

**Consequently the cancellation wording is NOT fixed yet.** It cannot be until a corrected Meta
template is approved, which is gated on the display-name review like everything else. The
`portal.url` variable is built, allowlisted and tested, but deliberately **used by no live config** —
a test guards that too, and is the one to delete when the first URL-bearing template is approved.

---

## What live testing found that tests did not

The feature was built with 54 passing tests and a simulated inbound path. It was
then exercised for real — a Meta test number (`+1 555 202 9644`), an ngrok tunnel
to a dev bench, and messages typed on a physical handset. **Four defects surfaced
in the first twenty minutes**, three of them invisible to any unit test, and all
four are the kind that reach a patient.

| # | Defect | Why no test caught it |
|---|---|---|
| 1 | `cancel` was **both** a consent-withdrawal word and a reply keyword | Two modules, each correct alone. The collision only exists in the composed path |
| 2 | A patient stored as `+91 8707672263` was never matched | Fixtures used clean E.164; humans type spaces |
| 3 | The retired `_handle_cancel` **shadowed** the new keyword and returned silently | The old path found no appointment and exited without error or log |
| 4 | Dates and times were sent raw — *"a las 15:01:00"* | Every screen showed the config as valid; the formatter only applies at send |

### Defect 1 in full, because it is the serious one

`STOP_WORDS` contained `cancel` and `cancelar`. Those are also the words the clinic
now publishes as the way to cancel an appointment. So a patient typing **"Cancel"**
about their visit had their WhatsApp consent **silently revoked**, received no
reply (the STOP guard suppresses replies, correctly), and would have been cut off
from every future clinic message — reminders, results, everything — **without ever
learning it happened**.

Observed on a real handset, not theorised.

**Resolution (decided 2026-09-12):** withdrawal keeps four unambiguous words —
`alto`, `baja`, `stop`, `unsubscribe`. `cancel`/`cancelar` are appointment
keywords only.

The cost is stated rather than hidden: someone who means *"stop messaging me"* and
types "cancel" now gets a portal link instead of being unsubscribed. That is worse
UX, and it is **recoverable** — they can type ALTO. Silent unsubscription is not
recoverable by the patient, because they never find out. A test now asserts no
withdrawal word is also a keyword, so the next overlap fails in CI.

### The general lesson, worth more than the four fixes

Every one of these lived **between** correct components. The consent module was
right. The keyword matcher was right. The composition was wrong — and only a real
message through the real path showed it.

Three of the four were already found the same way the day before (the STOP guard
and the consent gate were both documented in docstrings and absent from the code).
The pattern is consistent enough to name: **on this channel, prose in a docstring
is not a control, and a test that mocks the layer above cannot see the seam.**

---

## Alternatives Considered

1. **Free-text replies inside Meta's 24-hour window.**
   - Pros: no Meta approval needed, so it ships immediately rather than waiting on the
     `PENDING_REVIEW` display name. Wording can be corrected in minutes. Technically permitted —
     the patient's inbound message opens the window.
   - Cons: **requires amending R-1 and punching a hole in `refuse_free_form()`** — the single
     enforcement point that currently makes "template-only" true rather than aspirational. Once a
     caller can pass arbitrary text to `_send_free_text`, "no PHI on this channel" becomes a
     convention again instead of a control, and the next feature will widen the hole. Meta charges
     per conversation either way, so the saving is time, not money. Rejected: **we would trade a
     permanent structural guarantee for a few weeks of schedule.**

2. **Template replies, extending the existing `_parse_intent` mechanism (chosen).**
   - Pros: R-1 stays intact and enforced. Follows the pattern `_handle_confirm` already
     established, so there is one inbound decision point rather than two. Templates are reviewed by
     Meta, which is a second pair of eyes on anything patient-facing. Consent, audit, the 24-hour
     window, per-patient language and transaction safety are all inherited from code we already own.
   - Cons: blocked until the display-name review clears. Wording changes need Meta re-approval.
     Roughly 4 new templates × 2 languages to get approved.

3. **Adopt `frappe_whatsapp_chatbot`.**
   - Pros: a flow engine, a keyword matcher and 10 doctypes of admin UI, already written.
   - Cons: Commons Clause forbids use in a product that is sold, and forking does not help because
     the licence travels with the code. Two technical defects survive configuration. We would
     maintain 2,597 lines to use ~117. Fully argued in
     [the evaluation](../Discuss_frappe_whatsapp_chatbot.md).

4. **Meta's native Icebreakers and Commands.**
   - Pros: zero backend code; Meta renders the options in the WhatsApp UI itself; good
     discoverability for first-time senders.
   - Cons: **they do not reply.** Tapping one only sends that text to us — our backend still has to
     produce the answer, so this solves none of the problem. Worth adding later as a *presentation*
     layer on top of alternative 2, but it is not an alternative to it.

---

## Consequences

### Prerequisite — done 2026-09-11

Retiring the direct-cancel keywords routes every patient cancellation through the portal, and the
portal told nobody at the clinic. That is fixed and tested before any keyword changes:
`notify_front_desk_cancelled()` (`services/appointment_notifications.py`), a new
`appointment_cancelled_by_patient` event type, and the matching react-query invalidation in the
EHR's `use-notification-stream.ts`.

### Code to write

All inside `remedisys_healthcare_ai`. No third-party app, no core edits.

| Component | What it does |
|---|---|
| `Remedisys WhatsApp Auto Reply` (new doctype) | `keyword`, `language`, `template_name`, `enabled`. One row per keyword-language pair, editable in the Desk |
| `integrations/whatsapp/auto_reply.py` (new) | Match a keyword, resolve language, enforce the rate limit, send the template. Keeps the matching logic out of the already-large `chat_api.py` |
| `chat_api.py::on_whatsapp_message_created` | One call into the above, after the existing consent check |
| `_parse_intent` / `_CONFIRM_KEYWORDS` / `_CANCEL_KEYWORDS` | Direct-cancel retired; `_handle_cancel` and `_notify_front_desk_cancellation` go with it. Confirm is unaffected and stays |
| Seeding patch | Create-if-missing, never touch `enabled` — the pattern of `seed_whatsapp_notification_configs_20260910.py` |

### Meta templates — the wording is agreed, submission is blocked

All four carry exactly one variable, the portal URL (`portal.url`), placed **mid-sentence**: Meta
rejects a body that begins or ends with a variable, which is how three of ours were refused before.

| Template | es | en_US |
|---|---|---|
| `auto_reply_book_v1` | Puedes agendar tu cita en {{1}} — inicia sesión para elegir tu horario. | You can book your appointment at {{1}} — sign in to choose a time. |
| `auto_reply_cancel_v1` | Puedes cancelar tu cita en {{1}} — inicia sesión para verla. | You can cancel your appointment at {{1}} — sign in to view it. |
| `auto_reply_reschedule_v1` | Puedes reagendar tu cita en {{1}} — inicia sesión para elegir otro horario. | You can reschedule your appointment at {{1}} — sign in to choose another time. |
| `auto_reply_fallback_v1` | ¡Gracias por escribirnos! Nuestro equipo verá tu mensaje. Para ver tus citas o escribirnos de forma segura, entra a {{1}} y te respondemos ahí. Si es urgente, busca atención médica. | Thanks for your message! Our team will see it. To view your appointments or message us securely, sign in at {{1}} and we'll reply there. If it's urgent, please seek medical care. |

Named `auto_reply_fallback_v1`, **not** `..._not_monitored_v1`: the number *is* monitored, and a
template name that says otherwise would keep the false claim alive in the codebase.

**These cannot be submitted until the `Narzim Care` display-name review clears**, and per the
ordering rule above no config may reference a template before Meta has approved it. The code, the
doctype, the patch and the tests can all be built now; the rows ship **disabled**.

### Operational

- **Rate limit the fallback per phone number** — at most one per rolling 24 hours. Meta bills per
  conversation, and a patient sending five messages must not trigger five replies. Keyword replies
  are not rate-limited: those are a direct answer to a direct request.
- **Every reply is audited under R-5**, like any other send.
- **English is missing at Meta.** Only `es` exists for the current templates; `en_US` variants must
  be created in the same submission, or an English-speaking patient silently gets Spanish.

### Documentation, once the code is merged

- `WHATSAPP_HIPAA_COMPLIANT.md` §5: inbound keyword replies exist, are template-only, and therefore
  do not weaken R-1; R-3 records the fallback carve-out. Not written earlier, per PHI-5 — a document
  must not describe behaviour the code does not yet have.

**Re-evaluation triggers:**

- The requirement grows into multi-step conversational booking → re-cost **Alternatives Considered** #3, but only if
  its licence has also changed.
- Meta withdraws or restricts free-form-window replies → no effect, since we chose templates.
- The fallback generates complaints or cost → revisit rate limiting, not the safety text.

---

## Verification

The decision is in force when all of these are true:

1. `apps/frappe_whatsapp_chatbot` is absent from the bench, and
   `frappe.get_installed_apps()` does not list it on any site.
2. `grep -n "refuse_free_form" integrations/whatsapp/phi_policy.py chat_api.py` still shows the
   refusal intact and unmodified — proving R-1 was not weakened to ship this.
3. A test asserts a STOP word revokes consent and sends **nothing**.
4. A test asserts an unmatched message sends the fallback template exactly once.
5. All auto-reply sends appear in `WhatsApp Message` with a non-null `template`, and in the
   `View Log` audit trail (R-5).
6. No new row in any `ComplianceProfile` subprocessor list — this feature calls no external service
   beyond Meta, which is already registered.

---

## Remaining inputs (implementation, not design)

| # | Input | Status |
|---|---|---|
| 1 | Does management accept `cancel` becoming a link? | **Answered 2026-09-11 — yes.** Enabled by the portal-notification fix above |
| 2 | Clinic phone number for the fallback text | **Resolved 2026-09-11 — not needed.** No clinic number is on record, and the fallback redirects to the patient portal instead, which is monitored and authenticated. Note this does NOT resolve the separate `appt_cancelled_v2` defect above, which still renders an empty `{{3}}` |
| 3 | One portal URL or three deep links? | **Resolved 2026-09-11 — one configurable base URL.** Read from `patient_portal_url` per environment (see **The link is configuration, not a constant**). Deep links remain possible later by appending a path to the same base |

All three are now resolved. Implementation is unblocked; only Meta template **submission** remains
gated on the `Narzim Care` display-name review.

---

## References

- [`docs/Discuss_frappe_whatsapp_chatbot.md`](../Discuss_frappe_whatsapp_chatbot.md) — why the
  third-party app was rejected
- [`docs/security/WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) — §5 R-1,
  R-3, R-5
- [`ADR-060`](adr-060-patient-communication-consent.md) — the consent model
- [`CLAUDE.md`](../../CLAUDE.md) — §9.9 PHI-3/PHI-5/PHI-6, §10 four-approaches rule
- `integrations/whatsapp/chat_api.py:20-21, 118, 158-162, 707-776` — the existing mechanism
- `integrations/whatsapp/phi_policy.py:148` — `refuse_free_form()`

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.0 | 2026-09-12 | Ashutosh (AI-assisted) | Verified end-to-end on a Meta test number. Records four defects live testing found and tests did not — the `cancel` withdrawal/keyword collision that silently unsubscribed a patient, unmatched formatted phone numbers, the retired cancel path shadowing the new keyword, and raw dates/times in patient messages. Withdrawal words narrowed to alto/baja/stop/unsubscribe |
| 2.5 | 2026-09-11 | Ashutosh (AI-assisted) | Matching reversed from exact-equality to whole-word contains, so "hey reschedule my appointment" works; ambiguous two-intent messages go to the fallback rather than a guess. Also drops the per-row `language` column, which produced duplicate rows that behaved identically |
| 2.4 | 2026-09-11 | Ashutosh (AI-assisted) | Build spec firmed up: component table, all four template texts in both languages, one-per-24h fallback rate limit, and the prerequisite front-desk fix recorded as done. Fallback template renamed from `..._not_monitored_v1` to `auto_reply_fallback_v1` |
| 2.3 | 2026-09-11 | Ashutosh (AI-assisted) | Records the Meta-before-config ordering rule, learned by breaking it: rewording our copy while Meta's approved text was unchanged would have sent "call us at <URL>". `portal.url` is built and allowlisted but used by no live config until a matching template is approved |
| 2.2 | 2026-09-11 | Ashutosh (AI-assisted) | Fallback wording agreed. Drops the "not monitored" claim, which was false — inbound WhatsApp does reach a shared staff inbox — and redirects to the portal's monitored chat instead of a clinic phone number, which does not exist. Records a separate live defect: `appt_cancelled_v2` renders an empty `{{3}}` |
| 2.1 | 2026-09-11 | Ashutosh (AI-assisted) | Portal link resolved from `patient_portal_url` per environment rather than hardcoded; records the three constraints that follow (no localhost fallback, Meta's no-trailing-variable rule, explicit PHI allowlist widening) |
| 2.0 | 2026-09-11 | Ashutosh (AI-assisted) | **Accepted.** `cancel` now sends a portal link like the other two, and the direct-cancel keywords are retired — reversing v1.0's exclusion. Enabled by fixing portal cancellation, which notified nobody because `update_status()` bypasses the document lifecycle |
| 1.0 | 2026-09-11 | Ashutosh (AI-assisted) | Initial version. Build in-house, extend the existing `_parse_intent` mechanism, replies are templates so R-1 is not amended; `cancel` excluded because it already does more than a link |
