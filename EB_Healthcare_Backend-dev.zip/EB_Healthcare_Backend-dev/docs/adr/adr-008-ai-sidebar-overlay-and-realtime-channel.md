# ADR-008: AI capture UI is a floating overlay, not an in-form sidebar; realtime channel is derived per encounter

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** **Superseded** (the UI half) · Accepted (the channel half)
- **Date:** 2026-05-15 (decided) · **Recorded:** 2026-08-20 (retroactively)
- **Supersedes:** the in-form Frappe Desk sidebar described by `CLAUDE.md` Rule 8
- **Superseded by:** ADR-010 (`adr-010-nextjs-frontend-vercel.md`) for everything UI-related

> **Recorded retroactively, and deliberately short.** The hygiene audit (2026-08-20) found "ADR-008"
> cited by 8 files with no document. Unlike ADR-009, most of what ADR-008 decided is **no longer in
> force**: ADR-010 moved all clinical UI to Next.js, so the Frappe Desk overlay it specified was
> never built for production. This file exists so the citations resolve and so a reader knows which
> half still binds. It does not reconstruct a rationale nobody recorded.

## Context

Before ADR-010, the AI capture surface was to live inside the Frappe Desk Patient Encounter form.
`CLAUDE.md` Rule 8 required it to feel native ("it is not a plugin, overlay, or widget — it is part
of the form"). Two questions needed deciding: where the capture UI lives, and how the browser
subscribes to realtime transcript events for one encounter.

## Decision

1. **UI (superseded):** the capture surface is a floating overlay — FAB → popover → fullscreen —
   rather than an in-form sidebar. This deliberately relaxed Rule 8's "part of the form" wording for
   the AI surface specifically.
2. **Realtime channel (still in force):** each encounter gets its own channel name, derived from a
   single constant rather than assembled at call sites —
   `api/ai/auth.py::REALTIME_CHANNEL_PREFIX` + the encounter name. `publish_to_encounter()` is the
   only publisher.

## Alternatives Considered

Not recorded at the time. The audit found no document, no prompt archive entry, and no code comment
stating the alternatives. **Do not treat the absence as "there were none."**

## Consequences

- The UI decision is **dead**: ADR-010 replaced the Desk surface with the Next.js encounter screen,
  where the AI panel is a docked right-hand lane, not a FAB. Anything citing "ADR-008's design" for
  UI purposes is citing a superseded decision — cite ADR-010 instead.
- The channel decision is **live** and load-bearing: `api/ai/auth.py`, `api/ai/realtime.py` and
  `api/ai/sessions.py::_envelope` all derive the channel from `REALTIME_CHANNEL_PREFIX`.
- `CLAUDE.md` Rule 8 ("Frappe-Native UX") is now vestigial for clinical screens — it describes a
  Desk sidebar that no longer exists. **Flagged for the constitution's next revision.**

## Verification

| Claim | Artefact |
|---|---|
| One channel per encounter, one prefix constant | `api/ai/auth.py::REALTIME_CHANNEL_PREFIX`; used by `sessions.py::_envelope` and `realtime.py::publish_to_encounter` |
| The overlay UI is not in production | The live surface is `Healthcare_next_app`'s `copilot/CopilotPanel.tsx` with `variant="column"`, mounted as a docked lane |

## References

- ADR-010 (Next.js frontend) · ADR-009 (browser-direct audio)
- `CLAUDE.md` Rule 8 · `api/ai/auth.py` · `api/ai/realtime.py`
- `docs/audit/DOCUMENTATION_HYGIENE_AUDIT.md` §3

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Recorded retroactively; UI half marked superseded by ADR-010 |
