# ADR-017: Front-desk POS billing reuses native healthcare invoicing

**Doc status:** living · **Created:** 2026-06-26 by Invincible · **Updated:** 2026-06-26 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-06-26
- **Supersedes:** —
- **Superseded by:** —

## Context

Billing today is fragmented. A single visit can produce several invoices from
separate code paths:

- consultation → `create_appointment_invoice` (ADR-012, core `invoice_appointment`)
- vaccines → `create_vaccination_invoice` (Flow B)
- procedures / labs → would be yet another path

A patient with a consult + two vaccines walks out with up to three invoices and
three payments. That is wrong both for the front desk (three checkouts) and the
patient (three receipts). The correct clinic model is **one visit → one bill →
one payment**.

ERPNext Healthcare already implements exactly this model — but only in the
**Frappe Desk** (`/app`), which our front desk never opens (ADR-010: browser
talks only to our `api/v1/*` methods through the Next.js BFF). The native flow is:

1. `healthcare.utils.get_healthcare_services_to_invoice(patient, customer, company)`
   aggregates **every un-invoiced billable service** for a patient (appointments,
   encounters, lab tests, clinical procedures, inpatient, therapy, service
   requests, observations) — fee-validity / free-follow-up aware, and
   insurance-coverage aware.
2. `Sales Invoice.set_healthcare_services(checked_values)` (the Healthcare
   `SalesInvoiceMixin`, registered via `override_doctype_class` — not a core edit)
   appends one invoice line per service, each carrying `reference_dt/reference_dn`
   back to its source plus the full insurance-coverage block, and recomputes
   totals + the patient/payor split.
3. On submit, `set_invoiced` writes `invoiced = 1` back onto every source, so
   nothing is double-billed.

Two structural gaps stop our front desk from using this directly:

- **Desk-only.** The "Get Items From → Healthcare Services" dialog and the mixin
  live in the Desk; our front desk uses Next.js.
- **Immunization is not a billable source.** The native aggregator has zero
  references to immunization, which is why vaccine billing is custom
  (`list_billable_immunizations` + `create_vaccination_invoice`). Even the native
  dialog would not list a shot.

## Decision

Expose the native consolidated flow through two thin whitelisted methods — a
**point-of-sale checkout** for the Next.js front desk — and patch only the one
gap (vaccines). We **do not** build a parallel billing engine.

1. **`services.billing.get_patient_billables(patient)`** — the unified cart:
   - `customer = _ensure_patient_customer(patient)` (self-heals dangling links)
   - native `get_healthcare_services_to_invoice(patient, customer, company)`, each
     line tagged with a `group` (`consultation` / `lab` / `procedure` / …) for UI
   - **plus** `list_billable_immunizations(patient)`, normalised into the same
     `{reference_type, reference_name, service, rate, description, group:"vaccine"}`
     shape
   - returns `{ currency, lines: [...] }`

2. **`services.billing.create_pos_invoice(patient, lines, mode_of_payment=None,
   paid_amount=None, discount_amount=0, discount_percentage=0)`** — one Sales
   Invoice from the selected lines:
   - split selected lines by `reference_type`:
     - **healthcare lines** → core `set_healthcare_services(checked_values)`
       (inherits rate / income-account / reference / insurance logic)
     - **`Immunization` lines** → appended directly (same as
       `create_vaccination_invoice`), because native does not know vaccines
   - `submit()` → GL postings + `set_invoiced` write-back on every source
   - if `mode_of_payment` → `settle_invoice(...)` (core Payment Entry)
   - returns `{ sales_invoice, currency, grand_total, outstanding, payment_entry,
     lines }`

The two endpoints in `api/v1/billing/api.py` are thin wrappers, both gated by
`require_permission("Sales Invoice", "create")`.

**The existing per-service methods are kept** as building blocks
(`create_appointment_invoice`, `create_vaccination_invoice`, `settle_invoice`,
`collect_payment`). POS composes them; it does not replace them.

## Alternatives Considered

1. **Reuse native `set_healthcare_services` (chosen).**
   - Pros: inherits insurance coverage split, fee-validity skip, per-source
     income-account routing, write-back — all the hard, money-critical logic, for
     free; minimal new code.
   - Cons: couples us to a Healthcare *internal* mixin method (not a documented
     public API). Mitigated by a CI integration test (below) that fails loudly if
     an upstream upgrade changes the behaviour. The coupling is not new — we
     already call its sibling `get_healthcare_services_to_invoice`.

2. **Build our own line-builder in `services/billing.py`.**
   - Pros: no upstream coupling.
   - Cons: re-implements rate resolution, income-account routing, discount math,
     and insurance coverage by hand — exactly the logic native already gets right.
     Reinventing billing is how billing bugs (wrong GL account, double-charge)
     are born. Rejected.

3. **Custom POS / "Visit Invoice" doctype.**
   - Pros: bespoke fields.
   - Cons: duplicates the GL, breaks ERPNext reporting, violates Rule 1. Rejected.

## Consequences

- New code: `services/billing.py` (`get_patient_billables`, `create_pos_invoice`),
  `api/v1/billing/api.py` (two whitelisted wrappers).
- Frontend gains `GET /api/billing/pos?patient=` and `POST /api/billing/pos`, and
  a new front-desk **Checkout** screen (separate frontend task).
- No new doctypes, no migrations, no GL changes.
- Re-evaluate when insurance Pay-Now or partial-coverage settlement is introduced
  (POS already passes coverage fields through native, but the settle step assumes
  full patient-payable settlement, as ADR-012 does).

## Verification

- New CI integration test pinning the flow end-to-end: a patient with a
  consultation + two vaccines → `get_patient_billables` returns one cart →
  `create_pos_invoice` produces **one** submitted Sales Invoice with correct
  per-line `reference_dt/dn`, all sources `invoiced = 1`, and (with
  `mode_of_payment`) outstanding 0 + a Payment Entry. This test is the guard that
  makes the native-`set_healthcare_services` coupling safe.
- `bench run-tests --module remedisys_healthcare_ai.tests.billing.test_billing`.
- CI: ruff + mypy + install/uninstall gate on the PR.

## References

- CLAUDE.md §3 (API pattern), §4 Rule 1 (upgrade-safe), §9 (tests on
  persistence/safety), §10 (working style)
- ADR-010 (Next.js BFF), ADR-012 (appointment payment orchestration)
- Native: `healthcare.healthcare.utils.get_healthcare_services_to_invoice`,
  `healthcare.healthcare.custom_doctype.sales_invoice.SalesInvoiceMixin.set_healthcare_services`
- Existing: `services.billing.create_invoice_from_appointment`,
  `create_vaccination_invoice`, `_ensure_patient_customer`, `settle_invoice`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-26 | Sarvesh | Initial version (header backfilled from git history) |
