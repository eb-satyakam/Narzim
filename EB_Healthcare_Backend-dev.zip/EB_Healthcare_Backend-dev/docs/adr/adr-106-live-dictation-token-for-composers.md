# ADR-106: A dictation token for composers with no encounter

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

Two composers have a microphone and no encounter: the Narzim GPT chat and the template editor.

- The chat records a clip and uploads it through Frappe to `transcribe_audio`. ADR-009 says audio
  never reaches Frappe. The clinician sees no words until they stop.
- The template editor uses the browser's Web Speech API, which sends audio to the browser vendor.
  No `ComplianceProfile` names that vendor (PHI-1).
- A stakeholder reported "mic not working". English dictated on a site set to `es-MX` is
  transcribed as Mexican Spanish, because the language is the site's.

The encounter scribe already streams to Deepgram from the browser, with words appearing as they are
spoken. Its token comes from `start_session`, which needs an encounter, consent and a session row.
`mint_browser_token` needs none of those, but it copies the site's multichannel and diarization
settings, and multichannel asks for two-channel PCM that a plain microphone does not produce.

## Decision

Add `mint_dictation_token()`: one channel, no diarization, a 10-minute token, and a language chosen
by the server from the clinician's own language and the site setting
(`integrations/deepgram.py::_dictation_language`). Both composers use it through one frontend hook.

1. The method takes no arguments. The client cannot choose the model or the language (ADR-009).
2. It calls `_assert_declared()` first, so an undeclared audio vendor is refused (PHI-1, ADR-078).
3. The grant's comment is the fixed word "dictation". No user, encounter or patient is sent.
4. Nothing is stored on the server. The text exists only in the composer until the clinician sends.

## Alternatives Considered

1. **Reuse `mint_browser_token("")`.**
   - Pros: no backend change.
   - Cons: breaks on any site with multichannel on; diarizes a single speaker; keeps the language
     fault; writes an empty encounter into the audit comment.
2. **A dedicated method (chosen).**
   - Pros: parameters fit one person dictating; fixes the language fault for dictation; small.
   - Cons: a third place that requests a grant from Deepgram.
3. **Keep the batch upload and add a language parameter.**
   - Pros: smallest change to the chat.
   - Cons: audio still passes through Frappe, against ADR-009; no words until the clinician stops;
     does nothing for the template editor.
4. **A client-supplied language.**
   - Pros: the interface language is known in the browser.
   - Cons: ADR-009 gives that choice to the server; `User.language` already records it.
5. **An `AI Settings` field for the dictation language.**
   - Pros: an administrator can set it.
   - Cons: one value for a bilingual floor repeats the fault; a schema change.

## Consequences

- No consent gate. Consent under PHI-2 is the patient's, for recording a consultation. A clinician
  dictating their own question is not recording a patient. If a patient's voice is ever the
  subject, that is the encounter scribe, which keeps its gate.
- `transcribe_audio` stays for the encounter. The chat stops calling it.
- The frontend stops using the Web Speech API.
- Re-evaluate if dictation is used for long recordings, or if a third language is needed.

## Verification

- `tests/ai/test_dictation_token.py`: language choice, single channel, fixed comment, refusal when
  the vendor is undeclared, and refusal before the API key is looked for.
- The endpoint index lists `mint_dictation_token`.

## References

- ADR-009 (browser-direct audio), ADR-078 (PHI-1 at the provider), ADR-075 (Narzim GPT context)
- `CLAUDE.md` PHI-1, PHI-2, BE-10

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-104 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
