# ADR-027: Architecture Gap Remediation Roadmap & Scope Boundaries

**Doc status:** living · **Created:** 2026-07-16 by Invincible · **Updated:** 2026-07-16 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-16
- **Supersedes:** —
- **Superseded by:** —
- **Related:** ADR-016 (internal/external pharmacy), ADR-017 (front-desk POS consolidated billing), ADR-023 (cash drawer/shift — *Proposed, unbuilt*), ADR-024 (nurse-initiated billable procedure), ADR-025/026 (encounter opt-in + vaccine two-part billing). QA basis: `docs/qa/E2E_TEST_PLAN.md`, `docs/qa/QA_FINDINGS.html`.

## Context

An end-to-end QA pass across all 12 clinical features (see `docs/qa/E2E_TEST_PLAN.md`, 13 defects) plus a two-track architecture trace of the **revenue cycle** and **pharmacy/inventory** layers established the following facts about the current system, verified against the code on 2026-07-16.

The platform is a wrapper over ERPNext Healthcare + Accounting. It is strongest where it delegates to core (billing, Payment Entry, credit notes) and weakest where a clinic needs a **stateful operational layer core does not provide for free**: money-handling, supply chain, and clinical-safety rules. The gaps below are grouped by whether they are **genuine** (should exist, do not) or a **deliberate scope-out** already decided for outpatient-pediatric (external pharmacy, no in-house lab processing, no inpatient).

### Confirmed facts (with code evidence)

**Revenue cycle**
- Every invoice is a plain `Sales Invoice`; the `POS Invoice` doctype is never used and `is_pos` is never set by any builder. ADR-023's premise that consolidated checkout invoices are `is_pos=1` is **stale vs. current code**.
- Payments use core `Payment Entry` (`api/v1/billing/api.py::collect_payment`, `services/billing.py::settle_invoice`). No split-tender, no change/tender-given.
- **Cash Drawer / Shift has no backend.** Open/close shift, opening float, drawer transfers, and expected-vs-actual variance live entirely in browser `localStorage` (`Healthcare_next_app`: `lib/narzim/shift.ts`, `session.ts`, `cash-client.tsx`). There is no `api/v1/cash`, no `POS Opening/Closing Entry`, no `POS Profile` in the app. ADR-023 specifies the fix but is **Proposed / unbuilt**.
- **Insurance** provides coverage-split at invoice + policy CRUD (`api/v1/insurance/api.py`) but **claims are read-only** (`insurance/report.py`); no claim generation/submission, adjudication/EOB, remittance, or eligibility check.
- Pricing is `Item Price` + invoice-level discount only; no Pricing Rule engine. `Item Tax Template` is unused (header `Sales Taxes and Charges Template` only). `Fee Validity` (free follow-up window) is honored implicitly by core but not surfaced or configurable.
- Credit note / refund is **fully built and atomic** (`services/billing.py::create_credit_note`) — full returns only (no partial/write-off).

**Pharmacy / inventory**
- Inventory is essentially **absent as a first-class capability.** Drugs and vaccines are modeled as catalogue Items with `is_stock_item: 0` (`scripts/seed/seed_medications.py`, `patches/v0/seed_vaccine_catalog_20260716.py`).
- Drug dispensing has **no stock effect** — it is a billing line only (`overrides/encounter_orders.py`, `services/billing.py`). No `dispense` endpoint exists. This is consistent with the external-pharmacy model (ADR-016) — **a deliberate scope-out.**
- Vaccine administration has **no stock decrement and no batch/expiry tracking** — `lot_number` is free text on the Immunization doctype and vaccines are `is_stock_item: 0`, so a stock ledger is not even possible (`api/v1/immunizations/api.py`). This is **not** covered by the external-pharmacy scope-out because vaccines are administered in-house.
- Clinical Procedure consumables are the only real stock path, delegated to core, but shipped **OFF by default** (`api/v1/procedures/api.py`).
- No purchasing / supplier / receiving / stock reconciliation / reorder surface anywhere.

**Clinical safety & RBAC**
- No prescribing safety validators (allergy conflict, drug–drug interaction, pediatric weight-based dose bounds, duplicate therapy). **Correction (verified 2026-07-16):** the drug-interaction doctypes (`drug_interaction`, `allergy_interaction`, `medication_class_interaction`) are **NOT installed on this site** (`tabDrug Interaction` does not exist; no doctype JSON in the healthcare app) — there is **no native drug-interaction data source at all**. Only allergy data exists: `Patient.allergies` (free text) plus the `Allergy` doctype. Therefore the **allergy-conflict** check is buildable now against existing data, but **drug–drug interaction** and **pediatric dose-bounds** require a data source to be introduced first (curated dataset or new doctype) — they are not mere wiring.
- No immunization contraindication / duplicate-dose guard.
- Abnormal/critical vitals are stored with no flag.
- Nurse can create/edit Patient Encounters (should be Doctor-only) — RBAC over-privilege.
- No triage (`triage_level`), no Patient Assessment (developmental screening), and therapy is stashed in a SOAP blob rather than a first-class Therapy Plan (relevant given Rehab/Speech/Psychology departments).

## Decision

Adopt the following **prioritized remediation order** and **scope boundaries**. Priority is set by combined operational + compliance + clinical-safety risk, not feature count.

**Tier 1 — build before broad clinical go-live (release-blocking):**

1. **Cash Drawer / Shift backend** — implement `api/v1/cash` over native `POS Opening Entry` / `POS Closing Entry` per ADR-023, reconciled against real `Payment Entry` rows. Retire the `localStorage` mock. *Rationale: real pesos on a per-browser mock is the single highest operational/compliance risk in the product.*
2. **Prescribing safety validator** — gate encounter `drug_prescription` signing on clinical-safety checks. **Phase A (buildable now):** allergy-conflict against `Patient.allergies` + `Allergy` records. **Phase B (needs a data source first):** drug–drug interaction and pediatric weight-based dose bounds — the native interaction doctypes are not installed, so a curated dataset or a new doctype must be introduced. *Rationale: patient-harm class.* Gate e-prescribing go-live behind at least Phase A.
3. **Vaccine batch / lot / expiry tracking** — link `lot_number` to an ERPNext `Batch`, capture expiry, and block administration of an expired dose. *Rationale: in-house vaccine administration; NOM-036 compliance; not covered by the external-pharmacy scope-out.*

**Tier 2 — revenue integrity & clinical completeness:**

4. **Insurance claim submission & adjudication** — claim generation/submission, remittance/EOB posting, payor A/R (currently coverage-split + read-only status only).
5. **RBAC correction** — restrict Encounter create/write to Doctor; audit the validation-before-permission ordering that leaks record existence.
6. **Abnormal vitals / critical-lab flagging** and **immunization contraindication / duplicate-dose guard**.
7. **Fee Validity surfacing** and **Item Tax Template** wiring.

**Tier 3 — clinical breadth (schedule against pilot feedback):**

8. Triage (`triage_level`), Patient Assessment (developmental screening), first-class Therapy Plan, Pricing Rule engine, partial returns/write-offs.

**Scope boundaries (explicitly NOT gaps):**

- **Drug dispensing stock** is out of scope while the clinic runs the external-pharmacy model (ADR-016, `has_internal_pharmacy` default off). Revisit only if in-house pharmacy is enabled.
- **In-house lab processing** and **inpatient / ward / discharge** remain out of scope for outpatient-pediatric (per the Nurse role spec).

## Alternatives Considered

1. **Feature-count parity with ERPNext Healthcare (build everything).**
   - Pros: complete parity; nothing surprises a power user.
   - Cons: ignores the outpatient-pediatric scope; builds inpatient/lab/pharmacy surfaces the clinic will never use; slowest path to a safe pilot.

2. **Risk-prioritized remediation with explicit scope-outs (chosen).**
   - Pros: money/safety/compliance risks fixed first; deliberate scope-outs documented so they read as decisions, not omissions; smallest safe path to pilot.
   - Cons: some ERPNext capabilities stay dormant; requires discipline to resist scope creep.

3. **Ship current state, fix reactively after pilot.**
   - Pros: fastest to "live."
   - Cons: cash-drawer fiction and absent Rx safety are unacceptable to expose to a real clinic; a single mis-prescription or cash-variance dispute is a reputational/compliance event. Rejected.

## Consequences

- **New code:** `api/v1/cash/` (Tier 1.1); a prescribing-safety validator hooked on encounter save/submit (Tier 1.2); Batch/expiry wiring in `api/v1/immunizations/api.py` (Tier 1.3); insurance claim methods in `api/v1/insurance/api.py` (Tier 2.4).
- **ADR-023** moves from Proposed toward Accepted once 1.1 is implemented; its stale `is_pos=1` claim should be corrected.
- **RBAC:** Encounter permission rules tightened (supersedes the effective behavior tested in ADR-022's nurse-draft-write — confirm the intended boundary).
- **CONSTITUTION:** no section amended; this ADR records prioritization, not a locked-assumption change. Rule 6 (physician-in-control) and Rule 1 (no core modification) constrain all Tier-1 work — safety validators and cash entries wrap core, never patch it.
- **Re-evaluation triggers:** enabling in-house pharmacy (`has_internal_pharmacy=1`) reopens the drug-stock scope-out; adding a second clinic/company reopens the CC-vs-CPMX company-scope defect (QA DEF-07); moving to a market with e-claim mandates raises insurance (Tier 2.4) to Tier 1.

## Verification

- Tier 1.1: a `POS Closing Entry` exists per cashier shift and its totals reconcile to the sum of that shift's `Payment Entry` rows; no clinical/financial data in `localStorage`.
- Tier 1.2 Phase A: prescribing a drug matching a `Patient.allergies` entry is blocked/hard-warned (CS-01). Phase B (once a data source exists): an interaction pair returns a warning (CS-02); an out-of-range pediatric dose is flagged (CS-03).
- Tier 1.3: administering a vaccine decrements a `Batch` and an expired batch is refused; `lot_number` resolves to a real Batch, not free text.
- Tier 2.4: an `Insurance Claim` can be generated and submitted from a covered invoice and its status transitions on remittance.
- Regression: the QA smoke suite (P1 subset + CS-01…08) passes on every build.

## References

- QA test plan & defect log: `docs/qa/E2E_TEST_PLAN.md`, findings summary `docs/qa/QA_FINDINGS.html`
- ADR-016 (pharmacy fulfillment), ADR-017 (POS billing), ADR-023 (cash drawer — Proposed), ADR-024/025/026 (procedure/vaccine billing)
- Constitution: Rule 1 (no core modification), Rule 6 (physician-in-control), §Locked Assumptions (jurisdiction, external pharmacy)
- ERPNext Healthcare doctypes referenced: `drug_interaction`, `allergy_interaction`, `medication_class_interaction`, `triage_level`, `patient_assessment`, `therapy_plan`, `fee_validity`, `pos_opening_entry`, `pos_closing_entry`, `insurance_claim`, `batch`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-16 | Sarvesh | Initial version (header backfilled from git history) |
