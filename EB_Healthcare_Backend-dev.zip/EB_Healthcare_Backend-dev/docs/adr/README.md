# Architecture Decision Records — Index

<!-- INDEX: manual -->

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 6.13

Every ADR in this repository. Before this index existed all of them were orphaned — no document
linked to any of them (see [`../audit/DOCUMENTATION_HYGIENE_AUDIT.md`](../audit/DOCUMENTATION_HYGIENE_AUDIT.md) §6).

**Governing rules:** [`adr-043-adr-identity-is-the-filename.md`](adr-043-adr-identity-is-the-filename.md)
— an ADR's identity is its **filename**; numbers are historical labels. `CLAUDE.md` §9 — number
sequentially, use the template, **never edit a merged ADR: supersede it**.

> ### Cite the slug, not the number
> Write `adr-026-llm-provider-allowlist`, not "ADR-026". Fourteen numbers below identify two
> different decisions each (marked ⚠️); a bare number is ambiguous. Enforced by
> `scripts/check_adr_numbering.py` against `scripts/adr_known_defects.json`.

---

## Frozen collisions — fourteen numbers, two decisions each

Accepted permanently per ADR-042: renumbering would have meant editing merged ADRs and rewriting
~100 mechanically-unresolvable citations, trading a *visible* defect for an *invisible* one. Repair
is by supersession only.

| Number | Decision A | Decision B |
|---|---|---|
| **003** | `adr-003-no-core-modification.md` (2026-05-13) | `ADR-003-bff-pattern.md` (—) |
| **004** | `adr-004-frappe-v16-lock.md` (2026-05-13) | `ADR-004-no-core-docperm.md` (—) |
| **018** | `adr-018-multi-jurisdiction-compliance.md` (2026-06-30) | `adr-018-practitioner-appointment-visibility-and-coverage.md` (2026-06-30) |
| **020** | `adr-020-queue-derived-handoff-state.md` (2026-06-30) | `adr-020-vaccine-nurse-administration-handoff.md` (2026-07-03) |
| **026** | `adr-026-llm-provider-allowlist.md` (2026-07-13) | `adr-026-vaccine-two-part-billing-at-administration.md` (2026-07-15) |
| **027** | `adr-027-ai-copilot-credit-metering.md` (2026-07-13) | `adr-027-architecture-gap-remediation-roadmap.md` (2026-07-16) |
| **028** | `adr-028-narzim-central-ai-platform.md` (2026-07-13) | `adr-028-lab-parameter-master.md` (2026-07-20) |
| **030** | `adr-030-ai-patient-chat-persistence.md` (2026-07-23) | `adr-030-llm-curated-tool-access.md` (—) |
| **038** | `adr-038-narrative-documents-with-embedded-values.md` (2026-07-30) | `adr-038-encounter-signing-assigned-practitioner-only.md` (2026-07-31) |
| **061** | `adr-061-drive-to-patient-chart-move.md` (2026-09-09) | `adr-061-adr-and-md-per-unit-of-work.md` (2026-09-08) |
| **063** | `adr-063-drive-access-list.md` (2026-09-09) | `adr-063-clinical-command-center-reassign-and-stage-logging.md` (2026-09-09) |
| **065** | `adr-065-admin-practitioner-booking-user-permission-bypass.md` (2026-09-14) | `adr-065-permission-before-changes-and-docs-before-work.md` (2026-09-22) |
| **069** | `adr-069-open-us-jurisdiction.md` (2026-09-14) | `adr-069-admin-practitioner-booking-fixed-via-ignore-permissions.md` (2026-09-15) |
| **080** | `adr-080-report-type-templates-for-lab-extraction.md` (2026-09-22) | `adr-080-patient-import-session-and-llm-column-mapping.md` (2026-09-24) |

## Written retroactively on 2026-08-20

Three numbers were cited by production code and `CLAUDE.md` with no document. They now exist:

| Number | Why it mattered | Evidentiary status |
|---|---|---|
| **008** | AI capture UI + realtime channel derivation | UI half **superseded by ADR-010**; channel half live |
| **009** | **Browser-direct audio to Deepgram — the privacy basis of ambient recording**, asserted by `CLAUDE.md` §3 and `api/ai/sessions.py` and decided nowhere | Fully reconstructed and verified against the implementation |
| **040** | Consolidated invoice drawer, prescope modes, partial payment | Decision reconstructed from code; **§Context and §Alternatives left explicitly incomplete** — the author must finish them |

## Two directories

`docs/adr/` is canonical. `remedisys_healthcare_ai/docs/adr/` still holds
`ADR-003-bff-pattern` and `ADR-004-no-core-docperm`, whose numbers collide; they stay until
superseded (ADR-042 rule 6). `adr-001` and `adr-002` were relocated here on 2026-08-20 because
their numbers were free, so no renumbering was needed.

---

**Writing a new one:** copy [`adr-template.md`](adr-template.md). Next free number is **123**
(040 is taken by a written ADR; see ADR-042 on why numbers are never reused).

## The record

| # | Decision | Status | Date | File |
|---|---|---|---|---|
| 001 | EB_ Prefix for Custom Frontend Roles | — | — | [`adr-001-eb-role-naming.md`](adr-001-eb-role-naming.md) |
| 002 | All EB_ Roles Are Website User / No Desk Access | — | — | [`adr-002-website-user-only.md`](adr-002-website-user-only.md) |
| 003 ⚠️ | No modification of Frappe/ERPNext/Healthcare core; hooks + custom fields only | Accepted | 2026-05-13 | [`adr-003-no-core-modification.md`](adr-003-no-core-modification.md) |
| 003 ⚠️ | Next.js BFF Pattern (Backend-for-Frontend) | — | — | [`ADR-003-bff-pattern.md`](../../remedisys_healthcare_ai/docs/adr/ADR-003-bff-pattern.md) |
| 004 ⚠️ | Lock to Frappe v16 (not v15) | Accepted | 2026-05-13 | [`adr-004-frappe-v16-lock.md`](adr-004-frappe-v16-lock.md) |
| 004 ⚠️ | Never Add Custom DocPerm to Core System DocTypes | — | — | [`ADR-004-no-core-docperm.md`](../../remedisys_healthcare_ai/docs/adr/ADR-004-no-core-docperm.md) |
| 005 | Deploy on Frappe Cloud — suspend Rule 3 (service separation) for Phases 0–2 | Accepted | 2026-05-13 | [`adr-005-frappe-cloud-deployment-suspend-rule-3.md`](adr-005-frappe-cloud-deployment-suspend-rule-3.md) |
| 006 | Use MariaDB for CI; revisit Postgres lock | Accepted | 2026-05-13 | [`adr-006-mariadb-for-ci.md`](adr-006-mariadb-for-ci.md) |
| 007 | Lock jurisdiction to Mexico; defer US; drop India assumption | Accepted | 2026-05-16 | [`adr-007-jurisdiction-mexico.md`](adr-007-jurisdiction-mexico.md) |
| 008 | AI capture UI is a floating overlay, not an in-form sidebar; realtime channel  | Superseded | 2026-05-15 | [`adr-008-ai-sidebar-overlay-and-realtime-channel.md`](adr-008-ai-sidebar-overlay-and-realtime-channel.md) |
| 009 | Stream microphone audio browser-direct to Deepgram; audio never reaches Frappe | Accepted | 2026-05-15 | [`adr-009-browser-direct-audio-to-deepgram.md`](adr-009-browser-direct-audio-to-deepgram.md) |
| 010 | Next.js on Vercel as the clinical frontend; Frappe as headless backend engine | Accepted | 2026-06-03 | [`adr-010-nextjs-frontend-vercel.md`](adr-010-nextjs-frontend-vercel.md) |
| 011 | Authenticate via eb_frappe_jwt Bearer tokens (supersedes OAuth2 + SID) | Accepted | 2026-06-05 | [`adr-011-auth-eb-frappe-jwt.md`](adr-011-auth-eb-frappe-jwt.md) |
| 012 | Orchestrate Pay-Now booking by sequencing standard ERPNext documents | Proposed | 2026-06-15 | [`adr-012-appointment-payment-orchestration.md`](adr-012-appointment-payment-orchestration.md) |
| 013 | Introduce a Patient Feedback doctype for the satisfaction report | Proposed | 2026-06-19 | [`adr-013-patient-feedback-doctype.md`](adr-013-patient-feedback-doctype.md) |
| 014 | Onboarding and demo provisioning — sandbox-first hybrid | Proposed | 2026-06-22 | [`adr-014-onboarding-and-demo-provisioning.md`](adr-014-onboarding-and-demo-provisioning.md) |
| 015 | Internal Team Chat (staff-to-staff messaging) | — | — | [`adr-015-team-chat-messaging.md`](adr-015-team-chat-messaging.md) |
| 016 | Per-clinic internal/external fulfillment for pharmacy (and lab, therapy, proce | Accepted | 2026-06-23 | [`adr-016-internal-external-pharmacy-fulfillment.md`](adr-016-internal-external-pharmacy-fulfillment.md) |
| 017 | Front-desk POS billing reuses native healthcare invoicing | Proposed | 2026-06-26 | [`adr-017-frontdesk-pos-consolidated-billing.md`](adr-017-frontdesk-pos-consolidated-billing.md) |
| 018 ⚠️ | Pluggable compliance profiles — India and Mexico as first two markets | Accepted | 2026-06-30 | [`adr-018-multi-jurisdiction-compliance.md`](adr-018-multi-jurisdiction-compliance.md) |
| 018 ⚠️ | Practitioner appointment visibility and coverage reassignment | Accepted | 2026-06-30 | [`adr-018-practitioner-appointment-visibility-and-coverage.md`](adr-018-practitioner-appointment-visibility-and-coverage.md) |
| 019 | Bind encounter vaccines/exam/vitals to native ERPNext Healthcare | Proposed | 2026-06-30 | [`adr-019-encounter-native-binding.md`](adr-019-encounter-native-binding.md) |
| 020 ⚠️ | Patient queue uses derived room state, not a phantom status | Accepted | 2026-06-30 | [`adr-020-queue-derived-handoff-state.md`](adr-020-queue-derived-handoff-state.md) |
| 020 ⚠️ | Doctor → nurse vaccine administration handoff | Proposed | 2026-07-03 | [`adr-020-vaccine-nurse-administration-handoff.md`](adr-020-vaccine-nurse-administration-handoff.md) |
| 021 | Master-data CRUD goes through a generic whitelisted method, not `/api/resource | Proposed | 2026-07-02 | [`adr-021-master-data-crud-access.md`](adr-021-master-data-crud-access.md) |
| 022 | Nurse can save a full Patient Encounter draft; signing stays Doctor-only | Accepted | 2026-07-07 | [`adr-022-nurse-encounter-draft-write.md`](adr-022-nurse-encounter-draft-write.md) |
| 023 | Cash Drawer & Shift Reconciliation via native ERPNext POS entries | Proposed | 2026-07-09 | [`adr-023-cash-drawer-shift-reconciliation.md`](adr-023-cash-drawer-shift-reconciliation.md) |
| 024 | Nurse-Initiated Billable Procedure Recording | Proposed | 2026-07-10 | [`adr-024-nurse-initiated-billable-procedure.md`](adr-024-nurse-initiated-billable-procedure.md) |
| 025 | Encounter Opt-In Billing Selection and Two-Part Vaccine Charging | Proposed | 2026-07-15 | [`adr-025-encounter-opt-in-billing-and-two-part-vaccine.md`](adr-025-encounter-opt-in-billing-and-two-part-vaccine.md) |
| 026 ⚠️ | LLM provider is pluggable — approved allowlist, not a single-vendor lock | Accepted | 2026-07-13 | [`adr-026-llm-provider-allowlist.md`](adr-026-llm-provider-allowlist.md) |
| 026 ⚠️ | Vaccine Two-Part Billing — Product at Assignment, Administration at Dose | Proposed | 2026-07-15 | [`adr-026-vaccine-two-part-billing-at-administration.md`](adr-026-vaccine-two-part-billing-at-administration.md) |
| 027 ⚠️ | AI Copilot usage metering — credit-based subscription plans | Proposed | 2026-07-13 | [`adr-027-ai-copilot-credit-metering.md`](adr-027-ai-copilot-credit-metering.md) |
| 027 ⚠️ | Architecture Gap Remediation Roadmap & Scope Boundaries | Proposed | 2026-07-16 | [`adr-027-architecture-gap-remediation-roadmap.md`](adr-027-architecture-gap-remediation-roadmap.md) |
| 028 ⚠️ | Narzim — a separate, centrally-owned platform; Marley Health becomes a thin AI | Proposed | 2026-07-13 | [`adr-028-narzim-central-ai-platform.md`](adr-028-narzim-central-ai-platform.md) |
| 028 ⚠️ | Canonical Lab Parameter Master and Coverage-Based Template Reuse | Proposed | 2026-07-20 | [`adr-028-lab-parameter-master.md`](adr-028-lab-parameter-master.md) |
| 029 | AI Patient Clinical Summary | — | — | [`adr-029-ai-patient-clinical-summary.md`](adr-029-ai-patient-clinical-summary.md) |
| 030 ⚠️ | Persist the AI patient chat + capture answer feedback | Accepted | 2026-07-23 | [`adr-030-ai-patient-chat-persistence.md`](adr-030-ai-patient-chat-persistence.md) |
| 030 ⚠️ | Curated LLM Tool Access (refines Rule 4) | — | — | [`adr-030-llm-curated-tool-access.md`](adr-030-llm-curated-tool-access.md) |
| 031 | Runtime-editable prompts via AI Prompt Template | Accepted | 2026-07-23 | [`adr-031-ai-prompt-template-doctype.md`](adr-031-ai-prompt-template-doctype.md) |
| 032 | Match extracted lab parameters by analyte name, not by unit compatibility | Accepted | 2026-07-24 | [`adr-032-name-first-analyte-matching.md`](adr-032-name-first-analyte-matching.md) |
| 033 | The report summary supersedes the per-test lab summary — stored on the Lab Tes | Accepted | 2026-07-24 | [`adr-033-report-summary-supersedes-per-test-lab-summary.md`](adr-033-report-summary-supersedes-per-test-lab-summary.md) |
| 034 | Persist Narzim encounter chat in an encounter-scoped doctype | — | — | [`adr-034-encounter-chat-persistence.md`](adr-034-encounter-chat-persistence.md) |
| 035 | Narrative reports feed the patient-wide lab summary and the clinical summary | Accepted | 2026-07-25 | [`adr-035-narrative-reports-feed-stored-summaries.md`](adr-035-narrative-reports-feed-stored-summaries.md) |
| 036 | Tag Channel Provenance on Patient Portal Chat Messages, Both Directions | Superseded | 2026-07-29 | [`adr-036-patient-portal-chat-channel-provenance.md`](adr-036-patient-portal-chat-channel-provenance.md) |
| 037 | Portal Chat Is a Separate Thread, Independent of WhatsApp | Proposed | 2026-07-29 | [`adr-037-portal-chat-separate-thread.md`](adr-037-portal-chat-separate-thread.md) |
| 038 ⚠️ | Narrative documents with embedded lab values get verbatim capture plus a bound | Proposed | 2026-07-30 | [`adr-038-narrative-documents-with-embedded-values.md`](adr-038-narrative-documents-with-embedded-values.md) |
| 038 ⚠️ | Restrict encounter signing and cancelling to the assigned practitioner | Accepted | 2026-07-31 | [`adr-038-encounter-signing-assigned-practitioner-only.md`](adr-038-encounter-signing-assigned-practitioner-only.md) |
| 039 | Any practitioner may sign an encounter; a new field records who actually did | Accepted | 2026-08-07 | [`adr-039-encounter-signing-any-practitioner-with-provenance.md`](adr-039-encounter-signing-any-practitioner-with-provenance.md) |
| 040 | One consolidated New Sales Invoice drawer with prescope modes and per-invoice  | Accepted | — | [`adr-040-consolidated-invoice-drawer-with-prescope-modes.md`](adr-040-consolidated-invoice-drawer-with-prescope-modes.md) |
| 041 | My Work moves to single assignee + single assigner; doctors assign Nursing Tas | Accepted | 2026-08-18 | [`adr-041-single-assignee-and-nursing-task-assignment.md`](adr-041-single-assignee-and-nursing-task-assignment.md) |
| 042 | Government payment mode is a deferred receivable, not a waiver | Accepted | 2026-08-20 | [`adr-042-government-deferred-receivable-billing.md`](adr-042-government-deferred-receivable-billing.md) |
| 043 | An ADR's identity is its filename; historical number collisions are frozen, no | Accepted | 2026-08-20 | [`adr-043-adr-identity-is-the-filename.md`](adr-043-adr-identity-is-the-filename.md) |
| 044 | Let a clinician continue the report-scoped chat after Done, from the completed | Accepted | 2026-08-21 | [`adr-044-post-done-report-chat-continuation.md`](adr-044-post-done-report-chat-continuation.md) |
| 045 | Replace notification polling with SSE for in-app delivery and FCM for out-of-app push, behind a single `notify()` chokepoint | Accepted | 2026-08-24 | [`adr-045-push-notifications-fcm-and-sse.md`](adr-045-push-notifications-fcm-and-sse.md) |
| 046 | Store notification event keys with parameters, and give each delivery channel a distinct job | Accepted | 2026-08-26 | [`adr-046-notification-event-keys-and-channel-roles.md`](adr-046-notification-event-keys-and-channel-roles.md) |
| 047 | Clinical reporting is served by our own whitelisted APIs, not a BI tool | Proposed | 2026-08-25 | [`adr-047-reporting-engine-custom-apis-not-insights.md`](adr-047-reporting-engine-custom-apis-not-insights.md) |
| 048 | AI chat replies stream over SSE from the web worker, not via background jobs | Accepted | 2026-08-27 | [`adr-048-narzim-streaming-sse-not-background-jobs.md`](adr-048-narzim-streaming-sse-not-background-jobs.md) |
| 049 | Vaccines live in their own child table on Treatment Plan Template, not in `items` | Accepted | 2026-08-27 | [`adr-049-vaccines-in-treatment-plan-templates.md`](adr-049-vaccines-in-treatment-plan-templates.md) |
| 050 | Narzim general assistant is limited to clinical, platform and conversational turns via a classifier gate | Accepted | 2026-08-29 | [`adr-050-narzim-assistant-domain-scope-gate.md`](adr-050-narzim-assistant-domain-scope-gate.md) |
| 051 | AI transcript retention is indefinite, with a single authoritative configuration | Accepted | 2026-08-27 | [`adr-051-transcript-retention-indefinite-single-source.md`](adr-051-transcript-retention-indefinite-single-source.md) |
| 052 | Extract a multi-file lab upload in ONE call, then recover dropped documents with bounded per-file re-checks | Accepted | 2026-08-25 | [`adr-052-one-call-per-upload-with-bounded-recovery.md`](adr-052-one-call-per-upload-with-bounded-recovery.md) |
| 053 | An uploaded lab document is split: its values go into Objective, its interpretation never writes itself | Proposed | 2026-08-31 | [`adr-053-uploaded-lab-documents-split-into-note-and-consideration.md`](adr-053-uploaded-lab-documents-split-into-note-and-consideration.md) |
| 054 | Ship the encounter as a 3-step flow that reuses the V1 components | Accepted | 2026-08-26 | [`adr-054-three-step-encounter-flow-reusing-v1-components.md`](adr-054-three-step-encounter-flow-reusing-v1-components.md) |
| 055 | The signed report is the attestation gate — Sign & Close previews, Sign & finish submits | Accepted | 2026-09-01 | [`adr-055-sign-then-acknowledge-before-submit.md`](adr-055-sign-then-acknowledge-before-submit.md) |
| 056 | Consent for AI recording becomes server-derived evidence, V3 only | Accepted | 2026-09-03 | [`adr-056-consent-server-derived-evidence.md`](adr-056-consent-server-derived-evidence.md) |
| 057 | Recognise a returning patient by tiered matching, and reveal nothing while doing it | Proposed | 2026-09-03 | [`adr-057-patient-duplicate-match-blind-claim-and-verify.md`](adr-057-patient-duplicate-match-blind-claim-and-verify.md) |
| 058 | Read a photographed registration form with the existing vision pipeline, as a proposal only | Proposed | 2026-09-03 | [`adr-058-registration-form-vision-extraction.md`](adr-058-registration-form-vision-extraction.md) |
| 059 | A stale `Recording` session resumes or is superseded — it never deadlocks the encounter | Accepted | 2026-09-04 | [`adr-059-stale-recording-session-resume-or-supersede.md`](adr-059-stale-recording-session-resume-or-supersede.md) |
| 060 | Patient Communication Consent as a doctype, and the send-path gate that reads it | Accepted | 2026-09-04 | [`adr-060-patient-communication-consent.md`](adr-060-patient-communication-consent.md) |
| 061 ⚠️ | Moving a Narzim Drive file onto a patient chart — copy the bytes, trash the source | Accepted | 2026-09-09 | [`adr-061-drive-to-patient-chart-move.md`](adr-061-drive-to-patient-chart-move.md) |
| 061 ⚠️ | Every unit of work produces an ADR and a companion mechanism doc, not only architecturally-significant changes | Accepted | 2026-09-08 | [`CLAUDE.md §9`](../../CLAUDE.md#9-cross-cutting-standards) |
| 062 | Practitioner self-service availability, built on core's Practitioner Availability doctype | Proposed | 2026-09-08 | [`adr-062-practitioner-self-service-availability.md`](adr-062-practitioner-self-service-availability.md) |
| 063 ⚠️ | Sharing a Drive entry is a set, not a stream of grants — and changing it needs write | Accepted | 2026-09-09 | [`adr-063-drive-access-list.md`](adr-063-drive-access-list.md) |
| 063 ⚠️ | Clinical Command Center — inline reassignment, per-room stage logging, and role-based tips | Accepted | 2026-09-09 | [`adr-063-clinical-command-center-reassign-and-stage-logging.md`](adr-063-clinical-command-center-reassign-and-stage-logging.md) |
| 064 | LLM-phrased operational suggestions (queue congestion + cross-clinic workload) — numbers in, one sentence out, no PHI (narrowly supersedes ADR-063 §"Role-based tips") | Proposed | 2026-09-10 | [`adr-064-queue-tips-llm-summary.md`](adr-064-queue-tips-llm-summary.md) |
| 065 ⚠️ | Admin-practitioner booking bypasses the practitioner User Permission via a reassignment-style write, not `ignore_permissions=True` | Accepted | 2026-09-14 | [`adr-065-admin-practitioner-booking-user-permission-bypass.md`](adr-065-admin-practitioner-booking-user-permission-bypass.md) |
| 065 ⚠️ | Explicit permission before any repo change, and a doc + ADR before non-trivial work | Accepted | 2026-09-22 | [`adr-065-permission-before-changes-and-docs-before-work.md`](adr-065-permission-before-changes-and-docs-before-work.md) |
| 066 | WhatsApp keyword auto-replies built in-house, template-only — the third-party chatbot app is licence-blocked | Accepted | 2026-09-11 | [`adr-066-whatsapp-keyword-auto-replies.md`](adr-066-whatsapp-keyword-auto-replies.md) |
| 067 | WhatsApp templates may carry the patient's name — a pseudonymous disclosure to Meta becomes an identified one | Accepted | 2026-09-12 | [`adr-067-patient-name-in-whatsapp-templates.md`](adr-067-patient-name-in-whatsapp-templates.md) |
| 068 | AI-drafted clinical replies on WhatsApp, approved by a clinician before sending — reverses R-2 and R-3 | Accepted | 2026-09-14 | [`adr-068-ai-drafted-whatsapp-clinical-replies.md`](adr-068-ai-drafted-whatsapp-clinical-replies.md) |
| 069 ⚠️ | Admin-practitioner booking fixed via `ignore_permissions=True` — supersedes ADR-065's write-through mechanism, which broke booking outright | Accepted | 2026-09-15 | [`adr-069-admin-practitioner-booking-fixed-via-ignore-permissions.md`](adr-069-admin-practitioner-booking-fixed-via-ignore-permissions.md) |
| 069 ⚠️ | Open US scope as a third jurisdiction, with the cell as the unit of jurisdiction — supersedes ADR-018's India/Mexico-only lock | Accepted | 2026-09-14 | [`adr-069-open-us-jurisdiction.md`](adr-069-open-us-jurisdiction.md) |
| 070 | Concurrent open Patient Vaccine rounds — a still-open vaccine order no longer reuses or blocks, it opens a separate round | Accepted | 2026-09-15 | [`adr-070-concurrent-open-vaccine-rounds.md`](adr-070-concurrent-open-vaccine-rounds.md) |
| 071 | Patient-wide total pending balance via a real (never-saved) draft invoice — and the item-tax bug in `create_pos_invoice` it surfaced and fixed | Accepted | 2026-09-16 | [`adr-071-patient-total-pending-and-item-tax-fix.md`](adr-071-patient-total-pending-and-item-tax-fix.md) |
| 072 | Reschedule/reassign delta invoices were silently dropping tax, and Patient 360 could only ever show one invoice per appointment | Accepted | 2026-09-16 | [`adr-072-reschedule-delta-invoice-tax-fix-and-invoice-trail-visibility.md`](adr-072-reschedule-delta-invoice-tax-fix-and-invoice-trail-visibility.md) |
| 073 | Billing/appointment mutations never invalidated the Billing tab, checkout cart, or Command Center payment tile — and the invoice success screen never showed what was actually paid | Accepted | 2026-09-16 | [`adr-073-billing-cache-invalidation-and-paid-amount-display.md`](adr-073-billing-cache-invalidation-and-paid-amount-display.md) |
| 074 | "Pay Now" silently did nothing once a visit's own invoice was settled but the patient had other unbilled items — and reschedule delta invoices never carried a practitioner | Accepted | 2026-09-16 | [`adr-074-pay-now-dead-end-and-missing-practitioner-on-delta-invoices.md`](adr-074-pay-now-dead-end-and-missing-practitioner-on-delta-invoices.md) |
| 075 | Narzim GPT becomes patient-aware through explicitly linked, permission-checked ids — the free-text patient-name block stays | Accepted | 2026-09-17 | [`adr-075-narzim-gpt-patient-aware-context.md`](adr-075-narzim-gpt-patient-aware-context.md) |
| 076 | Jurisdiction profiles become one central table over a HIPAA baseline, with the stricter of the two applied per field | **Proposed** | 2026-09-18 | [`adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md`](adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md) |
| 077 | Clinical Web is enabled — NCBI/PubMed as a named retrieval host, and clinician-pasted links, with the address itself screened | Accepted | 2026-09-18 | [`adr-077-clinical-web-outbound-retrieval.md`](adr-077-clinical-web-outbound-retrieval.md) |
| 078 | PHI-1 is enforced at the provider chokepoints and at the save, not in one feature | Accepted | 2026-09-18 | [`adr-078-phi1-enforced-at-the-provider-chokepoints.md`](adr-078-phi1-enforced-at-the-provider-chokepoints.md) |
| 079 | External fetches are stored, for reproducibility rather than speed, with the retention number as the switch | Accepted | 2026-09-18 | [`adr-079-ai-source-cache-stored-for-reproducibility.md`](adr-079-ai-source-cache-stored-for-reproducibility.md) |
| 080 ⚠️ | A template per report type, chosen by the model and created when missing | Accepted | 2026-09-22 | [`adr-080-report-type-templates-for-lab-extraction.md`](adr-080-report-type-templates-for-lab-extraction.md) |
| 080 ⚠️ | A persisted `Patient Import Session` so a 1000-row import survives a refresh, with the LLM mapping column HEADERS only — never patient rows | Accepted | 2026-09-24 | [`adr-080-patient-import-session-and-llm-column-mapping.md`](adr-080-patient-import-session-and-llm-column-mapping.md) |
| 081 | A structured subject (site + side) on every report, and summaries shaped by the report's own template | Accepted | 2026-09-22 | [`adr-081-report-subject-and-template-driven-summaries.md`](adr-081-report-subject-and-template-driven-summaries.md) |
| 082 | The AI describes a medical image, in its own field, and never diagnoses it | Accepted | 2026-09-22 | [`adr-082-ai-image-observations.md`](adr-082-ai-image-observations.md) |
| 083 | Every extracted measurement carries its side, and the de-duplicator respects it | Accepted | 2026-09-22 | [`adr-083-per-parameter-side.md`](adr-083-per-parameter-side.md) |
| 084 | Capture the warnings a report prints about its own results | Accepted | 2026-09-22 | [`adr-084-report-printed-warnings.md`](adr-084-report-printed-warnings.md) |
| 085 | Look at the pictures in every report, not only in reports that are nothing but pictures | Accepted | 2026-09-22 | [`adr-085-image-observations-on-every-document.md`](adr-085-image-observations-on-every-document.md) |
| 086 | A measurement report is a third kind of document, not a lab panel with missing ranges | Accepted | 2026-09-23 | [`adr-086-measurement-reports-are-not-lab-panels.md`](adr-086-measurement-reports-are-not-lab-panels.md) |
| 087 | Keep the model's structured transcription; substitute the raw text layer only when it failed | Accepted | 2026-09-23 | [`adr-087-keep-the-models-structured-transcription.md`](adr-087-keep-the-models-structured-transcription.md) |
| 088 | An image is read from what it shows — a report template is a suggestion, and an unlabelled image gets none | Accepted | 2026-09-23 | [`adr-088-images-read-from-what-they-show.md`](adr-088-images-read-from-what-they-show.md) |
| 089 | A body site is recorded only when printed words name it — a site read from a picture is a suggestion | Accepted | 2026-09-23 | [`adr-089-body-site-needs-printed-evidence.md`](adr-089-body-site-needs-printed-evidence.md) |
| 090 | Image observations say everything visible, and every finding is graded Clear or Possible | Accepted | 2026-09-24 | [`adr-090-image-observations-graded-not-restricted.md`](adr-090-image-observations-graded-not-restricted.md) |
| 091 | Images are reviewed systematically, read by a stronger model, and summarised briefly in plain words | Accepted | 2026-09-24 | [`adr-091-images-reviewed-systematically-by-a-stronger-model.md`](adr-091-images-reviewed-systematically-by-a-stronger-model.md) |
| 092 | Report prompts are stored per test, a template is generated from the prompt, and the clinician approves both before extraction | Accepted | 2026-09-24 | [`adr-092-report-prompts-reviewed-before-extraction.md`](adr-092-report-prompts-reviewed-before-extraction.md) |
| 093 | Staff push banners name the patient, resolved from our own origin rather than sent through Google | Accepted | 2026-09-26 | [`adr-093-patient-name-in-staff-push-banners.md`](adr-093-patient-name-in-staff-push-banners.md) |
| 094 | Every clinical list offers every Patient field the user may read as a column, permlevel-filtered and name-validated server-side | Accepted | 2026-09-24 | [`adr-094-user-selectable-list-columns.md`](adr-094-user-selectable-list-columns.md) |
| 095 | Encounter Canvas stores both editable stroke data and a rendered PNG, one derived from the other | Superseded by 097 | 2026-09-28 | [`adr-095-encounter-canvas-storage-format.md`](adr-095-encounter-canvas-storage-format.md) |
| 096 | Encounter Canvas and Encounter Advice surface through Patient Encounter custom fields, not their own PMR rows | Accepted | 2026-09-28 | [`adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md`](adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md) |
| 097 | Encounter Canvas stores only canvas_data (HTML) — no rendered file, no image field | Accepted | 2026-09-28 | [`adr-097-encounter-canvas-html-only-no-rendered-file.md`](adr-097-encounter-canvas-html-only-no-rendered-file.md) |
| 098 | Billing screen restyled to the Narzim design mock, scoped to the presentation layer only | Accepted | 2026-09-28 | [`adr-098-billing-screen-restyle-presentation-layer-only.md`](adr-098-billing-screen-restyle-presentation-layer-only.md) |
| 099 | Dashboard revenue KPIs computed clinic-wide via Sales Invoice, not from today's appointments | Accepted | 2026-09-29 | [`adr-099-dashboard-revenue-kpis-clinic-wide.md`](adr-099-dashboard-revenue-kpis-clinic-wide.md) |
| 100 | Invoice list rows carry a batched item-summary field | Accepted | 2026-09-29 | [`adr-100-invoice-list-item-summary-field.md`](adr-100-invoice-list-item-summary-field.md) |
| 101 | Invoice detail returns the fields the printed invoice needs | Accepted | 2026-09-29 | [`adr-101-invoice-detail-print-fields.md`](adr-101-invoice-detail-print-fields.md) |
| 102 | Invoice list totals computed server-side, independent of page size | Accepted | 2026-09-29 | [`adr-102-invoice-list-exact-totals.md`](adr-102-invoice-list-exact-totals.md) |
| 103 | Service Request and Medication Request get their own Patient Medical Record rows, registered going forward only | Accepted | 2026-09-29 | [`adr-103-service-medication-request-in-patient-history.md`](adr-103-service-medication-request-in-patient-history.md) |
| 104 | Rx print renders an attached Canvas drawing as an `<img>`-loaded SVG, never an iframe | Accepted | 2026-09-30 | [`adr-104-rx-print-canvas-svg-rendering.md`](adr-104-rx-print-canvas-svg-rendering.md) |
| 105 | Template studio: sessionless drafts, deletable templates, cached examples | Accepted | 2026-09-30 | [`adr-105-template-studio-drafts-delete-and-example-cache.md`](adr-105-template-studio-drafts-delete-and-example-cache.md) |
| 106 | A dictation token for composers with no encounter | Accepted | 2026-09-30 | [`adr-106-live-dictation-token-for-composers.md`](adr-106-live-dictation-token-for-composers.md) |
| 107 | Rename a Narzim GPT conversation and mark it a favourite | Accepted | 2026-09-30 | [`adr-107-narzim-thread-rename-and-favourites.md`](adr-107-narzim-thread-rename-and-favourites.md) |
| 108 | Narzim GPT reads the linked visit's prescriptions and writes an attached template | Accepted | 2026-09-30 | [`adr-108-linked-visit-medications-and-attached-template.md`](adr-108-linked-visit-medications-and-attached-template.md) |
| 109 | A document written from a template reads the chart first, and returns no placeholder | Accepted | 2026-09-30 | [`adr-109-document-turn-reads-the-chart-first.md`](adr-109-document-turn-reads-the-chart-first.md) |
| 110 | With a chart linked, the literature is searched only for a knowledge question | Accepted | 2026-09-30 | [`adr-110-literature-search-only-for-knowledge-questions.md`](adr-110-literature-search-only-for-knowledge-questions.md) |
| 111 | Reports v3 round 2 — every report's default chart matches the design's own chart-type map, not the round-1 toggle compromise | Accepted | 2026-09-28 | [`adr-111-reports-v3-chart-parity.md`](adr-111-reports-v3-chart-parity.md) |
| 112 | Real Booked→Paid and Submitted→Paid funnels for Check-in Rates and Claims Status, built from existing fields | Accepted | 2026-09-28 | [`adr-112-check-in-and-claims-funnels.md`](adr-112-check-in-and-claims-funnels.md) |
| 113 | Rolling 7/30/90-day report periods, additive alongside the calendar periods | Accepted | 2026-09-28 | [`adr-113-rolling-day-count-report-periods.md`](adr-113-rolling-day-count-report-periods.md) |
| 114 | Reschedule, cancel and refund act only on the appointment's own invoice line | Accepted | 2026-09-30 | [`adr-114-appointment-line-owns-its-money.md`](adr-114-appointment-line-owns-its-money.md) |
| 115 | Billing runs on real role permissions; only front desk and admin move money | Accepted | 2026-09-30 | [`adr-115-billing-without-permission-bypass.md`](adr-115-billing-without-permission-bypass.md) |
| 116 | "Refunds today" counts cash paid out, not credit-note face value | Accepted | 2026-10-01 | [`adr-116-refunds-today-counts-cash-paid-out.md`](adr-116-refunds-today-counts-cash-paid-out.md) |
| 117 | Replace the appointment's line even when its invoice still has a balance | Accepted | 2026-10-01 | [`adr-117-replace-the-line-when-the-invoice-has-a-balance.md`](adr-117-replace-the-line-when-the-invoice-has-a-balance.md) |
| 118 | Lock the bill, and refuse if it changed, before moving money | Accepted | 2026-10-01 | [`adr-118-lock-the-bill-before-moving-money.md`](adr-118-lock-the-bill-before-moving-money.md) |
| 119 | A rounding residue of 0.05 or less is neither a debt nor a waiver | Accepted | 2026-10-01 | [`adr-119-a-rounding-residue-is-not-a-debt-or-a-waiver.md`](adr-119-a-rounding-residue-is-not-a-debt-or-a-waiver.md) |
| 120 | Local Langfuse traces the whole encounter flow, grouped by encounter | Accepted | 2026-10-01 | [`adr-120-langfuse-encounter-tracing.md`](adr-120-langfuse-encounter-tracing.md) |
| 121 | The Refund dialog shows the figure the server would pay, not its own calculation | Accepted | 2026-10-01 | [`adr-121-the-refund-figure-comes-from-the-server.md`](adr-121-the-refund-figure-comes-from-the-server.md) |
| 122 | The billing cart runs as the clerk; Administrator only for a scan the clerk cannot read | Accepted | 2026-10-01 | [`adr-122-billing-cart-runs-as-the-clerk.md`](adr-122-billing-cart-runs-as-the-clerk.md) |

⚠️ = the number is ambiguous; cite the filename.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 6.13 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-122 (Accepted): the billing cart runs as the clerk; "next free number" 123 |
| 6.12 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-refund-preview-from-server`: entries and rows from both sides kept; version numbers below may overlap |
| 6.10 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-121 (Accepted): the refund figure comes from the server (drafted as 120; dev took 120 for Langfuse); "next free number" 122 |
| 6.11 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-rounding-residue`: entries and rows from both sides kept; version numbers below may overlap |
| 6.9 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-119 (Accepted): a rounding residue is neither a debt nor a waiver; corrected "next free number" 119 -> 120 |
| 6.10 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-concurrent-money-moves`: entries and rows from both sides kept; version numbers below may overlap |
| 6.8 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-118 (Accepted): lock the bill before moving money; corrected "next free number" 118 -> 119 |
| 6.9 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/reschedule-partly-paid-balance`: entries and rows from both sides kept; version numbers below may overlap |
| 6.7 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-117 (Accepted): replace the line when the invoice has a balance; corrected "next free number" 114 -> 118 |
| 6.8 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Renumbered from 117 to 120: open billing PRs #482/#483 also took that number, and no branch uses 120 (ADR-042: the unmerged side moves) |
| 6.7 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Added ADR-120: Local Langfuse traces the whole encounter flow, grouped by encounter |
| 6.6 | 2026-10-01 | Divyanshu (AI-assisted) | Added ADR-116: Refunds today counts cash paid out |
| 6.5 | 2026-09-30 | Divyanshu (AI-assisted) | Added ADR-115: billing without permission bypass |
| 6.4 | 2026-09-30 | Divyanshu (AI-assisted) | Added ADR-114 (Proposed): appointment line owns its money |
| 5.9 | 2026-09-30 | Anant Sharma (AI-assisted) | Reports v3 ADRs added and renumbered before the rebase. `dev` had taken 095–102 for the encounter canvas and the billing restyle while this branch was off it, so the three that ship here moved 096→111 (chart parity), 097→112 (funnels) and 098→113 (rolling periods) — renumbered twice, because `dev` took 095–102 and then 103–110 while this branch was in review — unmerged ADRs are renumbered rather than frozen as collisions, the same call v5.2 made for 081→094 and v5.8 made for the billing ADRs. Confirmed on the second rebase: dev's own "next free number" was 111, which is what this branch took. Every citation was rewritten in both repos. The fourth, the AI-findings ADR (`reports-v3-ai-insights`), is NOT indexed and carries no number: its implementation was lost before it was ever committed, so it takes a number when it ships (`docs/KNOWN_ISSUES.md`). "Next free number" 095 → 114 |
| 6.3 | 2026-09-30 | Anant Sharma (AI-assisted) | Reports v3 ADRs renumbered a second time, 103/104/105 → 111/112/113: `dev` merged its own 103–110 (patient history, Rx print Canvas, template studio, Narzim GPT) while this branch was in review. Per ADR-042 the unmerged side moves; never merged under the old numbers, and every citation updated in both repos |
| 6.1 | 2026-09-30 | Satyakam (AI-assisted) | Merged `dev` into `feat/narzim-gpt-experience`: rows 103–104 (dev) and 105–110 (this branch) both indexed; "next free number" confirmed 111 |
| 5.14 | 2026-09-30 | Satyakam (AI-assisted) | ADRs 103–108 of this branch renumbered to 105–110: `dev` merged its own adr-103 (patient history) and adr-104 (Rx print Canvas) first; per ADR-042 the unmerged side moves. Never merged under the old numbers; index rows 103–108 -> 105–110; "next free number" 103 -> 111 (dev's 104 is taken too) |
| 5.13 | 2026-09-30 | Satyakam (AI-assisted) | adr-110 added |
| 5.12 | 2026-09-30 | Satyakam (AI-assisted) | adr-109 added |
| 5.11 | 2026-09-30 | Satyakam (AI-assisted) | adr-107 and adr-108 added |
| 5.10 | 2026-09-30 | Satyakam (AI-assisted) | adr-106 added |
| 5.9 | 2026-09-30 | Satyakam (AI-assisted) | adr-105 added |
| 6.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Added adr-104-rx-print-canvas-svg-rendering (104, Accepted); corrected "next free number" 104 -> 105 |
| 5.9 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased `feature/v9-service-request-active-status` onto `dev`: number 098 was already claimed here (billing, previous entry) — renumbered my own adr-098-service-medication-request-in-patient-history to adr-103, "next free number" 103 -> 104 |
| 5.8 | 2026-09-29 | Divyanshu (AI-assisted) | Moved uncommitted billing work onto `dev`: its five ADRs, drafted as 095–099, collided with dev's merged Encounter Canvas 095–097. Per ADR-042 the unmerged side moves, so they were renumbered 098–102 before merge (never merged under the old numbers) and indexed; "next free number" 098 -> 103 |
| 5.7 | 2026-09-28 | Divyanshu (AI-assisted) | Added adr-097-encounter-canvas-html-only-no-rendered-file (097, Accepted); marked adr-095 Superseded by 097; corrected "next free number" 097 -> 098 |
| 5.6 | 2026-09-28 | Divyanshu (AI-assisted) | Added adr-096-encounter-canvas-advice-surface-via-patient-history-fields (096, Accepted); corrected "next free number" 096 -> 097 |
| 5.5 | 2026-09-28 | Divyanshu (AI-assisted) | Added adr-095-encounter-canvas-storage-format (095, Accepted); corrected "next free number" 095 -> 096 |
| 5.4 | 2026-09-28 | Divyanshu (AI-assisted) | Rebased `holidayavailability` onto `dev`. "Next free number" carried two independently-stale claims from the two branches (this one said 080, dev said 070) — corrected to 095, the actual next free number now that adr-080 through adr-094 are all merged in. The rebase also surfaced two NEW genuine number collisions the two branches created independently (`check_adr_numbering.py` FAIL): 069 (`adr-069-admin-practitioner-booking-fixed-via-ignore-permissions.md` vs. `adr-069-open-us-jurisdiction.md`) and 080 (`adr-080-report-type-templates-for-lab-extraction.md` vs. `adr-080-patient-import-session-and-llm-column-mapping.md`) — added as frozen collisions per the same ADR-042 convention as the other twelve, never renumbered; also indexed adr-069-open-us-jurisdiction.md, missing from the record table entirely |
| 5.3 | 2026-09-26 | Anant Sharma (AI-assisted) | Added adr-094-user-selectable-list-columns (094, Accepted) |
| 5.2 | 2026-09-26 | Anant Sharma (AI-assisted) | Merged dev into feat/patient-import-export. This branch's adr-080 and dev's adr-080 are different decisions sharing a number — recorded, not renumbered, per ADR-042. The list-columns ADR was still unmerged, so it moved 081 -> 094 rather than become a third duplicate |
| 5.1 | 2026-09-26 | Ashutosh (AI-assisted) | Added adr-093-patient-name-in-staff-push-banners (093, Accepted) |
| 5.0 | 2026-09-24 | Divyanshu (AI-assisted) | Added adr-092-report-prompts-reviewed-before-extraction (092, Proposed) |
| 4.9 | 2026-09-24 | Divyanshu (AI-assisted) | Added adr-091-images-reviewed-systematically-by-a-stronger-model (091, Accepted) |
| 4.8 | 2026-09-24 | Divyanshu (AI-assisted) | Added adr-090-image-observations-graded-not-restricted (090, Accepted) |
| 4.7 | 2026-09-23 | Divyanshu (AI-assisted) | Added adr-089-body-site-needs-printed-evidence (089, Accepted) |
| 4.6 | 2026-09-23 | Divyanshu (AI-assisted) | Added adr-088-images-read-from-what-they-show (088, Accepted) |
| 4.5 | 2026-09-23 | Divyanshu (AI-assisted) | Added ADR-080 through ADR-087 (lab/report extraction: templates, subject+side, image observations, printed warnings, measurement reports, structured transcription; all Accepted) |
| 4.4 | 2026-09-18 | Divyanshu (AI-assisted) | Added adr-079-ai-source-cache-stored-for-reproducibility (079, Accepted) |
| 4.3 | 2026-09-18 | Divyanshu (AI-assisted) | Added adr-078-phi1-enforced-at-the-provider-chokepoints (078, Accepted) |
| 4.2 | 2026-09-18 | Divyanshu (AI-assisted) | Added adr-077-clinical-web-outbound-retrieval (077, Accepted — the ADR that ADR-075 required by name and that did not exist) |
| 4.1 | 2026-09-18 | Divyanshu (AI-assisted) | Added adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline (076, **Proposed** — supersedes ADR-018 points 1 and 5, awaiting Sarvesh) |
| 4.0 | 2026-09-17 | Divyanshu (AI-assisted) | Added adr-075-narzim-gpt-patient-aware-context (075, Accepted) |
| 3.9 | 2026-09-16 | Ashutosh (AI-assisted) | Added adr-074-pay-now-dead-end-and-missing-practitioner-on-delta-invoices (074, Accepted) |
| 3.8 | 2026-09-16 | Ashutosh (AI-assisted) | Added adr-073-billing-cache-invalidation-and-paid-amount-display (073, Accepted) |
| 3.7 | 2026-09-16 | Ashutosh (AI-assisted) | Added adr-072-reschedule-delta-invoice-tax-fix-and-invoice-trail-visibility (072, Accepted) |
| 3.6 | 2026-09-16 | Ashutosh (AI-assisted) | Added adr-071-patient-total-pending-and-item-tax-fix (071, Accepted) |
| 3.5 | 2026-09-15 | Ashutosh (AI-assisted) | `check_adr_numbering.py` flagged 3 unindexed ADRs — added: adr-069-admin-practitioner-booking-fixed-via-ignore-permissions (069, Accepted), adr-070-concurrent-open-vaccine-rounds (070, Accepted), and adr-061-adr-and-md-per-unit-of-work — a pre-existing, never-indexed ADR from 2026-09-08 that collides with the already-indexed adr-061-drive-to-patient-chart-move; marked both 061 ⚠️ per the same frozen-collision convention already established for 063 |
| 2.13 | 2026-09-11 | Divyanshu (AI-assisted) | Resolved a stash-pop conflict against Anant Sharma's separately-merged ADR-063 (Drive access list): both 063s are genuinely different, unmerged decisions written the same day — added as a new frozen collision (063 ⚠️) rather than renumbering either, matching this doc's own established rule; version numbers below re-sequenced to remove the resulting duplicate "2.9" |
| 2.12 | 2026-09-10 | Anant Sharma (AI-assisted) | Added adr-061-drive-to-patient-chart-move and adr-063-drive-access-list |
| 2.11 | 2026-09-10 | Divyanshu (AI-assisted) | adr-064's scope widened to also cover the cross-clinic practitioner workload suggestion (still Proposed); index row title updated to match |
| 2.10 | 2026-09-10 | Divyanshu (AI-assisted) | Added adr-064-queue-tips-llm-summary (Proposed) — narrowly supersedes ADR-063's "Role-based tips" section only; "next free number" 064 → 065 |
| 2.9 | 2026-09-09 | Divyanshu (AI-assisted) | Added adr-063-clinical-command-center-reassign-and-stage-logging (Accepted); "next free number" 063 → 064 |
| 3.2 | 2026-09-14 | Ashutosh (AI-assisted) | Added adr-068-ai-drafted-whatsapp-clinical-replies (Accepted). Reverses R-2 and R-3 of the WhatsApp design for the AI-reply path |
| 3.1 | 2026-09-12 | Ashutosh (AI-assisted) | Added adr-067-patient-name-in-whatsapp-templates (Accepted). Widens the WhatsApp PHI allowlist by one entry — the patient's name — and supersedes the prohibition in WHATSAPP_HIPAA_COMPLIANT.md §6.1 |
| 3.0 | 2026-09-11 | Ashutosh (AI-assisted) | Added adr-066-whatsapp-keyword-auto-replies (Proposed). Records that a keyword auto-reply mechanism already existed in chat_api.py and was extended rather than duplicated; replies stay template-only so §5 R-1 is not amended |
| 2.9 | 2026-09-10 | Anant Sharma (AI-assisted) | Added adr-061-drive-to-patient-chart-move and adr-063-drive-access-list. 063, not 062: dev merged its own ADR-062 (practitioner availability) while this branch was open, and a merged ADR is never renumbered — the unmerged one moves |
| 2.8 | 2026-09-08 | Divyanshu (AI-assisted) | Added adr-062-practitioner-self-service-availability (Proposed); "next free number" corrected 061 → 063 (061 exists on disk, gitignored, from an earlier session) |
| 2.7 | 2026-09-03 | Anant Sharma (AI-assisted) | Added adr-057-patient-duplicate-match-blind-claim-and-verify and adr-058-registration-form-vision-extraction (QR self-registration); both Proposed |
| 2.6 | 2026-09-04 | Ashutosh (AI-assisted) | Added adr-060-patient-communication-consent (Accepted). Numbered 060, not 057: dev merged its own ADR-057 (patient duplicate matching) plus 058 and 059 while this branch was open, and a merged ADR is never renumbered — the unmerged one moves |
| 2.5 | 2026-09-03 | Sarvesh-SocialAngel (AI-assisted) | Added adr-056-consent-server-derived-evidence (T-38) |
| 2.3 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Merged `dev`. `adr-050` collided: `dev` had merged narzim-assistant-domain-scope-gate under 050 while this branch held three-step-encounter-flow. The merged one keeps its number; the unpublished one renumbered **050 → 054** (051-053 were already taken), with 27 citations repointed by meaning across 8 files. ADR-053 indexed |
| 2.2 | 2026-08-29 | Anant Sharma (AI-assisted) | ADR-050 status: Proposed → Accepted (implemented) |
| 2.1 | 2026-08-29 | Anant Sharma (AI-assisted) | Added adr-050-narzim-assistant-domain-scope-gate |
| 2.0 | 2026-08-27 | Anant Sharma (AI-assisted) | Added adr-049-vaccines-in-treatment-plan-templates (written as 048, renumbered before merge — same as 1.7 and 1.2) |
| 1.9b | 2026-08-29 | Sarvesh-SocialAngel (AI-assisted) | ADR-045 collision resolved by renumbering `one-call-per-upload` to **052** on the repo owner's instruction. 14 citations reclassified by meaning across 6 files — bare "ADR-045" had been used for four different decisions. Baseline entry and the ⚠️ marks added earlier are reverted: there is no collision left |
| 1.9 | 2026-08-27 | Ashutosh (AI-assisted) | ADR-048 title widened (now covers the lab chat too) |
| 1.8 | 2026-08-27 | Ashutosh (AI-assisted) | Added adr-048-narzim-streaming-sse-not-background-jobs |
| 1.7b | 2026-08-29 | Sarvesh-SocialAngel (AI-assisted) | Indexed the 6 ADRs from `dev` that were never listed (052 one-call-per-upload, 045 push-notifications, 046 notification-event-keys, 047 reporting-engine, 048 narzim-streaming, 049 vaccines-in-templates); renumbered the two unpublished encounter ADRs 045/046 to 050/051 after they collided with published ones; flagged the live ADR-045 duplicate with ⚠️ |
| 1.7 | 2026-08-26 | Anant Sharma (AI-assisted) | Added adr-047-reporting-engine-custom-apis-not-insights (written as 045, renumbered before merge — same as 1.2); indexed the missing adr-045-one-call-per-upload-with-bounded-recovery and marked 045 ambiguous |
| 1.6b | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Added ADR-051 (Phase 7 transcript retention — indefinite, single authoritative source) |
| 1.6 | 2026-08-26 | Ashutosh (AI-assisted) | Added adr-046-notification-event-keys-and-channel-roles |
| 1.5b | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Added the 3-step encounter flow ADR (written as 050, renumbered to 054 at 2.3) |
| 1.5 | 2026-08-24 | Ashutosh (AI-assisted) | Added adr-045-push-notifications-fcm-and-sse |
| 1.4 | 2026-08-21 | Divyanshu (AI-assisted) | ADR-044 status: Proposed → Accepted (implemented) |
| 1.3 | 2026-08-21 | Divyanshu (AI-assisted) | Added ADR-044; corrected ADR-042's status to Accepted (it shipped 2026-08-20) |
| 1.2 | 2026-08-20 | Sarvesh-SocialAngel (AI-assisted) | Upstream ADR-042 (government deferred receivable billing) added; mine renumbered to 043 |
| 1.1 | 2026-08-20 | Sarvesh (AI-assisted) | Added ADR-008/009/040/042; recorded the freeze decision and the enforcement baseline |
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial index — collisions and phantom numbers documented |
