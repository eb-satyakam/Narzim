# ADR-073: Billing/appointment mutations never invalidated the Billing tab, checkout cart, or Command Center payment tile — and the invoice success screen never showed what was actually paid

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-16
- **Supersedes:** — (extends, does not replace, ADR-071/072's same-day billing work)
- **Superseded by:** —

## Context

Reported live, across two patients (Diego Gómez Reyes, Aditya Patel), in the middle of testing ADR-071/072's fixes:

1. Diego's Dr Hathi appointment card showed a green "Paid" badge on the Command Center queue, but opening its drawer showed "PAYMENT — Unpaid MXN 1,740."
2. Clicking "Pay Now" on that drawer appeared to do nothing.
3. The resulting "New Sales Invoice" success screen ("Invoice partially paid," 540 MXN outstanding) never showed how much was actually paid — only the total and what was still owed.
4. On Aditya Patel, reassigning an appointment created a real Credit Note (confirmed in the database and via the clinic-wide Revenue/Billing hub), but it never appeared in the Patient 360 Billing tab.

Investigating each with live data (not assumption) found:

- **(1) was not a bug.** Diego's Dr Hathi appointment genuinely is fully paid (2,137.93 across 3 invoices, 0 outstanding) — the badge was correct. The drawer's 1,740 was the PATIENT's total unbilled amount from three *other* appointments (per ADR-071's own design, confirmed and chosen by the person requesting it: the tile is patient-wide, not appointment-scoped). Both numbers were correct; showing them side-by-side on the same card just reads as contradictory. Recorded here as a known UX tension, not fixed as a bug — see Consequences.
- **(2) and part of (3)'s confusion trace to the same root cause**: no mutation that creates or settles a Sales Invoice/Credit Note (`useReassignAppointment`, `useRescheduleWithPayment`, `useUpdateAppointmentStatus`, `useCancelAppointment` in `use-appointments.ts`; `useCollectPayment`, `useCreatePosInvoice` in `use-billing.ts`) ever invalidated the query keys `["invoices"]`, `["invoice"]`, `["patient-billables"]`, or `["patient-total-pending"]`. Confirmed by reading each mutation's `onSuccess`: `invalidateAll()` (used by every appointment mutation) touches `["appointments"]`, `["appointment"]`, `["appointments-with-total"]`, `["dashboard"]` — never billing. `useCollectPayment` invalidated `["invoices"]`/`["payments"]` but not `["patient-total-pending"]`. `useCreatePosInvoice` invalidated `["patient-billables"]`/`["invoices"]`/`["payments"]` but not `["patient-total-pending"]` either. Every one of these gaps meant the drawer's PAYMENT tile (ADR-071) and the Patient 360 Billing tab could keep showing pre-mutation numbers after a real, successful action — which is exactly what made "Pay Now" look like it did nothing, and exactly why Aditya's Credit Note was invisible in the Billing tab until something unrelated triggered a refetch.
- **(3)'s remaining half is a real, standalone display gap**: `new-invoice-client.tsx`'s success screen (`if (result) {...}`) renders total/net/tax/discount/outstanding, but never the amount actually paid — even though `result.grand_total - result.outstanding` is sitting right there, a plain subtraction of two numbers already on the same authoritative server response (not a re-derived tax figure).

## Decision

1. **`use-appointments.ts`'s `invalidateAll()`** now also invalidates `["invoices"]`, `["invoice"]`, `["patient-billables"]`, `["patient-total-pending"]` — covers every appointment-mutation entry point (reassign, reschedule-with-payment, status update, cancel) in one place.
2. **`useCollectPayment`** (`use-billing.ts`) now also invalidates `["invoice"]`, `["patient-billables"]`, `["patient-total-pending"]`.
3. **`useCreatePosInvoice`** (`use-billing.ts`) now also invalidates `["patient-total-pending", patient]`.
4. **`new-invoice-client.tsx`'s success screen** now shows an explicit "Paid" row (`grand_total - outstanding`), unconditionally, not only when there's an outstanding balance — so "how much did we actually collect" is never absent from this screen.
5. **The badge-vs-drawer tension (finding 1) is left as-is, not fixed** — see Consequences for why and what would change it.

## Alternatives Considered

1. **Fix each mutation's invalidation individually, in place (chosen).**
   - Pros: minimal, targeted diff; each mutation's own comment explains exactly what it now also covers and why; no new abstraction.
   - Cons: the same four query keys are now repeated across several call sites — a future new billing-affecting mutation could still forget one of them.

2. **Centralize into one shared `invalidateBillingQueries(queryClient, patient?)` helper, called from every affected mutation.**
   - Pros: one place to extend if a fifth billing query key is ever added; removes the repetition alternative 1 accepts.
   - Cons: `use-appointments.ts` and `use-billing.ts` are different files with no existing shared cross-cutting utility module for this; introducing one is a real (if small) architectural addition for what is, today, four query keys — judged not worth it yet. Revisit if a third file needs the same list.

3. **Make the PAYMENT tile poll instead of relying on invalidation.**
   - Pros: self-healing regardless of which mutation caused the change, no need to track every call site.
   - Cons: ADR-071 deliberately chose `staleTime: 0, refetchOnMount: "always"` (fetch-on-open, not poll) for this exact tile — polling a payment amount is wasted load for a value that only changes on a deliberate action, and every other billing hook in this app already follows the invalidate-on-mutation pattern instead of polling. Would be inconsistent with the rest of the codebase for no real gain.

4. **Do nothing about the badge/drawer number tension (finding 1) — try to make the queue card ALSO reflect the patient-wide total.**
   - Rejected outright, not just deprioritized: the queue card's "Paid" badge is deliberately appointment-scoped (that specific visit's own bill), which is a genuinely different fact from "does this patient owe money anywhere." Collapsing them would re-introduce the exact problem ADR-071 was built to fix in the other direction — hiding a specific visit's true status behind a patient-wide number.

## Why this approach, specifically

- **Vs. 2 (shared helper):** loses on introducing a new cross-file utility for four invalidation calls that, today, only live in two files — a reasonable simplification once a third caller needs the same list, not before.
- **Vs. 3 (polling):** loses on being inconsistent with every other billing hook in this codebase and wasting load for a value that only changes on explicit action.
- **Vs. 4:** not a real alternative — it would undo ADR-071's own explicit decision.

## Consequences

- `EB_Healthcare_Frontend/src/hooks/use-appointments.ts`: `invalidateAll()` extended — affects `useReassignAppointment`, `useRescheduleWithPayment`, `useUpdateAppointmentStatus`, `useCancelAppointment`.
- `EB_Healthcare_Frontend/src/hooks/use-billing.ts`: `useCollectPayment`, `useCreatePosInvoice` extended.
- `EB_Healthcare_Frontend/src/app/(clinic)/billing/invoices/new/new-invoice-client.tsx`: success screen shows a "Paid" row.
- `EB_Healthcare_Frontend/messages/en.json`, `messages/es.json`: new `billingPage.newInvoice.amountPaid` key (exact namespace path per the file's existing structure).
- **The badge/drawer tension is a recorded, accepted UX consequence of ADR-071's own decision, not a defect.** A patient with a fully-paid visit AND separate unbilled items elsewhere will continue to show a "Paid" badge on that visit's card alongside a nonzero PAYMENT tile in its drawer. If this reads as confusing enough to warrant a UI change, the fix belongs in the drawer's own copy (e.g. labeling the tile explicitly as "Other pending for this patient" when the current appointment is itself fully settled) — not attempted here without being asked, per the frontend rule against expanding scope beyond what was requested.
- **Re-evaluation trigger:** if a third file (beyond `use-appointments.ts`/`use-billing.ts`) needs to invalidate this same billing-query set, extract the shared helper considered and rejected in Alternative 2.
- (Addendum) `remedisys_healthcare_ai/api/v1/billing/api.py::get_patient_invoice` — new `credit_notes` field. `EB_Healthcare_Frontend/src/types/billing.ts` — `InvoiceDetail.credit_notes`. `components/billing/invoice-preview-sheet.tsx` — `effectiveCreditNoteIds` fallback, renders the forward link. `billing-tab.tsx`, `appointments-tab.tsx` — `onViewCreditNote`/`onViewOriginalInvoice` wired for the first time. `messages/en.json`/`es.json` — new `creditNoteRefLabel` key.

## Verification

- Root-caused live, against two real patients' real mutation history (Diego Gómez Reyes, Aditya Patel) — not synthetic data.
- Confirmed by reading every appointment/billing mutation's `onSuccess` block directly, not by assumption: enumerated exactly which query keys each one touched before deciding what was missing.
- Confirmed Aditya Patel's Credit Note (`ACC-SINV-2026-01019`, `is_return: 1`, `return_against: ACC-SINV-2026-01018`) already existed correctly in the database and was already correctly returned by `list_patient_invoices` (the exact endpoint `billing-tab.tsx` calls) — proving the gap was purely a stale frontend cache, not a backend defect, before writing any fix.
- Frontend: `tsc --noEmit` clean (same one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts`); `npm run i18n:check` clean.
- Not yet verified: an actual browser click-through confirming the drawer/Billing tab now refresh immediately after a live reassign/collect/checkout action (no browser tooling available in this environment) — the fix is verified by code inspection (every affected mutation's `onSuccess` now lists the correct keys) and by the same "read the real backend response" technique used for ADR-071/072, not by an end-to-end UI observation.

## Addendum (same day): finding 4's real root cause was deeper than caching — the sheet had no button to open a credit note at all

Re-raised after the initial fix shipped: "when I open the invoice, again which credit note is issued it is showing credit note issued but not able to see the credit note — and same in Billing tab in patient 360." This corrected the original diagnosis of finding 4 — cache staleness was real (and is still fixed, above), but it was not the whole story. Investigating further found `InvoicePreviewSheet` (`components/billing/invoice-preview-sheet.tsx`) already declared `linkedCreditNoteIds`/`onViewCreditNote`/`onViewOriginalInvoice` props, with a doc comment describing exactly this feature — but:

- The clinic-wide Revenue/Billing hub (`app/(clinic)/billing/billing-client.tsx`) already wires all three correctly, computing `linkedCreditNoteIds` itself from its own already-loaded, clinic-wide invoice list.
- **Neither `billing-tab.tsx` (Patient 360's own Billing tab) nor `appointments-tab.tsx` ever passed any of the three props at all.** Both instantiate the same `InvoicePreviewSheet`, but a patient-scoped tab doesn't have the clinic-wide list the Billing hub uses to compute credit-note siblings — so simply copying the hub's approach wasn't available to them.
- `get_patient_invoice` (`api/v1/billing/api.py`) — the endpoint backing `useInvoiceDetail`, which every one of these call sites reads from — never returned which Credit Note(s) (if any) were issued against the invoice being viewed. `return_against` exists, but only on the credit note itself, pointing backward to its original; nothing pointed forward from an original to its credit note(s).

**Fixed**: `get_patient_invoice` now also returns `credit_notes: [{name, amount}]` — every submitted Sales Invoice with `is_return=1` and `return_against` equal to the invoice being viewed. `InvoiceDetail` (frontend type) gained the matching field. `InvoicePreviewSheet` now derives `effectiveCreditNoteIds` from the prop when supplied, falling back to the invoice's own `credit_notes` field when it isn't — so a caller that never had a full list to compute siblings from (both `billing-tab.tsx` and `appointments-tab.tsx`) now gets correct behavior for free, with no per-caller computation needed. Both of those call sites also had `onViewCreditNote`/`onViewOriginalInvoice` wired for the first time (previously accepted but silently dropped, since neither was ever passed).

**Verified live**: called `get_patient_invoice("ACC-SINV-2026-01018")` (Aditya Patel's real, already-credit-noted invoice) directly — confirmed it now returns `credit_notes: [{"name": "ACC-SINV-2026-01019", "amount": 1320.0}]`, the exact real Credit Note already established to exist in the database.

## References

- ADR-071 (the drawer's PAYMENT tile — `usePatientTotalPending`, `staleTime: 0`/`refetchOnMount: "always"` — whose own cache this fixes the invalidation side of)
- ADR-072 (the same-day reassignment trail this was found investigating)
- `WORK_LOG.md` 2026-09-16 entry

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-16 | Ashutosh (AI-assisted) | Addendum added: finding 4's real root cause was a missing forward-link from an invoice to its Credit Note(s), not only caching — `get_patient_invoice` now returns `credit_notes`, and `InvoicePreviewSheet`'s already-declared-but-unwired `linkedCreditNoteIds`/`onViewCreditNote`/`onViewOriginalInvoice` are now wired in `billing-tab.tsx` and `appointments-tab.tsx` |
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
