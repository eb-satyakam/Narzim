# ADR-100: Invoice list rows carry a batched item-summary field

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted
- **Date:** 2026-09-29
- **Supersedes:** —
- **Superseded by:** —

## Context

`EB_Healthcare_Frontend`'s Billing screen was restyled to the Narzim design mock (adr-098), whose
Invoices table has a permanent **Items** column with no equivalent field in today's Sales Invoice
list response. `_LIST_FIELDS` (`api/v1/billing/api.py:42-61`) never touches the `Sales Invoice Item`
child table — the list endpoints (`list_patient_invoices`, `list_all_invoices`) return header-level
invoice fields only. The frontend cannot render the column without a real data source.

## Decision

Add a new batched helper, `_item_summaries(rows)`, following the exact convention already
established in this file by `_payment_methods` (`api.py:299`) and the child-table query in
`_apply_appointment_fallback` (`api.py:359`): one `frappe.get_all("Sales Invoice Item", filters=
{"parent": ["in", names]}, ...)` call per page, grouped by parent invoice, joined into a short
string capped at the first three item names plus a `"+N more"` suffix. Threaded through
`_serialize_invoice` as a new `items_summary` key, returned by both `list_patient_invoices` and
`list_all_invoices` — the two callers of the shared serializer.

**Amended 2026-09-29, before merge (v1.1):** repeated item names collapse into one entry with a line
count (`"Consultation fee ×2"`), and the overflow is returned as a separate integer,
`items_more_count`, instead of an English `" +N more"` suffix inside the string. The first version
wrote that suffix server-side, which would have shown in English in the `es-MX` UI; the frontend now
renders it from its own catalogue (`billingPage.itemsMore`). Found from a user screenshot showing
"Consulatation fee, Consulatation fee".

1. Read-only, additive fields (`items_summary`, `items_more_count`). No new endpoint, no new request parameter.
2. `Sales Invoice Item` read access follows the parent Sales Invoice's own permission — no new
   permission surface.
3. One batched query per page, same cost class as the existing `_payment_methods` call — no N+1.

## Alternatives Considered

1. **Do nothing; leave the Items column empty or hide it in the frontend.**
   - Pros: zero backend change.
   - Cons: the mock's Items column is a core piece of what makes the row scannable ("what was this
     invoice for") — hiding it silently diverges from the approved restyle (adr-098) for no technical
     reason, since the data is one query away.

2. **Fabricate the summary client-side** from fields already on the response (`remarks`, `status`).
   - Pros: no backend change.
   - Cons: `remarks` is free text for other purposes (write-off reasons, waiver scheme names — see
     `billing_service.waiver_mode_from_remarks`), not a line-item description. Guessing invoice
     contents from it would put fabricated billing content on a clinical/financial screen — exactly
     what this repo's PHI/fabrication rules (`CLAUDE.md` §6: no capability shipped without a real
     data source) exist to prevent.

3. **Return the full line-item array** (`items: [{item_name, qty, rate, amount}, ...]`) instead of a
   pre-joined summary string.
   - Pros: more flexible — frontend could render qty/rate if a future screen wants it.
   - Cons: no current consumer needs more than a one-line summary; a full array on every list row (up
     to 100 rows/page, each with N line items) is a heavier payload for a table cell that only ever
     shows a truncated string. Rejected on Rule BE-5's spirit (return only what's needed, not the
     full record) applied to a list endpoint, not just an LLM context — the same minimum-necessary
     principle. Revisit if a real second consumer needs the structured form.

4. **A single `frappe.get_all` join across both `Sales Invoice` and `Sales Invoice Item`** (a nested
   query) instead of two separate calls (main list query, then the item-summary batch).
   - Pros: one round-trip instead of two.
   - Cons: `frappe.get_list`'s permission-condition injection (used by `list_all_invoices` for the
     scope guard, per its own docstring at `api.py:611`) applies to the outer doctype; joining in the
     child table at the ORM level either loses that scoping or requires raw SQL, reintroducing the
     exact company-scoping risk ADR-099 rejected for the dashboard revenue query. The two-query batch
     keeps permission scoping on the parent query and touches the child table only for names already
     known to be in-scope.

**Chosen: the batched-helper approach (item 1 above).** It reuses an established, reviewed pattern in
this exact file, costs one extra cheap query per page, and returns exactly what the approved mock
needs — nothing more, nothing fabricated.

## Consequences

- `api/v1/billing/api.py`: new `_item_summaries` helper; `_serialize_invoice` gains one optional
  parameter and one new response key (`items_summary`); both list endpoints call the helper.
- Additive only — no existing key renamed, removed or reshaped. Existing consumers of these two
  endpoints are unaffected.
- Re-evaluation trigger: if a future screen needs structured line-item data (qty, rate) rather than
  a display string, that is Alternative 3 above, added as a separate field — not a reason to change
  this one's shape.

## Verification

- Live via `bench --site remedisis.localhost console`: `list_all_invoices()` and
  `list_patient_invoices(patient=...)` both include a populated `items_summary` for an invoice with
  line items, and `""` for one without.
- `python3 -m py_compile` clean on the modified file.
- No automated test currently exercises `items_summary` (new field; none pre-existing to break).
- v1.1, live on `remedisis.localhost`: `ACC-SINV-2026-01104` → `"Consulatation fee ×2"`, more 0;
  `ACC-SINV-2026-01040` → `"Consulatation fee ×3, Administración de Antibiótico Nebulizado"`;
  `ACC-SINV-2026-00150` (7 distinct items) → `"Consulatation fee, Hepatitis B, Abc test"`, more 4.

## References

- `docs/architecture/INVOICE_LIST_ITEM_SUMMARY.md` (this repo)
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md` (frontend repo — the mock's
  Items column this field feeds)
- `adr-098-billing-screen-restyle-presentation-layer-only.md`,
  `adr-099-dashboard-revenue-kpis-clinic-wide.md` — the two prior ADRs in this same restyle effort

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Before merge: repeated items collapse with a count; overflow moved to `items_more_count` so the frontend translates it (the English suffix was an i18n bug) |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
