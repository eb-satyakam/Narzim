# ADR-095: AI-written report findings, grounded in the report's own numbers

**Doc status:** living · **Created:** 2026-09-28 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-28 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** —
- **Superseded by:** —

## Context

The Reports v3 design (Claude Design project *Narzim EHR*, file `Reports v3.dc.html`) adds three
things the reports module does not have today:

1. **A Brief** on the `/reports` landing page — one headline sentence plus up to four findings, each
   linking to the report it came from ("No-shows climbed to 6.2 %… See report").
2. **Numbered findings** on each of the 17 report pages ("What stands out").
3. **Ask Orin** — a chat panel where a user asks a question about the report on screen.

Anant Sharma decided on 2026-09-28 that these are written by the AI, not by fixed rules. That makes
this a new clinical-adjacent AI capability, and three rules in `CLAUDE.md` bind it:

- **§11** — never add a clinical AI capability without a deterministic validator or an explicit
  recorded decision to skip one.
- **PHI-6** — an AI call receives the narrowest context that answers the question.
- **Rule 6 / Rule 7** — the AI explains, never decides; its failure never breaks the screen.

There is a house precedent. [ADR-064](adr-064-queue-tips-llm-summary.md)
(queue tips) computes every number in Python and lets the model write only the sentence, from a
names-free stats dict. The v3 design's placeholder copy shows why that discipline matters: it
contains a nurse who "moved to Bandra", insurers "CGHS" and "Medi Assist" in a Mexican clinic, and
advice such as "consider testing earlier in febrile patients" — fluent, specific, and invented.

## Decision

**Findings and answers are written by the AI from a digest of the report's own response, and a
deterministic validator drops any sentence that states a number the digest does not contain.**

1. **Input is the report endpoint's own output, minimised.** `services/report_insights.py` calls
   the same whitelisted report method the page calls — so its role gate and
   `report_practitioner_scope()` apply unchanged — and keeps only `meta` window, `kpis` and
   `charts`. The `table` is dropped entirely, and any field whose name marks a person
   (`patient*`, `mrn`, `mobile`, `email`, `dob`, …) is dropped from what remains. Practitioner
   names in `charts.by_provider` labels are kept: they are staff, not patients, and the design's
   findings name doctors.
2. **Output is JSON of a fixed shape** — `{headline?, findings: [{text, tone, report?}]}`, at most
   four findings, each at most 220 characters.
3. **The validator.** Every number in a finding (`6.2 %`, `MXN 1.14 M`, `14 min`, `1,184`) is
   parsed and must match, within half a unit of its last written digit, a number the digest
   contains or one of a deliberately narrow set of comparisons: a kpi against its own previous
   period, two kpis' headline values, or two points of one chart. Each finding is checked against
   **the report it cites**, not the whole Brief. A finding that fails is dropped, not repaired; an
   Ask Orin answer that fails is withheld and the frontend says "I can't confirm that from this
   report's numbers".
   - **Points are checked separately.** A number written as "N points" must equal a kpi's
     `change_points` or a within-chart difference — never a `delta_pct`, which is relative.
   - **The digest does the arithmetic** (the ADR-064 pattern): every kpi with a `delta_pct` also
     carries `previous_value`, and a rate carries `change_points`, computed in Python.
   - Both were added after a live call on 2026-09-28 wrote "no-show rate increased by 40.1 points
     to 70.6 %" — 40.1 was a real, *relative* figure; the move was 50.4 % → 70.6 %, 20.2 points.
4. **Explanation only.** The prompt forbids clinical advice, diagnosis, treatment, staffing and
   causal claims the data cannot show ("because a nurse moved"). The validator also drops any
   finding containing a small list of directive clinical verbs (prescribe, start/stop a drug,
   increase/decrease a dose, diagnose).
5. **Off by default.** New `AI Settings.enable_report_insights` (Check, default 0). Off, the
   endpoints return `{enabled: false}` and the pages render exactly as without AI.
6. **Cached** per (report, prompt version, language, digest hash) for 30 minutes, so repeated page
   loads over unchanged data make no second call.
7. **Logged** to `AI Prompt Log` through `log_prompt_call_general` — purpose, model, tokens, cost,
   latency, error. No prompt or response text (Rule 10).
8. **Provider-neutral.** Uses `get_llm_client().complete(...)`, which both allowlisted
   integrations implement (ADR-026); PHI-1 is enforced inside `get_llm_client()` (ADR-078).

## Alternatives Considered

1. **The AI writes freely from the report data.**
   - Pros: simplest; best prose.
   - Cons: no validator, so it violates §11 outright; the design's own placeholder copy is the
     demonstration of what it would produce.
2. **The AI writes from the report's digest; a validator enforces numeric grounding (chosen).**
   - Pros: real AI wording, as decided; a deterministic guard on the one failure that is both
     common and checkable — a wrong number; reuses the report endpoints, so scoping cannot drift.
   - Cons: the validator catches wrong numbers, not wrong reasoning. A correctly-numbered but
     misleading sentence passes — and a number that happens to appear elsewhere in the same report
     passes too. Mitigated by the narrow comparison set, the points rule, the explanation-only
     prompt, the directive-verb check, and the on-screen label "Written by Orin from this report's
     numbers. Check before acting."
3. **Python detects findings; the AI only phrases them (ADR-064's pattern).**
   - Pros: the strongest guarantee; a proven pattern here.
   - Cons: a rule set per report — seventeen of them — before any sentence appears. This is the
     "fixed rules" option, which was explicitly not chosen. Remains the fallback if (2) fails.
4. **An agent with the Encounter Copilot's tool registry (ADR-030).**
   - Pros: can answer any question, including ones the report does not cover.
   - Cons: widens what the model can read — a PHI-6 change needing its own compliance ADR; the
     tools are patient-scoped, not clinic-aggregate; several tool round-trips per page load.

## Consequences

- New: `api/v1/reports/api.py`, `services/report_insights.py`,
  `prompts/report-insights-v1.txt`, `prompts/report-ask-v1.txt`,
  `AI Settings.enable_report_insights`, tests under `tests/reports/`.
- The frontend (`EB_Healthcare_EHR`, branch `feat/reports-design`) renders findings and Ask Orin
  only when the endpoint says `enabled: true`, and labels them as AI-written.
- Cost: at most one call per report view per 30 minutes per distinct data state. Measured
  2026-09-28 on `gpt-4o`: USD 0.011 for a six-report Brief, USD 0.003 for one report, USD 0.0024 per
  question.
- The Brief reads `get_reports_overview`, which returned clinic money to any role (G-42). It was
  gated the same day to Front Desk + Practitioner (Admin by bypass), so neither the Brief figures
  nor the Brief findings can show a nurse clinic revenue.
- **Re-evaluation trigger — what would falsify this choice:** review of real findings shows
  correctly-numbered sentences that mislead (a causal claim, a comparison across different bases).
  If that happens more than rarely, move to alternative 3 for the affected reports.

## Verification

- `tests/reports/test_report_insights.py` (30 tests): the validator drops an ungrounded number and
  keeps a grounded one; a finding is grounded against its cited report only; a relative change
  called "points" is dropped; the digest contains no `table` and no patient-shaped key; `run_report`
  bypasses all three wrapper layers and restores `frappe.response`; a provider failure returns
  `findings: []` without raising; the flag off returns `enabled: false` and makes no call.
- `tests/reports/test_overview_role_gate.py`: nurse refused, Front Desk / Practitioner / Admin pass.
- Live, 2026-09-28: all 18 report digests run as a practitioner and as an all-roles user — no
  patient field in any; 8 refusals for the practitioner, 0 new Error Log rows.
- `AI Prompt Log` rows with purpose `Report Insights` / `Report Ask` after a live call.

## References

- [`docs/reports/18-reports-v3-redesign.md`](../reports/18-reports-v3-redesign.md) — the redesign
  this ADR serves.
- [ADR-064](adr-064-queue-tips-llm-summary.md), [ADR-026](adr-026-llm-provider-allowlist.md), [ADR-030](adr-030-llm-curated-tool-access.md), [ADR-078](adr-078-phi1-enforced-at-the-provider-chokepoints.md).
- `CLAUDE.md` §11, §9.9 (PHI-1, PHI-5, PHI-6), Rules 6, 7, 10.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Anant Sharma (AI-assisted) | Initial version |
