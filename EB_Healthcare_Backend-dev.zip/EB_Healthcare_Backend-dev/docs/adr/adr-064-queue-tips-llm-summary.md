# ADR-064: LLM-Phrased Operational Suggestions — Numbers In, One Sentence Out, No PHI
### (covers both Live Queue congestion tips and cross-clinic practitioner workload tips)

**Doc status:** living · **Created:** 2026-09-10 by Divyanshu (AI-assisted) · **Updated:** 2026-09-12 by Divyanshu (AI-assisted) · **Version:** 1.28

**Title widened from "Queue Tips Summary" at v1.1** — the product owner asked for a second,
distinct suggestion type (cross-clinic practitioner workload) that shares the exact same design
principle. Filename kept per ADR-043 (an ADR's identity is its filename); see revision history.

- **Status:** Proposed
- **Date:** 2026-09-10
- **Supersedes:** [`adr-063-clinical-command-center-reassign-and-stage-logging.md`](adr-063-clinical-command-center-reassign-and-stage-logging.md) — §"Role-based tips" (Decision §3) only. ADR-063's reassign flow and Queue Stage Log decisions are untouched and remain in force.
- **Superseded by:** —

## Context

ADR-063 built the Command Center's tips panel (`QueueTipsPanel`) as a deterministic, rule-based
feature and explicitly **rejected** LLM-generated tips in its own Alternative 3, citing ADR-026 /
ADR-030 tool-registry governance and scope creep. That ADR's §9 ("known gaps," see
`docs/CLINICAL_COMMAND_CENTER.md`) also recorded that the panel does not yet read live Queue Stage
Log data: there is no exposure of an open row's running duration, and no comparison against the
historical per-room average that `_build_queue_stage_breakdown`
(`api/v1/appointments/report.py`) already computes for reporting.

The product ask that produced this ADR has three parts:

1. Wire the panel to live Queue Stage Log data (an open card's actual running duration, and how
   that compares to the historical average for its room) — this alone does not touch ADR-063's
   LLM decision at all.
2. Collapse the panel to one short summary line by default; a single button both re-fetches fresh
   numbers and expands the full detail list.
3. Have that one summary line **phrased by an LLM**, not a fixed Python template.

Item 3 is what reopens the question ADR-063 already closed. This ADR exists to decide, narrowly,
whether and how an LLM may be used here — not to reopen tip selection, the reassign flow, or
anything else ADR-063 decided.

Constraints already in force that bound this decision:

- **Rule 9** (pipelines over agents) — no autonomous reasoning; the agent, if any, is a single
  bounded call, not a loop that decides things.
- **Rule 10 / §9.9 PHI-6** (minimum necessary) — a call gets the narrowest data that answers the
  question; widening it is a decision, not a convenience.
- **ADR-026** — any LLM call goes through the shared allowlist dispatcher
  (`services/llm.py::get_llm_client()`), and a genuinely new capability needs a shared-interface
  implementation on both approved providers.
- **Rule 4** — the LLM never sees the database or raw records; it only ever receives what a tool
  or service function hands it.

The team states a Business Associate Agreement is in place with the active LLM vendor(s). This
ADR's safety case does not rely on that fact, and does not restate or verify it — a BAA is a
contractual protection for *if* PHI is disclosed, not a reason to disclose more than a feature
needs. The design below keeps patient-identifying data out of the prompt regardless of what any
BAA would permit, because it is cheaper to audit a call that structurally cannot contain PHI than
to rely on a contract for one that could. (Per PHI-1, the durable record of any signed BAA belongs
in the compliance profile / `docs/compliance/HIPAA_READINESS.md`, not in this ADR.)

**A second suggestion type, added to this ADR at v1.1, with higher real-world stakes.** The
product owner separately asked for a cross-clinic practitioner workload suggestion: a practitioner
who works at more than one clinic may be scheduled/blocked for the same number of hours at each,
even when one clinic has far fewer booked appointments than the other on a given day (e.g. 10
appointments at Clinic A vs. 100 at Clinic B, same blocked hours at both). The ask is for the
system to notice this and suggest the practitioner could reasonably end their day early at the
lighter clinic.

This is a materially different — and materially higher-stakes — case than a queue-congestion
notice. A wrong queue tip is an ignorable notification. A wrong "you can leave early" suggestion
is an input to an actual staffing decision: acted on incorrectly, it could leave a clinic
short-staffed or a patient unseen. That raises, rather than lowers, the bar for keeping the actual
judgment call (is there really enough slack to justify this?) in code that can be pointed at and
tested, with the LLM's role limited to phrasing — exactly the same principle already chosen below
for queue tips, now confirmed as the design for both suggestion types after this was discussed
directly with the product owner.

**Verified 2026-09-10 — the cross-clinic data model does not exist, and building it now was
rejected.** `Healthcare Practitioner.custom_company` is a single Link, confirmed orphaned by
`docs/audit/settings/07-practitioners.md` PR5 (never populated by any API or UI); `Practitioner
Schedule` has no company field at all; `CHANGELOG.md`'s 2026-09-03 entry independently confirms
this deployment is single-clinic today. **Per direct product-owner instruction, the cross-clinic
comparison is deferred — permanently out of scope until a real second clinic exists to design and
test against, not re-attempted on a guess.** §3b below now describes the single-clinic version
that was built instead: the same underlying "expected time needed vs. actually scheduled" math,
scoped to the one clinic that exists, so a real second clinic later is an extension (add a
`company` grouping) rather than a rewrite.

**v1.4 addition (2026-09-10) — role-scoped facts: idle/backed-up rooms and lateness-vs-scheduled-slot.**
Product ask, in three parts: (1) surface when a room is empty while another is backed up — "blank
or overcrowded" — as a suggestion, not just the existing busiest/slowest-vs-average facts; (2)
surface how late a specific appointment is running **against its originally scheduled slot**, not
just its time in the *current* room stage (`get_open_row_durations` already gives the latter); (3)
make every fact role-specific, tied to what that role can actually act on, not just what they can
see.

Two things had to be resolved before this could be designed, both checked directly against code
rather than assumed:

- **"Overcrowded" is a judgment call, and ADR-063 already declined to make that same kind of call
  once.** ADR-063 explicitly dropped a per-room *delay* threshold on direct product-owner
  instruction — no code declaring a duration "too long," no `delayed` field, no threshold config
  (`docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md` §9, restated in
  `docs/CLINICAL_COMMAND_CENTER.md`). A hardcoded or historically-derived "this count is too many"
  verdict is the same shape of decision, on a count instead of a duration, and this app also has
  **no existing capacity or historical-count concept to derive one from** — `Queue Stage Log` has
  no capacity field, no Company/Healthcare Settings room-limit field exists, and the only
  "capacity" anywhere in the codebase (`Healthcare Service Unit.service_unit_capacity`) is a
  booking concept, unrelated to live queue occupancy (verified by full-repo grep, 2026-09-10). Given
  that precedent and that absence, this ADR does **not** introduce a crowding verdict. It reports
  the **imbalance itself** — one room empty while another is not — as a plain fact, the same way
  `longest_wait` already reports a raw number without judging whether it is "too long." See
  Alternatives below for the options considered and why an imbalance fact, not a threshold, was
  chosen.
- **Which two rooms are worth comparing is role-specific, not global.** A fact about rooms neither
  Nurse nor Front Desk can move a patient between is trivia, not a suggestion — it names a problem
  with no lever next to it. Verified directly against `EB_Healthcare_Frontend`'s role/capability
  code (`src/lib/narzim/roles.ts`, `ROOM_ROLES` in `mission-control-client.tsx`) which room-to-room
  moves each role can actually perform: Front Desk owns Arriving Soon and Waiting Room and holds
  `reassign=true`; Nurse owns the Waiting Room → Nursing Room move and also holds `reassign=true`;
  Practitioner owns only their own patient's encounter (no reassign, no cross-room move); Admin is
  unrestricted everywhere. Each role's new fact is scoped to the room pair (or, for Admin, the
  whole board) that role can actually act on — detailed per role below.

The two design questions this raised while scoping §3b were resolved during implementation, not
left open:

- **`avg_consult_minutes` fallback for a practitioner with no history:** resolved as a
  clinic-wide average for the same room (no practitioner filter) — a computed fallback from real
  data, never a hardcoded constant (`[[feedback_no_hardcoded_limits]]`). If even that is `None`,
  the endpoint says so (`available=False, reason="not_enough_history"`) rather than guessing.
- **The "is this slack worth mentioning" threshold:** resolved as `scheduled_minutes > 0 and
  slack_minutes > 0` — no invented percentage cutoff, just "there is real, positive spare time."
  Deliberately conservative, not validated against real usage yet.

Still genuinely open: which screen/role shows this suggestion (the practitioner's own dashboard,
the Providers screen, or elsewhere) — a product decision, not made yet; the backend does not
depend on it. Confirmed, per direct product-owner instruction: this suggestion is
**informational only** — it never edits or shortens a practitioner's actual blocked schedule. The
practitioner decides whether to act on it, consistent with Rule 6 (AI/system suggests, human
acts).

## Decision

An LLM may phrase — and only phrase — a single short sentence summarizing an operational
suggestion, generated on demand from a stats payload built entirely out of already-computed,
non-identifying numbers. **The LLM never selects, ranks, or decides which suggestions exist or
whether a threshold was crossed; that logic is always deterministic Python.** This principle
governs both suggestion types below identically — only the numbers going in differ.

### 3a. Queue congestion tips (Live Queue screen)

1. **Live data (independent of the LLM question).** Add `get_open_row_durations()` to
   `services/queue_stage_log.py` — read-only, returns each open Queue Stage Log row's running
   `now() - entered_at`, keyed by appointment. This closes ADR-063 §9's recorded gap.
2. **New whitelisted method** `regenerate_queue_tips()` in the dashboard API module, called only
   when a user clicks the panel's button — never polled, never scheduled, never on a timer.
   **Amended at v1.23, reverted at v1.25** — briefly also called once on mount (§3s), reverted
   back to click-only per direct instruction after an unrelated bug investigation (§3u). It:
   a. Computes deterministic tip candidates from live open-row durations (step 1) plus the
      existing historical per-room average (`_build_queue_stage_breakdown`).
   b. Assembles a stats dict containing only: room name, counts, live minutes, historical average
      minutes. No patient name, MRN, DOB, or free text of any kind goes into this dict.
   c. Calls `get_llm_client().generate_ops_tip_summary(stats)` — a new, narrow, single-purpose
      method added to both `integrations/openai.py` and `integrations/anthropic.py` (the ADR-026
      shared-interface requirement), modeled directly on the existing `generate_thread_title()`
      precedent (`integrations/openai.py:1262`) — a small, disposable, single-purpose call with
      its own prompt file, not folded into any larger prompt.
   d. Logs the call via the existing `log_prompt_call_general()` (`services/ai.py:629`) — the
      sibling already built for exactly this: a non-encounter, by-construction-no-PHI LLM call.
   e. Returns `{summary, tips[], generated_at, model}`. `tips[]` is the same deterministic
      structure ADR-063 already designed; the LLM never sees or produces it — only `summary` is
      LLM output.
   f. **(v1.4)** Before assembling the stats dict, compute additional candidate facts — deterministic,
      never delegated to the LLM — scoped to what the resolved `audience` can actually act on:
      - **Nurse:** compare `by_room["waiting_room"]` and `by_room["nursing_room"]` counts only (the
        one move a Nurse can make). If Nursing Room's count is 0 and Waiting Room's is not, that is
        the fact — an idle downstream stage while an upstream one backs up. No historical baseline,
        no threshold; a plain "this is 0, that is not" check.
      - **Front Desk:** compute `wait_minutes = now − appointment_datetime` (the exact math
        `_wait_minutes()` in `api/v1/dashboard/api.py` already uses for the live "Nhr Nmin" card
        badge — reused, not reinvented) for every open appointment whose current room is
        `arriving_soon` or `waiting_room` (the rooms Front Desk owns and can reassign out of), and
        take the largest. Reports the raw number, same pattern as the existing `longest_wait` tip.
      - **Admin:** the board-wide version of the Nurse check — any room at a live count of 0 while
        another room's count is meaningfully ahead of it, across all five rooms, no room-pair
        restriction (Admin can act anywhere). Plus a rollup: the count of currently-open
        appointments with `wait_minutes > 0` and the single worst value among them — both raw
        numbers, not a verdict on whether that count is acceptable.
      - **Practitioner:** unchanged — still gets nothing from this mechanism (see Context §3b for
        where a practitioner-facing lateness fact belongs instead).
      When a role now has more than one candidate fact, Python orders them (most-actionable first);
      the prompt's per-audience instructions (not free LLM judgment) decide how much of each makes
      the one sentence — see `prompts/ops-tip-summary-v1.txt`. The LLM still never decides *whether*
      something is worth mentioning; it only phrases what Python already selected and ordered.
      New stats-dict keys these facts require (still PHI-free, room/count/minute values only):
      `idle_room`, `busy_room` (Nurse/Admin pair), `most_overdue_minutes`, `most_overdue_room`
      (Front Desk/Admin), `overdue_count`, `worst_overdue_minutes` (Admin rollup) — each added to
      the existing key-allowlist test (`tests/appointments/test_queue_tips.py`) as a deliberate,
      reviewed addition, per that test's existing "allowlist, not blocklist" design.
3. **Frontend** `QueueTipsPanel` collapses to `summary` by default. One button both re-fetches
   (regenerates) and expands to show `tips[]`. If the LLM call fails, the panel shows `tips[]`
   with no summary line — it never breaks or blocks (Rule 7).

### 3b. Practitioner workload/slack tip — single-clinic version (built; cross-clinic deferred)

The cross-clinic version originally described here was not built — see Context for why (no
working multi-clinic data model exists, confirmed 2026-09-10). What shipped instead, per direct
product-owner instruction, is the same underlying comparison scoped to the one clinic that exists:

1. **Deterministic computation, per practitioner per day, one clinic:**
   - `appointments_today` = count of that practitioner's `Patient Appointment` rows for today,
     excluding Cancelled/No Show.
   - `avg_consult_minutes` = `_build_queue_stage_breakdown`'s existing duration analytics, scoped
     to `practitioner_room` and filtered to this practitioner. **Fallback, resolved:** when this
     practitioner has no history, the same call with no practitioner filter (the clinic-wide
     average) is used instead — computed from real data, never a hardcoded constant
     (`[[feedback_no_hardcoded_limits]]`). If that is also `None`, the endpoint returns
     `available=False, reason="not_enough_history"`.
   - `expected_minutes_needed = appointments_today × avg_consult_minutes`.
   - `scheduled_minutes` = new `services/availability.py::get_scheduled_minutes_for_date()` — the
     day's `Practitioner Schedule` blocks minus `Unavailable` overrides plus `Available` overrides
     not already covered by the normal schedule, reusing ADR-062's own primitives so it can never
     disagree with what booking allows.
   - `slack_minutes = scheduled_minutes - expected_minutes_needed`.
2. **Threshold, resolved:** `scheduled_minutes > 0 and slack_minutes > 0` — no invented percentage
   cutoff, just "there is real, positive spare time and a real schedule to compare it to."
   Otherwise `available=False, reason="no_notable_slack"`. Deliberately conservative; not yet
   validated against real usage. Always a Python decision, never delegated to the LLM.
3. If available, the same `generate_ops_tip_summary()` call as §3a — fed
   `{language, appointments_today, expected_minutes_needed, scheduled_minutes, slack_minutes}`,
   no patient data. Logged via `log_prompt_call_general(purpose="Workload Tip Summary", ...)`.
4. **Informational only** — no button or action edits the practitioner's schedule. The
   practitioner reads it and decides for themselves.
5. Built in `api/v1/providers/api.py::get_my_workload_suggestion()` — a self-service endpoint via
   `_session_practitioner()`, same ownership convention as `get_my_holidays`. Screen/role ownership
   for the frontend is still not decided — the backend does not depend on it.

### 3c. v1.6 addition (2026-09-10) — a named next step per fact, and two new facts

Product feedback on v1.5, in three parts: (1) every fact so far only described a number — it never
said what to do about it, which made the whole feature "not helpful" in practice; (2) Nurse should
be told specifically when Nursing Room patients have no vitals recorded yet; (3) the Practitioner
workload suggestion (§3b) should react to what has actually happened *so far today*, not only a
start-of-day forecast — e.g. "you've spent 2 hours on 2 patients, 8 remain, you may be running long."

**The next-step question resolved the same way the crowding question was resolved above: fixed in
code, never left to the LLM to invent.** Every next step is a **fixed, deterministic phrase tied to
a specific fact**, written into `prompts/ops-tip-summary-v1.txt`, not a new field the LLM composes —
identical in spirit to the audience-priority instructions the prompt has carried since v1.3. This
stays inside Rule 9 (code decides what's true and what's worth saying) and Rule 6 (nothing here
clicks anything; a next step in a sentence is still just information — the nurse still has to click
the actual move/record-vitals control herself). It also stays operational-only, never clinical, per
the prompt's existing rule 6 ("no clinical action, diagnosis, or treatment") — "move a patient,"
"record vitals," "collect a payment," "check someone in," "review staffing" are all logistics, none
of them a clinical judgment.

**New fact — Nurse: vitals not yet recorded.** For every appointment currently in Nursing Room,
check for an existing Vital Signs record — reusing the exact existence-check `get_dashboard_data`
already performs for its own `vital_by_appt` lookup (`api/v1/dashboard/api.py:344-361`), not a new
query shape. `vitals_missing_count` is the count with none. A plain existence check, no threshold to
invent — same category as the already-accepted `payment_pending` fact.

**New fact — Practitioner: mid-day pace check (§3b extension).** Independent of the existing
start-of-day slack forecast (which uses the *historical* average consult time), this uses **today's
actual completed Practitioner Room stays** to project whether the remaining appointments are likely
to fit in the time actually left in the schedule. Fires only on a real, positive gap — same "no
invented threshold" rule as everything else in this ADR, just recomputed from what has already
happened today instead of history. Notably, this makes the endpoint useful on a day with **no prior
history at all** (which previously meant an automatic "not_enough_history"), since it needs only
today's own data — the two facts (slack, pace) are independent and either can carry the response on
its own.

**Status: built and unit-tested, 2026-09-10** — 34/34 tests passing across both mechanisms
(`tests/appointments/test_queue_tips.py`, `tests/providers/test_workload_suggestion.py`), verified
live against the running site for both the Nurse vitals-missing path and the Practitioner pace/slack
path.

### 3d. v1.7 addition (2026-09-10) — Practitioner Room attention, multi-role users, and a real bug found live

Three more items of direct feedback: (1) Nursing Room and Practitioner Room were under-served — Nurse
only ever compared Waiting Room against Nursing Room, nothing looked at how long a patient has
actually been *with the practitioner*; (2) a Nurse should see a Practitioner Room fact too, since
she can open/draft (though not sign) an encounter there per the verified role-action map; (3) a user
holding more than one role (e.g. Nurse + Front Desk) was only ever getting the single
highest-priority role's facts, silently dropping the others.

**New fact — a patient stuck with the practitioner.** `_room_duration_outlier_fact(by_room,
historical, room)` — a live duration in the given room exceeding that room's own historical
average is the fact; no baseline (no completed history for that room yet) means no fact, never a
guess. Wired to Nurse only, awareness-only (no forced next step — a Nurse cannot make the
practitioner finish faster). Admin deliberately excluded for this round, per direct instruction —
scope kept to exactly what was asked, not broadened on a guess.

**Multi-role handling.** `_resolve_audience()` (singular, one winner) is superseded by
`_resolve_audiences()` (the full set of matched roles). The mutually-exclusive board-wide facts
(`idle_room`, `most_overdue`, `overdue_rollup` — they share stats keys, so only one verdict can
occupy each) are still computed from a single `primary` role (same admin > nurse > frontdesk
priority as before) to avoid two different verdicts silently overwriting each other. The additive,
uniquely-keyed facts (`vitals_missing_count`, `practitioner_room_*`, `payment_pending_count`) are now
computed whenever the relevant role is anywhere in the held set, not only when it is `primary` — a
Nurse + Front Desk user gets Nurse's board-wide fact **and** Front Desk's payment/overdue fact in
the same summary. The prompt's three separate per-audience priority lists are replaced by one fixed,
audience-independent priority list keyed on which fields are present — this was already effectively
how "admin" handled multiple candidate facts, now applied uniformly, and it is what actually makes
multi-role support work without a combinatorial explosion of per-combination prompt instructions.

**A real bug found live while testing this, fixed before shipping.** The original board-wide
`idle_room` check (v1.4) compared *any* empty room against the single overall busiest room,
regardless of workflow position. Verified live against this dev site's real board, it produced:
*"Checkout está vacío... podría mover a un paciente de Arriving Soon a Checkout"* — recommending a
patient skip Waiting Room, Nursing Room, and Practitioner Room entirely. Fixed by restricting the
board-wide check to **adjacent pairs only**, walked in actual pipeline order
(`arriving_soon → waiting_room → nursing_room → practitioner_room → checkout`) — a later stage empty
while the one immediately before it is busy is a real, single, physically possible move; a
non-adjacent pair never is. Re-verified live after the fix: the same board now correctly reports
*"Checkout está vacío mientras Practitioner Room tiene 1 paciente... podría mover a un paciente de
Practitioner Room a Checkout."*

**Status: built, tested, and the live-caught bug fixed — 2026-09-10.** 44/44 tests passing
(`tests/appointments/test_queue_tips.py`), including new tests that lock in the adjacency fix so it
cannot regress. Verified live for `["nurse"]`, `["nurse","frontdesk"]`, and `["admin"]` — the
multi-role case confirmed Front Desk's `most_overdue` fact correctly appended even with Nurse as
primary.

### 3e. v1.8 addition (2026-09-10) — vitals done but still stuck, for Nurse and the practitioner

Direct feedback with a concrete example: a real patient (B Praak) sitting in Nursing Room with
vitals already recorded — 7h47min there — and nothing in this feature said anything about it.
`vitals_missing` only covers the opposite case (vitals not yet done); nothing covered "vitals are
done, but the patient hasn't moved on."

**New shared fact — `patient_ready_and_waiting_fact()`.** Moved into `services/queue_stage_log.py`
(not kept private to one API module) because both Nurse and a practitioner need the identical
judgment, just over different scopes: a patient who already has a Vital Signs record but has been
in Nursing Room longer than that room's own historical average. No invented threshold — no real
baseline means no fact, same rule as every duration fact in this app.

- **Nurse** (`api/v1/dashboard/api.py`, board-wide): any such patient, anywhere on the board.
- **Practitioner** (`api/v1/providers/api.py::get_my_workload_suggestion`, new): pre-filtered to
  **that practitioner's own patients only**, before the duration judgment ever runs — Rule 10/PHI-6
  minimum necessary. A practitioner never learns anything about another practitioner's patients
  through this endpoint. This is a third, independent fact alongside the existing slack forecast and
  mid-day pace check — it can carry the response on its own even when neither of the other two has
  anything to say (verified live: `slack_minutes=None`, `completed_count=0`, `available=True`, driven
  entirely by this fact).

**Status: built and verified live, 2026-09-10.** `tests/appointments/test_queue_stage_log.py` gained
`TestPatientReadyAndWaitingFact` (6 pure-function tests, the shared judgment itself);
`tests/appointments/test_queue_tips.py` and `tests/providers/test_workload_suggestion.py` each
gained a wiring test mocking the shared function at its import boundary. 64/64 tests passing across
all three files. Live-verified against the exact reported scenario: Nurse's summary correctly named
the room and both durations; the real Anant Sharma practitioner account received the
practitioner-facing phrasing for the same underlying patient.

### 3f. v1.9 addition (2026-09-10) — cover every applicable fact, not only the single leading one

Direct feedback: "you are showing just 1 info... these are the problems, not only one." Every
version through v1.8 deliberately picked the single highest-priority fact and covered only that one
(the original v1.0-1.3 design intent, carried through every revision since). Verified live moments
before this change that the board can genuinely have three-plus facts true at once for a single
audience (Admin: `idle_room` + `most_overdue` + `overdue_rollup` simultaneously) — the old rule was
silently discarding two of the three every time.

**Fix: `prompts/ops-tip-summary-v1.txt` rewritten from "pick the first and stop" to "cover every
fact present, in the fixed 1-7/1-3 order, each as one short clause."** Still the same boundary as
every revision before it — Python decides which facts are true, the LLM only phrases them, in the
same fixed order, never choosing what to include or omit. The output is now 1-4 short sentences
instead of always exactly one. No stats-dict or response-shape change — same fields, same `tips[]`,
same `summary: str`.

**A real, unresolved frontend consequence, flagged rather than silently left:** `QueueInsightBar`'s
summary span (`EB_Healthcare_Frontend/.../mission-control-client.tsx:2655`) uses Tailwind's
`truncate` (single line, ellipsis-cut) with a `title` attribute for the full text on hover. A
multi-fact summary will now visually clip in the board itself — the full text is still reachable via
hover, but "the collection of problems" this revision was asked for will not be visible at a glance
without one. Not fixed in this revision — the fix is a frontend layout decision (wrap the text
instead of truncating; a small height increase) that needs its own confirmation before touching that
repo, per this app's standing frontend-is-read-only-by-default rule.

**Separately investigated in the same round: why nothing shows for a plain `EB_Practitioner`
session.** Confirmed by a full-repo grep of `EB_Healthcare_Frontend` — zero files reference
`get_my_workload_suggestion` at all. Not a bug in the backend (verified live and by 64 passing tests
across three test files) — there is simply no frontend screen, button, or component wired to this
endpoint yet. This is the exact, previously-recorded open item from §3b/§4 ("Not built: the frontend
surface") — still open, not addressed by this revision.

**Status: prompt rewritten and live-verified, 2026-09-10.** No Python/test changes needed — the
change is entirely in `prompts/ops-tip-summary-v1.txt`, which the existing 64 tests do not exercise
(they mock the LLM client's return value directly). Verified live: an Admin call with `idle_room`,
`most_overdue`, and `overdue_rollup` all true produced one summary correctly covering all three.

### 3g. v1.10 fix (2026-09-10) — a stale prior-day Queue Stage Log row, misread as "AI hallucination"

Reported as an AI hallucination: the summary named "Waiting Room" as 1381 minutes overdue while the
board plainly showed Waiting Room empty. **Investigated directly against the database — it was not
a hallucination.** `get_dashboard_data` has always filtered appointments to
`appointment_date == target_date` (`api/v1/dashboard/api.py:275`); `regenerate_queue_tips` never
did. A real appointment (`HLC-APP-2026-00378`) had a Queue Stage Log row that entered `waiting_room`
the previous evening and was never closed or moved — `get_open_row_durations()` has no date
awareness of its own, so it read that stale row as a live patient indefinitely (1381 minutes ≈ 23
hours ≈ "since yesterday evening," confirmed by the row's own `entered_at`). The LLM faithfully
phrased a number Python computed from bad, wrong-day input — this is a real Rule-9 boundary held
correctly (the LLM never invented a room; it was handed one).

**Fix:** both `regenerate_queue_tips` (`api/v1/dashboard/api.py`) and `_my_ready_patient_fact`
(`api/v1/providers/api.py`, the practitioner-facing sibling) now filter to appointments whose
`appointment_date` is today, matching the exact scope `get_dashboard_data` already uses — the two
should never have been able to disagree about what "live" means. An earlier comment on this
function claiming "there is no which-date ambiguity" was itself wrong and is corrected.

**Not fixed, flagged as a deeper root cause:** nothing in this app currently closes out a Queue
Stage Log row left open past its day — this is the second such stale row found in this database in
one session (`HLC-APP-2026-00326`, `HLC-APP-2026-00378`, both entered 2026-09-09 evening). The
per-call date filter above stops it from corrupting a summary, but the underlying rows stay open
forever unless something explicitly closes them. Worth a follow-up decision (an end-of-day sweep
job, or an explicit "abandon" action) — not built here, since it is a new mechanism, not a fix to
this feature.

**Status: fixed and live-verified, 2026-09-10.** 64/64 tests still passing (all test fixtures book
for "today," so unaffected by the new filter). Re-ran against the real board after the fix: numbers
dropped from an impossible 1381/1390/1460-minute range to a realistic 417-506 minute range
consistent with today's actual activity since ~10 AM, and `overdue_rollup`'s count correctly fell
from 6 to 4 once the two stale rows were excluded everywhere, not just in one fact.

**Separately confirmed in the same round: the "no summary for EB_Practitioner" report is the same,
already-recorded by-design behavior, not a regression.** `_resolve_audiences(["practitioner"])`
still correctly returns an empty set for this mechanism — see §3d — nothing changed here.

### 3h. v1.11 addition (2026-09-10) — a bare Practitioner rides this same mechanism, scoped to their own day

Direct instruction: "for practitioner we have to use all the appointments for that practitioner in
all queue for that day." §3d had already found that `get_my_workload_suggestion` (the mechanism
built for exactly this) has no frontend surface calling it — so a Practitioner-only session got
nothing from either mechanism. Rather than build a new screen, this wires Practitioner into the
mechanism that already has a working screen (`QueueInsightBar`).

**`_resolve_audiences` now matches "practitioner"** (previously deliberately excluded). A bare
Practitioner session (`audiences == {"practitioner"}` exactly — a session holding a staff role too
keeps the board-wide view for that role) filters `live` to only their own appointments, across all
five rooms, before any fact computation runs — Rule 10/PHI-6 minimum necessary; a practitioner has
no operational reason to see another practitioner's patients on this board, unlike Nurse/Front
Desk/Admin whose job is the whole board. Every existing fact function (busiest room, longest wait,
most overdue, vitals-missing, ready-and-waiting) applies unchanged, just over this narrower `live` —
no new fact-computation code was needed for those. `idle_room` and `overdue_rollup` do NOT apply to
a bare Practitioner — both are board-wide imbalance/staffing facts a lone practitioner has no lever
over (no reassign, no cross-room move, per the verified role-action map from earlier in this ADR).

**A real scoping-correctness issue found and fixed before shipping, not after:** a Practitioner's
`by_room` counts are now their own-patients-only, but the room they're in may hold other
practitioners' patients too. Phrasing "Arriving Soon has 2 patients" for a practitioner with 2 of
their own appointments there — while the room might actually total 5 — would misstate a room's real
occupancy as a fact, not merely omit context. Fixed with a new `own_appointments_only: true` stats
flag, read by the prompt to phrase every room-based fact as "you have N of your own patients in
[room]" rather than "[room] has N patients."

**Status: built, tested, and live-verified, 2026-09-10.** 69/69 tests passing, including a new
`TestPractitionerAudience` (DB-backed, not pure-function, because the thing under test — excluding
another practitioner's real appointments — only means something against real rows). Live-verified
against the actual Sarvesh Sandhu practitioner account: correctly returned *"Your patient in
Arriving Soon is 533 minutes overdue; check them in,"* scoped to exactly his one appointment
(`count: 1`) on a board that had appointments for four other practitioners at the time.

A real test-fixture bug was caught and fixed during this work, not shipped: the first version of
`TestPractitionerAudience`'s helper created a User linked to a Healthcare Practitioner but never
granted the `EB_Practitioner` Frappe role — Queue Stage Log and Patient Appointment are both
permission-checked doctypes, so the session saw zero rows and every new test errored with a
`NoneType` (the LLM was never even called). This is worth naming because it is exactly the shape of
bug a real multi-role production account could also hit if provisioned incompletely — the fix
(granting the role) is the same either way.

### 3i. v1.12 addition (2026-09-11) — durations formatted as hours, not raw minutes

Direct instruction: "if min is greater than 60 than we have to show in the hours" — the LLM-phrased
summary was reading a raw count like "533" as "533 minutes" in a sentence, where the Live Queue
board's own card badges already show the same figure as "8hr 10min." The two should never disagree
on how a duration reads.

**New shared function `format_minutes()`** in `services/queue_stage_log.py` — "8hr 10min" for 490,
"45min" for 45 (hours omitted below 60), "2hr" for an exact multiple of 60, `None` in → `None` out
(a genuinely absent historical average must not become a fabricated "0min"). Deliberately **not**
applied inside the fact functions themselves (`_room_duration_outlier_fact`, `_most_overdue_fact`,
etc. all still return plain ints, comparable/testable as numbers) — only the caller assembling the
LLM-facing `stats` dict formats for display, keeping compute and presentation at the same boundary
every other display-only decision in this ADR already sits at.

Applied in `regenerate_queue_tips` to every room's `live_avg_minutes`/`historical_avg_minutes` and to
`most_overdue_minutes`/`worst_overdue_minutes`/`practitioner_room_live_minutes`/
`practitioner_room_avg_minutes`/`nursing_ready_live_minutes`/`nursing_ready_avg_minutes`; in
`get_my_workload_suggestion`, to the equivalent slack/pace/ready-fact keys — **in `stats` only,
never in `common_fields`** (that endpoint's actual JSON response keeps plain integer minutes, since
that is its real API contract and not something to change as a side effect of a phrasing fix). Counts
(`busy_count`, `overdue_count`, `payment_pending_count`, `appointments_today`, `completed_count`,
`remaining_count`) are untouched — only genuine durations are reformatted. `prompts/ops-tip-summary-v1.txt`
updated to state every `*_minutes` field already arrives as a formatted string, quote it exactly,
never recompute or append "minutes."

**Status: implemented and live-verified, 2026-09-11.** Pure-function check: `format_minutes` matches
the exact board convention across the full range (0, 5, 45, 59, 60, 61, 65, 120, 125, 490 → `0min`,
`5min`, `45min`, `59min`, `1hr`, `1hr 1min`, `1hr 5min`, `2hr`, `2hr 5min`, `8hr 10min`). End-to-end
wiring check: intercepted the exact `stats` dict handed to a mocked LLM client for a real,
temporarily-created 95-minute-overdue appointment — confirmed `most_overdue_minutes`/
`worst_overdue_minutes` arrived as `'3hr 58min'` and room averages as `'1hr 35min'`/`'3hr 27min'`,
with `busy_count`/`overdue_count` correctly left as plain integers. Scenario created and cleaned up
directly against the live database (this dev site had no live queue data on the day this shipped).

**A pre-existing gap found while doing this work, unrelated to the fix itself, worth recording
plainly rather than silently working around:** the three test files this whole ADR's automated
coverage depended on — `tests/appointments/test_queue_tips.py`, `tests/appointments/test_queue_stage_log.py`,
`tests/providers/test_workload_suggestion.py` — are missing from disk as of 2026-09-11 (only stale
`.pyc` cache remains; `git status` shows no trace, since they were never committed). The feature code
itself (this ADR, the prompt, `services/queue_stage_log.py`, and the two API files) is untouched and
intact. Cause unconfirmed — this appears to be a shared dev environment (other files not touched by
this line of work are also modified: `docs/KNOWN_ISSUES.md`, `adr-062`, `patient_portal/api.py`), so
this was not chased down further. **This ADR's automated test coverage does not currently exist on
disk** and needs to be rebuilt before this feature can be called properly tested again — not done as
part of this fix, since rewriting three test files from memory risks compounding an already-surprising
state with unverified guesses.

### 3j. v1.13 addition (2026-09-11) — "cover reassign and practitioner availability too"

Direct instruction, following up on the earlier session's gap review: extend the summary to also
flag appointments whose assigned practitioner is unavailable — the exact situation reassignment
exists to fix. Researched first, not assumed: `_REASSIGN_ROLES` (Admin, Nurse, Front Desk — never
Practitioner, `appointments/api.py:2410`) already matches this ADR's existing reassign-adjacent
role gating exactly, so no new role logic was needed. No existing function answers "is this
practitioner unavailable today" directly — composed from two real signals.

**A real design bug caught and fixed via live testing, not shipped:** the first version used
`assert_bookable()` (the same write-time guard `reassign_appointment` itself calls) as the sole
check, on the reasoning that reusing an existing, proven function beats reinventing time-overlap
math. Live-tested by temporarily adding a real entry to a practitioner's actual Company Holiday
List (Anant Sharma's, 52 real entries) and re-running the check — **the fact never fired.**
Investigated why rather than assuming the test was wrong: `assert_bookable`'s own holiday check
(`check_employee_wise_availability`) is Employee-linked-leave, already confirmed dead in this
deployment (zero Healthcare Practitioner records carry an Employee link) — so a real Company
holiday has zero effect on it. Fixed by composing `assert_bookable()` (real, time-window-precise,
for Unavailable overrides) with `get_practitioner_holidays()` (the actual live holiday signal this
app has, `services/providers.py`) — re-tested with the same real, temporary holiday entry, and the
fact correctly fired at `count=21` (this practitioner's full reassignable-stage appointment count
for the day), with the real LLM correctly phrasing *"21 appointments today are booked with an
unavailable practitioner and must be reassigned to another practitioner."* The holiday entry was
removed immediately after (Holiday List restored to its original 52 entries, confirmed by count),
and a follow-up baseline call confirmed the fact correctly does not fire when nothing is unavailable.

**Deliberately per-appointment, not per-practitioner.** A single-hour Unavailable override must not
be read as "unavailable all day," over-counting every one of that practitioner's other, unaffected
appointments — each candidate appointment's own `appointment_time`/`duration` is checked against
`assert_bookable`, not a single whole-day yes/no per practitioner.

**Scoped to reassignable stages only** (`arriving_soon`/`waiting_room`/`nursing_room`) — matching
`_REASSIGNABLE_STATUSES` exactly: once a Patient Encounter exists, `reassign_appointment` itself
already refuses, so an appointment in `practitioner_room`/`checkout` is correctly excluded.

**A plain count, never naming a specific appointment, room, or practitioner** — per direct
product-owner instruction, and for a second reason found during design: this app's own
`get_reassignment_candidates()` doesn't filter candidates by availability either (confirmed via the
same research), so recommending a specific substitute practitioner would itself be a guess this
ADR's own restraint rule (state the fact, never invent the missing judgment) exists to prevent.

**Status: built and live-verified, 2026-09-11.** No automated test added at the time this fact
shipped (the three test files this ADR's coverage depended on were missing from disk, per the
earlier-recorded gap) — verified instead via a real, temporary Company Holiday List entry against a
real practitioner with real appointments, added and removed in the same session, with an explicit
before/after/restored count check at every step. **Later the same day:** this fact gained real
coverage — `TestPractitionerUnavailableForAppt` (the `assert_bookable`/`get_practitioner_holidays`
composition) and wiring tests on `regenerate_queue_tips` (`practitioner_unavailable_count` reaching
both `tips` and the LLM stats, and correctly never computed for a bare Practitioner) — as part of
rebuilding all three missing files; see the note at the end of §3i above and `WORK_LOG.md`.

### 3k. v1.15 addition (2026-09-12) — pace/throughput fact for Front Desk, Nurse, and Admin (decision only, not yet built)

Direct product ask: "we have this much time and these appointments, but we have completed only
this much — if we go with this pace we would not cover all; how much time we have to spend on each
[remaining one] to cover all." §3c already built exactly this for a practitioner's own day
(`_pace_fact`, §3c above) — this is the same fact, asked for every other role that already gets a
`regenerate_queue_tips` summary.

**Why this isn't a copy-paste of §3c's fact.** `_pace_fact()` itself is already role-agnostic — it
takes four plain numbers (`appointments_today`, `scheduled_minutes`, `completed_count`,
`time_spent_minutes_today`) and does not care whose day they describe. What a practitioner has, and
Front Desk/Nurse/Admin do not, is a real `scheduled_minutes` number to feed it —
`services/availability.py::get_scheduled_minutes_for_date()` reads that practitioner's own
`Practitioner Schedule`/`Practitioner Availability` rows. **This app has no equivalent concept for a
role, a room, or the clinic as a whole** — confirmed by grep: no "operating hours," "business
hours," or "clinic close" field exists anywhere in this codebase (`Company`, `Healthcare Settings`,
or otherwise). So the actual design question this section answers is narrow: **where does "how much
time is left" come from for these three roles**, given none of them has a schedule the way a
practitioner does.

**Four approaches were considered** (see the new Alternatives subsection below for the full
pros/cons table); **chosen: derive the deadline from the last actually-booked appointment of the
day**, never a new setting and never an aggregate of practitioners' own schedules.

**What would be built, once approved:**

1. **`_pace_fact()` moves from `api/v1/providers/api.py` into `services/queue_stage_log.py`**,
   alongside `patient_ready_and_waiting_fact()` and `format_minutes()` — the same reason §3e moved
   that function there: more than one API module needs the identical judgment over a different
   scope. `get_my_workload_suggestion()` (practitioner) keeps calling it exactly as today, unchanged
   in behavior; `regenerate_queue_tips()` becomes a second caller.
2. **New pure helper, `_remaining_window_minutes(now, deadline)`** — plain
   `max(0, round((deadline - now).total_seconds() / 60))` given a pre-computed deadline datetime;
   trivial, but kept as its own function so it is independently unit-testable rather than inlined.
3. **New query, one per call, not per role:** for the in-scope appointment set (Admin: every
   non-Cancelled/No-Show `Patient Appointment` for today, optionally company-filtered, matching the
   existing `appointments_today` count pattern in `get_my_workload_suggestion`; Nurse and Front Desk
   reuse the identical query — see below for why the *scope* differs only in which count/duration
   numbers are layered on top, not in which appointments are eligible for the deadline itself) — the
   deadline is `max(appointment_datetime + duration)` across that set. A day with zero appointments
   has no deadline and no pace fact — same "no real data, no fact" rule as everything else in this
   ADR.
4. **Per-role `completed_count` / `time_spent_minutes_today`, each reusing an existing query shape,
   not a new one:**
   - **Admin:** completed Practitioner Room stays today, clinic-wide (no practitioner filter) — the
     same query `_avg_practitioner_room_minutes(None)` already runs in `providers/api.py`, summed
     instead of averaged.
   - **Nurse:** completed Nursing Room stays today, clinic-wide — the same shape as
     `_avg_nursing_room_minutes()`, summed instead of averaged. Chosen over "same total as Admin"
     because every other Nurse fact in this ADR (`idle_room` restricted to the
     waiting/nursing pair, `vitals_missing`, `ready_but_stuck`) is already scoped to Nursing Room
     specifically — a clinic-wide Practitioner Room number would be the one inconsistent fact on
     this board.
   - **Front Desk:** completed Arriving Soon stays today (a completed `arriving_soon` Queue Stage Log
     row *is* a check-in, by this app's own room model) — same reasoning: every existing Front Desk
     fact (`most_overdue` restricted to `owned_rooms=(arriving_soon, waiting_room)`,
     `payment_pending`) is scoped to what Front Desk owns, never the whole board.
   - `remaining_count = appointments_today − completed_count`, identical to §3c's practitioner
     version.
5. **Gating:** Admin gets the fact whenever `"admin" in audiences`; Nurse whenever `"nurse" in
   audiences`; Front Desk whenever `"frontdesk" in audiences` — additive, same as every other
   uniquely-keyed fact since v1.7 (a Nurse+Front Desk user gets both). A bare Practitioner is
   untouched — they already have this exact fact through the existing §3h/§3c path and do not need
   a second, clinic-wide version.
6. **Stats-dict keys** (new, PHI-free — counts and minutes only, matching every existing key in this
   ADR's allowlist pattern): `pace_completed_count`, `pace_time_spent_minutes`,
   `pace_remaining_count`, `pace_expected_remaining_minutes`, `pace_remaining_window_minutes`.
   Prefixed `pace_` to avoid colliding with the practitioner-only, unprefixed
   `completed_count`/`remaining_count`/etc. keys `get_my_workload_suggestion`'s own prompt branch
   already uses (§0 of `prompts/ops-tip-summary-v1.txt`) — the two branches must stay
   unambiguous to the prompt, which currently tells them apart only by the presence/absence of a
   `rooms` key.
7. **Prompt:** a new numbered fact in the `rooms`-key branch of `prompts/ops-tip-summary-v1.txt`,
   phrased the same way §3c's practitioner branch already does ("you've completed N in M, K remain,
   at this pace expect roughly J more — about Y min each to cover all of them") — informational, no
   invented urgency beyond what the numbers already say, same restraint every fact in this file
   already follows.

**Status: decision recorded here; not yet built.** No file has been touched for this section
(§3k) — matching how this same ADR separated the v1.4 decision (line 743 below) from its build a
revision later. See `docs/OPERATIONAL_SUGGESTIONS.md` §3.3 for the same decision in mechanism-doc
form.

### Alternatives considered — the pace-fact "how much time is left" figure specifically (v1.15)

A practitioner's pace fact (§3c) compares expected-remaining-minutes against their own
`Practitioner Schedule`. Front Desk, Nurse, and Admin have no such schedule to compare against —
this is the decision for what stands in for it.

1. **Sum every practitioner's own `get_scheduled_minutes_for_date()` into one clinic-wide budget.**
   - Pros: Reuses real, already-trusted per-practitioner schedule data; no new query shape.
   - Cons: Doesn't correspond to what Front Desk or Nurse actually do — neither works "practitioner
     hours." A practitioner with no schedule row (a locum, or a misconfigured account) silently
     drops out of the sum rather than being flagged, understating the true remaining budget. The
     resulting number belongs to no one role — it's an average of several different people's days.
2. **Rate and a projected finish time only — no deadline, no "won't cover all" claim.**
   - Pros: Never invents a deadline at all, the most conservative option, fully consistent with
     this ADR's repeated "no invented threshold" rule (§3b's slack threshold, the room-crowding
     alternatives above).
   - Cons: Under-delivers on the actual ask — "you may finish around 4:40pm" is not the same
     statement as "you won't cover all of them at this rate," which is what was asked for.
3. **A new clinic-operating-hours setting** (e.g. a field on `Company`), giving every role a literal
   deadline the same way a practitioner's schedule does.
   - Pros: The most literal match to the practitioner version — a true configured deadline, not a
     derived stand-in.
   - Cons: A new field/migration/fixture, and its own ADR-worthy decision, before anything ships —
     and a genuine risk of building config nobody sets: a Nurse's shift end, a Front Desk shift end,
     and "when the clinic closes" are not necessarily the same time, so one field would not even be
     correct for all three roles. The same caution CLAUDE.md's PHI-3 applies to an unenforced
     retention number applies here to an unset or wrong operating-hours field: a number nobody
     maintains is worse than none.
4. **Derive the deadline from the last actually-booked appointment of the day — chosen.** `max(
   appointment_datetime + duration)` across today's real bookings (scoped by company), computed
   fresh per call from data that is already trusted for booking itself.
   - Pros: Zero new schema, zero new config, zero new judgment call — it is a fact already implied
     by what is booked, the same posture this ADR has taken toward every other number in it (derive
     from real data, never invent a constant). Applies uniformly to all three roles with the exact
     `owned_rooms`-style scoping this ADR already established for `_most_overdue_fact`. Errs in the
     safe direction: a day where staff work past the last booked slot produces a false *reassurance*
     (fact doesn't fire when it arguably should), never a false *alarm* (it can never fire "you're
     behind" against a deadline shorter than the real one).
   - Cons: "Last booked slot's end" is a soft proxy for an actual closing time, not a verified one —
     if a clinic reliably works later than its last booking (e.g. clean-up, charting), the fact will
     under-warn on those days. Accepted as the same category of known limitation this ADR already
     carries for the practitioner slack threshold ("deliberately conservative, not validated against
     real usage yet").

**Chosen: 4.** It is the only option that gives every role the actual claim asked for
("won't cover all at this rate") without inventing a number this deployment has no real source for
(3), without conflating multiple people's schedules into one figure nobody owns (1), and without
settling for a weaker, deadline-free statement than what was actually requested (2).

### 3l. v1.16 addition (2026-09-12) — worst wait among vitals-missing patients (a priority signal, not just a count)

Direct feedback, after a Nurse saw the panel live: "Nurse also know how many patients' vitals are
not recorded [already — it's the room's own header count] — give some productive info, not just
show the data." `vitals_missing_count` (§3c) restates a number already visible on the board
(Nursing Room's own occupancy count) and pairs it with a fixed instruction that doesn't say which
patient to see first — a real gap, not a misunderstanding of the feature.

**Investigated live before building anything, not assumed.** Two things were checked directly
against the running site (`remedisis.localhost`), both confirming the code already in production is
correct — the anomalies were in the data, not the logic:

- `nurse_pace` (§3k) returned no fact for this Nurse's real session. Traced to the actual Queue
  Stage Log rows: 60 "completed" Nursing Room stays today, `entered_at`/`exited_at` **30-90
  milliseconds apart** — a bulk seed script's synthetic data, not real consultations. `pace_fact`'s
  own math (average time per completed patient ≈ 0) correctly concludes there is no gap; this is an
  honest reflection of unrealistic input data, not a defect in the fact itself.
- A naive "longest current wait" check (run standalone, not through `regenerate_queue_tips`)
  produced a **1655-minute (27hr 39min)** wait. Traced to 22 Nursing Room Queue Stage Log rows still
  open from **2026-09-11**, never closed — the exact stale-row failure mode §3g (v1.9) already found
  and fixed once, recurring because (as v1.9 itself flagged and left unresolved) nothing in this app
  closes out an abandoned open row. `regenerate_queue_tips` itself is unaffected — its `live` is
  already date-scoped to today before any fact runs (the v1.9 fix). With that same scoping applied,
  the real worst wait for this Nurse's actual board was **61 minutes** — the number this section
  builds on.

**Decision:** add the longest current live wait among Nursing Room patients who still have no Vital
Signs record — a duration, never a patient name (Rule 10/PHI-6, same restraint `most_overdue`/
`ready_but_stuck` already apply) — alongside the existing `vitals_missing_count`. Turns "15 need
vitals" into "15 need vitals; the longest has been waiting 61min" — a priority signal a Nurse can
act on (go see that one first) that the board's own room-count header cannot give her. Computed
from `live`/`nursing_appts`, which `regenerate_queue_tips` has already date-scoped to today before
this fact runs — inherits the v1.9 fix for free rather than needing its own copy of it.

**Four approaches considered, matching this ADR's usual depth for a new fact:**

1. **Worst current wait among vitals-missing patients (chosen)** — always available (no
   `completed_count > 0` precondition the way `nurse_pace` has), no threshold invented, reuses
   `live_minutes` already computed for every open row.
2. **Rely solely on `nurse_pace` (§3k)** — rejected as insufficient alone: it requires at least one
   completed Nursing Room stay today and a real projected gap; a Nurse one minute into her shift, or
   on a day that happens to be on pace overall, still has 15 patients with no prioritization signal
   between them.
3. **A fixed-minute "overdue vitals" threshold** (e.g. flag anyone waiting >30 min) — rejected, same
   reason ADR-063 and this ADR's own room-crowding decision both already rejected an invented
   threshold: no real baseline in this app to derive one from, and a duration fact stated as a plain
   number (no verdict attached) is this ADR's existing, consistent convention.
4. **Solve it in the UI instead** (sort/highlight the Nursing Room column by wait time) — a
   genuinely different, valid fix, but a frontend decision; this app's frontend is read-only by
   default absent an explicit ask, so out of scope for this revision.

**Status: built and unit-tested, 2026-09-12.** New pure function `_vitals_missing_worst_wait`
(`api/v1/dashboard/api.py`), wired into the existing `vitals_missing` block in
`regenerate_queue_tips`, new stats key `vitals_missing_worst_wait_minutes` (formatted via
`format_minutes`, same as every other duration field). `prompts/ops-tip-summary-v1.txt` extended.

### 3m. v1.17 addition (2026-09-12) — Checkout excluded from "most overdue" / the overdue rollup

Direct instruction: "do not check busy for the checkout queue for check[out], only check the
payment pending." Live-verified before this fix: Admin's summary said *"La cita en Checkout está
5hr 59min pasada. Hay 66 citas retrasadas; revise la dotación de personal para hoy"* — Checkout was
both the single "most overdue" room and a large share of the 66-appointment overdue rollup.

**Why this is a real, not cosmetic, problem.** `wait_minutes` (what `_most_overdue_fact`/
`_overdue_rollup_fact` both consume) measures time past the appointment's *original scheduled
slot* — the same math the live per-card delay badge already uses. By the time an appointment
reaches Checkout, it has already passed through four earlier stages, so a large "wait_minutes"
value there is close to structural, not a sign of anything actually going wrong — the patient has
already been fully seen. Treating that as "needs more staffing" (the fixed next step this ADR
attaches to `overdue_rollup`) is actively the wrong instruction: a Checkout backlog's real, existing
lever is `payment_pending_count` (already built, already scoped across all 5 rooms since
2026-09-11), not a staffing review.

**Four approaches considered:**

1. **Exclude Checkout from the room pool both facts draw from (chosen).** `_most_overdue_fact`
   already supports a room-restriction parameter (`owned_rooms`) — Admin's call site simply passes
   the four non-Checkout rooms instead of `None` ("unrestricted"). `_overdue_rollup_fact`'s own
   pure-function signature is untouched (its existing unit tests keep passing unchanged); the
   caller pre-filters `wait_by_appt` to the same four rooms before passing it in.
   - Pros: Minimal, reversible, no new fact, no signature change to either pure function — only
     what the wiring feeds them changes. `payment_pending_count` already covers Checkout's real
     signal; nothing new needs building there.
   - Cons: None identified — this is a straightforward narrowing of an existing candidate pool,
     the same shape of change `_ROOM_PIPELINE`'s adjacency restriction (v1.7) already made once.
2. **Keep computing both facts over all five rooms, but suppress a Checkout result from ever
   reaching the phrased sentence** (mirrors `practitioner_room_stuck`'s "compute it, keep it in
   `tips[]`, never merge into `new_facts`" pattern).
   - Cons: Rejected — Checkout, being structurally the highest-`wait_minutes` room, would still
     silently WIN the "worst" comparison inside `_most_overdue_fact`/`_overdue_rollup_fact`,
     crowding out a genuinely actionable delay in an earlier stage that would otherwise have been
     reported. Suppressing the display doesn't fix the underlying comparison being won by the wrong
     room.
3. **Redefine `_wait_minutes` for Checkout to mean "time in Checkout" instead of "time since the
   original scheduled slot."**
   - Cons: Rejected — `_wait_minutes()` is shared with the live per-card delay badge everywhere
     else on the board; changing its meaning for one room to fix one summary sentence is a much
     larger, riskier change than the actual ask needs.
4. **Leave both facts as they were; do nothing.**
   - Cons: Rejected outright — does not address the reported problem.

**Chosen: 1.** Lowest risk, no new mechanism, and it is the literal fix for the actual complaint:
Checkout stops being treated as a delay to staff up for, and payment collection (`payment_pending`)
remains its own, already-correct signal.

**Status: built and unit-tested, 2026-09-12.** New constant `_OVERDUE_ELIGIBLE_ROOMS` (every room
except `checkout`) in `api/v1/dashboard/api.py`; Admin's `_most_overdue_fact` call now passes it
instead of `None`; `_overdue_rollup_fact`'s input is pre-filtered to the same room set at the call
site. Neither pure function's own signature or existing tests changed.

### 3n. v1.18 addition (2026-09-12) — `slowest_vs_average` gets a decision, not just a restated number

Direct feedback: "Waiting Room live wait is 16min versus a historical 5min, the largest slowdown on
the board. It is showing this for frontend which is good but what do I have to do with that — based
on that you have to give some suggestion so that I can reduce this waiting time; you have to help
him [the reader] making [a] decision, not just read the data and convert into text form."

**What was actually wrong, precisely.** `slowest_vs_average` (built 2026-09-10, §3a) is the one fact
in this entire ADR that never graduated to "always covered when true" the way every other fact did
at v1.9 ("cover every applicable fact, not just one"). Per the prompt's own rule 12, it (and
`busiest_room`) is used **only as a last-resort fallback when NONE of the other numbered facts are
true** — so on any board busy enough to also have a `vitals_missing`/`most_overdue`/pace fact firing
(the normal case, and almost certainly true when this was reported), `slowest_vs_average` is silently
dropped from the phrased sentence entirely, even though it is still present in `tips[]` for the
frontend to render as a raw card. That is exactly the "just showing the data" complaint: the number
reaches the screen, but Python has never attached a next step to it the way it has for every other
fact since §3c (v1.6).

**Why a next step here is a real decision, not a restated number.** Unlike `most_overdue` (whose
next step is always the same generic "check them in" / "move them along"), a room's *duration*
slowdown has a genuinely different right answer depending on one concrete, already-available fact:
**is the very next pipeline stage currently free to receive a patient right now, or is it occupied
too?**
- If the next stage has **nobody in it**, that is `_idle_room_fact`'s own case exactly (a Nurse's
  `idle_candidates=("nursing_room","waiting_room")` pair covers precisely Waiting Room → Nursing
  Room) — already computed, already phrased, nothing new to add without duplicating an existing
  fact.
- If the next stage **also has people in it**, the one-patient-move lever isn't available — the
  slowdown is more likely a genuine capacity/staffing question at that next stage, not "nobody has
  walked anyone forward yet." **This half was never computed anywhere in this ADR.**

**Four approaches considered:**

1. **Compute the next-stage-occupied signal only, and promote `slowest_vs_average` to a normal,
   always-covered numbered fact (chosen).** New pure `_slowdown_next_step_fact(slowest_room,
   by_room)` — `None` when the next pipeline stage is idle (already `_idle_room_fact`'s territory)
   or when `slowest_room` is the last stage (Checkout has no next stage); otherwise
   `{"next_room", "next_room_count"}`. `slowest_vs_average` itself moves out of the "fallback only"
   branch into the same "cover every present fact" list every other fact already lives in (v1.9's
   own rule, finally applied here too), gated per role to the same room-pair capability restriction
   `_idle_room_fact` already enforces (Nurse: only Waiting Room; Front Desk: only Arriving Soon;
   Admin: unrestricted; bare Practitioner: excluded, no lever, same as `idle_room`/`overdue_rollup`).
   - Pros: No duplicate computation with `idle_room` (the two are mutually exclusive by
     construction — idle triggers exactly when this one returns `None`), no invented threshold (the
     `next_count == 0` boundary is the same non-invented one `_idle_room_fact` already uses), fixes
     the actual reported gap (silently dropped when other facts are present) at its root rather than
     patching the fallback branch that rarely fires in a busy clinic.
   - Cons: Changes existing behavior for every call where `slowest_vs_average` was previously
     silently dropped — a broader, if correct, fix. Reviewed and accepted below.
2. **Leave `slowest_vs_average` in its fallback-only branch; only add the next-step signal inside
   that same fallback.**
   - Cons: Rejected — does not address the actually-reported case. A board busy enough to have
     `vitals_missing`/`most_overdue`/a pace fact (which is when a slowdown is most worth explaining)
     would still silently drop this fact and its new next step both.
3. **A generic "review staffing" next step for every `slowest_vs_average` fact, regardless of
   downstream occupancy** (mirrors `overdue_rollup`'s fixed phrase).
   - Cons: Rejected — loses the one piece of real decision support this room already has data for
     (whether the immediate one-patient-move lever exists right now); a blanket "review staffing"
     is exactly the "just showing data with a generic caption" pattern being complained about.
4. **A new analytics/causal-breakdown mechanism** (e.g. correlate the slowdown against practitioner
   load, appointment mix, or time-of-day) to explain *why* the room is slow.
   - Cons: Rejected — a new data model/mechanism for a request that has a real, already-computable
     answer using data this ADR already has (the pipeline's own next-stage occupancy). Disproportionate
     to the ask; nothing here forecloses building this later if the simpler fix proves insufficient.

**Chosen: 1.** It fixes the actual defect (fact silently dropped whenever the board is busy — the
normal case), adds a genuine decision (not a restated number) using data already on hand, introduces
no new threshold, and never duplicates `_idle_room_fact`'s own territory.

**Status: built, unit-tested, and live-verified, 2026-09-12.** New pure `_slowdown_next_step_fact`
in `api/v1/dashboard/api.py`; `slowest_vs_average` promoted out of the LLM prompt's fallback-only
branch into the normal numbered-fact list (new fact #12 in `prompts/ops-tip-summary-v1.txt`); new
stats keys `slowdown_room`, `slowdown_live_avg_minutes`, `slowdown_avg_minutes`,
`slowdown_next_room`, `slowdown_next_room_count`. Live-verified against the real board (Waiting
Room 29-30min live avg vs. 5min historical, Nursing Room also occupied): Admin's phrased summary
correctly said *"Waiting Room promedia 29min frente a su histórico de 5min y además Nursing Room
tiene 15 pacientes ahora"* — the real decision (downstream is also busy, not a simple move) reaching
the reader, not a restated number.

**A genuine, measured gap found during live verification, recorded rather than smoothed over: the
Python side is 100% correct every time (confirmed by intercepting the exact stats dict handed to the
LLM); the LLM's PHRASING of it is not always complete when 3+ facts compete for one short sentence.**
For a Nurse session with `vitals_missing` + `slowdown` + `nurse_pace` all true simultaneously (the
most facts this ADR has ever had fire together for one audience), `slowdown_room`/`slowdown_next_room`
reached the LLM correctly in every one of 4 repeated live calls, but the **phrased sentence covered
all three facts in 3 of 4 calls and silently dropped the slowdown clause in 1 of 4** — the same
"only phrase what's true, cover every fact" instruction the prompt already carries (and which v1.9
fixed once for exactly this failure mode) is not perfectly reliable once three real facts are
competing against the prompt's own "1-3 short sentences, fewest possible words" brevity constraint.
This is a genuinely different failure mode than v1.9's (that was a **deterministic** "always stops
after the first fact" prompt design bug, fixed by rewriting the prompt; this is **stochastic**
under-coverage at a fact count this feature has never previously reached for one audience in normal
use). **Not fixed in this revision** — flagged as a real, measured limitation rather than papered
over. `tips[]` always carries the full, correct fact regardless, so the frontend and any future UI
reading structured data is unaffected; only the LLM-phrased sentence can occasionally miss one fact
among three or more. Worth a follow-up decision if this recurs in practice (a stronger structured
output constraint, a lower-temperature/more deterministic call, or accepting a longer sentence
budget when many facts are true) — not attempted here, since it would be a real design change to the
phrasing call itself, not a fix to this feature.

### 3o. v1.19 addition (2026-09-12) — a real decision for "busiest AND slowest," the last data-only fact

Reported live, from a real board: "Practitioner Room is busiest with 30 patients and a live average
of 34min versus a historical 25min. What do I have to do with this — where is your suggestion?"
Direct follow-up: "we have to help the user take a decision... suggest what to do to overcome this
situation... show suggestion WITH the fact, not only the fact."

**Why `busiest_room` specifically was still a gap after §3n.** §3n gave `slowest_vs_average` a real
decision (is the next stage free or occupied). `busiest_room` is the other of the two original,
pre-role-scoping facts (built 2026-09-10, before any "here's what to do" fact existed) and had
**never** had a next step in this feature's entire history — reported live in exactly the case where
both `busiest_room` and `slowest_vs_average` happened to name the SAME room (Practitioner Room:
busiest by count, and also running slower than its own history).

**Why that coincidence — not "busiest" alone — is the right, non-invented trigger.** A room simply
having the most patients does not by itself mean anything is wrong: Practitioner Room naturally
holds more people for longer than Arriving Soon, by the nature of a consultation. Attaching a
"review staffing" suggestion to `busiest_room` alone would invent urgency this ADR has consistently
refused to invent for a mere count (see the room-crowding Alternatives already in this ADR). What
**is** a real, non-invented signal — because it reuses two already-computed facts, not a new
threshold — is when the busiest room and the slowest-vs-its-own-history room are the exact same
room: unusual **volume** and unusual **duration** coinciding on one room is a genuine capacity
signal a plain count alone is not.

**Why this is Admin-only, unlike §3n's fact.** §3n's "next stage occupied" signal is gated per role
to whichever room-pair that role can physically move a patient across — a real, non-staffing lever.
Staffing/coverage is a different kind of decision entirely: only Admin can add staff or adjust who's
scheduled today (matches `overdue_rollup`'s own existing Admin-only "review staffing" precedent
exactly — no new judgment invented, the same already-accepted phrase is reused). Nurse and Front
Desk still see the underlying `busiest_room`/`slowest_vs_average` numbers in `tips[]` for
board-wide context (unchanged from today — a separate, real visibility question raised in the same
conversation and not decided yet, see the Open Items note below), but never a staffing suggestion
they have no power to act on.

**What was built:** new pure `_capacity_strain_fact(busiest_room, slowest_room)` — `None` unless the
two are the same room; otherwise `{"room": ...}`. Wired into `regenerate_queue_tips`, Admin-only,
adding `capacity_strain_room` to the stats dict and a new `capacity_strain` tip. Deliberately
independent of §3n's `_slowdown_next_step_fact` (that answers "is the next stage free," this answers
"does this specific room look understaffed for today's volume") — both can be true at once, and
both are computed and phrased when they are.

**Status: built and unit-tested, 2026-09-12.**

**Open item, raised in the same conversation, not decided or built here:** whether `busiest_room`,
`longest_wait`, and the LLM prompt's own board-wide fallback branch should be scoped to each role's
own rooms the way every actionable fact already is — today a Front Desk (or Nurse) session can still
be told about a room they have no lever over at all, purely as unscoped board-wide awareness. Two
options were discussed directly with the product owner (restrict visibility entirely, vs. keep it
but ensure the LLM never implies an action the reader can't take) and neither has been chosen yet.

### 3p. v1.20 correction (2026-09-12) — §3o's own trigger was too narrow, found live within the hour

Reported live, with a screenshot: the banner read *"Practitioner Room is busiest with 30 patients
and a 46min live average"* — no comparison to history, no suggestion, the exact "just showing data"
complaint §3o was built to fix, on the very fact §3o just shipped.

**Root cause, found by inspecting the real stats dict, not guessed:** §3o's `_capacity_strain_fact`
required `busiest_room` to be the SAME room as `slowest_vs_average`'s own separately-computed
"single globally worst ratio" room. At the moment of the report, Practitioner Room (busiest, 46min
live vs. 25min historical — ratio 1.8×, genuinely elevated) was NOT the fact's registered
`slowest_room`, because Waiting Room (50min live vs. 5min historical — ratio 10×) had a more
extreme ratio and won that separate, unrelated contest. A smaller room, affecting far fewer
patients, silently crowded out a real signal on the room that matters most.

**Fix:** `_capacity_strain_fact` no longer compares `busiest_room` against whichever room happens to
win the board-wide "worst ratio" title. It now checks the busiest room's **own** live average
against its **own** historical average directly — the same "ratio > 1.0, a real historical baseline
required" gate `slowest_vs_average` already applies, just scoped to the room that actually affects
the most patients, not whichever room wins an unrelated, separate comparison. New signature:
`_capacity_strain_fact(busiest_room, by_room, historical)`, returning `{"room",
"live_avg_minutes", "avg_minutes"}` — the actual numbers, so the phrased sentence can now state the
comparison directly ("30 patients, averaging 46min vs. a usual 25min") instead of a bare "may need
staffing" with no numbers attached, closing the second half of the same complaint at the same time.

**Status: built, unit-tested, and live-verified against the found scenario, 2026-09-12.** A new
regression test locks in the exact bug: busiest room has a real, elevated ratio (1.8×) while a
DIFFERENT, non-busiest room has an even more extreme one (10×) — the fact must still fire for the
busiest room.

### 3q. v1.21 addition (2026-09-12) — a projected clock-time finish, not just a duration

A reference design was shared showing: *"4 patients are delayed up to 4h 28m. Nursing and
practitioner capacity is idle, 3 payments are pending, and projected clinic finish is 17:45 — 35
minutes beyond plan."* Direct instruction, after discussing the reference's severity-label styling
("Operationally critical") separately: **not** the severity label — that would invent a new
judgment threshold this ADR has consistently refused to add without a real, explicit decision (see
§0 and every "Alternatives considered" subsection in this ADR). What was actually asked for:
"just show the useful info so the user can manage their day easily... our suggestion should help
them manage their day."

**What's new here, and why it needed no new judgment call.** The pace facts (§3k) already compute
`expected_remaining_minutes` (how long the rest of today's patients are projected to take, from
today's own observed pace) and `remaining_scheduled_minutes` (minutes actually left until the
already-derived deadline — §3k's own "last actually-booked appointment's scheduled end," reused
unchanged as "the plan"). The reference design's "17:45, 35 min beyond plan" is nothing but those
same two numbers, presented as a wall-clock time instead of two separate durations:

- `projected_finish_time = now + expected_remaining_minutes` (a clock time)
- `beyond_plan_minutes = expected_remaining_minutes - remaining_scheduled_minutes` (always positive
  whenever a pace fact exists at all — `pace_fact` only ever fires on a real, positive gap)

No new threshold, no new data source — pure arithmetic on numbers already computed and already
trusted (§3k), reformatted to answer "when will I actually be done, and by how much am I behind"
instead of "how many minutes per patient," which is a genuinely more directly useful number for
planning the rest of the day (deciding whether to call in help now, or warn patients of a delay).

**Scope: `admin_pace`/`nurse_pace`/`frontdesk_pace` only, not the practitioner's own
`get_my_workload_suggestion` pace fact — a deliberate, narrower scope, not an oversight.** Those
three facts already have a real deadline **datetime** to project against (§3k's
`_today_appointment_pace_basis`). A practitioner's own `scheduled_minutes`
(`get_scheduled_minutes_for_date`) is only ever a total duration, potentially summed across several
discontiguous schedule blocks in a day — there is no single "last scheduled block's end time"
computed anywhere yet to project a wall-clock finish against. Building that would be new work, not
a reuse of an existing number, and is recorded as a follow-up, not attempted here.

**New pure `format_clock_time(dt)`** in `services/queue_stage_log.py`, alongside `format_minutes` —
`"5:45 PM"` style (12-hour, no leading zero), matching this app's existing appointment-time display
convention. New stats keys: `admin_pace_projected_finish_time`, `admin_pace_beyond_plan_minutes`
(and the `nurse_pace_`/`frontdesk_pace_` equivalents) — only present alongside their existing pace
fact, since "beyond plan" is meaningless without a real projected shortfall already established.

**Status: built and unit-tested, 2026-09-12.**

### 3r. v1.22 addition (2026-09-12) — compressed phrasing for a heavily multi-role account

Reported directly, from a real 4-role account (Admin + Practitioner + Nurse + Front Desk all held
at once) whose summary had grown to 7 distinct facts in one paragraph: "make this summary a bit
shorter[; the] facts and recommendation are correct." Confirmed: every individual fact and number
was genuinely accurate — this is a phrasing/compression request only, not a data or logic change.

**Prompt-only change, no code touched.** `prompts/ops-tip-summary-v1.txt` gained two hard
compression rules:
1. When two or more facts name the **exact same room** (e.g. `most_overdue_room` and
   `capacity_strain_room` both naming Practitioner Room), they are now combined into ONE clause
   about that room instead of two separate sentences.
2. When both `overdue_count`'s staffing signal (fact 6) and `capacity_strain_room`'s staffing
   signal (fact 13) are present, "review staffing" is said once for the whole summary, not once per
   fact that happens to suggest it.

The previous "1-3 short sentences" instruction was replaced with an explicit "be terse, strip every
connecting/explanatory word, dense clauses over flowing prose" rule — the earlier wording had
implicitly permitted growth ("if the facts genuinely present would run longer... still cover every
one, but say each in the fewest words") without ever instructing the model to *merge* related facts,
which is what actually produced the reported wall of text once 5+ facts were true at once for a
single caller.

**Status: built and live-verified, 2026-09-12** — same underlying facts, a visibly shorter phrased
result on the exact account that reported the issue. No stats-key or fact-selection change, so no
existing test needed updating (tests assert which keys reach the LLM call, not prompt wording).

### 3s. v1.23 addition (2026-09-12) — auto-fetch once on first page load (frontend, EB_Healthcare_Frontend)

Direct instruction: "when [a] user comes [to] this page [for the] first time it should automatically
show the summary; later work on the refresh button [stays manual]." This narrows, rather than
reverses, the Decision's original "called only when a user clicks the panel's button... never
polled, never scheduled, never on a timer" — the distinction that matters: an auto-fetch bounded to
exactly once per page load is a single, bounded, user-triggered-by-visiting action (someone is
demonstrably there to read it, the moment they open the page), not a recurring background poll. The
Alternatives Considered section's Alternative 4 (rejected: "regenerate suggestions on a schedule...
burns LLM cost continuously for panels that may have no one watching") is untouched — a schedule/
timer is still not being added; this is a one-time initial fetch, not a recurring one.

**What changed, frontend only — no backend code touched:** `QueueInsightBar`
(`mission-control-client.tsx`) gained a `useEffect` that calls the exact same `handleRefresh()` the
button already calls, guarded by a `useRef` flag so it fires **exactly once per mount**, never on
subsequent prop/dependency changes (`handleRefresh` itself depends on `roles`/`paymentPendingCount`,
which can change after mount — without the ref guard, a naive `useEffect` keyed on those would
silently become a recurring auto-refresh, exactly the polling behavior this ADR has always rejected).
The existing Refresh button is completely unchanged — every subsequent update still requires the
user's own click, per direct instruction ("later work on the refresh button" — read as "leave that
part alone for now, this isn't asking to change it").

**Cost note, stated plainly rather than left implicit:** this does mean one additional LLM call per
page load that would not have happened before (previously: manual clicks only). Accepted per direct
product-owner instruction; not re-litigated here.

**Status: built, 2026-09-12.** Verified: `npx tsc --noEmit` (zero new errors — the same
pre-existing `e2e/encounter-submit.spec.ts` error this ADR has recorded since 2026-09-10), `eslint`
on the changed file (zero new findings — the same 3 pre-existing errors this file has carried since
2026-09-10, confirmed at different line numbers only because of accumulated unrelated edits since).
Not yet exercised in a running browser.

| File | Change |
|---|---|
| `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx` | `QueueInsightBar` gained a mount-once auto-fetch effect, guarded by a `useRef` flag |

### 3t. v1.24 addition (2026-09-12) — fact-vs-recommendation rebalance, a refused streaming request, and a real fix for the perceived-latency complaint

Direct instruction, three parts: "make [the] fact [a] little bit shorter and increase the
recommendation... when I come to this page newly it is taking too much time to generat[e the]
summary... if possible apply streaming."

**Part 3 (streaming) was refused, not built.** CLAUDE.md §11 Hard Don'ts, under "AI-specific
(these apply NOW — AI is live)," lists explicitly: **"Stream every LLM token to the UI."** Per
CLAUDE.md's own instruction ("If a request from me violates any of the above, refuse, explain why,
and propose the correct approach"), this was declined outright rather than attempted. Reasoning
given to the user: every fact this ADR produces is delivered as one complete, already-decided
sentence — never a partial fragment a reader could glance at mid-generation — and token streaming
would structurally break that guarantee for a purely cosmetic latency-perception goal.

**The real problem behind the streaming request WAS fixed, without streaming.** Investigated
directly: since §3s's auto-fetch-on-mount, `QueueInsightBar` showed the OLD, now-stale placeholder
text ("Click Refresh for a live summary of the queue") during the entire wait for the very first
LLM call of a page visit — text that no longer made sense (nobody clicked anything) and gave zero
indication that anything was in progress, reading as a stalled page rather than a loading one. Root
cause of the "feels slow" complaint was a missing loading state, not the actual latency of the LLM
call itself.

**Fix, frontend only:** new i18n key `queue.tips.generating` ("Generating today's insights…" /
"Generando las estadísticas de hoy…"), shown while `regenerate.isPending` is true instead of the
stale placeholder; a Tailwind `animate-pulse` class on the text during that window gives honest,
real-time progress feedback — the summary text itself is still delivered as one complete unit once
ready, never partial.

**Part 1 (fact vs. recommendation balance) — prompt-only.** New instruction: within each clause,
state the underlying fact in the fewest possible words (a bare count/room/duration, no elaboration)
and give the recommendation the fuller, clearer phrasing — the fact exists only to justify the
action, the action is what the reader actually needs. Worked example added directly to the prompt
(`"15 need vitals — record them, starting with the one waiting 1hr 12min"` over `"15 vitals
missing, 1hr 12min: record."`).

**Status: built, 2026-09-12.** Prompt change verified against existing tests (no stats-key/logic
change, same as §3r). Frontend change: `tsc --noEmit`/`eslint` on the changed files — no new errors
beyond this repo's existing documented baseline.

| File | Change |
|---|---|
| `prompts/ops-tip-summary-v1.txt` | New fact-vs-recommendation phrasing-balance rule + worked example |
| `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx` | Pending-state loading text + `animate-pulse` |
| `EB_Healthcare_Frontend/messages/en.json`, `messages/es.json` | New `queue.tips.generating` key; `queue.tips.placeholder` corrected (no longer instructs a click that no longer applies) |

### 3u. v1.25 — auto-fetch-on-mount (§3s) reverted; a real environment bug found and fixed along the way

Reported live: the summary got stuck on "Generating today's insights…"/"Refreshing…" indefinitely.
Investigated properly rather than guessed at — the investigation itself is worth recording, since
the eventual root cause was not in this ADR's own code at all.

**What was ruled out, in order, each with real evidence:**
1. A hung/slow LLM call — ruled out: every observed network request to `/api/dashboard/queue-tips`
   completed with a real 200 and a real, valid summary in 6-10 seconds, every single time, across
   many repeated live checks (both automated and the reported user's own Chrome DevTools Network
   tab).
2. The auto-fetch effect re-firing repeatedly (a polling regression) — ruled out: a full request/
   response timeline showed exactly ONE request per page load, never more.
3. A logic bug in the mutation wiring itself — ruled out with a targeted diagnostic (temporary
   `console.log` in `onSuccess`/`onError`/`onSettled`, added and removed in the same session): the
   mutation call fired once, correctly, but **its callbacks never fired at all** — despite the
   network layer independently confirming success.
4. Stale/duplicate dev-server processes — a real, separate problem FOUND and fixed along the way
   (two completely unrelated `pnpm dev` process trees were running against the same project
   simultaneously, likely leftover from this session's own earlier process churn) — but fixing
   this and restarting with a fully clean single instance and a cleared `.next` cache **did not
   fix the reported symptom**, ruling this out as the root cause too (though still worth having
   fixed).

**Root cause, confirmed:** the exact same diagnostic (console log of `[Fast Refresh] rebuilding`)
showed the dev server rebuilding itself repeatedly — 14 times in 30 seconds on the freshly-cleaned
single instance — with no file being edited by anyone. The project folder
(`Desktop\EB_Healthcare_Frontend`) sits inside an actively-syncing OneDrive "Known Folder" (Windows
Desktop, confirmed via the folder's OneDrive-tracking `ReadOnly` attribute and a running
`OneDrive.exe` process). OneDrive's background sync bookkeeping touches files, which the dev
server's file watcher reads as real changes, triggering an unwanted rebuild — and if that rebuild
lands while a request is still in flight, the request still completes successfully against the
network, but the specific React component instance waiting for its result has already been
hot-swapped away, so the result has nowhere to land. This is a well-documented class of problem for
JS dev servers running from a OneDrive-synced folder, not specific to this app's code.

**Fix, in two parts:**
- **Environment (the actual root cause):** move the project out of OneDrive's synced scope, or
  exclude this folder from OneDrive sync — not something any code change can reliably prevent.
  Not done as part of this revision; the user was given the choice and has not yet decided.
- **This ADR's own mitigation, per direct instruction:** revert the v1.23 auto-fetch-on-mount
  behavior entirely — "whenever user clicks on refresh then only generate." This does not fix the
  underlying OneDrive/rebuild-storm issue, but it meaningfully reduces exposure to it: a request is
  now only ever in flight during a moment the user deliberately chose to click, not on every single
  page load regardless of whether anyone is even watching.

**Status: reverted, 2026-09-12.** `QueueInsightBar`'s mount effect and its `useRef` guard removed
entirely; `queue.tips.placeholder` restored to its original "Click Refresh for a live summary of the
queue" text (accurate again now that nothing fetches automatically); the backend's own docstring
amended back to its original "called only on click" wording. The `queue.tips.generating` loading
state added at v1.24 is KEPT — it's still genuinely useful feedback while an explicit click's
request is in flight, independent of whether that request was triggered by a click or a mount.

| File | Change |
|---|---|
| `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx` | Removed the mount-effect auto-fetch and its ref guard |
| `EB_Healthcare_Frontend/messages/en.json`, `messages/es.json` | `queue.tips.placeholder` reverted to instruct clicking Refresh |
| `remedisys_healthcare_ai/api/v1/dashboard/api.py` | Docstring reverted to "called only on click" |

### 3v. v1.26 — a real, confirmed defect: the client-sent `roles` was trusted for scope, not just phrasing

Reported live, from a real account: the summary said *"104 booked, 60 vitals done, 44 remain,
Nursing Room has 15 patients"* while the board directly beneath it, for the same logged-in user at
the same moment, showed only **26 total patients, 5 in Nursing Room**. Investigated, not assumed —
this was a genuine defect, not a data-quality artifact like the earlier findings in this ADR.

**Root cause, confirmed against the database directly.** The reported account's REAL Frappe role is
`EB_Practitioner` only — nothing else. `get_dashboard_data` (the board itself) correctly checks the
user's real, server-verified role via `_practitioner_read_scope()` (ADR-018) and scopes the board to
that practitioner's own appointments, since this clinic's `practitioners_see_all_appointments`
setting is off for them. `regenerate_queue_tips`, however, derives its own `is_bare_practitioner`/
scope decision **entirely from the client-supplied `roles` parameter** — and for this account, the
frontend was sending `roles=["admin","nurse","frontdesk","practitioner"]`, a claim that does not
match the account's real permissions (a separate frontend bug, not this endpoint's to fix). This
endpoint trusted that claim and summarized the entire clinic to a user who could only ever see his
own patients on the board.

**Why this crossed a real line, not just a cosmetic one.** This ADR has always stated the
client-sent `roles` is "never a security boundary... the underlying numbers carry no PHI either
way" — true for *which fact to lead with*. It was never true for *whose appointments get counted at
all*, and this endpoint had conflated the two. The result: a summary that flatly contradicted the
board it sits above, for a real account, using data the account's own logged-in session has no
server-verified right to see summarized to it.

**Fix:** `regenerate_queue_tips` now calls `_practitioner_read_scope()` (`api/v1/appointments/api.py`
— the exact same server-verified check `get_dashboard_data` already uses) and lets it **override**
the client-sent `roles` whenever it is more restrictive:
- `_SCOPE_NONE` (a scoped practitioner with no linked Healthcare Practitioner record) → `audiences`
  forced empty, matching the board's own identical handling — sees nothing, regardless of the
  claim.
- A specific practitioner name (a genuinely scoped practitioner) → `audiences` forced to
  `{"practitioner"}`, and that name is reused directly (no redundant `_session_practitioner()`
  call) to scope `live` to that practitioner's own appointments only — exactly the board's own
  behavior.
- `_SCOPE_ALL` (a real admin/nurse/front-desk role, or a practitioner whose clinic has
  `practitioners_see_all_appointments` ON) → completely unaffected; `audiences` still comes from the
  client's own claim as before. This only ever **tightens** scope to match server-verified reality,
  never widens it beyond what the client already claimed.

**Status: built and unit-tested, 2026-09-12.** New `TestPractitionerScopeOverride` test class locks
in the exact reported scenario (an inflated multi-role claim overridden by a real scoped
practitioner), the `_SCOPE_NONE` case, and a regression check that a genuine multi-role account is
completely unaffected. Every existing bare-practitioner wiring test updated to mock
`_practitioner_read_scope` (previously unmocked, since this call did not exist before this fix).

### 3w. v1.27 (frontend) — rebranded the panel icon as "Nova Insights"

Direct instruction, with two reference screenshots: replace the generic alert (`Siren`) icon at the
start of the summary banner with a named "Nova Insights" badge, matching the sparkle-icon "AI"
branding already used across the app's AI Workforce screens (`agent-directory.tsx`'s
`aiBadge`/`heroBadge` pills — Nova being one of the product's existing named AI personas).

**What changed, frontend only:** `QueueInsightBar`'s standalone icon replaced with an inline teal
pill (`Sparkles` icon + "Nova Insights" text), reusing the exact brand teal (`#087d70`) already
established for AI badges elsewhere in this app rather than inventing a new color. The
`.ai-avatar-label`/`.ai-avatar-mark` CSS classes used by the AI Workforce avatar cards were
deliberately NOT reused — they are absolutely positioned for overlaying a photo/avatar card, not
suited to an inline text banner. New i18n key `queue.tips.novaInsightsBadge` — kept as the literal
"Nova Insights" in both `en`/`es` catalogs (a product/brand name, same convention as "Narzim" itself
staying untranslated).

**Status: built and verified, 2026-09-12.** `tsc --noEmit`/`eslint`/`i18n:check` clean (same
pre-existing baseline; i18n now 7166 keys, en↔es aligned). Live-verified in a running browser: the
badge renders correctly alongside the phrased summary.

**v1.28 follow-up (same session, minutes later) — replaced the text/icon pill with Nova's own
portrait, no text at all.** Direct instruction: "just show the image only in circle as avatar
icon." Reused the exact same portrait asset the AI Workforce directory already uses for this
persona (`lib/mock/ai-agents.ts::portrait()`, `/avatars/agents/nova.png` — the square crop, not
`-wide`, since this is a small round icon, not a card header), rendered via `next/image` in a
24px circular frame (`rounded-full overflow-hidden`), `aria-hidden` with no alt text since it's a
decorative brand mark — the accessible content is the summary text right next to it. The
`Sparkles` icon and `queue.tips.novaInsightsBadge` i18n key from the text-pill version were removed
as unused, not left orphaned (matching this ADR's own established practice, e.g. §3a's frontend
history removing 7 unused pill-text keys the same way). Verified: `tsc`/`eslint`/`i18n:check`
clean (i18n back to 7165 keys — the one key added then removed, net no orphan), live-verified in a
running browser.

| File | Change |
|---|---|
| `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx` | `Siren` icon → `Sparkles`+"Nova Insights" pill (v1.27) → Nova's own circular portrait image, no text (v1.28) |
| `EB_Healthcare_Frontend/messages/en.json`, `messages/es.json` | `queue.tips.novaInsightsBadge` key added (v1.27), then removed as unused (v1.28) |

## Alternatives Considered

These apply identically to both suggestion types (§3a queue congestion, §3b cross-clinic
workload) — the choice is about how *any* operational suggestion in this app gets generated, not
specific to one screen.

1. **Keep suggestions fully deterministic; template the sentence in Python — no LLM.**
   - Pros: No new ADR needed, zero marginal cost, zero new failure mode, fully consistent with
     ADR-063 as originally accepted.
   - Cons: Does not meet the explicit ask for an LLM-phrased summary.

2. **LLM reasons directly over raw data (Queue Stage Log rows, or raw appointment/schedule rows
   across clinics) and chooses which suggestions matter, with what urgency.**
   - Pros: Could in principle surface patterns a fixed rule set misses (e.g. a combination of
     small factors nobody wrote an explicit rule for).
   - Cons: This is exactly ADR-063's Alternative 3, already rejected once for scope creep and
     tool-registry governance. Harder to audit ("why did it say that?"). Real risk of PHI reaching
     the prompt if raw rows are passed instead of pre-aggregated numbers. Violates Rule 9. For the
     workload suggestion specifically, this means the AI — not a testable rule — decides when it's
     safe to imply a practitioner could leave a clinic early; given the staffing consequence of
     getting that wrong, this is the worst fit of the four for that case, not just a governance
     inconvenience.

3. **LLM phrases a pre-computed, PHI-free stats dict only; suggestion selection and thresholds
   stay 100% deterministic Python (chosen).**
   - Pros: The LLM's entire blast radius is "writes one sentence" — nothing else. It structurally
     cannot see PHI, because the dict handed to it never contains any, by construction, not by
     policy. Matches an existing, already-accepted pattern (`generate_thread_title`) instead of
     inventing a new one. Auditable: the stats dict going in and the `AI Prompt Log` row coming out
     are both concrete, inspectable artifacts. Every suggestion — including "you could leave
     early" — traces to one calculation that can be shown to anyone who asks why.
   - Cons: Still a new prompt file, a new cost/latency line, and this ADR's overhead — not free.

4. **Regenerate suggestions on a schedule (background RQ job every N minutes) instead of on
   click/on demand.**
   - Pros: Always shows a "fresh-ish" suggestion without anyone needing to trigger it.
   - Cons: Directly contradicts the explicit requirement that regeneration only happen on click.
     Burns LLM cost continuously for panels that may have no one watching at a given moment —
     worse cost/value than on-demand, with no compensating benefit.

### Alternatives considered — the room-crowding signal specifically (v1.4)

A separate decision from the LLM-vs-no-LLM question above: given a room has more or fewer patients
than usual, how should code decide that is worth mentioning?

1. **Historical same-stage average count baseline** — compute, per room, the typical simultaneous
   headcount at a comparable time-of-day (mirroring how `_build_queue_stage_breakdown` already
   computes average *duration*), flag live count meaningfully above/below it.
   - Pros: No invented number; the same "compute from real data" pattern this ADR already
     committed to twice (§3b's `avg_consult_minutes` fallback, its slack threshold).
   - Cons: Needs real historical volume this deployment doesn't have yet — confirmed by grep, no
     function anywhere in this codebase computes a historical *count* baseline today, only
     durations. Would ship with the same "not enough history" honesty problem §3b already has,
     from day one.
2. **Admin-configured capacity per room** (a number set once, e.g. in AI Settings).
   - Pros: Immediately meaningful for a room with a real physical capacity (Waiting Room's seats).
   - Cons: Four of the five rooms are workflow *stages*, not physical spaces with a natural
     capacity (confirmed: `Queue Stage Log.room` is a fixed 5-value Select computed at read time
     from appointment status/encounter existence, not a Link to a physical-location doctype —
     `docs/adr/adr-063-...md` — there is no "how many fit in Practitioner Room" to configure).
     Requires an admin to set and maintain a number for stages where one doesn't naturally apply.
3. **Cross-room imbalance, no history or configuration needed — chosen.** A room at 0 while
   another (that the viewing role can actually move a patient into/out of) is not, reported as a
   plain fact.
   - Pros: Works from day one, zero data dependency, zero config. Never asserts a count is
     "wrong" — only that two numbers differ, the same restraint `longest_wait` already applies to
     duration. Directly consistent with ADR-063's explicit rejection of a duration-verdict; this
     does not quietly reintroduce that judgment on a different metric.
   - Cons: Less precise than a real historical baseline — could occasionally flag an ordinary
     pattern (e.g., a stage that is naturally empty at day's end). Deliberately conservative,
     not validated against real usage yet, same caveat §3b's threshold already carries.
4. **Hand the LLM raw per-room counts, let it decide what's notable.**
   - Pros: No threshold design work at all.
   - Cons: This is Alternative 2 above, already rejected for this entire ADR, applied again to a
     different metric. Not reconsidered.

**Chosen: 3.** It is the only option that needs neither data this deployment doesn't have (1) nor
configuration effort for rooms that don't have a natural capacity (2), and it is the only one that
doesn't reopen a judgment ADR-063 already declined to make (4, and arguably 1/2 as well, since a
computed or configured threshold is still a verdict, just with a more defensible number behind it).
1 and 2 remain viable future upgrades if the imbalance-only signal proves too coarse in practice —
not rejected outright, deferred pending real usage, same posture §3b's threshold already takes.

## Consequences

- Narrowly supersedes ADR-063's rejection of LLM-generated tips, for summary phrasing only.
  ADR-063's tip-selection rules, reassign flow, and Queue Stage Log decisions are unchanged.
- New files: `remedisys_healthcare_ai/prompts/queue-tips-summary-v1.txt`;
  `remedisys_healthcare_ai/tests/appointments/test_queue_tips.py`.
- Modified files: `services/queue_stage_log.py`, `api/v1/dashboard/api.py` (or a new
  `api/v1/dashboard/tips.py`), `integrations/openai.py`, `integrations/anthropic.py`,
  `docs/CLINICAL_COMMAND_CENTER.md` (§6, §9), and `QueueTipsPanel` in
  `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx`.
- New `AI Prompt Log` rows under `purpose="Queue Tips Summary"` and `purpose="Workload Tip Summary"`
  — the same audit trail every other LLM call in this system gets (Rule 10, CLAUDE.md §9 "Every
  LLM call").
- The workload suggestion adds new data dependencies this app has not previously combined:
  `Patient Appointment` counts grouped by practitioner+company+date, `Practitioner Schedule` +
  `Practitioner Availability` (ADR-062) for scheduled hours, and a per-practitioner consult-time
  average. None of this is built yet — see the open items in Context.
- **Re-evaluation trigger:** if a future change proposes adding any field to either stats dict
  that could identify a specific patient (e.g. "slowest patient" instead of "slowest room"), this
  ADR does **not** authorize that — it would need its own decision. Practitioner name/id in the
  workload stats dict is not a patient-PHI concern (a practitioner sees a suggestion about their
  own day) but is still scoped to that one practitioner, never another's. The same restriction
  applies to v1.4's new facts: "most overdue" names a **room**, never the patient in it — the
  existing `longest_wait`/`slowest_vs_average` precedent, not a new exception.
- **v1.4 status: built and verified, 2026-09-10.** The three fact computations
  (`_idle_room_fact`, `_most_overdue_fact`, `_overdue_rollup_fact`) are pure functions in
  `api/v1/dashboard/api.py` — no DB access, independently unit-tested with synthetic data rather
  than against this site's real (constantly-changing) queue state. `regenerate_queue_tips` wires
  them in per-audience. `prompts/ops-tip-summary-v1.txt` carries the phrasing priority per audience.
  20/20 tests passing (`tests/appointments/test_queue_tips.py`, via `bench console` per this
  module's documented workaround). Additionally verified live against the running site's real data
  for all three audiences — Front Desk's most-overdue fact correctly excluded a worse appointment
  sitting in Practitioner Room (not an owned room) that Admin's unrestricted rollup correctly
  included. No new files, no doctype/schema changes, no frontend changes — the response shape
  (`{summary, tips[], generated_at, model}`) is unchanged, so `QueueInsightBar` needed no edits.

## Verification

- `tests/appointments/test_queue_tips.py` asserts: (a) live-duration math is correct for an open
  row; (b) the historical-average figure matches `_build_queue_stage_breakdown`'s own output for
  the same data; (c) the stats dict passed to `generate_ops_tip_summary` contains no
  patient/practitioner-identifying keys (an explicit allowlist-of-keys assertion, not a blocklist);
  (d) an LLM failure still returns `tips[]` with `summary` absent/`None`, and does not raise.
- A new test file for the workload suggestion (once the open items in Context are resolved)
  asserts the same shape: (a) `slack_minutes` math is correct given known appointment counts and
  schedule blocks; (b) the threshold decision is deterministic and independent of any LLM call;
  (c) the stats dict contains no patient data; (d) LLM failure degrades to no suggestion shown,
  never an error.
- A manual click against a running site produces an `AI Prompt Log` row with
  `purpose="Queue Tips Summary"` (and, once built, `purpose="Workload Tip Summary"`).
- `docs/CLINICAL_COMMAND_CENTER.md` §9's "tips panel doesn't read live Queue Stage Log data yet"
  gap is removed once §3a ships.
- **v1.4, once built**, must additionally assert: (a) the Nurse fact only ever compares
  waiting_room/nursing_room, never any other pair; (b) the Front Desk "most overdue" figure is
  computed only from appointments in arriving_soon/waiting_room, matching what `_wait_minutes()`
  would report for the same appointment (same math, not reinvented); (c) the Admin board-wide
  imbalance and rollup facts still contain no patient-identifying key, per the existing allowlist
  test's pattern; (d) a role with no new fact available (nothing idle, nothing overdue) falls back
  to today's existing tips rather than fabricating one — "nothing notable" is a valid, honest
  output per the prompt's own existing rule 6, not a gap to fill.

## References

- [`docs/OPERATIONAL_SUGGESTIONS.md`](../OPERATIONAL_SUGGESTIONS.md) — companion mechanism doc, layer-by-layer, for both suggestion types.
- [`adr-063-clinical-command-center-reassign-and-stage-logging.md`](adr-063-clinical-command-center-reassign-and-stage-logging.md) — the ADR this narrowly supersedes.
- [`adr-062-practitioner-self-service-availability.md`](adr-062-practitioner-self-service-availability.md) — authority on `Practitioner Schedule`/`Practitioner Availability`, needed for §3b.
- [`adr-026-llm-provider-allowlist.md`](adr-026-llm-provider-allowlist.md) — governs how any new LLM call must be wired.
- [`adr-030-llm-curated-tool-access.md`](adr-030-llm-curated-tool-access.md) — the curated-not-autonomous boundary this stays inside.
- CLAUDE.md §4 Rule 4, Rule 6, Rule 9, Rule 10; §9.9 PHI-6.
- `remedisys_healthcare_ai/integrations/openai.py:1262` — `generate_thread_title()`, the precedent this follows.
- `remedisys_healthcare_ai/services/ai.py:629` — `log_prompt_call_general()`, the logging path this reuses.
- `docs/compliance/HIPAA_READINESS.md` — where a signed BAA, if durable, is recorded (not this ADR).
- `docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md` §9 — the explicit
  rejection of a per-room delay threshold this revision deliberately stays consistent with.
- `EB_Healthcare_Frontend/src/lib/narzim/roles.ts` — `Capabilities`, `ROOM_ROLES` (via
  `mission-control-client.tsx`) — the source of truth for which role can act on which room pair,
  verified directly against code before this revision scoped each new fact.
- `remedisys_healthcare_ai/api/v1/dashboard/api.py:63-77` — `_wait_minutes()`, the existing
  scheduled-slot-lateness math the Front Desk/Admin facts reuse rather than reinvent.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.28 | 2026-09-12 | Divyanshu (AI-assisted) | §3w extended (frontend): the "Nova Insights" text pill replaced with Nova's own circular portrait image, no text — per direct follow-up instruction. Reused the AI Workforce directory's existing portrait asset; the now-unused `Sparkles` icon and i18n key removed |
| 1.27 | 2026-09-12 | Divyanshu (AI-assisted) | §3w added (frontend): the panel's generic alert icon replaced with a named "Nova Insights" badge (Sparkles icon, the app's existing AI-brand teal), matching the AI persona branding already used on the AI Workforce screens |
| 1.26 | 2026-09-12 | Divyanshu (AI-assisted) | §3v added: fixed a real, confirmed defect — the summary trusted the client-sent `roles` to decide WHOSE appointments to count, not just which fact to phrase. A real account whose only actual role was EB_Practitioner was sent by the frontend as admin+nurse+frontdesk+practitioner, and this endpoint summarized the entire clinic to them despite their own board (correctly, server-side) showing only their own patients. Fixed by deferring to `_practitioner_read_scope()` (ADR-018) — the same check the board itself uses — whenever it is more restrictive than the client's claim |
| 1.25 | 2026-09-12 | Divyanshu (AI-assisted) | §3u added: reverted v1.23's auto-fetch-on-mount per direct instruction, after investigating a "stuck Refreshing" report. Root cause found: the project folder sits inside an actively-syncing OneDrive path, causing the dev server to rebuild itself unprompted and strand in-flight requests — an environment issue, not a code bug. Ruled out first: a hung LLM call, a re-firing effect, a mutation-wiring bug, and (a real, separate problem found and fixed along the way) duplicate dev-server processes |
| 1.24 | 2026-09-12 | Divyanshu (AI-assisted) | §3t added: refused a request to stream LLM tokens to the UI (CLAUDE.md Hard Don't) and fixed the actual underlying complaint instead — a stale, no-longer-accurate placeholder with zero loading feedback during the auto-fetch's wait, replaced with an honest "Generating…" state. Separately, prompt rebalanced so the recommendation half of each clause gets fuller phrasing than the fact half |
| 1.23 | 2026-09-12 | Divyanshu (AI-assisted) | §3s added (frontend): `QueueInsightBar` now auto-fetches the summary once when the panel first mounts, per direct instruction — narrows, not reverses, the "never polled, never scheduled" decision (a single bounded fetch tied to the user opening the page, not a recurring timer). The existing Refresh button is unchanged; every subsequent update still requires a manual click |
| 1.22 | 2026-09-12 | Divyanshu (AI-assisted) | §3r added: prompt-only compression fix for a heavily multi-role account (4 roles at once, 7 facts in one paragraph) — merge same-room facts into one clause, say a staffing recommendation once even when two different facts suggest it. No code/logic change; all facts confirmed correct, phrasing only |
| 1.21 | 2026-09-12 | Divyanshu (AI-assisted) | §3q added: a projected wall-clock finish time ("5:45 PM, 35min beyond plan") for the admin/nurse/frontdesk pace facts — pure arithmetic on numbers §3k already computes, no new judgment call. A reference design's severity-label styling ("Operationally critical") was explicitly declined per direct instruction — that would invent a threshold this ADR has consistently refused to add without a real product decision |
| 1.20 | 2026-09-12 | Divyanshu (AI-assisted) | §3p added: found live within the hour — §3o's own trigger was too narrow (busiest room had to also be the single board-wide worst-ratio room, so a smaller, less-consequential room with an even more extreme ratio could silently crowd out a real signal on the busiest room). Fixed by checking the busiest room's own ratio directly; the fact now also states the actual live-vs-historical numbers, not a bare "may need staffing" |
| 1.19 | 2026-09-12 | Divyanshu (AI-assisted) | §3o added: a real Admin-only "review staffing" decision for the case a room is BOTH busiest AND running slower than its own history — the coincidence of the two already-computed facts is the non-invented trigger, never a plain count alone. `busiest_room` was the last of the original two facts (with `slowest_vs_average`, fixed at v1.18) to never have a next step in this feature's history. Raised, not yet decided: whether board-wide-only facts should be scoped to each role's own rooms the way every actionable fact already is |
| 1.18 | 2026-09-12 | Divyanshu (AI-assisted) | §3n added: `slowest_vs_average` promoted from a fallback-only fact to a normal, always-covered one (fixing the actual reported gap — it was silently dropped whenever the board was busy enough to have another fact fire, which is the normal case); new `_slowdown_next_step_fact` adds a real decision — whether the very next pipeline stage is free to receive a patient right now, or is itself occupied too — instead of restating the room/duration pair as plain text |
| 1.17 | 2026-09-12 | Divyanshu (AI-assisted) | §3m added: Checkout excluded from `most_overdue`/`overdue_rollup`'s room pool — a Checkout appointment's large `wait_minutes` is structural (it has already passed through four earlier stages), not a real delay, and the fixed "review staffing" next step attached to it was actively the wrong instruction. `payment_pending_count` (already built, already covers Checkout) remains Checkout's real signal |
| 1.16 | 2026-09-12 | Divyanshu (AI-assisted) | §3l added: worst current wait among Nursing Room patients still missing vitals — a priority signal, not just a restated count, after direct Nurse feedback that the existing `vitals_missing_count` just repeats a number already visible on the board. Live investigation on the way to building it found two real, separate issues in the demo data (near-zero synthetic Queue Stage Log durations defeating `nurse_pace`; a recurrence of the v1.9 stale-open-row bug in a naive standalone check) — neither is a defect in `regenerate_queue_tips` itself, which already applies the v1.9 date-scoping fix |
| 1.15 | 2026-09-12 | Divyanshu (AI-assisted) | §3k added: pace/throughput fact for Front Desk, Nurse, and Admin — the same fact §3c already built for a practitioner's own day, extended to every other role that gets a queue-tips summary. Decision only, not yet built. New "Alternatives considered" subsection: four options for what stands in for a practitioner's own schedule (no such concept exists for these three roles) — chosen: derive the deadline from the last actually-booked appointment of the day, never a new setting, never an aggregate of practitioners' own schedules |
| 1.14 | 2026-09-11 | Divyanshu (AI-assisted) | Rebuilt the three test files this ADR's coverage depended on (`test_queue_tips.py`, `test_queue_stage_log.py`, `test_workload_suggestion.py`), missing from disk since before v1.9 — rewritten from current code, not memory; 89/89 passing, live-verified via `bench console`. Closes the "no automated test" status note carried since v1.9 |
| 1.13 | 2026-09-11 | Divyanshu (AI-assisted) | §3j added: a new "practitioner unavailable, needs reassign" count fact, gated to Admin/Nurse/Front Desk (matching `_REASSIGN_ROLES`). A design bug caught via live testing — `assert_bookable()` alone missed real holidays (its holiday check is a dead Employee-based path) — fixed by also composing `get_practitioner_holidays()`. Live-verified with a real, temporary Holiday List entry, added and removed in the same session |
| 1.12 | 2026-09-11 | Divyanshu (AI-assisted) | §3i added: durations over 60 minutes now phrase as hours ("8hr 10min"), matching the board's own card badges, via a new shared `format_minutes()`. Applied to the LLM-facing `stats` dict only, never to either endpoint's actual JSON response. Live-verified against a real, temporarily-created scenario. Also recorded: the three test files this ADR's coverage depended on are missing from disk — not rebuilt as part of this fix |
| 1.11 | 2026-09-10 | Divyanshu (AI-assisted) | §3h added: a bare Practitioner session now rides `regenerate_queue_tips`, scoped to their own appointments across all five rooms (Rule 10/PHI-6). New `own_appointments_only` stats flag so room facts are phrased as "your own patients," never the room's real total. `idle_room`/`overdue_rollup` correctly excluded (no lever over either). 69/69 tests passing (new `TestPractitionerAudience`), live-verified against the real Sarvesh Sandhu account |
| 1.10 | 2026-09-10 | Divyanshu (AI-assisted) | §3g added: reported "AI hallucination" (Waiting Room shown overdue while empty) investigated and found to be a real bug, not a hallucination — a stale prior-day Queue Stage Log row was never date-scoped. Fixed in both `regenerate_queue_tips` and `_my_ready_patient_fact`; live-verified numbers dropped to a realistic range. Flagged, not fixed: nothing currently closes a stale open row at all |
| 1.9 | 2026-09-10 | Divyanshu (AI-assisted) | §3f added: prompt rewritten to cover every applicable fact (not only the single leading one) after live verification showed the board can have 3+ facts true at once for one audience. Investigated and confirmed separately: `EB_Practitioner` sees nothing because no frontend screen calls `get_my_workload_suggestion` at all — a pre-existing open item, not a new bug. Flagged, not fixed: the frontend summary span truncates to one line, which will clip a multi-fact summary |
| 1.8 | 2026-09-10 | Divyanshu (AI-assisted) | §3e added: new shared fact `patient_ready_and_waiting_fact()` (in `services/queue_stage_log.py`) for a vitals-checked patient still stuck in Nursing Room — the mirror case of `vitals_missing`. Wired to Nurse (board-wide) and, new, to the practitioner's own `get_my_workload_suggestion` (pre-filtered to their own patients only, Rule 10/PHI-6). 64/64 tests passing, live-verified against the exact reported scenario (B Praak) for both roles |
| 1.7 | 2026-09-10 | Divyanshu (AI-assisted) | §3d added: new Practitioner-Room-duration fact for Nurse; multi-role support (`_resolve_audiences` supersedes `_resolve_audience` — a user holding more than one role now gets every held role's additive facts, not just one); a real bug found and fixed live (the board-wide idle-room check recommended a physically nonsensical 4-stage-skip move — restricted to adjacent pipeline pairs only). 44/44 tests passing, re-verified live after the fix |
| 1.6 | 2026-09-10 | Divyanshu (AI-assisted) | §3c added: a fixed, deterministic next-step phrase per fact (move a patient, record vitals, collect payment, check someone in, review staffing), addressing feedback that facts-only summaries weren't actionable. Two new facts: Nurse vitals-missing count (reusing `get_dashboard_data`'s existing Vital Signs existence check) and a Practitioner mid-day pace check using today's actual completed consultations, independent of the historical-average slack forecast. 34/34 tests passing, live-verified |
| 1.5 | 2026-09-10 | Divyanshu (AI-assisted) | v1.4 built: `_idle_room_fact`/`_most_overdue_fact`/`_overdue_rollup_fact` implemented as pure functions in `api/v1/dashboard/api.py`, wired into `regenerate_queue_tips`, prompt updated, 20/20 tests passing, verified live against real queue data for all three audiences |
| 1.4 | 2026-09-10 | Divyanshu (AI-assisted) | Decision only, not yet built: role-scoped facts added to §3a — Nurse (idle Nursing Room vs. busy Waiting Room), Front Desk (most overdue vs. scheduled slot, reusing `_wait_minutes()`), Admin (board-wide imbalance + a lateness rollup). Deliberately an imbalance fact, not a crowding verdict — new "Alternatives considered" subsection records why, consistent with ADR-063's explicit rejection of a duration threshold. Room-pair scoping verified directly against `EB_Healthcare_Frontend`'s role/capability code, not assumed |
| 1.3 | 2026-09-10 | Divyanshu (AI-assisted) | Two live bugs found and fixed, both discovered from real product-owner use: raw room keys ("waiting_room") were reaching the LLM verbatim instead of a human label; every `AI Prompt Log` write for both suggestion types was silently failing (the doctype's `purpose` Select field never had these two options added), so real, successful LLM calls left zero audit trail — a violation of CLAUDE.md §9's "every LLM call is logged." Both fixed; see `docs/OPERATIONAL_SUGGESTIONS.md` §3 revision 1.5 for detail |
| 1.2 | 2026-09-10 | Divyanshu (AI-assisted) | Verified the cross-clinic data model does not exist (custom_company orphaned, no company field on Practitioner Schedule, deployment confirmed single-clinic 2026-09-03) — cross-clinic comparison deferred per product-owner instruction; §3b rewritten as the single-clinic version actually built, with its two open design questions (avg-consult fallback, threshold) resolved rather than left open. Both §3a and §3b backend built this revision |
| 1.1 | 2026-09-10 | Divyanshu (AI-assisted) | Widened scope to also cover the cross-clinic practitioner workload suggestion (§3b), per direct product-owner instruction after the tradeoffs were discussed; added the open items blocking that half specifically; title widened, filename unchanged (ADR-043) |
| 1.0 | 2026-09-10 | Divyanshu (AI-assisted) | Initial version |
