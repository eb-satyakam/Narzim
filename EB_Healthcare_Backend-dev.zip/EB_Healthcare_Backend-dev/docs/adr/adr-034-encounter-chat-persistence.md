# ADR-034: Persist Narzim encounter chat in an encounter-scoped doctype

**Doc status:** living · **Created:** 2026-07-25 by Sarvesh-SocialAngel · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-07-25
- **Supersedes:** none
- **Superseded by:** —
- Related: ADR-030 (curated LLM tool access), ADR-030 (AI Patient Chat persistence — patient-portal), ADR-009 (AI session lifecycle)

## Context

The "Ask Narzim AI" encounter copilot (`ask_copilot`, ADR-030) is a bounded
agentic turn scoped to a single Patient Encounter. Until now its chat lived only
in the browser's memory: it was lost on reload/navigation, so Narzim had no
memory of what was already discussed on an encounter, and its suggestions were
never stored. The physician also wants a "Save & analyze" action that runs the
agent over the whole conversation + transcript and fills the draft.

The existing `AI Patient Chat Message` doctype (ADR-030) is **patient-portal**
scoped (keyed on `patient`, no `encounter` link) and mixes a different trust
context (patient-facing) — reusing it for the physician copilot would conflate
two distinct surfaces in one table.

## Decision

Add a new doctype **`AI Encounter Chat Message`**, keyed on `encounter`
(with `patient` / `appointment` / `practitioner` fetched from it), storing each
turn's `role` (doctor|assistant), `content`, the `actions_json` (suggestions the
turn produced), a `kind` (chat|analysis), and audit fields (model / tokens /
latency), mirroring the other AI doctypes.

- `ask_copilot` persists each turn and loads prior turns from this doctype for
  context (capped to the last N turns — Rule 5, no full-history dump).
- `get_encounter_chat(encounter)` replays the persisted thread to the frontend.
- `analyze_encounter(encounter, transcript)` ("Save & analyze") runs the agent
  over the full chat + transcript and returns ClinicalSuggestions filled into
  the draft (Rule 6 — still suggestions, never direct DB writes), persisted as
  `kind="analysis"`.

Permissions: System Manager (full), Physician (read/write/create/report),
Healthcare Administrator (read/report). `track_changes` on.

## Consequences

- Narzim gains durable, encounter-scoped memory that survives reload and links
  cleanly to the encounter → patient → appointment graph.
- Rule 5 is respected by capping the context window fed to the model.
- Rule 6 is unchanged: write tools still emit draft suggestions, not DB writes.
- Content is stored intentionally (chat replay is the feature); logs still carry
  IDs/tokens only (Rule 10). If a deployment's `ComplianceProfile` later requires
  content-at-rest controls, this is the single table to gate.
- A new doctype is created via the module on `bench migrate` (no data patch
  needed for creation).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Status block normalised to `- **Status:**`, the shape the rest of the set uses, so the ADR tooling can read it. No decision changed |
| 1.0 | 2026-07-25 | Sarvesh | Initial version (header backfilled from git history) |
