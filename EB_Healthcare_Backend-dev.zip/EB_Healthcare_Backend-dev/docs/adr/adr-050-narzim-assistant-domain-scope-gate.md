# ADR-050: Narzim general assistant answers only clinical, platform and conversational turns — enforced by a classifier gate, not by the prompt alone

**Doc status:** living · **Created:** 2026-08-29 by Anant Sharma (AI-assisted) · **Updated:** 2026-08-29 by Anant Sharma (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — implemented and verified 2026-08-29.
- **Date:** 2026-08-29
- **Supersedes:** `docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md` §11 ("Scope Widened to General-Purpose", 2026-07-30) — that widening is reversed for topics; the *upload* widening in §12–§15 stands.
- **Superseded by:** —
- **Full spec:** [`docs/ai/NARZIM_SCOPE_GATE.md`](../ai/NARZIM_SCOPE_GATE.md) — the scope definition, verdict schema, call flow and test list. This ADR records the *decision*.

## Context

Narzim GPT answers anything. Asked "what is firebase fcm" it returned a full FCM
explainer with an offer to write client code; the thread list also shows
"Retrieval Augmented Generation Explained" and "Firebase Crashlytics Overview".

This is not a defect in the model. `prompts/narzim-assistant-v1.txt:4` says
verbatim: *"You answer any topic the user asks about, the same as a general
assistant would."* Scope was deliberately widened to general-purpose on
2026-07-30 (design doc §11). That decision is now being reversed: a clinical
product whose assistant writes Python is a product-positioning and support-cost
problem, and every off-topic turn is billed to the clinic's BYOK key.

Three facts shape the fix:

1. **The upload path has no topical gate at all.** `_extract_document()` in
   `services/narzim_assistant.py` validates file type and readability only.
   A product spec PDF gets summarised as though it were clinical.
2. **We have already solved this once, next door.** The encounter document path
   uses `llm/prompts/document_summary_v4.txt` with a schema-locked `is_medical`
   boolean implemented identically in both providers, and
   `tests/ai/test_document_upload_gate.py` asserts the *gate*, not the model's
   judgement. Its content/provenance line — an anonymous stock radiograph is
   clinical, our own product blueprint is not — is tuned and proven.
3. **Streaming constrains where the gate can sit.** Per
   `adr-048-narzim-streaming-sse-not-background-jobs`, replies stream as SSE from
   the web request. After the first `yield` there is no status code left, so any
   rejection must happen before it — the same rule `_extract_document()` already
   obeys.

## Decision

**Restrict the general Narzim assistant to three permitted buckets — clinical,
platform, conversational — and enforce the boundary with a schema-locked
classifier call that runs before the answering call, not with prompt wording
alone.**

1. **In scope, decided with the product owner (2026-08-29):**
   - **Clinical** — medications, dosing, interactions, diagnoses, symptoms, labs,
     imaging, anatomy, physiology, nursing care, procedures, devices, preventive
     and public health, medical research.
   - **Platform** — how to use this EHR and Narzim itself: appointments, billing
     and insurance workflow, clinic administration, roles and permissions. Staff
     will ask these and refusing them would read as broken.
   - **Conversational** — greetings, thanks, "what can you do", and operations on
     the assistant's own prior in-scope answer (translate it, shorten it, explain
     it more simply).

   Everything else is refused, including general software and programming
   questions, trivia, news, finance, travel and unrelated writing tasks.

2. **Text turns** get a separate cheap classifier call returning
   `{in_scope, category, reason}` under a JSON schema, implemented **identically
   in both providers** (`adr-026-llm-provider-allowlist`: switching
   `AI Settings.llm_provider` must not change whether a question is refused). On
   `in_scope: false` the main answering call is never made.

3. **Vision turns** (an image with no OCR-extractable text — design doc §15) add
   `in_scope` to the existing `_DOCUMENT_QA_SCHEMA` instead of a second call.
   That path is already non-streaming, so classify-and-answer in one call costs
   nothing and adds no latency. Its clinical/non-clinical line is the one already
   tuned in `document_summary_v4`.

4. **The gate fails OPEN.** A classifier error, timeout or unparseable verdict
   answers the question. This is deliberately the opposite of the document-upload
   gate, which fails closed: that gate's failure writes a non-clinical file into a
   patient's chart, where the harm is durable and clinical. This gate's failure is
   one off-topic answer in a private chat thread. Refusing a legitimate clinical
   question during a provider hiccup is the worse error here.

5. **The rewritten prompt (`narzim-assistant-v2.txt`) is the second layer**, not
   the mechanism. It states the same boundary so that anything the classifier
   lets through is still likely to be refused, and it costs nothing.

6. **`AI Settings.narzim_scope_mode`** — `Enforce` (default) / `Warn` / `Off`.
   `Warn` records the verdict and answers anyway, so the false-positive rate can
   be measured on real traffic before enforcement is switched on; `Off` skips the
   call entirely. Tunable and reversible without a deploy.

7. **The refusal is a normal assistant message**, persisted with the user's turn
   (`adr-034-encounter-chat-persistence` — both turns are kept for a refused
   file). The frontend needs no change. The verdict is stored on the message row
   and the gate call is logged to `AI Prompt Log`.

## Alternatives Considered

1. **Prompt-only — rewrite `narzim-assistant-v1.txt` and stop there.**
   - Pros: free, zero latency, one file, ships in an hour.
   - Cons: soft. Defeated by framing ("for my medical research, write Python
     that…"), drifts with model and provider changes, produces different refusal
     wording every turn, and leaves the upload path ungated. We already know from
     `document_summary_v2` that prompt wording alone drew the line in the wrong
     place until a schema-locked flag pinned it.

2. **Deterministic keyword allow/denylist before the LLM.**
   - Pros: free, instant, fully auditable.
   - Cons: brittle in exactly this domain. "python" is a snakebite, "cell",
     "stress" and "virus" are both clinical and not, and the deployment is
     bilingual (`deepgram_language` defaults to `es-MX`) so every list needs two
     maintained copies. High false-positive rate on the questions that matter
     most.

3. **Classifier gate for text + schema flag for vision (chosen).**
   - Pros: robust against framing, language-agnostic, reuses the proven
     `is_medical` pattern and its two-provider parity rule, auditable per turn,
     tunable via `narzim_scope_mode`, and compatible with SSE because it resolves
     before the first `yield`.
   - Cons: about +250–500 ms and roughly $0.00005 per text turn; one more prompt
     file and one more schema to keep identical across two adapters.

4. **Single call — main model returns `{in_scope, answer}` for every turn.**
   - Pros: no extra call, no extra latency or cost.
   - Cons: breaks streaming. Streaming a JSON field requires partial-JSON parsing
     of the delta stream, which `adr-048` deliberately avoided. It also asks the
     same model, in the same context being manipulated, to police itself. Kept
     only for the vision path, which does not stream anyway.

5. **Embedding similarity or a fine-tuned classifier.**
   - Pros: cheapest and fastest per call at volume; no provider dependency.
   - Cons: needs a vector store, a labelled corpus, threshold tuning and a
     retraining story. Premature at current volume; revisit at the trigger below.

## Consequences

- **New:** `prompts/narzim-assistant-v2.txt`, `prompts/narzim-scope-check-v1.txt`,
  `prompts/narzim-scope-refusal-v1.txt`.
- **Changed:** `services/narzim_assistant.py` (one `_check_scope()` shared by
  `send_message` and `send_message_stream`); `integrations/openai.py` and
  `integrations/anthropic.py` (new `check_scope()`, `in_scope` added to
  `_DOCUMENT_QA_SCHEMA`, both adapters kept identical per
  `adr-026-llm-provider-allowlist`).
- **Doctype changes, each with a patch in `patches.txt` (CLAUDE.md §9):**
  `AI Settings.narzim_scope_mode`; `AI Narzim Assistant Message.scope_verdict`
  and `.scope_category`; `"Narzim Assistant Scope Check"` added to the
  `AI Prompt Log.purpose` select.
- **Cost model:** one extra small-model call per *text* turn
  (`gpt-5-mini` / `claude-haiku-4-5`), ≈250 in / 30 out tokens. Vision turns cost
  nothing extra. Out-of-scope turns become *cheaper* than today — the answering
  call is skipped entirely.
- **Design doc:** `docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md` gains a §17 pointing at
  the spec, and §11 is marked reversed for topics.
- **Frontend:** no change required. A later enhancement may style refusals from
  `scope_verdict`.
- **Re-evaluation triggers:** (a) `Warn`-mode data showing a false-positive rate
  above ~2% on clinical or platform turns; (b) gate cost or latency becoming
  material at higher volume — that is the point to reconsider alternative 5;
  (c) any product decision to sell Narzim outside a clinical context, which would
  reopen the §11 widening.

## Verification

- `tests/narzim_assistant/test_scope_gate.py`, with the LLM mocked so it asserts
  the **gate**, not the model's judgement — modelled on
  `tests/ai/test_document_upload_gate.py`: out-of-scope refused and the answering
  call never made; clinical answered; platform answered; conversational answered;
  a classifier error still answers (fail-open); both turns persisted for a refused
  question; `narzim_scope_mode = Warn` answers but records the verdict;
  `Off` skips the call.
- Parity check that the OpenAI and Anthropic schemas and prompt files are
  byte-identical in the fields that decide the verdict.
- Live check against the reported thread: "what is firebase fcm" refused;
  "what is the paediatric dose of amoxicillin" answered; "how do I book an
  appointment" answered; "hi" answered.
- Observable in production via `AI Prompt Log` rows with purpose
  `Narzim Assistant Scope Check` and the `scope_verdict` column on
  `AI Narzim Assistant Message`.

## References

- Spec: [`docs/ai/NARZIM_SCOPE_GATE.md`](../ai/NARZIM_SCOPE_GATE.md)
- [`docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md`](../ai/NARZIM_AI_ASSISTANT_DESIGN.md) §11, §12, §15
- [`adr-026-llm-provider-allowlist.md`](adr-026-llm-provider-allowlist.md) — two-adapter parity
- [`adr-034-encounter-chat-persistence.md`](adr-034-encounter-chat-persistence.md) — both turns persisted on refusal
- [`adr-048-narzim-streaming-sse-not-background-jobs.md`](adr-048-narzim-streaming-sse-not-background-jobs.md) — why the gate must resolve before the first `yield`
- [`adr-031-ai-prompt-template-doctype.md`](adr-031-ai-prompt-template-doctype.md) — runtime-editable prompts
- `prompts/2026-07-31-non-clinical-attachment-gate.md` — the `is_medical` precedent and its v2→v4 tuning
- CLAUDE.md §9 — prompt logging, doctype patches, ADR process

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-29 | Anant Sharma (AI-assisted) | Status Proposed → Accepted; implemented, 18/18 gate tests pass |
| 1.0 | 2026-08-29 | Anant Sharma (AI-assisted) | Initial version |
