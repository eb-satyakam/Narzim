# ADR-057: Recognise a returning patient by tiered matching, and reveal nothing while doing it

**Doc status:** living · **Created:** 2026-09-03 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-03 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-09-03
- **Supersedes:** —
- **Superseded by:** —

## Context

Self-service patient registration is **live** on the patient portal URL:
`patient_portal.register()` (`api/v1/patient_portal/api.py:122`) is
`@frappe.whitelist(allow_guest=True)`, creates a `Patient` plus a Website User
with the `EB_Patient` role, and returns an eb_frappe_jwt token pair so the
registrant is logged straight in. A QR code pointing at that screen is being
added (`docs/scanner/REQUIREMENT.md`), which will increase the
traffic reaching it but creates none of the problems below — they are already
reachable today.

**Every duplicate guard in the codebase keys on an exact identifier:**

| Where | Keys on | Behaviour |
|---|---|---|
| `patient_portal.register()` | `Patient.uid` (`id_number`) | 409 naming the existing MRN |
| `patients.create_patient()` | `Patient.uid` (CURP) | throws `DuplicateEntryError` |
| `appointments._create_patient_for_booking()` | `Patient.uid` | throws |
| `overrides/patient_duplicate_check.py` | `User.email` | links to the existing User, or throws |

Nothing matches on name, date of birth or mobile number. The consequence is a
split chart: allergies recorded on record A are invisible to a physician
looking at record B. Recorded previously as **R3** in
`docs/audit/frontdesk/screens/03-patient-registration.md` and rated Med-High,
where the chosen remedy was **warn-and-allow** via the existing `list_patients`
search — a decision made on 2026-07-18 **for authenticated front-desk staff**,
who can open the matched chart and judge it.

Three facts constrain the choice here and did not apply to that decision:

1. **The caller is anonymous.** `list_patients` is staff-permissioned and
   returns patient names and MRNs. Exposing it to a guest screen would confirm
   a stranger's identity to anyone who types a common name and a plausible
   date of birth. Warn-and-allow cannot be reused as-is.
2. **The fields a fuzzy match would use are optional.** `Patient.dob` and
   `Patient.mobile` default to `None` in the doctype and in
   `create_patient()`'s signature. Measured on the local bench 2026-09-03:
   575 of 654 patients have no `dob`, 630 have no `mobile`, and **653 of 654
   have no `uid`** — so the system's only existing guard is inert for
   virtually every chart that exists. That bench is mostly seeded and QA data
   (598 rows owned by `Administrator`), so the *percentages* are a warning
   rather than a production measurement; the *optionality* is a schema fact
   and is not.
3. **The patient cannot answer the question.** The person least able to know
   whether they already hold an MRN is the person registering. A warning they
   are invited to click past is, for this audience, a warning that will be
   clicked past.

Constitution: `CLAUDE.md` §9.9 **PHI-6** (minimum necessary) and **PHI-8** (no
PHI in logs); Rule 10. `adr-011-auth-eb-frappe-jwt` for the token pair
`register()` already returns. `flows/FLOWS_PATIENT_PORTAL_INVITE.md` for the
existing account-access email path this decision reuses.

## Decision

**Match server-side in three tiers, and let a probable match reveal nothing to
the caller beyond a masked hint of the contact channel we already hold. Never
hand an anonymous caller a name, an MRN, a date of birth or a full contact
value.**

1. **Tier 1 — exact identifier (`uid`, or `User.email`).** Unchanged from
   today: 409, and the existing MRN may be named, because the caller has
   already demonstrated knowledge of the identifier. This preserves current
   behaviour rather than replacing it.

2. **Tier 2 — probable match: normalised name **and** date of birth.** Name
   comparison uses `_name_tokens()` from `api/ai/lab_extraction.py` — existing,
   accent-, case- and punctuation-insensitive, dropping single-letter initials,
   written to compare a printed name against a patient record. It already
   handles `Gomez` vs `Gómez`. **Do not write a second name normaliser.**
   Response: `{"match": "probable", "contact_hint": "a•••@gmail.com"}` and an
   offer to send an access link to the contact on file. Nothing else.

3. **Tier 3 — weak suspicion: normalised name only, or name plus mobile.**
   Does **not** block and does **not** claim a match. It routes to the same
   "we may already have your record — we can send a link" offer as Tier 2,
   because the remedy is identical and safe, while the caller learns nothing
   they did not supply.

4. **The access link is the only channel that carries identity.** It goes to
   the email or mobile already on the matched record, never to a value the
   caller typed, and it reuses the portal-invite path
   (`admin/_helpers.py::send_portal_access_notice`,
   `send_set_password_email`) rather than a new one.

5. **"Too empty to confirm" is a defined outcome, not a fall-through.** When
   the candidate record carries neither `dob` nor a usable contact channel —
   the majority case on today's data — there is nothing to verify against and
   nothing to send a link to. Those cases show *"please ask reception to
   confirm your record"* and do not create a `Patient`. This is deliberately
   the one place the front-desk hand-off applies.

6. **`dob` becomes required for self-registration.** It is the only field that
   makes a name match safe, and in a pediatric clinic it is clinically
   necessary regardless: every mg/kg dose and every weight-for-age percentile
   depends on it. Staff-side `create_patient()` is **unchanged** — front desk
   can still register without a DOB, because refusing a walk-in over a missing
   field is worse than the alternative.

7. **The caller always has a way forward.** "This is not me" continues to
   registration, and the event is recorded (see 8). Blocking a genuinely new
   patient is a worse failure than admitting a duplicate.

8. **Every tier-2 and tier-3 event is logged with IDs and the tier only** —
   never the compared values (Rule 10). Without this the false-positive rate
   is unknowable and clause 7 cannot be tuned.

9. **Rate limiting is a precondition, not a companion improvement.** A
   matching endpoint reachable by a guest is an identity oracle; see
   Consequences for the limit this does and does not buy.

## Alternatives Considered

1. **Keep exact `uid` matching only (the status quo).**
   - Pros: zero work; zero false positives; no disclosure surface at all;
     already shipped and understood.
   - Cons: inert for 653 of 654 existing charts, and defeated by one mistyped
     CURP character. It is the reported defect, so choosing it is choosing to
     leave R3 open on a live self-service URL where no staff member is watching.

2. **Warn-and-allow, mirroring the front-desk R3 decision** — search
   name+DOB/mobile, show "possible existing patient", let the caller continue.
   - Pros: consistent with a decision already taken; reuses `list_patients`;
     never blocks a real new patient; smallest frontend change.
   - Cons: fails on a checkable fact — `list_patients` is staff-permissioned
     and returns names and MRNs, so wiring it to a guest screen discloses a
     stranger's identity to anyone guessing a common name and DOB. The R3
     decision it copies was made for an authenticated user who could see the
     chart; the warning it shows asks the patient to make a judgement they
     have no basis for.

3. **Blind claim-and-verify, tiered (chosen).**
   - Pros: satisfies "recognise the returning patient" and "reveal nothing to
     an anonymous caller" simultaneously — matching happens where the data
     already is, and identity only ever travels to a channel already on file.
     Reuses `_name_tokens()` and the existing invite path. Degrades honestly
     when the candidate record is too empty to verify (clause 5), instead of
     silently reporting "no match" as a name+DOB-only design would.
   - Cons: the most work of the four; needs a guest-safe response shape, a
     tier definition, and the "this is not me" escape. Reduces duplicates
     without eliminating them — a matched patient with a stale email will take
     the escape and register again. Requires making `dob` mandatory for
     self-registration, which will cost some completions.

4. **Hand every probable match to the front desk.**
   - Pros: no disclosure risk whatsoever; a human with the paper chart
     resolves it; simplest logic; strictly safest.
   - Cons: the returning patient is the *common* case, not an edge case.
     Sending them to reception removes the only benefit self-service has and
     turns the QR into a queue ticket. Retained for clause 5 only, where there
     is genuinely nothing to verify against.

## Consequences

- **Code to write:** tiered matching in `services/patients.py` (not inline in
  the API); a guest-safe `check_existing_patient` and `request_access_link` in
  `api/v1/patient_portal/api.py`; `dob` added to `register()`'s required set;
  `@rate_limit` on `register()` and both new endpoints.
- **`register()`'s contract changes** — `dob` moves from optional to required.
  A **MIGRATION** note for the frontend: the portal registration form must
  collect it before this ships, or registration breaks.
- **`_name_tokens()` moves.** It currently lives in
  `api/ai/lab_extraction.py`, which is the wrong home once patient matching
  depends on it. Move to `services/` and re-export, or import it explicitly —
  do not copy it.
- **New `allow_guest` endpoints must satisfy**
  `tests/patient_portal/test_portal_scoping_guardrails.py`, which asserts every
  guest endpoint in the module is deliberate.
- **Known limitation, stated rather than solved: this is still an identity
  oracle.** Behaviour must differ between "we may know you" and "registration
  proceeded", so an attacker can infer whether a name+DOB is a patient at this
  clinic. Rate limiting raises the cost; it does not remove the inference. A
  neutral always-the-same response was considered and rejected because a
  genuinely new patient would then wait for an email that never arrives. This
  is a deliberate trade, and it is the clause to revisit first if the endpoint
  is ever abused.
- **Does not fix existing duplicates.** Detection is at the point of
  registration. The 5 name-only duplicate groups already on the bench need a
  staff-side merge surface, which is out of scope here.
- **Re-evaluation triggers:** (a) a measured tier-2/tier-3 false-positive rate
  high enough that real new patients are routinely diverted — the log in
  clause 8 exists to detect exactly this; (b) a match rate so low that the
  tiers buy nothing over alternative 1; (c) evidence of enumeration against
  the endpoint.

## Verification

- Integration test: a `Patient` with `uid = ""`, a DOB and a name registers
  again through `register()` with a CURP supplied → tier 2 fires, **no second
  `Patient` row is created**, and the response body contains no name, MRN or
  DOB. This is the case `docs/scanner/REQUIREMENT.md` §5.3
  describes and the one alternative 1 misses.
- Integration test: two different people sharing a name and DOB → the second
  can still complete registration via "this is not me", and learns nothing
  about the first.
- Integration test: a candidate record with no `dob` and no contact channel →
  the reception message, and no `Patient` inserted.
- `test_portal_scoping_guardrails.py` passes with the new guest endpoints.
- Rate limit proven by exceeding it in a test.
- `grep` of a full registration run's logs shows no patient name, DOB, email,
  mobile or CURP (Rule 10).

## References

- `CLAUDE.md` §9.9 PHI-6, PHI-8; §4 Rule 10
- `docs/scanner/REQUIREMENT.md` §5.3, §7 (the four approaches, costed)
- `docs/audit/frontdesk/screens/03-patient-registration.md` R3 — the front-desk decision this deliberately does not reuse
- `docs/flows/FLOWS_PATIENT_PORTAL_INVITE.md` — the access-link path reused here
- `adr-011-auth-eb-frappe-jwt.md` — the token pair `register()` returns
- `remedisys_healthcare_ai/overrides/patient_duplicate_check.py` — why a shared mobile must never block

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Anant Sharma (AI-assisted) | Initial version. Proposed, not accepted — clauses 6 (mandatory `dob`) and the identity-oracle limitation need the repo owner's decision |
