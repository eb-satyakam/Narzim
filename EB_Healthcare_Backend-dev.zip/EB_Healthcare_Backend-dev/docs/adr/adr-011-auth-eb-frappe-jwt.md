# ADR-011: Authenticate via eb_frappe_jwt Bearer tokens (supersedes OAuth2 + SID)

**Doc status:** living · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-05 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-05
- **Supersedes:** ADR-010 §3 (the clause storing the Frappe **SID** in the NextAuth session); the Phase 0 **Frappe OAuth2** login mechanism (`/oauth2/get_token`) documented in `docs/SYSTEM_DESIGN.md`, `docs/WORKFLOWS.md`, and the `bruno/auth/` collection.
- **Superseded by:** —

## Context

Authentication is currently fragmented across three inconsistent designs:

1. **Backend (Phase 0)** was built and documented for **Frappe's built-in
   OAuth2** — `POST /api/method/frappe.integrations.oauth2.get_token` (password
   grant, `client_id`/`client_secret`), with `get_current_user()` reading
   `frappe.session.user`. The Bruno collection and `docs/WORKFLOWS.md` describe
   this flow.

2. **ADR-010 §3** specified the BFF pattern storing the Frappe **SID** session
   token in the NextAuth session.

3. **The frontend (`Healthcare_next_app/src/lib/auth.ts`) actually implements
   neither cleanly** — it calls Frappe's classic `POST /api/method/login`,
   scrapes the `sid` cookie, and sends `Cookie: sid=<sid>` on every API call.
   The OAuth2 `client_id`/`client_secret` in `.env.local` are referenced nowhere
   in `src/`.

This works only incidentally: `frappe.session.user` is populated from either a
Bearer token or a sid cookie, and both `get_current_user()` and
`require_permission()` read `frappe.session.user`. The consequences of leaving
it as-is:

- **No token refresh.** The frontend enforces a hard 24-hour expiry and relies
  on Frappe session auto-extension. There is no refresh-token rotation.
- **No 2FA and no brute-force lockout** on the live path beyond Frappe defaults.
- **The planned mobile client cannot use sid cookies** — it requires a Bearer
  token (BACKEND_ARCHITECTURE.md §1 already shows "Bearer Token · HTTPS").
- **Dead OAuth2 configuration** invites confusion and credential sprawl.

Separately, the team has built **`eb_frappe_jwt`** — a standalone, CI-green
Frappe app (github.com/eBasics-Services-P-Limited/eb_frappe_jwt) providing
HS256 Bearer JWTs with single-use refresh-token rotation, two-factor OTP
support, and per-user/per-IP brute-force lockout, integrated through Frappe's
official `auth_hooks` pipeline. `prompts/2026-06-05-eb-frappe-jwt.md` records
the intent to adopt it here.

## Decision

**Adopt `eb_frappe_jwt` Bearer JWT as the single authentication mechanism for
Remedisys**, replacing both the Phase 0 OAuth2 flow and the ADR-010 SID-cookie
storage. The ADR-010 BFF pattern is otherwise **preserved** — tokens remain
server-side in the NextAuth session and are never exposed to the browser; only
the credential changes from a Frappe SID cookie to an eb_frappe_jwt access +
refresh pair.

1. **`remedisys_healthcare_ai` depends on `eb_frappe_jwt`** via
   `required_apps = ["eb_frappe_jwt"]` in `hooks.py`. The signing secret
   (`eb_jwt_secret`) is set per site in `site_config.json`.

2. **Login** uses `POST /api/method/eb_frappe_jwt.api.get_token`
   (`{usr, pwd, device?}`) returning `{access_token, refresh_token,
   token_type, expires_in}`.

3. **Every authenticated request** sends `Authorization: Bearer <access_token>`.
   `eb_frappe_jwt`'s `auth_hooks` sets `frappe.session.user`; `get_current_user()`
   and `require_permission()` are **unchanged** — they already read it.

4. **Refresh** uses `POST /api/method/eb_frappe_jwt.api.refresh_token`. Refresh
   tokens are single-use (rotation); the frontend must store the new refresh
   token returned on each refresh.

5. **Logout** uses `revoke_token` (this device) / `revoke_all_tokens` (all).

6. **Two-factor auth is supported by the backend now but deferred on the
   frontend.** Password-only Bearer ships first. When 2FA is enabled, `get_token`
   returns `{requires_2fa, tmp_id}` and the frontend completes login via
   `verify_otp(tmp_id, otp)`. This second-step flow is a follow-up, tracked
   separately.

7. **Custom claims (optional):** `remedisys_healthcare_ai` may define
   `jwt_payload_hook` to embed `frontendRole` and `practitioner` into the access
   token, removing the second round-trip to `get_current_user()` on login. This
   is an optimization, not required for the cutover.

8. **The OAuth2 path is retired:** the `bruno/auth/` OAuth2 requests are replaced
   with eb_frappe_jwt requests; the unused `FRAPPE_CLIENT_ID`/`FRAPPE_CLIENT_SECRET`
   are removed from the frontend env.

## Alternatives Considered

1. **Keep Frappe OAuth2 (Phase 0 design).**
   - Pros: built-in; no new app dependency; standards-based (RFC 6749).
   - Cons: heavier setup (OAuth Client doctype, client_id/secret per
     environment); refresh handling is coarse; no first-class 2FA on the token
     endpoint; the frontend never actually adopted it. Operationally more moving
     parts than a single-tenant clinical app needs.

2. **Keep Frappe SID cookie (current frontend reality, ADR-010 §3).**
   - Pros: simplest; already working; zero new dependencies.
   - Cons: no refresh-token model (hard expiry); sid is tied to Frappe's session
     table and CSRF machinery; cannot serve a native mobile client; no 2FA or
     brute-force lockout beyond Frappe defaults on this path. Couples the
     frontend to Frappe's web-session internals.

3. **Adopt eb_frappe_jwt Bearer JWT (chosen).**
   - Pros: one credential model for web + future mobile; refresh-token rotation;
     2FA and per-user/per-IP lockout built in; matches the `Authorization: Bearer`
     contract the architecture diagrams already specify; backend change is a
     one-line `required_apps`; BFF pattern and `require_permission()` unchanged;
     the app is CI-green and uninstall-clean.
   - Cons: introduces an app dependency we maintain ourselves; HS256 is
     symmetric (single signing secret per site — acceptable for single-tenant
     clinical deployment; RS256 deferred); the frontend must implement refresh
     rotation correctly (mitigated by the plan's explicit `jwt`-callback logic).

## Consequences

### CLAUDE.md amendments

- **AMENDMENTS block** gains an ADR-011 line.
- **§3 `API pattern`** note: authentication is `eb_frappe_jwt` Bearer JWT
  (clinical data access still flows through `api/v1/<module>/api.py`; this ADR
  changes only how the caller is authenticated, not the API surface).

### Backend (`remedisys_healthcare_ai`)

- `hooks.py`: add `required_apps = ["eb_frappe_jwt"]`; optionally add
  `jwt_payload_hook`.
- `bruno/auth/`: OAuth2 requests replaced with get_token / refresh_token /
  revoke_token / verify_otp.
- `docs/SYSTEM_DESIGN.md`, `docs/WORKFLOWS.md`, `docs/API_SPEC.md`: auth sections
  updated from OAuth2 to eb_frappe_jwt.
- `marley.local`: `eb_frappe_jwt` installed; `eb_jwt_secret` set.
- **Unchanged:** `api/v1/auth/api.py` (`get_current_user`), `utils.py`
  (`require_permission`), the entire service layer, all clinical APIs.

### Frontend (`Healthcare_next_app`)

- `src/lib/auth.ts`: `authorize()` calls `get_token`; access + refresh stored in
  the NextAuth JWT; `jwt` callback refreshes on near-expiry and stores the
  rotated refresh token.
- `src/lib/api/client.ts`: send `Authorization: Bearer <access>` instead of
  `Cookie: sid=`.
- `.env`: remove `FRAPPE_CLIENT_ID` / `FRAPPE_CLIENT_SECRET`.
- `docs/AUTHENTICATION.md`, `docs/AUTH_IMPLEMENTATION.md`,
  `docs/SESSION-RECOVERY.md`: updated to the Bearer + refresh model.

### Unchanged

- ADR-003 (no core modification) — eb_frappe_jwt is a separate app; no core edits.
- ADR-010 **BFF pattern** — preserved; only the stored credential changes.
- ADR-005/006/007 — unaffected.
- All CLAUDE.md Rules 1–10.

### Re-evaluation triggers

- A second service needs to verify tokens without the signing secret → revisit
  for RS256 (eb_frappe_jwt enhancement).
- Multi-tenant key isolation becomes a requirement → per-tenant secret strategy.
- eb_frappe_jwt is deprecated or unmaintained → fall back to Frappe OAuth2.

## Verification

- `bench --site marley.local list-apps` shows `eb_frappe_jwt`.
- `POST /api/method/eb_frappe_jwt.api.get_token` with valid creds returns an
  access + refresh pair.
- `GET .../get_current_user` with `Authorization: Bearer <access>` returns the
  profile (proves `frappe.session.user` is set by eb_frappe_jwt's hook).
- Frontend login → role-based redirect → patient list loads, with the network
  tab showing `Authorization: Bearer` (no `Cookie: sid=`) on Frappe calls.
- An expired access token transparently refreshes (single-use rotation honored).
- `FRAPPE_CLIENT_ID`/`SECRET` no longer present in the frontend env.
- CLAUDE.md AMENDMENTS block contains the ADR-011 line.

## References

- ADR-010 (Next.js BFF — pattern preserved, SID clause superseded)
- ADR-003 (no core modification — unchanged)
- CLAUDE.md §3 (API pattern), §8 Phase 0 (auth foundation)
- prompts/2026-06-05-eb-frappe-jwt.md (eb_frappe_jwt design)
- prompts/2026-06-05-eb-jwt-integration.md (this integration)
- docs/AUTH_INTEGRATION_PLAN.md (file-by-file plan)
- eb_frappe_jwt repo: github.com/eBasics-Services-P-Limited/eb_frappe_jwt

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
