# ADR-040: One consolidated New Sales Invoice drawer with prescope modes and per-invoice partial payment

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted (in production) · **Context and Alternatives: RECONSTRUCTED — needs the author**
- **Date:** ~2026-08-07 (inferred from the citing patch) · **Recorded:** 2026-08-20 (retroactively)
- **Supersedes:** the separate per-surface "Pay now" navigation paths
- **Superseded by:** —

> ### ⚠️ Read this before citing
> The hygiene audit found "ADR-040" cited by 9 files — including `services/billing.py`,
> `patches.txt`, and three frontend clients — with no document. The **Decision** section below is
> reconstructed from those citations and is verifiable against the code. The **Context** and
> **Alternatives** sections are **not** reconstructible: nobody recorded why this shape was chosen
> over the alternatives, and I will not invent a rationale for a billing decision I did not make.
> **Action: the author should complete §Context and §Alternatives.** Until then, treat this as a
> faithful record of *what* was decided, not *why*.

## Context

**INCOMPLETE — to be completed by the decision's author.** What is verifiable: before this change
there were several independent "collect payment" entry points (Patient 360, the Billing screen, a
drawer "Pay now" button), which resolved to different components with different capabilities — one
of them a plainer inline card (`OutstandingInvoiceRow`) rather than the polished
`CollectPaymentDialog` used elsewhere. Partial payments could not be expressed: the flow compared
"has balance" against "fully paid" and never against the invoice total.

## Decision

Consolidate every payment-collection entry point into **one New Sales Invoice drawer** with
**prescope modes**:

1. **`patient` prescope mode** shows, in one combined view, that patient's **outstanding invoices**
   *and* their **unbilled cart**.
2. **Each outstanding invoice settles independently** — its own amount input and its own
   `useCollectPayment` call. A payment is **never merged** across invoices, which is what makes it
   possible to show several outstanding invoices side by side.
3. **Partial payment is a first-class input**: the amount defaults to the full outstanding and is
   editable downward, so `paid_amount` can legitimately mean "pay only part of this". A caller
   intending full payment is still protected from the rounding hazard `services/billing.py`
   describes (no `smallest_currency_fraction_value`, so core rounds to whole pesos before submit
   computes the real `outstanding_amount`).
4. Patient 360's payment action is **repointed** at this drawer rather than keeping its own flow.

Paired with **ADR-039** in the permission layer: any practitioner may open another practitioner's
encounter and see that patient's own Sales Invoice, which required exempting `Patient Encounter`'s
`practitioner` link from the self-scoping Healthcare Practitioner User Permission
(`patches/v0/exempt_encounter_practitioner_user_permission_20260807.py`).

## Alternatives Considered

**NOT RECORDED — to be completed by the author.** At minimum, the obvious alternatives were: keep
per-surface flows and merely fix the inconsistent component; or allow a single merged payment across
several invoices instead of independent settlement. Neither the trade-offs nor the reason for
rejecting them was written down.

## Consequences

- `CollectPaymentDialog` is the single collect-payment component; per-surface variants are retired.
- Partial-payment detection must compare `outstanding_mxn` against `invoice_total_mxn`, not merely
  test "has balance" — the latter cannot distinguish a partial payment.
- The ADR-039 permission exemption is a dependency, not an optional extra.
- **Re-evaluation trigger:** a requirement to settle several invoices in one payment would contradict
  decision point 2 and needs a superseding ADR.

## Verification

| Claim | Artefact |
|---|---|
| One consolidated drawer, prescope modes | `src/app/(clinic)/billing/invoices/new/new-invoice-client.tsx` |
| Patient 360 repointed | `src/app/(clinic)/patients/[id]/patient-chart-client.tsx:870` |
| Independent per-invoice settlement | each row's own `useCollectPayment` call, same file |
| Partial payment supported server-side | `services/billing.py:3015` |
| Permission dependency applied | `patches/v0/exempt_encounter_practitioner_user_permission_20260807.py` |

## References

- ADR-039 (`adr-039-encounter-signing-any-practitioner-with-provenance.md`)
- `services/billing.py` · `patches.txt` (ADR-039/ADR-040 note)
- `docs/audit/DOCUMENTATION_HYGIENE_AUDIT.md` §3

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Recorded retroactively. Decision reconstructed from code; Context and Alternatives left explicitly incomplete rather than invented |
