# ADR-038: Restrict encounter signing and cancelling to the assigned practitioner

**Doc status:** superseded · **Created:** 2026-07-31 by Sarvesh-SocialAngel · **Updated:** 2026-09-01 by Sarvesh-SocialAngel · **Version:** 2.0

> **Superseded by [ADR-039](adr-039-encounter-signing-any-practitioner-with-provenance.md).**
> The rule here — only the assigned practitioner may sign — is NOT the rule today.
> Any practitioner may sign, and who signed is recorded instead.
>
> Kept because the reversal is the useful part: this ADR explains why the
> restriction looked right, and ADR-039 explains what made it wrong in a clinic
> where the assigned doctor goes home. Read this only if you want that history.

- **Status:** Superseded
- **Date:** 2026-07-31
- **Supersedes:** the 2026-07-02 decision recorded in
  `_require_assigned_practitioner_or_admin` (api/v1/encounters/api.py) and
  ADR-022's "Signing/cancelling stays Doctor/Admin-only" clause
- **Superseded by:** [ADR-039](adr-039-encounter-signing-any-practitioner-with-provenance.md) — any practitioner may sign, with provenance recorded.

## Context

`complete_encounter` submits a Patient Encounter (docstatus 0 → 1);
`cancel_encounter` voids one (→ docstatus 2). Since the 2026-07-02 decision both
have been gated by `_require_assigned_practitioner_or_admin`, which allows either
the practitioner assigned to the encounter **or** any holder of
`EB_Healthcare Admin`. The frontend mirrored that with
`canSign = isAdmin || isAssignedPractitioner`.

Three facts make the admin half wrong:

1. **The note is a licensed attestation.** The signed encounter renders a
   signature block containing the assigned practitioner's name, specialty and
   Cédula Profesional (e.g. `sarvesh shahi · Urología · Céd. Prof.
   MEX-CED-394018`), plus "This encounter will be digitally signed upon
   completion." An admin submitting it produces a document attesting, under
   another clinician's licence, to findings that clinician never signed off.
   Cancelling is the mirror image: voiding a colleague's clinical record behind
   their back is equally theirs to authorise, not an operational convenience.
   NOM-024-SSA3-2010 expects the author of a clinical record entry to be
   identifiable and responsible for it; `EB_Healthcare Admin` is an operational
   role with no licence attached.

2. **It already contradicted our own permission spec.** In
   `patches/v0/eb_docperm_spec.json`, `EB_Healthcare Admin` has `submit: 0` and
   `cancel: 0` on Patient Encounter while `EB_Practitioner` has `submit: 1`. A
   pure admin was therefore already rejected by
   `require_permission("Patient Encounter", "submit")` — the role bypass only
   ever took effect for a user holding *both* roles (e.g.
   `admin@chavitos.health`, which also holds `EB_Practitioner`), in which case it
   skipped precisely the ownership check that mattered.

3. **Nothing is stranded by removing it.** `save_draft` is unaffected: an admin,
   a nurse (ADR-022) and any other practitioner can still open and write the
   draft. Only the two irreversible, attributed transitions narrow.

The one remaining admin-overridable action on an encounter is the WhatsApp
summary resend (`notifications.send_encounter_summary_whatsapp`). It neither
creates nor alters a clinical record — it re-delivers an already-signed note to
the patient — so it keeps the old gate.

## Decision

**Signing and cancelling an encounter require being the practitioner assigned to
it. There is no clinic-admin override for either.**

1. Backend helper `_require_assigned_practitioner(doc)` — the caller's linked
   Healthcare Practitioner (`Healthcare Practitioner.user_id == session user`)
   must equal `doc.practitioner`. Role membership grants nothing on its own.
2. `complete_encounter` and `cancel_encounter` both use it. The framework
   superuser `Administrator` is the single documented exemption (see
   Consequences).
3. `_require_assigned_practitioner_or_admin` is retained **unchanged** and keeps
   the `EB_Healthcare Admin` bypass, now scoped to exactly one caller:
   `send_encounter_summary_whatsapp`.
4. Frontend keeps ONE flag: `canSign` = assigned practitioner only. Everyone
   else — nurse, other practitioner, admin — gets the identical save-only
   footer: a **Save draft** button, no Sign and no Cancel, never a disabled Sign
   button (keeps the 2026-07-27 rule).
5. Someone must still be able to close a note the assigned doctor cannot sign.
   The supported route is reassignment under the practitioner who actually saw
   the patient — not signing or voiding on their behalf.

## Alternatives Considered

1. **Keep the admin override; hide the buttons only.**
   - Pros: zero backend change; no test churn; admin can still unblock a clinic
     where a doctor left a note open.
   - Cons: the endpoints stay open, so the guarantee is cosmetic — any client,
     Bruno collection or stale bundle can still submit. Leaves a licensed
     attestation forgeable by an operational role. Rejected.

2. **Assigned practitioner only for signing; admin keeps cancel.**
   - Pros: protects the attestation, which is the sharper legal risk, while
     leaving an operational escape hatch for stuck drafts.
   - Cons: an admin can still erase a colleague's clinical record without them;
     under NOM-024 the record's integrity and its authorship are the same
     concern, and two different rules for the two buttons is harder to explain to
     staff and to auditors. This was the initial implementation on 2026-07-31,
     rejected the same day.

3. **Assigned practitioner only for BOTH sign and cancel (chosen).**
   - Pros: one rule, stated in one sentence — only the clinician who saw the
     patient finalises or voids their own note; the signature block can never
     name someone who did not submit it; matches
     `eb_docperm_spec.json`'s existing `submit: 0` / `cancel: 0` for admins; the
     stricter gate lives in the API, so every client inherits it; `save_draft`
     keeps every other role productive.
   - Cons: a genuinely stuck note now needs reassignment rather than an admin
     signature or an admin void. Accepted — that friction is the point.

4. **Admin may act but the record names them as a countersigner.**
   - Pros: preserves the escape hatch with honest provenance.
   - Cons: needs a real countersignature model — extra fields, a second
     signature line on the printed note, migration of already-signed encounters,
     and a defensible legal reading of who is responsible. Disproportionate to
     the reported problem, and nobody has asked for delegated signing. Rejected
     for now; this is the shape to revisit if clinics do ask.

## Consequences

- `EB_Healthcare Admin` loses `complete_encounter` and `cancel_encounter`.
  Admins keep read, `save_draft` (draft edit), and the WhatsApp summary resend.
- A multi-role user (admin + practitioner) can still sign and cancel, but only
  their **own** encounters — the ownership check applies to everyone equally.
- The framework superuser `Administrator` remains exempt in the API. This is
  deliberate: Frappe's `Administrator` bypasses permission checks throughout and
  can submit or cancel the doctype directly from Desk or `bench console`, so a
  check there would block nothing while breaking the test harness and seed
  scripts, which run as `Administrator` by design (`FrappeTestCase`).
  `Administrator` is not an assignable clinic account, and the UI offers it no
  Sign or Cancel button either (no linked Healthcare Practitioner ⇒ `canSign`
  is false).
- ADR-022's summary line "Signing/cancelling stays Doctor/Admin-only" now reads:
  signing and cancelling are assigned-Doctor-only.
- Files: `api/v1/encounters/api.py`,
  `tests/encounters/test_encounters.py`,
  `Healthcare_next_app/src/app/(clinic)/encounters/[id]/page.tsx`,
  `Healthcare_next_app/src/components/narzim/encounter/encounter-screen.tsx`.
- Re-evaluation trigger: a clinic reporting notes stranded unsigned because the
  authoring practitioner is unavailable (long leave, departure). That is the
  signal to design reassignment or counter-signing (alternative 4) rather than to
  restore a blanket admin override.

## Verification

- `TestAdminCannotSignOrCancel` in
  `remedisys_healthcare_ai/tests/encounters/test_encounters.py`: an
  `EB_Healthcare Admin` + `EB_Practitioner` user who is not the assigned
  practitioner gets **403** from both `complete_encounter` and
  `cancel_encounter` (asserting on the gate's own message, not just the code, so
  a DocPerm rejection can't pass for it) and **200** from `save_draft`; the
  assigned practitioner still signs and cancels successfully.
- Manual, `marley.local`: as `admin@chavitos.health` (linked to
  `HLC-PRAC-2026-00019`) open an encounter assigned to `HLC-PRAC-2026-00001` —
  the footer shows only **Save draft**.

## References

- Constitution §4 Rule 6 (physician in control), §11 (no auto-finalizing
  anything clinical without physician approval)
- ADR-022 — nurse encounter draft write
- ADR-018 — multi-jurisdiction compliance (NOM-024-SSA3-2010 for `mx`)
- `patches/v0/eb_docperm_spec.json` — `EB_Healthcare Admin.submit = 0`,
  `.cancel = 0` on Patient Encounter

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Marked superseded by ADR-039. It had said `Superseded by: —` while ADR-039 declared it superseded, so two Accepted ADRs gave contradictory signing rules |
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
