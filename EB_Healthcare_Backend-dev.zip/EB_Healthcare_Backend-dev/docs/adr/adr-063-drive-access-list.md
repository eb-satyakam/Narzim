# ADR-063: Sharing a Drive entry is a set, not a stream of grants — and changing it needs write

**Doc status:** living · **Created:** 2026-09-09 by Anant (AI-assisted) · **Updated:** 2026-09-09 by Anant (AI-assisted) · **Version:** 1.1

- **Status:** **Accepted** — decided by Anant, 2026-09-09
- **Date:** 2026-09-09
- **Supersedes:** — (extends [ADR-061](adr-061-drive-to-patient-chart-move.md)'s module)
- **Superseded by:** —

## Context

Reported 2026-09-09: the Share dialog's search box does nothing. It was worse than that. The
dialog was a shell — the input was `<input placeholder=… />` with no `value`, no `onChange` and no
results list; "People with access" was hardcoded to the owner; and the "General access" dropdown
wrote to local React state that **Done** discarded.

Underneath, sharing was **write-only**:

- `services/drive.py::share()` grants and can never revoke.
- Nothing could **read** the current access list, so no UI could show who actually had access.

So a picker built on `share()` could add a colleague but not remove one, and could never display
the truth. Both halves exist upstream and were unused: `drive.api.permissions.get_shared_with_list`
and `DriveFile.unshare`.

Two further facts shaped the decision:

1. **Drive gives every team member `share: 1`** (`api/permissions.py::get_user_access` 72-81). Left
   alone, any colleague could widen — or silently narrow — access to someone else's clinical document.
2. **Drive gives every team member `read: 1` on every file in the team**, with no permission row.
   Verified: a file with zero `Drive Permission` rows returned `read = True` for four team members.

## Decision

Add two operations alongside `share()`, which is left unchanged:

- **`get_access(id)`** → `{owner, users[], with_team}` — the read half.
- **`set_access(id, users, level, with_team)`** → reconcile to exactly that list: grant what is new,
  revoke what was dropped, toggle team access, never touch the owner.

**`set_access` requires `write` permission**, not Drive's `share`. Changing who can see patient data
is an owner-level act, and `write` is the same gate Drive itself requires to delete the file
(`api/files.py:773`). It also matches the UI, which only offers the picker to the owner.

**Public sharing remains unreachable.** The only widening is `with_team`; every named recipient must
clear the `_SHAREABLE_ROLES` allowlist, which is what stops Drive's `invite_users(user, auto=True)`
creating an account for a stranger.

## Options considered

| Approach | Pros | Cons |
|---|---|---|
| **A.** Keep `share()` additive; add a separate `unshare(user)` the UI calls per removal | Smallest backend change | The UI must diff the list itself and issue N calls; a partial failure leaves access half-applied with no way to tell what stuck |
| **B.** `get_access` + `set_access` reconcile **(chosen)** | One call, one end state; the picker is a statement of intent, which is what a checklist already is; revocation is not an afterthought | A new endpoint; "set" semantics must never touch the owner |
| **C.** Change `share()` itself to replace rather than append | No new endpoint | Silently changes the meaning of a live endpoint the document detail page already calls — a caller that sends one name would revoke everyone else |
| **D.** Expose Drive's `get_shared_with_list` / `unshare` straight to the browser | No new code at all | Breaks the rule that the browser never reaches a `drive.*` method; skips the staff allowlist and writes no audit; `get_shared_with_list` prepends the owner into the same array, which every caller then has to special-case |

**Why each rejected option loses.** **A** loses on atomicity: removing two people and adding one is
three requests, and the second failing leaves an access list nobody intended. **C** loses because it
is a silent semantic change to an endpoint with an existing caller — the kind of change that removes
someone's access months later and cannot be traced to a commit. **D** loses on the boundary this
whole module exists to hold ([ADR-061](adr-061-drive-to-patient-chart-move.md) context, and
`services/drive.py`'s docstring): Drive's own methods carry no allowlist and no audit.

## Consequences

**Denial rows are not access.** Removing team access can make Drive insert a `Drive Permission` row
with `read = 0` — an explicit denial written when an ancestor folder still shares the entry
(`DriveFile.unshare`, the `$GENERAL` branch). `get_access` filters on `read = 1`, or it would report
team access precisely because it had just been removed. Pinned by
`test_a_team_denial_row_is_not_reported_as_access`.

**The owner is reported separately** and excluded from `users`, so no UI can offer a remove button
for the one person whose access cannot be removed.

**"Restricted" is honest now, but limited.** Because of fact 2 above, sharing does not gate reading
among staff. The UI wording was corrected rather than the model: "Only people with access can open
with the link" → "Not shared with anyone outside the clinic team", and the "Anyone with the link —
anyone on the internet can view" option was **removed** (the backend always refused it; PHI-5 forbids
saying in the UI what the code does not do). The underlying model is recorded as an open decision in
[`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md) and pinned by
`test_a_team_member_can_read_without_any_grant`, which fails if it ever changes.

**One dialog serves files and folders.** A folder is a `Drive File` row, so the same access list
serves it; Drive resolves permissions up the tree, so a grant on a folder reaches its contents
(pinned by `test_sharing_a_folder_reaches_what_is_inside_it`). The UI had kept a separate
`FolderShareDialog` stub showing "folder sharing is not available yet", which survived the first
pass of this work because it looked like a distinct unbuilt feature. It was not — it was the same
feature on the same doctype, and the split was the only thing making it look unbuildable. Both call
sites now render one `EntityShareDialog`.

**The staff list is inline, not behind a disclosure.** The first implementation reused the detail
page's `SharePicker`, which keeps its list behind a Private → Shared toggle and then a "Select
users" popover. Since 27 of 28 Drive entries have no grants at all, it opened on the toggle alone
and still showed no list — the same complaint it was meant to fix. `SharePicker` is unchanged and
still used on `/documents/[id]`, where it sits inside a form and collapsing is appropriate.

**`share()` is retained unchanged** for the document detail page's existing save path. Two endpoints
with different semantics is a cost; the alternative was changing a live endpoint's meaning under a
caller (option C).

**Verified 2026-09-09** on `remedisys.localhost`: 10 new tests (46 in the Drive module, all passing),
plus an API-layer run confirming `users` parses from a JSON string, the envelope shape, and that team
access toggles both ways. Extended 2026-09-09 to folders: 12 tests in that class, 48 in the module.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-09 | Anant (AI-assisted) | One dialog for files and folders; inline staff list instead of the reused collapsed picker |
| 1.0 | 2026-09-09 | Anant (AI-assisted) | Initial version |
