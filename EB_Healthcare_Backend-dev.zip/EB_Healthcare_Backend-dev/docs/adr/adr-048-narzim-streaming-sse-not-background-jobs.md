# ADR-048: AI chat replies stream over SSE from the web worker, not via background jobs

**Doc status:** living · **Created:** 2026-08-27 by Ashutosh (AI-assisted) · **Updated:** 2026-08-27 by Ashutosh (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — implemented 2026-08-27.
- **Date:** 2026-08-27
- **Supersedes:** —
- **Superseded by:** —
- **Full rationale:** [`docs/RESEARCH_NARZIM_STREAMING.md`](../RESEARCH_NARZIM_STREAMING.md) — a
  frozen `record` holding the measurements, the four-buffer analysis, and the five traps. This ADR
  records the *decision*.

## Context

A NarzimGPT answer appeared all at once after a long `Thinking…` pause. Measured on `gpt-5-mini`
with the parameters the app actually sends: **4.75s to the first token, 45.90s in total** for a
long answer. The user saw nothing for all 45.90s.

Four buffers sat in series — provider call, provider adapter, Frappe's JSON response, and the BFF's
`await res.json()`. Removing any one alone changes nothing.

Two facts made the decision rather than opinion:

1. **Frappe can stream.** `frappe/handler.py:57` and `frappe/api/__init__.py:64` both pass a
   returned `werkzeug.Response` through untouched, and the `ClosingIterator` in
   `frappe/app.py::after_response_wrapper` defers `frappe.destroy` until the body is consumed —
   verified by direct test, not inferred: `iterator-returned → yield-0 → yield-1 → yield-2 →
   frappe.destroy`.
2. **`background_workers: 1`** on this bench. A job-based design would give one concurrent stream
   site-wide, queued behind notification and email jobs.

## Decision

The streaming reply is generated **inside the web request** and delivered as `text/event-stream`,
end to end: Frappe returns a streaming `Response`; the BFF forwards `upstream.body` untouched; the
client reads it with a fetch reader.

`send_message` (blocking) is kept working and unchanged. It is the fallback, and the vision path
still uses it.

### Consequences

- **A gunicorn worker is held for the whole generation** — up to ~46s. Affordable at
  `gunicorn_workers: 25` and single-digit concurrent assistant users; it is the number to watch if
  NarzimGPT use grows. This is the cost the decision buys with.
- **Errors after the first token cannot use a status code.** The 200 and headers are already sent,
  so they arrive as a terminal SSE `error` frame. The generator is therefore **primed before the
  Response is built**, so everything that can legitimately reject a request — bad thread,
  unsupported file, provider 401/429 — still raises inside the normal request cycle with a real
  status.
- **Nothing commits on our behalf.** `sync_database()` runs when the Response is *returned*, before
  the body is pulled, so the generator commits explicitly. Without that, replies stream perfectly
  and are never saved.
- **`X-Accel-Buffering: no` is required**, on both the Frappe response and the BFF response. nginx
  buffers proxied responses by default, so this works locally (`bench serve`, no nginx) and would
  be silently broken in production without it.

## Alternatives rejected

| Option | Why not |
|---|---|
| Background job + socket.io chunks | `background_workers: 1` → one concurrent stream site-wide, queued behind notifications. Also four hops per delta at 2,661 measured deltas, needing sequence numbers, room auth and replay. |
| Client-side typewriter over the blocking call | Does not reduce time-to-first-token at all. The user still waits 46s, then watches a fast animation — it misrepresents progress rather than improving it. |
| Chunked plain text, no SSE framing | No channel for `message_name`, usage, cost, or a mid-stream error. Usage accounting (`get_usage_summary`) depends on all of them. |

## Two behaviours decided here, not obvious from the code

**A stopped stream keeps its partial answer.** Pressing Stop closes the generator; the text that
arrived was generated, paid for, and already read by the user, so it is persisted. The linked
`AI Prompt Log` records `error = "client stopped the stream"` so partial rows stay distinguishable
in the audit trail.

**Cost and usage are recorded identically on both paths.** The streaming provider call sets
`stream_options.include_usage`, without which OpenAI sends no usage at all when streaming and every
streamed reply would silently record `tokens_out = 0` and `cost_usd = 0`. The terminal `done` event
returns the same keys the blocking call returns, so the two cannot drift structurally.

## Scope

**In:**

| Surface | Endpoint | Status |
|---|---|---|
| NarzimGPT assistant | `api/v1/narzim_assistant/api.py::send_message_stream` | streaming (2026-08-27) |
| Patient-intelligence chat, Lab Test tab ("Zoomo") | `api/ai/lab_result_summary.py::ask_lab_question_stream` | streaming (2026-08-27) |
| Report chat during review | `ask_report_question` | blocking — primitive ready |
| Saved report chat (ADR-044) | `ask_saved_report_question` | blocking — primitive ready |

Both provider adapters implement the streaming primitives, and the two remaining report chats share
the same seam (`_answer_with_retry` → `_stream_answer_with_retry`), so switching them over is
frontend work rather than backend design.

**Out:** the encounter copilot (`ask_copilot_agent`) — streaming a tool-calling loop means
reassembling partial `tool_calls` fragments across deltas, a different problem. Also out: markdown
rendering of replies, and the answer-length cap discussed in the research doc §3.1.

### What the lab chat added to the decision

Two constraints that NarzimGPT did not have:

1. **Retry must become conditional.** The lab chats retry a transient provider failure
   (timeout / 429 / 5xx) with backoff. Streaming can only retry *while no token has been emitted* —
   after that, restarting would splice two half-answers together on the clinician's screen.
   `_stream_answer_with_retry` therefore tracks whether any delta has been yielded and re-raises
   instead of retrying once one has.

2. **The gain is proportional to answer length, and these answers are short.** The lab chats cap at
   700 tokens against NarzimGPT's ~3,350, so measured time-to-first-token improvement is **24–42%**,
   not the 81–90% NarzimGPT sees. Most of a short answer's wait is the model thinking before it
   writes, which streaming cannot remove. Still worth doing — the panel shows progress instead of
   freezing — but it is a smaller change and should not be described as the same win.

**PHI is unchanged.** The lab chats send the patient's clinical record to the provider. Streaming
alters the transport only: same content, same provider, same audit row (content-free, Rule 10).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-27 | Ashutosh (AI-assisted) | Extended to the Lab Test patient-intelligence chat; recorded the conditional-retry constraint and the measured (smaller) gain on short answers |
| 1.0 | 2026-08-27 | Ashutosh (AI-assisted) | Initial decision, taken with the implementation |
