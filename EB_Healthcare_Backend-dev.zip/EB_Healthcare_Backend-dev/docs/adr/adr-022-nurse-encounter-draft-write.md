# ADR-022: Nurse can save a full Patient Encounter draft; signing stays Doctor-only

**Doc status:** living · **Created:** 2026-07-07 by Sarvesh-SocialAngel · **Updated:** 2026-07-07 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-07
- **Supersedes:** `docs/qa/NURSE_ROLE.md` §2/§4/§5's "Patient Encounter is read-only for Nurse" policy. No prior ADR superseded.
- **Superseded by:** —

## Context

Before this change, Patient Encounter was Doctor-only for writing, both by policy
(`docs/qa/NURSE_ROLE.md`: "Start or write a consultation (encounter) — Doctor-only
clinical authority", "Add diagnoses or prescriptions — Doctor-only") and by
enforcement:

- DocPerm (`remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json`, "Patient
  Encounter" block): `EB_Nurse` had `create=1, read=1, write=0, submit=0`. She
  could trigger `start_encounter`/`create_encounter` (the "Move to Practitioner"
  hand-off creates the draft shell and auto-attaches her vitals via
  `_link_vitals_to_encounter`), but any subsequent `save_draft` call was rejected
  outright by `require_permission("Patient Encounter", "write", doc=encounter)`
  (`api/v1/encounters/api.py`).
- Frontend (`Healthcare_next_app`): the "Practitioner Room" button's navigation
  is gated by `caps.startEncounter` (`src/lib/narzim/roles.ts`), `false` for
  `nurse` — she never reached the SOAP screen at all, only a hand-off toast.

Product wants first-pass clinical documentation (chief complaint, HPI, plan,
diagnoses, prescriptions, labs, procedures, therapies — the same fields
`save_draft` already accepts) to start with the nurse, not wait on the doctor to
open the chart. **Signing/submitting a Patient Encounter must remain
Doctor/Admin-only** — this is Constitution §4 Rule 6's spirit applied to human
documentation, not just AI output: a nurse's entries are a draft contribution,
never a final clinical record until a physician reviews and submits.

Critically, that submit-only boundary was **already independently enforced**
before this ADR, by `_require_assigned_practitioner_or_admin()`
(`api/v1/encounters/api.py:1374`), which gates both `complete_encounter` and
`cancel_encounter` on `EB_Healthcare Admin` or the assigned `EB_Practitioner`.
Verified live (this session, `marley.local`): a user holding only `EB_Nurse`
gets `403 PermissionError` from both `complete_encounter` and `cancel_encounter`
regardless of the DocPerm change below, because that function checks
`frappe.get_roles()` directly and never consults the write DocPerm at all. This
means the only thing standing between "nurse can save a draft" and today's
world was a single DocPerm flag — the safety boundary the product needs was
already built.

## Decision

Grant `EB_Nurse` **write** access to Patient Encounter (`create`/`read` were
already `1`); `submit` stays `0`. Concretely:

1. `eb_docperm_spec.json`: `EB_Nurse` → Patient Encounter `write: 0 → 1`.
   Reapplied via a new idempotent patch,
   `patches/v0/reapply_eb_role_permissions_20260707.py`, following the existing
   `rebuild_eb_role_permissions.execute()` pattern.
2. No change to `_require_assigned_practitioner_or_admin` — it already blocks a
   nurse from `complete_encounter`/`cancel_encounter`.
3. Frontend: a nurse gets access to the same SOAP screen a doctor uses
   (`EncounterScreen`), with a "Save draft" action instead of "Sign & close
   encounter", and no Cancel/void action (that stays behind the same backend
   gate as signing).
4. No new row-level (User Permission) scoping is added: any `EB_Nurse` user in
   a company can write to any Draft encounter in that company — the same shape
   as every other EB_ role grant today (none of them are scoped by User
   Permission except the practitioner-to-own-encounter one from ADR-018, which
   only applies to users holding `EB_Practitioner`).

## Alternatives Considered

1. **Deny nurse write entirely (status quo).**
   - Pros: zero change, zero new risk surface.
   - Cons: documentation waits on the doctor unnecessarily; the nurse
     hand-off flow already creates the draft and attaches vitals — leaving the
     rest of the note blank until the doctor opens the chart is the actual
     workflow complaint driving this ADR.

2. **A separate "Nurse Note" shadow doctype, merged into the encounter at
   sign time, instead of writing into Patient Encounter directly.**
   - Pros: no permission change on the core clinical doctype at all;
     nurse-authored content is structurally distinct from doctor-authored
     content.
   - Cons: duplicates the SOAP schema (`chief_complaint`, `hpi`, `plan`,
     `diagnosis`, `drug_prescription`, `lab_test_prescription`,
     `procedure_prescription`, `therapies`) in a second doctype; needs a merge
     step at `complete_encounter` time with its own conflict rules; solves an
     attribution problem that Frappe's Version log already solves for free
     (every `doc.save()` is attributed to `frappe.session.user` regardless of
     role, so "who wrote what" is already auditable without a shadow table).

3. **Grant write via DocPerm (chosen).**
   - Pros: one-line permission change, reuses the exact `save_draft` code path
     a doctor already uses (no new endpoint), reuses the already-built
     submit/cancel boundary (`_require_assigned_practitioner_or_admin`) with
     zero new backend code, matches how every other EB_ role's Patient
     Encounter access is already granted (Role Permissions Manager, not custom
     Python gates).
   - Cons: any nurse in the company can edit any draft in the company (no
     per-practitioner scoping) — accepted below as matching the existing
     shape of role-level grants, not a new gap this decision introduces.

## Consequences

- `docs/qa/NURSE_ROLE.md` §2 (encounter row), §4 (blocked-actions list), §5
  (permission table) are updated to reflect `R C W` instead of `R`, and to
  distinguish "can draft" from "can sign" instead of a blanket "Doctor-only."
- Frontend: `src/lib/narzim/roles.ts` gains a `canEditEncounterDraft`
  capability; `appointments-tab.tsx`'s `canOpenEncounter` widens to include
  it; `encounters/[id]/page.tsx` computes and passes a `canSign` prop into
  `EncounterScreen`, which swaps its Sign/Cancel actions for a Save-draft
  action when `canSign` is false.
- Dashboard Mission Control (`mission-control-client.tsx`) has an independent
  second "Practitioner Room" surface, initially left doctor-only pending a
  follow-up decision. That follow-up landed the same day: `ROOM_ROLES.practitioner_room`
  now includes `"nurse"` and `permissions-store.ts`'s `ACTION_DEFAULTS.nurse.startencounter`
  is `true`, so the queue's "Open Encounter" action is reachable from there too.
  No new logic was needed for the sign boundary — `canSign` in `EncounterScreen`
  is computed from the user's actual roles regardless of entry point, so a nurse
  reaching the same `/encounters/[id]` page via this surface still only gets
  "Save draft," never "Sign & close."
- Re-evaluation trigger: if a clinic reports a nurse editing another
  practitioner's in-progress note in a way that causes confusion or a
  documented incident, revisit the "no row-level scoping" choice in
  Alternative 3 and consider a User Permission or company/department-level
  restriction.

## Verification

- Live on `marley.local` (this session): `frappe.has_permission("Patient
  Encounter", "write", user=<EB_Nurse-only user>)` → `True`;
  `frappe.has_permission("Patient Encounter", "submit", ...)` → `False`.
- `remedisys_healthcare_ai/tests/encounters/test_encounters.py`,
  `TestNurseDraftWrite`: `test_nurse_has_write_permission`,
  `test_nurse_can_save_draft` (200, draft content persisted, docstatus
  unchanged), `test_nurse_cannot_complete` / `test_nurse_cannot_cancel` (403).
  All passing as of this ADR.
- `EB_Healthcare Admin`'s permissions were diffed against the spec across all
  62 doctype rows before and after applying the patch — zero mismatches.

## References

- Constitution §4 Rule 1 (no core modification — enforced via DocPerm +
  service layer, not a core edit), Rule 6 (physician-in-control, applied here
  to human documentation authority), §9 (architectural decisions require an
  ADR).
- `docs/qa/NURSE_ROLE.md` (superseded sections).
- ADR-018 (`practitioner-appointment-visibility-and-coverage.md`) — the only
  existing row-level (User Permission) scoping on this doctype, unaffected by
  this change since it only applies to `EB_Practitioner` users.
- `api/v1/encounters/api.py`: `save_draft`, `_require_assigned_practitioner_or_admin`,
  `complete_encounter`, `cancel_encounter`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-07 | Sarvesh | Initial version (header backfilled from git history) |
