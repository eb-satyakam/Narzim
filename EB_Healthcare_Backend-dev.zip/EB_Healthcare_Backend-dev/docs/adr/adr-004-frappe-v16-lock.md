# ADR-004: Lock to Frappe v16 (not v15)

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-05-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-05-13
- **Supersedes:** Section 3 of the Engineering Constitution (original lock: Frappe v15)
- **Superseded by:** —

## Context

The Engineering Constitution (Section 3) originally locked the EHR base to
"ERPNext Healthcare on Frappe v15". When the `remedisys_healthcare_ai` app was
installed onto the existing `marley-bench` development bench on 2026-05-13,
`bench list-apps` reported:

| App | Version | Branch |
|---|---|---|
| frappe | 16.17.5 | version-16 |
| erpnext | 16.17.0 | version-16 |
| healthcare | 16.0.8 | version-16 |
| payments | 0.0.1 | version-16 |
| builder | 1.0.0-dev | develop |
| telephony | 0.0.1 | develop |
| clefincode_chat | 1.3.902 | develop |

The bench is already on the v16 line. The other installed apps (ERPNext,
Healthcare, payments) all track `version-16` and depend on Frappe v16 APIs.

## Decision

Lock Remedisys to **Frappe v16 / ERPNext v16 / ERPNext Healthcare v16**. Update
Section 3 of the Engineering Constitution accordingly. All new code targets
v16 APIs.

## Alternatives Considered

1. **Downgrade the bench to v15.**
   - Pros: matches the original constitution; v15 has been in production
     longer at other Frappe shops.
   - Cons: requires reinstalling Frappe, ERPNext, Healthcare, payments,
     builder, telephony, clefincode_chat at compatible v15 versions; some
     installed apps (notably `builder` on `develop` and `healthcare` 16.0.8)
     have no clean v15 equivalent matching current data; risk of data
     migration loss on the existing site `marley.local`; multi-day reset for
     zero clinical benefit.

2. **Lock to v16 (chosen).**
   - Pros: zero migration cost; uses the bench as-is; v16 is the active
     mainline; Healthcare 16.0.8 is the supported release line; aligned with
     payments, builder, telephony branches already on `version-16` /
     `develop` tracking v16.
   - Cons: v16 is newer; surface area for upstream breaking changes is higher
     than v15. Mitigation: pin minor versions in deployment manifests, watch
     Frappe v16 release notes.

3. **Multi-version support.**
   - Rejected. Adds compatibility shims and CI matrix for no near-term
     benefit. Can be revisited if a customer demands v15.

## Consequences

- Section 3 lock table updated: `EHR base = ERPNext Healthcare on Frappe v16`.
- Section 5 (Tech Stack) updated: `Frappe Framework v16`.
- Sections 1, 2 hero text updated: "Frappe v15" → "Frappe v16".
- All future ADRs, design notes, and code references say v16.
- Any v15-specific guidance in past prompts (e.g., the original constitution
  text) is superseded by this ADR.

## Verification

- `bench --site marley.local list-apps` shows v16 line for frappe, erpnext,
  healthcare.
- `remedisys_healthcare_ai 0.0.1` installed cleanly against this stack on
  2026-05-13.

## References

- Engineering Constitution Section 3 (Locked Assumptions)
- Engineering Constitution Section 5 (Tech Stack)
- ADR-003 (no core modification) — unaffected; rule applies equally to v16.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
