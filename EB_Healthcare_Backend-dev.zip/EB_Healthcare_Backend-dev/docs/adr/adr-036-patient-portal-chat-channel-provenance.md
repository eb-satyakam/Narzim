# ADR-036: Tag Channel Provenance on Patient Portal Chat Messages, Both Directions

**Doc status:** superseded · **Created:** 2026-07-30 by Divyanshu · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Superseded
- **Date:** 2026-07-29
- **Supersedes:** —
- **Superseded by:** ADR-037

> **2026-07-29 — Superseded.** The product decision changed: Portal Chat and
> WhatsApp Chat are now two fully separate conversations with their own EB
> Healthcare Frontend tab each, not one merged thread distinguished by a
> `channel` tag. See ADR-037. This document is kept for the historical
> reasoning (the 24-hour-window bug this was originally meant to fix is
> still real background context — ADR-037's Context section carries the
> parts of it that still apply).

## Context

The Patient Portal (`EB_Healthcare_PatientPortal`, Next.js, port 3003) has a
chat screen (`src/app/(portal)/chat/page.tsx`) that mirrors the clinic's
WhatsApp conversation with the logged-in patient. The backend for it is
`remedisys_healthcare_ai/api/v1/patient_portal/chat.py`.

When a patient sends a message from the portal, `send_my_chat_message`
inserts a `WhatsApp Message` record directly:

```python
doc = frappe.get_doc({
    "doctype": "WhatsApp Message",
    "type": "Incoming",
    "from": conv.patient_phone,
    "message": message,
    "content_type": "text",
    "whatsapp_account": conv.whatsapp_account,
})
doc.insert(ignore_permissions=True)
```

No Meta Graph API call happens — this was an intentional, documented choice
(see the module docstring, `chat.py:10-20`): Meta's Cloud API is
one-directional for this purpose, a business number can send *to* a patient,
but there is no API for "receive a message on behalf of a patient." A real
WhatsApp round-trip for a portal-originated message isn't possible even in
principle.

Because the insert goes through the normal `after_insert` hook
(`hooks.py:254-257` → `on_whatsapp_message_created`,
`integrations/whatsapp/chat_api.py:42-124`) — the same hook a *real* inbound
WhatsApp webhook message triggers — a portal message threads onto the same
`WhatsApp Conversation`, bumps `unread_count`, and updates the preview
identically to a genuine WhatsApp reply. That part is working as designed and
is the right behavior: staff should see one thread per patient regardless of
which channel the patient used.

**The problem:** the same hook also extends `window_expires_at` /
`window_open` on the `WhatsApp Conversation` doctype
(`remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/whatsapp_conversation/whatsapp_conversation.json`)
— the local mirror of Meta's 24-hour customer-service window. That window is
enforced **server-side by Meta**, based on when the patient's message
actually arrived over the WhatsApp network. A portal-only message cannot
truthfully reopen it, but today our system treats it as if it does.

Concrete failure mode: a patient's last real WhatsApp message was more than
24 hours ago. They then send a message through the portal. Our
`window_open` flag flips to true. The EB Healthcare Frontend (staff app)
trusts that flag verbatim —
`EB_Healthcare_Frontend/src/components/narzim/messages/conversation-thread.tsx:87`:

```ts
const canReply = sessionIsOpen(conversation.session_expires_at)
```

— so staff sees a normal reply box (not "Session closed"), types a free-text
reply, and it's sent via the real WhatsApp Graph API
(`send_chat_message`). Meta rejects it (error 131047, re-engagement message
outside window) because nothing ever actually reopened the window on Meta's
side. This is a silent, confusing failure traceable to one hook not
distinguishing which channel produced the triggering message.

There is also no field recording *how* a given `WhatsApp Message` row
actually arrived — over Meta's encrypted WhatsApp network, or via an
authenticated portal session. That is a provenance gap worth closing on its
own terms: these are two different channels with different trust and
compliance characteristics (relevant under ADR-018's jurisdiction-pluggable
compliance model), and today they are indistinguishable in the data.

**The same asymmetry exists in the outbound direction, and needs the same
fix.** Today, every staff reply goes through exactly one path,
`send_chat_message` (`chat_api.py:301-337`), which always:

```python
account = frappe.get_doc("WhatsApp Account", conv.whatsapp_account)
resp = _send_free_text(account, conv.patient_phone, body.strip())
```

`account` holds the Meta access token — every staff reply requires it and
makes a real Graph API call, whether or not the patient is even a portal
user. That's correct when the goal is "reach the patient on WhatsApp," but
it means: (a) it's blocked entirely once the 24h window is closed (staff
must fall back to a paid template), and (b) there's no way to just leave a
reply for a portal-using patient without spending a Meta template send. The
`whatsapp_account` link is only *metadata* (which clinic this belongs to,
used for `to_phone` lookup and multi-clinic routing) — the credential is
actually spent only inside `_send_free_text`'s HTTP call. A reply that never
calls `_send_free_text` never touches the key, regardless of whether
`whatsapp_account` is still recorded on the row for reference.

An alternative was considered and rejected: routing portal messages through
the existing internal Team Chat system instead
(`Chat Thread` / `Chat Message`, ADR-015,
`remedisys_healthcare_ai/api/v1/messages/api.py`). That system is
deliberately staff-only by design — every endpoint calls
`_require_chat_role()`, and the module docstring states outright:
*"Patient-only users hold none of these... Patient/WhatsApp chat is a
separate system... this module never touches it."* Retrofitting patient
access would unpick an intentional access boundary (membership, contacts
list, role gates all assume staff-to-staff), and would still leave staff
checking two separate surfaces per patient — the WhatsApp inbox and a Team
Chat thread — which reintroduces the exact fragmentation the unified
conversation model exists to avoid.

## Decision

Add a `channel` tag to `WhatsApp Message` distinguishing `WhatsApp` from
`Portal`, and make only real WhatsApp messages control WhatsApp-specific
state (the session window). The unified per-patient thread stays exactly as
it is today.

1. Add a custom field `channel` (Select: `WhatsApp` / `Portal`, default
   `WhatsApp`) to `WhatsApp Message` via the package-level
   `remedisys_healthcare_ai/fixtures/custom_field.json`. `WhatsApp Message`
   is a vendor doctype owned by the `frappe_whatsapp` app — per Rule 1
   (upgrade-safe), it is extended with a custom field, never edited
   directly.
2. `send_my_chat_message` (`patient_portal/chat.py`) sets
   `channel = "Portal"` on insert.
3. The real inbound webhook path
   (`integrations/whatsapp/webhook.py`) leaves `channel` at its default,
   `WhatsApp` — no change needed there.
4. `on_whatsapp_message_created` (`integrations/whatsapp/chat_api.py`) only
   extends `window_expires_at` / `window_open` when the triggering message's
   `channel == "WhatsApp"`. Portal messages still thread onto the
   conversation, still bump `unread_count`, still update the preview — they
   just don't touch the WhatsApp session window.
5. Backfill existing rows: a migration patch sets `channel = "WhatsApp"` on
   every pre-existing `WhatsApp Message` (accurate, since the portal channel
   did not exist before this ADR), registered in `patches.txt`.
6. The staff-facing message formatter in `chat_api.py` (used by
   `list_conversations` / `get_conversation`) includes `channel` in its
   response per message.
7. EB Healthcare Frontend (staff app): add `channel` to the `WaMessage` type
   (`src/hooks/use-whatsapp.ts`) and render a small "via Portal" / "via
   WhatsApp" label per message in
   `src/components/narzim/messages/message-bubble.tsx`. No change is needed
   to `conversation-thread.tsx`'s `canReply` / `sessionIsOpen()` gating — it
   already reads `session_expires_at` correctly; it will simply start
   receiving a trustworthy value.
8. Patient Portal app: no change required. It never reads or depends on
   `channel`.
9. Add a new whitelisted method, `send_portal_reply(conversation, body)`, in
   `chat_api.py`, for staff replies that should land only in the portal:
   - Same permission gate as today (`_require_whatsapp_role()`), same
     conversation/company checks as `send_chat_message`.
   - No `_send_free_text` call — the Meta Graph API is never invoked, so no
     WhatsApp key is spent.
   - Inserts via `_log_outbound_message(conv.name, conv.whatsapp_account,
     "text", body, channel="Portal")` — `whatsapp_account` is still recorded
     for reference/routing (which clinic this belongs to), but that alone
     does not call Meta; only `_send_free_text` does, and this path never
     calls it.
   - No 24-hour-window check — the whole point of this path is that it
     works even when the WhatsApp window is closed, since it doesn't touch
     WhatsApp at all.
   - The message shows up in the shared conversation thread like any other
     message; the patient sees it next time they open or refresh the
     portal chat. It does **not** produce a WhatsApp notification, since it
     was never sent over WhatsApp.
10. `send_chat_message` (existing, real WhatsApp send) is unchanged —
    still requires `conv.whatsapp_account`, still calls `_send_free_text`,
    still enforced against the 24-hour window, still logs with
    `channel = "WhatsApp"` (via `_log_outbound_message`'s default).
11. EB Healthcare Frontend: `conversation-thread.tsx` gets a second action
    alongside the existing reply box. Concretely: when
    `sessionIsOpen(...)` is `false` (window closed), the reply box currently
    forces the template picker only — it now also offers "Reply in Portal"
    (calls the new `send_portal_reply` endpoint) as a free alternative,
    for patients known to use the portal. When the window is open, behavior
    is unchanged — the default send stays a real WhatsApp free-text
    reply, since that reaches the patient immediately either way.

## Alternatives Considered

1. **Reuse the internal Team Chat system (`Chat Thread`/`Chat Message`,
   ADR-015) for portal messages.**
   - Pros: reuses existing generic thread/participant infrastructure;
     patients do have a real Frappe `User` record, so could technically be
     added as participants.
   - Cons: that system's access model (`_require_chat_role`, staff-only
     contacts list) is deliberately built to exclude patients; retrofitting
     it means unpicking an intentional boundary, not just adding a role.
     Staff would end up checking two separate inboxes per patient (WhatsApp
     + Team Chat), reintroducing the fragmentation the unified thread
     avoids.

2. **Build a brand-new, fully separate "Portal Message" doctype.**
   - Pros: no provenance ambiguity at all; zero risk of touching
     `WhatsApp Message`/`WhatsApp Conversation` semantics.
   - Cons: duplicates conversation/unread-count/preview machinery
     `WhatsApp Conversation` already provides; still fragments the staff
     view into two surfaces per patient; more code to build and maintain
     for no benefit over tagging.

3. **Add a `channel` field to the existing `WhatsApp Message` /
   `WhatsApp Conversation` model and gate WhatsApp-specific logic on it
   (chosen).**
   - Pros: minimal change (one custom field, a few conditional lines);
     preserves the single-thread-per-patient staff experience; fixes the
     real Meta session-window bug; closes the provenance/compliance gap;
     consistent with Rule 1 (custom fields only on vendor doctypes, no
     restructuring).
   - Cons: `WhatsApp Message` becomes a slightly overloaded name (a "WhatsApp
     Message" that isn't always from WhatsApp) — mitigated by making that
     fact explicit and visible everywhere via the `channel` tag, rather than
     leaving it hidden as it is today.

## Consequences

**Backend files touched:**
- `remedisys_healthcare_ai/fixtures/custom_field.json` — new `channel`
  custom field on `WhatsApp Message`.
- `remedisys_healthcare_ai/api/v1/patient_portal/chat.py` —
  `send_my_chat_message` sets `channel="Portal"`.
- `remedisys_healthcare_ai/integrations/whatsapp/chat_api.py` —
  `on_whatsapp_message_created` gates window extension on `channel`; message
  formatter includes `channel` in API responses; new `send_portal_reply`
  endpoint; `_log_outbound_message` gets a `channel` parameter
  (default `"WhatsApp"`, unchanged for existing callers).
- `remedisys_healthcare_ai/patches/v0/<new>.py` + `patches.txt` — backfill
  `channel="WhatsApp"` on existing rows.

**EB Healthcare Frontend files touched:**
- `src/hooks/use-whatsapp.ts` — add `channel` to `WaMessage`; add a
  `useWaPortalReply(id)` mutation hook calling the new endpoint (mirrors
  `useWaReply`).
- `src/components/narzim/messages/message-bubble.tsx` — render the channel
  badge.
- `src/components/narzim/messages/conversation-thread.tsx` — add the
  "Reply in Portal" action shown when `!canReply` (window closed),
  alongside the existing template-picker prompt.
- `src/app/api/whatsapp/conversations/[id]/` — new `reply-portal` (or
  equivalent) BFF route proxying to `send_portal_reply`, following the
  existing `reply/route.ts` pattern.

**No changes needed:**
- Patient Portal app (`EB_Healthcare_PatientPortal`) — unaffected.
- `conversation-thread.tsx`'s session-window gating — already correct logic,
  just starts receiving accurate input.

**Re-evaluation trigger:** if a future channel (SMS, email reply-to-clinic,
etc.) needs the same "one thread per patient" treatment, generalize
`channel` properly rather than special-casing a third value ad hoc — at that
point this ADR should be superseded.

## Verification

- Patient sends a portal-only message after the real WhatsApp window has
  expired → `window_open` stays `false` → EB frontend still shows "Session
  closed" and forces the template picker (no incorrect free-text send
  attempt).
- A real inbound WhatsApp message still flips `window_open` to `true` as
  before.
- Every message returned by `list_conversations` / `get_conversation` /
  patient portal's `list_my_chat_messages` carries a correct `channel`.
- `tests/patient_portal/test_patient_portal.py` extended: portal-inserted
  messages assert `channel="Portal"` and assert `window_expires_at` is
  unchanged after insert.
- `send_portal_reply` is called with the Meta credential mocked/unset (or
  the `WhatsApp Account` deliberately misconfigured) and still succeeds —
  proving the code path genuinely never calls `_send_free_text` or spends
  the WhatsApp key.
- `send_chat_message` still throws `ValidationError` outside the window,
  unchanged.
- Staff sends via "Reply in Portal" while the window is closed → message
  appears in the shared thread tagged `channel="Portal"`; no WhatsApp
  message is delivered to the patient's real WhatsApp app (manually
  verified against a test WhatsApp number — no notification received).

## References

- ADR-015 (Team Chat, staff-only messaging) — why it is not reused here.
- ADR-018 (multi-jurisdiction compliance) — provenance/compliance
  motivation for distinguishing channels.
- Constitution §4, Rule 1 (upgrade-safe — custom fields only on vendor
  doctypes, never edit core/vendor files).
- `remedisys_healthcare_ai/api/v1/patient_portal/chat.py`
- `remedisys_healthcare_ai/integrations/whatsapp/chat_api.py`
- `remedisys_healthcare_ai/integrations/whatsapp/webhook.py`
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/whatsapp_conversation/whatsapp_conversation.json`
- `EB_Healthcare_Frontend/src/components/narzim/messages/conversation-thread.tsx`
- `EB_Healthcare_Frontend/src/hooks/use-whatsapp.ts`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Doc status corrected living -> superseded. Its `Status:` already said Superseded, so the document was describing a replaced rule while declaring itself normative (CLAUDE.md §9) |
| 1.0 | 2026-07-30 | Sarvesh | Initial version (header backfilled from git history) |
