# ADR-096: Encounter Canvas and Encounter Advice surface through Patient Encounter custom fields, not their own Patient Medical Record rows

**Doc status:** living · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-28 by Divyanshu (AI-assisted) · **Version:** 1.4

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** —
- **Superseded by:** —

## Context

`Encounter Canvas` (ADR-095) and the new `Encounter Advice` doctype are both scoped to one
`Patient Encounter`. The product requirement (confirmed with the requester) is that their content
appear **inside the same Patient Medical Record (PMR) entry the encounter already has** — the one
row a clinician sees for that visit in the patient's Medical Record / history — not as additional,
separate rows in that list.

Two facts from the codebase make this a real design decision rather than a default:

1. **Every entry in the patient's Medical Record timeline is a `Patient Medical Record` row, with
   no exceptions and no nesting.** `healthcare/page/patient_history/patient_history.py::get_feed()`
   builds the entire feed from a single `frappe.db.get_all("Patient Medical Record", ...)` call.
   There is no mechanism by which one feed entry can point at two different source records — one
   PMR row is one `reference_doctype` + `reference_name` pointing at exactly one document.

2. **A submitted `Patient Encounter` already gets exactly one PMR row, built by core Healthcare
   itself.** Verified directly against this site's data: every submitted encounter
   (`docstatus=1`) has a corresponding `Patient Medical Record` row with
   `reference_doctype="Patient Encounter"`. It is created by a global hook
   (`doc_events["*"]["on_submit"]` in Healthcare's own `hooks.py`, calling
   `patient_history_settings.py::create_medical_record`), not by `patient_encounter.py`'s own
   `on_submit()` method — easy to miss by reading that file alone, which is why this ADR states it
   as directly-verified fact rather than inference.

3. **That PMR row's `subject` field is generated, not fixed text**, by
   `patient_history_settings.py::set_subject_field(doc)`: it iterates the field names configured in
   `Patient History Settings → Patient Encounter → selected_fields`, rendering each as
   `**Label:** value` (or, for a Table field, an HTML table — this is why "Drug Prescription"
   already appears as a rendered table inside that one PMR entry today). `doc` in that function is
   the `Patient Encounter` instance — it can only render fields that exist on Patient Encounter's
   own schema. It has no way to reach into an unrelated doctype like `Encounter Canvas` or
   `Encounter Advice`.

Given (1) and (2), "one shared entry, not separate rows" rules out ever creating a PMR row for
Canvas or Advice directly. Given (3), the only way their content can appear inside the encounter's
*existing* PMR row is for it to exist as data **on the Patient Encounter document itself** at the
moment that row's subject is (re)built.

## Decision

Add two custom fields to `Patient Encounter` — `custom_canvas_summary` and
`custom_advice_summary` (via `fixtures/custom_field.json`, per CLAUDE.md Rule 1's sanctioned
"custom fields added via fixtures" mechanism; core's own file is never edited) — and register both
field names in `Patient History Settings → Patient Encounter → selected_fields` (a one-time data
change, via a patch, not a code change to core).

Every time an `Encounter Canvas` or `Encounter Advice` record is saved or deleted, a shared helper
(`services/encounter_summary_sync.py::sync_encounter_summary(encounter)`) recomputes both fields
from the current set of Canvas/Advice rows for that encounter and writes them via `db_set`. If the
encounter is already submitted, the helper additionally calls core's own
`patient_history_settings.update_medical_record(doc)` directly for that encounter — the same
function core's `on_update_after_submit` hook would call, invoked explicitly here because saving a
Canvas or Advice record does not itself touch the Patient Encounter document, so nothing would
otherwise trigger that hook.

Net effect: no new PMR rows are ever created for Canvas or Advice. The encounter's one existing PMR
entry gains two more rendered lines — "Canvas" and "Advice" — the same way "Drug Prescription"
already appears there, refreshed every time either changes.

## Alternatives Considered

1. **A separate PMR row per Canvas/Advice record**, written manually (the same pattern
   `services/documents.py` already uses for uploaded Documents, since that feature hit the same
   "not in the Healthcare module, so no automatic PMR creation" wall — see `get_module(doc) !=
   "Healthcare"` in `validate_medical_record_required()`).
   - Pros: simplest to implement; no core-adjacent custom fields; each record's own history is
     independently timestamped.
   - Cons: **directly contradicts the confirmed requirement** — this produces additional, separate
     timeline rows, exactly what was asked not to happen.

2. **Register Canvas/Advice in `Patient History Settings.custom_doctypes` directly**, letting core's
   automatic mechanism create their PMR rows the way it does for standard Healthcare doctypes.
   - Pros: zero custom sync code — core would create and refresh the rows itself.
   - Cons: doesn't compile, structurally. `validate_medical_record_required()` hard-gates on
     `get_module(doc) == "Healthcare"` — our doctypes' module is `Remedisys Healthcare Ai`, so this
     path can never fire for them regardless of configuration. It also still produces separate rows
     (same objection as #1), since `custom_doctypes` registration only wires up *their own* PMR
     creation, not a merge into the encounter's row.

3. **A frontend-only merge** — leave the encounter's PMR row alone, and have whatever screen
   displays "the encounter" additionally fetch Canvas/Advice and render them alongside it at
   display time, with no backend change at all.
   - Pros: no core-adjacent fields, no sync helper, cheapest to build.
   - Cons: only solves it for *whichever specific screen* does that extra fetch. The actual PMR
     entry — which is what `docs/adr/adr-096...` is about, and what Frappe Desk's own Patient
     History page shows — would still be missing Canvas/Advice entirely; any other consumer of that
     PMR row (a report, an export, a different screen) would silently be incomplete. Rejected
     because the requirement was for the entry itself to carry this, not for one screen to fake it.

4. **Custom fields + Patient History Settings registration + explicit sync helper (chosen).**
   - Pros: satisfies the requirement exactly — one entry, refreshed automatically, using the same
     rendering path ("Drug Prescription" et al.) that already exists and is never touched by this
     change. Reuses a sanctioned Rule-1 mechanism (custom fields via fixtures) rather than inventing
     a new one.
   - Cons: two custom fields on a core doctype, one data patch, and one helper function that must be
     called from both Canvas's and Advice's save/delete paths — the only real cost, and it is paid
     once.

## Consequences

- `fixtures/custom_field.json` gains `custom_canvas_summary` and `custom_advice_summary` on
  `Patient Encounter`.
- `patches/v0/register_canvas_advice_in_patient_history_20260928.py` appends both field names to
  the existing `Patient Encounter` row's `selected_fields` in `Patient History Standard Document
  Type` — additive; every other registered field and doctype is untouched.
- New `services/encounter_summary_sync.py`; called from `Encounter Canvas`'s and `Encounter
  Advice`'s own `on_update`/`after_delete` controller hooks (**not** from the API layer — moved
  there 2026-09-28, see that file's own docstring: a record created directly in Desk, the only
  way to use either feature before the frontend exists, never went through the API at all, so the
  summary silently never synced for it).
- **RENDERING MECHANISM SUPERSEDED BY ADR-097 (2026-09-28, same day).** The next three bullets
  describe an `<img>`-based, data-URI-embedded thumbnail — that was true for a few hours and is no
  longer how a canvas renders. `Encounter Canvas.image` was removed entirely and the regex-based
  "extract the `<svg>` block" fallback that briefly replaced it was found to silently drop any
  `<style>` the SVG depended on, turning a real drawing into a solid black shape. The current
  mechanism renders the stored `canvas_data` (HTML) verbatim inside a sandboxed iframe — see
  ADR-097 for the full reasoning; this ADR's own subject (custom fields + sync helper +
  `Patient History Settings` registration) is unaffected by that change and still accurate.
  Kept below as the historical record of what escaping/embedding was verified at the time.
- **`custom_canvas_summary` DOES render an actual inline thumbnail per canvas, not just a name —
  corrected 2026-09-28.** This ADR originally claimed the opposite ("`format_value()` escapes
  plain Text/Small Text fields"), which was never actually verified and was wrong:
  `format_value()` does not escape "Text" fields at all — confirmed reading its source, then
  empirically. The real, separate finding that made this safe to rely on: Frappe's own `Document`
  save layer already sanitizes "Data"/"Small Text" field values unconditionally on every
  insert/save (verified directly against both `Encounter Canvas.title` and `Encounter Advice
  Item.advice_text` — a title of `<script>alert(1)</script> R&D` is stored as ` R&amp;D`, the
  script tag stripped entirely, the ampersand already entity-encoded), so no additional escaping
  is needed — or wanted — when this data is later embedded in the summary. A first attempt added
  `html.escape()` on top of that anyway, which double-encoded the already-encoded value into a
  visible `&amp;amp;` bug; removed once the actual sanitization behavior was confirmed.
- **The thumbnail embeds the actual image bytes as a `data:` URI, not a link to the file —
  direct instruction, 2026-09-28.** The stored `subject` is then fully self-contained: viewing it
  never depends on the underlying `File` record still existing at that path, and never issues a
  second request for something already sitting in this same field. `_image_data_uri()` reads the
  file directly (`frappe.utils.file_manager.get_file()`), base64-encodes it, and degrades to the
  plain-text fallback (never a hard failure) if the file can't be read. Cost: base64 inflates the
  raw PNG by roughly a third, stored directly in the field — `custom_canvas_summary` is `Long
  Text`, not `Text`, specifically because of this (a plain `Text`/MySQL `TEXT` column tops out
  around 64KB, which a handful of embedded sketches could exceed).
- **A THIRD, best-effort rung was added 2026-09-28 — direct instruction ("IN PMR we have to show
  the image of of htm too") — and was itself superseded hours later, same day, by ADR-097.** It
  added a regex-based `_canvas_data_svg_data_uri()` that sliced out just a `<svg>...</svg>`
  substring from `canvas_data` and embedded that as an `image/svg+xml` data: URI. Found wrong on
  the very next real test: a live drawing whose strokes were styled via a `<style>` block in the
  document's `<head>` rendered as a solid black shape once that block was left behind by the
  slice. Kept here, struck through in spirit, as the record of why a parsing-based rung doesn't
  survive `canvas_data`'s schema actually being opaque (see ADR-097's Alternatives, option 1).
- Re-evaluation trigger: if `Patient History Settings` or `set_subject_field()` itself is ever
  changed by a core Healthcare upgrade to render Table-only content differently, or to stop
  accepting arbitrary field names in `selected_fields`, this ADR's mechanism needs re-verification
  against the new version before assuming it still works.

## Verification

- A `Patient Encounter`'s PMR row's `subject` contains an AI/Manual advice line, and an actual
  inline `<img>` thumbnail for a canvas that has one (falling back to its name/title when it
  doesn't), immediately after saving each — verified via `bench console`, not assumed.
- Saving a Canvas or Advice record against an **already-submitted** encounter updates the existing
  PMR row's `subject` in place — no second PMR row is created (`frappe.db.count("Patient Medical
  Record", {"reference_doctype": "Patient Encounter", "reference_name": encounter})` stays `1`
  before and after).
- A canvas title or advice line containing an attempted script injection (`<script>...</script>`)
  never reaches the subject as live markup — verified the tag is stripped entirely by Frappe's own
  save-time sanitization, and that the summary builder does not re-escape the already-sanitized
  value on top of it (which would visibly double-encode it instead of adding real protection).
- A record created directly in Desk (`frappe.get_doc(...).save()`, no API call at all) resyncs the
  summary exactly the same as one created through the API — verified against the actual records
  that first surfaced the gap this fixed.
- **Superseded by ADR-097's own Verification** (that ADR now owns this fact): a canvas whose
  `canvas_data` is the live HTML/CSS/SVG document that first surfaced the black-shape bug renders
  its actual styled drawing, not a black shape and not a regex-sliced fragment. The
  `data:image/svg+xml` / bare-`<svg>`-extraction verification this bullet used to describe no
  longer reflects how a canvas renders.

## References

- `docs/ENCOUNTER_CANVAS.md`, `docs/ENCOUNTER_ADVICE.md` — the mechanism docs for each doctype
- ADR-095 — Encounter Canvas's own storage-format decision (`canvas_data` + `image`), unaffected by
  this ADR
- `patches/v0/drop_clinical_document_20260909.py` — why `Clinical Document` was never a candidate
  storage target for either doctype
- `services/documents.py` — the other place in this app that hit the same
  `get_module(doc) != "Healthcare"` wall, solved differently (separate PMR rows), because that
  feature's requirement was different (a Documents list, not "inside the encounter's own entry")

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-28 | Divyanshu (AI-assisted) | Rendering mechanism superseded by ADR-097 same day: `image` removed, the regex-based SVG-extraction rung (1.3) replaced by rendering `canvas_data` verbatim in a sandboxed iframe. This ADR's own subject (custom fields + sync helper) is unaffected — annotated in place, not rewritten |
| 1.3 | 2026-09-28 | Divyanshu (AI-assisted) | Third fallback rung added: a canvas with no rendered `image` but literal `<svg>` markup in `canvas_data` now renders that SVG directly as the thumbnail, instead of falling to plain text |
| 1.2 | 2026-09-28 | Divyanshu (AI-assisted) | The canvas thumbnail embeds the actual image bytes as a `data:` URI, not a link to the file (direct instruction) — `custom_canvas_summary` widened to `Long Text` to hold it |
| 1.1 | 2026-09-28 | Divyanshu (AI-assisted) | Corrected two claims found wrong by direct verification: (1) `custom_canvas_summary` DOES render an actual inline image, not just text — the original "escapes non-Table fields" claim was never checked and was false; (2) the sync call moved from the API layer to `on_update`/`after_delete` doctype hooks, since a Desk-created record (the only way to use either feature today) never went through the API |
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
