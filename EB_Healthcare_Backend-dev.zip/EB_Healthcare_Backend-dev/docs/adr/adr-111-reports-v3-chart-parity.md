# ADR-111: Reports v3 round 2 — default chart per report matches the design

**Doc status:** living · **Created:** 2026-09-28 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-28 by Anant Sharma (AI-assisted) · **Version:** 1.3

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** the chart-swap deferral in `docs/reports/18-reports-v3-redesign.md` §4 v1.0/1.1
- **Superseded by:** —

## Context

Round 1 (the AI-findings ADR, `docs/reports/18-reports-v3-redesign.md`) shipped the Reports v3 shell, AI
findings, Ask Orin and pins, and explicitly deferred replacing each report's default chart —
`docs/reports/18-reports-v3-redesign.md` §4 v1.0 gave the reason: 17 pages carry tuned chart logic
(drill-downs, `—`-not-`0`, scoping), and swapping all of them at once risks breaking behaviour
`CLAUDE.md` §13 rule 3 says to preserve.

During round 1, two of those swaps shipped anyway, as an **additive second view** rather than a
replacement (Patient Flow's heat map, Payment Methods' by-mode view — both opt-in toggles next to
the original chart, which stayed default). `docs/reports/18-reports-v3-redesign.md` v1.1 documents
this. Anant flagged, from a screenshot of the live design canvas, that Patient Flow in the actual
design has **one** chart — the heat map, full width, no toggle — and asked for full parity with the
design across all reports, "everything."

Two things in the design cannot be built, and this ADR does not reopen them:

- **§5's fabricated-figure list** (WhatsApp-confirmed vs. unconfirmed arrivals, "scribe saves
  4.2 min," patient rating 4.8/5, per-station staffing, slots overbooked) — nothing measures these;
  showing them would violate `CLAUDE.md` PHI-5.
- **Chart annotations** ("Two doctors start at 10:30…", "WhatsApp reminders paused for 2 days") —
  the system does not record the underlying events (schedule changes, reminder toggles) as data.

Reading the design's own component logic (`Reports v3.dc.html`'s `CH` map — the definitive
per-report chart-type table) against the current frontend (`remedisys-ai-ehr`) **and** against what
each report's backend method actually computes surfaced a second category of gap, worse than a
chart-wiring task: for four reports, the design's chart shows a metric the backend has never
computed — not a stub waiting to be plotted, a number that does not exist yet.

| Report | Design type | Real gap found |
|---|---|---|
| Patient Flow | `heat` | None — toggle exists, wrong default (round 1) |
| Payment Methods | `stack` | None — toggle exists, wrong default (round 1) |
| Utilization Rate | `rank` + target 85 % | None — `RankedBarList` already default on real `util_pct` data; a leftover Pie chart sits alongside it; target is a genuinely new number, not derived from an existing stub |
| Diagnosis Trends | `rank` | None — `RankedBarList` already default on real diagnosis counts |
| Revenue by Provider | `rank` | None — `RankedBarList` already default on real collected amounts |
| Average Visit Time | `rank` | None — real per-practitioner average-minutes data, component already imported |
| Outstanding Balances | `rank`, money | None — real balance-owed data |
| My Performance | `line` | None — no chart component exists yet, but the underlying data (visits per day) is real and already computed elsewhere; this is genuinely a build, not a metric problem |
| Queue Wait Times | `line` + target 10 min | None — `by_hour` is real per-hour wait data; was rendered as a bar chart, not a metric problem |
| **Check-in Rates** | `funnel` (Booked→Arrived→Seen→Paid) | **Blocked.** `_build_check_in_rates` (`api/v1/appointments/report.py:1658`) measures arrival **punctuality** — early/on-time/late/no-show, mutually exclusive categories with their own carefully-reasoned denominators (see the function's docstring) — not sequential funnel stages. There is no "seen by doctor" / "paid at checkout" stage data behind this report at all |
| **Claims Status** | `funnel` (Submitted→Documents complete→Approved→Paid) | **Blocked.** `_build_claims_status` (`api/v1/insurance/report.py:51`) has 3 mutually-exclusive buckets (approved/pending/rejected), not 4 sequential stages — no "documents complete" or "paid" state is tracked on `Insurance Claim`. Also zero rows in this environment (`docs/reports/HIDDEN_REPORTS.md`) |
| **Chronic Care** | `rank` + target 70 % ("Clinic goal") | **Blocked.** `_build_chronic_care` (`api/v1/clinical/report.py:105`) sets `"controlled": None,  # stub — no control state anywhere in the schema`. There is no clinical-control concept (an HbA1c-vs-threshold check, say) recorded anywhere for any condition — the rank chart itself, not just the target line, has nothing real to plot |
| **Immunization Rates** | `rank` + target 95 % ("National target") | **Blocked.** `_build_immunization_rates` (`api/v1/immunizations/report.py:68`) computes `by_vaccine` **dose counts**, which is a different ranking from the design's per-vaccine **coverage percentage** (e.g. "90 of 96 children" — doses given ÷ eligible population). Coverage requires an eligible-population walk against each vaccine's schedule; `coverage_pct`/`coverage_by_age`/`overdue` are explicit stubs (`meta.stub_fields`), never built |
| **Queue Stage Breakdown** | `stack` | **Blocked, found 2026-09-28 in a post-round-2 audit.** `_build_queue_stage_breakdown` (`api/v1/appointments/report.py:1522`) returns one number per room — 5 rooms, one `avg_duration_min` each — with no time dimension. A stacked chart needs two dimensions (a category axis, and a series stacked within each category, e.g. "per day, split by room"); this data has one. There is nothing to stack without adding a new dimension server-side (e.g. per-day room time instead of one window-wide average) — a data-model decision, not chart wiring |
| **Patient Volume** | `stack` | **Blocked, same audit.** `_build_patient_volume` (`api/v1/providers/report.py:71`) has `by_provider` (one value per provider), `share` (the same, as a percentage) and `trend` (one weekly visit count, unsplit) — none carries a second dimension to stack against. Same class of gap as Queue Stage Breakdown |

A first pass at this ADR proposed wiring all of `rank`/`funnel` uniformly and adding a configurable
"clinic goal" field for Chronic Care's target. That was wrong: four of these reports don't have the
underlying metric at all, so no amount of chart wiring produces a real chart, and a settable target
with nothing real to compare it against is decoration, not a target line — the same
"code doesn't back what the UI claims" problem PHI-5 exists to catch, just found one layer deeper
than usual (in a metric, not a retention window). This revision (v1.1) corrects that.

`v3-charts.tsx` (`remedisys-ai-ehr/src/components/narzim/reports/`) already exports all four
non-line primitives the design needs — `HeatMapGrid`, `RankedBarList`, `FunnelChart`,
`TargetReferenceLine` — so for the reports that are NOT blocked, this is wiring and cleanup work on
existing components, not new chart libraries.

The two target lines that remain in scope (Immunization's and Chronic Care's) are moot — both belong
to blocked reports. Only **Utilization's 85 %** ("Healthy utilisation," an operational benchmark, not
a clinic-set number) survives into round 2.

## Decision

**Bring the eight unblocked reports' default chart to the design's `CH` type.** Four reports
(Check-in Rates, Claims Status, Chronic Care, Immunization Rates) are excluded — see the table above
— pending a decision only Anant can make, since each requires either redefining what the report
measures or building new data tracking that does not exist in the schema today. Nothing is built for
them in round 2; their current charts stay.

For the eight in scope, three tiers ordered by how much new plumbing each needs:

1. **Flip existing toggles to default** (Patient Flow → heat map default; Payment Methods → by-mode
   default). Smallest change; both primitives and both data fields already exist and are tested.
2. **Clean up / confirm the already-wired primitive** (Utilization Rate → drop the redundant Pie
   chart, keep `RankedBarList`, add the 85 % target line as a Python constant; confirm Diagnosis
   Trends, Revenue by Provider, Average Visit Time and Outstanding Balances render `RankedBarList` as
   their sole chart — no target line on any of these four, the design doesn't show one).
3. **Build what does not exist** (My Performance → a `line` chart of visits per day, reusing the same
   `AreaChart`/`Line` pattern already used by Payment Methods' and No-show Analysis' trend charts
   rather than introducing a second line-chart implementation; Queue Wait Times gets **both** its
   10-minute target line and a chart-TYPE conversion, bar → line, to actually match `CH`'s
   `type: 'line'` — v1.1 of this ADR under-scoped this to "the target line" only, and shipped a bar
   chart with a target line drawn across it; corrected in v1.2 once the mismatch was caught in a
   design-vs-code audit, not by re-reading the ADR).

Both surviving target lines (Utilization 85 %, Queue Wait Times 10 min) are Python constants in the
report service, not new settings — neither is presented by the design as clinic-editable ("Healthy
utilisation," not "your clinic's utilisation goal"), so a hardcoded constant does not misrepresent
anything. If either ever needs to vary by clinic, that becomes its own small change against
`EB Clinic Settings` (already the per-clinic settings surface: Facilities / Notifications / Access &
Security / Appearance / Permissions) — not built now, nothing asks for it yet.

**"Additive extra chart" cases — surfaced, then resolved by Anant directly, 2026-09-28.** A second
audit found extra, undesign charts on six reports, not the two v1.2 first flagged: No-show Analysis
(bar-by-weekday), Encounter Summaries (bar-by-type, bar-by-provider), Utilization Rate (a separate
weekly trend line beside the rank chart), Diagnosis Trends (a second by-category rank chart),
Average Visit Time (a Pie chart and a by-visit-type bar chart beside the rank chart), and Outstanding
Balances (aging/by-range/trend charts beside the new by-patient rank chart). Two more — Patient
Flow's bar-chart toggle and Payment Methods' Total toggle — were offered and **declined**: those stay
as opt-in secondary views, not removed.

Presented back to Anant as one decision per report (not assumed): **removed** — No-show Analysis,
Encounter Summaries, Utilization Rate, Outstanding Balances. **Left as-is, not removed** — Diagnosis
Trends' by-category chart, Average Visit Time's Pie/bar charts, Patient Flow's bar toggle, Payment
Methods' Total toggle. In every removed case the backend field the extra chart read
(`charts.by_dow`, `charts.by_type`, `charts.by_provider`, `charts.trend`, `charts.aging`,
`charts.by_range`) is still returned by the report endpoint, unused by the page — nothing was
deleted server-side, and restoring any of these views is a frontend-only change.

**Explicitly out of round 2**, same reasoning as round 1's §5/annotations exclusions:
- The `NEXT` map (per-report "Suggested next step" text) — advice, which the AI-findings ADR already excludes
  for the Brief; the same reasoning applies per-report.
- Chart annotations on the `line`-type reports — no underlying event data.
- The one-line per-report hint on the *All reports* landing list (design: `'Peak 10–11 am'`,
  `'Avg 14 min · ↓ 3'`) — computing it for real requires each of the 17 reports' own top KPI, and
  `docs/reports/18-reports-v3-redesign.md` §4 already priced this as "needs all 17 reports fetched to
  render one list." No cheap aggregate exists yet. Deferred to round 3.

## Alternatives Considered

1. **Wire all `rank`/`funnel` reports uniformly, including the four blocked ones, using the closest
   existing data as a stand-in (dose counts for coverage, punctuality buckets for a booking funnel).**
   - Pros: full visual parity with the design in one pass, no reports left behind.
   - Cons: this is the option actually tried first, and rejected — it draws charts that assert a
     ranking or a stage sequence the data doesn't represent. Doses-given ≠ coverage-percentage ranking
     order; punctuality categories ≠ funnel stages. A clinician reading "coverage" would read the
     wrong number as true.
2. **Build the missing metrics now** (an eligible-population/schedule walk for immunization coverage,
   a control-state field for chronic conditions, new `Insurance Claim` states, a redefinition of
   Check-in Rates around booking-to-payment).
   - Pros: closes every gap; full design parity including the four blocked reports.
   - Cons: each of these is its own clinical/data-model decision (what counts as "controlled" for
     four different chronic conditions is a clinical judgment call, not an engineering one) — bundling
     four such decisions into a chart-parity ADR is how a scope creeps from "wire a chart" to
     "redesign four measurement systems" without anyone deciding to do that on purpose.
3. **Ship the eight unblocked reports now; leave the four blocked ones exactly as they are, flagged
   for a separate decision (chosen).**
   - Pros: real, honest progress on the reports where the data already supports the design; no
     fabricated or mismatched chart shipped; the four blocked reports get the deliberate,
     clinically-informed decision they actually need instead of a rushed one bundled into this ADR.
   - Cons: round 2 still doesn't reach full design parity — 4 of ~13 reports remain visually
     different from `Reports v3.dc.html` until a follow-up ADR resolves them.
4. **Hide or visually flag the four blocked reports' charts as "not yet available"** rather than
   leaving their current (working, real) charts in place.
   - Pros: makes the gap visible to users instead of silent.
   - Cons: these reports work today and show real data in a different chart shape — replacing a
     working chart with an empty state to signal a design gap is a worse outcome for the person using
     the report than the gap itself. The gap belongs in this ADR and the plan doc, not the product UI.

## Consequences

- Frontend (`remedisys-ai-ehr`, `feat/reports-design`): `patient-flow/page.tsx`,
  `payment-methods/page.tsx` (default flips), `utilization-rate/page.tsx` (remove Pie, add target
  line, and — v1.3 — remove the trend chart), `diagnosis-trends/page.tsx`, `revenue-by-provider/page.tsx`,
  `average-visit-time/page.tsx` (confirmed already correct, no change), `outstanding-balances/page.tsx`
  (new `by_patient` rank card, and — v1.3 — remove the aging/by-range/trend charts), `my-performance/page.tsx`
  (new line chart), `queue-wait-times/page.tsx` (target line, and — v1.2 — bar-to-line chart-type
  conversion), `no-show-analysis/page.tsx` (v1.3 — remove the bar-by-weekday chart),
  `encounter-summaries/page.tsx` (v1.3 — remove the bar-by-type and bar-by-provider charts).
  **Not touched, all blocked on a data-model decision:** `check-in-rates/page.tsx`,
  `claims-status/page.tsx`, `chronic-care-management/page.tsx`, `immunization-rates/page.tsx`,
  `queue-stage-breakdown/page.tsx`, `patient-volume/page.tsx`.
  **Extra charts offered and explicitly declined by Anant, left as-is:** `diagnosis-trends/page.tsx`'s
  by-category chart, `average-visit-time/page.tsx`'s Pie and by-visit-type charts, `patient-flow/page.tsx`'s
  bar-chart toggle, `payment-methods/page.tsx`'s Total toggle.
- Backend (`remedisys_healthcare_ai`, `feat/reports-design`): `providers/report.py` (Utilization) gets
  a `_UTIL_TARGET_PCT = 85` constant; `appointments/report.py` (Queue Wait Times) gets its 10-minute
  target constant, exposed the same way; `billing/report.py` (Outstanding Balances) gets
  `charts.by_patient`, a real per-patient aggregation; `dashboard/report.py` (My Performance) gets a
  real rolling-30-day `charts.trend` query. **No doctype/schema change** — the Chronic Care settings
  field proposed in v1.0 of this ADR is withdrawn; there is nothing real for it to configure until
  Chronic Care's `controlled` stub is resolved.
- `docs/reports/18-reports-v3-redesign.md` §3/§4 updated to record round 2's actual scope.
- A follow-up decision is needed, NOT made here, for **six** reports: Check-in Rates' and Claims
  Status' funnel semantics, Chronic Care's control-state tracking, Immunization's
  coverage-percentage computation, and Queue Stage Breakdown's and Patient Volume's missing
  second dimension for a stacked chart. Each is a clinical or data-model question, not a chart
  question — the last two were found in a post-implementation audit against the design's `CH` map,
  not planned for in v1.0/v1.1.
- Re-evaluation trigger: if any of the six blocked reports gets its underlying metric built, this ADR
  is revisited (or superseded) for that report specifically — not reopened wholesale.

## Verification

- Existing report tests (`tests/*/test_*.py`) continue to pass with the added target constants and
  the new `by_patient`/`trend` chart fields.
- Frontend: each of the reports listed as in-scope above renders the design's `CH` chart type as the
  sole chart, verified directly against `Reports v3.dc.html`'s own `CH` map — TypeScript
  (`tsc --noEmit`) and ESLint clean on every touched file, including the four v1.3 removals.
- No backend field was deleted for a removed chart — `charts.by_dow`, `charts.by_type`,
  `charts.by_provider` (encounter-summaries), `charts.trend` (utilization-rate), `charts.aging`,
  `charts.by_range` and `charts.trend` (outstanding-balances) are all still in the report response,
  just unread by the page now — confirmed by grepping each removed import/variable left no dangling
  reference (`tsc --noEmit` would have caught an unused-but-required prop; it did not).
- **This ADR was itself found incomplete by a design-vs-code audit after v1.1 shipped**: v1.1 claimed
  Queue Wait Times was done with "the target line" alone, without checking the chart's actual `type`
  prop against `CH['queue-wait-times'].type === 'line'` — it was still a bar chart. The same audit
  is what surfaced Queue Stage Breakdown and Patient Volume as blocked, and the two "extra chart"
  cases. Lesson recorded here rather than left implicit: "added the field the ADR asked for" is not
  the same check as "rendered against the design's own literal chart-type map."
- The six blocked reports are unchanged — their existing tests and current chart behaviour are
  untouched by this ADR.
- `docs/reports/18-reports-v3-redesign.md` and `WORK_LOG.md` updated in the same change, per
  `CLAUDE.md` §9's one-fact-one-owner rule.

## References

- `docs/reports/18-reports-v3-redesign.md` (round 1) and its v1.1 chart-scope correction.
- The AI-findings ADR (`reports-v3-ai-insights`, unnumbered, parked on
  `wip/reports-v3-ai-insights` — its implementation was
  lost, see `../KNOWN_ISSUES.md`) — the `NEXT`/advice exclusion this ADR reuses for
  per-report "Suggested next step."
- `CLAUDE.md` §9.9 PHI-5, §13 rule 3, §10 (four-approaches rule, doc-before-code rule).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-28 | Anant Sharma (AI-assisted) | Extra-chart cases from v1.2, plus two more found in a third pass (Utilization Rate's separate trend, Outstanding Balances' aging/range/trend), presented to Anant per-report; removed on his explicit direction: No-show Analysis, Encounter Summaries, Utilization Rate, Outstanding Balances. Left as-is on his explicit direction: Diagnosis Trends, Average Visit Time, Patient Flow's toggle, Payment Methods' toggle. No backend field deleted in any removal |
| 1.2 | 2026-09-28 | Anant Sharma (AI-assisted) | Found by a post-implementation audit against `Reports v3.dc.html`'s own `CH` map (not by re-reading this ADR): Queue Wait Times was still a bar chart despite v1.1 saying it was done — fixed, bar → line. Queue Stage Breakdown and Patient Volume found blocked the same way as the original four (no second dimension to stack) — added as blocked #5 and #6. No-show Analysis and Encounter Summaries recorded as carrying extra charts the design doesn't show, left unresolved. Consequences/Verification rewritten to state this ADR was itself incomplete once, and why |
| 1.1 | 2026-09-28 | Anant Sharma (AI-assisted) | Corrected before any code was written: Check-in Rates, Claims Status, Chronic Care and Immunization Rates are blocked by real missing metrics (not chart-wiring gaps) and pulled out of round 2's scope; the Chronic Care settings field is withdrawn since nothing real exists for it to configure; Alternatives and Consequences rewritten around the 8-report scope actually being built |
| 1.0 | 2026-09-28 | Anant Sharma (AI-assisted) | Initial version |
