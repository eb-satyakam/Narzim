# ADR-041: My Work moves to single assignee + single assigner; doctors assign Nursing Tasks to a named nurse

**Doc status:** living · **Created:** 2026-08-18 by ashulockedin · **Updated:** 2026-08-18 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-08-18
- **Builds on:** ADR-020 (doctor → nurse vaccine administration handoff), which is the proof this
  pattern already works — it's generalised here beyond vaccines.
- **Superseded by:** —

## Context

"My Work" modelled "assign this task to several people" by giving `ToDo.allocated_to` — a single
`Link(User)` field that can never hold more than one person — a workaround: one `ToDo` row per
assignee, each sibling pointing back at an "anchor" row via `reference_type="ToDo"` /
`reference_name=<anchor>`. This produced duplicate rows in the UI (an avatar stack with a "+N"
overflow), an invented `primary_holder`/`assignees` vocabulary layered on top of the real schema, and
no honest answer to "who owns this?" — group membership had to be resolved with extra queries on
every read, write, and delete.

Separately, `Nursing Task` (ERPNext Healthcare) is a real single-assignee doctype built exactly for
"hand a clinical task to a nurse" — submittable, a `user` field for the assignee, patient-linked, with
a completion-proof mechanism (`task_doctype`/`task_document_name`). This project already wraps it in
`nursing/api.py` and already uses it for one narrow case, vaccine administration (ADR-020). But nothing
let a doctor create one directly from My Work, and core's template-generated tasks never set `user` at
all, so only vaccine tasks ever reached a nurse's worklist.

An internal audit (`docs/audit/nurse/screens/11-nursing-tasks.md`, finding NT3) had already flagged
that My Work's Nursing Task rows carried a `Start`/`Complete` action label that did nothing but
navigate to the patient chart — a fake client-only dismiss, not a real status transition.

## Decision

**One assignee, one assigner, per task — across every source My Work aggregates — plus a new
`assign_nursing_task` endpoint so a doctor can hand a Nursing Task to a named nurse directly.**

1. **ToDo multi-assign is retired.** `allocated_to` is the one assignee; `assigned_by` (native) is the
   one assigner. The anchor/sibling machinery (`_todo_group_anchor`, `_todo_group_members`,
   `_todo_group_primary_holder`, `_create_sibling_todos`, the `assignees`/`primary_holder` API fields)
   is deleted outright, not deprecated. `create_todo`/`update_todo` no longer accept an `assignees`
   list. An existing sibling group is collapsed by a one-time migration patch
   (`collapse_todo_assignee_groups_20260818`): open siblings are deleted (keep the anchor — the
   locked product decision), closed/cancelled siblings are **detached** (reference cleared, row kept)
   rather than deleted, since destroying a record of completed work is a worse outcome than an "extra"
   row. The patch matches strictly on `reference_type == "ToDo"`, so genuine references
   (`"Patient Encounter"` follow-ups, `"Patient Appointment"` refund requests) are never touched.

2. **The one other multi-assign producer, the auto-generated refund task
   (`encounters.api._create_refund_task_for_appointment`), changes shape, not just implementation.**
   It used to fan out to the whole Front Desk team via the anchor/sibling mechanism. It now creates a
   single **unassigned** ToDo (`allocated_to` empty). `tasks.api._fetch_todos` widens its filter so any
   Front Desk user (not just the whole-clinic "show all" admin view) also sees unassigned ToDos —
   preserving "the whole team sees this request" without reintroducing multi-assign. Claiming it is a
   plain `update_todo` call that sets `allocated_to`; no new "claim" endpoint was needed.

3. **`assign_nursing_task(patient, activity, user, notes, ...)`** (new, whitelisted) lets a doctor
   create *and submit* a Nursing Task for a named nurse in one call — avoiding the orphan-Draft risk of
   a separate create-then-submit round trip. `user` must be an enabled account holding `EB_Nurse`
   (enforced server-side), matching the locked product rule: one named nurse, not a role or a pool.
   Real permission checks apply (`require_permission("Nursing Task", "create")`) — unlike ADR-020's
   `create_vaccine_administration_task`, which needs `ignore_permissions` because it runs inside the
   encounter-sign transaction; here the doctor is acting directly and already holds create rights via
   `eb_docperm_spec.json`.

4. **The nurse picker (`list_nurse_users`) is deliberately not gated on `User`-doctype read.** Only
   `EB_Healthcare Admin` holds that permission; a doctor assigning work does not need to manage
   accounts. Same reasoning, and same shape, as `notes.api.list_shareable_users` and
   `encounters.api._front_desk_users`.

5. **Assigner exposure on Nursing Task uses `owner`, not a new field.** Nursing Task has no
   `assigned_by`; `owner` (Frappe's built-in record-creator stamp) is the only signal available, and is
   true for both `assign_nursing_task` and the ADR-020 vaccine flow. Consistent with ADR-020's own
   rejection of adding Custom Fields to this doctype.

6. **My Work assigns and displays Nursing Tasks; it never writes their status.** This *narrows* NT3's
   original complaint rather than reopening a second write path: the fake `Start`/`Complete` label is
   removed and replaced with a real "Open in Nursing Tasks" deep-link to `/nursing`, which is the one
   place `update_nursing_task_status` is called from the UI. The one exception, unchanged: a vaccine
   administration task still deep-links straight into the Add-immunization dialog, because recording
   the dose *is* the completion there — a real transition, not a workaround.

7. **A latent data-quality bug is fixed in passing.** Core computes
   `task_duration = time_diff_in_seconds(now, task_start_time)` whenever a task reaches `Completed`.
   `get_datetime(None)` resolves to *now*, not an error, so a task that skips `In Progress` entirely
   (every ADR-020 vaccine handoff does exactly this) got a small negative duration silently written on
   every dose. `update_nursing_task_status` and `immunizations.api._complete_vaccine_task` now stamp
   `task_start_time` before completing if it isn't already set.

## Alternatives Considered

1. **Keep ToDo multi-assign, add Nursing Task assignment alongside it.** Rejected — the point of this
   change is that multi-assign was never real, and leaving it in place while adding a second,
   genuinely-single-assignee model in the same feed would make the inconsistency worse, not better.
2. **A new `assigned_by` Custom Field on `Nursing Task`.** Rejected, same reasoning as ADR-020: `owner`
   already carries this information; a Custom Field would duplicate it.
3. **Reassignment via `doc.save()` after submit.** Not implemented. `user` is not
   `allow_on_submit` on `Nursing Task`, so a later "reassign to a different nurse" would need either a
   raw `db.set_value` bypass (deferred — no product requirement for it yet) or amend/cancel-recreate
   (rejected — destroys the document's identity and audit trail for no benefit). Reassignment is
   explicitly **out of scope** for this change; assignment is create-time only.
4. **Deduplicating concurrent identical assignments** (two doctors ordering the same activity for the
   same patient to the same nurse). Rejected — two doctors independently ordering the same nursing
   action is a legitimate clinical event; a false-merge would be worse than a harmless duplicate.
5. **Fixing the whole-team refund fan-out by picking "first Front Desk user only."** Rejected — that
   silently drops the real "the whole team should see this" behaviour; the unassigned-queue model
   keeps it without reintroducing multi-assign.

## Consequences

- **`tasks/api.py`** — `_parse_emails`, `_todo_group_anchor`, `_todo_group_members`,
  `_todo_group_primary_holder`, `_create_sibling_todos` deleted. `create_todo`/`get_todo`/`list_todos`/
  `update_todo`/`delete_todo` simplified to plain single-row operations (a real perf win too:
  `list_todos` went from up to 3 queries per page down to 1). `_fetch_tasks`/`_fetch_todos`/
  `_fetch_nursing_tasks`/`_fetch_clinical_procedures` all now emit one consistent shape:
  `assigned_to` (scalar) + `assigned_to_full_name` + `assigned_by` + `assigned_by_full_name`.
- **`nursing/api.py`** — new `list_nurse_users`, `assign_nursing_task`, `_ensure_task_start_time`;
  `_fmt`/`_LIST_FIELDS` expose `owner`/`owner_full_name`/`user_full_name`.
- **`immunizations/api.py`** — `_complete_vaccine_task` now calls `_ensure_task_start_time` before
  completing.
- **`encounters/api.py`** — `_create_refund_task_for_appointment` rewritten to a single unassigned
  ToDo with an idempotency guard; the `_create_sibling_todos` import is dropped.
- **New patches** — `seed_nursing_activities_20260818` (7 standard activities, all with an empty
  `task_doctype` so a nurse can complete them from My Work without a linked proof document) and
  `collapse_todo_assignee_groups_20260818` (the one-time migration described above).
- **Frontend** (`EB_Healthcare_EHR`) — `WorkItem`/`TodoItem` narrowed to the single-assignee shape;
  the avatar-stack "+N" UI is gone; a type badge distinguishes ToDo vs Nursing Task rows in the
  unified list; "+ New" gained a Task/Nursing Task choice, the latter gated to
  practitioner/nurse/admin roles; a new `AssignNursingTaskForm` (patient + activity + nurse pickers,
  notes, requested start time); new BFF routes `/api/nursing/nurses`, `/api/nursing/activities`, and a
  `POST` on `/api/nursing/tasks`.
- **Not addressed here (follow-up work):** core template-generated Nursing Tasks (admission/lab/
  procedure checklists) still never set `user`, so they remain invisible to any nurse's worklist filter;
  reassignment of an already-submitted Nursing Task; backfilling the small negative `task_duration`
  values already written by live vaccine handoffs before this fix.

## Verification

- Manually verified end-to-end via `bench console` against `mysite.localhost`: `list_nurse_users`
  called as a plain `EB_Practitioner` account returns the nurse pool (not a 403, confirming it is
  correctly independent of `User`-doctype read); `assign_nursing_task` creates a submitted task in
  `Requested` with `user` = the chosen nurse and `owner` = the calling doctor, and rejects a non-nurse
  target with a 400 `VALIDATION_ERROR`; `update_nursing_task_status(..., "Completed")` on a task that
  never went `In Progress` now yields a small **positive** `task_duration` instead of a negative one;
  `get_my_tasks` returns the assignment on the nurse's feed with `assigned_by`/`assigned_by_full_name`
  populated.
- Migration verified on the same site: pre-migration state was 9 sibling groups / 16 open + 1 closed
  sibling row; post-migration, zero `reference_type="ToDo"` rows remain, the pre-existing
  `reference_type="Patient Encounter"` follow-up ToDos (7 of them) and `reference_type="Patient
  Appointment"` refund ToDos (2 of them) were confirmed untouched.
- Frontend: full `tsc --noEmit` and `eslint` passes on every changed file with zero new errors; `en.json`/
  `es.json` confirmed in exact key parity (216 `myWork` keys each) after the edit.

## References

- Constitution §4 Rules 1, 6, 10; §9 (ADR + patch requirement); §13 (frontend rules, i18n)
- ADR-020 (`docs/adr/adr-020-vaccine-nurse-administration-handoff.md`) — the doctor→nurse handoff
  pattern this generalises, and the precedent for using `owner` instead of a Custom Field
- `docs/audit/nurse/screens/11-nursing-tasks.md` finding NT3 — the fake status-action label this
  change removes
- Native doctypes: `Nursing Task` (`user`, `owner`, `task_doctype`/`task_document_name`,
  `on_update_after_submit`), `ToDo` (`allocated_to`, `assigned_by`, `reference_type`/`reference_name`),
  `Healthcare Activity`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-18 | Sarvesh | Initial version (header backfilled from git history) |
