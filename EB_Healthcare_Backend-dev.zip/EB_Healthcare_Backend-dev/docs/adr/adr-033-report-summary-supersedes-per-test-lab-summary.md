# ADR-033: The report summary supersedes the per-test lab summary — stored on the Lab Test, shared per report, with a saved chat

**Doc status:** living · **Created:** 2026-07-24 by Divyanshu · **Updated:** 2026-07-24 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-24
- **Supersedes:** the per-Lab-Test AI summary DISPLAY produced by `services/lab_result_summary.py::maybe_generate_summary` (the terse "All N results within normal range" line shown in the Lab Test detail popover). That per-test generation is retired as the user-facing summary. The patient-wide lab summary (ADR-029, `enqueue_patient_summary`) and the report-extraction summary (`generate_report_summary`/`preview_report_summary`, 2026-07-23) are unchanged in how they are produced.
- **Superseded by:** —

## Context

There are three lab AI summaries in the product:

1. **Per-test summary** — generated for each individual Lab Test by `maybe_generate_summary`, stored on that Lab Test in `custom_ai_summary` (JSON: `narrative` + `flags`), `custom_ai_summary_status`, `custom_ai_summary_generated_on`. Shown in the Lab Test detail popover.
2. **Report summary** — generated once per uploaded multi-panel report (`generate_report_summary`, prompt `lab_report_summary_v2.txt`): a richer narrative that explains the whole report (all panels), plus per-abnormal `flags` and every `items` row. Shown on the extraction "Review Results" screen. **Currently never persisted** — it disappears when the physician clicks Done.
3. **Patient-wide lab summary** — the "Lab Summary & Assistant" panel (ADR-029).

Product decision (2026-07-24): the terse per-test summary is redundant with, and weaker than, the report summary. A report that produces N Lab Tests (N panels) should show **one** summary — the report summary — on **every** one of those tests, replacing the per-test line. The physician also wants, on the Review screen, a **chat** to ask questions about the report, and to have that chat **saved and shown later on the tests**.

The two prior options considered and rejected for storage were a dedicated `AI Lab Report Summary` doctype and a per-Lab-Test link field. The user directed reusing the EXISTING per-test summary storage (`custom_ai_summary`) rather than adding a doctype or field.

## Decision

1. **The report summary becomes the Lab Test's summary.** On Done the frontend calls a dedicated whitelisted endpoint **`save_report_summary(lab_tests, summary, chat)`** (rather than threading the payload through `create_order_for_panel`), which writes the already-generated report summary payload (narrative + flags + items) plus the review-screen chat transcript into `custom_ai_summary` of **each Lab Test the report created** — the same content copied to all of them — with `custom_ai_summary_status = "Success"`. The JSON gains a `"source": "report"` marker and a `"chat": [{role, content}, ...]` array. No new doctype, no new field (ADR-authorised reuse of `custom_ai_summary`).

2. **The per-test summary generation is retired.** `maybe_generate_summary` no longer auto-generates the terse per-test summary on result writes. A Lab Test therefore has a populated `custom_ai_summary` only when it came from an AI report. A Lab Test entered by hand (no report) has an empty `custom_ai_summary` → the frontend shows a **"Not uploaded by AI"** badge instead of a summary. The patient-wide lab summary trigger (`enqueue_patient_summary`) is untouched.

3. **Report chat.** A new stateless whitelisted endpoint `ask_report_question(extraction, question, history)` answers questions scoped to the report's extracted values + summary, reusing the existing lab-chat LLM plumbing; the call is logged to `AI Prompt Log` (purpose, model, tokens — no PHI content, Rule 10). One conversation per report. The Review screen accumulates the transcript client-side and it is saved on Done (no extra LLM call at Done). **Post-Done the chat is read-only** on the Lab Test detail (history display only); continuing it from the test page (which would require syncing across the report's sibling tests) is deliberately out of scope for this pass.

4. **No new LLM cost at Done.** The report summary shown on the Review screen was already generated there; the Done handlers persist the payload passed from the client rather than regenerating. This is advisory content the physician just reviewed (Rule 6), so trusting the passed payload is acceptable; the generating call is already audited in `AI Prompt Log`.

## Alternatives Considered

1. **New `AI Lab Report Summary` doctype + a `custom_report_summary` link on Lab Test (single shared row per report).**
   - Pros: no content duplication; chat naturally shared/continuable across the report's tests.
   - Cons: a new doctype + custom field + migration; the user explicitly asked to reuse the existing per-test summary storage instead. Rejected on that direction.

2. **Reuse `custom_ai_summary`, copy per test (chosen).**
   - Pros: no schema change; the existing reader/popover already renders `custom_ai_summary`; simplest path.
   - Cons: the summary + chat are duplicated across the report's N tests; keeping a post-Done chat in sync across siblings would be awkward — which is why post-Done chat is read-only here.

3. **Keep the per-test summary and also show the report summary.**
   - Cons: two summaries per test is exactly the redundancy this removes; contradicts the "use the report summary in place of the per-test one" decision.

## Consequences

- **Code (backend, done 2026-07-24):** `api/ai/lab_result_summary.py` — new `save_report_summary(lab_tests, summary, chat)` (persist onto each of a report's Lab Tests) and `ask_report_question(report_params, question, history)` (stateless report-scoped chat, prompt `llm/prompts/report_chat_v1.txt`); `get_result_summary` now returns `source`/`items`/`chat`. `services/lab_result_summary.py` — `maybe_generate_summary` retired to a no-op (per-test generation stops); new `report_chat_context` helper. No doctype/field/migration change (reuses `custom_ai_summary`). Frontend (pending): chat UI under the Review-screen REPORT SUMMARY calling `ask_report_question`, and `save_report_summary` on Done with the created Lab Test names; Lab Test detail shows the report summary + read-only chat, or the "Not uploaded by AI" badge; bilingual strings.
- **Behavior:** every Lab Test from one report shows that report's summary + saved chat; hand-entered tests show a badge, not a summary. The terse per-test line is gone.
- **Data:** `custom_ai_summary` on report tests now holds the richer report payload with an inline `chat`; existing per-test summaries on old tests are left as-is (harmless; overwritten only if that test is re-finalized from a report).
- **Rule 10:** summary/chat CONTENT lives on the Lab Test (clinical record-adjacent), never in `AI Prompt Log`, which keeps only model/tokens/cost/prompt-hash.
- **Re-evaluation trigger:** if physicians need to CONTINUE the chat from the test page after Done, revisit a shared per-report store (Alternative 1) so sibling tests stay in sync rather than diverging.

## Verification

- New-patient, multi-panel report → Review shows one report summary + chat → Done → every created Lab Test's detail shows that same summary + saved chat.
- A hand-created Lab Test (results typed manually) shows the "Not uploaded by AI" badge, no summary.
- `AI Prompt Log` for the chat call carries model/tokens only, no message content.
- `ruff`/`mypy` clean on the backend; `tsc`/`eslint` + i18n parity clean on the frontend.

## References

- Rule 6 (advisory only, physician-reviewed, never a plan of care), Rule 10 (no PHI in logs).
- ADR-029 (AI Patient Clinical Summary — patient-wide lab + clinical summaries), the 2026-07-23 report-only summary split, ADR-022 (multi-panel extraction).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-24 | Sarvesh | Initial version (header backfilled from git history) |
