# ADR-090: Image observations say everything visible, and every finding is graded Clear or Possible

**Doc status:** living · **Created:** 2026-09-24 by Divyanshu (AI-assisted) · **Updated:** 2026-09-24 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — requested by Divyanshu, 2026-09-24, after a hand X-ray with displaced fractures was described as "tubular bones in a fan-like arrangement"
- **Amends:** [ADR-085](adr-085-image-observations-on-every-document.md) and [ADR-088](adr-088-images-read-from-what-they-show.md) — "describe, never diagnose" and "describe appearance, not condition" are replaced; [ADR-089](adr-089-body-site-needs-printed-evidence.md) decisions 4 and 5 — prose may name clearly recognisable anatomy, and the gate no longer rewrites it. ADR-089's stored-`body_site` gate is unchanged.

- **Prompt file:** `multi_panel_extraction_v18.txt` was removed 2026-09-24 at the owner's request (not kept in the repo); the live prompt is `multi_panel_extraction_v21` (ADR-091).
---

## 1. Context

A right-hand radiograph (printed text: "R", "LM", a "5 cm" scale bar, window/level settings)
shows displaced breaks in two central metacarpals. Prompt v17 returned:

> "multiple tubular bones in a fan-like arrangement arising from a cluster of small rounded
> bones … Notable: Alphanumeric side marker 'R' visible on image"

Three rules together produced that:

1. **v17 (ADR-089):** name an organ or part only when printed — so "metacarpal" became
   "tubular bone".
2. **v16 (ADR-088):** "describe appearance, not condition" — so "cortical break" and
   "displaced fragment" read as forbidden interpretation.
3. **`notable`** was never told to be filled by *looking*; it listed the marker.

The owner's direction was "do not restrict it". The ultrasound runs of 2026-09-23 are why this
ADR stops short of that: unrestricted, the same unlabelled image was called "kidney" (3 of 12)
and "fetal head" (1 of 8). The line drawn is between what is **clearly visible** and what is
**not**, not between restricted and unrestricted.

## 2. Decision

1. **Prompt `multi_panel_extraction_v18`:** name anatomy when printed **or clearly
   recognisable**; say plainly when it is not; **look for abnormalities actively** (breaks or
   steps in an outline, displacement, abnormal density, masses, fluid or air, foreign objects,
   asymmetry, something missing) and name them in a clinician's terms, with location.
2. **Every notable line is graded** `Clear:` or `Possible:`. Code enforces it
   (`integrations/llm.py::grade_image_findings`, run before the response is saved): an
   ungraded line becomes `Possible:`, never presented as certain.
3. **Still forbidden:** a final diagnosis, cause, prognosis, severity grade or management
   advice, and calling the whole image normal. A finding may not be graded surer than it looks.
4. The rules against adding findings now state that they apply to **the document's** content
   (transcription, parameters, template sections), not to `image_observations`.
5. **ADR-089's gate on the stored `body_site` stays** — the summary treats it as fact. The
   prose flag `names_unconfirmed_site` stays; the code-written note appended to the
   description is removed, since the prose now carries its own grading.

## 3. Options considered

| Approach | Pros | Cons |
|---|---|---|
| A. Remove all restrictions | Richest output | Brings back the measured wrong-organ guesses, stated as fact; nothing marks a guess |
| **B. Say everything visible, graded Clear/Possible (chosen)** | Names clear anatomy; looks for findings; uncertainty is visible per line; stored site still gated | Grading is only as honest as the model |
| C. Keep the rules, add "look for abnormalities" | Smallest change | The naming ban still blocks "metacarpal fracture" |
| D. Separate strict-observation and AI-impression sections | Cleanest separation | New schema field plus frontend and translations |

## 4. Verified — and what it shows

Live, v18, nothing saved (2026-09-24):

| | Result |
|---|---|
| Hand, gpt-5-mini default, 4 runs | anatomy and side named 4/4; fracture: **0 Clear**, 2 Possible (one on the wrong bone) |
| Hand, gpt-5-mini `reasoning_effort=high`, 3 runs | 2 Possible (3rd metacarpal); **1 run: "Possible: No obvious … displaced fracture identified"** |
| Hand, gpt-5, 2 runs | 1 run: "Clear: displaced midshaft fracture, 3rd metacarpal; Possible: 4th"; **1 run: no findings**; 155–166 s each |
| Ultrasound, gpt-5-mini default, 4 runs | stored site "not identified" 4/4; 3 runs neutral; **1 run: "consistent with a dilated collecting system", "Possible: cortical thinning"** |

**The prompt is no longer the limit; the model's reading is.** v18 removed the rules that hid
the fracture, but gpt-5-mini still misses it most of the time, and even gpt-5 missed it in one
of two runs. **AI image observations must not be relied on to find or exclude an abnormality.**
A "no fracture seen" style line is the worst output and is the next thing to prevent.

Tests: `tests/labs/test_image_findings_graded.py` (11); `test_body_site_gate.py` updated — both removed 2026-09-24 at the owner's request (not kept in the repo).

## 5. Open

- **False reassurance.** The model can write an absence ("no fracture identified") as a
  `Possible:` finding. v18 forbids calling the image normal as a whole but does not stop a
  per-structure absence claim.
- **Detection.** Whether a stronger vision model, a dedicated findings-only call, or both,
  reads reliably enough — needs a measured comparison on more than two images before any
  change of model or cost.
- **Printed scale and display settings** ("5 cm", W/L) were not transcribed in 0 of 4 runs.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-24 | Divyanshu (AI-assisted) | Recorded that its prompt file and tests were removed at the owner's request |
| 1.0 | 2026-09-24 | Divyanshu (AI-assisted) | Initial version |
