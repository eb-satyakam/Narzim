# ADR-020: Patient queue uses derived room state, not a phantom status

**Doc status:** record · **Created:** 2026-06-30 by Invincible · **Updated:** 2026-06-30 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-30
- **Supersedes:** —
- **Superseded by:** —

## Context

The standalone `/queue` (Nursing Room) page is broken: its "Waiting for Provider"
stage filters appointments whose frontend status equals `"Ready for Provider"`,
but the backend never emits that value. The appointment status map only produces
`Confirmed / Checked-in / Checked-out / Completed / Cancelled / No Show`
(`_STATUS_ERP_TO_FE` in `api/v1/appointments/api.py`), because native ERPNext
Patient Appointment has no "Ready for Provider" status — its options are
`Scheduled / Open / Confirmed / Checked In / Checked Out / Closed / Cancelled /
No Show`. So the stage is always empty and its "Start Encounter" button is
unreachable (verified live earlier: a checked-in patient lands in "Checked In"
with a "Record Vitals" button; "Waiting for Provider" stays at 0).

The root cause is two parallel state models:
- **`/queue`** filters a flat appointment `status` string — which cannot
  distinguish "checked in, with the nurse" from "ready for the provider" from
  "in the encounter", because all of those are the same native status
  (`Checked In`) plus/minus a clinical artifact.
- **The dashboard** (`get_dashboard_data` in `api/v1/dashboard/api.py`) already
  solves this by **deriving room placement** from real clinical artifacts, not
  status strings:
  - `arriving_soon` ← ERP `Open`
  - `waiting_room` ← ERP `Confirmed`, no encounter
  - `nursing_room` ← ERP `Checked In`, no encounter (carries the linked Vital Signs)
  - `practitioner_room` ← a **draft** Patient Encounter exists (carries encounter id)
  - `checkout` ← a **submitted** Patient Encounter exists
  Each row carries a code-derived `custom_status` and the relevant `vital_sign` /
  `encounter` ids.

This matches native ERPNext Healthcare, which has no "ready" sub-status — the
handoff is implied by clinical state (vitals taken, encounter opened), not a
workflow flag.

## Decision

Adopt **Option A — derive the handoff** (see ADR discussion). Point the `/queue`
page at the dashboard's already-derived room model instead of filtering
appointments by a status string.

1. `/queue` consumes `get_dashboard_data`'s room arrays (`arriving_soon`,
   `waiting_room`, `nursing_room`, `practitioner_room`, `checkout`) plus today's
   `no_show` set — the same source the dashboard mission-control queue uses. No
   new appointment status, no custom workflow field, no schema change.
2. The handoff is **derived from real artifacts**: recording vitals + opening the
   encounter advances the patient. A checked-in patient with no encounter sits in
   the nursing room; once a draft encounter exists (the doctor/nurse "move to
   practitioner" / "start encounter" action that creates it) the patient is in the
   practitioner room; a submitted encounter moves them to checkout.
3. The previously-inert **"Start Encounter"** action becomes reachable: from the
   nursing room a checked-in patient is moved to the practitioner (creates the
   draft encounter via `start_encounter`), and the practitioner-room row opens
   that encounter (`/encounters/{id}`) — mirroring the dashboard handlers.
4. No backend change is required; `get_dashboard_data` already returns everything.
   This ADR records the decision and the frontend rewire.

"Ready for Provider" is removed as a queue concept; it was never a real state.

## Alternatives Considered

1. **Derive the handoff — `/queue` consumes dashboard rooms (chosen, Option A).**
   - Pros: native-aligned (handoff implied by clinical artifacts, exactly how the
     dashboard already works); unifies the two queue implementations; zero schema
     change; fully upgrade-safe; frontend-only.
   - Cons: "ready" is inferred from vitals/encounter existence rather than an
     explicit nurse click; a clinic wanting an explicit "I'm done, hand off"
     gesture would need more.

2. **Add a real `Ready for Provider` sub-state (Option B).**
   - Pros: explicit, intentional handoff; supports "vitals done but not yet ready".
   - Cons: native Patient Encounter/Appointment has no such status; adding one
     means a custom field or customizing the core status Select (a second source
     of truth alongside native status), plus widening the nurse role's allowed
     statuses and migrations. More moving parts for marginal benefit; diverges
     from native.

3. **Leave `/queue` as-is.**
   - Cons: the stage stays permanently empty and the Start Encounter button stays
     unreachable — a visibly broken screen.

## Consequences

- **Frontend `src/app/(clinic)/queue/queue-client.tsx`** — rewired to fetch the
  dashboard data and render the derived rooms; status-string `STAGES`/`Ready for
  Provider` removed. Action handlers (check-in, record vitals, move-to-practitioner
  = start encounter, open encounter, collect payment) mirror the dashboard.
- **No backend change** — `get_dashboard_data` is the single source of truth for
  queue placement; the appointment status map is untouched.
- **The reverted ADR-018 queue "Start Encounter" wiring** can now land here in its
  correct, reachable form (practitioner-room → open encounter).
- **Re-evaluation trigger** — if a clinic requires an explicit nurse "mark ready"
  gesture distinct from recording vitals, revisit with Option B.

## Verification

- Live drive `/queue`: a checked-in patient appears in the nursing room with a
  vitals/move action; after the encounter is started they appear in the
  practitioner room with a working "Open encounter" that navigates to
  `/encounters/{id}`; a completed encounter shows in checkout. Confirm no
  permanently-empty "Waiting for Provider"/"Ready for Provider" stage remains.
- Cross-check counts against the dashboard mission-control queue for the same day
  (both now read `get_dashboard_data`).

## References

- Constitution §4 Rule 1 (upgrade-safe), §9 (ADR requirement)
- `api/v1/dashboard/api.py` `get_dashboard_data` (derived rooms) ·
  `api/v1/appointments/api.py` status maps
- ADR-018 (queue Start-Encounter wiring was reverted as inert pending this fix)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-30 | Sarvesh | Initial version (header backfilled from git history) |
