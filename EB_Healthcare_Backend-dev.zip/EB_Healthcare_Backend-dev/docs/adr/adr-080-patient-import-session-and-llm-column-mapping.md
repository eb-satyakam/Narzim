# ADR-080: A persisted `Patient Import Session`, with the LLM mapping column HEADERS only

**Doc status:** living · **Created:** 2026-09-23 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-24 by Anant Sharma (AI-assisted) · **Version:** 1.2

- **Status:** Accepted
- **Date:** 2026-09-23
- **Supersedes:** —
- **Superseded by:** —

## Context

The bulk patient import shipped 2026-09-22
([`docs/export-import/PATIENT_IMPORT_EXPORT.md`](../export-import/PATIENT_IMPORT_EXPORT.md)) assumes
the operator fills **our** template and that the whole import completes inside one HTTP request. The
real front-desk workflow breaks both assumptions.

**The reported workflow.** A front-desk user is handed a list of ~1000 patients by the clinic, as an
Excel file, a CSV or a Google Sheet, with whatever headers its author chose — in practice Spanish:
`Nombre`, `Apellido Paterno`, `Apellido Materno`, `Sexo`, `Fecha de Nacimiento`, `Celular`.

**Four things measured on `remedisys.localhost`, 2026-09-22/23:**

1. **A real Spanish file is refused outright.** `parse_upload()` matches only our machine column
   names or our English labels, so the whole file bounces with *"No recognised columns. Download the
   template and use its header row."* Frappe's own Data Import solves this with a column-mapping
   step; ours has none. This is the single reason the workflow does not work today.
2. **The row cap is 500** (`MAX_IMPORT_ROWS`), and the requirement is 1000.
3. **Preview costs ~8 ms/row steady state** — 10 rows 0.41 s, 50 rows 0.45 s, 200 rows 1.53 s — so
   1000 rows is 10–30 s once real surnames produce more duplicate candidates. Commit is far heavier:
   each row creates a Patient plus a guardian Contact plus an Address, so 1000 rows is minutes, not
   seconds. Neither fits in a request.
4. **`EB_Front Desk` holds `import = 0` on Patient**, so the role that has the workflow cannot
   perform it at all.

**Why the work has to survive the browser.** Reviewing 53 possible duplicates out of 1000 rows is not
a single sitting. A refresh, a session timeout or a closed laptop currently discards the upload, the
mapping and every skip/create decision. That is the requirement stated as *"between all process
save"*.

**What was considered and rejected first: Frappe's Data Import doctype.** It would give a background
job, a per-row import log and retry for free, and two objections raised against it early were wrong —
verified 2026-09-23: a plain `doc.insert()` **does** produce a correct `MRN-2026-…` name (the
doctype's `autoname` wins over the `naming_series` field default), and `uid` carries `unique = 1`, so
a duplicate CURP **is** rejected at the database level.

Two objections survive, and they are decisive:

- **It cannot satisfy the stated requirement.** The operator wants *"if the patient already exists,
  say so; if I say create, create it."* Data Import is fire-and-forget — it inserts or it errors.
  There is no pause, no per-row decision, no resume. The check that actually finds
  "Ana Torres Jiménez already exists" is `find_duplicate_candidates()` (name + date of birth), which
  Data Import never calls; the CURP unique index catches almost nothing here because **3 of 661
  patients carry a CURP**.
- **It bypasses `create_patient()`**, so no guardian Contact, no Address, no Dynamic Links, no
  `_validate_links`. Those exist only in the API wrapper.

## Decision

**1. Add a `Patient Import Session` doctype.** One row per import, owning the whole flow:

| Field | Holds |
|---|---|
| `state` | `uploaded → mapping → previewing → reviewing → committing → done / failed` |
| `source_type`, `source_file`, `source_url` | where the rows came from |
| `raw_rows` | the file as read, never modified — so re-mapping needs no re-upload |
| `column_mapping`, `date_format` | what the operator confirmed |
| `verdicts` | per-row validation result and duplicate candidates |
| `decisions` | per-row include / skip |
| `created_records`, `failures`, `progress` | filled in as the commit job runs |

`AI Encounter Session` is the precedent: a long-running, resumable, per-user process with a state
machine.

**2. The LLM maps column HEADERS ONLY.** One call per import, carrying the header row and our field
list — roughly ten column names. **No patient row is ever sent.** The response is schema-locked
against `column_spec()`, so it cannot name a field we do not have, and low-confidence columns come
back as a *question* rather than a guess. Every mapping is an editable dropdown the operator
confirms. Logged to `AI Prompt Log` (model, tokens, latency — no content).

**3. Values stay deterministic.** `Femenino → Female`, `Soltera → Single`, `o+ → O Positive` remain
alias-table work. The LLM does not touch them: the tables are certain, free, testable, and cannot
invent a value the doctype lacks.

**4. Date order is declared or proven, never inferred by the model.** The column is scanned — any
first component > 12 proves day-first — and the operator confirms. Where every day is ≤ 12 the file
genuinely does not say, and the operator is asked. **An LLM cannot recover information absent from
the file; it can only produce confident guesses**, and a wrong date of birth sets the age that drives
weight-based dosing and the immunization schedule.

**5. Preview and commit run as background jobs**, writing progress into the session. The 500-row cap
is raised to 2000 for the session path.

**6. `create_patient()` remains the only writer.**

## Alternatives considered

| Approach | Why not |
|---|---|
| **A.** LLM rewrites the whole file into our format, then Frappe Data Import inserts it | Sends 1000 patients' names, dates of birth and phone numbers to OpenAI to work out what a column means — the opposite of §9.9 PHI-6. Non-deterministic: the same file could import differently twice. And it still cannot ask "this one exists, create anyway?", so it fails the requirement it was proposed to satisfy |
| **B.** Manual column mapping only, no LLM | Works, and is the fallback if the LLM is unavailable — the dropdowns exist either way. Rejected as the *primary* path only because the operator would map ten columns by hand on every file, which is the friction this ADR exists to remove |
| **C. (chosen)** LLM maps headers, deterministic values, persisted session, background jobs | — |
| **D.** Keep everything in the browser (React state), no doctype | No ADR, no schema. But the entire flow is lost on refresh, which is the stated requirement; and 1000-row preview/commit cannot run in a request regardless |

**B is retained as the degraded mode**: if `get_llm_client()` fails, the mapping screen still opens
with nothing pre-filled and the import proceeds. AI failure must not break a clinical workflow
(Rule 7).

## Consequences

**PHI now exists in a second place, in flight.** `raw_rows` holds patient data before any Patient
record exists. Therefore:

- **Retention (§9.9 PHI-3).** A session is purged **7 days after reaching `done` or `failed`**, and
  immediately on operator request. The purge is a scheduled job shipped *with* the doctype — a
  declared retention period with no purge job is a false promise.
- **Erasure (§9.9 PHI-4).** Patient erasure must reach import sessions too. Sessions are indexed by
  the patient records they created; rows not yet committed are matched on the identifiers they carry.
- **Visibility.** A session is readable by its owner and by System Manager only. It is not shared
  team-wide — unlike Drive's trash, whose team-wide scope is a known open issue.
- **No PHI in logs (Rule 10).** `AI Prompt Log` records model, token counts and latency. Not headers,
  not rows.

**A new subprocessor interaction, within the existing register.** OpenAI is already named in the `mx`
profile (`llm_provider="openai"`), so PHI-1 is satisfied — and in any case the header row carries no
patient data, so this call discloses nothing about a patient.

**Front Desk gains `import` on Patient**, so the role with the workflow can perform it. Nurse does
not.

The grant goes in
[`patches/v0/eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json),
**not** in a standalone patch. This was learned the hard way on 2026-09-23: three grant patches were
written that set `Custom DocPerm` rows directly, and every one was silently undone by the next
`bench migrate`, because `patches.v0.rebuild_eb_role_permissions` reconciles every `EB_` role from
that spec. A permission set any other way does not survive. Verified across a migrate.

**What would falsify this decision.** If the header-only mapping proves too weak in practice — if
operators routinely have to correct it because column names alone are not enough — the next step is
sending a handful of sample values masked through `services/pii_redaction.py`, which is a new
disclosure and needs its own ADR. It is deliberately not authorised here.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-24 | Anant Sharma (AI-assisted) | Renumbered 075 -> 080 before merge: dev had already taken 075 for `adr-075-narzim-gpt-patient-aware-context`. Renumbered rather than superseded because this ADR had not yet landed, so it had no inbound links to break |
| 1.1 | 2026-09-23 | Anant Sharma (AI-assisted) | Permission grants recorded as an `eb_docperm_spec.json` change — standalone grant patches do not survive `bench migrate` |
| 1.0 | 2026-09-23 | Anant Sharma (AI-assisted) | Initial version |
