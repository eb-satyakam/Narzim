# ADR-119: A rounding residue of 0.05 or less is neither a debt nor a waiver

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

The refund plan treats up to 0.05 still owing as paid (`_SETTLEMENT_TOLERANCE`). The refund step
(`create_credit_note`) refuses anything above 0. A bill short by a few centavos is therefore
offered for refund and then refused, and the all-or-nothing appointment refund rolls back.

`create_credit_note` also books any gap between the Credit Note and the cash paid back as a
reversed waiver, to the write-off account, from 0.000001 up. That includes a rounding gap on a
bill that was never waived. Analysis: [design note](../flows/BILLING_ROUNDING_RESIDUE.md).

## Decision

Treat a residue of `_SETTLEMENT_TOLERANCE` (0.05) or less as rounding, the same in every refund
step:

1. A refund of a bill still owing ≤ 0.05 goes through. Its Credit Note withdraws the residue
   from the bill first (`_withdraw_own_balance`, ADR-117), so the bill ends at 0. The plan shows
   the residue as `balance_withdrawn`.
2. A gap of ≤ 0.05 between a Credit Note and the cash paid back is booked as a waiver reversal
   only when the bill carries a waiver write-off. Otherwise nothing is booked.

## Alternatives Considered

1. **Make the plan strict too (block at > 0).**
   - Pros: one rule, and no money logic changes.
   - Cons: the refund is still impossible. The front desk would have to collect 0.03 from a patient
     who is owed a refund. It moves the stuck case to a dead end rather than fixing it.

2. **Treat ≤ 0.05 as rounding everywhere, and withdraw it (chosen).**
   - Pros: plan and step agree, and the bill ends at 0. It reuses ADR-117's withdrawal, so there is
     no new accounting primitive. No false entries in the waiver register.
   - Cons: up to 0.05 per bill is forgiven without a ledger line of its own (it shows as
     `balance_withdrawn` on the Credit Note).

3. **Collect the residue automatically** (a 0.03 Payment Entry) **before refunding.**
   - Pros: the bill is paid in full on paper.
   - Cons: it records money nobody handed over (PHI-5's spirit applied to money). It also needs a
     tender for 0.03.

4. **Write the residue off through the write-off account.**
   - Pros: an explicit ledger line.
   - Cons: it is exactly the false "waiver" this ADR removes. It would mix rounding into the waiver
     register.

## Consequences

- **Code:**
  - `services/billing.py::create_credit_note` accepts outstanding ≤ 0.05, withdraws it, and books
    a reversal only on a waived bill (`_has_write_off`).
  - `appointment_refund_plan` reports the residue as `balance_withdrawn`.
- **Tests:** new `tests/billing/test_rounding_residue.py`.
- **Not covered:** the reschedule line replacement's own ≤ 0.05 residue (design note §4).

## Verification

`tests/billing/test_rounding_residue.py` fails on the code before this ADR and passes after. The
reschedule and billing suites fail only where `dev` already fails.

## References

- [Design note](../flows/BILLING_ROUNDING_RESIDUE.md).
- [ADR-117](adr-117-replace-the-line-when-the-invoice-has-a-balance.md): the balance withdrawal reused here.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted by the product owner ("go ahead") |
