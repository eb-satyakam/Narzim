# ADR-016: Per-clinic internal/external fulfillment for pharmacy (and lab, therapy, procedures)

**Doc status:** living · **Created:** 2026-06-23 by Anant Sharma · **Updated:** 2026-06-23 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-23
- **Supersedes:** —
- **Superseded by:** —

## Context

A clinic either runs an in-house pharmacy or it does not. The two cases have
materially different operational and accounting needs:

- **In-house pharmacy (internal).** The clinic dispenses the drug it prescribes.
  It must hold stock (batch, expiry, warehouse), sell the drug to the patient,
  and book the revenue. This is a retail/POS transaction layered on top of the
  clinical prescription.
- **No pharmacy (external).** The clinic only prescribes. The patient fills the
  prescription at an outside pharmacy. The clinic holds no stock, raises no
  drug Sales Invoice, and books no drug revenue — the prescription document is
  the entire deliverable.

The same split applies to **lab/diagnostics**, **therapy/rehabilitation**, and
**procedure rooms**: a clinic may perform these in-house (direct fulfillment,
billable) or refer the patient out (external referral, not billed here).

Constraints that shape the decision:

- **Rule 1 (upgrade-safe)** and **Section 11** forbid modifying ERPNext
  Healthcare core. Medication/prescription/stock/selling doctypes are core; we
  may only add custom fields, hooks, and whitelisted methods.
- **Rule 1 / API pattern (Section 3):** all data access goes through
  `api/v1/<module>/api.py` whitelisted methods, never `/api/resource/`.
- Clinics in the pilot are single-tenant per Company; the platform is
  multi-clinic, so the choice must be **per Company**, not global.
- A clinic can transition (open a pharmacy later). Historical orders raised
  while external must not retroactively appear in the new internal pharmacy
  queue.

## Decision

Model fulfillment as a **per-Company capability flag**, defaulting to external,
and tag every clinical order with the channel that was in force when it was
raised. Do **not** branch the clinical workflow itself — only what happens
downstream of the order.

1. **Settings doctype.** `EB Clinic Settings` (one row per Company) holds the
   boolean facility flags, all defaulting to `0` (external):
   `has_internal_pharmacy`, `has_internal_lab`, `has_internal_therapy`,
   `has_internal_procedures`. `get_clinic_settings(company)` returns the saved
   row or a safe **all-external** default dict, so no caller handles `None`.

2. **Settings API.** `api/v1/admin/settings.py` exposes `get_clinic_settings`
   and `update_clinic_settings` (permission-checked, per Company). The frontend
   Settings → Facilities section reads and patches these flags.

3. **Channel tagging at submit.** On Patient Encounter `on_submit`,
   `overrides/encounter_orders.on_encounter_submit` reads the encounter
   company's settings and tags each generated order:
   - **Medication Request** → custom field `custom_order_channel` =
     `Internal` | `External`.
   - **Service Request** (lab / procedure / therapy) → core `source` =
     `Direct` | `External Referral`.
   Tagging is at-creation, so a clinic that later flips a flag only sees orders
   raised *after* the transition in its internal queue.

4. **Internal fulfillment = POS, not encounter billing.** When
   `has_internal_pharmacy` is on, drug dispensing and revenue run through a
   **Pharmacy Counter POS Profile** against a **Walk-In Customer**, billing the
   drug's sellable/stock ERPNext `Item`. The drug is **never** a line on the
   encounter/consultation invoice. Setup is scripted
   (`scripts/seed/seed_pharmacy_stock.py` makes drug Items stock+sellable;
   `scripts/setup_walkin_customer.py` wires the POS profile).

5. **External = clinical record only.** When the flag is off, the prescription
   exists purely as the Medication Request / printed Rx. No `Item` stock flags,
   no Item Price, no Sales Invoice, no stock ledger movement.

6. **The Medication master is identical in both modes.** Internal vs external
   does not change the formulary (`Medication` doctype) or the act of
   prescribing inside an encounter. It changes only (a) the order's channel tag
   and (b) whether a downstream POS/stock setup exists for that drug's `Item`.

## Alternatives Considered

1. **Per-medication internal/external flag.**
   - Pros: a clinic could stock some drugs and refer others.
   - Cons: explodes configuration surface (every drug needs a decision),
     easy to misconfigure, and does not match the real-world unit of the
     decision — a clinic has a pharmacy or it doesn't. Rejected; revisit only
     if a pilot clinic genuinely needs a partial formulary.

2. **Per-clinic capability flag with at-submit channel tagging (chosen).**
   - Pros: matches reality (one decision per clinic); single branch point;
     safe external default needs zero setup to start prescribing; historical
     orders keep their original channel; clinical workflow stays identical.
   - Cons: a clinic with a genuinely mixed model is not expressible without a
     later per-medication override.

3. **Bill the drug on the encounter/consultation invoice when internal.**
   - Pros: one invoice per visit.
   - Cons: conflates clinical billing with retail pharmacy accounting (stock
     valuation, batch/expiry, separate revenue account, walk-in buyers who are
     not the patient). Forces the encounter-billing path to grow stock logic it
     should not own. Rejected in favor of a dedicated POS lane.

## Consequences

- **Constitution:** Section 3 (locked assumptions) gains an implicit
  "fulfillment is a per-Company capability" note; Phase 3 billing scope is
  clarified — drug revenue is POS, not encounter-invoice.
- **Code already in force:** `EB Clinic Settings` doctype + controller,
  `api/v1/admin/settings.py`, `overrides/encounter_orders.py` (wired in
  `hooks.py` as Patient Encounter `on_submit`), custom field
  `Medication Request-custom_order_channel`, and the two setup scripts.
- **Follow-up (this change):** the admin **Medications** screen CRUD is wired
  to Frappe standard `/api/resource` insert (`standardCrud: true`), which both
  violates the API-pattern rule and **fails** because it cannot satisfy the
  `Medication` doctype's mandatory fields (`medication_class`, `strength_uom`).
  It must route through the whitelisted `create/update/delete_medication`
  methods in `api/v1/admin/catalog.py`. Tracked as the frontend fix accompanying
  this ADR.
- **Re-evaluation triggers:** a pilot clinic needing a partial (mixed)
  formulary → reconsider alternative 1; a requirement to bill drugs on the
  visit invoice → reconsider alternative 3.

## Verification

- `get_clinic_settings("<Company>")` returns the flags; an unconfigured company
  returns the all-external default.
- Submitting an encounter with a drug at a clinic with `has_internal_pharmacy=0`
  produces a Medication Request with `custom_order_channel = "External"`; with
  the flag on, `"Internal"`.
- A medication created via the admin Medications screen persists (post-fix)
  through `api.v1.admin.catalog.create_medication`, not `/api/resource`.
- Internal-pharmacy revenue appears on a POS Sales Invoice against the Walk-In
  Customer, never on the encounter invoice.

## References

- Constitution Sections 1, 3 (API pattern), 4 (Rule 1), 11 (Hard Don'ts)
- ADR-012 (appointment payment orchestration) — billing boundaries
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/eb_clinic_settings/`
- `remedisys_healthcare_ai/overrides/encounter_orders.py`
- `remedisys_healthcare_ai/api/v1/admin/settings.py`,
  `remedisys_healthcare_ai/api/v1/admin/catalog.py`
- `remedisys_healthcare_ai/scripts/seed/seed_pharmacy_stock.py`,
  `remedisys_healthcare_ai/scripts/setup_walkin_customer.py`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-23 | Sarvesh | Initial version (header backfilled from git history) |
