# ADR-065: Explicit permission before any repo change, and a doc + ADR before non-trivial work

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-22
- **Supersedes:** —
- **Superseded by:** —

## Context

Earlier in this same session, Claude resolved a `git stash pop` conflict in
`remedisys_healthcare_ai/api/v1/providers/api.py` autonomously — investigating,
editing, staging, and (attempted) dropping the stash — narrating the steps but
never pausing for a go-ahead before any of them landed. That is the default
behavior under this environment's "Auto Mode": bias toward acting, and only
stop when genuinely blocked.

divyanshu then asked for a standing personal rule: no change to code or git
state without explicit permission, and a markdown doc plus an ADR written
before work starts on anything "each and everything." Three points were
ambiguous enough to need a decision, not an assumption:

1. **Scope** — a personal preference that should follow divyanshu into any
   repo, a rule scoped to this repo alone (so any other engineer or agent
   working here is also bound by it), or both.
2. **Granularity** — whether "ask before changing anything" means a pause
   before every single tool call, or a single plan confirmed once per task
   and then carried out.
3. **MD/ADR trigger** — whether "each and everything" overrides
   `CLAUDE.md` §10's existing carve-out that a trivial one-line fix can skip
   the four-approaches/ADR ceremony, or sits on top of it.

These were put to divyanshu directly (`AskUserQuestion`, 2026-09-22) rather
than guessed, because each answer implies a different, hard-to-undo working
pattern, and `CLAUDE.md` §10 itself requires exactly this kind of decision to
be made deliberately rather than defaulted into.

## Decision

Adopt, effective immediately, for this repo and as Claude's standing personal
working preference with divyanshu across any project:

1. **No `Edit`/`Write`/`NotebookEdit` and no state-changing git or shell
   command** (`commit`, `push`, `merge`, `rebase`, `stash drop`, `reset`,
   branch deletion, etc.) **runs without divyanshu's explicit go-ahead**,
   given after Claude states the plan — files touched, doctypes/endpoints/
   hooks involved, and the exact git actions — **once per task**. Approval is
   not re-requested for each individual step inside an already-approved task,
   unless the work drifts outside the stated scope. Read-only investigation
   (`Read`, `Grep`, `git status`/`log`/`diff`, etc.) is exempt — it has no
   blast radius to approve.
2. **Before implementation starts on any non-trivial task**, a short MD
   design/context doc (in the relevant `docs/` subfolder) and an ADR (in
   `docs/adr/`, per `CLAUDE.md` §9) exist first. "Non-trivial" is the same
   line `CLAUDE.md` §10 already draws for its four-approaches rule — a typo
   or an obvious one-line fix is still exempt from the MD/ADR requirement,
   but is **not** exempt from rule 1 above.

Recorded in `CLAUDE.md` §10 (v3.2 → v3.3) so it binds any engineer or agent
working in this repo, not only this session, and in
`docs/planning/CLAUDE_PERMISSION_POLICY.md` as the fuller WHAT/WHY/HOW/WHEN
account, and saved to Claude's own persistent memory as a cross-project
preference so it survives outside this repo too.

## Alternatives Considered

1. **Confirm every individual action**, not once per task.
   - Pros: zero ambiguity about what's approved; nothing at all happens
     without a fresh yes.
   - Cons: turns any multi-file task into dozens of sequential prompts,
     destroying most of the value of an agent that can carry out an approved
     plan unattended; divyanshu explicitly rejected this granularity when
     asked directly.

2. **Enforce at the tool/settings layer** (reconfigure Claude Code's
   permission mode so edits and git commands always require approval),
   instead of a documented convention.
   - Pros: mechanically enforced — can't be forgotten or silently drift, the
     way a purely narrative rule can.
   - Cons: a blunt instrument — it cannot distinguish "read-only, harmless"
     from "about to git push," doesn't capture the *reasoning* in writing the
     way an ADR does, and divyanshu asked for a working agreement plus a
     paper trail, not only a permission toggle. (Still a reasonable follow-up
     — see Consequences.)

3. **Repo-only rule, no personal memory.**
   - Pros: single source of truth in `CLAUDE.md`, visible to every
     collaborator without needing to know it also lives in Claude's memory.
   - Cons: would not follow divyanshu into any other repo or project, which
     is explicitly part of what was asked for.

4. **Personal-memory-only, no `CLAUDE.md` change.**
   - Pros: fastest to set up, no churn to a shared, checked-in document.
   - Cons: invisible to any other engineer or agent working in this repo —
     `CLAUDE.md`'s own preamble calls itself "the operating contract between
     you (Claude) and the engineering team," and a rule this consequential
     (nothing changes without sign-off) belongs where the team can see it,
     not only in one person's private assistant memory.

5. **Both — repo rule in `CLAUDE.md` + personal memory; once-per-task
   granularity; MD/ADR required for non-trivial work only (chosen).**
   - Pros: binds the repo for anyone, follows divyanshu everywhere else,
     keeps agent work usably fast within an approved task, and preserves
     `CLAUDE.md` §10's already-considered trivial/consequential line instead
     of relitigating it.
   - Cons: two places to keep in sync (`CLAUDE.md` and memory) — mitigated by
     each naming the other and this ADR being the single decision record
     both point back to.

## Consequences

- `CLAUDE.md` §10 gains a new hard rule (v3.2 → v3.3, revision history
  updated).
- `docs/planning/CLAUDE_PERMISSION_POLICY.md` created as the companion MD doc.
- Every future non-trivial task in this repo requires an MD doc + ADR before
  implementation begins — this itself is the first instance of that pattern
  being followed.
- No `Edit`/`Write`/`NotebookEdit` or state-changing git/shell command
  proceeds in any future session without a stated plan and an explicit
  go-ahead, once per task.
- Claude's persistent memory now carries this as a `feedback`-type entry,
  applied across any repo, not only this one.
- **Re-evaluation trigger:** if once-per-task granularity proves too coarse in
  practice (an approved task drifts materially from what was described, more
  than once), or the MD+ADR requirement goes unfollowed the way `CLAUDE.md`
  §9 itself warns a documented-but-unchecked rule tends to ("a rule nothing
  checks is not a rule"), revisit — likely toward Alternative 2 (tool-layer
  enforcement) as a backstop rather than a replacement.

## Verification

- This ADR's existence, `CLAUDE.md` §10's diff, and
  `docs/planning/CLAUDE_PERMISSION_POLICY.md` are the concrete artifacts.
- `scripts/check_adr_numbering.py` and `scripts/check_md_headers.py` (CI
  gates already in place per `CLAUDE.md` §9) cover this ADR and MD doc the
  same as any other.
- The permission-before-changes half is a behavioral rule for Claude, not a
  property of the code, so no CI gate enforces it directly today — the
  re-evaluation trigger above names the fallback if that turns out to matter.

## References

- `CLAUDE.md` §9 (ADR rule, provenance headers)
- `CLAUDE.md` §10 (four-approaches rule, trivial-task exception)
- `docs/planning/CLAUDE_PERMISSION_POLICY.md`
- This session's transcript, 2026-09-22 — the `git stash pop` conflict
  resolution in `remedisys_healthcare_ai/api/v1/providers/api.py` that
  prompted the request

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu | Initial version |
