# ADR-NNN: <Short imperative title>

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-05-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed | Accepted | Superseded | Deprecated
- **Date:** YYYY-MM-DD
- **Supersedes:** ADR-NNN (or section of a doc), or —
- **Superseded by:** ADR-NNN, or —

## Context

What is the situation that forces this decision? What constraints, prior
decisions, or facts about the system shape the choice? Cite the constitution
sections, prior ADRs, or external requirements (compliance, vendor terms,
team size) that matter. Keep it factual — no speculation about future state.

## Decision

What was decided. Stated as imperative ("Lock to X", "Use Y for Z", "Suspend
rule N"). One paragraph, then a numbered list of concrete consequences if
needed. The reader should be able to follow this section alone and implement
the decision.

## Alternatives Considered

Each alternative gets a short paragraph with explicit **Pros** and **Cons**.
The chosen alternative is also listed here for symmetry — pretend you're
arguing for each one in turn. Three is usually the right number; two means
you didn't think hard enough; five means you're over-scoping.

1. **Alternative A.**
   - Pros: …
   - Cons: …

2. **Alternative B (chosen).**
   - Pros: …
   - Cons: …

3. **Alternative C.**
   - Pros: …
   - Cons: …

## Consequences

What changes downstream because of this decision. Be specific:

- Constitution sections amended.
- Other ADRs superseded.
- Code/files that need to be written or removed.
- Operational implications (CI gates, on-call rotation, cost model).
- Re-evaluation triggers — what observable conditions would force us to
  revisit this ADR.

## Verification

How will we know the decision is in force? List the concrete artifacts that
prove it: a CI check, a config file, a deployed environment, a test result.

## References

- Constitution section X
- Prior ADR-NNN
- External link (vendor docs, RFC, paper)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
