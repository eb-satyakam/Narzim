# ADR-042: Government payment mode is a deferred receivable, not a waiver

**Doc status:** living · **Created:** 2026-08-20 by Divyanshu · **Updated:** 2026-08-21 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — implemented in `2f54f95` ("feat: Implement government deferred receivable
  billing mechanism"), verified live (see `WORK_LOG.md`'s 2026-08-20 entry), shipped ahead of this
  ADR's own header ever being updated to say so — flipped from Proposed on 2026-08-21.
- **Date:** 2026-08-20
- **Supersedes:** the undocumented "Government waiver" design shipped 2026-07-18 (never written up as an ADR — see `docs/ai/DECISION_LOG.md`-style gap; captured only in session memory as "Government/waiver payment mode produces a fully-waived (0-value) Sales Invoice"). This ADR is the first formal record of the mechanism and corrects it.
- **Superseded by:** —

## Context

"Government" is a real ERPNext **Mode of Payment** (type General, enabled) used
when a patient's visit is covered by a government scheme: the **patient pays
nothing**. The mode was added 2026-07-18 and implemented as a full **waiver**:

- At invoice creation (`create_invoice_from_appointment`, `services/billing.py:183`),
  selecting Government applies a 100% Grand-Total discount
  (`_apply_waiver`, `billing.py:100`) — the invoice submits at **grand_total = 0**.
- At Collect Payment on an already-submitted invoice (`settle_invoice`,
  `billing.py:432`), selecting Government instead **writes off the full
  outstanding via a Journal Entry** (`_write_off_invoice`, `billing.py:116`) —
  debiting the invoice's receivable account and crediting the Company's
  `write_off_account`. No Payment Entry is ever created either way.
- `invoice_and_settle` (`billing.py:504`, the appointment Pay-Now orchestrator)
  skips real settlement whenever `_is_waiver_mode(mode_of_payment)` is true.

This treats "Government" as **nobody ever pays** — economically identical to
a 100%-off promotional discount. That is wrong. The actual requirement is:
the clinic still delivers billable value and is still owed the full amount —
just by a different payer (the government scheme) instead of the patient,
and typically **on a delay** (the clinic bills now, reimbursement arrives
later — no different in kind from how the existing, partial Insurance flow
defers patient-vs-payor collection). A 100% discount or a write-off both
erase that receivable from the books entirely, which understates revenue and
makes it impossible to track what the government actually owes the clinic.

**This is live in production, not hypothetical.** As of 2026-08-20 there are
already 6 submitted Sales Invoices carrying the `"Waived — Government
scheme (100% discount)"` remark, and 3 corresponding write-off Journal
Entries:

| Invoice | grand_total | Path used | Status |
|---|---|---|---|
| ACC-SINV-2026-00101 | 0.00 | create-time discount | Paid |
| ACC-SINV-2026-00144 | 0.00 | create-time discount | Paid |
| ACC-SINV-2026-00147 | 4,320.00 | collect-time write-off (ACC-JV-2026-00055/-00054 range) | Paid |
| ACC-SINV-2026-00148 | 580.00 | collect-time write-off | Paid |
| ACC-SINV-2026-00149 | 870.00 | collect-time write-off | Paid |
| ACC-SINV-2026-00150 | 7,076.00 | collect-time write-off (ACC-JV-2026-00056) | Credit Note Issued |

Front desk is already using the collect-time write-off path on real,
non-trivial invoice amounts (4,320 / 7,076 MXN) — confirming this isn't an
edge case, it's the normal flow for a government-scheme patient today, and
it is currently erasing real receivables from the books.

## Decision

**Government (and any mode listed in the existing deferred-payer set) bills
the full, undiscounted amount and is never auto-settled. Settlement happens
later, exactly like any other Mode of Payment, when the reimbursement is
actually received.**

Concretely:

1. **No discount, ever.** Delete `_apply_waiver` and every call to it
   (`billing.py:1935, 2460, 2576, 3009` — the four non-appointment builders —
   and the `_is_waiver_mode` branch in `create_invoice_from_appointment`,
   `billing.py:218`). A Government-billed invoice submits at its real
   `grand_total`, identical to a Cash/Card invoice.
2. **No forced write-off, ever.** Delete `_write_off_invoice`
   (`billing.py:116`) and its call site in `settle_invoice`
   (`billing.py:473-474`). Selecting Government at Collect Payment becomes a
   **normal settlement**: it flows through the same `get_payment_entry` /
   `pe.mode_of_payment = mode_of_payment` path every other mode uses
   (`billing.py:486-500`), posting to whatever GL account is configured on
   `Mode of Payment Account` for "Government" (recommend a dedicated
   "Government Receivable — Clearing" account, not a P&L write-off account).
   This is the point at which an actual government reimbursement gets
   recorded — a real Payment Entry, for whatever amount actually arrived
   (full or partial, cash or bank).
3. **Never auto-settle at booking/invoicing time.** The one behavior that
   *does* stay special-cased: `invoice_and_settle` (`billing.py:504`, the
   appointment Pay-Now path) and the four invoice builders must skip calling
   `settle_invoice` when the mode is a deferred-payer mode — nothing is
   collected at the moment of billing, by construction. This is the only
   place "Government" still needs an `if` branch anywhere in `billing.py`.
   - `invoice_and_settle` currently only blanks the appointment's own
     `mode_of_payment`/`paid_amount` fields before invoicing `if not
     is_waiver` (`billing.py:554`) — that blanking (which forces a clean,
     tax-correct, non-POS invoice instead of core's raw-pre-tax POS
     shortcut) must now happen **unconditionally**, including for
     Government, since Government invoices need the same correct-tax
     treatment as a real payment. Only the *settle* step
     (`billing.py:590-593`) stays conditional on "was this a deferred mode".
   - The return contract changes for a deferred booking: today a waived
     booking returns `{"payment_status": "Paid", "outstanding": 0}` — which
     was internally honest only because grand_total was 0. With a real
     grand_total this becomes a lie. It must instead return something like
     `{"payment_status": "Billed", "outstanding": payable}` (exact status
     string is an implementation choice — must not collide with ERPNext's
     own Sales Invoice `status` values; "Unpaid"/"Overdue" already mean
     something specific in core) so callers see the true, uncollected
     balance.
4. **Rename away from "waiver" terminology** so the code doesn't keep lying
   about what it does:
   - `_waiver_modes()` → `_deferred_payer_modes()`
   - `_is_waiver_mode()` / public `is_waiver_mode()` (re-exported from
     `api/v1/billing/api.py:79-83`, consumed at `billing/api.py:837`) →
     `_is_deferred_payer_mode()` / `is_deferred_payer_mode()`
   - `_waiver_remark()` / `waiver_mode_from_remarks()` / `_WAIVER_REMARK_RE`
     → `_deferred_payer_remark()` / `deferred_payer_from_remarks()` /
     a renamed regex, with **new wording** that doesn't say "discount" or
     "waived" (e.g. `"Billed to {mode} — deferred, awaiting reimbursement"`).
   - **Keep the `site_config` key name `remedisys_waiver_payment_modes`
     unchanged.** Renaming it would require an operational site_config edit
     on Frappe Cloud (ADR-005) with no code-side benefit — internal
     identifiers can be renamed for free, a deployed config key cannot.
5. **Legacy remark compatibility — do not touch existing rows.** The 6
   invoices and 3 Journal Entries listed above keep their original
   `"Waived — Government scheme (100% discount)"` remark text and their
   already-posted GL entries exactly as they are. No backfill, no
   reissue/re-credit-note migration. The renamed
   `deferred_payer_from_remarks()` helper must match **both** the new
   remark pattern and the legacy `"Waived — (.+?) scheme \(100% discount\)"`
   pattern, so the invoice list's Payment-Method fallback column keeps
   working for these historical rows.
6. **Frontend — delete the special-casing, don't add more of it**, except in
   one place:
   - `components/billing/collect-payment-dialog.tsx` (`isWaiverMethod`
     L45-46, `isWaiver`/`effectivePayType` L93-94, forced-full L170, the red
     `t("collectWaived")` label L195-196) — **remove entirely.** Once
     `settle_invoice` no longer write-offs, Collect Payment via Government
     is indistinguishable from Cash/Card/Bank: a real amount field, real
     partial-payment support, real reference-number rules by mode `type`.
   - `components/narzim/dashboard/new-appointment-dialog.tsx` — this is the
     **one surviving special case**, because "Pay Now" is misleading when
     Government is selected (nothing is paid by anyone today). Keep
     `isWaiverMethod` (`L909`) only to drive copy: when it's true, the
     Payment summary (`L2552`) must not silently show `Total: {fee} MXN` /
     `Pay now via Government` as if cash changes hands — it needs to say
     the total is **billed to the government, not collected today** (exact
     copy is a product-copy decision, not this ADR's call — flagging the
     requirement, not the wording).

## Alternatives Considered

1. **Instant settle** — bill full amount, immediately create a real Payment
   Entry with `mode_of_payment="Government"`, same as Cash/Card, assuming
   the clinic already has a pre-funded arrangement with the scheme.
   - Pros: simplest possible change (delete the discount/write-off code,
     delete the "skip settle" branch too — Government becomes a zero-special-case
     mode).
   - Cons: does not match reality described by the user — the clinic does
     **not** have the money in hand at the moment of billing; recording it
     as instantly "Paid" would make AR aging and cash-position reporting
     wrong in the opposite direction (looks collected when it isn't).

2. **Deferred receivable (chosen).** See Decision above.
   - Pros: matches the actual cash-flow reality (bill now, collect later);
     reuses 100% of the existing Sales Invoice / Payment Entry / Mode of
     Payment machinery — no new doctype; smallest safe change from the
     current (broken) implementation; makes the government's outstanding
     balance visible in the exact same AR aging report used for everyone
     else, for free.
   - Cons: "Government" still needs the one special "don't auto-settle at
     invoice time" branch — not a fully generic Mode of Payment. The
     invoice list has no distinct visual marker for "outstanding because of
     a normal unpaid patient" vs. "outstanding because it's deferred to the
     government" beyond the remark text (acceptable per the existing
     no-new-field convention, but worth a follow-up if reporting needs to
     filter on it directly rather than via a `LIKE` on remarks).

3. **Full payor/claim model** — a real `Government Payor` doctype mirroring
   `Insurance Payor`/`Patient Insurance Policy`, with claim-status tracking
   (Submitted → Approved → Paid), reusing/extending the Phase 3 insurance
   machinery (`_create_insured_invoice`, `billing.py:258`).
   - Pros: the eventually-correct model if government billing grows real
     claim-lifecycle needs (rejections, partial approvals, resubmission) —
     matches how Insurance already works.
   - Cons: large scope (new doctype(s), claim UI, reconciliation reporting)
     for a requirement that today is just "don't erase the receivable"; the
     existing Insurance module itself is still Phase 3 **partial**
     (§12 of the constitution) — building a second claims system in parallel
     is premature. Revisit if/when a real reimbursement-claim workflow
     (submission batches, rejection handling) is actually needed.

## Consequences

- **Files to change** (implementation, not part of this ADR):
  `services/billing.py` (all six items in Decision §1–5),
  `api/v1/billing/api.py:79-83,837` (rename passthrough),
  `components/billing/collect-payment-dialog.tsx` (delete waiver special-case),
  `components/narzim/dashboard/new-appointment-dialog.tsx` (replace the
  false "Total ... Pay now" copy with deferred-billing copy for Government).
- **No doctype, no migration patch, no site_config change.** Pure behavior
  change inside existing functions.
- **AR aging / outstanding-balance reports** (Phase 4, `get_outstanding_balances`
  once built) will start showing Government-billed invoices as real
  outstanding receivables going forward — this is the intended fix, not a
  side effect to guard against, but anyone building that report should know
  a `remarks LIKE '%Billed to%'` (or the new marker) filter is how "expected
  from government" gets separated from "patient just hasn't paid".
- **The 6 existing invoices / 3 journal entries are frozen as legacy.** They
  are not reissued, not re-credited, not backfilled. `deferred_payer_from_remarks()`
  must recognize their old wording so the invoice list doesn't regress for them.
- **Re-evaluation trigger:** if the government scheme introduces a real
  claims process (batched submission, rejection/resubmission, partial
  approval percentages), revisit Alternative 3 — at that point "Government"
  stops being a Mode of Payment and becomes a Payor.

## Verification

- Bench console smoke test (mirrors the original 2026-07-18 manual
  verification style — no automated test suite for this path yet, matching
  prior practice): book/invoice an appointment with `mode_of_payment=
  "Government"` and assert:
  - `Sales Invoice.grand_total` equals the real, undiscounted fee (not 0).
  - `Sales Invoice.outstanding_amount` equals `grand_total` (nothing
    collected) immediately after creation.
  - No Payment Entry exists against that invoice yet.
  - `invoice_and_settle`'s return payload reports the true outstanding, not
    a fabricated `"Paid"/0`.
  - A subsequent `settle_invoice(invoice, amount, "Government")` call
    creates a normal, submitted Payment Entry (not a Journal Entry) and
    reduces `outstanding_amount` accordingly, for a **partial** amount too
    (proving it's no longer all-or-nothing).
- Grep confirms zero remaining references to `_apply_waiver` and
  `_write_off_invoice` in `services/billing.py`.
- The 6 legacy invoices still render a "Government" Payment Method in the
  invoice list (proves the renamed remark parser stays backward-compatible).

## Addendum (2026-08-21) — two defects found in the exact surface this ADR governs

Decision §3 required that a Government-billed appointment invoice go through the same
non-POS, `create_invoice_from_appointment`-driven path a real payment does, "since Government
invoices need the same correct-tax treatment as a real payment." Two gaps surfaced when a real
Government booking was exercised after this ADR shipped — both fixed, neither required
reopening this ADR's decision:

1. **Government-mode bookings crashed outright** with `"Sales Taxes and Charges Template
   Mexico Tax - N not found."` Root cause was unrelated to this ADR's own logic: core
   Healthcare's invoice builder reaches its POS branch specifically for a deferred-payer mode
   (per Decision §3, `mode_of_payment` is deliberately *not* blanked for a waiver/deferred mode
   before invoicing — see `services/billing.py:554`), and that branch pulls in a company POS
   Profile. POS Profile `Pharmacy Counter`'s own `taxes_and_charges` field pointed at a name
   that only exists as an *Item Tax Template*, not a *Sales Taxes and Charges Template* — a
   pre-existing data misconfiguration, not something this ADR introduced, but one this ADR's
   own required routing is what exposed. Fixed by clearing the field (the site has no valid
   Sales Taxes and Charges Template for Narzim at all, and none was ever supposed to
   auto-apply — `Accounts Settings.add_taxes_from_taxes_and_charges_template = 0`).
2. **The "same correct-tax treatment as a real payment" requirement itself wasn't met — for
   any appointment invoice, Government or not.** Core Healthcare's appointment invoice builder
   never applies an Item's own default Item Tax Template to the line it constructs (that
   lookup normally only happens via the Desk form's client-side `item_code`-change handler,
   which never runs for a server-built invoice). So a tax-classified consulting fee posted at
   0% tax regardless of payment mode — this ADR's own stated requirement for Government was
   silently unmet for every mode. Fixed by a new `before_validate` hook
   (`overrides/appointment_invoice_tax.py`), gated on a flag `services/billing.py` now sets
   only around its two calls into core's builder — not on document shape, since this app's own
   billing-tab invoice editor can also bill an appointment's consulting charge and must not be
   affected (a first version of the fix, scoped by `reference_dt` instead, briefly
   over-applied tax to a billing-tab invoice where the front desk had deliberately chosen no
   tax — corrected same day).

Neither defect changes this ADR's Decision, Alternatives, or Consequences — both are
implementation bugs in the routing this ADR already specified, not gaps in the specification
itself. Full detail: `WORK_LOG.md`'s two 2026-08-21 entries.

## References

- `services/billing.py:60-181` (current waiver mechanism, to be replaced)
- `services/billing.py:183-256, 432-501, 504-611` (create_invoice_from_appointment, settle_invoice, invoice_and_settle)
- `services/billing.py:1878, 2339, 2496, 2694` (the four non-appointment invoice builders)
- `api/v1/billing/api.py:79-83, 837` (public `is_waiver_mode` passthrough)
- `components/billing/collect-payment-dialog.tsx:45-46, 93-100, 170, 195-196`
- `components/narzim/dashboard/new-appointment-dialog.tsx:905-926, 2536-2553`
- Constitution §3 (Locked Assumptions — API pattern, no new doctypes without cause), §10 (Working Style — Risks before Implementation)
- Project memory: `project_government_waiver_billing.md` (as-is state this ADR corrects), `project_appointment_pay_now_billing.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-21 | Divyanshu (AI-assisted) | Status: Proposed → Accepted (already implemented and live); added the 2026-08-21 addendum on the POS-crash and appointment-tax-gap fixes |
| 1.0 | 2026-08-20 | Divyanshu | Initial version (header backfilled from git history) |
