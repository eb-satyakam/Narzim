# ADR-085: Look at the pictures in every report, not only in reports that are nothing but pictures

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted — 2026-09-22
- **Supersedes** the scope of [ADR-082](adr-082-ai-image-observations.md) (image observations only where there was nothing to transcribe). The ADR-082 safety rules — describe never diagnose, keep observations out of the transcription — are unchanged and still binding.

---

## 1. Context

ADR-082 gave the model a way to describe an image, but only for a document with no discrete
values: a bare ultrasound still, an X-ray, a photograph. **Most clinical reports are not
like that.** An eye-biometry printout has measurement tables *and* scan images on the same
page; an echocardiogram has measurements and an image; an ECG has a tracing above a table of
intervals.

For those, three things followed, all observed on one real IOLMaster 700 upload:

- `text_layer_is_caption_only` was correctly **false** (the text layer is rich), so the pages
  were never rendered and the model never saw the pictures at all.
- `image_observations` lived inside a `narrative_reports` entry, and a panel-classified
  document has no narrative entry — so there was nowhere to put them even in principle.
- The report chat, asked *"how many images do we have in this report?"*, answered from the
  **numbers**: "There appear to be two image/measurement sets, based on the two distinct
  blocks of biometric and keratometry values." Asked what a colour on the image meant, it
  answered "I cannot determine what green means from these data alone."

## 2. Decision

1. **`image_observations` moves to document level** — a top-level array of
   `{modality, description, notable, side, source_file_index}`, one entry per distinct image
   or set of images. It no longer hangs off a text block, so a report with tables gets them.
2. **Pages are rendered for any PDF that carries pictures**, not only for ones that are
   almost all picture. When the whole document is a picture every page is rendered; otherwise
   only the pages that actually carry an image (`render_pages_to_png(only_pages_with_images=True)`),
   so a long printout does not pay tokens for its table-only pages.
3. **Overlays are part of the observation.** The prompt asks for what is drawn on the image —
   coloured lines, markers, calipers, axes, legends — and for any legend printed with it. A
   colour whose meaning is not printed is described and reported as unexplained, never guessed.
4. **The same three blocks reach the summary AND the chat**: the report's own warnings
   (ADR-084), the image observations, then the transcribed text. Both carry their provenance
   in their heading, so a model's reading of an image can never be presented as something the
   report stated.

## 3. Result, on the report that prompted it

```
pdf has images = True   caption_only = False   pages rendered = 4
params = 47   sides = {right 23, left 22, n/a 2}   notices = 4   IMAGE OBSERVATIONS = 7
```

Seven images identified with modality and side — two OCT B-scans, two topography power maps,
anterior-segment photographs — including one described as carrying "overlaid circular degree
marks and a yellow axis line; annotation 'Eje escarpado TK2'".

The chat, on the same two questions that failed before:

- *how many images* → "The report contains seven images as observed in the document: Right
  OCT (cornea-to-retina B-scan), Right topography / total axial power map, …"
- *what does the yellow line mean* → "The yellow line marks the steep corneal meridian — the
  'eje escarpado' for TK2 … an overlaid axis indicator showing the orientation of the steep
  keratometry measurement."

## 4. A trap that cost two failed extractions

OpenAI's strict structured-output mode requires **every** property of every object to appear
in that object's `required` array. Adding `report_notices`, and then `image_observations`,
without adding them there produced
`Invalid schema for response_format: 'required' is required to be supplied and to be an array
including every key in properties`, failing every extraction at the provider.

`_assert_strict_schema` now checks all three schemas **at import**, so the mistake surfaces
when the module loads rather than on the next upload. Verified to reject a deliberately
broken schema.

## 5. Consequences accepted

| Consequence | Detail |
|---|---|
| **More input tokens on image-bearing reports** | Rendered pages are images. Latency is output-bound (`docs/ai/LAB_EXTRACTION_PERFORMANCE.md`), so the wall-clock effect is small, but the cost is real. Bounded by rendering only image-bearing pages, capped at four |
| **The AI now describes images on ordinary clinical reports** | Not only on image-only documents. Same guards as ADR-082: describe never diagnose, own field, labelled as AI-observed, physician reviews. Still no deterministic validator — ADR-082 §3 stands |
| **A longer extraction prompt** | Each added rule has twice shifted the panel/narrative classification of an unrelated document. Both were caught only by re-running a file whose correct answer was already known, which is not a test |


## 6. The observations belong IN the report, and the code writes the heading

Requested 2026-09-23: the image explanation must appear in the extraction as well as the
summary, "with proper heading and all".

`render_image_observations_markdown` now writes a section into the report body:

```
## AI Image Observations

_Observed by the assistant from the images in this report. A description of what is
visible, not a diagnosis, and not stated by the report itself._

### BAER waveform — bilateral
...
**Notable:**
- ...
```

**The section is generated by CODE, not by the model, and that is the point.** ADR-082
requires a reader to be able to tell a model's reading of a picture from something the report
states. A heading the model writes can be reworded, mis-levelled or omitted; one the code
writes from the structured field cannot. The model is never asked to produce this section.

It is appended AFTER `_finalize_narrative_report`, which can replace the body with the text
layer when the model produced nothing usable — appending first would have let that
replacement silently wipe the section. It is idempotent on the heading, so a retry never
stacks it twice.

**A regression this uncovered.** Moving observations to document level (§2) left the UI still
reading `narrative_reports[].image_observations`, a field that no longer existed — so the
side panel had been rendering nothing at all, silently, since that change. The panel now
reads the document-level list and is shown ONLY when the upload produced no narrative body
(a biometry or calculation sheet, all tables and pictures); where there is a body it carries
the section instead, so nothing appears twice.

Verified on a five-page audiology report: section present exactly once, three sub-headings
(BAER waveform, Tympanogram, DPOAE plots), each with its notable list; transcription 10,170
characters with 13 headings; page furniture still absent.


## 7. The summary card shows them by default

The report chat answered image questions well once it had the observations, but the SUMMARY
only mentioned them when the model's prose happened to. Requested 2026-09-23: show them by
default whenever a report contains images.

`generate_report_summary` now returns `image_observations` alongside the narrative, and the
summary card renders them in their own block with the same "observed by AI, not a diagnosis"
label used elsewhere.

**Returned as data, not left to the narrative.** Whether the prose mentions the pictures is
the model's choice; a clinician should not have to hope for it. Same reasoning as generating
the report's observation heading in code (§6): where something must always be visible, a
deterministic display beats model discretion.

**A second return shape nearly hid this.** A report whose content is entirely narrative — an
audiology or imaging report, precisely the kind most likely to carry images — is summarised by
`_generate_narrative_report_summary`, which has its own return dict. Adding the field to
`generate_report_summary`'s four returns left that path unchanged, so the very reports this was
for still arrived with nothing. Caught by checking the actual response rather than assuming the
edit was sufficient: `image_observations returned=MISSING`, then `=3` after threading it
through the narrative path too.

The scope check written after the `report_kind` incident (a regex that added a field to
functions where the variable did not exist) was re-run here and reported none.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Divyanshu (AI-assisted) | Summary card shows image observations by default; narrative summary path threaded through |
| 1.1 | 2026-09-23 | Divyanshu (AI-assisted) | Observations written into the report body as a code-generated headed section; fixed the side panel, which had been reading a removed field |
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — document-level image observations, selective page rendering, observations reach summary and chat, import-time schema guard |
