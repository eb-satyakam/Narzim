# ADR-007: Lock jurisdiction to Mexico; defer US; drop India assumption

**Doc status:** living · **Created:** 2026-05-19 by Sarvesh-SocialAngel · **Updated:** 2026-09-23 by Nishant · **Version:** 1.1

- **Status:** Superseded
- **Date:** 2026-05-16
- **Supersedes (partially):** Constitution Section 3 — `Jurisdiction` row
  (original: "India (DPDP Act 2023) + HIPAA-aligned controls"). Also adjusts
  Section 1 expertise bullet ("HIPAA/DPDP") and Section 12 deliverable 8
  (retention policy jurisdiction note).
- **Superseded by:** [ADR-018](adr-018-multi-jurisdiction-compliance.md) (2026-06-30), which opened India alongside Mexico. The Mexican healthcare standard is now NOM-024-SSA3-2012; see [the compliance plan §4.2](../security/COMPLIANCE_MULTI_JURISDICTION.md)

## Context

The constitution was drafted with India as the assumed launch market — DPDP
Act 2023 as the privacy regime and HIPAA-aligned controls as a defensive
overlay. That assumption was never validated against the actual go-to-market.

On 2026-05-16 the product owner clarified that Remedisys is **primarily for
Mexico**, that the United States is **deferred** (not in scope for the
current build, but may re-open later), and that the India assumption is
incorrect.

The decision matters now, not later, because three Phase 0 deliverables —
the threat model, the retention policy, and the BAA/DPA tracker — are about
to be written. Each of them cites jurisdiction-specific law. Writing them
against the wrong regime would either be discarded work or, worse, would be
treated as authoritative by someone who didn't realise it was based on a
mis-stated locked assumption.

Several downstream choices already in flight also key off jurisdiction:

- Deepgram language config was set to `en-IN` (English, India). For Mexico
  this needs to move to Spanish — `es-MX` or `es-419`. The medical model
  selection (`nova-2-medical`) needs separate verification for Spanish
  support.
- Consent text shown to physicians and patients at session start.
- BAA / DPA negotiation language with Anthropic, Deepgram, Frappe Cloud.
- Retention windows for clinical records (different under NOM-024 than
  under DPDP).

## Decision

1. **Primary jurisdiction is Mexico.** All Phase 0 compliance artifacts
   (threat model, retention policy, BAA/DPA tracker, consent UX) are
   written against Mexican law as the controlling regime.

2. **The United States is explicitly deferred.** No HIPAA-specific
   controls, BAA language, or US data-residency work is undertaken until
   the business explicitly re-opens US scope via a new ADR. HIPAA-aligned
   defensive practices already present in the constitution (no PHI in logs,
   audit trail, least-privilege) are kept — they are good engineering
   regardless of jurisdiction — but framed as Mexican-law compliance, not
   HIPAA compliance.

3. **India is removed as an assumption.** The constitution's §3
   `Jurisdiction` row is amended (see Consequences). No DPDP-specific
   work is undertaken.

4. **The controlling Mexican regimes for Remedisys (initial scope):**
   - **LFPDPPP** — Ley Federal de Protección de Datos Personales en
     Posesión de los Particulares (federal data protection, private sector).
     Applies to private hospitals and clinics.
   - **NOM-024-SSA3-2010** — the Mexican Official Standard for electronic
     health record systems. Sets technical, interoperability, and
     confidentiality requirements for EHR software.
   - **LGPDPPSO** — Ley General de Protección de Datos Personales en
     Posesión de Sujetos Obligados (public sector data protection).
     Applies *only if* a pilot site is a public-sector institution
     (IMSS, ISSSTE, state health secretariats). Conditional inclusion.
   - **COFEPRIS** — software-as-medical-device classification. Applies
     *only if* Remedisys is marketed in a way that crosses the
     medical-device threshold. The current scope (ambient documentation
     copilot, physician-in-the-loop, no autonomous clinical decisions —
     see Constitution Rule 6) is intentionally designed to stay on the
     documentation-aid side of that line, but classification must be
     confirmed with regulatory counsel before any pilot.

   These are **named, not interpreted**, in this ADR. Detailed
   interpretation is delegated to a Mexican healthcare-law counsel review
   (see Open questions below).

5. **The architecture remains jurisdiction-pluggable.** Because US scope
   is deferred rather than rejected, the following are designed as
   configuration, not hardcoded constants:
   - UI / consent text language (default `es-MX`).
   - ASR language code passed to Deepgram.
   - Retention windows per doctype (defaults are Mexican-law-derived;
     surfaces are in `AI Settings` so a US deployment can override).
   - BAA/DPA language pack per vendor.

   Re-opening US scope therefore means adding a configuration profile and
   writing the HIPAA-specific overlay — not refactoring core code.

6. **Bilingual UX is a product requirement, distinct from jurisdiction.**
   Many Mexican private hospitals serve a bilingual physician and patient
   population (border cities, private specialty hospitals serving US
   patients, medical tourism corridors). The product therefore supports
   **both `es-MX` and `en-US`** across:
   - UI copy and consent text (per-user preference, default `es-MX`).
   - ASR language (per-session selectable; default `es-MX`; the same
     session may not mix mid-stream in the MVP — language switch starts
     a new session).
   - SOAP generation prompts (paired prompt files per language, versioned
     independently — `soap_v1_es.txt` and `soap_v1_en.txt`).
   - LLM-generated output language matches the session ASR language.

   This is a **language-pluggability** requirement, *not* a jurisdiction-
   pluggability requirement. Supporting en-US as a UI/ASR language does
   **not** put the product under US jurisdiction; the controlling regime
   for a Mexican-deployed instance remains Mexican law regardless of
   which language the physician selected. HIPAA compliance work remains
   deferred per §2 above.

   Implications for the Deepgram model choice: `nova-2-medical` is
   English-only at time of writing; Spanish medical ASR requires either
   `nova-2-general` (with prompt-side medical priming) or a newer model.
   A follow-up task verifies current Deepgram model coverage and locks
   the per-language model choice.

7. **No PHI flows until BAA/DPA equivalents are signed under Mexican
   regimes.** The original Phase 0 deliverable 10 ("BAA/DPA tracking —
   no PHI flows until signed") is preserved verbatim; "BAA/DPA" is now
   read as the Mexican-law equivalent (data processing agreement under
   LFPDPPP Art. 36 / its regulations) rather than the US HIPAA BAA. The
   gate remains.

## Alternatives Considered

1. **Keep India + HIPAA-aligned, treat Mexico as a future port.**
   - Pros: no churn on the in-flight constitution.
   - Cons: actively wrong — the product owner has stated India is not
     the market. Every compliance artifact written this week would be
     against the wrong regime. Doing this would burn trust and create
     documents that quietly poison later decisions.

2. **Lock to Mexico, defer US, drop India (chosen).**
   - Pros: matches stated business reality; unblocks the three Phase 0
     compliance deliverables to be written truthfully; keeps the
     architecture pluggable so re-opening US is a configuration change
     rather than a rewrite.
   - Cons: requires this ADR plus a constitution amendment; team has to
     re-baseline mental model from "India + HIPAA" to "Mexico
     (LFPDPPP/NOM-024)." Some already-written language strings
     (Deepgram `en-IN`) need follow-up tasks.

3. **Lock to Mexico, simultaneously write Mexico + US (HIPAA) layers.**
   - Pros: maximally future-proof.
   - Cons: doubles the compliance work in Phase 0 for zero current
     business value; HIPAA-specific controls can drift if not actively
     used; product owner explicitly said US is deferred. Premature.

4. **Lock to Mexico, declare US permanently out of scope.**
   - Pros: simpler — no pluggability requirement; can hardcode Mexican
     assumptions where convenient.
   - Cons: product owner said "deferred," not "out." Hardcoding now
     would create exactly the kind of rewrite cost that pluggability
     avoids. Premature in the other direction.

## Consequences

### Constitution amendments (this ADR's primary effect)

- **§3 `Jurisdiction` row** changes from
  `India (DPDP Act 2023) + HIPAA-aligned controls`
  to
  `Mexico — LFPDPPP + NOM-024-SSA3-2010 (LGPDPPSO if public-sector pilot; COFEPRIS classification to be confirmed) — see ADR-007`.

- **§3 gains a new `Languages` row:**
  `es-MX (default) + en-US (per-user / per-session) — see ADR-007`.

- **§1 expertise bullet** changes from
  `HIPAA/DPDP`
  to
  `Mexican healthcare compliance (LFPDPPP, NOM-024-SSA3-2010) and jurisdiction-pluggable architecture`.

- **§12 deliverable 8 jurisdiction note** changes from
  `DPDP Act 2023 + HIPAA-aligned`
  to
  `LFPDPPP + NOM-024-SSA3-2010 (per ADR-007)`.

- **AMENDMENTS block** at the top of the constitution gains an ADR-007
  line so future readers see the supersession before reaching §3.

### Other ADRs

- ADR-001 (FastAPI service separation), ADR-002 (WebSocket JWT auth),
  ADR-003 (no core modification), ADR-004 (Frappe v16), ADR-005
  (Frappe Cloud), ADR-006 (MariaDB), ADR-008 (overlay FAB), ADR-009
  (audio ingress) — none of these carry jurisdiction claims. Not
  superseded.

### Code / files to be written or revised

- **New:** all Phase 0 compliance artifacts (threat model, retention
  policy, BAA/DPA tracker) are written against the new baseline. No
  pre-existing content to migrate.
- **Revised:** `deepgram` config in `start_session` (currently
  `language=en-IN`) → follow-up task to switch to `es-MX` *after*
  verifying Spanish support on the chosen medical model. **Not done
  in this turn** — separate task with its own verification step.
- **Revised:** any UI copy committed in `apps/remedisys_healthcare_ai/`
  that is English-only — follow-up audit task.
- **New:** `AI Settings` will gain language and retention-window
  configuration fields when those doctypes' Phase 1 work lands; this
  ADR locks them as configurable rather than hardcoded.

### Operational implications

- Frappe Cloud region selection: confirm whether a Mexico-resident or
  US-resident region is appropriate under LFPDPPP. Open question for
  counsel — see below.
- Vendor agreement language: BAA → Convenio de Encargo del Tratamiento
  de Datos Personales (or equivalent under LFPDPPP Art. 36 and its
  regulations). Anthropic, Deepgram, and Frappe Cloud each need their
  Mexican-equivalent data processing agreement reviewed.

### Re-evaluation triggers

- Business decides to re-open US scope. Action: new ADR adds the HIPAA
  configuration profile; this ADR's Decision §5 (pluggability) makes
  that an additive change.
- Mexican counsel determines that COFEPRIS classifies Remedisys as a
  medical device. Action: new ADR adjusts product scope, validation
  pipeline, and pilot gating.
- Pilot site turns out to be public-sector. Action: LGPDPPSO overlay
  documented in retention policy and threat model.
- Data residency requirement forces in-country storage that Frappe
  Cloud cannot meet. Action: re-evaluate ADR-005 (Frappe Cloud
  deployment).

## Open questions / counsel review

These are explicitly **not answered** in this ADR and must go to Mexican
healthcare-law counsel before the threat model, retention policy, or
BAA/DPA tracker are treated as authoritative:

1. Does NOM-024-SSA3-2010 require in-country data residency for
   clinical records, or is cross-border processing under an LFPDPPP-
   compliant data processing agreement sufficient?
2. Does the product, as scoped (documentation copilot, physician-in-
   the-loop, no autonomous clinical decisions), trigger COFEPRIS
   software-as-medical-device classification? If yes, at what risk
   class?
3. Retention windows: what are the controlling minimums under NOM-024
   for clinical record components (transcript, generated SOAP draft,
   prompt-log metadata)?
4. Audio retention: if patient and physician both consent in writing,
   may raw audio be retained beyond the encounter, and under what
   safeguards? (Constitution §3 default is OFF; this question only
   affects the future opt-in path.)
5. Consent text: what specific disclosures must appear at session
   start under LFPDPPP transparency principles for ambient recording?

## Verification

- Constitution AMENDMENTS block contains an ADR-007 line.
- Constitution §3 `Jurisdiction` row no longer references India or DPDP.
- This ADR file exists at `apps/remedisys_healthcare_ai/docs/adr/adr-007-jurisdiction-mexico.md` with status `Accepted`.
- A follow-up task is filed (next turn) to switch Deepgram language
  from `en-IN` to `es-MX` after model-support verification.
- Phase 0 deliverables 7, 8, 9 (when written) cite ADR-007 as the
  jurisdiction baseline.

## References

- Engineering Constitution, Sections 1, 3, 12
- ADR-005 (Frappe Cloud deployment) — region selection is downstream of
  this ADR's residency question
- LFPDPPP — Ley Federal de Protección de Datos Personales en Posesión
  de los Particulares (statute; consult counsel for current regulations
  and recent amendments)
- NOM-024-SSA3-2010 — Norma Oficial Mexicana for EHR systems (consult
  counsel for current revision; NOMs are periodically updated)
- Memory: `project_remedisys_jurisdiction.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-23 | Nishant | Supersession recorded: ADR-018 already declared it supersedes this ADR. Decision text unchanged, per the rule that a merged ADR is superseded, never edited |
| 1.0 | 2026-05-19 | Sarvesh | Initial version (header backfilled from git history) |
