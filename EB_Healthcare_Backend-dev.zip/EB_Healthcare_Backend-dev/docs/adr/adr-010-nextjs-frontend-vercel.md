# ADR-010: Next.js on Vercel as the clinical frontend; Frappe as headless backend engine

**Doc status:** living · **Created:** 2026-06-04 by Sarvesh-SocialAngel · **Updated:** 2026-06-04 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-03
- **Supersedes (partially):** CLAUDE.md §3 — `Frontend framework` row ("Frappe's native JS — NOT React/Vue/Nuxt"). All other rules unchanged.
- **Superseded by:** —

## Context

CLAUDE.md §3 locked the frontend to "Frappe's native JS (jQuery + Frappe UI) —
NOT React/Vue/Nuxt." That decision was made when the only frontend surface in
scope was the AI sidebar on the Patient Encounter form — a narrow widget best
delivered as a `doctype_js` hook.

The product scope has grown. The team is now building a complete clinical
frontend covering all workflows a physician, nurse, and front-desk user touches:
appointments, patient chart, encounters, vitals, labs, prescriptions,
immunization, billing, documents, reports, messages, and admin. Building this
surface in Frappe's native jQuery + Frappe UI would require:

- Deep knowledge of Frappe's page/form/list framework across all roles.
- Overriding or duplicating Frappe Desk UX patterns that are designed for ERP
  operators, not clinicians.
- Accepting the Frappe Desk layout constraints (sidebar, toolbar, form chrome)
  on every clinical screen.

The team's product direction requires a **purpose-built clinical UX** with
role-specific layouts and flows that cannot be satisfied within Frappe Desk's
design system without extensive core modification (which ADR-003 forbids).

Simultaneously, the team decided to deploy the frontend on **Vercel** — a
separate domain from Frappe Cloud. This means Frappe functions purely as a
backend engine: REST API, MariaDB, ERPNext Healthcare doctypes, existing role
permissions. No new backend code in the manual flow phase.

The AI phase (CLAUDE.md Phase 1+: Deepgram transcription, SOAP generation,
validators) is explicitly deferred. When it resumes, the AI sidebar ships as a
React component inside this frontend.

## Decision

1. **The clinical frontend is built in Next.js 14+ (App Router)**, deployed to
   Vercel, in a standalone `remedisys-web` GitHub repository.

2. **Frappe (Frappe Cloud) is the backend engine.** It is consumed via its
   existing REST API (`/api/resource/*`, `/api/method/*`). No new whitelisted
   methods, no new doctypes, no changes to Frappe Desk, no changes to core in
   this phase. ADR-003 holds fully.

3. **BFF (Backend For Frontend) pattern.** Next.js API route handlers proxy
   all Frappe calls server-side. The browser never opens a connection to Frappe
   directly. The Frappe SID session token is stored encrypted in the Next.js
   session (NextAuth.js v5 with a custom Frappe credentials provider) and never
   exposed to the browser.

4. **RBAC at two layers.**
   - **Next.js middleware** reads roles from the session and guards routes
     (UX layer). A nurse who navigates directly to `/doctor/encounters` is
     redirected to their dashboard.
   - **Frappe's existing Healthcare role permissions** enforce data-layer access
     on every API call. If the Next.js guard is bypassed, Frappe returns 403.
   - No new Frappe role configuration required. The three roles in scope
     (Healthcare Receptionist / Front Desk, Nurse, Physician / Doctor) already
     exist in ERPNext Healthcare.

5. **The only Frappe-side configuration change** is adding the Vercel domain
   to `allow_cors` in `common_site_config.json`. No code changes.

6. **AI phase deferred.** The `encounter_ai.js` vanilla-JS sidebar work and
   ADR-008 (overlay FAB design) are suspended. When the AI phase resumes, the
   sidebar ships as a React component in `remedisys-web`. ADR-008's design
   specification (FAB → popover → fullscreen, three-mode pattern) is preserved;
   only the implementation language changes from vanilla JS to React.

## Alternatives Considered

1. **Frappe native JS — keep the current lock.**
   - Pros: no new repo; all frontend hooks in `remedisys_healthcare_ai` via
     `page_js` / `doctype_js`; no Vercel dependency.
   - Cons: Frappe Desk UX is designed for ERP operators. Building clinical
     screens (appointment calendar, patient chart, encounter SOAP form) within
     Frappe's list/form/page framework requires fighting the framework on every
     screen. Role-specific layouts (different sidebars for front desk, nurse,
     doctor) are not a first-class Frappe concept. Effectively a custom framework
     built on top of a framework, without the productivity benefits of either.

2. **Next.js with direct browser → Frappe calls (no BFF).**
   - Pros: simpler route handlers; no server-side session management.
   - Cons: Cross-origin cookie auth is complex and fragile. Frappe's SID would
     need to ride a CORS request from the browser, requiring `credentials: include`
     and permissive CORS headers on Frappe — a security regression. Frappe API
     keys stored in the browser are equally problematic. The BFF pattern is the
     correct solution for this deployment shape.

3. **Next.js + BFF pattern, with Frappe as headless backend (chosen).**
   - Pros: clean auth story (SID never in browser); Frappe URL and structure
     never exposed to the client; single auth surface; role-based routing in
     middleware is straightforward; Frappe's existing permissions remain the
     data-layer enforcement without any new configuration.
   - Cons: Next.js API route handlers add a network hop for every request. In
     practice this is sub-5ms server-to-server on the same cloud backbone and
     is acceptable for clinical workflows (these are not sub-100ms realtime
     operations; forms and lists tolerate 200–500ms).

4. **Vue.js or another framework.**
   - Not considered seriously. Next.js is the stated choice. When AI phase
     resumes, React component ecosystem is better suited to building the audio
     capture + transcript render + SOAP editor than Vue.

## Consequences

### CLAUDE.md amendments

- **§3 `Frontend framework` row** changes from
  `Frappe's native JS (jQuery + Frappe UI) — NOT React/Vue/Nuxt`
  to
  `Next.js 14+ App Router (remedisys-web, Vercel) for all clinical screens — see ADR-010. Frappe native JS suspended for clinical UI.`

- **AMENDMENTS block** at the top of CLAUDE.md gains an ADR-010 line.

### Suspended work

- `apps/remedisys_healthcare_ai/public/js/encounter_ai.js` — the Phase 1 AI
  sidebar vanilla-JS implementation is suspended. The file is kept in the repo
  as reference; it is not deleted. When AI phase resumes, implementation moves
  to a React component in `remedisys-web`.
- `apps/remedisys_healthcare_ai/public/css/encounter_ai.css` — same; kept as
  design reference.

### New artifacts

- `remedisys-web/` GitHub repository (standalone, deployed to Vercel).
- `docs/SYSTEM_DESIGN_FRONTEND.md` — full frontend system design.
- `prompts/2026-06-03-nextjs-frontend-architecture.md` — decision archive.

### Unchanged

- ADR-003 (no core modification) — unchanged and fully applicable.
- ADR-005 (Frappe Cloud) — unchanged.
- ADR-006 (MariaDB) — unchanged.
- ADR-007 (Mexico jurisdiction) — unchanged; all compliance requirements
  (LFPDPPP, NOM-024-SSA3-2010, bilingual `es-MX`/`en-US`) apply to the
  Next.js frontend equally.
- ADR-008 (overlay FAB design) — design intent preserved; implementation
  deferred to AI phase.
- ADR-009 (browser-direct audio to Deepgram) — unchanged; deferred to AI phase.
- All CLAUDE.md architecture rules (Rules 1–10) — unchanged.

### Re-evaluation triggers

- Frappe Cloud restricts `allow_cors` to same-origin only (would require a
  reverse-proxy to share the domain).
- Vercel cold-start latency proves unacceptable for clinical workflows (move
  to edge runtime or self-hosted Next.js).
- Team decides to collapse back to a single deployment target (merge Vercel
  and Frappe Cloud behind a reverse proxy on the same domain).

## Verification

- `remedisys-web` repo exists on GitHub; Vercel deployment is live.
- `GET https://<vercel-domain>/login` returns 200 and the login form.
- Login flow: POST credentials → NextAuth session created → role-based redirect
  to correct dashboard → Frappe API call from route handler returns patient list.
- `GET https://<frappe-cloud>/api/resource/Patient` from the browser returns 403
  (no session cookie) — confirms browser never talks directly to Frappe.
- CLAUDE.md AMENDMENTS block contains the ADR-010 line.

## References

- CLAUDE.md §3 (Frontend framework lock — superseded for clinical screens)
- CLAUDE.md §4 Rule 1 (Upgrade-Safe), Rule 7 (AI failure must not break healthcare)
- ADR-003 (no core modification — unchanged)
- ADR-005 (Frappe Cloud deployment)
- ADR-007 (Mexico jurisdiction — applies to Next.js frontend)
- ADR-008 (overlay FAB design — deferred to AI phase)
- docs/SYSTEM_DESIGN_FRONTEND.md
- prompts/2026-06-03-nextjs-frontend-architecture.md

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-04 | Sarvesh | Initial version (header backfilled from git history) |
