# ADR-105: Template studio — sessionless drafts, deletable templates, cached examples

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** the "never store `example_markdown`" line of
  `docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md` §2.5, for the cache described in decision 3 only
- **Superseded by:** —

## Context

A stakeholder tested the Narzim GPT template studio on 2026-09-29 and found it unusable. The
frontend half was reworked on 2026-09-30. Five faults remain that only the backend can fix. Design:
[`docs/ai/NARZIM_TEMPLATE_STUDIO_FIXES.md`](../ai/NARZIM_TEMPLATE_STUDIO_FIXES.md).

| # | Fault | Cause |
|---|---|---|
| R1 | A template that was ever opened in the editor cannot be deleted | `AI Template Edit Session.template` is a Link, so Frappe's link check refuses the delete |
| R2 | A failed "new template" leaves a blank row behind | An outline can only be written inside a session, and a session needs a saved template |
| R3 | Saving from the editor cannot set the template's type or description | `save_template_session` takes only `session_id` and `name` |
| R4 | The editor cannot tell whether a request changed anything | `edit_template_chat` returns the outline and no statement about it |
| R5 | New templates fail to save; examples take about 5 s on every open and drop their labels | A heading line longer than 140 characters; no cache; the authoring prompt writes bare slots |

## Decision

1. **Delete a template's edit sessions in its `on_trash`.** Frappe runs `on_trash` before the link
   check, so the rows are gone by the time it looks.
2. **Add `draft_template_outline(message)`**, which writes a first outline and saves nothing.
3. **Cache a generated example in the Redis cache for 7 days**, keyed by a hash of the structure,
   the prompt version and the language. Run the patient-identifier check on the example before it
   is cached. `regenerate=1` bypasses and replaces the entry.
4. **`save_template_session` accepts `category` and `description`.**
5. **`edit_template_chat` returns `changed`, `sections_added` and `sections_removed`**, computed
   from the two outlines with no model call.
6. **`parse_sections` stores a heading without its slots and instructions, cut to 140 characters.**
7. **New prompt versions**: `narzim-template-edit-v3`, `narzim-template-example-v3`,
   `narzim-template-fill-v2`.

## Alternatives Considered

### Where a generated example lives (decision 3)

1. **Own doctype, keyed by structure hash.**
   - Pros: survives a cache clear; visible to an administrator.
   - Cons: a new PHI-shaped store that needs a retention job and an erasure path (PHI-3, PHI-4); a
     schema change and a migration for content that can be regenerated at will.
2. **A field on the template or its edit session.**
   - Pros: no new doctype.
   - Cons: the template is copied by `duplicate_from` and a system row is readable by every user,
     so one bad example spreads; `test_narzim_template_editor.py` asserts the session holds no
     example, for that reason.
3. **Redis cache with a TTL (chosen).**
   - Pros: no schema change; expiry is enforced by Redis, so the retention period cannot be a false
     promise (PHI-3); `bench clear-cache` is a complete erasure path (PHI-4); nothing is copied with
     a template.
   - Cons: a cache clear costs one regeneration per structure.
4. **Client memory only.**
   - Pros: nothing stored on the server.
   - Cons: already shipped in the frontend, and it does not survive a reload or a second device,
     which is the complaint.

### How a template with sessions becomes deletable (decision 1)

1. **`on_trash` deletes the sessions (chosen).** Pros: one place, covers Desk and scripts too.
   Cons: relies on Frappe's hook order, which a test pins.
2. **`delete_template` deletes them before `frappe.delete_doc`.** Pros: explicit. Cons: a Desk
   delete still fails.
3. **Change `template` from Link to Data.** Pros: no link check at all. Cons: a schema change and a
   patch, and the link is useful in Desk.
4. **`force=True` on the delete.** Pros: one word. Cons: skips every link check, including ones
   added later; leaves orphaned session rows.

### How a first outline is written without a row (decision 2)

1. **A sessionless method (chosen).** Pros: no row until there is content. Cons: one more endpoint.
2. **Sessions without a template.** Pros: reuses the chat method. Cons: `template` is required; a
   schema change, and every session reader must handle the empty case.
3. **Create the row, delete it on failure.** Pros: no backend change. Cons: this is today's
   behaviour and the source of the blank rows.
4. **Client-side outline from fixed templates.** Pros: instant. Cons: only covers document types
   someone hard-coded; the mock module's version of this is being removed.

## Consequences

- The inventory's "never store" rule now reads "never store in a doctype"; the cache is the one
  allowed location.
- A cached example is synthetic. It is still treated as PHI-shaped: checked before caching, expired
  by TTL, and never written to a log (BE-10).
- No doctype changes, so no patch and no `bench migrate` (BE-9).
- The frontend switches new-template creation to `draft_template_outline` followed by
  `create_template`.
- Re-evaluate if clinicians report stale examples, or if examples need to be shared between users.

## Verification

- `tests/ai/test_narzim_template_studio_fixes.py` covers each decision; each test fails on the
  code before this change.
- `python3 scripts/gen_endpoint_index.py --check` lists `draft_template_outline`.

## References

- `CLAUDE.md` BE-9, BE-10, PHI-3, PHI-4, PHI-6
- ADR-065 (a document before non-trivial work)
- `docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md` §2.5
- Frontend `docs/NARZIM_GPT_EXPERIENCE_HANDOFF.md` §9 (R1–R5)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-103 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
