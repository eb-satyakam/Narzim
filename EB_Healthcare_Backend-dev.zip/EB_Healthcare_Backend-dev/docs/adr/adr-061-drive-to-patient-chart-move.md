# ADR-061: Moving a Narzim Drive file onto a patient chart — copy the bytes, trash the source

**Doc status:** living · **Created:** 2026-09-09 by Anant (AI-assisted) · **Updated:** 2026-09-09 by Anant (AI-assisted) · **Version:** 1.0

- **Status:** **Accepted** — decided by Anant, 2026-09-09
- **Date:** 2026-09-09
- **Supersedes:** —
- **Superseded by:** —

## Context

Narzim Drive has had a **Move to Patient** action since 2026-08-19
(`5c1f4b13`, "full Narzim Drive folder UI"). It never worked. `handleMove` in
`clinical-documents-tab.tsx` was a 900 ms `setTimeout` followed by a green
"Moved!" — no request was made, and the dialog carried an amber footer saying
"Backend endpoint not yet available". Reported by the user 2026-09-09: a
document filed this way never appeared in the patient's Documents tab.

The reason it could not simply be "wired up" is that the two screens are
**deliberately different stores**, and this ADR exists because bridging them is
a PHI decision rather than plumbing:

| | Narzim Drive | Patient chart → Documents |
|---|---|---|
| Storage | `Drive File` (Frappe Drive team space) | `Patient Medical Record` + private `File` |
| Read path | `api/v1/drive/api.py::list_entries` | `api/v1/documents/api.py::list_documents` |
| Permission authority | Drive's `user_has_permission` tree-walk | `require_permission("Patient", …)` |
| Audit | `Access Log` written by `services/drive.py` | `Access Log` + `View Log` via `utils.require_permission` |

[`DRIVE_MIGRATION_PLAN.md`](../narzim-drive/DRIVE_MIGRATION_PLAN.md) §11.3 states the intent
plainly: *"Narzim Drive is Drive; the patient-chart Documents tab keeps `Patient Medical Record`.
The two features stop sharing a name."* There was no patient field, no endpoint, and no bridge —
`grep -i patient services/drive.py` returned comments only.

## Decision

**Copy the bytes into a `Patient Medical Record` row through the existing chart-upload path, then
trash the Drive original.** A real move: one copy of the patient data survives it.

Implemented as `services/drive.py::move_to_patient` / `move_to_patient_bulk`, exposed as
`api/v1/drive/api.py::move_to_patient`.

## Options considered

| Approach | Pros | Cons |
|---|---|---|
| **A.** Custom `patient` link field on `Drive File`; the Documents tab queries Drive too and merges | No byte duplication; the move is one field write | Makes Drive's tree-walk an authority over chart documents |
| **B.** Copy into a PMR row via the chart-upload path, then trash the source **(chosen)** | One store, one permission gate, one audit path, one erasure path; the Documents tab needs no change | A transient second copy during the move; Drive shares/tags/comments do not travel; notes and folders need explicit handling |
| **C.** Copy into a PMR row and leave the Drive entry in place | Non-destructive; nothing to restore | Duplicates PHI across two stores with two erasure paths |
| **D.** Drop the action; add "Attach from Drive" on the patient chart instead | The write happens in patient context, where the permission gate and the category picker already are | Does not fix the reported defect; discards an affordance staff already use |

**Why each rejected option loses, specifically.**

**A** loses on one fact, not on taste. `list_documents` is today bounded by
`require_permission("Patient", "read")`. Drive grants **every team member `read` on every file**
and `write` only to the owner or a team admin (`drive/api/permissions.py::get_user_access`
lines 70–81). Under A, a Drive share on the file *or any ancestor folder* would grant
chart-document access that the patient check never sees — and `services/drive.py`'s own docstring
names duplicated permission authorities as "the failure mode that hides privilege bugs", which is
why that module refuses to re-implement Drive's resolution in the first place. A also leaves
erasure needing to walk two stores.

**C** loses on **PHI-4** (duplicated PHI must be reachable by one erasure path): the same change
would have to add Drive to erasure and retention. It also contradicts its own label — a lab result
"moved" to a chart would sit in a staff drive indefinitely, which is how a stale second copy of a
clinical document outlives the record it was filed into.

**D** loses because it does not fix the reported defect and discards an affordance clinic staff
are already reaching for. It remains worth building later as an *addition*, not as this fix.

## Consequences

**Ordering is a safety property, not a style choice.** The chart row is written **first** and the
Drive entry trashed **second**, because `trash()` commits. Filing first means the worst case is a
document that reached the chart plus a visible leftover in the drive, removable by hand and
reported to the caller as `source_trashed: false`. The reverse order risks bytes gone from Drive
with no chart row — silent loss of a clinical document.

**Files only.** Folders are refused (a folder is not a document) and notes are refused (a note's
body lives in a linked `Drive Document` and has no stored bytes; rendering one would turn an
editable note into a frozen clinical record — a separate decision, not this one).

**`write`, not `read`, is the gate.** Moving an entry out of the drive destroys it there, so the
mover must be able to write it — the same permission Drive's own `remove_or_restore` requires
(`drive/api/files.py:773`). A nurse cannot yank a document out of a physician's drive; a team
admin or the owner can. This is consistent with the existing Delete action rather than stricter.

**Reuse is what makes it safe.** `move_to_patient` calls
`services/documents.py::upload_document`, the identical path a chart upload takes, so a moved
document is indistinguishable from an uploaded one: same PMR shape, same private `File`
attachment, same category link, same delete semantics. `utils.save_private_file` salts Frappe's
content-hash dedup with `(doctype, name)`, so two byte-identical scans filed for the same patient
get separate blobs instead of the `PermissionError` that bit us on 2026-07-16.

**Both reads are audited.** Pulling the bytes out of Drive to copy them is a PHI egress in its own
right and Drive writes no such row, so an `Access Log` entry is written before the content is
produced — IDs only, never the title (Rule 10).

**Partial results are the normal case.** A selection may mix files with folders, notes, and
colleagues' files, so `move_to_patient_bulk` returns `{moved, skipped}` with a per-item reason and
each item wrapped in its own savepoint — otherwise one refusal poisons the transaction for every
item after it.

**Not carried across:** Drive shares, tags and comments on the source. A moved document is
governed by the patient's permissions from then on, which is the point.

**Verified 2026-09-09** on `remedisys.localhost`: 11 new tests in
`remedisys_healthcare_ai/tests/security/test_drive_service.py` (32 in that module, all passing),
plus an end-to-end run confirming the filed document is returned by `list_documents`, the source
leaves `list_entries`, deleting the chart row removes the blob, and an MRN-named patient
(`MRN-2026-0000001`) works.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-09 | Anant (AI-assisted) | Initial version |
