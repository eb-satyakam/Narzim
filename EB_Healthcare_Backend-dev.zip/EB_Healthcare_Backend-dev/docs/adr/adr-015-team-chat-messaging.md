# ADR-015 — Internal Team Chat (staff-to-staff messaging)

**Doc status:** living · **Created:** 2026-06-22 by Anant Sharma · **Updated:** 2026-06-22 by Sarvesh-SocialAngel · **Version:** 1.0

- Status: Accepted
- Date: 2026-06-22
- Supersedes: none
- Related: ADR-005 (Frappe Cloud, Rule 3 suspended — in-app RQ/SocketIO), CLAUDE.md §12
  ("Messages threading" listed under items requiring an ADR before building)

## Context

The clinical web app ships a floating chat widget (`chat-widget.tsx`) with two tabs:

- **Threads** — WhatsApp patient conversations. Already bound to the backend via
  `api/v1/notifications/api.py` (`get_whatsapp_conversations`, `send_whatsapp_reply`, …).
- **Team** — staff-to-staff internal chat. Shipped with hardcoded mock data and local
  React state only. No backend, no persistence.

We need real internal messaging so clinic staff (front desk, nurses, practitioners,
admins) can coordinate ("patient in Room 2 is ready"). This is operational chat between
authenticated staff — not patient-facing, not clinical record data.

## Decision

Build internal team chat inside the `remedisys_healthcare_ai` app (Rule 1, ADR-005 — no
separate service). Three new custom doctypes plus a whitelisted API module.

### Doctypes

| Doctype | Kind | Purpose |
|---|---|---|
| `Chat Thread` | normal | One conversation (1:1 or group). Holds participants + last-message denormalised fields for cheap list rendering. |
| `Chat Thread Participant` | child of Chat Thread | A member (`user`) and their `last_read_at` (drives unread counts). |
| `Chat Message` | normal | One append-only message: `thread`, `sender`, `content`. |

- **1:1 dedup**: a direct thread stores `direct_key` = `"::".join(sorted([userA, userB]))`,
  indexed (not DB-unique — empty-string collisions on group threads). `start_thread`
  reuses an existing direct thread instead of creating a duplicate.
- **Unread** = `Chat Message` in the thread with `creation > participant.last_read_at` and
  `sender != me`. Opening a thread (`get_thread`) and sending (`send_message`) stamp
  `last_read_at = now`.
- **Text only** for v1. No media (the widget Team tab has no media affordance).

### API — `api/v1/messages/api.py` (custom whitelisted methods only, FRONTEND_CONTRACT)

`list_threads` (set_list_response) · `get_thread` · `send_message` · `start_thread` ·
`mark_read` · `list_contacts` (set_response). Every method gates on a staff role
(`EB_Front Desk | EB_Nurse | EB_Healthcare Admin | EB_Practitioner | System Manager`) and
on **thread membership** — a user can only read/post to threads they participate in. No
`ignore_permissions`, no `/api/resource/`.

### Realtime

Polling (react-query `refetchInterval`), matching the existing WhatsApp hooks
(15 s list / 10 s thread). SocketIO push is deferred — polling is sufficient at clinic
staff scale and keeps the binding identical to the rest of the widget.

## Consequences

- New tables; uninstall drops them with the app. No core tables touched (Rule 2 safe —
  removing the app leaves Healthcare working; team chat simply disappears).
- Row-level visibility is enforced in the API layer, not via Frappe user-permissions —
  consistent with the shared-inbox model already used for WhatsApp.
- Patient-only users have no staff role and are excluded by the role gate.
- No PHI: messages are free-text staff coordination. Staff are advised not to put PHI in
  chat; content is not indexed into logs (Rule 10).

## Alternatives rejected

- **Frappe core "Chat" / Comment / ToDo** — not a threaded multi-party messaging model;
  bending them is more work than three small doctypes and breaks the FRONTEND_CONTRACT.
- **A separate messaging service** — violates ADR-005 (single Frappe app for Phases 0–4).
- **DB-unique `direct_key`** — empty string for group threads collides; dedup in code.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-22 | Sarvesh | Initial version (header backfilled from git history) |
