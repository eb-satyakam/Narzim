# ADR-024: Nurse-Initiated Billable Procedure Recording

**Doc status:** living · **Created:** 2026-07-10 by Invincible · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-10
- **Supersedes:** —
- **Superseded by:** —

## Context

A nurse frequently performs a chargeable procedure in-house — a wound dressing,
an injection, nebulization, suture removal, ear syringing — that no physician
ordered on an encounter. Today there is no way for that act to reach the bill:

1. **No frontend path.** The entire Clinical Procedure lifecycle
   (`create/submit/start/complete/cancel_clinical_procedure`) exists and is
   permitted for `EB_Nurse`, but the app exposes **only** `list_procedure_templates`.
   The doctor's encounter merely *orders* procedures; My Work only *displays*
   them read-only; the nursing worklist has no procedure handling. Verified
   2026-07-10.
2. **Templates are not billable.** Every `Clinical Procedure Template` (including
   the seeded "Wound Dressing") has `is_billable = 0`, so even a completed
   procedure is skipped by `get_clinical_procedures_to_invoice`.

The billing engine itself already does the right thing: a Clinical Procedure with
`docstatus = 1`, `invoiced = 0`, and a billable template auto-appears in front
desk's cart (`get_patient_billables`). The gap is purely the capture path and the
config, not the billing math.

Constraints that shape this decision:
- **Rule 1 (upgrade-safe):** no core edits; new whitelisted methods + custom
  fields/fixtures only.
- **Rule 6 (physician in control):** a nurse may record procedures within her
  scope; she must not order physician-gated procedures. Precedent: **ADR-020**
  (vaccine nurse-administration handoff).
- **ADR-016 (internal/external pharmacy fulfillment):** the `has_internal_pharmacy`
  flag and `custom_order_channel` tag drive pharmacy queue/reporting — they are
  **not** a billing gate. Billing must not be suppressed by them (a clinic with no
  formal pharmacy still bills in-house dressings/injections).

## Decision

Add a **nurse-initiated "record procedure done" capability** that creates a
completed, billable Clinical Procedure which flows to front desk's cart via the
existing billing engine. The billing cart is the handoff — no manual message.

Concrete consequences:

1. **D1 — Trigger surface:** the nurse records a procedure from the **Nursing
   worklist (`/nursing`)** via a "Record procedure" action. (Patient Chart may
   add the same action later; the worklist is the first slice.)
2. **D2 — One-step recording:** a new whitelisted wrapper
   `record_procedure_done(patient, procedure_template, notes?, service_unit?,
   practitioner?)` performs create → submit → complete in one call, reusing the
   existing lifecycle functions. It is **idempotent** against accidental
   double-tap (guard on a recent identical patient+template+day record).
3. **D3 — Walk-ins allowed:** `appointment`/`encounter` remain optional; a
   procedure with no visit is valid. Front desk bills it from the cart, where the
   patient→customer link is resolved at invoice time.
4. **D4 — Billable set (PENDING INPUT):** the nurse-performable chargeable
   templates and their prices are supplied by clinical/admin, then applied via a
   repeatable seed/patch that sets `is_billable = 1` and a priced Item. **This
   ADR is not fully executable until D4 is provided.**
5. **D5 — Scope guard (Rule 6):** the nurse's picker is restricted to an
   **allow-list of nurse-performable procedures**. She cannot record
   physician-gated procedures. The allow-list is the enforcement point.
6. **D6 — "Billed externally" opt-out** for procedures is **deferred** to a later
   slice (it mirrors the Medication Request `custom_billed_externally` pattern
   from the medication discussion and is not required for this capability).

Billing is **not** gated on `has_internal_pharmacy` / `custom_order_channel`
(ADR-016) — a recorded in-house procedure is billable regardless of pharmacy
configuration.

## Alternatives Considered

1. **Manual message / task from nurse to front desk ("please bill a dressing").**
   - Pros: no schema/UI change.
   - Cons: no billable record is created, so it never enters the cart or the
     clinical record; error-prone, unauditable, easily missed. Rejected.

2. **Record the procedure done → auto-bill via the existing engine (chosen).**
   - Pros: reuses the full existing backend lifecycle + billing pickup; the
     procedure is a real clinical record; the cart is a reliable, auditable
     handoff; supports walk-ins.
   - Cons: needs new BFF routes + a UI surface + template billability config;
     `complete_procedure()` spawns post-op Nursing Tasks (manageable via
     side-effect-light templates).

3. **Gate billing on `has_internal_pharmacy` / channel (ADR-016) as the "bill
   in-house?" signal.**
   - Pros: reuses an existing flag.
   - Cons: wrong lever — a clinic without a formal pharmacy still bills ad-hoc
     in-house dressings/injections; this flag is for queue/reporting, not
     billing. Explicitly rejected per the product owner.

## Consequences

- **New backend:** `record_procedure_done` whitelisted wrapper in
  `api/v1/procedures/api.py` (+ idempotency guard). No core edits.
- **New frontend:** BFF routes (`record_procedure_done`, `list_clinical_procedures`)
  and a "Record procedure" action on `/nursing` with a template picker + notes +
  confirmation.
- **Config:** a seed/patch marking the D4 templates `is_billable = 1` with priced
  Items; and the D5 allow-list of nurse-performable procedures.
- **Docs:** companion plan `docs/audit/nurse/PLAN_NURSE_PROCEDURE_BILLING.md`;
  nurse audit README references this as the procedure-billing capability.
- **Re-evaluation triggers:** if procedures need per-instance pricing (not
  template-driven), or if the "billed externally" opt-out (D6) becomes required,
  revisit.

## Verification

- Live end-to-end: as `EB_Nurse`, `record_procedure_done(patient, "Wound Dressing")`
  → the Clinical Procedure is `docstatus=1`, `status=Completed` → it appears in
  `get_patient_billables(patient)` under a procedure line → front desk creates a
  Sales Invoice from the cart → `invoiced` flips and it leaves the cart.
- Regression test (rolled back): nurse records a billable procedure → present in
  cart; a non-allow-listed template is rejected (D5); double-tap yields one record
  (idempotency).
- Config check: the D4 templates show `is_billable = 1` with a resolvable priced Item.

## References

- Constitution Rule 1 (upgrade-safe), Rule 6 (physician in control), §12 (billing)
- ADR-016 internal/external pharmacy fulfillment (billing not gated on it)
- ADR-020 vaccine nurse-administration handoff (precedent for nurse-performed billable acts)
- ADR-022 nurse encounter draft write (nurse clinical-write precedent)
- Plan: `docs/audit/nurse/PLAN_NURSE_PROCEDURE_BILLING.md`
- Backend: `api/v1/procedures/api.py`, `services/billing.py` (`get_patient_billables`),
  healthcare `get_clinical_procedures_to_invoice`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
