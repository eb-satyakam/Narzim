# ADR-025: Encounter Opt-In Billing Selection and Two-Part Vaccine Charging

**Doc status:** living · **Created:** 2026-07-15 by Divyanshu · **Updated:** 2026-07-15 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-15
- **Supersedes:** the vaccine billing model in ADR (Flow B, "the Immunization's `vaccine` Item IS the billable line") — see `services/billing.py::list_billable_immunizations`. Partially revisits the `custom_billed_externally` opt-out from the medication-billing discussion (ADR-024 D6).
- **Superseded by:** —

## Context

Front desk's consolidated cart (`get_patient_billables`, ADR-017) today bills
**everything** a patient has un-billed: every submitted Medication Request, every
Service Request the aggregator returns, and every un-invoiced Immunization. There
is no way for the physician to say "this order is clinical only — do not charge
for it." Two real situations force a change:

1. **No pharmacy / doctor-dispensed medicine.** Not every clinic runs an in-house
   pharmacy. In those clinics the physician hands over some medicines directly and
   the patient buys the rest elsewhere. Billing must reflect **only what the clinic
   actually provides**, not the full prescription. The current default (bill all
   prescribed drugs) over-bills.

2. **Vaccines are a single all-in line.** `list_billable_immunizations` bills one
   line — the vaccine product Item off the `Immunization` record. It cannot
   separate the **product** (the vial) from the **administration** (the injection
   service), which are distinct charges and behave differently when the patient
   brings their own vaccine (product not charged, injection still charged). The
   `VAC-APLICACION` administration item was seeded for exactly this but was never
   wired into billing.

Facts about the system that shape the decision (all verified 2026-07-15):

- Encounter child rows become billable docs **inside ERPNext core** on submit:
  `drug_prescription` → **Medication Request**, `lab_test_prescription` /
  `procedure_prescription` / `therapies` → **Service Request**
  (`patient_encounter.py::make_medication_request` / `make_service_request`).
  Core does **not** copy unknown custom fields onto the docs it creates.
- Both **Medication Request** and **Service Request** carry a `billing_status`
  (`Pending` / `Partly Invoiced` / `Invoiced`). The medication cart filters
  `billing_status in (Pending, Partly Invoiced)`; the core service aggregator
  filters `billing_status != "Invoiced"` (`get_service_requests_to_invoice`).
  Neither field is re-derived on ordinary saves — only a real Sales Invoice
  submit/cancel recomputes it. So `billing_status = "Invoiced"` is a reliable,
  already-supported "exclude from cart" lever with no new schema.
- There is **no native per-order "not billable" flag or status** on either
  doctype — the only Select values are `Pending / Partly Invoiced / Invoiced`.
- Vaccines use two custom doctypes: **Patient Vaccine** (assignment/order) and
  **Immunization** (the recorded shot). `Immunization.supply` is a Select
  `In-house stock / Patient-supplied / External-history`, set by the nurse at
  administration. Per ADR-020 the physician never records a dose in-room; the
  nurse records it later via `create_immunization_record`.
- The app has never created a Service Request directly — core always did. Doing so
  at injection time is a new (but Rule-1-safe) pattern.

Constraints:
- **Rule 1 (upgrade-safe):** no core edits; custom fields/fixtures + whitelisted
  methods only. The MR/SR stamping happens in our app code post-submit.
- **Rule 6 (physician in control):** the physician decides what is billed, at the
  point of ordering.

## Decision

Introduce a **physician-controlled, opt-in billing selection** captured on the
Patient Encounter, and split vaccine charges into **product + administration**.
Reuse core's `billing_status` as the exclusion lever — do **not** add a new
per-order "bill this" custom field.

Concrete decisions:

1. **D1 — Per-order "bill this" checkbox, facility-driven default.** The encounter
   form shows a "Bill this" checkbox on every orderable row (drugs, labs,
   procedures, therapies). The choice round-trips through `save_draft` so it
   survives draft reload.

   **Amended 2026-07-15 — default is no longer unconditionally ON.** The default
   checked state is now driven by whether the clinic provides that service
   in-house, read from **EB Clinic Settings** (the same four flags
   `overrides/encounter_orders.py` uses for Internal/External channel tagging):

   | Order type | Default "Bill this" |
   |---|---|
   | Drugs (`drug_prescription`) | `has_internal_pharmacy` |
   | Labs (`lab_test_prescription`) | `has_internal_lab` |
   | Procedures (`procedure_prescription`) | `has_internal_procedures` |
   | Therapies (`therapies`) | `has_internal_therapy` |

   Rationale: a clinic with no in-house pharmacy hands over or refers out most
   medicines and should not bill them by default; the physician *checks* the ones
   the clinic actually charges for. `get_clinic_settings` falls back to
   all-external (every flag OFF) when no settings row exists, so an **unconfigured
   clinic bills nothing by default** until it configures its facilities — a
   deliberate reversal of the original revenue-safe "bill all" default. A present
   per-row flag (physician's explicit choice) is always authoritative over the
   default. The three enforcement points — display (`_fmt_encounter`), save
   (`save_draft`) and submit (`_stamp_billing_optout`) — share one
   `_bill_defaults_for_company` helper so they cannot drift. The full encounter
   response also echoes `bill_defaults` so the frontend can seed the checkbox for a
   newly added, not-yet-saved order row.

2. **D2 — Exclusion lever is `billing_status = "Invoiced"`, no new field.** For any
   order the physician **unchecks**, the app stamps the resulting billable doc
   (`Medication Request` / `Service Request`) to `billing_status = "Invoiced"`
   (and `qty_invoiced = quantity`, to stay internally consistent). Checked orders
   are left `Pending` and bill normally. This reuses the exact fields core already
   filters on, so the cart needs **no filter changes** for services (the aggregator
   already excludes `Invoiced`) and the existing medication filter already excludes
   it.

3. **D3 — Stamping is post-submit, in our code.** Because core creates the MR/SR on
   `doc.submit()` and ignores our custom fields, `complete_encounter` reads each
   child row's checkbox after submit and, for unchecked rows, stamps the created
   MR (`drug.medication_request`) / SR (`row.service_request`) via `db_set`. No
   core file is touched. The per-row choice is persisted on the encounter child
   rows via one custom field per child doctype (see D9) purely as the *carrier* of
   the physician's intent from draft to submit — it is **not** the billing gate;
   `billing_status` is.

4. **D4 — Vaccines bill as two documents.** A vaccine produces up to two billables:
   - **Product** → a **Medication Request** (the vial), so it bills as a medication
     and carries `billing_status`.
   - **Administration** → a **Service Request** (the injection), so it bills as a
     service and carries `billing_status`.
   This retires the single all-in Immunization line.

5. **D5 — `supply` governs which vaccine components bill.** Set at administration:

   | `supply` | Product (Medication Request) | Injection (Service Request) |
   |---|---|---|
   | In-house stock | created (billable) | created (billable) |
   | Patient-supplied | not created | created (billable) |
   | External-history | not created | not created |

6. **D6 — Both vaccine billables are created at administration**, in
   `create_immunization_record`, not at assignment. Rationale: `supply` (D5) is only
   known when the nurse records the dose, so creating the product MR at assignment
   would risk billing a no-show or a patient-supplied dose. Assignment
   (`ensure_patient_vaccine` / `assign_vaccine` / `apply_program`) creates no
   billable. (This is a deliberate refinement of the "create the MR at assign"
   request — the billable is created at the moment its billability is actually
   determinable.)

7. **D7 — Single flat "Vaccine Administration" service.** The injection Service
   Request points at one billable Clinical Procedure Template ("Vaccine
   Administration") whose billable Item is the seeded **`VAC-APLICACION`** priced at
   **150 MXN** — a flat fee for all vaccines. A repeatable seed/patch ensures the
   template exists with `is_billable = 1` and is linked to the priced
   `VAC-APLICACION` Item. (Confirmed 2026-07-15.)

8. **D8 — Retire `list_billable_immunizations`.** The old Immunization-as-line path
   is removed from `get_patient_billables` and the invoice builders so a vaccine is
   never billed twice (once as the Immunization line and once as the new product
   MR). Vaccine billing flows entirely through the MR (product) + SR (injection)
   from D4–D6.

9. **D9 — Carrier fields.** One `Check` custom field per encounter child doctype
   (`Drug Prescription`, `Lab Prescription`, `Procedure Prescription`,
   `Therapy Plan Detail`), default `1`, to carry the physician's "bill this" intent
   from draft through submit. These carry intent only; the enforced billing state
   lives in `billing_status` (D2). No custom field is added to Medication Request or
   Service Request for this feature.

Scope boundary: the per-order opt-in (D1) applies to **drugs, labs, procedures,
therapies**. **Vaccine billing is governed by `supply` (D5)**, not by an encounter
checkbox, in this slice. A "do not bill this in-house vaccine" case (e.g. a
government-funded dose given from clinic stock) is **deferred** — see
re-evaluation triggers.

Prerequisite: `Healthcare Settings.process_service_request_only_if_paid` must be
**OFF**. If it is on, `billing_status = "Invoiced"` on an excluded Service Request
would bypass the "process only if paid" gate; verify at implementation.

## Alternatives Considered

1. **New per-order `custom_bill_this` flag on Medication Request + Service Request,
   filtered explicitly in the cart.**
   - Pros: semantically honest (an excluded order is *not* marked "invoiced");
     trivially reversible (flip one boolean); one uniform flag across all types.
   - Cons: new custom fields on core doctypes; a data-migration patch to backfill
     existing pending orders; the cart's service path (core aggregator) can't read
     a custom field without our own SR pre-scan, adding code. More surface for the
     same outcome.

2. **Reuse core `billing_status = "Invoiced"` as the exclusion lever (chosen).**
   - Pros: zero new billing fields; the cart already filters on it (no service
     filter change); not re-derived except by a real invoice; minimal code — the
     work is the checkbox + a post-submit `db_set`.
   - Cons: semantically "already invoiced" — an excluded order reads as *paid* in
     any surface that interprets `billing_status` (ERPNext's core patient portal;
     not our Next.js UI, which reads paid-state from Sales Invoices). Reversing a
     mistaken exclusion needs a `db_set` back to `Pending`, not a UI toggle. Chosen
     because the semantic leak is confined to core surfaces we do not use, and the
     simplicity is decisive.

3. **Keep the single all-in Immunization billing line; add an optional admin-fee
   line beside it.**
   - Pros: least change to the vaccine path.
   - Cons: leaves vaccines outside the uniform `billing_status` model (the vaccine
     gap that forced a special filter); can't reuse the D1/D2 opt-in for vaccines;
     the product/patient-supplied/external distinction (D5) stays ad-hoc. Rejected
     in favour of the uniform MR + SR model.

## Consequences

- **Backend:**
  - `fixtures/custom_field.json` — four `Check` carrier fields (D9), default `1`.
  - `api/v1/encounters/api.py` — `_apply_*` helpers accept + persist the flag per
    row; `save_draft` round-trips it; `complete_encounter` stamps unchecked orders'
    MR/SR to `billing_status="Invoiced"` post-submit (D2/D3).
    `_bill_defaults_for_company` (D1 amendment) resolves the facility-driven
    default from EB Clinic Settings and is shared by display, save, and submit;
    the full encounter response echoes `bill_defaults`.
  - `api/v1/immunizations/api.py` — `create_immunization_record` creates the product
    MR and injection SR per D4–D6.
  - `services/billing.py` — remove `list_billable_immunizations` from the cart and
    invoice builders (D8); no other cart-filter change needed.
  - Seed/patch for the "Vaccine Administration" billable template + priced Item (D7).
- **Frontend (`EB_Healthcare_Frontend`):** a "Bill this" checkbox per order row in
  the encounter form (`encounter-screen.tsx` + state/type/payload/i18n changes,
  bilingual `en`/`es`). Minor: add the missing `medication` group label/icon in the
  checkout cart.
- **Supersedes** the Flow-B vaccine billing note in `services/billing.py`.
- **Re-evaluation triggers:**
  - If a "do not bill this in-house vaccine" (free/government dose) need arises,
    extend the opt-in to vaccines (a carrier on Patient Vaccine, or a fourth
    `supply` value).
  - If reversibility of an accidental exclusion becomes a support burden, revisit
    Alternative 1 (honest `custom_bill_this` flag).
  - If per-vaccine (not flat) administration pricing is required, revisit D7.
  - If `process_service_request_only_if_paid` is ever enabled, D2's lever must
    change.

## Verification

- Live, as physician: sign an encounter with two drugs, one **unchecked** →
  after submit the checked drug's Medication Request is `billing_status=Pending`
  and appears in `get_patient_billables`; the unchecked drug's MR is
  `billing_status=Invoiced` and is **absent** from the cart. Same for a lab/
  procedure via Service Request.
- Live, vaccine: nurse records an **In-house** dose → a product Medication Request
  and an injection Service Request both appear in the cart (two lines);
  **Patient-supplied** → only the injection line; **External-history** → no line.
  No duplicate line from the retired Immunization path.
- Config check: the "Vaccine Administration" template is `is_billable=1` with a
  resolvable priced Item; `process_service_request_only_if_paid` is OFF.
- Facility-driven default (D1 amendment): in a clinic with `has_internal_pharmacy=0`,
  a drug ordered and left untouched submits with its Medication Request
  `billing_status=Invoiced` (absent from the cart); with `has_internal_pharmacy=1`
  the same drug bills. Same matrix for labs/procedures/therapies against their flags.
  An unconfigured clinic (no EB Clinic Settings row) bills nothing by default.

## References

- Constitution Rule 1 (upgrade-safe), Rule 6 (physician in control), §12 (billing)
- ADR-017 front-desk POS consolidated billing (`get_patient_billables`)
- ADR-016 internal/external pharmacy fulfillment (billing not gated on pharmacy config)
- ADR-020 vaccine nurse-administration handoff (assignment → nurse records dose)
- ADR-024 nurse-initiated billable procedure (Clinical Procedure billing precedent; `custom_billed_externally` opt-out precedent)
- Backend: `api/v1/encounters/api.py`, `api/v1/immunizations/api.py`,
  `services/billing.py`; core `patient_encounter.py` (`make_medication_request`,
  `make_service_request`), core `utils.py` (`get_service_requests_to_invoice`,
  `get_drugs_to_invoice`)
- Frontend: `EB_Healthcare_Frontend` `src/components/narzim/encounter/encounter-screen.tsx`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-15 | Sarvesh | Initial version (header backfilled from git history) |
