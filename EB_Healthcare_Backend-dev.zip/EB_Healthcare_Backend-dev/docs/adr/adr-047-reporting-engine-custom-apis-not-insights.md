# ADR-047: Clinical reporting is served by our own whitelisted APIs, not a BI tool

**Doc status:** draft · **Created:** 2026-08-25 by Anant Sharma (AI-assisted) · **Updated:** 2026-08-25 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Proposed — not yet agreed. Must not be cited as decided.
- **Date:** 2026-08-25
- **Supersedes:** —
- **Superseded by:** —
- **Full rationale:** [`docs/architecture/REPORTING_STRATEGY.md`](../architecture/REPORTING_STRATEGY.md).
  This ADR records the *decision*; that document owns the evidence, the report classification, and
  the caching policy.

## Context

Frappe Insights v3.12.6 was installed on the local bench on 2026-08-24. It is a capable
open-source BI tool. The question raised was whether it should serve the product's Reports
screens — in particular whether it would relieve report latency at a target scale of ~5,000
patients and ~500 practitioners.

Two facts frame the decision:

1. **Reporting is already built.** Seventeen whitelisted endpoints across eight
   `api/v1/<module>/report.py` files (~2,150 lines) back seventeen Next.js screens. Both
   `CLAUDE.md` §12 and `REPORTS_API.md`'s own intro still describe this as unbuilt; they are
   stale.
2. **Report latency is a query-shape problem.** Measured on `remedisys.localhost`: all 33
   `frappe.get_all` calls use `limit_page_length=0` and aggregate in Python; there is no SQL
   `GROUP BY` anywhere. Python-loop versus SQL aggregation over identical data measured 2.2 ms
   vs 1.9 ms at 1,027 rows and **37.8 ms vs 9.9 ms (3.8×) at 8,183 rows**, with the gap widening
   because the Python path is O(rows transferred) and the SQL path is O(groups).

## Decision

1. **Clinical and operational reporting is served by our own whitelisted methods** in
   `api/v1/<module>/report.py`, consumed through the Next.js BFF. This is the only sanctioned
   reporting path for product screens.
2. **Frappe Insights is not a product surface.** It is retained as an internal analyst/developer
   sandbox for ad-hoc questions and for prototyping the aggregations of reports not yet built.
   No `Insights User` / `Insights Admin` role is granted, and clinical tables are out of scope.
3. **Report performance is addressed by optimising the queries** — SQL aggregation, indexes,
   bounded scans, and a cache tiered by staleness tolerance — **not** by adopting a BI tool or a
   separate warehouse.
4. **Promotion of Insights to any clinic site requires a superseding ADR** plus the five controls
   in `REPORTING_STRATEGY.md` §4.

## Alternatives considered

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | **Optimise `report.py` in place** (chosen) | Measured 3.8× and widening; no new infrastructure; no PHI duplication; every permission guarantee preserved; ~1–2 days | Provides no ad-hoc exploration |
| B | Insights + DuckDB warehouse as the reporting engine | Genuinely fast columnar analytics; ad-hoc querying for free | Duplicates PHI to `private/files/*.duckdb`; stale by refresh interval; parallel permission model; **does not speed up the existing 17 screens**; contradicts §3 and ADR-010 |
| C | Nightly pre-aggregated summary doctypes in our own app | Near-instant reads; stays inside `api/v1`; no new dependency | Stale by up to a day; new doctypes need their own ADR; more code to own |
| D | Accept current performance | No work | Degrades monotonically as data grows |

**Why the others lose.** **B** answers a query-optimisation problem with a data-duplication
architecture: its cost is paid in PHI surface (a `Site DB` source is auto-created on migrate,
indexing 1,015 tables of which 38 are clinical; team permissions default to off; the query log
stores raw SQL, breaching Rule 10) while its benefit lands on a different UI — the seventeen
product screens stay exactly as slow. It would also delete working `report_practitioner_scope()`
enforcement and replace it with a default-permissive model. **C** is the correct *second* step if
A proves insufficient beyond roughly three years of data, and it keeps everything inside the
service layer that B abandons; it is not first because it trades freshness for speed we have not
yet demonstrated we need. **D** loses because the trend moves one way only.

## Consequences

- The `api/v1` service layer (`CLAUDE.md` §3) and the BFF boundary (ADR-010) remain unbroken for
  reporting.
- `report_practitioner_scope()` stays the single enforcement point preventing one practitioner
  from reading another's data.
- Ad-hoc analytical questions still require a backend change to reach a clinic user; only bench
  users get self-service. Accepted for now.
- Insights remains installed and unused on the local bench. **Its current safety rests on nobody
  holding an Insights role — an accident of a fresh install, not a control.** This ADR makes the
  scope deliberate.

## Verification

- No `Insights User` or `Insights Admin` role holders on any clinic site.
- No product screen calls an Insights endpoint.
- After the §9 optimisation work in `REPORTING_STRATEGY.md`, re-benchmark at synthetic volume
  (~20,000 appointments) and confirm analytical reports stay under one second.

**What would falsify this decision:** if profiling after A still shows multi-second aggregate
reports at realistic volume, C becomes correct. If the demand turns out to be clinicians
self-serving novel clinical questions rather than faster fixed screens, B deserves a real hearing
with its five controls in place.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-25 | Anant Sharma (AI-assisted) | Initial draft — proposed, not ratified |
