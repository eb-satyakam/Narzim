# ADR-052: Extract a multi-file lab upload in ONE call, then recover dropped documents with bounded per-file re-checks

**Doc status:** living · **Created:** 2026-08-25 by Divyanshu (AI-assisted) · **Updated:** 2026-08-26 by Divyanshu (AI-assisted) · **Version:** 3.0

- **Status:** Accepted — Alternative 1 (one call + bounded recovery), implemented 2026-08-25. Reached
  after Alternative 2 (one call per file) was implemented and reverted the SAME day; that attempt and
  why it was withdrawn are recorded verbatim under Alternatives Considered, because the reasoning is
  the whole point of this ADR.
- **Date:** 2026-08-25
- **Supersedes:** — (refines the extraction step of ADR-022; nothing in ADR-022 is reversed)
- **Superseded by:** —

## Context

ADR-022 established multi-panel extraction: one uploaded batch, one LLM call against the site-wide
analyte catalog, results bucketed onto owning Lab Test Templates. It did not say how many provider
calls a batch of N files should cost, because at the time a batch meant "the pages of one report".

Real use broke that assumption. Clinicians upload **several genuinely unrelated documents together** —
on 2026-08-25 a single upload contained a serotype photo, a scanned cardiology consult, a 13-page
genetic report, a hormonal panel, a scanned pneumonia discharge note and a liver panel: six files,
six documents, three different patients.

Three defects surfaced against that reality, all verified on live records:

1. **Silent document loss.** With everything in one call the model decided, unprompted, how many
   distinct documents it had seen — and sometimes dropped one entirely. `status=Success`, no error,
   no warning, the file's content simply absent. Confirmed repeatedly, always on **scanned** files
   (`AI Prompt Log` `adm7hgp26m`, `k5m9pi7r7r`), because a digital PDF's text layer carried its
   content through other paths while a scan had nothing to fall back on.

2. **No bound on a stalled call.** The extraction call passed no `timeout`, so it inherited the
   OpenAI SDK default — a 600 s read timeout plus up to two retries (verified by inspecting
   `OpenAI().timeout` directly). One upload sat at `status=Extracting` for **43 minutes**. Three
   separate uploads reached this state in one afternoon.

3. **`source_file_index` is not an address.** v13 asked the model to tag each value with its
   1-based upload position so a gap could be located. Observed values were offset (`2/3/4` for three
   files) and, worse, **skipped** (`{1, 3}` for three files with the middle document dropped;
   `{1, 5, 7}` for six files). Rank-normalising `{1, 3}` → positions `{1, 2}` made the completeness
   check "locate" the gap at position 3 and re-check a file that had been read correctly, while the
   genuinely missing file was never looked at again.

Constraints that shape the decision: Rule 7 (an AI failure must degrade visibly, never silently),
Rule 9 (deterministic pipelines over model judgment), the site's single background worker
(`worker-pool --num-workers 1`, deliberate — `scripts/dev/run_worker.sh` documents it as a
Python 3.14 fork-safety workaround), and `frappe.enqueue`'s 1500 s budget for the `long` queue.

## Decision

**Extract the whole upload in ONE provider call. Then establish coverage from evidence we already
hold — the files' own text, and OCR where there is none — asking the model only "how many documents
did you see", never "which file did this come from". Spend an extra per-file call only on what none
of that can settle, under a job-wide deadline.**

1. `services/lab_panel_extraction.py::run_panel_extraction` makes one
   `llm.extract_multi_panel_report(files, ...)` call for the entire upload.
2. That call carries an explicit `timeout`, from
   `AI Settings.lab_extraction_call_timeout_seconds` (default 420 s — see Consequences for why that
   number and not a rounder one). Never hardcoded at the call site.
3. **Coverage is established deterministically, per file, with no LLM call.**
   `_coverage_by_attribution` searches each uploaded file's OWN text for the response's structured
   output: a parameter is attributed to a file when both its name and its value appear in that
   file's text; a narrative when a third of its long words do. Searching the SOURCE rather than the
   response means nothing the model wrote can manufacture a false confirmation. A digital PDF is
   thereby settled outright — proven present (skip) or proven absent (must re-check).
4. **For files with no embedded text (scans, photos), OCR locally before spending an LLM call.**
   `_ocr_verified_positions` runs `services/ocr_text_extraction.py` (already in the app, bilingual
   eng+spa, already used by the Narzim assistant) over just the re-check candidates and drops the
   ones it can verify. It runs ONLY on files already destined for a re-check, so a healthy upload
   pays nothing for it, and it replaces a 30–70 s billed call with ~13–17 s of local CPU.
   **HARD BOUNDARY: OCR text is used only for this internal check and is NEVER sent to the model** —
   Adobe Scan embeds its own unreliable OCR layer and feeding that to the model corrupted extraction
   earlier the same day, which is exactly why `pdf_pages.looks_like_scanned_pdf` reports "no text
   layer" for a scan.
5. **The model's numbering is read as a COUNT only, and only for what deterministic means cannot
   settle.** Compare distinct `source_file_index` values against the file count; a shortfall marks
   the still-unverifiable files for re-check. It is never used to identify WHICH file is missing.
6. Whatever survives all of the above is re-checked with one solo LLM call
   (`_recover_missing_file`), guarded by content-based dedup (normalised title / first 200 chars /
   `(name, value)` pairs) so a file already captured contributes nothing on its second pass.
7. Recovery runs against `_recovery_deadline_seconds()` — 75 % of the RQ `long` budget, read from
   Frappe rather than assumed. On reaching it, remaining files are named in
   `incomplete_files_warning` instead of being attempted.
8. A file still unaccounted for after its own re-check is named in
   `AI Prompt Log.incomplete_files_warning`, surfaced to the review screen as an
   `incomplete_files` warning.
9. `source_file_index` is used for **nothing else**. File attachment and `custom_report_group`
   stay whole-upload (every Lab Test from one upload gets every file and one shared group).
10. The deterministic text-layer substitution in `_finalize_narrative_report` requires the upload to
    be **exactly one PDF** (`_single_pdf_file`), not merely to contain one narrative.

## Revision (same day, 2026-08-25) — how the recovery step got to its final shape

The Decision above is the third form the recovery step took on 2026-08-25. Both earlier forms
shipped, and both were replaced within hours. Recorded because each replacement was driven by
evidence, and because the sequence is the argument for the final design.

1. **Rank-mapped index → re-check the implicated position.** Assumed the model's numbering was
   offset but order-preserving. Broke on a *skip*: `{1, 3}` for three files rank-mapped to positions
   `{1, 2}`, so the check re-read a file that had been read correctly while the genuinely missing one
   was never looked at again. This is why the same cardiology scan was lost twice after being
   "fixed". Function deleted; the reasoning is left in its place in the source.
2. **Count-based → re-check EVERY file.** Correct but expensive: 6 extra billed calls on a 6-file
   shortfall, and it fired on 40 % of multi-file uploads (2 of 5 on record). It also spent calls
   re-discovering content that was demonstrably already present.
3. **Deterministic attribution, then OCR, then the count (final).** Measured on the same real 6-file
   upload: **6 → 2 re-checks**, and **6 → 0** when nothing is actually missing.

The through-line: each step moved a question away from the model and onto evidence we already hold.
The model is now asked only "how many documents did you see", never "which file did this come from".

## Alternatives Considered

**Alternative 1 — One call, then bounded per-file recovery (CHOSEN).**
**Pros:** one call in the common case, so the normal path costs exactly what it did before;
extra calls only when something is genuinely unaccounted for; the count-based check needs the
numbering to be right about *how many*, not *which*, which is the weaker and empirically reliable
claim; the deadline guarantees the job reaches its own save.
**Cons:** a shortfall on a 6-file upload costs up to 6 extra sequential calls (~5–7 min measured);
a single report photographed across several files legitimately reports one document for N files and
so pays that cost while finding nothing new.

**Alternative 2 — One call per file, always (IMPLEMENTED, THEN REVERTED SAME DAY).**
Every uploaded file gets its own extraction call; results merged into one proposal set. Attribution
comes from the loop index, so it needs nothing from the model.
**Pros:** a file cannot be skipped when it is the only thing in its call — the guarantee is
structural, not probabilistic; deletes the numbering, the completeness check, the retry and the
dedup outright.
**Cons, and why it was withdrawn:** it multiplied provider calls by N on **every** upload,
including the healthy majority. Measured on the same four files: 158.6 s sequential vs 85.8 s
batched (1.85×), input tokens 1.95× (the analyte catalog is re-sent per call). Running the calls
in a thread pool did beat the batched baseline (66.5 s), but combined with defect 2 above — no
timeout anywhere — one stalled call held an entire upload for 20+ minutes with the record stuck at
`Extracting`. Paying N× on every upload to fix a minority failure was the wrong trade against a
single worker shared by the whole clinic.

**Alternative 3 — Trust `source_file_index` as an address, rank-normalised.**
Map the model's reported indices onto upload positions by rank and re-check only the positions that
appear uncovered.
**Pros:** at most one extra call, precisely targeted; cheapest possible repair.
**Cons:** empirically wrong, and wrong in the dangerous direction. Rank-normalisation is only valid
when the numbering is offset but complete; on a **skip** it silently re-targets the check at an
already-read file and reports success. This shipped, and it is the reason a cardiology scan was
lost twice with no warning. Removed, with the reasoning left in place of the deleted function so it
cannot be reintroduced.

**Alternative 4 — Add workers / a dedicated extraction queue instead.**
Leave the per-upload cost alone and buy parallelism.
**Pros:** no extraction-logic change; also fixes multi-user queueing, which none of the above do.
**Cons:** does not address silent document loss at all — a dropped document stays dropped, just
sooner. The single worker is a documented Python 3.14 fork-safety workaround, so raising it is not
free, and production runs on Frappe Cloud where the worker count is a plan/config matter outside
this repo. Orthogonal, and still open (see References).

## Consequences

1. **Normal uploads cost exactly one call**, as before this ADR. Verified across the site's own
   history: 3 of 5 multi-file uploads reported a distinct document per file and would make zero
   extra calls.
2. **Shortfall is common enough to matter**: 2 of 5 multi-file uploads on record (40 %). A 6-file
   shortfall measured ~5–7 min wall clock; the deadline caps the pathological case at ~19 min with a
   warning rather than a kill.
3. **420 s timeout, chosen from the site's own data, not a round number.** Two earlier guesses were
   both wrong in the dangerous direction — 90 s, then 240 s — and the log then produced a genuinely
   **successful** 2-file call at **301 s** (`lgr3g5g6sn`) that either value would have killed,
   converting a slow-but-working extraction into an outright failure. 420 s clears the observed
   worst case with margin.
4. **A killed job is worse than a skipped re-check.** Overrunning the RQ budget does not fail
   gracefully: RQ kills the job, so the `except` block that records `status=Failed` never runs and
   the record is left at `Extracting` with no error, forever. Hence the deadline.
5. **`source_file_index` is now load-bearing for one thing only** (the count). It remains in the v13
   schema and prompt; nothing reads it as an address. A future pass may drop it entirely if the
   deterministic check below replaces the count.
6. **A single report split across several files** loses the deterministic text-layer substitution
   (consequence 8 of the Decision) and falls back to the model's own transcription, which prompt v10+
   keeps structurally faithful. Accepted: the alternative welded unrelated documents together.

## Verification

- **Silent loss, reproduced and fixed.** Mocked the exact failure shape (indices `{1, 3}`, file at
  position 1 omitted): cardiology narrative recovered, no duplicate Litio, no duplicate Serotipo,
  no false warning. Live end-to-end on the same three real files that lost the cardiology scan:
  `ECOCARDIOGRAMA` present, all three documents found, 174 s.
- **Zero cost on healthy uploads.** 3 files all reported → 1 call. Odd numbering `2/3/4` (count
  still correct) → 1 call. Single file with content but no index → 1 call. Single file with an
  empty response → 1 re-check plus a correct warning.
- **Deadline guard.** Simulated 6 files at 400 s per re-check: job stopped at the budget,
  `status=Success`, warning named the three un-checked files. Completed instead of being killed.
- **Text-layer scoping.** Several PDFs → keeps the model's own transcription; exactly one PDF →
  substitutes as intended; one PDF but scanned → keeps the transcription; one photo + one unrelated
  PDF → the photo's narrative is no longer overwritten by the PDF.
- **Regression:** 55 tests in `tests/labs/` pass, with two pre-existing failures unrelated to this
  work (`test_filled_result_enqueues`, `test_retry_works_on_submitted_lab_test` — both assert
  `maybe_generate_summary` enqueues, which ADR-033 retired to a no-op).

- **Deterministic attribution** (Decision 3), validated on two independent live records before any
  code was written: `Z005.pdf` attributed its 11 liver-panel parameters, `817-1012` its Litio, the
  Invitae report its narrative — while the two scans and the photo correctly came back unverifiable,
  exactly the set that needed re-checking. Then by scenario: 3 digital + complete count → 0
  re-checks; 3 digital + short count (false alarm) → **0** (was 3); 1 digital + 2 scans + short
  count → 2 (was 3); 1 digital + 2 scans + complete count → 0 (was 3); 2 digital genuinely absent →
  2 plus a correct warning.
- **OCR pre-filter** (Decision 4), on the real files: the scanned cardiology consult OCR'd to 9,772
  chars and its narrative matched 56/60 long words; the phone photo of the serotype panel OCR'd to
  only 1,797 noisy chars yet still attributed all 12 of its parameters by name+value. No false
  positive in either direction. End-to-end on the real 6-file upload with the main call mocked to
  reproduce the observed shortfall and OCR running for real: **2 re-checks instead of 6**, 81 s wall,
  and the warning correctly named the two documents that were genuinely absent from the response.

> ⚠️ **VERIFICATION WAS INCOMPLETE WHEN THIS WAS WRITTEN — now partly closed, see the 2026-08-26
> revision below.** The original warning read: no live UI upload had exercised any of this; every
> result came from scripts run via `bench execute` and from replaying stored records, while the RQ
> worker still held pre-change code. That gap is now closed — live UI uploads have run on `v14`
> (`g4sfv8ncqk`, `sabqnuktlt`, `pa8ndq37l9`) and exercised the timeout, the deadline, the
> deterministic attribution and the OCR pre-filter. **The outstanding check named `prompt_version=v13`;
> the live version is now `v14`.** What live use then exposed is recorded in the revision below, and
> the still-open items are in [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md). The original lesson stands:
> three defects reached production because passing scripts were mistaken for a working system.

## Revision (2026-08-26) — what live use exposed

The decision above holds. Live uploads found three defects in how it interacts with the prompt, none
of which change the one-call-plus-bounded-recovery shape:

1. **A marker could pass every guard while carrying no report text.** Prompt v13's REFERENCE TEXT
   SHORTCUT let the model write `[full text supplied via reference layer]` instead of transcribing,
   on a precondition ("only ONE narrative document in this batch") it was asked to police in prose.
   On a 7-file upload with three narratives it took the shortcut for two, nothing substituted the
   text back (the upload was six PDFs, not one), and two reports were stored as 82- and
   75-character placeholders with `status=Success` and an empty `incomplete_files_warning`. It stayed
   silent because the marker keeps the document's real TITLE: `_response_attributable_to` found the
   title's words in that file's own text and recorded the document as PROVEN present, and
   `_recover_missing_file`'s title dedup discarded the real transcription as a duplicate of the
   placeholder. Fixed by moving the shortcut out of the static prompt into
   `build_reference_text_instruction(allow_shortcut=...)`, which the caller sets only when the
   substitution can actually happen — and by treating a marker body as EMPTY in both guards
   (`_is_marker_body`), repairing it in place, and naming any that survive.

2. **The deadline was a start-by time, not a return-by time.** `_recovery_deadline_seconds` bounded
   when a re-check could *begin*, then handed it the full per-call timeout — so with the site's own
   values (1500 s budget, 0.75 fraction, 420 s per call) a call cleared at 1124 s could return at
   1544 s and be killed, which is the exact stuck-at-`Extracting` failure this ADR exists to prevent.
   `_recovery_call_timeout` now clamps each call to the budget actually left. Deliberately arithmetic
   rather than a re-tuned constant: both the timeout and the queue budget are configurable.

3. **Recovery calls write no `AI Prompt Log` row**, so whether a re-check timed out or returned
   nothing can only be inferred from wall-clock subtraction. Open — see `docs/KNOWN_ISSUES.md`.

**What live use did NOT fix, and is now the top of this feature's list:** documents are still dropped
from multi-file uploads, and every extracted parameter still matches zero templates. Both are
recorded with evidence in [`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md). The dropped-document cause is
upstream of everything in this ADR — the request itself tells the model the upload is ONE report —
which is why more recovery machinery is not the answer.

## References

- ADR-022 — multi-panel extraction (this ADR refines its extraction step only)
- ADR-033 — report summary storage; `maybe_generate_summary` retired to a no-op
- ADR-005 — the suspended FastAPI sidecar, the documented end-state for slow LLM work; this ADR is
  the pressure that suspension anticipated
- `services/lab_panel_extraction.py` — `run_panel_extraction`, `_recover_missing_file`,
  `_recovery_deadline_seconds`, `_extraction_timeout_seconds`, `_single_pdf_file`
- `WORK_LOG.md` — 2026-08-25 entry, including the process failure that let three of these defects
  reach production unnoticed
- **Open, deliberately out of scope:** multi-user concurrency (Alternative 4), a deterministic
  text-layer coverage check to replace most recovery calls, and a content-hash result cache.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.0 | 2026-08-26 | Divyanshu (AI-assisted) | Live-use revision: marker guards (shortcut gated to single-PDF uploads, marker treated as empty), recovery deadline clamped to a return-by time, verification box closed; open items moved to KNOWN_ISSUES |
| 2.0 | 2026-08-25 | Divyanshu (AI-assisted) | Recovery step replaced twice, same day: rank-mapped index -> re-check-everything -> deterministic attribution + OCR pre-filter (6 re-checks down to 2, or 0 when nothing is missing). Decision 3-6 rewritten; Revision section added; Verification expanded and marked INCOMPLETE (nothing exercised by a live upload) |
| 1.0 | 2026-08-25 | Divyanshu (AI-assisted) | Initial version — records the one-call decision, the same-day per-file attempt and its reversal, and the rank-normalisation defect |
