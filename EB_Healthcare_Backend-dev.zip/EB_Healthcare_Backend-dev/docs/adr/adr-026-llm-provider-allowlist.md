# ADR-026: LLM provider is pluggable — approved allowlist, not a single-vendor lock

**Doc status:** living · **Created:** 2026-07-13 by Sarvesh-SocialAngel · **Updated:** 2026-07-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-13
- **Supersedes:** CLAUDE.md §3 `LLM` row ("Anthropic Claude Sonnet only, via abstraction layer")
- **Superseded by:** —

## Context

CLAUDE.md §3 locks the LLM to "Anthropic Claude Sonnet only, via abstraction layer," and
§5's tech-stack diagram lists only `integrations/anthropic.py` under AI integrations.

In practice, `remedisys_healthcare_ai/services/llm.py::get_llm_client()` already dispatches
to either `integrations/openai.py` or `integrations/anthropic.py` based on
`AI Settings.llm_provider`, and the live AI Encounter Copilot deployment runs
`llm_provider = "OpenAI"` / `gpt-4o` (confirmed in the frontend repo's
`docs/ai/SYSTEM_DESIGN.md` §7c and tracked as open item **GOV-1** in `docs/ai/PLAN.md`).
The constitution says Anthropic-only; the running system uses OpenAI. That gap has stood
as an unresolved governance conflict since Sprint 4 hardening began.

The product owner has confirmed the actual intent: the platform should be LLM-provider
flexible, not locked to a single vendor. This ADR records that decision precisely enough
to close GOV-1, while keeping the same discipline CLAUDE.md already applies elsewhere
(§9: every LLM call is logged and audited; Rule 10: no PHI in logs; ADR-018: pluggable
profiles over hardcoded assumptions).

## Decision

Replace the single-vendor LLM lock with a **pluggable provider architecture restricted to
an approved allowlist**. "Flexible" means provider-agnostic within governance, not
"any SDK, no review" — this is a clinical system and a provider choice is also a
data-handling decision under the active `ComplianceProfile` (LFPDPPP for `mx`, DPDPA/ABDM
for `in`).

1. **Approved allowlist as of this ADR:** Anthropic (Claude Sonnet family) and OpenAI
   (GPT-4 family) — both already implemented in `integrations/`. Selection is per-site via
   `AI Settings.llm_provider`, dispatched by `services/llm.py::get_llm_client()`. The
   constitution does not mandate a default preference between the two; each deployment
   sets its own.

2. **Adding a new provider to the allowlist** requires, before merge:
   - A data-processing agreement (or equivalent vendor terms) covering the active
     `ComplianceProfile`'s jurisdiction.
   - An implementation of the shared interface — `generate_suggestions(transcript, ctx)`,
     `chat_reply(prompt, history, ctx)` — with no schema drift from `ClinicalSuggestion`.
   - Prompt files versioned under `prompts/` per the existing `<name>_v<N>.txt` convention.
   - A one-line addition to the allowlist in this ADR (not a new ADR) recording the
     provider and the DPA reference.

3. **Unchanged regardless of active provider:** Rule 4 (no direct DB access from the LLM),
   Rule 5 (no full-history dumping), Rule 6 (physician in control, no auto-apply), Rule 9
   (pipelines, not agents), Rule 10 (no PHI in logs), and §9's per-call audit fields
   (prompt_version, model, tokens, cost, latency). None of these are Anthropic-specific;
   none are relaxed by this ADR.

4. **This resolves GOV-1.** The live `OpenAI` / `gpt-4o` configuration becomes
   constitutionally valid as of acceptance — no config change back to Anthropic is
   required — provided OpenAI's data-processing terms are confirmed against the currently
   active `ComplianceProfile` (consequence 2, applied retroactively to the already-shipped
   integration).

## Alternatives Considered

1. **Keep the single-vendor lock (status quo).**
   - Pros: one vendor relationship to audit; simplest sentence in the constitution.
   - Cons: doesn't match confirmed product intent; permanently keeps the live, working
     OpenAI integration "out of compliance" with no path to close GOV-1 short of ripping
     out working code. **Rejected.**

2. **Fully open — "any LLM provider," no allowlist, no gate.**
   - Pros: maximum flexibility, zero process overhead.
   - Cons: for a system under LFPDPPP/DPDPA, adding a provider is a PHI-adjacent decision
     even when prompts are field-value-only (age, meds, allergies) rather than free text —
     skipping review means the first new SDK import becomes a compliance surface with no
     record of who approved it or under what data terms. This is exactly what CLAUDE.md's
     "every architectural decision gets an ADR" and "no PHI in logs, ever" rules exist to
     prevent. **Rejected** as literally specified; the allowlist model keeps the spirit
     (no more single-vendor lock) without the unreviewed-vendor risk.

3. **Pluggable allowlist with a lightweight per-provider governance checklist (chosen).**
   - Pros: mirrors the `ComplianceProfile` precedent (ADR-018) already accepted for
     jurisdiction; adding a provider is cheap (checklist + one allowlist line, not a new
     ADR); preserves an audit trail of who approved what and why.
   - Cons: marginally more process than "just add it" — a few hours per *new* provider,
     not per model-version bump within an already-approved one. **Accepted.**

## Consequences

- **CLAUDE.md §3 amendment:** `LLM` row changes from
  `[AI phase only] Anthropic Claude Sonnet only, via abstraction layer` to
  `[AI phase only] Pluggable — approved allowlist (Anthropic, OpenAI) via services/llm.py::get_llm_client(); see ADR-026. No single-vendor lock.`

- **CLAUDE.md §5 tech-stack diagram:** add `integrations/openai.py` alongside
  `integrations/anthropic.py` under "AI integrations."

- **CLAUDE.md §11 Hard Don'ts** — no wording change needed; "hardcode prompts, model
  names, temperatures, or token limits" already assumes a swappable provider and needs no
  amendment.

- **docs/ai/PLAN.md (frontend repo):** GOV-1 can be marked resolved, referencing this ADR,
  in a follow-up frontend-repo edit.

- **Re-evaluation trigger:** a future candidate provider that cannot produce a data-terms
  equivalent for an active jurisdiction stays off the allowlist regardless of technical
  readiness — this ADR does not waive that check for anyone.

## Verification

- `AI Settings.llm_provider` accepts only allowlisted values (`"Anthropic"`, `"OpenAI"`) —
  add a Select-field constraint at the doctype level if one does not already exist, so an
  invalid value fails at save time rather than at `get_llm_client()` runtime.
- `services/llm.py::get_llm_client()` has no default branch that silently falls through to
  an unapproved SDK.
- CLAUDE.md §3 and §5 no longer contain "Anthropic ... only."

## References

- ADR-018: Pluggable compliance profiles (the precedent this ADR follows)
- CLAUDE.md §3, §5, §9, Rule 4, Rule 6, Rule 9, Rule 10
- Frontend repo `docs/ai/SYSTEM_DESIGN.md` §7c — live provider configuration
- Frontend repo `docs/ai/PLAN.md` — backlog item GOV-1

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-13 | Sarvesh | Initial version (header backfilled from git history) |
