# ADR-103: Service Request and Medication Request get their own Patient Medical Record rows, registered going forward only

**Doc status:** living · **Created:** 2026-09-29 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-29
- **Supersedes:** —
- **Superseded by:** —

## Context

The v9 Overview "Active now" fix (this same session) resolves a real Service Request /
Medication Request status (Active, On Hold, Revoked, Stopped) and lets a doctor or nurse
change it. That status change is real — it changes the actual order record — but it never
reaches the patient's Medical Record / Patient History timeline.

Checked directly against `Patient History Settings` on this site: its registered doctypes are

```
standard_doctypes: Patient Encounter, Clinical Procedure, Lab Test, Therapy Session,
                    Vital Signs, Inpatient Medication Order, Observation, Discharge Summary
custom_doctypes:   (empty)
```

`Service Request` and `Medication Request` are both `module=Healthcare` and `is_submittable=1`
— they pass core's own `validate_medical_record_required()` module check — but neither is in
that list, so the global `doc_events["*"]` hooks (`create_medical_record` /
`update_medical_record` / `delete_medical_record`, `patient_history_settings.py:75-127`) silently
no-op for them on submit, update, and cancel. This is a gap in core Healthcare's own default
setup (`healthcare/setup.py::get_patient_history_config()` never seeded these two either) — not
something this app regressed.

**Contrast with ADR-096.** Encounter Canvas / Encounter Advice were made to surface *inside* the
encounter's own existing PMR row, because neither is a core Healthcare-module doctype
(`get_module(doc) != "Healthcare"` blocks them from ever getting a PMR row of their own — see
that ADR). Service Request and Medication Request are core Healthcare doctypes, each already a
distinct clinical event in its own right (an order placed, a status changed) — exactly the same
shape as `Lab Test` and `Clinical Procedure`, which already get their own row each. There is no
reason to nest these into the encounter's row; the natural, consistent choice is to register them
the same way their siblings already are.

## Decision

Register `Service Request` and `Medication Request` into `Patient History Settings.standard_doctypes`
(a JSON row each: `document_type`, `date_fieldname: order_date`, `selected_fields` covering
`status`, `template_dt`/`template_dn` or `medication`/`dosage`/`dosage_form`/`period`, and
`practitioner_name`) — the same shape, and the same migration-patch mechanism, as the existing
rows for `Lab Test`/`Clinical Procedure`/etc. No core file is touched (BE-1); this is entirely a
`Patient History Settings` data change, applied by a one-shot patch.

**A second gap found while implementing this.** Registering the doctype makes core's global
`doc_events["*"]` hooks (`create_medical_record` on submit, `update_medical_record` on
`on_update_after_submit`) start firing for it — but `on_update_after_submit` only fires through
the normal document lifecycle (`doc.save()`). `set_medication_status`/
`set_service_request_status` (this session's Continue/Hold/Stop fix) write the new status with a
direct `frappe.db.set_value()` call, exactly the same way core Desk's own status menu does
(`healthcare_note.js::update_status`) — which bypasses that hook entirely. Registering the
doctype alone would have meant only the ORIGINAL order showed in the timeline; a later Hold or
Revoke would never update it there, silently going stale. Both status-change methods now call
`update_medical_record()` directly after the status write (a small, best-effort, own-code helper
— never lets a Patient History sync failure surface as a failed status change).

## Known limitation: this is going-forward only, not retroactive

`validate_medical_record_required()` returns `False` whenever `frappe.flags.in_patch` is set
(`patient_history_settings.py:200-207`) — which is true for the whole duration of a migration
patch. This means the registration patch itself **cannot** call `create_medical_record()` to
backfill a PMR row for every Service Request / Medication Request that was already submitted
before this patch ran; that call would silently no-op the entire time the patch is executing.

Consequence: from the moment this patch runs, every *new* submit, status-change, or cancel of a
Service Request / Medication Request gets (or updates) its own PMR row, exactly like a lab
result already does. An order that was placed and later put On Hold *before* this patch ran will
not retroactively gain a PMR entry. Backfilling history — reading every existing submitted
Service Request / Medication Request and writing its PMR row directly, bypassing the `in_patch`
guard — is possible but is its own separate piece of work, deliberately not bundled into this
change; it was not asked for and doing it silently inside a migration patch is exactly the kind
of surprise this document exists to avoid.

## Consequences

- A doctor putting a lab On Hold, or a nurse stopping a medicine, now shows up in that patient's
  Medical Record / Patient History timeline — both the original order AND every later status
  change, going forward.
- No frontend change needed — Patient History is core Desk's own page; the Next.js app does not
  render it.
- Historical Service Request / Medication Request activity (everything before this patch) has no
  PMR entry and is not expected to gain one without a separate, explicit backfill decision.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased onto `dev`: renumbered from 098 to 103 — 098 was already claimed there for the billing screen restyle |
| 1.0 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
