# ADR-003: No modification of Frappe/ERPNext/Healthcare core; hooks + custom fields only

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-05-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-05-13
- **Supersedes:** —
- **Superseded by:** —

## Context

Remedisys integrates deeply with ERPNext Healthcare's Patient Encounter
workflow — sidebar UI, custom fields, document hooks, scheduled jobs. There
are three broad ways to make those integrations:

1. **Fork** Frappe/ERPNext/Healthcare and edit them directly.
2. **Monkey-patch** core classes/functions at import time.
3. **Build a custom app** (`remedisys_healthcare_ai`) and integrate only
   via Frappe's published extension points: hooks, custom fields, document
   events, whitelisted methods, REST API.

The team deploys to Frappe Cloud (ADR-005) and tracks the upstream
`version-16` branch for `frappe`, `erpnext`, and `healthcare`. Constitution
Rule 1 (Upgrade-Safe) and Rule 2 (Uninstall-Safe) both require that custom
code never lock us out of upstream updates and that uninstalling our app
leaves the EHR intact.

The team has direct prior experience with the failure mode being avoided
here: a `modules.txt` collision under our previous app caused Frappe's
orphan-detection to delete core doctypes (see memory:
`feedback_modulestxt_collisions`). Any approach that touches core files
directly carries similar — or worse — risk.

## Decision

**Never modify Frappe, ERPNext, or ERPNext Healthcare core files.** All
custom code lives in the `remedisys_healthcare_ai` app. Integration points
are limited to:

- **Custom fields** added via fixtures
  (`remedisys_healthcare_ai/fixtures/custom_field.json`).
- **`doctype_js` hooks** registered in `hooks.py` to inject the AI sidebar
  into the Patient Encounter form.
- **Document hooks** (`on_submit`, `validate`, `before_save`, etc.)
  registered in `hooks.py`.
- **Whitelisted methods** exposed under
  `remedisys_healthcare_ai.api.*`.
- **REST API consumption** for any cross-app data access.
- **Scheduled jobs** registered in `hooks.py`.
- **Boot session additions** for client-side configuration.

If a requirement cannot be met via these mechanisms, the rule is to **wrap
the workflow** in a Remedisys-owned doctype that mirrors or proxies the
core behavior — *not* to patch core. The wrapping approach must be
proposed explicitly and documented as an ADR before code is written.

## Alternatives Considered

1. **Fork Frappe/ERPNext/Healthcare.**
   - Pros: complete freedom; no extension-point gymnastics.
   - Cons: every upstream patch becomes a manual merge; security
     backports become a chore; Frappe Cloud will not host a forked stack;
     team loses access to the Frappe ecosystem.

2. **Monkey-patch core at import time.**
   - Pros: smaller diff than a fork; doesn't require maintaining a fork
     branch.
   - Cons: invisible to grep across the codebase; load-order-dependent;
     breaks silently when upstream renames or moves a function; impossible
     to reason about for new engineers.

3. **Custom app with hooks/fields/REST only (chosen).**
   - Pros: upstream-safe; uninstall-safe; standard Frappe pattern;
     reviewable as a single app.
   - Cons: occasionally Frappe does not expose a hook for what we need.
     Mitigation: wrap the workflow in a Remedisys doctype; if absolutely
     necessary, contribute a hook upstream.

## Consequences

- All Remedisys code is contained in `apps/remedisys_healthcare_ai/`.
- The install/uninstall CI test (Phase 0 deliverable 4) verifies Rule 2:
  install app → create a Patient Encounter via REST → uninstall app →
  Patient Encounter still opens and saves.
- Any code review that touches a path under `apps/frappe/`,
  `apps/erpnext/`, or `apps/healthcare/` is **automatically rejected**.
- A pre-commit hook (Phase 0 hardening) blocks edits to those paths from
  the working tree.

## Re-evaluation triggers

This ADR is intended to remain in force for the life of the product. The
only condition under which it would be revisited is if Frappe's
extension-point model fundamentally changes such that the current pattern
is no longer sufficient — at which point we would supersede with a new
ADR, not patch core in the meantime.

## Verification

- `git log --name-only` across `apps/remedisys_healthcare_ai/` shows no
  edits to other `apps/*` paths.
- Install/uninstall CI test (Phase 0 deliverable 4) passes.
- Pre-commit hook in `.pre-commit-config.yaml` (Phase 0 hardening) blocks
  edits to other `apps/*` paths.

## References

- Engineering Constitution, Section 4 Rule 1 (Upgrade-Safe)
- Engineering Constitution, Section 4 Rule 2 (Uninstall-Safe)
- Memory: `feedback_modulestxt_collisions` (the failure mode this rule
  prevents)
- Memory: `feedback_custom_app_isolation` (the team norm this ADR
  formalizes)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
