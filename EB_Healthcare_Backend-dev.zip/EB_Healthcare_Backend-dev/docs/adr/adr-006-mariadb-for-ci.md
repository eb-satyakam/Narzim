# ADR-006: Use MariaDB for CI; revisit Postgres lock

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-05-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-05-13
- **Supersedes (partially):** Constitution Section 3 — `Database` row (original lock: PostgreSQL 15+)
- **Superseded by:** —

## Context

Constitution Section 3 locks the database to PostgreSQL 15+. In practice:

- The upstream Frappe / ERPNext / ERPNext Healthcare projects run their
  own CI on **MariaDB 11.x**. Their published test matrix does not
  include Postgres.
- Frappe v16 supports Postgres but the Postgres path receives less
  attention; Healthcare 16.0.8 has historically been validated against
  MariaDB.
- Frappe Cloud, our deployment target (ADR-005), provisions sites on
  MariaDB by default. Postgres on Frappe Cloud requires a private bench
  arrangement.
- The existing `marley-bench` dev environment is on MariaDB (`marley.local`
  is a MariaDB site).

Holding to the Postgres lock means CI debugs upstream Postgres-on-Frappe
issues before our own code runs, and the deployment environment doesn't
match what CI verifies.

## Decision

For Phase 0 and the foreseeable horizon:

1. **CI runs on MariaDB 11.x.** Workflow service container is
   `mariadb:11.8` (mirroring upstream Healthcare CI).
2. **Production deployment on Frappe Cloud uses MariaDB.**
3. **Section 3 `Database` lock changes** from `PostgreSQL 15+` to
   `MariaDB 11+` (matching upstream + Frappe Cloud default).
4. The Postgres path is not abandoned — if a customer-specific deployment
   later requires it, this ADR is revisited via a new ADR documenting that
   case.

## Alternatives Considered

1. **Hold the Postgres 15+ lock.**
   - Pros: respects original constitution.
   - Cons: CI fights upstream Postgres issues; production target
     (Frappe Cloud) is on MariaDB anyway, so we'd be verifying on a
     stack we don't ship. No PHI value gained.

2. **MariaDB 11.x (chosen).**
   - Pros: matches upstream Frappe/ERPNext/Healthcare CI; matches
     Frappe Cloud default; matches existing `marley-bench` dev
     environment. Zero migration cost.
   - Cons: deviates from constitution's original Postgres lock —
     hence this ADR.

3. **Matrix CI on MariaDB + Postgres.**
   - Pros: defends both paths.
   - Cons: ~2× CI minutes; Phase 0 doesn't justify the cost.

## Consequences

- Section 3 `Database` row updated: `MariaDB 11+ — see ADR-006`.
- CI workflow (Phase 0 deliverable 4) uses MariaDB service container.
- ERPNext Healthcare doctype dialects (e.g., FULLTEXT vs PG `tsvector`)
  default to MariaDB conventions.
- `pgvector` mention in Section 3 row (`Vector DB`) is unaffected —
  pgvector is a Postgres extension and was already deferred to Phase 5.
  If/when pgvector lands, that decision will need its own ADR addressing
  the database split (Postgres for vectors only, or migrate primary db).

## Re-evaluation triggers

- A customer deployment requires Postgres for compliance or platform reasons.
- Frappe upstream deprecates MariaDB support.
- pgvector becomes load-bearing for differential-diagnosis retrieval and
  the dual-database story becomes untenable.

## Verification

- `.github/workflows/install-uninstall.yml` declares `mariadb:11.8` as the
  CI database service.
- `bench --site test_site list-apps` runs successfully on a MariaDB-backed
  site in CI.

## References

- Engineering Constitution, Section 3 (Locked Assumptions)
- ADR-005 (Frappe Cloud deployment)
- Upstream Healthcare CI: `apps/healthcare/.github/workflows/ci.yml`
- Upstream Healthcare install helper: `apps/healthcare/.github/helper/install.sh`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
