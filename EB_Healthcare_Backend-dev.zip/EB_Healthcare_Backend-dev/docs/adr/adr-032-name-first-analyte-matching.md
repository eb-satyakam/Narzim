# ADR-032: Match extracted lab parameters by analyte name, not by unit compatibility

**Doc status:** living · **Created:** 2026-07-24 by Divyanshu · **Updated:** 2026-07-24 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-24
- **Supersedes:** the unit-guard rejection introduced by ADR-028 (the "cross-specimen / incompatible-unit ⇒ unmatched" behavior in `services/lab_panel_extraction.py`). ADR-028's Lab Parameter master and coverage-threshold reuse are unchanged.
- **Superseded by:** —

## Context

The AI multi-panel extraction pipeline (ADR-022) resolves each extracted report
parameter to a catalog analyte, then buckets it onto the Lab Test Templates that
own that analyte. ADR-028 added a per-owning-template guard
(`lab_units.match_incompatibility`, "Gate D"): if the report's value/unit was not
convertible into the template analyte's own unit — including a qualitative result
("Negativo", "Ausentes") landing on an analyte the template defines numerically —
the match was rejected for that template, and if no template accepted it the
parameter was pushed to `unmatched_details`, which the frontend renders under
"Needs review".

Observed on a real Chopo urinalysis (`EXAMEN GENERAL DE ORINA`, order H71144): the
template exists and its 23 analytes match the report's 23 parameters exactly, yet
3 legitimate analytes (`Bilirrubina`, `Glucosa`, `Eritrocitos dismórficos`) were
demoted to "Needs review" purely because the lab reported them qualitatively while
the template slot is numeric. This is not report-specific: any analyte whose
printed representation (qualitative vs numeric, or a unit with no conversion rule)
differs from its template slot hits the same guard, on every report. A physician
reviewing an extraction expects a parameter that is plainly in the panel to sit in
the panel — not scattered into a review queue — and every extraction is reviewed
before anything is written (Rule 6).

## Decision

Match extracted parameters to templates by **analyte name (identity) alone**. A
name-resolved analyte is never demoted to "Needs review" over a unit/type mismatch.
The unit check is retained only to decide **how** the value is carried:

1. **Units compatible / a conversion rule exists** → convert into the template's
   unit via the existing deterministic `lab_units.resolve_display_value`
   (`Lab Unit Conversion` rules) and set `converted=True` with
   `original_value`/`original_unit`, so the UI shows "converted from X" (unchanged
   behavior).
2. **Not convertible** (no rule, or a qualitative result against a numeric analyte)
   → carry the report's **own** value / unit / reference range through **verbatim**,
   `converted=False`. The analyte still lands in its panel for physician review; no
   fabricated conversion is performed (Rule 4 — the model/pipeline never invents a
   numeric value).
3. A parameter reaches `unmatched_details` **only** when its resolved analyte is
   attached to no template at all (a bare catalog `Lab Parameter`), which is the
   genuine "create a template" case (ADR-022: nothing is discarded).

Wrong-**panel** matches (e.g. a lone serum `Glucosa 108 mg/dL` name-matching a urine
panel's `Glucosa`) remain held back by the ADR-028 **coverage threshold** in
Phase 2/3 (`_TEMPLATE_REUSE_THRESHOLD` / `_TEMPLATE_REUSE_MIN_PARAMS`) — a single
cross-specimen hit never clears 60% of a foreign template, so it is not spun up as a
panel. Coverage, not the unit guard, is the correct protection against wrong-panel
matches.

## Alternatives Considered

1. **Keep the unit guard; ask the physician to resolve each demoted analyte.**
   - Pros: no code change; the guard prevents an odd-looking value in a numeric slot.
   - Cons: fails the actual requirement — legitimate template analytes land in
     "Needs review" on essentially every report; the physician does redundant work
     re-attaching analytes that are already in the matched template.

2. **Match by name; convert when possible, else pass through verbatim (chosen).**
   - Pros: a parameter that is in the panel shows in the panel; conversion + the
     "converted" badge still apply when meaningful; coverage still blocks wrong-panel
     matches; physician reviews everything before save (Rule 6).
   - Cons: relaxes an ADR-028 guard; a genuinely cross-specimen value could appear in
     a panel row if that panel is independently reused — mitigated by coverage and by
     mandatory review.

3. **Use an LLM to convert/normalize units at match time.**
   - Pros: could handle exotic unit systems.
   - Cons: violates Rule 4 (LLM deriving clinical numbers), adds cost/latency, and is
     non-deterministic; the deterministic `Lab Unit Conversion` table is safer and
     already covers the real conversions.

## Consequences

- **Code:** `services/lab_panel_extraction.py` Phase 1 (Gate D) — on
  `match_incompatibility`, add a verbatim pass-through row instead of `continue`;
  the trailing `unmatched` branch now fires only when `owning_templates` is empty.
  Phase 1 comment updated.
- **Behavior:** matched-panel counts rise; `unmatched_details` shrinks to true
  no-template analytes. `converted=False` pass-through rows show the report's own
  value with no "converted" badge (correct — nothing was converted).
- **Unchanged:** ADR-028 Lab Parameter master, coverage-threshold reuse, qualifier
  conflicts (Gate C), and `resolve_display_value` conversion/flagging.
- **Re-evaluation trigger:** if a cross-specimen value is observed landing in a
  reused panel in production (not merely a coverage-failing candidate), revisit
  whether a specimen tag — not a unit type — should gate the match.

## Verification

- **Done (2026-07-24):** the stored model output of the H71144 urinalysis extraction
  was replayed through the fixed bucketing (mock `extract_multi_panel_report`, real
  catalog/templates, throwaway doc). Before: `matched_count=20`, 3 in
  `unmatched_details` (Bilirrubina, Glucosa, Eritrocitos dismórficos). After:
  `matched_count=23`, `unmatched_details` empty — all 23 in the
  `EXAMEN GENERAL DE ORINA` panel; no spurious Lab Parameters created.
- **Follow-up:** a CI regression test (qualitative result vs a numeric template slot
  stays matched) requires rebuilding the panel-extraction test harness, whose sources
  were previously removed (only stale `.pyc` remain). Tracked separately; the
  replay above is the interim proof.

## References

- Constitution §11 (single documented threshold), Rule 4 (no LLM-derived clinical
  values), Rule 6 (physician reviews every extraction before save).
- ADR-022 (multi-panel extraction, nothing discarded), ADR-024 (per-template
  unit resolution), ADR-028 (Lab Parameter master + coverage-threshold reuse).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-24 | Sarvesh | Initial version (header backfilled from git history) |
