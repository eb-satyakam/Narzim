# ADR-069: Admin-practitioner booking fixed via `ignore_permissions=True` — supersedes ADR-065's write-through mechanism

**Doc status:** living · **Created:** 2026-09-15 by Divyanshu (AI-assisted) · **Updated:** 2026-09-15 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-15
- **Supersedes:** ADR-065 (its *chosen implementation*, Alternative 5 — the "withhold `practitioner` from `doc_data`, patch it in via `frappe.db.set_value` after insert" mechanism. Does **not** supersede ADR-065's underlying decision that this bypass should exist, or its scoping to `EB_Practitioner` + admin-role callers naming someone other than themselves — that population and that intent are unchanged.)
- **Superseded by:** —

## Context

ADR-065's implementation shipped 2026-09-14 and was never actually exercised end-to-end against a real Appointment Type before being marked Accepted — its own §7 Testing section admits this: "The end-to-end write path ... is exercised manually per ADR-065 §Verification; an integration test ... is a reasonable follow-up." No such integration test was ever added.

Reported live 2026-09-15: booking Anant Sharma with a different practitioner (Dr. Haati) failed with **`"Please enter Practitioner"`**, not the `frappe.PermissionError` ADR-065 was written to fix.

Root cause, traced in `_create_impl` (`api/v1/appointments/api.py`):

1. ADR-065's fix detects this population via `_resolve_admin_target_practitioner()` and, when it fires, pops `practitioner` out of `doc_data` entirely before `doc.insert()` (the old lines 1212-1216), intending to patch it back in afterward through `frappe.db.set_value()` — a call that bypasses Frappe's permission layer.
2. This assumes the **only** thing checking `practitioner` at insert time is Frappe's Link-field User Permission ("Healthcare Practitioner = self"). It is not. `Patient Appointment`'s own controller
   (`apps/healthcare/healthcare/healthcare/doctype/patient_appointment/patient_appointment.py:237-247`, `validate_based_on_appointments_for`) runs on every `validate()`:
   ```python
   def validate_based_on_appointments_for(self):
       if self.appointment_for:
           appointment_for_field = frappe.scrub(self.appointment_for)   # "practitioner"
           if not self.get(appointment_for_field):
               frappe.throw(_("Please enter {}").format(frappe.bold(self.appointment_for)), frappe.MandatoryError)
   ```
3. `appointment_for` is `fetch_from: appointment_type.allow_booking_for`, and every standard clinical Appointment Type (e.g. "General Consultation" — the exact fixture `tests/appointments/test_appointment_department.py` already uses) resolves this to `"Practitioner"`. So by the time this check runs, `self.appointment_for == "Practitioner"` and `self.practitioner` is empty (withheld) → `doc.insert()` throws and the transaction rolls back. The post-insert `frappe.db.set_value` patch this ADR relied on **never runs**, because `insert()` never returns.

This is not a style disagreement with ADR-065 — its chosen mechanism does not work for any normal booking. ADR-065's own §"Alternatives Considered" explicitly evaluated and rejected exactly the fix adopted here (its "Alternative 1: blanket `ignore_permissions=True`"), on the grounds that it was broader than necessary and silent. Superseding is appropriate rather than amending in place: the rejection reasoning in ADR-065 assumed both approaches *worked* and only differed in blast radius; that premise is false, so the comparison itself needs to be redone, not patched.

## Decision

In `_create_impl`, keep `practitioner` **in** `doc_data` at all times — never withhold it. When `_resolve_admin_target_practitioner()` flags this booking (the identical population ADR-065 defined: `EB_Practitioner` + an admin role, naming someone other than themselves), pass `ignore_permissions=True` to `doc.insert()`:

```python
doc.insert(ignore_permissions=skip_staff_authorization or bool(admin_target_practitioner))
```

Consequences:

1. `validate_based_on_appointments_for()` sees a populated `self.practitioner` and never throws — the actual defect is gone.
2. `doc.insert(ignore_permissions=True)` also skips the Link-field User Permission check on `practitioner` for this one insert — the original ADR-065 problem this whole mechanism exists to solve — and it is skipped for a caller who already passed `require_permission("Patient Appointment", "create")` earlier in the same function, so nothing is granted that wasn't already authorized.
3. `department` (`fetch_from=practitioner.department`) is now fetched normally during `insert()`, because `practitioner` is present — the post-insert `frappe.db.set_value` + `doc.reload()` + `_ensure_appointment_department(doc, target_practitioner=...)` sequence is deleted for this branch; there is nothing left for it to fix.
4. The one structured audit log line is kept unchanged (appointment name, target practitioner, acting user — IDs only, Rule 10).

A caller who is not both `EB_Practitioner` and an admin never reaches this branch — unchanged from ADR-065.

## Alternatives Considered

1. **`doc.flags.ignore_user_permissions = True`, still withholding nothing — field-scoped instead of insert-scoped.**
   - Pros: narrower than `ignore_permissions=True` — only suppresses the Link-field User Permission check, not the doctype-level `create` check (already redundant here) or any other link's User Permission.
   - Cons: `ignore_user_permissions` is still doc-wide, not field-scoped, so the narrowing over the chosen option is smaller than it first appears — checked directly: every other Link field on this doctype that Frappe would enforce User Permission on already carries `ignore_user_permissions:1` in the schema (`patient`, `referring_practitioner`); `practitioner` is the only one this flag would actually change anything for. The two options are functionally near-identical for this doctype today; `ignore_permissions=True` was chosen only because it reuses the exact parameter this function already threads through (`skip_staff_authorization`), so the diff stays one boolean expression instead of introducing a second flag.

2. **Permanent `property_setter` fixture giving `Patient Appointment.practitioner` `ignore_user_permissions:1` doctype-wide.**
   - Pros: no branch in `_create_impl` at all; fixes it for every caller, forever.
   - Cons: rejected on scope, not effort — it silently removes a real access control for *every* caller, not just the narrow, already-role-gated ADR-065 population. A clinic that later configures a legitimate practitioner-scoped User Permission for a non-admin front-desk role would lose that protection with no record of why. This is exactly the "broader than the problem" objection ADR-065 raised against blanket `ignore_permissions`, except permanent and global instead of scoped to one already-authorized branch.

3. **Fake `appointment_for` (blank it) during insert to dodge `validate_based_on_appointments_for()`, backfill both `appointment_for` and `practitioner` post-insert.**
   - Pros: touches no permission flag.
   - Cons: `appointment_for` also gates `appointment_time`'s and `service_unit`'s own `mandatory_depends_on` rules on this same doctype — blanking it to dodge one check changes what two *other* fields require during that same insert. Rejected: trades one validation-ordering bug for a real chance of a second, differently-shaped one (an appointment briefly persisted with no practitioner, no department, and a mandatory-check-free `appointment_time`), for no benefit over option 4 below.

4. **Keep `practitioner` in `doc_data`; use `ignore_permissions=True` on `doc.insert()` for this branch; delete the now-dead post-insert patch (chosen).**
   - Pros: fixes the actual defect (mandatory-value check never sees a value); reuses the exact mechanism (`ignore_permissions`) this function already uses for the portal's pre-authorized path (`skip_staff_authorization`), rather than introducing a second bypass shape; net *deletion* of ~20 lines of now-unnecessary workaround code (the `frappe.db.set_value` / `doc.reload()` / `_ensure_appointment_department` sequence), since `department` is now fetched correctly at insert like any other booking.
   - Cons: `ignore_permissions=True` also skips the doctype-level `create` check inside `insert()` — already proven redundant, since `require_permission("Patient Appointment", "create")` runs explicitly earlier in the same function for every non-portal caller.

## Why this approach, specifically

- **Vs. 1 (`ignore_user_permissions` flag):** loses only on code-reuse grounds, not correctness — both fix the bug identically for this doctype today. `ignore_permissions=True` wins narrowly because it slots into the parameter (`skip_staff_authorization or bool(admin_target_practitioner)`) this function already has, rather than adding a second, differently-named flag for what is, on this doctype, the same effective bypass.
- **Vs. 2 (permanent property setter):** loses on scope, exactly as ADR-065 already argued against blanket `ignore_permissions` — except worse, because it is global and permanent rather than scoped to one pre-authorized branch of one function.
- **Vs. 3 (fake `appointment_for`):** loses on correctness margin — it doesn't just risk a second bug, it structurally can't avoid touching the *other* fields `appointment_for` gates, because Frappe evaluates `mandatory_depends_on` against whatever value the field holds at that moment, not against its "real" intended value.
- **What changed since ADR-065 rejected this exact shape as "Alternative 1":** ADR-065 rejected it for being broader than necessary while treating its own chosen mechanism (Alternative 5) as working and merely narrower. That was the load-bearing error — Alternative 5 does not work at all for a normal Appointment Type. Between "narrower but broken" and "measurably broader (one already-authorized branch skips one redundant doctype check) but correct," correctness wins without a close call.

## Consequences

- `api/v1/appointments/api.py`, `_create_impl`:
  - Removed the `if admin_target_practitioner: doc_data.pop("practitioner", None)` block — `practitioner` now always reaches `doc.insert()` when the caller supplied one.
  - `doc.insert(ignore_permissions=skip_staff_authorization)` → `doc.insert(ignore_permissions=skip_staff_authorization or bool(admin_target_practitioner))`.
  - Removed the post-insert `frappe.db.get_value`/`frappe.db.set_value`/`doc.reload()`/`_ensure_appointment_department(doc, target_practitioner=...)` sequence; kept the audit log line.
  - Comments above `_resolve_admin_target_practitioner()` and the `doc.insert()` call rewritten to record this history, so a future reader does not re-derive the same wrong mechanism ADR-065 chose.
- `_ensure_appointment_department()` itself is untouched and still required — `reassign_appointment` (ADR-018) still uses the identical withhold-then-patch pattern for a *write*, where it is correct (an existing document's `practitioner` is `set_only_once`, so there is no equivalent mandatory-value check to trip at `doc.save()` time the way there is at `doc.insert()` time). This ADR does not touch that function or its callers.
- `docs/ADMIN_PRACTITIONER_BOOKING_OVERRIDE.md` rewritten to describe the corrected mechanism (§4.2-4.5 replaced; new §2 "Why the first version broke").
- **Re-evaluation trigger, carried over from ADR-065 unchanged:** this needs to extend to a role beyond Admin (e.g. Front Desk claiming on a doctor's behalf) → revisit ADR-065's parked Alternative 4 (explicit-consent override endpoint). A second admin-practitioner-shaped bug appears on another doctype (lab/procedure ordering) → consider a shared helper.
- **New re-evaluation trigger:** any future Frappe/Healthcare core upgrade that adds `ignore_user_permissions:1` to a *different* Link field on `Patient Appointment` should be checked against this ADR's "Alternative 1" comparison — the claim that `ignore_permissions=True` and a field-scoped flag are functionally equivalent today depends on today's schema.

## Verification

- `tests/appointments/test_appointments.py::TestResolveAdminTargetPractitioner` (6 cases, unchanged — the helper's own branching logic was never wrong) — all pass.
- `tests/appointments/test_appointments.py::TestBookAppointmentForPatientRollback` — all pass (unaffected; exercises a different failure path).
- `tests/appointments/test_appointment_department.py::TestAppointmentDepartmentTrap` and `TestAppointmentForTrap` — all pass (the `_ensure_appointment_department`/`_ensure_appointment_for` helpers this ADR stops calling from `_create_impl`'s admin branch are still exercised directly and via `reassign_appointment`/`reschedule_appointment_with_payment`, unchanged).
- Full `tests/appointments/` package run via `bench console` (per `docs/KNOWN_ISSUES.md` — `bench run-tests` is broken bench-wide by ERPNext's `before_tests` Fiscal Year overlap, unrelated to this change, reproduced 2026-09-15): 289 tests, 1 pre-existing failure + 4 pre-existing errors, none touching `_create_impl`, `book_appointment`, `book_appointment_for_patient`, `_resolve_admin_target_practitioner`, or the department/appointment_for backfill helpers (traced individually: a status-role-gate assertion, two reschedule-payment-preview response-shape errors, and two failures from a missing "Appointment Type: Consultation" site fixture — all pre-existing, none introduced by this diff).
- **Gap, named honestly:** no integration test yet exercises the corrected end-to-end path (`doc.insert(ignore_permissions=True)` actually bypassing a real Frappe User Permission row) — this is the same gap ADR-065 admitted and never closed. Follow-up tracked in `WORK_LOG.md` (2026-09-15 entry).

## References

- ADR-065 (superseded implementation — ADR-018's `reassign_appointment` write-through pattern remains correct for that function; the error was reusing it for a *create*, where a mandatory-value check the write path doesn't have gets in the way)
- ADR-018 (`reassign_appointment`, still using the withhold-then-`db.set_value` pattern correctly, for a write)
- ADR-062 (`assert_bookable` guard, called immediately before this code, unaffected)
- Constitution §4 Rule 1 (no core modification — this fix touches only `remedisys_healthcare_ai`), Rule 10 (no PHI in logs — audit line unchanged), §9 (ADR requirement), §10 (four-approaches requirement for a consequential-but-reversible fix)
- `docs/ADMIN_PRACTITIONER_BOOKING_OVERRIDE.md` (mechanism doc, rewritten alongside this ADR)
- `apps/healthcare/healthcare/healthcare/doctype/patient_appointment/patient_appointment.py:237-247` (the core controller check that actually threw)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-15 | Divyanshu (AI-assisted) | Initial version — supersedes ADR-065's implementation after a live booking failure traced the mechanism to a real defect, not a style tradeoff |
