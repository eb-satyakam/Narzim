# ADR-082: The AI describes a medical image, in its own field, and never diagnoses it

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — requested by Divyanshu, 2026-09-22, after a renal ultrasound reached the review screen with nothing on it
- **Builds on:** [ADR-080](adr-080-report-type-templates-for-lab-extraction.md) · [ADR-081](adr-081-report-subject-and-template-driven-summaries.md)

---

## 1. Context

A renal ultrasound (a JPEG, one image, essentially no printed text) was uploaded and the
review screen showed "No tests detected in this report" and "Nothing left to resolve".
Nothing indicated a failure. The record (`AI Prompt Log csd8hmkchl`) shows why:

```
title:              'Renal Ultrasound'   ← the model DID look at the image
transcribed_report: ''                   ← and wrote nothing
```

Two defects, one visible and one not:

1. **Our instructions ask the model to TRANSCRIBE.** On a document whose content is a
   picture there is nothing to transcribe, so an empty answer is the correct response to the
   question we asked. We never asked it to describe what it saw.
2. **An empty narrative was silently discarded** — by `clean_narrative_reports` and again by
   `_extraction_narrative_reports`, both of which required non-empty text. A document that
   could not be read therefore looked exactly like a document that was read and contained
   nothing. That is a Rule 7 breach: degradation must be visible.

## 2. Decision

The model **describes** an image it cannot transcribe, and **flags what stands out**, in a
field of its own.

`narrative_reports[].image_observations`:

| Field | Meaning |
|---|---|
| `modality` | ultrasound, X-ray, CT, MRI, OCT, fundus photograph, ECG tracing, clinical photograph |
| `description` | what is visible — anatomy shown, view or plane, appearance of the structures |
| `notable` | anything that stands out and a clinician would want to look at; empty is a normal answer |

An entry is no longer discarded for having no transcribed text, as long as it carries
observations.

### 2.1 Why a separate field, and not more prose in `transcribed_report`

**This is the load-bearing part of the decision.** `transcribed_report` is what the DOCUMENT
says. `image_observations` is what a MODEL saw in the pixels. Merged into one block, a
reader cannot tell a clinician's documented finding from a model's reading of an image — and
an AI observation that reads as a radiologist's finding is fabricated clinical content, the
thing §11 forbids outright. Separation is structural rather than a matter of wording, so the
UI can label it and no prompt change can erode it.

The frontend renders it in its own panel headed "Observed by AI from the image", with the
caveat "A description of what is visible, not a diagnosis. Review the image yourself."

### 2.2 Hard limits, in the prompt

- **Describe, never diagnose.** Say what is visible; never name a disease, never say what a
  finding means, never say whether it is normal or abnormal. "A rounded anechoic area is
  present in the upper pole" — not "this is a cyst", not "consistent with hydronephrosis".
- **Never write observations as though the report stated them**, and never into
  `transcribed_report`.
- **Say when you cannot tell.** Poor quality or an unidentifiable structure is reported as
  such, never filled in with something plausible.
- Printed text that IS present still goes to `transcribed_report`. The fields are
  independent.

## 3. Consequences accepted

| Consequence | Detail |
|---|---|
| **The AI now produces clinical observations, not only transcriptions** | A description of anatomy from an image is an observation. It remains a proposal under physician review (Rule 6) and is labelled as AI-observed wherever it is shown |
| **No validator covers it** | There is no deterministic check that an image description is accurate — unlike a lab value, which has a reference range. The mitigations are the no-diagnosis limit, the visible label, and physician review. Recorded here rather than implied; this is the weakest point of the decision |
| **Output tokens rise for image-heavy reports** | Latency is output-bound (`docs/ai/LAB_EXTRACTION_PERFORMANCE.md`), so an image-only document now costs more time than an empty answer did |
| **Requested at this strength deliberately** | A narrower option — describe but never flag anything — was offered and declined. Recorded so a later reader does not mistake the scope for drift |

## 4. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Describe only, never flag anything notable | Offered as the safer option and explicitly declined: it fixes the blank screen but leaves the clinician no better off than looking at the image unaided |
| Say only "this document is an image with no readable text" | Honest and safe, and almost useless |
| Put the description into `transcribed_report` | Smallest change, and the worst: it makes a model's reading indistinguishable from a clinician's documented finding |
| Leave it to each report type's template | A template is AI-authored and optional, so a type whose template omitted it would silently go back to a blank screen. Never returning an empty document is an invariant, not a per-type preference |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — image observations in their own field; describe-never-diagnose; empty narratives no longer discarded |
