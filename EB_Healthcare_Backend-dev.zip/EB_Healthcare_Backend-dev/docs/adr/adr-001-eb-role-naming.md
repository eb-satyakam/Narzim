# ADR-001 — EB_ Prefix for Custom Frontend Roles

**Doc status:** living · **Created:** 2026-06-11 by Invincible · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
## Context

ERPNext Healthcare ships with built-in roles: `Healthcare Administrator`, `Physician`, `Nursing User`, `Laboratory User`, etc. We also define five custom roles for the Remedisys frontend. Without a naming convention, it is easy to accidentally use a built-in role name in code, fixtures, or DB queries, causing silent permission mismatches.

## Decision

All custom Remedisys frontend roles use the `EB_` prefix:

| Role | Purpose |
|---|---|
| `EB_Healthcare Admin` | Clinic manager — full frontend access |
| `EB_Practitioner` | Doctor / physician |
| `EB_Front Desk` | Reception / scheduling |
| `EB_Clinic Staff` | Combined front-desk + nursing duties |
| `EB_Nurse` | Nursing — vitals, ready-for-provider |
| `EB_Patient` | Patient portal accounts |

## Consequences

- Any grep for `EB_` instantly identifies all custom role references.
- Built-in ERPNext role names are never mistakenly used in custom code.
- The Frappe→RoleId mapping lives in a single place: `lib/auth/roles.ts` on the frontend.
- ERPNext field *values* that happen to contain "Practitioner" (e.g. `appointment_for` on Patient Appointment) are **not** role names and must not be renamed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Status block normalised to `- **Status:**`, the shape the rest of the set uses, so the ADR tooling can read it. No decision changed |
| 1.0 | 2026-06-11 | Sarvesh | Initial version (header backfilled from git history) |
