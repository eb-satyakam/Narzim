# ADR-067: Send the patient's name in WhatsApp templates

**Doc status:** living · **Created:** 2026-09-12 by Ashutosh (AI-assisted) · **Updated:** 2026-09-12 by Ashutosh (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-12
- **Supersedes:** the `patient_name` prohibition in `docs/security/WHATSAPP_HIPAA_COMPLIANT.md` §6.1 and the allowlist rationale in `integrations/whatsapp/phi_policy.py`
- **Superseded by:** —

> **This ADR widens what we disclose to a company that has refused a Business
> Associate Agreement.** It was taken deliberately, with the trade-off stated
> below, by the product owner on 2026-09-12. It is written up in full precisely
> because a decision of this kind must not be inferable only from a diff.

## Context

### What was asked for

Notification and auto-reply messages should open with the patient's name, the way
consumer health brands do:

> **Dear Aman Uttam,**
>
> Your appointment at Socialangel is confirmed for 15-09-2026 at 14:30.

### What the existing rule said, and why

`integrations/whatsapp/phi_policy.py` maintains an **allowlist** of variable paths
an automatic template may carry. Its docstring names this exact request as the one
that would come next:

> *STILL FORBIDDEN, and these are the ones people ask for next: `patient_name` (an
> identifier)…*

The reasoning behind the original rule is unchanged and remains true:

1. **Every template variable is POSTed to `graph.facebook.com`.** There is no
   local-only path; a variable *is* a disclosure.
2. **Meta has refused to sign a BAA.** Under HIPAA §164.502 every such value is a
   disclosure to a non-Business-Associate.
3. **The allowlist was built because a blocklist only has to be wrong once.** Six
   of the seven originally shipped templates carried `patient_name`; all six were
   `enabled = 0`, and "the only thing standing between us and a reportable
   disclosure was a checkbox nobody had ticked."

### The distinction this ADR changes

The phone number already goes to Meta on every send and always will — it is the
delivery address, not content. That makes the existing disclosure **pseudonymous**:
Meta learns *a number* receives clinic messages.

Adding the name makes it **identified**: Meta learns *Aman Uttam* is a patient of
this clinic. Under §164.514(b)(2) both name and phone are identifiers; carrying
both together is materially more disclosing than either alone.

That is the whole substance of the decision. It is not a UI change.

## Decision

**Automatic WhatsApp templates may carry the patient's name.** `patient_name` is
added to `phi_policy._ALLOWED_PATHS`, and the shipped templates are reissued with
a greeting line.

Concretely:

1. `patient_name` joins the allowlist. Nothing else does — `practitioner_name`,
   `lab_test_name`, `medication`, `diagnosis` and financial values stay forbidden,
   and for the unchanged reason: they describe the *care*, not the recipient.
2. The templates are reissued (a new version; an approved template's body cannot
   be meaningfully edited) with the greeting as `{{1}}` and existing variables
   shifted.
3. `WHATSAPP_HIPAA_COMPLIANT.md` §6.1 is amended to say what the code now does.
   **PHI-5 forbids the document claiming a restriction the code no longer
   enforces**, so this happens in the same change, not afterwards.

### What is NOT changed

- **Consent is still required** before any automatic send (R-3). A patient who has
  not authorised the channel receives nothing, name or no name.
- **The clinical prohibitions stand.** Nothing about a diagnosis, a medication, a
  test or a practitioner may be sent. R-2 — WhatsApp says *that* something
  happened, the portal says *what* — is untouched.
- **The allowlist mechanism stays.** This widens it by one entry; it does not
  replace it with a blocklist or with judgement at the call site.

## Alternatives Considered

1. **Keep the name out entirely (the prior rule).**
   - Pros: minimum disclosure; no policy change, no ADR, no template reissue. Meta
     learns only that a number receives clinic messages.
   - Cons: a generic "Hola," reads as machine-generated, and in a channel patients
     already distrust that costs engagement — the product owner's stated reason for
     the request. Rejected by the product owner, who owns that trade-off.

2. **Send the patient's name (chosen).**
   - Pros: the message reads as addressed to a person; matches what patients see
     from every other business on the channel; reduces "is this a scam?" doubt,
     which is a real failure mode for an unbranded clinic message.
   - Cons: converts a pseudonymous disclosure into an identified one, to a
     processor with no BAA. Irreversible per message once sent.

3. **First name only.**
   - Pros: intuitively less identifying; still personal.
   - Cons: **the intuition is wrong in the way that matters.** A first name plus a
     phone number is still an identifier under §164.514(b)(2) — safe harbour
     requires removing *all* name elements, not shortening them. It buys the
     appearance of caution without the substance, which is worse than either
     honest option. Rejected on that basis.

4. **Put the greeting in the portal, not the message.**
   - Pros: no new disclosure; the portal is authenticated and already shows the
     patient's name legitimately.
   - Cons: does not address the request at all — the WhatsApp message is the thing
     being read, and nobody signs in to be greeted. Listed for completeness.

## Consequences

**Code**

- `integrations/whatsapp/phi_policy.py` — `patient_name` added to
  `_ALLOWED_PATHS`, with the reasoning inline and a pointer here.
- `patches/v0/` — a patch adding the greeting variable to each config, in the
  correct position, and pointing configs at the reissued templates.
- `tests/whatsapp/test_portal_url_variable.py` — the allowlist test asserts the
  full expected set, so it changes here **deliberately and visibly**, which is the
  point of asserting the whole set rather than individual members.

**Documentation, in the same change (PHI-5)**

- `docs/security/WHATSAPP_HIPAA_COMPLIANT.md` §6.1 amended, and this ADR linked
  from it.

**Operational**

- 12 templates × 2 languages × 2 WABAs must be reissued and re-approved.
- Existing approved templates are left in place; nothing is deleted, so a rollback
  is a config change rather than a Meta round-trip.

**Re-evaluation triggers**

- **A US deployment.** This decision is defensible under LFPDPPP and DPDPA with
  consent; it is materially harder to defend under HIPAA without a BAA. A `us`
  `ComplianceProfile` must revisit it, and the profile is the right place to force
  that.
- **Meta signs a BAA**, at which point the whole allowlist can be re-examined.
- **A regulator or customer questions the disclosure**, which is exactly the
  scenario this ADR exists to answer.

## Verification

1. `phi_policy._ALLOWED_PATHS` contains `patient_name` and the test asserting the
   complete set was updated in the same commit as the code.
2. No enabled template carries a clinical variable — the existing test over
   forbidden paths still passes unchanged.
3. `WHATSAPP_HIPAA_COMPLIANT.md` §6.1 no longer claims the name is withheld.
4. Consent is still refused-by-default: the R-3 tests pass unchanged.

## References

- [`docs/security/WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) — §5 R-2/R-3, §6.1
- [`ADR-066`](adr-066-whatsapp-keyword-auto-replies.md) — the auto-reply design these templates serve
- [`ADR-060`](adr-060-patient-communication-consent.md) — the consent model, unchanged by this
- [`CLAUDE.md`](../../CLAUDE.md) — §9.9 PHI-5, PHI-6; §11 hard don'ts
- `integrations/whatsapp/phi_policy.py` — the allowlist and its original rationale

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-12 | Ashutosh (AI-assisted) | Initial version. Permits `patient_name` in automatic WhatsApp templates, reversing the §6.1 prohibition; records the pseudonymous-to-identified trade-off and why "first name only" was rejected as false caution |
