# ADR-012: Orchestrate Pay-Now booking by sequencing standard ERPNext documents

**Doc status:** living · **Created:** 2026-06-15 by Sarvesh-SocialAngel · **Updated:** 2026-06-15 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-06-15
- **Supersedes:** —
- **Superseded by:** —

## Context

The appointment-booking wizard (frontend) has a Payment step with three timings:
**Pay Now**, **Pay Later**, **Insurance** (deferred). For **Pay Now**, the
frontend expects one call that books the appointment, raises the charge, records
the payment, and returns the created document IDs (`appointment`,
`sales_invoice`, `payment_entry`, `payment_status`).

Constraints (CLAUDE.md §4 Rule 1, §3 API pattern, BACKEND_ARCHITECTURE §2):
- No custom accounting doctypes; never duplicate the GL.
- Two-layer architecture: logic in `services/`, thin whitelisted wrappers in `api/v1/`.
- Reuse ERPNext Healthcare's core invoicing (`invoice_appointment` → `create_sales_invoice`)
  and core `Payment Entry` (`get_payment_entry`), both already wrapped by
  `services.billing.create_invoice_from_appointment` and `api.v1.billing.collect_payment`.

## Decision

Add a thin orchestration method **`book_appointment_with_payment`** that
**sequences existing, standard documents** — it writes no new accounting logic.

1. Create the Patient Appointment (`_create_impl`, same path as `book_appointment`,
   incl. the practitioner-conflict guard).
2. `services.billing.invoice_and_settle(appointment, mode_of_payment, discount_*)`:
   - `create_invoice_from_appointment` → core Sales Invoice (with discount).
   - `settle_invoice` → core Payment Entry allocated to the invoice → Paid, outstanding 0.
3. Return `{ appointment, sales_invoice, payment_entry, payment_status }`.

**Failure policy:** the invoice + payment run inside a DB **savepoint** taken
*after* the appointment is created. If billing fails, roll back to the savepoint —
the **appointment stays booked (Unpaid)** and the billing error is surfaced.
Front desk retries collection at checkout (existing `collect_payment`).

**Pay Later** = `book_appointment` only (no invoice/payment). **Insurance** =
placeholder (no accounting yet). Payment methods come from the standard
**Mode of Payment** master via `get_payment_methods`.

## Alternatives Considered

1. **Healthcare POS path (`paid_amount` + `mode_of_payment` on the appointment).**
   - Pros: single core call creates + settles the invoice.
   - Cons: settles *inside* the Sales Invoice (is_pos payment row) — **no separate
     Payment Entry document**, so it can't return the `payment_entry` ID the
     frontend contract requires.

2. **Sequence invoice → Payment Entry (chosen).**
   - Pros: produces a real `Payment Entry` (matches the contract); reuses only
     existing reviewed methods; no new accounting; clean savepoint failure policy.
   - Cons: two writes instead of one; orchestration lives in a service.

3. **Custom "Appointment Payment" doctype.**
   - Pros: bespoke fields.
   - Cons: duplicates the GL, breaks ERPNext reporting, violates Rule 1. Rejected.

## Consequences

- New code: `services/billing.py` (`list_payment_methods`, `settle_invoice`,
  `invoice_and_settle`), `api/v1/billing/api.py` (`get_payment_methods`),
  `api/v1/appointments/api.py` (`book_appointment_with_payment`).
- Frontend gains `GET /api/payment-methods` and `POST /api/appointments/create-with-payment`.
- No doctypes, no migrations, no GL changes.
- Re-evaluate if Insurance Pay-Now or partial payments are introduced (the
  full-settlement assumption changes).

## Verification

- `bench run-tests --module remedisys_healthcare_ai.tests.billing.test_billing`
  (validation paths; a fixture-backed happy-path test to be added before merge).
- Manual E2E: Pay Now → invoice `Paid`, outstanding 0, Payment Entry exists,
  appointment references both.
- CI: ruff + mypy + install/uninstall gate on the PR.

## References

- CLAUDE.md §3 (API pattern), §4 Rule 1 (upgrade-safe), §10 (working style)
- BACKEND_ARCHITECTURE.md §2 (two-layer), §8 (key rules)
- Existing: `services.billing.create_invoice_from_appointment`, `api.v1.billing.collect_payment`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-15 | Sarvesh | Initial version (header backfilled from git history) |
