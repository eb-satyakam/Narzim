# ADR-086: A measurement report is a third kind of document, not a lab panel with missing ranges

**Doc status:** living · **Created:** 2026-09-23 by Divyanshu (AI-assisted) · **Updated:** 2026-09-23 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — 2026-09-23, after Divyanshu asked why a device report was being treated as tabular
- **Builds on:** [ADR-083](adr-083-per-parameter-side.md) · [ADR-085](adr-085-image-observations-on-every-document.md)

---

## 1. Context

The pipeline had exactly two kinds of document: a **panel** (discrete values, matched to Lab
Test Templates, checked against reference ranges) and a **narrative** (prose). An IOLMaster
700 optical biometry is neither, and forcing it into "panel" produced four wrong statements
at once on the review screen:

- **"Detected tests (0)"** — it was hunting for orderable lab tests. There are none, and there
  should be none: nobody orders "AL", they order one biometry that yields all 47 values.
- **Every value in "Needs review"** — nothing matched a Lab Test Template and nothing ever will.
- **"45 results could not be checked — the report gave no reference range"** — true, and
  misleading. It implies something is missing. Nothing is missing; an axial length of
  24.08 mm is not "normal" or "abnormal", it is an input to a lens calculation.
- **`SD 3 µm` filed as a reference range.** That is the device's measurement precision, not a
  range of healthy values. Verified that `parse_normal_range` refuses it and no false flag was
  produced — the damage was misleading language, not a wrong result.

## 2. The alternative that was rejected, and why

The obvious suggestion was to classify it **narrative/descriptive** — it is a device printout
with images, after all. Rejected, on evidence:

- 47 of 47 values are numeric, each a named measurement with a unit. Structurally it is a table.
- Classifying it narrative turns those into prose. That happened by accident earlier the same
  day when a prompt change flipped the classification: `parameters: []` and a wall of text. It
  was plainly worse and was treated as a regression.
- **The asymmetry decides it.** Structured values can always be rendered as prose; prose can
  almost never be recovered as structured values. Going narrative is a one-way door, taken only
  when there is no alternative — and there was one.

The numbers were never the problem. The problem was asking a lab-screening question —
*"is this value within range?"* — of a ruler.

## 3. Decision

A third document kind, declared by the model in `report_kind`:

| Kind | Meaning |
|---|---|
| `panel` | Results meant to be read against reference ranges — a blood count, a urinalysis |
| `measurement` | Device readings or a calculation, where a value is an INPUT and normal/abnormal does not apply — an optical biometry, a dimensional measurement, a calculation sheet |
| `narrative` | Prose — an imaging report, a pathology report, a consultation letter |

An unrecognised value falls back to `panel`, so an unknown kind can never quietly take a real
lab report out of reference-range checking.

**Precision is separated from reference range.** Parameters gain `precision` for a standard
deviation, tolerance or confidence figure. `reference_range` stays empty when the document
prints no range, which is the correct answer for a measurement report rather than a failure.

**Downstream behaviour for `measurement`:**

- The summary and the report chat are told what they are reading and instructed not to
  describe values as unchecked or of unknown status, and never to call a measurement normal or
  abnormal.
- The review screen stops reporting "no tests detected" and stops counting values as
  unchecked; the values are labelled Measurements.

## 4. Result on the report that prompted it

```
report_kind = 'measurement'    params = 42    images = 4    notices = 3
with precision: 23             with reference_range: 0
ACD 3.47   precision 'SD 3 µm'   reference_range ''
```

The summary now leads with the device's own warnings, describes both eyes' measurements and
the images, and says nothing about missing reference ranges.

## 5. Consequences accepted

| Consequence | Detail |
|---|---|
| **The model decides the kind** | A misclassification of a real lab panel as a measurement would skip reference-range language for values that do have ranges. Mitigated by defaulting to `panel` on anything unrecognised, and by the prompt rule that a mixed document chooses `panel` |
| **Nothing validates the kind** | As with every other AI-decided field here, there is no deterministic check. Recorded rather than implied |
| **A longer extraction prompt again** | Each added rule has twice shifted the panel/narrative classification of an unrelated document. Both times it was caught only by re-running a known file, which is not a test |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-23 | Divyanshu (AI-assisted) | Addendum: the frontend typecheck was not checking anything; nine real errors found once fixed |
| 1.0 | 2026-09-23 | Divyanshu (AI-assisted) | Initial version — `report_kind`, `precision` separated from `reference_range`, measurement-aware summary/chat/screen |

---

## Addendum, 2026-09-23 — the frontend typecheck was silently doing nothing

While fixing a `ReferenceError` reported from the running app (`sideRank is not defined` — a
helper defined inside `LabOrderDialog` but used inside `SectionGroupRow`, a separate
component), it emerged that **`npx tsc --noEmit` had not been checking anything.**

`tsconfig.json` includes `.next/dev/types/**/*.ts`. The Next dev server rewrites
`routes.d.ts` continuously, so tsc frequently read it mid-write and hit unrecoverable syntax
errors ("Unterminated template literal"), after which it reported those and stopped semantic
checking altogether. Excluding the path does not help: `next-env.d.ts` pulls the file in by
triple-slash reference.

Proved rather than assumed: a file containing `export const probe = definitelyNotDefined;`
was added to `src/` and tsc **did not report it**. With `routes.d.ts` temporarily replaced by
`export {}`, the same probe was caught immediately.

Every "type-checks clean" claim made on 2026-09-22 was therefore worthless. Re-running with
the generated file neutralised surfaced **nine real errors**, all introduced that day:

| Error | Consequence |
|---|---|
| `Property 'side' does not exist on type 'UnmatchedItem'` (×6) | The side badge and ordering referenced a field the row type did not declare |
| `Duplicate identifier 'observations'` (×2) | A replace-all added the prop to a type that already had it |
| `'"High" \| "Low" \| "Abnormal" \| null' and '"Normal"' have no overlap` | **A real logic bug:** the confirmed-in-range count filters on `flag === "Normal"`, which the type made impossible, so it would have read zero for every lab panel — silently removing the reassurance line |

**Procedure that actually works**, until the tsconfig include is reconsidered: replace
`.next/dev/types/routes.d.ts` with `export {}`, run `npx tsc --noEmit`, restore the file.
A tool that reports success without checking is worse than no tool, because it is believed.
