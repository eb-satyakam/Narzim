# ADR-049: Vaccines live in their own child table on Treatment Plan Template, not in `items`

**Doc status:** living · **Created:** 2026-08-27 by Anant Sharma (AI-assisted) · **Updated:** 2026-08-27 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-08-27
- **Supersedes:** —
- **Superseded by:** —

## Context

A Treatment Plan Template is a reusable clinical protocol. Until now it carried two child tables:

| Table | Doctype | Holds |
|---|---|---|
| `items` | `Treatment Plan Template Item` | lab tests, clinical procedures, therapies |
| `drugs` | `Drug Prescription` | formulary medications |

A pediatric protocol frequently includes a vaccine — a 12-month well-child visit is the obvious
case. There was no way to express that, and the two obvious workarounds are both unsafe:

**1. `items` silently drops unknown types.** `Treatment Plan Template Item.type` is a `Link` to
`DocType` with `template` a `Dynamic Link` following it, so the schema will accept *any* doctype.
What narrows it is a query filter, and — critically — the code that *consumes* the rows is a
hardcoded chain with no `else` and no error:

```python
# healthcare/healthcare/doctype/patient_encounter/patient_encounter.py:135
if plan_item.type == "Clinical Procedure Template": ...
if plan_item.type == "Lab Test Template": ...
if plan_item.type == "Therapy Type": ...
if plan_item.type == "Observation Template": ...
# no else — an unrecognised type falls through and vanishes
```

Our own apply path, `api/v1/encounters/api.py::get_treatment_plan_template`, has the same shape.
So merely widening the dropdown to admit `Immunization Template` would produce a row that saves,
displays, and is then discarded at the moment it matters.

**2. `drugs` is the wrong clinical object.** `Drug Prescription` requires a `Medication`, and a
vaccine is an `Item` reached through `Immunization Template.vaccine`. Even with a synthetic
`Medication` per vaccine, the result is a *prescription to dispense*, which carries no lot number,
no administration site, no consent, no dose-in-series, and no `Patient Vaccine` linkage — so the
dose would never reach the patient's Cartilla and the immunization schedule report would not see it.

Two facts make a third option cheap. `save_draft` **already** has a `vaccines` lane
(`adr-019-encounter-native-binding`) that resolves against `Immunization Template` and becomes a
`Patient Vaccine` order plus a `Nursing Task` on signing
(`adr-020-vaccine-nurse-administration-handoff`). And we do **not** call core's
`set_treatment_plan`; we have our own apply endpoint. So a plan can feed that existing lane without
touching core.

Immunization Program already models "which vaccines, for which ages" and remains the right tool for
a routine age-based schedule. This ADR covers the different need: a vaccine that belongs to a
*diagnosis- or visit-specific protocol*.

## Decision

**Add a third child table, `custom_vaccines`, to Treatment Plan Template, as a Custom Field
supplied by this app. Do not extend `items`.**

1. New child doctype `Treatment Plan Template Vaccine` (module `Remedisys Healthcare AI`), fields:
   `immunization_template` (Link → `Immunization Template`, required), `vaccine` (Link → `Item`,
   `fetch_from` the template, read-only), `mandatory` (Check, default 1), `instructions` (Data).
2. Attached to the core doctype by two Custom Fields in
   `remedisys_healthcare_ai/fixtures/custom_field.json` — a `Vaccines` Section Break and the
   `custom_vaccines` Table — so **no core file is edited** (Rule 1).
3. `vaccine` is never accepted from the caller. It is fetched from the Immunization Template, so a
   plan can never disagree with the vaccine catalog.
4. `admin/catalog.py` gains `_build_tpt_vaccine_rows`, plus a `vaccines` parameter on
   `create_treatment_plan_template` / `update_treatment_plan_template` with the same replace
   semantics the other two tables use (omit = untouched, `[]` = clear).
5. `encounters/api.py::get_treatment_plan_template` returns a `vaccines` array keyed by `template`
   (the docname), which is the key `_create_encounter_immunizations` reads first — so ordering never
   depends on label matching.
6. **Applying a plan orders vaccines; it never administers them.** Rows come back with `nurse: ""`.
   A reusable protocol cannot know who is on shift, and `complete_encounter` already refuses to sign
   a vaccine with no nurse. Pre-filling one would silently assign clinical work to a named person.
7. `mandatory` and `instructions` are display-only hints. They are carried through to the encounter
   payload so the frontend can show them — they are deliberately **not** invented as behaviour,
   because a field nothing consumes is the same silent-drop defect in a new place.

## Alternatives Considered

1. **Use Immunization Program instead (no code).**
   - Pros: exists today; zero build; full record — consent, lot, site, Cartilla, billing.
   - Cons: applicability is age/gender only. It cannot express "this vaccine is part of *this*
     protocol", which is the requirement. Remains the right tool for routine schedules, and this
     ADR does not replace it.

2. **Add `Immunization Template` as a fourth `items` type.**
   - Pros: no new doctype; one dropdown entry; reuses an existing table.
   - Cons: `Treatment Plan Template Item` has no field for anything vaccine-specific, and the row
     would still need special-casing in every consumer. Most importantly it leaves the row one
     forgotten `elif` away from silent disappearance — including in core's Desk path, which we
     cannot fix. Rejected on the silent-drop risk, not on effort.

3. **Add the vaccine as a `Drug Prescription` row.**
   - Pros: no schema change at all.
   - Cons: clinically wrong. Produces a dispense order, not an administration; no lot, site,
     consent or dose-in-series; never reaches the Cartilla; the immunization schedule report would
     under-report coverage while the plan claimed the child was covered.

4. **New `custom_vaccines` child table (chosen).**
   - Pros: correct fields; no core edit; feeds the `vaccines` lane that already exists, so the
     downstream path (Patient Vaccine order → Nursing Task → Immunization) is unchanged and already
     tested; an unknown row can no longer be confused with a lab or a procedure.
   - Cons: a second place where "a vaccine belongs to this group" is expressed, alongside
     `Immunization Program Item`. Accepted knowingly — see Consequences.

## Consequences

- **A second vaccine grouping now exists.** `Immunization Program Item` (age-driven schedule) and
  `Treatment Plan Template Vaccine` (protocol-driven) both name vaccines. They answer different
  questions and neither is derived from the other, so they can drift: a vaccine retired from the
  program stays in a plan. Mitigated by validating against the catalog on every write — a disabled
  `Immunization Template` is rejected — but not eliminated. **Re-evaluation trigger:** if a clinic
  ends up maintaining the same vaccine list in both places, collapse them behind one resolver.
- Both tables converge on the same downstream path, so there is exactly one way a dose is recorded.
- Uninstalling the app removes the Custom Fields and the child doctype. Treatment Plan Templates
  keep working with `items` and `drugs`; their vaccine rows are lost. This satisfies Rule 2
  (uninstall is non-destructive to core function) and is the accepted cost of a Custom Field table.
- Requires `bench migrate` to install the fixture. The read paths use `doc.get("custom_vaccines")`
  so an un-migrated site returns an empty list rather than a 500.
- The frontend (`EB_Healthcare_Frontend`) must render the third table on
  `/settings/treatment-plans/*` and the vaccine rows on encounter apply. Not covered here.

## Verification

- `remedisys_healthcare_ai/tests/admin/test_treatment_plan_vaccines.py` — validator branches, CRUD
  replace semantics, and `test_apply_returns_the_plan_vaccines`, the regression guard for the
  silent-drop defect above.
- Verified live on `remedisys.localhost` 2026-08-27: a plan created with `VPH (Virus del Papiloma
  Humano)` round-tripped through create → read → apply with `vaccine` auto-fetched as `VAC-VPH` and
  `nurse` empty; duplicate, disabled and unknown vaccines rejected.

## References

- `CLAUDE.md` Rule 1 (upgrade-safe), Rule 2 (uninstall-safe)
- [`adr-019-encounter-native-binding.md`](adr-019-encounter-native-binding.md) — the `vaccines` lane
- [`adr-020-vaccine-nurse-administration-handoff.md`](adr-020-vaccine-nurse-administration-handoff.md) — vaccines are ordered, never administered from the encounter
- [`adr-026-vaccine-two-part-billing-at-administration.md`](adr-026-vaccine-two-part-billing-at-administration.md) — per-row billing

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-27 | Anant Sharma (AI-assisted) | Initial version |
