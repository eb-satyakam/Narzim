# ADR-077: Clinical Web is enabled — NCBI/PubMed as a named retrieval host, and clinician-pasted links, with the address itself screened

**Doc status:** living · **Created:** 2026-09-18 by Divyanshu (AI-assisted) · **Updated:** 2026-09-18 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — decision taken 2026-09-18.
- **Date:** 2026-09-18
- **Supersedes:** nothing. This is the ADR that [ADR-075](adr-075-narzim-gpt-patient-aware-context.md)'s consequences require and that did not exist.
- **Superseded by:** —
- **Related:** ADR-075 (Narzim patient-aware — required this ADR by name), ADR-026 (LLM provider allowlist — the precedent that a vendor needs review before it joins a list), ADR-076 (jurisdiction profile structure — **still Proposed, and independent of this**), CLAUDE.md §9.9 PHI-1 / PHI-3 / PHI-6.
- **Drives:** [PR #493](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/493) — the composer's **Clinical Web** toggle and **paste a URL** field.

## Context

ADR-075's consequences said, in terms:

> **Clinical Web (PubMed/NCBI, guideline hosts, arbitrary URL fetch) requires its own ADR and a
> `ComplianceProfile` update under PHI-1 before any outbound call is built** — a subprocessor the
> profile does not name must be refused.

Two things then happened, in this order, and both are worth recording honestly:

1. **The code was built first, on instruction** (2026-09-18). It was built the only way that is
   defensible in that state — behind gates that raise, with both markets naming nothing — so it
   shipped structurally incapable of making a call. That was a mitigation, not compliance with
   the sentence above.
2. **The ADR it named was never written.** For several days the gate was described internally as
   "waiting on ADR-076". That was wrong: ADR-076 is about restructuring jurisdiction profiles into
   a central table and has nothing to do with outbound retrieval. The required artefact simply did
   not exist. This is it.

The team's decision on 2026-09-18 was to unblock the feature.

## Decision

**Clinical Web is enabled in both shipped markets, as two separate, separately-revocable
capabilities, with one named host.**

1. **`retrieval_providers = ("ncbi",)`** in `mx` and `india`. One host, named. Not a category, not
   "medical literature", not a wildcard. A second host is a register change with a reviewer.
2. **`url_fetch_allowed = True`** in both. Kept as a **separate switch** from the above, because it
   is a separate decision with a different risk: one is a known host we chose, the other is any
   address a clinician types. A deployment may reasonably allow the first and refuse the second.
3. **`source_cache_retention_days` stays `0`.** Nothing caches a fetched page. A retention number
   with no purge job behind it is a false promise (PHI-3), and `AI Source Cache` does not exist.
4. **NCBI is a retrieval host, not a PHI subprocessor** — and this rests on code, not on intent.
   `services/clinical_web_query.py` removes the patient's name and record id (checked against the
   `Patient` table, so that half is exact rather than a judgement), any email, and any number longer
   than three digits. `is_safe_to_send` re-checks the assembled string immediately before the URL is
   built, so a future second query-builder cannot bypass the gate.
5. **The pasted address is itself screened** (`is_url_safe_to_send`, new in this change). A URL
   copied out of another system's address bar can carry `?patient=...&mrn=...`, and every byte of it
   reaches the destination host as the request target before any page comes back. This was **not**
   guarded while the feature was switched off, because the address never travelled; enabling the
   feature is what made it necessary, and it landed in the same change.
6. **The digit rule is applied to the query string and fragment only** for a pasted URL, never to
   the host or path. `pubmed.ncbi.nlm.nih.gov/12345678/` is an article id, and refusing it would
   break the commonest paste this feature exists to serve. Names and emails are screened across the
   whole address, decoded first — see Consequences for what this does and does not catch.

## Alternatives considered

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | Leave both off; require a per-site `site_config.json` override to enable | Nothing changes for existing sites; enabling is an explicit act per clinic | Duplicates the register per site — the exact failure ADR-076 option D loses on. PHI-1 says **the profile** is the record of who receives data; a second, per-site source of that truth guarantees the two disagree |
| **B** | **Name `ncbi` and allow pasted links in both shipped profiles (chosen)** | One reviewable record, in the file a person reads to answer "who receives data". Both capabilities stay independently revocable. A new host is still a code change with a reviewer | Enables for every deployment of that market at once, including ones nobody has looked at |
| **C** | Enable PubMed only; leave `url_fetch_allowed = False` | Strictly safer — avoids the SSRF surface entirely, and the residual DNS-rebinding window with it | Leaves a control in the shipped composer that always errors, which is the "accepted and ignored" shape we have been removing everywhere else. The team asked for both |
| **D** | Replace arbitrary URL fetch with an allowlist of guideline hosts (WHO, NICE, CENETEC…) | Removes the SSRF surface **and** the "any address" question; every fetch is to a host somebody vetted | Does not do what the feature is for. A clinician pastes the link they are looking at, which is usually a journal, a society page or a PDF nobody pre-listed. An allowlist that misses the actual link is a feature that appears broken |

**Why B, specifically.** **A** loses on one precise point: it puts the subprocessor record in two
places, and CLAUDE.md is explicit that a wrong register is *"worse than none, because it will be
relied on"* — two sources of the same fact is how one becomes wrong. **C** is the genuinely
defensible conservative option and is **a one-line revert per market if the SSRF residual risk is
judged unacceptable**; it was not chosen because the team asked for pasted links and the control
already ships in the UI. **D** solves the safety problem by removing the feature's actual use case.

**What would falsify this choice:** evidence that a de-identified query still identifies a patient
in practice — for example a clinic whose questions routinely contain a rare condition plus a town,
which NCBI's logs could correlate. The name/email/number screen does not address re-identification
by combination, and it does not claim to. If that turns out to be real, the answer is C, not a
wider screen.

## Consequences

- **What now leaves this system:** a de-identified search string to `eutils.ncbi.nlm.nih.gov`, and
  an HTTP GET to whatever address a clinician pastes. **No patient identifier in either**, subject
  to the limits below. Nothing is stored at the far end by us, and nothing is cached here.
- **The residual DNS-rebinding window is unchanged and now live.** `safe_fetch.py` validates every
  resolved address and re-validates every redirect hop, but `requests` resolves again when it
  connects. Closing the gap means pinning the socket to the validated address while keeping TLS
  hostname verification, which `requests` does not expose cleanly. Every address must be public
  **and** an attacker must win that race — narrowed, not solved. It is the main reason §2 keeps the
  two switches separate.
- **A record number in a URL *path* is not caught** (`/records/00123456`), because it is
  indistinguishable from an article id by shape. Asserted as a known limitation in
  `tests/ai/test_url_identifier_screen.py` so nobody "fixes" it and breaks every PubMed link. The
  name and email screens still cover the path.
- **Percent-encoding is decoded before screening, up to three rounds.** A name in a real URL arrives
  as `Ram%C3%ADrez`, which tokenises to `ram` / `c3` / `adrez` and matches no patient. The raw-string
  version of this screen let every accented name through; it was caught by its own test before
  shipping, which is the argument for writing the awkward test case.
- **PHI-6 minimum-necessary is what governs here, not the BAA.** OpenAI and Anthropic are covered
  and already receive chart data; NCBI is not covered and receives none. That asymmetry is the
  whole design, and it is why the screen exists on the outbound query and not on the LLM call.
- **Still open, and not decided here:** whether NCBI needs the same data-processing-terms check
  ADR-026 requires before an LLM vendor joins the allowlist. The argument that it does not is that
  no personal data is sent; the argument that it does is that PHI-1 names the register, not the
  payload. **Flagged for the compliance owner** rather than settled by an engineer.
- `AI Source Cache` remains unbuilt and `source_cache_retention_days` remains `0`. Building the
  cache means writing the purge in the same change (PHI-3) and adding it to the erasure path
  (PHI-4).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-18 | Divyanshu (AI-assisted) | Initial version — records the 2026-09-18 decision to enable Clinical Web with NCBI as the one named host, pasted links as a separate switch, and the pasted address screened for identifiers |
