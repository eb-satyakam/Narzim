# ADR-037: Portal Chat Is a Separate Thread, Independent of WhatsApp

**Doc status:** living · **Created:** 2026-07-30 by Divyanshu · **Updated:** 2026-07-30 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-29
- **Supersedes:** ADR-036
- **Superseded by:** —

## Context

ADR-036 proposed keeping patient-portal chat messages inside the same
`WhatsApp Conversation` / `WhatsApp Message` records as real WhatsApp
messages, distinguished by a `channel` tag (`WhatsApp` / `Portal`). That
design was chosen to give staff a single merged thread per patient
regardless of which channel the patient used.

**The product requirement has changed.** Portal Chat and WhatsApp Chat are
now two deliberately separate conversations, each with its own tab in the
EB Healthcare Frontend: a new **"Portal Chat"** tab showing only messages
exchanged through the patient portal, sitting alongside the existing
**"Messages"** tab (real WhatsApp, unchanged). Portal Chat must never call
the WhatsApp Business API and must never require a `WhatsApp Account`
credential, in either direction.

This reverses ADR-036's core call (one merged thread), but the reasoning
that surfaced while working through ADR-036 still explains *why* keeping
them separate is the right call, not just a preference:

1. **The two channels are not actually symmetric, and merging them implied
   they were.** A patient's portal message can never appear on their real
   WhatsApp app — there is no API, from Meta or anyone, that lets a
   business inject a message into a customer's own WhatsApp chat history as
   if the customer had sent it. That's not a gap in our implementation; no
   WhatsApp Business integration anywhere can do this — it would let any
   business forge messages in a customer's own chat. But a clinic's real
   WhatsApp reply *does* land in both the real WhatsApp app and (because it
   was one shared thread) the portal. A single merged thread quietly
   implied a two-way mirror that can only ever be one-way. Two separate
   threads make the actual behavior of each channel obvious instead of
   surprising.
2. **The WhatsApp 24-hour session window is a real Meta policy, tracked
   server-side by Meta based on genuine WhatsApp traffic.** Mixing portal
   messages into the same conversation that carries `window_expires_at`
   meant every portal message had to be explicitly prevented from touching
   that field (ADR-036's core fix). Keeping Portal Chat in its own
   doctype removes the risk category entirely — there is no WhatsApp window
   concept in a thread that was never a WhatsApp conversation to begin with.
3. **Portal Chat, by definition, never needs the WhatsApp credential.**
   Under ADR-036, a portal message still recorded a `whatsapp_account`
   link (for company/routing metadata) even though no Meta call was made —
   accurate, but still living inside a doctype whose entire reason for
   existing is to be a WhatsApp record. A purpose-built doctype has no such
   field at all, so "does this need the WhatsApp key" has an obvious answer
   by construction: no code path in this module can call it, because there
   is nothing to call it with.

**Existing precedent to build on:** the internal Team Chat system
(`Chat Thread` + `Chat Message`, ADR-015,
`remedisys_healthcare_ai/api/v1/messages/api.py`) already implements exactly
the lightweight shape this needs — a thread doctype, a message doctype
linked to it, simple polling from the frontend, no third-party credential
anywhere in the flow. `Chat Thread`
(`remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/chat_thread/chat_thread.json`)
holds `title`, `is_group`, `company`, `last_sender`, `last_message_at`,
`last_message_preview`, and a `participants` child table; `Chat Message`
(`.../doctype/chat_message/chat_message.json`) holds just `thread`,
`sender`, `content`. That's the right *pattern* to copy.

Reusing that pattern is not the same as reusing those *doctypes*. As
already established when ADR-036 considered and rejected this: Team Chat is
deliberately staff-only (`_require_chat_role()` in `messages/api.py`
explicitly excludes patient-only users; `list_contacts` only ever returns
staff). Retrofitting patient membership into `Chat Thread` would unpick an
intentional access boundary and mix two audiences (internal staff-to-staff
chat and patient-to-clinic chat) that have different permission models,
different contact-discovery logic, and different UI needs. The fix is to
build a second, parallel pair of doctypes shaped the same way, scoped to
exactly one patient and one clinic per conversation (matching how
`WhatsApp Conversation` is scoped) — not to widen an existing staff-only
doctype's purpose.

## Decision

Build Portal Chat as its own independent doctype pair, its own backend
module, and its own EB Healthcare Frontend tab. It never touches
`WhatsApp Message`, `WhatsApp Conversation`, `Chat Thread`, or `Chat
Message`, and never requires a `WhatsApp Account` credential in either
direction.

1. **New doctype `Portal Conversation`** — one row per (patient, company)
   pair, modeled on `WhatsApp Conversation`'s shared-inbox shape minus
   anything Meta-specific:
   - `patient` (Link → Patient, required)
   - `patient_name` (Data, fetched from Patient — display convenience)
   - `company` (Link → Company, required)
   - `status` (Select: `Open` / `Closed`, default `Open`)
   - `assigned_to` (Link → User, optional — same triage pattern as
     WhatsApp Conversation's `assigned_to`)
   - `last_message_at` (Datetime, read-only)
   - `last_message_preview` (Small Text, read-only)
   - `unread_count` (Int, read-only)

2. **New doctype `Portal Message`** — one row per message, modeled on
   `Chat Message`'s simplicity:
   - `conversation` (Link → Portal Conversation, required)
   - `sender_type` (Select: `Patient` / `Staff`)
   - `sender` (Link → User, required — the patient's own portal user for
     patient messages, the staff member's user for clinic replies; both
     are real Frappe Users so one field covers both cases)
   - `content` (Small Text, required)
   - creation timestamp is the built-in `creation` field, same as
     `Chat Message` — no separate timestamp field needed.

3. **Rewrite `remedisys_healthcare_ai/api/v1/patient_portal/chat.py`** to
   read/write `Portal Conversation` / `Portal Message` instead of
   `WhatsApp Message`. `get_my_conversation`, `list_my_chat_messages`,
   `send_my_chat_message` keep their existing whitelisted names and
   response shapes (so the Patient Portal frontend needs zero changes) but
   their implementation no longer references `WhatsApp Account`,
   `whatsapp_account`, or anything Meta-related — there is nothing in this
   module to call Meta with.

4. **New staff-facing module**,
   `remedisys_healthcare_ai/api/v1/patient_portal/portal_chat.py` (naming
   mirrors `integrations/whatsapp/chat_api.py`'s shape, kept as a sibling
   rather than merged into it, since the two are now unrelated systems):
   - `list_portal_conversations(status, assigned_to, ...)` — same shared-
     inbox-per-company model as `list_conversations`.
   - `get_portal_conversation(conversation)` — thread + full message
     history, resets `unread_count`.
   - `send_portal_message(conversation, content)` — staff reply. Pure
     `Portal Message` insert; no `_send_free_text`, no Meta call, no
     `WhatsApp Account` lookup anywhere in this function.
   - Permission gate: same staff-role list already used elsewhere
     (`EB_Front Desk`, `EB_Nurse`, `EB_Healthcare Admin`, `EB_Practitioner`,
     `System Manager`), company-scoped the same way `_assert_company` scopes
     WhatsApp conversations.

5. **EB Healthcare Frontend — new "Portal Chat" tab**, sibling to the
   existing "Messages" tab, not a mode inside it:
   - `src/hooks/use-portal-chat.ts` — new hook file mirroring
     `use-whatsapp.ts`'s shape (`usePortalConversations`,
     `usePortalThread`, `usePortalSend`, `usePortalAssign`,
     `usePortalClose`), calling new BFF routes.
   - `src/app/api/portal-chat/**` — new BFF routes mirroring
     `src/app/api/whatsapp/**` 1:1 (`conversations/route.ts`,
     `conversations/[id]/route.ts`, `conversations/[id]/reply/route.ts`,
     `conversations/[id]/assign/route.ts`, `conversations/[id]/close/
     route.ts`), each proxying to the new `portal_chat.py` methods.
   - New page/tab under `src/app/(clinic)/messages/` (or a sibling route,
     e.g. `portal-chat/page.tsx`) reusing the existing `ConversationThread`
     / `MessageBubble` component shells where the shape fits (both are
     already generic over a message list + a send box), pointed at the new
     hooks instead of `use-whatsapp.ts`. No delivery-tick logic applies
     here (`DeliveryTick` in `message-bubble.tsx` is WhatsApp-specific —
     Portal Chat messages have no Meta delivery status, so that component
     is simply not used on this tab).
   - Patient Chart → Communication area: `messages-tab.tsx` gets a sibling
     "Portal Chat" tab alongside its existing WhatsApp "Messages" tab, same
     embed pattern (`hideActions`), for a doctor/staff member viewing one
     patient's chart. Noted as the natural follow-on; not required for the
     first cut if scope needs trimming.

6. **No `channel` field, anywhere.** ADR-036's custom field is dropped —
   there is nothing to tag, since provenance is now structural (which
   doctype a row lives in), not a label on a shared one.

7. **Patient Portal app (`EB_Healthcare_PatientPortal`): no changes.**
   Its `/api/chat` and `/api/chat/messages` BFF routes keep calling the
   same method names with the same response shapes (per point 3) — the
   swap from `WhatsApp Message` to `Portal Message` happens entirely behind
   those whitelisted methods.

## Alternatives Considered

1. **ADR-036's tagged single-thread approach (previously chosen, now
   superseded).**
   - Pros: one inbox per patient regardless of channel; smaller initial
     change (one custom field vs. two new doctypes and a new tab).
   - Cons: implied a two-way mirror between portal and WhatsApp that can
     only ever be one-way (a portal message can never reach the patient's
     real WhatsApp app — no API allows it), which reads as confusing/buggy
     to a patient using both; required permanently guarding every WhatsApp-
     specific field (the 24h window) against non-WhatsApp writes forever;
     kept portal messages structurally inside a vendor-owned doctype they
     don't semantically belong to.

2. **Retrofit patients into the existing Team Chat doctypes (`Chat
   Thread` / `Chat Message`, ADR-015).**
   - Pros: reuses doctypes that already exist; patients are real Frappe
     `User` records, so technically linkable as participants.
   - Cons: Team Chat's access model (`_require_chat_role`, staff-only
     contacts list) is deliberately built to exclude patients — widening it
     mixes two different audiences and permission models into one system.
     Rejected for the same reason under ADR-036; still the right call here.

3. **New purpose-built `Portal Conversation` / `Portal Message` doctypes,
   modeled on Team Chat's thread/message shape (chosen).**
   - Pros: total independence from WhatsApp (no shared fields, no shared
     risk surface, no credential anywhere in the flow); matches the
     explicit product decision for a dedicated tab; company/patient-scoped
     the same way `WhatsApp Conversation` already is, so the shared-inbox
     UX pattern staff already know carries over.
   - Cons: two new doctypes, one new backend module, one new frontend tab,
     and a full set of new BFF routes — materially more to build than
     ADR-036's single custom field. Staff now has two separate tabs to
     check per patient instead of one merged view — an explicit, accepted
     trade-off in exchange for removing the cross-channel asymmetry and the
     WhatsApp-credential dependency.

## Consequences

**New doctypes:**
- `Portal Conversation` (JSON + permissions: staff roles read/write,
  Patient role read-own-only via `has_permission`/
  `permission_query_conditions`, same pattern as
  `overrides/patient_portal_perms.py` already uses for WhatsApp).
- `Portal Message` (JSON + permissions, same pattern).

**Backend files touched:**
- `remedisys_healthcare_ai/api/v1/patient_portal/chat.py` — rewritten to
  target `Portal Conversation` / `Portal Message`; drops all
  `WhatsApp Account` / `whatsapp_account` references.
- `remedisys_healthcare_ai/api/v1/patient_portal/portal_chat.py` — new,
  staff-facing endpoints.
- `remedisys_healthcare_ai/fixtures/` — new doctype fixtures/permissions as
  needed; **no** new custom field on `WhatsApp Message` (ADR-036's is
  dropped, not carried forward).
- `remedisys_healthcare_ai/patches.txt` — migration for the new doctypes.

**EB Healthcare Frontend files touched:**
- `src/hooks/use-portal-chat.ts` — new.
- `src/app/api/portal-chat/**` — new BFF routes.
- New "Portal Chat" tab/page under `src/app/(clinic)/messages/` (exact
  route TBD at implementation time), reusing `ConversationThread` /
  `MessageBubble` where their shape fits.
- `src/components/narzim/patient-chart/messages-tab.tsx` — optional
  follow-on: sibling "Portal Chat" tab in the patient chart.

**No changes needed:**
- Patient Portal app — unaffected end-to-end (same method names, same
  response shapes, different storage underneath).
- Real WhatsApp flow — completely untouched; `WhatsApp Message`,
  `WhatsApp Conversation`, `integrations/whatsapp/*` are not modified by
  this ADR at all.
- Team Chat (`Chat Thread` / `Chat Message`, ADR-015) — untouched; Portal
  Chat is a sibling system, not an extension of it.

**Explicitly accepted trade-off:** staff now checks two tabs per patient
(WhatsApp Messages, Portal Chat) instead of one merged thread. This is the
direct, intended consequence of the product decision this ADR implements,
not an oversight.

**Re-evaluation trigger:** if a future requirement asks for a single merged
view again (e.g., a combined "all patient communication" timeline for
convenience), build it as a read-only aggregation *over* both systems
(query both, merge client-side or in a thin API layer, sorted by time) —
do not re-merge the underlying storage; that reintroduces the exact
asymmetry this ADR moves away from.

## Verification

- Sending a message from the Patient Portal chat screen creates a
  `Portal Message` row and never creates a `WhatsApp Message` row.
- Staff replying from the new "Portal Chat" tab never results in a call to
  `_send_free_text` or any Meta Graph API endpoint (verified by mocking/
  removing the `WhatsApp Account` credential entirely and confirming Portal
  Chat still works end-to-end).
- The existing "Messages" (WhatsApp) tab, `WhatsApp Conversation`/
  `WhatsApp Message`, and the 24-hour session-window logic are completely
  unaffected — no shared code path, no shared field.
- `tests/patient_portal/test_patient_portal.py` updated to assert against
  `Portal Conversation` / `Portal Message` instead of `WhatsApp Message`.
- New tests for `portal_chat.py` covering role gating, company scoping, and
  the absence of any WhatsApp credential requirement.

## References

- ADR-036 (superseded by this document) — original tagged-single-thread
  design and the reasoning that led away from it.
- ADR-015 (Team Chat, staff-only messaging) — the thread/message pattern
  this ADR copies, and why its doctypes aren't reused directly.
- ADR-018 (multi-jurisdiction compliance) — patient communication
  provenance considerations, satisfied here structurally (separate
  doctypes) rather than via a tag.
- Constitution §4, Rule 1 (upgrade-safe) — new doctypes are our own, not
  vendor-owned, so no custom-field constraint applies here (unlike
  ADR-036's approach on `WhatsApp Message`).
- `remedisys_healthcare_ai/api/v1/patient_portal/chat.py`
- `remedisys_healthcare_ai/api/v1/messages/api.py` (Team Chat, pattern
  reference)
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/chat_thread/chat_thread.json`
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/chat_message/chat_message.json`
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/whatsapp_conversation/whatsapp_conversation.json`
- `EB_Healthcare_Frontend/src/hooks/use-whatsapp.ts` (pattern reference)
- `EB_Healthcare_Frontend/src/components/narzim/patient-chart/messages-tab.tsx`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-30 | Sarvesh | Initial version (header backfilled from git history) |
