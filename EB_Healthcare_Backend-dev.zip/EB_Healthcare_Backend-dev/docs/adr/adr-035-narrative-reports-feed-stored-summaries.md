# ADR-035: Narrative reports feed the patient-wide lab summary and the clinical summary

**Doc status:** living · **Created:** 2026-07-25 by Divyanshu · **Updated:** 2026-07-25 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-25
- **Supersedes:** the ADR-019 gap G14b premise *as applied to the stored summaries* — that an Imaging-type Lab Test "has nothing to summarise because it has no discrete rows". That premise stands for per-analyte flagging (a narrative report still produces no `High`/`Low`/`Abnormal` flags and no trend points); it no longer stands for summary CONTENT. ADR-019's encounter binding is otherwise untouched.
- **Superseded by:** —

## Context

Since the multi-panel extraction gained per-document classification (ADR-022 v4), an upload can produce **narrative** Lab Tests — genetic, pathology, imaging, and functional-study reports with no discrete analyte rows. They are created as Imaging-type Lab Tests (`imaging_toggle = 1`) whose whole result is one free-text field, `descriptive_result`.

Observed on `remedisis.localhost` for patient `MRN-2026-0000120` (2026-07-25):

| Lab Test | `imaging_toggle` | `descriptive_result` |
|---|---|---|
| Invitae Inborn Errors of Immunity and Cytopenias Panel | 1 | 40,615 chars |
| Molecular Genetics / Transcriptomics / High-Speed Video Microscopy / FeNO | 1 | ~1,500–1,650 chars each |
| HbA1c, Lipid Screen, CBC, ALC, DLC, … | 0 | analyte rows |

All five narrative tests are submitted (`docstatus = 1`). Neither stored summary reflects a single word of them:

1. **Patient-wide lab summary** (ADR-029) — `services/lab_result_summary.py::_rows_for_patient_summary` and the trend collector both `continue` on `imaging_toggle`, so `lab_narrative` and `lab_flags` can only ever contain tabular analytes. That patient's `lab_flags` holds five entries (HbA1c, HDL Cholesterol, Globulin, Nitritos, Bacterias) — every one from a tabular test.
2. **Clinical summary** (ADR-029, `AI Patient Clinical Summary`) — `services/patient_clinical_summary.py::_gather_labs` delegates to the same `_rows_for_patient_summary`, inheriting the exclusion. The delta run that followed the narrative uploads recorded `source_counts` `{"labs": 0, …}` — all zeros — because the only new Lab Tests were invisible to the gatherer. Its own narrative text conceded the gap: *"Previous elevated globulin concerns are not updated."*
3. **The lab chat** already reads them. `_chat_imaging_reports` (bounded, boilerplate-guarded) feeds `lab_context_text`, used only by `ask_lab_question`. So the assistant can answer questions about the genetic report while both stored summaries remain blind to it.

Two aggravating details:

- `lab_test_count` is `len(lab_tests)` measured *before* the skip, so narrative tests are counted but not read — the summary looks complete when it is not.
- The exclusion is invisible to the clinician. Nothing on screen says "5 reports were not considered", so a summary that has never seen a pathogenic-variant report reads exactly like one that has.

This is a clinical-safety gap, not a cosmetic one: a genetic report identifying pathogenic variants is precisely the content a physician expects a patient-level summary to carry forward.

Constraints that shape the fix: **Rule 5** (no full-history dumping; explicit, logged truncation; the documented budget is AI Settings `llm_context_token_budget`), **Rule 6** (advisory only — explanation, never a diagnosis or plan of care), **Rule 10** (no PHI in logs), and §9 (prompts are versioned files, never inline). Repo direction, 2026-07-25: **prompts must not name specific analytes or units** — they serve every report the platform sees, so rules stay generic.

## Decision

Narrative reports become a **first-class, separately-labelled context block** in both stored summaries, summarised rather than dumped, and never a source of analyte flags.

1. **Promote the collector.** Generalise `_chat_imaging_reports` into a shared `narrative_reports_for_patient(patient)` in `services/lab_result_summary.py`, keeping its existing guards: submitted **and** draft-with-a-real-value, and the boilerplate check that skips an untouched template skeleton. It returns `{lab_test, lab_test_name, text, is_draft}`. `lab_context_text` switches to it, so the chat keeps today's behaviour by construction.

2. **Bound by the documented budget, not new constants.** Both new call sites reuse `_narrative_input_text`'s mechanism — AI Settings **`llm_context_token_budget`**, approximated at ~4 chars/token, truncation logged content-free (Rule 10). No new hardcoded cap is introduced. `_LAB_CHAT_IMAGING_CAP` / `_LAB_CHAT_IMAGING_CHARS` stay as the chat's own pre-existing caps.

3. **Summarise long reports; never dump them.** A report over the per-report share of the budget is reduced via the existing `llm.summarize_narrative_report` before entering either aggregate prompt, and the condensed form is what the aggregate sees. A 40,615-character genetic report cannot otherwise share a 4,000-token context block with 65 tabular tests. Where a report has already been summarised for its own Lab Test (`custom_ai_summary`, ADR-033), **that stored summary is reused** and no new LLM call is made.

4. **Lab summary: narrative in, flags unchanged.** `patient_lab_summary_v3.txt` (new version; v2 untouched) gains a `NARRATIVE REPORTS` section instructing the model to weave those findings into the narrative. `lab_flags` remains analyte-only — a narrative report yields no `High`/`Low`/`Abnormal` row and no trend point, so nothing is invented to fill the schema. `lab_test_count` is unchanged; a new `lab_narrative_report_count` records how many narrative reports were actually read.

5. **Clinical summary: a distinct category, delta-aware.** `_gather_context` gains `narrative_reports` as its own category — not folded into `labs`, so `source_counts` shows separately how many were read, and truncation can be reasoned about per category. `patient_clinical_summary_v2.txt` (new version) describes the block. The category **honours the `since` watermark like every other gatherer**: a rolling update carries only reports that changed after it. This is not optional — `_is_empty()` over the delta context is what lets an unchanged patient skip the LLM call, so returning every narrative report on every pass would make that check never fire and charge a full regeneration for each unrelated write. Standing findings are not lost by this: they are already in the previous summary the update revises, exactly as for labs, conditions and every other category. The patient-wide **lab** summary passes no watermark — it is regenerated whole, not incrementally.

6. **Regeneration triggers.** The ADR-029 `doc_events` hook already fires for every Lab Test including Imaging-type, so both summaries already regenerate on a narrative save — verified by the `modified` timestamp on the summary row. No trigger change; only the gatherers change.

7. **Rule 6 boundary restated in both prompts.** Genetic and pathology findings carry a stronger pull toward diagnosis than a numeric panel does. Both new prompt versions state that carrier status, variants of uncertain significance, and pathology impressions are reported as **findings the report states**, never converted into a diagnosis, a risk quantification, or a management plan. Generic wording — no analyte, gene, or unit named.

## Alternatives Considered

1. **Leave the exclusion; rely on the lab chat (status quo).**
   - Pros: zero work; zero added token cost; the information is reachable if asked for.
   - Cons: the clinician must already suspect there is something to ask about. A stored summary that silently omits a pathogenic-variant report is actively misleading — the failure mode is an omission the reader cannot see. Rejected.

2. **Narrative reports as their own separately-labelled block, summarised, flags untouched (chosen).**
   - Pros: the content reaches both summaries; the analyte/flag/trend contract is unchanged, so nothing downstream that consumes `lab_flags` has to change; `source_counts` makes the new source auditable; budget and truncation reuse the documented mechanism; reusing ADR-033 summaries keeps the marginal LLM cost near zero for reports already summarised.
   - Cons: two new prompt versions to maintain; a long report is read in condensed form, so wording in the aggregate is one step removed from the source; a report never summarised before costs one extra call on first inclusion.

3. **Feed raw `descriptive_result` text straight into the existing prompts.**
   - Pros: simplest diff; no summarisation step; no new prompt version.
   - Cons: a single 40K-character report is ~10,000 tokens — it would consume the whole Rule 5 budget and push the tabular rows out, making the summary *worse* for the 65 tests that currently work. Violates Rule 5's spirit even while technically truncating. Rejected.

4. **Synthesise pseudo-analyte rows from narrative text so the existing pipeline works unchanged.**
   - Pros: no prompt or schema change at all; narrative content would flow through `lab_flags` and trends for free.
   - Cons: requires the model to invent an analyte name, a value, and a reference range that were never printed — fabricated structured clinical data, flagged against a range that does not exist. Squarely against Rule 6 and the extraction prompt's own "never infer or invent a value" rule. Rejected on safety.

## Consequences

- **Code — `services/lab_result_summary.py`:** `_chat_imaging_reports` → shared `narrative_reports_for_patient`; new helper to resolve a report's condensed text (prefer the stored ADR-033 summary, else `summarize_narrative_report`, else the budget-truncated verbatim text); the patient-lab-summary builder gains the narrative block and `lab_narrative_report_count`. `_rows_for_patient_summary` keeps skipping `imaging_toggle` — it stays analyte-only by design, and its docstring must say so explicitly so the skip is not re-read as an oversight.
- **Code — `services/patient_clinical_summary.py`:** new `_gather_narrative_reports` (watermark-aware, see Decision 5); `narrative_reports` added to `_gather_context`, to `_CONTENT_KEYS`, and to `source_counts`.
- **Prompts (§9):** new `patient_lab_summary_v3.txt` and `patient_clinical_summary_v2.txt`; version defaults bumped at their call sites; v2/v1 left on disk unmodified. Both free of analyte-, gene-, and unit-specific literals.
- **Doctype:** `AI Patient Clinical Summary` gains `lab_narrative_report_count` (Int) with a patch in `patches.txt` — no manual schema edit (§9). Per the fixtures trap, any custom field goes in the **package-level** `fixtures/custom_field.json`.
- **Cost:** one extra summarisation call per narrative report **only on first inclusion**, and none for reports already carrying an ADR-033 summary. Aggregate prompts grow by at most the narrative block's share of `llm_context_token_budget`. Every call is audited in `AI Prompt Log` (model, tokens, cost, prompt hash — no content, Rule 10).
- **Behaviour change to review:** patient-level summaries for patients with narrative reports will change wording on the next regeneration. `lab_flags`, trends, and the Lab Test detail popover are unaffected.
- **Not in scope:** narrative reports still produce no trend points and no analyte flags; the encounter copilot's `get_lab_analysis` tool (ADR-030) is untouched; the deeper catalog-modelling issue behind unit-variant analytes (one `Lab Parameter` per name) is separate and unrelated.
- **Re-evaluation triggers:** (a) clinicians report the condensed form loses detail they needed → revisit per-report budget allocation, or a retrieval step over the full text instead of a fixed block; (b) narrative reports become common enough that the aggregate prompt is budget-bound → split the lab summary into tabular and narrative passes; (c) a physician asks for narrative findings on the problem list → that is a structured-extraction decision needing its own ADR, not an extension of this one.

## Verification

- A patient with **only** narrative Lab Tests gets a lab summary and a clinical summary that describe those reports — today both are empty of them.
- `MRN-2026-0000120` regenerated: `summary_en` references the genetic findings; `source_counts.narrative_reports` is 5, not 0; `lab_flags` still holds exactly the five analyte entries (no fabricated narrative flag).
- The 40,615-character report is included in condensed form; the truncation/summarisation is visible in `logs/remedisys.log` with character counts and the token budget, and **no report text** (Rule 10).
- `AI Prompt Log` rows for the new calls carry model/tokens/cost/prompt-hash only.
- A narrative Lab Test left as an untouched Draft skeleton is **not** included (boilerplate guard holds).
- An unrelated write to a patient who owns a narrative report still takes the cheap incremental path — `source_counts` records no new content and no LLM call is made (the watermark check in Decision 5 holds).
- Both new prompt files contain no analyte, gene, or unit literals — grep-checked.
- `ruff` + `mypy` clean; the lab and clinical summary tests under `remedisys_healthcare_ai/tests/labs/` pass, extended with a narrative-only-patient case.

## References

- ADR-019 (encounter-native binding; gap G14b — the "no discrete rows" premise narrowed here)
- ADR-022 (multi-panel extraction; per-document classification creates narrative reports)
- ADR-029 (AI Patient Clinical Summary — event-driven rolling regeneration)
- ADR-033 (report summary stored on the Lab Test — the reused per-report summary)
- Constitution Rule 5 (retrieval + explicit token budget), Rule 6 (physician in control), Rule 10 (no PHI in logs), §9 (versioned prompts, migration patches)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-25 | Sarvesh | Initial version (header backfilled from git history) |
