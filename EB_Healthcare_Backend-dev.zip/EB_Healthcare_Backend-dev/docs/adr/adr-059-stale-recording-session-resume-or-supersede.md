# ADR-059: A stale `Recording` session resumes or is superseded — it never deadlocks the encounter

**Doc status:** living · **Created:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-04
- **Supersedes:** —
- **Superseded by:** —

## Context

An `AI Encounter Session` leaves `Recording` only when `stop_session` is called. A closed tab, a
page reload, a browser crash or a dropped provider connection all skip that call, so the row stays
`Recording` for ever.

`record_consent` (T-38) then refused, because it required `status == "Draft"`:

```
ValidationError: Consent can only be recorded before recording starts.
  api/ai/sessions.py:492
```

That refusal was correct in intent — consent must never be amended in place, because rewriting
`consent_obtained_at` would misrepresent when consent was actually given — but it made the encounter
**permanently un-recordable**. The consent gate asks, the clinician answers, the answer is rejected,
and there is no path back for anyone, on any device.

Measured on the local bench on 2026-09-04: **31 encounters** were in this state, the oldest stranded
since 2026-08-29.

The frontend is not at fault. `use-recording.ts:148-157` deliberately re-asks rather than adopting an
existing session, and that decision is right: an existing `Recording` session is not evidence anyone
was asked. The two halves simply disagreed about what should happen when the clinician answers.

### The discriminator

`consent_method` separates real evidence from a client-side assertion. Of the 31 stuck sessions:

| `consent_method` | `consent_obtained` | Count | Meaning |
|---|---|---|---|
| `unverified` | 1 | 25 | V1 auto-start wrote the flag client-side. **Nobody was asked** |
| `asked_and_agreed` | 1 | 6 | A human was asked and answered |

Both look identical on `consent_obtained`. Only `consent_method` tells them apart, and 81% of the
stuck rows are the kind that must never be treated as consented.

The safety net does not cover this. `sweep_orphan_sessions` only closes sessions older than
`max_session_minutes` (60), so a clinician who reloads is blocked for up to an hour; it had never run
on the local bench (0 `Scheduled Job Log` entries); and dev has `enable_orphan_sweep = 0` entirely.

## Options considered

| | Approach | Pros | Cons |
|---|---|---|---|
| A | Front-end silently adopts any existing `Recording` session | Trivial; deadlock gone | Reverses the documented decision at `use-recording.ts:148`. On 25 of 31 rows it would treat a client-side assertion as consent — the PHI-2 defect the gate exists to close |
| B | Let `record_consent` overwrite consent on a `Recording` session | Smallest diff | Rewrites `consent_obtained_at` retroactively, which this endpoint's contract forbids by name. On a genuinely live session it also re-stamps a different clinician as `consent_by` |
| C | Auto-close any stale `Recording` session and open a fresh `Draft` | Backend only, no i18n. Consent integrity preserved | Cannot distinguish "stale" from "recording next door". Closing a live session drops a real recording |
| **D** | **Disclose, and branch on who owns the session and whether its consent is real** | Never infers consent, never rewrites a timestamp, never guesses staleness | Backend and frontend must change together; backend must deploy first |

## Decision

**D.** `record_consent` branches on three cases when it finds an active session that is not `Draft`:

1. **Another user's session** → refuse, with a message that says so. ADR-039 makes a covering
   physician a designed workflow, so superseding a colleague would drop a real recording
   mid-consultation. The previous generic message sent clinicians to check their network.
2. **The caller's own session, `consent_method == "asked_and_agreed"`, caller agreeing again** →
   return the row **untouched** with `resumed: True`. Real evidence exists; the front-end reattaches.
   Nothing is written, so `consent_obtained_at` keeps the real answer's timestamp.
3. **Anything else** — a decline, or `unverified` consent → close the stale row `system_close` and
   record consent on a fresh `Draft`. The superseded row keeps its original `consent_method` as
   evidence of what actually happened; the new answer gets its own honest timestamp.

`get_active_session` additionally returns `consent_method`, which is what lets the front-end offer
"resume" only where case 2 applies.

C is not discarded — it is the mechanism used inside case 3, scoped by ownership so it can never
close a colleague's live recording.

### Why the others lose

A is unsafe on 81% of the affected rows. B destroys the audit record T-38 was built to create. C
alone is right in mechanism but guesses at staleness; asking a human is better than guessing about a
live recording.

### What would falsify this

If `consent_method` stops being written reliably on new sessions, the discriminator collapses and
case 2 would start resuming sessions whose consent is not evidence. `TestGetActiveSessionConsentMethod`
exists to catch that.

## Consequences

- A reload during recording resumes instead of burning the encounter.
- A family withdrawing consent mid-consultation now **stops** the recording. Previously the call was
  refused and recording continued.
- Legacy `unverified` sessions are closed rather than resumed, so no legacy row is ever mistaken for
  consent.
- `record_consent` gains a `resumed` key in its response. Additive; existing callers are unaffected.
- **Deploy order matters.** The backend must ship before the frontend, or the frontend reads a
  `consent_method` field that is not there — the same class of failure as the 2026-09-04 dev incident
  recorded in `prompts/2026-09-04-dev-mic-record-consent-missing.md`.
- The 31 already-stuck rows are not migrated by this change. They unblock the first time a clinician
  answers the gate on those encounters, via case 3.
- Not addressed here: `enable_orphan_sweep = 0` on dev, and the sweep having never run locally. The
  sweep remains a garbage collector for old sessions, not a recovery path.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-04 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
