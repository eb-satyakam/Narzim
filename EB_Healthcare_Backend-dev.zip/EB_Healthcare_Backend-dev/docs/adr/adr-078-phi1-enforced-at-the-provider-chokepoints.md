# ADR-078: PHI-1 is enforced at the provider chokepoints and at the save, not in one feature

**Doc status:** living · **Created:** 2026-09-18 by Divyanshu (AI-assisted) · **Updated:** 2026-09-18 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — decision taken 2026-09-18.
- **Date:** 2026-09-18
- **Supersedes:** nothing. It gives CLAUDE.md §9.9 **PHI-1** an implementation; the rule is unchanged.
- **Superseded by:** —
- **Related:** ADR-026 (LLM provider allowlist — a vendor change needs review), ADR-009 (browser streams audio direct to Deepgram), ADR-077 (the retrieval gates, same shape), ADR-018 / ADR-076 (the profiles themselves), CLAUDE.md §9.9 PHI-1, Rule 7.

## Context

CLAUDE.md §9.9 PHI-1 says:

> Every subprocessor that receives patient data must be named in the active `ComplianceProfile`.
> **An integration must refuse to run against a provider the active profile does not name.**

Measured on 2026-09-18, that refusal existed in **exactly one function**:
`services/registration_form_extraction.py::_assert_provider_declared`, guarding the
registration-form scanner (and re-exported to `services/drive_summary.py`). Everything else
reached a vendor with nothing checked:

| Path | Callers | Checked? |
|---|---|---|
| `services/llm.py::get_llm_client()` | ~15 modules — Encounter Copilot, SOAP, Narzim | **no** |
| `integrations/llm.py::provider()` | ~12 dispatch points — lab extraction, lab summaries, dedup | **no** |
| `integrations/deepgram.py` | all ASR | **no** |

And `ComplianceProfile.audio_provider` had **zero readers anywhere in the codebase** — a field
declaring who receives a patient's voice that nothing had ever compared to reality. Of the 19
profile fields, 12 had no reader at all.

The rule exists because of a real incident, recorded in CLAUDE.md: the `mx` profile declared
`anthropic`/`groq` while live traffic went to OpenAI and Deepgram. That instance was corrected. The
*class* of defect was not — nothing stopped it recurring, and `india` still declares
`llm_provider="anthropic"` / `audio_provider="groq"` today (deliberately, as an UNVERIFIED
placeholder with a warning comment).

**The live scenario this is really about.** `AI Settings.llm_provider` is a two-option `Select`
that any **System Manager** can change from the Desk UI. ADR-026 made that a feature — "swap
providers by changing llm_provider in AI Settings, no code change". Nothing compared that change to
the subprocessor register, so a two-click config edit could silently redirect every subsequent
consultation to a vendor the register does not name, with no log line and no error.

## Decision

**The check runs at the point the provider is CHOSEN, and again at the point the setting is SAVED.
One implementation, in `compliance/`.**

1. **`compliance.assert_llm_provider_allowed()` and `compliance.assert_audio_provider_allowed()`** —
   new, beside the register they read. Both **raise**; neither returns a boolean a caller can ignore.
2. **Both LLM dispatchers call it.** `services/llm.py::get_llm_client()` **and**
   `integrations/llm.py::provider()`. There are two provider-decision functions in this codebase and
   guarding one would have left the other's ~12 dispatch points unchecked.
3. **The Deepgram boundary calls it at all three entry points** — `mint_session_token`,
   `mint_browser_token`, `transcribe — *before* the API-key check, so a vendor the register omits is
   refused whether or not the site is even configured to reach it.
4. **`AI Settings.validate()` refuses the save** that would create the mismatch, so the mistake is
   caught at the screen where it is made rather than by a clinician mid-consultation. Skipped during
   migrate/install/patch/import so a shipped default can never make `bench migrate` fail; never
   skipped in tests.
5. **The vendor display-name → slug mapping lives in one place.** It was hand-rolled inside the form
   scanner; that function now delegates.

### Why the token mint, and not the audio upload

Under ADR-009 the browser streams audio **straight to Deepgram** and it never passes through Frappe.
The disclosure decision is therefore made when we **mint the token**, not when bytes move. A gate
watching only our own outbound audio would be watching the one path the audio does not take.

## Alternatives considered

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | Check inside each vendor module (`openai.py`, `anthropic.py`, `deepgram.py`) | Closest to the wire — impossible to reach a provider without passing it | Three copies that must each remember, and a fourth for every new vendor. The duplicated-logic failure is not hypothetical here: the streaming and blocking prompt paths diverged exactly that way on the same day |
| **B** | **At the dispatchers + the ASR boundary + the save (chosen)** | Covers ~27 call sites with four edits, at the places the CHOICE is made. Prevention and detection are separated, so an already-wrong site is caught too | A caller that imports `integrations.openai` directly bypasses the dispatcher — checked, and nothing outside `integrations/llm.py` does |
| **C** | Validate once at boot / app init | Fails loudly at deploy, never mid-encounter — the friendliest to Rule 7 | Misses the actual scenario. A System Manager flipping a dropdown at 11am would not be caught until a restart, and "refuse to boot" on a clinical system is worse than the disease |
| **D** | `validate()` on AI Settings only | Stops the mistake at the moment it is made, with a clear message to the person making it, and nothing can break at runtime | Only covers the Desk path — a fixture, a patch or a `db_set` bypasses it entirely, and it does nothing for a site whose value was already wrong before the hook existed |

**Why B.** **A** loses on duplication, in a codebase that produced a live defect from exactly that
on 2026-09-18. **C** loses on the one case that matters: the runtime dropdown change. **D** is not
wrong — it is **half of B**, and it is included in B for the reason its own Pros column gives. D
alone leaves every already-wrong site unprotected; B's dispatcher guard alone would first announce
itself by taking AI away from a clinician mid-consultation for a mistake someone else made days
earlier. Prevention and detection answer different questions and both are cheap.

**What would falsify this choice:** if the dispatcher guard turns out to fire in production for a
reason other than a genuine mismatch — a cache staleness, a migration ordering, a test fixture
leaking — then it is costing clinical availability for no compliance gain, and the right answer
collapses to D plus a monitoring alert. Watch the first month.

## Consequences

- **Rule 7 is not violated, and this was checked rather than assumed.** A mismatch degrades AI
  exactly as a provider outage does: the caller reports AI unavailable, the Encounter form still
  loads, saves and submits, and the clinician writes the note by hand. No clinical action depends on
  the guard passing.
- **An India deployment will refuse AI outright** until its profile is verified, because `india`
  declares `anthropic`/`groq` against live OpenAI/Deepgram. **That is the intended behaviour**, not
  a regression: the profile's own comment says "Verify before an India deployment carries patient
  data", and this turns that comment into something enforced instead of something read.
- **An unreadable `AI Settings` no longer falls through silently.** `get_llm_client()` defaulted to
  Anthropic on any exception — CLAUDE.md §3 flags that as the untested, uncached, mispriced path.
  It now has to survive the same check, so on `mx` (which names OpenAI) it refuses instead.
- **The two dispatchers still both exist**, and they even disagree on their fallback spelling
  (`"Anthropic"` vs `"Claude"`). Merging them is worth doing and is deliberately **not** done here:
  it touches ~28 call sites across two layers, and a refactor of that size does not belong inside a
  compliance fix. Follow-up.
- **Ten profile fields still have no reader** — `audit_retention_years`, `right_to_erasure`,
  `consent_required`, `breach_notification_hours` and others. This ADR closes `llm_provider` and
  `audio_provider` only. The rest are declarations nothing enforces, and each needs the same
  treatment or honest removal.
- **This does not make the product compliant**, and no code change can. It is one technical control.
  See CLAUDE.md §11 and `docs/compliance/HIPAA_READINESS.md`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-18 | Divyanshu (AI-assisted) | Initial version — PHI-1 enforced at both LLM dispatchers, the Deepgram token mint and the AI Settings save, replacing a single-feature guard |
