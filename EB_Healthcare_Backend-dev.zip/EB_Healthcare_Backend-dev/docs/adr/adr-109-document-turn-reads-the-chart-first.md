# ADR-109: A document written from a template reads the chart first, and returns no placeholder

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

In Narzim GPT a clinician can attach a template, link a patient, and ask for the document. On
2026-09-30 the owner did that with the word "generate". The reply was the template itself, with
nine placeholders in it. The AI Prompt Log shows one model call and no tool call.

adr-108 had already added a prompt section telling the model to read the chart before writing and
never to print a bracket. The model followed neither instruction on this turn. The streaming path
had a second fault of the same kind: an answer that could not be saved was still shown, and the
stream said nothing.

## Decision

When a template is attached and a patient is linked, two steps are taken in code, around the model
call (`services/narzim_document_turn.py`).

1. **Read first.** `chart_snapshot` runs the read tools through `ai_tools.execute_tool` and places
   the results in the prompt: the visit's state when a visit is linked, then allergies, current
   medications, labs and previous encounters. It adds the patient's name, today's date, and the
   signed-in clinician and clinic.
2. **Remove what is left.** `remove_unfilled_slots` removes from the reply any bracket whose text
   is one of the attached template's own slots, with the line it stood on when nothing else is on
   that line. The names of the slots left out are returned as `unfilled_slots`.
3. The model keeps its tools and may still call them.
4. Apply template uses the same two steps and keeps the label of a blank field.
5. The stream's closing event carries `saved`, false when the reply could not be written.

## Alternatives Considered

1. **A stronger prompt.**
   - Pros: no code.
   - Cons: this is what adr-108 did, and it did not hold for one turn. A rule the model may ignore
     is not a control.
2. **Read first and remove afterwards, in code (chosen).**
   - Pros: the document is filled from the record whatever the model decides; a placeholder cannot
     reach the clinician; what was left out is named.
   - Cons: every document turn reads four or five tools, including ones the template may not need.
3. **Read only what the template's slots name.**
   - Pros: the narrowest read (PHI-6).
   - Cons: slot names are free text in two languages. Mapping "Meds", "Tratamiento actual" and
     "What they take" to one tool is a classifier, and its misses would be silent gaps.
4. **Retry the model when it returns a placeholder.**
   - Pros: no post-processing.
   - Cons: a second paid call with no guarantee; slots with no answer would loop.
5. **Force a tool call with `tool_choice`.**
   - Pros: the provider guarantees one call.
   - Cons: one call, not the five a document needs, and the two provider adapters differ.

## Consequences

- PHI-6: a document turn sends the patient's name and a wider part of the chart to the LLM
  provider than an ordinary chat turn does. The provider is the one the active `ComplianceProfile`
  names; nothing new is contacted. An ordinary chat turn is unchanged and still sends the id only.
- BE-5: each read is bounded by its tool. What reaches the prompt is capped at 4,000 characters a
  tool and 16,000 in all.
- BE-10: tool names are logged; their results and the slot values are not.
- BE-6: the reply is a draft turn in a chat thread. Nothing is written to the record.
- A slot the record does not answer is removed, never filled with a guess. The clinician sees the
  list of what was left out and edits the draft.
- Re-evaluate alternative 3 if the cost of document turns becomes material.

## Verification

- `tests/ai/test_narzim_document_turn.py`, 27 tests.
- `tests/ai/test_narzim_stream_parity.py`: the `saved` flag, true and false.
- On `marley.local` against the live model, 2026-09-30, the reported request repeated: four tools
  read, no bracket in the reply, the two prescriptions and the clinic present, six slots reported
  as left out (clinic address, phone, email, the specialist's name and two more).

## References

- adr-108 (the prompt rule this makes enforceable), adr-105 (template prompts), ADR-075, ADR-030
- `CLAUDE.md` BE-5, BE-6, BE-10, PHI-6

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-107 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
