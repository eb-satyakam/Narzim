# ADR-093: Staff push banners name the patient, resolved from our own origin rather than sent through Google

**Doc status:** living · **Created:** 2026-09-25 by Ashutosh (AI-assisted) · **Updated:** 2026-09-25 by Ashutosh (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — decision taken 2026-09-25 by the product owner.
- **Date:** 2026-09-25
- **Supersedes:** nothing. It qualifies the content-free payload contract in ADR-045, which still holds for the payload itself.
- **Superseded by:** —
- **Related:** ADR-045 (FCM + SSE), CLAUDE.md §9.9 **PHI-1** (subprocessor register) and **PHI-6** (minimum necessary), `docs/PUSH_NOTIFICATIONS.md` §4.4.

## Context

EHR out-of-app push shipped earlier the same day. The first real banner read:

```
New message from a patient
localhost:3000
```

The product owner asked for the patient's name instead — *"Khalid Kashmiri sent a
message"* — so staff can triage without opening the app.

The banner is generic because **the FCM payload is deliberately content-free**. It
carries a generic title plus two identifiers (`type`, `ref`) and nothing else. That
is not decoration: it is the reason Google is **absent from the subprocessor
register**. `compliance/profiles/mx.py` names `openai`, `deepgram` and `ncbi`, and
argues explicitly that NCBI is "a retrieval host and not a PHI subprocessor"
*because no patient identifier reaches it*. FCM stands on exactly the same
argument today. A separate open item — the Google/FCM data-terms check against
both profiles — is **not started**.

So there are two distinct exposures hiding behind one request, and they have
different answers:

1. **Does Google receive the name?** Putting it in the payload makes Google a PHI
   subprocessor. PHI-1 then requires the profile change in the same commit, and
   the data-terms review that has not happened.
2. **Does an unattended staff screen show the name?** The banner appears only when
   no EHR window is visible. At a front desk that can mean the screen is facing
   the waiting room.

## Decision

**The name is shown, and Google never receives it.**

The payload is unchanged — still generic, still two identifiers. When the service
worker builds the banner it calls `/api/push/preview?type=&ref=` on our own
origin with the recipient's session cookie, and the backend
(`api/v1/push/api.py::notification_preview`) returns the `subject` of the
`Notification Log` row **addressed to that caller**.

Exposure 2 was put to the product owner with four options (per-clinic toggle
defaulting off, on for everyone, per-user, or keep it generic). **"On for everyone,
no toggle" was chosen**, with the waiting-room case stated. Recorded here because
that is a deliberate acceptance, not an oversight.

## Consequences

**What this does not change.** Google's copy of every notification is byte-for-byte
what it was: a generic title, `type`, `ref`, `link`. The subprocessor register stays
correct without amendment, and the pending data-terms check keeps the same scope.

**What it discloses, precisely.** The same `subject` string the recipient already
sees in their bell — reused deliberately, so the banner and the in-app row cannot
drift apart. It is a name and an action ("sent a message"), never message text and
never clinical content.

**Why returning a name from this endpoint is safe.** The lookup is filtered by
`for_user = <the caller>`. A caller can only read back a notification already
addressed to them; guessing another user's `ref` returns an empty title. Verified:
a recipient got the name, a non-recipient with no such row got `""`.

**Accepted risk.** A banner naming a patient can appear on an unattended
workstation. There is no toggle, by decision. Mitigations already in place: the
banner is suppressed whenever any EHR window is visible, registration is per-login
and dropped on sign-out, and the body carries no message text. If a clinic reports
this, the fix is the per-clinic switch that was offered and declined — the settings
section (`EB Clinic Settings.notifications_section`) already exists to hold it.

**It fails open.** A 401, an error or a network slower than 2.5 s falls back to the
generic title. A banner that says slightly less is a non-event; one that never
appears is a missed patient message.

**Language.** `subject` renders in the writer's session language, not the reader's
— a pre-existing wart recorded in `PUSH_NOTIFICATIONS.md` §4.7, inherited here
rather than introduced. The generic titles it replaces *are* translated, so a
Spanish-speaking staff member may now see an English banner where they previously
saw a Spanish one. Narrow, and the fix belongs with the §4.7 work.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-25 | Ashutosh (AI-assisted) | Initial version |
