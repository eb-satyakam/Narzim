# ADR-074: "Pay Now" silently did nothing once a visit's own invoice was settled but the patient had other unbilled items — and reschedule delta invoices never carried a practitioner

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-16
- **Supersedes:** — (fixes a real bug ADR-071 introduced as a side effect; does not replace it)
- **Superseded by:** —

## Context

Reported live, marked highest priority: on patient Ximena González Torres (MRN-2026-0001432), a queue card showed a green "Paid" badge for her 4:15 PM Anant Sharma visit — correctly, that appointment's own invoice (`ACC-SINV-2026-01020`) was fully paid, 0 outstanding. But the drawer's PAYMENT tile showed "Unpaid MXN 1,740," and clicking "Pay Now" did nothing at all — no dialog opened.

This is the same badge-vs-drawer pattern already seen once (Diego Gómez Reyes) and recorded in ADR-073 as an accepted, cosmetic UX tension. This time it was flagged again, on a different patient, as the top-priority issue — treated here as the correction it is: the NUMBER being right (1,740 is genuinely Ximena's real unbilled total across 3 other visits, confirmed live) does not mean the BUTTON built to act on that number was ever updated to work with it.

Traced `mission-control-client.tsx`'s "Pay Now" wiring (`goCollect` → `onAction("queue.actCollect", row)` → `setCollectFor(row)`) to the dialog that actually renders:

```jsx
{collectFor && collectAppt?.billing?.collect_invoice ? (
  <CollectPaymentDialog ... />          // settle an EXISTING balance on THIS appointment's own invoice
) : collectFor && !collectFor.invoiced && (
  <NewInvoiceSheet ... prescope={{ mode: "appointment", appointmentId: collectFor.name }} />  // bill THIS appointment fresh
)}
```

For Ximena's row: `collectFor.invoiced` is `true` (her visit IS invoiced) and `collectAppt.billing.collect_invoice` is `null` (that invoice has zero balance — nothing of its OWN to collect). **Both branches evaluate false. Neither dialog renders.** This ternary was written before ADR-071 made `canCollect` (the condition that makes "Pay Now" clickable at all) reflect the PATIENT's total unbilled amount rather than this one appointment's own state — so the button became clickable in a new case (this visit settled, but the patient owes elsewhere) that neither existing branch was ever built to handle.

Separately, in the same investigation: Diego Gómez Reyes' Patient 360 Billing tab showed a blank Practitioner column for both of his reschedule-delta invoices (`ACC-SINV-2026-01012`, `-01013`), while his normally-booked invoices correctly showed one. Traced to `_create_reschedule_delta_invoice` (`services/billing.py`) never setting `ref_practitioner` on the Sales Invoice it builds — unsurprising once traced, since that invoice is deliberately never reference-linked to the appointment (to dodge Healthcare's "already invoiced" re-validation guard), so core never gets the chance to auto-populate it from the appointment's own practitioner the way it does for a normal booking.

## Decision

1. **`mission-control-client.tsx`'s collect-dialog ternary gains a third branch**: when the row's own invoice chain has nothing to collect (checked via `collectAppt !== undefined && !collectAppt?.billing?.collect_invoice`, guarding against a still-loading fetch) but `collectFor` is set at all, open `NewInvoiceSheet` with `prescope={{ mode: "patient", ... }}` — the exact same, already-proven prescope mode the Patient Chart's own top-level "Pay now" button already uses (`patient-chart-client.tsx:955`).
2. **`_create_reschedule_delta_invoice`** gains a `practitioner: str | None` parameter, set as `si.ref_practitioner` before save when given. **`adjust_payment_for_reschedule`** now passes its own `new_practitioner` through.

## Alternatives Considered (item 1 — the dead-end button)

1. **Add a third, patient-scoped branch reusing the existing `mode: "patient"` prescope (chosen).**
   - Pros: reuses an already-shipped, already-correct mechanism (the Patient Chart's own "Pay now" button) rather than inventing a new checkout path; minimal diff; naturally builds a cart from whichever of the patient's appointments are actually still unbilled, which is exactly what the drawer's own number was already promising.
   - Cons: one more conditional branch in an already-nested ternary.

2. **Make `canCollect` appointment-scoped again — revert to ADR-071's original appointment-only condition.**
   - Rejected outright: this is what ADR-071 was explicitly asked to change, twice, across two sessions ("we have to show total amount which is pending not only the Appointment"). Reverting it to fix a downstream wiring gap would re-break the feature it was building.

3. **Keep the ternary appointment-scoped; hide/disable "Pay Now" instead when the current appointment has nothing of its own to collect, even if the patient owes elsewhere.**
   - Rejected: this makes the button lie in the opposite direction — the drawer would show "Unpaid MXN 1,740" right next to a Pay Now button that's disabled, which is a more confusing failure than the current dead click, not a better one.

4. **Route this case through `CollectPaymentDialog` instead of `NewInvoiceSheet`, resolving "which invoice" some other way.**
   - Rejected: `CollectPaymentDialog` settles ONE already-existing invoice by name; Ximena's 1,740 isn't sitting on any single existing invoice at all — it's three still-unbilled appointments with no invoice yet. `NewInvoiceSheet`'s patient-scoped checkout is the only one of the two flows that can build a fresh invoice from unbilled cart lines.

## Why this approach, specifically

- **Vs. 2:** loses because it undoes the very feature this session was asked to build, not because of any flaw in the alternative itself.
- **Vs. 3:** loses on producing a worse-looking failure (an inert button next to a real amount) than the one being fixed.
- **Vs. 4:** loses because it's solving the wrong problem — there is no existing invoice to settle in this case, only unbilled items to bill.

## Consequences

- `EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx`: the collect-dialog ternary gains the third, patient-scoped branch.
- `remedisys_healthcare_ai/services/billing.py`: `_create_reschedule_delta_invoice` gains `practitioner`; `adjust_payment_for_reschedule` passes `new_practitioner` through. Every FUTURE reschedule-delta invoice will carry the correct practitioner; Diego's existing `ACC-SINV-2026-01012`/`-01013` are left as-is (forward-only fix, same policy as every other fix this session).
- **Re-evaluation trigger:** if a fourth checkout entry point is ever found with the same appointment-only assumption baked in (this is the second time a "Pay Now"-style button has needed patient-scope awareness added after the fact — the first was the drawer's own amount display in ADR-071), it's worth a dedicated audit of every `collectFor`/`goCollect`-style handler in the app rather than fixing them one at a time as they're reported.

## Verification

- Root-caused live against Ximena González Torres' real appointment/invoice/payment state (not synthetic): confirmed her 4:15 PM visit is genuinely fully paid, and her 1,740 unbilled total is genuinely real (3 other visits, 500 MXN each, tax-inclusive) — the number was never wrong; only the button's behavior was.
- Confirmed the exact failure mode by reading the ternary's two existing branches against Ximena's actual field values (`collectFor.invoiced: true`, `collectAppt.billing.collect_invoice: null`) — both evaluate false, matching the reported "nothing happens" exactly.
- Confirmed the `mode: "patient"` prescope this fix reuses is not new or unproven — it's the identical mechanism already live behind the Patient Chart's own "Pay now" button.
- The `ref_practitioner` fix verified via `.validate()` on a throwaway, never-saved draft (established pattern from ADR-071/072): confirmed the field survives validation unchanged once set.
- Frontend: `tsc --noEmit` clean (same one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts`); backend: `py_compile` clean.
- Not yet verified: an actual browser click-through confirming "Pay Now" now opens the patient-scoped checkout for a settled-appointment-with-other-unbilled-items row (no browser tooling available here).

## References

- ADR-071 (introduced the patient-wide `canCollect` condition this ADR finishes wiring)
- ADR-073 (the badge/drawer tension this ADR does NOT relitigate — that part stays as documented; only the dead button is new)
- `WORK_LOG.md` 2026-09-16 entry

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
