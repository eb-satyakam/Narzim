# ADR-094: User-selectable columns on the clinical lists, from the full doctype meta

**Doc status:** living · **Created:** 2026-09-24 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-24 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-24
- **Supersedes:** —
- **Renumbered:** 081 -> 094 on 2026-09-26, before merge. dev had already taken 081 (report subject and template-driven summaries); this one had not been merged, so it moved rather than become a third duplicate number. ADR-042 freezes MERGED numbers.
- **Superseded by:** —

## Context

The Patients list showed a fixed set of columns. `_LIST_FIELDS` in
[`api/v1/patients/api.py`](../../remedisys_healthcare_ai/api/v1/patients/api.py) hardcoded twelve
fields, and the frontend rendered each column as bespoke JSX. A user who wanted to see marital
status, occupation or blood group beside a patient's name had no way to ask for it, and adding one
meant a code change in two repos.

Frappe Desk already solves this for its own list views: a "List View Settings" dialog with an
"Add / Remove Fields" picker listing every field on the doctype. The request was for the same thing
on our Next.js Patients screen.

**What makes it a decision rather than a feature ticket.** The Patient doctype is not a neutral table.
Alongside `mobile` and `marital_status` it carries `medical_history`, `allergies`, `surgical_history`,
`tobacco_past_use`, `alcohol_current_use`, `occupation` and `patient_details`. Offering the whole meta
means a Front Desk user can put a child's medical history on a directory screen that is often on a
monitor facing a waiting room.

Three options were weighed (the fourth, fixed presets, was rejected before this ADR because it does
not give the control that was asked for):

| Option | Why it lost / won |
|---|---|
| **A. Expose the full doctype meta** (chosen) | Matches Frappe's behaviour exactly, which is what was asked for. Any Custom Field added to Patient appears with no code change. Cost: no role-based narrowing of *which* clinical fields a given role may surface |
| B. Role-scoped allowlist per role | Narrower exposure, but requires a clinical decision about which role sees which field, which nobody had made; it would have blocked the feature indefinitely |
| C. Show/hide over the existing twelve fields only | Zero new exposure, but does not answer the request — the point was reaching fields the list does not already carry |

**A was chosen explicitly by the product owner** after B was put forward and the exposure described.
It is recorded here rather than left implicit because "minimum necessary" is the governing principle
for patient data in this system (`CLAUDE.md` §9.9), and a widening of what a screen can surface
should be a decision on the record, not a side effect of a UI change.

Note on scope: PHI-6's text governs the context handed to an **AI call**, not a list view, so this
does not contradict a hard rule. The minimum-necessary *principle* still applies, which is why the
technical safeguards below are not optional.

## Decision

The Patients list offers every Patient field the current user may read, chosen through a field
picker, with the choice remembered per browser.

**Three safeguards hold regardless of the above, because they are correctness rather than policy:**

1. **`permlevel` filtering.** `_selectable_patient_fields()` drops any field whose `permlevel` is not
   in `meta.get_permlevel_access("read")` for the calling user. Without this, the column picker would
   be a way around the field-level permissions the doctype already declares — a list view must never
   return more than the form would.
2. **Names are validated, never passed through.** `_resolve_selected_fields()` matches every
   caller-supplied name against that same catalogue and throws on anything else. A fieldname reaches
   `frappe.get_list` only after being found in the meta. The browser cannot name a column into
   existence.
3. **A cap of 50 columns**, matching Frappe Desk's own limit, enforced server-side. The dialog also
   disables further boxes at the cap, but the browser value is not the limit.

**Values are returned under `extra`**, keyed by fieldname, rather than at the top level of each row.
`list_patients` remaps `name` → `mrn`, `patient_name` → `name` and collapses `sex`; a user who picks
one of those as a column must still get its real value, and a top-level merge would either collide
with or silently overwrite the computed keys.

**Non-data fieldtypes are excluded** using Frappe's own `no_value_fields` tuple rather than a
hand-kept copy, so a fieldtype added upstream is excluded automatically instead of leaking through on
the next version bump.

**The catalogue is served from our own whitelisted method**, `get_patient_list_fields`, not Frappe's
`/api/resource` meta endpoint, per the locked API pattern in `CLAUDE.md` §3 — which is also what makes
the permlevel filtering possible, since the browser receives an already-filtered list.

**The choice is stored in `localStorage`, per browser.** A server-side per-user preference would need
a new doctype and a migration; that is deferred, and is the natural next step if the same picker is
wanted on the other list screens.

## Consequences

- A Custom Field added to Patient is immediately offerable as a column, in both repos, with no code change.
- A Front Desk user can surface clinical fields on the directory screen. This is the accepted cost of
  option A, and the mitigation available today is role configuration on the doctype: a field given a
  `permlevel` above 0, with read access granted only to clinical roles, disappears from the picker for
  everyone else. That is a doctype configuration task, not a code change.
- Export column sets are **not** yet tied to the chosen columns, so a user may see six columns on screen
  and a different set in an exported file. Named here because it is a real inconsistency; see `WORK_LOG`.
- The other three list screens (Appointments, Encounters, Billing) keep fixed columns. Generalising this
  belongs with the shared list shell, not with a fourth copy of the picker.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-24 | Anant Sharma (AI-assisted) | Initial version |
