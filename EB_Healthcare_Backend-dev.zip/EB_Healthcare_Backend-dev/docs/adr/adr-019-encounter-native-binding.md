# ADR-019: Bind encounter vaccines, exam and vitals to native ERPNext Healthcare

**Doc status:** living · **Created:** 2026-06-30 by Invincible · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.0

- **Status:** Proposed
- **Date:** 2026-06-30
- **Supersedes:** the proposal in the frontend `docs/BACKEND_PENDING.md` to build a new `Patient Encounter Vaccination` child doctype (#3). Adopts #2's blob approach for the physical exam and refines #6 (vitals wiring).
- **Superseded by:** —

## The problem

The encounter screen let a clinician type things that were **silently lost on
Sign & close**. Verified live on the Marley bench.

| What they typed | What happened |
|---|---|
| Vaccines — chips, lot, site, date | written nowhere |
| Physical examination | no field to write to |
| Vitals | lost unless they also pressed a separate "Save vitals" button |

**USER STORY.** Nurse Ana records a BCG dose with its lot number → **the screen
shows** it in the vaccine section → she presses Sign & close → **the database
contains no Immunization row** → **consequence:** the Cartilla shows the child
never had BCG, and someone gives a second dose.

The cause was the same each time: the screen invented a structure that native
ERPNext Healthcare already provides, built the UI, and never built a home for
the data.

## The decision

Bind to **native** structures. Do not build parallels.

**1. Vaccines → native `Immunization` records.** Reuse the existing create path
in `api/v1/immunizations/api.py`. No new child doctype. This also fills the
Cartilla schedule for free.

```
UI field      →  Immunization field
site          →  administration_site
lot           →  lot_number
date          →  date_administered
practitioner  →  administered_by
```

**2. Physical exam → the `encounter_comment` JSON blob.** Native has nowhere
else to put it: the docfield named `physical_examination` is a **Column Break**,
a layout divider with no database column. So exam text joins the other SOAP
fields in the blob.

```
encounter_comment (JSON)
  chief_complaint · hpi · physical_examination · diagnosis · plan · education · notes
```

**3. Vitals → saved on Sign & close.** Keep native Vital Signs as the separate
linked document, which is correct. Remove the trap: signing saves the typed
vitals whether or not the extra button was pressed.

**Signing twice must not duplicate anything.** Guard on `{appointment + vaccine}`
for Immunizations, and on the existing draft name for Vital Signs.

## Why not the alternatives

| Option | Why it loses |
|---|---|
| A new `Patient Encounter Vaccination` child doctype | duplicates `Immunization`, and the Cartilla would not see it |
| Add a real `physical_examination` column to core | patches ERPNext core — Rule 1 forbids it, and it breaks on upgrade |
| Keep the separate "Save vitals" button | the data loss above is the button working as designed |

## What follows from it

- **Good:** nothing new to maintain, the Cartilla stays correct, and an
  uninstall leaves native data intact (Rule 2).
- **Cost:** the SOAP text is a JSON blob, so it cannot be queried by field. A
  report that needs, say, every Assessment has to parse the blob.
- **Trap this created:** three blob-only fields (`physical_examination`,
  `diagnosis`, `notes`) have no native column, so any code that assumes a column
  reads them as empty. That caused a live bug where a reload showed those boxes
  blank while the record held their text.

## Out of scope

Coded diagnosis via `codification_table`, ROS, follow-up auto-create, paediatric
vital ranges, growth percentiles, weight-based dosing, allergy interlock, and
the sign-time completeness soft-stop. Each is either larger or genuinely
net-new.

## References

- [`ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md) §6 — where the data lives today
- CLAUDE.md Rule 1 (upgrade-safe) and Rule 2 (uninstall-safe)
- ADR-018 — the same lesson: align with native, do not invent parallels

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Rewritten for length and readability: 142 → ~95 lines, a user story, a field-mapping example, and the blob-only-field trap this decision created. Decision unchanged; still Proposed |
| 1.0 | 2026-06-30 | Sarvesh-SocialAngel | Initial version |
