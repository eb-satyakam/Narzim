# ADR-083: Every extracted measurement carries its side, and the de-duplicator respects it

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted — 2026-09-22, after half of an eye-biometry report was silently deleted
- **Builds on:** [ADR-081](adr-081-report-subject-and-template-driven-summaries.md) (site + side on a narrative report). This extends the same idea to each individual measurement.

---

## 1. Context — half a study disappeared, with no error

An IOLMaster 700 biometry PDF was uploaded (`AI Prompt Log gb9n0qto51`). The model read it
correctly and returned **36 parameters — both eyes**. The review screen showed **18**.

```
AL    x2 ->  24.08 mm  /  24.20 mm
ACD   x2 ->  3.47 mm   /  3.51 mm
CCT   x2 ->  550 µm    /  542 µm
```

Every left-eye measurement was discarded by `_unmatched_dedupe_key`, which identifies a
report line as `(analyte name, section, unit)`. A paired-site report prints the same analyte,
in the same section, in the same unit, once per side — so the two eyes were indistinguishable
and the second was treated as a duplicate of the first.

Nothing errored. Nothing warned. The screen simply showed half a study, and it looked
complete. It also breaks ADR-022's "no extracted parameter is discarded", which
`services/lab_panel_extraction.py` asserts three times.

This is the **second** data loss from the same key. On 2026-08-26 it keyed on the name alone
and turned 57 extracted values into 53, dropping the absolute white-cell differential;
`section` and `unit` were added then. The discriminator this time was the eye, which was in
none of the three.

## 2. Decision

Every parameter carries `side`: `left` · `right` · `bilateral` · `not applicable` ·
`not stated`, and `side` joins the de-duplication key.

**The MODEL normalises; the code only validates.** An early version of this carried a
hardcoded synonym map in Python (`OD`/`OS`/`OU`, `derecho`/`izquierdo`, `R`/`L`). It was
removed, because a list like that is unfinishable and its gaps fail silently: it knew `OU`
(*oculus uterque*, both **eyes**) but not `AU` (*aures utraque*, both **ears**), and knew
neither `AD`/`AS` — the standard notation for right and left ear — nor dexter/sinister, nor
`B/L`, nor any language beyond the two it happened to list. A report using a missing notation
would have its side quietly dropped, and nobody would learn which notations were absent until
a specialty using one turned up.

The prompt now states the rule once — translate any notation, in any language, to the five
English values — and `_clean_side` does nothing but check the answer is one of them.
Unrecognised becomes `not stated`, never a guessed side. Verified after removing the map:
the same biometry still returned 20 `right` and 20 `left`, 40 of 40 values surfaced.

**Generic by construction.** The same field carries left-versus-right ear on an audiometry,
kidney on a renal study, breast, limb and lung. Nothing about it is ophthalmic.

The surfaced row carries `side` too, so a paired-site report can be shown grouped by side
rather than as two identical-looking rows.

## 3. A regression this change caused, and how it was found

Adding the ADR-082 image-observation rule to the same prompt moved this report from "panel"
to "narrative": a re-run returned `parameters: []` and transcribed the whole document
instead. The rule was written for documents that are purely a picture, and the model
over-applied it to a report that contains both tables and images.

Scoped in the prompt: a document printing named measurements is a panel **however many
images sit beside them**, and an image never moves a document to narrative. Re-verified
after the fix.

Recorded because it is the instructive part: a prompt rule added for one document shape
changed the classification of a different one, and only a re-run of a known-good file caught
it. There is still no automated test asserting that.

## 4. Result

```
extracted = 40   surfaced = 40   (lossless)
sides: right 20, left 20
AL  -> right '24.08 mm (*)'   left '24.20 mm (!)'
CCT -> right '550 µm'         left '542 µm SD 3 µm'
```

40 rather than the original 36: forcing a side per row made the model enumerate both columns
completely. The device's own quality markers came through as well — `(*)` manually edited,
`(!)` marginal measurement — which an external review had separately flagged as missing.

## 5. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Add `value` to the de-duplication key | The case the de-duplicator genuinely exists for is one line emitted twice, where the two copies can disagree on the number. Keying on the value lets both through and puts the same line in front of the physician twice |
| Key on the model's `source_file_index` | Not an address — ADR-052 §5 records it being wrong. Both eyes are on the same page anyway |
| Drop de-duplication entirely | Reinstates the duplicate-line problem it was built for |
| Have the template declare paired-site behaviour | Templates are AI-authored and optional; a type whose template omitted it would silently lose half a study again. Losing no extracted value is an invariant, not a per-type preference |


## 6. Follow-on: the parameter name stopped being a row identity

Keeping both sides made `parameter_name` non-unique on screen, and three separate things were
keyed on it. React reported the visible one — *"Encountered two children with the same key,
`Refr. dest.`"* — but the other two were worse and silent:

| Keyed on the bare name | What went wrong once both sides were present |
|---|---|
| The React `key` | Two rows collide; React may duplicate or drop one |
| The drag payload | Dragging one eye's value to another section moved BOTH |
| `onRemoveParam` | Removing one eye's value removed the other eye's too |

A row is now identified by `rowKey()` — the analyte name and its side, separated by NUL, which
cannot appear in a printed analyte name. The React key, the drag payload, removal,
`handledParams`, `excludedParams` and `sectionOverrides` all use it. The displayed label and
the remove tooltip still show the bare name, which is what a reader wants to see.

All of this is local component state; nothing keyed this way is sent to the server, so the
change is contained to the dialog.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Divyanshu (AI-assisted) | Row identity is now name + side; the bare name also governed dragging and removal, so both acted on the wrong eye |
| 1.1 | 2026-09-22 | Divyanshu (AI-assisted) | Side normalisation moved from a hardcoded Python synonym map into the prompt; the code now validates only |
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — per-parameter side, side in the de-duplication key, image rule scoped to documents with no printed values |
