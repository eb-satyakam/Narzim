# ADR-099: Dashboard revenue KPIs computed clinic-wide, not from today's appointments

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.4

- **Status:** Accepted
- **Date:** 2026-09-29
- **Supersedes:** —
- **Superseded by:** —

## Context

`get_dashboard_data`'s `revenue.collected_today_mxn`/`revenue.pending_mxn` are computed by walking
today's Patient Appointments and summing the `paid`/`outstanding` fields of whichever ones already
have a linked invoice (`api/v1/dashboard/api.py:879-912`). The frontend's Billing screen was just
restyled to match a Claude Design mock (`EB_Healthcare_Frontend/docs/architecture/
BILLING_NARZIM_RESTYLE.md`) whose own header KPIs — "Collected today" / "Uncollected" — represent a
different concept: today's actual collections and the clinic's total outstanding debt, neither
scoped to today's appointment schedule. Live on this site, every invoice is dated in the past
relative to today, so the existing figures correctly show 0.00 MXN — a real data gap, not a bug, but
one that also reveals the current computation never matched what either the mock or a plain reading
of the label ("Uncollected") actually means. Full reasoning and the safety check (nothing renders
these fields in production today) are in the design doc linked above.

## Decision

Compute `collected_today_mxn` and `pending_mxn` directly from Sales Invoice via `frappe.get_all`
aggregate queries (`sum(paid_amount)` filtered to `posting_date = target_date`; `sum(
outstanding_amount)` with no date filter, clinic-wide), instead of deriving them from the day's
appointment list. `pending_count` becomes a count of invoices instead of appointments, consistent
with the new basis.

1. Uses `frappe.get_all`, not raw `frappe.db.sql` — this keeps the query inside Frappe's normal
   permission-condition injection, so the same (implicit) company/User-Permission scoping the rest
   of `get_dashboard_data` already relies on continues to apply, with no new `company` parameter to
   add or thread through.
2. `appt_billing` and everything downstream of it (`_attach_billing`, `_attach_patient_pending`, the
   per-row `outstanding_mxn` on queue cards) are untouched — this ADR only changes the three
   top-level `revenue` numbers.
3. No new endpoint, no new parameter on `get_dashboard_data`'s signature.

### Correction — v1.2, 2026-09-29, before merge

Two errors in v1.0/1.1, both found from a user screenshot showing "Collected today 0.00 MXN" on a
day with a real 11,800 MXN payment:

1. **"Collected today" missed every non-POS payment.** It summed `Sales Invoice.paid_amount`, which
   ERPNext fills only for POS invoices. A non-POS invoice is settled by a separate Payment Entry and
   its own `paid_amount` stays 0 — `ACC-SINV-2026-01106` (posted today, paid today by
   `ACC-PAY-2026-00812`) counted as 0. Now: POS invoices posted on the date (`paid_amount`) **plus**
   allocations to Sales Invoices from Payment Entries (`payment_type = Receive`, submitted) posted on
   the date — the same definition of real cash as `services/billing.py::_real_cash_paid`.
2. **Point 1 of the Decision above was false.** `frappe.get_all` does *not* apply permission
   conditions — it forces `ignore_permissions=True` (`frappe/__init__.py::get_all`). The aggregates
   now use `frappe.get_list`, which does, matching `billing/api.py::list_all_invoices`. The
   Payment Entry Reference child query stays `get_all` but is keyed only by Payment Entries the
   caller could read.

### Change — v1.3, 2026-09-29, before merge

**`pending_mxn` / `pending_count` are now today only** (`posting_date = target_date`), reversing
v1.0's clinic-wide, no-date-filter choice. Explicit request after seeing the Billing header KPI row:
all three chips there ("Collected today", "Uncollected", "Refunds") are read as one "today" row, and
an all-time "Uncollected" beside two today figures read as inconsistent. v1.0's argument — don't hide
old debt — still holds, but old debt is not hidden: the Invoices tab's own summary line shows the
exact all-time outstanding (adr-102), and the Overdue / Unpaid pills list it. Live on
`remedisis.localhost`: `pending_mxn` 5,500.0 / `pending_count` 1 (today), versus 7,340.0 / 4
all-time; both match direct SQL. "Refunds" needed no backend change — it is computed on the frontend
from a `date_from = date_to = today` invoice query and was already today-only.

Not counted, by decision: an advance Payment Entry with no invoice allocation (money received
before any invoice exists). On this site `EB_Practitioner` has Sales Invoice and Payment Entry read
(a Custom DocPerm), so practitioners see the figures too — that is the site's permission config,
not this code.

## Alternatives Considered

1. **Leave it as-is (today's appointments only).**
   - Pros: zero change, zero risk.
   - Cons: doesn't answer the actual question the user asked — the figures would keep reading 0.00
     MXN whenever no appointment happens to be scheduled today with an already-linked invoice, even
     on a clinic with real revenue posted yesterday or an hour ago against an older visit. Doesn't
     match the mock's own definition of either label.

2. **Widen the date window (e.g., "this week"/"this month") but keep the appointment-walk approach.**
   - Pros: smaller code change than switching data source entirely.
   - Cons: still conflates "when the appointment was" with "when the money moved" — a late-billed
     visit or a payment collected today against an old invoice still would not count. Picking an
     arbitrary window (a week? a month?) is also just a different wrong scope, not a fix of the
     actual mismatch.

3. **Direct Sales Invoice aggregate via raw `frappe.db.sql` (chosen data source, wrong access path).**
   - Pros: matches the existing `_batch_outstanding_balance` style exactly, explicit control over the
     query.
   - Cons: raw SQL bypasses Frappe's permission engine entirely — `_batch_outstanding_balance`'s own
     docstring exists to warn about exactly this ("a card must not report the other clinic's debt"),
     and doing so here would mean either resolving and threading an explicit `company` filter through
     a function that currently has no such parameter, or genuinely leaking cross-company financial
     totals on a multi-company platform. Rejected specifically because it reintroduces the risk the
     existing helper was written to avoid.

4. **Direct Sales Invoice aggregate via `frappe.get_all` (chosen).**
   - Pros: matches the actual target concept (today's collections; all outstanding debt,
     clinic-wide); reuses Frappe's own permission-condition injection for company scoping, so no new
     parameter or explicit resolution is needed; cheaper than the current per-appointment walk (two
     aggregate queries vs. iterating every appointment); nothing in production currently depends on
     the old numbers (verified by grep), so this cannot regress a working screen.
   - Cons: correctness now depends on this site's User Permission configuration for Company being set
     up correctly for Sales Invoice — the same assumption the rest of this function already silently
     makes for Patient Appointment, so not a new dependency, but worth naming.

## Consequences

- `remedisys_healthcare_ai/api/v1/dashboard/api.py::get_dashboard_data` changes: the `revenue` block
  computation only.
- `pending_count`'s meaning changes (appointments → invoices) — safe because nothing consumes it
  today (verified).
- Re-evaluation trigger: if a screen is later built that genuinely needs "outstanding balance among
  today's scheduled patients" (the old semantic) as a distinct figure from clinic-wide debt, that is
  a new, separate field — not a reason to revert this one.

## Verification

- Live end-to-end via `bench console` against `remedisis.localhost`: `get_dashboard_data()` now
  returns `{"pending_mxn": 1940.0, "collected_today_mxn": 0.0, "pending_count": 4}` — real, non-zero
  clinic-wide outstanding, and an honest zero for today's collections (no invoice posted today on
  this site). Rest of the response (`queue_summary`, `checkout`, etc.) confirmed unchanged.
- Code review: confirm `frappe.get_all` (not `frappe.db.sql`) is used for both new queries, with the
  dict-form aggregate syntax Frappe v16 requires (see the design doc's Verification section for the
  string-vs-dict gotcha this surfaced).
- `EB_Healthcare_Frontend`'s Billing screen KPI chips (already wired to this endpoint) will show
  these live figures the next time that page loads.

- v1.2, live on `remedisis.localhost` (2026-09-29): `collected_today_mxn` **11,800.0** (was 0.0),
  `pending_mxn` 1,940.0, `pending_count` 4, identical for Administrator, a Front Desk user and a
  Practitioner user (all three hold Sales Invoice read on this site). Multi-company scoping is
  **UNVERIFIED** in practice — this site has one company (`Narzim`); the mechanism is `get_list`.

## References

- `docs/architecture/DASHBOARD_REVENUE_KPI_SCOPE.md` (this repo)
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md` (frontend repo, round 2 and
  the KPI zero-data investigation)
- `services/billing.py::_batch_outstanding_balance` — the existing company-scoping precedent and
  cautionary docstring this ADR follows

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.3 | 2026-09-29 | Divyanshu (AI-assisted) | Before merge: "Uncollected" (`pending_mxn`/`pending_count`) scoped to today on request; all-time figure remains on the Invoices tab |
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Before merge: "collected today" now includes Payment Entry receipts (non-POS payments were counted as 0); corrected the false claim that `get_all` applies permissions — aggregates moved to `get_list` |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Recorded live end-to-end verification results |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
