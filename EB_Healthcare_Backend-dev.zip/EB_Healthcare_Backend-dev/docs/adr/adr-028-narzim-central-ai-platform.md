# ADR-028: Narzim — a separate, centrally-owned platform; Marley Health becomes a thin AI client

**Doc status:** living · **Created:** 2026-07-13 by Sarvesh-SocialAngel · **Updated:** 2026-07-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-13
- **Supersedes:** ADR-027's local enforcement model (retired, not discarded — see Migration)
- **Superseded by:** —

## Context

Marley Health (this repo, `remedisys_healthcare_ai`) runs as **one Frappe site per hospital**
— each hospital owns its own isolated database, may contain multiple clinics
(`Company` records), and hospitals never share operational data with each other.
This is a deliberate, confirmed choice: hospital data isolation, independent
upgrade/uptime, and jurisdictional compliance (LFPDPPP/DPDPA, per ADR-018) all
favor hospitals never touching each other's data.

Today's session built a working AI Copilot usage-metering system entirely inside
this model: `AI Subscription Plan`, `Seats`, `Covered Companies`, `AI Usage
Counter`, and `services/ai_billing.py`, enforced per-request in
`api/v1/ai/api.py` (ADR-026, ADR-027). It works, and was verified end-to-end
against a real test plan. But it was built assuming *this one hospital's site*
is the whole world — each hospital would need its own separately-managed
subscription plan, and every hospital's OpenAI/Anthropic/Deepgram API keys would
have to live in that hospital's own `site_config.json`.

That doesn't hold up at the scale the product actually targets — "thousands of
hospitals" (per the Narzim platform brief this ADR formalizes). At that scale:

- Provider credentials duplicated across every hospital site is a large,
  growing attack surface with no central rotation or audit point.
- There is no single place to see usage/billing across hospitals (today's
  usage-overview report only works because everything sits in one shared
  database — it stops working the moment hospitals are truly isolated sites).
- Every hospital onboarding requires manually creating a subscription record
  inside that specific hospital's own site — doesn't scale past a handful of
  hospitals.
- Model/prompt governance (which models are approved, which prompt version is
  live) would need to be kept in sync across every hospital site individually.

CLAUDE.md's Rule 3 (Service Separation) anticipated something like this and was
suspended by ADR-005 pending "re-evaluation at Phase 1 architecture review."
This ADR is that re-evaluation, with a different shape than originally
sketched (Frappe, not FastAPI — see Alternatives).

## Decision

**1. Why Narzim exists.** Narzim is a centrally-owned platform for
ecosystem-wide concerns that no single hospital should own: AI provider
relationships and credentials, cross-hospital subscription/billing/analytics,
and (later) other genuinely cross-hospital services. It exists because these
concerns cannot be correctly solved inside a one-site-per-hospital model —
they are definitionally things that sit *above* any one hospital.

**2. Why Marley Health and Narzim are separate systems.** Marley Health's job
is hospital operations — patients, encounters, billing, inventory, appointments
— scoped to exactly one hospital, intentionally isolated. Narzim's job is
everything that is *not* hospital-specific: provider credentials, ecosystem
subscriptions, usage/billing/analytics *about* AI usage (not clinical data
itself), and future shared services. Keeping them as separate repos and
separate deployments preserves hospital data isolation (a hospital's clinical
data never needs to leave its own site except the minimal context a specific
AI call needs — Rule 5 still applies in full), lets Narzim be deployed/scaled/
updated on its own schedule independent of any one hospital, and keeps
ownership, billing, and liability lines clean — Narzim is a Narzim product,
not a feature of any one hospital's system.

**3. Why one hospital equals one Frappe site.** Confirmed as the production
multi-tenancy model for Marley Health (distinct from ADR-014's narrower
question about demo-sandbox provisioning, which this ADR does not reverse).
Each hospital's site is fully isolated — its own database, its own uptime, its
own upgrade schedule, no cross-hospital data access at the Marley Health layer
under any circumstance.

**4. Why all AI credentials remain only inside Narzim.** OpenAI, Anthropic,
Deepgram (and future providers) API keys live exclusively in Narzim's own
secrets storage. No hospital site's `site_config.json` holds a provider key,
ever. This gives one rotation point, one audit trail per key, and the ability
to add/remove/swap providers globally without touching a single hospital site.

**5. Why hospital sites become AI clients.** Marley Health's
`integrations/openai.py`, `integrations/anthropic.py`, `integrations/deepgram.py`,
and `services/llm.py` are replaced by one thin client module that authenticates
to Narzim and calls its gateway instead of any provider directly. The hospital
site's job shrinks to: send the request (transcript/context, already minimized
per Rule 5), receive the result, render it. Every decision about "is this
allowed, is there budget, which model, which prompt version" moves to Narzim.

**6. Migration from today's local implementation.** Not discarded — it is the
validated reference design for Narzim's own subscription/seat/usage schema.
Concretely:
- Narzim gets its own equivalent doctypes (a Hospital-scoped plan record,
  Seats, Usage Counter) — near-identical in shape to `AI Subscription Plan` /
  `AI Subscription Plan Seat` / `AI Usage Counter`, but living once, centrally,
  covering every hospital, instead of duplicated per hospital site.
- Sequencing: Narzim is built and proven first (in its own repo, against at
  least one real hospital) → Marley Health's `generate_suggestions` /
  `ask_copilot` are rewired to call Narzim's gateway instead of
  `get_llm_client()` → **only then** are `AI Subscription Plan`, its child
  doctypes, `AI Usage Counter`, and `services/ai_billing.py` removed from this
  repo. Today's code is not deleted as part of this ADR — it stays live and
  enforcing until Narzim is ready to take over, so AI access is never
  interrupted mid-migration.

**7. Security model.** Each hospital is issued one long-lived credential pair
(Hospital ID + API Token) by Narzim at onboarding, stored in that hospital's
`site_config.json` (never in code — same convention this repo already uses for
`openai_api_key` etc.). Every request from a hospital site to Narzim carries:
Hospital ID, Bearer API Token, a timestamp, and an HMAC signature over the
request body (shared secret issued alongside the token) — timestamp + nonce
reject replayed requests outside a short window (e.g. 5 minutes). Rule 5 (no
full-history dumping) and Rule 10 (no PHI in logs) apply identically at the
Narzim boundary — Narzim receives only the same minimized context Marley
Health was already sending straight to providers (age, meds, allergies, chief
complaint, transcript text), never raw DB access into any hospital's records.

**8. Deployment architecture.** Narzim: its own Frappe site, its own repo, its
own deployment — no shared infrastructure with any hospital's Marley Health
site. Hospital sites reach it over authenticated HTTPS REST, the same
whitelisted-method pattern this repo already uses internally, just crossing a
site boundary now. Narzim becomes a single point of failure for the *AI
feature* across every hospital — never for core clinical work (Rule 7 is
enforced identically: a hospital's Patient Encounter form and manual
documentation are completely unaffected by Narzim being unreachable, exactly
as today's `onError` / "AI unavailable" degradation already works). This
concentration of risk is accepted for now; Narzim's own uptime practices are
an operational concern to design when Narzim itself is built, not a blocker to
this ADR.

**9. Future roadmap.** Narzim's architecture — a central platform, hospital
sites as thin clients for anything cross-hospital — is chosen specifically
because it accommodates, without redesign, later modules already anticipated:
Global Patient Identity, Global Patient Timeline, Consent Management, Record
Sharing, Marketplace, Payment Integration, SSO, Notifications. **None of these
are built now.** They are listed here only to confirm the chosen shape doesn't
need to be reworked when they arrive — each is, structurally, another
"ecosystem-wide concern Narzim owns, hospitals consume," the same split this
ADR establishes for AI.

## Alternatives Considered

1. **Keep AI logic inside each hospital's own Marley Health site (today's
   implementation, unchanged).**
   - Pros: already built and verified; no new repo/deployment.
   - Cons: provider credentials duplicated per hospital (unmanageable at
     "thousands of hospitals" scale); no cross-hospital visibility without a
     separate aggregation layer (the exact problem that started this
     conversation); doesn't match the stated long-term goal. **Rejected as
     the long-term architecture** — but it served its purpose: proving the
     seat/subscription/credit model actually works before committing to build
     it centrally.

2. **Narzim as a separate FastAPI service** (the original shape Rule 3 /
   ADR-005 anticipated).
   - Pros: purpose-built for a gateway/high-throughput role; total separation
     from Frappe.
   - Cons: Narzim is fundamentally a *business platform* — hospitals,
     subscriptions, billing, permissions, workflows, admin screens — exactly
     Frappe's strength. Building all of that in FastAPI means reimplementing
     doctypes, permissions, an admin UI, and a workflow engine from scratch.
     **Rejected for the platform as a whole**; extracting only the AI
     *execution* layer into FastAPI later remains available if AI traffic
     volume ever demands it, with Narzim staying the system of record for
     everything else.

3. **Narzim as a separate Frappe app/site, business-platform-first, with a
   future option to extract a FastAPI execution layer if traffic demands it
   (chosen).**
   - Pros: reuses Frappe's doctype/permission/workflow/admin machinery for
     exactly the parts of Narzim that are business-platform shaped (Hospital
     Registry, Subscription Management, Billing, Analytics, Prompt
     Management); keeps the team working in a stack they already know; the
     AI Gateway is "just" one more module inside it, not the whole platform.
   - Cons: a Frappe-native gateway may need more deliberate performance work
     later than a purpose-built FastAPI service would need out of the box —
     accepted as a later, narrower problem (extract just that piece) rather
     than a reason to rebuild the whole platform in a different stack now.

## Consequences

- **A new repository is required** for Narzim (name/slug TBD at creation
  time) — separate from `remedisys_healthcare_ai`, deployed independently.
- **This repo's AI integration surface will be rewritten**, but not yet:
  `integrations/openai.py`, `integrations/anthropic.py`,
  `integrations/deepgram.py`, `services/llm.py` are replaced by a thin Narzim
  client once Narzim exists and is proven.
- **Today's local metering doctypes stay in place until Narzim is ready**:
  `AI Subscription Plan` (+ its Seats/Covered Companies child tables) and
  `AI Usage Counter`, plus `services/ai_billing.py` and the guard functions in
  `api/v1/ai/api.py`, are not removed by this ADR — only scheduled for removal
  once migration (point 6) completes.
- **ADR-026 and ADR-027 are carried forward, not discarded.** Their content —
  the approved-provider-allowlist reasoning and the credit/seat/token model —
  becomes the reference design for Narzim's own subscription and provider
  management modules. Once Narzim is live, both ADRs should be marked
  superseded by whatever ADR documents Narzim's internal provider/subscription
  schema, in Narzim's own `docs/adr/`.
- **CLAUDE.md will need a follow-up amendment** once Narzim ships: ADR-005's
  Rule 3 suspension should be updated to reflect that the "separate service"
  question has been resolved (as Narzim, a Frappe platform, not the originally
  sketched FastAPI sidecar) — tracked here as a known follow-up, not yet done.
- **Re-evaluation trigger:** if AI traffic volume ever makes a Frappe-native
  gateway a real performance bottleneck, extract only the AI execution layer
  into a dedicated FastAPI service, per Alternative 3 — Narzim remains the
  system of record for hospitals, subscriptions, and billing regardless.

## Verification

- Narzim exists as its own repository, deployed separately from any Marley
  Health hospital site.
- A test hospital site can authenticate to Narzim (Hospital ID + API Token +
  HMAC-signed request) and receive a real AI response without that hospital's
  site ever holding a provider API key.
- That hospital's `site_config.json` contains no `openai_api_key` /
  `anthropic_api_key` / `deepgram_api_key` once migrated.
- Narzim enforces seat, credit, and token-ceiling rules equivalent to what was
  verified in today's prototype (no-seat refusal, seat-cap validation,
  daily/monthly budget refusal) — before this repo's local enforcement is
  removed.
- Rule 7 holds across the migration: killing Narzim's connectivity from a test
  hospital site does not affect that hospital's Patient Encounter save/submit.

## References

- ADR-005: Frappe Cloud deployment, Rule 3 (service separation) suspended —
  this ADR is the re-evaluation that ADR-005 deferred to Phase 1
- ADR-014: Onboarding/demo provisioning — related but narrower question
  (demo sandboxes), not reversed by this ADR's production one-site-per-hospital
  stance
- ADR-018: Multi-jurisdiction `ComplianceProfile` — hospital data isolation
  rationale this ADR's separation of concerns is consistent with
- ADR-026: LLM provider allowlist — carried forward into Narzim's provider
  management module
- ADR-027: Credit-based subscription metering — carried forward into Narzim's
  subscription management module; today's local implementation is this ADR's
  validated prototype, not discarded
- CLAUDE.md Rule 3, Rule 5, Rule 7, Rule 10 — all remain in force, enforced at
  the Narzim boundary identically to how they're enforced today

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-13 | Sarvesh | Initial version (header backfilled from git history) |
