# ADR-020: Doctor → nurse vaccine administration handoff

**Doc status:** record · **Created:** 2026-07-03 by Sarvesh-SocialAngel · **Updated:** 2026-07-03 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-03
- **Builds on:** ADR-019 (encounter vaccines → native `Immunization`), which introduced
  the encounter-native binding this reuses.
- **Superseded by:** —

## Context

ADR-019 made encounter vaccine chips create native `Immunization` records on Sign &
close — i.e. the doctor's vaccine tag is recorded as **administered in the room**. Real
pediatric clinics separate the two roles: the **doctor orders** a vaccine, a **nurse
administers** it (often minutes later, sometimes at a follow-up). The "Add immunization"
dialog already gates on allergies and febrile temperature and requires an *assigned*
vaccine ("No assigned vaccines are due. Use 'Assign vaccine' first."), and
`IMMUNIZATION_PROCESS.md` Flow G describes a nurse worklist — but nothing routed an order
to a specific nurse, and the worklist-driven administration was "planned, not built".

Existing building blocks (no rebuild needed):

- `Patient Vaccine` — the assignment/order record (`patient`, `immunization_template`,
  `status`, `assigned_by`, `appointment`, `encounter`).
- `Immunization` — the administration record. Had `appointment` but **no encounter link**.
- `Nursing Task` (Healthcare core) — submittable, assigned via `user`, with native
  `task_doctype` / `task_document_name` reference fields; already aggregated per-assignee
  by `get_my_tasks()` (tasks/api.py) into the "My Work" feed.
- Roles `EB_Nurse` / `EB_Practitioner` already distinct; nurse can create Immunization and
  cannot sign encounters (`_require_assigned_practitioner_or_admin`).

## Decision

Add a **per-vaccine `mode`** to the encounter vaccine payload and route accordingly, reusing
native structures (no new doctype, no Custom Field — consistent with ADR-019):

1. **`give_now` (default)** — unchanged ADR-019 behaviour: create the `Immunization` at Sign
   & close, `administered_by` = practitioner.
2. **`assign_nurse` (with a `nurse` User)** — create only the `Patient Vaccine` **order**
   (stamped with the ordering `encounter`, `assigned_by`, `appointment`) plus a **submitted
   `Nursing Task`** assigned to that nurse. The task references the order via
   `task_doctype = "Patient Vaccine"` / `task_document_name`, so `get_my_tasks()` surfaces it
   on the nurse's worklist with no feed change. **No `Immunization` is created yet.**
3. **Nurse records the dose** from the worklist via the existing `create_immunization`
   endpoint, now accepting `nursing_task`. Recording: inherits the ordering `encounter` from
   the linked `Patient Vaccine`, creates the `Immunization`, and marks the task **Completed**
   in the same transaction — the task's proof document is already the linked order, satisfying
   core's completion guard.
4. **Add `encounter` (Link → Patient Encounter) to `Immunization`.** Because the dose may now
   be recorded outside the ordering visit, the administration record stamps its source
   encounter for traceability (mirrors `Patient Vaccine.encounter`).

`Immunization` is an app-owned doctype, so the new `encounter` field is a plain JSON field
picked up by model-sync on migrate (no Custom Field / no data backfill). The
`Administer Vaccine` Healthcare Activity that backs the task is seeded by an idempotent patch
(`ensure_administer_vaccine_activity`) and defensively by `nursing.api._ensure_vaccine_activity`.

Idempotency: give-now stays guarded on `{appointment, template}` (ADR-019); assign-nurse is
guarded on "one open (submitted, non-closed) Nursing Task per `Patient Vaccine` order", so
re-signing does not re-assign.

## Alternatives Considered

1. **Custom Field on `Nursing Task` → `Patient Vaccine`.** Rejected: the native
   `task_doctype`/`task_document_name` reference already models "this task is about that
   document" and is already surfaced by the worklist feed. A Custom Field would duplicate it
   and add core-doctype schema (against the ADR-019/ADR-018 "reuse native" principle).
2. **New `Vaccine Order` doctype.** Rejected for the same reason ADR-019 rejected a
   `Patient Encounter Vaccination` child: `Patient Vaccine` already is the order, and it feeds
   the Cartilla schedule.
3. **Keep auto-recording as given; add nurse assignment as a separate manual step.** Rejected
   as the default because a doctor who wants a nurse to give the shot should not also have it
   recorded as already administered — that is exactly the double-record we are avoiding. The
   per-vaccine `mode` lets both paths coexist without a global behaviour change.
4. **ERPNext `Service Request` for ordering.** Deferred (see IMMUNIZATION_PROCESS §5): heavier
   FHIR-style order object; `Patient Vaccine` is the lean order we already use.

## Consequences

- **`Immunization` doctype** — new nullable `encounter` link; `_WRITABLE` + `_validate_refs`
  updated; `create_immunization` / `create_immunization_record` accept `encounter` and
  `nursing_task`.
- **`api/v1/immunizations/api.py`** — new reusable `ensure_patient_vaccine()` (stamps ordering
  context; `_ensure_assignment` now delegates to it); `_encounter_from_nursing_task()` +
  `_complete_vaccine_task()` for the record-and-close path.
- **`api/v1/nursing/api.py`** — `create_vaccine_administration_task()` (create + submit,
  ignore_permissions since the ordering doctor need not hold Nursing Task create) and
  `_ensure_vaccine_activity()`.
- **`api/v1/encounters/api.py`** — `_create_encounter_immunizations` branches on `mode`.
- **Worklist** — no `get_my_tasks` change; vaccine tasks appear with
  `reference_doctype = "Patient Vaccine"`.
- **Frontend (next increment, separate repo)** — encounter Vaccinations chip gains a
  give-now / assign-nurse toggle + nurse picker (users with `EB_Nurse`); the worklist "open
  task" launches the Add-immunization dialog pre-filled and passes `nursing_task` on record.
  All strings via the message catalogs (es-MX / en-US).
- **Deferred (Phase 2):** nurse **Deferred** status (febrile) with reason + re-due; standalone
  walk-in / catch-up assignment outside an encounter.

## Verification

- Tests (pytest): signing an encounter with a `mode=assign_nurse` vaccine creates a
  `Patient Vaccine` (encounter stamped) + a submitted `Nursing Task` for the nurse and **no**
  `Immunization`; re-signing does not duplicate the task; recording via `create_immunization`
  with `nursing_task` creates the `Immunization` (encounter inherited from the order) and marks
  the task Completed; `mode=give_now` (and omitted mode) still records the dose as before with
  `encounter` stamped.
- Runtime: drive the encounter UI — assign a vaccine to a nurse, Sign & close, confirm the task
  appears on that nurse's worklist, record the dose, confirm the Immunization + closed task and
  that the dose shows on the Cartilla.

## References

- Constitution §4 Rule 1 (upgrade-safe), §9 (ADR requirement)
- ADR-019 (encounter-native binding) · ADR-018 (align with native, don't reinvent)
- `docs/flows/IMMUNIZATION_PROCESS.md` (Flow G, §5 role→doctype map, §7 principles)
- Native doctypes: Nursing Task (`task_doctype`/`task_document_name`, submittable),
  Patient Vaccine (`encounter`), Immunization, Healthcare Activity
- `prompts/2026-07-03-vaccine-nurse-handoff.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-03 | Sarvesh | Initial version (header backfilled from git history) |
