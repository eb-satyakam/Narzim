# ADR-058: Read a photographed registration form with the existing vision pipeline, as a proposal only

**Doc status:** living · **Created:** 2026-09-03 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-03 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-09-03
- **Supersedes:** —
- **Superseded by:** —

## Context

The QR self-registration requirement
(`docs/scanner/REQUIREMENT.md`) offers two ways to register: type
the form, or photograph a paper one and have the system read it. Clinics
already have paper intake forms, and in a pediatric clinic the person filling
one in is a parent holding a sick child, so the photo path is the accelerator
that makes self-service worth using.

**The machinery already exists, aimed at a different document.** The lab-report
pipeline is the same shape — image in, named fields out, human confirms:

- `services/ocr_text_extraction.py` — `is_readable_image()` (a cheap Pillow
  decode, which exists because corrupt bytes make a provider throw an
  unhandled error rather than reject cleanly), `extract_image_text()`,
  `extract_scanned_pdf_text()`; bilingual `eng+spa`; returns `""` rather than
  raising when tesseract is absent.
- `services/lab_extraction.py` — `normalize_report_part()` fixes the sideways
  photos phone cameras produce constantly, which degrade both vision and OCR;
  `run_extraction()` logs to `AI Prompt Log` with a cost estimate, and its own
  docstring records the rule this ADR must inherit: *"Never writes to the Draft
  Lab Test (Rule 6)."*
- `integrations/openai.py` — `_content_part()` base64-encodes to a `data:` URL;
  `_call_openai()` uses `response_format` `json_schema` with `strict`, so the
  reply **is** valid JSON in a declared shape rather than prose to be parsed.
- `integrations/llm.py` — `load_prompt(version, prefix=...)` reads
  `llm/prompts/<prefix>_v<N>.txt` and returns its SHA-256, because §9 forbids
  inline prompts.

Two facts about the live site constrain this decision, both verified
2026-09-03 on `remedisys.localhost`:

1. `AI Settings.llm_provider = "OpenAI"`, `openai_model = "gpt-4o"`, and
   `enable_lab_extraction = 1`. Vision extraction is on and running against
   OpenAI today.
2. **The subprocessor register disagrees.** `compliance/profiles/mx.py:24-25`
   declares `llm_provider="anthropic"` / `audio_provider="groq"`, and
   `remedisys_compliance_profile` is not set in `site_config.json`, so the
   `mx` default applies. This is the precise discrepancy `CLAUDE.md` §9.9
   PHI-1 was written about: *"a subprocessor register that is wrong is worse
   than none, because it will be relied on."*

Fact 2 matters here more than for labs. A lab report is uploaded by staff for
an existing patient inside an authenticated clinical workflow. A registration
form is photographed by a member of the public, before any patient record
exists, from a screen reached by scanning a poster — the weakest consent
context in the product.

Governing: `CLAUDE.md` §4 Rule 6 (physician/human in control), Rule 7 (an AI
failure must not break the clinical path), Rule 10 (no PHI in logs), §9.9
PHI-1, PHI-3, PHI-5, PHI-6; `adr-026-llm-provider-allowlist.md` (approved
allowlist, and the data-terms check a new provider requires);
`adr-052-one-call-per-upload-with-bounded-recovery.md` (one call per upload).

## Decision

**Read the photographed form with the existing vision pipeline — one
schema-locked call per upload, versioned prompt, logged as tokens and cost
only — and return the result as an editable proposal that never creates a
`Patient`. Ship it only after the subprocessor register is corrected and
explicit consent is captured.**

1. **One call per upload**, following
   `adr-052-one-call-per-upload-with-bounded-recovery`, with an explicit
   timeout read from `AI Settings` — never hardcoded at the call site.
2. **Schema-locked output.** A `REGISTRATION_FORM_SCHEMA` passed to
   `_call_openai(schema=...)`, returning per field a `{value, confidence}`
   pair plus an `unreadable` list. There is no text-parsing step: the image and
   a schema go in, named fields come out.
3. **A new prompt file**, `llm/prompts/registration_form_v1.txt`, loaded via
   `load_prompt(prefix="registration_form")` with its hash recorded. Its
   governing instruction, adapted from `lab_extraction_v10.txt`'s
   transcribe-don't-infer discipline: **never complete a partially legible name
   or identifier from plausibility.** A model that "helpfully" corrects a
   half-readable CURP into a well-formed one has invented a national
   identifier. Return the characters visible; mark the rest unreadable.
4. **Proposal only — no `Patient`, no `User`, no row.** The extractor returns
   draft values to the caller, mirroring how `run_extraction` stores
   `filled_rows` on the log as "a proposal, not an application". Submission
   goes through `register()` unchanged, with values the person confirmed.
5. **The Confirm step is unconditional.** Not "review only the low-confidence
   fields" — every field, every time. Confidence is a model's self-report, not
   a calibrated probability; it is used to *order the reader's attention* by
   rendering low-confidence fields visibly louder, and never to skip review.
6. **`is_readable_image()` gates the bytes before any provider call**, and
   `normalize_report_part()` fixes rotation before encoding. Unreadable input
   returns "we couldn't read that — type it instead", never a stack trace.
7. **Local OCR is the degradation path, not the primary engine.** If the
   provider is unreachable, the flow falls back to the manual form with
   anything recoverable pre-filled, and registration completes. An extraction
   failure must never dead-end the journey (Rule 7 in spirit).
8. **The uploaded image is not retained.** It is read, extracted from, and
   discarded. Not retaining is cheaper than retaining, is the easiest true
   statement to put in front of a patient (PHI-5), and avoids inventing a
   retention period with no purge job behind it (PHI-3).
9. **Logs carry tokens, cost, latency, model, prompt version and hash. Never
   field values, never the image** (Rule 10). `AI Prompt Log` rows for this
   purpose carry no `patient` link, because at extraction time no patient
   exists.
10. **Two shipping preconditions, both blocking.** (a) The active
    `ComplianceProfile` is corrected to name the provider that actually
    receives the data, in the same commit as any code that sends it (PHI-1).
    (b) Explicit consent is captured before capture, naming what is read and
    by whom — not a checkbox defaulted on, and never satisfied on the
    patient's behalf (PHI-2's lesson: a hardcoded `true` produced 13,631
    stored PHI turns with no human ever asked).
11. **Behind a feature flag on `AI Settings`, default OFF**, like
    `enable_lab_extraction`.

## Alternatives Considered

1. **Local OCR only** — `extract_image_text()` plus field-position rules.
   - Pros: no PHI leaves the server, so PHI-1 and the consent question largely
     evaporate; no per-call cost; already installed and exercised; no
     subprocessor to register.
   - Cons: raw OCR returns a wall of text, not fields — mapping it needs a
     fixed form layout, and it is weak on handwriting, which is most of what a
     parent writes. It would fail on its primary input. Retained as the
     degradation path (clause 7), where returning partial text beats returning
     nothing.

2. **Vision LLM, schema-locked, via the existing pipeline (chosen).**
   - Pros: reuses a proven path end to end — rotation normalisation, prompt
     versioning and hashing, `AI Prompt Log` accounting, strict JSON schema —
     so almost nothing new is invented. Handles handwriting and arbitrary
     layouts. Returns typed fields, so there is no fragile parsing step.
     Provider already on the `adr-026` allowlist.
   - Cons: sends PHI to a subprocessor from the weakest consent context in the
     product, making clause 10 mandatory rather than nice-to-have. Per-call
     cost on a guest-reachable endpoint, so rate limiting is load-bearing.
     Self-reported confidence means clause 5 is doing real safety work.

3. **OCR first, vision LLM only on failure.**
   - Pros: cheapest common case; the model is spent only when OCR is
     inadequate.
   - Cons: the "cheap common case" is precisely where OCR fails here —
     handwriting — so the saving rarely materialises, while two engines mean
     two failure modes and two incompatible confidence notions to reconcile in
     one Confirm screen. Complexity without the payoff. (Distinct from
     `adr-052`, where OCR verifies *coverage* of text we already hold rather
     than extracting fields.)

4. **A third-party document-AI / ID-reading service.**
   - Pros: purpose-built for identity documents and forms; often better on
     printed IDs than a general vision model.
   - Cons: a **new subprocessor**, which under `adr-026` requires a
     data-processing-terms check against the active `ComplianceProfile` plus a
     shared-interface implementation before it joins the allowlist — process
     cost paid for one screen, when alternative 2 reaches usable accuracy with
     a provider already approved.

## Consequences

- **Code to write:** `services/registration_form_extraction.py` (mirroring
  `services/lab_extraction.py`); `REGISTRATION_FORM_SCHEMA` and an
  `extract_registration_form()` in both provider adapters plus the `llm.py`
  dispatcher, so the allowlist stays honoured;
  `llm/prompts/registration_form_v1.txt`; a rate-limited guest endpoint in
  `api/v1/patient_portal/api.py`; a feature flag on `AI Settings`.
- **`compliance/profiles/mx.py` must be corrected** before this ships. It
  currently names `anthropic` while the site runs OpenAI. This ADR does not fix
  that discrepancy — it declares it blocking, because sending a *new* category
  of PHI through a register known to be wrong compounds the existing PHI-1
  defect instead of inheriting it.
- **A consent surface is required on the patient-facing screen**, and its
  wording must match enforced behaviour (PHI-5): "the photo is read and not
  stored" is true under clause 8 and must stay true.
- **Cost exposure moves to an unauthenticated endpoint.** Rate limiting is not
  an optimisation here; without it a public URL bills a provider per scan.
- **`_name_tokens()`** (see `adr-057-patient-duplicate-match-blind-claim-and-verify`)
  becomes reusable for a further safety check — comparing the name printed on a
  photographed form against a matched patient record, the way
  `report_patient_name_mismatch` already does for lab reports. Out of scope
  here; noted so it is not rebuilt.
- **Re-evaluation triggers:** (a) measured field-level accuracy poor enough
  that patients routinely correct several fields, which would make typing
  faster than photographing and remove the reason for the feature; (b) a
  provider price or terms change; (c) a purpose-built document-AI service
  joining the allowlist for another reason, which would reopen alternative 4
  at no incremental process cost.

## Verification

- Integration test: a photographed form produces draft fields and **no
  `Patient` row exists afterwards** — the clause 4 guarantee, asserted rather
  than assumed.
- Integration test: provider unreachable → the manual form is returned and
  registration still completes (clause 7, Rule 7).
- Integration test: garbage bytes → clean rejection, no 500 (clause 6).
- Test: a low-confidence field is marked as such in the response, and the
  frontend renders it distinctly (clause 5).
- `AI Prompt Log` row inspection: tokens, cost, latency, prompt version and
  hash present; **no field values, no image, no patient name** (clause 9).
- `grep` of a full photo-path run's logs shows no PHI.
- The feature flag defaults OFF on a fresh site.
- `compliance/profiles/mx.py` names the provider that `AI Settings.llm_provider`
  actually selects — the PHI-1 precondition, checkable in one diff.

## References

- `CLAUDE.md` §4 Rule 6, Rule 7, Rule 10; §9 (prompts are never inline); §9.9 PHI-1, PHI-2, PHI-3, PHI-5, PHI-6
- `docs/scanner/REQUIREMENT.md` §5.2, §5.6, §9, §9.1 (the mechanism, step by step)
- `adr-026-llm-provider-allowlist.md` — the approved allowlist and the data-terms check
- `adr-052-one-call-per-upload-with-bounded-recovery.md` — one call per upload; OCR used for verification, never sent to the model
- `docs/AI_LAB_REPORT_EXTRACTION.md` — the pipeline this reuses
- `remedisys_healthcare_ai/services/lab_extraction.py` — `run_extraction`'s "never writes" rule

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Anant Sharma (AI-assisted) | Initial version. Proposed, not accepted — clause 10's two preconditions (correcting the `mx` subprocessor register, and the consent surface) need the repo owner's decision before any code |
