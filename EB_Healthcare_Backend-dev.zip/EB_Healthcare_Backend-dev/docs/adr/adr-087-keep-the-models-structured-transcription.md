# ADR-087: Keep the model's structured transcription; substitute the raw text layer only when it failed

**Doc status:** living · **Created:** 2026-09-23 by Divyanshu (AI-assisted) · **Updated:** 2026-09-23 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted — 2026-09-23, after a five-page audiology report came back shapeless
- **Amends:** [ADR-052](adr-052-one-call-per-upload-with-bounded-recovery.md)'s reference-text handling and prompt v12's shortcut

---

## 1. Context

A UWMC paediatric audiology report (ABR/SNHL, 5 pages) extracted as a flat wall of text: every
page header repeated five times, a printed sidebar rendered letter-by-letter as
`P / R / O / G / R / E / S / S`, and the report's own structure — HISTORY, TEST RESULTS, the
BAER results table with per-ear thresholds, ASSESSMENT, RECOMMENDATIONS — gone.

The cause was not the model. `_finalize_narrative_report` contained:

```python
if text_layer and pdf_bytes:
    nr["transcribed_report"] = text_layer
```

**Unconditional.** For any single digital PDF, the model's transcription was overwritten with
raw pypdf output, whatever the model had produced. The reasoning was sound as far as it went —
a deterministic extraction cannot hallucinate — but it traded away the thing that makes a
clinical document readable. The model's own Markdown transcription, which preserved every
heading and the results table, was discarded unread on every such upload.

A first attempt at a fix (raising the threshold at which the prompt's marker *shortcut* is
offered) changed nothing, because the substitution was never gated on the shortcut at all.
That is recorded because it is the instructive part: the fix was aimed at the wrong mechanism
until the actual line was read.

## 2. Decision

Substitute the raw text layer **only when the model did not give us a usable transcription**:

- it wrote the reference-layer **marker** (`_is_marker_body`, the prompt v12 shortcut), or
- its transcription is **less than half the length** of the text layer, meaning it dropped a
  substantial part of the document.

The reference text is still supplied in both cases and the prompt still requires the model to
cross-check against it, so completeness is not traded for shape.

The marker shortcut itself is additionally restricted to documents above
`_REFERENCE_SHORTCUT_MIN_CHARS` (25,000). It exists for one real failure — a 13-page, 40,000+
character genetic report that hit the output-token cap — and a 10,702-character report is not
that case.

## 3. Result on the report that prompted it

| | Before | After |
|---|---|---|
| Transcription | 10,620 chars, raw dump | 9,184 chars, structured |
| Markdown headings | **0** | **11** |
| Repeated page furniture | present | gone |
| Sidebar letters `P R O G R E S S` | present | gone |
| BAER results table | flattened into prose | a Markdown table with Left Ear / Right Ear columns |
| Image observations | — | 3 (BAER waveforms, tympanograms, DPOAE plots) |

Headings recovered, in the report's own order: AUDIOLOGICAL EVALUATION · HISTORY · TEST
RESULTS · Brainstem Auditory Evoked Response · Immittance and Otoscopy · Evoked Otoacoustic
Emissions · ASSESSMENT · RECOMMENDATIONS · Hearing Loss · Hearing Technology · Intervention.

## 4. Consequences accepted

| Consequence | Detail |
|---|---|
| **A model transcription can drift from the page** | Previously impossible, because the deterministic text always won. Mitigated by keeping the reference text as grounding, by the cross-check requirement in the prompt, and by the half-length floor that falls back when the model clearly dropped content |
| **More output tokens** | The model now writes the transcription for documents under 25,000 characters instead of emitting a marker. Latency is output-bound (`docs/ai/LAB_EXTRACTION_PERFORMANCE.md`) |
| **The half-length floor is a heuristic** | A legitimately terse structured transcription of a very verbose page could trip it and fall back to the raw layer. Chosen over a stricter rule because falling back is safe — it loses shape, never content |

## 5. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Keep substituting, and post-process the raw text to strip page furniture | Fragile pattern-matching against every clinic's letterhead, and it still could not rebuild a table |
| Drop the reference text entirely for narratives | Loses the completeness grounding that keeps a long multi-page report from silently missing a page |
| Let each report type's template decide | Templates are AI-authored and optional; a type whose template omitted it would silently return to flat dumps. Preserving a document's structure is an invariant, not a per-type preference |


## 6. Follow-on: page furniture

Once the model's own transcription was kept, it reproduced everything printed on the page —
faithfully, including things that are not the report:

- the letterhead and clinic address, repeated on all five pages
- `Page 1 of 5` on each page
- a margin label reading `P / R / O / G / R / E / S / S / — / B / L / U / E`

The last one was worth diagnosing rather than assuming. It is **not rotated text**: the PDF
genuinely contains thirteen separate one-character horizontal lines, stacked down the margin —
a paper-chart filing marker ("progress notes, blue copy"). Verified by reading each line's
direction vector: every line reports `(1.0, 0.0)`, i.e. horizontal.

The prompt now excludes page furniture, with a test that generalises rather than a list of
things to strip:

> **Would a clinician reading this report aloud say it?** They would read the history, the
> results tables, the assessment and the recommendations. They would not read out a
> letterhead five times, a page number, or a vertical form marker.

Identifiers are transcribed once as a small table; a page number is explicitly never an
identifier, while the report date is.

**Verified that nothing clinical was lost in the process:**

| Check | Result |
|---|---|
| Letterhead occurrences | 1 (was 5) |
| Page numbers | 0 |
| Margin-label letters | 0 |
| BAER threshold rows | 6 of 6 |
| Wave V latencies 10.87 / 7.33 / 6.80 | all present |
| ASSESSMENT · RECOMMENDATIONS | kept |
| Numbered recommendations | 6 of 6 |
| Reporting audiologist · cc list · test date | kept |


### 6.1 The rule states the principle; the evidence stays here

The first version of the page-furniture rule carried the specific case into the prompt — it
named the audiology report, the thirteen letters and the four repetitions. Divyanshu objected,
on the same ground as the side-abbreviation map in [ADR-083](adr-083-per-parameter-side.md)
§2: an instance teaches one shape, and the next report will carry a kind nobody listed.

He was right, and the rule was already carrying its own weight without the anecdote. The
prompt now states only the principle and the test, and explicitly tells the model NOT to match
against a list:

> "When something is borderline, ask that question — do not try to match it against a list of
> things to strip, because the next report will carry a kind you have not seen."

It names a watermark, a barcode's digits, a confidentiality footer and a printed-on date stamp
as illustrations of the CATEGORY, not as cases to recognise. The anecdote lives in §6 above,
which is where evidence belongs.

**A general rule proved no weaker.** Re-run after removing the example: page furniture 0,
margin letters 0, and every content check still passing — 6 of 6 BAER rows, all three Wave V
latencies, both narrative sections, all six numbered recommendations, the reporting
audiologist, the cc list and the test date.

**One behaviour change worth noting:** the clinic letterhead is now dropped entirely rather
than kept once. The reporting audiologist, her contact details and the test date are all
retained, so the source of the report is still identifiable — but if the clinic name is wanted
on the record, it should be captured as an identifier rather than relied on as a side effect
of the letterhead surviving.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Divyanshu (AI-assisted) | Page-furniture rule generalised — the specific case moved out of the prompt into this ADR |
| 1.1 | 2026-09-23 | Divyanshu (AI-assisted) | Page furniture excluded — repeated letterheads, page numbers and a letter-per-line margin label; content verified intact |
| 1.0 | 2026-09-23 | Divyanshu (AI-assisted) | Initial version — conditional text-layer substitution; shortcut restricted to very large documents |
