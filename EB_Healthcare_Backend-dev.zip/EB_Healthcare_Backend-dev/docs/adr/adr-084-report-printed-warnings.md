# ADR-084: Capture the warnings a report prints about its own results

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — 2026-09-22
- **Builds on:** [ADR-083](adr-083-per-parameter-side.md)

---

## 1. Context

An IOLMaster 700 biometry was uploaded and summarised as *"The application flagged no results
as abnormal."* That was true of **our** flagging and badly misleading, because the device had
printed its own warnings on the report and we captured none of them:

- `OS: Las mediciones de longitud axial muestran una ligera inconsistencia. Sírvase verificar
  la fijación.` — left-eye axial length inconsistent, verify fixation
- `Para este cálculo de IOL se han editado valores manualmente.` — manually edited values were
  used for this calculation
- `! Compruebe las advertencias en todas las páginas.` — check the warnings on all pages
- The legend `(!) Valor marginal` / `(*) Valor editado manualmente`

Verified present in the source PDF on pages 3-5.

**Why our flagger could never find this.** `result_flag` compares a value against a reference
range. Every number in this study looks perfectly ordinary, and the report prints no ranges
at all, so nothing was flagged — correctly. The warning is not about any single value being
out of range; it is the machine saying it does not trust a measurement and asking for it to
be repeated. That sentence cannot be reached by looking at numbers, and a surgeon planning a
lens implant needs it.

## 2. Decision

A document-level `report_notices` on the extraction: `[{text, side}]`, the document's own
wording, captured verbatim, with the side attached when the notice names one.

Generic by design. The same field carries a haemolysed-sample note on a blood panel, a
"results pending" line, a poor-acquisition caution on an imaging study, a disclaimer about
method. Nothing about it is ophthalmic.

**These are the report's words, never our assessment.** The prompt forbids putting our own
opinion of the results there, and the summary is required to attribute them to the report.

### 2.1 Reaching the summary

The notices are rendered ahead of the narrative text (`render_report_notices`), so **both**
summary paths see them — the discrete-analyte one and the narrative one — without threading
a new argument through each. The report-summary prompt is versioned to v4 with a rule that
they are stated early and never merged with our own flagging:

> "Saying 'nothing was flagged as abnormal' while the device is asking the clinician to
> repeat a measurement is wrong and is dangerous: every number can look ordinary in a study
> the machine itself does not trust."

The API resolves them from the `extraction` id the review screen already sends, so no client
change was needed for a clinician to be told.

## 3. Result

Captured on the real report: 4 of 4 notices, with the left-eye one correctly attributed to
`side = left`. The summary now opens with them, keeps them apart from our flagging, and the
status is `Review` rather than `Normal`.

## 4. A schema trap worth recording

The first attempt failed every extraction with
`Invalid schema for response_format: 'required' is required to be supplied and to be an array
including every key in properties. Missing 'report_notices'.`

OpenAI's strict structured-output mode requires **every** property to appear in `required`.
Adding a property without adding it there breaks the whole call. It failed loudly with a
clear message, which is the behaviour we want — recorded so the next person adding a field
does not lose an hour to it.

## 5. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Leave the warnings inside the transcription | A panel-classified report has no transcription at all, which is exactly the case that failed here |
| Let our flagger infer a warning from the values | It cannot. Nothing about 24.20 mm is abnormal; the warning is about the measurement's reliability, not its magnitude |
| Put it in each report type's template | Templates are AI-authored and optional; a type whose template omitted it would silently drop a device warning. Not losing a printed caution is an invariant |
| Show the notices only on screen, not in the summary | The summary is what most people read, and "nothing was flagged" is precisely the sentence that needed correcting |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — `report_notices` captured, surfaced and summarised; report-summary prompt v4 |
