# ADR-065: Admin-practitioner booking bypasses the practitioner User Permission via a reassignment-style write, not `ignore_permissions=True`

**Doc status:** living · **Created:** 2026-09-14 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-14 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-14
- **Supersedes:** — (closes a gap ADR-018 left open; does not change ADR-018's decision)
- **Superseded by:** —

## Context

Dr. Anant Sharma holds both `EB_Practitioner` and an admin role (`EB_Healthcare
Admin` / `System Manager` / `Administrator`). Booking a Patient Appointment and
naming a *different* practitioner (Dr. Sarvesh Sandhu) fails with
`frappe.PermissionError`.

Two independent gates evaluate the same decision, and only one of them knows
about admin roles:

1. **App-level** — `_enforce_practitioner_self_booking()`
   (`api/v1/appointments/api.py:336-361`) already contains an admin carve-out
   (`roles & _ADMIN_ROLES` at line 347): an admin's `practitioner` argument
   passes through unchanged. This layer was never the blocker.
2. **Frappe-core** — every plain `EB_Practitioner` user carries a **User
   Permission** row (`Healthcare Practitioner = <self>`), which restricts
   which values of that Link field the user's session may reference *anywhere
   in the system*. It has no concept of a role union; it does not know the
   same user also holds an admin role. `book_appointment` never sets
   `skip_staff_authorization`, so `_create_impl`
   (`api/v1/appointments/api.py:1097`) always calls
   `doc.insert(ignore_permissions=False)`
   (`api/v1/appointments/api.py:1213`, pre-fix) — Frappe's own permission
   engine then rejects the insert.

This User Permission is not a mistake on Anant's account — it is the only
thing stopping every plain doctor (Sheru, Sandhu) from naming a colleague as
`practitioner` on a new appointment. Removing or loosening it for everyone
would remove real protection. The fix must be scoped to the population that
is both `EB_Practitioner` *and* an admin, and must leave every other caller's
codepath untouched.

The identical restriction, on a *write* instead of a *create*, was already
solved once: **`reassign_appointment`** (ADR-018,
`api/v1/appointments/api.py:2422`) lets Front Desk/Admin move an *existing*
appointment to a different practitioner. It works by never letting
`doc.save()` see the restricted Link value at all — it writes `practitioner`
through `frappe.db.set_value()`, which does not go through Frappe's
permission/User-Permission layer, then manually refreshes the two fields
(`practitioner_name`, `title`) that would otherwise have been derived by
`doc.save()`'s own field-fetch logic. It also logs the change
(`frappe.logger("remedisys").info(...)`) — IDs only, no PHI, per Constitution
Rule 10.

This ADR applies that exact, already-reviewed mechanism to the *create* path,
rather than introducing a new kind of bypass.

## Decision

In `_create_impl`, detect the one population this restriction needs to be
routed around — `EB_Practitioner` + an admin role, naming someone other than
themselves — via a small pure helper, `_resolve_admin_target_practitioner()`.
When it returns a value:

1. The restricted `practitioner` value is kept **out of `doc_data`**, so
   `doc.insert()` never evaluates it against the User Permission. Every other
   field, and every other permission check on the insert, is unaffected.
2. Immediately after `doc.insert()` succeeds, `practitioner`,
   `practitioner_name`, and `title` are written through
   `frappe.db.set_value()` — the same call shape `reassign_appointment` uses,
   for the same reason (it does not go through the permission layer).
3. `department` (`fetch_from=practitioner.department`, `fetch_if_empty`) is
   backfilled through the existing `_ensure_appointment_department()` guard
   with `target_practitioner` set to the admin-chosen doctor — it was never
   fetched at `insert()` because `practitioner` was withheld from `doc_data`.
4. One structured log line records the override: appointment name, the
   practitioner named, and `frappe.session.user` — IDs only, no patient name
   or clinical content (Rule 10).

A caller who is **not** both `EB_Practitioner` and an admin never reaches this
branch:
- A plain `EB_Practitioner` (no admin role) is already forced to their own
  value by `_enforce_practitioner_self_booking` upstream — nothing to route
  around.
- A non-practitioner Front Desk/Admin user holds no restrictive User
  Permission in the first place (only `EB_Practitioner` accounts get one) —
  booking any doctor for any patient already worked before this change.
- The patient-portal path (`skip_staff_authorization=True`) is excluded
  explicitly.

Since the routing lives inside the single shared `_create_impl`, every caller
that funnels through it (`book_appointment`, `book_appointment_with_payment`,
`book_appointment_for_patient`) gets the fix with no per-endpoint change.

## Alternatives Considered

1. **Blanket `ignore_permissions=True` gated on admin role** (the shape first
   proposed).
   - Pros: smallest diff — one conditional around the existing
     `skip_staff_authorization` flag.
   - Cons: `ignore_permissions=True` waives **every** permission check on that
     insert, not only the practitioner User Permission — broader than the
     actual problem, and silent (no record of what was overridden or why),
     unlike the audit-log requirement NH-52 already set for the identical bug
     class on Encounters. Rejected: correctness margin too wide for a
     permission-relevant change, and it introduces a second, differently-shaped
     bypass mechanism alongside the one `reassign_appointment` already
     established.

2. **Narrow Anant's own User Permission row scope** (`applicable_for = Patient
   Encounter` only, removing the blanket restriction).
   - Pros: zero code change; smallest possible blast radius (one user, one
     record, reversible by deleting the row).
   - Cons: invisible in a code diff/CHANGELOG unless separately documented;
     has to be redone by hand for every future admin-practitioner — a data
     fix, not a systemic one, so the identical bug resurfaces the next time
     someone is promoted. Rejected as the durable fix, though it remains a
     valid *immediate, no-deploy* stop-gap if this code fix cannot ship
     right away.

3. **Role-level "ignore user permissions" flag on the DocPerm rule.**
   - Checked directly: Frappe core's `DocPerm` doctype
     (`frappe/core/doctype/docperm/docperm.json`) exposes no
     `ignore_user_permissions` field in this Frappe version. Not a real
     mechanism in this stack — ruled out, not merely disfavored.

4. **New explicit-consent override endpoint/flag**, requiring the frontend to
   pass an explicit `override_practitioner_restriction` argument rather than
   inferring it from role, with its own audit doctype.
   - Pros: makes the bypass visible and deliberate per-request, not automatic;
     extensible to other roles later without more silent branching.
   - Cons: disproportionate for a single-account problem today — new field,
     new frontend wiring, slower to ship. Noted as a candidate follow-up if
     this bypass needs to extend beyond Admin-practitioners (e.g. to Front
     Desk claiming a colleague's slot on a doctor's behalf).

5. **Reuse `reassign_appointment`'s exact mechanism inside `_create_impl`
   (chosen).**
   - Pros: no new bypass shape introduced — the identical write pattern is
     already reviewed, tested in production use (ADR-018), and logged; scoped
     to exactly the practitioner field; zero effect on any caller outside the
     admin-practitioner population; the audit line matches the sibling
     function's format exactly, so log tooling built for one covers both.
   - Cons: two extra DB round-trips (the deferred `db.set_value` +
     `_ensure_appointment_department`) versus a single `insert()` — negligible
     for a booking action that is not a hot loop.

## Why this approach, specifically

Four other approaches were on the table, and each loses for a specific,
checkable reason rather than a vague "too complex":

- **Vs. Alternative 1 (blanket `ignore_permissions=True`):** loses on
  correctness margin, not style. It would waive every permission check the
  insert performs, not just the one restriction this ADR is actually about —
  a broader grant than the problem calls for — and it would do so silently,
  with no record of what was overridden, unlike NH-52's own audit-log
  requirement for the identical bug class on Encounters. It also introduces a
  *second, differently-shaped* bypass mechanism into the codebase, when one
  already exists and is already trusted.
- **Vs. Alternative 2 (narrow Anant's own User Permission scope):** loses on
  durability, not correctness — it would work today, for Anant, with zero
  code change. But it is a fix to one *person's data*, not to the *system*: it
  has to be manually repeated for every future doctor who becomes an admin,
  and nothing enforces that it will be. The bug is systemic (any
  EB_Practitioner + admin hits it); the fix should be too.
- **Vs. Alternative 3 (a DocPerm-level "ignore user permissions" flag):** not
  a matter of preference — checked directly against
  `frappe/core/doctype/docperm/docperm.json` and the field does not exist in
  this Frappe version. There was nothing to choose; it was never available.
- **Vs. Alternative 4 (explicit-consent override endpoint + new audit
  doctype):** loses on proportionality, not merit — it is arguably the more
  complete long-term answer (an explicit, per-request flag beats inferring
  intent from role), but it means new frontend wiring and a new doctype for a
  problem that currently affects one account. Parked as the next step if this
  ever needs to extend past Admin-practitioners (e.g. Front Desk claiming a
  colleague's slot), not thrown away.

What made Alternative 5 win on its own merits, not just by elimination: it
introduces **no new mechanism** at all. `reassign_appointment` (ADR-018)
already solved the identical problem — a restricted `practitioner` value that
Frappe's core permission layer would reject — for a *write*. Reusing that
exact write shape for a *create* means there is only ever one pattern in this
codebase for "an admin needs to set a practitioner value the User Permission
would otherwise block," not two. That is what let the fix land as ~40 lines
touching one function, verified by 6 unit tests plus one real end-to-end
booking, rather than a new subsystem.

## Consequences

- `api/v1/appointments/api.py`:
  - New helper `_resolve_admin_target_practitioner()` next to
    `_enforce_practitioner_self_booking()`.
  - `_create_impl` withholds `practitioner` from `doc_data` when the helper
    flags an override, then writes it via `frappe.db.set_value()` post-insert,
    backfills `department` via the existing `_ensure_appointment_department()`
    guard, and logs the override.
- `tests/appointments/test_appointments.py` — `TestResolveAdminTargetPractitioner`
  unit-tests the helper's branching directly (no DB fixtures needed): admin
  practitioner naming a colleague is flagged; admin practitioner booking
  themselves is not; a plain practitioner is never flagged; a non-practitioner
  admin is never flagged; the portal path is never flagged; no-practitioner
  bookings are never flagged.
- No frontend change required — `book_appointment`'s existing request shape
  (patient, practitioner, ...) already carries everything needed; the fix is
  entirely server-side.
- **Re-evaluation triggers:** this needs to extend to a role beyond Admin
  (e.g. Front Desk claiming on a doctor's behalf) → revisit Alternative 4. A
  second admin-practitioner-shaped bug appears elsewhere (e.g. lab or
  procedure ordering) → consider whether the pattern should become a shared
  helper rather than being re-derived per doctype.

## Verification

- `tests/appointments/test_appointments.py::TestResolveAdminTargetPractitioner`
  (6 cases, mock-only, no site fixtures required).
- Manual: Anant (EB_Practitioner + System Manager) books a patient with
  Sandhu as practitioner → `201`, appointment's `practitioner` = Sandhu,
  `department` populated from Sandhu's record, one `remedisys` log line
  emitted. Sheru (plain EB_Practitioner) attempting to name Sandhu still gets
  the pre-existing `"You can only book appointments for yourself."` — this
  path is unchanged by this ADR (`_enforce_practitioner_self_booking` forces
  it before `_create_impl` is even reached).

## References

- Constitution §4 Rule 1 (no core modification), Rule 10 (no PHI in logs), §9
  (ADR requirement)
- ADR-018 (practitioner appointment visibility and coverage reassignment —
  origin of `reassign_appointment` and the write-through-`db.set_value`
  pattern this ADR reuses)
- Jira NH-118 (Admin practitioner blocked from booking appointment for
  another doctor), NH-10 (Doctor Permission epic), NH-49/NH-52 (identical bug
  class, fixed for Patient Encounter)
- `docs/ADMIN_PRACTITIONER_BOOKING_OVERRIDE.md` (mechanism doc, layer by layer)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-14 | Sarvesh-SocialAngel (AI-assisted) | Added "Why this approach, specifically" — explicit, itemized comparison against each rejected alternative |
| 1.0 | 2026-09-14 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
