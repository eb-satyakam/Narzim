# ADR-089: A body site is recorded only when printed words name it — a site read from a picture is a suggestion

**Doc status:** living · **Created:** 2026-09-23 by Divyanshu (AI-assisted) · **Updated:** 2026-09-24 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted — requested by Divyanshu, 2026-09-23, after measuring that the ADR-088 prompt alone still named an organ for an unlabelled ultrasound
- **Amended by:** [ADR-090](adr-090-image-observations-graded-not-restricted.md) — decisions 4 and 5 (prose may name clearly recognisable anatomy; the gate flags prose but no longer rewrites it). Decisions 1–3 and 6 stand.
- **Amends:** [ADR-081](adr-081-report-subject-and-template-driven-summaries.md) — `subject.body_site` is no longer taken from the model as given; [ADR-088](adr-088-images-read-from-what-they-show.md) — decision 4 ("an organ is named only when printed or clearly recognisable") is replaced by "only when printed"

- **Prompt file:** `multi_panel_extraction_v17.txt` was removed 2026-09-24 at the owner's request (not kept in the repo); the live prompt is `multi_panel_extraction_v21` (ADR-091).
---

## 1. Context

[ADR-088](adr-088-images-read-from-what-they-show.md) found that an unlabelled ultrasound JPEG
(the only printed text is the scanner's name, "SAMSUNG RS85") was described as a kidney because
Stage 1 had matched it to a renal ultrasound template. It stopped the template path and told
the model (prompt v16) to name an organ only when printed or clearly recognisable.

That fix was verified on 2–3 console runs. Two things then came to light on 2026-09-23:

1. **Real uploads were still on v15.** The RQ worker had been running since before the change;
   every clinician upload used the old code (AI Prompt Log `orvuninfnc`, v15, `body_site:
   "kidney"`, evidence `""`) while every console re-run used v16. Restarting `bench start` put
   v16 live (`97gt508sv3`: "not identified").
2. **v16 on its own still names the organ.** Nine further runs of the same image (5 at
   `reasoning_effort` default, 5 at `high`; 9 returned) gave `body_site: "kidney"` in **3**, with
   no printed text to support it. Across all v16 runs that day: **3 of 12 (25%)**. Raising
   reasoning effort did not help (2 of 5 at `high`).

Why it matters: `build_established_facts_instruction` hands `body_site` to the report summary as
its **source of truth**, so a wrong site is not only stored — the summary is told to repeat it.
The review screen reads the same saved raw response.

A prompt rule that fails a quarter of the time is not a safeguard. The decision has to be made
by code, on something code can check.

## 2. Decision

1. **The model reports how it identified the site** (`subject.identified_from`: `printed_text`
   / `image_appearance` / `not applicable`) and, for printed, **the exact printed words**
   (`subject.printed_quote`). Schema: `MULTI_PANEL_EXTRACTION_SCHEMA`; prompt
   `multi_panel_extraction_v17`.
2. **Code keeps `body_site` only when the quote is found in the model's own transcription**
   (`integrations/llm.py::gate_subject_identification`; case-, whitespace- and
   Markdown-insensitive; at least 3 characters). Otherwise the site moves to
   `suggested_body_site`, `body_site` becomes `"not identified"`, the model's reasoning moves to
   `suggestion_evidence`, and `evidence` states that no printed text names the site. An unknown
   `identified_from` is treated as `image_appearance`, never as printed.
3. **The gate runs on the parsed response before it is saved**
   (`services/lab_panel_extraction.py`, after recovery, before `raw_text` is serialised), so the
   review screen, the summary and the cleaned result all see the same gated value.
4. **Image descriptions name an organ only when it is printed** (v17). The model's impression
   has one place to go — the gated `body_site` — instead of the prose.
5. **Prose that still names the suggested site is flagged, not rewritten.** If an image
   observation on the same file uses the suggested site's words, code sets
   `names_unconfirmed_site` and appends a fixed note to the description. The words are the
   model's own suggestion, so no vocabulary list is maintained; side words are excluded using
   the existing side allow-list.
6. **The review API passes the new fields through** (`identified_from`, `suggested_body_site`,
   `suggestion_evidence`, `names_unconfirmed_site`). A UI that shows `suggested_body_site` must
   label it as unconfirmed; the frontend shows none of these yet, which is the safe default.

## 3. Options considered

| Approach | Pros | Cons |
|---|---|---|
| A. Tighten the prompt again (v17 wording only) | One file | The same kind of rule already fails 25% of the time; nothing checks it |
| **B. Model states basis + quote; code verifies the quote against the transcription (chosen)** | The decision rests on a check code can perform; the visual impression is kept as a labelled suggestion, not lost | Schema change in both providers; a transcription the model fabricated to match its own quote would pass |
| C. Code denylist of organ and condition words in image output | Deterministic | Never complete across specialties and languages; the `_clean_side` docstring records why a hardcoded vocabulary was already removed; conflicts with generic prompts |
| D. A second LLM call to verify the identification | Can judge the picture itself | Another call per image, and the verifier is a model with the same failure mode |

A was insufficient by measurement. C would never be finished and decides by vocabulary, not
evidence. D checks one model's guess with another's. B moves the decision onto the one thing the
code can verify — whether the words exist in the transcription — and still gives the clinician
the model's impression, clearly labelled.

**What would falsify this:** an upload whose printed site is dropped to "not identified" because
the quote did not match (check `suggested_body_site` on uploads *with* printed titles — e.g. a
PDF whose text layer replaced an empty model transcription after the gate ran), or a stored
`body_site` on an image with no printed site.

## 4. Verified

Same image, prompt v17, gate applied, 8 live runs (2026-09-23, console, nothing saved):

| | v16 (12 runs) | v17 + gate (8 runs) |
|---|---|---|
| Model named a site from the picture | 3 ("kidney") | 1 ("fetal head") |
| Stored as the study's site | 3 | **0** |
| Image prose names an organ | in the failing runs | 0 |

The one v17 guess was a *different* organ from the v16 guesses — direct evidence of why a
site read from this picture cannot be stored as fact. Tests: `tests/labs/test_body_site_gate.py` (removed 2026-09-24 at the owner's request (not kept in the repo))
(23; 9 fail with the gate disabled).

## 5. Not changed

- **`side` from image appearance** is not gated. It already defaults to `"not stated"`, and no
  wrong side was observed; the same printed-quote check could be applied if one is.
- **Interpretive wording** remains prompt-only. One v17 run called the structure "the central
  lesion" — a word that judges the tissue. The gate covers the site, not the vocabulary.
- **The text-layer case:** when `_finalize_narrative_report` replaces an empty model
  transcription with a PDF's text layer, that happens after the gate, so a site printed only in
  the text layer is demoted. Rare (the model normally transcribes a PDF with text), and the
  failure is the safe one.
- **Anthropic** gets the same schema and prompt; it was not measured.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-24 | Divyanshu (AI-assisted) | Recorded that its prompt file and tests were removed at the owner's request |
| 1.1 | 2026-09-24 | Divyanshu (AI-assisted) | Decisions 4–5 amended by ADR-090 |
| 1.0 | 2026-09-23 | Divyanshu (AI-assisted) | Initial version |
