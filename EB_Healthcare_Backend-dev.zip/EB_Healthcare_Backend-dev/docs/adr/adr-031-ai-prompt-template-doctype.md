# ADR-031: Runtime-editable prompts via AI Prompt Template

**Doc status:** living · **Created:** 2026-07-23 by Divyanshu · **Updated:** 2026-07-23 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted — **doctype + seed only; loader integration DEFERRED**
- **Date:** 2026-07-23
- **Relates to:** §9 (prompt governance), Rule 2 (uninstall-safe), Rule 6 (physician-in-control)

> **Current state (2026-07-23):** the `AI Prompt Template` doctype is installed and
> seeded from the existing prompt files, but the LLM loaders are **unchanged** and
> still read prompts from the files — the runtime does NOT consult the doctype yet.
> This is deliberate: the store is in place for future customization, but we keep
> the current file-based method for now. The "Decision" below describes the
> intended override wiring for when it is switched on; wiring it is a follow-up.

## Context

Prompts lived only as versioned files under `llm/prompts/` and the repo-root
`prompts/`, loaded by `llm.load_prompt(version, prefix)` and the copilot
`_load_prompt(filename)`. Changing a prompt required a code change + redeploy.
The team needs to customize/iterate prompts (wording, tone, added guidance)
**without a code change**.

§9 requires prompts to be file-based, versioned, and **hash-recorded** in every
AI Prompt Log row. A naive "move prompts into the DB" would break that discipline
and git history.

## Decision

Add a doctype **`AI Prompt Template`** that acts as an **override layer**, not a
replacement:

- Keyed by `prompt_key` = the prompt filename **stem** (e.g. `patient_chat_v2`,
  `suggest-v2`) — the one key both loader families share.
- Fields: `title`, `is_active` (uncheck → ignore this row, fall back to the file),
  `description`, `content`. `track_changes: 1`; **write restricted to System
  Manager** (prompts drive clinical AI behavior — Rule 6).

Loader behavior (`llm.resolve_prompt` / `prompt_with_hash`, and the copilot
`_load_prompt`):

1. If an **active** `AI Prompt Template` row exists for the stem → use its content.
2. Otherwise → read the git-tracked file (the default).
3. The SHA-256 is computed from **whatever content is actually used**, so the
   AI Prompt Log hash still reflects reality (§9 preserved).

A one-time patch seeds the doctype from the current files (content-identical, so
zero behavior/hash change at seed time), making every prompt visible and editable
in the Desk immediately.

## Consequences

- **Customize without code change** — edit a prompt in the Desk; it takes effect
  on the next call. `is_active` off = instant rollback to the file.
- **§9 intact** — files remain the version-controlled default and fallback; the
  logged hash always matches the content used; `track_changes` gives a who/when
  audit of prompt edits (stronger governance than raw files).
- **Rule 2 (uninstall-safe)** — `resolve_prompt` is defensive (returns None if the
  doctype/table is absent or on any error), so prompts still load from files on a
  fresh site, pre-migrate, or after uninstall.
- **Rule 6 (safety)** — editing is System-Manager-only; a prompt is not a place
  for unreviewed clinical instructions. Editing under the same version string
  changes behavior for that version — the change log is the traceability backstop.
- Once seeded, a DB row is authoritative and **masks** later edits to that prompt
  file (expected — that's the override model). To adopt a new file default, edit
  the row (or delete it to fall back to the file).

## Alternatives considered

- **DB-only prompts (no files):** rejected — breaks §9 versioning/git history and
  Rule 2 (nothing to fall back to on uninstall).
- **Inline prompts in code:** already forbidden by §9 / Hard Don'ts.
- **New provider/config for each prompt:** heavier and less discoverable than one
  keyed doctype covering both loader families.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-23 | Sarvesh | Initial version (header backfilled from git history) |
