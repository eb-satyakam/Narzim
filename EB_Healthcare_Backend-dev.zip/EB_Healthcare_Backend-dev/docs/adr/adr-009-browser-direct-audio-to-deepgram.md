# ADR-009: Stream microphone audio browser-direct to Deepgram; audio never reaches Frappe

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-05-15 (decided and implemented) · **Recorded:** 2026-08-20 (retroactively)
- **Supersedes:** —
- **Superseded by:** —

> ### Why this ADR is dated twice
> The decision was made on 2026-05-15 and has been in production since. **The ADR was never
> written.** The documentation hygiene audit (2026-08-20) found "ADR-009" cited by 17 files —
> including `CLAUDE.md` §3, `ROADMAP.md`, and the module docstring of `api/ai/sessions.py` — with no
> such document in existence. This file records the decision from the evidence in the code and the
> constitution; it does not invent it. Every claim below was verified against the implementation on
> that date. Nothing here is new policy.
>
> Recording it matters because this is the **privacy architecture of the entire ambient-documentation
> feature**. The assertion "audio never reaches Frappe" is load-bearing for the LFPDPPP position on
> recording a consultation, and until now it was asserted in a docstring and nowhere decided.

## Context

Ambient documentation requires streaming a live doctor–patient consultation to a speech-recognition
provider. Three constraints shape how:

1. **Rule 10 (no PHI in logs) and the jurisdictional profile.** A consultation recording is the most
   sensitive artefact the system handles. Every hop it traverses is a place it can be logged,
   cached, buffered to disk, or captured in a stack trace.
2. **ADR-005 suspended Rule 3 (service separation).** There is no FastAPI sidecar; all backend code
   runs inside the Frappe app on Frappe Cloud. Frappe's request model is synchronous WSGI workers —
   it is not a media relay, and streaming binary audio through it would occupy a worker for the
   duration of a consultation.
3. **Rule 7 (AI failure must not break healthcare).** A transcription outage must degrade to a
   visible "unavailable" state, never block documenting or signing an encounter.

Deepgram supports both a server-relayed model (server holds the socket, client posts audio to the
server) and a browser-direct model (server mints a short-lived scoped credential, the browser holds
the socket to the vendor).

## Decision

**The browser streams microphone audio directly to Deepgram over a WebSocket. Audio bytes never
transit, and are never stored by, the Frappe backend.**

Concretely:

1. The backend holds the long-lived Deepgram API key in `frappe.conf` (`deepgram_api_key`) and
   **never** sends it to the client.
2. `integrations/deepgram.py::mint_session_token(session)` mints a **short-lived scoped token** per
   recording session, with a TTL derived from `AI Settings.max_session_minutes`, and returns
   `{url, token, ttl_seconds, params}`.
3. The **server** decides the recognition parameters and bakes them into the returned params —
   `model`, `language`, `interim_results`, `endpointing`, `punctuate`, `numerals`, and exactly one
   of `diarize` or `multichannel`. The client cannot choose the model or the language.
4. Token minting is gated: `api/ai/sessions.py::start_session` requires **Patient Encounter read
   permission** and an explicit `consent_obtained` before a token is issued. Without consent the
   session stays `Draft` and the response carries `deepgram: null`.
5. The browser (`copilot/real-provider.ts`) opens the WebSocket to `wss://api.deepgram.com` itself
   and feeds it captured audio.
6. **Only finalized text returns to us**, through `api/ai/segments.py::append_segment`, persisted as
   `AI Transcript Segment` rows.
7. Long consultations are covered by proactive rotation: the client mints a fresh token ~60 s before
   TTL (`RealCopilotProvider.REFRESH_MARGIN_S`) via `refresh_deepgram_token`, which refuses to mint
   for any session not in `Recording`.
8. Audio is **not retained anywhere**: `AI Settings.retain_audio = 0`, `audio_retention_days = 0`,
   and `AI Encounter Session.audio_retained` is 0 on every session on record.

## Alternatives Considered

1. **Server-relayed audio (browser → Frappe → Deepgram).**
   - Pros: the API key never leaves the server in any form, not even scoped; one place to enforce
     policy; easier to add server-side audio archival later if a jurisdiction ever demands it.
   - Cons: audio traverses Frappe, so it can be logged by any middleware, buffered to disk by the
     WSGI layer, or captured in a traceback — directly at odds with Rule 10's spirit. Occupies a
     synchronous worker for the length of a consultation. Doubles bandwidth. Adds a hop that can
     fail independently, worsening Rule 7 exposure.

2. **Browser-direct with a short-lived scoped token (chosen).**
   - Pros: audio never touches our infrastructure, so it cannot be logged or leaked by it; no worker
     is held for the consultation; one fewer failure hop; the server still controls *what* is
     transcribed (model, language, diarization) and *whether* it may start (consent + permission).
   - Cons: a scoped token exists briefly in the browser; the client must implement rotation to
     survive long sessions; we lose the option of server-side audio inspection or archival without
     revisiting this ADR.

3. **On-device / self-hosted ASR.**
   - Pros: no third party sees the audio at all — the strongest possible privacy position.
   - Cons: no viable multilingual (es-MX + en-US), diarizing, streaming model at the accuracy this
     use case needs at our team size (~3 backend, 1 frontend, 1 ML). Would require GPU
     infrastructure that ADR-005 explicitly avoids.

## Consequences

- `CLAUDE.md` §3's `ASR` row records this: *"Browser streams direct to Deepgram (ADR-009); audio
  never reaches Frappe."* That claim is now backed by a decision record.
- `AI Encounter Session` becomes the consent and audit anchor for a recording, since it is the only
  server-side artefact of a session that the server never sees the content of.
- **`retain_audio` must stay off** unless this ADR is superseded. Turning it on would require a
  server-side audio path that this decision deliberately does not build.
- `integrations/deepgram.py` raises stable error codes (`DEEPGRAM_NOT_CONFIGURED`,
  `DEEPGRAM_HTTP_ERROR`, `DEEPGRAM_TIMEOUT`, `DEEPGRAM_BAD_RESPONSE`, `DEEPGRAM_TRANSPORT_ERROR`) so
  the client can degrade to "AI unavailable" per Rule 7 rather than surfacing a raw failure.
- **Re-evaluation triggers:** a jurisdiction requiring us to retain or inspect the audio itself; a
  Deepgram terms change affecting browser-direct scoped tokens; a viable self-hosted multilingual
  streaming model; or a decision to add a service tier (un-suspending Rule 3), which would make the
  relayed option cheap again.

## Verification

| Claim | Artefact |
|---|---|
| The API key never reaches the client | `integrations/deepgram.py::mint_session_token` reads `frappe.conf["deepgram_api_key"]`; the response contains only a scoped token |
| Audio never reaches Frappe | No endpoint in `api/ai/` accepts an audio body except `transcribe_audio` (the separate batch-upload path); the streaming path has no audio parameter |
| Consent gates the token | `api/ai/sessions.py::start_session` returns `deepgram: null` while `consent_obtained` is falsy |
| Permission gates the token | `_require_encounter_read(encounter)` precedes every mint |
| The server chooses the model | `params` is assembled server-side from `AI Settings` in `mint_session_token` |
| Audio is not retained | `AI Settings.retain_audio = 0`; `AI Encounter Session.audio_retained = 0` on all 137 sessions on record (2026-08-20) |
| Long sessions rotate tokens | `refresh_deepgram_token` refuses any session not in `Recording`; client rotates 60 s before TTL |

**Known gap at the time of recording (not a defect in this decision):** the *consent* precondition
in step 4 is currently defeated by the client — `app/api/ai/session/route.ts` hardcodes
`consent_obtained: true` and the recorder auto-starts. The server-side gate described here is
correct and intact; the caller bypasses it. See
`docs/audit/practitioner/screens/03-encounter-deep-audit.md` §10.4 and P0-2 in its plan.

## References

- `CLAUDE.md` §3 (`ASR`, `Audio retention`), Rule 7, Rule 10
- ADR-005 (Frappe Cloud, Rule 3 suspended) · `adr-011-auth-eb-frappe-jwt.md` (BFF pattern)
- `integrations/deepgram.py` · `api/ai/sessions.py` · `api/ai/segments.py`
- `Healthcare_next_app`: `src/components/narzim/encounter/copilot/real-provider.ts`
- `docs/audit/DOCUMENTATION_HYGIENE_AUDIT.md` §3 (how this ADR's absence was found)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Recorded retroactively from the 2026-05-15 implementation, after the hygiene audit found 17 citations and no document |
