# ADR-118: Lock the bill, and refuse if it changed, before moving money

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

These steps read a bill, decide, and write, with nothing held between the read and the write:

- collect a payment;
- refund a bill;
- refund a cancelled appointment;
- reschedule with payment.

Two requests on the same bill can both pass the check and both pay out (`services/billing.py`
takes no row lock). The site runs MariaDB at `REPEATABLE-READ` with snapshot isolation on, so a
request reads from a snapshot taken at its first query. A request that only waits for a lock
then decides on numbers that are already out of date. Full analysis:
[design note](../flows/BILLING_CONCURRENT_MONEY_MOVES.md).

## Decision

Every money step calls `lock_for_money(doctype, name)` before it reads the bill or appointment it
will change. The helper:

- takes a row lock (`FOR UPDATE`);
- refuses with HTTP 409 when the row changed after the request began (MariaDB's own
  snapshot-isolation error, or an explicit before/after comparison);
- marks the row so a waiting request sees the change.

It covers `settle_invoice`, `create_credit_note`, `refund_appointment`, the balance-withdrawal
refund, the line replacement, and `reschedule_appointment_with_payment`.

## Alternatives Considered

1. **Row lock only (`SELECT … FOR UPDATE`).**
   - Pros: one line per step; standard.
   - Cons: at `REPEATABLE-READ` the waiting request resumes on its old snapshot, cannot see the
     first Credit Note, and refunds again. It does not fix the bug on this database.

2. **Row lock with a changed-since-start check (chosen).**
   - Pros: correct at `REPEATABLE-READ` with snapshot isolation on or off. No schema change
     (BE-9). It works for two clerks, not only one double-click. The refusal is a plain 409 the
     UI already shows.
   - Cons: the second request gets "refresh and try again" instead of a quiet no-op. `modified`
     on the bill moves when money moves.

3. **Idempotency key per request** (the browser sends a request id; the server stores and refuses
   repeats).
   - Pros: a replayed click returns the first result.
   - Cons: needs a new field or doctype and a migration (BE-9), plus a frontend change on every
     money screen. Two clerks send two different keys, so it does not stop them.

4. **Redis lock** (`frappe.cache` lock per bill).
   - Pros: no database lock held.
   - Cons: with Redis down, billing would either stop (against BE-7) or run unguarded. It also
     does nothing about the stale snapshot.

5. **Disable the button while saving, frontend only.**
   - Pros: trivial.
   - Cons: it cannot see another clerk's screen, and a direct API call bypasses it. It is kept
     as a courtesy, not as the guard.

## Consequences

- **Code:** new `services/billing.py::lock_for_money` and `BillingConflictError`, a subclass of
  `frappe.DuplicateEntryError`, so `handle_api_errors` returns 409. It is called at the start of
  the steps above.
- **Tests:** new `tests/billing/test_concurrent_money_moves.py`, with the second request on a
  second database connection.
- **Behaviour:** a second simultaneous click gets 409 "This bill was just changed by someone
  else". A later click gets the existing refusal ("Nothing left to refund", "has no
  outstanding balance").
- **Revisit** if a money step grows long enough that clerks wait noticeably, or if the
  database's isolation level changes.

## Verification

- `tests/billing/test_concurrent_money_moves.py`, with the second request on a second connection:
  passes, 4 of 4 (2026-10-01). On the code before this ADR, the three race cases end in a raw
  `QueryDeadlockError` (1020, "Record has changed since last read in table 'tabSeries'") — a 500
  for the clerk. The second refund was stopped only because both requests drew the next number
  from the same naming series, and this server runs with snapshot isolation on. A refund on
  another series, or a server with it off, has no such accident to rely on.
- The reschedule and billing suites (145 tests) fail only where they already fail on `dev`.

## References

- [Design note](../flows/BILLING_CONCURRENT_MONEY_MOVES.md).
- [ADR-115](adr-115-billing-without-permission-bypass.md): who may move money.
- [ADR-117](adr-117-replace-the-line-when-the-invoice-has-a-balance.md): the line replacement this
  also locks.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted by the product owner ("yes fix this also") |
