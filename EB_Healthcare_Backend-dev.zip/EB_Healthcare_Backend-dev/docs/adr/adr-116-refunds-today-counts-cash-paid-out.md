# ADR-116: "Refunds today" counts cash paid out, not credit-note face value

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

The Billing page's "Refunds today" card summed `abs(grand_total)` of today's return invoices on the
client (`billing-client.tsx`, `refundsToday`). A cheaper reschedule (ADR-114) returns the old line in
full, raises a replacement invoice and pays it from the credit, so part of a credit note never leaves
the till. Live example, appointment HLC-APP-2026-00819 on 2026-10-01: credit notes ACC-SINV-2026-01927
(1,320) and ACC-SINV-2026-01928 (1,000) read 2,320, but only 740 + 1,000 = 1,740 was paid out
(ACC-PAY-2026-01355, -01356); 580 moved to replacement invoice -01929 by journal entry ACC-JV-2026-00256.
The card therefore disagreed with the till by 580, while "Collected today" (Payment Entries of type
Receive) was already cash-based.

The Appointments list shows the badge "Refund Issued" whenever the appointment's original invoice has
status Credit Note Issued. After the same reschedule and a later cancellation, 580 is still held on the
replacement invoice and the Refund button is correctly offered (`canRefund` follows money held), so the
row reads "Refund Issued" next to a live Refund button.

## Decision

1. `list_all_invoices` returns `refunded_cash_total` beside `billed_total`: the cash paid out through
   the credit notes in the filtered set (submitted Payment Entry allocations against return invoices,
   the same definition as `_credit_note_refunded_cash`), computed in one batched query over every
   matching return, not only the current page.
2. "Refunds today" reads that field. Credit moved onto a replacement invoice is not a refund of cash.
3. The Appointments badge shows "Refund due" instead of "Refund Issued" when the appointment is
   Cancelled and money is still held; it keeps "Refund Issued" once nothing is held.
4. The invoice preview's Visit block falls back to Appointment Reschedule History
   (`replacement_invoice`, `additional_invoice`, `refund_credit_note`), also asking about the invoice a
   credit note reverses (`return_against`), when no line carries a
   `Patient Appointment` reference. Reschedule invoices leave that reference empty on purpose
   (`billing._create_reschedule_delta_invoice`), so ACC-SINV-2026-01929 showed Visit "—". Only
   appointment type and date are returned (ADR-101, PHI-6).

## Alternatives Considered

1. **Sum return face value (status quo).**
   - Pros: no change.
   - Cons: wrong whenever a credit note is partly carried to a replacement invoice; the card cannot be
     reconciled with the till.

2. **Compute cash-out on the client from the list rows.**
   - Pros: no backend change.
   - Cons: rows carry no cash-out figure, and the list is capped at 100 rows; a day with more returns
     silently under-counts (the reason ADR-102 moved totals server-side).

3. **Reuse the dashboard KPI endpoint.**
   - Pros: one source for clinic-wide KPIs.
   - Cons: the dashboard tile has no refund figure and ADR-099 scopes it clinic-wide; the Billing card
     must follow the page's own filters and permission scoping.

4. **A new `refunded_cash_total` on the invoice list (chosen).**
   - Pros: same filters and permission scoping as `billed_total`; exact regardless of page size; reuses
     the existing cash definition.
   - Cons: one extra batched query per list call.

Badge wording: relabel only (chosen) versus changing the invoice status mapping. Status is shared with
Billing's own badge and is correct there, so only the Appointments row changes.

## Consequences

- `list_all_invoices` response gains `refunded_cash_total` (additive; no caller breaks).
- The BFF route and `useInvoices` type pass it through; `refundsToday` stops summing rows.
- A refund today of a credit note dated an earlier day is counted under the credit note's own date,
  the same date rule as every other figure on the list. Re-evaluate if the card must follow the
  payment date instead.
- No schema change, no migration patch, no PHI.

## Verification

- `tests/billing/test_refunded_cash_total.py`: the 2026-10-01 example returns 1,740, not 2,320; a
  fully carried-over credit note returns 0; empty input returns 0.
- Live: Billing page shows Refunds today 1,740 for the asdv data above.

## References

- ADR-099, ADR-102, ADR-114
- `services/billing.py::_credit_note_refunded_cash`, `api/v1/billing/api.py::list_all_invoices`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-10-01 | Divyanshu (AI-assisted) | Decision 4 also covers a credit note via return_against (ACC-SINV-2026-01930) |
| 1.1 | 2026-10-01 | Divyanshu (AI-assisted) | Decision 4: invoice preview Visit falls back to reschedule history |
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Initial version |
