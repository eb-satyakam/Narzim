# ADR-088: An image is read from what it shows — a report template is a suggestion, and an unlabelled image gets none

**Doc status:** living · **Created:** 2026-09-23 by Divyanshu (AI-assisted) · **Updated:** 2026-09-23 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — requested by Divyanshu, 2026-09-23, after an unlabelled ultrasound was described as a kidney
- **Amends:** [ADR-080](adr-080-report-type-templates-for-lab-extraction.md) — the template is no longer binding on Stage 2, and Stage 1 no longer chooses or writes one for a document identified only from how a picture looks

- **Prompt file:** `multi_panel_extraction_v16.txt` was removed 2026-09-24 at the owner's request (not kept in the repo); the live prompt is `multi_panel_extraction_v21` (ADR-091).
---

## 1. Context

A single ultrasound JPEG was uploaded with no note. The only printed text on it was the
scanner's model name, "SAMSUNG RS85": no title, no labels, no report. (AI Prompt Log
`3jtnock9li`, prompt v15, `gpt-5-mini`.)

- **Stage 1** matched it to the clinic's only ultrasound template, "Radiology — Renal
  Ultrasound (Kidney)" (`TMPL-00044`, itself written by the model a day earlier).
- **Stage 2** was told the upload "has been identified as" that kind of report, and the v15
  prompt said the template's sections and guidance were "BOTH binding" and that it "wins" over
  the general rules.
- The output named a kidney, a renal sinus and "cortical thinning", and gave as its evidence
  for the body site: *"Study identified as 'Renal Ultrasound' in upload context"*.

The organ was never read from the picture. It came from our own template choice, and the model
then described the picture through it. A second opinion on the output flagged the wording as
over-confident; the larger defect was that the identification itself was imported.

Filenames were checked and are not a factor: no file name reaches any provider
(`integrations/openai.py::_content_part` sends images as bare data URLs and PDFs as
`report.pdf`). The rule this ADR serves is the one the product owner stated: **analyse the
content, never anything else.**

## 2. Decision

1. **Stage 1 records how it identified each document** — `identified_from`, exactly
   `printed_text` or `image_appearance` (schema field, prompt `report_template_select_v2`).
   A scanner or brand label does not count as printed text about the study.
2. **An `image_appearance` document gets no template, matched or written — enforced in code**
   (`services/lab_panel_extraction.py::_choose_report_template`), not trusted to the prompt.
   A missing or unrecognised value is treated as `image_appearance`: an image read without a
   template is still read; an image read through a wrong one is read as something it may not
   be. This also means a template is never *written* from an unlabelled picture.
3. **The template is a suggestion the document overrides** —
   `integrations/llm.py::build_report_template_instruction` and prompt
   `multi_panel_extraction_v16`. The document wins, and the prompt's own rules win, exactly as
   they already did over the uploader's note.
4. **Images are described from what is visible** (v16): an organ is named only when printed or
   clearly recognisable; `body_site` may be `"not identified"`; a template, note or file order
   is never evidence; tissue-judging words ("thinning", "debris", "mass", "collection", …) are
   not used unless the document prints them.

## 3. Options considered

| Approach | Pros | Cons |
|---|---|---|
| A. Skip the template for every image file (decide by file type) | Simple; no schema change | A phone photo of a printed lab report — the common WhatsApp case — is also an image, and would lose its template for no reason. Decides by container, not content |
| **B. Stage 1 reports how it identified the document; code skips image-only (chosen)** | Decided from the content, which is the requirement; photographed printed reports keep their template; enforced in code | One schema field and a prompt version; relies on Stage 1 telling printed text from a picture — a task it performs anyway |
| C. Reword the template as a hint, change nothing else | Smallest change | The model is still told "renal ultrasound" before it looks, and a weak hint still primes the reading; nothing enforced |
| D. A post-check that rejects diagnostic words in image observations | Catches symptoms whatever their cause | Treats the output, not the cause; a word list is never complete; does nothing about the wrong organ, which used only ordinary words |

A loses because it decides by file type, which breaks the rule it is meant to serve. C is kept
as part of B (decision 3) but is insufficient alone — the priming is the defect. D may still be
worth adding later as a second line; it does not remove the cause.

**What would falsify this:** a photographed printed report being marked `image_appearance` and
losing its template (check `classification_json` on photo uploads), or an unlabelled image
still returning an organ name with a template, note or "context" as its evidence.

## 4. Verified

Same file and patient re-run through the changed pipeline (AI Prompt Log `8pjoe2kmh1`, v16):
Stage 1 returned `identified_from: "image_appearance"` with no template; no template was
created; `body_site` came back `"not identified"` with the evidence *"No identifying text or
labels on the image; organ or body site cannot be determined from the picture alone."* The
description named no organ and used no tissue-judging word. The generated summary likewise
stated that no labels identify the organ or location.

Tests: `tests/labs/test_image_only_no_template.py` (17) — removed 2026-09-24 at the owner's request (not kept in the repo).

## 5. Not changed

A mixed upload still gets one template for the whole upload (the first document that yields
one), as recorded in ADR-080 — deliberately left as it is for now. An image-only document in
such an upload no longer chooses that template, but it may still be read alongside another
document's template, now framed as a suggestion the image overrides.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-24 | Divyanshu (AI-assisted) | Recorded that its prompt file and tests were removed at the owner's request |
| 1.0 | 2026-09-23 | Divyanshu (AI-assisted) | Initial version |
