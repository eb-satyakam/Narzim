# ADR-095: Encounter Canvas stores both editable stroke data and a rendered PNG

**Superseded by [ADR-097](adr-097-encounter-canvas-html-only-no-rendered-file.md)** — the "store
both" decision below was reversed the same day: `canvas_data` (raw HTML) is now the only stored
artifact, and `image` was removed entirely. This document is frozen as the record of why "store
both" was the original call and why `canvas_data` is `Code` not `Long Text` (that part of this
ADR's Consequences is unaffected and still true) — do not cite its Decision/Alternatives sections
as current.

**Doc status:** superseded · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-28 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Superseded
- **Date:** 2026-09-28
- **Supersedes:** —
- **Superseded by:** ADR-097

## Context

The Guided Encounter view (`v3/`) needs a sketch/annotation tool — a doctor drawing a diagram to
explain a diagnosis or procedure, per the product mockup. Two facts from the codebase shape this:

1. **There is no existing drawing surface anywhere in this app.** No `<canvas>` element, no
   `fabric`/`konva` dependency. `html2canvas-pro` exists in the frontend's `package.json`, but it
   rasterizes an existing DOM subtree to an image (used today for PDF/screenshot export) — it is not
   itself a drawing library.
2. **`Clinical Document` — this app's previous general "attach something to a patient" doctype — was
   deleted outright** on 2026-09-09 (`patches/v0/drop_clinical_document_20260909.py`), because any
   EB_-role user could enumerate and download any patient's private attachments through it, including
   ones marked permanently deleted. It was replaced by Narzim Drive, which is a deliberately separate
   permission model (copy-then-trash into the chart via `services/drive.py::move_to_patient()`), not
   built for a record that must live and be governed under one specific `Patient Encounter`.

A new doctype (`Encounter Canvas`, ADR pending its own doctype-shape decision — this ADR is scoped
to the storage-format question only) will hold one sketch. The product requirement (confirmed with
the requester) is that **one encounter can have multiple canvases**, which means a practitioner will
return to and build on these across a session, not just export a single flattened picture once.

The open question this ADR settles: when a canvas is saved, do we persist the flattened image, the
raw drawing data, or both?

## Decision

**Store both.** `Encounter Canvas.canvas_data` (`Code`, JSON — corrected 2026-09-28 from `Long
Text`; see Consequences) is the source of truth — every stroke, shape, text box and inserted
image, as structured data, matching the existing `Patient Import Session` pattern of a JSON
payload with `load()`/`store()` helpers rather than a child table (nothing needs to query inside
it; only the editor reads/writes it whole).
`Encounter Canvas.image` (Attach) is a PNG rendered from `canvas_data` via `html2canvas-pro` on the
client and uploaded through `utils.py::save_private_file()` — the same attachment path lab report
uploads already use. Every save regenerates `image` from the current `canvas_data`, so the two never
drift apart; `image` is never hand-edited independently of `canvas_data`.

Consequences:
1. Re-opening a saved canvas re-hydrates the editor from `canvas_data` — full undo/redo history is
   not preserved across a reload (only the current state is), but every stroke can still be erased,
   moved, or built upon, because the shapes are real data, not baked pixels.
2. Anything that just needs a picture — printing, attaching to a prescription once that flow exists —
   reads `image` directly. It never has to render `canvas_data` itself.
3. `canvas_data`'s JSON schema is owned by the frontend editor and treated as opaque by the backend
   (stored and returned verbatim, like `Patient Import Session.raw_rows`) — a schema change there
   does not require a backend migration.

## Alternatives Considered

1. **Flattened image only, no `canvas_data`.**
   - Pros: Simplest possible schema — one Attach field. Works immediately as an Rx/print attachment.
   - Cons: The moment a practitioner closes the tab, the drawing is a picture, not a drawing —
     nothing can be erased, moved, or continued. Directly contradicts the confirmed requirement that
     one encounter holds multiple canvases practitioners return to.

2. **`canvas_data` only, rendered on demand.**
   - Pros: Nothing to keep in sync; smallest write cost (no rasterization on every save).
   - Cons: Every consumer that just wants "a picture of this sketch" — a print view, a future
     prescription attachment, a list thumbnail — would have to render the DOM and rasterize it
     itself, on every read, in every context that needs one. That is real, repeated cost pushed onto
     every future caller to save one write-time `html2canvas-pro` call today.

3. **Versioned flattened images only — each save is a new PNG layered on the last.**
   - Pros: No new data format; "editing" is just drawing more.
   - Cons: Not real editing. A stroke from an earlier save can never be erased or moved, only painted
     over — the eraser tool in the mockup's own toolbar would not actually work across a reload.

4. **Both, one derived from the other (chosen).**
   - Pros: Satisfies both real requirements at once — editable indefinitely, and usable as a plain
     image everywhere one is needed, with the second derived cheaply from the first using a library
     already in the dependency tree.
   - Cons: One extra field, and `image` must be regenerated on every edit — the only cost, and it is
     the same `html2canvas-pro` call the client already needs to make to export at all.

## Consequences

- `Encounter Canvas` doctype carries both `canvas_data` (`Code`) and `image` (Attach); see
  `docs/ENCOUNTER_CANVAS.md` for the full field list and API surface, which this ADR does not restate.
- **`canvas_data`'s fieldtype is `Code`, not `Long Text` — corrected 2026-09-28, found live.**
  Frappe's own save-time HTML sanitizer (`base_document.py::_sanitize_content()`) runs
  unconditionally on any `Long Text`/`Text`/`Small Text` field whose value contains `<` or `>`,
  and silently stripped every SVG shape attribute (`cx`, `cy`, `r`, `stroke`, a path's `d`) out of
  a `canvas_data` value containing literal markup. This was not only a manual-Desk-testing risk:
  the identical sanitizer would corrupt correctly JSON-encoded `canvas_data` from a real frontend
  too, the instant any text on the canvas contained a `<` or `>` (a clinical annotation like
  `"BP < 90"` would trigger it the same way). `Code` is unconditionally exempt from this
  sanitizer, per its own docstring — the fix, not a workaround.
- `attach_to_rx` is stored on `Encounter Canvas` starting now, even though no prescription/Rx print
  flow exists yet to read it (confirmed: no hits for a print/Rx flow under `api/v1/encounters/`).
  It is cheap to carry the field now and avoids a schema migration later; it is inert until that flow
  is built.
- Re-evaluation trigger: if a future requirement needs full undo/redo history to survive a reload
  (not just the current state), `canvas_data` would need to become an append-only operation log
  instead of a snapshot — a breaking change to this ADR's schema, not a compatible extension.

## Verification

- `Encounter Canvas` doctype JSON declares both fields.
- `api/v1/encounter_canvas/api.py::save_canvas()` writes `canvas_data` from the request body and
  `image` from an uploaded rendered PNG in the same call, never one without the other.
- A saved canvas re-opened in the Guided Encounter view restores editable shapes, not a flattened
  picture — verified via `get_canvas()` returning `canvas_data` for the editor to re-hydrate from.

## References

- `docs/ENCOUNTER_CANVAS.md` — the mechanism doc (scope, fields, API, build order)
- `patches/v0/drop_clinical_document_20260909.py` — why `Clinical Document` is not the storage target
- `services/drive.py` — why Narzim Drive is not the storage target
- `remedisys_healthcare_ai/doctype/patient_import_session/patient_import_session.py` — the Long
  Text JSON payload pattern this ADR reuses
- `utils.py::save_private_file()` — the attachment path `image` is written through

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-28 | Divyanshu (AI-assisted) | Superseded by ADR-097 — `image` removed entirely; `canvas_data` (HTML) is now the only stored artifact. Marked `Doc status: superseded`; content frozen |
| 1.1 | 2026-09-28 | Divyanshu (AI-assisted) | `canvas_data` fieldtype corrected from `Long Text` to `Code` — Frappe's own save-time HTML sanitizer was silently stripping SVG attributes from any value containing `<`/`>`; found live |
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
