# ADR-117: Replace the appointment's line even when its invoice still has a balance

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

ADR-114 made each appointment's invoice line the only place its money lives, and made a cheaper
reschedule replace that line. The replacement runs only when every source invoice is fully paid
(`services/billing.py:2548`). Every other case falls back to older code:

- **Dearer reschedule, invoice with a balance.** A standalone delta invoice for "new fee incl.
  tax − cash paid" is raised, and the old invoice's unpaid balance stays open
  (`services/billing.py:2883-2923`). On `HLC-APP-2026-00820` (1,000 billed, 500 paid, moved to
  2,000 + 16 %) the patient owes 1,820 and is billed 2,320.
- **Cheaper reschedule, invoice with a balance.** This falls back to the legacy value-based return
  that ADR-114 replaced (`:2944-2945`).
- **Cancel, invoice with a balance.** The refund plan blocks it as `partly_paid` (`:2757`), so the
  cash already paid cannot be refunded (`:2789-2791`).

The preview (`_reschedule_quote`) already shows the right amount owed. Only the settlement is
wrong. ERPNext 16.26.2 lets a Credit Note larger than the original invoice's balance stand on its
own, to be reconciled later (`erpnext/controllers/accounts_controller.py:200-203`). The
cheaper-reschedule path already reconciles Credit Notes with `reconcile_dr_cr_note`.

Full analysis, worked examples and regression list:
[design note](../flows/RESCHEDULE_PARTLY_PAID_BALANCE.md).

## Decision

When an appointment's line can be identified, a reschedule or a cancellation returns that line in
full even if its invoice is not fully paid. The Credit Note pays, in order: (1) the unpaid balance
of the same invoice, (2) the replacement invoice for the new fee, (3) cash back for what is left.

1. **Dearer reschedule of an invoice with a balance** uses the replacement path. The patient owes
   the replacement's remainder, which equals the preview's figure.
2. **Cheaper reschedule of an invoice with a balance** uses the replacement path, not the legacy
   value-based refund.
3. **Cancelling an appointment whose invoice has a balance** is refundable through
   `appointment_refund_plan` / `refund_appointment`. The plan reports `balance_withdrawn`
   alongside `cash_back`.
4. **Fully paid invoices behave as today.**
5. **Shared checkout invoices with a balance** stay flagged until the accountant approves the
   proportional split (design note §4.4, Q2).
6. **No change** to the classifier, the preview numbers, the money-role checks (ADR-115), the manual
   Billing-tab refund (`create_credit_note`), or any doctype.

## Alternatives Considered

1. **Delta against what was billed, not what was paid. The old invoice stays open.**
   - Pros: a one-line change at `:2849`. On `HLC-APP-2026-00820` it raises 1,320, and 500 + 1,320
     is the correct 1,820 owed.
   - Cons: two open invoices for one visit, at different tax bases (the old one has none). The
     cheaper direction is not defined when billed > new fee > paid, so it still needs the legacy
     refund. It does not fix the cancel case. The preview (paid basis) and the settlement (billed
     basis) would then use different rules, the divergence `classify_reschedule_delta` was written
     to prevent.

2. **Replace the line, using the Credit Note first against the invoice's own balance (chosen).**
   - Pros: one open invoice per visit. It is the same model as ADR-114, so a later cancel is an
     ordinary refund. One rule covers dearer, cheaper and cancel. It uses ERPNext returns and
     reconciliation only, with no core change (BE-1). The settlement starts agreeing with the
     existing preview.
   - Cons: more documents per reschedule (a Credit Note, a reconcile and a replacement). Two
     helpers must learn that a Credit Note reconciled against its own invoice is neither cash nor
     credit moved elsewhere (design note §5, R1 and R2). Shared invoices need an accounting answer
     first.

3. **Cancel the old invoice and issue a new one at the new fee.**
   - Pros: the simplest books, with one invoice.
   - Cons: an invoice with a payment cannot be cancelled until the Payment Entry is unlinked or
     cancelled, which rewrites the cash record. The invoice number the patient holds becomes void.
     On a checkout invoice it also cancels other lines, which ADR-114 forbids. It is not reversible
     in the way a Credit Note is.

4. **Write off the old invoice's unpaid balance with a Journal Entry.**
   - Pros: few documents, and it reuses `_write_off_invoice`.
   - Cons: a write-off records forgiven revenue (a waiver or bad debt), but this is a withdrawn
     charge. It would mix into the waiver register and the "waiver reversed" figures of every
     later refund (`_reverse_write_off`), the confusion the 2026-09-14 Government fix removed.
     The line also stays on the old invoice, so a later cancel has the same problem again.

5. **Refuse to reschedule or cancel-refund until the invoice is fully paid.**
   - Pros: no new money code, and no wrong balances.
   - Cons: front desk would have to collect the old fee only to refund or top it up a minute later.
     Patients leaving mid-visit are stuck. It moves the gap into a manual Desk workflow rather
     than closing it.

## Consequences

- **Code:**
  - `services/billing.py`: the balance-aware replacement step, and the `_credit_note_reallocated`
    and `_appointment_funding` fixes (R1, R2).
  - `api/v1/appointments/api.py`: the history row records `replacement_invoice` on a dearer
    replacement.
  - Frontend Refund dialog: shows `balance_withdrawn`.
- **Tests:** two existing assertions change on purpose (`test_reschedule_payment.py:377`, `:388`),
  and nine new tests are added (design note §6).
- **Data:** no doctype or field change, so no patch (BE-9). Existing double-billed appointments
  are not corrected by this change (design note Q3).
- **Revisit** if fully paid dearer reschedules should also replace the line (Q1), or if the
  accountant chooses a non-proportional split for shared invoices (Q2).

## Verification

- `tests/appointments/test_reschedule_payment.py`: the nine new cases and the two re-asserted ones
  fail on `dev` and pass with the change (2026-10-01). The suite's other failures are the same on
  `dev` (design note §9).
- `tests/billing/` passes unchanged apart from the failures it already had (`docs/KNOWN_ISSUES.md`).
- On the dev site, the same steps as `HLC-APP-2026-00820` (1,000 billed, 500 paid, moved to
  2,000 + 16 %) left one open invoice for 1,820 (`ACC-SINV-2026-01935`). The old invoice's preview
  reads "Withdrawn by credit note 500", not a write-off.

## References

- [ADR-114](adr-114-appointment-line-owns-its-money.md): the appointment line owns its money.
- [ADR-115](adr-115-billing-without-permission-bypass.md): only money roles move money.
- [Design note](../flows/RESCHEDULE_PARTLY_PAID_BALANCE.md).
- [ADR-114 design note](../flows/RESCHEDULE_CANCEL_REFUND_LINES.md) §8 Q5.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted by the product owner; verification recorded |
| 0.1 | 2026-10-01 | Divyanshu (AI-assisted) | Proposed |
