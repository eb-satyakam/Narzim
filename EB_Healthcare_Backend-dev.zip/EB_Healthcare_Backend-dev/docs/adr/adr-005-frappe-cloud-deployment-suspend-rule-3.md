# ADR-005: Deploy on Frappe Cloud — suspend Rule 3 (service separation) for Phases 0–2

**Doc status:** living · **Created:** 2026-05-13 by Sarvesh-SocialAngel · **Updated:** 2026-05-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-05-13
- **Supersedes (partially):** Constitution Rule 3 (Service Separation), Section 5 (Tech Stack — FastAPI block), Section 6 (Repo Layout — `remedisys_ai_service/`), Section 12 deliverables 2/3/6.
- **Superseded by:** —

## Context

The Engineering Constitution Rule 3 requires a clean split: Frappe owns
transactional records and workflows; a separate FastAPI service owns
transcription, realtime orchestration, LLM reasoning, WebSocket handling, and
validation pipelines.

The team deploys to **Frappe Cloud**, which is a managed hosting environment
for Frappe apps. Frappe Cloud does not run arbitrary Python processes —
there is no place to put a `remedisys_ai_service` FastAPI container alongside
the Frappe site. Adopting Rule 3 as written would require provisioning a
second deployment target (Render, Fly.io, Railway, or self-managed VPS), a
second CI/CD path, and a second on-call surface, from day one — before we
know whether the streaming-audio architecture actually needs it.

We are at Phase 0. Phase 1 (transcription MVP) and Phase 2 (SOAP generation)
are the next clinical milestones.

## Decision

For **Phase 0, Phase 1, and Phase 2**:

1. **All Remedisys code lives inside the `remedisys_healthcare_ai` Frappe
   app.** Python modules for LLM orchestration, prompts, validators, and
   tool functions are organized under `remedisys_healthcare_ai/<area>/` and
   imported from Frappe whitelisted methods or background jobs.
2. **Long-running and CPU-bound work runs as Frappe RQ background jobs.**
   SOAP generation, transcript cleanup, context assembly all fit this model.
3. **Realtime fan-out to the browser uses Frappe's built-in SocketIO**, not
   a separate WebSocket server.
4. **The streaming Deepgram bridge is the one piece we cannot do inside the
   Frappe worker pool.** For Phase 1 we will first attempt a chunk-and-batch
   approach (client uploads short audio chunks → Frappe background job sends
   each to Deepgram → SocketIO emits transcript back). True streaming WSS to
   Deepgram is deferred until we have evidence that the batch latency is
   clinically unacceptable.
5. **Rule 3 (Service Separation) is suspended for Phases 0–2.**
6. **Deployment lock changes from "Docker Compose initially; K8s when scale
   demands it" to "Frappe Cloud (managed)."**

The decision to *re-instate* Rule 3 (i.e., split out a sidecar service) is
**deferred to Phase 1 architecture review**, after the chunk-and-batch
approach has been measured against real recordings.

## Alternatives Considered

1. **Build a separate FastAPI service from day one, deploy on
   Render/Fly/VPS, leave Frappe Cloud for the Frappe app only.**
   - Pros: matches the original Rule 3; no architectural debt; streaming
     ASR via raw WebSocket is straightforward.
   - Cons: two deployment targets, two CI pipelines, two infra bills, two
     on-call surfaces, from Phase 0. For a ~5-person team this is a
     significant ops tax for value we have not yet proven we need.

2. **Hybrid from day one: Frappe app + a tiny Deepgram WS bridge service
   elsewhere.**
   - Pros: minimizes external surface to one small service.
   - Cons: still introduces a second deployment now. Better made as a
     Phase 1 evolution once we know the bridge is required.

3. **In-app for all phases (chosen for Phases 0–2; revisit later).**
   - Pros: single deployment target; matches the team's existing
     operational model on Frappe Cloud; lets us land Phase 0/1/2 without
     paying ops tax we may never need to pay.
   - Cons: streaming ASR is harder inside Frappe's worker model; we may
     have to split later. We accept that risk in exchange for not
     pre-building.

## Consequences

### Constitution amendments

- **Section 3 (Locked Assumptions)** — two rows change:
  - `Background jobs` row: `Frappe RQ background workers (in-app); FastAPI/Celery deferred — see ADR-005`
  - `Deployment` row: `Frappe Cloud (managed) — see ADR-005`
- **Section 4 Rule 3** — marked SUSPENDED for Phases 0–2; FastAPI mentions
  in the rule text are aspirational, not current.
- **Section 5 (Tech Stack)** — the "AI Service Layer" and "Realtime"
  blocks describe a future state; current state is "Python modules inside
  the Frappe app + Frappe RQ + Frappe SocketIO". To be rewritten when
  Phase 1 architecture is finalized.
- **Section 6 (Repo Layout)** — the `remedisys_ai_service/` and `infra/`
  trees are not built. The `docs/` tree (ADRs, threat model, retention
  policy) lives inside `apps/remedisys_healthcare_ai/docs/`.
- **Section 12 (First Task)** — deliverables 2 (`remedisys_ai_service`
  skeleton), 3 (FastAPI half of WS JWT), and 6 (`docker-compose.yml`) are
  dropped from Phase 0. The trimmed Phase 0 list is:
  1. ✅ Frappe app skeleton — installs/uninstalls (done 2026-05-13)
  2. ~~FastAPI skeleton~~ — dropped
  3. ~~WebSocket JWT auth (Frappe + FastAPI)~~ → reduced to "Frappe-side
     auth check on existing SocketIO channels"
  4. Install/uninstall CI test — still required
  5. ADR template + ADR-001, ADR-002, ADR-003 — ADR-001 and ADR-002 to be
     reworded (they assumed FastAPI); ADR-003 unchanged
  6. ~~docker-compose.yml~~ — dropped
  7. Threat model document — still required
  8. Retention policy document — still required
  9. BAA/DPA tracking — still required

### Rule-7 implication

Rule 7 ("AI failure must not break healthcare") becomes both easier and
harder. Easier because there is no separate service to crash. Harder
because a misbehaving AI module *inside* the Frappe app can poison the
Frappe worker pool. Mitigation:

- All LLM and Deepgram calls run only in background RQ jobs, never in the
  request path of the Patient Encounter form.
- Worker timeouts are configured aggressively.
- The Patient Encounter form is fully usable with all `remedisys_ai`
  background jobs disabled; this is verified by Phase 6 chaos drills.

### Re-evaluation trigger

The decision to split out a sidecar service is **forced** by any of:

- Streaming ASR latency requirement that chunk-and-batch cannot meet.
- LLM call volume that consistently saturates Frappe RQ workers.
- A customer compliance requirement that forbids LLM calls from the same
  process as the EHR.

We will revisit this ADR at the Phase 1 architecture review (post Phase 0
exit gate) and again at the Phase 2 exit gate.

## Verification

- After this ADR, Phase 0 exit gate is redefined: install/uninstall CI green,
  Frappe SocketIO emits a test event from a whitelisted method against
  real Frappe session, compliance docs reviewed. The "WS auth round-trip
  against real Frappe session" originally meant FastAPI-issued JWT —
  redefined to "Frappe-side auth check on a SocketIO channel".

## References

- Engineering Constitution, Section 3 (Locked Assumptions)
- Engineering Constitution, Section 4 Rule 3 (Service Separation)
- Engineering Constitution, Section 5 (Tech Stack)
- Engineering Constitution, Section 6 (Repo Layout)
- Engineering Constitution, Section 12 (First Task)
- ADR-004 (Frappe v16 lock)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-05-13 | Sarvesh | Initial version (header backfilled from git history) |
