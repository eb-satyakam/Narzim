# ADR-029 — AI Patient Clinical Summary

**Doc status:** living · **Created:** 2026-07-22 by Divyanshu · **Updated:** 2026-07-22 by Sarvesh-SocialAngel · **Version:** 1.0

- Status: Accepted
- Date: 2026-07-21
- Supersedes: none
- Related: ADR-026 (LLM provider allowlist), Rule 5 (no full-history dumping),
  Rule 6 (physician in control), Rule 10 (no PHI in logs)

> **AMENDMENT (2026-07-22) — rolling summary + full record + event-driven refresh.**
> The original design below (bounded recent-slice per source, generated at view
> time, with a live preview of the in-review report) is superseded by the
> following. The Decision/Consequences sections above the amendment describe the
> first iteration; where they conflict with this amendment, the amendment wins.
>
> **1. Full record, not a recent slice.** The summary reads *every* related record
> for the patient, so the clinical picture is complete (product decision). This
> deliberately relaxes Rule 5's bounded-slice stance. The only remaining bound is
> a high safety ceiling on the one voluminous source — **lab analyte rows
> (`_LAB_ROW_CEILING = 1000`)** — kept solely so a very long-history patient can't
> overflow the model's context window and make the call fail. Every other source
> is unbounded (`get_all limit=0`).
>
> **2. Broader sources.** Adds the **Patient** doctype (demographics: sex, age,
> blood group; plus `allergies` and `medical_history`, which is where allergies &
> conditions actually live — same store as `api/v1/clinical`), **Clinical
> Procedure**, and **Patient Appointment**, on top of the original Lab Test,
> Medication Request, Immunization, Patient Encounter, Vital Signs.
>
> **3. Rolling (incremental) summary — the reason full-record is affordable.**
>   - *First time / manual Regenerate (`rebuild`) / no prior summary* → read the
>     FULL record and generate.
>   - *Any later change* → read ONLY what changed since a stored watermark
>     (`last_synced_at`) and hand the model the existing summary + that delta to
>     revise in place (`build_clinical_summary_update_instruction`). The prompt
>     stays small regardless of history size.
>   - *Nothing changed since the watermark* → no LLM call at all.
>   The watermark is captured **before** the gather and advanced **only on
>   success**, so a failed run retries the same delta and an incremental failure
>   keeps the last good summary visible (status stays Success) instead of erroring.
>
> **4. Not generated at view time — event-driven + debounced.** A `doc_events`
> hook (`on_patient_activity`) on Lab Test, Vital Signs, Patient Encounter,
> Medication Request, Immunization, Clinical Procedure, Patient Appointment and
> Patient marks the row Summarizing and enqueues **one deduplicated background job
> per patient** (`job_id="clinical_summary::<patient>"`, `deduplicate=True`), so
> several edits in a visit collapse into a single regeneration. The Summary tab and
> review dialog only READ the stored row (polling while Summarizing). The dialog's
> live preview of the unsaved report is dropped — the report is summarized after
> Done, when saving the Lab Tests fires the same hook. Our own AI doctypes are
> excluded from the trigger (`_SKIP_DOCTYPES`) to prevent a regeneration loop.
>
> **5. Performance.** Patient demographics read via `get_cached_doc`; a migration
> patch (`index_clinical_summary_sources_20260722`) ensures a `patient` index on
> the six list-source doctypes (DB-level, idempotent, upgrade-safe — no core file
> changes).
>
> **6. New field.** `AI Patient Clinical Summary.last_synced_at` (Datetime) holds
> the rolling-summary watermark.
>
> Rule 6 floor is unchanged: advisory only, labelled unverified, never written to
> the clinical record; no treatment/plan produced. Rule 10 unchanged: no patient
> content in AI Prompt Log.

## Context

Clinicians reviewing a patient want a single at-a-glance read of the patient's
current clinical picture drawn from data that already lives in the EHR — recent
lab results, active medication requests, immunization history, encounters, and
vital signs — plus an AI-suggested "what is the problem / what would be the
differential" framing to orient the review.

Today the platform has only a patient-wide **lab** summary
(`services/lab_result_summary.py::generate_patient_summary`, purpose
`Patient Lab Summary`) which is (a) labs-only and (b) explanation-only. The
product ask is broader: read across five doctypes and add a suggested problem
list and differential, and persist it so the Summary tab can show it without
recomputing every open.

## Decision

Add a **new custom doctype `AI Patient Clinical Summary`**, one row per patient
(`autoname: field:patient`), regenerated in place. A request-time service
gathers a **structured, token-budgeted** snapshot (Rule 5) from Lab Test,
Medication Request, Immunization, Patient Encounter, and Vital Signs, sends it
through the pluggable LLM layer (ADR-026), and stores a bilingual
`summary` / `problem` / `diagnosis` on the doctype. The Patient 360 "Summary"
sub-tab reads the stored row.

### Safety model (Rule 6)

The user chose "auto-generate and display" (no manual approval gate). We honor
that **with a hard floor**:

- The output is stored **only** on this advisory doctype. It is **never**
  written into the authoritative clinical record — no Diagnosis/Condition row,
  no ICD code, no encounter field is created or mutated from it.
- The `diagnosis` field holds an **AI-suggested differential**, surfaced in the
  UI as "AI-generated · not a verified diagnosis · for reference only" and
  never presented as a finalized clinical decision.
- No treatment/plan/dosing is generated (consistent with the lab-summary
  precedent).

This keeps the AI a non-authoritative assistant (Rule 6's core: AI never
finalizes a clinical decision autonomously; its contribution is tracked
separately), while delivering the requested always-visible summary.

### Retrieval budget (Rule 5)

The service pulls only a bounded, recent slice per doctype (most-recent N,
newest first), as structured fields — never a raw dump of full history. The
exact caps live in `services/patient_clinical_summary.py` and are logged as
`source_counts` on the row for provenance.

### Audit (§9 / Rule 10)

Every generation is logged to `AI Prompt Log` (new purpose
`Patient Clinical Summary`) with model, prompt version/hash, tokens, cost,
latency — never the patient content (Rule 10). The clinical text itself lives on
the doctype (its intended store), not in logs.

## Consequences

- One new doctype, gated by the existing `AI Settings.enable_lab_extraction`
  flag (same master switch as the other AI lab features) so it ships OFF and is
  enabled per-environment behind the compliance gate.
- Uninstall-safe: the doctype belongs to `remedisys_healthcare_ai`; removing the
  app drops the advisory rows and leaves every core clinical record untouched
  (Rule 2), because nothing was ever written into them.
- A new provider still only needs the shared `summarize_patient_clinical`
  interface (ADR-026), same as the other summary calls.

## Alternatives considered

- **Reuse `AI Prompt Log` as the store.** Rejected: the log is an append-only
  audit trail, not a queryable per-patient record; "one current summary per
  patient, regenerated in place" is a document, not a log line.
- **Physician-approval gate before display.** The safer Rule-6 shape, but the
  product owner explicitly chose auto-display; the advisory-doctype + label +
  no-write-to-record floor is the compromise that keeps it non-authoritative.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-22 | Sarvesh | Initial version (header backfilled from git history) |
