# ADR-112: Real Booked→Paid and Submitted→Paid funnels for Check-in Rates and Claims Status

**Doc status:** living · **Created:** 2026-09-28 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-28 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** the "blocked" status of Check-in Rates and Claims Status in ADR-111
- **Superseded by:** —

## Context

ADR-111 found Check-in Rates and Claims Status blocked: the design (`Reports v3.dc.html`'s `CH` map)
shows both as a 4-stage `funnel`, and neither report's backend computed sequential stages —
Check-in Rates measured arrival punctuality (early/on-time/late/no-show), and Claims Status had 3
mutually-exclusive status buckets, not 4 ordered ones. Anant directed (2026-09-28) to build both
real funnels rather than leave them blocked. Before writing code, the actual fields behind each
funnel stage were checked (not assumed):

**Check-in Rates — `Booked → Arrived → Seen by doctor → Paid at checkout`.** Every stage already
has a real, proven query pattern elsewhere in this same file (`api/v1/appointments/report.py`):
- Arrived: `Patient Appointment.custom_checked_in_at` is set — the exact field
  `_build_check_in_rates` (line 1668) already reads.
- Seen: the first `Patient Encounter` per appointment — the exact join
  `_build_queue_wait_times` (line 1364) already performs.
- Paid: the linked `Sales Invoice` (`ref_sales_invoice`) has `outstanding_amount == 0` — the exact
  join used twice already in this file (lines 589-621, billing reconciliation; and 1130-1144).

No new schema. This is a new aggregation function combining three patterns this file already trusts.

**Claims Status — `Submitted → Documents complete → Approved → Paid`.** `Insurance Claim` is core
ERPNext Healthcare (`apps/marley/healthcare/healthcare/doctype/insurance_claim/insurance_claim.json`)
— Rule 1 forbids editing it; nothing here does. Its real fields:
- `status`: `Draft | Submitted | Completed | Cancelled | Error` — matches the existing
  `_CLAIM_BUCKET` mapping in `api/v1/insurance/report.py:34`.
- `approved_amount`, `rejected_amount`, `paid_amount`, `outstanding_amount` — all real `Currency`
  fields on the doctype, currently read by nothing in this report.

Three of the four stages map cleanly: Submitted = `status != "Draft"`; Approved = `status ==
"Completed"`; Paid = `paid_amount > 0`. **"Documents complete" has no field at all** — verified by
reading every field on the doctype. The honest options were: drop the stage (a 3-stage funnel, not
matching the design); invent a status nothing tracks (fabrication, the exact thing refused for
Chronic Care and Immunization Rates in ADR-111); or use a real, already-existing Frappe mechanism —
attached files (`File.attached_to_doctype/attached_to_name`) — as a labelled proxy. The last is
chosen: it is real, measurable data (a claim genuinely has attachments or doesn't), not an invented
number, and the funnel step is labelled by what it actually counts.

This is a materially lower-stakes call than Chronic Care's clinical thresholds: no patient-safety
consequence, `Insurance Claim` has zero rows in this environment today (`docs/reports/HIDDEN_REPORTS.md`),
and "claims with at least one attachment" is a defensible, inspectable operational proxy rather than
a clinical judgment about a person's body. It is flagged here, not silently assumed, so it can be
revisited if a real "documents complete" concept is added to the workflow later.

## Decision

**Both funnels are new, additive backend aggregations — `charts.funnel` on each report — and become
each page's sole chart, replacing the punctuality/status charts that answered the wrong question.**

1. **Check-in Rates**: `_build_check_in_rates` (`api/v1/appointments/report.py`) gains a cumulative
   funnel count — each stage is a strict subset of the one before it, same convention
   `_build_patient_flow`'s funnel already uses ("reached" means got this far or further, so it
   decreases monotonically by construction, not by clipping). The existing punctuality KPIs
   (`on_time_pct`, `early_pct`, `late_pct`, `no_show_pct`, `median_late_min`) and their `coverage`
   block are **kept** — they measure arrival promptness, a real and different question from
   completion-through-payment, the same reasoning ADR-111 used to keep Diagnosis Trends' and Average
   Visit Time's extra charts. What's replaced is the **chart area**: the bar-by-weekday, trend line,
   and arrival-status pie all visualised the same punctuality numbers the KPI strip already states;
   the funnel is a materially different, additional fact, so it takes over as the report's one chart
   and the three redundant chart visualisations are removed (not the underlying KPI numbers).
2. **Claims Status**: `_build_claims_status` (`api/v1/insurance/report.py`) gains the same
   cumulative-funnel treatment. `submitted`, `approved`, `rejected` KPIs (already real, already
   correctly derived from `status`) are kept; the existing `status` pie chart and `by_insurer`/
   `approval_trend` charts are replaced by the funnel as the sole chart, since they visualise the
   same 3-bucket status split the KPI strip already states, and the funnel is the new, additional
   fact matching the design.
3. Frontend (`remedisys-ai-ehr`): both pages import `FunnelChart` from `v3-charts.tsx` (already
   built, unused until now) and render it as the sole chart; the KPI strips are unchanged.

**Not built**: the design's own KPI figures for Check-in Rates ("Confirmed patients 97%," "Unconfirmed
78%") are WhatsApp-confirmation rates — already named in `docs/reports/18-reports-v3-redesign.md` §5
as a figure nothing measures. Not reopened here; the existing, real punctuality KPIs stay in that
strip instead.

## Alternatives Considered

1. **Drop "Documents complete," ship a 3-stage Claims funnel.**
   - Pros: no proxy, no interpretation call.
   - Cons: visibly diverges from the design's 4 stages on the one field that's genuinely missing,
     when a real, labelled proxy exists and is not clinical/safety-sensitive.
2. **File-attachment count as "Documents complete" (chosen).**
   - Pros: real, inspectable, measurable data; matches the design's stage count; clearly labelled so
     it can be revisited if a real completeness concept is added later.
   - Cons: "has an attachment" is not verified to mean "the claim's paperwork is actually complete" —
     an operational assumption, not a guarantee. Mitigated by the label and this ADR's record of the
     choice; zero live rows today means zero immediate exposure.
3. **Replace the KPI strips too, not just the charts, so each report shows only funnel-derived
   figures.**
   - Pros: maximal design literalism.
   - Cons: throws away real, already-correct numbers (on-time %, approval rate) that answer questions
     the funnel doesn't — the same reasoning ADR-111 used repeatedly to keep some "extra" content
     when it answered a different real question, not a duplicate one.
4. **Keep all existing charts AND add the funnel (six charts total across the two pages).**
   - Pros: nothing removed.
   - Cons: the existing charts visualise the exact same numbers the KPI strip already states (unlike
     Diagnosis Trends' by-category breakdown, say, which is genuinely different data) — keeping them
     next to the funnel is redundant chart clutter, not a second real question answered.

## Consequences

- Backend: `api/v1/appointments/report.py` (`_build_check_in_rates` gains `charts.funnel`),
  `api/v1/insurance/report.py` (`_build_claims_status` gains `charts.funnel`, reads `approved_amount`/
  `paid_amount`/`outstanding_amount` for the first time, and queries `File` for attachment counts).
- Frontend: `check-in-rates/page.tsx` and `claims-status/page.tsx` — `FunnelChart` becomes the sole
  chart; bar-by-dow/trend/pie (check-in) and status-pie/by-insurer/approval-trend (claims) removed
  from the page, not from the backend response (same "field still returned, unread" pattern as every
  prior ADR-111 removal).
- `docs/reports/18-reports-v3-redesign.md` §7 and `docs/reports/API.md` updated with the new
  `charts.funnel` shape for both reports.
- Re-evaluation trigger: if `Insurance Claim` gains a real documents-complete concept (a checklist,
  a required-attachment rule), the file-attachment proxy is replaced with it — this ADR is revisited
  for that one stage, not reopened wholesale.

## Verification

- Backend: new `tests/appointments/test_check_in_funnel.py` (4 tests) and
  `tests/insurance/test_claims_funnel.py` (5 tests) — cumulative-decrease, the empty case makes no
  query, a claim with no invoice is never "paid," a Draft claim never reaches "submitted," Cancelled/
  Error claims never reach "approved." **Written and hand-verified line-by-line against the actual
  function code, but not executed**: importing `api/v1/appointments/report.py` (via
  `services/billing.py` → core Healthcare → ERPNext → `frappe.utils.pdf`) hits the same pre-existing,
  already-documented bench-wide breakage as `tests/notifications/test_notify.py` ("`bench run-tests`
  is broken bench-wide... verified via bench console instead") — a missing `cssutils.log` path when
  `frappe.logger()` is called outside an initialized site context. Not introduced by this change; not
  fixed by it either. Re-run once a live bench/site is available.
- Frontend: TypeScript (`tsc --noEmit`) and ESLint clean on both touched pages.
- `Insurance Claim` has zero rows in this environment — the Claims Status funnel renders its empty
  state, not fabricated data; verified this is the same `has_data`/empty-state pattern already used
  elsewhere in this report.

## References

- [ADR-111](adr-111-reports-v3-chart-parity.md) — the blocked-report finding this ADR resolves for
  two of its six.
- `docs/reports/18-reports-v3-redesign.md` §5 — the WhatsApp-confirmation KPI figures this ADR does
  not build, and why.
- `CLAUDE.md` Rule 1 (no core doctype edits — `Insurance Claim` is core Healthcare), §10
  (doc-before-code, four-approaches for consequential decisions).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Anant Sharma (AI-assisted) | Initial version |
