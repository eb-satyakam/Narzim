# ADR-097: Encounter Canvas stores only canvas_data (HTML) — no rendered file, no `image` field

**Doc status:** living · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-28 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** ADR-095's storage-format decision ("store both `canvas_data` and a rendered `image` PNG")
- **Superseded by:** —

## Context

ADR-095 decided `Encounter Canvas` would store both `canvas_data` (the editable source of truth)
and `image` (a PNG rasterized from it client-side via `html2canvas-pro`, uploaded as an Attach
file). That decision assumed a real frontend would always be the thing producing `canvas_data`,
in a small, predictable shape ("strokes, shapes, text and inserted images" — see ADR-095's own
Decision), with `image` as the reliable, simple thing to render a thumbnail from.

Two live findings broke that assumption, both surfaced 2026-09-28 testing directly in Desk (still
the only way to create these records — no frontend exists yet):

1. **`canvas_data` is not always a small structured payload — it can be an entire, real HTML
   document.** A live test record (`ENCVS-2026-00004`) has a `canvas_data` value that is a full
   `<!DOCTYPE html>` page: a `<head><style>` block defining `.stroke { fill:none; stroke:#4385ee;
   stroke-width:7 }` and `.name {...}`, and a `<body><svg>` whose `<path class="stroke">` /
   `<text class="name">` elements depend on that stylesheet to render correctly at all.
2. **A regex-based "extract just the `<svg>...</svg>` substring" fallback (added one commit
   earlier, in response to "IN PMR we have to show the image of the html too") is provably wrong
   for exactly this case.** It slices out the `<svg>` element but leaves the `<style>` block
   behind in the `<head>`, outside the slice. SVG's own defaults are `fill="black"`,
   `stroke="none"` — with the class rules gone, every open, multi-segment stroke path in the
   drawing auto-closes and fills solid black. Verified directly: the extracted fragment
   (`extracted.svg`, 3704 bytes) contains `class="stroke"` on every path and `class="name"` on the
   text, but zero `<style>` tags. The practitioner's actual drawing — a clean blue signature named
   "Divyanshu" — renders in the encounter's Medical Record entry as a black smudge. Not a display
   glitch: the stored source is intact and correct; only the *rendering* of it is wrong.

Separately, and independently of the bug: the explicit direction (given twice, in these words) is
**"in canva we will store only html not any file"** — a real design decision, not just a bug
report. `canvas_data`'s schema was always meant to be opaque and frontend-owned (ADR-095's own
Consequences say so) — the correct fix is not a second, cleverer regex that also carries along a
`<style>` block (still fragile: breaks the moment the real schema puts CSS somewhere else, uses a
`<link rel=stylesheet>`, or isn't SVG at all), it is to stop trying to parse `canvas_data` on the
backend altogether and render exactly what is stored, verbatim, the same way a browser would if you
opened the file directly.

## Decision

**Drop the `image` field. `canvas_data` (raw HTML, `Code` fieldtype) is the only artifact stored.**
Rendering a thumbnail no longer parses, slices, or rasterizes `canvas_data` in any way — it embeds
the stored HTML **verbatim** inside a sandboxed `<iframe src="data:text/html;charset=utf-8;
base64,...">` in the encounter's Medical Record entry. Whatever the frontend (or, today, a
practitioner in Desk) put in `canvas_data` is exactly what renders, because nothing on the backend
interprets its structure.

`sandbox=""` (empty — the most restrictive value) is set on that iframe: it disables script
execution, forms, top-navigation and popups, while still rendering markup and CSS. This is a real
requirement, not defense in depth for its own sake — `canvas_data`'s fieldtype (`Code`) is
*unconditionally exempt* from Frappe's save-time HTML sanitizer (`base_document.py::
_sanitize_content()`, the whole reason it is `Code` and not `Long Text`, per ADR-095's own
Consequences). A `<script>` tag placed in `canvas_data` survives a save completely untouched;
rendering it in an unsandboxed iframe would execute it. `sandbox=""` is what makes "render whatever
is stored, unparsed" safe to do at all.

A canvas with no `canvas_data` content yet (freshly created, metadata-only) still falls back to its
bare name/title as plain text — unchanged from before, and still the safety net for anything that
isn't real markup.

## Alternatives Considered

*(This is the same four-approaches comparison presented to and approved by Divyanshu before any
code changed — reproduced here as the ADR's permanent record, per §10.)*

1. **Patch the existing regex-slice to also carry along any `<style>` block(s) it finds, inlining
   them into the extracted `<svg>` before embedding it.**
   - Pros: Smallest possible change; keeps the existing `<img>`-based embedding, which is already
     known-safe (a script inside an `<img>`-loaded SVG never executes, per spec).
   - Cons: Still a heuristic slice of an explicitly opaque, frontend-owned schema (ADR-095) — it
     silently breaks again the instant the real shape isn't "exactly one `<svg>` plus one
     `<style>` block" (an external stylesheet, multiple SVGs, a real `<canvas>`+JS drawing).
     Papers over the actual instruction ("store only html... render that html directly") with
     another special case tuned to today's one test record.

2. **Render the stored `canvas_data` verbatim in a sandboxed `<iframe>`, no parsing at all
   (chosen).**
   - Pros: Matches the instruction literally — whatever is stored is what renders. Cannot go stale
     as the real frontend schema evolves, because it never inspects the schema. `sandbox=""`
     closes the one real safety gap this approach opens (unsanitized `Code` content executing).
   - Cons: An iframe in Patient History's timeline is a new kind of element there — needs explicit
     sizing (confirmed via `patient_history.js`: entries render through raw jQuery `.append()`,
     with no client-side sanitizer stripping anything and nothing sizing an unknown element
     either). A future `<canvas>`+JS-only drawing (no static markup at all) would render blank
     with scripts disabled — an honest limitation, not a hidden one: no design here can safely
     execute arbitrary stored script in Desk.

3. **Drop rungs 2/3 entirely, require a real rendered `image` PNG always present** (revert to
   ADR-095's "store both, PNG is authoritative" design, strictly enforced).
   - Pros: Simplest possible rendering code — one `<img src=data-uri>` path, zero CSS/SVG edge
     cases.
   - Cons: **Directly contradicts the explicit instruction.** Also regresses Desk-only testing
     (the only way to exercise this feature today, with no frontend built) back to "no picture at
     all," since nothing in Desk can produce a rendered PNG.

4. **Server-side rasterize `canvas_data` → PNG at save time** (a headless browser or
   `wkhtmltoimage`), so a real raster image is always available without any client upload.
   - Pros: A real rendering engine handles arbitrary CSS/SVG correctly, by construction; satisfies
     "no file, just HTML" in the sense that the PNG becomes a derived cache, not an upload.
   - Cons: A genuinely new, heavyweight runtime dependency not in the locked stack (§3/§11
     requires justifying that against the locked stack) — a headless-browser binary is not
     guaranteed available on Frappe Cloud's managed workers, and a synchronous per-save browser
     launch is slow and resource-heavy for what is, today, a Desk preview thumbnail. Disproportionate
     to the problem.

**Chosen: 2.** It is the only option that survives `canvas_data`'s schema actually being opaque —
which ADR-095 already said it was, and which this exact bug just proved in practice. Option 3
contradicts the explicit instruction outright. Option 4 adds a locked-stack violation for a
thumbnail. Option 1 is smaller but provably fragile: it broke on the very next real-world input it
saw.

**What would falsify this choice**: if Frappe Desk's own CSP ever blocks `data:` iframes outright
(would need a different embedding mechanism, e.g. a dedicated preview route instead of a data URI),
or if the rate of `canvas_data` values that are pure `<canvas>`+JS drawings with no static
fallback markup turns out to be high enough that "renders blank" is a frequent, not rare,
practitioner-facing failure — at which point option 4 would need to be revisited despite its cost.

## Consequences

- `Encounter Canvas.image` (Attach) is removed from the doctype. `save_canvas()` no longer accepts
  `image_base64`; nothing calls `utils.py::save_private_file()` from this module anymore.
  `list_canvases()` / `get_canvas()` no longer return an `image` field.
- `canvas_data` is no longer treated as JSON by the API layer. `save_canvas()` previously did
  `doc.canvas_data = json.dumps(_parse(canvas_data), default=str)` — that normalization is gone;
  whatever string the caller sends is stored verbatim. `get_canvas()` returns it as a plain string,
  not a parsed object. `EncounterCanvas.load_canvas_data()` (a JSON-parsing helper) is removed —
  there is no JSON to parse.
- The doctype JSON's `canvas_data.options` changes from `"JSON"` to `"HTML"` (a `Code` field's
  `options` only selects its editor's syntax-highlighting mode — this has no effect on validation
  or storage, it is a UI-only correction now that the field's real contents are HTML, not JSON).
- `services/encounter_summary_sync.py::_build_canvas_summary()` drops the three-rung fallback
  (`image` → regex-sliced SVG → plain text) for a two-rung one: `canvas_data` present → rendered
  verbatim in a sandboxed iframe; `canvas_data` blank → plain-text name/title, unchanged.
- Existing `Encounter Canvas` rows that had `image` set lose that data when the column is dropped
  (`patches/v0/drop_encounter_canvas_image_field_20260928.py` logs which rows were affected before
  the drop; no data migration, since every existing row is dev/test data the user already
  confirmed disposable, and none of it is live patient data — no frontend has ever created a real
  one).
- `attach_to_rx` / `print_mode` are unaffected — they remain inert until a print/Rx flow exists
  (ADR-095), and that future flow will need to render `canvas_data` itself (e.g., print the raw
  HTML), not read a PNG that no longer exists.
- Re-evaluation trigger: if a future requirement needs a *non-Desk* consumer of a canvas thumbnail
  that cannot render an iframe (an email digest, a PDF export, a report that only accepts raster
  images), that consumer will need its own rasterization step — this ADR does not provide one.

## Verification

- `Encounter Canvas`'s doctype JSON no longer declares `image`; a fresh `bench migrate` drops the
  column (confirmed via `patches/v0/drop_encounter_canvas_image_field_20260928.py`, which runs
  first and logs any row that had one).
- A canvas saved with `canvas_data` equal to the live HTML document that surfaced this bug
  (`full_canvas_data.html`, the "Divyanshu" signature) renders its actual blue-stroke drawing in
  the encounter's Medical Record entry, styling intact — not a black-filled shape, and not the
  regex-sliced fragment from before.
- A canvas saved with a `<script>alert(1)</script>` planted inside `canvas_data` does not execute
  it when the encounter's Medical Record entry is viewed (`sandbox=""` blocks script execution
  regardless of what `canvas_data` contains).
- A canvas with blank/no `canvas_data` still renders as plain text (its name/title) — the rung-3
  safety net from before is unchanged.

## References

- `docs/adr/adr-095-encounter-canvas-storage-format.md` — the decision this ADR supersedes (the
  "store both" call, and why `canvas_data` is `Code` not `Long Text`, which remains true and
  unaffected)
- `docs/adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md` — the PMR-surfacing
  mechanism this ADR's rendering change plugs into; its own core decision (custom fields + sync
  helper) is unaffected, only the "how do we render a Canvas's picture" sub-mechanism changes
- `docs/ENCOUNTER_CANVAS.md` — the mechanism doc, updated alongside this ADR
- `apps/healthcare/healthcare/healthcare/page/patient_history/patient_history.js` — confirms entries
  render via raw jQuery `.append()` with no client-side sanitizer and no default sizing, which is
  why the iframe needs explicit dimensions and `sandbox=""` is load-bearing, not optional hardening

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
