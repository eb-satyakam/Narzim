# ADR-027: AI Copilot usage metering — credit-based subscription plans

**Doc status:** living · **Created:** 2026-07-13 by Sarvesh-SocialAngel · **Updated:** 2026-07-13 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-13
- **Supersedes:** —
- **Superseded by:** —

## Context

The AI Encounter Copilot (Phase 5, pulled forward — see `docs/ai/` in this repo and in
the frontend repo) is currently gated by a single global flag,
`AI Settings.enable_ambient_documentation`: on or off for every user, with no usage
limit and no per-clinic differentiation. Remedisys intends to sell AI access as a
paid, tiered feature and needs a metering model before that can happen safely — right
now nothing stops one clinic's usage from being unbounded, and there is no mechanism
to grant or restrict access per clinic.

Real, measured costs (not estimates — verified live against the OpenAI and Deepgram
APIs on 2026-07-13, see `docs/ai/SYSTEM_DESIGN.md` and `docs/ai/AI_SCRIBE_STATUS.md`)
underpin every number in this ADR:

| Action | Real measured cost | Notes |
|---|---|---|
| Deepgram transcription (Nova-3 monolingual, streaming, diarized) | $0.0068/min | Official Deepgram pricing, pay-as-you-go |
| `generate_suggestions` on `gpt-5-mini` | ~$0.0055/call | Measured after fixing two real bugs in `integrations/openai.py` — see below |
| `chat_reply` (`ask_copilot`) on `gpt-5-mini` | ~$0.0007 for a trivial reply | Likely an underestimate for a real multi-sentence clinical answer; not yet measured at realistic length |
| `generate_suggestions` on `gpt-4o` | N/A — **returns an empty `[]` deterministically**, 6/6 test calls across two transcripts | Not a cost problem, a correctness problem. `gpt-4o` is not viable for this endpoint with the current prompt. |
| `generate_suggestions` on `gpt-5` (full) | ~$0.22/call | 40× `gpt-5-mini`'s cost, no measurable quality/latency advantage on this workload |

Two bugs were found and fixed while gathering these numbers, both in
`remedisys_healthcare_ai/integrations/openai.py`:
1. `max_tokens` is rejected outright by GPT-5-family models (need `max_completion_tokens`).
2. GPT-5-family models reject any non-default `temperature`.
3. (Related, not a bug fix but a design addition) GPT-5-family models spend part of
   their token budget on hidden reasoning before any visible output, with variable
   consumption call to call — `_effective_max_tokens()` adds headroom so this doesn't
   silently return zero suggestions.

A third, separate bug was found and fixed in the same file: `_estimate_cost()` looked
up pricing by exact model-string match, but OpenAI returns a dated snapshot id (e.g.
`gpt-5-mini-2025-08-07`), so the lookup always missed and silently fell back to a
hardcoded default that happened to equal full `gpt-5` pricing — every `cost_usd`
logged before the fix was wrong (`gpt-5-mini` looked ~30× more expensive than it
really is). Fixed via `_pricing_for_model()`, which matches by longest known prefix.

## Decision

Meter AI Copilot usage with a **credit system**, priced to real measured cost with a
small buffer (8–10%), not a percentage-of-revenue profit margin — the product owner
has been explicit that these plans should roughly cover cost, not generate margin.

### Credit costs per action

| Action | Credits |
|---|---|
| One AI-assisted encounter (recording + transcription + `generate_suggestions`) | **3** |
| One "Ask AI" chat message (`ask_copilot`) | **1** |

Chat is folded into the same credit pool as suggestions — one shared currency, not
separate quotas per feature. 1 credit ≈ $0.03 of real cost basis.

### Plan tiers

| Plan | Price/mo | Users included | Monthly credits | Daily credit limit | Daily token ceiling (safety net) |
|---|---|---|---|---|---|
| Starter | $49 | 2 | 1,500 | 50 | 65,000 |
| Professional | $99 | 5 | 3,000 | 100 | 130,000 |
| Business | $199 | 15 | 6,000 | 200 | 255,000 |
| Enterprise | Custom | Unlimited | Custom | Custom | Custom |

Key properties of this design:

1. **Daily limit = monthly credits ÷ 30, exactly** (no burst multiplier). This
   guarantees the monthly pool lasts the full 30-day billing cycle even if the clinic
   hits the daily cap every single day — an earlier draft used a 2× burst allowance,
   which meant the pool could exhaust in 15 days. Deliberately corrected to a flat,
   predictable pace instead. Tradeoff: no allowance for one unusually busy day
   averaged against a quiet one. Acceptable for launch; revisit (e.g. capped daily
   rollover) if this proves too rigid in practice.

2. **Daily token ceiling is a backend safety net, not a customer-facing number.**
   Credits are flat-rate per *action* regardless of transcript length or chat history
   size — a token ceiling bounds the worst case (e.g. an unusually long transcript or
   chat history) independently of whether the credit-counting logic is otherwise
   correct. Sized to the worst case of spending the entire daily credit limit on the
   token-heaviest action (`generate_suggestions`), so it should essentially never
   trigger under normal use.

3. **Only `gpt-5-mini` is used for any paid tier at launch.** `gpt-5` (full) is
   reserved for a possible future Enterprise offering, not offered below Enterprise.
   Rationale: measured 40× more expensive with no measurable quality or latency
   advantage on this workload (see cost table above). Re-evaluate only if a future
   workload or customer segment demonstrates a real quality gap `gpt-5-mini` can't
   close.

4. **"Users included" (seat count) is a separate axis from credits.** Credits bound
   total usage volume; the seat count bounds how many distinct user accounts may
   access AI at all. **Decided:** seats are assigned explicitly by the
   `EB_Healthcare Admin` role — standard SaaS seat licensing, predictable for the
   client, no auto-grant.

5. **A subscription is bought by a client, not by a single clinic — one plan can
   cover multiple `Company` records, and credits/seats are shared across all of
   them.** This was not in the original draft; it surfaced from a concrete example
   worth keeping here verbatim, since it's the clearest illustration of how the
   pooling works:

   > Client "Example Group" buys the **$99 Professional plan** — 5 seats, 3,000
   > credits/month, 100 credits/day. The client owns **two clinics**, Clinic A and
   > Clinic B, both covered by this **one** plan. The client has **7 doctors**: 4
   > work at both clinics, 2 work only at Clinic A, 1 works only at Clinic B.
   >
   > The plan has only 5 seats for 7 doctors — the `EB_Healthcare Admin` must choose
   > which 5 get one. A sensible choice: the 4 who work both clinics (a shared seat
   > covers more ground) plus 1 more. The other 2 doctors simply have no AI access
   > under this plan — not an error, just how 5 seats were allocated among 7 people.
   > A seat is per-*user*, not per-(user, clinic) — a doctor with a seat can use AI
   > at **any** clinic the plan covers, so the 4 dual-clinic doctors need only one
   > seat each, not two.
   >
   > The credit pool is **one shared pot across both clinics**, not one pool per
   > clinic. If a seated doctor at Clinic A does 10 AI-assisted visits today (30
   > credits) and a seated doctor at Clinic B does 15 (45 credits), that's 75 of the
   > *same* 100-credit daily pool gone — which clinic the visit happened at doesn't
   > matter, only whether the plan's shared pool has room left.

   Consequence for the enforcement design: the daily/monthly credit *and* token
   ceiling checks must sum usage across **every seated user on the plan**, not
   evaluate each user against their own separate allowance — it's genuinely one
   pool with several people drawing from it. Per-user usage is still recorded at
   full granularity (so the admin can see who used how much), but the limit
   comparison itself is plan-wide.

6. **What the `EB_Healthcare Admin` can and can't do.** They manage the Seats list
   (add/remove users, capped at the plan's seat count) and see the Companies the
   plan covers. They get **read-only visibility** into current usage — credits and
   tokens spent, both today and this billing cycle, against the plan's limits — so
   they can see why AI stopped working for their clinic without needing to contact
   support. They **cannot edit** the plan's own numbers (monthly credits, daily
   limit, token ceiling, seat count, price) — those are commercial terms of the
   subscription tier the client bought, changeable only by upgrading the plan (a
   Remedisys-side action, `System Manager` role), not something a clinic admin
   adjusts themselves. This mirrors why the token ceiling exists in the first place
   (§ point 2) — it's Remedisys's safety net against its own cost exposure, not a
   dial clinics should be able to turn up.

### Enforcement mechanism (design, not yet implemented)

Two new doctypes:

- **`AI Subscription Plan`** — one row per **subscribing client** (the paying
  account), not per `Company`. Holds plan tier, monthly credit pool, daily credit
  limit, daily token ceiling, seat count, price, and:
  - a child table **Covered Companies** — every `Company` (clinic) this plan applies
    to, one or many;
  - a child table **Seats** — every `User` assigned a seat, capped at the plan's
    seat count (a `validate()` hook blocks saving past the cap). A seat is per-user,
    not per-(user, company) — one seat covers that user at every company in the
    Covered Companies list.
- **`AI Usage Counter`** — one row per (user, date), tracking credits and tokens
  that specific user spent that day. Kept at full per-user granularity for
  reporting/admin visibility, but **the limit check itself sums every seated user's
  rows for the plan** and compares that total to the plan's shared daily/monthly
  caps — see point 5 above. A monthly balance is derived by summing the current
  cycle's rows, not stored as a separately decrementing field, so it self-corrects
  if a day's rows are ever corrected or backfilled.

Guard functions added at the top of `generate_suggestions` and `ask_copilot` in
`api/v1/ai/api.py`, alongside the `_require_auth()` / `_require_encounter_read()`
checks already added for backlog item SEC-1:

```
_require_auth()
_require_encounter_read(encounter)
_require_ai_seat(user)          # new — is this exact user a Seats row on *any* plan?
                                 # (no company-resolution needed — a seat is looked up
                                 # directly by user, see the note in Consequences below)
_require_credit_and_token_budget(user, action_cost_credits, estimated_tokens)
                                 # new — resolve the user's plan, sum today's/this
                                 # cycle's usage across every seated user on that plan,
                                 # confirm still under the daily and monthly credit
                                 # limits and the daily token ceiling. Increments the
                                 # user's own AI Usage Counter row if allowed.
```

Consistent with Rule 7 (AI failure must not break healthcare): any of these checks
failing refuses only the AI call. The Patient Encounter form, and the physician's
ability to document manually, is completely unaffected.

## Alternatives Considered

1. **Per-user daily quota that scales up with plan tier** (e.g. 5/15/30 suggestions
   per user per day across Starter/Professional/Business) — the original draft of
   this plan. **Rejected:** at fixed prices, this let higher tiers grant
   disproportionately more usage per dollar than lower tiers (credits-per-dollar
   roughly doubled from Starter to Business), which loses money faster the more a
   clinic actually uses the product — the opposite of sustainable at scale.

2. **Fixed per-feature bundles per encounter** (e.g. "up to N chat messages included
   per encounter") — an intermediate draft. **Rejected in favor of credits:** a flat
   bundle can't flex if a clinic wants more chat and fewer visits, or vice versa,
   without either wasting allowance or needing per-feature quota tracking. A shared
   credit pool is simpler to reason about and more flexible for the clinic.

3. **Credit-based pool with a flat per-action cost, daily and monthly caps,
   token-ceiling safety net (chosen).** Ties the pricing directly to real measured
   per-action cost, flexible across how a clinic actually wants to use it, and
   guarantees the monthly pool cannot run out before the billing cycle ends.

## Consequences

- **New doctypes required:** `AI Subscription Plan`, `AI Usage Counter` (see above).
- **`api/v1/ai/api.py` changes required:** `_require_ai_seat()` and
  `_require_credit_and_token_budget()` guards in `generate_suggestions` and
  `ask_copilot`, following the same pattern as the SEC-1 permission check.
- **Resolved since the first draft of this ADR:**
  - Seat assignment is explicit, by `EB_Healthcare Admin` (Decision, point 4) — not
    automatic.
  - A plan covers one or many `Company` records via the Covered Companies child
    table, not a single `Company` link (Decision, point 5) — needed once a
    multi-clinic client scenario was worked through concretely.
- **Still not resolved, blocking a public-facing pricing page:**
  - The pricing table circulated internally lists `SOAP Notes` and
    `Medical History Summary` as included features. **Neither exists in the
    codebase.** `AI SOAP Draft` and all SOAP generation is backlog item `SOAP-1`,
    explicitly not built. A general medical-history AI summary is listed as a future
    item on Patient Chart 360, also not built. These must be removed from any
    customer-facing pricing material or explicitly marked "Coming soon" before
    publishing.
  - The pricing table lists an `On-premise Option` for Enterprise. This conflicts
    with ADR-005 (Frappe Cloud, managed, multi-tenant deployment) — on-premise is a
    fundamentally different infrastructure and support model, not a checkbox
    feature. Needs its own scoping conversation before being sold.
- **Re-evaluation triggers:**
  - If real-world chat usage, once measured at realistic message length, costs
    meaningfully more than the ~$0.0007 trivial-reply estimate, the 1-credit chat
    price and/or the daily token ceiling should be revisited.
  - If the flat daily limit (no burst allowance) proves too rigid in practice,
    consider a capped daily-rollover mechanism.
  - If `gpt-5` (full) or a future model demonstrates a measurable quality advantage
    over `gpt-5-mini` on real clinical transcripts, re-evaluate offering it below
    Enterprise.

## Verification

- `AI Subscription Plan` (with its Covered Companies and Seats child tables) and
  `AI Usage Counter` exist and are wired into `generate_suggestions` / `ask_copilot`
  per the guard-function design above.
- `EB_Healthcare Admin` cannot save an `AI Subscription Plan` with more Seats rows
  than its seat count — the `validate()` cap is enforced, not just documented.
- A user with a seat can use AI at every `Company` in that plan's Covered Companies
  list, and a user with no seat is refused at every company, verified in a test
  environment with a multi-clinic plan (mirroring the worked example above).
- A plan's total usage (summed across every seated user) cannot exceed its monthly
  credit pool within a billing cycle, verified by attempting to exceed it.
- A plan's total usage cannot exceed its daily credit limit or daily token ceiling
  on any single day, verified the same way — confirm this is a true plan-wide sum,
  not a per-user limit (e.g. two seated users each under their "share" but the plan
  total over its cap should still refuse).
- `EB_Healthcare Admin` can view current usage (credits and tokens, daily and
  monthly) against the plan's limits, but cannot edit the plan's own numbers
  (credits, daily limit, token ceiling, seat count, price) — confirm this is
  enforced by doctype permissions, not just hidden in the UI.
- Refusal at any of these limits produces a clear error and does not affect Patient
  Encounter save/submit (Rule 7 kill-test, same method as backlog item QA-1).
- No customer-facing pricing material references `SOAP Notes`, `Medical History
  Summary`, or `On-premise` without either removing them or explicitly resolving
  their status first.

## References

- ADR-026: LLM provider allowlist (Anthropic, OpenAI) — the provider-selection
  decision this ADR's cost data assumes
- ADR-005: Frappe Cloud deployment (the on-premise conflict noted above)
- CLAUDE.md §9 (every LLM call must be logged/auditable) — `AI Usage Counter` should
  satisfy this for the metering path; the separate `OBS-1` backlog item (copilot LLM
  audit trail) is related but not identical — one is for billing/quota, one is for
  compliance audit
- `docs/ai/SYSTEM_DESIGN.md`, `docs/ai/PLAN.md`, `docs/ai/AI_SCRIBE_STATUS.md` (frontend
  repo) — architecture and backlog this metering layer sits on top of

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-13 | Sarvesh | Initial version (header backfilled from git history) |
