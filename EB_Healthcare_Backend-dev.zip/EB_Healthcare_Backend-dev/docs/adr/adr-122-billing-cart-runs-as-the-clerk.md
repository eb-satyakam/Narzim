# ADR-122: The billing cart runs as the clerk; Administrator only for a scan the clerk cannot read

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

Building a patient's billing cart switched the whole request to Administrator, ran ten core
Healthcare scans, and switched back. This was `services/billing.py::_aggregate_billables_elevated`
(used by the cart, checkout, the pending total and insured booking). The queue board's
"anything unbilled?" probe did the same (`_patients_with_unbilled`). ADR-115 removed this kind of
bypass everywhere else in billing.

Three findings (2026-10-01; permissions and data from the local site):

1. **Only three scans need a read front desk lacks.** EB_Front Desk already reads Patient
   Appointment, Patient Encounter, Lab Test, Clinical Procedure, Service Request and Patient.
   Their row-scoping hooks are patient-portal only and return no condition for front desk. The
   inpatient and emergency scans read the database directly. The ones left are Therapy Plan,
   Therapy Session and Observation, each with 0 rows on the local site.
2. **The queue probe needs no elevation at all.** It uses `frappe.get_all` and `frappe.db`, which
   do not check permissions, plus one Service Request `get_list` that every EB role can read.
3. **`frappe.set_user` resets more than the user.** It also clears `form_dict` (the request's
   parameters), sets `session.sid` to the user name, and clears `session.data` and the caches
   (`frappe/__init__.py::set_user`). Switching back restores only the user, so code later in the
   same request saw an empty request.

## Decision

1. Each cart scan runs as the logged-in user when the user can read the doctype it reads.
2. For a doctype the user cannot read, the scan runs at all only if this patient has a row there.
   It then runs alone under `_read_as_administrator`, which:
   - snapshots and restores the session (user, sid, data), `form_dict`, the caches and the
     permission state;
   - logs `billing.cart_elevated_read user=… doctype=… patient=…` (IDs only, BE-10).
3. `_patients_with_unbilled` no longer switches user.
4. No role gains a permission.

## Alternatives Considered

1. **Grant EB_Front Desk read on Therapy Plan, Therapy Session and Observation.**
   - Pros: no elevation anywhere.
   - Cons: Observation holds clinical results. Widening it to front desk for a billing list is
     against PHI-6 (minimum necessary), and every Desk list would show it.

2. **Rewrite the three scans as our own narrow queries** (`frappe.get_all` of billing fields only).
   - Pros: no elevation, and only billing fields read.
   - Cons: it duplicates core's pricing logic (therapy plan templates, observation templates and
     their items), which then drifts from core. That is the class of bug `_list_billable_service_requests`
     already exists to work around.

3. **Real user first, scoped elevation only where needed and only when there is data (chosen).**
   - Pros: on this site Administrator is never used, since the three doctypes are empty. Where
     they are used, billing still works. The request is never left reset, and the elevated read
     is logged with the real user.
   - Cons: an elevated read remains for those three doctypes.

4. **Keep the blanket switch and only restore the request state.**
   - Pros: the smallest change.
   - Cons: all ten scans still run as Administrator, and the bypass stays the default.

5. **Skip the scans the user cannot read.**
   - Pros: no elevation.
   - Cons: the front desk could no longer bill therapy or observations, so the money would
     silently drop out of the cart.

## Consequences

- **Code:**
  - `services/billing.py`: `_aggregate_billables` (renamed from `_aggregate_billables_elevated`),
    `_CART_SCANS` and `_read_as_administrator`.
  - `_patients_with_unbilled` loses its user switch.
- **Tests:** new `tests/billing/test_cart_permissions.py`. It runs as a real EB_Front Desk user,
  since a run as Administrator cannot see a permission regression.
- **Revisit** if front desk is ever given read on those doctypes (then delete the fallback), or if
  core starts reading another doctype the clerk cannot see.

## Verification

- `tests/billing/test_cart_permissions.py`:
  - a front-desk cart is built with no Administrator switch;
  - the elevated helper restores `form_dict` and the session.
- The reschedule and billing suites fail only where `dev` already fails.

## References

- [ADR-115](adr-115-billing-without-permission-bypass.md): billing runs on real permissions.
- [Design note](../flows/BILLING_CART_PERMISSIONS.md).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted by the product owner ("yes fix this also") |
