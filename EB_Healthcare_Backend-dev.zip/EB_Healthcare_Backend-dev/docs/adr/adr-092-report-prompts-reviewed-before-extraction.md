# ADR-092: Report prompts are stored per test, a template is generated from the prompt, and the clinician approves both before extraction

**Doc status:** living · **Created:** 2026-09-24 by Divyanshu (AI-assisted) · **Updated:** 2026-09-24 by Divyanshu (AI-assisted) · **Version:** 3.16

- **Status:** Accepted — Divyanshu, 2026-09-24. v3.0 restates the owner's requirement (prompt first, template from the prompt, two entry paths, approval on the same screen). **Parts 1, 2a and 3 implemented 2026-09-24, behind `AI Settings.enable_report_review` (off)**; 2b and 4 not started.
- **Amends (when implemented):** [ADR-080](adr-080-report-type-templates-for-lab-extraction.md) — a report template is no longer applied without a human seeing it; [ADR-088](adr-088-images-read-from-what-they-show.md) — an image-only upload may carry a study stated by the clinician, and in the review flow the AI may *suggest* a saved prompt from a picture for the clinician to confirm (§3.2.4).
- **File name:** kept from v1.0 so existing links hold.

---

## 1. Context

Today one background job runs the whole upload without stopping
(`services/lab_panel_extraction.py::run_panel_extraction`): Stage 1 picks a report template from
the clinic's `AI Chat Template` library — or writes a new one — and Stage 2 extracts with it at
once. Nobody sees the template. The extraction prompt says so itself: templates are "generated
automatically and not reviewed before use" (`multi_panel_extraction_v21.txt:46`). The
"Renal Ultrasound" template behind ADR-088 was written by the model and then misled it.

Reading the whole lab flow for this (2026-09-24) found facts the design has to respect:

1. **One template per upload.** The chosen template is stamped on every narrative report in the
   upload (`services/lab_panel_extraction.py:1323-1328`), even when the upload holds different
   reports.
2. **Parameters reach Lab Test Templates by name only** — no link field
   (`services/lab_catalog.py:131`).
3. **Narrative and imaging reports usually have no Lab Test Template** until the clinician creates
   an Imaging one at "Done" (`create_imaging_order_from_narrative`). The site has 27 Lab Test
   Templates, none Descriptive.
4. **The frontend has no concept of a report template.** The review flow lives in one component,
   `lab-order-dialog.tsx` (3,605 lines); the uploader-note box is not reachable in the AI flow
   (`docs/KNOWN_ISSUES.md`).
5. **Provenance is missing.** The Stage 1 prompt version is not recorded, and a template the AI
   writes does not record the prompt, model or upload that produced it
   (`services/lab_panel_extraction.py:560`).
6. **`AI Chat Template` bumps `version` in place** when its body changes
   (`ai_chat_template.py:139-150`), so the text an earlier result used is overwritten.

## 2. The owner's requirement (2026-09-24)

> First we choose the prompt, then according to that the template. The user can pass a note with
> the report. There are two ways in: the user picks a test, and we take the prompt for it — if no
> prompt is found we create one — then preview. If the user does not select a test and uploads the
> report directly, the same process. The template is approved on the same screen.

Terms used below:

- **Report prompt** — the stored instructions for how to read one kind of report (what to
  capture, which sections, what matters). Stored in the new doctype `AI Report Prompt`, linked to
  one or more Lab Test Templates.
- **Template** — the layout generated from the prompt: sections and fields, shown in the preview.
- **Note** — free text the user adds to the upload; context for the model, never an instruction.

## 2.1 How the lab flow works today on `dev`

Verified by reading the code on 2026-09-24 (backend and `EB_Healthcare_Frontend`).

**Way A — AI upload (the main path)**

```
① Lab order dialog, first screen (lab-order-dialog.tsx:2437): the user drops file(s) on the AI card.
   There is no test picker on this path, and the note box is not shown (it sits on a step this path
   skips, lab-order-dialog.tsx:2100-2107).
   → POST /api/labs/panel-upload → upload_lab_report_package (api/ai/lab_panel_extraction.py:177)
   → AI Prompt Log row, purpose "Multi-Panel Extraction", status "Extracting"
   → background job on the "long" queue (one worker on dev, shared with summary jobs)

② Background job — run_panel_extraction (services/lab_panel_extraction.py:1024), no stop:
   a. read the files (PDF text layer; page images for pictures; HEIC → JPEG)
   b. Stage 1 — report_template_select_v2 on the base model: picks ONE AI Chat Template for the
      whole upload, or writes a new one (none for an image-only document, ADR-088). Nobody sees it.
   c. Stage 2 — multi_panel_extraction_v21; the image model (gpt-5.5) when a file is an image
   d. retry any file the model skipped (without the template or note)
   e. code gates: body site needs printed words (ADR-089); every image finding Clear/Possible (ADR-090)
   f. values matched to Lab Test Templates by name; grouped per test; status "Success"

③ Screen polls every 2 s → results review: detected tests, "needs review" sections, narrative
   reports, AI image observations, the report summary (lab_report_summary_v5 /
   report_narrative_summary_v3), report chat

④ "Done": each detected test → Lab Test created, values saved, SUBMITTED (needs submit permission
   since 2026-09-24); a new section → new Lab Test Template + submitted Lab Test; a narrative report
   → DRAFT Imaging Lab Test; the summary is saved onto the Lab Tests

⑤ After every Lab Test save/submit: two AI summary jobs are queued for the patient (hooks.py:277-285)
```

**Way B — pick a test, then upload**

The user picks a test on the manual card → an order is placed → a single-file upload fills that one
Lab Test's rows (`api/ai/lab_extraction.py::upload_lab_report`, prompt `lab_extraction_v10`). This
path uses no report template and no prompt beyond the extraction prompt.

**What is missing today:** no one sees or approves the template; one template for a whole upload;
no stored prompt per test; no record of how a template was made; no note on the AI path; a unit
with no conversion rule is saved under the template's unit label.

## 2.2 What we are implementing

| Step | Today on `dev` | After ADR-092 |
|---|---|---|
| Entry | AI upload (no test picker, no note) **or** pick a test → single-test extractor | **Path 1:** pick a test + upload + note. **Path 2:** upload + note, the AI identifies the test. Both run the same process. **An upload against an order that already exists keeps today's single-test extractor** |
| Which instructions | One `AI Chat Template` chosen or written by the AI for the whole upload | The **report prompt** stored for that test (`AI Report Prompt`); created by the AI if none exists; one per report |
| Template | Picked or written silently | **Generated from the prompt**, once per prompt version, and saved with it |
| Human check before extraction | None | **Review screen on every upload**: prompt and template preview, editable, approved on the same screen |
| Reuse next time | Whatever Stage 1 picks again | The **approved** prompt and its template, linked to the Lab Test Template (or fingerprint) |
| Record of how it was made | None | Prompt version, approver, drafting file prompt, model and upload; the Lab Test links to the prompt version |
| Job | One job, never stops | Job 1 (identify → prompt → template) stops at "Awaiting Review"; job 2 extracts after approval; own queue |
| Units without a rule | Saved under the template's unit label | The AI proposes the rule, a clinician approves once, code converts; until then the printed unit is kept |
| Screen | Four-step dialog, review inside a 3,605-line component | Stepper ① Upload → ② Review prompt & template → ③ Extracting → ④ Review results; review step its own component |
| Unchanged | — | Extraction prompt and its safety rules, code gates, results review, "Done" behaviour, summaries |

## 3. Decision

### 3.1 Two entry paths, one process

**Path 1 — the user picks a test first**

```
① Upload: pick Lab Test Template (e.g. CBC) + upload file(s) + optional note
  → look up the Approved AI Report Prompt linked to that Lab Test Template
      found      → use it
      not found  → the AI drafts a report prompt for this test (from the report + test + note)
  → template for that prompt version:
      approved template already saved with it → use it, no model call
      none yet                                  → the AI generates it from the prompt
② Review (same screen): the prompt and the template preview, both editable → Approve
③ Extracting — with the approved prompt + template
④ Review results (existing screen)
```

The test the user picked is recorded as **clinician-identified**; Stage 1 does not second-guess it.

**Path 2 — the user uploads directly, no test picked**

```
① Upload file(s) + optional note
  → Stage 1: for each report in the upload, the AI identifies its Lab Test Template (from those
    that have a report prompt, then the rest), else a printed-report fingerprint, else none
  → then the same steps as Path 1, per report
② Review → ③ Extracting → ④ Review results
```

An image with no printed text has nothing to identify it by: no prompt is picked automatically;
the review screen says "study not identified" and the clinician may pick a test or state the study.

**No order is needed (owner, 2026-09-24).** A practitioner often orders nothing and the report
arrives anyway — brought by the patient, or from an outside lab. Both paths accept it: the user
picks the test (Path 1) or just uploads (Path 2), and at "Done" the Lab Test is created as today
for an unordered report — `ordered_via` "Self", no practitioner order, no Service Request
(`create_order_for_panel`, ADR-025). If the patient already has an open Draft Lab Test for that
same test, that open order is filled instead of a second one being created (the intended reuse in
`services/labs.py::create_direct_lab_test`).

**Existing orders keep today's single-test extractor (owner decision, option 2).** When a result
is uploaded against a Lab Test that **already exists** — a pending order placed during a visit or
earlier — it is filled the way it is today (`api/ai/lab_extraction.py::upload_lab_report`,
`lab_extraction_v10`): no report prompt, no review step. Path 1 is for **new** uploads where the
user picks a test. Consequences recorded: that path keeps its current gaps (no request timeout,
one file only; `docs/KNOWN_ISSUES.md`), and the "pick a test" entry on today's manual card, which
places a new order and then uploads, moves to Path 1.

### 3.2 The review screen (step ②), on every upload

Per report in the upload:

- the **report prompt** (editable), marked "Approved by Dr ___ on ___, version N" when reused, or
  "New — drafted by AI" when just created;
- the **template preview** — layout only: headings and empty slots, no extracted values;
- the **note** (editable);
- **Two explicit buttons in the bottom bar, next to Back** (owner, 2026-09-24): **Save & extract**
  saves every prompt and template in the review that has text as an approved version, then
  extracts; **Extract without saving** uses them for this upload only. (A per-test "save for
  future" checkbox was tried first and replaced: it was easy to miss.) Nothing is extracted until
  one is chosen.

Edits:

- **Saved for future** → a new prompt version is created, Approved, linked to the Lab Test
  Template; its template is saved with it. The previous version is kept as Superseded.
- **Not saved** → the edited prompt/template is used for this upload only and stored on the upload
  record; the library is unchanged.
- **A newly drafted prompt approved as-is** → version 1, Approved.

### 3.2.0 Screen details settled after the first click-through (owner, 2026-09-24)

- **Test picker ("Select Test"):** the same control as the practitioner selector — a compact
  bar whose dropdown has a search box and a list — but multi-select (ticks; the bar shows one name
  or "N tests selected", with clear). Options from Lab Test Template, directly under the
  practitioner. Several picked
  tests are one report with one prompt per test. Backend: `lab_test_templates` (JSON list) on
  upload; `AI Prompt Log.selected_lab_test_templates` (list) replaces the single-test field added
  the same day (never released).
- **Review step shows the prompt and a preview of the output only.** While job 1 prepares the
  prompts the screen says so ("Preparing the prompt and template…") — never the extraction
  checklist, which appeared there at first because the record reads "Extracting" from upload. The
  extraction checklist appears on step ③ only. The preview is output-shaped: each section with its
  slots as columns and empty cells — no values exist before extraction.

### 3.2.4 With no test picked, the AI first chooses among the saved prompts (owner, 2026-09-24)

Path 2 now gives the identify step (prompt `report_identify_v2`) the clinic's Approved report prompts
— title, the tests each serves, its section headings — and asks which one fits each report, and
whether it judged from printed text or from how a picture looks. Per report with no test:

- **chosen from printed text** → used as the approved prompt;
- **chosen from the picture** → used, but marked **suggested** ("Suggested by AI from the picture —
  check the preview before extracting");
- **nothing fits** → matched by printed-title fingerprint, else **drafted — for an image too**.

So every report reaches the review with a preview. **This relaxes ADR-088 decision 2 within the
review flow only:** ADR-088 stopped the AI from choosing a template from a picture because the
choice was then used silently; here nothing is extracted until a clinician has seen the choice,
labelled as a suggestion. A picture still never adds a test (`test_indices` stays empty for an
image), and ADR-089's code gate on the stored body site is unchanged. Approving a suggested prompt
unchanged keeps its link and "Save & extract" does not duplicate it. Measured on the hand X-ray with
`RPRM-00001` saved: 5 s, one call, `RPRM-00001` suggested with its 7-section preview.

### 3.2.5 Uploads get their own worker (owner, 2026-09-24)

Measured: an upload waited 514 s and another 272 s although the prompt step itself took seconds —
both were queued behind a patient-lab-summary job that had held the only worker for 9+ minutes.
Uploads now run on a dedicated RQ queue, **`lab_upload`**, when the bench declares it; otherwise on
`default` (Frappe refuses an undeclared queue, so the code checks and falls back —
`services/lab_panel_extraction.py::upload_queue`). The job budget and the recovery deadline come
from that queue's timeout. A time limit on the summary calls was proposed and **rejected by the
owner**; the summary jobs themselves are unchanged (see `docs/KNOWN_ISSUES.md`).

**Enable it on a bench:** in `sites/common_site_config.json`

```json
"workers": { "lab_upload": { "timeout": 1500 } }
```

then run a worker for that queue (`bench worker --queue lab_upload`).
- **Local dev (this bench):** declared; `scripts/dev/run_upload_worker.sh` + a Procfile
  `upload_worker` line; restart `bench start`.
- **Frappe Cloud:** add the same `workers` key to the bench's common site config (Bench Group →
  config) and redeploy; `bench setup supervisor` creates one worker process per declared queue.
  UNVERIFIED on this account: that the plan allows editing bench config (private bench groups do;
  shared benches may not). If it cannot be set, uploads stay on `default`, and raising the number
  of background workers is the fallback.

### 3.2.3 The review screen shows the output, not the prompt (owner, 2026-09-24)

The review step shows, per test, only the **output preview** (its template as columns with empty
cells), the source badge, and — for an unidentified image — the test picker and "state the study".
The prompt text, summary guidance and manual template editing are **not shown**; the prompt still
drives extraction and is what the AI changes. Changes are made only through **Ask AI**: one input,
fixed at the bottom of the review, targeting the selected test card ("Changing: …"), with Undo per
card. The input is the **same component as Narzim GPT** — moved out of `narzim-chat-panel.tsx` into
`src/components/shared/chat-composer.tsx` and used by both. The uploader's note is taken at upload
only; the review has no note box and no Cancel button (an unreviewed upload expires after 7 days).
This supersedes the manual editing described in §3.2 and §3.2.1. Each card keeps a **Rebuild
preview** action (a fresh template from its prompt; text only; Undo applies). The manual cancel
method and its frontend were deleted.

### 3.2.2 Image-only reports, and uploads that never ran (owner, 2026-09-24)

- **A saved prompt for an image is reused only through a picked test.** An unlabelled image has no
  printed title to match by fingerprint, and the AI never names a study from the picture (ADR-088),
  so a saved image prompt was never proposed again (seen live: `RPRM-00001` for "Right hand X-ray"
  ignored on a direct upload of the same X-ray). Picking the test — in "Select Test" on the first
  screen, or on the review screen for that report — now loads its approved prompt and template
  (`get_review_test_prompt`). The approval records the loaded version (`decisions[].prompt`), so an
  unchanged prompt keeps its link and "Save & extract" never duplicates it.
- **The AI's guess is labelled.** For an image-only report the heading is "Report N", with "AI's
  guess from the picture: … (unconfirmed)" beneath (ADR-089).
- **Stuck uploads.** A job that never runs leaves the record "Extracting" forever (seen live after a
  stale worker). Past the job budget + 120 s it cannot be running, so the status call and a
  15-minute sweep (`report_review.mark_stuck_uploads`) mark it Failed with a clear message.

### 3.2.1 Ask the AI to change a prompt (owner, 2026-09-24)

On the review screen each prompt has an "Ask AI to change this" box. The clinician types an
instruction ("also capture the method for each value"); the AI returns a revised prompt, template
and summary guidance, which replace the editors' contents marked "Updated by AI — check before
approving", with Undo. With an empty prompt (a failed draft, an unidentified image) the instruction
is how the clinician asks the AI to write one.

- **Text only.** The report file is never sent for this call, so no patient data leaves the system
  (`llm.refine_report_prompt`, prompt `report_prompt_refine_v1`).
- **Nothing is saved.** The revision is an edit like any other; the library changes only when the
  clinician ticks "save for future" and approves. The Approve button says which: "Save & extract"
  or "Extract without saving".
- **It cannot weaken the fixed rules.** The instruction is delimited and labelled as a request; the
  rules live in the extraction prompt and in code (§3.5). Capped at 1,000 characters.
- Method `refine_review_prompt` (only while the upload awaits review; Lab Test create).
  Measured: 12 s on a sample lipid prompt, changing only what was asked.

### 3.3 The approved template is saved with its prompt version

Generating the template afresh on every upload would give a slightly different layout each time for
the same test, because model output varies run to run, and would add a model call to every upload.
So a template is generated **once per prompt version**, approved with it, and saved on it. The same
prompt version always shows the same template. A new template is generated only when the prompt is
edited into a new version.

### 3.4 Storage — new doctype `AI Report Prompt`

| Field | Purpose |
|---|---|
| `title` | e.g. "Complete Blood Count" |
| `prompt_text` | The report prompt — how to read this kind of report |
| `template_markdown`, child table `template_sections` | The approved template generated from this prompt version |
| `summary_guidance` | What a summary of this kind of report must state (as `AI Chat Template` has today) |
| child table `linked_lab_test_templates` | The Lab Test Templates this prompt serves |
| `fingerprint` | Lab name, title, section headings — for reports with no Lab Test Template |
| `status` | Draft / Approved / Superseded. Only Approved is picked automatically |
| `version`, `previous_version` | Each saved edit is a new record; earlier versions are never changed |
| `approved_by`, `approved_on` | Who approved this version (PHI-7) |
| `drafted_by_prompt`, `drafted_prompt_hash`, `drafted_model`, `drafted_from_upload` | The file prompt, its hash, the model and the upload that drafted this prompt or its template — "store the prompt through which we generate the template" |

Also recorded:

- **The upload (`AI Prompt Log`):** path (test picked / direct); per report, the `AI Report Prompt`
  version used (or the one-off edited text), who approved it, the note, and any clinician-stated
  study; the Stage 1 prompt version and hash.
- **`Lab Test`:** a custom field (fixtures, Rule 1) linking to the `AI Report Prompt` version that
  produced it.

The **file prompts** stay files, versioned in git: the one that drafts a report prompt, the one that
generates a template from a prompt (new, `llm/prompts/…_v1.txt`), Stage 1 identification, and the
extraction prompt `multi_panel_extraction_vN.txt`. The patient-name guard `AI Chat Template` applies
to its text is applied to `prompt_text` and `template_markdown` too.

### 3.5 What an edit can never change

A report prompt and its template control **what a report of this kind contains and how it is laid
out**. The fixed rules stay in the file prompts and in code, and an edit cannot switch them off:
never report a value not printed; never diagnose; AI image observations kept apart from the
document's content; the body-site gate (ADR-089); Clear/Possible grading (ADR-090). The prompt,
template and note reach the model as delimited blocks, as templates and notes do today
(`build_report_template_instruction`, `build_upload_note_instruction`).

### 3.6 Everything the current flow handles stays handled

The unit of review is the **document** Stage 1 already identifies (`run_panel_extraction` STEP 0),
and inside a document, the **test**. Prompts are linked per test, so each test in a document uses
its own approved prompt; only a test with none gets one drafted. Stage 2 stays **one extraction
call for the whole upload** plus the existing recovery (it is not split per document), now given
each document's approved prompts and templates.

| Case (owner, 2026-09-24: "all which we currently follow") | Today on `dev` | New flow |
|---|---|---|
| **Several files that are pages of one report** | One document; values carry their own file index | One document → one review entry |
| **Several different reports uploaded together** | Classified separately, but one template stamped on all (fact 1) | One review entry **per document**, each with its own prompts and template |
| **Multi-panel report** — one file with several tests (e.g. CBC + liver panel + thyroid) | Values bucketed per Lab Test Template by name | One document with several tests: **each test uses its own approved prompt and template**; missing ones are drafted; the review shows each test; an approval of, say, the CBC prompt is reused in any later package containing a CBC |
| **Mixed upload** — a panel, a narrative report and images together | Each classified; one template for all | Each document its own entry; a narrative report is matched by fingerprint when it has no Lab Test Template |
| **Report kind** — panel / measurement / narrative | Decided by the extraction (`clean_report_kind`) | Unchanged |
| **Image-only study** (no printed text) | No template (ADR-088) | "Study not identified"; the clinician may pick a test or state the study |
| **Left / right** (both eyes, both ears) | Side on every value; kept apart when de-duplicating | Unchanged |
| **The report's own warnings** ("repeat measurement", "(!)") | Captured verbatim, shown first | Unchanged |
| **A file the model skipped** | One recovery call per missing file, without template or note | Recovery carries that document's prompts, template, note and page images |
| **Values matching no test** ("needs review") | Grouped by printed section; the clinician can create a Lab Test Template from it | Unchanged; a prompt drafted for that section in step ② is linked to the new Lab Test Template when it is created at "Done" |
| **Duplicate upload / patient-name mismatch warnings** | Shown on the results screen | Unchanged |
| **File limits and formats** — up to 10 files, 20 MB each, PDF / images / HEIC | Enforced | Unchanged |

This also fixes fact 1: no template is ever stamped across documents it was not approved for.

### 3.7 Unit conversion — the AI finds the rule, a clinician approves it once, code converts

Today conversion into the template's unit is done by code (`services/lab_units.py::resolve_display_value`,
called at save by `services/labs.py::_apply_report`) and only when a `Lab Unit Conversion` rule
exists. With no rule, the value is saved as printed while the row keeps the template's unit label
(the range is blanked, so no false flag): a glucose template in mmol/L can store "100" from a report
that printed 100 mg/dL.

1. When a report's unit differs from the template's and no rule exists, the AI **proposes the
   rule** — analyte, from-unit, to-unit, factor or formula — in Stage 2's output. It never outputs
   a converted value.
2. The results screen shows it ("0.9 mg/dL → 79.6 µmol/L, factor ×88.4, proposed by AI"); the
   clinician approves or rejects.
3. On approval the rule is saved to `Lab Unit Conversion` (approved by, approved on, proposed by
   AI) and **code** converts — this result and every later one with that analyte and unit pair.
4. Until approved, the value keeps **its own printed unit**, never the template's label.

### 3.8 Stepper UI

① Upload → ② Review prompt & template → ③ Extracting → ④ Review results. The waits read as steps
("Reading your report…", "Preparing the template…"), not as a stall. The review step is its **own
component**, not inside `lab-order-dialog.tsx`.

### 3.9 Existing templates and the old flow

The current flow stays unchanged until the new one replaces it. The 7 `AI Chat Template` rows in
category "report" are not used by the new flow; they stay for history and for the old flow until
it is switched off.

## 4. Options considered

**What is stored and reused**

| Approach | Pros | Cons |
|---|---|---|
| **Report prompt stored per test; template generated from it once per prompt version and saved with it (chosen)** | Matches the owner's flow — prompt first, template from the prompt; same test shows the same template; no model call for a known test | A new test waits once for the prompt and template to be drafted |
| Report prompt stored; template regenerated on every upload | Template always reflects the latest model | Different layout each time for the same test; a model call on every upload |
| Only the approved template stored (v2 of this ADR) | Simplest data | No stored prompt — not the owner's requirement |
| Template chosen by the AI with no review (today) | No wait | Unreviewed templates mislead extraction (ADR-088) |

**How units are converted**

| Approach | Pros | Cons |
|---|---|---|
| The AI outputs the converted value for each result | No rules to manage | Arithmetic and factor mix-ups (glucose ÷18, creatinine ×88.4, urea ×0.357) are silent, vary run to run, and leave no record |
| **The AI proposes the rule, a clinician approves it once, code converts (chosen)** | Model knowledge with exact arithmetic; deterministic; every rule has an approver | One approval the first time a unit pair appears |
| The AI proposes and it applies at once | No click | A wrong factor reaches saved results before anyone checks |
| Admin-entered rules only (today) | Fully controlled | A missing rule leaves the value under the wrong unit label |

**When the review screen appears:** every upload (owner decision) — every prompt and template is
seen before use, at the cost of one step and its wait.

## 5. Settled (owner, 2026-09-24)

| Question | Decision |
|---|---|
| Where prompts live | New doctype `AI Report Prompt` |
| An upload nobody reviews | Stays "Awaiting Review"; auto-cancelled after 7 days, files kept. (A manual Cancel was built and then removed at the owner's request, 2026-09-24.) |
| Who may approve for one upload | Any user with create permission on Lab Test |
| Who may "save for future" and approve a unit-conversion rule | Users with write permission on Lab Test Template |
| Model for Stage 1 and drafting on uploads with images | The provider's image model (`openai_image_model` / `anthropic_image_model`) |
| `gpt-5.5` price | To be supplied by the owner; until then the fallback price and Error Log entry apply |

## 6. Plan (not started)

**Part 1 — storage (no change to today's flow) — done 2026-09-24.** The template sections reuse the
existing `AI Chat Template Section` child table rather than a new identical one; the lock also
refuses deleting an Approved or Superseded version, and allows one Approved prompt per Lab Test
Template (the version being replaced excepted, and superseded on approval). The Stage 1 prompt
version and hash are recorded in the upload's `classification_json` under `prompt`. Tests:
`tests/labs/test_ai_report_prompt.py` (17, mocks only).

1. `AI Report Prompt` doctype with child tables `linked_lab_test_templates` and
   `template_sections`; approved versions immutable; patient-name guard.
2. `Lab Test` custom field linking to the `AI Report Prompt` version.
3. Provenance on today's flow: Stage 1 prompt version and hash recorded on the upload.
4. Anthropic adapter records `cached_tokens`, cache-write and `reasoning_tokens` as OpenAI does
   (costs are correct today only because it sends no caching or extended thinking,
   `integrations/anthropic.py:202-207`).
5. Mock-only tests; migration.

**Part 2a — the review flow (backend) — done 2026-09-24, switched off.** Built as planned, with
these decisions recorded:

- **Behind a switch.** `AI Settings.enable_report_review`, default off. The current frontend polls
  only while the status is "Extracting" (`use-labs.ts:529`), so enabling it before part 3 would
  leave the upload screen waiting forever. Off, the upload runs exactly as before.
- **Queue.** Uploads (both jobs, and the old flow) run on RQ `default` with the long queue's
  1500 s budget passed explicitly (`services/lab_panel_extraction.py::UPLOAD_QUEUE`,
  `upload_job_timeout`). A worker drains `default` before `long`, so uploads no longer wait behind
  summary jobs. A new queue name was rejected: the dev worker listens only to the standard queues.
- **Drafting is one call per report, not per test.** Measured on a 14-test health-package PDF: one
  call per test took 15 calls and 404 s; one call for all missing tests took 2 calls, 96 s,
  $0.02. `report_prompt_draft_v1` was rewritten as a batch prompt before it was ever released.
- **A drafted prompt is not a record until saved.** It lives in the upload's `review_proposal`;
  "save for future" creates the `AI Report Prompt` version (Approved), otherwise the edit is a
  one-off stored in `approved_review`.
- **Path 1 is for one test.** A package uploaded under one picked test gets one prompt written for
  the whole package under that test's name (seen on a real run). A package should be uploaded
  without picking a test (Path 2).
- **Identification lists overlapping tests.** On the package, Stage 1 named both panels and the
  single-analyte tests inside them (e.g. a panel and its electrolytes). Harmless for extraction —
  values are still bucketed by coverage — but it adds entries to review. Open for tightening.
- **Also done here:** recovery calls carry the note and that file's approved prompts; the
  duplicate `"Lab Test Template"` key in `hooks.py` is merged; a daily job cancels reviews left
  7 days; the approved prompt version is stamped on each Lab Test at "Done".
- Methods: `approve_report_review`, `regenerate_review_template`, `cancel_report_review`; the
  status call returns `review_proposal` and `approved_review`. Tests:
  `tests/labs/test_report_review.py` (27, mocks only).

**Part 2 — the new flow (backend), original plan**

1. New file prompts: draft a report prompt; generate a template from a prompt; Stage 1 identify
   the Lab Test Template.
2. Split `run_panel_extraction`: job 1 (identify → find/draft prompt → template) ends at
   "Awaiting Review"; job 2 (extract) starts on approval.
3. Methods: get the proposal; approve (with edits, "save for future"); cancel. Path 1 takes the
   picked Lab Test Template.
4. Stage 2 receives each report's approved prompt + template; one per report.
5. Unit-rule proposals (§3.7).
6. Same build: recovery calls carry the report's prompt, template, note and page images
   (`services/lab_panel_extraction.py:782-804`); `gpt-5.5` priced; the duplicate
   `"Lab Test Template"` key in `hooks.py` merged; uploads on their own RQ queue; 7-day expiry job.

**Part 3 — frontend — done 2026-09-24 (`EB_Healthcare_Frontend`), switched off with the backend.**
The review is a new step inside the existing lab dialog, built as its own component
(`lab-report-review-step.tsx`; logic in `lab-report-review-model.ts` with vitest tests), with a
stepper (`lab-upload-stepper.tsx`) shown only when review is on. Step 1 shows the note once files
are staged (fixing the unreachable-note issue) and the optional test picker only when review is on
(FE-5). While a review waits, the processing step shows the review instead of the spinner; a
cancelled or expired review offers a fresh start. The backend availability call returns
`report_review_enabled`. Route handlers: `review-approve`, `review-regenerate-template`,
`review-cancel`. 49 strings in `en` and `es` (parity check passes).

Verified end to end on the dev site (in-process, switch turned on for the run and off after; test
record deleted): a mixed upload of a 14-test package PDF and the hand X-ray — job 1 in 72 s
(X-ray "not identified", 14 prompts drafted in one call) → approve → job 2 in 74 s, all 14 tests
detected, 3rd/4th/5th metacarpal fractures found "Clear". The run found that a study stated for an
unidentified image never reached the model (no prompt → block skipped); fixed, with a test.
Not done: the browser path through the Next.js BFF (no login available to the agent) — to be
clicked through by the owner; vitest cannot run under WSL here (Windows-built native binaries).

Seen on the run: an upload containing any image is read by the image model as a whole, so the PDF
in a mixed upload is read by `gpt-5.5` too.

**Part 3 — frontend (`EB_Healthcare_Frontend`), original plan**: the stepper; test picker and note on step ①; the
review step as its own component; unit-rule approval on step ④; `es-MX` and `en-US` strings.

**Part 4 — measure, then switch**: the same uploads (a panel, a two-eye measurement report, a
narrative report, an image-only study, a report whose units differ from the template) through the
old and new flow; switch when the new flow is at least as good.

Tests run on a separate test site, not `remedisis.localhost` (`WORK_LOG.md` 2026-09-24).

### 6.1 Gaps this closes

Templates used unapproved; no template provenance; one template per upload; uploader note
unreachable; unit mislabelled when no conversion rule exists; recovery calls dropping the template;
`gpt-5.5` unpriced; duplicate `hooks.py` key; uploads queued behind summaries; Anthropic usage
fields. Partly: image-only reports (clinician picks the test or states the study) and test coverage.
Not addressed: CRITICAL grading, the de-duplication merge without approval, hardcoded English on
the Lab Center tab, summary jobs on every Lab Test save.

## 7. Risks

- An upload left unreviewed waits — mitigated by cancel and the 7-day expiry.
- A new test waits once for drafting (prompt + template); later uploads of that test need no model
  call before review.
- Stage 1 choosing among Lab Test Templates (Path 2) is a new classification task; a wrong choice
  proposes a wrong prompt. The review screen is the check.
- An approved prompt is reused widely; a poor one spreads. Every version names its approver and a
  Superseded version stays readable, so a fault can be traced and replaced.
- Clinic-editable prompts are instructions to a model; §3.5 keeps an edit from widening what the
  model may do (PHI-6).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.16 | 2026-09-24 | Divyanshu (AI-assisted) | §3.2.5: dedicated lab_upload queue (declared → used, else default); summary timeout rejected by the owner; Frappe Cloud steps |
| 3.15 | 2026-09-24 | Divyanshu (AI-assisted) | §3.2.4: with no test picked the AI chooses among saved prompts (suggested when from a picture); images without a fit are drafted |
| 3.14 | 2026-09-24 | Divyanshu (AI-assisted) | Rebuild preview kept on each card; manual cancel deleted (backend + frontend) |
| 3.13 | 2026-09-24 | Divyanshu (AI-assisted) | §3.2.3: review shows output preview only; Ask AI fixed at the bottom (shared Narzim GPT composer); note and Cancel removed from review |
| 3.12 | 2026-09-24 | Divyanshu (AI-assisted) | §3.2.2: picked test loads its saved prompt on review; AI guess labelled; stuck-upload guard |
| 3.11 | 2026-09-24 | Divyanshu (AI-assisted) | Review actions moved to the bottom bar; explicit Save & extract / Extract without saving replace the per-test checkbox |
| 3.10 | 2026-09-24 | Divyanshu (AI-assisted) | Test picker rebuilt as the practitioner-style "Select Test" control |
| 3.9 | 2026-09-24 | Divyanshu (AI-assisted) | §3.2.0: multi-select picker under the practitioner; review step shows only prompt + output preview; preparing state instead of the extraction checklist |
| 3.8 | 2026-09-24 | Divyanshu (AI-assisted) | Added §3.2.1: ask the AI to change a prompt and template on the review screen (text only, nothing saved) |
| 3.7 | 2026-09-24 | Divyanshu (AI-assisted) | Part 3 implemented; end-to-end run and the stated-study fix recorded |
| 3.6 | 2026-09-24 | Divyanshu (AI-assisted) | Part 2a implemented behind a switch; decisions and measurements recorded in §6 |
| 3.5 | 2026-09-24 | Divyanshu (AI-assisted) | Part 1 implemented; how it was built recorded in §6 |
| 3.4 | 2026-09-24 | Divyanshu (AI-assisted) | §3.6 rewritten: every case the current flow handles (multi-file, multi-report, multi-panel, mixed, image-only, sides, warnings, recovery, unmatched sections, limits) and how the new flow keeps it; multi-panel reports use one approved prompt per test |
| 3.3 | 2026-09-24 | Divyanshu (AI-assisted) | Stated that no order is needed: unordered reports go through Path 1 or 2 and are saved as "Self" at Done |
| 3.2 | 2026-09-24 | Divyanshu (AI-assisted) | Existing orders keep today's single-test extractor; Path 1 is for new uploads (owner, option 2) |
| 3.1 | 2026-09-24 | Divyanshu (AI-assisted) | Added §2.1 (how the lab flow works today on dev) and §2.2 (today vs after, step by step) |
| 3.0 | 2026-09-24 | Divyanshu (AI-assisted) | Restated to the owner's requirement: report prompt stored per test in a new doctype `AI Report Prompt`; template generated from the prompt once per version and saved with it; two entry paths (test picked / direct upload); prompt created when missing; note; approval of prompt and template on the same screen; plan split into four parts |
| 2.2 | 2026-09-24 | Divyanshu (AI-assisted) | Accepted by the owner; open questions settled; Anthropic usage-field fix added |
| 2.1 | 2026-09-24 | Divyanshu (AI-assisted) | Added unit conversion, the stepper UI, same-build fixes, and the list of gaps closed |
| 2.0 | 2026-09-24 | Divyanshu (AI-assisted) | Switched to approach B: the approved template stored and reused |
| 1.0 | 2026-09-24 | Divyanshu (AI-assisted) | Initial proposal (stored prompt regenerating the template) |
