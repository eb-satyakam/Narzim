# ADR-108: Narzim GPT reads the linked visit's prescriptions and writes an attached template

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.2

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** the unconditional exclusion of the linked encounter in `get_current_medications`
- **Superseded by:** —

## Context

On 2026-09-30 the owner asked Narzim GPT, with a patient and a signed visit linked, what the
patient was prescribed. The reply was that no current medications were documented. The record held
two prescriptions, both on the linked visit, and two active Medication Requests.

| Fault | Cause |
|---|---|
| "No current medications documented" | `get_current_medications` excluded the linked encounter by name. That is right for the encounter copilot, where the linked encounter is the draft being written. In Narzim GPT the linked visit is usually signed |
| "generate explainer" with a letter template attached was answered with "I'm here to assist with clinical questions" | The answering prompt never mentions an attached template, and its scope rule refuses a request to "draft an essay" |
| Every short answer ended "feel free to ask" | The prompt forbids padding; the model wrote it anyway |

## Decision

1. `get_current_medications` no longer excludes the linked encounter. The signed-only filter stays,
   so a draft is still kept out whichever encounter is linked. Each row carries
   `from_linked_encounter`.
2. New prompt versions `narzim-assistant-context-v5` (plain) and `-v6` (markdown): an "Attached
   template" section, a line that a clinical document about the patient is a clinical request, a
   line on where the linked visit's prescriptions are, and a rule against generic closing offers.
3. A closing sentence that is only a generic offer of help is removed in code
   (`narzim_context_answer.strip_generic_closer`), whether it is a paragraph of its own or the
   last sentence of the final one.
4. **Amended the same day, on the owner's decision: report prescriptions and medication orders
   both.** `get_current_medications` also reads the patient's submitted `Medication Request` rows.
   A prescription carries the `status` of the order behind it; an order that no listed
   prescription accounts for is returned in `medication_orders`. `orders_checked` is false when
   the caller may not read orders. `get_encounter_state` adds a note pointing at this tool,
   because the model otherwise stops after reading the visit.

## Alternatives Considered

### The medication answer

1. **Include the linked encounter when it is signed (chosen).**
   - Pros: one rule, correct for both surfaces; no new data source.
   - Cons: in the copilot, after signing, the visit's own orders now appear in this tool too.
2. **Tell the model to call `get_encounter_state` as well.**
   - Pros: no tool change.
   - Cons: depends on the model making a second call. It did not, which is the fault.
3. **A separate tool for Narzim GPT.**
   - Pros: the copilot is untouched.
   - Cons: two tools with nearly the same name, and a second copy of the permission reasoning.
4. **Read Medication Request instead of Drug Prescription.**
   - Pros: carries a status, so "active" can be meant literally.
   - Cons: a wider read than today (PHI-6) and a different answer for every existing caller. Worth
     its own decision.

### The closing offer

1. **Prompt only.** Pros: no code. Cons: measured not to work.
2. **Remove it in code (chosen).** Pros: cannot be ignored. Cons: a pattern list to maintain, in two
   languages.
3. **A second model call to tidy the reply.** Pros: handles any wording. Cons: cost and latency on
   every turn for one sentence.
4. **Leave it.** Pros: nothing to maintain. Cons: the owner called the assistant "dumb" partly for
   this.

## Consequences

- PHI-6: the tool's reach grows by one encounter, the one the clinician linked and may already
  read, and by one doctype, `Medication Request`, read through `frappe.get_list` so the caller's
  permissions apply. Only the medicine, dose, form, duration, date, prescriber, status and
  encounter are returned; the demographic fields on that doctype are not selected. No other
  patient is reachable.
- Alternative 4 under "The medication answer" is no longer rejected: it is adopted alongside
  alternative 1, not in place of it.
- Every row still cites its encounter, so an answer can say "prescribed at this visit".
- `narzim-assistant-context-v3` and `-v4` stay on disk for the replies they wrote.
- The closer removal changes model output after the fact. It removes one final paragraph, only when
  that paragraph is a single short sentence matching a fixed pattern, and never the whole reply.

## Verification

- `tests/ai/test_copilot_chart_tools.py`: the linked, signed visit's prescriptions are returned.
- `tests/ai/test_narzim_context_answer.py`: the four prompt additions, and the closer removal.
- On `marley.local` against the live model, 2026-09-30: the same question now returns both
  prescriptions, each reported as active, and states that no other orders are recorded; the model
  called `get_encounter_state` and `get_current_medications`. "generate explainer" with the
  template returns the letter, with no unfilled slot.

## References

- ADR-075 (patient-aware context), ADR-030 (tool registry), adr-105 (template prompts)
- `CLAUDE.md` PHI-6, BE-6

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-106 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Decision 4 added: medication orders are read and reported alongside prescriptions; closer removal works on a trailing sentence |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
