# ADR-013: Introduce a Patient Feedback doctype for the satisfaction report

**Doc status:** living · **Created:** 2026-06-20 by Anant Sharma · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-06-19
- **Supersedes:** —
- **Superseded by:** —

## Context

`patient_satisfaction` (Screen 18, the `providers/patient-satisfaction` report) is
the only one of the 16 analytics reports that cannot be built. Every other report
reads or derives from existing data (appointments, encounters, invoices, insurance
claims, `Patient.medical_history`). Satisfaction has **no source at all** — there is
no rating, NPS, survey, or feedback field or doctype anywhere in the system, and no
mechanism that collects patient feedback (see `docs/REPORTS_API.md` §15 and §6-F).
So the report is shipped as a static mock on the frontend and stubbed-out on the
backend.

Constraints that shape the decision:

- **§7 — "No new custom doctypes are needed for Phases 1–4."** All clinical data so
  far lives in ERPNext Healthcare doctypes. A feedback source is genuinely new data
  the platform does not model, so this is a deliberate, logged exception to §7 — and
  therefore requires an ADR.
- **Rule 1 (upgrade-safe).** Any new doctype must live in the `remedisys_healthcare_ai`
  app, never in core. **Rule 2 (uninstall-safe):** uninstalling the app must drop the
  feedback data cleanly without breaking ERPNext Healthcare.
- **Jurisdiction — Mexico, LFPDPPP + NOM-024-SSA3-2010 (ADR-007).** A free-text patient
  comment is **PHI-adjacent**: it is personal data tied to an identified patient and
  may contain health information. It must be collected with a lawful basis, stored
  minimally, kept in-jurisdiction, and **never written to logs (Rule 10)**.
- **API pattern (§3, Rule 11).** All access goes through whitelisted `api/v1/<module>`
  methods — never `/api/resource/`. Patient-facing submission (if any) must not require
  a Desk login.
- This is **Phase 4** work (Operations & Reporting). It is *not* started until
  prioritized; this ADR records the design so it can be picked up without re-deciding.

## Decision

Introduce a custom doctype **`Patient Feedback`** in the `remedisys_healthcare_ai`
app as the single structured source for patient satisfaction, collected through
clinic-controlled channels, and read by a new `get_patient_satisfaction` report.

1. **Doctype `Patient Feedback`** (module: Remedisys Healthcare AI), fields:
   - `patient` (Link → Patient), `appointment` (Link → Patient Appointment, optional),
     `practitioner` (Link → Healthcare Practitioner, optional), `company` (Link → Company).
   - `rating` (Int 1–5), `nps` (Int 0–10, optional), `comment` (Small Text, optional).
   - `source` (Select: `Post-visit link` / `Front desk` / `SMS`), `submitted_at` (Datetime),
     `submitted_by` (Data — staff user or `"patient"` for self-service; never a free identifier).
   - `track_changes: 1`; indexes on `patient`, `practitioner`, `appointment`, `submitted_at`.
2. **Collection channels** (both clinic-controlled, no Desk login for patients):
   - **Post-visit link** — on checkout, the Phase 4 notifications module sends a
     tokenized one-time URL (WhatsApp/SMS) to a thin public submission endpoint. The
     token encodes the appointment, is single-use, time-bounded, and carries the lawful-
     basis/consent flag. No PHI in the URL beyond the opaque token.
   - **Front desk** — a whitelisted `api/v1` method for staff to enter feedback captured
     verbally, gated by `require_permission("Patient Feedback", "create")`.
3. **Report** — `get_patient_satisfaction` in `api/v1/providers/report.py` (it is a
   provider-performance report), returning the existing envelope: KPIs (NPS, avg rating,
   responses, promoters %), charts (rating distribution, by-provider, NPS trend), and a
   **recent-feedback table that is anonymized** (no patient name/MRN — show a masked id).
4. **Privacy & retention** — `comment` is treated as PHI-adjacent: scrubbed from all logs
   (Rule 10), excluded from any non-consented export, and subject to a retention window
   (default purge after N months, configurable). Aggregates and per-provider scores are
   not PHI; the report exposes those freely, but raw comments only to authorized roles.
5. **Permissions** — System Manager + Clinic Admin read/manage; Front Desk create; the
   public submission path writes via a server-side service with `ignore_permissions` scoped
   strictly to inserting one validated `Patient Feedback` row from a valid token (no other
   writes), which is the only sanctioned use of elevated permissions here.

## Alternatives Considered

1. **New `Patient Feedback` custom doctype (chosen).**
   - Pros: structured rating/NPS/comment with proper fields, indexes, permissions, and
     audit; upgrade- and uninstall-safe; keeps data in-jurisdiction; unstubs the report
     cleanly; reusable beyond reporting (e.g. quality dashboards).
   - Cons: first new custom doctype in Phases 1–4 (§7 exception); requires a collection
     channel and a privacy/retention review before go-live.

2. **Reuse an existing record (Communication / Patient Medical Record / a generic Note).**
   - Pros: no new doctype.
   - Cons: no structured rating/NPS fields → reporting needs fragile text parsing; pollutes
     the clinical record with operational data; weaker permissioning; conflates PHI scopes.
     Rejected.

3. **Third-party survey/NPS SaaS (Typeform, Delighted, Google Forms) with import.**
   - Pros: turnkey collection UX and analytics; no in-app collection code.
   - Cons: patient PHI leaves the jurisdiction/control (LFPDPPP + NOM-024 risk, ADR-007);
     data-ownership and DPA overhead; integration + reconciliation work; weakens the
     "Frappe is source of truth" model. Rejected for PHI-adjacent data.

4. **Defer indefinitely / drop the report.**
   - Pros: zero work; avoids the §7 exception.
   - Cons: leaves Screen 18 permanently incomplete; satisfaction/NPS is a standard clinic
     KPI the product roadmap lists. Acceptable only as the status quo until prioritized.

## Consequences

- **§7 amended** — logs the first sanctioned new custom doctype in Phases 1–4; future
  feedback-adjacent needs reference this ADR rather than re-litigating §7.
- New doctype JSON + controller under `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/`,
  plus a migration patch in `patches.txt` (no manual schema edits, §9).
- New whitelisted methods: `api/v1/providers/report.py::get_patient_satisfaction` (read) and
  a feedback submission/create path (`services/` + `api/v1`). FE: un-mock
  `reports/providers/patient-satisfaction` to `useReport("patient-satisfaction")` and add the
  i18n keys — the dynamic BFF route already has the slot.
- **Depends on the Phase 4 notifications module** for the post-visit link channel; until that
  exists, only the front-desk channel collects data, and the report is prospective.
- **Privacy review required before go-live** — lawful basis/consent text, retention window,
  log-scrubbing of `comment`, and the anonymized recent-feedback table. Coordinate with
  counsel on COFEPRIS/LFPDPPP classification (per §3).
- **Rule 2 (uninstall):** the install/uninstall CI gate must still pass — uninstalling the app
  drops `Patient Feedback` and its data with no orphaned references in core tables.
- **Re-evaluation triggers:** if a regulator requires feedback data residency/retention beyond
  what the doctype models, or if clinics demand richer survey logic, revisit (possibly a
  dedicated survey doctype or a vetted in-jurisdiction vendor).

## Verification

- `Patient Feedback` doctype installs on `bench migrate`; `bench --site … list-apps`/desk shows
  it owned by the Remedisys module.
- `get_patient_satisfaction` returns the standard `{meta, kpis, charts, table}` envelope with
  real data once feedback rows exist; smoke test added to `tests/test_reports_smoke.py`.
- Install/uninstall CI gate (`.github/workflows/install-uninstall.yml`) stays green with the
  new doctype present.
- A log audit confirms no `comment` text appears in any log line or Sentry event (Rule 10).
- Frontend: `/reports/providers/patient-satisfaction` renders live data (no mock import).

## References

- Constitution §2 (product scope), §3 (jurisdiction, API pattern), §7 (no new doctypes —
  exception), §9 (migrations), Rules 1, 2, 10, 11
- `docs/REPORTS_API.md` §15 (report shape) and §6-F (the gap)
- ADR-007 (jurisdiction: Mexico, LFPDPPP + NOM-024-SSA3-2010)
- Phase 4 (Operations & Reporting) — `docs/PHASES.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-20 | Sarvesh | Initial version (header backfilled from git history) |
