# ADR-081: A structured subject (site + side) on every report, and summaries shaped by the report's own template

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — requested by Divyanshu, 2026-09-22
- **Builds on:** [ADR-080](adr-080-report-type-templates-for-lab-extraction.md) (a template per report type, chosen by the model and created when missing)

---

## 1. Context

Two gaps surfaced while reviewing a real ophthalmic OCT report against the same file read by
an external model.

**Which side was examined is loose prose.** The report's header prints `OD ○  ● OS` — a
radio selector, filled on the eye that was scanned. Extraction reproduces that faithfully
(ADR-080 page rendering made it reliable: 4 of 4 runs), but it lands *inside* a paragraph of
transcribed text. Prose cannot be validated, cannot be queried, cannot be asserted in a
test, and — the important part — cannot be **missing visibly**. When the model omits it, the
record simply does not mention the side, and nothing indicates that a fact is absent.

Measured: the marker survived 3 of 3 runs, but an explicit statement of which eye appeared
in roughly 1 of 3.

**The summary is written by one prompt for every report on earth.** `summarize_narrative_report`
loads a single `report_narrative_summary_v{n}.txt` and is handed the transcription as text.
An eye scan, a genetic report and a pathology slide are summarised by identical
instructions. This is precisely the "one generic prompt for everything" problem ADR-080
solved for extraction — still unsolved one layer up. Evidence: on a transcription that
contains `OD ○  ● OS`, the summary reported "no explicit eye-specific findings". It had the
answer in front of it and hedged.

## 2. Decision

### 2.1 A structured `subject` on every narrative report

Each entry in `narrative_reports[]` gains:

| Field | Meaning |
|---|---|
| `body_site` | What was examined, in ordinary words — `eye`, `ear`, `knee`, `kidney`, `breast`, `lung`, `tooth`, `spine`. Empty when the report is not site-specific |
| `side` | `left` · `right` · `bilateral` · `not applicable` · `not stated` |
| `evidence` | How it was determined, in the report's own terms — e.g. "filled selector beside OS" |

**Deliberately generic, not ophthalmic.** `side`/`body_site` carries left-vs-right ear, limb,
kidney, breast and lung equally. The report's own notation (`OD`/`OS`, `L`/`R`, `Izq`/`Der`)
stays in `evidence`; the structured value is normalised so it can be compared across
specialties and languages.

`not stated` is a first-class value, distinct from empty. A report that does not say which
side is a different fact from a report we failed to read.

### 2.2 Summaries shaped by the report's template

`AI Chat Template` gains `summary_guidance`: what a summary of THIS kind of report must
always state. An eye-scan template says "always state which eye and how you know"; a genetic
template says "always list each gene and its classification".

Extraction stamps the chosen template's name onto each narrative entry, so the summary path
— which already receives `narrative_reports` — can load the template and apply its guidance
without a new link field or a second lookup path.

## 3. Consequences accepted

| Consequence | Detail |
|---|---|
| **The extraction response shape changes** | Every extraction now returns `subject` on each narrative entry, not only ophthalmic ones. The frontend reads this shape |
| **Guidance is AI-authored** | `summary_guidance` is written by the model along with the rest of the template. Under ADR-080's precedence rule it can shape a summary but can never override the summary prompt's own safety rules |
| **Not yet queryable** | `subject` is returned and displayed, but is not persisted to its own column, so "show me every left-eye scan" is not possible yet. Recorded here rather than implied |
| **A summary prompt version bump** | The guidance is injected into the summary prompt, so the prompt is versioned forward rather than edited in place — past `AI Prompt Log` rows keep describing the text they actually used |

## 4. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Keep side in prose, tell the template to always state it | Measured at roughly 1 in 3. Prose cannot be checked, and an omission is invisible |
| An ophthalmology-specific `eye` field | Solves one specialty and leaves ear, limb, kidney and breast with the same defect. The request was explicitly for every kind of clinician |
| Give the summariser the rendered page as well | Genuinely better and not ruled out, but it costs an image on every summary and does not fix the one-prompt-for-everything problem, which is the larger defect |
| A separate summary-template doctype | A second template library to keep in step with the first. The guidance belongs on the report type it describes |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — generic `subject` (site + side + evidence) on narrative reports; per-report-type `summary_guidance` |
