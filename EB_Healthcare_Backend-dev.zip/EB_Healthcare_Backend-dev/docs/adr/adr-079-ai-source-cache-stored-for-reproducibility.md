# ADR-079: External fetches are stored, for reproducibility rather than speed, with the retention number as the switch

**Doc status:** living · **Created:** 2026-09-18 by Divyanshu (AI-assisted) · **Updated:** 2026-09-18 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted — decision taken 2026-09-18.
- **Date:** 2026-09-18
- **Supersedes:** nothing. It builds the one doctype from [PR #493](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/493) that had been deferred.
- **Superseded by:** —
- **Related:** ADR-077 (Clinical Web enabled — this caches what that fetches), ADR-078 (PHI-1 at the chokepoints), CLAUDE.md §9.9 PHI-3 / PHI-4, §7 (custom doctypes), Rule 7.

## Context

With Clinical Web enabled (ADR-077), nothing is remembered between turns. Every
question re-downloads everything:

- A turn may carry **5 URLs** (`_MAX_URLS`), each with a `(5, 20)` connect/read budget and up to
  5 redirect hops. Three pasted links plus four follow-up questions = **twelve downloads of the
  same three pages**, and the clinician waits for each.
- PubMed makes **two** calls per turn (`esearch` + `esummary`) against a rate limit that is about
  3 requests/second site-wide without an API key. The code correctly **raises** on a rate-limit
  page rather than reporting "no literature", so throttling is visible as a failure.

Those are the speed arguments, and on their own they do **not** justify a stored doctype — an
in-process cache would have fixed the waiting and created no obligations at all. The reason this is
persisted is different:

> **A source changes.** A guideline is revised, a page is taken down, a server is briefly
> unreachable. Without a stored copy, reopening a conversation re-fetches, and the answer the
> clinician read yesterday can no longer be traced to the words that produced it.

`AI Source Reference` already stores a short **snippet** on the message, permanently, so the
smallest form of that proof never expires. What is missing is the full text the model reasoned over.

The team was shown both options — an in-memory cache (speed only, no obligations) and a stored one
(speed plus reproducibility, plus retention and erasure duties) — and chose the stored one.

## Decision

**Store external fetches in a new `AI Source Cache`, and make the retention number the switch.**

1. **`ComplianceProfile.source_cache_retention_days` is both the permission and the promise.**
   `0` means nothing is stored. A market enables caching only by naming a period it is willing to be
   held to. **There is deliberately no second boolean** that could disagree with the number — the
   defect this whole area keeps producing is two facts that drift apart.
2. **Set to 30 days in both markets.** A month covers revisiting recent work; past that, the
   permanent record is the citation snippet, which never expires. Shorter is safer and this is one
   line per market.
3. **The purge ships in the same change** — `purge_expired`, daily, in `hooks.py`, bounded per run,
   never raising (Rule 7). PHI-3 exists precisely because a number without a job is a false promise,
   so the number was `0` until the job existed.
4. **Expiry is enforced on read, not only by the job.** `get()` filters on `expires_at > now`. If
   expiry were only the job's business, a declared retention would really mean "up to a day longer
   than we told you".
5. **The key includes the session user.** One clinician's fetch is never served to another: a page
   reachable with one person's access is not necessarily one the next person may see, and a shared
   cache would quietly turn "I can reach this URL" into "everyone can". The case this exists
   for — the same clinician asking follow-ups — is unaffected.
6. **`context_patient` is the erasure handle (PHI-4).** A pasted page can be a page from another
   clinical system about a real patient, so a cached copy can hold patient data.
7. **A cache hit never skips a gate.** The compliance check and the pasted-address identifier screen
   both run *before* the cache is consulted. Otherwise fetching a bad URL once would make it
   permanently allowed for as long as the row lived. Asserted by test.

### `track_changes` is 0 — a deliberate exception to §7

§7 says every custom doctype carries `track_changes: 1`. This one does not, and the reason is not
convenience: Frappe's version history would keep a copy of `text_content` in the `Version` doctype,
**including content this doctype exists to delete on schedule**. Versioning a cache would defeat the
retention promise it was built to keep, which is a worse outcome than the audit value §7 protects.
The rows are derived data — nothing here is authored by a person, and the original is the website.

## Alternatives considered

| | Approach | Pros | Cons |
|---|---|---|---|
| **A** | In-process cache for the life of one request | Fixes the repeated downloads within a turn. **Zero new obligations** — nothing stored, PHI-3/PHI-4 never engage | Does nothing across turns, which is the actual complaint, and nothing at all for reproducibility |
| **B** | **Stored doctype, retention-gated, user-scoped (chosen)** | Speed across turns **and** a reopened conversation shows what was really read. Retention and erasure are handled in the same change | A second place patient data can live. Needs a purge, an erasure handle, and a retention decision |
| **C** | Store a content **hash** only, not the text | Proves the source changed since we read it, at almost no storage and no PHI risk | Proves a change happened; cannot show *what was read*, which is the point. Useless for answering "on what basis did the AI say that" |
| **D** | Cache PubMed only; never cache pasted pages | PubMed responses are public bibliographic data and can never be PHI, so PHI-4 never engages at all | Backwards on the merits: PubMed records are **stable**, so caching them buys speed but little reproducibility, while pasted pages — the volatile ones — are exactly what needs preserving |

**Why B.** **A** is the honest cheap option and was offered first; it loses only because the team
asked for reproducibility, which it cannot provide at any price. **C** is a genuinely clever middle
and is the right answer if the requirement were ever only "tell me if the source moved" — it loses
because the requirement is "show me what the model read". **D** inverts the risk/benefit: it avoids
the PHI question by declining to cache precisely the content whose volatility created the
requirement.

**What would falsify this choice:** if cached pages turn out to routinely contain patient data —
i.e. clinicians habitually paste links from other clinical systems rather than from literature —
then the store is a PHI duplicate in normal operation rather than in the exceptional case, and the
right answer collapses to **D** plus a refusal to cache pasted pages at all. That is measurable:
count rows with a non-null `context_patient` after a month.

## Consequences

- ⚠️ **PHI-4 is satisfied in form but not yet in practice, and this is recorded rather than
  glossed.** `purge_for_patient()` exists and is tested — but **no patient-erasure path exists
  anywhere in this app**, verified 2026-09-18, while both profiles declare `right_to_erasure=True`.
  PHI-4 permits shipping a duplicated store only when the change "records explicitly that it did not
  and why". This is that record. The handle is ready for the erasure path when somebody builds it;
  see `docs/KNOWN_ISSUES.md`.
- **Tests became order-dependent, and that had to be fixed explicitly.** A stored cache meant one
  test's fetch of `https://g/f` served the next test that reused the URL, so a test asserting "a page
  that cannot be fetched raises" passed **without ever attempting a fetch**. Both affected suites now
  state `source_cache_retention_days=0` in their profile helper, making the dependency visible rather
  than accidental. This is a general hazard of persistent caches in tests and is worth remembering.
- **A rate-limit or error page is never cached** — only a response that parsed. Caching one would
  turn a throttled minute into days of "no literature".
- **A cached body that will not parse is treated as a corrupt row**, not a provider failure: the code
  falls through and fetches live rather than reporting an error the clinician cannot act on.
- **Storage is bounded** at 200,000 characters per row on top of the caller's own truncation.
- The daily job now runs three purges (template edit sessions, source cache, consent lifecycle).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-18 | Divyanshu (AI-assisted) | Initial version — records the decision to persist external fetches for reproducibility, with the retention number as the switch and the purge in the same change |
