# ADR-062: Practitioner self-service availability, built on core's Practitioner Availability doctype

**Doc status:** living · **Created:** 2026-09-08 by Divyanshu (AI-assisted) · **Updated:** 2026-09-15 by Divyanshu (AI-assisted) · **Version:** 5.0

- **Status:** Proposed
- **Date:** 2026-09-08
- **Supersedes:** —
- **Superseded by:** —

## Context

Only an admin can set a practitioner's schedule today, via named weekly-recurring `Practitioner Schedule`
docs attached to `Healthcare Practitioner.practitioner_schedules`. There is no way for a practitioner to
declare, for a specific date, that they are absent, working reduced hours, or working *extra* hours beyond
their normal schedule.

Two pre-existing gaps this feature runs into (`docs/flows/GAPS_APPOINTMENT_AND_RESCHEDULE.md`):

- **A-3.** Holiday/leave/unavailability checks are consulted only in the advisory slot-picker endpoints,
  never re-checked when a booking is actually written.
- **C-1.** Staff booking (`appointments/api.py::get_available_slots`) and patient-portal booking
  (`patient_portal/api.py::get_my_available_slots`) are separate implementations. **Both already call
  `get_practitioner_unavailability()`**, i.e. both already read core's `Practitioner Availability`
  doctype's `Unavailable` rows — nothing in this app writes to it, and nothing reads its `Available` rows
  at all.

Core's `Practitioner Availability` doctype takes exactly two direct inputs — `type` (Available/Unavailable)
and a date/time range — with no derived or computed fields. Its own `validate()` already blocks saving an
Unavailable record that overlaps an existing, non-cancelled `Patient Appointment`, and blocks overlapping
Available records against each other. Its DocPerm rows grant access to core's `Physician`/`Nursing User`
roles — but `scripts/setup_roles.py:70-81` deliberately migrates every user off the `Physician` role onto a
custom `Practitioner` role, and `eb_docperm_spec.json` has no entry for this doctype. The write access
isn't missing; it's pointed at a role nobody holds anymore.

This app already has a proven pattern for a practitioner writing to a doctype they have no DocPerm access
to: `providers/api.py::update_my_provider_profile()` resolves the caller's own record via
`_session_practitioner()` (session-derived, never a request param) and saves with `ignore_permissions=True`.

## Decision

**Practitioners self-manage availability by writing directly to core's `Practitioner Availability` doctype,
through new whitelisted methods copying the `update_my_provider_profile` ownership pattern — mirroring
core's own fields exactly (type, date, start/end time, reason), not a derived or named-schedule concept.
Both `Available` and `Unavailable` are fully functional, including on the read/slot-generation side. No new
custom doctype is introduced.**

1. **The screen exposes exactly core's own fields** — `type` (Available/Unavailable), `date`, `start_time`,
   `end_time`, and (Unavailable only) `reason` — with no reference to named `Practitioner Schedule` rows at
   all. An earlier design asked the practitioner to toggle their own named schedules on/off instead; dropped
   in favour of mirroring core directly (see Alternatives). *(Superseded in part by decision 6 — the shipped
   fields are `start_date`/`end_date`, not a single `date` — and extended by a later small addition: core's
   own `note` field, free text, accepted for both types since the doctype places no `depends_on` restriction
   on it, unlike `reason`.)*
2. **Write:** `providers/api.py::set_my_availability_override(type, date, start_time, end_time, reason=None)`
   and `cancel_my_availability_override(name)`. Both resolve the caller's own practitioner via
   `_session_practitioner()`, then `doc.insert(ignore_permissions=True)` / `doc.cancel(...)` — core's own
   `validate()` still runs (ignore_permissions bypasses DocPerm, not document validation), so its
   overlap/conflict checks remain in force unchanged.
3. **Read, `Unavailable` direction — already built, no new code.** Both `get_available_slots` and
   `get_my_available_slots` already call `get_practitioner_unavailability()` and merge its rows in.
4. **Read, `Available` direction — new.** `services/availability.py::generate_override_slots(practitioner,
   date, ...)` reads `Available` rows and produces additional bookable slots for that window, called from
   both booking functions alongside their existing base-schedule generation. This is the one genuinely new
   piece of read-side logic this feature adds — nothing in this app has ever generated slots from anything
   but the weekly `Practitioner Schedule` template before. **Before generating, it subtracts whatever the
   normal weekly schedule already covers that weekday from the `Available` window, and generates slots only
   for what's left** — otherwise an `Available` override overlapping normal hours would produce duplicate
   slot entries alongside the base-schedule generation. Generated slots use a duration resolved by
   `_default_slot_minutes()` — `Healthcare Settings.default_appointment_type`'s own `Appointment
   Type.default_duration` — not a private constant; falls back to a `_FALLBACK_SLOT_MINUTES` of 20 only if
   that chain is unset. *(Corrected 2026-09-10 — see decision 10. Originally shipped as a bare 20-minute
   constant, matched by hand to `scripts/seed/seed_practitioner_schedules.py`'s own separate constant; core's
   doctype still has no per-record duration/capacity field to read instead, which is why this remains a
   clinic-wide value rather than something read off `Practitioner Availability` itself.)*
5. **Write-time guard, `services/availability.py::assert_bookable(...)`**, called from both booking
   create/reschedule paths (staff and patient-portal) before a save commits. Checks, in order: not inside a
   self-declared `Unavailable` window; not on a holiday or during approved leave
   (`check_employee_wise_availability`); if outside the normal weekly schedule, falls inside a declared
   `Available` window. **This closes gap A-3 in full** — holiday/leave enforcement at write time was
   originally scoped out of this feature and is folded in here instead, since the guard already has to exist
   for the feature's own data.
6. **A date range, plus core's own Repeat/weekday fields, not a single date.** The write API takes
   `start_date`/`end_date` (a continuous range) and, matching core's own `Practitioner Availability` fields
   exactly, `repeat` (Never/Daily/Weekly/Monthly) and — only meaningful for `repeat="Weekly"` — the doctype's
   seven weekday checkboxes. Requested by the product owner after seeing the shipped screen (2026-09-08);
   see the correctness finding below for why this could not be a thin pass-through of those fields.
7. **Correctness finding, discovered while scoping decision 6 — core never enforces its own Repeat/weekday
   fields.** `get_practitioner_unavailability()`, the core function this app's slot pickers and write guard
   called directly (decisions 3 and 5, as first shipped), is a pure `start_date<=date<=end_date` containment
   check — it never reads `repeat` or the weekday checkboxes. A "Weekly, Monday only" declaration would
   therefore have been silently treated as "every day in the range" everywhere this app called that function,
   blocking (or, for `Available`, opening) every day in the range rather than only the ticked weekday — a
   control that visibly offers "pick specific days" while doing something else entirely. **Fix:**
   `services/availability.py::applies_on_weekday(row, date)` — true unless `row` is `repeat="Weekly"` and
   `date`'s weekday isn't ticked — and `get_unavailability_for_date(practitioner, date)`, a weekday-aware
   drop-in replacement for core's function, now called at all three sites that used to call core's function
   directly (`appointments/api.py::get_available_slots`, `patient_portal/api.py::get_my_available_slots`,
   `services/availability.py::assert_bookable`). The same filter was added to `_override_ranges` (the
   `Available`-direction read, feeding `generate_override_slots`). `Daily`/`Monthly`/`Never` have no extra
   distinguishing fields on the doctype (the weekday checkboxes `depends_on repeat=="Weekly"` only) — they
   still mean "every day in the range," which is what the doctype can actually express, not a shortcut taken
   here. *(Superseded in part by decision 8: `list_availability_overrides`, the self-service list view, no
   longer applies this filter at all — it dropped per-date scoping entirely.)*
8. **The self-service list shows everything, not one date's worth — removed the "viewing date" filter.**
   `list_availability_overrides`/`list_my_availability_overrides` dropped their `date` parameter entirely and
   now return every submitted override for the practitioner (past, current, future) in one list. Requested by
   the product owner after seeing the shipped screen (2026-09-08), along with switching the display from
   stacked cards to a table. **Deliberately does not touch decision 7's fix** — `applies_on_weekday` and
   `get_unavailability_for_date` are unrelated to this list and remain exactly as they were, still governing
   whether a row actually blocks/opens a *booking*, which is a different question from whether this list
   *displays* the row.
9. **Read-only holiday list, shown alongside the availability screen — new, `services/providers.py::
   get_practitioner_holidays(practitioner)`.** Resolves `Healthcare Practitioner.custom_company` ->
   `Company.default_holiday_list` -> that Holiday List's `holidays` child rows, sorted ascending by date.
   **Deliberately not Employee-based**, even though core's own holiday/leave check
   (`check_employee_wise_availability`, already called by decision 5's `assert_bookable`) resolves the
   practitioner's Employee first — Alternative 4 below already verified zero `Healthcare Practitioner`
   records in this app carry an `employee` link, so that path returns empty for every practitioner here.
   **This surfaced a separate, pre-existing correctness gap while researching this decision**: because
   `check_employee_wise_availability`'s `employee` lookup always comes back `None` in this app, its holiday
   and leave checks inside `assert_bookable` are a silent no-op — a booking on a company holiday is never
   actually rejected today, despite decision 5's write-time guard listing "holiday / approved leave" as its
   first check. Recorded, not fixed here (out of scope — this decision is a read-only display, not a change
   to booking enforcement): `docs/KNOWN_ISSUES.md` §"Holiday/leave enforcement in assert_bookable is a silent
   no-op". Read via `frappe.get_all`/`frappe.db.get_value`, both of which do not check permissions by
   design (`Holiday List`'s own DocPerm is HR-only) — safe here because the function only ever resolves the
   caller's own session-derived company, never an arbitrary one (`api/v1/providers/api.py::get_my_holidays`
   always calls it with `_session_practitioner()`'s result). No new doctype, no schema change, no write path
   — purely additive to the same screen decisions 1-8 already built.
10. **Correction to decision 4's duration source (2026-09-10).** The 20-minute constant decision 4 shipped
    with was a private guess duplicating a *different* private guess (`scripts/seed/seed_practitioner_
    schedules.py`'s own `SLOT_DURATION`), kept in sync only by a code comment asking the reader to trust
    they matched. Found while investigating why a practitioner's `Available`-override evening slots (20-min
    grid) visibly didn't match their normal-schedule slots (15-min grid) in the same booking day. Fixed:
    `services/availability.py::_default_slot_minutes()` resolves `Healthcare Settings.default_appointment_
    type` → that Appointment Type's own `default_duration` — a value the clinic has actually configured,
    read fresh on every call rather than baked in at import time — falling back to the renamed
    `_FALLBACK_SLOT_MINUTES = 20` only when that chain is unset. Callers may still pass an explicit
    `slot_minutes` to bypass resolution entirely (existing tests do). Does **not** fix the underlying
    mismatch this surfaced — see Consequences.
11. **Override-slot duration now follows the appointment type actually being booked, when one is known
    (2026-09-10) — supersedes alternative 11's rejection below.** Decision 10's own alternatives comparison
    rejected threading `appointment_type` through as "well beyond scope," reasoning that neither booking
    picker took one and every call site would need new plumbing. That reasoning was checked against the
    actual frontend, not assumed, and turned out to be wrong for three of the four real callers:
    `new-appointment-dialog.tsx` already selects `visitTypeKey` (an Appointment Type) in Step 1, before the
    Schedule step ever requests slots; the reassign dialog and the reschedule flow both already carry the
    original appointment's `appointment_type` in the object they're working from. Only
    `patient_portal/api.py::get_my_available_slots`'s frontend caller is unverified (not present in this
    repo). **Built:** `get_available_slots`/`get_my_available_slots` gained an optional `appointment_type`
    parameter, passed to a new `services/availability.py::_slot_minutes_for(appointment_type)` — that type's
    own `default_duration` when it resolves to one, else falling through to decision 10's clinic-wide
    `_default_slot_minutes()` unchanged. `generate_override_slots`'s duration-resolution order is now:
    explicit `slot_minutes` (unchanged, existing tests use this) → `appointment_type`'s own duration →
    clinic-wide default. Wired through the three confirmed frontend callers; the patient-portal surface is
    deliberately left unwired pending its own check. **Does not by itself close the schedule-vs-override
    mismatch** recorded under decision 10 — an override can still differ in granularity from the
    practitioner's own normal-schedule slots even when it now correctly matches the booked appointment type
    — see the updated Consequences bullet and `docs/KNOWN_ISSUES.md`.

12. **Front Desk task on declaration, 2026-09-14 — closes an operational
    dead end found live. Corrected the same day — see decision 13 for the
    shipped shape; kept here as a record of the first cut.** Marking
    Unavailable while it conflicts with existing appointments was, until now,
    a pure dead end: core's own `validate_existing_appointments()` rejects
    the save and names the conflicting appointments in its error text, and
    nothing in this app ever did anything with that information — the
    practitioner stayed blocked, the appointments stayed exactly as they
    were, and nobody was told to act. Two related behaviors, both scoped to
    `EB_Front Desk`:
    - **Unavailable, conflicts with appointments — doctor-initiated, never
      automatic.** `find_unavailable_conflicts()` (`services/availability.py`)
      pre-checks the identical conflict core would find — same non-cancelled/
      non-cancelled-docstatus appointment set, same interval-overlap math —
      read-only, before ever attempting the insert. `set_my_availability_override`
      now returns `{"conflict": true, "conflicts": [...]}` at 200 (a real
      business state, not an HTTP error) instead of letting core's exception
      propagate as a dead-end error. The frontend shows the conflicting
      appointments and a "Create task" button; only when the practitioner
      explicitly clicks it does ~~`create_availability_conflict_task()`~~
      *(this endpoint was removed the same day — decision 13)* create
      the Task — re-deriving the conflict list fresh (never trusting whatever
      the client last saw, which could be stale) and resolving `practitioner`
      from the session, never the request.
    - **Available, or Unavailable with nothing to reassign — automatic.**
      When the save actually succeeds (no conflict), a Task is created
      without any button: for Available, "new slots opened, go fill them";
      for a clean Unavailable save, situational awareness that a doctor is
      out. Both are informational, not blocking anything, so there is no
      "review before creating" need the conflict case has.
    - **Both paths dedupe on an identical Task `subject`** — `subject` is
      built deterministically from (practitioner, start/end date, start/end
      time), so it doubles as the dedup key: retrying an already-blocked or
      already-declared window does not pile up a second Task for the same
      problem. Core `Task` has no reference-doctype field to hang a dedup
      check on instead (checked directly against
      `frappe/projects/doctype/task/task.json`) — an exact-subject match was
      the only dedup mechanism available without a schema change.
    - Two new `notify()` event types (`practitioner_unavailable_conflict`,
      `practitioner_availability_declared`) — `EVENT_TYPES` is a closed set
      by design (services/notifications.py), so both had to be added there,
      not just used.

13. **Same-day correction, 2026-09-14 — ToDo not Task; notify widened to
    Admin; no-backdating; a cancel-guard; two unrelated real bugs found and
    fixed.** Decision 12 shipped against the wrong doctype and an
    incomplete notification target — both corrected within the same day,
    before release, once checked against how "My Work" actually works.
    - **`Task` was the wrong doctype — corrected to `ToDo`.** "My Work"
      (`tasks/api.py::_fetch_todos`, `inbox-tab.tsx`) is backed by core's
      `ToDo` doctype, not `Task` — `Task` is a Projects-module concept this
      app's task list never reads. `create_front_desk_task()` now inserts a
      `ToDo` with `allocated_to=None`, the exact shape
      `encounters.api._create_refund_task_for_appointment` already
      established as "unassigned, claimable Front Desk queue item" — not a
      new mechanism. Dedup changed to match: an exact match on `ToDo.description`
      (ToDo has no separate `subject` field), skipped when a non-cancelled
      row with that description already exists.
    - **The conflict button no longer calls a bespoke backend endpoint.**
      `create_availability_conflict_task` and its BFF route
      (`api/providers/me/availability/conflict-task`) are removed. The
      button instead opens the **actual** My Work task-creation overlay —
      `CreateTodoForm` wrapped in a `Sheet` (`components/narzim/inbox/todo-tab.tsx`
      + `inbox-tab.tsx`'s own "New Task" panel chrome, mirrored rather than
      imported wholesale into `practitioner-availability-card.tsx`) —
      pre-filled with the conflicting appointments (patient name + appointment
      ID in brackets, dd/mm/yyyy + 12-hour time), the practitioner's name
      **and ID in brackets**, the stated reason, and a due date equal to the
      declaration's start date. Submission goes through the existing
      `useCreateTodo()`/`create_todo()` flow — creating a `ToDo`, never a
      `Task` — so the conflict path and the automatic path now produce the
      identical kind of record, just via different trigger (button vs.
      automatic).
    - **Automatic path widened: `notify()` now targets Front Desk AND
      Admin**, not Front Desk alone — `_admin_users()` added alongside the
      existing `_front_desk_users()` in `services/providers.py`, both
      passed to `notify()`. Reason: a notification's own "Open" action
      lands on My Work, so an unassigned `ToDo` must actually exist there
      for that link to open onto something — this reverses an interim
      "notify only, no ToDo" version tried the same day and found
      insufficient for exactly that reason.
    - **No-backdating.** Nobody may mark himself Available or Unavailable
      for a `start_date` before today. Enforced in both
      `set_availability_override()` and `set_my_availability_override()`
      (defense in depth — the same check exists at the service layer and
      the whitelisted-wrapper layer, so a future direct caller of the
      service function is still protected), plus client-side: the date
      inputs carry a `min` attribute and the form's own validation message
      blocks submission before the request is even sent.
    - **Cancel-guard.** `cancel_availability_override()` now refuses to
      remove an **Available** override if a `Patient Appointment` was
      booked into its window — re-running `find_unavailable_conflicts()`
      against the override's own start/end date and time before allowing
      the cancel, throwing a `ValidationError` naming the blocking
      appointment(s) if any exist. Scoped to `Available` only: cancelling an
      `Unavailable` declaration never blocks anything, since removing "I'm
      out" cannot strand a booking the way removing "these hours are open"
      can.
    - **Two real, pre-existing bugs found and fixed in passing — neither
      specific to this feature.** (a) `notify()`'s normal delivery path
      (`frappe.enqueue(..., enqueue_after_commit=True)`) silently delivers
      nothing whenever a document was already written earlier in the same
      request — confirmed via isolated reproduction scripts, and confirmed
      present for other, unrelated pre-existing records
      (`TASK-2026-00016`, `HLC-APP-2026-00326`) via their own
      "notification fanout failed" Error Log entries. Since
      `set_my_availability_override` always writes a `Practitioner
      Availability` (or a `ToDo`) before calling `notify()`, every call here
      would hit that failure. Fixed narrowly with a new `force_sync: bool`
      parameter on `notify()` (`services/notifications.py`) that forces
      `now=True` (synchronous, in-process) instead of the default deferred
      Redis-queued path — used only at this call site; the shared
      chokepoint's default behaviour for every other caller is unchanged.
      The broader reliability question (why a prior write breaks the
      deferred path at all) is not root-caused at the Frappe-internals
      level and is out of scope for this ADR. (b)
      `api/v1/notifications/api.py` requested a nonexistent `description`
      SQL column on core's `Notification Log` (the doctype only has
      `email_content`) — this broke the **entire** notifications list page,
      for every user, for every notification type, with an HTTP 500. Found
      while verifying this feature's own notifications were not appearing;
      `bench migrate` correctly did nothing (there was never a field to
      migrate — `description` was never a real column). Fixed by reading
      `email_content` in both places `description` was requested.

14. **Same-day-but-not-really correction, 2026-09-15 — the automatic path's "one named owner" (decision
    13) always resolved to the `Administrator` system account, never a real Front Desk person.** Found
    live while investigating an unrelated-looking report ("marked a practitioner unavailable but slots
    still show when booking" — that part turned out to be correct behaviour, the declared window was
    9 AM-5 PM, not the full day). Checking whether the Front Desk notification fired for that declaration
    surfaced this instead: it had fired, and created a ToDo, but `allocated_to: Administrator`.
    - **Root cause.** `_front_desk_users()[0]` (decision 13's own "deterministic, alphabetical by full
      name" pick) is not actually a pick among real staff — Frappe auto-grants every newly-created role,
      `EB_Front Desk` included, to the `Administrator` system account, and "Administrator" sorts before
      every real full name in this dataset ("Ad" < "Al" Rivera < "Am" Salinas). The single-owner design
      itself was sound reasoning (decision 13's stated goal: "tell the recipient exactly one person 'this
      is yours'"); the alphabetical tiebreak just never had a way to exclude a non-human account it didn't
      know existed.
    - **Fix: stop picking one owner — create a ToDo for every recipient instead.**
      `create_front_desk_task(description, recipients, priority)` now takes the full recipient list
      explicitly (built once, by the caller, from `_front_desk_users() + _admin_users()`, deduped) and
      inserts one `ToDo` per recipient, skipping only a recipient who already holds a non-cancelled ToDo
      with this exact description (per-recipient dedup, replacing the old global "does any such ToDo
      exist at all" check — so a partial retry still fills in whoever is missing rather than creating
      nothing for anyone). `set_my_availability_override` builds that recipient list once and passes the
      identical list to both `create_front_desk_task()` and `notify()`, so the two can never disagree
      about who was told. `notify()`'s `ref_doctype`/`ref_name` now point at the `Practitioner
      Availability` record itself, since there is no longer one canonical ToDo to reference.
    - **`Administrator` is not filtered out.** It still receives its own ToDo alongside real staff,
      since it does hold the role — considered and deliberately not done here (see Alternatives 18-19
      below); this decision only removes the "pick just one" behaviour that made `Administrator`
      *exclusively* the recipient.

## Alternatives Considered

1. **Reuse core's doctype via a role bridge** (restore the `Physician` role to practitioners).
   Cons: reverses a deliberate migration and grants everything else that role's DocPerm carries — unaudited,
   much larger blast radius than needed.
2. **A new custom doctype**, owned entirely by this app.
   Cons: the existing-appointment conflict check would need writing and testing from scratch (core already
   has it, tested); both slot-computation sites would need new code regardless — more new code for an equal
   or weaker result.
3. **Extend `Doctor Profile` with a child table of overrides.**
   Cons: mixes identity data with availability data; a child table can't be queried independently, so an
   admin "who's out today" view becomes a scan across every profile.
4. **Core `Leave Application`** against the practitioner's linked Employee.
   Cons: **verified — zero code anywhere in this app links a `Healthcare Practitioner` to an Employee**; no
   field for a partial-day window either.
5. **Reuse core's doctype via session-ownership + `ignore_permissions` (chosen mechanism).**
   Pros: existing-appointment conflict check for free, already tested; the ownership pattern is already
   proven safe elsewhere in this app.

**Two design iterations within option 5, recorded because both were live proposals before landing here:**

- **Named-schedule toggles, dropped.** First proposal: the practitioner ticks their own `Practitioner
  Schedule` rows on/off by name (e.g. "Morning Shift"), and the backend translates the ticked name into a
  time window. Dropped for directly mirroring core's own `type` + time-range fields instead — one fewer
  translation layer, and it stops the screen inventing a "shift" concept that doesn't exist anywhere else in
  the system (a real point of confusion caught mid-design).
- **`Unavailable`-only, widened to both.** First proposal shipped only `Unavailable`, since it's the only
  direction either booking screen already reads; `Available` would have saved successfully while silently
  producing no bookable slots — a save that looks like it worked but does nothing. Widened to build
  `generate_override_slots` (decision point 4) so `Available` is genuinely functional on both booking
  screens from the start, rather than shipping a control that lies about what it did.

**Why 1–4 lose, specifically:** unchanged from the original reasoning — role-bridge grants too much,
building fresh duplicates core's already-tested conflict check, `Doctor Profile` has the wrong query shape
for admin reporting, and `Leave Application` has a verified-missing dependency and no partial-day field.

**Alternatives for decision 9 — how to resolve "the practitioner's holiday list":**

6. **Employee-based** (mirror core's own `check_employee_wise_availability`).
   Cons: **verified dead by alternative 4 above** — no `Healthcare Practitioner` in this app carries an
   `employee` link, so this always returns empty; building it would duplicate a path this ADR already proved
   doesn't fire.
7. **Company-based — `custom_company` -> `Company.default_holiday_list` (chosen).**
   Pros: matches the "home clinic" convention already used in `dashboard.py`/`report.py`; zero schema change;
   works today wherever a Company has one configured.
8. **Employee-then-Company fallback chain.**
   Cons: the Employee branch can never fire (per alternative 6) — this is alternative 6 padded onto 7, not
   real extra robustness; rejected on that basis alone.
9. **New `holiday_list` field directly on `Healthcare Practitioner`.**
   Cons: schema change + migration patch for a feature explicitly scoped read-only; `Company` already carries
   this exact concept in core — redundant, and scope creep beyond what was asked.

**Why 6, 8 and 9 lose, specifically:** 6 is provably empty for every practitioner in this app (same verified
fact as alternative 4); 8 adds a code path that can never execute; 9 duplicates data core's own `Company`
doctype already holds, for no functional gain, at the cost of a schema change this feature does not need.

**Alternatives for decision 10 — where the override-slot duration should come from:**

10. **Resolve `Healthcare Settings.default_appointment_type → Appointment Type.default_duration` (chosen).**
    Pros: this is the exact value decision 4's own original text already pointed at ("the clinic-wide
    default appointment duration already used elsewhere") without ever actually reading it; no schema
    change; one function edited.
    Cons: still one site-wide number, not per-department or per-appointment-type.
11. **Thread a real `appointment_type` argument through the whole call chain** (frontend → both
    `get_available_slots` functions → `generate_override_slots`) and read that specific type's own
    `default_duration`.
    Cons *(as first assessed, without checking the actual frontend)*: neither booking picker endpoint takes
    an `appointment_type` today — this would touch the staff booking dialog, the reassign dialog, the
    reschedule dialog, and the patient-portal booking screen just to add one field, well beyond "stop
    hardcoding one number."
    **Superseded 2026-09-10 (decision 11) — this rejection was based on an assumption, not a check.**
    Three of the four callers already had an Appointment Type sitting in local state before ever requesting
    slots (verified in the frontend source, not assumed); only the value was never sent. Built as decision
    11, optional and backward-compatible, with the fourth caller's frontend left unverified rather than
    guessed at.
12. **A new dedicated setting** (e.g. an `AI Settings` field or a `site_config.json` key) just for this slot
    length.
    Cons: invents a second place to configure "appointment duration" when `Appointment Type.default_duration`
    already owns that concept for the rest of core Healthcare — the exact duplication this fix exists to
    remove, for a schema/fixture change with no offsetting benefit.
13. **Derive the duration from the practitioner's own normal-schedule slot duration that weekday**, instead
    of any clinic-wide value.
    Cons: undefined exactly in the case decision 4 was built for — a day the practitioner has no normal
    schedule at all — and ambiguous when a schedule carries multiple rows at different durations on the same
    day.

**Why 12 and 13 lose, specifically:** 12 duplicates a field core Healthcare already owns; 13 has no defined
answer on the exact no-normal-schedule day decision 4 exists to handle. **11 no longer loses** — see
decision 11, which built it once its "well beyond scope" premise was actually checked against the frontend
and found false for three of the four real callers.

**Alternatives for decision 12 — what to do about a blocked Unavailable declaration:**

14. **Blanket auto-create a Task the moment a conflict is detected**, no button, no review.
    Cons: the conflict check would have to run somewhere with no user-visible moment to confirm it —
    either inside `set_my_availability_override` itself (silent side effect on every failed save attempt,
    including ones the practitioner immediately corrects) or via a background job polling for blocked
    declarations that were never actually saved anywhere to poll. Silent and surprising either way.
15. **Auto-create, but only after N failed retries of the same window.**
    Cons: invents a threshold with no natural value, delays Front Desk being told by however long it takes
    the practitioner to retry N times, and still removes the practitioner's ability to add context (or
    decide not to bother) before something gets created in their name.
16. **Doctor-initiated button + pre-filled overlay (chosen).**
    Pros: matches this app's general "person stays in control of what gets created" pattern; the
    practitioner sees exactly what Front Desk will see before it exists; no task is ever created for a
    declaration the practitioner abandons or corrects instead of pursuing.
    Cons: relies on the practitioner actually clicking it — a conflict could otherwise go unactioned if
    they just close the dialog. Accepted: the alternative (auto-create) trades an unlikely-but-possible
    missed click for a guaranteed silent/surprising creation on every attempt, which is worse.
17. **Auto-create for the no-conflict case too** (Available, and Unavailable with nothing to reassign).
    Pros (why this one is NOT rejected): nothing to review — there is no "conflicting appointment list" a
    practitioner could inspect or dispute, so the "stay in control" reasoning that rules out auto-create
    for the conflict case does not apply here. Symmetric with decision 12's own framing: automatic exactly
    when there is nothing to confirm, a button exactly when there is.

**Why 14 and 15 lose, specifically:** 14 has no non-silent place to live; 15 invents an arbitrary threshold
that only delays the same silent-creation problem. **17 is not an alternative to 16 — both are the shipped
decision**, listed separately only because the "auto vs. button" choice resolves differently for the two
cases covered by the code walkthrough above.

**Alternatives for decision 14 — how to fix the "always lands on `Administrator`" bug:**

18. **One ToDo per recipient (chosen).** Every enabled Front Desk + Admin user gets their own ToDo,
    instead of the code choosing a single "owner."
    Pros: nobody is silently excluded by a name-sort tiebreak ever again — the bug class (a deterministic
    pick landing on the wrong account) cannot recur regardless of which accounts exist or how they sort.
    Matches this task's explicit requirement ("create for all front desk user and admin, not only one").
    Cons: N ToDo rows per declaration instead of 1 — more rows in the table, though at this feature's
    volume (one declaration per practitioner per day, at most) that is not a real scaling concern.
19. **Keep the single-owner design, but exclude known non-human accounts (`Administrator`) from the pool
    `_front_desk_users()[0]` picks from.**
    Cons: only patches the one account this investigation happened to find — the underlying problem (a
    role can be held by an account nobody intends as a notification target, and the code has no way to
    know that) is still there for the next such account. Also does not satisfy this task's actual
    requirement, which is "notify everyone," not "notify one correctly-chosen person."
20. **Round-robin among real Front Desk users** (rotate who gets picked instead of always the same one).
    Cons: solves fairness/distribution, not correctness — the person who happens to be off that day could
    still be the one picked, and it adds state (a rotation pointer) for a low-volume feature that does not
    need it.
21. **A dedicated "on-call Front Desk" designation** (a flag or small doctype naming who's currently
    covering the desk).
    Cons: real long-term correctness, but a schema/config change and a new admin workflow — well beyond
    the size of the bug being fixed, and nothing in this task asked for shift/on-call modeling.

**Why 19-21 lose, specifically:** 19 fixes today's symptom, not the underlying "the pick can silently miss
whoever should have been told" class of bug, and does not satisfy the actual ask; 20 trades one silent gap
for a different, still-possible silent gap; 21 solves a problem (who's covering the desk right now) nobody
has asked to solve yet. 18 is the only option where "did Front Desk get notified" no longer depends on
name sort order or account provenance at all.

## Consequences

- New code: `set_my_availability_override` / `cancel_my_availability_override` (write); `list_my_availability_overrides`
  (read); `services/availability.py` holding `generate_override_slots` (new bookable-slot generation
  from `Available` rows), `assert_bookable` (the write-time guard, now covering self-declared absence,
  holiday/leave, and `Available`-window validation together), `applies_on_weekday` and
  `get_unavailability_for_date` (the weekday-repeat correctness fix); a frontend screen with a type toggle,
  start/end date, time-range, Repeat selector and weekday checkboxes — no schedule-name UI.
- No core file is modified (Rule 1) — only calls to core's already-public functions and ordinary
  inserts/cancels on an already-installed doctype.
- Uninstall-safe (Rule 2): removing this app leaves ordinary `Practitioner Availability` rows in place;
  core's own booking flow (which never enforced Repeat/weekday itself — see decision 7) is unaffected either
  way.
- **Gap A-3 is now closed in full**, not partially — holiday/leave write-time enforcement was widened into
  this feature's scope rather than left open.
- **A second, unplanned correctness gap was found and closed in the same change** (decision 7) — not part of
  the original scope, surfaced only because the date-range/Repeat expansion required actually reading fields
  core itself never enforced.
- **A third correctness gap was found, but NOT closed, while scoping decision 9** — `assert_bookable`'s
  holiday/leave check (decision 5) never actually fires in this app, because `check_employee_wise_availability`'s
  Employee lookup always resolves to `None` (alternative 4/6, verified). Left open deliberately: decision 9 is
  a read-only display feature, and fixing booking enforcement is a separate, larger change (would need this
  app to decide how a practitioner's Employee link — or a replacement mechanism — actually gets populated).
  Tracked in `docs/KNOWN_ISSUES.md`.
- New code (decision 9): `get_practitioner_holidays` (read); `get_my_holidays` whitelisted wrapper; a new
  read-only "Holiday List" card on the same profile screen. No write path, no new doctype, no schema change.
- **A fourth correctness gap was found, but NOT closed, while scoping decision 10** — a practitioner's
  normal-schedule slot duration (`Healthcare Schedule Time Slot.duration`, set per schedule when it was
  created) and the resolved clinic-default duration decision 10 now reads can genuinely differ, so a single
  day's booking grid can show two different slot granularities side by side (e.g. 15-minute normal slots
  next to 20-minute override slots). Cosmetic today — every generated slot is still individually correct and
  bookable. **Deriving the override duration from the practitioner's own schedule (alternative 13) is not a
  viable fix for this, not merely an unexplored one** — decision 4's entire reason to exist is that an
  `Available` override must work on a day the practitioner has no normal schedule at all, where there is
  nothing to derive a duration from; a practitioner can also carry more than one `Practitioner Schedule` at
  once, at different durations, with no single value to borrow even when a schedule does exist. The only
  coherent follow-up, if this proves confusing in practice, is letting the override declare its **own**
  explicit duration at write time (`set_my_availability_override(..., slot_duration=None)`, defaulting to
  today's clinic-wide value when omitted) — never inherited from a schedule the feature is designed to work
  without. Left open deliberately: a genuinely new question, not this fix's scope. Tracked in
  `docs/KNOWN_ISSUES.md`.
- **Decision 11 narrows, but does not close, the gap above.** Override slots now use the booked
  appointment type's own duration when one is known, instead of always the single clinic-wide default —
  genuinely more correct, since a quick follow-up and a new-patient consult can rightly need different
  lengths. It still does not make an override slot match the *practitioner's own* normal-schedule
  granularity — those remain two independent numbers (`Healthcare Schedule Time Slot.duration` vs. whatever
  `Appointment Type.default_duration` resolves to for the type being booked), and can still visibly differ
  in the same day's grid. `docs/KNOWN_ISSUES.md` updated to record the narrowing, not closed.
- New code (decision 11): `services/availability.py::_slot_minutes_for`; `appointment_type` parameter added
  to `get_available_slots`, `get_my_available_slots`, and `generate_override_slots`; frontend
  `useAvailableSlots`/`useMultiPractitionerSlots`/`fetchSlots` (`use-healthcare.ts`) and the
  `/api/appointments/slots` BFF route gained the same optional parameter; wired from
  `new-appointment-dialog.tsx` (covers both new-booking and reschedule, since reschedule reuses this
  component) and the reassign dialog (`mission-control-client.tsx`). `patient_portal/api.py::
  get_my_available_slots` accepts the parameter but nothing in this repo calls it with one yet — recorded,
  not assumed fixed.
- New code (decision 12/13, backend): `services/availability.py::find_unavailable_conflicts` (read-only
  pre-check, also reused by decision 13's cancel-guard); `services/providers.py::create_front_desk_task`
  (dedup-checked **`ToDo`** creation, unassigned) + `_front_desk_users` + `_admin_users`;
  `api/v1/providers/api.py::set_my_availability_override` (returns `{"conflict": bool, ...}` instead of
  letting core's exception propagate; on a clean save, creates a `ToDo` AND calls `notify()` for both
  Front Desk and Admin, synchronously via `force_sync=True`); `cancel_availability_override` gained the
  cancel-guard; both `set_availability_override` and `set_my_availability_override` gained the
  no-backdating check; `services/notifications.py::notify()` gained `force_sync`;
  `services/notifications.py::EVENT_TYPES` gained `practitioner_unavailable_conflict` (declared, not
  currently used — the conflict path creates nothing automatically) and
  `practitioner_availability_declared`. The `create_availability_conflict_task` endpoint from decision 12
  was removed the same day (decision 13) — the conflict path no longer has a bespoke backend endpoint.
- Separate, pre-existing, unrelated bug also fixed in passing (decision 13):
  `api/v1/notifications/api.py` read a nonexistent `description` column instead of core's real
  `email_content` field — broke the entire notifications list page for every user.
- New code (decision 12/13, frontend, `Healthcare_next_app`): `types/providers.ts` gained
  `AvailabilityConflictAppointment`/`AvailabilitySaveResult`; `practitioner-availability-card.tsx` — the
  conflict banner and scrollable appointment list render inline inside the existing Add dialog (not a
  second stacked dialog), and its "Create task" button opens the real `CreateTodoForm`/`Sheet` overlay
  (mirrored from `inbox-tab.tsx`), pre-filled, submitting through the existing `useCreateTodo()` flow —
  not a bespoke conflict-task BFF route (the one built for decision 12 was removed); date inputs gained a
  `min` attribute and client-side validation blocking a backdated `start_date`; new i18n keys in both
  `en.json` and `es.json` (Rule: no hardcoded user-visible strings).
- **No core file touched** (Rule 1) — `find_unavailable_conflicts` reads `Patient Appointment` directly via
  the ORM; core's own `Practitioner Availability.validate()` is still what actually enforces the block,
  unchanged and un-bypassed. The pre-check only decides what our own code does *before* reaching it.
- **Re-evaluation trigger:** if this needs to extend to a role beyond Front Desk/Admin (e.g. a specific
  nurse pool), `_front_desk_users()`/`_admin_users()`/`create_front_desk_task()` would need a role
  parameter — not built now because nothing has asked for it yet.
- **New code (decision 14):** `create_front_desk_task()` signature changed — takes `recipients: list[str]`
  explicitly and returns `list[tuple[str, str]]` (one entry per ToDo actually created) instead of
  `tuple[str, str] | None`. `set_my_availability_override` now computes `recipients` once and passes the
  same list to both `create_front_desk_task()` and `notify()`. `notify()`'s `ref_doctype`/`ref_name`
  changed from `"ToDo"`/`todo_name` to always `"Practitioner Availability"`/`name`. No schema change, no
  new doctype, no core file touched.
- **Behaviour change worth naming:** the `Administrator` account still receives its own ToDo (it holds
  `EB_Front Desk`/admin roles same as before) — this decision stops it being the *only* recipient, it does
  not remove it from the pool. See Alternative 19 for why excluding it specifically was considered and
  rejected as treating the symptom rather than the underlying bug class.

## Verification

| Claim | Artefact |
|---|---|
| A practitioner can declare Unavailable/Available for a date range | `set_my_availability_override` + test asserting the resulting row, either type |
| A practitioner cannot declare for another practitioner | Test: `_session_practitioner()` rejects a foreign practitioner |
| Unavailable blocks a conflicting booking | Test reproducing core's `validate_existing_appointments()` throw |
| Available produces real bookable slots on both booking screens | Test hitting both slot functions after an Available override, including on a day with no normal schedule |
| A booking can't be written into an Unavailable window or outside a declared Available window | Write-time `assert_bookable` guard tests on create/reschedule, both surfaces |
| ~~A booking can't be written on a holiday~~ **Corrected 2026-09-09 — this claim was never actually true.** `test_availability_enforcement.py`'s "holiday mock" test mocks `check_employee_wise_availability` to force the exception, which only proves `assert_bookable`'s exception handling works — it never exercises real Employee resolution, which always yields `None` in this app's actual data (see decision 9). No test with real data has ever shown a holiday blocking a booking, because it doesn't | See `docs/KNOWN_ISSUES.md` §"Holiday/leave enforcement in assert_bookable is a silent no-op" |
| A Weekly override ticked Monday-only applies on a Monday in its range and NOT on a Wednesday in that same range | `applies_on_weekday` unit tests + `assert_bookable`/`generate_override_slots`/`list_availability_overrides` regression tests, each proving the non-ticked weekday is unaffected |
| The holiday list shown to a practitioner is their own company's, resolved via `custom_company` | `tests/providers/test_holidays.py::test_resolved_via_company_default_holiday_list` |
| A practitioner with no `custom_company` sees an empty list, not an error | `tests/providers/test_holidays.py::test_empty_when_practitioner_has_no_company` |
| An override's slot duration matches a given appointment type's `default_duration` when one is passed | `test_availability_enforcement.py::TestGenerateOverrideSlots::test_appointment_type_duration_overrides_clinic_default` — verified passing against `remedisis.localhost`, 2026-09-10 |
| An unknown/invalid appointment_type falls back to the clinic default rather than raising or returning empty | `...::test_unknown_appointment_type_falls_back_to_clinic_default` — verified passing |
| An explicit `slot_minutes` still overrides appointment_type-based resolution | `...::test_explicit_slot_minutes_still_wins_over_appointment_type` — verified passing |
| A conflicting Unavailable save returns `conflict:true` with the exact conflicting appointments, inserts nothing, creates no ToDo | `test_availability_override.py::TestAvailabilityNotifications::test_conflicting_unavailable_returns_conflict_without_inserting_or_creating_anything` |
| A clean Available save auto-creates exactly one unassigned `ToDo` | `...::TestAvailabilityNotifications::test_available_save_auto_creates_an_unassigned_todo` |
| A clean Unavailable save (no conflict) auto-creates exactly one unassigned `ToDo` | `...::TestAvailabilityNotifications::test_clean_unavailable_save_auto_creates_an_unassigned_todo` |
| Nobody can declare Available/Unavailable for a `start_date` before today — both the whitelisted wrapper and the service layer reject it | `...::TestNoBackdating` (3 tests: wrapper-Available, wrapper-Unavailable, service-layer-direct) |
| Cancelling an Available override is blocked while a `Patient Appointment` is booked into its window | `...::TestCancelAvailabilityOverride::test_cancelling_available_override_blocked_while_appointment_booked_into_it` |
| Cancelling that same override succeeds once the appointment is gone | `...::test_cancelling_available_override_succeeds_once_appointment_is_gone` |
| The cancel-guard is Available-only — cancelling Unavailable is never blocked by appointments | `...::test_cancelling_unavailable_override_is_never_blocked_by_appointments` |
| A clean Available/Unavailable save creates one ToDo for every enabled Front Desk + Admin user, not one | `test_availability_override.py::TestAvailabilityNotifications::test_available_save_auto_creates_a_todo_per_front_desk_and_admin_user`, `...::test_clean_unavailable_save_auto_creates_a_todo_per_front_desk_and_admin_user` — **written 2026-09-15, not yet run** (same `bench run-tests` breakage as the rest of this file; pending the same `bench console` + throwaway-runner verification) |

## References

- `docs/PRACTITIONER_AVAILABILITY.md` — companion mechanism doc
- `docs/flows/GAPS_APPOINTMENT_AND_RESCHEDULE.md` — gaps A-3, C-1
- `docs/adr/adr-003-no-core-modification.md` — Rule 1
- `docs/adr/adr-021-master-data-crud-access.md` — whitelisted-method-only access
- `api/v1/providers/api.py::update_my_provider_profile` — the copied pattern
- `healthcare/healthcare/doctype/practitioner_availability/practitioner_availability.py` — core validation relied on
- `healthcare/healthcare/doctype/patient_appointment/patient_appointment.py::check_employee_wise_availability` — the core function whose Employee-lookup gap (decision 9) is why holiday-list resolution here goes via Company, not Employee
- `docs/KNOWN_ISSUES.md` — the resulting silent-no-op enforcement gap, recorded not fixed
- `api/v1/encounters/api.py::_front_desk_users` — the query shape decision 12's own `_front_desk_users` duplicates rather than imports (layering: services/ must not depend on api/)
- `api/v1/appointments/api.py::reassign_appointment` — precedent this ADR does NOT reuse (a different
  problem: reassignment already has a specific target appointment + practitioner; declaring Unavailable
  does not, hence a Task rather than a direct reassignment action)
- Jira NH-123 (Front Desk task auto-created when a practitioner declares Available/Unavailable time)
- `frappe/projects/doctype/task/task.json` — confirms core `Task` has no reference-doctype field (decision
  12's original, superseded reason for dedup-by-subject — moot once decision 13 switched to `ToDo`)
- `api/v1/encounters/api.py::_create_refund_task_for_appointment` — the precedent decision 13's
  `create_front_desk_task` mirrors: an unassigned `ToDo` (`allocated_to=None`) as a claimable Front Desk
  queue item, not a new mechanism
- `EB_Healthcare_Frontend/src/components/narzim/inbox/todo-tab.tsx` (`CreateTodoForm`) +
  `inbox-tab.tsx` (the `Sheet`/"New Task" panel chrome) — the real My Work task-creation overlay decision
  13's conflict button opens, mirrored rather than imported wholesale into
  `practitioner-availability-card.tsx`
- `tasks/api.py::_fetch_todos` — the "Front Desk widening" that makes an unassigned `ToDo` visible to
  every `EB_Front Desk` user in My Work

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 5.0 | 2026-09-15 | Divyanshu (AI-assisted) | Decision 14 added: the single-owner pick from decision 13 (`_front_desk_users()[0]`, alphabetical) always resolved to the `Administrator` system account — it auto-holds every role and sorts before real staff names — so real Front Desk/Admin users never received a task. Fixed by creating one ToDo per recipient instead of choosing one owner; `create_front_desk_task()` now takes an explicit recipient list and dedupes per recipient rather than globally. `Administrator` is not excluded from the pool, only from being the *sole* recipient (Alternative 19, rejected). Found live while investigating an unrelated report about slots still showing for an unavailable practitioner (which turned out to be correct behaviour — a partial-day window, not a full-day one). 2 tests renamed and rewritten; not yet run |
| 4.0 | 2026-09-14 | Divyanshu (AI-assisted) | Decision 13 added, same day as decision 12: corrected `Task` to **`ToDo`** (the real My Work backing doctype — `Task` is a Projects-module concept this app's task list never reads) and removed the bespoke `create_availability_conflict_task` endpoint in favour of the conflict button opening the actual `CreateTodoForm`/`Sheet` overlay, pre-filled; widened the automatic path's `notify()` to target Admin as well as Front Desk (an unassigned `ToDo` is created automatically too, since the notification's "Open" action lands on My Work); added no-backdating validation (client + server, both layers); added a cancel-guard blocking removal of an Available override while an appointment is booked into it; found and fixed two real, unrelated pre-existing bugs in passing — an async `notify()` delivery failure after any prior write in the same request (new `force_sync` param, used only at this call site) and a wrong-column bug in `notifications/api.py` that broke the entire notifications list page for every user. 8 new/changed tests, all verified passing against `remedisis.localhost` |
| 3.0 | 2026-09-14 | Sarvesh-SocialAngel (AI-assisted) | Decision 12 added (Front Desk task on availability declaration): a conflicting Unavailable declaration no longer dead-ends — the practitioner is shown the conflicting appointments and an explicit "Create task" button (never automatic — decision maintains "person stays in control of what gets created"); a clean Available or Unavailable save auto-creates a Task, since there is nothing to review in that case. Both dedupe on an identical Task subject (core `Task` has no reference field to key on instead — verified). Two new `notify()` event types. New backend: `find_unavailable_conflicts`, `create_front_desk_task`, `create_availability_conflict_task`. New frontend (`Healthcare_next_app`): conflict UI inline in the existing Add dialog, new BFF route, bilingual i18n keys. 4 new tests. Found live via two screenshots during NH-118 investigation; Jira NH-123 |
| 2.0 | 2026-09-10 | Divyanshu (AI-assisted) | Decision 11 built: override-slot duration now prefers the booked appointment type's own `default_duration` when one is known (via a new optional `appointment_type` parameter), falling back to decision 10's clinic-wide default otherwise. Supersedes alternative 11's "well beyond scope" rejection in decision 10 — checked against the actual frontend and found false for 3 of 4 real callers, which already carried an Appointment Type in state before requesting slots. Wired through `new-appointment-dialog.tsx` (covers booking + reschedule) and the reassign dialog; the patient-portal caller is unverified, not assumed fixed. 3 new tests, verified passing against `remedisis.localhost`. Narrows, does not close, the schedule-vs-override granularity mismatch from 1.8/1.9 |
| 1.9 | 2026-09-10 | Divyanshu (AI-assisted) | Corrected the Consequences bullet from 1.8 — it had framed "derive the override duration from the practitioner's own normal schedule" as an open follow-up option, when alternative 13 (same version) already rejects it for a reason that doesn't go away with more thought: decision 4's core use case is a day with no normal schedule to derive from at all. Replaced with the one option that doesn't depend on a schedule existing: the override declaring its own explicit duration at write time |
| 1.8 | 2026-09-10 | Divyanshu (AI-assisted) | Decision 10 added: `generate_override_slots`'s slot duration no longer a private hardcoded constant — resolves `Healthcare Settings.default_appointment_type -> Appointment Type.default_duration` at call time, falling back to the renamed `_FALLBACK_SLOT_MINUTES` only if unset. Found while investigating why a practitioner's normal-schedule slots and `Available`-override slots showed different granularities in the same booking day; that mismatch itself is recorded, not fixed, in the new Consequences bullet and `docs/KNOWN_ISSUES.md` |
| 1.7 | 2026-09-09 | Divyanshu (AI-assisted) | Decision 9 added: read-only holiday list on the same screen, resolved via `custom_company` -> `Company.default_holiday_list` (not Employee-based — alternatives 6-9 weighed, 6/8/9 rejected). Surfaced, and recorded but did not fix, a third correctness gap: `assert_bookable`'s holiday/leave check has always been a silent no-op in this app, since `check_employee_wise_availability`'s Employee lookup never resolves — corrected the Verification table row that had implied it was tested and working |
| 1.6 | 2026-09-08 | Divyanshu (AI-assisted) | Removed the self-service list's "viewing date" filter (decision 8) — `list_availability_overrides`/`list_my_availability_overrides` now return every declared override, not one date's worth; display switched from stacked cards to a table. Corrected decision 7, which had claimed the weekday filter was applied inside `list_availability_overrides` — that's no longer true now that the function dropped date-scoping entirely; the correctness fix itself (`applies_on_weekday`, `get_unavailability_for_date`) is untouched and still governs booking enforcement |
| 1.5 | 2026-09-08 | Divyanshu (AI-assisted) | Small addition: core's own `note` field (free text, both types) exposed on the write/read API and the frontend form — no new alternatives to weigh, since the field already exists on the doctype with no restricting `depends_on` |
| 1.4 | 2026-09-08 | Divyanshu (AI-assisted) | Widened at the product owner's request to a date range + core's own Repeat/weekday fields (decision 6). Surfaced and closed a second, unplanned correctness gap in the process (decision 7): core's own `get_practitioner_unavailability()` never read the Repeat/weekday fields it stores, so "Weekly, Monday only" silently meant "every day in range" everywhere this app called it — fixed with `applies_on_weekday`/`get_unavailability_for_date`, swapped in at all three call sites plus the `Available`-direction read and the list view |
| 1.3 | 2026-09-08 | Divyanshu (AI-assisted) | Resolved the two open items from `PRACTITIONER_AVAILABILITY.md` §Open items into the decision itself: `generate_override_slots` now specifies the subtraction-against-normal-schedule algorithm and the default slot duration source, closing the double-counting risk |
| 1.2 | 2026-09-08 | Divyanshu (AI-assisted) | Redesigned: dropped named-schedule toggles for core's own type/time-range fields directly; widened from Unavailable-only to both Available and Unavailable, adding `generate_override_slots` for real bookable-slot generation; folded holiday/leave write-time enforcement into the same guard, closing gap A-3 in full rather than partially |
| 1.1 | 2026-09-08 | Divyanshu (AI-assisted) | Terminology fix: "shift" was never a system concept — replaced with `Practitioner Schedule` / "schedule" throughout |
| 1.0 | 2026-09-08 | Divyanshu (AI-assisted) | Initial version |
