# ADR-028: Canonical Lab Parameter Master and Coverage-Based Template Reuse

**Doc status:** living · **Created:** 2026-07-21 by Divyanshu · **Updated:** 2026-08-26 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Proposed
- **Date:** 2026-07-20
- **Supersedes:** the `Lab Analyte Alias` doctype and the name-based
  `services/lab_catalog.py::build_analyte_catalog` (the alias role is absorbed into a
  single searchable `abbreviations` field on the new master — no separate alias
  doctype or child table, per product direction 2026-07-20). Makes the heuristic
  `services/lab_units.py::match_incompatibility` guard structural on the template
  side (the guard is retained, not removed — see Decision D6).
- **Superseded by:** —

## Revision 2026-07-20 (post-review simplification — supersedes the sub-decisions below where they conflict)

After building Phase A/B, product direction pared the master to the minimum that
earns its keep. The decisions below are amended as follows:

- **Lean `Lab Parameter`**: `parameter_name`, `abbreviations`, `default_uom` (for
  template-authoring unit auto-fill), `auto_created` (read-only AI-provenance marker),
  `disabled`. **Dropped** `specimen_type`, `value_type`, `default_reference_range`,
  `needs_specimen_review`. Rationale: the reference range varies per template and is
  already authoritative on the template row (the matcher reads it from there); specimen
  and value_type were extra curation surface for marginal gain.
- **Guard is unit + qualitative only** (no specimen check). Those two checks read each
  template's own unit/range and, together with the owning-template context handed to
  the model (the template name — e.g. "EXAMEN GENERAL DE ORINA" — signals specimen
  implicitly), are what actually caught the blood-into-urinalysis false matches in
  testing. The structural specimen guard (old D7) is withdrawn.
- **Unknown analytes are auto-created ACTIVE**, not quarantined. On extraction, each
  unmatched analyte becomes a usable `Lab Parameter` (idempotent by canonical name,
  `auto_created=1`, `default_uom` from the report unit only if it is already a Lab Test
  UOM). No `disabled`/review gate. A templateless auto-created parameter is recognized
  by the model next time but can't be bucketed until an admin attaches it to a template.
- **Model context** now comes from the owning template's name + unit/range (via
  `template_analyte_meta`), not from parameter fields.

The Context / Decision / Alternatives sections below are retained for the original
reasoning; read them through this revision.

## Context

The AI lab-report extraction pipeline (multi-panel `services/lab_panel_extraction.py`
and single-template `services/lab_extraction.py`) matches each transcribed report
parameter to the clinic's known analytes, then buckets matches onto the Lab Test
Template(s) that own them. Facts about the current system (verified 2026-07-20):

- Analytes are **not** modelled as first-class records. They live **inside each
  template** as `Normal Test Template` child rows (`lab_test_event`, `lab_test_uom`,
  `secondary_uom`, `conversion_factor`, `normal_range`). There is **no specimen field
  at the analyte level**, in core or in our app.
- A lightweight **`Lab Analyte Alias`** master exists (canonical + alias + enabled)
  and `build_analyte_catalog()` aggregates analyte *labels* across every enabled
  Single/Compound/Descriptive template plus aliases — a **name-based** catalog.
- Results are written to core **`Lab Test` → `Normal Test Result` /
  `Descriptive Test Result`** child rows. Core has **no hook** to make a Lab Test
  "use" an external parameter master; core owns result storage.
- **Matching is name-based**, which just produced a clinically dangerous defect: a
  blood/serum report (`01_espana…`, HEMOGRAMA + BIOQUÍMICA) had its Glucosa 108
  mg/dL, Hemoglobina 13.4 g/dL and Leucocitos 7.2 ×10³/µL matched into a **urinalysis**
  template purely because the names collide with that template's qualitative
  analytes. The immediate fix added a heuristic `match_incompatibility` guard
  (unit-dimension + numeric-vs-qualitative) and specimen/unit context in the
  matching prompts (`multi_panel_extraction_v5` / `lab_extraction_v8`), but the guard
  infers specimen from unit text because the data model carries no specimen.
- A template becomes a "detected panel" if **≥1** of its analytes matches — there is
  no notion of *how much* of a template the report actually covers, so a single
  incidental match can surface a whole unrelated template.
- The site currently has **4 templates** and **1 alias** — introducing a canonical
  layer now is cheap; retrofitting after the catalog grows is not.

Constraints:
- **Rule 1 (upgrade-safe):** no core edits. Links onto core doctypes are **custom
  fields via fixtures** only; matching/selection lives in our service layer.
- **Rule 2 (uninstall-safe):** if `remedisys_healthcare_ai` is uninstalled, core Lab
  Test Templates and Lab Tests must still open, save, and submit. The master may not
  be a hard structural dependency of core storage.
- **Rule 9 (deterministic pipelines):** analyte identity and template selection are
  decided by deterministic, auditable code — the LLM proposes, it never decides
  identity.
- **§11 (no hardcoded magic numbers):** the reuse threshold is configuration.

## Decision

Introduce a **canonical `Lab Parameter` master** as a reference/metadata layer mapped
onto core's existing per-template storage (never a replacement for it), and make
template selection **coverage-based** instead of any-single-match.

1. **`Lab Parameter` (new doctype, ours) — the only new doctype.** Fields:
   `parameter_name` (canonical), `abbreviations` (Small Text: comma/newline-separated
   synonyms, e.g. "Hb, Hgb, HGB"), `specimen_type` (Select: Blood / Serum / Plasma /
   Urine / Stool / CSF / Other), `value_type` (Select: Numeric / Qualitative),
   `default_uom` (Link → Lab Test UOM), `default_reference_range` (Data),
   `needs_specimen_review` (Check), `disabled` (Check). `autoname =
   "field:parameter_name"` so the record `name` **is** the parameter name (e.g.
   "Hemoglobin") — this both enforces uniqueness and makes the name matched by default
   in a Link lookup. `search_fields = "abbreviations"` adds abbreviation matching on
   top, so typing "hemoglo" matches the name and "hg" matches an abbreviation
   (listing `parameter_name` in `search_fields` would be redundant with `name`).
   `track_changes = 1`; permissions System Manager (write) + Physician (read). **No
   alias child table and no separate alias doctype** — synonyms live in
   `abbreviations` (product direction 2026-07-20).

2. **Template authoring UX.** When an admin builds a Lab Test Template and picks a
   `Lab Parameter` in a `Normal Test Template` row, the row auto-fills `lab_test_uom`
   from `default_uom` and `normal_range` from `default_reference_range`. In the Desk
   this is a Client Script (ours, via fixtures — no core edit); the Next.js
   settings/labs authoring screen consumes a new whitelisted
   `search_lab_parameters(query)` endpoint (returns canonical name + abbreviations +
   default unit/range) — the frontend wiring is a follow-up, not part of this ADR.

3. **Links onto core via custom fields (fixtures, additive, Rule 1/2-safe).**
   - `Normal Test Template` → `custom_lab_parameter` (Link → Lab Parameter): the
     authoritative mapping of a template analyte row to its canonical parameter.
   - `Normal Test Result` and `Descriptive Test Result` → `custom_lab_parameter`
     (Link): traceability on the recorded lab report; core still owns the value.
   - Added in the **package-level** `fixtures/custom_field.json` (2-deep), not the
     module-level copy (Frappe ignores the deeper one).

4. **Catalog from the master.** `build_analyte_catalog()` is rebuilt to read
   `Lab Parameter` (canonical name + aliases + `specimen_type` + `default_uom` +
   `default_reference_range`), with `owning_templates` derived from which
   `Normal Test Template` rows link each parameter. Matching resolves report
   parameters → `Lab Parameter`, structurally.

5. **Coverage-based template reuse.** For each candidate template X:
   `coverage(X) = |matched parameters belonging to X| / |X's total parameters|`.
   Reuse (propose an order against) X only when `coverage(X) ≥ threshold` **and**
   `|X.params| ≥ min_params`; otherwise the matched parameters are routed to the
   existing "create new template" (unmatched-by-section) flow. Both are **named,
   documented module constants** in the coverage code (defaults `0.60` and `3`), not
   AI Settings fields — a single threshold is a documented constant, which satisfies
   §11 (the rule targets unexplained scattered literals, not named constants).
   Promote to configuration only if per-clinic tuning is later required
   (revision 2026-07-20).

6. **One lab-AI feature flag.** Collapse `AI Settings.enable_lab_result_summary` into
   `AI Settings.enable_lab_extraction` (relabelled "Enable AI Lab Extraction"): the
   single flag gates report extraction **and** the AI result/patient summary. The two
   summary gate call sites (`services/lab_result_summary.py::maybe_generate_summary`
   and `generate_patient_summary`) read `enable_lab_extraction`; the
   `enable_lab_result_summary` field is removed from `ai_settings.json`. Behaviour
   change: extraction and summary can no longer be toggled independently — by
   product direction they move together (revision 2026-07-20).

7. **Guard becomes structural on the template side.** `match_incompatibility` gains
   the parameter's `specimen_type` from the master: a report parameter whose inferred
   specimen conflicts with the candidate parameter's `specimen_type` is rejected
   structurally. The existing unit/qualitative heuristic is **retained** as the
   secondary signal, because the *report* side still carries no declared specimen
   (inferred from section/unit). A blank `specimen_type` means "unknown" and never
   rejects on specimen alone.

8. **Backfill migration (idempotent).** A patch creates `Lab Parameter` records from
   the existing templates' analytes (deduped by canonical name), links the
   `Normal Test Template` rows, and folds the existing `Lab Analyte Alias` record(s)
   into the matching parameter's `abbreviations` field (then the `Lab Analyte Alias`
   doctype is deprecated/removed). `specimen_type` is set by a conservative heuristic
   (urinalysis-type templates → Urine; otherwise Blood) and **every** created record
   is flagged `needs_specimen_review = 1` for a human pass before matching relies on
   specimen. `value_type` is derived from whether the analyte's reference range is
   numeric or qualitative (reusing `labs.reference_is_qualitative`).

9. **Sync hook.** A `Lab Test Template` `on_update` hook ensures each
   `Normal Test Template` row has a `custom_lab_parameter` (creating a review-flagged
   master record when an analyte is added that has no canonical match), so the master
   never silently drifts from the templates that are the operational source of truth.

## Alternatives Considered

1. **New `Lab Parameter` master mapped onto core (chosen).**
   - Pros: canonical analyte identity; specimen/unit/value-type become structured data,
     making matching and the safety guard robust rather than heuristic; makes the 60%
     coverage rule clean; cheapest to introduce now (4 templates); absorbs the
     overlapping `Lab Analyte Alias`.
   - Cons: a new doctype (ADR-gated); two representations (master vs core child rows)
     that must be kept in sync; a backfill + manual specimen curation pass; the report
     side still needs specimen inference, so it is not 100% structural end-to-end.

2. **Extend the existing catalog/alias only (no new master).**
   - Pros: least invasive; no migration; no new doctype; keeps a single storage model.
   - Cons: analyte identity stays name-based and fuzzy; specimen stays a heuristic;
     the coverage rule has no clean per-parameter identity to count against; does not
     resolve the class of bug that motivated this — only patches its symptom.

3. **Do nothing beyond the heuristic guard already shipped.**
   - Pros: zero further work; the immediate false-match bug is already mitigated.
   - Cons: leaves matching name-based and specimen heuristic; the "any single match
     surfaces a whole template" behavior remains; technical debt compounds as the
     catalog grows.

## Consequences

- **New files:** `remedisys_healthcare_ai/doctype/lab_parameter/` (JSON + controller
  — the only new doctype); a `search_lab_parameters` whitelisted method
  (`api/v1/labs/api.py` or `admin` module); a Desk Client Script fixture for the
  template auto-fill; a backfill patch under `patches/v0/` + a `patches.txt` entry;
  this ADR.
- **Modified:** `fixtures/custom_field.json` (package-level) for the three custom
  fields; `ai_settings.json` (remove `enable_lab_result_summary`, relabel
  `enable_lab_extraction`); `services/lab_result_summary.py` (both gate call sites
  read `enable_lab_extraction`); `services/lab_catalog.py` (catalog from master),
  `services/lab_units.py` (specimen-aware guard), `services/lab_panel_extraction.py`
  (coverage selection, named-constant threshold), `hooks.py` (template sync hook);
  tests under `tests/labs/`.
- **Deprecated:** `Lab Analyte Alias` doctype (data migrated; kept read-only until a
  follow-up removes it, to stay uninstall-safe during transition).
- **Uninstall-safety:** custom fields and both new doctypes are removed on uninstall;
  core `Normal Test Template` / result rows keep their native fields and values; a
  dangling `custom_lab_parameter` link simply disappears with the field.
- **Operational:** after the backfill, an admin curates `specimen_type` on the
  `needs_specimen_review` records before Phase B matching is trusted.
- **Re-evaluation triggers:** if the catalog grows past the point where a single
  `specimen_type` per parameter is insufficient (e.g. the same analyte name legitimately
  measured on two specimens as distinct tests), revisit whether specimen belongs on the
  parameter or on the template-analyte link.

## Verification

- Backfill run on `remedisis.localhost` creates one `Lab Parameter` per distinct
  analyte across the 4 templates, all `needs_specimen_review = 1`, with the 1 alias
  migrated; re-running the patch is a no-op.
- Unit tests: coverage selection (≥threshold + floor), specimen-aware guard
  (blood→urine rejected, same-specimen accepted, unknown specimen falls back to unit).
- End-to-end: the `01_espana…` blood report yields **0** false matches and surfaces
  HEMOGRAMA + BIOQUÍMICA as create-template groups; a report that covers ≥60% of an
  existing template reuses it.

## References

- Constitution §1 (Rule 1/2/6/9), §9 (ADR per architectural decision), §11 (no
  hardcoded magic numbers), §12 (new custom doctypes require an ADR).
- Prior art in code: `services/lab_catalog.py`, `services/lab_units.py`,
  `services/lab_panel_extraction.py`, `Lab Analyte Alias`, prompts
  `multi_panel_extraction_v5.txt` / `lab_extraction_v8.txt`.

## Verification (2026-08-26) — the coverage rule measured on live data

First measurement of this rule against a real multi-document upload, once the site
actually had templates: `AI Prompt Log g4sfv8ncqk`, 37 extracted parameters, a
98-entry catalog, thresholds at their documented defaults
(`_TEMPLATE_REUSE_THRESHOLD = 0.6`, `_TEMPLATE_REUSE_MIN_PARAMS = 3`).

All 37 parameters resolved to a catalog entry — the model returned both
`matched_index` and `matched_analyte` for 37/37, and 0 were unresolvable. The
coverage rule then decided which owning templates to reuse:

| Template | matched | owns | coverage | verdict |
|---|---|---|---|---|
| `Anticuerpos IgG Streptococcus pneumoniae (12 serotipos)` | 10 | 12 | 83% | **reused** |
| `LIVER PANEL 1; LFT,SERUM` | 10 | 11 | 91% | **reused** |
| `LIPID SCREEN, SERUM` | 3 | 6 | 50% | rejected — below 60% |
| `COMPLETE BLOOD COUNT; CBC` | 2 | 10 | 20% | rejected — below 60% |
| `Differential Leucocyte Count (DLC)` | 1 | 5 | 20% | rejected — below 60% |
| `LIVER & KIDNEY PANEL, SERUM` | 2 | 13 | 15% | rejected — below 60% |
| `Test Summary Panel B` and two others | 1-2 | 1-2 | 100% | rejected — template below MIN_PARAMS |

This is the rule behaving as designed: two genuine panels recognised, and the
scattered single hits (2 of 10 CBC analytes, 2 of 13 on the liver/kidney panel)
correctly declined rather than proposing an order for a panel the report does not
contain. `LIPID SCREEN` at 50% is the closest call on record — three of six
analytes present, rejected by 10 percentage points.

**A misdiagnosis worth recording, because it will happen again.** Before this
measurement, four extraction runs all reported `matched_count=0` and it was briefly
written up as a defect in `KNOWN_ISSUES.md`. It was not. Every `Lab Test Template`
on the site had been created between 11:06 and 11:29 on 2026-08-26, and every one of
those extraction runs predated 11:06 — so the catalog genuinely had nothing to match
against and 0 was the right answer. The lesson for anyone reading a low
`matched_count`: check the catalog's contents and the templates' `creation`
timestamps before suspecting the matcher. A site with no templates matches nothing,
by design, and the create-template-from-section flow is how it bootstraps.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-26 | Divyanshu (AI-assisted) | Added Verification: the coverage rule measured on live data (2 panels reused, partial panels correctly declined), plus the zero-match misdiagnosis and how to avoid repeating it. No decision changed; this ADR's Status remains Proposed |
| 1.0 | 2026-07-21 | Sarvesh | Initial version (header backfilled from git history) |
