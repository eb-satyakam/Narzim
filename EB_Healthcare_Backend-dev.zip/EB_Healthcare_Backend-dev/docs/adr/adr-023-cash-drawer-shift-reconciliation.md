# ADR-023: Cash Drawer & Shift Reconciliation via native ERPNext POS entries

**Doc status:** living · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-09
- **Supersedes:** —
- **Superseded by:** —

## Context

The front-desk audit (`docs/audit/frontdesk/`) found the Cash Drawer / Shift
subsystem is **entirely client-side mock**: `lib/narzim/shift.ts` stores shift
open/close, opening float, drawer transfers, and expected-vs-actual variance in
browser `localStorage` (its header comment literally says "All data lives in
localStorage"), and `lib/narzim/session.ts` holds a mock PIN "who's on the
terminal" identity in `sessionStorage`, separate from the real JWT auth. There
is **no `/api/cash` route and no backend doctype.** (Audit refs: screen 12
CD1–CD4; backend gap B2; charter G1; hand-off FD-BH-1.)

Consequences of the current state:
- Cash records are **per-browser**: not persisted server-side, not multi-user,
  wiped by a cache clear. Two terminals cannot share a drawer.
- The drawer total is **not reconciled against real money taken** — actual
  payments live in `Payment Entry` (surfaced read-only in Billing → Payments),
  disconnected from the mock drawer.
- For a clinic handling real pesos this is the single highest operational and
  compliance risk in the front-desk surface, and it *looks* trustworthy while
  being fiction.

Relevant facts about the system (verified against the billing code, 2026-07-09):
- Every consolidated checkout invoice is already created with **`is_pos = 1`**
  (`services/billing.py`), and cash payments are recorded as real core
  **`Payment Entry`** documents.
- However, there is **no `POS Profile`, no `POS Opening Entry`, and no
  `POS Closing Entry` anywhere** — `is_pos` is set on the invoice but nothing
  ties it to a cashier session. So reconciliation is not "add a closing step";
  it requires introducing the POS Profile + Opening Entry and linking the
  `is_pos` invoices to it.
- Constitution Rule 1 (upgrade-safe: never fork core) and CLAUDE.md §12 (new
  custom doctypes require an ADR) both apply. Deployment is Frappe Cloud
  (ADR-005), MariaDB (ADR-006), jurisdiction India + Mexico (ADR-018) — cash
  handling and till accountability matter in both markets.

This ADR chooses the persistence model for cash/shift so the mock can be
replaced with an auditable, multi-user, reconciled backend.

## Decision

**Adopt ERPNext's native POS session model — `POS Profile` + `POS Opening
Entry` + `POS Closing Entry` — as the source of truth for cash/shift, and
build a thin `api/v1/cash` service over it. Do not invent custom shift
doctypes.** The browser `localStorage`/`sessionStorage` cash layer is removed;
cashier identity comes from the authenticated JWT user, not a mock PIN session.

Concrete consequences:

1. **POS Profile per clinic/company.** Seed one `POS Profile` per company
   (payment modes = the clinic's enabled `Mode of Payment`s, default warehouse,
   write-off/change accounts). This is configuration, provisioned like other
   master data (aligns with ADR-014 onboarding).
2. **Shift = POS Opening Entry.** `api/v1/cash.open_shift(pos_profile,
   opening_balances[])` creates a submitted `POS Opening Entry` for the current
   user with the counted opening float per mode. Reject a second open while one
   is already open for that user/profile.
3. **Checkout invoices bind to the open shift.** `create_pos_invoice` /
   `collect_payment` stamp the active `POS Opening Entry` (via the POS Profile)
   onto the `is_pos` Sales Invoice + its Payment Entry, so the session owns its
   transactions. (This is the net-new linkage flagged in FD-BH-1 — without it
   the Closing Entry has nothing to reconcile.)
4. **Close = POS Closing Entry.** `api/v1/cash.close_shift(counted[])` creates a
   `POS Closing Entry` referencing the opening entry, pulls the linked invoices/
   payments as **expected** per mode, records **counted** per mode, and computes
   **variance** — all server-side, audited (`track_changes`), immutable after
   submit.
5. **Drawer transfers (petty cash out / cash drop).** Record as a small custom
   child/log on the session **or** a core cash Journal Entry referencing the
   opening entry — decided at build time; must be included in the expected-cash
   math. This is the one place a minimal custom addition may be needed; keep it
   additive, never a core edit.
6. **Identity from auth.** Cashier = `frappe.session.user`. Delete
   `lib/narzim/session.ts` mock PIN session; the shift widget derives the
   cashier from the real user.
7. **Frontend swap.** Replace the `localStorage` layer in
   `app/(clinic)/cash/*` + `components/narzim/cash/*` with the `api/v1/cash`
   hooks; the Billing → Payments day-end summary (audit BP1) reads the same
   reconciled data.
8. **Permissions.** `EB_Front Desk` may open/close their own shift and record
   transfers; cannot alter a submitted closing entry. Reconciliation review is
   `EB_Healthcare Admin`.

## Alternatives Considered

1. **Custom shift doctypes (`Cash Shift`, `Cash Transaction`, `Drawer
   Transfer`).**
   - Pros: exact shape we want; no need to learn POS Entry fields; independent
     of ERPNext POS assumptions (warehouses, POS Profile config).
   - Cons: **re-implements reconciliation ERPNext already does**; we'd have to
     hand-join `Payment Entry` to our shift and keep the expected-cash math in
     sync with core changes; more doctypes to own and migrate; drifts from core
     (the exact "beside, not with, core" anti-pattern the audit flags).

2. **Native POS Profile + POS Opening/Closing Entry (chosen).**
   - Pros: reconciliation, expected-vs-counted, and multi-mode totals are
     **built in**; ties directly to the `is_pos` invoices we already create;
     upgrade-safe (Rule 1) — we add a service + linkage, not core edits; one
     less bespoke schema to maintain; auditable/submittable out of the box.
   - Cons: POS Entry carries retail assumptions (warehouse, item stock) not all
     relevant to a clinic; requires seeding a POS Profile; the invoice→opening-
     entry linkage is net-new plumbing (must be built, not assumed); drawer
     transfers may still need a small additive record.

3. **No cash tracking — rely on the raw `Payment Entry` list only.**
   - Pros: zero new build; the payments ledger is already real.
   - Cons: no opening float, no counted-vs-expected, no per-cashier drawer, no
     variance, no close-out — i.e. it does not solve the accountability problem
     at all. Only viable if the clinic genuinely takes no cash (not the case).

## Consequences

- **New backend:** `api/v1/cash/api.py` (open_shift, close_shift, record_transfer,
  get_active_shift, get_shift_summary); a seeded `POS Profile` per company;
  a patch to link `create_pos_invoice`/`collect_payment` to the active opening
  entry. Any custom drawer-transfer record added via fixtures (Rule 1).
- **Frontend:** remove the `localStorage` cash layer and mock `session.ts`;
  rewire `cash-client.tsx`, `shift-widget.tsx`, open/close/transfer dialogs to
  the API; Billing → Payments gains the reconciled day-end summary (BP1).
- **Audit trail:** cash open/close/variance become submittable, `track_changes`
  documents — satisfies the "persisted, auditable, multi-user" requirement and
  the LFPDPPP/NOM (MX) + DPDPA (IN) posture for financial records.
- **Interim safety (before this lands):** hide the Cash Drawer screen (or badge
  it "not saved"); do not present the mock drawer total as real (decision-sheet
  CD1 Week-1 item).
- **Re-evaluation triggers:** if clinics run genuinely multi-till counters
  needing concurrent open shifts per profile, or if POS Entry's warehouse/stock
  coupling proves too heavy for a services-only clinic, revisit the
  custom-doctype alternative for the drawer-transfer/close layer only.
- Updates the audit hand-off FD-BH-1 from "spec" to "decided — native POS".

## Verification

- A `POS Profile` exists per company on the site (seed/onboarding check).
- `open_shift` → a submitted `POS Opening Entry`; a subsequent checkout's Sales
  Invoice + Payment Entry reference that opening entry (query proves the link).
- `close_shift` → a submitted `POS Closing Entry` whose expected-per-mode equals
  the sum of the linked payments, with counted + variance stored.
- No `localStorage`/`sessionStorage` key (`remedisys_shifts`,
  `remedisys_transfers`, `remedisys_session`) is written by the cash screens
  (grep the frontend).
- Integration test: open → checkout (cash) → close reconciles to zero variance;
  a deliberate miscount surfaces the correct variance.

## References

- Constitution Rule 1 (upgrade-safe); CLAUDE.md §12 (new doctypes require ADR)
- ADR-005 (Frappe Cloud), ADR-006 (MariaDB), ADR-017 (front-desk POS
  consolidated billing — the `is_pos` invoices this reconciles), ADR-018
  (multi-jurisdiction)
- Audit: `docs/audit/frontdesk/screens/12-cash-drawer.md` (CD1–CD4),
  `10-billing-payments.md` (BP1), `BACKEND_HANDOFFS.md` (FD-BH-1),
  `../OPD_BACKEND_FLOW_AND_GAPS.md` (B2), `FRONTDESK_CHARTER_AND_GAPS.md` (G1)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
