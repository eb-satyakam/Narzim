# ADR-051: AI transcript retention is indefinite, with a single authoritative configuration

**Doc status:** living · **Created:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-27 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-08-27
- **Supersedes:** `ComplianceProfile.transcript_retention_days` (`mx.py` = 90
  days, `india.py` = 30 days) as any kind of retention policy, and the claim
  in [`adr-018-multi-jurisdiction-compliance.md`](adr-018-multi-jurisdiction-compliance.md)
  that "`transcript_retention_days` drives the cleanup job" — no cleanup job
  exists; verified against `docs/compliance/HIPAA_READINESS.md`'s own audit
  finding ("is read by no deletion code") before writing this ADR. ADR-018
  itself is not edited (CLAUDE.md §9 — never edit a merged ADR); this ADR is
  the correction of record.
- **Superseded by:** —

## Context

This is Phase 7 of `ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md` (§16, §24
Q1/Q2). Before this ADR, **three retention values disagreed with each
other and none was enforced by any code**:

| Source | Value | Enforced? |
|---|---|---|
| `ComplianceProfile` (`mx.py`) | 90 days | No — read by no deletion code |
| `ComplianceProfile` (`india.py`) | 30 days | No — read by no deletion code |
| `AI Settings.transcript_retention_days` | 2555 days (~7 years) | No — read by no deletion code |

`mx.py` additionally declares `right_to_erasure=True` (LFPDPPP Art. 16
ARCO — *cancelación*). Shipping indefinite retention with a declared
erasure right and no erasure mechanism is a contradiction the plan flagged
explicitly (§25): *"Either commit to building the mechanism... or change
the profile to stop claiming the right. Do not ship the contradiction
silently."* This ADR resolves the retention half of that; the erasure half
is deliberately **documented, not built** — see
[`docs/compliance/TRANSCRIPT_ERASURE_PATH.md`](../compliance/TRANSCRIPT_ERASURE_PATH.md).

The plan's own open questions (§24) — Q1 (is a transcript a clinical
record under NOM-024, ≥5 years) and Q2 (which config is authoritative) —
were both marked as blocking this ADR. **Both are now answered by product
decision** (2026-08-27), not deferred further:

## Decision

1. **Retention is indefinite**, by decision, as part of the clinical
   record. No automatic purge is implemented, based on the 90-day `mx.py`
   value or any other value. This is a deliberate choice, not an
   oversight — see §25 of the implementation plan for why indefinite
   retention is technically compatible with the HIPAA Security Rule (it
   governs *how* PHI is protected, not *how long* it is kept).
2. **`AI Settings.transcript_retention_days` is now the single
   authoritative transcript-retention configuration.** `ComplianceProfile`
   no longer declares a `transcript_retention_days` field at all (removed
   from `compliance/base.py`, `compliance/profiles/mx.py`,
   `compliance/profiles/india.py`) — a second, disagreeing, equally-unread
   value is exactly the problem being fixed, not a acceptable redundancy.
3. **No 5-year or 7-year limit is introduced.** `AI Settings.
   transcript_retention_days` is changed from its old default `2555`
   (~7 years — itself never a real limit, since nothing read it) to `0`,
   with its field description now stating explicitly: *"0 = indefinite
   retention... NOT delete immediately."* This directly fixes the
   ambiguity the implementation plan called out: *"today 0 means nothing,
   and the next engineer could read it as delete immediately."*
4. **Erasure is not automated.** `right_to_erasure=True` remains true on
   both `ComplianceProfile` instances (the legal right is real and
   unchanged) — what's deferred is the *mechanism*. The complete erasure
   path (every copy a request would need to reach) is enumerated in
   `docs/compliance/TRANSCRIPT_ERASURE_PATH.md` as a separate,
   compliance-controlled capability: something a future, explicitly
   authorized piece of work implements on request, not something this ADR
   or Phase 7 builds.

## Consequences

- A reader of `ComplianceProfile` no longer sees a transcript-retention
  field that was never true and never enforced. `audit_retention_years`
  (NOM-024's real ≥5-year audit-log requirement) and `audio_retention_days`
  (unrelated — audio is never stored, `0` in both profiles) are untouched.
- `AI Settings.transcript_retention_days` still isn't read by any code —
  this ADR does not add a purge job. It exists so a single place can be
  pointed to when someone asks "what's the transcript retention policy,"
  and so a future purge (if one is ever authorized) has exactly one place
  to read from instead of three.
- The existing `AI Settings` singleton row on `marley.local` had its
  stored value updated from `2555` to `0` to match — a config-value update
  on a Single doctype, not a historical-data backfill (no `AI Transcript
  Segment`/`AI Encounter Session` row was touched).
- `docs/compliance/HIPAA_READINESS.md`'s existing retention-gap findings
  (lines ~154, ~196, ~248 as of this ADR) describe the *pre*-this-ADR
  state (a `record`-status audit) and are not edited by this ADR — they
  remain accurate as a dated snapshot of what was found.

## Alternatives considered

| Approach | Why rejected |
|---|---|
| Keep `ComplianceProfile.transcript_retention_days`, change its value instead | Doesn't fix the two-source disagreement — `AI Settings` would still disagree with it |
| Implement an automatic purge now | Explicitly out of scope for this decision — retention is indefinite by decision, not merely unenforced |
| Set retention to NOM-024's ≥5-year clinical-record minimum as an explicit ceiling | Explicitly rejected — "do not introduce a 5-year/7-year limit"; indefinite means no scheduled expiry at all |
| Build the erasure mechanism alongside this ADR | Explicitly deferred — a separate, compliance-controlled capability, not bundled into a retention-policy ADR |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-27 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
