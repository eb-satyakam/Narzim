# ADR-044: Let a clinician continue the report-scoped chat after Done, from the completed Lab Test view

**Doc status:** living · **Created:** 2026-08-21 by Divyanshu (AI-assisted) · **Updated:** 2026-08-21 by Divyanshu (AI-assisted) · **Version:** 2.0

- **Status:** Accepted — Alternative 1 (shared per-report store), implemented 2026-08-21. This
  ADR shipped twice in one day: it was first implemented as Alternative 2 (scoped to the one
  panel being viewed, no new doctype), then replaced hours later, same day, by Alternative 1 —
  see "Revision (same day)" below for why. The Decision/Consequences/Verification sections below
  describe the FINAL, actually-implemented design (Alternative 1); the original Alternative-2
  reasoning is kept verbatim under Alternatives Considered as the historical record of why it was
  tried first.
- **Date:** 2026-08-21
- **Supersedes:** ADR-033 §3's explicit scope limit only ("continuing it from the test page... is deliberately out of scope for this pass") — everything else ADR-033 decided (report summary storage, `custom_ai_summary` reuse, the review-screen live chat, `ask_report_question`'s existing stateless design) is unchanged and unaffected.
- **Superseded by:** —

## Context

The "Uploaded report" modal on the Lab Center tab (`lab-center-tab.tsx:1225-1238` for a single
report, `:1245-1255` for a multi-panel group) renders `LabResultSummaryPanel`
(`lab-result-summary-panel.tsx`), which shows a completed Lab Test's AI summary plus — per ADR-033
— a **read-only** history of the chat conducted during the live extraction Review screen, if any
question was asked there. There is no input in this view; the chat, once Done, cannot be continued.

This is not an oversight — ADR-033 §3 designed it this way on purpose ("Post-Done the chat is
read-only on the Lab Test detail... continuing it from the test page... is deliberately out of
scope for this pass") and named the exact condition under which to revisit it (§ Consequences,
Re-evaluation trigger): **"if physicians need to CONTINUE the chat from the test page after Done,
revisit a shared per-report store... so sibling tests stay in sync rather than diverging."** That
condition has now been asked for directly (screenshot, 2026-08-21: a genetic panel report —
`HLC-LAB-2026-00453`, Invitae Inborn Errors of Immunity and Cytopenias Panel — viewed well after
upload, wanting to ask a new question about it right there).

**What already exists and is reused unchanged by this ADR:**
- `services/lab_result_summary.py::report_chat_context(items, narrative_reports)` — builds a
  context string scoped to **one report's own content only** (its discrete analyte rows and/or its
  transcribed narrative text), explicitly separate from the patient-wide chat
  (`patient_clinical_summary.build_patient_chat_context`). This already satisfies "answerable only
  for that specific report" — it is not something this ADR needs to build.
- `api/ai/lab_result_summary.py::ask_report_question(report_params, question, history, extraction,
  narrative_reports)` — the live, in-review, **stateless** chat endpoint. It is built for the
  Review screen's in-memory (unsaved) state and cannot be reused as-is for a report that has
  already been saved: `report_params`/`narrative_reports` are the client's live review-time state,
  which no longer exists once the browser has moved on to viewing a completed Lab Test later.
- `custom_ai_summary` on `Lab Test` (JSON: `narrative`, `flags`, `items`, `source`, `chat`) — the
  ADR-033 storage. A multi-panel report writes the byte-identical blob onto **every** Lab Test it
  created; the combined-group modal already only ever shows **one representative** panel's copy
  (`lab-center-tab.tsx`'s own comment: "whichever panel was picked as the representative... rather
  than the same text N times"), not a true merge across siblings.
- `get_result_summary(lab_test)` already returns `chat` to the frontend; `LabResultSummaryPanel`
  already renders it read-only. Both are extended, not replaced, by this ADR.

**What does not exist yet:** a way to source `report_chat_context`'s two inputs (`items`,
`narrative_reports`) from an **already-saved, completed** Lab Test (rather than live review
state), and a way to persist a new question/answer pair back onto that saved record.

## Revision (same day, 2026-08-21) — Alternative 2 replaced by Alternative 1

Shipped first as Alternative 2 (below): a question asked from one Lab Test's own view was saved
only onto that one test's `custom_ai_summary.chat`. Within hours, real use (not a hypothetical)
showed the cost was worse than estimated: a report with **50** tests from one upload means a
clinician asking from panel #12 leaves 49 other panels with no trace of it — at that scale, "narrow
limitation" was no longer an honest description. Separately, the divergence-detection mechanism
Alternative 2 used to answer "how many reports are in this upload" (matching siblings by identical
stored *narrative text*) produced a **false positive**: a second, unrelated upload of similar
sample lab data was treated as belonging to the SAME report as an earlier, different upload, because
their AI-generated narratives came out near-identically worded. Both problems are solved by moving
to Alternative 1, which this ADR's Decision below now describes as the actually-implemented design.

## Decision

1. **New doctype `AI Report Chat Message`** — one row per turn (mirrors `AI Patient Chat Message`,
   ADR-030's own patient-wide chat pattern, rather than inventing a third storage convention):
   `report_group` (Data, the shared group id — see below), `patient`, `role`, `content`,
   `in_reply_to`, `prompt_log`, `model`/`prompt_version`/`prompt_hash`/`tokens_in`/`tokens_out`/
   `cost_estimate_usd`/`latency_ms`, `feedback`/`feedback_by`/`feedback_on`/`feedback_note`. `owner`
   (standard Frappe field, free) is the "who asked" attribution — no new field needed for that.
2. **A stable, id-based group key — never content-based.** New Data field `custom_report_group` on
   `Lab Test` (`fixtures/custom_field.json`), stamped at creation time
   (`api/ai/lab_panel_extraction.py::create_order_for_panel` / `finalize_section_order`, via new
   `_stamp_report_group(lab_test, extraction)`) with the triggering Multi-Panel Extraction's own
   `AI Prompt Log` name. Every sibling one upload creates shares the same value, permanently — this
   value is written once and never re-derived from content, closing the false-positive risk the
   narrative-matching approach had. `services/lab_result_summary.py::report_group_key(lab_test)`
   resolves it, falling back to the Lab Test's own name when unset (never created through the
   multi-panel pipeline, or predates this field) — a "group of one", so the report chat works
   identically whether a report has 1 sibling or 50. `report_group_members(lab_test)` returns every
   Lab Test sharing that key, still used to answer "how many reports/panels are in this upload."
3. **`ask_saved_report_question(lab_test, question, history)`** — unchanged from the original
   Alternative-2 version in how it builds the AI's context (`_items_from_saved_lab_test` +
   `_stored_report_narrative` feed the existing `report_chat_context()`, ADR-033, untouched).
   What changed is persistence: the new turn is inserted as two new `AI Report Chat Message` rows
   keyed by `report_group_key(lab_test)`, not appended to a per-test JSON array.
4. **`list_report_chat(lab_test, page, page_size)`** (new) — returns the full shared thread for
   `lab_test`'s report group, oldest first, with feedback state and `owner_name` (who asked),
   mirroring `list_patient_chat` exactly. Same thread regardless of which sibling's `lab_test` id is
   passed. **`set_report_chat_feedback(message, feedback, note)`** (new) — thumbs up/down on a
   saved answer, mirroring `set_patient_chat_feedback` exactly.
5. **`save_report_summary`** (ADR-033, the Done-time bulk save) no longer writes `chat` into
   `custom_ai_summary` — the review-screen transcript it receives is now inserted as
   `AI Report Chat Message` rows too (once, keyed by the group already stamped on the Lab Tests it
   was called with), so there is exactly ONE place a report's chat ever lives, regardless of
   whether the turn came from the live review screen or a later, post-Done question.
6. **`get_result_summary`** drops the `chat` key entirely (frontend now calls `list_report_chat`
   as a separate query, same separation `usePatientChatHistory` already has from the patient
   summary) and adds `report_group` (informational; the frontend doesn't need to pass it anywhere
   since the chat endpoints resolve it themselves from `lab_test`).
7. **Frontend:** `LabResultSummaryPanel` fetches the shared thread via a new
   `useReportChatHistory(labTest)` hook (mirrors `usePatientChatHistory`), renders `owner_name` for
   user turns, and adds interactive thumbs up/down on the latest assistant turn via a new
   `useSetReportChatFeedback` hook (mirrors `useSetChatFeedback`) — same UX the patient-wide chat
   already has. Both existing "Uploaded report" dialogs in `lab-center-tab.tsx` render this one
   shared component, so both get the capability for free, no changes needed there.
8. **Existing demo data migrated, not discarded:** the two already-existing test groups had
   `custom_report_group` backfilled by hand (no formal migration patch — this is one-off demo data,
   not a real production migration), and the 10 chat turns already recorded inline on one panel's
   `custom_ai_summary.chat` were moved into the new doctype rather than left orphaned.

## Alternatives Considered

1. **Adopt ADR-033's own suggested fix now: a shared per-report store (new doctype or a
   report-level link), so continuing the chat from any sibling stays in sync everywhere (chosen,
   after Alternative 2 below was tried first and replaced same day).**
   - Pros: The architecturally "correct forever" answer — zero divergence across a multi-panel
     report's sibling tests, ever, closing the exact gap ADR-033 named. Confirmed necessary, not
     just theoretically nicer, once a real 50-test panel scenario was described.
   - Cons: A new doctype + a new stamped field + a migration — genuine, contained scope; needed
     an id-based group key (not the narrative-text matching first tried) to avoid a real
     false-positive risk between unrelated uploads with similarly-worded AI summaries.

2. **Persist post-Done turns onto the SAME per-test `custom_ai_summary.chat`, scoped to the one
   Lab Test being viewed (tried first, same day; replaced by Alternative 1 above — see "Revision"
   above for what real use exposed).**
   - Pros: No schema change — reuses the exact field, shape, and read path ADR-033 already
     shipped; the frontend change is additive to one existing component; matches this codebase's
     established preference (ADR-033 itself, the multi-panel doc's AI Prompt Log reuse) for
     extending existing storage over adding doctypes. For the single-panel narrative report that
     prompted this request (no siblings at all), there is no divergence risk whatsoever.
   - Cons (confirmed, not hypothetical): for a genuine multi-panel upload, a question asked on one
     sibling's individual view does not appear on another sibling's individual view. At the 50-test
     scale a real scenario described, this stopped being a narrow edge case. The narrative-matching
     mechanism used alongside it to answer "how many reports" also produced a real false-positive
     match between two unrelated uploads with similarly-worded AI summaries.

3. **Keep it fully stateless, like the existing `ask_report_question` — nothing written back to
   `custom_ai_summary`; the continued conversation lives only in the browser tab and is lost on
   close.**
   - Pros: Simplest and safest of all four — zero persistence risk, zero divergence-across-siblings
     risk (nothing is shared because nothing is saved), exactly consistent with the sibling
     endpoint's already-proven design.
   - Cons: Directly contradicts the product intent ADR-033 itself recorded ("have that chat saved
     and shown later on the tests") for a report a clinician is *revisiting specifically to ask
     more about it* — losing the answer the moment the modal closes defeats the point of asking
     from the completed-report view rather than during the fleeting live review.

4. **A new, separate persisted thread for post-Done questions only** (e.g. a `lab_test` link field
   on `AI Patient Chat Message`, keeping the original ADR-033 review-time transcript in
   `custom_ai_summary.chat` untouched and routing every NEW post-Done turn into its own doctype-backed
   store instead).
   - Pros: Never touches the already-shipped `custom_ai_summary` reuse pattern at all; a report's
     "original AI-reviewed conversation" and "questions asked later" stay visibly distinct.
   - Cons: Two different places a "report chat" can live for the same Lab Test — more moving parts,
     a `LabResultSummaryPanel` that now has to merge and re-sort two sources to render one thread
     in order, and a new schema field for a distinction (original vs. later) users have not asked
     for and the UI does not need to expose.

## Consequences

- **Files changed:**
  - New doctype `remedisys_healthcare_ai/doctype/ai_report_chat_message/` (json + controller +
    `__init__.py`).
  - New custom field `Lab Test.custom_report_group` (`fixtures/custom_field.json`).
  - `remedisys_healthcare_ai/api/ai/lab_panel_extraction.py` — new `_stamp_report_group(lab_test,
    extraction)`, called from `create_order_for_panel` and `finalize_section_order`.
  - `remedisys_healthcare_ai/services/lab_result_summary.py` — new `report_group_key(lab_test)`,
    `report_group_members(lab_test)`.
  - `remedisys_healthcare_ai/api/ai/lab_result_summary.py` — `ask_saved_report_question` rewritten
    to persist via the new doctype; new `list_report_chat`, `set_report_chat_feedback`;
    `save_report_summary` no longer writes `chat` into `custom_ai_summary`, instead inserts the
    review-time transcript into the new doctype; `get_result_summary` drops `chat`, adds
    `report_group`.
  - `EB_Healthcare_Frontend/src/components/narzim/patient-chart/lab-result-summary-panel.tsx` —
    fetches the shared thread via `useReportChatHistory`, renders `owner_name` + interactive
    thumbs up/down via `useSetReportChatFeedback`.
  - `EB_Healthcare_Frontend/src/{types/labs.ts, hooks/use-labs.ts, lib/api/labs.ts}` and two new BFF
    routes (`app/api/labs/report-chat-history`, `app/api/labs/report-chat-feedback`).
  - No new i18n strings — `reportChatTitle`/`reportChatPlaceholder`/`reportChatSend`/
    `reportChatThinking`/`reportChatFailed`/`labChatThumbsUp`/`labChatThumbsDown`/
    `labChatReasonPlaceholder`/`labChatReasonSubmit` all already existed bilingually from ADR-033's
    and ADR-030's own work and are reused as-is.
- **`AI Prompt Log`** gains more `purpose="Lab Chat"` rows going forward (one per continued
  question) — no schema change, same purpose value `ask_report_question` already uses.
- **No divergence risk left**, at any N: `list_report_chat`/`ask_saved_report_question` resolve the
  same `report_group` regardless of which sibling's `lab_test` id is passed, verified live across
  two different siblings of a real 5-panel group.
- **Existing demo data**: two pre-existing test groups backfilled with a `custom_report_group`
  value by hand (not a formal patch — one-off demo data); 10 chat turns previously embedded inline
  on one panel's `custom_ai_summary.chat` were migrated into the new doctype.
- **Re-evaluation trigger:** none outstanding — this closes the gap Alternative 2 left open. If a
  future need arises to distinguish "the original AI-reviewed conversation" from "questions asked
  later" (Alternative 4), that would still be a compatible, additive change to this same doctype
  (e.g. a boolean/phase field), not a storage migration.

## Verification

- Live, non-mutating check against a real 5-panel group (`HLC-LAB-2026-00441`…`00445`):
  `report_group_key` and `report_group_members` return the identical group/member list whether
  called from `Litio` or from `Perfil Hormonal I` — confirmed the shared-store design actually
  eliminates the divergence Alternative 2 had.
  `list_report_chat(lab_test='HLC-LAB-2026-00441')` (Perfil Hormonal I) returned the full 10-turn
  thread originally recorded while viewing `Litio` — confirmed cross-sibling visibility works.
  `set_report_chat_feedback` set then cleared "Up" on a real row — confirmed round-trip.
- `bench migrate` applied cleanly: `DocType "AI Report Chat Message"` and `Custom Field
  "Lab Test-custom_report_group"` both exist in the live schema afterward.
- `ask_saved_report_question` rejects without `Lab Test` read permission; returns
  `{"answer": None, "status": "Disabled"}` when `enable_lab_extraction` is off (mirrors
  `ask_report_question`'s existing gates exactly).
- Ask a question referencing content NOT in this report (e.g. a different report's analyte) →
  answer should decline or say it isn't in this report — proves the context is genuinely scoped to
  the one report, not silently widened to the patient's full record.
- `AI Prompt Log` row for the call carries model/tokens/cost only, no message content (Rule 10).
- Frontend: `tsc --noEmit` clean across the whole app (one pre-existing, unrelated
  `e2e/encounter-submit.spec.ts` error only); `eslint` clean on every new/changed file — the only
  lint errors found are pre-existing `setState`-in-effect violations in `lab-order-dialog.tsx`, a
  file untouched by this work. Manual check pending (post bench-restart): both the single-report
  and combined-group "Uploaded report" modals in `lab-center-tab.tsx` show the new input, a newly
  asked question appears immediately without a reload, and thumbs up/down persist across a reload.

## References

- ADR-033 (report summary + review-screen chat — the design this extends)
- ADR-029 (patient-wide clinical summary — the separate, unaffected "Lab Summary & Assistant" chat)
- ADR-022 (multi-panel extraction — why one report can create several sibling Lab Tests)
- `remedisys_healthcare_ai/services/lab_result_summary.py:365-447, 547-577` (`_report_lab_rows`,
  `_stored_report_narrative`, `report_chat_context`)
- `remedisys_healthcare_ai/api/ai/lab_result_summary.py:129-140, 422-519` (`_resolve_narratives`,
  `ask_report_question`)
- `EB_Healthcare_Frontend/src/components/narzim/patient-chart/lab-result-summary-panel.tsx:119-156`
  (the read-only chat block being made continuable)
- `EB_Healthcare_Frontend/src/components/narzim/patient-chart/lab-center-tab.tsx:1225-1255` (the two
  "Uploaded report" modals that render it)
- Rule 5 (bounded context — `report_chat_context` already caps both rows and narrative text), Rule 6
  (advisory only), Rule 10 (no PHI in `AI Prompt Log`)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-08-21 | Divyanshu (AI-assisted) | Replaced Alternative 2 (shipped first) with Alternative 1 (shared doctype, id-based group key) same day — real use exposed both the divergence-at-scale problem and a narrative-matching false positive. Decision/Consequences/Verification rewritten for the final design |
| 1.1 | 2026-08-21 | Divyanshu (AI-assisted) | Status: Proposed → Accepted; implemented (backend + frontend) |
| 1.0 | 2026-08-21 | Divyanshu (AI-assisted) | Initial version |
