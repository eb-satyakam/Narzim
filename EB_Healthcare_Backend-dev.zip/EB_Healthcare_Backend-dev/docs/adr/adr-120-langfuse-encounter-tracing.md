# ADR-120: Local Langfuse traces the whole encounter flow, grouped by encounter

**Doc status:** living · **Created:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-10-01
- **Supersedes:** —
- **Superseded by:** —

## Context

`integrations/langfuse_trace.py` sends LLM and tool spans to a Langfuse instance on the
developer's machine. It is gated to developer sites (`developer_mode` + `langfuse_enabled` +
keys) and is a no-op everywhere else. It is the only place a developer can see what was sent to
the model and what came back; `AI Prompt Log` deliberately stores no content (BE-10).

A full run of the v9 encounter flow on `marley.local` on 2026-10-01 (Bruno
`bruno/encounter-flow/` plus the v9 screen) showed what the module could not answer:

1. **No grouping by encounter.** `session_id` falls back to the request id, so every request is
   its own session. "What did the AI do, and what did it cost, for this visit?" has no answer.
2. **Only requests that call a model get a trace.** `save_draft`, `accept_soap_draft`,
   `record_consent` and the rest of the flow are invisible. An `accept_soap_draft` call that took
   30–40 s (it normally takes milliseconds) left no trace to explain it.
3. **The trace itself is empty.** The root span has no input and no output, so the list view
   shows "—" for every request.
4. **Background jobs are not closed.** `_ensure_root()` opens a root span in an RQ job, but only
   `after_request` closes it, and jobs never run that hook. The Overview clinical summary and lab
   summaries run as jobs.
5. **The prompt name is wrong for composed prompts.** `note_prompt()` keeps the last file loaded.
   A v9 SOAP draft loads `soap-v1` and then its addendum, so the span reports the addendum as the
   prompt.
6. **Silent failures stay silent.** When the SOAP reply is not valid JSON, the adapter returns no
   suggestions and nothing in the trace says why.

Measured on the same run: a v9 SOAP draft sent 8,689 input tokens, of which the system prompt was
about 4,300 and the catalogs about 4,000; the transcript was 16. That kind of number is why this
tracing exists.

The team's existing test `test_a_patient_identifier_never_reaches_a_trace_attribute` records a
deliberate rule: trace attributes name the clinic user, never a patient or an encounter.

## Options considered

| # | Option | Why not / why |
|---|---|---|
| A | **Call `set_session()` and annotation helpers by hand in each encounter endpoint** (~40 methods) | Every new endpoint has to remember it, and the ones that forget are exactly the gaps found above. Spreads tracing code through clinical modules |
| B | **OpenTelemetry auto-instrumentation** of the WSGI app and `requests`, exported to Langfuse over OTLP | New dependencies in the bench; spans know HTTP, not Frappe methods, encounters or prompts; the LLM spans would duplicate the ones the module already makes |
| C | **Put the content into `AI Prompt Log`** and skip Langfuse | Reverses BE-10 for every environment, including production. Rejected outright |
| D | **LangGraph / LangSmith** | `CLAUDE.md` §2 locks orchestration to plain Python and RQ ("Not LangGraph"); LangSmith is a hosted service, which would send PHI off the machine (PHI-1) |
| E | **Request-level root for every app request, identity derived once from the request arguments** | Chosen. One place in the module, no per-endpoint code, works for new endpoints automatically |

## Decision

All of this stays inside `integrations/langfuse_trace.py` and stays behind the existing gate.
Production behaviour does not change.

1. **Every request to a `remedisys_healthcare_ai.*` method gets a trace**, opened in a
   `before_request` hook, whether or not it calls a model. `langfuse_trace_scope: "ai"` in
   site_config restores the old behaviour (trace only requests that call a model).
2. **Encounter sessions, without an encounter id.** The session id is
   `enc-` + the first 16 hex characters of `sha256(site + ":" + encounter)`. The encounter is read
   from the request arguments: `encounter` directly, or resolved from `session`
   (AI Encounter Session) or `draft_name` (AI SOAP Draft). An explicit `set_session()` (Narzim
   GPT's chat thread) still wins. The raw encounter id never becomes a trace attribute, so the
   team's rule and its test hold. `session_for(encounter)` prints the session id for a developer.
3. **The root span records the request and the response**: the arguments (secret-looking keys
   masked, long strings cut at 2,000 characters, uploaded files replaced by their name and size)
   and the response status and body (cut at 8,000 characters). A 4xx/5xx response marks the trace
   `ERROR`. This is content, like the generation spans already are, and lives in the same local
   store.
4. **Background jobs close their own trace.** When a root opens inside an RQ job, the module
   registers a close-and-flush callback on `frappe.local.job.after_job`, which Frappe runs after
   success and failure alike. The trace is named after the job method. No `hooks.py` entry, so
   jobs that trace nothing pay nothing. The flush is synchronous because the job's process may
   exit right after.
5. **Every prompt loaded before a call is recorded.** `note_prompt()` keeps its contract (the last
   prompt, as the team's test requires) and also appends to a per-call list; the generation span
   gets `prompt_versions` (all of them) and is named after the first one, e.g.
   `openai.chat.stream · soap-v1`.
6. **Quality events.** The SOAP adapter emits an `ERROR` event when the reply is not valid JSON,
   with the reply's length (not its text).

## Consequences

- A developer can open Langfuse → Sessions and see one encounter's whole flow, AI and non-AI
  calls, in order, with latency, tokens and cost.
- Every app request on a traced dev site now sends one trace. Langfuse runs locally, so the cost
  is local disk; the scope switch turns it off.
- More PHI goes into the local Langfuse store (request and response bodies). It was already
  receiving prompts and replies; the rules in `docs/grafana/LANGFUSE_LOCAL_TRACING.md` §5 apply
  unchanged: test patients only, never a hosted Langfuse.
- Background jobs that call a model are flushed synchronously at the end of the job. With the
  Langfuse container stopped, a job can wait for the exporter's timeout before it ends.
- Not covered: the browser and the live Deepgram stream (ADR-009 keeps audio off the server), and
  the Anthropic paths that are not yet wrapped (`anthropic.py::_call_claude`, `_stream_messages`).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Renumbered from 117 to 120: open billing PRs #482/#483 also took that number, and no branch uses 120 (ADR-042: the unmerged side moves) |
| 1.0 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Initial decision |
