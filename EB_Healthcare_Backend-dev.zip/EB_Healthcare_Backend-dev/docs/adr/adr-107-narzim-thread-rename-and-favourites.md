# ADR-107: Rename a Narzim GPT conversation and mark it a favourite

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

A conversation in Narzim GPT is not a row. It is the set of `AI Narzim Assistant Message` rows that
share a `thread` id, and its name is the `thread_title` generated on its first row. The owner asked
for two things the sidebar could not do: rename a conversation, and keep chosen ones in a
Favourites section.

## Decision

1. **Rename** writes the clinician's title to `thread_title` on the thread's first row and clears
   it from any later row. No new field. `modified` is left alone, so a rename does not reorder the
   history. A title is limited to 120 characters and refused, not cut, beyond that.
2. **Favourites** are one per-user default, `narzim_favourite_threads`, holding a JSON list of
   thread ids, at most 50. `list_threads` returns `favourite` on each row. Removing a conversation
   takes it out of the list.
3. Both are scoped to the caller's own visible rows. Somebody else's thread id reads as a
   conversation that does not exist.

## Alternatives Considered

### Where a favourite is stored

1. **A `favourite` Check field on the message doctype.**
   - Pros: queryable; visible in Desk.
   - Cons: a schema change and a migrate on every site (BE-9) for a sidebar preference; the flag
     would sit on one row of many and every reader would need to know which.
2. **A per-user default holding thread ids (chosen).**
   - Pros: no schema change; per user by construction; holds ids only, no content.
   - Cons: a JSON list in a text value; capped at 50 to keep it small.
3. **A new `AI Narzim Thread` doctype, one row per conversation.**
   - Pros: the right home for a title, a favourite and later a folder.
   - Cons: a migration of every existing thread and a second source of truth for the title. Worth
     doing when a third per-thread property appears, not for two.
4. **Browser storage.**
   - Pros: no backend work.
   - Cons: lost on another device or a cleared browser; the owner asked for it to persist.

### Where a renamed title is stored

1. **`thread_title` on the first row (chosen).** Pros: the field `list_threads` already reads.
   Cons: later rows must be cleared, because the list takes the last title it meets.
2. **A separate `user_title` field.** Pros: keeps the generated title. Cons: a schema change, and
   nothing reads the generated title once the clinician has chosen their own.
3. **Every row of the thread.** Pros: no ordering rule. Cons: dozens of writes for one rename.

## Consequences

- No doctype changes and no migrate.
- A title is free text typed by the clinician, like a message. It is not sent to a provider.
- Re-evaluate in favour of alternative 3 when conversations need folders, sharing or pinning order.

## Verification

- `tests/ai/test_narzim_thread_rename_favourite.py`, 16 tests, including that the content, the
  scope verdict and `modified` are unchanged by a rename.
- `tests/ai/test_narzim_hide_history.py` still passes.

## References

- `docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md` (no session doctype, soft delete)
- `CLAUDE.md` BE-9, BE-10

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-105 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
