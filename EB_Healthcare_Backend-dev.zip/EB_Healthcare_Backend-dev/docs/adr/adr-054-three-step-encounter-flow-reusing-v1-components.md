# ADR-054: Ship the encounter as a 3-step flow that reuses the V1 components

**Doc status:** living · **Created:** 2026-08-26 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

> **Renumbered 050 → 054 on 2026-08-31.** `dev` merged
> [`adr-050-narzim-assistant-domain-scope-gate.md`](adr-050-narzim-assistant-domain-scope-gate.md)
> (PR #365) while this branch was open, so two different decisions held the same
> number. ADR-042 forbids reusing a number and ADR-043 makes the FILENAME the
> identity, so the unpublished one moved; 051, 052 and 053 were already taken on
> this branch, making 054 the next free. The decision itself is unchanged.

- **Status:** Accepted
- **Date:** 2026-08-26
- **Supersedes:** the single-screen recommendation in
  [`architecture/ENCOUNTER_UX_RESEARCH.md`](../architecture/ENCOUNTER_UX_RESEARCH.md) §"Recommended screen structure"
- **Superseded by:** —

## Context

The V1 encounter screen (`encounter-screen.tsx`, ~6,400 lines) is the working
clinical surface. Two problems drove a redesign:

1. **Measured usage.** Across 144 encounters, six fields carry the encounter.
   `hpi`, `physical_examination`, `notes` and free-text ICD were populated in
   0–1% of records. The screen presents them all with equal weight.
2. **P0-2, the consent bypass.** `CopilotHost` starts recording in a mount
   effect. All 144 `AI Encounter Session` rows carry `consent_obtained = 1`,
   set client-side by code that never asked anyone
   ([`ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md) GAP-1).

Two designs were prototyped. A single-screen workspace (`workspace.tsx`, on mock
data) and a 3-step flow. The 3-step flow was chosen by the product owner on
2026-08-25 and confirmed as final.

The decisive constraint arrived during implementation: a v3 that *reimplements*
V1's fields is a second implementation of the same clinical contract. The first
build of step 3 did exactly that and drifted immediately — an add button that
did nothing, and a real risk of the P0-4 defect class, where writing a rendered
string like `"6 Hours"` back over the `interval` / `interval_uom` fields silently
erases dosing frequency from a live prescription.

## Decision

**Ship the 3-step flow. Build step 3 out of V1's own components and V1's own
read/write functions, not copies of them.**

1. `NEXT_PUBLIC_FEATURE_ENCOUNTER_V2` selects the screen at `/encounters/[id]`:
   off → V1 untouched; on → the 3-step flow. **No second route.**
2. Step 3 imports `SymptomsInput`, `ObjectiveBody`, `DiagnosisInput`,
   `PlanOrdersBody` and `EducationBody` from `encounter-screen.tsx`. Only the
   layout around them is new.
3. Reads go through V1's `encFromEncounter()`; writes through V1's
   `buildSaveDraftPayload()` and `flushTypedVitals()`. There is exactly one
   payload builder in the codebase.
4. Recording is driven through `useCopilot` directly, never `CopilotHost`.
   `start()` is reachable only from an explicit human answer to the consent
   question.
5. The single-screen prototype and its mock data are **deleted**, not parked.

## Alternatives Considered

1. **Keep both surfaces, converge later.**
   - Pros: no deletion; the single-screen design stays reviewable.
   - Cons: two half-wired copies of one screen. The prototype rendered a mock
     patient, and its `MOCK_PATIENT` fallback had already leaked into the shared
     header component used by the real screen (FE-16).

2. **Rebuild the fields in v3 with a cleaner API (rejected).**
   - Pros: v3 owns its code; no coupling to a 6,400-line file.
   - Cons: two implementations of dosing, order billing defaults (ADR-025),
     vaccine nurse routing (ADR-020) and the days→seconds therapy conversion.
     Tried, and it drifted within a day.

3. **Reuse V1's components and functions (chosen).**
   - Pros: the clinical behaviour cannot diverge, because it is the same code.
     Bug fixes land on both screens at once.
   - Cons: v3 is coupled to V1's props; V1 cannot be deleted until v3 absorbs
     it; V1's mount-order quirks are inherited (see Consequences).

4. **Extract the sections into a neutral shared package first.**
   - Pros: cleanest long-term boundary.
   - Cons: a large refactor of the live clinical screen before the new design
     has been validated with clinicians. Defer until v3 is accepted.

## Consequences

- `encounter-screen.tsx` gains five `export` keywords, `EMPTY_ENC`,
  `encFromEncounter()`, and exports on `buildSaveDraftPayload()` /
  `flushTypedVitals()`. **No logic changed** — verified line-for-line, with an
  identical eslint count before and after.
- **Mount order is now part of the contract.** `PlanOrdersBody` has an effect
  keeping `enc.plan` equal to the applied templates. V1 survives it because it
  mounts blank and hydrates later. v3 must do the same: all three steps stay
  mounted, and loading is an overlay, never a separate tree. Mounting step 3
  after hydration wiped a real encounter's plan text in testing.
- The save layer refuses to write before hydration, so the blank starting state
  cannot land on a draft.
- Deleted: `workspace.tsx`, `use-mock-encounter.ts`, `mock-data.ts`,
  `order-table.tsx`, `order-specs.ts`, `catalog-picker.tsx`,
  `use-encounter-options.ts`, and the `/encounters/v3-prototype` route. v3 went
  from 4,990 to 2,140 lines.
- **Re-evaluation trigger:** when V1 is retired, alternative 4 becomes the right
  shape — extract the sections into their own module and drop the import from
  a screen that no longer exists.

## Verification

- `/encounters/HLC-ENC-2026-00150` with the flag on renders three steps and the
  real patient; with the flag off renders V1.
- Parity test: the same prescriber interaction driven on both screens produces
  **byte-identical** `save_draft` payloads, including `interval`,
  `interval_uom`, `strength`, `bill_this` and `plan`.
- A signed encounter (`HLC-ENC-2026-00053`) issues **zero** writes.
- `tsc` and `eslint` clean across the changed files.
- Commits `57f4a00` (extraction) and `457635e` (flow) on
  `feature/encounter-progressive-disclosure`.

## References

- [`architecture/ENCOUNTER_UX_RESEARCH.md`](../architecture/ENCOUNTER_UX_RESEARCH.md)
- [`architecture/ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md)
- ADR-009 (browser-direct audio), ADR-019 (vaccines in the SOAP blob),
  ADR-020 (vaccine → nurse order), ADR-025 (`bill_this`), ADR-039 (any
  practitioner may sign)
- Frontend constitution FE-15 … FE-18

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Renumbered 050 → 054; `dev` had merged a different ADR-050. Decision unchanged |
| 1.0 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | Initial version — records the 3-step decision and the reuse-V1-components constraint |
