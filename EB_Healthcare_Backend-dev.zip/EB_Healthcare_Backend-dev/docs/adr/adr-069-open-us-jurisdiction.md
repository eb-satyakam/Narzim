# ADR-069: Open US scope as a third jurisdiction, with the cell as the unit of jurisdiction

**Doc status:** living · **Created:** 2026-09-14 by Nishant · **Updated:** 2026-09-14 by Nishant · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-14
- **Supersedes:** ADR-018 (India and Mexico as the only two markets)
- **Superseded by:** —

> Part of the decision to move the platform to AWS. This ADR records **how** US scope opens,
> and the preconditions that gate the first US tenant. It does not claim any of them are met.
> Raised by [`COMPLIANCE_MULTI_JURISDICTION.md`](../security/COMPLIANCE_MULTI_JURISDICTION.md)
> Stage 3.3.

## Context

ADR-018 established pluggable compliance profiles with `mx` and `india`, activated per deployment
via `remedisys_compliance_profile`. That decision holds. Two things have changed since.

**The V2 platform introduces cells.** A tenant is placed in one cell by region and deployment. That
gives jurisdiction a physical home it did not have when ADR-018 was written against a single site.

**The user population is projected at 1,000 clinicians, and US tenants are plausible within that
range.** Waiting until a US customer appears means discovering the design constraints under
commercial pressure, which is the worst time to find that an obligation inverts.

Three facts shape the decision:

1. `COMPLIANCE_MULTI_JURISDICTION.md` **D1** chose a strictest-common-denominator superset plus an
   enforcement layer, and explicitly rejected "add a `us` profile plus ~15 fields" because the
   profile pattern had produced eleven unread fields in fourteen months.
2. **Most obligations are monotonic across the three regimes.** Consent, breach clocks, residency
   and de-identification are all satisfied by doing the strictest thing everywhere.
3. **Erasure is not.** Mexico and India require deletion; HIPAA forbids deleting the designated
   record set and mandates retention. No superset satisfies both.

## Decision

Open US as a supported jurisdiction, under four rules.

### 1. The cell is the unit of jurisdiction

One cell carries exactly one compliance profile, for the life of the cell. A US tenant means a **US
cell**, never a flag on a cell serving another regime.

Consequence: no row is ever ambiguous about which law governs it, and no query reasons about mixed
regimes. Onboarding a jurisdiction becomes an infrastructure operation with a known cost rather
than unbounded reasoning in application code.

### 2. Jurisdiction resolution fails closed

`get_active_profile()` currently reads `remedisys_compliance_profile` from `site_config.json` and
**defaults to `mx` when the key is absent**. An unknown value throws; an absent one does not.

That is reversed. Absence throws. A default is a guess about the law, and it will be made by
whoever forgets a config key rather than by whoever understands the regime.

This is a breaking change for any deployment relying on the default, so it ships as: set the key
explicitly on every existing site, then tighten the code. Not the reverse.

### 3. Monotonic obligations use the superset. Inverted obligations use a decision function

D1's superset stands for anything where doing more satisfies everyone. It cannot express an
obligation that inverts.

`right_to_erasure: bool` is therefore replaced by an erasure **decision**, evaluated per record
class, returning an outcome and a reason:

| Record class | Mexico · India | United States |
|---|---|---|
| Clinical record under a retention duty | Block, then erase after the duty expires | **Retain.** Deleting is the violation |
| Non-clinical (marketing, analytics, unused account) | Erase | Erase |
| Anything under legal hold | Retain, and say so | Retain, and say so |

A boolean that answers "yes or no" for something that is really "it depends on the record class" is
a lie that type-checks. This shape is cheaper to adopt before the Stage 2.3 erasure service is
written than after.

### 4. Adding a jurisdiction is config plus review, never new code paths

Every PHI-touching path passes through one of a small enumerable set of choke points: consent gate,
retention executor, erasure service, egress gate, audit writer, subprocessor registry. Each reads
policy rather than constants.

The Stage 2.6 CI gate is extended: every profile field has at least one real consumer, **and** every
profile is exercised against every choke point. Adding a fourth jurisdiction is then a profile, a
test run, and a legal review.

## Preconditions for the first US tenant

None of these are met today. All are tracked in `COMPLIANCE_MULTI_JURISDICTION.md`.

| # | Precondition | Gap | Lead time |
|---|---|---|---|
| P1 | **Signed BAAs with every subprocessor that receives PHI**, LLM and speech included | G1 | Weeks to months. **The long pole, and it is procurement, not engineering** |
| P2 | Encryption at rest | G3 | Hosting decision, see D2 |
| P3 | Consent gate enforced server-side, not defeatable from the frontend | G5 | Stage 1 |
| P4 | `scheduler_events` enabled; retention and erasure can actually execute | G2 | Stage 2.1 |
| P5 | Erasure service built to the decision shape above | G11 | Stage 2.3 |
| P6 | HIPAA technical safeguards and annual risk analysis | — | Stage 3.4 |

**P1 gates everything.** No router design makes it lawful to send PHI to an endpoint with no BAA.

## Alternatives Considered

**Keep US closed until a customer appears.** Sequencing by legal deadline is sound, and this is why
US work is last in the plan. Rejected as a design posture, not as sequencing: the erasure inversion
changes the shape of a service being written in Stage 2, so discovering it later means rewriting
that service rather than parameterising it.

**One global deployment with per-tenant policy.** Rejected. It puts mixed regimes in one database
and makes every query a jurisdiction question. The cell model already exists; this would abandon it
for the hardest case.

**Add a `us` profile with the existing field set.** This is D1 option A, already rejected on
measurement. This ADR does not reintroduce it: the US entry carries only genuinely divergent
values, and the inverted one becomes a decision rather than a field.

## Consequences

- A US tenant requires a US cell: a second region, a BAA chain, and HIPAA controls. That cost is now
  explicit rather than discovered at signing
- The erasure service gains a record-class taxonomy it would otherwise have needed retrofitted
- Existing deployments must set `remedisys_compliance_profile` explicitly before the fail-closed
  change ships, or they will not boot
- ADR-018's pluggable-profile architecture is retained; only its two-market scope is superseded
- ADR-007's Mexico-only lock stays superseded

## Verification

- A test asserts `get_active_profile()` raises when the key is absent
- A per-profile matrix exercises each choke point against `mx`, `india` and `us`
- The Stage 2.6 CI gate fails when a profile field has no consumer
- The erasure decision has a case per row of the record-class table, per profile

## References

- [`COMPLIANCE_MULTI_JURISDICTION.md`](../security/COMPLIANCE_MULTI_JURISDICTION.md) D1, G1, G2, G5, G11, Stage 2, Stage 3.3
- [ADR-018](./adr-018-multi-jurisdiction-compliance.md) — the pluggable profile architecture this retains
- [`docs/platform/05-deployment.md`](../platform/05-deployment.md) — cells and the jurisdiction router
- [`docs/platform/01-system-map.md`](../platform/01-system-map.md) — the runtime model the cell contains
- [`docs/platform/02-invariants.md`](../platform/02-invariants.md) — monotonic versus inverted obligations

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-14 | Nishant | Initial version |
