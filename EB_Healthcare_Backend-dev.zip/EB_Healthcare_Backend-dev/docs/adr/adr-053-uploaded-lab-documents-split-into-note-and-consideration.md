# ADR-053: An uploaded lab is split — values into the note, interpretation never

**Doc status:** living · **Created:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.0

- **Status:** Proposed
- **Date:** 2026-08-31
- **Supersedes:** —
- **Superseded by:** —

## The problem

A clinician photographs a lab report into the encounter chat. The AI reads it,
answers in the chat, and **stops there**. The values never reach the note, so
the clinician retypes them by hand — twelve lines for a twelve-serotype panel,
during a consultation.

The obvious fix is to let the reading flow into the note. That is where it gets
dangerous, because a single vision reading produces **two different things**:

```
values    "All 12 serotypes: <0.3 mcg/mL"          ← evidence
meaning   "consistent with an inadequate response"  ← a clinical judgement
```

If the second one lands in the note, the doctor's signature says a doctor
concluded it.

**USER STORY.** Dr. Bracamontes uploads a pneumococcal panel → **the note is
written** to include *"inadequate vaccine response"* → he skims and signs →
**the record now contains a diagnosis he never made**, in his name, and the
child may be revaccinated on it.

## The decision

Split the reading in two before anything reaches the record.

**1. Values go into Objective, verbatim, with their source and date.**

```
OBJECTIVE

Lab · Akulab (Quest Diagnostics, Nichols Institute)
Collected 20/07/2026 · Resulted 29/07/2026 · Order 10053928
  Anticuerpos IgG S. pneumoniae, 12 serotypes
  All serotypes: <0.3 mcg/mL
```

Objective, because Subjective is what the patient reports and Objective is what
is measured. A lab is measured.

The source line is not decoration. The transcript is evidence of what was said
in the room; a lab is evidence of something that happened in another building on
another day. Blending them loses the distinction the doctor needs to trust
either.

**2. Interpretation is a consideration, never note text.**

```
┌─ Not ordered ────────────────────────────────┐
│ All 12 pneumococcal serotypes below          │
│ 0.3 mcg/mL on the 29/07 report.              │
│ [ Review ]  [ Add ]  [ Dismiss ]             │
└──────────────────────────────────────────────┘
```

Same instruction the transcript path already uses: copy what is printed, never
say what it means, and ignore any interpretation section the report carries.

**3. The document must match the patient.**

```
This report is for Lopez Jimenez Carlos Nicolas, DOB 23/04/2021.
This encounter is Mario Matias Hernandez Gongora. Not attached.
```

An override exists — some reports genuinely carry a guardian's name, or a
lab-side typo — but it is a recorded decision, not a silent default.

**4. Every lab line carries its date.** Always, not only when the result is old.
A value with no date cannot be read safely a year later.

All of it appears at **Review SOAP**, the step where the clinician already reads
and corrects the draft. No new screen, no new habit.

## Why not the alternatives

| Option | Why it loses |
|---|---|
| Put the whole reading, interpretation included, into Objective | the signature then asserts a conclusion no clinician reached |
| Leave it in the chat, as today | the clinician retypes twelve lines mid-consultation, and mistypes them |
| Attach the file only, no reading | the values are in the chart but not in the note, so the note is incomplete |
| Ask the model to "be careful" not to interpret | that is a prompt, not a guarantee. The split is enforced by code |

## What follows from it

- **Good:** values reach the note without retyping, and their provenance travels
  with them.
- **Cost:** Objective grows long on a multi-panel report. A twelve-serotype panel
  is twelve lines, and it should be collapsed to one summary line — open work.
- **Depends on:** the patient-match check. Without it this decision makes it
  *easier* to put another child's results into this child's note.

## References

- [`ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md) §4 — where this appears on screen
- `services/ai.py::_resolve_attached_labs` · `_strip_interpretation`
- CLAUDE.md Rule 6 — physician in control

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Rewritten for length and readability: 200 → ~110 lines, a user story, and the alternatives as a table. Decision unchanged; still Proposed |
| 1.0 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
