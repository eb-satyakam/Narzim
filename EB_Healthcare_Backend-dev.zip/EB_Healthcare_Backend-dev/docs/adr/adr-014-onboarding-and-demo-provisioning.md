# ADR-014: Onboarding and demo provisioning — sandbox-first hybrid

**Doc status:** living · **Created:** 2026-06-22 by Sarvesh-SocialAngel · **Updated:** 2026-06-22 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-06-22
- **Supersedes:** —
- **Superseded by:** —

## Context

We need new Remedisys clinics to come up usable with minimal effort, at a target
of ~10 onboardings/day, and we want a self-serve demo so a prospect on the
marketing site can try the product. Today none of this is automated:

- **Seeding is fragmented** across fixtures (`hooks.py`), two migration patches
  (`patches/v0/seed_cardiology_*`), and manual `scripts/seed/*` that only run
  when a developer invokes them. There is **no install-time entry point** — the
  `after_install` hook is commented out.
- The cardiology seed patches **break the Frappe Cloud build**: they create
  records with Link / Dynamic-Link references (`Prescription Dosage`,
  `Prescription Duration`, `Lab Test Template`, `Clinical Procedure Template`)
  that exist on `marley.local` but not on a fresh site, so `bench migrate`
  throws `LinkValidationError` and aborts. Because `rebuild_eb_role_permissions`
  (ADR-relevant, see `prompts/2026-06-22-eb-roles-rpm-permission-rebuild.md`) is
  listed after them in `patches.txt`, a failed seed also means **EB roles and
  permissions never get applied** on Frappe Cloud.
- Frappe Cloud gives a **14-day free window**; we offer clients a **7-day demo**.
  A 7-day demo therefore sits inside the 14-day free window with a 7-day buffer
  to delete or convert before any billing.
- Constraints that shape this: Frappe Cloud deployment (ADR-005); users are
  Website Users with `desk_access = 0` (cannot use Frappe's built-in Desk setup
  wizard); Next.js BFF frontend (ADR-010); jurisdiction Mexico, synthetic-only
  demo data required for PHI/LFPDPPP (ADR-007); build order = core platform
  first (Constitution §2). Whether Frappe Cloud grants the 14-day trial
  **per-site** or **per-account**, and whether the Press API allows programmatic
  site creation, is **currently unconfirmed**.

## Decision

Adopt a **sandbox-first hybrid** onboarding and demo architecture, built in
three layers and sequenced so the core platform is unblocked first. Provisioning
of fully isolated per-clinic sites is **deferred** behind an unconfirmed vendor
capability and real demand.

1. **Foundational seed (auto, on install).** Enable `after_install` to run an
   idempotent, dependency-ordered seeder for data the app cannot run without and
   that is identical everywhere: roles + permissions (delegating to the existing
   `eb_docperm_spec.json` rebuild), prescription dosages/durations, dosage forms,
   required UOMs, document categories. The fragile cardiology seed patches are
   refactored to delegate to ordered seeders (dependencies first), which removes
   the `LinkValidationError` and fixes the Frappe Cloud build.

2. **In-app onboarding wizard (Next.js, first login).** A custom multi-step
   wizard in `Healthcare_next_app` — NOT Frappe's Desk wizard — that (a) collects
   per-clinic config (locale pre-filled to Mexico/es-MX/MXN, clinic profile,
   rooms, practitioners) and (b) lets the admin select clinical **packs**
   (general, cardiology, rehabilitation, pediatrics/immunization) to install.
   Each step calls a whitelisted `api/v1` method; bulk packs run as **RQ
   background jobs** with progress. An onboarding-status flag gates first login.

3. **Self-serve demo = instant shared sandbox.** One always-on paid Frappe Cloud
   site; each "Create my demo" provisions a **Company + synthetic data + a
   company-scoped demo user**, expiring after 7 days by disabling the company.
   No per-demo site creation, no FC Press API dependency, ~$0 marginal cost,
   cleanup = drop the company. Isolation relies on existing per-company
   permission scoping (`project_multiclinic_facilities`).

4. **Per-site auto-provisioning is deferred** to demo→paid conversion only, and
   only if Frappe Cloud confirms (a) per-site 14-day free and (b) a programmatic
   Press API. It is out of scope for the top-of-funnel demo.

## Alternatives Considered

1. **Per-site Frappe Cloud provisioning for every demo (control plane + Press API).**
   - Pros: full tenant isolation; matches "a site is created automatically"; each
     site rides FC's free trial if per-site.
   - Cons: provisioning takes minutes (no instant demo); depends on **unconfirmed**
     FC per-site trial + Press API; cleanup-before-day-14 logic is fragile and
     risks real bills; a public button that creates real sites is a cost/abuse
     magnet; needs a whole new control-plane service. Too much risk for the funnel.

2. **Instant shared-sandbox demo + foundational auto-seed + wizard (chosen).**
   - Pros: instant (seconds); ~$0 marginal cost; no dependency on the unconfirmed
     FC API; reuses multi-company + company-scoped permissions; trivial cleanup;
     fixes the build error as a side effect; foundational seed unblocks core now.
   - Cons: weaker isolation than separate sites (mitigated: synthetic data only,
     strict company scoping); per-site isolation still needed later for real
     paying customers (handled by layer 4).

3. **Convert everything to ordered fixtures, no wizard, no demo.**
   - Pros: simplest; declarative; auto on install/migrate; fixes build error.
   - Cons: fixtures re-import on every migrate (fights per-clinic edits); no
     self-serve demo; no pack selection; doesn't address the onboarding UX or the
     demo funnel the business wants.

## Consequences

- **Constitution:** adds an Onboarding/Demo workstream; reaffirms "core platform
  first" by sequencing foundational seed + build fix before the wizard and demo.
- **Code to write (backend):** enable `after_install`; a
  `remedisys_healthcare_ai/setup/seed/` ordered idempotent seeder module;
  refactor `seed_cardiology_*` patches to delegate (deps first); whitelisted
  onboarding/pack APIs (RQ jobs); an onboarding-status field/doctype; (later)
  demo-sandbox provisioning API + expiry scheduler.
- **Code to write (frontend):** first-login onboarding wizard; multi-tenant /
  company resolution in the BFF; "Create my demo" entry on the marketing site.
- **Operational:** demos are synthetic-data only; abuse controls (email verify,
  captcha, rate limit) required before any public demo button; demo expiry job.
- **Build fix:** the Frappe Cloud `bench migrate` build goes green and EB
  roles/permissions apply on deploy.
- **Re-evaluation triggers:** Frappe Cloud confirms per-site 14-day free + Press
  API → promote layer 4 (per-site) sooner; demand for hard tenant isolation in
  demos → revisit the sandbox model.

## Verification

- Frappe Cloud deploy completes `bench migrate` with no `LinkValidationError`,
  and `Patch Log` shows `rebuild_eb_role_permissions` ran (roles/permissions
  present on the deployed site).
- A freshly installed/reset site has the foundational master data without any
  manual step (`after_install` seeded it).
- The onboarding wizard provisions a clinic end-to-end from first login.
- "Create my demo" yields a working, company-scoped, synthetic-data demo in
  seconds, and is gone after 7 days.

## References

- Constitution §2 (build order), §3 (locked assumptions), §6 (repo layout)
- ADR-005 (Frappe Cloud), ADR-007 (Mexico/PHI), ADR-010 (Next.js BFF)
- `prompts/2026-06-22-eb-roles-rpm-permission-rebuild.md`
- `docs/planning/ONBOARDING_PLAN.md` (companion implementation plan)
- Memory: `project_multiclinic_facilities`, `project_eb_docperm_patch`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-22 | Sarvesh | Initial version (header backfilled from git history) |
