# ADR-072: Reschedule/reassign delta invoices were silently dropping tax, and Patient 360 could only ever show one invoice per appointment

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-16
- **Supersedes:** — (no prior ADR governed `_create_reschedule_delta_invoice`'s tax handling or the appointment card's invoice display)
- **Superseded by:** —

## Context

Reported live, with a concrete trail: a patient (Diego Gómez Reyes, MRN-2026-0001427) was booked with Sarvesh Sandhu (fee 500 + 16% tax = 580, invoiced and paid in full), reassigned to Anant Sharma (fee 1000, additional 420 collected), then reassigned again to Dr Hathi (fee 2000). The Revenue/Billing hub showed 3 real, paid invoices for this patient (580 / 420 / 1137.93) — but the request was to "check the collection and all," and, separately, that the Patient Chart only ever showed one of the three invoices for the appointment ("we have to show all not single").

Tracing the numbers surfaced two independent, real defects:

1. **The Dr Hathi reassignment undercharged the patient by the exact tax amount.** `adjust_payment_for_reschedule` (`services/billing.py`) correctly computed the target: Dr Hathi's fee (2000) tax-inclusive is 2320; 1000 was already paid (580 + 420); the delta owed is 1320. It correctly backs the tax out to a pre-tax rate (1320 ÷ 1.16 = 1137.93) on the assumption that core will re-apply that 16% tax when the invoice is saved. `_create_reschedule_delta_invoice` then built and submitted that invoice — but never set `item_tax_template` (or the JSON `item_tax_rate` map core's own tax engine actually reads) on the row, so the tax was never applied. The invoice submitted at exactly 1137.93 — the patient paid 182.07 MXN less than the reassignment should have collected. Verified live: `Sales Invoice Item` for `ACC-SINV-2026-01013` had `item_tax_template: null`, while the ORIGINAL invoice's identical item (`ACC-SINV-2026-01011`, built through the normal booking path) correctly carried `"Mexico Tax - N"`.

   This is the same defect *class* found and fixed the same day in `_build_pos_invoice_doc` (ADR-071) — a different function, in the same file, with the same missing step — but it required a distinct fix here: setting `item_tax_template` alone was not sufficient (confirmed by testing it in isolation — it produced `total_taxes_and_charges: 0.0`). Core's `append_taxes_from_item_tax_template` (the step that actually creates the header tax row) reads `row.item_tax_rate`, a separate JSON `{account_head: rate}` field that only `get_item_details()`/`get_item_tax_map()` populates — `item_tax_template` being set is not enough on its own. `_build_pos_invoice_doc` worked around this by coincidence of call order (its `set_missing_values()` runs after the template is set); `_create_reschedule_delta_invoice` did not have that luck, and needed both fields set explicitly.

2. **The Patient Chart could only ever show the ORIGINAL invoice for an appointment.** The appointment card's "See Invoice" button reads `appt.billing.invoice` — a single field, always the appointment's `ref_sales_invoice`. Every reschedule/reassign delta invoice is deliberately *not* linked via that field (linking it would trip Healthcare's "already invoiced" guard on submit — a pre-existing, correct design choice). The two delta invoices for Diego's reassignments were consequently invisible anywhere in the Patient Chart, only reachable via the clinic-wide Revenue/Billing hub.

   Investigating this found the fix was already 90% built: `api/v1/appointments/api.py::_billing_for` (called by `_fmt`, which every appointment list/get response goes through) already computes and returns `billing.invoices` — the FULL array of every invoice billing that appointment, original plus every delta, each with its own total/paid/outstanding, batched for a whole page with no extra queries (`_billing_context`). The type `AppointmentBillingInvoice[]` already existed in the frontend (`types/appointments.ts`), with a doc comment stating exactly this. The gap was purely that no component ever rendered it — `appointments-tab.tsx`'s `AppointmentRow` read only `billing.invoice` (singular) and never `billing.invoices` (plural).

   An earlier version of this fix (built before this was discovered) added a brand-new whitelisted endpoint, hook, and per-row query mirroring an *existing but unused* `get_reschedule_history` method — unnecessary duplication of data the appointment list already returns, and it would have introduced an N+1 query per row in a list view. Reverted in favour of reading the field that was already there.

## Decision

1. **`_create_reschedule_delta_invoice`** (`services/billing.py`) now resolves the item's default tax template via the existing `_item_tax_template_map` helper and sets BOTH `row.item_tax_template` and `row.item_tax_rate` (via `erpnext.stock.get_item_details.get_item_tax_map`) explicitly, before save — mirroring, and now made robust beyond, ADR-071's fix in the same file.
2. **`appointments-tab.tsx`**'s `AppointmentRow` now reads `appt.billing.invoices` (already computed, already batched, already shipped) and shows every invoice OTHER than the original as a small, collapsed "reassignment trail" disclosure inside the existing Actions cell — each one independently clickable into the same `InvoicePreviewSheet` already used for the primary invoice. `onInvoice` gained an optional `invoiceOverride` parameter so a trail entry can open ITS invoice specifically instead of always opening `billing.invoice`.
3. **No retroactive correction.** The 182.07 MXN Diego was undercharged on `ACC-SINV-2026-01013` is left as-is — explicit decision, matching how ADR-071's tax bug was handled the same day: fix the code path going forward, do not recompute or adjust historical invoices as a side effect of a bug fix.
4. **Anant Sharma's practitioner record** (misconfigured `op_consulting_charge_item`, pointing at a nebulizer-administration item instead of a consultation-fee item — found during the same investigation) is explicitly OUT of scope for this ADR. Flagged separately; not touched.

## Alternatives Considered (item 2 — invoice-trail visibility)

1. **New endpoint + per-row hook wrapping the existing but unused `get_reschedule_history` method (tried first, reverted).**
   - Pros: `get_reschedule_history`'s response shape is arguably richer (old/new practitioner names, dates, adjustment type/status) than the plain invoice-total array `billing.invoices` carries.
   - Cons: duplicates data the appointment list endpoint already returns; introduces one extra network request PER appointment row in a list (N+1) where the existing field requires zero extra requests; builds a second path to the same information, which the constitution's "one fact, one owner" principle argues against maintaining.

2. **Render `billing.invoices` directly (chosen).**
   - Pros: zero backend change, zero new requests, uses data that's already correct and already batched; the type was already defined for exactly this purpose and simply never consumed.
   - Cons: shows less narrative detail per entry (just the invoice's own total/paid/outstanding, not "why" the reassignment happened) — judged an acceptable trade since the invoice itself, once opened, shows the full line-item detail, and `get_reschedule_history` remains available (unused, not removed) for a future screen that specifically wants the reassignment narrative rather than just the invoice list.

3. **Fold delta invoices into the original via a header-level "additional charge" line, so there's only ever one invoice per appointment.**
   - Pros: would make "one invoice per appointment" true again, simplifying every downstream consumer.
   - Cons: rejected on the same grounds `_create_reschedule_delta_invoice`'s own docstring already gives — Healthcare's `on_submit` hook re-validates and throws "already invoiced" the moment a second reference tries to touch an appointment that's already invoiced against its original. Not a reversible, low-risk change; a much larger restructuring than this bug warrants.

4. **Do nothing in the Patient Chart; direct staff to the Revenue/Billing hub for the full picture.**
   - Pros: zero engineering effort.
   - Cons: does not answer what was asked, twice, in the same message ("we have to show all not single").

## Why this approach, specifically

- **Vs. 1 (new endpoint):** loses on being redundant, slower (N+1), and a second source of truth for the same fact — not a close call once the existing field was found.
- **Vs. 3 (fold into one invoice):** loses on being a much larger, riskier change to solve a display problem, when the actual clinical/accounting reason for separate invoices (avoiding "already invoiced" re-validation) is sound and unrelated to what was asked.
- **Vs. 4 (do nothing):** loses because it doesn't do what was asked.

## Consequences

- `remedisys_healthcare_ai/services/billing.py`: `_create_reschedule_delta_invoice` now sets `item_tax_template`/`item_tax_rate` — every FUTURE reschedule/reassign fee-increase delta invoice will correctly include tax. Invoices created before this fix (including Diego's `ACC-SINV-2026-01013`) are unaffected.
- `EB_Healthcare_Frontend/src/components/narzim/patient-chart/appointments-tab.tsx`: reassignment-trail disclosure added; `onInvoice` prop signature extended (backward compatible — the override parameter is optional).
- `EB_Healthcare_Frontend/messages/en.json`, `messages/es.json`: new `chart.appointments.moreInvoices` key.
- **No backend change was needed for item 2** — `_billing_for`/`_billing_context` (`api/v1/appointments/api.py`) were already correct and unchanged by this ADR.
- **Re-evaluation trigger:** if a third code path is ever found building a Sales Invoice row directly (bypassing `set_healthcare_services`) without setting both `item_tax_template` and `item_tax_rate`, that is very likely the same defect a third time — check first for exactly this pattern before treating it as new.

## Verification

- Live, read-only, against Diego Gómez Reyes' real appointment/invoice/payment records (not test/scratch data) — confirmed the exact 182.07 MXN shortfall, confirmed the root cause field-by-field (`item_tax_template: null` on the buggy invoice vs. `"Mexico Tax - N"` on the correctly-taxed original), confirmed `Anant Sharma`'s practitioner record's misconfigured item as a SEPARATE, unrelated finding.
- The tax fix was verified via the same "build the identical doc, call `.validate()`, never `.insert()`/`.save()`/`.submit()`" technique established in ADR-071 — first confirmed the ORIGINAL bug reproduces exactly (`total_taxes_and_charges: 0.0`, matching the live undercharge), then confirmed the fix produces the correct `grand_total: 1320.0` with a real `IVA - N` tax row of `182.07` — the exact amount Diego was actually shorted.
- The invoice-trail field (`billing.invoices`) was confirmed live, directly, by calling the real `list_appointments` function against Diego's patient: it already returns all 3 invoices (580 / 420 / 1137.93) correctly, batched, with zero code changes needed on the backend.
- Frontend: `tsc --noEmit` clean (same one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts`); `npm run i18n:check` clean.
- No data was created, modified, or persisted during this investigation — every verification call either read existing records or built a throwaway, never-saved document.

## References

- ADR-071 (the same-day, same-file, same defect *class* found in a different function — `_build_pos_invoice_doc`)
- Constitution §4 Rule 1 (no core modification — the fix lives entirely in `_create_reschedule_delta_invoice`, app-owned code; `erpnext.stock.get_item_details.get_item_tax_map` is called, not patched), §10 (four-approaches requirement for a financially consequential + a consequential-but-reversible UI change), §9 (ADR requirement)
- `docs/RESCHEDULE_DELTA_INVOICE_FIX.md` (companion mechanism doc)
- `WORK_LOG.md` 2026-09-16 entry

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
