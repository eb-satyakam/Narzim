# ADR-046: Store notification event keys with parameters, and give each delivery channel a distinct job

**Doc status:** living · **Created:** 2026-08-26 by Ashutosh (AI-assisted) · **Updated:** 2026-08-26 by Ashutosh (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-08-26
- **Supersedes:** —
- **Superseded by:** —

## Context

[`adr-045-push-notifications-fcm-and-sse.md`](adr-045-push-notifications-fcm-and-sse.md) established
*how* a notification is delivered — one `notify()` chokepoint, SSE while an app is open, FCM when it is
closed. It did not say anything about **what the message says**, because at the time every message was
a fixed sentence with no variable content.

Appointment notifications broke both of those assumptions at once, and surfaced a defect in what
`adr-045` had already shipped.

**1. The text is not translated, despite looking like it is.** Every string goes through `_()`, but
`locale/es.po` contains none of them — verified for `"New message from your clinic"`,
`"sent a message"` and `"sent a WhatsApp message"`. They render in English on an `es-MX` site.

**2. `_()` resolves in the writer's language, not the reader's.** The subject and body are rendered on
the server, inside the session of whoever triggered the event. A receptionist working in English
produces an English notification for a Spanish-speaking patient. Invisible today — all 45 users are
`language: en` — and wrong for a product whose default `ComplianceProfile` is `mx`
([`adr-018-multi-jurisdiction-compliance.md`](adr-018-multi-jurisdiction-compliance.md)).

**3. Variable content makes both of the above visible.** *"New message from your clinic"* being in the
wrong language is a wart. *"Moved to 2026-09-08 at 16:45"* is a different matter: a parent needs
`martes 8 de septiembre a las 16:45`, formatted to their conventions, or they turn up on the wrong day.
`appointment_time` is also a `timedelta`, and the site timezone is `Asia/Kolkata`, so naive
interpolation produces both the wrong language and the wrong time.

**4. Three channels now fire for one event.** Research found that core Frappe `Notification` rows were
**already enabled and emailing patients** on booking and cancellation, plus 1-day and 1-hour reminders
(`docs/RESEARCH_APPOINTMENT_NOTIFICATIONS.md` §2.2). Adding the bell and push means an email, a bell
entry and a phone buzz for a single booking. The concern that three identical notifications train
people to ignore all three was raised and **the decision was to keep all three** — so they need
differentiating rather than reducing.

## Decision

**1. A notification stores a stable event key plus parameters, and the client renders it.**

`notify()` writes `remedisys_event` (e.g. `appointment_rescheduled`) and `remedisys_params` (JSON:
dates, practitioner name, department) as custom fields on `Notification Log` — added via the
`Custom Field` fixture, which is one of the integration points Rule 1 explicitly permits.

**2. The server-rendered `subject`/`description` stay, as a fallback.** They are not removed. A client
that does not know a key, a row written before this existed, and the Frappe Desk itself all continue to
show something sensible. Adding parameters to an event is therefore additive and never breaks an older
client.

**3. A push payload's title is rendered on the server, in the recipient's language.** A push has no
client to render it — the string in the payload *is* what the OS displays. `services/push.py`
provides a `recipient_language()` context manager that resolves `User.language` around
`build_payload`. The payload stays content-free per `adr-045` decision 5; only its generic title is
translated.

**4. Each delivery channel has a distinct job, and must not duplicate the others.**

| Channel | Job | Content |
|---|---|---|
| **Push** | the interrupt — "something changed, look" | Generic line only. No date, no practitioner, no clinic name: it renders on a lock screen |
| **Bell** (`Notification Log`) | the record — persists, has read state, deep-links | Full detail, rendered by the client in its own language |
| **Email** (core `Notification`) | the receipt — searchable, forwardable, survives losing the app | Fullest. Left exactly as it is |

This is what makes three channels for one event acceptable rather than spam. It is also why the
content-free push is a feature here, not a limitation.

**5. Existing channels are not touched.** The core `Notification` emails and the
`Remedisys WhatsApp Notification` configs keep working as they are. Notably the two email reminders
(1 day / 1 hour before) are the only scheduled notifications the system has — `notify()` cannot
schedule at all — so they are load-bearing, not redundant.

## Alternatives Considered

1. **Keep rendering on the server, and fix it by resolving the recipient's language there.**
   - Pros: no client change; one code path; works for email and push identically.
   - Cons: needs a `frappe.local.lang` swap per recipient inside the fan-out, so a five-recipient
     notification renders five times; date/number formatting still follows server conventions rather
     than the device's; and a native mobile app cannot re-render when the user changes phone language.

2. **Put both languages in one string,** as the existing core email notifications already do —
   `"Cita agendada / Appointment booked"`.
   - Pros: zero infrastructure, proven in this codebase, and honest about being bilingual.
   - Cons: does not scale past two languages, and reads badly in a native notification tray where
     space is tight — which is precisely where the patient app is heading. Also cannot format a date
     two ways in one string.

3. **Event key + parameters, rendered by the client (chosen).**
   - Pros: correct by construction — the reader's device renders in the reader's language and
     conventions; the portal and the future React Native app already have `next-intl` catalogues;
     changing a phone's language changes existing notifications; adding a language is a catalogue file,
     not a migration.
   - Cons: two representations of the same message to keep in step (the key/params and the fallback
     string); a client must know the key or it falls back; and a push still needs a server-side render,
     so this does not eliminate that path — decision 3 exists because of this.

4. **A translation table doctype**, resolving message templates per language at write time.
   - Pros: clinic-editable wording without a deploy; one place to see every message.
   - Cons: a whole doctype, an editor UI and a caching story for a problem two JSON catalogues already
     solve; and it still renders server-side, inheriting alternative 1's date-formatting problem.

Alternative 3 wins because the mobile app is the deciding factor: it is the one option where a
notification is rendered by the device that displays it. Alternative 1 loses on formatting and on
mobile re-rendering; alternative 2 loses at the third language and in a notification tray;
alternative 4 buys editability nobody has asked for at the cost of a doctype.

## Consequences

- `notify()` gains an optional `params` argument. Existing callers are untouched — five call sites
  continue to work with no change, and their rows simply carry an empty `params`.
- Two custom fields on `Notification Log` (`remedisys_event`, `remedisys_params`), shipped in
  `fixtures/custom_field.json`. Rule 1 compliant; no core file is modified.
- `api/v1/patient_portal/notifications.py` returns `event` and `params` alongside the existing fields,
  and its `_PATIENT_VISIBLE_DOCTYPES` allow-list gains `Patient Appointment`.
- **Every new notification event should now ship parameters**, not a pre-rendered sentence. A
  pre-rendered sentence is not a bug, but it cannot be translated after the fact.
- **Adding an event means adding its catalogue key in the same change.** The fallback covers a missing
  key gracefully, but only because the client checks for it explicitly — and that check must interrogate
  the catalogue (`useMessages()`), never rely on the translator throwing. `next-intl` does not throw on
  a missing message; it returns the key path as the string. Two guards built on the opposite assumption
  shipped inert and rendered `notifications.<key>` at users. See `../PUSH_NOTIFICATIONS.md` §4.7.
- `locale/es.po` is missing the existing strings. Client-side rendering makes that catalogue irrelevant
  for anything migrated to keys, but the fallback text still comes from it — so it is now a
  *degradation* path rather than the primary one.
- Three channels per event is the accepted design. If notification fatigue does appear, the fix is
  per-channel opt-out (Frappe's `Notification Settings` already offers per-type email control, and push
  has the browser permission) — not removing a channel.

**Re-evaluation triggers**

- A third language is added, or a locale needs different date conventions from the site's: confirms
  this decision; nothing to revisit.
- Clinic staff ask to edit notification wording themselves: revisit alternative 4.
- Notification fatigue is reported: build per-channel opt-out before removing a channel.

## Verification

1. `Notification Log` has `remedisys_event` and `remedisys_params` after migrate.
2. A rescheduled appointment produces a row whose `remedisys_event` is `appointment_rescheduled` and
   whose `remedisys_params` carries `date`, `time`, `datetime`, `practitioner`, `department`.
3. `subject`/`description` are still populated on that row — the fallback is present, not replaced.
4. A row written before this ADR returns `event: ""` and `params: {}` from the patient API without
   error, proving graceful degradation.
5. `services/push.py::recipient_language` is used by `send_to_user`, and the payload still contains no
   patient-identifying string (the existing payload-contract test).

## References

- [`adr-045-push-notifications-fcm-and-sse.md`](adr-045-push-notifications-fcm-and-sse.md) — delivery
- [`adr-018-multi-jurisdiction-compliance.md`](adr-018-multi-jurisdiction-compliance.md) — the two active locales
- [`../RESEARCH_APPOINTMENT_NOTIFICATIONS.md`](../RESEARCH_APPOINTMENT_NOTIFICATIONS.md) — the research this came from
- [`../PUSH_NOTIFICATIONS.md`](../PUSH_NOTIFICATIONS.md) — the mechanism
- `CLAUDE.md` §4 Rule 1 (custom fields as a permitted integration point), Rule 10, §13 rule 10 (no hardcoded user-visible strings)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-26 | Ashutosh (AI-assisted) | Consequences: a new event must ship its catalogue key, and key existence must be checked against the catalogue rather than by catching a throw next-intl never makes |
| 1.0 | 2026-08-26 | Ashutosh (AI-assisted) | Initial version |
