# ADR-102: Invoice list totals computed server-side, independent of page size

**Doc status:** living · **Created:** 2026-09-29 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.3

- **Status:** Accepted
- **Date:** 2026-09-29
- **Supersedes:** —
- **Superseded by:** —

## Context

The Billing screen's Invoices tab showed a different "outstanding" total in its own summary text
(6,540 MXN) than the header KPI chip fed by adr-099's clinic-wide aggregate (7,340 MXN), verified
live at the same instant so it was not a timing artifact. Root cause: `list_all_invoices` is always
called with a fixed `page_size: 100`; the frontend fetches once and does all further paging, sorting
and summation client-side. This site has grown to 240 submitted invoices, so the 140 beyond the
newest 100 are invisible to the summary text, the "All N" count, and to paging through the table —
only server-side search still reaches them. Detail: `docs/architecture/INVOICE_LIST_PAGINATION_TOTALS.md`.

## Decision

Add `billed_total`/`outstanding_total` to `list_all_invoices`'s response — real aggregates computed
server-side over every invoice matching the request's filters, not the fetched page.
`set_list_response` gains an optional `extra` parameter to carry the two new fields without changing
its existing shape for the 48 other call sites.

**Scope correction made before writing code:** the original draft of this ADR also raised the
frontend's fetch `page_size` from 100 to 1000. Dropped — `page_size = min(100, ...)` turned out to be
a hard cap repeated verbatim across roughly twenty list endpoints in this app (`clinical_notes`,
`company`, `labs`, `immunizations`, `prescriptions`, `vital_signs`, `tasks`, and billing's own other
three list methods), not something specific to invoices. Overriding it for one endpoint would be a
real, unreviewed inconsistency with every other list in the app, not a small fix, and is out of scope
here. Consequence: this ADR fixes the two money totals completely (they're now exact regardless of
page size), but does **not** fix the separate, still-open problem that invoices beyond the newest 100
are unreachable by paging through the table, the "All N" count, or the practitioner/payment-method/
due-date-range filters.

## Alternatives Considered

1. **Do nothing / raise the frontend fetch cap only, no backend change.**
   - Pros: zero backend risk.
   - Cons: still silently wrong the moment the true dataset exceeds whatever cap is chosen — exactly
     the bug that was just found, just with a higher threshold. The two money figures would stay
     approximate rather than exact, on a billing screen.
2. **True server-side pagination for the whole table** (page/page_size sent on every page turn,
   matching how the Patients screen already works).
   - Pros: the textbook-correct fix; scales indefinitely; consistent with the rest of the app.
   - Cons: three of this table's filters — practitioner, payment method, due-date range — are
     currently client-side only, with no backend parameter for any of them. Paginating server-side
     while leaving those three client-side would make them return near-empty results most of the
     time (a 20-row page rarely contains many rows matching one practitioner) — trading today's bug
     for a worse one. Doing this correctly requires extending the backend with all three filters
     first, a materially larger change. Rejected **for this task**, recorded as a real follow-up
     (not silently dropped) rather than attempted half-done.
3. **Compute the aggregates client-side from a second, unpaginated fetch** (e.g. `page_size=0` /
   "all matching rows, fields-only, no pagination").
   - Pros: no backend response-shape change.
   - Cons: still bounded by whatever the backend would return for "all" — Frappe's `get_list` needs
     an explicit `limit_page_length` either way — and doubles the request count (one for the page,
     one for the totals) for no benefit over asking the backend to sum once. `_build_invoice_filters`
     already exists specifically so the same filter logic isn't duplicated a second time; a second
     unpaginated client fetch would still need to reapply it.
4. **Server-side aggregate fields only, page-size cap left untouched (chosen).**
   - Pros: the two money figures become exact regardless of fetch completeness, closing the specific
     bug reported (7,340 vs 6,540); no change to the three client-side filters or to the shared
     `page_size` cap, so zero regression risk and full consistency with every other list endpoint;
     small, additive, same risk class as this session's other backend additions (adr-099/097/098).
   - Cons: does not fix row-visibility — the "All N" count, full-table paging, and the three
     client-side filters still only ever see the newest 100 invoices. Documented as an open,
     separate problem, not silently left unmentioned.

## Consequences

- `api/v1/billing/api.py::list_all_invoices` gains two response fields; `utils.py::set_list_response`
  gains one optional, backward-compatible parameter.
- `billing-client.tsx`'s `billedInView`/`outstandingInView` read the new fields instead of summing
  client-side. `page_size` is unchanged.
- Re-evaluation trigger: a decision to build the three missing backend filters (practitioner,
  payment method, due-date range) and do true server-side pagination (item 2) — the correct long-term
  direction, and the only way to also fix row-visibility, not just the two totals.

## Verification

- Live on `remedisis.localhost`: `billed_total`/`outstanding_total` cross-checked against direct SQL
  for the same filter set.
- **A second bug found by this same verification, fixed before merge:** the frontend's clinic-wide
  list always requests `include_returns=true` (so credit notes can appear under the Refunded filter),
  but the original client-side sum this ADR replaces explicitly excluded returns
  (`invFiltered.filter(i => !i.isReturn)`). The first aggregate implementation didn't — it summed
  whatever `filters`/`or_filters` produced, returns included. Measured live: 6,340 including returns
  vs the correct 7,340 excluding them. Fixed by forcing `is_return: 0` on the aggregate query
  specifically, independent of `include_returns` on the row query. Re-verified: `include_returns=True`
  request now returns `outstanding_total: 7340.0`, matching direct SQL with `is_return=0` exactly.
- **A third bug, found only by checking the actual browser code path, not just the backend:** the
  Next.js BFF route (`src/app/api/billing/route.ts`) and the shared `frappeFetchList` helper it calls
  both destructured only `{ data, pagination }` from the Frappe response — silently dropping the two
  new fields before they ever reached the browser, even though the backend itself was already correct
  and verified. `frappeFetchList` gained an optional `Extra` generic (backward compatible, ~4 other
  callers unaffected) and the billing route now requests and forwards the two fields.

## References

- `docs/architecture/INVOICE_LIST_PAGINATION_TOTALS.md`
- `adr-099-dashboard-revenue-kpis-clinic-wide.md` — the aggregate this bug was found by comparing against
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md` (Round 30)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Two real bugs found by re-verifying after the user reported the figures still disagreed: the aggregate summed returns it should have excluded; the Next.js BFF route silently dropped the new fields before they reached the browser. Both fixed and re-verified |
| 1.1 | 2026-09-29 | Divyanshu (AI-assisted) | Before implementation: dropped the page_size raise (repo-wide cap, not billing-specific); scope narrowed to the two aggregate fields |
| 1.0 | 2026-09-29 | Divyanshu (AI-assisted) | Initial version |
