# ADR-098: Billing screen restyle is scoped to the presentation layer only

**Doc status:** living · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-29 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** —
- **Superseded by:** —

## Context

The frontend repo (`EB_Healthcare_Frontend`) has a Claude Design project, **"Narzim EHR"**
(`https://claude.ai/design/p/e5b92eb1-ae6c-4761-b326-1f6c3d74c417`, owned by Gaurav Gautam), holding
visual mocks for every clinical screen, including `Billing.dc.html`. The request was to bring the
live Billing screen (`src/app/(clinic)/billing/billing-client.tsx` in the frontend repo) into visual
alignment with that mock.

`billing-client.tsx` is not a stub: it is a ~2,000-line, production screen wired to real invoice and
payment data (`useInvoices`, `usePayments`, `useCollectPayment`), carrying multiple previously-fixed
edge cases documented inline — waiver-mode (Government scheme) write-offs that are always full not
partial, split-tender payment matching across a joined `"Cash + Wire Transfer"` string, a documented
gap between the posting-date filter and the KPI window (204 rows vs. a card reading 41), and
partial-vs-full refund inference by summing every credit note against an original invoice. None of
this is covered by an automated test — confirmed by reading the repo; `e2e/` and `tests/billing/`
(backend) do not exercise it.

The frontend constitution (`EB_Healthcare_Frontend/CLAUDE.md`) makes several of these load-bearing:
**FE-14** ("preserve existing functionality and user flows... without explicit permission"), **FE-12**
(never delete or replace suspected-unneeded code without explicit approval), **FE-1/FE-4/FE-6**
(no fabricated clinical/financial values, no silently swallowed errors, never drop data to make a
request succeed). The backend constitution's §10 worked example — a prescription's dosing interval
silently dropped during a rewrite of a similarly dense form — is the precise failure mode this decision
guards against.

## Decision

Restyle the Billing screen using a **component-level, presentation-only swap**: the screen's state,
data-fetching, filtering, sorting, and all financial/business logic (refunds, waivers, split payments)
remain byte-for-byte unchanged. Only the rendering layer — buttons, badges, cards, table chrome — is
replaced, using this repo's own `src/design-system` component set (shadcn/ui, already exported via
`src/design-system/index.ts`) styled to match the mock's visual language (color tokens, spacing,
typography), not by importing files from the Claude Design project directly (that project's
`components/*.jsx` are Claude Design's own generated implementation, not published for consumption by
this repo).

Work proceeds in five reviewable batches (KPI header + toolbar; table shell; action buttons + dialogs;
insurance tab; remaining sub-components), each verified against current behavior before the next
starts. Full plan: `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`.

## Alternatives Considered

1. **Full rewrite from the mock.** Discard the current JSX/styling and rebuild against the mock's
   structure, re-porting business logic into the new shape.
   - Pros: cleanest, most direct path to visual parity with the mock.
   - Cons: highest risk of silently dropping one of the undocumented-by-tests edge cases (the waiver
     branch, the split-payment matcher, the refund-summation logic) during the port — exactly the
     failure class FE-1/FE-4/FE-6/FE-14 exist to prevent, on a screen with no test suite to catch it.

2. **Component-level swap, presentation only (chosen).** See Decision.
   - Pros: zero risk to business logic (it is never touched); reviewable in small batches; each batch
     independently verifiable against current behavior.
   - Cons: will not reach 100% pixel-parity with the mock on custom-behavior pieces (the
     `indeterminate` checkbox, click-to-sort headers) without bespoke adaptation rather than a
     drop-in component replacement.

3. **Tokens-only pass.** Adopt the mock's color/spacing/type tokens globally via Tailwind config;
   leave all component markup as-is.
   - Pros: lowest risk, fastest, touches no component logic or structure at all.
   - Cons: does not deliver what was actually requested — recolors the existing screen without
     adopting the mock's layout or component treatment.

4. **New screen behind a flag.** Build the mock as a new route, run it in parallel, cut over after
   verification.
   - Pros: zero risk to the production screen during the build; enables direct side-by-side comparison.
   - Cons: doubles the maintenance surface until cutover — every business-logic fix (e.g. a future
     waiver-mode change) would need to land in both screens; large scope for a first pass on one
     screen.

## Consequences

- `EB_Healthcare_Frontend/src/app/(clinic)/billing/billing-client.tsx` and its supporting components
  (`src/components/billing/*`, `src/components/narzim/billing/*`) will be edited across the five
  batches named above. No backend file, API, or schema changes.
- No new dependency (the component set already exists in `src/design-system`).
- Re-evaluation trigger: if a batch cannot be completed without touching business logic (e.g. a
  component's behavior is genuinely inseparable from its markup), stop and raise it rather than
  silently expanding scope — per frontend `CLAUDE.md` §4.5 ("explain before a major change").
- This ADR's approach (component-level swap over full rewrite) is the template intended for the same
  restyle exercise on Appointments, Patients and Encounters, once Billing is verified.

## Verification

- `pnpm build` and typecheck pass after each batch.
- Manual behavioral comparison against the current screen for: waiver-mode Collect flow, split-tender
  filtering, refund/credit-note chain display, the posting-date-vs-KPI-window banner.
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md` updated with the actual
  before/after mapping as each batch lands.

## References

- `EB_Healthcare_Frontend/CLAUDE.md` FE-1, FE-4, FE-6, FE-12, FE-14
- `remedisys_healthcare_ai/CLAUDE.md` §10 (four-approaches hard rule; the worked WHAT/WHY/HOW/WHEN
  example this ADR's Context section follows)
- `EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`
- Claude Design project "Narzim EHR": `https://claude.ai/design/p/e5b92eb1-ae6c-4761-b326-1f6c3d74c417`,
  file `Billing.dc.html`

## Amendment — scope expanded, 2026-09-28

Recorded rather than silently absorbed. Two decisions went beyond the presentation-only rule above,
each approved by the user in session after a written comparison:

1. **A Checkout tab was added** (the mock's `Checkout` tab), backed only by existing endpoints —
   `get_dashboard_data` → `checkout` for the queue, `get_patient_total_pending` for amounts, the
   existing invoice sheet and Record Payment dialog to take money. No endpoint added or changed; the
   user set "no new or updated API" as a hard constraint for the whole restyle.
2. **The dashboard was edited** to move its "Pay now" branch into a shared
   `src/components/billing/queue-row-collect.tsx`, so the dashboard and the Billing Checkout tab run
   one copy of a payment branch that has already needed two live fixes. Moved verbatim, verified
   identical to `HEAD` by script. Alternatives rejected: copying it (two copies of money logic that
   already drifted once), the simpler `appointment` prescope alone (reintroduces the
   HLC-APP-2026-00714 empty-sheet bug), linking to the dashboard (not a Checkout tab).

Correction also recorded: the Context section above implies the live screen had an Insurance tab.
It did not — `InsuranceTab` is never rendered (the screen had no tab bar). Full record:
`EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-29 | Divyanshu (AI-assisted) | Renumbered billing ADRs 095-099 -> 098-102 on moving this work onto `dev` (dev had merged Encounter Canvas ADRs 095-097; ADR-042: the unmerged side moves) |
| 1.1 | 2026-09-28 | Divyanshu (AI-assisted) | Amendment: approved scope expansion (Checkout tab; shared QueueRowCollect extracted from the dashboard); Insurance-tab correction |
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
