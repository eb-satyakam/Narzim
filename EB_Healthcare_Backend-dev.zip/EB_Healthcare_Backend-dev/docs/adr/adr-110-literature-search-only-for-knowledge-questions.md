# ADR-110: With a chart linked, the literature is searched only for a knowledge question

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

Clinical Web is a switch in the composer that the clinician leaves on. While it was on, every turn
searched PubMed with the question as its query and the reply cited whatever came back. On
2026-09-30 the owner reported five papers attached to "summarize entire transcript" and to "what
was discussed with the patient". Those are questions about the record; the literature has nothing
to add, and the citations only said that something had been fetched.

A second complaint from the same session: the follow-up questions under a reply appeared only after
a broad request, because the prompt forbade them after a narrow one.

## Decision

1. `services/narzim_literature_gate.py::should_search_literature(question, patient_linked)` decides
   before any request leaves the site. With no chart linked, the switch means search. With a chart
   linked, the literature is searched only when the question asks for knowledge beyond the record
   (a guideline, evidence, a dose, a treatment, a comparison, a risk) and is not about the record
   itself (a summary, the transcript, what was discussed, vitals, medicines, allergies, labs, the
   last visit). A rule, not a model call.
2. Every answer ends with up to three follow-up questions the assistant can answer, except a
   refusal. Prompts `narzim-assistant-context-v5/v6` are amended in place (they are unreleased on
   this branch); the general prompts get new versions `narzim-assistant-v5/v6`.

## Alternatives Considered

1. **Ask the model whether to search.** Pros: handles any wording. Cons: a paid call before every
   turn, and a decision that cannot be read afterwards.
2. **A word rule in code (chosen).** Pros: free, immediate, testable, readable. Cons: a list to
   maintain in two languages; a new phrasing may be misjudged.
3. **Search, and let the model decide whether to cite.** Pros: no change. Cons: this is today's
   behaviour, and the model cites what it is given.
4. **Turn the switch off after each turn.** Pros: no rule. Cons: the clinician who wants literature
   for the next question has to turn it on again, every time.

## Consequences

- A question about the record with Clinical Web on is answered from the record, cites nothing and
  contacts NCBI not at all.
- A wrong judgement fails safe in one direction: a knowledge question misread as a record question
  is answered from general knowledge without citations. The clinician can rephrase.
- Follow-up questions become part of every reply's shape, and the frontend turns them into buttons.

## Verification

- `tests/ai/test_narzim_literature_gate.py`: record questions in English and Spanish are not
  searched; knowledge questions are; no chart means search.
- Live on `marley.local`, 2026-09-30: "summarize entire transcript" with Clinical Web on and a visit
  linked returned no citations; an otitis question with no chart returned five and a follow-up
  list; both replies ended with follow-up questions.

## References

- adr-108 (prompt rules for a linked chart), ADR-075, `CLAUDE.md` PHI-6, BE-5

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | Renumbered from adr-108 on merge with `dev`, which had already taken that number (ADR-042). No other change |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
