# ADR-002 — All EB_ Roles Are Website User / No Desk Access

**Doc status:** living · **Created:** 2026-06-11 by Invincible · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
## Context

Frappe has two user types: `System User` (can log into Frappe Desk) and `Website User` (cannot). ERPNext Healthcare admin roles traditionally carry desk access, giving clinic managers full ERPNext Desk visibility. We want the Next.js frontend to be the **only** interface for all clinic roles.

## Decision

All six `EB_` roles have `desk_access: 0` and `user_type: Website User`:

- `EB_Healthcare Admin`, `EB_Practitioner`, `EB_Front Desk`, `EB_Clinic Staff`, `EB_Nurse`, `EB_Patient`

Only two accounts retain System User status: `Administrator` and `groupmonks@gmail.com` (developer/superadmin).

## Consequences

- Clinic staff — including the healthcare admin — cannot access Frappe Desk at all.
- All clinic operations must be built into the Next.js app; there is no Frappe Desk fallback.
- The Next.js BFF proxies all data via `eb_frappe_jwt`; browsers never hold a Frappe session cookie.
- `setup_roles.py` and `assign_patient_role.py` enforce this at user creation time.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Status block normalised to `- **Status:**`, the shape the rest of the set uses, so the ADR tooling can read it. No decision changed |
| 1.0 | 2026-06-11 | Sarvesh | Initial version (header backfilled from git history) |
