# ADR-018: Practitioner appointment visibility and coverage reassignment

**Doc status:** living · **Created:** 2026-06-30 by Invincible · **Updated:** 2026-06-30 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-30
- **Supersedes:** Refines the implicit row-level model introduced by commits `39f7728` (nurse encounter lockdown), `47ef06a` (nurse handoff perm), `fd4dabb` (start_encounter whitelist). No prior ADR superseded.
- **Superseded by:** —

## Context

Live investigation of the "start encounter" flow surfaced a coherent but broken
permission model:

- Each practitioner user carries a **User Permission** `Healthcare Practitioner = <self>`
  (verified: `lourdes@narzim.com` → `Lourdes Ritto Mijangos`). This restricts
  **row-level writes**: a doctor can create/open an encounter for their own
  appointments but **not** for another practitioner's.
- The **appointment list / queue read** is **not** scoped. The queue shows a
  doctor *every* provider's appointments, lets them click "Start Encounter", and
  then the insert fails with `frappe.PermissionError` → HTTP **403**, surfaced to
  the user as the unhelpful `"An error occurred."`
- Reproduced as Dr. Lourdes: starting **her own** Checked-In/Open appointment →
  `201 OK`; starting **another doctor's** appointment → `403`.
- `start_encounter(appointment)` copies `practitioner` from the appointment and
  does **not** adopt the caller, whereas its sibling `create_encounter` **does**
  adopt the logged-in practitioner. The two endpoints are inconsistent.

Reads-unscoped + writes-scoped is the worst combination: the UI advertises an
action it then forbids.

**Native ERPNext Healthcare baseline** (verified against the upstream `healthcare`
app, for alignment):
- Native `make_encounter` copies `practitioner` directly from the appointment
  (a rigid `get_mapped_doc` field map) — there is **no** "logged-in user becomes
  the practitioner" concept. The **appointment is the single source of truth** for
  who owns the visit.
- Native has **no practitioner-level access control**: there are no
  `permission_query_conditions` on Patient Appointment or Patient Encounter, so
  every Physician sees and edits every appointment/encounter. Visibility is purely
  role-based — i.e. "everyone in the clinic sees everything" is the native default.
- Native does **not** validate that the submitting user matches the encounter's
  practitioner.
- Native appointment status options are exactly: `Scheduled, Open, Confirmed,
  Checked In, Checked Out, Closed, Cancelled, No Show`. `"Ready for Provider"` is
  **not** a native status — it is a frontend-only label.
- Our app already deviates from native in `create_encounter` (it overrides the
  practitioner to the caller for `EB_Practitioner`) and in `complete_encounter`
  (only the assigned practitioner may submit), justified by Rule 6. `start_encounter`
  does **not** do this — so the two creation endpoints are inconsistent today.

Constraints shaping the decision:
- **Constitution §3** — jurisdiction is Mexico (LFPDPPP + NOM-024-SSA3-2010);
  data-minimization applies, but the meaningful boundary for a single clinic is
  the *clinic*, not the individual provider. API pattern is custom whitelisted
  methods only.
- **Constitution §4 Rule 1** — no core modification; scoping/permissions via our
  service layer and fixtures/patches, not core edits.
- **Constitution §9** — architectural/permission decisions require an ADR.
- Product target is **small pediatric clinics** where providers cover for each
  other constantly; a hard per-provider wall breaks daily operations.

Two related frontend defects were found in the same flow and are tracked
separately (not decided here): the `/queue` "Start Encounter" button is
toast-only (never calls the API), and no appointment ever reaches the
`"Ready for Provider"` status the queue gates that button on.

## Decision

Adopt **role-aware, clinic-configurable appointment visibility** with an explicit
**front-desk coverage reassignment** path. Keep the **appointment as the single
source of truth** for who owns the visit (native ERPNext Healthcare model) — the
encounter inherits the appointment's practitioner; we do **not** silently
re-attribute at encounter time.

1. **Clinic-level setting `practitioners_see_all_appointments`** (boolean,
   **default ON**). When ON, practitioners see all appointments *within their
   clinic*; when OFF, a practitioner's worklist is scoped to their own
   appointments. Front Desk, Nurse, and Admin **always** see all in-clinic
   appointments regardless of the flag.

2. **Scope appointment reads server-side, by role and flag.** `list_appointments`
   and the dashboard/queue feed apply the scope in the query — practitioners are
   filtered to their linked `Healthcare Practitioner` when the flag is OFF;
   other roles are unfiltered (within clinic).

3. **Front Desk + Admin can reassign an appointment's practitioner** via a new
   whitelisted `reassign_appointment(appointment, practitioner)`:
   - Allowed only in **pre-encounter** statuses (Scheduled / Confirmed /
     Checked-in). **Blocked** once an encounter exists for the appointment.
   - **Audited**: records who reassigned, when, and from→from-practitioner→to.
   - **Doctor self-claim is deferred** (YAGNI) — front-desk reassignment covers
     the real coverage workflow and avoids reopening the write-permission surface.

4. **`start_encounter` inherits the appointment's practitioner** (native
   `make_encounter` behavior) and does **not** override it with the caller. The
   coverage workflow is handled exclusively by `reassign_appointment` (§3): front
   desk moves the appointment to the covering provider, then that provider opens
   the encounter and inherits it cleanly. This keeps the appointment as the single
   source of truth and avoids two competing mechanisms mutating attribution
   (which would drift against billing / revenue-by-provider). The row-level User
   Permission **remains** as a defense-in-depth backstop; its generic failure is
   replaced with an explicit message (e.g. *"This appointment is assigned to
   another practitioner — ask front desk to reassign it before opening the
   encounter."*).

   The existing caller-adoption logic in `create_encounter` /
   `complete_encounter` is **left untouched** here (out of blast radius) but is
   flagged as a follow-up consistency pass — long term, both creation paths should
   converge on the appointment-as-source-of-truth model.

5. **Compliance posture:** rely on **access audit logging** (who opened which
   chart/appointment), not per-practitioner walls, to satisfy data-minimization
   intent. **Cross-clinic isolation is absolute** and is never governed by the
   `practitioners_see_all_appointments` flag — "all" always means "all within
   this clinic."

## Alternatives Considered

### A. Visibility model

1. **Hard per-practitioner walls (scoped by default, no toggle).**
   - Pros: strictest data-minimization reading; simplest mental model.
   - Cons: breaks coverage/locum every time a provider is out; constant support
     burden; most small clinics would disable it anyway; gives a false sense of
     compliance while the real control (audit logging) is absent; **further from
     native** (native has no per-practitioner walls at all).

2. **Clinic-level toggle (default ON) + front-desk reassignment (chosen).**
   - Pros: **default ON matches native** (native has no practitioner-level access
     control); matches how small clinics operate; coverage works out of the box; a
     single, comprehensible setting; compliance carried by audit logging;
     larger/privacy-conscious clinics can opt into scoping.
   - Cons: default visibility is broader than the strictest minimization; leans
     on audit-log discipline; one more setting to document.

3. **No scoping — everyone always sees everything.**
   - Pros: trivial; exactly native.
   - Cons: no path for clinics that genuinely need provider separation
     (multi-specialty, shared-building practices); weakest minimization posture;
     cannot satisfy customers with stricter internal policy.

### B. Encounter attribution model

1. **Appointment owns the practitioner; encounter inherits it (chosen — "Path A").**
   - Pros: **matches native `make_encounter` exactly**; single source of truth;
     coverage handled by `reassign_appointment`; no attribution drift against
     billing / revenue-by-provider; simpler `start_encounter`.
   - Cons: a doctor cannot ad-hoc "grab" another provider's appointment — front
     desk must reassign first (acceptable, since self-claim is deferred).

2. **`start_encounter` adopts the logged-in practitioner ("Path B").**
   - Pros: most forgiving — a doctor can open any appointment and become its owner;
     consistent with existing `create_encounter` adoption.
   - Cons: **two mechanisms mutate attribution** (adoption + reassignment) that can
     disagree with the appointment record; diverges from native; risks
     revenue-by-provider drift; the silent re-attribution is surprising.

## Consequences

- **New setting field** `practitioners_see_all_appointments` on the clinic
  settings surface (implementation: custom field via fixture/patch on the clinic
  settings doctype or Company — to be finalized in the build plan, must remain
  Rule-1 upgrade-safe).
- **`api/v1/appointments/api.py`** — `list_appointments` and the dashboard/queue
  feed gain role+flag scoping.
- **New `reassign_appointment` endpoint** (Front Desk/Admin, pre-encounter,
  audited) in `api/v1/appointments/api.py`. Note: core Healthcare marks
  `Patient Appointment.practitioner` as `set_only_once`, so the reassignment
  writes via `frappe.db.set_value` (and refreshes the fetched `practitioner_name`),
  mirroring how `cancel_appointment`/`check_in_patient` already write — a doctype
  `save()` would be rejected with "Value cannot be changed".
- **`api/v1/encounters/api.py`** — `start_encounter` keeps inheriting the
  appointment's practitioner (no caller adoption); generic permission error
  replaced with an explicit message. Existing `create_encounter` /
  `complete_encounter` adoption left as-is, flagged for a later consistency pass.
- **Audit** — reassignment writes an audit trail (Frappe comment/version or a
  dedicated log); ties into revenue-by-provider reporting, which now reflects the
  reassigned provider.
- **Frontend (separate tickets, cross-referenced):** respect read scoping; add a
  front-desk "reassign provider" action; wire the dead `/queue` Start-Encounter
  button; reconcile the `"Ready for Provider"` status vocabulary.
- **Billing note:** if two providers have different consultation fees,
  reassignment can change the billable rate — surfaced to the front-desk user.
- **Re-evaluation triggers:** a clinic reports cross-provider data concerns, or a
  multi-specialty customer onboards needing default-OFF, or self-claim becomes a
  real requested workflow.

## Verification

- **Tests** (pytest, `tests/appointments/` and `tests/encounters/`):
  - Practitioner with flag **OFF** lists only their own appointments; with flag
    **ON** lists all in-clinic appointments; **never** cross-clinic in either case.
  - Front Desk / Admin always list all in-clinic appointments regardless of flag.
  - `reassign_appointment` pre-encounter succeeds and writes an audit record;
    reassignment after an encounter exists is rejected.
  - `start_encounter` sets the encounter's `practitioner` equal to the
    **appointment's** practitioner (native inherit — no caller adoption).
  - Front desk reassigns an appointment to Dr. B → Dr. B calls `start_encounter`
    → `201`, and the encounter's `practitioner` is Dr. B (inherited, because the
    appointment now points to Dr. B).
  - Doctor calls `start_encounter` on another practitioner's (un-reassigned)
    appointment → backstop permission failure returns the explicit message, not
    `"An error occurred."`
- **Config artifact:** the `practitioners_see_all_appointments` field exists via
  fixture/patch and defaults ON on a fresh install.

## References

- Constitution §3 (jurisdiction Mexico, custom-whitelisted API pattern), §4
  Rule 1 (no core modification), §9 (ADR requirement)
- Commits `39f7728`, `47ef06a`, `fd4dabb` (nurse/encounter permission history)
- ADR-012 (appointment payment orchestration), ADR-017 (front-desk POS)
- `docs/FRONTEND_FEATURE_AUDIT.md` (start-encounter flow findings)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-30 | Sarvesh | Initial version (header backfilled from git history) |
