# ADR-030: Persist the AI patient chat + capture answer feedback

**Doc status:** living · **Created:** 2026-07-23 by Divyanshu · **Updated:** 2026-07-23 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-07-23
- **Supersedes:** none (extends ADR-029 AI Patient Clinical Summary)

## Context

The patient assistant chat (`api/ai/lab_result_summary.ask_lab_question`) was
**ephemeral**: the clinician's question and the AI's answer were never stored, and
conversation history was replayed by the client on each call. Two gaps:

1. The thread did not survive a reload — a clinician lost the conversation on
   navigation, and there was no record of what was asked/answered about a patient.
2. There was no way to capture whether an answer was useful — nothing to drive
   later quality review or prompt evaluation.

AI Prompt Log is deliberately **content-free** (Rule 10 — no PHI in logs), so it
cannot be the store for the chat text.

## Decision

Introduce a dedicated doctype **`AI Patient Chat Message`** (one row per message,
keyed by `patient`; all rows for a patient form that patient's single thread —
WhatsApp-like, no separate thread doctype).

- `role` (`user` / `assistant`), `content` (the message text), `language`.
- Per-answer audit fields: `model`, `prompt_version`, `prompt_hash`, `tokens_in`,
  `tokens_out`, `cost_estimate_usd`, `latency_ms`, `prompt_log` (link to the
  content-free AI Prompt Log row), `in_reply_to` (assistant → its question).
- Feedback: `feedback` (`Up` / `Down` / blank), `feedback_by`, `feedback_on`,
  `feedback_note`. Only `assistant` rows can be rated.

API (all gated on `AI Settings.enable_lab_extraction`, permission-checked via
`require_permission("Patient", "read")`):

- `ask_lab_question` — now persists the question up front, then the answer on
  success, and returns `message_name` for feedback. Conversation memory prefers
  client `history`, else rebuilds from the stored thread.
- `list_patient_chat(patient, page, page_size)` — reload the thread, oldest-first.
- `set_patient_chat_feedback(message, feedback, note?)` — set/clear thumbs up/down.

## Consequences

- **PHI at rest.** Chat content is PHI stored in a doctype — consistent with
  `AI SOAP Draft` / `AI Patient Clinical Summary`. It is a clinical record, not a
  log: it must never be written to AI Prompt Log, Sentry, or any logger (Rule 10
  unchanged). Content stays advisory (Rule 6) — never an authoritative order.
- **On LLM failure**, the committed question remains in the thread with no answer
  (the honest state); the audit row is marked Failed.
- **Retention:** kept indefinitely for now. A purge/retention window tied to the
  active `ComplianceProfile` is deferred to a follow-up ADR.
- **Feedback for eval:** thumbs-down rows (with optional notes) become the review
  queue for prompt/quality iteration.

## Alternatives considered

- **Reuse `Chat Thread` / `Chat Message`** (internal staff messaging): rejected —
  `sender` is a `User`, no patient scoping, no AI metadata, no feedback; wrong
  domain, would couple AI chat to human messaging.
- **Store content in AI Prompt Log:** rejected — violates Rule 10 (no PHI in logs).
- **Thread + message (2 doctypes):** rejected — only needed for multiple named
  threads per patient, which is not a requirement.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-23 | Sarvesh | Initial version (header backfilled from git history) |
