# ADR-056: Consent for AI recording becomes server-derived evidence, V3 only

**Doc status:** living · **Created:** 2026-09-03 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-03 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-03
- **Supersedes:** —
- **Superseded by:** —

## Context

`start_session(encounter, consent_obtained: bool)` (`api/ai/sessions.py`) has
always trusted a bare boolean sent by the caller. Nothing server-side
verified a physician actually asked, or recorded who did. Verified live: the
Next.js BFF route `app/api/ai/session/route.ts` sends
`consent_obtained: true` unconditionally on every call — confirmed by its
own comment ("the UI's consent modal already gates every path that reaches
here, so consent_obtained is always true"). PHI-2 (CLAUDE.md §9.9) already
names the class of defect this produces: "a hardcoded `true` produced
13,631 stored PHI turns with no human ever asked" — that incident was V1's
auto-start; this ADR closes the same trust gap at the API boundary that let
it happen.

Investigating the fix surfaced a second, live instance of the same class of
problem: V1's `CopilotHost.tsx` carries a "TEMPORARY DEV SHORTCUT"
(2026-07-25) that auto-starts recording on mount with **no consent question
asked at all** — its own comment already flags it as unreviewed and unsafe
for real clinical use. V1 and V3 share one code path to `start_session`
(`RealCopilotProvider` -> `POST /api/ai/session`), so any unconditional
server-side enforcement change here affects both screens even though this
task (05-FIX-PLAN.md T-38) is scoped to V3 only.

## Decision

`start_session` gains an opt-in parameter, `require_consent_record`
(default `False`, backward compatible). When true, `consent_obtained` alone
is no longer sufficient — the session's own `consent_method` field must
already be `"asked_and_agreed"`, written by a new, separate endpoint,
`record_consent(encounter, method)`, called before recording is requested.

1. `record_consent` stamps `consent_by` (`frappe.session.user`) and lets the
   existing `_stamp_consent` controller hook set `consent_obtained_at` — 
   neither is ever accepted as a request argument. This is what makes the
   record evidence rather than a second copy of the same trust problem.
2. `method` is `"asked_and_agreed"` or `"declined"` — a decline is recorded
   as real evidence too, not silently dropped.
3. Two new fields on `AI Encounter Session`: `consent_by` (Link, User),
   `consent_method` (Select, default `"unverified"`).
   `consent_obtained`/`consent_obtained_at` already existed and are
   unchanged.
4. Only the frontend's V3 call site (`v3/use-recording.ts`, via a new
   `RealCopilotProvider` constructor flag) passes `require_consent_record:
   true`. V1's call site (`CopilotHost.tsx`) is untouched and continues to
   trust `consent_obtained` exactly as before — confirmed by a zero-diff on
   that file.
5. Every `AI Encounter Session` row that existed before this shipped is
   backfilled to `consent_method = "unverified"` — a one-time migration
   patch, not a guess at the true historical status.

## Alternatives Considered

1. **Make `start_session` unconditionally require a consent record.**
   - Pros: one code path, no flag to reason about, closes the gap for both
     screens at once.
   - Cons: breaks V1 immediately — its auto-start never calls
     `record_consent`, so every V1 recording would fail server-side the
     moment this deployed. A V3-scoped task should not silently change V1's
     runtime behaviour.

2. **Fix V1's dev-shortcut bypass in the same change.**
   - Pros: the more complete compliance fix — V1's gap is arguably more
     urgent, since it is actively skipping consent today, not just trusting
     an unverified claim.
   - Cons: materially larger and riskier change to a screen this task was
     explicitly told to leave alone; V1's real consent UI (`CopilotPanel`'s
     screen, referenced in the shortcut's own comment) is not confirmed
     reachable or correct given the bypass has been live since 2026-07-25.
     Left as its own, separately tracked finding instead.

3. **Ship `record_consent` and the new fields, but leave `start_session`
   unchanged (no enforcement).**
   - Pros: zero risk to either screen, fastest to ship.
   - Cons: does not close the actual gap this task exists for — a client
     that never calls `record_consent` can still mint a token on a bare
     `consent_obtained: true`, unchanged from today.

4. **Opt-in flag on `start_session`, default preserves today's behaviour
   (chosen).**
   - Pros: V3 gets real enforcement now; V1 is provably unaffected (diff
     and a live e2e test both confirm it); the V1 bypass is surfaced as its
     own documented finding rather than either silently left broken or
     silently expanded into scope.
   - Cons: two screens now trust different things at the same endpoint —
     acceptable and temporary; the flag's own docstring states plainly that
     V1 should move to `True` once its consent flow is real, not that this
     is the permanent end state.

## Consequences

- `api/ai/sessions.py`: new `record_consent`; `start_session` gains
  `require_consent_record`.
- `remedisys_healthcare_ai/doctype/ai_encounter_session/ai_encounter_session.json`:
  two new fields, `consent_by` and `consent_method`.
- New patch: `patches/v0/flag_unverified_legacy_ai_session_consent_20260903.py`.
- Frontend (`Healthcare_next_app`, same task, different repo): new
  `/api/ai/session/consent` BFF route; `RealCopilotProvider` gains an
  opt-in `requireConsentRecord` constructor flag; `v3/use-recording.ts`'s
  `grant()`/`decline()` call the new endpoint before proceeding.
- **Open, not closed by this ADR:** V1's `CopilotHost.tsx` auto-start
  bypass. Re-evaluation trigger — when V1's consent UI is confirmed real
  and reachable, `require_consent_record` should default to `True` for
  both screens and the flag itself can be retired.

## Verification

- 40 backend tests (`tests/ai/test_sessions.py`,
  `doctype/ai_encounter_session/test_ai_encounter_session.py`) run via
  `bench console` (see `tests/notifications/test_notify.py` for why —
  `bench run-tests` is broken bench-wide here, pre-existing).
- Live `curl` against the local bench (`marley.local`): `start_session`
  with `require_consent_record=true` and no prior `record_consent` call
  refuses; `record_consent` then `start_session` succeeds and mints a real
  Deepgram token; the exact V1 call shape (no new fields at all) still
  succeeds unchanged.
- 263 pre-existing `AI Encounter Session` rows confirmed flagged
  `consent_method = "unverified"` by direct query after `bench migrate`.
- Frontend: `Healthcare_next_app/e2e/encounter-consent-evidence.spec.ts`
  (3 tests, real backend, real UI).

## References

- `Healthcare_next_app/docs/qa/encounter-v3/05-FIX-PLAN.md`, T-38
- CLAUDE.md §9.9, PHI-2
- `prompts/2026-09-03-consent-server-derived-evidence.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Sarvesh-SocialAngel (AI-assisted) | Initial version. |
