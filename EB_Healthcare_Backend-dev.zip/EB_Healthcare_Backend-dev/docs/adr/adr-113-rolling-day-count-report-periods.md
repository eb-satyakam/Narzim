# ADR-113: Rolling 7/30/90-day report periods, additive alongside the calendar periods

**Doc status:** living · **Created:** 2026-09-28 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-28 by Anant Sharma (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-28
- **Supersedes:** —
- **Superseded by:** —

## Context

Every report's period selector currently offers five **calendar-aligned** presets — Today, This
Week, This Month, This Quarter, This Year — all resolved by `resolve_report_window()`
(`remedisys_healthcare_ai/utils.py:878`) and shared by all 17 report builders. `Reports v3.dc.html`
shows a different, **rolling day-count** set instead: Today / 7 days / 30 days / 90 days. Anant
directed (2026-09-28) adding the design's periods alongside the existing ones, not replacing them.

Before writing code, the actual blast radius was checked, not assumed (research summary):

- `resolve_report_window` is the **only** function in `utils.py` that branches on the period
  *name*; `report_prior_window`, `report_trend_granularity`, `report_bucket_of` and
  `report_date_buckets` all operate purely on `[start, end]` dates, with zero dependency on which
  preset produced them.
- All **27 call sites** across 10 backend files use the resolved period (`rp`, the function's third
  return value) only as a label passed to `report_meta()` — never branched on. Adding new period
  names cannot change behaviour at any existing call site.
- The frontend has **one** canonical `ReportPeriod` type and `REPORT_PERIODS` array
  (`src/lib/narzim/report-scope-url.ts`); `report-shell.tsx`'s period buttons are already
  data-driven off that array, so the buttons need no code change beyond extending it. A **second,
  separately-maintained** `ReportPeriod` union exists in `src/types/reports.ts` — used by
  `ReportParams.period` — that would silently drift out of sync with the canonical one if only one
  were extended.
- `report-shell.tsx`'s `LIST_PRESETS` set (`today`/`week`/`month`, the three with a matching
  calendar-aligned destination screen) deliberately does **not** include the new periods — they
  have no destination-screen equivalent, so they correctly fall through to the existing
  explicit-dates branch with no code change.
- Under the current `report_trend_granularity` thresholds (day ≤14, week ≤120, else month): 7 days
  → daily buckets (7 points); 30 days → weekly buckets (~5, matching what "This Month" already
  produces); 90 days → weekly buckets (~13, matching "This Quarter"). No threshold changes needed.
- No existing test asserts the exact contents of `_VALID_REPORT_PERIODS`; nothing breaks additively.

## Decision

**Add three period keys — `7d`, `30d`, `90d` — as rolling N-day windows ending today, purely
additive alongside the five existing calendar-aligned periods.**

1. Backend (`utils.py`): `_VALID_REPORT_PERIODS` gains `"7d"`, `"30d"`, `"90d"`;
   `resolve_report_window` gains three branches computing `start = ref - (N-1) days`, `end = ref` —
   the same pattern already used for `_build_my_performance`'s ad hoc rolling-30-day trend
   (`dashboard/report.py`), now generalised into the shared function instead of staying a one-off.
2. Frontend: `report-scope-url.ts`'s `ReportPeriod` type and `REPORT_PERIODS` array gain the three
   keys — the period buttons render them with no further code change. `types/reports.ts`'s
   duplicate `ReportPeriod` is **re-exported from `report-scope-url.ts`** instead of independently
   maintained, closing the drift risk the research surfaced, not just working around it for these
   three keys.
3. i18n: `reports.index.period.{7d,30d,90d}` ("7 days" / "30 days" / "90 days", `es`: "7 días" /
   "30 días" / "90 días") and `reports.index.vsCaption.{7d,30d,90d}` ("vs previous 7 days" / "vs
   previous 30 days" / "vs previous 90 days") — the latter was not in the original research summary
   and was found by checking `TrendChip`'s caption lookup directly; without it every KPI delta on a
   7/30/90-day period would silently fall back to the generic "vs previous period" caption instead
   of the design's specific one.
4. `LIST_PRESETS` is **not** touched — the new periods have no calendar-aligned destination screen,
   and forcing one would be inventing a mapping nothing asks for.

## Alternatives Considered

Depth here follows the "consequential but reversible" tier (`CLAUDE.md` §10): a real, brief
comparison rather than a full write-up, since the research already established the change is
additive and low-risk everywhere it touches.

1. **Replace the five calendar periods with the design's four rolling ones.**
   - Pros: exact design match.
   - Cons: explicitly rejected by Anant — removes a period model every report and every existing
     saved link/export currently depends on, for a design column that itself only ever showed
     Today/7d/30d/90d as an *example*, not a stated requirement to drop the others.
2. **Add the three periods alongside the existing five (chosen).**
   - Pros: nothing removed; confirmed zero-risk to all 27 existing call sites; the frontend button
     list needs no new code, only three array entries.
   - Cons: two period vocabularies now coexist (rolling vs calendar-aligned) — a report open on
     "30 days" and "This Month" can show different figures for what looks like a similar window.
     Mitigated by `TrendChip`'s caption always stating what the delta is measured against, so the
     ambiguity is never silent on screen.
3. **Build 7d/30d/90d as a Patient-Flow-only, page-local feature** (bypass `resolve_report_window`
   entirely for that one report).
   - Pros: zero risk to the other 16 reports.
   - Cons: duplicates window-resolution logic exactly where the shared function already exists to
     prevent that; the next report that wants a rolling period repeats the same one-off `utils.py`
     already outgrew once (My Performance's ad hoc 30-day trend, ADR-111's round 2).

## Consequences

- Backend: `remedisys_healthcare_ai/utils.py` (`_VALID_REPORT_PERIODS`, `resolve_report_window`);
  new `remedisys_healthcare_ai/tests/test_resolve_report_window.py` covering the three new periods
  as pure-function tests (no site needed, same convention as `tests/appointments/test_patient_flow.py`).
- Frontend: `src/lib/narzim/report-scope-url.ts`, `src/types/reports.ts` (re-export, not a second
  definition), `messages/en.json`, `messages/es.json`.
- Every one of the 17 report pages gains the three new period buttons automatically — the shared
  `report-shell.tsx` selector is what renders them, not a per-page change.
- Re-evaluation trigger: if a report needs a rolling period with a different destination-screen
  mapping than `LIST_PRESETS` currently supports for the calendar periods, that is a new, separate
  decision — not assumed here.

## Verification

- New pure-function tests confirm `resolve_report_window("7d"/"30d"/"90d", ref_date=...)` returns
  the correct inclusive N-day window and the resolved period name round-trips into `report_meta`.
- Frontend: TypeScript (`tsc --noEmit`) and ESLint clean; `types/reports.ts`'s `ReportPeriod` no
  longer independently declared.
- Manual check: a report opened with `?period=30d` reads a real 30-day window in its response
  `meta.date_from`/`date_to`, and the period button row shows the three new buttons on every report
  page without a page-specific change.

## References

- `docs/reports/18-reports-v3-redesign.md` — the plan this ADR extends.
- `CLAUDE.md` §10 (depth-scaling by reversibility, doc-before-code).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Anant Sharma (AI-assisted) | Initial version |
