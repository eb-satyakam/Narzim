# ADR-021: Master-data CRUD goes through a generic whitelisted method, not `/api/resource/`

**Doc status:** living · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-02 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-02
- **Supersedes:** —
- **Superseded by:** —

## Context

The Engineering Constitution locks the API pattern hard:

- §3 (Locked Assumptions, *API pattern*): "**Custom whitelisted methods only** — `api/v1/<module>/api.py`. Never use Frappe's built-in `/api/resource/` endpoints. All data access goes through our permission-checked service layer."
- §11 (Hard Don'ts): "Use Frappe's built-in `/api/resource/` endpoints" is listed as a thing we will NOT do.

The Settings & Setup audit (`docs/audit/settings/`) found that the reality diverges from this rule for **master / reference data**. The frontend's generic admin CRUD route `src/app/api/admin/[resource]/route.ts` carries a `standardCrud: true` flag on many resources; when set, create/update/delete route through `frappeRestInsert / frappeRestUpdate / frappeRestDelete` in `src/lib/api/client.ts`, i.e. **`POST/PUT/DELETE /api/resource/<DocType>`** — Frappe's built-in REST, no custom `api/v1` method behind it.

Resources currently on `standardCrud` (non-exhaustive, from the route config): **Medical Department, Patient Care Type, Holiday List, Insurance Payor, Item Group, Lab Test UOM, Lab Test Sample, UOM, Price List, Sample Collection, combination-medications, therapy-types (partial)**. Company writes hit the same `/api/resource/` surface for admin master edits (audit finding **C-4**); Medical Departments is the canonical case (audit finding **MD1**).

Facts that shape the decision:

1. `/api/resource/` is **not** unauthenticated. It runs through Frappe's ORM and permission engine — DocPerm role rules, user permissions, mandatory fields, and `validate`/`before_insert` controller hooks all still fire. The security concern is not "no auth"; it is "no *service layer*".
2. What `/api/resource/` bypasses is our control point: the standardized `{status, data, error}` envelope + `request_id` (§9), PHI scrubbing and audit conventions (Rule 10), and any cross-field / value-restricted business rule that DocPerm cannot express (e.g. the appointment status role-gate).
3. On **write**, `/api/resource/` accepts **any field** the client sends and exposes **every field** on read. The frontend's `fields` allowlist in the `[resource]` route governs reads only; it does not constrain what a PATCH body may set. This is a real over-exposure surface.
4. Master/reference data (department names, dosage forms, UOMs, item groups, price lists) is **low-risk**: non-PHI, non-transactional, small lookup tables. The blast radius of points 2–3 is far smaller here than for clinical/PHI/financial doctypes.
5. Hand-writing bespoke `create_/update_/delete_` methods for ~15 master doctypes is high-cost, low-value boilerplate — which is precisely why `standardCrud` was introduced as a shortcut.

The tension: the constitution's blanket ban is correct for clinical/PHI/money, but it was written before the master-data CRUD surface existed, and the team has been silently violating it rather than deciding the policy.

## Decision

Adopt a **two-tier data-access policy**, and provide a single safe mechanism for tier 2 so we neither hand-write 15× boilerplate nor punch through raw `/api/resource/`.

**Tier 1 — Clinical / PHI / transactional data** (Patient, Patient Appointment, Patient Encounter, Vital Signs, Lab Test, Sales Invoice, Payment Entry, Insurance claim docs, and anything carrying PHI or money): **whitelisted `api/v1/<module>` methods only.** `/api/resource/` is forbidden, no exceptions. This is unchanged from §3/§11.

**Tier 2 — Master / reference data** (Medical Department, Patient Care Type, Dosage Form, UOM, Lab Test UOM/Sample, Item Group, Price List, Sample Collection, Brand, Manufacturer, Therapy Type, and similar non-PHI lookup doctypes): CRUD goes through **one generic whitelisted method** — `api/v1/admin/master_crud.py` — that:

1. Accepts a **doctype + operation (list/create/update/delete)** but only for doctypes on a **server-side allowlist** (a dict mapping each permitted doctype to its **writable field allowlist** and read field list). Unknown doctypes are rejected.
2. Enforces the **field allowlist on write** — any field not in the allowlist is dropped, not persisted. This closes the over-exposure hole `/api/resource/` leaves open.
3. Calls `require_permission(doctype, perm)` (so DocPerm still applies) **and** returns the standard `set_response` / `set_list_response` envelope (§9).
4. Is the single place to add master-data audit logging if ever needed.

`standardCrud: true` and the `frappeRest*` helpers in `src/lib/api/client.ts` are **deprecated** and removed once each resource is migrated to `master_crud`. The frontend `[resource]` route calls `master_crud` instead of `/api/resource/`.

This keeps the DRY benefit of generic CRUD (one method, config-driven) while restoring the service-layer guarantees (envelope, field allowlist, permission checkpoint) that the constitution requires.

## Alternatives Considered

1. **Keep `/api/resource/` for master data (formalize the current state).**
   - Pros: zero backend work; framework-tested; DocPerm still applies; fastest.
   - Cons: violates §3/§11 as written (needs the ban relaxed); no `{status,data,error}` envelope (frontend handles two error shapes); **write accepts arbitrary fields** (over-exposure); open client-driven `filters/fields/order_by` query surface; couples the frontend to Frappe's REST + schema, which breaks the future FastAPI-sidecar option (Rule 3). Acceptable risk for tiny lookup tables, but the write-exposure hole is real even there.

2. **Generic `master_crud` whitelisted method (chosen).**
   - Pros: honors "whitelisted methods only"; one method covers all master doctypes (no 15× boilerplate); enforces a **write field allowlist** (fixes over-exposure); standard envelope; single audit/permission checkpoint; keeps the frontend decoupled from Frappe internals. ~50–80 lines written once.
   - Cons: some backend work now; a config (doctype → field allowlist) to maintain as master doctypes are added; slightly less "free" than raw REST.

3. **Hand-write bespoke `create_/update_/delete_<doctype>` per master doctype.**
   - Pros: maximum control and per-doctype validation; fully consistent with clinical modules.
   - Cons: ~15 doctypes × 3–4 methods = a large volume of near-identical boilerplate to write and maintain; high cost for low-risk reference data; the exact churn `standardCrud` was created to avoid.

## Consequences

- **Constitution:** add an amendment note to §3 (*API pattern*) and §11 recording the Tier-1/Tier-2 split; §3's blanket ban now reads "whitelisted methods only — via bespoke module methods (Tier 1) or the generic `master_crud` method (Tier 2); `/api/resource/` remains forbidden."
- **Backend (new):** `remedisys_healthcare_ai/api/v1/admin/master_crud.py` — `list/create/update/delete` gated by an allowlist config `{doctype: {read_fields, write_fields, required, permission_doctype}}`. Registered in the admin whitelist.
- **Frontend (change):** `src/app/api/admin/[resource]/route.ts` — replace `standardCrud`/`frappeRest*` calls with calls to `master_crud`; drop the `frappeRestList/Insert/Update/Delete` helpers from `src/lib/api/client.ts` once no caller remains. The per-resource `fields` config moves server-side into the allowlist (single source of truth).
- **Audit items closed:** Company **C-4** and Medical Departments **MD1** resolve by migration to `master_crud`. Every remaining `standardCrud` settings screen (Dosage Forms, Lab Test Templates/Groups, Brands, Manufacturers, Therapy Types, Service Units where applicable) inherits the fix.
- **Migration is incremental:** resources move to `master_crud` one at a time; `standardCrud` stays working until the last one is migrated, then the dead code is deleted.
- **Re-evaluation trigger:** if the master-data allowlist config becomes a maintenance burden, or if a master doctype needs real per-field business rules, promote that doctype to a Tier-1 bespoke method.

## Verification

- `grep -r "standardCrud\|frappeRestInsert\|frappeRestUpdate\|frappeRestDelete" src/` in the frontend returns **zero** once migration completes.
- A backend test asserts `master_crud` (a) rejects a doctype not on the allowlist, (b) drops a non-allowlisted field on write, and (c) returns the standard envelope.
- The Settings audit rows C-4 and MD1 are marked resolved with the `master_crud` commit referenced.

## References

- Constitution §3 (Locked Assumptions — API pattern), §9 (Cross-Cutting Standards — Errors), §11 (Hard Don'ts), Rule 10 (No PHI in Logs)
- Audit: `docs/audit/settings/01-company.md` (C-4), `docs/audit/settings/03-medical-departments.md` (MD1), `docs/audit/settings/README.md` (pattern log)
- ADR-003 (BFF pattern) · ADR-004 (no core DocPerm edits)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
