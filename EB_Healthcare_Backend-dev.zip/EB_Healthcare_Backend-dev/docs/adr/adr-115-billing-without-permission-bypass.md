# ADR-115: Billing runs on real role permissions; only front desk and admin move money

**Doc status:** living · **Created:** 2026-09-30 by Divyanshu (AI-assisted) · **Updated:** 2026-09-30 by Divyanshu (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

Every billing flow (collect payment, refund, checkout, pay-now booking, reschedule settlement,
write-off, the ADR-114 line replacement) saved and submitted its documents with
`ignore_permissions=True`: 14 sites in `services/billing.py`, plus the invoice cancel in
`api/v1/appointments/api.py::cancel_unpaid_invoice_for_appointment` and the reschedule's own saves.
The EB roles could not in fact submit anything: before this change only EB_Healthcare Admin held
`submit` on Sales Invoice and Payment Entry, and no EB role held any Journal Entry right. The
constitution forbids `ignore_permissions` to make a call succeed (§5, §6). The product owner decided
on 2026-09-30 that **only EB_Front Desk and EB_Healthcare Admin move money**. Separately, reassigning
a practitioner (`reassign_appointment`) moved no money when the two practitioners' fees differed.

## Decision

Remove every permission bypass from the billing flows and grant the money roles what those flows
need; refuse everyone else before anything is written.

1. `eb_docperm_spec.json` (patch `apply_eb_docperm_spec_20260930`): EB_Front Desk gains
   write/submit/cancel on Sales Invoice and submit/cancel on Payment Entry; EB_Front Desk and
   EB_Healthcare Admin gain create/submit/cancel (no read) on Journal Entry.
2. The Journal Entry grant is narrowed by a `has_permission` hook
   (`overrides/billing_journal_perms.py`): an EB user's Journal Entry write is allowed only inside
   `services.billing.billing_journal_entries()`, which billing opens around its own entries
   (write-off, write-off reversal, Credit Note applied to a replacement invoice). Core accounting
   roles are unaffected.
3. `require_money_role` refuses non-money roles up front at every money-writing endpoint
   (collect, refund, invoice creation, checkout, pay-now and insured booking) and at a reschedule
   whose quote is a Refund or an Additional Payment. A pay-later difference still goes through.
4. A non-money role cancelling an appointment with an unpaid invoice leaves the charge and raises a
   claimable Front Desk task instead of cancelling the invoice.
5. `Appointment Reschedule History` gains create for EB_Front Desk, EB_Practitioner and EB_Nurse
   (those who can write an appointment), so a reschedule writes its history row without a bypass.
6. `reassign_appointment` settles a fee difference through the reschedule path
   (`reschedule_appointment_with_payment`): refund via line replacement when cheaper, collect now
   or at checkout when dearer.

## Alternatives Considered

1. **Grant the money roles real permissions and narrow Journal Entry with a hook (chosen).**
   - Pros: the constitution's rule holds; Frappe itself enforces who may move money; a
     non-money role gets a clear refusal before any write.
   - Cons: practitioners can no longer take a payment or refund; Journal Entry needs a hook.

2. **Grant Journal Entry without the hook.**
   - Pros: simplest.
   - Cons: front desk could post an arbitrary Journal Entry through Frappe's generic document API.

3. **Avoid Journal Entry for the replacement step with one Payment Entry that nets the Credit
   Note against the replacement invoice.**
   - Pros: no Journal Entry grant for that step.
   - Cons: rejected by ERPNext on this bench ("Allocated Amount cannot be greater than outstanding
     amount" / "Debit and Credit not equal"); two separate Payment Entries would show a false 500
     refund and 300 collection in the day's figures. Write-offs need Journal Entry anyway.

4. **Keep the bypasses and check roles in code.**
   - Pros: no permission changes.
   - Cons: exactly what §5/§6 forbid; the framework no longer protects the documents.

## Consequences

- EB_Practitioner, EB_Nurse, EB_Clinic Staff and EB_Finance can no longer collect, refund or
  invoice; they get a 403 naming the action. Front desk does it.
- Every site needs `bench migrate` (the permission patch) before front desk can collect; without
  it, front desk is refused at submit.
- Outside billing, ~96 files still use `ignore_permissions` (AI logs, Drive, WhatsApp webhooks,
  nursing, seed scripts); many run with no user at all. Tracked in `docs/KNOWN_ISSUES.md`.
- Re-evaluate if a clinic needs practitioners to take payments (grant, do not bypass).

## Verification

`tests/appointments/test_reschedule_payment.py` runs as real EB_Front Desk / EB_Practitioner users:
front desk reschedules cheaper and reassigns cheaper/dearer with no bypass; a practitioner is
refused a money-moving reschedule and a payment; a practitioner's cancellation leaves the unpaid
charge and a task; front desk cannot post its own Journal Entry. Each of the reassign, refusal and
cancellation tests fails on the code before this change.

## References

- [ADR-114](adr-114-appointment-line-owns-its-money.md) — the line replacement this settles through
- [Design note](../flows/RESCHEDULE_CANCEL_REFUND_LINES.md)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-30 | Divyanshu (AI-assisted) | Accepted and implemented |
