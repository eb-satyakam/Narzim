# ADR-060: Patient Communication Consent as a doctype, and the send-path gate that reads it

**Doc status:** living · **Created:** 2026-09-04 by Ashutosh (AI-assisted) · **Updated:** 2026-09-04 by Ashutosh (AI-assisted) · **Version:** 1.1

- **Status:** **Accepted** — countersigned by Ashutosh, 2026-09-04
- **Still gated separately:** the legal read on
  [`WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) §2 gates **enabling a
  template**, not building this. Acceptance here authorises the build; it does not turn the
  channel on
- **Date:** 2026-09-04
- **Supersedes:** —
- **Superseded by:** —

## Context

WhatsApp is being adopted as a system-generated notification channel. Meta will not sign a
Business Associate Agreement, so §164.308(b)(1)'s usual route is closed and the disclosure has to
rest on a different basis: it is made **to the individual, at their own request** —
§164.502(a)(1)(i) permits disclosure to the individual, §164.522(b) gives them the right to
request communication by alternative means, and HHS's unsecured-channel guidance permits it where
the individual asks for it having been warned of the risks. The full argument, and its limits, is
[`WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) §2.

**Consent is therefore not a feature of this channel. It is the reason the channel may exist.**
Absent a valid authorization there is no §164.508 cover and no §164.522(b) request, and every
send is simply an impermissible disclosure.

Today there is **none**. Verified on the live site: no consent, opt-in, opt-out or unsubscribe
check exists anywhere in `integrations/whatsapp/*.py`, and every template resolves
`phone_field_path = "patient.mobile"` directly. **Possession of a mobile number is currently
treated as permission to message it.** `Patient` carries `report_preference` and
`consent_for_aadhaar_use`; neither concerns messaging.

Three facts from the live data shape the design:

- **The population is mixed-age**: 36 adults to 10 minors, ages 0-65. An adult authorizes
  personally; a minor or an incapacitated adult needs a personal representative under
  §164.502(g). `CLAUDE.md` §2's "pediatric clinics" framing is inaccurate and is flagged
  separately.
- **239 patients have no date of birth**, so for most of the list the system cannot determine
  *which* of those two paths applies, and therefore cannot determine whether a consent it holds is
  valid at all.
- **`patient.mobile` frequently belongs to someone else** — a parent's number on a child's record,
  a spouse's or an adult child's on an elderly patient's. The field is named for the patient and
  routinely holds a third party's number.

This ADR exists because `CLAUDE.md` §12 requires one before a new custom doctype is built, and §9
requires one for any architectural decision.

## Decision

### 1. A dedicated `Patient Communication Consent` doctype

`track_changes: 1`, insert-mostly, and **no `delete` permission for any role** — the same
reasoning that protects `View Log` and `Permission Log` (register gap #19).

| Field | Type | Purpose |
|---|---|---|
| `patient` | Link → Patient, indexed | The patient the notifications concern |
| `channel` | Select: `WhatsApp` · `SMS` · `Email` | Extensible to any unsecured channel; this ADR only enables `WhatsApp` |
| `status` | Select: `Granted` · `Revoked` · `Expired` · `Blocked` | `Expired` is the majority transition; `Blocked` is a documented objection |
| `phone_number` | Data | **The authorized number.** The send path matches on this, never on `patient.mobile` |
| `granted_by_relationship` | Select: `Self` · `Parent` · `Legal Guardian` | Which §164.502(g) path this consent travels |
| `granted_by_contact` | Link → Contact | *Which* guardian, resolved from the existing `Dynamic Link` guardian records |
| `granted_on`, `granted_by_user`, `granted_ip` | Datetime, Link, Data | Authorization provenance |
| `revoked_on`, `revoked_by_user`, `revoked_reason` | Datetime, Link, Small Text | Revocation provenance |
| `expires_on` | Date | The 18th birthday — set **only** when `granted_by_relationship != "Self"` |
| `patient_dob_at_grant` | Date | The DOB the age check was made against, so a later correction is detectable |
| `consent_text_version` | Data | Which wording was agreed to |
| `jurisdiction` | Data | Active `ComplianceProfile` code at grant time |

### 2. The gate lives in the send path, server-side

A send is refused unless a `Granted`, unexpired consent exists for that patient **and** its
`phone_number` matches the number about to be messaged. Checked in
`integrations/whatsapp/notifications.py::_fire_notification` and in the template send functions —
**not** in the UI. The UI may check too; the server is the control.

This is the direct lesson of PHI-2: a hardcoded frontend `true` produced 13,631 stored PHI turns
with no human ever asked.

### 3. A date of birth is a precondition

Capture refuses without a DOB, and the send path refuses for any patient whose DOB is absent.
Neither default is acceptable: "assume adult" lets a relative's consent silently authorize
disclosures about a 14-year-old, and "assume minor" demands a guardian for a 40-year-old. A
missing DOB makes the authorization **unverifiable**, and an unverifiable authorization is the one
that would be relied upon in an investigation. This is a small visible blocker at capture time
instead of an invisible defect at send time.

### 4. Consent binds to a number, and expires with the authority behind it

- If `patient.mobile` changes, the stored `phone_number` no longer matches and the send refuses
  until new consent is captured. Silent transfer is a disclosure to a party who authorized nothing.
- `expires_on` is the 18th birthday for representative-granted consent only; a patient's own
  consent has no expiry and ends only on revocation.
- A daily scheduled job expires due consents. Fourteen days before, template **T7** warns the
  guardian *while the consent is still valid*, so that send is itself permitted; on expiry a
  front-desk task prompts staff to invite the young adult to consent personally.

### 5. Revocation is immediate, self-service, and ours to honour

A portal toggle, plus inbound stop words (`ALTO`, `BAJA`, `STOP`, `UNSUBSCRIBE`) handled in the
webhook. Meta enforces opt-out for MARKETING templates but **not** UTILITY, and every template in
the catalogue is UTILITY — so the obligation is entirely ours.

### 6. Role permissions

Left unspecified in v1.0 and decided on acceptance. Consent capture is where the PHI-2 failure
mode lives — someone ticking a box on the patient's behalf — so the set of people who *can* do it
is deliberately narrow, and narrowing it also narrows who needs training on the consent text.

| Action | Roles |
|---|---|
| **Create** (capture consent) | `EB_Front Desk`, `EB_Healthcare Admin` |
| **Write** (revoke) | `EB_Front Desk`, `EB_Healthcare Admin` |
| Set **`Blocked`** — a custody order or written objection | `EB_Healthcare Admin` only |
| **Read** | all clinical roles — the send path and staff both need to see whether consent exists |
| **Delete** | **nobody, in any role** |

**Nurses are excluded from capture**, though they routinely collect phone numbers. Registration is
a front-desk workflow, and every additional role with capture rights is another group that must
understand what the consent text commits the clinic to. If coverage turns out to suffer, adding
`EB_Nurse` is a one-line permission change and a training decision — the reverse is not, because
consents captured under a misunderstanding cannot be un-captured.

**No `delete` for any role** is the same reasoning that protects `View Log`, `Activity Log` and
`Permission Log`, and the absence of which is the live finding in register gap #19: an
authorization that can be deleted cannot be produced for a specific patient on a specific date,
which is the only moment it matters.

### 7. Consent is given by the patient or their representative, never by staff on their behalf

Portal-primary; the front desk may capture it only with a recorded staff attestation naming who
agreed. Absence is refusal — the default is off. Treatment is never conditioned on it
(§164.508(c)(2)(ii)), so no clinical or booking flow may be gated on consent existing.

## Alternatives Considered

| Approach | Pros | Cons |
|---|---|---|
| **A. Dedicated doctype (chosen)** | Holds the §164.508(c) elements, a revocation history and several consents per patient; `track_changes` gives field history free; delete can be denied to every role; Rule 1-safe because it touches no core doctype | A new custom doctype to maintain, and a migration patch |
| **B. Custom fields on `Patient` via fixtures** | The Rule 1-compliant way to extend a core doctype, already used for other fields; no new doctype | **Cannot hold more than one consent** — one patient with two guardians on two numbers is the normal case, not the edge. No revocation history, no grant provenance, and a field cannot carry an authorization's required elements. Would need a child table on a core doctype, which Rule 1 forbids |
| **C. Reuse an existing mechanism** — `consent_for_aadhaar_use`'s checkbox pattern, or Frappe's `Communication` | Nothing new at all | `consent_for_aadhaar_use` is a checkbox and inherits every problem in B. `Communication` records *messages*, not *authorizations* — it has no notion of grant, expiry or revocation, and overloading it would make both meanings unreliable |
| **D. No stored consent — paper forms, and a boolean flag to gate sends** | Least engineering; familiar in clinic | A number in a system with nothing enforcing it is exactly what PHI-3 forbids. Revocation has no path, the scans become their own retention and erasure problem (PHI-4), and there is no server-side gate — so the authorization could not be produced for a specific patient on a specific date, which is the only moment it matters |

**A is chosen.** B and C fail on the same structural point — a patient legitimately needs several
consents, and an authorization is a record with provenance rather than a flag, so neither a
checkbox nor a reused message table can represent one. D fails because an unenforced declaration
is worse than an absent one: it reads as a control to an auditor and is not one.

**What would falsify this choice:** if consent turned out to be genuinely one-per-patient and
never revocable in practice, B would be the cheaper answer. The pediatric and shared-phone data
above says otherwise.

## Consequences

- **The channel becomes buildable but not enableable.** Everything here can be built while the
  legal read on §2 is in flight; no template may be enabled until it lands.
- **Rollout is capped by data, not code.** With 239 patients lacking a DOB, consent can initially
  be captured for roughly the 46 whose age is known. That is a visible number rather than a silent
  gap, and it makes DOB capture a product priority.
- **A new doctype means a migration patch** in `patches.txt`, per §9's no-manual-schema-fixes rule.
- **Cross-repo work.** The grant/revoke UI is in `EB_Healthcare_PatientPortal`; the front-desk
  fallback is in `EB_Healthcare_EHR`.
- **The consent text will lower opt-in**, because it names Meta and says Meta can read and retain
  the messages. That is the intended behaviour — a consent that omits the risk warning would
  produce a higher rate and a worthless authorization.
- **This ADR does not make the product HIPAA compliant** and no code comment, UI string or
  document may say that (`CLAUDE.md` §11).

## Verification

Per `CLAUDE.md` §11, auth, persistence and safety code needs tests. The negative cases matter
more than the positive one:

- No consent record → send refused. Revoked, `Expired`, `Blocked` → refused.
- Consent for a **different number** than the one being messaged → refused.
- `Granted` and matching → sent.
- Patient with **no DOB** → both capture and send refused.
- `granted_by_relationship` inconsistent with the patient's age (a `Parent` consent on a 19-year-old)
  → refused.
- The majority job sets `expires_on` for representative consent and **leaves `Self` consent
  untouched**.
- An inbound stop word revokes, and a subsequent send refuses.
- Grant and revoke each write an `Activity Log` row carrying no PHI (Rule 10).
- No role can delete a consent row.

Note for whoever runs these: `bench run-tests` is broken bench-wide — ERPNext's `before_tests`
throws a Fiscal Year overlap because `_Test Fiscal Year 2026` collides with the site's real
`2026-2027`. Run modules directly via `unittest` until that is resolved.

## References

- [`docs/security/WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) — §2 the
  legal basis, §7 the consent model this ADR implements, §13 the six decisions taken
- [`docs/security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md`](../security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md)
  — gap #1 (Meta discloses PHI), gap #2 (no BAAs), gap #28 (the free-form paths, now closed)
- `CLAUDE.md` §9.9 — PHI-2 (consent gates recording, in the UI *and* on the server), PHI-3 (a
  declared period must be enforced by code), PHI-4 (duplicated PHI needs one erasure path), PHI-5
  (never say in the UI what the code does not do)
- 45 CFR §164.502(a)(1)(i), §164.502(g), §164.508(c), §164.522(b)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-04 | Ashutosh | **Accepted.** Role permissions decided, having been left unspecified in v1.0: `EB_Front Desk` + `EB_Healthcare Admin` capture and revoke, `EB_Healthcare Admin` alone sets `Blocked`, all clinical roles read, **nobody deletes**. Nurses are excluded from capture on purpose — registration is a front-desk workflow, and every extra role with capture rights is another group needing to understand what the consent text commits the clinic to; adding them later is a one-line change, whereas consents captured under a misunderstanding cannot be un-captured. Records that acceptance authorises the **build** only: the legal read on §2 still gates enabling a template |
| 1.0 | 2026-09-04 | Ashutosh (AI-assisted) | Initial proposal. A dedicated `Patient Communication Consent` doctype with a server-side send-path gate, chosen over custom fields on `Patient`, a reused existing mechanism, and paper-plus-flag. Records that consent is the legal basis for the channel rather than a feature of it; that the population is mixed-age so an adult consents personally while a minor needs a personal representative; that a DOB is a precondition because 239 patients lack one and the consent path cannot otherwise be determined; and that consent binds to a phone number, since `patient.mobile` routinely holds a third party's |
