# ADR-091: Images are reviewed systematically, read by a stronger model, and summarised briefly in plain words

**Doc status:** living · **Created:** 2026-09-24 by Divyanshu (AI-assisted) · **Updated:** 2026-09-24 by Divyanshu (AI-assisted) · **Version:** 1.2

- **Status:** Accepted — requested by Divyanshu, 2026-09-24
- **Amends:** [ADR-090](adr-090-image-observations-graded-not-restricted.md) — its "HARD LIMITS" block is replaced (v19), and its open item "detection" is answered with a measured model choice. ADR-089's stored-`body_site` gate and ADR-090's Clear/Possible grading code are unchanged.

- **Prompt file:** `multi_panel_extraction_v19.txt` and `multi_panel_extraction_v20.txt` were removed 2026-09-24 at the owner's request (not kept in the repo); the live prompt is `multi_panel_extraction_v21` (ADR-091).
---

## 1. Context

The right-hand X-ray behind ADR-090 shows displaced shaft fractures of the 3rd and 4th
metacarpals and a probable 5th. Two further steps were taken on 2026-09-24.

**v19 (owner decision).** The owner asked for the image section to carry no restriction except
"do not diagnose". v19 kept that one content rule plus the provenance rules (observations are
the AI's, never the template's or the note's). The code gates stay.

**v19 still missed it.** A real upload on v19 (`AI Prompt Log 2285nnknm2`, `gpt-5-mini`)
reported one "possible" 3rd-metacarpal fracture and stopped. A second opinion on that output
named the fault: the review stopped after the first finding, and hedged what was plainly
visible. Nothing in v19 forbade the other fractures, so the fault was not a restriction.

## 2. Decision

1. **Prompt `multi_panel_extraction_v20`** — image section only (everything else is v19,
   enforced by a test): review systematically, every separately identifiable structure one at
   a time; do not stop after the first finding; one line per affected structure; say what the
   image cannot show; never state that a structure is normal, aligned or free of a finding
   unless the image shows it. Written for every kind of study — no organ, modality or example
   word appears in the added lines (tested).
2. **Images are sent at `detail: "high"`** (`integrations/openai.py::_content_part`), for every
   OpenAI call that sends an image.
3. **Uploads containing a picture are read by `AI Settings.openai_image_model`** (new field,
   default `gpt-5.5`, filled on existing sites by patch
   `v0.set_openai_image_model_20260924`). An image file or rendered page images triggers it;
   a PDF with a text layer and no rendered pages stays on `openai_model`. Blank = no override.
   `integrations/openai.py::_image_model`.
   **Each provider has its own image model, shown only when that provider is selected**
   (owner, 2026-09-24): `openai_image_model` (OpenAI) and `anthropic_image_model` (Anthropic,
   `integrations/anthropic.py::_image_model`). Neither provider ever reads the other's setting
   (tested). `anthropic_image_model` ships **blank** (= use `anthropic_model`): no Claude model
   was measured on images, because the dev site has no Anthropic key, and a default would be a
   guess.
4. **Prompt `multi_panel_extraction_v21`** — after a second-opinion review of the first live
   v20 output (`detn2jtuju`, on `gpt-5`, which the settings form had been switched to at 11:54
   and which missed the 3rd metacarpal): `notable` holds findings only (coverage, view, quality
   and printed markers go in the description); a finding whose exact structure between
   neighbours is uncertain names the region and says the structure is indeterminate, never
   picking one; no property the view cannot establish (direction, depth, extent in an unseen
   plane) is stated; limitations only where they matter. Generic, like v20 (tested).
   `openai_image_model` set back to `gpt-5.5`.
5. **Summaries are short and plain** — `report_narrative_summary_v3`: at most 5 short lines,
   findings of one kind grouped on one line, every significant finding kept, "seen on the
   image" said once, a technical term explained in brackets the first time; the v2 line that
   barred "a judgement of normal versus abnormal" (which softened graded findings) is gone,
   and the image block's findings keep their Clear/Possible grading. `lab_report_summary_v5`:
   the same simple-language rule, 3-5 sentences instead of 4-7, and it now carries the
   image-findings rule it lacked.

## 3. Options considered — which model reads images

| Approach | Pros | Cons |
|---|---|---|
| **A. A separate image model, used only for uploads with a picture (chosen, `gpt-5.5`)** | Accuracy where it was measured to fail; text reports, chat and the copilot stay on the cheaper model | One settings field, one patch, one code branch |
| B. Switch `openai_model` to `gpt-5.5` everywhere | No code | Every AI call costs more, with no measured gain on text |
| C. `gpt-6-sol` for images | Equally accurate in these runs | Newest and least known; kept in the dropdown as the next step if A falls short |
| D. `gpt-5.4-mini` for images | Found the fractures, ~4 s | Called the unlabelled ultrasound a "fetal head" as a **Clear** finding — rejected |

## 4. Verified

Live, v20, nothing saved, 2026-09-24. One process per model (an earlier threaded run mixed
models and was discarded); the model each call actually used was confirmed from the response.

| Model | Hand X-ray (4 runs): 3rd + 4th found | 5th found | "No fracture" written | Unlabelled ultrasound (3 runs): organ invented | Time/call |
|---|---|---|---|---|---|
| gpt-5-mini | 0/4 | 0/4 | **3/4** (one as "Clear") | 1/3 "kidney" | ~18 s |
| gpt-5.4-mini | 4/4 | 4/4 | 0 | **1/3 "fetal head" (Clear)** | ~4 s |
| gpt-5.5 | 4/4 | 4/4, all Clear | 0 | 0/3 | ~18 s |
| gpt-6-sol | 4/4 | 4/4 | 0 | 0/3 | ~15 s |

An earlier v20 run on gpt-5-mini (5 X-ray, 5 ultrasound) agreed: 0/5 found the fractures,
2/5 wrote a "no fracture" line, 1/5 ultrasounds named a kidney.

**v21, `gpt-5.5`, through the real settings (no override), 4 + 4 runs, nothing saved:**

| | Result |
|---|---|
| Hand X-ray: 3rd, 4th, 5th metacarpal breaks | **4/4 all three**, graded Clear (one run graded a "less clearly defined" 5th as Clear, which should have been Possible) |
| Coverage / quality / marker lines in `notable` | 0/4 (v20 on gpt-5: 4 such lines in its one run) |
| A direction the single view cannot show | 0/4; three runs said depth or dorsal/volar displacement cannot be assessed |
| Unlabelled ultrasound: organ invented | 0/4; 3 of 4 marked the exact structure "indeterminate" (one run said "abdominal-appearing") |
| Time per call | 18-33 s |

**What this does not show.** Two images, one of each kind; no ECG, CT, MRI or photograph was
tested. The result says the prompt was no longer the limit and the model was; it does not
prove `gpt-5.5` reads every modality well. AI image observations still must not be relied on
to find or exclude an abnormality.

Tests: `tests/labs/test_image_review_systematic.py` — removed 2026-09-24 at the owner's request (not kept in the repo).

## 5. Open

- **Price of `gpt-5.5` is UNVERIFIED** and not in `openai.py::_COST_PER_MTOK`. Corrected
  2026-09-24: `_pricing_for_model` matches by longest prefix, so `gpt-5.5` silently matches
  `gpt-5` and is priced at gpt-5's rate — no Error Log entry is written (an earlier version of this
  note said one was). Cost figures for image uploads are therefore unverified until the real price
  is added.
- **The summary card collapses line breaks** (`lab-report-summary.tsx:184`,
  `lab-result-summary-panel.tsx:188` render a plain `<p>`); the short lines read as one
  paragraph until `whitespace-pre-line` is added. Frontend change not yet approved.
- **Anthropic image model unmeasured** — run the §4 comparison on the Claude models before
  choosing a value for `anthropic_image_model`.
- **More modalities** — measure on an ECG, a CT/MRI slice and a clinical photograph before
  treating the choice as general.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-24 | Divyanshu (AI-assisted) | Corrected: gpt-5.5 is priced silently as gpt-5 by prefix match, no Error Log is written |
| 1.1 | 2026-09-24 | Divyanshu (AI-assisted) | Recorded that its prompt file and tests were removed at the owner's request |
| 1.0 | 2026-09-24 | Divyanshu (AI-assisted) | Initial version — v19, v20, v21, image model per provider (OpenAI gpt-5.5; Anthropic blank), short summaries |
