# ADR-043: An ADR's identity is its filename; historical number collisions are frozen, not renumbered

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-08-20
- **Supersedes:** —
- **Superseded by:** —

## Context

The documentation hygiene audit (2026-08-20) found the decision record structurally broken:

- **Nine numbers each identify two different decisions.** ADR-018 is cited by 61 files, ADR-020 by
  39, ADR-026 and ADR-030 by 30 each — and each of those numbers means two different things.
- **The constitution and the production code disagree on what a number means.** `CLAUDE.md` cites
  ADR-026 meaning the LLM provider allowlist; `encounter-screen.tsx` cites ADR-026 meaning
  two-part vaccine billing.
- **Three numbers were cited with no document at all** (008, 009, 040 — since written).
- **All 47 ADRs were orphaned** — `docs/adr/` had no index.
- `CLAUDE.md` §9 requires sequential numbering. It was violated seven times inside the canonical
  directory and twice more against a second, nested ADR directory.

The obvious remedy — renumber the collisions — was designed, costed, and **rejected**. Two rules for
choosing which document keeps a number (first-created vs most-cited) disagree in four of the seven
cases, and either way the work is a mass rewrite of 62–148 citations across two repositories.
Roughly 100 of those citations are bare "ADR-0NN" mentions whose intended meaning cannot be
determined mechanically.

Three reasons that remedy is worse than the disease:

1. **It converts a visible defect into an invisible one.** A bare ambiguous number makes a careful
   reader go and check. A citation confidently rewritten to point at the *wrong* decision does not.
   In a clinical system's decision record, never trade a loud defect for a quiet one.
2. **It violates `CLAUDE.md` §9's own instruction** — *"never edit a merged ADR — supersede it."* An
   ADR's number is how the entire codebase refers to it; changing it **is** editing the ADR. Calling
   renumbering "a filing correction, not a content change" is rationalisation of exactly the kind
   this codebase has been bitten by before (Rule 5 relaxed by a code comment; ADR-030's "write tools
   never touch the DB" honoured in letter while master records get written).
3. **The ambiguity is not actually load-bearing when a citation names its subject.**
   `adr-021-master-data-crud-access.md:79` cites *"ADR-003 (BFF pattern) · ADR-004 (no core DocPerm
   edits)"* — unambiguous, because it names the meaning. The defect is bare numbers, not numbers.

## Decision

**An ADR's canonical identity is its filename. Numbers are historical labels, not identifiers.**

1. **No renumbering. No edits to merged ADRs.** Every existing number and filename stays exactly as
   merged. The nine collisions are **frozen and documented**, not repaired.
2. **Cite the slug, not the number.** `adr-026-llm-provider-allowlist`, not "ADR-026". This applies
   to code comments, docs, prompts, commit messages and `CLAUDE.md`. Existing bare-number citations
   are **grandfathered** and listed in `docs/adr/README.md`.
3. **The index is mandatory.** `docs/adr/README.md` lists every ADR and names every collision, so an
   ambiguous number is always resolvable in one hop.
4. **The defect stops growing today.** `scripts/check_adr_numbering.py` runs against a recorded
   baseline (`scripts/adr_known_defects.json`) and fails CI on any **new** collision, any **new**
   phantom citation, and any ADR missing from the index.
5. **Repair only by supersession.** A collision may be resolved only the way `CLAUDE.md` §9 already
   prescribes: write a new, correctly-numbered ADR that supersedes the mis-numbered one, and mark
   the old one `Superseded by`. The old file and its number are never reused or rewritten.
6. **The nested directory stays** until `ADR-003-bff-pattern` and `ADR-004-no-core-docperm` are
   superseded under rule 5. Two clearly-documented files in a second directory is a smaller defect
   than editing two merged ADRs plus the merged ADR-021 that cites them. `adr-001` and `adr-002`
   were relocated on 2026-08-20 because their numbers were free — no renumbering was required.

## Alternatives Considered

1. **Renumber, first-created keeps the number.**
   - Pros: principled — the number belongs to whoever was assigned it first; rewards no mistake.
   - Cons: ~148 citation rewrites; changes what `CLAUDE.md`'s amendment block means for ADR-018 and
     ADR-030; requires editing merged ADRs; ~100 citations unresolvable mechanically.

2. **Renumber, most-cited keeps the number.**
   - Pros: fewest edits (~62); the constitution's citations stay correct.
   - Cons: optimises for editing volume, which is an engineering-convenience criterion, not a
     records one; still edits merged ADRs; still needs ~100 judgement calls, each a chance to point
     a citation at the wrong decision.

3. **Freeze and disambiguate by filename (chosen).**
   - Pros: no merged ADR is edited; zero risk of a silently wrong citation; the ambiguity stops
     growing immediately; discoverability is fully solved by the index; consistent with §9.
   - Cons: the historical collisions remain forever; a reader who sees a bare number must consult the
     index; the record is permanently untidy in a way a greenfield project would not be.

## Consequences

- `CLAUDE.md` §9's "Number sequentially" stands for **new** ADRs and is now enforced.
- Nine numbers are permanently ambiguous in the historical record. This is accepted, and documented
  at the top of `docs/adr/README.md`.
- Reviewers should reject new code or docs citing a bare ADR number.
- ADR-008, ADR-009 and ADR-040 were written on 2026-08-20 to close the phantom citations. ADR-009 —
  browser-direct audio to Deepgram, the privacy basis of ambient recording — is the reason this
  thread was prioritised at all.
- **Re-evaluation trigger:** if bare-number citations keep appearing despite the gate, or if a
  collision causes a real misread in review, revisit supersession for that specific pair.

## Verification

| Claim | Artefact |
|---|---|
| Index exists and lists every ADR | `docs/adr/README.md`; `check_adr_numbering.py` fails if any ADR is unlisted |
| New collisions fail CI | `scripts/check_adr_numbering.py` + `scripts/adr_known_defects.json` baseline |
| Phantom citations fail CI | same checker, phantom-citation check |
| No merged ADR was renumbered | `git log --diff-filter=R -- docs/adr/` shows only the adr-001/adr-002 relocation |

## References

- `CLAUDE.md` §9 (ADR rules, markdown provenance rule)
- `docs/audit/DOCUMENTATION_HYGIENE_AUDIT.md` §2–§4 (the evidence)
- `docs/adr/README.md` (the index and the collision table)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-20 | Sarvesh (AI-assisted) | Renumbered 042 -> 043: `adr-042-government-deferred-receivable-billing` reached origin/dev first, so it owns 042. Unpushed work adapts |
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial — freeze-and-disambiguate chosen over renumbering |
