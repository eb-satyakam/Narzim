# ADR-071: Patient-wide total pending balance, computed server-side via a real (never-saved) draft invoice — and the item-tax bug it surfaced in `create_pos_invoice`

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.1

- **Status:** Accepted
- **Date:** 2026-09-16
- **Supersedes:** — (no prior ADR governed the Command Center drawer's PAYMENT tile)
- **Superseded by:** —

## Context

Reported live, via the Command Center appointment drawer's PAYMENT tile: it showed "Unpaid MXN 1,000" — but that figure was only ever `row.expected_amount_mxn`, the *current appointment's own* consultation fee, computed with a client-side tax guess (`op_consulting_charge_tax_rate` read off the practitioner and multiplied in `mission-control-client.tsx`). A patient can owe money from other visits — other unpaid invoices, other unbilled labs/meds/procedures — none of which this figure ever reflected. The ask, repeated across two sessions: show the patient's real total pending balance, not one appointment's slice of it.

`get_patient_billables(patient)` (`services/billing.py`) already returns every un-invoiced billable line for the *whole* patient, not scoped to one appointment — the raw data existed. The missing piece was turning it into one correct, tax-inclusive number.

**A naive per-line tax calculation was rejected before being tried**, because this codebase already has a documented, live incident from exactly that mistake: `_create_reschedule_refund`'s own comment records that Healthcare's invoice builder does not always turn an item's tax template into real charged tax, and assuming otherwise cost a real 55-peso shortfall on a refund (`ACC-SINV-2026-00579`). Reusing the real invoice-computation engine — building the exact draft `create_pos_invoice` would submit, reading its computed total, and discarding the draft — was chosen specifically to never repeat that mistake.

**Building that shared path surfaced a second, live, pre-existing bug**, found only because the preview was built to *agree with reality* rather than assert its own number: `create_pos_invoice`'s invoice-building code (via the Healthcare app's `set_healthcare_services` mixin, and via `remedisys_healthcare_ai`'s own Immunization-line append) never carried each line's `item_tax_template` onto the actual Sales Invoice row. Verified live against a real patient (Isha Iyer, MRN-2026-0001437): her consultation-fee item carries a real 16% Mexico tax template; billing it through the consolidated POS checkout (`create_pos_invoice`) charged exactly 500 MXN — zero tax — while billing the *identical item* through the separate manual "New Sales Invoice" editor (`create_invoice`) correctly charged 580. Two checkout paths, two different real amounts collectible from the same patient for the same service, depending only on which screen staff happened to use.

## Decision

1. **New function `get_patient_total_pending(patient)`** (`services/billing.py`): returns `{currency, invoiced_outstanding_mxn, unbilled_total_mxn, total_pending_mxn}`.
   - `invoiced_outstanding_mxn` — `SUM(outstanding_amount)` across every submitted, non-return Sales Invoice for the patient's customer (same aggregate shape as `patients/api.py::_batch_outstanding_balance`, single-patient instead of batched).
   - `unbilled_total_mxn` — built from a real, in-memory-only Sales Invoice draft (never saved/submitted) of every line `get_patient_billables` currently returns, with `set_taxes_and_charges()` + `calculate_taxes_and_totals()` run on it explicitly (since skipping `.save()` also skips the `validate()` chain that would normally trigger tax promotion) and `grand_total` read off, then discarded.
2. **`create_pos_invoice`'s invoice-building code extracted** into a shared `_build_pos_invoice_doc(...)` helper, used by both `create_pos_invoice` (which still `.save()`s and `.submit()`s it for real) and `get_patient_total_pending` (which never does). One code path, so the preview can never silently drift from what checkout actually charges.
3. **Fixed inside that shared helper**: every healthcare-service row now has `item_tax_template` copied from the already-resolved cart line onto the Sales Invoice item row after `set_healthcare_services()` runs (that mixin — third-party, `apps/healthcare` — calls core's `get_item_details()` internally, which resolves the tax template, then discards it, copying only a fixed allowlist of other fields onto the row). The Immunization-line append (this app's own code) gained the same field for the identical reason — it never set it either.
4. **New whitelisted endpoint** `api/v1/billing/api.py::get_patient_total_pending`, gated on `require_permission("Sales Invoice", "read")` — deliberately `read`, not `create`: `EB_Nurse` has read but not create on Sales Invoice, and could already see the old client-computed estimate; requiring `create` would have been a real access regression for that role.
5. **Frontend** (`EB_Healthcare_Frontend`): new `usePatientTotalPending` hook + `/api/billing/total-pending` BFF route, and the Command Center drawer's PAYMENT tile (`mission-control-client.tsx`) rewritten. **Shows `unbilled_total_mxn`, not `total_pending_mxn`** — a deliberate, explicit choice made after shipping the combined figure first (see §"Displayed figure, revised" below) — collapsing to two states (something new to bill → show the unbilled total + Pay Now; nothing new to bill → Paid, or a neutral "not invoiced" when nothing was ever charged at all). The old client-side `op_consulting_charge_tax_rate` guess is removed entirely, not just unused. The backend still computes and returns all three figures (`invoiced_outstanding_mxn`, `unbilled_total_mxn`, `total_pending_mxn`) — only the frontend's choice of which one to display was narrowed.

### Displayed figure, revised after shipping

The combined `total_pending_mxn` (invoiced-outstanding + unbilled) was built and shipped first, exactly as described above, and verified live. Once visible, the person who asked for this asked to narrow it: show only `unbilled_total_mxn` — explicitly NOT the already-invoiced-but-unpaid portion. Asked directly, with the concrete tradeoff spelled out (a patient who owes money on a real, already-invoiced, unpaid invoice but has nothing new to bill will show as "settled" on this tile — that balance still exists on the invoice itself and in the full billing tab, just not surfaced here) — confirmed as the wanted behavior, not an oversight. This is why the backend still computes and returns the combined figure: a future screen (or a future request to widen this same tile back out) can use `total_pending_mxn`/`invoiced_outstanding_mxn` without any backend change, only a different field read on the frontend.

## Alternatives Considered

1. **Real draft-invoice engine, discarded after reading totals (chosen).**
   - Pros: Provably correct — it IS the real invoice calculation, not an approximation of it; cannot drift from what checkout actually charges, by construction; surfaced the item-tax bug instead of hiding it.
   - Cons: More code (extracting a shared helper, understanding `set_taxes_and_charges()` vs `calculate_taxes_and_totals()`) than a one-line sum.

2. **Per-line tax-rate guess** (rate × qty × item_tax_template's nominal rate, summed).
   - Pros: Simple, fast, no invoice-engine dependency.
   - Cons: **Already proven wrong in this exact codebase** (`_create_reschedule_refund`, `ACC-SINV-2026-00579`) — an item's nominal tax template does not reliably predict what a real invoice charges. Would also have completely missed the actual bug (never carrying `item_tax_template` onto the row at all), since a hand-rolled sum doesn't go through the row-building code where the bug lives.

3. **Pre-tax estimate only, labeled as such** ("~1,500, before tax").
   - Pros: Avoids claiming precision that a per-line guess can't back up, without the invoice-engine work.
   - Cons: Silently under-states what's actually owed whenever tax *does* apply (which, per this ADR, is more often than assumed) — a worse failure than not showing a number, because it invites collecting less than what checkout will actually demand.

4. **Leave the drawer showing only the current appointment's fee; add a link to the full billing tab for the true total.**
   - Pros: Zero engineering risk.
   - Cons: Doesn't answer what was asked, twice, across two sessions — the whole point was seeing the total without leaving the drawer.

## Why this approach, specifically

- **Vs. 2 (per-line guess):** loses on a documented incident, not a hypothetical — this codebase already paid for that exact mistake once. It would also never have found the real bug this work uncovered.
- **Vs. 3 (pre-tax only):** loses because under-stating a bill is a worse trust failure than a slower number; verified this session that tax is *not* always zero, so "before tax" would be actively wrong for real patients like Isha Iyer.
- **Vs. 4 (leave it, add a link):** loses because it doesn't do what was asked — the request was explicit and repeated.

## Consequences

- `remedisys_healthcare_ai/services/billing.py`: `create_pos_invoice`'s doc-building code extracted into `_build_pos_invoice_doc`; new `get_patient_total_pending`; the item-tax-template fix applies to **every future POS-checkout invoice**, not just the preview — real patients billed through consolidated checkout from now on will be charged the tax their item actually specifies, where before they were not.
- `remedisys_healthcare_ai/api/v1/billing/api.py`: new `get_patient_total_pending` endpoint.
- `EB_Healthcare_Frontend`: new `usePatientTotalPending` hook (`src/hooks/use-billing.ts`), new BFF route (`src/app/api/billing/total-pending/route.ts`), `mission-control-client.tsx`'s PAYMENT tile rewritten; the client-side tax-rate guess (`feeTaxRate`/`expectedFeeWithTax`, reading `op_consulting_charge_tax_rate`) removed entirely.
- **No historical invoices were touched or corrected.** Every Sales Invoice created via `create_pos_invoice` *before* this fix that should have carried tax and didn't is not retroactively adjusted — this ADR fixes the code path going forward only. Whether historical under-collected tax needs remediation (a credit-note-style correction, or a compliance/CFDI question) is a separate decision, not made here, and not something this session was asked to resolve.
- **Re-evaluation trigger:** if the manual invoice editor (`create_invoice`) and the POS path (`create_pos_invoice`) are ever found to disagree on tax again for some other reason, the fix belongs in `_build_pos_invoice_doc` (or a shared tax-resolution helper both paths call), not in a second one-off patch.

## Verification

- Live, read-only, against real patient data (Isha Iyer, MRN-2026-0001437 — a real existing patient with both a genuine outstanding invoice and genuine unbilled lines, not test/scratch data):
  - Before the item-tax fix: `get_patient_total_pending` returned `unbilled_total_mxn: 1500.0` (no tax) against the manual editor's real 1,580 for the identical two lines — confirmed mismatch, root-caused to `_build_pos_invoice_doc` never setting `item_tax_template`.
  - After the fix: `unbilled_total_mxn: 1580.0`, `total_pending_mxn: 2718.0` (1,138 invoiced-outstanding + 1,580 unbilled) — exact agreement with the manual editor.
  - Separately confirmed the *real* `create_pos_invoice` path (not just the preview) is fixed too: built the same draft and called `.validate()` (what `.save()` actually triggers, never calling `.insert()`/`.save()` itself) — produced `grand_total: 1580.0`, `total_taxes_and_charges: 80.0`, a real `IVA - N` tax row — proving a genuine invoice created through consolidated checkout after this fix will charge correctly, not just the preview number.
  - Confirmed `Accounts Settings.add_taxes_from_item_tax_template = 1` on this site (the flag gating whether an item tax template is ever promoted to a real header tax row) — the missing piece was carrying `item_tax_template` onto the row at all, not this site configuration.
  - Confirmed permission choice: `EB_Nurse` has `read: 1, create: 0` on Sales Invoice — `require_permission(..., "read")` was verified as the correct, non-regressing choice before shipping, not assumed.
- All diagnostic scripts (`tests/immunizations/_scratch_*.py`) were read-only or, where they touched `_build_pos_invoice_doc`'s draft, never called `.insert()`/`.save()`/`.submit()` — nothing was created, modified, or persisted on any real patient record during this investigation. All deleted after use.
- Frontend: `tsc --noEmit` clean (one pre-existing, unrelated error in `e2e/encounter-submit.spec.ts`, not touched); `npm run i18n:check` clean.

## References

- Constitution §4 Rule 1 (no core modification — `set_healthcare_services` lives in the third-party `apps/healthcare`, never patched directly; the fix lives entirely in `remedisys_healthcare_ai`'s own `_build_pos_invoice_doc`), §10 (four-approaches requirement for a financially consequential change), §9 (ADR requirement)
- `_create_reschedule_refund` (`services/billing.py`) — the prior, live incident (`ACC-SINV-2026-00579`) that ruled out a naive per-line tax assumption before this work started
- `WORK_LOG.md` 2026-09-16 entry

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-16 | Ashutosh (AI-assisted) | Decision §5 revised: the drawer shows `unbilled_total_mxn` only, not the combined `total_pending_mxn` — requested and confirmed after the combined figure was shipped and shown live; backend unchanged, still computes and returns all three figures |
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
