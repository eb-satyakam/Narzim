# ADR-104: Rx print renders an attached Canvas drawing as an `<img>`-loaded SVG, never an iframe

**Doc status:** living · **Created:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-09-30
- **Supersedes:** —
- **Superseded by:** —

## Context

Plan doc `docs/qa/encounter-v3/14-V9-ADVICE-CANVAS-CONNECT-PLAN.md` (frontend repo) lists "Rx print
shows advice and attached drawings" as build step 5, written 2026-09-29 but never built. Advice is
a plain string list — no design question there. Canvas is not.

`Encounter Canvas.canvas_data` is deliberately unsanitized HTML (ADR-097): it is exempt from
Frappe's save-time sanitizer on purpose, so an SVG-plus-embedded-stroke-JSON blob written by this
app's own frontend round-trips exactly. ADR-097 established the one safe way to *display* it —
a `sandbox=""` iframe, which blocks any planted `<script>` from executing regardless of content.

The v9 Rx print/PDF pipeline does not use that display mechanism. It rasterizes the live DOM with
`html2canvas-pro` (`encounter-report.tsx`). `html2canvas` walks the main document's render tree; it
does not descend into an iframe's separate document, sandboxed or not, without a purpose-built
plugin — it would capture a blank box where the drawing should be.

ADR-097's own Consequences section already named this exact situation as an open, un-decided
question: *"if a future requirement needs a non-Desk consumer of a canvas thumbnail that cannot
render an iframe (an email digest, **a PDF export**, a report that only accepts raster images),
that consumer will need its own rasterization step — this ADR does not provide one."* This ADR is
that consumer's decision.

ADR-097 also already named, in its own alternatives list, the one pattern it considers pre-approved
safe for exactly this shape of problem: *"a script inside an `<img>`-loaded SVG never executes, per
spec."*

## Decision

At print time, extract the `<svg>...</svg>` element from the attached canvas's `canvas_data`
(reusing `v9/data/canvas-serialize.ts`'s own parser — the same code that already round-trips this
shape for reopen-and-edit, not a fresh regex slice), wrap it as a `data:image/svg+xml;base64,...`
URI, and render it as a plain `<img>`. `html2canvas-pro` captures an `<img>` natively, same as any
other image in the report.

Only a canvas with `attach_to_rx = true` is included — the field's own stated purpose. A signed
encounter may have several saved canvases; only the attached one(s) print.

`print_mode` (`Full page` | `Compact`) is read and respected: `Full page` gives the drawing its own
report section at full width; `Compact` renders it inline, sized to fit alongside the Plan/Advice
text it accompanies.

## Alternatives Considered

*(Four approaches presented to and chosen by the user before any code changed.)*

1. **Extract SVG → `data:image/svg+xml` `<img>` (chosen).**
   - Pros: The exact pattern ADR-097 itself names as safe for a raster consumer. No backend change,
     no new stored field. `html2canvas-pro` captures `<img>` elements with no special handling.
     Reuses code already trusted to parse this shape (`canvas-serialize.ts`), not a new heuristic.
   - Cons: Needs a small, careful extractor; a malformed or unexpected `canvas_data` shape must
     degrade to "no image" rather than a broken print, never a thrown error mid-PDF-generation.

2. **Parse and re-inject the `<svg>...</svg>` markup as a live inline SVG element**, not an `<img>`.
   - Pros: Slightly crisper scaling at large print sizes than a rasterized `<img>` (browsers usually
     render inline SVG vector-perfect regardless of size).
   - Cons: ADR-097 already rejected "parse the opaque, frontend-owned schema" once, for the same
     Desk-rendering problem (its own alternative 1) — the exact fragility concern applies again
     here: it silently breaks the moment `canvas-serialize.ts`'s SVG shape changes and this second,
     independent consumer isn't updated in lockstep. Not worth the extra risk for a cosmetic gain.

3. **Make `html2canvas` capture the sandboxed iframe directly** (a plugin, or a different screenshot
   library for this one element).
   - Pros: One rendering mechanism everywhere — print would look exactly like Patient History's
     Desk view, no second code path.
   - Cons: ADR-097's own Consequences section already flags this exact mechanism as the one that
     does not reach a PDF export. Fighting the screenshot tool to do something it is not designed
     for, instead of using the pattern the same ADR already sanctioned for this case.

4. **Bring back a rasterized PNG, stored server-side, generated when `attach_to_rx` is toggled on.**
   - Pros: Most robust for any future raster consumer (email digest, external report, etc.) — a
     real file, not a client-side extraction, works everywhere without depending on the frontend's
     schema at read time.
   - Cons: ADR-095 and ADR-097 each already killed a dual-storage PNG+HTML design once, specifically
     to avoid a stale-copy problem — a PNG generated at attach-time drifts from `canvas_data` the
     moment the drawing is edited afterward without re-triggering rasterization. Reopening that
     design would need its own deliberate justification, not a side effect of a print feature.

## Consequences

- Rx print (both `SignedReportOverlay` and `EncounterReportModal`) can now show an attached Canvas
  drawing without adding an iframe to a screenshot-based pipeline that cannot capture one.
- A canvas saved with a planted `<script>` in `canvas_data` still cannot execute it here: extracting
  only the `<svg>` subtree and loading it via `<img>` means the browser parses it as an image
  resource, never as an HTML document with a script execution context — the same safety property
  ADR-097 already established for its own consumer, applied to a second one.
- `print_mode` (`Full page` | `Compact`) becomes live for the first time — it existed on the
  doctype since ADR-095/097 but nothing read it until this change.
- A canvas whose `canvas_data` cannot be parsed into a well-formed `<svg>` (corrupted, unexpected
  shape) is simply omitted from the print — never a thrown error that blocks generating the rest
  of the PDF.
- Re-evaluation trigger: if a future consumer needs the canvas's *editable* strokes at print time
  (not just a static image) — e.g., annotating on top of a previously attached drawing during
  print preview — this ADR's `<img>` approach does not provide that; it would need its own decision,
  the same way this one did.

## Verification

- `canvasDataToImgSrc()` (new, `canvas-serialize.ts`) unit-tested: a valid saved canvas → a
  `data:image/svg+xml;base64,...` string that decodes back to the same SVG markup; blank/missing
  `canvas_data` → `null`; a malformed/unexpected HTML shape → `null`, not a thrown error.
- A canvas saved with `canvas_data` containing a planted `<script>alert(1)</script>` does not
  execute it when the Rx print/PDF is generated (the script is either outside the extracted `<svg>`
  subtree and dropped, or — if placed inside the SVG itself — never executes when loaded via
  `<img src="data:image/svg+xml...">`, per the DOM spec ADR-097 already cited).
- A signed encounter with Advice lines and an `attach_to_rx = true` canvas shows both in the printed
  PDF from `SignedReportOverlay` (post-sign) and from `EncounterReportModal` (reprint later) —
  verified in-browser, not just by unit test.
- A signed encounter with a saved-but-not-attached canvas shows Advice but no drawing.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
