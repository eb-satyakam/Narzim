# ADR-045: Replace notification polling with SSE for in-app delivery and FCM for out-of-app push, behind a single `notify()` chokepoint

**Doc status:** living · **Created:** 2026-08-24 by Ashutosh (AI-assisted) · **Updated:** 2026-08-25 by Ashutosh (AI-assisted) · **Version:** 1.3

- **Status:** Accepted
- **Date:** 2026-08-24
- **Supersedes:** the **transport choice only** in
  [`adr-015-team-chat-messaging.md`](adr-015-team-chat-messaging.md) ("Polling (react-query
  `refetchInterval`) … SocketIO push is deferred") and
  [`adr-037-portal-chat-separate-thread.md`](adr-037-portal-chat-separate-thread.md) ("simple polling
  from the frontend"). Both remain in force in every other respect — their doctype shapes, threading
  models and permission rules are untouched. Neither file is edited, per `CLAUDE.md` §9: a merged ADR
  is superseded, never rewritten.
- **Superseded by:** —

## Context

Every notification in both frontends is delivered by **HTTP polling on a fixed timer**. There is no
push path of any kind. Verified 2026-08-24:

- `EB_Healthcare_EHR/src/hooks/use-notifications.ts:13` sets `POLL_INTERVAL = 30_000`, and four
  separate hooks each carry `refetchInterval: POLL_INTERVAL, staleTime: 0` — the list, the per-tab
  counts, the bell badge, and the `/notifications` screen. That is four HTTP round-trips every 30
  seconds per open tab for facts one response could carry.
- Chat surfaces poll harder: `use-portal-chat.ts:52-53`, `use-whatsapp.ts:47-48` and
  `use-team-chat.ts:51-52` each use a 15 s conversation-list poll and a 10 s thread poll. An EHR tab
  with a thread open issues roughly **44 authenticated requests per minute while idle**, each one a
  full JWT-authenticated Frappe method call through the BFF.
- The patient portal polls its chat every **5 s** (`use-my-chat.ts:9`) — 17,280 requests per device
  per day.
- Neither repo has `socket.io-client`, `pusher`, `ably` or `eventsource` in `package.json`. The only
  streaming anywhere is request-scoped SSE for AI analyze
  (`EB_Healthcare_EHR/src/components/narzim/encounter/stream/useAnalyzeStream.ts`) — and that hook is
  **dead code**: it has no callers, the route it fetches (`/api/ai/analyze-stream`) does not exist,
  and production logs show zero requests to that path in 24 h. So the stack has **no working SSE
  precedent**; this ADR's transport is new ground.

Consequences today: a staff member sees a patient's message up to 30 s after it exists, and the row
reads "30 seconds ago" the instant it appears, which reads as a broken system.

**Four facts about the stack constrain the choice.** All verified against this bench on 2026-08-24:

1. **Frappe's SocketIO server is already running and our JWT can authenticate it.** `bench socketio`
   is in the Procfile, `socketio_port: 9000` and `redis_socketio` are set in
   `sites/common_site_config.json`, and `apps/frappe/realtime/middlewares/authenticate.js:31-45`
   accepts **either** a `sid` cookie **or** an `Authorization` header, forwarding it to
   `frappe.realtime.get_user_info`. Since `eb_frappe_jwt`'s `auth_hooks` sets `frappe.session.user`
   from a Bearer token, a JWT-authenticated socket connects.
2. **But a browser cannot use that socket in our topology, for three independent reasons.**
   `authenticate.js:22` rejects the connection when `get_hostname(host) != get_hostname(origin)`, and
   the frontends run on Vercel (and `marley.local:8003` locally) against a different Frappe host.
   Browsers cannot set an `Authorization` header on a WebSocket upgrade at all. And `FRAPPE_URL` in
   the EHR's environment is deliberately **not** `NEXT_PUBLIC_` — under the BFF pattern
   (`adr-010-nextjs-frontend-vercel`, `adr-011-auth-eb-frappe-jwt`) the browser holds no Frappe URL
   and no JWT. Giving it one to open a socket would reverse a settled decision.
3. **Frappe v16 ships managed push, unwired.** `apps/frappe/frappe/push_notification.py` implements
   `add_token(user_id, fcm_token)` and `send_notification_to_user(...)` against a `notification_relay`
   service whose address comes from `frappe.conf.get("push_relay_server_url")` — **currently unset on
   every site here** — gated by the `Push Notification Settings` single doctype
   (`enable_push_notification_relay`, `api_key`, `api_secret`). Nothing in `remedisys_healthcare_ai`
   references it. Because the relay address is a config value, we choose who sits in the chain.
4. **A backgrounded native app cannot hold any connection.** iOS terminates network connections when
   an app backgrounds and kills the process under memory pressure. No transport choice avoids this;
   reaching a closed app requires APNs/FCM. This splits the problem into two, addressed separately
   below.

**Two further facts set the scope.** The patient portal will get a **React Native** application; the
staff EHR remains **web-only**. And the portal is already a PWA — `src/app/manifest.ts` with
`display: standalone`, a service worker registered at `pwa-controls.tsx:18`, an install prompt, and a
`notificationclick` handler at `public/sw-custom.js:62` — but **no `push` listener**, so the plumbing
is dug and unfinished.

**Finally, notification fan-out is already fragmented on the backend**, which is the strongest
argument for a chokepoint. At least three sites create `Notification Log` rows independently and have
already drifted:

- `api/v1/patient_portal/chat.py:333` respects `is_notifications_enabled(user)`, uses `type="Alert"`
  deliberately (the one type Frappe never emails, which is what makes naming the patient safe), and
  upserts so a chatty patient produces one row showing their latest message.
- `integrations/whatsapp/chat_api.py:730` is a raw inline `frappe.get_doc` with no preference check,
  no dedupe, and a hardcoded English subject not wrapped in `_()` — a visible defect in an `es-MX`
  deployment.

Adding per-platform notification logic on top of that would take three inconsistent implementations
to six.

## Decision

**Deliver notifications through one backend chokepoint with two transports: SSE for in-app live
delivery, and Firebase Cloud Messaging for out-of-app push. Adopt FCM only — no other Firebase
product. Delete all notification polling.**

1. **One chokepoint.** A single service function — `notify(recipients, event_type, ref_doctype,
   ref_name, link, **fields)` in `services/notifications.py` — becomes the only way any feature raises
   a notification. It writes the `Notification Log` row, publishes on the SSE channel, and enqueues
   push. Direct `Notification Log` creation outside it is forbidden, mirroring the existing rule in
   `api/ai/realtime.py` that all realtime emits go through `publish_to_encounter`.
2. **In-app: SSE relayed through the BFF.** A Next.js route handler holds the upstream connection to
   Frappe and re-emits to the client as `text/event-stream`. The browser never holds a JWT, the
   connection is same-origin, and Frappe stays private behind the BFF. This preserves
   `adr-010-nextjs-frontend-vercel` and `adr-011-auth-eb-frappe-jwt` unchanged.
3. **Out-of-app: FCM, called directly from the backend.** Our own Firebase project, FCM HTTP v1, with
   our own device-token registry. Frappe's `notification_relay` is **not** used, and
   `push_relay_server_url` stays unset.
4. **FCM only.** Firebase Auth, Firestore, Realtime Database and Cloud Functions are explicitly
   rejected. `eb_frappe_jwt` remains the only identity provider (ADR-011) and MariaDB the only source
   of truth (`adr-006-mariadb-for-ci`). No clinical data may be stored in a Firebase product.
5. **Push payloads are content-free — normative.** A push carries a **generic** title, an empty body,
   and identifiers only. It never carries a patient name, a message preview, a diagnosis, a
   medication, or any other PHI. The client receives the ping and fetches the real content over our
   authenticated API. This is a hard rule under Constitution Rule 10, because push payloads render on
   lock screens and transit Google.
6. **One token registry, one send path.** A new `Push Device Token` doctype holds `user`, `token`,
   `platform` (`Web`/`iOS`/`Android`), `app` (`Portal`/`EHR`), `last_seen` and `active`. Because web
   and React Native both produce FCM registration tokens, the server has a single send path and never
   branches on platform for delivery.
7. **Platform differences are thin client adapters, not separate logic.** Browser: Firebase JS SDK +
   the existing service worker. React Native: `@react-native-firebase/messaging`. Roughly 40–60 lines
   each, covering permission, token acquisition, foreground receipt, background receipt and tap
   handling. Steps 1–3 of a notification (event, recipients, persistence) are never duplicated.
8. **Browser push is scoped to the patient portal initially.** The portal is already a PWA and push is
   its primary channel. The EHR gets SSE only, keeping a Google-controlled script off pages that
   render whole patient charts. Adding EHR browser push later requires no backend change — but see
   the CSP condition in Consequences.
9. **Polling is removed, not merely supplemented.** Every `refetchInterval` in the notification and
   chat hooks listed in Context is deleted once its SSE channel is live. A poll left in place beside a
   push channel doubles the load it was meant to remove.

## Alternatives Considered

Two axes had to be decided. Both are recorded, because a reader who sees only the conclusion cannot
tell whether the losing options were costed.

### Axis 1 — in-app live delivery

1. **Tuned polling — shorten the intervals, coalesce the four notification hooks into one.**
   - Pros: no new transport, no new failure mode, hours of work; coalescing the four hooks is a real
     win worth taking regardless.
   - Cons: does not solve the problem, only trades latency against load; on a React Native client,
     5 s polling means 17,280 requests per device per day and measurable battery drain. Rejected as
     the answer, adopted as an incidental cleanup.

2. **Client connects directly to Frappe SocketIO** with a Bearer JWT, generalising the existing
   `publish_to_encounter` chokepoint.
   - Pros: server side already built and running; native clients *can* set both `Origin` and
     `Authorization`, so this works cleanly for React Native; Frappe's own permission model gates the
     rooms; no new infrastructure.
   - Cons: blocked for browsers by all three reasons in Context fact 2 — the hostname check, the
     WebSocket header limitation, and the BFF token boundary; would leave two different transports
     for web and native; exposes Frappe directly to every client.

3. **SSE relayed through the BFF (chosen).**
   - Pros: preserves the BFF absolutely — browser never holds a JWT, same-origin, no CORS; **one
     transport for all clients**, since SSE is plain HTTP and is easier to consume in React Native
     than a WebSocket; reconnection with `Last-Event-ID` replay is part of the protocol; Frappe
     stays private.
   - Cons: holds a long-lived connection per open tab in the Next server. Vercel's default
     `maxDuration` is **300 s** (verified 2026-08-24; neither frontend sets `maxDuration` or ships a
     `vercel.json`, so both run on the default), so the stream is cut mid-frame every 5 minutes and the
     client reconnects — acceptable, because SSE reconnects natively and `Last-Event-ID` replays from
     `Notification Log`. The **larger** cost is concurrency, not duration: every open tab holds a
     function invocation for as long as it stays connected (20 staff x 8 h is roughly 4,800
     function-hours/month), and raising `maxDuration` does **not** reduce that — only **Fluid
     Compute**, which lets one instance serve many mostly-idle connections, does. Also
     one-directional, though sends already go over POST; and it makes the BFF stateful, which it is
     not today.

4. **Dedicated realtime gateway** — Pusher/Ably/Supabase Realtime, or finally building the FastAPI WS
   service that Rule 3 describes.
   - Pros: purpose-built for presence, fan-out and per-connection scaling; native SDKs already
     written; offloads connection state off both Vercel and Frappe.
   - Cons: routes patient identifiers through a third party, requiring data-processing-terms review
     against **both** the `mx` and `in` ComplianceProfiles (`adr-018-multi-jurisdiction-compliance`); per-connection pricing across
     every clinic; reopens the Rule 3 split that `adr-005-frappe-cloud-deployment-suspend-rule-3` deliberately suspended; largest change for
     a problem the stack can already solve.

### Axis 2 — out-of-app push

1. **Our own Firebase project, FCM called direct from the backend (chosen).**
   - Pros: exactly one external party; full control of every payload byte, which is what makes the
     content-free rule enforceable; free at any volume we will reach; covers web, iOS and Android from
     one integration; stays inside the Frappe app, honouring `adr-005-frappe-cloud-deployment-suspend-rule-3`.
   - Cons: we write the token registry, retry and token-invalidation handling — about one doctype and
     150 lines; iOS needs an APNs auth key uploaded to Firebase; Google becomes a sub-processor
     needing the data-terms check that `adr-026-llm-provider-allowlist` established as precedent.

2. **Frappe's `notification_relay`, self-hosted.**
   - Pros: `frappe/push_notification.py` works as-is with near-zero code in our app; the relay handles
     tokens, topics and retries; no third party beyond Google.
   - Cons: a second service to operate, contradicting `adr-005-frappe-cloud-deployment-suspend-rule-3`'s "everything in-app on Frappe Cloud";
     Firebase is still underneath, so it removes nobody from the chain and only adds a hop; identical
     compliance surface to option 1 for strictly more operational cost.

3. **Frappe's hosted relay** — set `push_relay_server_url` to their service.
   - Pros: fastest possible; configuration only, no code, no Firebase project, no infrastructure.
   - Cons: inserts Frappe as a **second** sub-processor on top of Google, so two data-terms reviews
     under `adr-018-multi-jurisdiction-compliance` instead of one; notification titles and bodies transit a shared service whose
     retention and logging we do not control; opaque failure modes on a clinically relevant path.

4. **Web Push via the VAPID standard, no Google at all** (`pywebpush` + the existing service worker).
   - Pros: no vendor account; W3C standard; payloads are end-to-end encrypted by the specification, so
     no intermediary can read them — the strongest privacy story available.
   - Cons: **cannot reach an App Store or Play Store application**, which is precisely the stated
     future; iOS requires home-screen installation and is unreliable; no migration path to native. Its
     one real advantage — payload encryption — is largely nullified by decision 5, which puts nothing
     sensitive in the payload.

### Why the chosen pair wins

Axis 1 goes to SSE because it is the only option that delivers push to a browser *without* reversing
the BFF token boundary, and it happens to be the easier transport to consume from React Native as
well — one transport, all clients. Direct SocketIO loses on three independent blockers, any one of
which is fatal for web; it remains the correct optimisation for React Native later, and decision 2
does not preclude it. A third-party gateway is technically strongest and loses on compliance cost
alone: it adds a sub-processor under two jurisdictions to solve a problem for which the socket server
is already running and already accepts our tokens.

Axis 2 goes to direct FCM because Android has no alternative, so the only question was who else joins
the chain. The self-hosted relay adds a service without removing Google; the hosted relay adds Frappe
as a second sub-processor for the same end result; and VAPID-only cannot reach the native apps that
are the reason this ADR exists. Decision 5 is what makes the remaining Google exposure acceptable —
a device token, an event type and a timestamp.

## Consequences

**Constitution and prior ADRs.**

- `adr-010-nextjs-frontend-vercel` and `adr-011-auth-eb-frappe-jwt` are **preserved unchanged** —
  decision 2 exists specifically so the browser never holds a JWT.
- `adr-005-frappe-cloud-deployment-suspend-rule-3` is preserved: no sidecar service is introduced. Both transports run from the Frappe app
  and the existing BFF.
- Rule 3 stays suspended. Rule 7 (AI/infrastructure failure must not break healthcare) and Rule 10
  (no PHI in logs) both bind this work; decision 5 is Rule 10 applied to payloads.
- `CLAUDE.md` §3's `State machine`/realtime rows need no change. No locked assumption is broken.
- Google/FCM joins the external-vendor set and requires the same data-terms check
  `adr-026-llm-provider-allowlist` requires of an LLM provider.

**Code to be written.**

- `services/notifications.py` — the `notify()` chokepoint.
- `services/push.py` — FCM HTTP v1 client, content-free payload builder, token pruning.
- `remedisys_healthcare_ai/doctype/push_device_token/` — the registry.
- `api/v1/notifications/api.py` — add `register_device_token`, `unregister_device_token`, and the SSE
  subscribe/authorize method.
- Migrate the fan-out sites named in Context onto `notify()`, fixing the unwrapped English string at
  `integrations/whatsapp/chat_api.py:733` in passing.
- Frontend: one SSE route handler per BFF; a `push` listener in `EB_Healthcare_PatientPortal/public/sw-custom.js`;
  and a fix to `sw-custom.js:62-67`, which currently hardcodes `openWindow("/")` and discards the deep
  link the backend already produces (`chat.py:452`).
- Delete every `refetchInterval` in the notification and chat hooks listed in Context.

**Operational.**

- A Firebase project, an APNs auth key, and a service-account credential in environment variables
  only — never in the repo (`CLAUDE.md` §9 Secrets).
- FCM token invalidation must be handled: tokens expire, and unpruned dead tokens make send-failure
  rates grow without bound. `last_seen`/`active` on the registry exist for this.
- **A CSP is a precondition for EHR browser push.** Neither frontend has a
  `Content-Security-Policy` today. Loading a Google SDK into pages that render patient charts without
  one is not acceptable; the portal-only scope in decision 8 avoids this for now, and the CSP gap is
  a pre-existing defect worth its own ticket regardless.

**Re-evaluation triggers.**

- Product requires message previews or actionable quick-replies on the lock screen → decision 5
  breaks, and a data-processing agreement with Google actually covering PHI is required before
  shipping it.
- ~~**Fluid Compute is unavailable, or held-connection function-hours do not fit the plan.**~~
  **Resolved 2026-08-25:** Fluid Compute is enabled on the Vercel Pro project, so mostly-idle SSE
  connections share instances rather than occupying one each. This was the cost risk that could have
  inverted option 4's main disadvantage — a per-connection gateway being cheaper than serverless
  function-hours. It no longer applies. The trigger survives in one form: **if Fluid Compute is ever
  disabled, the SSE connections must be re-costed before that lands.**
- SSE proves unable to hold a usable stream on Vercel's runtime → revisit Axis 1, where the fallback
  is option 4 (dedicated gateway) or moving the BFF off serverless — **not** option 2.
- Staff need out-of-app alerts (a lone receptionist covering evenings with the tab closed) → EHR
  browser push, gated on the CSP above.
- A third client appears (a staff mobile app) → no backend change should be needed. If backend work is
  required, the layering in decisions 1 and 6 has been violated.

## Verification

The decision is in force when all of the following hold:

1. `grep -rn "refetchInterval" src/hooks/use-notifications.ts` returns **nothing** in both frontends,
   and the notification and chat hooks named in Context carry no interval.
2. `grep -rn '"Notification Log"' --include=*.py remedisys_healthcare_ai/` shows creation only inside
   `services/notifications.py` (reads in `api/v1/notifications/api.py` are expected).
3. `frappe.conf.get("push_relay_server_url")` is unset and `Push Notification Settings.enable_push_notification_relay`
   is 0 — proving decision 3's "not via Frappe's relay".
4. A test asserts the FCM payload builder never emits a patient name, message content, or any field
   outside the allow-listed keys — decision 5 enforced in code, not prose. This is the single most
   important test in the change.
5. An integration test asserts a patient message produces exactly **one** `Notification Log` row per
   recipient across repeated sends (the upsert behaviour), and that marking read on one client clears
   it for all.
6. Rule 7 test: with FCM credentials revoked and the SSE route returning 500, both apps still load,
   the bell still renders from `Notification Log`, and no clinical action is blocked.
7. `docs/PUSH_NOTIFICATIONS.md` exists and describes the built system, not the intended one.

**Conditions before the first production send** — the decision is accepted, but deployment is gated on:

- the Google/FCM data-terms check against both the `mx` and `in` ComplianceProfiles (`adr-018-multi-jurisdiction-compliance`),
  recorded the way `adr-026-llm-provider-allowlist` records its equivalent. **Status: not started.**
- the SSE-on-Vercel checks. **Duration: RESOLVED** — 300 s default (2026-08-24). **Streaming vs
  buffering: still UNVERIFIED**, and it is the fatal-if-true case — a buffered response means SSE
  cannot work at all, which is a different failure from "reconnect every 5 minutes". **Fluid
  Compute / function-hour cost: UNVERIFIED.** See `docs/PUSH_NOTIFICATIONS.md` "Open items".

## References

- `CLAUDE.md` §3 (locked assumptions), §4 Rule 7 and Rule 10, §9 (secrets, feature flags), §10
- [`adr-005-frappe-cloud-deployment-suspend-rule-3.md`](adr-005-frappe-cloud-deployment-suspend-rule-3.md) — no sidecar services
- [`adr-010-nextjs-frontend-vercel.md`](adr-010-nextjs-frontend-vercel.md) — BFF pattern
- [`adr-011-auth-eb-frappe-jwt.md`](adr-011-auth-eb-frappe-jwt.md) — tokens stay server-side
- [`adr-018-multi-jurisdiction-compliance.md`](adr-018-multi-jurisdiction-compliance.md) — the two active jurisdictions
- [`adr-026-llm-provider-allowlist.md`](adr-026-llm-provider-allowlist.md) — precedent for a vendor data-terms check
- [`adr-037-portal-chat-separate-thread.md`](adr-037-portal-chat-separate-thread.md) — the channel this first serves
- [`adr-043-adr-identity-is-the-filename.md`](adr-043-adr-identity-is-the-filename.md) — why this is 045, not 038
- [`../PUSH_NOTIFICATIONS.md`](../PUSH_NOTIFICATIONS.md) — the end-to-end mechanism
- `apps/frappe/realtime/middlewares/authenticate.js` · `apps/frappe/frappe/push_notification.py`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-08-25 | Ashutosh (AI-assisted) | Records that this supersedes the polling transport chosen in adr-015 and adr-037 — those files left untouched per §9 |
| 1.2 | 2026-08-25 | Ashutosh (AI-assisted) | Fluid Compute confirmed enabled; the concurrency-cost re-evaluation trigger is resolved and narrowed to "if it is ever disabled" |
| 1.1 | 2026-08-24 | Ashutosh (AI-assisted) | Vercel duration measured (300 s default); removed an incorrect claim that useAnalyzeStream.ts is a working SSE precedent (no callers, route absent, zero requests in 24 h); added the concurrency / Fluid-Compute cost risk |
| 1.0 | 2026-08-24 | Ashutosh (AI-assisted) | Initial version |
