# ADR-063: Clinical Command Center — inline reassignment, per-room stage logging, and role-based tips

**Doc status:** living · **Created:** 2026-09-09 by Divyanshu (AI-assisted) · **Updated:** 2026-09-10 by Divyanshu (AI-assisted) · **Version:** 1.11

- **Status:** Accepted
- **Date:** 2026-09-09
- **Supersedes:** —
- **Superseded by:** —

## Context

The **Live Queue** screen (`EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx`,
backed by `remedisys_healthcare_ai/api/v1/dashboard/api.py::get_dashboard_data`) is a five-column Kanban
board — **Arriving Soon · Waiting Room · Nursing Room · Practitioner Room · Checkout** — showing every
appointment moving through today's clinic day. The product owner requested four changes to this screen in
one request, discussed and scoped in detail with the AI assistant before this ADR was written:

1. Let staff change the assigned practitioner directly from a card on the board, not only from the
   Appointments screen.
2. Record how long each visit spends in each of the five rooms, so it can be reported on later.
3. Show short, role-specific tips on the dashboard, built from the data already being shown, to help each
   role (Front Desk, Nurse, Practitioner, Admin) manage their day.
4. Rename "Live Queue" to "Clinical Command Center" in the UI.

**Room placement is entirely computed at read time today, from two existing signals, and nothing is
stored about how a visit got there or how long it stayed:**

```
arriving_soon        Patient Appointment.status == "Open"
waiting_room         Patient Appointment.status == "Confirmed"
nursing_room         Patient Appointment.status == "Checked In"
practitioner_room    a Draft (docstatus 0) Patient Encounter exists for the appointment
checkout             a submitted (docstatus 1) Patient Encounter exists for the appointment
```

(`dashboard/api.py:203-241`, room-building logic at `dashboard/api.py:463-711`.) This derivation logic is
the **one and only place** that decides "which room is this visit in" today — a fact worth stating
explicitly, because it is the reason this ADR does not build a second way of answering that question (see
Alternative 4 below).

**Practitioner reassignment already exists, fully built, and already carries the exact restriction this
feature must keep.** `reassign_appointment(appointment, practitioner)`
(`api/v1/appointments/api.py:2320`) is whitelisted, role-gated to `_REASSIGN_ROLES` = admin roles ∪
`{EB_Front Desk, EB_Nurse}` (line 2315), and status-gated to `_REASSIGNABLE_STATUSES` = `{Scheduled, Open,
Confirmed, Checked In}` (line 2310) — i.e. **Arriving Soon, Waiting Room, and Nursing Room only**. It
additionally blocks once any non-cancelled `Patient Encounter` exists for the appointment (lines
2359-2372), per its own docstring: *"the appointment is the single source of truth for who owns the visit
... before an encounter exists; the encounter then inherits the new practitioner natively — start_encounter
does not re-attribute"* — an existing rule from ADR-018, not something this ADR introduces. **This was
explicitly re-confirmed with the product owner during scoping: the lock stays exactly as it is. No
reassignment once an encounter exists, in Practitioner Room or Checkout, under any circumstance, and no
new mechanism to propagate a reassignment into an existing encounter.** A frontend `ReassignDialog` for
this same endpoint already exists on the Appointments screen, but its trigger button is currently commented
out (`"Reassign provider — temporarily disabled per request"`, `appointments-client.tsx:436-445`, commit
`e0f5d79a`, 2026-07-03) with no reason recorded anywhere. This ADR does not investigate or reverse that —
the Live Queue's inline control described below is a different UI, in a different location, and does not
depend on that dialog being re-enabled.

**Nothing today records how long a visit spends in a room.** No child table, no `on_update`/`on_change`
hook writing a timestamp, no custom field for this purpose exists anywhere in `fixtures/custom_field.json`.
The one adjacent, already-shipped metric — `custom_checked_in_at` (stamped by `check_in_patient()`,
`api/v1/appointments/api.py:2260-2262`) feeding `get_queue_wait_times`
(`api/v1/appointments/report.py:1345-1421`) — measures one coarse number per visit: arrival → seen by the
doctor. It does not, and after this ADR still will not, break that number down by room. **This ADR does not
touch `custom_checked_in_at` or `get_queue_wait_times` — both keep working unchanged.**

**No existing pattern exists for role-based dashboard tips.** The only UI in this codebase resembling a
"tip card" is `SuggestionCard.tsx`, the AI Encounter Copilot's clinical suggestion component — a different
domain (LLM-driven clinical suggestions inside an encounter), not a dashboard widget, and not reused here.

**Naming collision, identified during scoping and explicitly accepted by the product owner.** A separate,
already-shipped feature is named **"Command Centre"** — the admin-only, multi-clinic aggregate dashboard
tab (`get_command_center`, `dashboard/api.py:994`; `command-centre-panel.tsx`; see the saved design note in
[[project_command_center_api]]). It is architecturally unrelated to the single-clinic operational Live
Queue board this ADR modifies. Renaming Live Queue to "Clinical Command Center" will read, to anyone who
has seen both screens, as the same feature. **The product owner was told this explicitly and chose the
full name "Clinical Command Center" anyway — this is a knowingly accepted risk, not an oversight.**

## Decision

**Ship all four changes as one initiative on the Live Queue screen, reusing existing backend mechanisms
wherever they already exist (reassignment), adding one new lightweight logging table for room-timing
(decision 2), and building the tips panel and rename as scoped, reversible, frontend-only work (decisions
3 and 4).**

### 1. Inline practitioner reassignment on the queue card

No backend change. The existing `reassign_appointment` endpoint already enforces every rule this feature
needs (role gate, status gate, encounter-exists block) — this decision is a new **frontend-only** entry
point into that same endpoint, shaped exactly as specified by the product owner:

```
Staff clicks the practitioner's name/avatar on a card
                    │
                    ▼
   A compact picker opens: every OTHER active practitioner
   (current one excluded, matching ReassignDialog's existing convention)
                    │
                    ▼
        Staff selects a name → an explicit confirm step
        ("Reassign this visit to Dr. X?") — no silent apply
                    │
                    ▼
   POST reassign_appointment(appointment, practitioner)   [existing endpoint — see the
                                                            2026-09-09 correction below:
                                                            this stopped being fully
                                                            "unchanged" the same day]
                    │
                    ▼
        Card re-renders with the new practitioner's name
```

- Available only on cards in **Arriving Soon, Waiting Room, Nursing Room** — the picker control simply
  does not render on Practitioner Room / Checkout cards, matching `_REASSIGNABLE_STATUSES` exactly. This is
  enforced by the backend regardless (a 409 if bypassed), but the control should not be offered where it
  cannot succeed.
- Gated to the same roles the backend already requires (`Capabilities.reassign`, already defined per-role
  in `src/lib/narzim/roles.ts:28` and already matching `_REASSIGN_ROLES` — confirmed identical during
  scoping, no drift to fix).
- **Corrected during implementation:** this section originally said the control would be "wired into
  `QUEUE_ACTION_CAP`" (`mission-control-client.tsx:566`). Before wiring anything into it, a grep across the
  file showed `QUEUE_ACTION_CAP` and its companion import `canDoAction` are both **dead code** — defined
  and imported, never actually called anywhere in this file. The live per-room role gate every other room
  control actually uses is `canActOnRoom`/`ROOM_ROLES`. The reassign control is gated by `canActOnRoom`,
  restricted to a new `REASSIGNABLE_ROOMS` set (arriving_soon/waiting_room/nursing_room, matching
  `_REASSIGNABLE_STATUSES`), and does not touch `QUEUE_ACTION_CAP` at all. No new architecture — this
  still follows the same established per-room gating convention every other action on this screen uses,
  just via the mechanism that is actually live rather than the one this ADR assumed was.
- **Correction, 2026-09-09, found live via a real reassignment (`HLC-APP-2026-00326`), reported by the
  product owner from a screenshot:** `reassign_appointment` was **not actually unchanged** — it had two
  real, pre-existing defects, both closed the same day:
  1. **Stale title.** Core's `Patient Appointment.title` ("{patient} with {practitioner}", computed by
     `set_title()`, `patient_appointment.py:120-124`) only ever recomputes inside `validate()`.
     `reassign_appointment` writes through `frappe.db.set_value` instead of `doc.save()` — because
     `practitioner` is `set_only_once` in core, and a real save would reject the change — so `validate()`,
     and therefore `set_title()`, never runs. The Desk heading/breadcrumb stayed on the OLD practitioner's
     name **permanently** after every reassignment. Fixed by computing `title` the same way `set_title()`
     does and adding it to the same `db.set_value` call that already refreshes `practitioner_name` (which
     had already been identified as needing the same manual-refresh treatment — `title` was simply missed).
  2. **No slot-safety check on the new practitioner at all.** `reassign_appointment` swapped the
     practitioner with zero check that the new one could actually take the slot — no holiday/leave/
     self-declared-Unavailable/schedule-coverage check (`assert_bookable`, ADR-062 — already used by
     booking creation and reschedule, at this exact file's lines 1107 and 2292), and no double-booking
     check (core's own `validate_overlaps()`, which also never runs since `validate()` is bypassed the same
     way as (1)). The reschedule endpoint's own code even already commented on half of this gap
     ("this endpoint doesn't reassign") without closing it. Fixed by calling `assert_bookable` for the new
     practitioner, and calling `doc.validate_overlaps()` directly (in-memory `doc.practitioner` mutation,
     never saved — so it runs core's own tested overlap logic without ever touching the framework's generic
     `set_only_once` check, which only fires inside the full `Document._validate()` pipeline that this
     write path exists specifically to avoid) — both before the swap, not after.
  New regression tests: `tests/appointments/test_reassign_availability_guard.py`, 3 tests, all passing live
  against `remedisis.localhost`, alongside the 12 pre-existing mock-based reassign tests
  (`test_visibility_reassign.py`), also re-run and still green.
- **Addition, same day, then redesigned the same day again — show the slot in the picker, not only after
  clicking Reassign.** First cut: a new read-only `get_reassignment_candidates(appointment)` that ran
  `assert_bookable`/`validate_overlaps` against the appointment's *own original slot* for every candidate.
  **Rejected on sight — "no this is not good, show the list of all practitioner and as we select than show
  the all available slot user select the slot and than reassign."** The actual requested flow is a
  3-step picker, not a same-slot-only check:

  ```
  Step 1  Pick a practitioner from a list — every active one is offerable
  Step 2  See THAT practitioner's real open slots for the day (may differ from the original time)
  Step 3  Pick a slot; if the fee differs, settle it (additional payment or refund); confirm
  ```

  This turned out to need almost no new backend at all — two already-existing, already-tested pieces cover
  steps 2-3 completely:

  - **Step 2** reuses `get_available_slots(practitioner, date)` verbatim (the exact function the normal
    booking screen's own slot picker already calls) — it already merges holidays/leave, self-declared
    Unavailable windows, real conflicting appointments, and ADR-062 Available overrides into one filtered
    slot list, so nothing new needed inventing there.
  - **Step 3's commit** uses `reschedule_appointment_with_payment`, not `reassign_appointment` — that is the
    function that actually supports changing practitioner AND date/time together (it already existed, doing
    most of the work for the "Book Appointment drawer, reused for reschedule" flow). **Confirmed with the
    product owner before building on it:** this function can trigger a real charge or refund if the new
    doctor's fee differs from the old one — the product owner's explicit instruction was, at the time,
    **"only show slots where the fee is unchanged,"** not the fuller pay-now/pay-later flow the Appointments
    screen's own reschedule drawer exposes. **Superseded the same day — see the fee-difference revision
    below.**

  **Step 1 is what `get_reassignment_candidates` became**, rewritten from "checks the original slot" to
  "checks the fee": lists every active practitioner (excluding the current one) and, per candidate, compares
  `_reschedule_quote(doc, candidate, doc.appointment_type)`'s `old.fee_incl_tax` against `new.fee_incl_tax`
  directly. **A real bug found and fixed while writing the FIRST test for this:** the naive approach —
  reading `quote["adjustment"]["type"]` — is wrong for this purpose. `adjustment` answers "is money owed
  given what has already been PAID," not "did the fee change" — for a never-invoiced appointment (every
  Arriving Soon/Waiting Room card, before checkout), nothing paid yet reads as the *entire new fee* being
  owed, regardless of whether the fee actually moved. Comparing the two fee quotes directly is the correct
  check; `adjustment` is answering a different question that happens to look similar.

  **Fee-difference revision, same day: "go with payment too as we are doing in the reschedule."** The
  fee-parity gate above lasted less than a day. The product owner's follow-up instruction reopened it:
  reassigning to a different-fee practitioner should be allowed, with the difference settled the *same way*
  a normal reschedule already settles one — an additional payment (collectible now or deferred to checkout)
  or an immediate refund via Credit Note, never a silent block. Two genuinely different ways to satisfy that
  were weighed:

  | Approach | Pros | Cons |
  |---|---|---|
  | A. Replace `QueueReassignDialog` with the existing `RescheduleDialog` (`NewAppointmentDialog`, `dialogMode="reschedule"`) | Zero new payment code — literally the same component the Appointments screen's reschedule already uses | Reopens a bigger surface (date/appointment-type change) than the reassign-only 3-step picker the product owner explicitly designed in the redesign above; a second, larger UI swap the same day |
  | B. Keep the 3-step picker, add a step 3 payment block reusing the reschedule preview/settlement hooks (chosen) | Preserves the exact picker UX already approved; reuses the same tested backend (`preview_reschedule_payment`, `reschedule_appointment_with_payment`) and the same frontend hooks (`useReschedulePaymentPreview`, `usePaymentMethods`) `NewAppointmentDialog` already uses, so the money math and copy cannot drift between the two dialogs | A second, smaller copy of the payment-step JSX exists in `mission-control-client.tsx`, not one shared component |
  | C. Backend-only: drop the fee gate, always settle "pay later" (deferred to checkout), no payment UI in the dialog at all | Smallest diff | Does not actually implement "payment too" — front desk could never collect an additional payment on the spot the way the reschedule drawer already allows, which is what "as we are doing in the reschedule" asked for |
  | D. Add a `fee_override` field so front desk can negotiate a rate instead of settling the real delta | Not requested; introduces an unrelated negotiated-rate concept | Out of scope, adds a decision nobody asked for |

  **B, confirmed with the product owner via an explicit either/or before building** ("Keep the 3-step
  reassign dialog, add a payment step" vs. "Replace it with the full Reschedule drawer" — answer: "Keep in
  same Modal only"). A lost because it discards the picker UX the product owner had just finished specifying
  in detail; C loses because a silent "always defer" is not "payment too," it is half of it; D was never
  asked for.

  **What changed, concretely:**
  - `get_reassignment_candidates`: `available` no longer goes `False` on a fee difference — only on a real
    data error. Two new response fields, `same_fee` (bool) and `fee_incl_tax` (float), are returned as a
    non-blocking hint the step-1 list shows next to each name ("Fee differs") rather than a block. The
    authoritative number remains `preview_reschedule_payment`, called once a practitioner is picked.
  - `QueueReassignDialog` (`mission-control-client.tsx`): step 2 (slot picking) gained a step 3, appearing
    once a slot is chosen, that calls `useReschedulePaymentPreview` (the same hook `NewAppointmentDialog`'s
    reschedule mode uses) and — when the adjustment is not `"None"` — shows the amount, a Pay Now/Pay Later
    toggle (`usePaymentMethods` for the mode-of-payment select), and a refund note, mirroring
    `NewAppointmentDialog`'s existing payment-step copy and layout exactly (same `newAppt` i18n keys — no new
    strings needed for the payment step itself, only for the step-1 fee-differs badge). Confirm now calls
    `useRescheduleWithPayment` (replacing the earlier raw `fetch` call) with `payment_timing`/`mode_of_payment`
    computed the same way `RescheduleDialog`'s `confirm()` does.
  - No backend change to `reschedule_appointment_with_payment` or `_reschedule_quote` — both already handled
    an arbitrary fee delta end-to-end; the gate being removed was frontend-facing only (`get_reassignment_candidates`).

  Two of the seven existing regression tests were updated for the new semantics rather than left describing
  a rule that no longer holds: `test_candidates_marks_different_fee_practitioner_unavailable` became
  `test_candidates_marks_different_fee_practitioner_still_available`, asserting `available=True`,
  `same_fee=False`. All 7 tests re-run and green.

  **Reversed again, same day: "do not show fee differ."** The `same_fee`/"Fee differs" badge above lasted a
  few hours. The product owner's next instruction removed it — the fee difference should not be surfaced
  twice, once as a step-1 hint and again as the step-3 preview; it is shown exactly once, in step 3, once a
  practitioner AND a slot are both picked. **What changed:** `get_reassignment_candidates` was simplified
  back to a plain active-practitioner listing — no `_reschedule_quote` call per candidate, no per-candidate
  try/except (there is nothing left that can fail candidate-by-candidate), and the response shrank from
  `{practitioner, practitioner_name, available, reason, same_fee, fee_incl_tax}` to just
  `{practitioner, practitioner_name}`. `original_practitioner` is now read via a single
  `frappe.db.get_value` instead of a full `frappe.get_doc` load, since nothing else in the function needs
  the document. `QueueReassignDialog`'s step-1 list lost the ✓/✗ icons, the `disabled` state, the `reason`
  tooltip, and the "Fee differs" badge — every candidate is now a plain, always-clickable row (step 3's
  payment block, added by the prior revision, is unaffected — it is the one and only place the fee now
  appears). The one i18n key this added, `queue.reassignFeeDiffers`, was removed from both locales as
  unused. The two tests added by the prior revision were replaced by one,
  `test_candidates_do_no_fee_computation`, asserting the response for a wildly-different-fee candidate has
  exactly the two remaining keys — locking in "no billing side-channel here" as the invariant, rather than
  a specific fee value that no longer exists in the response. All 6 remaining tests re-run and green.

  **"Keep the original fee" checkbox, added the same day — the emergency-reassignment case.** Product owner
  scenario: front desk books the patient with a cheaper doctor; that doctor becomes unavailable (an
  emergency, not the patient's choice); the patient is moved to whoever else IS available, who may charge
  more. **"Patient may deny to pay more"** — the clinic caused the fee increase, so the patient should not be
  forced to absorb it. Two readings of "skip the payment part" were put to the product owner as an explicit
  either/or:

  | Approach | What it does | Verdict |
  |---|---|---|
  | A. Waive the increase — `fee_override` = the OLD fee | No extra charge ever, now or at checkout — the patient's bill never actually changes | **Chosen** |
  | B. Just don't collect now, still bill the higher fee later | Forces `payment_timing="pay_later"` and hides the payment step, but the higher fee is still billed at checkout | Rejected — does not solve "may deny to pay more," only delays asking |

  **A, confirmed with the product owner before building.** Mechanism: `reschedule_appointment_with_payment`
  already accepts `fee_override` (the same parameter front desk uses to negotiate a rate at booking) — no
  backend change needed. A new checkbox in `QueueReassignDialog`'s step 3, shown only when the move would
  otherwise cost more (`delta > 0 || deferred > 0` — a refund already favors the patient, so the checkbox is
  never offered there), sends `fee_override = preview.old.fee` (the pre-tax figure the CURRENT/un-overridden
  preview already returns) when checked, and forces `payment_timing="pay_later"`/`mode_of_payment=null` —
  there is nothing to collect, now or ever, once the fee itself is pinned back to what it was.

  **Verified empirically, not just reasoned through** (`_reschedule_quote`'s delta is computed against
  `old_paid`, which is always 0 pre-checkout — see the "do not show fee differ" section above for why this
  exact quantity is misleading in isolation): reassigning a never-invoiced 500-fee appointment to a
  2000-fee practitioner with `fee_override=500` returns `adjustment.type="Deferred"`, `amount=500.0` — which
  reads like a charge, but is not one: it is the SAME number the patient always owed, restated. Confirmed
  live that `Patient Appointment.paid_amount` afterward is `500.0`, not `2000.0`, and no Sales Invoice is
  created. Checkout will bill exactly what the patient originally agreed to. The frontend hides the
  "Additional amount due"/"Due at checkout" badge when the box is checked (it reads off the un-overridden
  preview and would otherwise show a now-irrelevant number) and shows a plain "will be billed {old fee},
  same as before" note instead.

  New i18n keys (`queue.reassignKeepOriginalFee`, `queue.reassignKeepOriginalFeeNote`) — genuinely new copy,
  not reused from `newAppt` like the rest of the payment step, since `NewAppointmentDialog`'s reschedule mode
  has no equivalent waiver concept.

  **A second, analogous safety gap found and closed while wiring step 3:** `reschedule_appointment_with_payment`
  had the *exact same* missing `assert_bookable` gap as `reassign_appointment` did before this ADR's earlier
  fix — zero holiday/leave/self-declared-unavailable/schedule-coverage check on the target practitioner (core's
  own `validate_overlaps()` was already covered, indirectly, since this function's write path goes through a
  real `doc.save()` — unlike `reassign_appointment`'s raw `db.set_value`). Fixed the same way: `assert_bookable`
  now runs before the commit, but **only when the slot is actually moving** (a bare fee/payment-timing
  adjustment on an already-valid, already-booked slot must not be retroactively rejected just because
  availability data changed for that slot *after* it was booked).

  New BFF routes: none needed beyond what already existed for slots (`/api/appointments/slots`) and the
  commit (`/api/appointments/[id]/reschedule-with-payment`) — both already built for the Appointments
  screen's own reschedule drawer, reused as-is. `QueueReassignDialog` rewritten to the 3-step flow.
  7 backend tests (all passing live): excludes the current practitioner, marks same-fee available,
  marks different-fee **still available** (with `same_fee=False` — see the fee-difference revision below),
  the original title-refresh test, the original reassign-side Unavailable/double-booking guard tests, and a
  new test proving `reschedule_appointment_with_payment` itself now rejects a self-declared-unavailable
  target practitioner.

  **A test-hygiene finding along the way, unrelated to the feature itself but worth recording:** this test
  file's fixtures were leaking past `tearDown` on every run — even "0 failures" runs — because
  `frappe.db.commit()` (added earlier to protect against the `handle_api_errors`-rollback gotcha) also
  defeats `FrappeTestCase`'s own rollback-based test isolation, so `tearDown`'s explicit deletes became the
  *only* thing standing between committed test data and permanent leftovers. Root cause of the specific
  silent failures: deleting a `User` occasionally hits a genuine, transient Frappe race with its
  auto-created `Contact` (`QueryDeadlockError`, "Record has changed since last read"). Fixed two ways: a
  random per-`setUp` suffix on every fixture's identifiers (makes cross-run collisions structurally
  impossible, regardless of whether cleanup succeeds), plus a one-time retry on delete failure (closes the
  specific race in the common case).

### 2. Queue Stage Log — a new, standalone append-only table

**New doctype: `Queue Stage Log`.** One row per visit per room-stay:

| Field | Type | Notes |
|---|---|---|
| `appointment` | Link → Patient Appointment | required |
| `room` | Select | `arriving_soon` / `waiting_room` / `nursing_room` / `practitioner_room` / `checkout` |
| `practitioner` | Link → Healthcare Practitioner | whoever was assigned when this room-stay began — a snapshot, so a later reassignment does not rewrite history that already happened |
| `company` | Link → Company | read from `Patient Appointment.company` (verify at implementation time that this field is reliably populated on every appointment; fall back to the assigned practitioner's `custom_company` — the same "home clinic" convention `dashboard.py`/`get_command_center` already use — if not) |
| `encounter` | Link → Patient Encounter, nullable | **only ever set on the `practitioner_room` row** — see below |
| `entered_at` | Datetime | required |
| `exited_at` | Datetime, nullable | filled in only when the visit leaves this room |
| `duration_min` | Int, nullable | computed once, when `exited_at` is set — a plain calculation, `(exited_at - entered_at)` in minutes. No threshold, no "delayed" flag — this table stores what happened, not a judgment about whether it was too slow |

**Encounter timing rides on the same row, not a second mechanism.** Because `practitioner_room` already
*means* "a Draft encounter exists for this visit" (the room-derivation table above), the `practitioner_room`
row's own `entered_at`/`exited_at` already answer "how long did this encounter take" — `entered_at` is
stamped when the Draft encounter is created, `exited_at` when it is submitted. The only new information
this row needs beyond every other row is **which** encounter (`encounter` field) — not a second pair of
timestamps. This was a deliberate simplification reached during scoping, not an oversight: it was
originally going to be two extra fields, and turned out to be one.

**One honest limitation, recorded here rather than left implicit:** `practitioner_room` duration measures
wall-clock time from "Draft encounter created" to "encounter submitted," not active authoring time. A
practitioner interrupted mid-note for five minutes has that five minutes counted. This is the same
limitation any simple start/stop timer has; it should be stated plainly wherever this number is shown in a
report, not presented as a measure of effort.

**Write mechanism — there is no single "room changed" event to hook, because room is derived from two
different doctypes.** Two hook points, both using the already-established `on_trash`-style `hooks.py` doc
event convention (see `Complaint`/`Diagnosis`/etc. at `hooks.py:191-196` for the existing precedent of this
pattern in this codebase):

1. **`Patient Appointment.on_update`** — detects a `status` transition (Open → Confirmed → Checked In →
   ... → Closed) and closes the current open `Queue Stage Log` row / opens the next one for
   `arriving_soon`/`waiting_room`/`nursing_room`. Added as one more handler in the existing `on_update` list
   for Patient Appointment (`hooks.py:263`), alongside `patient_clinical_summary.on_patient_activity` —
   independent, so a failure in one cannot silently stop the other (matching this codebase's own stated
   convention for that list).
2. **`Patient Encounter.after_insert`** (Draft created → closes `nursing_room`, opens `practitioner_room`
   with `encounter` set) and **`Patient Encounter.on_submit`** (submitted → closes `practitioner_room`,
   opens `checkout`).

The final `checkout` row closes when the appointment reaches a completed status (`_COMPLETED_STATUSES`,
already defined in `report.py` — "Checked Out"/"Closed"), via the same `on_update` handler as (1).

**No delay threshold, on request.** Earlier drafts of this decision proposed a configurable per-room
threshold and a `delayed` flag, generalizing the existing `remedisys_checkin_grace_minutes` pattern
(`appointments/report.py:1490-1510`). **Dropped, on the product owner's explicit instruction: this table
only calculates and stores `duration_min` — it does not judge whether that duration was too long.** Nothing
about "is this a delay" is computed, stored, or configured anywhere in this doctype. If a delay/threshold
concept is wanted later, it is a separate, later decision — not assumed here.

**Retention — an explicit rule, not an implicit one.** `Patient Appointment.on_trash` deletes every
`Queue Stage Log` row referencing that appointment. This is a deliberate, written-down decision (see
Alternative 2 below for why this is not "free" the way it would be with a child table, and why an explicit
rule is the right trade anyway).

**Reporting.** A new report function, `get_queue_stage_breakdown`, in `api/v1/appointments/report.py`
(same file as `get_queue_wait_times`, same filter convention: `period`/`date_from`/`date_to`/
`practitioner`/`department`/`company`, **plus a new `room` filter** — pick one room to see only that room's
numbers, or omit it for a full breakdown across all five). Surfaced as one more card on the existing
Reports screen's Operations section, next to "Queue Wait Times" — not a new section, not a new screen.
Per-visit room timing (e.g. "how long was this one patient in Waiting Room today") is available directly
from that visit's own `Queue Stage Log` rows without going through the report at all.

### 3. Role-based tips

A new, dismissible frontend panel on the Live Queue screen. **Rule-based and deterministic, not
LLM-generated** — see Alternative 3 below for why. Computed from data already on screen (current per-room
counts, plus, once decision 2 ships, each open `Queue Stage Log` row's live `entered_at` vs. now — "this
card has been in Nursing Room for 23 minutes"), filtered per role using the existing `RoleId`/`Capabilities`
plumbing already threaded through `mission-control-client.tsx`. **This decision fixes the mechanism, not an
exhaustive rule set** — the scoping conversation for this part was intentionally lighter than decisions 1
and 2, so the initial rules below are a starting point, expected to grow, not a closed spec:

- Nurse/Admin: which room currently has the most patients waiting, or the single longest-waiting card right
  now ("Jaani has been in Nursing Room for 23 minutes") — a live number read off the open `Queue Stage Log`
  row, not a threshold comparison.
- Front Desk/Admin: actionable state on Arriving Soon/Waiting Room cards already visible today (e.g.
  Payment Pending count) — no new data needed for this one.
- Admin: which room is today's slowest, once decision 2's data exists.

### 4. Rename "Live Queue" → "Clinical Command Center"

Scoped to the `queue.liveQueueTitle` key in `messages/en.json`/`messages/es.json` (rendered at
`mission-control-client.tsx:1670`) and any other literal "Live Queue" text found by a grep sweep at
implementation time (not fully enumerated in this ADR). **The naming collision with the existing "Command
Centre" admin tab is a knowingly accepted risk** (see Context) — this ADR does not rename or otherwise
touch that other feature.

### 5. Live browser verification, same day (and the day after) — five bugs found and fixed

The very first real browser use of this feature (decisions 1 and 2 had, until this point, only ever been
exercised through automated tests and console scripts — see §9 Known gaps). Full detail, root cause, and
files touched for each is in [WORK_LOG — 2026-09-09](../../WORK_LOG.md); summarized here because these
correct claims made earlier in this document:

1. **Decision 1's reassign control was invisible on a Nursing Room card** for anyone but a Nurse.
   `canReassign` had been gated on `canActOnRoom()` — the "who owns this room for check-in/move actions"
   check every other room control uses — instead of the reassignment-specific `Capabilities.reassign` this
   ADR's own Context section already named as the intended gate
   (`src/lib/narzim/roles.ts:28`/`mergeCapabilities`). Fixed by switching to that helper.
2. **Decision 2's Queue Stage Log did not actually track a real Waiting Room → Nursing Room move** — the
   row stayed open on the old room forever, and no new room ever opened. Root cause: `check_in_patient()`,
   `update_status()`, `cancel_appointment()` (`appointments/api.py`), and
   `encounters/api.py::_cascade_cancel_appointment` all write `Patient Appointment.status` via
   `frappe.db.set_value`, which never fires `on_update` — the exact same class of gap `reassign_appointment`
   had before an earlier fix today. **"Done — 8/8 passing" (§8, this document's earlier revisions) was true
   and misleading at once**: every one of those 8 tests manually called `run_method("on_update")` after its
   own `db.set_value`, which proved the hook function correct but never proved it fires in production. Fixed
   by adding the same explicit call at all four call sites (mirroring the existing `notify_cancelled`
   pattern), and by adding 3 new tests that go through the real endpoints instead of the manual call — the
   only kind of test that could have caught this.
3. **A third bug, not from decisions 1 or 2 directly but surfaced by heavy use of decision 1**: the
   appointment drawer's "Paid" figure (`_billing_for`, feeds every queue card) summed invoice face values
   without netting a later refund, overstating what a repeatedly-reassigned appointment had actually
   collected (1420 shown, 580 real, on a live appointment used for manual testing). Fixed by netting Credit
   Note amounts out of `_billing_for`'s totals.
4. **A fourth bug, found while the user was reading that same live appointment's raw invoices to sanity-check
   #3**: the reschedule delta invoice (the extra Sales Invoice a fee increase raises) showed a fabricated
   "Item Discount" — e.g. `Base Total: 2,000, Item Discounts: -1,580` on a charge that was genuinely only
   420, never discounted from anything. Root cause: `_create_reschedule_delta_invoice`
   (`services/billing.py`) sets the row's `rate` to the delta amount, then `set_missing_values()` pulls the
   item's own Item Price into `price_list_rate` and manufactures a `discount_amount` to reconcile the two —
   correct ERPNext mechanics, applied to a number (a synthetic reschedule top-up) that was never actually a
   list price to begin with. **The identical pattern also appears on the plain, non-reschedule original
   booking invoice for the same item/practitioner** (core Healthcare's own `create_sales_invoice`) — left
   alone, per Rule 1 (never modify core) and because it is arguably correct there: it reflects a real,
   separate data fact (this item's Item Price genuinely differs from this practitioner's configured rate).
   Fixed only in `_create_reschedule_delta_invoice`, which is our code and where the "discount" concept
   never applied in the first place. The Grand Total (420) was correct throughout, in every version of this
   bug — only the displayed breakdown was wrong.
5. **A fifth bug, more serious than the previous four because it is settlement logic, not a display** —
   found 2026-09-10 while checking a DIFFERENT invoice/Credit Note pair the user asked about (unrelated to
   this ADR's own feature): `total_paid_for_appointment` (`services/billing.py`) reported a fully,
   manually-refunded appointment as still having paid its full original amount. Root cause:
   `_appointment_funding` — the one function BOTH `total_paid_for_appointment` and
   `appointment_refund_sources` (which decides what a reschedule/reassign settlement can actually charge or
   refund) are built on — only ever discovered a refund by reading `refund_credit_note` off THIS
   appointment's own `Appointment Reschedule History` rows. A refund issued through the plain, standalone
   billing-page "issue a refund" action (`create_credit_note`), with no connection to reassign/reschedule
   at all, writes no history row and was structurally invisible. Left unfixed, reassigning that appointment
   later would have settled the next move against a balance the patient no longer held. **Fixing it broke
   an existing test the first time** (`test_refund_on_a_shared_invoice_does_not_touch_the_sibling_
   appointment`) — a naive "any Credit Note against any tracked invoice" query wrongly applied one shared
   invoice's refund to every appointment sharing it, since reschedule/refund lines deliberately clear
   `reference_dt`/`reference_dn` on their return rows. Fixed by restricting the broadened detection to
   invoices that cannot be shared (delta invoices, always; the original invoice, only when exactly one
   appointment uses it), falling back to the old, safe, per-appointment-scoped history read for a shared
   original invoice. The identical shared-invoice risk was found and fixed in `_billing_for`
   (`api/v1/appointments/api.py`) in the same pass — it had the same broadened-query shape from finding #3
   above, not yet exercised against a shared invoice. Also corrected in both places: measured via
   `_credit_note_refunded_cash` (a Credit Note's actual Payment Entry allocation), not its face value —
   a return that reverses a write-off has a real `grand_total` but zero cash actually paid back. New
   regression test: `test_manual_refund_with_no_reschedule_history_is_still_seen`.

**§8's build-status table and this document's "Status of the build" line are corrected accordingly** — see
the header above and the revision history.

## Alternatives Considered

### Decision 2 (Queue Stage Log) — schema-significant, four+ approaches per CLAUDE.md §10

1. **Derive room-timing from Frappe's built-in Version log (`Patient Appointment` already has
   `track_changes: 1`).**
   - Pros: zero new schema; the `status` transitions are already being recorded, for free, today.
   - Cons: only covers the `status`-driven rooms — `practitioner_room`/`checkout` are driven by
     `Patient Encounter`, a different doctype, and are invisible to this doctype's own Version log. Version
     rows are opaque JSON diffs, expensive to parse and aggregate for a report. **Fatal, not just
     inconvenient:** reconstructing "which room" from raw Version diffs means re-deriving the same
     status↔room mapping that already lives in `dashboard/api.py` — a second, independent copy of that
     logic, free to drift from the first as either one changes. This app has an explicit rule against
     exactly that (§9, "one fact, one owner").

2. **A child table on `Patient Appointment` (the product owner's own initial proposal, weighed at
   length).**
   - Pros: automatic retention — child rows are deleted the instant the parent is deleted, no explicit rule
     needed; queryable cross-appointment the same way (proven in this same session: `Holiday`, a child of
     `Holiday List`, was read cross-parent via a plain `frappe.get_all` filter with no difficulty).
   - Cons: **write cost at this app's real target scale.** Every room-move requires loading the *entire*
     parent `Patient Appointment` document, appending a row, and saving the whole document again — which
     re-runs the parent's full `validate()` and every `on_update` hook already registered for it, just to
     log a room change. At ~5 room-moves per visit and a stated target of 10 lakh+ visits/month, that is
     ~50 lakh full-document reads/validates/saves *per month*, landing on the exact same table the rest of
     the app depends on for live booking and check-in — a real, avoidable risk to that table staying fast
     as volume grows, not a theoretical one.

3. **A new, standalone `Queue Stage Log` doctype, linked by a plain `appointment` field — chosen.**
   - Pros: each room-move is one small, direct write (`insert`/`db.set_value`) that never loads, validates,
     or re-saves the parent appointment at all. Matches this codebase's own established convention for
     append-only per-visit event logs living as their own linked doctype rather than a child table (e.g.
     `AI Transcript Segment`, linked to `AI Encounter Session` by a plain Link field, not nested inside
     it). Reporting is exactly as easy as a child table's (same `frappe.get_all` pattern, proven above) —
     that earlier concern was wrong and is explicitly retracted here, not carried forward as a real cost.
   - Cons: retention is not automatic — needs the explicit `on_trash` rule in the Decision above. Needs its
     own `DocPerm` rows configured (a genuine one-time setup cost this codebase has been bitten by before —
     see [[feedback_fixtures_path_trap]] and the "orphan DocPerm" gotcha in [[project_clinical_procedure_api]]
     — must be done carefully, not copy-pasted blindly).

4. **Skip real-time writes entirely; compute room-durations after the fact from a background job reading
   the Version log + `Patient Encounter` timestamps, materializing only a summary table for reporting.**
   - Pros: zero new writes at card-move time — staff experience nothing different at all.
   - Cons: inherits Alternative 1's fatal flaw (duplicates the status↔room derivation logic in a second
     place) *and* adds a background-reconciliation job on top, for a worse result on the "one fact, one
     owner" concern than Alternative 1 already has. Also cannot support a live "this card has been here 23
     minutes" figure (used by decision 3's tips) without the job running constantly, defeating its own
     "skip real-time work" premise.

5. **Denormalized timestamp fields directly on `Patient Appointment`** (e.g. `waiting_room_entered_at`).
   - Pros: simplest possible schema — no new doctype at all.
   - Cons: loses history the moment a visit revisits a room (e.g. sent back to Waiting Room from Nursing
     Room) — a single field can only ever hold the most recent entry, not a log. Represents "current state,"
     not "what happened," which is the opposite of what a report needs.

**Why 1, 4, and 5 lose, specifically:** 1 and 4 both duplicate business logic this app already has exactly
one copy of, which is a standing rule violation, not a style preference; 5 cannot represent a revisit at
all, which this operational flow explicitly allows (a patient can be sent back a room). Between the two
real contenders — 2 (the product owner's proposal) and 3 (chosen) — the deciding factor, reached only after
walking through the actual write volume at the app's stated 10 lakh+/month target, was that 2's "free"
retention benefit is fully recoverable with one explicit hook, while 2's write-cost problem has no
equivalent fix without abandoning the child-table shape altogether.

### Decision 3 (role-based tips)

1. **Rule-based, deterministic, computed from data already on screen — chosen.**
   - Pros: no new dependency, no cost per tip shown, predictable and testable, consistent with Rule 9
     ("pipelines over agents") — this is operational tooling, not a clinical judgment, and does not belong
     anywhere near the LLM-governed parts of this app (ADR-026/ADR-030's allowlisted, audited tool
     registry).
   - Cons: rules must be hand-written and maintained; will not generalize to a pattern nobody thought to
     write a rule for.
2. **LLM-generated tips.**
   - Cons: this app's LLM usage is deliberately scoped to the clinical Encounter Copilot, behind a curated
     tool registry, audit logging, and cost governance (ADR-026, ADR-030) — none of which this dashboard
     feature has any reason to acquire. Introducing a second, ungoverned LLM call site for a non-clinical
     convenience feature is scope creep this ADR explicitly declines.
3. **No tips; defer this decision entirely.**
   - Cons: leaves one of the four requested changes unaddressed with no path forward recorded.

## Consequences

- **New doctype:** `Queue Stage Log` (fields above) + migration/fixture entries + `DocPerm` rows (System
  Manager, Front Desk, Nurse, Practitioner — read; write restricted to the hooks themselves via
  `ignore_permissions`, matching this codebase's established service-layer-writes-not-users convention).
- **New hooks:** `Patient Appointment.on_update` (one more handler alongside the existing
  `patient_clinical_summary.on_patient_activity`), `Patient Appointment.on_trash` (new), `Patient
  Encounter.after_insert` and `Patient Encounter.on_submit` (verify neither collides with an existing
  handler for these events before adding — not confirmed absent in this ADR, must be checked at
  implementation time).
- **New report function:** `get_queue_stage_breakdown` in `api/v1/appointments/report.py`, new card on the
  existing Reports screen.
- **No new site_config key** — no delay threshold, per the product owner's instruction; `duration_min` is a
  plain calculation with nothing configurable about it.
- **Frontend:** inline reassign control on three room types (Live Queue only); new `QueueTipsPanel`
  component; `queue.liveQueueTitle` (and any other literal occurrences found by grep) renamed.
- **No change** to `custom_checked_in_at`, `get_queue_wait_times`, `reassign_appointment`'s existing rules,
  or the "Command Centre" admin tab.
- **Accepted, not resolved:** the "Clinical Command Center" / "Command Centre" naming overlap (Context).
- **Re-evaluation trigger:** if `Queue Stage Log` write volume ever becomes a measurable load concern on
  its own (unlikely given its narrow, indexed shape, but the whole point of decision 2 was avoiding exactly
  this risk on the *appointment* table — the same discipline should apply here if it ever recurs).

## Verification

| Claim | Artefact |
|---|---|
| Reassign only works on Arriving Soon / Waiting Room / Nursing Room cards, and only for the roles already allowed today | Frontend: control does not render outside those rooms/roles. Backend: unchanged, still enforced by `_REASSIGNABLE_STATUSES`/`_REASSIGN_ROLES` |
| A visit's total time in each room is recorded and queryable per room | `Queue Stage Log` rows exist for a completed visit, one per room, `duration_min` populated; `get_queue_stage_breakdown(room="nursing_room")` returns only that room's numbers |
| Encounter duration is available without a second tracking mechanism | The `practitioner_room` row's `entered_at`/`exited_at` match the linked encounter's creation/submission timestamps |
| Deleting an appointment leaves no orphaned `Queue Stage Log` rows | Test: delete an appointment with stage-log history, assert zero matching rows remain |
| Tips shown differ by role and reflect currently-visible data | Frontend: same board state, different logged-in role, different tip set |
| "Clinical Command Center" renders where "Live Queue" used to | i18n key updated in both locales; screen renders the new title |

## References

- `docs/CLINICAL_COMMAND_CENTER.md` — companion mechanism doc
- `docs/adr/adr-018-practitioner-appointment-visibility-and-coverage.md` — the reassignment-lock rule this
  ADR reuses unchanged
- `docs/adr/adr-026-llm-provider-allowlist.md`, `docs/adr/adr-030-llm-curated-tool-access.md` — why
  decision 3 stays rule-based, not LLM-generated
- `api/v1/appointments/api.py::reassign_appointment` — the reused endpoint
- `api/v1/dashboard/api.py::get_dashboard_data` — the existing room-derivation logic this ADR does not
  duplicate
- `api/v1/appointments/report.py::get_queue_wait_times` — the existing, unmodified coarse wait-time metric
- [[project_command_center_api]] — the separate, unrelated "Command Centre" admin feature

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.11 | 2026-09-10 | Divyanshu (AI-assisted) | §5's fifth bug, the most serious of the five: `total_paid_for_appointment`/`_appointment_funding` (`services/billing.py`) only ever detected a refund via `Appointment Reschedule History` rows, so a plain MANUAL refund (unrelated to reassign/reschedule) was invisible — a later reassignment would have settled against money the patient no longer held. Fixed by detecting any Credit Note against any non-shared invoice directly; first attempt broke `test_refund_on_a_shared_invoice_does_not_touch_the_sibling_appointment` (a shared invoice's refund leaked onto every appointment sharing it), fixed by restricting the broadened detection to invoices that cannot be shared, with a safe fallback for a shared original invoice. Also switched to `_credit_note_refunded_cash` (actual cash paid back) instead of a Credit Note's face value, in both this function and finding #3's `_billing_for` fix — a write-off-reversing return has real face value but zero real cash. New test: `test_manual_refund_with_no_reschedule_history_is_still_seen` |
| 1.10 | 2026-09-09 | Divyanshu (AI-assisted) | §5's fourth bug: a reschedule delta invoice showed a fabricated "Item Discount" (e.g. -1,580 on a genuinely-420 charge) — `set_missing_values()` pulled the item's own mismatched Item Price into `price_list_rate` and manufactured a discount to reconcile it against the explicitly-set delta `rate`. Fixed in `_create_reschedule_delta_invoice` only (our code); the identical pattern on the original, non-reschedule booking invoice is left alone (core Healthcare's own `create_sales_invoice`, Rule 1, and arguably correct there — reflects a real Item Price/op_consulting_charge mismatch). Grand Total was correct throughout; only the displayed breakdown was wrong |
| 1.9 | 2026-09-09 | Divyanshu (AI-assisted) | §5 (new): first real browser use of decisions 1/2 found three live bugs, all fixed same day — reassign control invisible in Nursing Room for non-Nurse roles (`canActOnRoom` wrongly gated it; switched to `Capabilities.reassign`/`mergeCapabilities`); Queue Stage Log never actually tracked a real room move (`check_in_patient`/`update_status`/`cancel_appointment`/`_cascade_cancel_appointment` all bypass `doc.save()` via `db.set_value`, so `on_update` never fired — the existing "8/8 passing" tests all manually called the hook, which is why this was missed; 3 new tests now go through the real endpoints); the drawer's "Paid" figure summed invoice face values without netting a later refund (`_billing_for` netting fix, verified against `total_paid_for_appointment`) |
| 1.8 | 2026-09-09 | Divyanshu (AI-assisted) | §1 "Keep the original fee" checkbox: for the emergency-reassignment case (a cheaper doctor became unavailable, patient moved to a pricier one, patient should not be forced to pay the difference), a step-3 checkbox sends `fee_override` = the old fee to `reschedule_appointment_with_payment` (existing param, no backend change), so no extra charge exists now or at checkout. Chosen over "just defer to checkout," which was rejected for not actually solving "patient may deny to pay more." Verified empirically: `Patient Appointment.paid_amount` after is the OLD fee, not the new doctor's default, and no invoice is created |
| 1.7 | 2026-09-09 | Divyanshu (AI-assisted) | "Do not show fee differ": removed 1.6's step-1 "Fee differs" badge and its `same_fee`/`fee_incl_tax` fields entirely — `get_reassignment_candidates` simplified back to a plain active-practitioner list (no per-candidate `_reschedule_quote` call, no try/except, `original_practitioner` read via `db.get_value` not a full doc load). The fee now appears exactly once, in step 3. `QueueReassignDialog`'s step-1 rows lost their ✓/✗ icons, disabled state, and badge. Removed the now-unused `queue.reassignFeeDiffers` i18n key. Two fee-semantics tests replaced by one shape-invariant test (`test_candidates_do_no_fee_computation`); 6 tests re-run green |
| 1.6 | 2026-09-09 | Divyanshu (AI-assisted) | Fee-difference revision, superseding 1.5's "only show slots where the fee is unchanged": a different fee no longer blocks a candidate. `get_reassignment_candidates` keeps `available=True` for any fee and adds non-blocking `same_fee`/`fee_incl_tax` hints; `QueueReassignDialog` gained a step 3 that settles the delta — additional payment (now or deferred) or immediate refund — reusing the exact hooks (`useReschedulePaymentPreview`, `usePaymentMethods`, `useRescheduleWithPayment`) and payment-step copy `NewAppointmentDialog`'s reschedule mode already ships, chosen over replacing the picker with that full drawer (an explicit either/or put to the product owner: "keep in same modal only"). 2 of 7 tests updated for the new semantics; all 7 re-run green |
| 1.5 | 2026-09-09 | Divyanshu (AI-assisted) | 1.4's "check the exact original slot" design was rejected on sight and redesigned same-day into a real 3-step picker (pick doctor, filtered by fee-parity → see that doctor's real open slots via the existing `get_available_slots` → pick a slot → commit via `reschedule_appointment_with_payment`, not `reassign_appointment`). Fixed a real bug found writing the first test: fee-parity must compare the two fee quotes directly, not `quote["adjustment"]`, which answers an unrelated question and is wrong for any never-invoiced appointment. Found and closed the same `assert_bookable` gap in `reschedule_appointment_with_payment` that 1.3 closed in `reassign_appointment`. Hardened the test file's fixture cleanup (random per-run suffixes + retry) after diagnosing why "passing" runs were still leaking test data |
| 1.4 | 2026-09-09 | Divyanshu (AI-assisted) | New read-only `get_reassignment_candidates` endpoint + BFF route, requested so the reassign picker shows every candidate's availability for this exact slot up front, not only after clicking Reassign — runs the identical `assert_bookable`/`validate_overlaps` checks as the real reassignment (single source of truth). `QueueReassignDialog` rewritten from a plain `<select>` to a list with a check/cross and reason per candidate. 4 new tests (7 total in the file). **Superseded by 1.5 the same day** — this design was rejected and redesigned before ever reaching a user |
| 1.3 | 2026-09-09 | Divyanshu (AI-assisted) | Two real defects found live in `reassign_appointment` (reported by the product owner from a screenshot of `HLC-APP-2026-00326`) and fixed the same day, correcting decision 1's "existing endpoint, unchanged" claim: (1) the Desk title/heading never refreshed after a reassignment — stayed on the old practitioner's name permanently; (2) reassignment performed zero availability/conflict check on the new practitioner (no holiday/leave/self-declared-unavailable/schedule-coverage check, no double-booking check) before swapping. Both fixed; 3 new regression tests passing live, 12 pre-existing tests re-verified unaffected |
| 1.2 | 2026-09-09 | Divyanshu (AI-assisted) | Implemented and verified — backend (doctype, hooks, report function) live-tested 8/8 passing on `remedisis.localhost`; frontend (reassign dialog, tips panel, rename, report page) typechecked/linted/i18n-verified, not yet browser-tested. Corrected decision 1: `QUEUE_ACTION_CAP` was assumed to be the room-action gating mechanism but is dead code — the reassign control actually gates via `canActOnRoom`/`ROOM_ROLES`, the mechanism every other room action on this screen actually uses |
| 1.1 | 2026-09-09 | Divyanshu (AI-assisted) | Dropped the per-room delay threshold and `delayed` field, on the product owner's explicit instruction — `Queue Stage Log` now only calculates and stores `duration_min`; no site_config key, no threshold config, no judgment about whether a duration was "too long" |
| 1.0 | 2026-09-09 | Divyanshu (AI-assisted) | Initial version |
