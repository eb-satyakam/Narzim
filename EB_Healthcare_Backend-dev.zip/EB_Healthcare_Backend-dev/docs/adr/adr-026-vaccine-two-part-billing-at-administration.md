# ADR-026: Vaccine Two-Part Billing — Product at Assignment, Administration at Dose

**Doc status:** living · **Created:** 2026-07-16 by Divyanshu · **Updated:** 2026-07-16 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Proposed
- **Date:** 2026-07-15
- **Supersedes:** the vaccine billing model in `services/billing.py` (Flow B — "the Immunization's `vaccine` Item IS the billable line", `list_billable_immunizations`). Activates and refines ADR-025 D4–D8, which were **deferred** at implementation time.
- **Superseded by:** —

## Context

ADR-025 introduced per-order opt-in billing for encounter orders (drugs, labs,
procedures, therapies) and, in D4–D8, designed a two-part vaccine billing model —
but the vaccine half was **explicitly deferred** and never built. Vaccines still
bill through the old **Flow B** in `services/billing.py`: `list_billable_immunizations`
emits **one all-in Sales Invoice line** = the `Immunization.vaccine` Item, for any
dose whose `supply != "External-history"`. This has two defects:

1. It cannot separate the **product** (the vial) from the **administration** (the
   injection service). These are distinct charges that behave differently when the
   patient brings their own vaccine (product not charged, injection still charged).
2. It bills the product even for **patient-supplied** doses (Flow B only excludes
   `External-history`), which over-bills.

This ADR was first drafted with both billables (product + administration) created
at **administration** time (when the nurse records the dose), governed entirely by
`supply`. That version was implemented, then **revised the same day**: the product
half moves to **assignment** time instead, mirroring how a regular drug order
already works (ADR-025) — the practitioner assigns the vaccine and decides "bill
this or not" right there, the same as a Medication Request for a drug. The
administration half (the injection fee) is unchanged — it is still created when
the nurse actually gives the dose.

Facts about the system that shape this decision (verified 2026-07-15):

- A dose is recorded as one **`Immunization`** doc via `create_immunization_record`
  (`api/v1/immunizations/api.py`). This is the per-dose event — a multi-dose course
  produces one `Immunization` per dose. `supply` (`In-house stock` / `Patient-supplied`
  / `External-history`, default `In-house stock`) is set here, at record time.
- **Assignment** (`assign_vaccine` / `ensure_patient_vaccine`) creates a
  **`Patient Vaccine`** — our own custom doctype — that is **idempotent per
  patient + template**: it represents the whole *course*, not a dose. `supply` is
  unknown at assignment; it is only known once a dose is actually administered.
- Three different code paths create a `Patient Vaccine`: the encounter order flow
  (`_create_encounter_immunizations`, when a doctor lists a vaccine and signs the
  encounter — this is where ADR-025's opt-in "bill this" checkbox already exists
  for drugs/labs/procedures/therapies), the standalone `assign_vaccine` endpoint
  (an explicit "Assign" action outside any encounter), and `create_immunization_record`'s
  own fallback (an ad-hoc/walk-in dose logged with no prior assignment — it
  assigns and administers in the same call). All three funnel through
  `ensure_patient_vaccine` or `assign_vaccine`'s own insert, so hooking product
  billing there covers all three uniformly.
- The template's dose ladder (`Immunization Schedule Dose`, one row per scheduled
  dose) gives the total dose count for a course — the same count
  `_course_complete` already uses to decide when a round is finished.
- A **Medication Request** bills off its `medication_item` field and does **not**
  require a `Medication` master: core's `patient_encounter.get_order_details` sets
  `medication=""` and `medication_item=<code>` when only a code is present, inserting
  with `ignore_mandatory=True`. Our cart (`_list_billable_medications`) reads
  `medication_item`, needs it to be a valid enabled Item, and only applies the
  `Medication.is_billable` gate when `medication` is set — so an empty `medication`
  bills cleanly.
- `Medication Request` already carries an unused, generic **`reason_reference_doctype`
  / `reason_reference`** Link/Dynamic-Link pair in its core schema — the same kind
  of "this order exists because of X" back-reference `Service Request` already uses
  (`order_reference_doctype` / `order_reference_name`) for the administration SR.
  Reusing it to point at the `Patient Vaccine` means **no custom field is needed**
  to trace a product MR back to the course it belongs to.
- A **Service Request** bills off its template's `item` + `is_billable`
  (`_list_billable_service_requests`). The seeded **`VAC-APLICACION`** Item
  (service, `is_stock_item=0`, 150 MXN) exists, linked to the **`Vaccine
  Administration`** `Clinical Procedure Template` (seeded, `is_billable=1`).
- The consolidated cart (`get_patient_billables`, ADR-017) already pulls un-billed
  Medication Requests (group `medication`) and Service Requests (group `procedure`).
  So a product MR + admin SR reach checkout with **no cart changes**, regardless of
  when each is created.

Constraints: Rule 1 (upgrade-safe — no core edits; we build the MR/SR in app code,
reuse existing core fields rather than adding new ones), Rule 7 spirit (an
auxiliary billing failure must not break the clinical record or the assignment).

## Decision

Bill a vaccine as **two documents**, created at **two different moments**:

- **Product** (the vial) → Medication Request, created at **assignment**.
- **Administration** (the injection) → Service Request, created at **administration**.

Retire Flow B so a vaccine never double-bills.

Concrete decisions:

1. **D1 — Product → ONE Medication Request per order, not per dose.** Every
   genuine order — the encounter order flow, the standalone `assign_vaccine`
   endpoint, or first-time creation via the ad-hoc/walk-in fallback — creates a
   **single** Medication Request, `quantity=1`, regardless of how many doses
   the template's ladder calls for. The doctor is charging for the vaccine
   itself — the pack/item handed over — once; the `Immunization Schedule Dose`
   ladder governs the clinical schedule (when doses are due) and has no bearing
   on this billing line. Each MR carries `medication=""`, `medication_item=`
   the `Immunization Template.vaccine` Item (the template already links it — no
   new field), and `reason_reference_doctype="Patient Vaccine"` /
   `reason_reference=<the assignment's name>` (the existing, previously unused
   field pair — no custom field). Practitioner resolved from the order's
   `assigned_by`, else its ordering encounter's practitioner.

   (An earlier version of this decision, same day, created one MR *per dose* in
   the ladder — e.g. 3 MRs for a 3-dose series. Corrected: the product is one
   line regardless of dose count, matching how a doctor actually thinks about
   charging for a vaccine — one item given, one charge.)

   The MR is created **unconditionally on a genuine order** — the opt-in flag
   (D3) does not gate creation, only `billing_status`. This mirrors ADR-025's own
   opt-out mechanism for drugs/labs/procedures/therapies exactly: core always
   creates the MR/SR for an order; the physician's uncheck only stamps
   `billing_status=Invoiced` afterward. Vaccines follow the identical pattern —
   the clinical record that a product was ordered exists regardless of the
   billing decision.

   Ordering the **same** vaccine again while the patient already has an Active
   course does **not** suppress the new MR — same as reordering a drug, this
   creates a second Medication Request (D9). What *is* suppressed is
   `ensure_patient_vaccine` being called incidentally, not as a new order — see D9.

2. **D2 — Administration → Service Request, created at administration
   (unchanged).** When the nurse records the dose (`create_immunization_record`),
   create a submitted `Service Request` pointing at the flat **"Vaccine
   Administration"** `Clinical Procedure Template` (`is_billable=1`,
   `item=VAC-APLICACION`, 150 MXN), linked back to the dose via the existing
   `order_reference_doctype` / `order_reference_name` fields.

3. **D3 — What governs each half is now different.**
   - **Product (MR, at assignment):** always created; governed by a practitioner
     **"bill this vaccine" opt-in flag** is whether it lands `billing_status=
     Pending` (billable) or is immediately stamped `billing_status=Invoiced` (+
     `qty_invoiced=quantity`) — excluded from the cart, order still on record.
     Mirrors ADR-025's opt-out mechanism for drugs/labs/procedures/therapies
     exactly (core always creates the MR/SR; the physician's uncheck only stamps
     `billing_status` afterward — see `complete_encounter`'s
     `_stamp_billing_optout`). The flag is carried in the encounter's SOAP blob
     (`bill_flags.vaccines`, parallel to the `vaccines` list) when assigned from
     an encounter. When no explicit flag exists (the standalone `assign_vaccine`
     endpoint, or an ad-hoc dose logged with no prior assignment), it falls back to
     the clinic's facility-driven default — **reusing `has_internal_pharmacy`**
     (a clinic that stocks its own drugs stocks its own vaccines too; no separate
     vaccine-specific setting was added).
   - **Administration (SR, at administration):** still governed by `supply`, as
     originally designed — created for `In-house stock` and `Patient-supplied`,
     skipped for `External-history` (a purely historical record, nothing was
     actually administered by us). Unlike the product MR, the admin SR is not
     created at all when `supply == External-history` — there is no equivalent
     "create but stamp Invoiced" step for the administration fee, since nothing
     was administered by us in that case.

   | | Product (MR, at assignment) | Administration (SR, at administration) |
   |---|---|---|
   | Created | always | In-house/Patient-supplied only; not for External-history |
   | Governed by | practitioner opt-in flag (default: facility setting) — sets `billing_status` only | `supply` — gates creation itself |
   | `supply` value | *unknown at this point — irrelevant to the decision* | In-house/Patient-supplied → created; External-history → not created |

4. **D4 — Savepoint-isolated at both moments.** Product MR creation
   (`_create_vaccine_assignment_billables`, called from `ensure_patient_vaccine`
   and `assign_vaccine`, right after the `Patient Vaccine` insert) and admin SR
   creation (`_create_vaccine_billables`, called from `create_immunization_record`
   after the `Immunization` insert) are each wrapped in their own savepoint. A
   failure in either rolls back only that billable and is logged — it never blocks
   the assignment or the recorded dose (Rule 7 spirit; mirrors `_eager_create_lab_test`).

5. **D5 — Timing: product at order, administration at dose (revised from the
   original administration-only design).** The original version of this ADR
   rejected order-time product billing (as its own "Alternative 1") for three
   reasons — a `Patient Vaccine` is per-*course* so billing at that point felt
   like it needed to represent every future dose; `supply` is unknown at order
   time; a no-show would leave a stale charge. Revised design addresses each
   directly instead of avoiding the timing:
   - **"How do we bill a multi-dose course"** → solved by **D1**: the product is
     one Medication Request, `quantity=1`, regardless of dose count — the
     doctor is charging for the vaccine once, not per dose, so there was never
     an under-billing problem to solve once framed correctly.
   - **`supply` unknown at order time** → solved by **decoupling product billing
     from `supply` entirely** (D3) — it's now a practitioner opt-in decision, not
     a supply-driven one. `supply` still governs only the administration SR, where
     it's actually known.
   - **No-show leaves a stale charge** → solved by D9 (below): `unassign_vaccine`
     cancels any still-unbilled product MR.

6. **D6 — Flat administration fee (unchanged).** One "Vaccine Administration"
   template / one `VAC-APLICACION` price (150 MXN) for every vaccine (ADR-025 D7).
   A repeatable seed (`seed_vaccines.py`) + idempotent patch
   (`ensure_vaccine_admin_template_20260715`) ensures the template exists,
   `is_billable=1`, linked to the priced Item.

7. **D7 — Retire Flow B (ADR-025 D8).** Remove `list_billable_immunizations` from
   `get_patient_billables` so a vaccine bills **only** via D1+D2 — **done**. Still
   outstanding: `create_pos_invoice` and `create_sales_invoice` in
   `services/billing.py` still carry a `reference_type == "Immunization"` branch
   each — now unreachable (the cart never emits that reference type any more) but
   not yet deleted. The standalone `create_vaccination_invoice` endpoint is also
   still live, untouched — retire it, or repoint it at the MR+SR cart, once it's
   confirmed whether the frontend still calls it.

8. **D8 — Supply-change-after-record is deferred.** Correcting `supply` on
   `update_immunization` after the dose is recorded does **not** adjust anything —
   this now only matters for the administration SR (the product side no longer
   depends on `supply` at all). Deferred as a fast-follow — see re-evaluation
   triggers.

9. **D9 — No cross-order dedup; `always_bill` distinguishes a real order from
   incidental course resolution; no-show handling (revised).** A product MR is
   linked to its course via `reason_reference_doctype="Patient Vaccine"` /
   `reason_reference=<name>`.

   `_create_vaccine_assignment_billables` has **no existence check** — every
   call creates a fresh Medication Request. What decides *whether* a given call
   happens is `ensure_patient_vaccine`'s `always_bill` parameter:
   - **`always_bill=True`** — the encounter order flow
     (`_create_encounter_immunizations`) and the standalone `assign_vaccine`
     endpoint. Calling this genuinely places an order, every time, whether the
     `Patient Vaccine` is brand new or already Active. Ordering the same vaccine
     twice before either MR is administered creates **two** Medication Requests
     — same as reordering a drug; front desk reconciles duplicate pending
     orders the same way they already do for medications. There is no dedup
     across separate order events, by design.
   - **`always_bill=False`** (default) — `create_immunization_record`'s
     internal call. This call exists to resolve/tag which course an
     *administered* dose belongs to, not to place a new order — it must not
     re-bill every time a later dose of an already-ordered course is recorded.
     This is the one case where an existing Active assignment is returned with
     no billing side effect at all.

   `unassign_vaccine` cancels every MR for that `reason_reference` still in
   `billing_status="Pending"` (unbilled), across however many separate orders
   exist — a course stopped before it was administered (no-show, declined)
   does not leave a stale charge. Anything already invoiced is left untouched.

Prerequisite (ADR-025): `Healthcare Settings.process_service_request_only_if_paid`
must be OFF (verified at implementation), else the admin SR's pay-gate behaviour changes.

## Alternatives Considered

1. **Both billables at administration, governed entirely by `supply` (the
   original version of this ADR).**
   - Pros: `supply` is known at the point of creation, so the D3 matrix (as it was
     originally written) is exact; no billable exists until the dose is actually
     delivered.
   - Cons: does not match how a regular drug order already works (opt-in decided
     at order time, ADR-025) — the practitioner has no say over vaccine product
     billing until the nurse acts, unlike every other order type. Superseded by
     the chosen approach (below), which resolves this while still addressing the
     multi-dose/no-show/supply concerns that motivated the administration-time
     design in the first place.

2. **Product MR at order time, one MR per order (quantity=1, not per dose),
   opt-in flag, auto-cancel on unassign (chosen).**
   - Pros: matches the existing drug-order billing UX exactly (practitioner
     decides "bill this" at order time); bills the vaccine as one item regardless
     of dose count, matching how a doctor actually thinks about charging for it;
     no stale charge survives a no-show; reuses the existing MR/SR cart and an
     existing-but-unused core field pair — zero schema changes.
   - Cons: the product bills before any dose is actually given (it isn't
     "reserved," it's billed at order time) — acceptable, since that's exactly how
     drug orders already behave in this system; `supply` (in-house vs.
     patient-supplied) no longer has any bearing on whether the product bills,
     only on whether the administration fee applies — a deliberate simplification,
     not an oversight.

3. **Keep the single all-in Immunization line; add an admin-fee line beside it.**
   - Pros: least change to the vaccine path.
   - Cons: leaves vaccines outside the uniform `billing_status` model; can't reuse
     the ADR-025 opt-in machinery; keeps the patient-supplied over-bill. Rejected.

## Consequences

- **Backend:**
  - `api/v1/immunizations/api.py` — `_create_vaccine_assignment_billables(...)`
    (D1/D9): ONE Medication Request per order, `quantity=1` regardless of dose
    count, linked via `reason_reference` to the `Patient Vaccine`,
    savepoint-isolated. No existence check — every call creates a fresh MR
    (D9). Hooked into `ensure_patient_vaccine` (new `always_bill` param — True
    for the encounter order flow, False by default for
    `create_immunization_record`'s incidental resolution call) and
    `assign_vaccine` (always bills, including on an existing Active
    assignment). `_create_vaccine_billables` (administration time) now only
    creates the admin Service Request (D2) — the product half moved out
    entirely. `unassign_vaccine` gains `_cancel_pending_vaccine_mrs` (D9),
    which cancels every still-Pending MR across however many separate orders exist.
  - `api/v1/encounters/api.py` — `vaccines` added to `_BILL_DEFAULT_SETTING`
    (reusing `has_internal_pharmacy`); `_fmt_encounter`, `save_draft`, and
    `_create_encounter_immunizations` carry a per-vaccine `bill_this` flag the same
    way the other four order tables already do (ADR-025); `always_bill=True` is
    passed on every call, since ordering from an encounter is always a real order.
  - No new doctype fields anywhere — `medication_item` comes from the template's
    existing `vaccine` Item link, and the course back-reference reuses Medication
    Request's existing (previously unused) `reason_reference_doctype` /
    `reason_reference` pair.
  - `scripts/seed/seed_vaccines.py` removed 2026-07-16 — a manually-run seed
    script was not guaranteed to have executed on every environment (see the
    Td-template gap under Verification). Its catalog logic moved to
    `patches/v0/seed_vaccine_catalog_20260716.py`, which runs automatically on
    every `bench migrate` and must run before
    `patches/v0/ensure_vaccine_admin_template_20260715.py` (D6, unchanged).
  - `services/billing.py` — `list_billable_immunizations` removed from
    `get_patient_billables` (done). Still outstanding (D7): dead
    `reference_type == "Immunization"` branches in `create_pos_invoice` /
    `create_sales_invoice`, and a decision on `create_vaccination_invoice`.
  - Tests in `tests/immunizations/`: an order creates exactly one MR
    (quantity=1) regardless of dose count; opted-out still creates it but
    stamped Invoiced; `always_bill=False` doesn't re-bill an existing course,
    `always_bill=True` does (a second MR); unassign cancels still-Pending MRs
    across all separate orders; administration creates only the SR now,
    regardless of the product decision; `supply` still governs the SR
    (External-history skips it).
- **Supersedes** Flow B in `services/billing.py`; **activates** ADR-025 D4–D8;
  **revises** this ADR's own original D1/D3/D5 (same-day revision, see Context).
- **Re-evaluation triggers:**
  - If per-dose linkage between a specific administered `Immunization` and a
    specific pre-created product MR becomes necessary (e.g. for refund/adjustment
    traceability), revisit — currently any Pending MR for the course is
    interchangeable, since all doses in a course bill the same Item at the same rate.
  - If per-vaccine (not flat) administration pricing is needed, revisit D6/D2.
  - If a "do not bill this in-house vaccine" (free/government dose) case arises at
    the *administration* side, add an opt-out there too (the assignment-side
    opt-in already covers the product).
  - If `process_service_request_only_if_paid` is ever enabled, the admin SR's gate
    must be reconsidered.

## Verification

- Live: ordering a vaccine with the "bill this" flag on creates exactly ONE
  Medication Request, `quantity=1` — regardless of whether the template has 1
  dose or 6 — `Pending`, linked via `reason_reference` to the `Patient
  Vaccine`; flag off still creates it, stamped `Invoiced`. Ordering the same
  vaccine again (encounter flow / Assign endpoint) creates a second MR, not a
  suppressed no-op. Recording a dose creates only the admin Service Request,
  governed by `supply` (`In-house stock` / `Patient-supplied` → created;
  `External-history` → not) — no product MR is created at this point
  regardless of `supply`, and administering a later dose of an
  already-ordered course does not create another product MR either.
  Unassigning a course cancels its still-`Pending` MRs (across however many
  separate orders exist); anything already invoiced is untouched. No
  duplicate line from the retired Flow B.
- Config: the "Vaccine Administration" template is `is_billable=1` with a
  resolvable priced `VAC-APLICACION` Item; `process_service_request_only_if_paid`
  is OFF.
- Regression: recording a dose still succeeds even if admin-SR creation raises
  (savepoint rolls back only the SR; the `Immunization` persists). Ordering a
  vaccine still succeeds even if MR creation raises (savepoint rolls back only
  the MR; the `Patient Vaccine` persists).

## References

- Constitution Rule 1 (upgrade-safe), Rule 7 (clinical action not blocked by aux failure), §12 (billing)
- ADR-025 (opt-in billing + deferred vaccine two-part model — D4–D8, D6 timing)
- ADR-017 (consolidated POS cart, `get_patient_billables`)
- ADR-020 (vaccine nurse-administration handoff — dose recorded by nurse)
- Backend: `api/v1/immunizations/api.py`, `api/v1/encounters/api.py`,
  `services/billing.py`, `scripts/seed/seed_vaccines.py`; core
  `patient_encounter.py` (`make_medication_request` / `get_order_details`),
  core `medication_request.json` / `service_request.json` (the reused
  `reason_reference_doctype`/`reason_reference` and
  `order_reference_doctype`/`order_reference_name` field pairs)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-16 | Sarvesh | Initial version (header backfilled from git history) |
