# ADR-055: The signed report is the attestation gate — Sign & Close previews, Sign & finish submits

**Doc status:** living · **Created:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.0

- **Status:** Accepted
- **Date:** 2026-09-01
- **Supersedes:** —
- **Superseded by:** —

## Context

Until 2026-09-01 **Sign & Close submitted immediately.** One click moved the
Patient Encounter from `docstatus 0` to `docstatus 1`. That transition is
irreversible from the clinical UI: a signed encounter is read-only, and
cancelling one is assigned-practitioner-only (ADR-038) and not exposed from this
screen at all.

Three facts made the order wrong rather than merely terse.

1. **The button's own footer already promised a review that did not happen.**
   V3's footer reads *"These values are written to the medical record when you
   sign. You are attesting to all of them."* Nothing sat between reading that
   sentence and the write.
2. **V1 already had a pre-submit hold, on the wrong scope.**
   `reviewDetailsState === "confirm"` stops with Back / Confirm & Sign, but only
   over the Review Details text — not the record being attested to.
3. **The post-sign overlay already owned the word.** `SignedReportOverlay` takes
   an `onAcknowledge`, which until this change navigated to Patient 360. An
   acknowledgement that happens *after* the irreversible act is a receipt, not a
   gate.

Server-side rules are untouched: `complete_encounter` still requires a chief
complaint, a linked practitioner (ADR-039) and a nurse on every vaccine
(ADR-020).

## Decision

**The report IS the gate. Sign & Close flushes the draft and opens the report,
still unsigned. `complete_encounter` fires only from that report's
"Sign & finish", after which the clinician lands on Patient 360.**

```
Sign & Close  ─►  save draft, open the report            NOTHING SUBMITTED
                  (Download PDF + Print; Email/WhatsApp withheld)
      │
      ├── Back           ─►  the encounter, draft intact, docstatus 0
      │
      └── Sign & finish  ─►  complete_encounter  ─►  Patient 360
```

1. Sign & Close **saves the draft first**. A failed flush must abort, because
   attesting to a note the record does not hold is the defect this order exists
   to prevent. The guard sits on the submit path too: `signer.sign(save.saveNow)`
   flushes again and aborts the signature if that fails.
2. The report renders in a new `pre-sign` variant of `SignedReportOverlay`:
   amber rather than green, copy that does not claim a signature
   (*"Ready to sign — not on the chart yet"*), and **Sign & finish** as the
   primary action.
3. **Email and WhatsApp are withheld until a signature exists.** Those deliver
   the document to the patient, and an unattested clinical record must not leave
   the clinic. Download and Print stay: that is the clinician reading their own
   draft.
4. Back dismisses the report and returns to the encounter. Unsigned, it is the
   editable draft; signed, it is the read-only record. **Never Patient 360** —
   closing a report is not a request to go elsewhere.
5. **One behaviour, both surfaces.** V1 and V3 use the same overlay and the same
   two-phase split, so the two cannot drift — the ADR-054 constraint applied to
   signing.

## Alternatives Considered

1. **Leave it: one click submits (status quo).**
   - Pros: fewest clicks; no change to a live clinical path; V3's "Before you
     sign" panel already shows the same facts on the page.
   - Cons: the only irreversible clinical action in the product had no
     confirmation, and the footer promised otherwise. A mis-tap on a tablet
     signed a record. Rejected.

2. **A confirm dialog on the button ("Are you sure?").**
   - Pros: an hour's work; no new component.
   - Cons: carries none of the information the clinician needs, so it trains a
     reflex rather than a reading. Also unstyleable and untranslatable through
     the message catalogs (FRONTEND_RULES 10). Rejected.

3. **A purpose-built attestation gate listing blocks / not-recorded / counts.**
   - Pros: compact; reuses the panel V3 already computes.
   - Cons: a second summary of a document the clinician is about to be shown
     anyway. Proposed in version 1.0 of this ADR and **rejected by the product
     owner on 2026-09-01** in favour of alternative 4, on the grounds that the
     thing worth checking before attesting is the document itself.

4. **The report itself as the gate (chosen).**
   - Pros: the clinician reads the actual output, rendered exactly as it will be
     kept and shared, before committing. Reuses `SignedReportOverlay` and its
     `onAcknowledge` rather than adding a surface. Nothing is written while
     previewing, so Back is free. The PDF is available at the moment it is
     genuinely useful.
   - Cons: the report must never *look* signed before it is — solved by the
     `pre-sign` variant and by withholding patient-facing delivery. One extra
     click on every encounter, forever. Accepted: it is the click that makes the
     footer sentence true.

## Consequences

- **Two states become distinguishable** that were conflated: "the clinician
  pressed Sign" and "the encounter is submitted". Nothing reading `docstatus` is
  affected; only the UI path changed.
- **V1's `sign()` is split in two** — `sign()` validates and flushes and opens
  the report; `finishSign()` submits, invalidates caches, stamps the real signer
  (ADR-039), submits draft vitals and books a pending follow-up. Kept as two
  functions because the halves fail differently: a failed flush must abort
  before the clinician is shown anything, while a failed submit happens with the
  report already on screen and must leave them there to retry.
- **`pendingSignId`** is new state in V1, because `prepareDraftForSign` may
  *create* the encounter, so the id does not exist before the preview.
- **V1's dead `"preparing"` overlay branch is reused** — it now shows while the
  draft actually flushes, instead of on a fixed 2.8 s timer after the work had
  already finished.
- **The post-sign overlay's `onAcknowledge` is now a receipt**, not a gate.
- Analytics `encounter.signed` fires on the submit, never on the button.
- **Re-evaluation trigger:** if clinicians report the extra click as friction on
  high-volume days, measure abandonment at the report before removing it. A gate
  nobody reads is a candidate for removal; a gate that catches mistakes is not.

## Verification

Driven in a real browser against `marley.local`, both surfaces.

**V3, `HLC-ENC-2026-00662`** — Sign & Close: pre-sign copy shown, Sign & finish
present, Download PDF available, Email and WhatsApp hidden, still on
`/encounters/…`, **0 `complete_encounter` calls**.

**V1 (classic), `HLC-ENC-2026-00662`** — Sign & close encounter → the existing
Review Details confirm appears, 0 submit calls; Confirm & Sign → pre-sign report,
Sign & finish present, Email/WhatsApp hidden, still on `/encounters/…`,
**0 `complete_encounter` calls**; Back → returns to the editable note at
`/encounters/…`, report dismissed, **not** `/patients/…`.

**Not yet verified:** the submit itself. Pressing Sign & finish creates an
irreversible `docstatus 1` on real data, so it was left for a deliberate
end-to-end run on a throwaway draft. The call it makes (`encountersApi.complete`)
is unchanged — only its trigger moved.

## References

- ADR-054 (one implementation, used by both surfaces)
- ADR-038 / ADR-039 (who may sign, who may cancel, what the signature names)
- ADR-020 (vaccine → nurse), ADR-025 (`bill_this`)
- [`architecture/ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md) §6.4 (Sign)
- Frontend constitution FE-15 (no claim the backend does not enforce)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Accepted, and the decision replaced. Version 1.0 proposed a purpose-built attestation gate; the product owner chose the report itself as the gate, which is what shipped. Alternative 3 now records the rejected proposal. Verification added for both surfaces |
| 1.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Proposed — a separate attestation gate. Superseded within the day by the decision above |
