# ADR-018: Pluggable compliance profiles — India and Mexico as first two markets

**Doc status:** living · **Created:** 2026-07-01 by Sarvesh-SocialAngel · **Updated:** 2026-07-01 by Sarvesh-SocialAngel · **Version:** 1.0

- **Status:** Accepted
- **Date:** 2026-06-30
- **Supersedes:** ADR-007 (Mexico-only jurisdiction lock)
- **Superseded by:** —

## Context

ADR-007 (2026-05-16) locked the jurisdiction to Mexico (LFPDPPP + NOM-024-SSA3-2010)
and deferred all other markets. The product owner has since confirmed that
**India (DPDPA 2023)** and **Mexico (LFPDPPP)** are the two active target markets,
with additional markets (US, Middle East, Southeast Asia) on the roadmap but not
yet scoped.

This decision is needed now because several items in flight key off jurisdiction:

- The AI scribe consent banner contains hardcoded "HIPAA" text — wrong for both
  active markets.
- The `AI Settings` doctype and the planned `/api/scribe/` module need to enforce
  audio retention rules that differ by market.
- i18n strings for compliance badges are hardcoded to a single law name.

Writing these components against a single-jurisdiction assumption requires rework
as soon as the India deployment begins.

The product owner also confirmed that a **separate Frappe custom app per
jurisdiction** is not the right approach. The compliance differences between
markets are configuration-level (retention numbers, label strings, consent type),
not architecture-level (different doctypes, different workflows). 20 lines of
config per market does not justify full Frappe app overhead.

## Decision

Replace the Mexico-only jurisdiction lock with a **pluggable compliance profile**
architecture. Each deployment activates one profile via `remedisys_compliance_profile`
in `site_config.json`. The active profile is the single source of truth for all
compliance-sensitive decisions in the application.

Concrete consequences:

1. A `compliance/` module is added inside `remedisys_healthcare_ai` (not a
   separate app). It exports a `ComplianceProfile` frozen dataclass, two profile
   files (`mx.py`, `india.py`), and a `get_active_profile()` function.

2. All compliance-sensitive code (retention enforcement, consent gate, AI scribe
   audio handling, breach notification, erasure endpoints) reads from
   `get_active_profile()` — never from hardcoded constants or conditional
   `if jurisdiction == "mx"` branches.

3. Two deployments are supported from day one:
   - **Mexico:** `"remedisys_compliance_profile": "mx"` → LFPDPPP + NOM-024-SSA3
   - **India:** `"remedisys_compliance_profile": "in"` → DPDPA 2023 + ABDM

4. i18n compliance strings in `en.json` and `es.json` are updated to remove
   hardcoded law names. The frontend reads `NEXT_PUBLIC_COMPLIANCE_PROFILE` (set
   per Vercel deployment) and maps it to display text via a client-side helper.

5. Adding a third market requires only: a new profile file + a new Vercel
   deployment with the env var. No schema changes, no new app, no new CI gate.

6. ADR-007's Mexico-as-primary-market stance is preserved — `"mx"` is the default
   when `remedisys_compliance_profile` is absent.

## Alternatives Considered

### 1. Separate Frappe app per jurisdiction
e.g. `remedisys_compliance_mx`, `remedisys_compliance_in`.

- Pros: Clean isolation; each market independently versioned and installable.
- Cons: Full Frappe app overhead (hooks.py, modules.txt, install lifecycle, CI
  gate) for 20 lines of config. Cross-app imports add complexity. Install order
  matters. **Rejected.**

### 2. `EB Compliance Settings` Frappe Single doctype
Store profile values in the database, editable via Desk UI at runtime.

- Pros: No code deploy needed to change settings.
- Cons: Compliance settings must not be changeable at runtime without a deliberate
  deployment step. Allowing an admin to accidentally switch jurisdictions mid-operation
  is itself a compliance violation. Runtime-editable doctype is the wrong tool.
  **Rejected.**

### 3. Frozen dataclass per profile, activated by site_config.json (chosen)
- Pros: Immutable once loaded; typed so incorrect profiles fail at import time;
  zero Frappe overhead; adding a market is one file + one env var; works with
  `bench` and Frappe Cloud.
- Cons: Requires worker restart to change profile (acceptable — profile is a
  deployment constant, not a runtime setting). **Accepted.**

## Consequences

- **CLAUDE.md §3 amendment:** `Jurisdiction` row changes from
  "Mexico — LFPDPPP + NOM-024-SSA3-2010" to
  "India + Mexico — pluggable via `ComplianceProfile`; see ADR-018. `mx` is default."
  `Languages` row updated: add `en-IN` for India deployment.

- **ADR-007 superseded.** Mexico remains primary/default. The Mexico-first
  stance is preserved.

- **Files created by this ADR:**
  - `remedisys_healthcare_ai/compliance/__init__.py` — `get_active_profile()`
  - `remedisys_healthcare_ai/compliance/base.py` — `ComplianceProfile` dataclass
  - `remedisys_healthcare_ai/compliance/profiles/__init__.py`
  - `remedisys_healthcare_ai/compliance/profiles/mx.py` — Mexico profile
  - `remedisys_healthcare_ai/compliance/profiles/india.py` — India profile

- **i18n fix (frontend, separate task):** Hardcoded `"HIPAA"`, `"LFPDPPP"`,
  `"HIPAA-ready"` strings in `en.json` and `es.json` replaced with neutral text
  or profile-driven interpolation keyed by `NEXT_PUBLIC_COMPLIANCE_PROFILE`.

- **AI scribe impact:** `audio_retention_days` from the active profile gates
  whether audio may be stored. `transcript_retention_days` drives the cleanup job
  cadence. `consent_type` drives whether the consent checkbox is shown in the
  capture modal.

- **Re-evaluation trigger:** If a third market (US, Saudi Arabia, UAE, Singapore)
  is added, this ADR remains valid — add a new profile file. Revisit only if a
  new market requires fundamentally different Frappe doctypes or workflows.

## Verification

- `compliance/profiles/mx.py` and `india.py` import cleanly with no Frappe
  context (pure Python dataclass).
- `get_active_profile()` returns the correct `ComplianceProfile` for each
  `site_config.json` value (`"mx"`, `"in"`).
- `get_active_profile()` raises `frappe.ValidationError` for unknown profile codes.
- i18n files contain no bare instances of `"HIPAA"` or `"LFPDPPP"` as UI-visible
  strings.
- `NEXT_PUBLIC_COMPLIANCE_PROFILE` is set in both Vercel deployment configs.

## References

- ADR-007: Lock jurisdiction to Mexico (superseded)
- ADR-005: Frappe Cloud deployment — Rule 3 (no separate FastAPI service)
- ADR-011: eb_frappe_jwt Bearer JWT auth
- CLAUDE.md §3 Locked Assumptions — Jurisdiction and Languages rows
- LFPDPPP (Mexico): Ley Federal de Protección de Datos Personales en Posesión de los Particulares (2010)
- NOM-024-SSA3-2010: Sistemas de información de registro electrónico para la salud
- DPDPA 2023 (India): Digital Personal Data Protection Act 2023
- ABDM: Ayushman Bharat Digital Mission Health Data Management Policy

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-01 | Sarvesh | Initial version (header backfilled from git history) |
