# ADR-080: A template per report type, chosen by the model and created when missing

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.1

- **Status:** Accepted — requested and signed off by Divyanshu, 2026-09-22
- **Amends:** the single-prompt assumption behind `multi_panel_extraction_v*.txt`, and the
  2026-07-02 "Decisions locked with the team" block in
  [`docs/AI_MULTI_PANEL_LAB_EXTRACTION.md`](../AI_MULTI_PANEL_LAB_EXTRACTION.md)
  (cited in code as "ADR-022"/"ADR-023", neither of which exists — see §6).
- **Builds on:** `AI Chat Template` and the Narzim GPT template services
  (`services/narzim_template_suggest.py`, `narzim_template_generate.py`,
  `narzim_template_fill.py`), all already on `dev`.

---

## 1. Context — one prompt for every specialty

Every uploaded report, whatever it is, is extracted with a single instruction set:
`multi_panel_extraction_v14.txt`, 301 lines, loaded unconditionally by
`integrations/llm.py::extract_multi_panel_report`. There is no per-report-type selection
anywhere in the pipeline, and the prompt version is a hardcoded Python default that
`AI Settings` cannot override.

The reports it has to cover have almost nothing structurally in common:

| Specialty | Shape of the report |
|---|---|
| Paediatrics | Discrete numeric analytes, age-banded reference ranges |
| ENT | Audiometry — a frequency x decibel grid, left ear vs right ear |
| Orthopaedics | MRI — prose: TECHNIQUE, FINDINGS, IMPRESSION |
| Nephrology | Numeric panel plus derived staging (eGFR category) |
| Cardiology | Measurements **and** prose **and** a printed diagram |

One instruction set covering all of these handles each of them adequately at best. The
prompt has absorbed the variety internally instead — a "STEP 0 classify, then branch"
structure that has grown across 14 versions — and every new report shape makes that single
file longer and more conditional.

## 2. Decision

Introduce a **library of report-type templates**, and let the pipeline extend it.

1. **The template is both structure and instructions.** An `AI Chat Template` record's
   `sections` declare what the output contains; its `body_markdown` carries the guidance for
   filling them. A cardiology echo template has a numeric *Measurements* section and a prose
   *Findings/Impression* section, so numeric and narrative reports stop being two code paths.
2. **The model chooses the template.** On upload, the existing templates are exposed to the
   model along with the documents; it states which template each document is.
3. **When nothing fits, the model writes a new template** and it is saved to the library
   automatically, with no human confirmation step. The next report of that type is
   recognised.
4. **Extraction then runs against the chosen template.**

The library therefore starts at whatever the clinic already has, and each unseen report type
adds itself exactly once. No one has to enumerate specialties up front, which is the property
that makes "handle every type of report" achievable rather than an endless prompt-writing task.

### What does NOT change

- **A section holding real measurements still produces `Lab Test` values.** Trends, abnormal
  flagging (`services/labs.py::result_flag`), the Patient 360 Lab tab, lab result summaries
  and the AI clinical summary all keep working. The template decides what shape to look for;
  it does not turn lab results into prose.
- Extraction still **never writes a clinical value**. Proposals land on `AI Prompt Log`; only
  a physician's own save/submit persists a result (Rule 6). Automatic creation applies to the
  **template**, never to a patient's result.
- Name-first analyte matching (ADR-032) and deterministic unit resolution
  (`services/lab_units.py`) are unchanged within a chosen template.

## 3. Also decided in the same change

- **The uploader may attach a note**, and it is sent to the model as context in both stages.
  It is delimited and framed as data: it cannot override what is printed on the document.
  A BAA is in place with the providers on the allowlist, so note content reaching a provider
  is not treated as an external-party disclosure.
- **OCR verification is removed from the lab path.** `_ocr_verified_positions` is deleted.
  It never extracted anything and its output never reached the model — it only proved a file
  was already covered so an LLM re-check could be skipped.

## 4. Consequences accepted

| Consequence | Detail |
|---|---|
| **Provider calls roughly double** | A selection call plus an extraction call per upload |
| **Recovery gets more expensive** | Without OCR verification every unverifiable file costs an LLM re-check. Previously measured: 3 re-checks instead of 6, and 0 instead of 6 when nothing was missing. Extraction accuracy is unaffected |
| **Recovery machinery is unaffected** | Selection is an ADDITIONAL call placed before extraction; the extraction call's request and response shape are unchanged, so ADR-052's completeness check and bounded per-file recovery keep working as written. An earlier draft of this ADR claimed they had to be re-derived — that was true of a rejected design in which extraction's analyte list was scoped per template, and is not true of what was built |
| **A wrong template choice propagates** | Previously a mis-match was caught afterwards by the coverage and unit guards; now it shapes extraction |
| **Unreviewed AI-authored templates enter the library** | An auto-created template governs every later report of that type. This is the deliberate cost of self-extending coverage. Templates are versioned (`AI Chat Template.version`) and editable, so a bad one can be corrected rather than only deleted |

## 5. Alternatives rejected

| Approach | Why rejected |
|---|---|
| Keep one prompt and keep growing it | The status quo. Every new report shape lengthens a single 301-line conditional file; quality per specialty stays flat |
| Hand-write a prompt per specialty | Does not scale and never finishes — an unseen report type is always a gap until someone writes it. Auto-creation is the whole point |
| Reuse `suggest_templates` (deterministic, no model call) | Free and instant, but it matches on text and cannot read an uploaded PDF or a scan, so it cannot judge a report it has no text for |
| Replace structured extraction with templated documents | Would turn lab results from queryable data into prose: no trends, no abnormal flags, nothing for the clinical summary to read |

## 6. Note on the phantom ADR citations

`services/lab_panel_extraction.py` and `services/lab_catalog.py` cite **ADR-022** (one call
per upload, deterministic bucketing) and **ADR-023** (continuous learning without a
suggestion queue) as authority. Neither exists: `docs/adr/adr-022-*` is *Nurse encounter
draft write* and `adr-023-*` is *Cash drawer & shift reconciliation*. The decisions are real
and recorded in the design document's 2026-07-02 block; only the numbers are wrong.
`docs/adr/` also carries nine duplicate numbers (018, 020, 026, 027, 028, 030, 038, 061,
063), which is why `scripts/check_adr_numbering.py` fails on `dev`. Both pre-existing; not
addressed here.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-22 | Divyanshu (AI-assisted) | Corrected §4: selection is additive, so ADR-052's recovery machinery is unaffected |
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial version — per-report-type templates chosen by the model and auto-created when missing; uploader note; OCR verification removed |
