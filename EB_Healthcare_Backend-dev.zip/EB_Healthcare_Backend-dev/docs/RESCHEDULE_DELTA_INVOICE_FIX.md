# Reschedule Delta Invoice Tax Fix & Invoice-Trail Visibility — Mechanism

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.0

## 1. Scope

Two related fixes found investigating one live billing trail: why `_create_reschedule_delta_invoice` silently drops tax on a fee-increasing reschedule/reassign, and why the Patient Chart only ever showed one invoice per appointment when a reassignment creates more than one. See [ADR-072](adr/adr-072-reschedule-delta-invoice-tax-fix-and-invoice-trail-visibility.md) for the decision and alternatives; this is the mechanism, layer by layer.

## 2. The reported trail

Patient Diego Gómez Reyes (MRN-2026-0001427):

1. Booked with Sarvesh Sandhu, fee 500 + 16% tax = **580**. Invoiced (`ACC-SINV-2026-01011`) and paid in full through the normal booking path.
2. Reassigned to Anant Sharma, fee 1000. Delta invoice `ACC-SINV-2026-01012` for **420** (1000 − 580 already paid). Anant's own consultation item happens to carry no tax template at all, so 420 with zero tax was actually correct for this leg.
3. Reassigned to Dr Hathi, fee 2000. Delta invoice `ACC-SINV-2026-01013` for **1137.93** — should have been **1320** (2320 tax-inclusive target − 1000 already paid).

## 3. Root cause 1 — tax silently dropped

`adjust_payment_for_reschedule` (`services/billing.py`) computes the target correctly:

```python
quote = consultation_fee_with_tax(new_practitioner, new_appointment_type, override=flt(new_fee))
new_fee_incl_tax = quote["fee_incl_tax"]        # 2320
delta = round(new_fee_incl_tax - flt(old_paid_amount), 2)   # 1320
...
delta_pretax = round(delta / (1 + tax_rate / 100), 2)        # 1137.93
```

`delta_pretax` (1137.93) is passed to `_create_reschedule_delta_invoice` as the row's `rate`, on the assumption that core will re-apply 16% tax at submit time to reproduce the intended 1320. It never did, because the row never carried enough information for core's tax engine to act on:

```python
si.append("items", {"item_code": item_code, "qty": 1, "rate": amount})
si.set_missing_values()
...
row.rate = amount
# item_tax_template was never set here — the bug
si.save(ignore_permissions=True)
si.submit()
```

**Setting `item_tax_template` alone is not sufficient**, confirmed empirically:

```
{"item_tax_template_resolved": "Mexico Tax - N", "total_taxes_and_charges": 0.0, "grand_total": 1137.93}
```

Core's `accounts_controller.py::append_taxes_from_item_tax_template` — the step that actually creates the header Sales Taxes and Charges row — reads `row.item_tax_rate`, a separate JSON `{account_head: rate}` field:

```python
def append_taxes_from_item_tax_template(self):
    for row in self.items:
        item_tax_rate = row.get("item_tax_rate")   # NOT item_tax_template
        if not item_tax_rate:
            continue
        ...
```

`item_tax_rate` is only ever populated by `get_item_details()`/`get_item_tax_map()` — never derived automatically just because `item_tax_template` is set. `_build_pos_invoice_doc` (ADR-071, same file) worked correctly by coincidence of call ORDER — its `set_missing_values()` runs *after* `item_tax_template` is assigned, and something in that later call path resolves `item_tax_rate` from it. `_create_reschedule_delta_invoice` calls `set_missing_values()` *before* setting the template, so by the time the template was set, nothing re-ran the resolution.

**Fix** — set both fields explicitly, matching what core's own `get_item_details()` would produce:

```python
tax_template = _item_tax_template_map([item_code]).get(item_code)
if tax_template:
    from erpnext.stock.get_item_details import get_item_tax_map
    row.item_tax_template = tax_template
    row.item_tax_rate = get_item_tax_map(doc=si, tax_template=tax_template, as_json=True)
```

**Verified**, same technique as ADR-071 (build the identical doc, call `.validate()` only, never insert/save):

```
{"item_tax_template_resolved": "Mexico Tax - N", "total_taxes_and_charges": 182.07, "grand_total": 1320.0}
```

`1320.0` is exactly the intended target; `182.07` is exactly the amount Diego was actually shorted.

## 4. Root cause 2 — Patient Chart could only show one invoice per appointment

`appointments-tab.tsx`'s "See Invoice" button reads `appt.billing.invoice` — always the appointment's own `ref_sales_invoice`, which core's Healthcare module only ever attaches to the ORIGINAL invoice (delta invoices are deliberately unlinked, to avoid Healthcare's on_submit "already invoiced" re-validation — see `_create_reschedule_delta_invoice`'s own docstring). So Diego's two delta invoices were invisible in the Patient Chart, findable only via the clinic-wide Revenue/Billing hub.

**The data was already there.** `api/v1/appointments/api.py::_billing_for` (called by every appointment list/get response's `_fmt`) already computes `billing.invoices` — every invoice billing the appointment, batched for a whole page (`_billing_context`, no N+1):

```python
"invoice": original or (names[0] if names else None),
"invoices": per_invoice,   # every invoice, each with its own total/paid/outstanding
```

Confirmed live by calling `list_appointments` directly against Diego's patient:

```json
"billing": {
  "invoice": "ACC-SINV-2026-01011",
  "invoices": [
    {"name": "ACC-SINV-2026-01011", "total": 580.0, ...},
    {"name": "ACC-SINV-2026-01012", "total": 420.0, ...},
    {"name": "ACC-SINV-2026-01013", "total": 1137.93, ...}
  ],
  ...
}
```

The frontend `AppointmentBillingInvoice[]` type already existed for exactly this (`types/appointments.ts`, with a doc comment naming this exact scenario) — nothing ever rendered it.

**First attempt, reverted**: before finding the above, a new whitelisted-method-backed endpoint/hook was built wrapping the existing-but-unused `get_reschedule_history` (`api/v1/appointments/api.py`). Reverted once `billing.invoices` was found — it would have added an extra request per appointment row (N+1 in a list view) to fetch data the list endpoint already returns in one batched call.

**Fix**: `AppointmentRow` now derives `extraInvoices = appt.billing.invoices.filter(inv => inv.name !== appt.billing.invoice)` and renders them as a small collapsed disclosure inside the existing Actions cell (flex-wrap, not a new grid row — the card's layout is CSS Grid and a stray sibling `<div>` would have landed in the wrong column). Each entry opens the same `InvoicePreviewSheet` via a new optional `onInvoice(appt, invoiceOverride?)` parameter.

## 5. What did NOT change

- No historical invoice was recomputed. Diego's `ACC-SINV-2026-01013` stays at 1137.93 — the fix is forward-only, matching how ADR-071's tax bug was handled the same day.
- Anant Sharma's practitioner record (`op_consulting_charge_item` pointing at a nebulizer-administration item instead of a consultation-fee item) was found during this same investigation and is explicitly out of scope here — flagged separately, not touched.
- `get_reschedule_history` (the endpoint the first, reverted attempt wrapped) is untouched and still unused by any frontend — left as a legitimate, richer-detail API for a future screen that wants the reassignment narrative specifically, not removed.
- No backend change was needed for the invoice-trail visibility fix — `_billing_for`/`_billing_context` were already correct.

## 6. Testing

Live, read-only verification only (no automated test added this pass):

- Confirmed the original bug reproduces exactly (`total_taxes_and_charges: 0.0`) by replicating `_create_reschedule_delta_invoice`'s pre-fix code in a throwaway, never-saved draft.
- Confirmed the fix produces the correct `grand_total: 1320.0` with a real `IVA - N` tax row of `182.07`, the same way.
- Confirmed `billing.invoices` already returns all 3 real invoices for Diego's appointment via a direct call to the live `list_appointments` function.
- A test asserting a real `create_pos_invoice`/reschedule-delta invoice's tax matches its own preview computation would be a reasonable follow-up for both this fix and ADR-071's.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
