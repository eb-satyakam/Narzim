# Lab Results + AI Report Extraction — Committed Design & Milestones

**Doc status:** living · **Created:** 2026-07-02 by Divyanshu · **Updated:** 2026-09-23 by Nishant · **Version:** 1.2

> **Status:** Committed 2026-06-30, after reading backend (`remedisys_healthcare_ai`) and frontend
> (`EB_Healthcare_Frontend`). **Owner:** backend. Frontend handed off via API contract (edited only on request).
>
> **Progress:** M1 ✅ · M2 ✅ · M4 ✅ · M5 ✅ (incl. LLM-assisted EN/ES analyte matching) — all backend, verified end-to-end on `remedisis.localhost`.
> **M3 (frontend) scheduled 2026-07-01.** M6 (compliance gate) pending before any real-environment go-live.
> **2026-07-02 — ADR-021** supersedes ADR-019 G6: the pipeline no longer writes AI values to the Draft at
> all (previously it wrote immediately on extraction, guarded against clobbering manual edits). It now only
> proposes (`AI Prompt Log`); the frontend renders the proposal as editable, unsaved form state; only the
> physician's own Save/Submit ever persists a value. §2 and §6 below reflect this.
>
> **Locked decisions:** (1) manual result flow first, AI second; (2) Service-Request-anchored spine
> (ERPNext-correct); (3) the reading stays on the **core Lab Test** — no new reading doctype;
> (4) audit goes in a new **`AI Prompt Log`** doctype; (5) external referrals are recorded but **not charged**.

---

## 1. Goal & the two scenarios

A lab is ordered → patient completes it → results land on the lab record → trends + abnormal flags.
The path splits on **`EB Clinic Settings.has_internal_lab`** (same pattern as pharmacy), tagged onto
`Service Request.source` at encounter submit:

| | In-house (`source="Direct"`) | External (`source="External Referral"`) |
|---|---|---|
| Performed by | Us | Outside lab |
| **Charge** | We charge the test | **Nothing** — the outside lab bills the patient; we only record the result |
| Result entry | Staff enters directly (manual) | Patient brings a report → **upload + AI extract** |
| Recorded in EHR? | Yes | Yes — same Lab Test record |

Both converge on the same `Lab Test` result rows. **The AI is the external path's result-entry method.**

## 2. Doctypes

**Reused as-is — no new doctype, no core edit:**

| Doctype | Role |
|---|---|
| **Service Request** (core) | The order; created by core on encounter submit (`template_dt="Lab Test Template"`, `template_dn`=template name) |
| **Lab Test** (core) | The reading record — created *against* the SR at result time, via core `create_lab_test_doc` |
| **Normal Test Result** (core child) | The values — `result_value` per analyte row |
| **Lab Test Template** (core) | Analyte definitions; **Compound** for multi-parameter panels |
| **Sample Collection** (core) | Sample tracking (core-driven, optional) |
| **File** / **Patient Medical Record** (core + our flag) | The uploaded report file (private), via the existing document-upload pattern |
| **EB Clinic Settings** (ours) | `has_internal_lab` → internal vs external |
| **AI Settings** (ours) | + one field `enable_lab_extraction` (Check, default OFF) |

**New doctype — exactly one, for AI audit:**

**`AI Prompt Log`** (`track_changes:1`; perms System Manager full, Physician read):

| Field | Type | Notes |
|---|---|---|
| patient | Link → Patient | indexed |
| lab_test | Link → Lab Test | indexed — the reading it produced |
| service_request | Link → Service Request | |
| purpose | Select | `Lab Extraction` (extensible) |
| model | Data | `claude-sonnet-4-6` |
| prompt_version | Data | `v1` |
| prompt_hash | Data | sha256 of the prompt file |
| raw_response | Long Text | model JSON — clinical audit (PHI allowed here; this is a record, **not** a log sink) |
| tokens_in / tokens_out | Int | |
| cost_estimate_usd | Currency | |
| latency_ms | Int | |
| status | Select | `Success` / `Failed` |
| skipped_manual_edits | Small Text | unused since ADR-021 (superseded ADR-019 G6) — kept on the doctype, always empty |
| qualifier_conflicts | Small Text | "report line → ordered analyte" pairs held back because their qualifiers explicitly clash — e.g. printed "Direct" vs an ordered "Total" (ADR-019 G7) |
| filled_rows | Long Text | JSON `[{row\|test_name, result_value, uom, reference_range}]` — the AI's **proposed** rows, exposed to the frontend via `get_extraction_status`'s `proposed` key. **Not applied to the Draft** (Rule 6; ADR-021) |
| error | Small Text | clean message on failure — **no PHI** (Rule 10) |

One row per call → retry history + spend reporting + records failures even before a Lab Test exists.
Since ADR-021 (2026-07-02, supersedes ADR-019 G6), the pipeline never writes to the Draft Lab Test —
`filled_rows` / `raw_response.transcribed_report` are proposals the frontend renders as editable, unsaved
form state. Only the physician's own Save (`record_result` / `record_imaging_result`) or Submit ever
persists a value, so a re-extraction can never clobber a manual edit — there is nothing left to clobber.

## 3. The spine — Service-Request-anchored

```
Encounter submit ──(core)──▶ Service Request (template_dt="Lab Test Template", order_group=encounter)
                                   │
result entry / report upload ──────▶ ensure_lab_test_for_service_request(sr)
                                   │   = core create_lab_test_doc(practitioner, patient, template, company)
                                   │     + lab_test.service_request = sr   (core before_insert guards dup)
                                   │     + core after_insert builds Normal Test Result rows from the template
                                   ▼
                            Lab Test (Draft) ── fill result_value ── physician SUBMIT
                                   │                                       │
                                   │                     core on_submit: status=Completed,
                                   ▼                     Service Request → completed-Request Status
                            Trends read result_value over time
```

**Eager creation (2026-07-01):** the Patient Encounter `on_submit` hook
(`overrides/encounter_orders.py`) now calls `ensure_lab_test_for_service_request`
for each ordered lab, so the Draft Lab Test exists **at order time** and the order is
immediately visible/actionable in the Lab Center worklist (which lists Lab Tests).
Result entry / report upload still call the same idempotent function, so lazy
creation remains the fallback. The eager step is savepoint-isolated and logs on
failure — it never rolls back the encounter submit (Rule 7 spirit).

`template_dn` is the **template name** (verified `patient_encounter.make_service_request`), so we resolve
the template by name — not core's `get_lab_test_template` (which looks up by linked Item and would miss).

## 4. AI = constrained result-entry assistant (not a free-form parser)
The AI reads the report **in the context of the ordered test's expected analytes** (from the Compound
template), returns a value per analyte + extras flagged `expected=false` (never dropped), and writes into
the **Draft** Lab Test — the same Draft a human fills. Physician submits (Rule 6). The model only ever
sees the file (Rule 4). Prompt is a versioned file, hashed (§9). Provider is pluggable (ADR-018) — Claude
Sonnet is the default from AI Settings (§3); OpenAI is dev-only until its own compliance gate clears.

**Matching by index, not name (prompt v3, ADR-019 G4):** the expected analytes are handed to the model as a
*numbered* list, and the model's primary identifier for a match is `matched_index` — the exact array
position — not the echoed analyte name. This survives the model abbreviating/normalizing the name on the
way back (e.g. returning "WBC" for the ordered "WBC Count"), which previously demoted a correct mapping to
"unmatched". `matched_analyte` (the name) is kept for audit/readability and as a fallback match when the
index is missing or out of range.

**Qualifier safety (prompt v4, ADR-019 G7):** some analytes share a base name but are clinically distinct
tests — fasting vs random vs postprandial glucose; direct vs indirect vs total bilirubin; free vs total
T3/T4/PSA/testosterone; ionized vs total calcium. The index fix (G4) makes the model's *stated* match
robust, but not necessarily *correct* when a report prints several qualified variants of the same base
analyte. Two layers: (1) prompt v4 explicitly instructs the model not to force a qualifier-mismatched match
— set `matched_index` to null instead of guessing; (2) `services/lab_qualifiers.py` is a deterministic
backend check (Rule 9, not another LLM call) that independently compares the ordered analyte's own name
against the report's printed parameter name — if they name *different* qualifiers from the same group, the
match is held back (never applied) and surfaced under `qualifier_conflicts` for manual placement. One-sided
or unqualified cases are not flagged — there's nothing to contradict, and G3 already shows the source label.

**Descriptive (qualitative) results (ADR-019 G9):** numeric (Normal Test Result) and descriptive
(Descriptive Test Result) rows share ONE combined, continuous `matched_index` space — no prompt or
schema change was needed, since the model already just transcribes a report line's printed value as
a string; "Cloudy" is as valid a `value` as "13.5". `services/labs.py` decides how to write a match
based on the resolved row's own doctype: numeric rows get the full unit/range/conversion treatment
(G1/G2/G5); descriptive rows get the verbatim text only — no unit, no range, no flag.

**`lab_test_template_type` coverage audit (2026-07-02):** core supports six types — Single, Compound,
Descriptive, Grouped, Imaging, No Result. Audited each against `record_result` + the AI pipeline:
- **Single** — uses the SAME `normal_test_items` table as Compound (core's `create_normals` appends
  one row, `lab_test_name` = the template's own name). Already worked through the existing numeric
  path; verified with a dedicated test, no code change needed.
- **Compound**, **Descriptive** — covered as above.
- **Grouped** — can combine Single/Compound/Descriptive sub-templates on ONE Lab Test. Found a real
  gap: core inserts a "heading" row (`require_result_value=0`) ahead of each Compound/Descriptive
  sub-template's real rows — a section-divider carrying the sub-template's own name, never a real
  result target. The numeric heading's `lab_test_name` IS matchable, so before this fix a report
  parameter or a physician's typed test name equal to that heading text would have written a value
  into a structural divider. **Fixed:** both `record_result` and the pipeline's `labeled_rows` now
  exclude any row where `require_result_value` is falsy — safe for every existing case (real rows,
  however created, always have it truthy) and closes the gap for Grouped headings specifically.
- **Imaging** — NOT a child-table result at all; core's `create_imaging` sets a single free-text/rich-text
  field (`descriptive_result`) directly on the Lab Test, copied from the template's own boilerplate
  text. Architecturally a different kind of result (one narrative blob, not discrete
  analyte/particular slots). **Decision (2026-07-02): built** — see §7.
- **No Result** — core never creates a Lab Test for this type (see the type's own doc-string: "no Lab
  Test will be created"). Confirmed by the code that explicitly special-cases it. Nothing to build —
  there is no document for our result-entry/AI-extraction system to ever act on.

## 4a. Imaging report AI transcription (ADR-019 gap G14b)

Scope: **transcription only** — the model reads an imaging report (image/PDF) and transcribes its FULL
text verbatim (preserving section headers like FINDINGS/IMPRESSION) into the Lab Test's ONE
`descriptive_result` field. This is deliberately NOT AI-generated report drafting/dictation — that is a
different, out-of-scope capability belonging to the Phase 5 ambient-documentation roadmap.

Because there are no discrete slots, this does not reuse `matched_index`/`LAB_EXTRACTION_SCHEMA` at all:
- `integrations/llm.py` gains a parallel, uniform result type — `ImagingExtractionResult` — and schema —
  `IMAGING_EXTRACTION_SCHEMA` (`report_date`, `lab_name`, `transcribed_report`) — plus a dispatcher
  `extract_imaging_report()` routing to the configured provider (same `AI Settings.llm_provider` as lab
  extraction, ADR-018).
- `integrations/anthropic.py` / `integrations/openai.py` each gain `extract_imaging_report()`, loading a
  SEPARATE versioned prompt family (`llm/prompts/imaging_transcription_v{n}.txt`, distinct from
  `lab_extraction_v{n}.txt`). `_call_claude`/`_call_openai` (the SDK-boundary functions) were parametrized
  to accept any schema — `LAB_EXTRACTION_SCHEMA` remains their default, backward-compatible.
- `services/labs.py::record_imaging_result(lab_test, transcribed_report, ai_reference=None)` — the
  write path. NOT `record_result` (no rows to match). Validates `doc.imaging_toggle`. The G6
  clobber-protection principle applies to a single field: a re-run's `ai_reference` is compared against
  the CURRENT text, but — unlike a numeric/descriptive row, which starts blank — an Imaging Lab Test
  starts holding the TEMPLATE's own boilerplate skeleton (core's `create_imaging` copies it at creation).
  The guard treats that boilerplate as "untouched" (not human content), so the FIRST AI transcription can
  still fill a freshly-ordered Imaging test; only a genuine human edit blocks a subsequent overwrite.
- `services/imaging_extraction.py::run_imaging_extraction` — the RQ pipeline (mirrors
  `services/lab_extraction.py`'s shape). Its "ai_reference" is parsed back out of the prior successful
  run's own `raw_response` (`AI Prompt Log.purpose="Imaging Transcription"`) rather than a dedicated
  field — no schema change needed for G6 parity.
- `api/ai/imaging_extraction.py` — `upload_imaging_report`, `extract_imaging_report`,
  `get_imaging_extraction_status`. Gated on the **SAME** `AI Settings.enable_lab_extraction` flag as lab
  extraction (not a separate flag) — imaging transcription is part of the one AI lab-test feature, sharing
  its compliance gate (M6).
- `api/v1/labs/api.py::record_imaging_result` — the manual-entry whitelisted endpoint.
- `AI Prompt Log.purpose` gained `"Imaging Transcription"` as a second Select option.
- **Frontend (2026-07-02, `EB_Healthcare_Frontend`):** `LabResultEntryDialog` now branches by the Lab
  Test's own `is_imaging` flag (from `get_lab_test`) — an Imaging-type test renders a single free-text
  textarea (manual entry, or AI-transcribed for review) instead of the numeric/descriptive table, chosen
  by what the Lab Test actually is, never a client-side guess. New BFF routes
  `/api/labs/imaging-{upload,extract,extraction-status,result}` mirror the lab-extraction ones.

## 5. Panel templates (data prerequisite)
Multi-analyte results need `Compound` Lab Test Templates (analytes as `normal_test_templates`
rows); qualitative results need `Descriptive` templates (particulars as `descriptive_test_templates`
rows). Seeded as a starting point (refine clinically later) — `scripts/seed/seed_lab_panels.py`:

**Compound (numeric):**
- **Complete Blood Count (CBC)** — Hemoglobin, Hematocrit, RBC, WBC, Platelets, MCV, MCH, MCHC.
- **Basic Metabolic Panel** — Glucose, Urea (BUN), Creatinine, Sodium, Potassium, Chloride.
- **Lipid Profile**, **Liver Function Test (LFT)**, **Thyroid Profile**, **Serum Electrolytes**.
- **CBC with Differential** (20 rows), **Comprehensive Metabolic Panel (CMP)** (14 rows),
  **Coagulation Panel (PT/INR/aPTT)**, **Iron Studies** — broader *separate* variants
  (2026-07-02), not bigger versions of the panels above. Mirrors how real lab catalogs offer
  "CBC" and "CBC with Differential" as distinct orderable tests, so a basic order stays lean
  (no permanently-blank rows) while a fuller order has a home for what it actually measures.
  **Decision (2026-07-02): this is the closing answer to ADR-019 gap G8** (report analytes
  with no matching row) — an on-the-fly "add analyte" affordance was considered and explicitly
  **not built**; worst-case template design is the accepted mitigation, residual long-tail risk
  accepted.

**Descriptive (qualitative, free text — ADR-019 gap G9, done 2026-07-02):**
- **Urinalysis (Routine)** (18 particulars: Color, Appearance, pH, Specific Gravity, dipstick
  panel, microscopy).
- **Stool Routine Examination** (6 particulars).

Descriptive rows have no unit/range/numeric-flag concept — `record_result` and the AI pipeline
fill them with the verbatim text (see §4/§6). `get_lab_test` reports `status: None` for them
rather than a fabricated "Normal" — a related frontend bug (a completed order's detail view was
rendering a green "Normal" badge for ANY non-numeric result, purely because `parseFloat` failed)
was fixed alongside this in `EB_Healthcare_Frontend`.

**CBC with Differential adds a new qualifier-conflict class:** each cell type is reported twice —
as a **percent** ("Neutrophils %") and an **absolute count** ("Neutrophils Absolute"/"ANC") — the
same "two clinically distinct numbers, one base name" shape as G7. `services/lab_qualifiers.py`
gained a percent-vs-absolute group so this is protected the same way. Note the "%" token needed a
small fix: percent-vs-absolute's `%` symbol can't use the existing word-boundary match (no `\w`/`\W`
transition when it's surrounded by spaces), so symbol-bearing tokens fall back to a plain substring
check.

Seed script: `scripts/seed/seed_lab_panels.py` (idempotent, non-billable, UOM set only if the Lab Test UOM exists).

## 6. Code components (backend)

| File | Purpose | Today |
|---|---|---|
| `services/labs.py` | `ensure_lab_test_for_service_request`, `record_result`, `submit_lab_result`, `record_imaging_result` (G14b), range parse + flag | empty |
| `api/v1/labs/api.py` | + `list_pending_lab_orders`, `record_result`, `submit_lab_result`, `record_imaging_result`; fix `get_lab_test` `normal_low/high/status` | read-only |
| `scripts/seed/seed_lab_panels.py` | seed CBC + BMP Compound templates | new |
| `integrations/anthropic.py` | Claude Sonnet client — schema-locked PDF/image extraction, constrained to ordered analytes | empty |
| `llm/prompts/lab_extraction_v{1,2,3,4}.txt` | versioned, hashed prompt (§9); v3 = index-based matching (G4); v4 = qualifier-safety rule (G7) | new |
| `services/lab_extraction.py` | deterministic RQ pipeline: load File → extract → map to rows → fill Draft → write AI Prompt Log | new |
| `api/ai/lab_extraction.py` | `upload_lab_report`, `extract_lab_report` (enqueue), `get_extraction_status` — gated on flag | new |
| `AI Prompt Log` doctype | audit (§2) | new |
| `AI Settings` | + `enable_lab_extraction` (Check, default OFF); + `llm_provider`, `openai_model` (ADR-018) | field add |
| `integrations/llm.py` | provider-agnostic dispatcher + shared schema/prompt loader (ADR-018) | new |
| `integrations/openai.py` | OpenAI adapter — mirrors the Claude adapter; dev-only until its DPA + consent clear | new |
| `Lab Unit Conversion` doctype | analyte-scopable unit conversion factors (ADR-020, gap G5) | new |
| `services/lab_units.py` | unit canonicalization + conversion lookup/apply | new |
| `scripts/seed/seed_lab_unit_conversions.py` | seed a vetted, source-cited starter conversion set | new |
| `services/lab_qualifiers.py` | deterministic qualifier-conflict detection (ADR-019 G7) — no LLM call, pure comparison | new |
| `services/imaging_extraction.py` | imaging RQ pipeline (ADR-019 G14b) — transcribe File → write `descriptive_result` → AI Prompt Log | new |
| `api/ai/imaging_extraction.py` | `upload_imaging_report`, `extract_imaging_report`, `get_imaging_extraction_status` — same flag as lab extraction | new |
| `llm/prompts/imaging_transcription_v1.txt` | versioned, hashed prompt for whole-document transcription (§4a) | new |
| `AI Prompt Log.purpose` | + `"Imaging Transcription"` option | field add |

## 7. Frontend (`EB_Healthcare_Frontend`, separate repo, on request)
Wire the (currently dead) Order button · manual result-entry UI · report-upload control (reuse the
documents-tab pattern) + "Extracting…" state + review/approve table · trend charts + abnormal badges
(the FE already renders flags from `normal_low/high`).

## 8. Milestones

- **M1 — manual result spine (no AI) — ✅ COMPLETE (2026-06-30):** `services/labs.py`
  (`ensure_lab_test_for_service_request`, `record_result`, `submit_lab_result`, range parse + flag)
  + labs API (`list_pending_lab_orders`, `record_result`, `submit_lab_result`, abnormal flags on
  `get_lab_test`) + the two Compound panels (CBC, Basic Metabolic Panel). Verified end-to-end:
  order → create Lab Test against SR → fill → submit → flags.
- **M2 — trends — ✅ COMPLETE (2026-06-30):** `get_lab_trends(patient, analyte?)` — per-analyte
  time series across finalized Lab Tests, with numeric points + flags. Verified.
- **M3 — frontend manual flow — 🔜 SCHEDULED 2026-07-01:** wire the Order button, manual
  result-entry UI, report-upload control, trend charts + abnormal badges (`EB_Healthcare_Frontend`).
- **M4 — AI client + prompt — ✅ COMPLETE (2026-06-30):** `integrations/anthropic.py` +
  standard versioned prompt; schema-locked uniform output; mocked-client tests; no DB writes.
- **M5 — AI pipeline + upload + AI Prompt Log — ✅ COMPLETE (2026-06-30):**
  `services/lab_extraction.py` (RQ job) + `api/ai/lab_extraction.py` (upload/extract/status,
  flag-gated) + `AI Prompt Log` doctype (migrated). **LLM-assisted EN/ES + full/abbrev analyte
  matching** (prompt v2, `matched_analyte`): the model maps each report parameter to the ordered
  analyte; unmapped extras surfaced. Verified end-to-end with a Spanish report (Hemoglobina→Hemoglobin,
  Leucocitos→WBC Count; Glucosa surfaced). Flag `enable_lab_extraction` default OFF.
- **M6 — compliance gate (go/no-go) — ⏳ PENDING (status disputed by observed reality, see
  2026-08-21 note):** PHI → Anthropic needs a data-processing
  agreement + patient consent (Mexico LFPDPPP + NOM-024-SSA3-2012, ADR-007) before
  `enable_lab_extraction` goes ON in any real env. Dev/test only until cleared. The live Anthropic
  call also needs the `anthropic` SDK + `ANTHROPIC_API_KEY` (not yet exercised).

  **2026-08-21 — contradiction found, not resolved here.** Checked
  `remedisis.localhost` directly: `AI Settings.enable_lab_extraction = 1`
  (ON) and `llm_provider = OpenAI` (not Anthropic — see ADR-026, the
  provider allowlist superseded the Anthropic-only lock this section still
  assumes), with 16 real `AI Prompt Log` rows (`purpose="Multi-Panel
  Extraction"`) already on record — the feature is in active use, not
  gated off pending a decision. Either M6 was actually cleared at some
  point and this section was never updated to say so, or PHI has been
  reaching OpenAI without the gate this section says is required — this
  revision does not know which, and does not decide it: that is a
  legal/compliance call for whoever owns the M6 gate (§3 of `CLAUDE.md`
  names this jurisdiction's compliance profile), not an engineering one.
  Flagging it here so it can't be quietly true or quietly false —
  `docs/KNOWN_ISSUES.md` is the right place for this until someone with
  the authority to answer it does.

## 9. Rules kept
Rule 1 (core never edited; custom fields/funcs only) · Rule 4 (LLM never touches DB) · Rule 6 (physician
submits; AI never auto-finalizes) · Rule 7 (AI failure can't block manual entry — RQ job) · Rule 9
(deterministic pipeline) · Rule 10 (no PHI in logs) · §9 (prompt in versioned file) · §3 (Claude Sonnet from AI Settings).

## 10. Risks
- **PHI → third party** (M6 gate) — legal, not engineering. Flag OFF by default.
- **Template structure** — multi-parameter results need Compound panels; Single templates hold one value.
- **Ordering spine half-built** — encounter SRs are currently orphaned and the FE order button is dead; M1 closes this on the SR-anchored path.
- **Extraction accuracy** — mitigated by constraining to expected analytes + physician submit + verbatim value kept.
- **Lossy range parsing** — keep verbatim value/range; numeric low/high best-effort, null when unparseable.

## 11. Verification
`remedisis.localhost` :8003, `bench console` (flat statements) + `pytest`. Per-milestone exit gates above.
End-to-end: order (SR) → create Lab Test → enter/extract → submit → `get_lab_test` flags → `get_lab_trends`;
kill Anthropic creds → extraction fails cleanly, upload preserved (Rule 7).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 1.1 | 2026-08-21 | Divyanshu (AI-assisted) | Flagged the M6 gate contradicting the live site (feature ON, real OpenAI calls); logged in `docs/KNOWN_ISSUES.md` |
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
