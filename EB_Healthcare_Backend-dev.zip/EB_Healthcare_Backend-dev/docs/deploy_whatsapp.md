# Deploying WhatsApp — step by step

**Doc status:** living · **Created:** 2026-09-28 by Ashutosh (AI-assisted) · **Updated:** 2026-10-01 by Ashutosh (AI-assisted) · **Version:** 3.0

How to make WhatsApp work on **dev** and on **production**.

Written for someone doing this for the first time. Follow the steps in order — several of
them fail **silently** when skipped, which is the whole reason this file exists.

## The environments

| | Backend (Frappe) | Frontend (EHR) |
|---|---|---|
| **Local** | `localhost:8000` (needs an ngrok tunnel) | `localhost:3000` |
| **Dev** | `https://dev-healthcare.m.frappe.cloud` | `https://devehr.narzim.com` |
| **Production** | `https://chavitosclinic.frappe.cloud` | `https://ehr.narzim.com` |

All of them share **one** Meta account (`Narzim`), **one** phone number and **one** set of approved
templates. Templates are approved on Meta, not in our database, so they never need re-approving per
environment.

Checked 2026-09-28: the app is deployed and the webhook endpoint is live on both dev and production —
both answer the verify handshake with *"No matching WhatsApp account"*, which means the code is there
and only the configuration below is missing.

> ### ⚠️ Only ONE environment can receive incoming messages
>
> A Meta app has exactly **one** callback URL. Whichever environment you point it at is the only one
> that receives patient replies and delivery receipts — everywhere else, inbound is silently
> discarded. **Outbound is unaffected: every environment can send.**
>
> **Production should own it.** Point the callback at `chavitosclinic.frappe.cloud` and leave it
> there. To test inbound on dev or locally, move it temporarily and move it back — and remember that
> while it is moved, **real patients writing to the clinic are not being heard**.
>
> Step 6 is the only step where dev and production differ.

---

## The one thing to understand first

**Most of this is NOT in the code.** Merging your branch does not carry it over.

Almost everything that makes WhatsApp work lives in two places that a deploy never touches:

1. **Site config and database records** on each site (credentials, which account to send from).
2. **Settings inside Meta** (which URL receives messages).

So a freshly deployed site starts with none of it, even though the code is identical. That is normal —
these are per-environment settings and they *should* differ between environments.

### Do we need patches?

**Everything in the code runs itself.** You configure; you never run a patch by hand.

| Thing | Ships with the code? | Why |
|---|---|---|
| Keyword auto-replies (`book` / `cancel` / `reschedule`) | ✅ Patch, automatic | `seed_whatsapp_auto_replies_20260911`. Nothing to do |
| The 8 notification configs themselves | ✅ Patch, automatic | `seed_whatsapp_notification_configs_20260910` creates them and keeps their wording current |
| `phone_field_path` on Reminder and Consent Ending | ✅ Patch, automatic | `repair_whatsapp_phone_field_paths_20260928`. Both were blank on sites migrated before the seed learned to set it, which made them silently inert |
| Template header image (`WhatsApp Templates.sample`) | ✅ **Runs on every migrate** — `after_migrate` in `hooks.py` | See the note below. Not a patch, deliberately |
| `whatsapp_header_image_url`, `whatsapp_app_secret` | ❌ Manual | Site config. The address differs per environment |
| `WhatsApp Account` record | ❌ Manual | Holds credentials. Never in the repo |
| Which account the 8 notifications use | ❌ Manual | Deliberately per-site: `seed_whatsapp_notification_configs` never touches `whatsapp_account`, so one clinic's choice is never forced on another |
| Meta webhook URL, number registration | ❌ Manual | Not in our system at all |

#### Why the header-image repair is not a patch

A patch runs **once** and is then recorded in Patch Log forever. That cannot work here: templates are
pulled from Meta **by hand** (step 4), which on a new site happens *after* the first migrate. A patch
would run against an empty table, be marked done, and never run again — leaving every template with
`header_type = IMAGE` and no image, which Meta accepts and silently drops.

So it is wired to `after_migrate` in `hooks.py` instead, alongside `rebuild_eb_role_permissions`. It
runs on **every** migrate, is idempotent, never overwrites an image someone set deliberately, and is a
no-op until `whatsapp_header_image_url` exists. In practice: set the config, fetch the templates,
migrate — in any order — and it repairs itself.

---

## Step 1 — Merge and migrate

Merge your branch and deploy as usual (`dev` first, then `pre`/`main`). On Frappe Cloud, migrate runs
as part of the deploy.

**Migrate now does steps 4 and 5 for you.** `after_migrate` runs an ordered chain
(`hooks.py`, `integrations/whatsapp/bootstrap.py`):

| | What it does |
|---|---|
| `bootstrap.sync_templates_from_meta` | pulls the approved template catalogue from Meta — the same call as the "Sync from Meta" button |
| `backfill_whatsapp_template_header_image_20260928` | gives IMAGE-header templates their image |
| `switch_whatsapp_templates_to_branded_20260912` | points the 8 configs at the v3/v4 templates and rebuilds their variables |

The order is load-bearing: the sync brings the templates in, the backfill needs them to exist, and
the mapping will not touch a config whose template this site has not approved. All three are
idempotent, and the whole chain is skipped on a site with no **Active** WhatsApp Account. Nothing in
it can fail a deploy — a Meta outage or an expired token is logged and migrate continues.

Nothing WhatsApp-specific works yet on the first deploy. The header-image repair runs but does
nothing, because `whatsapp_header_image_url` is not set yet. That is expected — step 2 is next, and
the deploy after it will complete the chain.

---

## Step 2 — Add two keys to the site config

Frappe Cloud → the site you are setting up → **Site Config**. Add:

| Key | Value | What it does |
|---|---|---|
| `whatsapp_header_image_url` | `https://mycare.narzim.com/narzim-logo.png` | The logo shown at the top of every branded template |
| `whatsapp_app_secret` | *(copy from local `site_config.json`)* | Verifies that inbound webhooks really came from Meta |

**`whatsapp_header_image_url` must be openable in a browser from anywhere.** Meta downloads that
image from its own servers when it builds the message. If it cannot, the message is **accepted and
then silently dropped** — you get a message id back and the patient never receives anything. This is
the single failure that cost a full day on 2026-09-28.

Never use `localhost`, a private IP, or an ngrok tunnel here. Check it first:

```bash
curl -I https://mycare.narzim.com/narzim-logo.png     # must be HTTP 200, image/png
```

`whatsapp_app_secret` is a secret — copy it across, do not commit it, do not paste it into chat.

---

## Step 3 — Create the WhatsApp Account record

Desk → **WhatsApp Account** → New. Same values on every environment:

| Field | Value |
|---|---|
| Account Name | `Narzim` |
| Company | `Socialangel` |
| Status | `Active` |
| URL | `https://graph.facebook.com` |
| Version | `v19.0` |
| Phone ID | `1318628821332969` |
| App ID | `1095875596728624` |
| Business ID | `1394820842240251` |
| Webhook Verify Token | `Dev@123` |
| Token | *(copy from local — it is a System User token and does not expire)* |
| Is Default Incoming | ✅ |
| Is Default Outgoing | ✅ |
| Allow auto read receipt | ✅ |

### Getting the Token (it is a secret, so it is not written here)

The **Token** is a Meta **System User token**. One token covers both the `Narzim` and
`Narzim Test` accounts, and it does **not expire** — which is exactly why it must never be
committed, pasted into a ticket, or sent over chat. Anyone holding it can message your patients
as the clinic.

Read it from the local site:

```bash
bench --site <local-site> console
>>> frappe.get_doc("WhatsApp Account", "Narzim").get_password("token")
```

Then paste it straight into the Token field on the new record and close the terminal.

To confirm the two sites ended up with the same token without ever displaying it:

```bash
bench --site <site> console
>>> import hashlib; hashlib.sha256(
...     frappe.get_doc("WhatsApp Account", "Narzim").get_password("token").encode()
... ).hexdigest()[:12]
```

Run that on both sites and compare the twelve characters. Same output means same token.

---

## Step 4 — Templates: automatic since 2026-10-01

**Nothing to do.** Migrate syncs the catalogue from Meta and repairs the header images (step 1).

Check it worked. This must return **0**:

```bash
bench --site <site> console
>>> frappe.db.count("WhatsApp Templates", {"header_type": "IMAGE", "sample": ["in", [None, ""]]})
```

Above zero means `whatsapp_header_image_url` was not set when migrate ran — do step 2, then deploy
again. Because the chain runs on every migrate rather than once, repeating it is always safe.

The **Sync from Meta** button on the WhatsApp Templates list still exists and is still the right tool
when Meta approves a new template and you do not want to wait for the next deploy.

> **How many templates to expect.** Whatever the Narzim WABA has approved — 13 on
> 2026-10-01, 37 on the local bench, which also carries older and probe templates. The count is not a
> health signal. What matters is that the eight in step 5 are present and `APPROVED`.

---

## Step 5 — Enable the 8 notifications

Migrate has already pointed each config at its template and rebuilt its variables (step 1). Open
Desk → **Remedisys WhatsApp Notification** and confirm **Meta Template Name** reads the v3/v4 name:

```
Appointment Confirmed    appt_confirmed_v4      Update Available — Lab Result  update_available_v3
Appointment Reminder     appt_reminder_v3       Update Available — Encounter   update_available_v3_encounter
Appointment Rescheduled  appt_rescheduled_v3    Payment Received               payment_received_v4
Appointment Cancelled    appt_cancelled_v4      Consent Ending                 consent_ending_v3
```

Still showing v1/v2 means the mapping skipped — look in **Error Log** for
"WhatsApp branded migration skipped". Each entry names a template Meta has not approved for this
WABA.

**Then tick Enabled on all eight. This is the one step that stays manual, deliberately:** a deploy
must never start messaging patients on its own. Enabling is the moment a human decides this
environment may write to real phones.

Leave any extra config (`hello_world` and anything a clinic added by hand) alone — the chain only
touches the eight above.

---

## Step 6 — Tell Meta where to send incoming messages

This is what makes patient replies and keyword auto-replies work. Without it, a patient's message is
posted to a dead address and thrown away — no error anywhere.

**This is the one step where the environments differ**, because Meta allows only one callback URL.
Normally this points at **production** and stays there.

| Environment | Callback URL |
|---|---|
| **Production** (normal) | `https://chavitosclinic.frappe.cloud/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook` |
| Dev (only while testing inbound) | `https://dev-healthcare.m.frappe.cloud/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook` |
| Local (only while testing inbound) | `https://<your-ngrok>.ngrok-free.dev/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook` |

Set it at **developers.facebook.com** → the Narzim app → **WhatsApp → Configuration → Edit webhook**:

- **Callback URL:** from the table above
- **Verify token:** the `Webhook Verify Token` on that site's `WhatsApp Account` record — they must
  match exactly, or Meta refuses to save the URL
- **Subscribe to fields:** `messages` and `message_template_status_update`

> ### ⚠️ Moving this away from production has a real cost
>
> While the callback points anywhere other than production, **patients writing to the clinic are not
> being heard** — their messages are posted to production's URL... which no longer receives them, and
> they are gone. There is no queue and no retry to recover them afterwards.
>
> So: test inbound on dev deliberately and briefly, then put it back. Do not leave it pointed at dev
> overnight.

Check it is reachable **before** saving it in Meta. This must print `test123`:

```bash
curl "https://chavitosclinic.frappe.cloud/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook?hub.mode=subscribe&hub.verify_token=<that+site's+token>&hub.challenge=test123"
```

If it returns `"No matching WhatsApp account"`, step 3 was not done on that site — the verify token
has to exist on a `WhatsApp Account` record there. If it returns `test123`, Meta will accept it.

**A note on the verify token.** `Dev@123` is fine for local and dev. For production, use something
long and random — it is the only thing standing between the internet and your inbound webhook, and it
is not a secret you ever need to remember (it lives in the record and in Meta).

---

## Step 7 — Make sure the app is subscribed

Setting the URL is not enough. The app also has to be subscribed to the WhatsApp account, which is a
separate switch. On the **WhatsApp Account** record in Desk there is a **Subscribe App to Webhooks**
button — press it.

To verify (uses the app secret as `<app_id>|<app_secret>`):

```bash
curl -s "https://graph.facebook.com/v21.0/1394820842240251/subscribed_apps" \
  -H "Authorization: Bearer 1095875596728624|<app_secret>"
```

The response must list the app. An empty `"data": []` means inbound messages are being discarded.

---

## What is still manual, per environment

Everything else is done by the deploy. This is the whole list, and the last two are the ones that
fail silently.

| | Where | Why it is not automated |
|---|---|---|
| WhatsApp Account keys | Desk → WhatsApp Account | The token is a secret; it is never in git |
| `whatsapp_header_image_url` + `whatsapp_app_secret` | Frappe Cloud → Site Config | Per-site, and one is a secret. **Missing `whatsapp_header_image_url` means Meta accepts every message and silently drops it** |
| **Enable** the 8 configs | Desk → Remedisys WhatsApp Notification | A deploy must not start messaging patients |
| **Subscribe App to Webhooks** | Desk → WhatsApp Account, the button | Separate switch from the callback URL (step 7) |
| Callback URL | Meta, one environment only | Production owns it (step 6) |
| Patient consent | Patient chart | Per patient. **Refused silently by design** — the most common "I enabled it and nothing happened" |
| Scheduler on; `appointment_reminder_timing` not `Disabled` | FC / EB Clinic Settings | Only affects Appointment Reminder and Consent Ending — the other six are document-driven |

---

## Step 8 — Test it, in this order

### First: the test patient needs consent

Nothing is sent to a patient without a `Patient Communication Consent` row, and the refusal is
**silent by design** — it is not an error, it is the correct outcome, so it is not logged as one. On a
fresh dev site no patient has consent yet, so this is the most likely reason a first test appears to
do nothing.

Pick a patient whose `mobile` is a phone you can actually check, then grant consent from the patient
chart, or from the console:

```bash
bench --site <dev-site> console
>>> from remedisys_healthcare_ai.services.communication_consent import has_consent
>>> has_consent("<MRN>", "<their mobile>")   # must be True before you test
```

### Then run these in order

Each test proves a different half. Do them in order — if one fails, later ones tell you nothing.

**1. Outbound.** Book an appointment for that patient.
→ They should receive a confirmation **with the Narzim logo at the top**.

- Nothing arrives → the header image is unreachable. Go back to step 2.
- Arrives **without** the logo → templates were not re-fetched, or the patch did not run. Step 4.

**2. Inbound.** From that phone, reply **"I want to book appointment"**.
→ You should get the "Book here" template back within a few seconds.

- Nothing → the webhook is wrong. Steps 6 and 7.

**3. Delivery status.** Open the WhatsApp Message list in Desk.
→ Recent rows should read `delivered` or `read`, not `Sent`.

- Stuck on `Sent` → the webhook is reachable for messages but not subscribed to status updates.
  Re-check the fields in step 6.

---

## If something does not work

| Symptom | Cause | Fix |
|---|---|---|
| Message accepted, never arrives | Header image not reachable by Meta | Step 2 — check the URL returns 200 publicly |
| Arrives without the logo | `sample` empty on the template | Step 4 — fetch templates, then migrate |
| Patient replies go nowhere | Webhook URL wrong or app not subscribed | Steps 6 and 7 |
| Everything stuck on `Sent` | Not subscribed to `message_template_status_update` | Step 6 |
| `... does not exist` from the webhook URL | Frappe cannot resolve the site from the Host header | Frappe Cloud handles this. Only an issue with local tunnels, which need `ngrok http 8000 --host-header=<site>` |
| Nothing sends, no error | Patient has no consent | Consent is required and refuses silently by design. Check `Patient Communication Consent` |

**The lesson from 2026-09-28:** an unreachable header image and a dead webhook URL both fail with
**no error at all**. Every dashboard says healthy. If WhatsApp "stops working" and nothing is in the
logs, check those two URLs first.

Background and full diagnosis: [`WHATSAPP_INTEGRATION.md`](WHATSAPP_INTEGRATION.md) §17.

---

## What actually fires, and what does not

Verified 2026-09-28 by tracing every caller. All eight now send:

| Config | What triggers it |
|---|---|
| Appointment Confirmed | document hook, After Insert |
| Appointment Rescheduled | document hook, After Save |
| Appointment Cancelled | document hook, After Save |
| Payment Received | document hook, On Submit |
| Update Available — Encounter | document hook, On Submit |
| Update Available — Lab Result | document hook, After Save |
| **Appointment Reminder** | `scheduled_notifications._run_reminders`, **`*/5` scheduler** |
| Consent Ending | `consent_lifecycle.run_consent_lifecycle`, **daily scheduler** |

The last two are **scheduler-driven, not document-driven**. If the scheduler is off, everything else
still works and those two silently never send. Frappe Cloud enables it by default; check with
`bench --site <site> doctor` if reminders or consent warnings do not appear.

### The reminder has two independent halves

`_run_reminders` sends the in-app/push reminder **and** the WhatsApp one, guarded separately
(`appointment_reminder` and `appointment_reminder_whatsapp` in `EB Notification Dispatch`). Either can
succeed while the other is skipped, and neither suppresses the other's retry.

They also reach **different people**. The in-app half needs `Patient.user_id` and is skipped without
it; the WhatsApp half needs only a consented mobile. A patient who has consented to WhatsApp and never
opened the portal gets the WhatsApp reminder and nothing else — which is the point.

Timing comes from **EB Clinic Settings → `appointment_reminder_timing`** (`24h before`, `12h before`,
`1h before`, or `Disabled`), per company. `Disabled` turns off both halves. Turning off only the
WhatsApp half is done by disabling the `Appointment Reminder` notification config.

> **Both of these were silently inert until 2026-09-28**, for the same reason: `phone_field_path` was
> empty on both configs, and `_fire_notification()` returns at the phone-resolution step — before the
> consent gate, before the send, with no error. `repair_whatsapp_phone_field_paths_20260928` fills
> them. If a config ever appears enabled and correct but sends nothing, check that field first.

---

## Going to production (`chavitosclinic.frappe.cloud` / `ehr.narzim.com`)

Steps 1–8 are the same. Only these differ.

**Step 2 — site config.** Identical values. `whatsapp_header_image_url` stays
`https://mycare.narzim.com/narzim-logo.png`; it is the patient portal's public domain and is already
reachable from anywhere.

**Step 3 — the account record.** Identical, except give it a long random **Webhook Verify Token**
rather than `Dev@123`.

**Step 6 — the callback URL.** Production owns it. Point it at
`https://chavitosclinic.frappe.cloud/...` and leave it there.

### Three things to check before real patients are on it

**1. The clinic name in the message.** Messages read *"your appointment at **Socialangel**"* — that is
`company.company_name` in Frappe, not the WhatsApp display name (which is correctly "Narzim
Healthcare"). If patients should see something else, change the Company record before go-live. It
appears in every template.

**2. The number patients see.** Outbound comes from **+1 555-428-8301**, a US number, for a clinic
billing in INR. It works — delivery is confirmed to numbers that were never allow-listed — but
whether patients should see a US number is a product decision, not a technical one. Changing it means
adding a real business number to the same WABA (WhatsApp Manager → Phone numbers → Add), then
updating `Phone ID` on the account record. Templates carry over; they belong to the WABA, not the
number.

**3. Consent on real patients.** Nothing is sent to a patient without a `Patient Communication
Consent` row, and the refusal is silent by design. Whatever flow grants consent must be working
before go-live, or notifications simply will not appear and nothing will look broken.

### What production does NOT need

- No template re-approval — templates live on Meta and are shared.
- No new phone number registration — done once, already complete.
- No code change — the header-image repair runs on every migrate.

---

## Quick reference — everything you need

Not secret, safe to copy:

```
Phone ID          1318628821332969
Business ID       1394820842240251
App ID            1095875596728624
Graph URL         https://graph.facebook.com
API version       v19.0
Verify token      Dev@123
Header image      https://mycare.narzim.com/narzim-logo.png

Webhook fields    messages, message_template_status_update

Webhook URLs (only ONE can be active in Meta at a time):
  production      https://chavitosclinic.frappe.cloud/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook
  dev             https://dev-healthcare.m.frappe.cloud/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook
  local           https://<your-ngrok>.ngrok-free.dev/api/method/remedisys_healthcare_ai.integrations.whatsapp.webhook.webhook
```

Secret — copy from the local site, never into git, a ticket or a chat message:

```
WhatsApp Account → Token        (Meta System User token, covers BOTH accounts, does not expire)
site_config      → whatsapp_app_secret
```

These two are deliberately absent from this file. A token that never expires and covers both the
production and test accounts is the most dangerous string in this integration — whoever has it can
message patients as the clinic. Retrieval commands are in step 3.

**If either is ever pasted into a chat, a ticket, a screenshot or a commit, rotate it.** A System
User token is regenerated at developers.facebook.com → Business Settings → System Users → the app's
system user → **Generate New Token** (scopes: `whatsapp_business_management`,
`whatsapp_business_messaging`). Then update the `WhatsApp Account` record on every site.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.0 | 2026-10-01 | Ashutosh (AI-assisted) | Steps 4 and 5 are automated: `after_migrate` now syncs templates from Meta, repairs header images and maps the 8 configs, in that order (`integrations/whatsapp/bootstrap.py`). Written after dev sat on v1/v2 template names because `switch_whatsapp_templates_to_branded_20260912` had run before any v3/v4 template existed, logged "fetch templates and re-run", and — having not raised — was written to Patch Log and never ran again; pre and production were waiting on the same trap. Adds "What is still manual, per environment"; corrects the stale "~36 templates" |
| 2.2 | 2026-09-28 | Ashutosh (AI-assisted) | The WhatsApp appointment reminder now sends — all eight configs fire. Records that the reminder has two independently-guarded halves reaching different people, and that an empty `phone_field_path` makes a config silently inert |
| 2.1 | 2026-09-28 | Ashutosh (AI-assisted) | Added "What actually fires, and what does not": traced every caller and found the WhatsApp **Appointment Reminder** has none, so it never sends. Records that the scheduler must be enabled for Consent Ending |
| 2.0 | 2026-09-28 | Ashutosh (AI-assisted) | Extended from dev-only to cover production (`chavitosclinic.frappe.cloud` / `ehr.narzim.com`). Records that a Meta app has only one callback URL, so production owns it and moving it means patient messages are lost meanwhile; adds the pre-go-live checks (clinic name, US number, consent) |
| 1.0 | 2026-09-28 | Ashutosh (AI-assisted) | Initial version, written after the 2026-09-28 outage where a stale ngrok URL in two places silently broke WhatsApp in both directions |
