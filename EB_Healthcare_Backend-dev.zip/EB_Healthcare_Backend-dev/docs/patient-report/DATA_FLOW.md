# Patient Reports — Where the Data Comes From

**Doc status:** living · **Created:** 2026-09-11 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-11 by Anant Sharma (AI-assisted) · **Version:** 1.7

Companion to [PATIENT_PAGE_REPORT.md](PATIENT_PAGE_REPORT.md) and
[APPOINTMENT_PAGE_REPORT.md](APPOINTMENT_PAGE_REPORT.md). Those say *what* each report shows.
This says *where every number comes from* — which doctype, which field, which function — so a
figure that looks wrong can be traced to its source without reading the whole stack.

## 1. The chain, end to end

Eight hops. The browser never talks to Frappe directly (the BFF pattern, ADR-010/ADR-011): the
access token lives in an httpOnly cookie readable only by the Next.js server, so a compromised
page script cannot lift a credential and call the EHR itself.

| # | Where | What happens |
|---|---|---|
| 0 | `report-drawer.tsx` → `DrawerBody` | Holds the report's own **period / practitioner / custom range**, seeded from the list's filters by a lazy initialiser. It mounts only while the drawer is open, so each open re-seeds from what the list currently shows instead of remembering an old window. An explicit range beats a preset — the same precedence `resolve_report_window()` applies — so the lit control and the resolved window cannot disagree |
| 1 | `report-drawer.tsx` | `useReport(slug, params)` — react-query, keyed on `["report", slug, params]`. Reopening with the same scope serves from cache |
| 2 | `lib/api/reports.ts` | `reportsApi.get()` → `GET /api/reports/<slug>?period&date_from&date_to&practitioner&gender&status` |
| 3 | `app/api/reports/[report]/route.ts` | **Next.js server**, not the browser. Reads the JWT via `getAccessToken()`, maps the slug to a whitelisted method through `METHODS`, and forwards **only** the keys in `PARAM_KEYS` — anything else a caller appends is dropped |
| 4 | `lib/api/client.ts` | `frappeFetchSet(method, {token, body})` → `POST /api/method/<dotted.path>` with `Authorization: Bearer <jwt>` |
| 5 | Frappe | The whitelisted method runs. Permission gates first (§4) |
| 6 | `_build_patient_panel` / `_build_patient_flow` | Queries the doctypes in §2 and §3 and computes every block in memory |
| 7 | back up | `set_response(200, data=…)` → `{status, data}`; the BFF unwraps `.data` and hands the envelope to the drawer |

Two slugs feed the report view:

| Screen | Slug | Whitelisted method |
|---|---|---|
| Patients | `patient-panel` | `api.v1.patients.report.get_patient_panel` |
| Appointments | `patient-flow` | `api.v1.appointments.report.get_patient_flow` |

**Nothing is cached server-side and nothing is stored.** There is no reports doctype and no
materialised table; every open is a live read. That is affordable because each builder does a
fixed number of batched queries regardless of how many rows it covers — never one per patient or
per appointment.

## 2. Patients report — `get_patient_panel`

Two reads of the database, plus one small lookup for display names.

| Source doctype | Fields read | Feeds |
|---|---|---|
| `Patient` | `name`, `sex`, `dob`, `status`, `creation` | **Total Patients**, **New Patients**, Age Distribution, Gender, *missing date of birth* |
| `Patient Appointment` (dated ≤ window end) | `patient`, `practitioner`, `appointment_date`, `status` | **Active Patients**, **Lapsed**, Last Visit, Visits per Patient, *never seen* |
| `Patient Appointment` (dated > today, not Cancelled/No Show) | `patient` | *lapsed with nothing booked* |
| `Healthcare Practitioner` | `practitioner_name` | nothing on screen today — see the note below |

> **The endpoint returns more than the report draws.** `by_practitioner` and `registrations` are
> still computed and returned; the Patients report stopped rendering them on 2026-09-11. The
> `Healthcare Practitioner` name lookup therefore costs one batched query per open for labels
> nobody sees. Harmless, and deliberate — the data is there the moment either chart is restored —
> but worth knowing before treating that query as load-bearing.

### The two card definitions that are easy to get wrong

- **Active Patients** = *seen at least once in the last 12 months*, derived from last-visit
  recency. It is **not** `Patient.status`. That field records whether a record is enabled: on this
  bench all 659 patients are "Active" while 601 have never attended, so it would report a fully
  active panel for a registry that is 91% dormant.
- **Active / Lapsed / never-seen partition the panel** — they sum to Total and match the Last
  Visit chart bucket-for-bucket (`active` = 0-3m + 3-6m + 6-12m, `lapsed` = over_12m). Asserted by
  `tests/patients/test_patient_report.py`.

### Balances vs window measures

`meta.date_from`/`date_to` select a window. Only **New Patients**, *patients seen* and the
Registrations chart are measured inside it. **Total**, **Active**, **Lapsed**, age and last-visit
are *balances* — facts as of a date — and use `as_of = min(window end, today)`, returned in the
payload. Measuring them from the window end instead was a real defect: with `period=year` the
window runs to 31 December, so patients seen four days ago were reported in the "3-6 months"
bucket and everyone aged up to their December age.

## 3. Appointments report — `get_patient_flow`

One read of the window's appointments; the encounter, reschedule and invoice lookups are each a
single batched query keyed on those appointment names.

| Source doctype | Feeds |
|---|---|
| `Patient Appointment` (`_PF_FIELDS`) | **Total Appointments**, **Completed**, **No-show Rate**, Outcomes, By Hour, New vs Returning |
| `Patient Encounter` (`_encounter_index`) | Flow funnel states, wait times (arrival → seen), *unsigned encounters* |
| `Appointment Reschedule History` | Reschedule Timing, Reschedule Outcome |
| `Sales Invoice` (`docstatus = 1`) | *checked out but unpaid* |
| `Practitioner Service Unit Schedule` + `Healthcare Schedule Time Slot` + `Healthcare Practitioner` | **Capacity Used** — the denominator |

Notes that change how the numbers read:

- **Funnel state is docstatus-first.** A draft `Patient Encounter` means the patient is with the
  practitioner; a submitted one means they are finished. Reading `status` alone left submitted
  encounters with no end time sitting in "in consultation" forever.
- **Capacity ignores holidays and leave** — neither is modelled — so it reads high around a
  holiday. When no schedule is readable it returns 0 and the card reports *unmeasured*, never 0%.
- **Wait times are computed but no longer shown.** An appointment with no check-in timestamp is
  left out of the average rather than counted as a zero-minute wait, and `meta.wait_coverage` says
  how many arrivals were actually measured. On this bench that is `{measured: 0, of: 4}` — nothing
  records a check-in time and an encounter start on the same appointment — so the two wait charts
  were removed from the drawer on 2026-09-12 rather than render permanent zeros. The endpoint is
  unchanged, so they can be restored in one line once the data exists.

## 3b. What a card does when you click it

**A same-screen card does not navigate — it drills.** The report pages under `/reports` link to
`/patients` and `/appointments`, which works because that is a real navigation to a different
route: the destination mounts fresh and seeds its filters from the query string. This drawer lives
*on* those screens, where the same link fails twice over:

1. Next.js navigating to the URL you are already on renders nothing.
2. Both lists seed their filter state from `searchParams` in **lazy `useState` initialisers** that
   run once at mount and never re-sync — deliberately, since an effect would resurrect a filter the
   user had just cleared. So even a link carrying query params changes the address bar and nothing
   else.

So `report-drawer.tsx` exposes a `ReportDrill` union; the host screen applies it to its own filter
state and switches back to the list. Only a card whose records live on **another** screen keeps a
real `href` — Completed → `/encounters` — because a real navigation is the better affordance
whenever one genuinely exists.

| Card | Behaviour |
|---|---|
| Total Appointments | drill — clear the status filter |
| Completed | **href** → `/encounters?from_date&to_date&status=completed&practitioner` |
| No-show Rate | drill — filter to `No Show` |
| Total Patients | drill — clear filters |
| New Patients | drill — set the registration window |
| Active Patients | drill — set the visit window to 12 months ending at `as_of` |
| Capacity Used · Lapsed (12m) | none — no list of slots, and no "not seen since" filter |

Rules, each learned the hard way:

- **Carry the practitioner** on any cross-screen href. Without it a card reading 36 opened a list
  of 92 the moment the practitioner filter was used.
- **Measure a relative window from the payload's `as_of`,** never the browser clock — a tablet with
  a stale clock would otherwise drill into a different window than the figure was computed for.
- **A figure naming no set of rows gets no affordance.** An average wait has no rows behind it; a
  percentage *of* a named category does.
- **Registration window ≠ visit window.** August 2026 held 646 registrations against 92 people
  actually seen, so the two drills set different filters and the list shows them as separate chips.

## 4. Who is allowed to see what

Three gates, in order, before any query runs:

1. `require_permission("Patient", "read")` / `require_permission("Patient Appointment", "read")`
2. `require_roles(EB_Practitioner, EB_Front Desk, EB_Nurse)`
3. `report_practitioner_scope()` — **the one that actually confines a doctor.** A caller holding
   only `EB_Practitioner` is forced to their own linked Healthcare Practitioner regardless of what
   the client asked for. It has no clinic-setting escape hatch, deliberately: the
   `practitioners_see_all_appointments` toggle governs same-day queue handoff, and report privacy
   is a different policy. A practitioner with no linked record gets an empty report, never an
   unscoped one.

When a practitioner or clinic scope is active, the patient universe becomes **appointment-derived**
— "Dr. V's patients" is not a column on `Patient` (the doctype has no practitioner link and no
company field), it is the set of patients holding an appointment with them. `scope_basis` in the
payload says which universe produced the figures, and the drawer prints it.

## 5. PHI

Only **counts** are shown. The "needs attention" block returns numbers, never patient names,
MRNs or dates of birth (PHI-6, minimum necessary) — identified data stays on the list screen, which
is already permission-checked. Practitioner display names are the one exception, and they are staff
names, not patient data.

## 6. Adding a card or a chart

1. Emit it from the builder in `report.py`, with a stable machine `key`. A value that cannot be
   measured is `None` and is named in `meta.stub_fields` — never a fabricated number, and never
   `0` standing in for "not measured".
2. Add it to the section's `mandatoryKpis` or `charts` in `report-drawer.tsx`. The drawer renders
   only what the section names, so a new payload key is invisible until it is listed.
3. Add labels to **both** `messages/en.json` and `messages/es.json`. A missing label renders the
   raw key to the user; `reportDrawer.*` holds the report view's own labels and existing reports keep
   theirs under `reports.<report>.*`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.7 | 2026-09-12 | Anant Sharma (AI-assisted) | Wait-time charts removed from the drawer; recorded that the endpoint still computes them |
| 1.6 | 2026-09-11 | Anant Sharma (AI-assisted) | Added the DrawerBody hop — the report now owns its period / practitioner / range, seeded from the list |
| 1.5 | 2026-09-11 | Anant Sharma (AI-assisted) | §3b rewritten: same-screen cards drill into the host's filters; only cross-screen cards navigate |
| 1.4 | 2026-09-11 | Anant Sharma (AI-assisted) | Added §3b — card drill-through destinations and the rules behind them |
| 1.3 | 2026-09-11 | Anant Sharma (AI-assisted) | Report is a right-side drawer again; `report-panel.tsx` back to `report-drawer.tsx` |
| 1.2 | 2026-09-11 | Anant Sharma (AI-assisted) | Drawer became an in-place List / Report view toggle; `report-drawer.tsx` renamed `report-panel.tsx` |
| 1.1 | 2026-09-11 | Anant Sharma (AI-assisted) | Patients report no longer draws the by-practitioner or registrations charts; recorded that the endpoint still returns them |
| 1.0 | 2026-09-11 | Anant Sharma (AI-assisted) | Initial version |
