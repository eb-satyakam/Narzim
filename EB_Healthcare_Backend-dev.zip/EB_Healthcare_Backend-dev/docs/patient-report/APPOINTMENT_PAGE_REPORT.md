# Appointment Page — Report View

**Doc status:** living · **Created:** 2026-09-11 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-11 by Anant Sharma (AI-assisted) · **Version:** 1.7

## What

On the **Appointments** screen the header carries a **List / Report** toggle. Selecting
**Report** opens the clinic-activity overview in a **right-side drawer** over the list. The list
stays mounted behind it, so closing the drawer — by its close button, Escape, or the backdrop —
returns to exactly the rows, scroll position and filters that were there, with nothing
re-fetched.

Backend: `appointments/report.py::get_patient_flow` (report key `patient-flow`).

## Why (for the admin)

The list shows today. The report shows the pattern: how full the clinic actually is,
how much of the booked day is being lost to no-shows, and where patients are stuck in the
flow. Those are the numbers an admin uses to move slots and staff.

## The 4 mandatory cards

Always shown, in this order, at the top of the report.

| # | Card | Key | Meaning |
|---|---|---|---|
| 1 | Total Appointments | `total` | Every appointment in the period, all statuses |
| 2 | Cancelled | `cancelled` | Called off before the visit |
| 3 | Checkout | `completed` | The visit happened and its note was submitted |
| 4 | No Show | `no_show` | Booked, never arrived — direct lost revenue |

**"Checkout" is `completed`**, which is what the product already calls that stage — the funnel's
own label for it is "Checkout" ("Salida" in `es-MX`). It is **not** appointment status
`Checked-out`: no row carries that status, because ERPNext moves an appointment to `Closed` the
moment an encounter exists.

The report is titled **Appointment Report**, and opens on **This Month**.

**Cards drill into the list behind the drawer**, except where the records live elsewhere:

| Card | Does |
|---|---|
| Total Appointments | Clears the status filter — the report's window is already the list's window, so the status is what it narrowed by |
| Cancelled | Filters the list to **Cancelled** |
| Checkout | **Navigates** to `/encounters?status=completed`. The only card that does: these records live on another screen, and this counts consultations whose note was submitted — which no appointment status can express. Verified: an appointment marked `Closed` with a *draft* encounter is "in consultation", not checkout, so the card (3) and an appointment-status filter (4) genuinely differ |
| No Show | Filters the list to **No Show** |

Verified against live data for September 2026: Total 13 → 13, Cancelled 0 → 0, No Show 9 → 9.

**The drilled filter is written to the URL.** Both lists seed their filters from the query string
at mount and hold them in state after, so a drill that only set state vanished as soon as you
opened a record and pressed Back. The date scope rides along with the status — Back restoring a
status against a different window would be its own wrong answer — and a preset travels by name so
its button lights up again rather than arriving as an anonymous custom range.

Only the cross-screen card navigates. A card whose records are on this very screen applies the
filter and closes the drawer instead — a link to the page you are already on does nothing.

## Rest of the report (below the cards)

- **Flow funnel** — booked → checked in → in consultation → completed.
- **Charts** — appointments by hour (peak hour), by status, new vs returning, reschedule
  reasons and outcomes.

  **No wait-time charts.** A wait is arrival → seen, which needs a check-in timestamp *and* an
  encounter start on the same appointment. Nothing currently records the pair — `wait_coverage`
  reads `{measured: 0, of: 4}` — so "Wait Times" showed four permanent zeros and "Average Wait
  by Hour" had no points at all. The endpoint still computes both; put them back once check-in
  times are actually being captured.
- **Needs attention** — stale appointments (stuck in a state) · unsigned encounters ·
  checked out but unpaid. Counts only, each clicks through to the filtered list.
- **Filters** — the report carries its own controls: **Today · This Week · This Month ·
  This Quarter · This Year**, a practitioner selector, and a custom date range. They open
  **seeded from the list** — so the first thing you see describes the rows you were just
  looking at — and are then independent, so widening the report to "This Quarter" does not
  disturb the list behind it.

  A custom range always beats a preset, matching the backend's own precedence, so the lit
  control and the window the server picked cannot disagree. The scope line under the controls
  prints the window the **server resolved**, not the one requested — a preset means nothing
  until it becomes dates. A practitioner confined to their own data server-side gets no
  selector, because it could not change anything.

  Department and clinic are not yet exposed.

## Rules

- Counts and rates only. No patient names are shown (PHI-6).
- Wait times are derived from real check-in and encounter timestamps; when a timestamp is
  missing the appointment is excluded from the average, not counted as zero.
- All labels come from the message catalog (`es-MX` + `en-US`). No hardcoded strings.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.7 | 2026-09-12 | Anant Sharma (AI-assisted) | Removed the wait-time charts — no appointment records both a check-in time and an encounter start, so they could only ever show zeros |
| 1.6 | 2026-09-11 | Anant Sharma (AI-assisted) | Cards are now Total · Cancelled · Checkout · No Show; report titled Appointment Report and opens on This Month |
| 1.5 | 2026-09-11 | Anant Sharma (AI-assisted) | The report has its own period / practitioner / custom-range controls, seeded from the list then independent |
| 1.4 | 2026-09-11 | Anant Sharma (AI-assisted) | Same-screen cards drill into the list's filters instead of linking |
| 1.3 | 2026-09-11 | Anant Sharma (AI-assisted) | Cards drill through to the filtered list; recorded which do not and why |
| 1.2 | 2026-09-11 | Anant Sharma (AI-assisted) | Report opens as a right-side drawer over the list again; the List / Report toggle is kept as the control |
| 1.1 | 2026-09-11 | Anant Sharma (AI-assisted) | The report is now a List / Report view toggle that replaces the list, not a right-side drawer over it |
| 1.0 | 2026-09-11 | Anant Sharma (AI-assisted) | Initial version |
