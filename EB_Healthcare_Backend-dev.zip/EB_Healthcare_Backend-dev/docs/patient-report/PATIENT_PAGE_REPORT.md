# Patient Page — Report View

**Doc status:** living · **Created:** 2026-09-11 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-11 by Anant Sharma (AI-assisted) · **Version:** 1.7

## What

On the **Patients** list screen (`/patients`) the header carries a **List / Report** toggle.
Selecting **Report** opens the patient-registry overview in a **right-side drawer** over the
directory. The list stays mounted behind it, so closing the drawer — by its close button, Escape,
or the backdrop — returns to exactly the rows, scroll position and filters that were there, with
nothing re-fetched. The toggle and the drawer's close button do the same thing, so the two
controls cannot disagree about which view you are in.

Backend: `patients/report.py::get_patient_panel` (report key `patient-panel`).

## Why (for the admin)

The list answers "who is this patient". The report answers "how healthy is my patient
base" — is it growing, how many patients have gone quiet, and how many still have a
follow-up booked. That is the only view an admin gets of the registry as a whole.

## The 4 mandatory cards

Always shown, in this order, at the top of the report.

| # | Card | Key | Meaning |
|---|---|---|---|
| 1 | Total Patients | `total_patients` | Everyone registered **as of** the period end. Shows % vs prior period |
| 2 | New Patients | `new_patients` | Registered **inside** the selected period. Shows % vs prior period |
| 3 | Active Patients | `active_patients` | Seen at least once in the last 12 months |
| 4 | Lapsed (12m) | `lapsed_12m` | No visit in 12 months. Also shows % of active — this is the recall list |

Cards 1 and 3 are balances (a count as of a date), cards 2 and 4 relate to a window.
Never compare a balance against a window number.

**Cards drill into the directory behind the drawer.** Clicking one applies the filter to
the list and closes the drawer — it does **not** navigate. It cannot: the drawer is already
on `/patients`, and the list seeds its filters from the URL once at mount and never re-reads
it, so a link would change the address bar and nothing else.

| Card | Does |
|---|---|
| Total Patients | Clears the filters the report was narrowed by — everyone on the register |
| New Patients | Sets the **registration** window to the report's window |
| Active Patients | Sets the **visit** window to the 12 months ending at the report's `as_of` — not the browser clock, so a stale tablet cannot drill into a different window than the figure was computed for |
| Lapsed (12m) | **nothing.** The list has no "not seen since" filter, so the card stays non-interactive rather than showing the opposite set. This is the recall list and the one most worth wiring |

Registration window and visit window are different questions and must not be conflated:
August 2026 held 646 registrations against 92 people actually seen.

**The drilled filter is written to the URL.** The list seeds its filters from the query
string at mount and holds them in state after, so a drill that only set state vanished the
moment you opened a patient and pressed Back. Writing it to the address bar makes Back
restore exactly the filtered list you left.

The report is titled **Patient Report**, and opens on **This Month**.

A card is interactive only while **gender and status are unset**: the list filters by neither,
so under those a drill would widen the set the card counted — narrow to Male (95) and it would
show all 659.

## Rest of the report (below the cards)

- **Charts** — patients by age band (pediatric bands), last-visit recency, by gender,
  visits per patient.
- **Needs attention** — counts only, each one clicks through to the filtered patient list:
  lapsed with no upcoming appointment · never seen · missing date of birth.
- **Filters** — the report carries its own controls: **Today · This Week · This Month ·
  This Quarter · This Year**, a practitioner selector, and a custom date range. They open
  **seeded from the list** — so the first thing you see describes the rows you were just
  looking at — and are then independent, so widening the report to "This Quarter" does not
  disturb the list behind it.

  A custom range always beats a preset, matching the backend's own precedence, so the lit
  control and the window the server picked cannot disagree. The scope line under the controls
  prints the window the **server resolved**, not the one requested — a preset means nothing
  until it becomes dates. A practitioner confined to their own data server-side gets no
  selector, because it could not change anything.

  Gender and status still come from the list and have no control here.

## Rules

- Counts only. No patient names, no MRN, no DOB (PHI-6). Names live on the
  list screen, which is already permission-checked.
- A block with no data source is flagged in `meta.stub_fields` — it is never filled with
  a made-up number.
- All labels come from the message catalog (`es-MX` + `en-US`). No hardcoded strings.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.7 | 2026-09-11 | Anant Sharma (AI-assisted) | Drilled filters persist in the URL so Back restores them; report titled Patient Report and opens on This Month |
| 1.6 | 2026-09-11 | Anant Sharma (AI-assisted) | The report has its own period / practitioner / custom-range controls, seeded from the list then independent |
| 1.5 | 2026-09-11 | Anant Sharma (AI-assisted) | Cards drill into the list's own filters instead of linking — a link to the page you are already on did nothing |
| 1.4 | 2026-09-11 | Anant Sharma (AI-assisted) | Cards drill through to the filtered list; recorded which do not and why |
| 1.3 | 2026-09-11 | Anant Sharma (AI-assisted) | Report opens as a right-side drawer over the list again; the List / Report toggle is kept as the control |
| 1.2 | 2026-09-11 | Anant Sharma (AI-assisted) | The report is now a List / Report view toggle that replaces the list, not a right-side drawer over it |
| 1.1 | 2026-09-11 | Anant Sharma (AI-assisted) | Dropped the registrations-over-time and by-practitioner charts. The endpoint still returns both; practitioner attribution belongs to the clinic-activity report, and registrations rendered as a single bar on any window shorter than two months |
| 1.0 | 2026-09-11 | Anant Sharma (AI-assisted) | Initial version |
