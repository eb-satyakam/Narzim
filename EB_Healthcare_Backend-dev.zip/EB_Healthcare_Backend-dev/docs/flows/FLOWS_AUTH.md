# Auth Flows — eb_frappe_jwt + Next.js BFF

**Doc status:** living · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

Authoritative diagrams for how the Remedisys frontend authenticates against the
backend. Decision: **ADR-011** (eb_frappe_jwt Bearer JWT, OAuth2/SID retired).
Pattern: **BFF preserved** — tokens live server-side in the NextAuth session; the
browser never holds a JWT. Mode: **password-only first**, 2FA (`verify_otp`)
deferred.

Backend endpoints (all under `/api/method/`):

| Endpoint | Purpose |
|---|---|
| `eb_frappe_jwt.api.get_token` | Login → access + refresh pair |
| `eb_frappe_jwt.api.refresh_token` | Rotate → new pair, old refresh revoked |
| `eb_frappe_jwt.api.revoke_token` | Logout this device |
| `eb_frappe_jwt.api.revoke_all_tokens` | Logout all devices |
| `eb_frappe_jwt.api.verify_otp` | 2FA second step (deferred) |
| `remedisys_healthcare_ai.api.v1.auth.api.get_current_user` | Profile + roles |

---

## 1. System Architecture

```mermaid
%%{init: {'theme':'dark'}}%%
graph TB
    subgraph BROWSER["Browser"]
        UI["React UI<br/>holds: encrypted NextAuth cookie only<br/>never sees JWT"]
    end

    subgraph VERCEL["Next.js on Vercel — BFF"]
        NA["NextAuth<br/>authorize() · jwt() · session()"]
        TOK["Server-side JWT store<br/>access_token · refresh_token · expiry"]
        CL["api/client.ts<br/>frappeFetch() → Authorization: Bearer"]
        NA --- TOK
        CL --- TOK
    end

    subgraph FC["Frappe Cloud"]
        AH["eb_frappe_jwt<br/>auth_hooks → validate_jwt_auth()"]
        API["remedisys_healthcare_ai<br/>api/v1/*/api.py + require_permission()"]
        EP["eb_frappe_jwt.api<br/>get_token · refresh_token · revoke_token"]
        DB[("MariaDB<br/>EB JWT Token · User · Healthcare")]
        AH --> API
        EP --> DB
        API --> DB
        AH --> DB
    end

    UI -->|"1 · login (email,pwd)"| NA
    UI -->|"data calls (session cookie)"| CL
    NA -->|"get_token"| EP
    CL -->|"Bearer access_token"| AH
    NA -.->|"refresh_token (silent)"| EP

    classDef b fill:#1e3a5f,stroke:#3b82f6,color:#e2e8f0
    classDef v fill:#14532d,stroke:#22c55e,color:#dcfce7
    classDef f fill:#431407,stroke:#f97316,color:#fed7aa
    class UI b
    class NA,TOK,CL v
    class AH,API,EP,DB f
```

---

## 2. Login Flow (password-only; 2FA branch shown but deferred)

```mermaid
%%{init: {'theme':'dark'}}%%
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant N as NextAuth (server)
    participant J as eb_frappe_jwt.api
    participant H as Healthcare DB

    U->>B: enter email + password
    B->>N: signIn("credentials")
    N->>J: POST get_token { usr, pwd, device }

    alt valid credentials, no 2FA
        J->>H: check_password + lockout tracker
        H-->>J: ok
        J-->>N: { access_token, refresh_token, expires_in }
        N->>N: store tokens in server-side JWT<br/>accessTokenExpires = now + expires_in
        opt role from get_current_user (Option B)
            N->>J: GET get_current_user (Bearer)
            J-->>N: { roles, frontendRole, practitioner }
        end
        N-->>B: session cookie (no tokens)
        B-->>U: redirect to role dashboard
    else 2FA enabled (DEFERRED)
        J-->>N: { requires_2fa, tmp_id }
        N-->>B: prompt for OTP
        U->>B: enter OTP
        B->>N: submit otp + tmp_id
        N->>J: POST verify_otp { tmp_id, otp }
        J-->>N: { access_token, refresh_token }
    else wrong password / locked
        J-->>N: 401 / lockout error
        N-->>B: show login error
    end
```

---

## 3. Authenticated Request Flow

```mermaid
%%{init: {'theme':'dark'}}%%
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant C as Next.js client.ts (BFF)
    participant H as eb_frappe_jwt auth_hooks
    participant A as api/v1/patients/api.py
    participant DB as MariaDB

    U->>B: open Patient List
    B->>C: fetch (NextAuth session cookie)
    C->>C: read access_token from server JWT
    C->>H: GET list_patients<br/>Authorization: Bearer <access_token>
    H->>H: verify_jwt() → set frappe.session.user
    alt token valid
        H->>A: dispatch as authenticated user
        A->>A: require_permission("Patient","read")
        A->>DB: frappe.get_all(...)
        DB-->>A: rows
        A-->>C: { data }
        C-->>B: JSON
    else token expired / invalid
        H-->>C: 401
        C->>C: trigger refresh (see Flow 4)
    end
```

---

## 4. Silent Refresh with Rotation

```mermaid
%%{init: {'theme':'dark'}}%%
sequenceDiagram
    autonumber
    participant C as Next.js (jwt callback)
    participant J as eb_frappe_jwt.api
    participant DB as EB JWT Token

    Note over C: on each request, jwt() checks<br/>now ≥ accessTokenExpires − skew ?
    alt access token still fresh
        C->>C: return token unchanged
    else needs refresh
        C->>J: POST refresh_token { refresh_token }
        J->>DB: look up hash, check revoked + expiry
        alt valid
            J->>DB: revoke OLD token (single-use)
            J->>DB: insert NEW refresh token (hashed)
            J-->>C: { new access_token, NEW refresh_token }
            C->>C: store NEW refresh_token + new expiry
        else revoked / expired / reused
            J-->>C: 401
            C->>C: mark session error → force re-login
        end
    end
```

> **Concurrent refresh is safe.** eb_frappe_jwt keeps a short idempotent grace
> window (`eb_jwt_refresh_grace_seconds`, default 30s): if several parallel
> requests refresh the *same* token at once (common when a page fans out API
> calls right at access-token expiry), they all replay the **same** new pair
> instead of one winning the single-use revoke and the rest getting a 401.
> Genuine reuse after the window is still rejected. Verified with 6 parallel
> refreshes → 6×200, one pair.

---

## 5. Logout

```mermaid
%%{init: {'theme':'dark'}}%%
sequenceDiagram
    autonumber
    actor U as User
    participant B as Browser
    participant N as NextAuth (server)
    participant J as eb_frappe_jwt.api
    participant DB as EB JWT Token

    U->>B: click Logout
    B->>N: signOut()
    N->>J: POST revoke_token { refresh_token }
    J->>DB: mark token revoked
    J-->>N: { message: "logged out" }
    N->>N: destroy NextAuth session
    N-->>B: clear session cookie
    B-->>U: redirect to /login
    Note over J,DB: revoke_all_tokens → kills every device
```

---

## 6. Token Lifecycle (state machine)

```mermaid
%%{init: {'theme':'dark'}}%%
stateDiagram-v2
    [*] --> Anonymous
    Anonymous --> Authenticating: submit credentials
    Authenticating --> Anonymous: invalid / locked
    Authenticating --> Active: get_token issues pair
    Active --> Active: API calls (Bearer)
    Active --> Refreshing: access token near expiry
    Refreshing --> Active: new pair (old revoked)
    Refreshing --> Anonymous: refresh expired/revoked
    Active --> Anonymous: logout (revoke)
    Active --> Anonymous: refresh token > 30d old
```

---

## Invariants (must always hold)

1. **Browser never holds a JWT.** Access + refresh tokens stay in NextAuth's
   server-side JWT; the browser only carries the encrypted NextAuth session cookie.
2. **Refresh tokens are single-use.** Every refresh returns a new refresh token;
   the client must persist it. Reusing the old one is rejected (rotation).
3. **The backend authenticates by `frappe.session.user`.** `eb_frappe_jwt`'s
   `auth_hooks` sets it from the Bearer token; `get_current_user()` and
   `require_permission()` are unchanged.
4. **Permissions are enforced server-side on every call**, regardless of frontend
   routing — a bypassed UI guard still hits a 403 from Frappe.
5. **No OAuth2, no SID cookie.** Both retired by ADR-011.

## References

- ADR-011 — `docs/adr/adr-011-auth-eb-frappe-jwt.md`
- Integration plan — `docs/planning/AUTH_INTEGRATION_PLAN.md`
- eb_frappe_jwt — github.com/eBasics-Services-P-Limited/eb_frappe_jwt

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
