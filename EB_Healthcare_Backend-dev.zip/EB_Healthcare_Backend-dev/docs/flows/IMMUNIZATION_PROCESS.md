# Immunization — End-to-End Process & Design

**Doc status:** living · **Created:** 2026-06-18 by Anant Sharma · **Updated:** 2026-08-27 by Divyanshu (AI-assisted) · **Version:** 1.3

**Scope rule:** this is built for **all medical practices and specializations**, NOT pediatrics only. No design here may hardcode pediatric assumptions. The same flows must serve adult/occupational vaccines, travel clinics, seasonal flu, event-based series (rabies, tetanus after injury), pregnancy, geriatrics, etc.

---

## 1. The mental model (the vaccination card)

Picture a paper vaccination card (*cartilla*). Three different concerns live on it:

1. **The rulebook** — "Hepatitis B = 3 doses: birth, 2 months, 6 months." Defined once, reused for everyone.
2. **This patient's card** — *which* vaccines this patient is on, and *when each dose is due*.
3. **The stamps** — each time a dose is actually given, the card is stamped (date, lot, who).

The on-screen chart is simply those three combined — and it is **computed live, never stored**. Dose dates are calculated from the patient's date of birth (or other anchors), and each dose is colored by whether a "stamp" (administration record) exists.

**One source of truth principle:** a dose given is recorded **once** as an `Immunization`. Workflow (a nurse to-do) and billing (a charge) are *separate layers* that point at it — they never duplicate it.

---

## 2. Roles / personas (who does what)

| Role | Responsibility in immunization |
|---|---|
| **Platform / Clinic Admin** | Builds the catalog: vaccines, each vaccine's schedule, and programs (named bundles). |
| **Front Desk** | Registers patients; applies a program (e.g. routine schedule) where the clinic uses one. |
| **Practitioner (Doctor)** | Assigns specific/on-demand vaccines (e.g. rabies after a bite); reviews the card. |
| **Nurse** | Sees due doses in the worklist; administers and records the shot (date, lot, site). |
| **Pharmacist / Safety** | Lot/batch tracking; recall ("who received lot #123?"); adverse-event follow-up. |
| **Patient / Parent** | Brings prior history (doses given elsewhere) to be recorded. |

---

## 3. User stories by role (with examples)

> Example cast: **Lucía** (mother) brings newborn **Mateo**; **Sofía** (12, HPV); **Sr. Ramírez** (adult, dog bite); **Doña Carmen** (70, flu). Staff: **Aminata** (front desk), **Lourdes** (nurse), **Dr. Miguel** (practitioner), **Diego** (pharmacist), plus a **Clinic Admin** and a **Safety/Epidemiology** officer. Each story shows the records touched.

### 👩‍🍼 Patient / Parent
- **US‑P1 — Routine enrolment.** *As a parent, I want my newborn put on the standard schedule, so I know exactly which vaccines are needed and when.*
  *Example:* Lucía registers Mateo; the clinic's "Mexico pediatric routine" program is applied → Mateo's card shows all 14 vaccines with due dates. **Records:** `Patient` (Mateo) + `Patient Vaccine` ×14.
- **US‑P2 — Doses done elsewhere.** *As a parent, I want shots given at another clinic recorded, so they aren't repeated.*
  *Example:* Lucía's *cartilla* shows BCG at birth (Hospital General). Lourdes records it as **External**. **Records:** `Immunization` (source=External, provider="Hospital General").
- **US‑P3 — Reminder.** *As a parent, I want a reminder before a dose is due, so I don't miss it.* *Example:* WhatsApp 3 days before Mateo's 2‑month doses. **Records:** `Notification` (Phase 4).
- **US‑P4 — Certificate.** *As a parent, I want a printed vaccination certificate for school enrolment.* **Records:** print/cert from the card.

### 🪪 Front Desk (Aminata)
- **US‑F1 — Register + apply program.** *As front desk, I want to register a patient and apply the clinic's routine program in one step.* *Example:* Aminata registers Mateo and clicks **Apply program → pediatric routine**. **Records:** `Patient`, `Patient Vaccine` ×14.
- **US‑F2 — Consent / guardian.** *As front desk, I want to capture guardian + consent before vaccination of a minor, so it's legal and on file.* *Example:* records Lucía as guardian and her consent for Mateo. **Records:** consent on the visit/`Immunization`.
- **US‑F3 — Collect payment.** *As front desk, I want to bill the vaccine + administration fee.* *Example:* charges Doña Carmen for the flu shot. **Records:** `Sales Invoice` (reuse ERPNext).

### 💉 Nurse (Lourdes)
- **US‑N1 — Worklist of due doses.** *As a nurse, I want today's due/overdue doses in my worklist, so I know who needs what.* *Example:* Lourdes sees "Mateo — Hep B 2nd (overdue)". **Records:** `Nursing Task` (optional) ← computed schedule.
- **US‑N2 — Pre‑vaccination screen.** *As a nurse, I want to screen temperature, weight and allergies before giving a dose, so I don't vaccinate unsafely.* *Example:* Mateo's temp is 38.5 °C → Lourdes **defers** today's doses. **Records:** `Vital Signs`; dose marked Deferred.
- **US‑N3 — Administer with batch + expiry.** *As a nurse, I want to pick the actual vaccine batch (expiry‑checked) and have stock decrement, so records are accurate and recalls work.* *Example:* gives Pentavalente from Batch `LOT‑2026A` (exp 2027‑05). **Records:** `Immunization` (source=In‑clinic, batch) + stock movement.
- **US‑N4 — Multi‑vaccine visit.** *As a nurse, I want to record several shots given in one visit together.* *Example:* Mateo gets Pentavalente + Rotavirus + Neumococo in one sitting. **Records:** 3× `Immunization`.
- **US‑N5 — Refusal / deferral.** *As a nurse, I want to record when a parent refuses or a dose is deferred, so it's not mistaken for "just not done yet".* *Example:* Lucía declines Rotavirus → marked **Refused**. **Records:** `Immunization`/status = Refused.
- **US‑N6 — Adverse event (AEFI/ESAVI).** *As a nurse, I want to record a reaction after a dose, so it's reported and tracked.* *Example:* Mateo develops fever after DTP → adverse event logged. **Records:** AEFI record linked to the `Immunization`.

### 🩺 Practitioner / Doctor (Dr. Miguel)
- **US‑D1 — On‑demand vaccine.** *As a doctor, I want to assign a single vaccine when clinically needed, without any routine bundle.* *Example:* Sr. Ramírez is bitten by a dog → Dr. Miguel assigns **Rabies (post‑exposure)**; doses day 0/3/7/14/28 from the bite. **Records:** `Patient Vaccine` (rabies); later `Immunization` per dose.
- **US‑D2 — Review + contraindication.** *As a doctor, I want to review the card and contraindications before approving a dose.* *Example:* before Sofía's HPV, checks no contraindication. **Records:** read‑only (uses Allergy/contraindication data).
- **US‑D3 — Catch‑up / special schedule.** *As a doctor, I want to put a late or special patient on a catch‑up schedule.* *Example:* a 3‑year‑old who never started → assigns the "catch‑up" schedule of a vaccine. **Records:** `Patient Vaccine` (catch‑up schedule).
- **US‑D4 — Minimum‑interval guard.** *As a doctor, I want a warning if a dose would be given too early, so the dose stays valid.* *Example:* tries MMR 2nd only 2 weeks after the 1st → system warns. **Records:** validation only.

### 💊 Pharmacist / Inventory (Diego)
- **US‑PH1 — Stock & batches.** *As a pharmacist, I want to maintain vaccine stock with batch + expiry, so the right product is available and traceable.* *Example:* receives a flu batch with expiry. **Records:** Item `Batch` / Stock Entry.
- **US‑PH2 — Stock‑out alert.** *As a pharmacist, I want an alert when a vaccine runs low.* *Example:* BCG below reorder level. **Records:** stock alert.
- **US‑PH3 — Recall by lot.** *As a pharmacist/safety, I want to find every patient who received a recalled lot.* *Example:* lot `LOT‑2026A` recalled → list all `Immunization` with that batch. **Records:** query.
- **US‑PH4 — Deduct on administration.** *As a pharmacist, I want stock to drop automatically when a dose is given (no double entry).* **Records:** stock movement triggered by `Immunization`.

### 🛠️ Clinic Admin
- **US‑A1 — Build the catalog.** *As an admin, I want to define vaccines, their schedules, and programs (named bundles), so staff don't assign one‑by‑one.* *Example:* creates the 14 routine `Vaccine Schedule`s and bundles them into the "Mexico pediatric routine" `Immunization Program`. **Records:** `Item`, `Vaccine Schedule` (+doses), `Immunization Program`.
- **US‑A2 — Configure auto‑apply.** *As an admin, I want to choose whether a program auto‑applies at registration for this clinic (a pediatric clinic does; a cardiology clinic doesn't).* **Records:** clinic setting.

### 📊 Safety / Epidemiology officer
- **US‑S1 — AEFI surveillance.** *As a safety officer, I want a report of adverse events for the period, so I can report to the health authority.* **Records:** report over AEFI.
- **US‑S2 — Coverage & defaulters.** *As an epidemiology officer, I want coverage % and a list of overdue patients, so we can chase defaulters.* *Example:* "62% of under‑2s up to date; 38 children overdue." **Records:** report over schedule + records.

---

## 4. The data model (doctypes)

> Naming below is the **target** model. A few items are renames/additions still to be implemented — see §8 for current names and build status.

| Doctype | Plain meaning | Key fields | Created by |
|---|---|---|---|
| **Item** (Vaccine item group) | The vaccine **product** — substance with **batch/lot, expiry, stock, price** | item_code, item_name, item_group=Vaccine, has_batch_no | Admin |
| **Vaccine Schedule** *(rename of "Immunization Template")* | One vaccine's **dose pattern**; a vaccine may have several (infant / adult / post-exposure) | schedule_name, vaccine (→Item), category, aliases, disabled, **doses** (child) | Admin |
| **Vaccine Schedule Dose** *(rename of "Immunization Schedule Dose")* | One scheduled dose inside a schedule | dose_label, **basis** (Age / Yearly / Previous Dose), age_months, interval_months, window_months, dose_amount, dose_uom | Admin |
| **Immunization Program** *(new)* | A **named bundle** of vaccine schedules for a context ("Mexico pediatric routine", "adult catch-up", "travel") | program_name, **schedules** (child → Vaccine Schedule), is_default, applies_to (optional) | Admin |
| **Patient Vaccine** | "**this vaccine is assigned to this patient**" — the card entry | patient, vaccine schedule, status (Active/Stopped), assigned_by, assigned_on, encounter/appointment, notes | Front Desk / Doctor |
| **Immunization** | "**a dose was given**" — the administration record (the stamp) | patient, vaccine (→Item), schedule, scheduled_dose_label, date_administered, **supply** (In-house stock / Patient-supplied / External-history), **external_provider**, batch, administered_by, administration_site, lot_number, notes | Nurse |
| **Nursing Task** *(reuse core, optional)* | "**nurse: give this dose**" — a worklist to-do generated from a due dose | patient, task/description, status, due — completing it writes an `Immunization` | system → Nurse |

**Why these and not fewer:**
- The vaccine product stays an **Item** (gives batch/lot/expiry/recall/stock for free) — we do **not** build a separate "vaccine master".
- A program (set of vaccines) and a vaccine's doses are **two levels** (Program → Schedule → Doses); they cannot collapse into one child table.
- `Immunization` is dedicated (not folded into Clinical Procedure) so vaccine specifics (lot, dose, series) and recall reporting stay clean.

### Relationships

```
Item (vaccine product: lot, expiry, stock)
   ▲ linked by
Vaccine Schedule (+ Vaccine Schedule Dose child)  ──many──►  Immunization Program (named set)
   │ assigned to a patient as
Patient Vaccine (patient ↔ vaccine schedule, Active/Stopped)
   │ administered as
Immunization (date, source, lot, site)   ◄── optionally created from ── Nursing Task (to-do)
```

The **chart** = Patient Vaccine rows × their schedule's doses × Immunization records, with dates computed per dose `basis`. Computed on read; nothing about the chart is stored.

### Entity diagram

```mermaid
erDiagram
    ITEM ||--o{ VACCINE_SCHEDULE : "is product for"
    VACCINE_SCHEDULE ||--o{ VACCINE_SCHEDULE_DOSE : "has doses"
    VACCINE_SCHEDULE }o--o{ IMMUNIZATION_PROGRAM : "bundled in"
    PATIENT ||--o{ PATIENT_VACCINE : "assigned"
    VACCINE_SCHEDULE ||--o{ PATIENT_VACCINE : "of schedule"
    PATIENT ||--o{ IMMUNIZATION : "received"
    PATIENT_VACCINE ||--o{ IMMUNIZATION : "fulfilled by"
    ITEM ||--o{ IMMUNIZATION : "product given"
    NURSING_TASK |o--o| IMMUNIZATION : "completes into"
```

**How to read it:**
- An **Item** (the vaccine product, with batch/lot/expiry) is used by one or more **Vaccine Schedules** (e.g. an infant schedule and an adult schedule of the same vaccine).
- A **Vaccine Schedule** has many **Vaccine Schedule Doses**, and can belong to many **Immunization Programs** — and a program bundles many schedules (many‑to‑many). This is why a program and a vaccine's doses are **two separate levels**, not one table.
- A **Patient** has many **Patient Vaccine** assignments (one per schedule they're on) and many **Immunization** records (one per dose actually given).
- Each **Immunization** points back to the **Patient Vaccine** it fulfils and to the **Item** actually administered (carrying the real batch/lot for recalls).
- A **Nursing Task** (optional) resolves into one **Immunization** when the nurse completes it — workflow layer, not a copy.

### Reuse of existing system doctypes (don't reinvent)

ERPNext Healthcare has **no native immunization/vaccination doctype**, which is why `Immunization`, `Vaccine Schedule`, `Vaccine Schedule Dose`, and `Patient Vaccine` are custom. Everything *around* immunization already exists and must be reused:

| Need | Reuse | Notes |
|---|---|---|
| Vaccine product + lot/expiry/stock | **Item + Batch + Stock** (core) | in-house supply, decrement, recall |
| Drug class / interaction safety | **Medication**, `Drug Interaction`, `Medication Class Interaction` | optional contraindication checks |
| **Named program / standard schedule** | *(small custom — see note)* | Treatment Plan Template was evaluated and **rejected**: its children link Items/procedures, so it can't hold a vaccine **with its dose ladder**, and it carries care-plan/inpatient semantics. Use either applicability fields on `Vaccine Schedule` (one routine set) or a tiny **Immunization Program** doctype (a named list of `Vaccine Schedule` links + age/gender) for multiple named sets. |
| Order a vaccine for a patient | **Service Request** *(alternative to `Patient Vaccine`)* | standard FHIR-style order (`patient`, `item_code`, `status`, `expected_date`). We keep lean `Patient Vaccine`; Service Request only if full ordering/worklist is wanted. |
| Pre-vaccination checklist | **Nursing Checklist Template** + **Nursing Task** | screening + worklist |
| Pre-screen temp / weight | **Vital Signs** | defer-if-febrile, weight-based dosing |
| Allergy / contraindication screen | **Allergy** + **Allergy Interaction** | |
| Administration as billable act | **Clinical Procedure** (+ template/item) → **Sales Invoice** | optional billing layer |
| Adverse event (AEFI/ESAVI) | *(no native — small new doctype)* | links to the `Immunization` |

**Decision recommendations:** reuse **Treatment Plan Template** for the program/bundle; **keep `Patient Vaccine`** for series assignment (lighter than Service Request); add only a small **AEFI** doctype where nothing native exists.

---

## 5. Timing — how each dose's due date is anchored (`basis`)

| basis | Due date = | Used for |
|---|---|---|
| **Age** | DOB + age_months | routine childhood vaccines |
| **Yearly** | last given + interval (default 12 mo); due now if never given | seasonal flu (all ages) |
| **Previous Dose** | previous given dose date + interval_months | "next dose N months after the last" |
| **Event** *(planned)* | an event date on the assignment + interval (in **days**) | rabies/tetanus after a bite/injury, travel |

A patient with **no date of birth is allowed** — Age-anchored doses simply show undated (status `future`); Yearly still works.

**Status & colors (computed per dose):** `given` 🟢 · `due` 🟠 (now / within window) · `overdue` 🔴 (past window) · `future` ⚪ (not yet due).

---

## 6. End-to-end flows (step by step · actor → action → record)

### Process overview (flow diagram)

```mermaid
flowchart TD
    A["Admin: define Item, Vaccine Schedule (+doses), Program"] --> B["Front Desk: register patient"]
    B --> C{"Clinic uses a routine program?"}
    C -- yes --> D["Apply program → Patient Vaccine × N (bulk)"]
    C -- no --> E["Doctor: Assign single vaccine → Patient Vaccine (e.g. rabies)"]
    D --> F["Chart computes per-dose: due / overdue / upcoming"]
    E --> F
    F --> H["Parent brings prior card → record as Immunization (source = External)"]
    F --> N["Reminders sent for due / overdue doses (Phase 4)"]
    F --> G["Nurse worklist: today's due / overdue doses"]
    G --> S{"Pre-vaccination screen OK? (temp / allergy / consent)"}
    S -- no --> R["Defer / Refuse (status recorded)"]
    S -- yes --> J["Administer: pick batch + expiry, record Immunization (In-clinic)"]
    J --> K["Stock decremented · dose turns green · schedule advances"]
    K --> L{"Adverse reaction?"}
    L -- yes --> M["Record AEFI (safety report)"]
    J --> P["Optional: bill vaccine + administration fee (Invoice)"]
```

**In words:** the admin builds the catalog once. A patient is then either **bulk‑enrolled** via a program (routine/newborn) or **hand‑assigned** a single vaccine (on‑demand, e.g. a dog‑bite rabies course). From there the chart is **computed**. Day to day the nurse works from **due doses**, screens the patient (temperature/allergy/consent), picks a **real batch**, and records the dose — which **decrements stock, turns the dose green, and advances the schedule**. Doses given elsewhere are captured as **history**; **reminders** chase overdue ones; **adverse events** and **billing** hang off the administration. Each step writes exactly one kind of record (shown per‑flow below), never a duplicate.

### Sequence — one real OPD visit (Mateo, 2‑month check‑up)

> Mateo was enrolled at birth (program applied). He's back for his 2‑month visit; several doses are due.

```mermaid
sequenceDiagram
    actor Parent as Lucía (parent)
    participant FD as Front Desk (Aminata)
    participant Nurse as Nurse (Lourdes)
    participant Sys as Remedisys
    participant Stock as Inventory

    Parent->>FD: Arrive for Mateo's 2-month visit
    FD->>Sys: Check in (Patient Appointment)
    FD->>Sys: Confirm guardian + consent
    Sys-->>FD: Card — due: Hep B 2nd, Pentavalente 1st, Rotavirus 1st, Neumococo 1st
    FD->>Nurse: Hand patient over
    Nurse->>Sys: Open worklist (list_pending_vaccines)
    Sys-->>Nurse: Pending vaccines + each one's next due dose
    Note over Nurse: Pre-screen — temp 36.8°C, no allergy → OK to proceed
    Nurse->>Stock: Select batch LOT-2026A (exp 2027-05)
    Nurse->>Sys: Record doses (create_immunization × 3, source = In-clinic, batch)
    Sys->>Stock: Decrement stock (3 units)
    Sys-->>Nurse: Doses → given · schedule advances · next due = 4 months
    opt If a reaction is reported
        Nurse->>Sys: Record AEFI linked to the dose
    end
    FD->>Sys: Bill vaccine + administration fee (Sales Invoice)
    Sys-->>Parent: Reminder scheduled for the 4-month visit (Phase 4)
```

**Records touched in this one visit:** `Patient Appointment` (check‑in) · consent on the visit · 3× `Immunization` (source=In‑clinic, with batch) · stock movement · optionally an AEFI record · `Sales Invoice` · a scheduled `Notification`. The chart re‑computes immediately — the three doses turn green and the next dose for each vaccine shows its new due date.

### Flow A — Clinic setup (one-time, by Admin)
1. **Admin** creates each vaccine as an **Item** (Vaccine group, batch tracking on). → *Item rows*
2. **Admin** creates a **Vaccine Schedule** per vaccine (or several per vaccine), adding its **doses** with a `basis`. → *Vaccine Schedule (+ Dose) rows*
3. **Admin** creates **Immunization Programs** — e.g. "Mexico pediatric routine" bundling the 14 routine schedules; "Travel - Africa"; "Adult occupational". → *Immunization Program rows*

### Flow B — Routine patient / newborn (Front Desk)
1. **Front Desk** registers the patient. → *Patient row*
2. The clinic's chosen program is **applied** — either automatically (if that clinic opted in) or via a one-click **"Apply program"**. This creates one **Patient Vaccine** per schedule in the program. → *Patient Vaccine rows (bulk)*
3. The chart now shows the full card with computed due/overdue/upcoming dates. No per-vaccine clicking.

> All-specializations note: auto-apply is **opt-in per clinic**, never forced. An adult walking into a cardiology clinic does NOT get baby vaccines auto-assigned.

### Flow C — Single on-demand vaccine, e.g. dog bite (Practitioner)
1. **Practitioner** clicks **Assign vaccine**, picks "Rabies (post-exposure)". → *one Patient Vaccine row*
2. Doses are timed from the bite (Event basis, *planned*) or recorded as given over the following days.
3. Rabies is **not** in any standard program, so it is never auto-applied — only assigned when needed.

### Flow D — Administering a dose in-clinic (Nurse)
1. **Nurse** opens the chart → **Add immunization**. The picker shows only **assigned + not-yet-complete** vaccines with each one's **next due dose** (computed server-side).
2. **Nurse** selects the vaccine; the next dose is pre-filled from the schedule. Enters date (today), lot, site.
3. Save → creates an **Immunization** with `source = In-clinic`. → *Immunization row*
4. The dose turns 🟢; the schedule advances to the next dose.

### Flow E — Recording doses given elsewhere / history (Nurse or Front Desk)
1. Parent presents the prior card: "BCG at birth at Hospital X; Hep B 1st at 2 months at Clinic Y."
2. **Staff** uses **Add immunization** with the **"Given elsewhere (history)"** toggle on for each: enters the **historical date**, sets `source = External`, types the **external_provider**, leaves lot/administered-by blank if unknown. → *Immunization rows (source=External)*
3. Those doses show 🟢 and the schedule advances; the clinic is **not** credited as administering them, and recall reports can exclude external rows (no lot).
4. *No longer a caveat, fixed 2026-08-27:* a record that names its dose explicitly (`scheduled_dose_label`) is matched to that exact ladder slot, so out-of-order/skipped-dose history now credits the right dose regardless of entry order. Only a record with no dose label at all still falls back to filling slots positionally, in date order — for backward compatibility with every record entered before this fix.

### Flow F — Viewing the card (Practitioner / any staff)
1. Open chart → Immunizations. **Schedule Card** (age-milestone grid), **Timeline**, or **Records** view.
2. Counters: Administered / Overdue / Due now / Upcoming. Overdue in 🔴.
3. *All-specializations note:* the age-milestone grid is a pediatric view; non-pediatric specialties should use the date/list view (every dose already carries a computed `due_date`).

### Flow G — Doctor → nurse administration handoff (built — ADR-020)
Two ways a `Nursing Task` "administer this vaccine" gets created:
1. **Doctor orders it in the encounter.** In the SOAP Vaccinations section the doctor sets a
   vaccine chip to **Assign to nurse** and picks the nurse. On Sign & close this creates the
   **`Patient Vaccine`** order (stamped with the ordering encounter) plus a **submitted
   `Nursing Task`** assigned to that nurse — and **no `Immunization` yet**. (The default chip
   mode, **Give now**, still records the dose in-room per ADR-019.) → *Patient Vaccine + Nursing Task*
2. **System-generated from a due/overdue dose** *(future)* — the computed schedule may also spawn
   the same kind of task.

The task references the order via `task_doctype = "Patient Vaccine"` / `task_document_name`, so it
appears in **My Work** (`get_my_tasks`) for the assigned nurse with no feed change.

**Nurse** opens it from the worklist → the Add-immunization dialog pre-fills the assigned vaccine
→ recording the dose (`create_immunization` with `nursing_task`) writes the **`Immunization`**
(inheriting the ordering encounter from the order), and marks the task **Completed** in the same
transaction. The computed schedule stays the source of truth; the task is just the actionable
surface. *Deferred (Phase 2): a nurse **Deferred** status (e.g. febrile) with reason + re-due.*

### Flow H — Lot recall / safety (Pharmacist / Safety)
1. A vaccine lot is recalled. **Safety** queries **Immunization** by `lot_number`. → *list of affected patients*
2. Because the product is an **Item with batch tracking**, expiry/stock context comes for free.

### Flow I — Patient-supplied vaccine (clinic has no in-house pharmacy)
The patient buys the vaccine at an outside pharmacy and brings the vial; we administer it.
1. **Nurse** records the dose with **`supply = Patient-supplied`**, typing the **lot + expiry off the patient's vial** (no inventory link). → *Immunization (supply=Patient-supplied)*
2. **No stock is decremented** (we never held it) — so a clinic with no pharmacy runs administration-only.
3. **Billing = administration fee only** (the vaccine itself wasn't sold by us). → *Sales Invoice (admin fee)*
4. Everything else is identical: the dose turns 🟢 and the schedule advances.

> Contrast the three `supply` values: **In-house stock** (decrement + lot from our Batch + bill vaccine&fee) · **Patient-supplied** (no decrement + lot from the vial + bill fee only) · **External-history** (given elsewhere — no stock, no billing; see Flow E).

---

## 7. Design principles (the rules we locked)

1. **All practices, no pediatric hardcoding.** Standard schedules are named, optional, configurable sets — never forced on every patient.
2. **The chart is computed, not stored.** Dose dates derive from DOB/anchors at read time, so a DOB correction or schedule change is always reflected.
3. **One source of truth per dose.** An `Immunization` records a dose once. Nursing Task (workflow) and Clinical Procedure (billing) are optional layers that *reference* it.
4. **Vaccine product = Item.** Reuse Frappe batch/lot/expiry/stock; do not reinvent a vaccine master.
5. **"Given" ≠ "given here".** `source` distinguishes in-clinic vs external/historical doses.
6. **Assignment before administration.** `Patient Vaccine` lets a vaccine (and its overdue doses) appear before any dose is given.

---

## 8. Current implementation status (built vs planned) & naming map

**Built today (in `api/v1/immunizations/api.py` + doctypes):**
- `Immunization Template` (+ `Immunization Schedule Dose`) — with `basis` (Age/Yearly/Previous Dose) + `interval_months`.
- `Patient Vaccine` (assignment) + `assign_vaccine` / `list_assigned_vaccines` / `unassign_vaccine`.
- `Immunization` (shot log) + `create/list/get/update/delete_immunization`.
- `get_immunization_schedule` (assigned-only, basis-aware, computed `due_date`, DOB optional).
- `list_pending_vaccines` (assigned + incomplete → next dose) — backs the Add-immunization picker.
- `Immunization Program` (+ `Immunization Program Item` child) — named bundle of vaccine schedules + age/gender; CRUD + **`apply_program(patient, program)`** (bulk enrolment, idempotent). Seeded "Mexico Pediatric Routine" (10 core vaccines).
- **Consent (2026-06-18)** — `consent_obtained` + `consent_by` + auto-stamped `consent_obtained_at` on Immunization (controller stamps, mirrors AI Encounter Session); FE consent checkbox + "consent given by" in the Add dialog. Non-blocking. Verified.
- **Pre-vaccination screening (2026-06-18)** — read-only safety banner in the Add dialog: the patient's **allergies** (from `patient.allergies`, shown only when present) + the **latest recorded temperature** (via `usePatientVitals`; red ≥38°C with "febrile, consider deferring", amber below, generic fever reminder when none on file). Reuses existing data, no new doctype, doesn't block.
- **`supply` field** on Immunization (In-house stock / Patient-supplied / External-history) + `external_provider` — backend (CRUD + validation). The two concerns were split:
  - **"Given elsewhere" (history) — BUILT (2026-06-18):** a focused **"Given at another clinic (history)"** toggle in the Add dialog (always available, not pharmacy-gated) that reveals a **Provider / clinic** field and saves the dose with `supply = External-history` + `external_provider`. Handles prior history AND a mid-series dose taken at another clinic (e.g. dose 1 here, dose 2 elsewhere). Verified end-to-end.
  - **Pharmacy / in-house-vs-patient-supplied — deferred:** intentionally hidden (no in-house pharmacy → needless friction). Re-enable gated behind a `manage_vaccine_inventory` clinic setting when inventory (#2) is built.
- Frontend (EB_Healthcare_Frontend): Add-from-pending picker, Schedule Card / Timeline / Records views. **Assign-vaccine and Apply-program buttons do NOT exist in the UI** — corrected 2026-08-27, see the note below; the dialogs (`AssignDialog`, `ApplyProgramDialog`) are dead code, unreachable from anywhere in the tab.
- **`show_by_default` on Immunization Template — BUILT (2026-08-27).** A vaccine flagged this way is offered to every patient's Schedule Card / Timeline / Add-immunization picker even before it's assigned to them — see the fixed items directly below. Settings → Vaccine Schedules has the checkbox; nothing is flagged on any template yet (a clinical/product call, not a code default).
- **Click-to-add on the Schedule Card / Timeline — BUILT (2026-08-27).** Clicking any not-yet-given dot opens "Add immunization" pre-selected to that vaccine **and that exact dose** — see the label-matching fix below. Still not built: browsing/picking a dose with no dot to click at all (the vaccine has to already be assigned or default-shown).

**Fixed 2026-08-27** (see `WORK_LOG.md`'s three 2026-08-27 immunization entries, and `IMMUNIZATION_DECISION_LOG.md` for the plain-language account, for the full details — three separate work sessions, same day):
- **Flow B (the old standalone vaccination-invoice endpoints) retired.** `list_billable_immunizations` / `create_vaccination_invoice` and the frontend "Bill" button that called them are deleted — closes `docs/flows/GAPS_BILLING.md` B-16, a live double-bill route left open since ADR-026.
- **`apply_program` now bills.** Bulk-enrolling a patient via a Program previously created the `Patient Vaccine` assignments with no product Medication Request — unlike assigning one vaccine at a time. Both paths now match.
- **"Add immunization" flags early/off-schedule doses.** The picker still offers doses that aren't due yet (a clinician may deliberately give one early), but now shows a clear warning naming both the vaccine and the real due date instead of no indication at all.
- **A patient with zero assigned vaccines can now actually add one.** `_schedule_payload` (backing the chart, Timeline, Records, and the Add-immunization picker alike) now also includes `show_by_default` templates the patient isn't assigned to yet.
- **An assigned Event Based dose (e.g. Anti Rabies / rabies PEP) now becomes actionable.** It used to sit permanently as "Not yet due," by design, even once genuinely ordered for a patient through an encounter — Event Based never computes a real calendar date. Now: assigned → "Due now" (the assignment itself is the clinical indication); only previewed via `show_by_default`, not actually assigned → correctly stays "Not yet due."
- Two Schedule Card grid display fixes: the "Ongoing" column (where no-fixed-age doses like Event Based render) is now pinned in view instead of scrollable out of sight past the age columns; "Not yet due" doses now render as a visible circle in its own colour (blue, matching the "Upcoming" label already used in the stats tile) instead of a nearly-invisible transparent gray dash — consistent now across the dot, its hover tooltip (which also shows the real due date), the legend, and the stats tile.
- **A vaccine with two doses still open could record the wrong one as given.** Picking (or clicking the dot for) a specific dose used to fall back to whichever dose was structurally first, regardless of which was actually chosen — and even that fix alone wasn't enough, because the schedule computation matched a recorded shot to its ladder slot by counting order, never by which dose was actually picked. Both fixed together: matching is now label-first (falls back to the original order-based behaviour for any record with no explicit dose label, so nothing already on file shifted), and `list_pending_vaccines` returns one row per open dose instead of collapsing to just "next." Verified live: recording "Second" before "1 dose" on a test patient's Anti Rabies correctly credited "Second," not "1 dose."

**Correction — the "Apply program" button claim below was wrong.** This section previously said the frontend "Apply program" button was built and verified working. It was — from 2026-06-18 to 2026-07-13 — then removed on 2026-07-14 in a commit whose own message says "Apply program / Assign vaccine — disabled for all roles per product request." That is a deliberate product decision, not a bug, and this doc simply was never updated to say so until now. Neither button currently exists anywhere in the patient chart.

**Planned (agreed in design, not yet built) — reuse-first:**
- Rename **Immunization Template → Vaccine Schedule** and **Immunization Schedule Dose → Vaccine Schedule Dose** (clarity); allow **multiple schedules per vaccine**.
- ~~Programs / standard schedules~~ **BUILT (2026-06-18):** `Immunization Program` doctype + `apply_program` bulk-assign (now billing-correct, see above). Chose this small purpose-built bundle over Treatment Plan Template. The **frontend "Apply program" button does not currently exist** (see correction above) — reachable only via direct API call today. Still pending: **opt-in auto-apply on registration per clinic**.
- ~~`supply` + `external_provider`~~ **BUILT (2026-06-18)** — backend + frontend. Still pending: link **Item Batch** + stock decrement for In-house supply (the inventory task #2).
- **Adverse Event (AEFI/ESAVI)** — small new doctype linked to Immunization (no native equivalent).
- **Pre-vaccination screening** → reuse **Vital Signs** (temp/weight) + **Allergy**/`Allergy Interaction` (contraindications); optionally **Nursing Checklist Template**.
- **Worklist** → reuse **Nursing Task** generated from due doses.
- **Billing** → reuse **Clinical Procedure** / **Sales Invoice** (vaccine + admin fee, or admin-only for patient-supplied).
- **Event basis + day intervals** (rabies-style post-exposure dating).
- **Date/list view** for non-pediatric specialties (the age-grid is pediatric-only).
- More dose states (**Refused / Deferred / Contraindicated**).
- ~~pick-exact-dose (out-of-order history)~~ **BUILT (2026-08-27)** — recording a specific, named dose now correctly credits that exact ladder slot; see Flow E and the Fixed list above. Still not built: a way to *browse and pick* an arbitrary dose that has no dot on the chart yet (the vaccine still has to be assigned or default-shown first).

**Naming map (target → current code):**

| Target name | Current code name |
|---|---|
| Vaccine Schedule | Immunization Template |
| Vaccine Schedule Dose | Immunization Schedule Dose |
| Immunization Program | Immunization Program (built 2026-06-18, same name) |
| Patient Vaccine | Patient Vaccine (same) |
| Immunization | Immunization (same) |

---

## 9. API reference (current)

All under `remedisys_healthcare_ai.api.v1.immunizations.api`, called via `/api/method/...`, standard `{status, data}` envelope.

| Method | Purpose |
|---|---|
| `assign_vaccine(patient, immunization_template, ...)` | Assign a vaccine to a patient (idempotent) |
| `list_assigned_vaccines(patient, include_stopped?)` | The patient's assigned vaccines |
| `unassign_vaccine(name)` | Stop an assignment (status → Stopped) |
| `get_immunization_schedule(patient)` | The computed chart (assigned-only, statuses + due dates) |
| `list_pending_vaccines(patient)` | Assigned + incomplete vaccines with the next due dose (Add-immunization picker) |
| `create_immunization(patient, vaccine|immunization_template, date_administered, ...)` | Record a dose (auto-assigns the vaccine if needed) |
| `list_immunizations` / `get_immunization` / `update_immunization` / `delete_immunization` | Record CRUD |
| `list_immunization_templates` / `get/create/update/delete_immunization_template` | Schedule (rulebook) CRUD |
| `list_vaccines(search?)` | Vaccine Item picker |

---

## 10. Open decisions

1. Build order for the planned items (Program + apply, then `source`/history, then Nursing Task?).
2. Auto-apply trigger for programs: on registration vs button vs both (per clinic).
3. Whether to do the rename now (low cost, early) or after Programs.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-08-27 | Divyanshu (AI-assisted) | Corrected a claim that had gone stale the same day it was written: "pick-exact-dose (out-of-order history)" was marked planned/caveated in two places, but was actually built and verified later the same day — both updated to BUILT. Logged the label-first dose-matching fix, and that "Upcoming" now has its own colour (was sharing gray with empty cells). Added `IMMUNIZATION_DECISION_LOG.md` as a companion read |
| 1.2 | 2026-08-27 | Divyanshu (AI-assisted) | Marked "Show by default" and click-to-add as BUILT (were "in progress"/unlisted); logged the zero-assigned-vaccines fix, the Event Based "never becomes actionable" bug fix, and the two Schedule Card display fixes (sticky Ongoing column, visible "not yet due" circle) |
| 1.1 | 2026-08-27 | Divyanshu (AI-assisted) | Corrected the false "Apply program button verified working" claim (removed 2026-07-14, per-product-request, never documented); noted Assign-vaccine is also unreachable; logged the Flow B retirement, the `apply_program` billing fix, and the Add-immunization early-dose warning; corrected the Immunization Program naming-map row ("not built" was wrong); added the in-progress "Show by default" checkbox to Planned |
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
