# ToDo — the create flow, and every field decision behind it

**Doc status:** living · **Created:** 2026-09-22 by Ashutosh (AI-assisted) · **Updated:** 2026-09-22 by Ashutosh (AI-assisted) · **Version:** 1.0

> **What this document owns:** how a `ToDo` is written from the app, and a field-by-field account of
> which parts of Frappe's ToDo form we expose, which we fill on the server, and which we deliberately
> leave alone — with the evidence for each.
>
> **What it does NOT own, and does not restate:** the single-assignee model, the Nursing Task state
> machine and the completion-bypass hunt. Those belong to
> [`FLOWS_TODO_AND_NURSING_TASK.md`](FLOWS_TODO_AND_NURSING_TASK.md) and
> [`adr-041`](../adr/adr-041-single-assignee-and-nursing-task-assignment.md). Read that one first if
> you are asking "who owns this task"; read this one if you are asking "what happens when someone
> presses Add To-Do".
>
> Per-change narrative lives in [`WORK_LOG.md`](../../WORK_LOG.md) (entries dated 2026-09-22); the
> reader-facing one-liners are in [`CHANGELOG.md`](../../CHANGELOG.md).

---

## 1. What a ToDo is here

`ToDo` is Frappe's own doctype — a reminder or an assignment. This app uses it for the personal,
non-clinical half of My Work: "call the lab", "book follow-up for Nina". It is **not** the doctype for
clinical work a nurse must be verified to have done; that is `Nursing Task`.

Three different doctypes surface as rows on My Work (`/inbox`), which is why the screen has three
sub-tabs:

| Sub-tab | Doctype | What it is |
|---|---|---|
| **To-Do** | `ToDo` | A personal reminder or an assignment between staff |
| **Nursing** | `Nursing Task` | Clinical work with a real state machine and completion proof |
| **Encounters** | `Patient Encounter` | A consultation left open — finished by signing the note |

⚠️ **Frappe also ships a separate `Task` doctype** (project management). This app never touches it.
Until 2026-09-22 the create drawer called a ToDo a "Task", which is why the UI now says **To-Do**
everywhere: one record should not have two names one scroll apart.

---

## 2. The write path, end to end

```
CreateTodoForm                    todo-tab.tsx
  description (HTML)              QuillDescription — Quill, toolbar on
  priority                        High / Medium / Low
  date                            optional due date
  assignTo                        allocated_to, "" means unassigned
  reference                       TodoReferencePicker
  files                           uploaded AFTER the ToDo exists
        │
        ▼  onSubmit
handleCreate                      inbox-tab.tsx
        │
        ▼  useCreateTodo().mutate
POST /api/my-work/todos           app/api/my-work/todos/route.ts
        │                         forwards the body WHOLESALE — the route
        │                         adds nothing and filters nothing
        ▼
remedisys_healthcare_ai.api.v1.tasks.api.create_todo
        │                         validates, fills server-owned fields
        ▼
frappe.get_doc({"doctype": "ToDo", ...}).insert()
```

Two consequences of that wholesale forward worth knowing:

- **Adding a field the backend already accepts needs no route change.** When the Reference pair was
  wired up on 2026-09-22, only `useCreateTodo`'s TypeScript payload type changed.
- **The route is not a validation layer.** Everything enforced lives in `create_todo`
  (`api/v1/tasks/api.py`) — `description` required, `priority` in a closed set, a `require_permission`
  check on `ToDo`/`create`.

Attachments are uploaded **after** insert, against the returned name, because a file needs a document
to attach to.

---

## 3. Field by field

Frappe's Desk form for ToDo shows nine editable fields. Only four are ours to ask the user for.

| Desk field | Who sets it | Why |
|---|---|---|
| `description` | **User** | Required. Rich text — see §4 |
| `priority` | **User** | High / Medium / Low, validated against a closed set server-side |
| `date` | **User** | The due date. Optional |
| `allocated_to` | **User** | Single assignee. Omitted → self-assign; explicit `""` → unassigned, a claimable queue item |
| `reference_type` / `reference_name` | **User** | Scoped picker — see §5 |
| `status` | **Server**, always `"Open"` | A to-do cannot be created already Closed |
| `assigned_by` | **Server**, `frappe.session.user` | Permission-bearing — see §6 |
| `color` | **Nobody** | No consumer anywhere — see §7 |
| `role` | **Nobody** | Does not mean what it looks like — see §8 |

---

## 4. Description is rich text, and always was

`ToDo.description` is a Frappe **Text Editor** field, so it stores HTML. This app already read it that
way at both ends long before it could write it:

- `todo-detail-client.tsx` renders it with `dangerouslySetInnerHTML`, through a `cleanQuillHtml`
  sanitiser.
- `titleFromDescription` runs `stripHtml` before taking the first five words as a row title.

Only the create form was a plain `<textarea>`, so a to-do could be *read* formatted and never
*written* that way. It now uses `QuillDescription` with the toolbar enabled.

**The toolbar is deliberately smaller than Desk's:**

| Kept | Dropped | Why dropped |
|---|---|---|
| bold, italic, underline, strike | headings | `titleFromDescription` takes the first five words regardless — a heading changes nothing and adds a font size the sheet has no room for |
| ordered / bullet / check list | tables, images | A to-do is a sentence and some steps, not a document |
| link | colours, alignment, indent, RTL, code blocks | Each is a way to make a task row render badly on another screen |
| clear formatting | | The escape hatch from pasted formatting |

⚠️ **Quill never yields an empty string.** An emptied editor is `"<p><br></p>"`. The submit guard
therefore measures `stripHtml(text)`, not the raw value — otherwise **Add To-Do** stays enabled on an
empty box and posts a to-do whose description is a line break.

---

## 5. Reference — scoped on purpose

`reference_type` + `reference_name` attach a to-do to another document. `create_todo` has always
accepted both; before 2026-09-22 no frontend sent them, so the only linked to-dos were the ones
backend flows created (the refund task links itself to its appointment).

**Desk offers `reference_type` as a Link to `DocType`** — every doctype on the site, roughly two
hundred of them, including `Email Queue`, `Patch Log` and `Version`. That is the right control for an
administrator and the wrong one for front desk staff attaching a reminder to a patient. The app's
picker offers three:

```
Patient  ·  Patient Appointment  ·  Patient Encounter
```

**Every path asks for the patient first.** All three targets are patient-scoped, and an appointment is
not findable by its own id — nobody recalls `HLC-APP-2026-00297`. So the picker asks *who*, then
narrows to that person's records, instead of offering a flat search across every appointment in the
clinic.

Implementation note: the records list is queried through `appointmentsApi` / `encountersApi` inside a
`useQuery` with an `enabled` gate, because neither `useAppointments` nor `useEncounters` exposes one
and calling them unguarded would fetch the whole clinic to fill a dropdown that is not open yet. The
two endpoints also return different envelopes — appointments a bare array, encounters
`{ data, pagination }`.

---

## 6. `assigned_by` is set by the server, and it matters

Set to `frappe.session.user` in `create_todo`. This was missing until 2026-09-22, and the omission was
not cosmetic:

- **It carries read permission.** `ToDo.has_permission` and `get_permission_query_conditions`
  (`frappe/desk/doctype/todo/todo.py`) both grant read on
  `allocated_to == user OR assigned_by == user`. With it blank, the only thing keeping a creator's own
  assignment visible to them is holding a role with blanket ToDo read. Frappe's own `test_todo.py`
  covers precisely the "no role, but is `assigned_by`" case.
- **It names the audit trail.** `ToDo.validate` composes the assignment comment from it, so the
  comment was being written without a name on it.

Setting it matches Frappe's own assignment path (`frappe/desk/form/assign_to.py`) rather than
inventing a convention. It is set unconditionally, including self-assignment — `validate()` has a
distinct message for `assigned_by == allocated_to`.

It is **not** a user input: the assigner is whoever is creating the record. Offering a field for it
would only allow someone to misattribute their own assignment.

---

## 7. Why `color` is left out

Frappe's form has a `Color` picker. Nothing renders it.

Verified across Frappe core:

- `todo_list.js` — the list view config. Does not reference `color`.
- `todo_calendar.js` — the calendar config. Its `field_map` has no colour key.
- `todo.py` — mentions `color` only as a generated type annotation.

Our own stack does persist it — `create_todo` accepts the argument and `_todo_fmt` returns it — and
our frontend ignores it on the way back. So a picker would write a value that no screen anywhere
displays, which is a dead affordance (frontend rule FE-5).

**If it is ever wanted, it has to come with a renderer** — e.g. a coloured left edge on the My Work
row. That was offered on 2026-09-22 and declined; the field stays out until something displays it.

---

## 8. Why `role` is left unset — the long answer

This is the field most likely to be "fixed" by someone reading the Desk form and assuming it is
missing. It is not missing. It means something other than it appears to.

**The intuition:** *"I am logged in as Doctor carloz, a practitioner, so `role` should say
`EB_Practitioner`."* Reasonable, and wrong.

### 8.1 Nothing writes it during assignment

`frappe/desk/form/assign_to.py` is Frappe's own assignment path — the code that runs when anyone
assigns a document to a user anywhere in the product. It constructs a `ToDo` with nine fields:
`allocated_to`, `reference_type`, `reference_name`, `description`, `priority`, `status`, `date`,
`assigned_by`, `assignment_rule`.

`role` is not among them. Frappe assigns thousands of ToDos through that function and never sets it.

### 8.2 Nothing reads it

Both permission functions in `frappe/desk/doctype/todo/todo.py` — `has_permission` and
`get_permission_query_conditions` — decide access from `frappe.get_roles(user)`, **the user's own
roles**, and from `allocated_to` / `assigned_by`. Neither looks at `doc.role`. No list view, calendar
or notification reads it either.

### 8.3 What actually populates it

The **Session Default** mechanism. `frappe/core/doctype/session_default_settings/` lets a user pin a
default value for a Link field, which is then auto-filled into new documents for the rest of their
session. Frappe's own test states it plainly: it registers `Role` as a session default, calls
`set_session_default_values({"role": "Website Manager"})`, inserts a bare `ToDo`, and asserts the new
document comes out with `role == "Website Manager"`.

So `ToDo.role` is a **per-user default slot**, empty unless someone has configured Session Default
Settings. It is not a stamp of the creator's role, and writing one there would be asserting something
Frappe never asserts.

### 8.4 It is ambiguous by construction

`role` is a single `Link`. A practitioner holds several roles — `EB_Practitioner` plus whatever else
the account carries. There is no "the" role to write, so any value we chose would be the app picking a
favourite and presenting the guess as a fact.

### 8.5 The decision

**Leave it unset.** Three independent reasons, any one of which is sufficient:

1. Frappe's own assignment path does not set it, so setting it makes our ToDos structurally unlike
   every other ToDo on the site.
2. Nothing reads it, so the value would be inert — the same objection that keeps `color` out (§7).
3. The value is not well-defined for a user with more than one role.

**If it is ever wanted anyway** — say, for reporting on which discipline raised a task — that is a
legitimate ask, but it should be a recorded decision rather than a bug fix, and it needs a rule for
choosing *which* role. Whoever implements it should read this section first and supersede it, not
quietly start writing the field.

---

## 9. Known limitation

**Column filters on My Work filter only the current page.** Pagination happens in `InboxTab`, and the
STATUS / PRIORITY / USER / date filters live in `InboxTable`, which receives only the current slice.
Filtering Nursing by "Requested" therefore searches 20 of 35 rows. This predates the 2026-09-22 work
and is recorded, unfixed, in [`WORK_LOG.md`](../../WORK_LOG.md); fixing it means lifting filter state
across the `InboxTab` ↔ `InboxTable` boundary.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Ashutosh (AI-assisted) | Initial version — create flow, field-by-field decisions, and the `role` / `color` rationale |
