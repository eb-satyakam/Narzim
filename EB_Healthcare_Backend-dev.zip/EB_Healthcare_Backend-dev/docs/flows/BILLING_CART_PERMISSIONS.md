# The Billing Cart Without Borrowing Administrator

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

Design note. The decision and the alternatives are
[ADR-122](../adr/adr-122-billing-cart-runs-as-the-clerk.md).

## 1. In one paragraph

To list what a patient still owes, the cart scans the clinical records that can be billed, and
some of them front desk may not read. The code used to switch the whole request to Administrator
for all ten scans, so the records showed Administrator, not the clerk, as the reader. The switch
also silently emptied the request's own parameters. Now each scan runs as the clerk.
Administrator is borrowed only for a scan of a record type the clerk cannot read, only when the
patient has such a record, and everything is put back afterwards.

## 2. Which scan needs what (verified 2026-10-01, local site)

| Scan (Healthcare core) | Reads, with permission check | EB_Front Desk can read? | Rows on local site |
|---|---|---|---|
| `get_appointments_to_invoice` | Patient Appointment | yes | many |
| `get_encounters_to_invoice` | Patient Encounter | yes | many |
| `get_lab_tests_to_invoice` | Lab Test | yes | many |
| `get_clinical_procedures_to_invoice` | Clinical Procedure | yes | — |
| `get_inpatient_services_to_invoice` | none (direct DB) | n/a | — |
| `get_emergency_services_to_invoice` | none (direct DB) | n/a | — |
| `get_therapy_plans_to_invoice` | Therapy Plan | **no** | 0 |
| `get_therapy_sessions_to_invoice` | Therapy Session | **no** | 0 |
| `get_observations_to_invoice` | Observation | **no** | 0 |
| `_list_billable_service_requests` (ours) | Service Request | yes (every EB role) | — |

The row-scoping hooks on Appointment, Encounter, Lab Test and Patient serve the patient portal.
For front desk they return no condition, so the clerk sees the same rows Administrator did.

## 3. Example

Clerk Priya opens Mr. Singh's cart.

| | Before | After |
|---|---|---|
| Who reads his appointments and lab tests | Administrator | Priya |
| His therapy plans (none) | read as Administrator | not read: nothing there |
| If he had a therapy plan | read as Administrator, with the other nine scans | that one scan as Administrator, logged `user=priya…`, everything restored |
| `frappe.form_dict` after the cart | empty | unchanged |

## 4. Tests

`tests/billing/test_cart_permissions.py` (as a real EB_Front Desk user):

1. The cart for a patient with an unbilled appointment lists it, and `frappe.set_user` is never
   called with Administrator.
2. `_read_as_administrator` runs its scan as Administrator, then leaves `form_dict`, the user and
   the session as they were, also when the scan raises.
3. The queue probe reports the unbilled patient without switching user.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | First version |
