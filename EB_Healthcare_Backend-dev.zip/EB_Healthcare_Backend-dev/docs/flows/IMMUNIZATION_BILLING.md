# Immunization Billing — Design Document

**Doc status:** living · **Created:** 2026-06-20 by Anant Sharma · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** design approved · pending implementation  
**Phase:** 3 (billing) — depends on immunization Phase 2 being complete  
**Related docs:** `docs/flows/IMMUNIZATION_PROCESS.md`, `docs/api/API_SPEC.md`, `docs/architecture/BACKEND_ARCHITECTURE.md`

---

## 1. The two charges

Every administered vaccine can produce up to two distinct charges. They are
billed by different roles via different documents and must never be conflated.

| Charge | What it is | Who bills | Document | Stock movement |
|---|---|---|---|---|
| **Injection / administration fee** | Service charge for the act of administering the vaccine | Front Desk | Sales Invoice (service items) | None |
| **Vaccine product cost** | Physical vaccine vial dispensed from clinic inventory | Pharmacy | Sales Invoice (`update_stock=1`) | Yes — stock ledger entry auto-created on SI submit |

The `Immunization` record is a **clinical log only**. It owns neither charge.
Billing documents reference the immunization via `Sales Invoice Item.reference_dt /
reference_dn` — the link goes outward, never inward.

---

## 2. When each charge applies

The `supply` field on `Immunization` drives billing eligibility:

| `supply` value | Injection fee | Vaccine product |
|---|---|---|
| `In-house stock` | ✅ bill | ✅ bill — clinic supplied the vial |
| `Patient-supplied` | ✅ bill — clinic administered it | ❌ not billed — patient owns the vial |
| `External-history` | ❌ not billed | ❌ not billed — happened elsewhere |

---

## 3. Schema additions

### 3.1 `Immunization Template` — one new field

| Field | Type | Purpose |
|---|---|---|
| `administration_fee_item` | Link → Item | Service item billed as the injection fee. `is_stock_item=0`. If not set the fee line is silently skipped — not an error. |

One fee item per template. Per-dose fee differentiation is out of scope for v1
(e.g. BCG dose 1 and dose 2 charge the same rate). If a clinic charges different
fees per dose, model them as separate templates.

### 3.2 `Immunization` doctype — no changes

No `billing_status`, no `sales_invoice` field. Traceability is achieved by querying
`Sales Invoice Item` on `reference_dn = immunization_name`. This keeps the
clinical record clean and avoids dual-write consistency problems.

### 3.3 Item master requirements (one-time clinic setup)

**For injection fees:**
- At least one Item with `item_group = "Services"`, `is_stock_item = 0`
- Example: "Vaccine Administration" — one item covers all vaccines; or one per
  vaccine type if fees differ
- An active `Item Price` (selling) for this item in the clinic's default price list
- Set `administration_fee_item` on each `Immunization Template`

**For pharmacy dispensing:**
- All vaccine Items must have `is_stock_item = 1`
- Valuation method: FIFO (standard for perishables)
- A clinic warehouse for cold-chain vaccine storage
- Batch tracking recommended (maps `Immunization.lot_number` → `Batch.name`)
- An active `Item Price` (selling) for each vaccine Item

---

## 4. Flow A — Visit with appointment (consultation + vaccination)

The most common case. One visit, one invoice, multiple line items.

```
[Front Desk — invoice screen for appointment X]

  1. Calls:  get_appointment_immunization_lines(appointment=X)
             ↓
             Returns: [{immunization, vaccine_name, fee_item, fee_item_name, rate}]
             (only supply != External-history; only templates with fee item set)

  2. User reviews the pre-populated fee lines in a confirm step.

  3. Calls:  create_visit_invoice(
               appointment=X,
               immunization_lines=[{immunization, fee_item, rate}, ...],
               mode_of_payment=...,   # optional — Pay Now
               paid_amount=...,       # optional — Pay Now
               discount_amount=0,
               discount_percentage=0,
             )
             ↓
             Backend builds ONE Sales Invoice:
               Line 1: consultation fee item  (from Healthcare Settings.op_consulting_charge_item)
                        rate: Healthcare Practitioner.op_consulting_charge
               Line N: injection fee item(s)  (one line per immunization in immunization_lines)
                        SI Item.reference_dt = "Immunization"
                        SI Item.reference_dn = imm.name
             Saves + submits SI.
             Sets appointment.invoiced = 1
             Sets appointment.ref_sales_invoice = si.name
             Optionally settles immediately (reuses billing.settle_invoice).

  4. Returns: {sales_invoice, grand_total, outstanding, payment_entry, lines}
```

**Insurance path:** when `appointment.insurance_coverage` is set, the existing
`_create_insured_invoice` path is used. The injection fee lines are appended after
`si.set_healthcare_services(checked)` and are marked patient-payable
(`coverage_percentage = 0`). Insurance does not cover administration fees.

**Why not use core `create_sales_invoice`?**  
Core's `create_sales_invoice(appointment_doc)` builds the SI internally and
submits it — there is no hook to inject extra lines. We already bypass it for the
insurance case (`_create_insured_invoice` in `services/billing.py`).
`create_visit_invoice` follows the same pattern and must replicate the same
post-submit steps: `appointment.invoiced = 1`, `appointment.ref_sales_invoice`.

---

## 5. Flow B — Vaccination-only visit (no appointment or no consultation fee)

Walk-in flu shot, travel vaccine, occupational vaccine. No consultation fee applies.

```
[Front Desk — vaccination-only invoice screen]

  1. Calls:  create_vaccination_invoice(
               immunization_names=[imm1, imm2, ...],
               patient=...,
               company=...,
               mode_of_payment=...,   # optional
               paid_amount=...,       # optional
             )
             ↓
             Backend builds Sales Invoice:
               One line per immunization → fee_item at rate from Item Price
               SI Item.reference_dt = "Immunization"
               SI Item.reference_dn = imm.name
             Saves + submits.
             Optionally settles immediately.

  2. Returns: {sales_invoice, grand_total, outstanding, payment_entry, lines}
```

Immunizations with `supply = "External-history"` are silently excluded. If none
of the supplied names produce a billable line, the endpoint throws `ValidationError`
before creating any document.

---

## 6. Flow C — Pharmacy dispensing (vaccine product cost)

Separate flow, separate document, separate role. Only for `supply = "In-house stock"`.

```
[Pharmacy screen]

  1. Calls:  get_pharmacy_dispensing_preview(name=imm_name)
             ↓
             Returns: {
               billable: true/false,
               reason: "..." (if not billable),
               item_code, item_name, rate, lot_number, already_dispensed
             }
             "already_dispensed" = true if an existing submitted SI Item
             references this immunization with a stock item.

  2. Pharmacy confirms the warehouse.

  3. Calls:  create_pharmacy_dispensing_invoice(
               name=imm_name,
               warehouse=...,         # required — pharmacy must name the source
               mode_of_payment=...,   # optional
               paid_amount=...,       # optional
             )
             ↓
             Guards:
               - supply == "In-house stock" (else raises immediately)
               - no existing submitted pharmacy SI for this immunization
             Backend builds Sales Invoice:
               update_stock = 1
               set_warehouse = warehouse
               Line 1: vaccine item (item_code = imm.vaccine)
                        qty = 1
                        rate = Item Price master
                        batch_no = imm.lot_number  (if Item has batch tracking)
                        warehouse = warehouse param
                        SI Item.reference_dt = "Immunization"
                        SI Item.reference_dn = imm.name
             Saves + submits.
             On submit: Frappe auto-creates Stock Ledger Entry → stock decrements.
             Optionally settles immediately.

  4. Returns: {sales_invoice, grand_total, outstanding, stock_entry_created, payment_entry}
```

**`warehouse` is always required.** There is no default. Pharmacy staff must
consciously confirm the source location. This prevents silent stock errors in
multi-warehouse clinics.

---

## 7. Traceability — finding invoices for an immunization

Since no billing field lives on the `Immunization` doctype, lookup goes the other way:

```python
# All SI items referencing a specific immunization
frappe.get_all(
    "Sales Invoice Item",
    filters={"reference_dt": "Immunization", "reference_dn": immunization_name},
    fields=["parent", "item_code", "item_name", "amount"],
)

# Filter by docstatus=1 for submitted invoices only
```

This query also answers:
- "Has this immunization been billed?" (any rows with docstatus=1)
- "Which invoice covers this shot?" (the `parent` field)
- "Was this a service or stock line?" (check `is_stock_item` on the item)

---

## 8. Endpoint summary

All endpoints follow the standard decorator chain:
`@frappe.whitelist()` → `@handle_api_errors` → `require_permission` → logic.

### `api/v1/billing/api.py`

| Endpoint | Method | Permission | Notes |
|---|---|---|---|
| `get_appointment_immunization_lines(appointment)` | GET | `Immunization` read | Read-only preview. Returns fee lines for the FE confirm step. |
| `create_visit_invoice(appointment, immunization_lines, ...)` | POST | `Sales Invoice` create | Flow A. Replaces `create_appointment_invoice` when vaccinations present. |
| `create_vaccination_invoice(immunization_names, patient, company, ...)` | POST | `Sales Invoice` create | Flow B. Vaccination-only visit. |

### `api/v1/immunizations/api.py`

| Endpoint | Method | Permission | Notes |
|---|---|---|---|
| `get_pharmacy_dispensing_preview(name)` | GET | `Immunization` read | Read-only. Returns rate, lot, already-dispensed guard. |
| `create_pharmacy_dispensing_invoice(name, warehouse, ...)` | POST | `Sales Invoice` create | Flow C. Stock-touching. `warehouse` required. |

---

## 9. What `create_appointment_invoice` does now

The existing endpoint is **unchanged**. It remains the correct path for:
- Appointments with no vaccinations
- Any case where the front desk does not select vaccination fee lines

The front desk screen should route to `create_visit_invoice` when
`get_appointment_immunization_lines` returns at least one line and the user
confirms inclusion. Otherwise it falls back to the existing `create_appointment_invoice`.

---

## 10. What is deferred

| Item | Reason |
|---|---|
| Batch / expiry validation on dispensing | Needs `Batch` master fully configured; deferred to pharmacy Phase 3 |
| Insurance coverage on injection fees | Extension of insurance module; fee is patient-payable for now |
| Auto-invoice on immunization save | Nurse records the shot; billing is an explicit front-desk/pharmacy action — never automatic |
| Stock replenishment / purchase orders | Separate procurement scope |
| Multi-dose single-invoice (e.g. 3 vaccines, one invoice) | Already supported via `immunization_names=[...]` in `create_vaccination_invoice` |
| `coverage_pct` in immunization report | Needs per-patient schedule computation across the whole panel; documented stub in `report.py` |

---

## 11. Build order

Steps are ordered by risk — non-stock, read-only steps first.

```
Step 1   Schema: add administration_fee_item to Immunization Template JSON
         bench migrate on dev to apply
         No patch needed — new field, no data migration

Step 2   get_appointment_immunization_lines        (read-only, billing/api.py)
Step 3   get_pharmacy_dispensing_preview           (read-only, immunizations/api.py)

Step 4   create_vaccination_invoice               (no stock; service items only)
         Requires: administration_fee_item set on at least one template
                   Item Price configured for the fee item

Step 5   create_visit_invoice                     (replaces core for vaccinated visits)
         Requires: Step 4 logic reused; consultation item configured in Healthcare Settings

Step 6   create_pharmacy_dispensing_invoice       (stock-touching)
         Requires: vaccine Items as stock items; warehouse configured; Item Price set
         Test with update_stock=1 against a real site — do not test against a
         site without stock ledger configured (SI submit will fail)
```

Steps 2–4 can be built and merged independently of Item master configuration.
Steps 5–6 require the site to be configured before end-to-end testing is possible.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-20 | Sarvesh | Initial version (header backfilled from git history) |
