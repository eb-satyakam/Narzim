# The Refund Dialog's Amount Comes From the Server

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.1

Design note. The decision and its alternatives are
[ADR-121](../adr/adr-121-the-refund-figure-comes-from-the-server.md).

## 1. In one paragraph

When a clerk refunded some lines of a bill, the billing page's Refund dialog worked out the amount
in the browser, then the server worked it out again when issuing the Credit Note. Two copies of
the same tax, discount and rounding rules can disagree: "Refund 1,160.00" on screen, 1,161.00
on the receipt. Now the dialog asks the server, which builds the very Credit Note it would issue
and reads its totals without saving it.

## 2. How it works

| Step | Where |
|---|---|
| Clerk ticks lines or changes a quantity | `refund-dialog.tsx` (`refundItems`) |
| Dialog asks "what would this refund be?" | `useRefundPreview` → `POST /api/billing/refund/preview` → `preview_credit_note` |
| Server builds the return in memory with the refund's own code | `services/billing.py::_build_credit_note`, then `calculate_taxes_and_totals` |
| Dialog shows the server's total, tax, discount, rounding, cash back and waiver | `refund-dialog.tsx` (`sp`) |
| Confirm is held while the answer is loading | `refund-dialog.tsx` |
| Refund issued with the same lines | `create_credit_note` → `_build_credit_note` |

If the preview cannot be fetched (an older backend, a network error), the dialog falls back to
its own estimate and Confirm stays available. A refund is never blocked by the preview.

## 3. Example

A bill with three lines (333.33, 333.33, 333.34) and 100 off the bill. Refund one line:

- the line's share of the discount is 33.33;
- the result is rounded to the peso.

Before, the browser repeated that arithmetic. Now the dialog shows `credit_total` from the
server, and the test requires the refund then pays exactly that
(`tests/billing/test_credit_note_preview.py`).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-10-01 | Divyanshu (AI-assisted) | The decision is ADR-121 (drafted as 120; `dev` took 120 for Langfuse) |
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | First version |
