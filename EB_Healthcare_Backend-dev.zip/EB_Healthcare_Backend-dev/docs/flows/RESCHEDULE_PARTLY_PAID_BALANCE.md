# Reschedule and Cancel When the Appointment's Invoice Still Has a Balance

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

Design note for the product owner and the clinic's accountant. The decision it proposes is
[ADR-117](../adr/adr-117-replace-the-line-when-the-invoice-has-a-balance.md) (Accepted). It extends
[ADR-114](../adr/adr-114-appointment-line-owns-its-money.md) and its design note
[RESCHEDULE_CANCEL_REFUND_LINES.md](RESCHEDULE_CANCEL_REFUND_LINES.md), which handled only invoices
that were already fully paid. What was built is in §9.

## 1. In one paragraph

When an appointment is rescheduled to a dearer fee while its invoice is not fully paid, the system
raises an extra invoice for "new fee minus what was paid" and leaves the old invoice's unpaid
balance open as well, so the patient is billed that balance twice. When a partly paid appointment
is cancelled, the refund is refused outright and the money already paid cannot be returned. Both
come from one gap: ADR-114's "replace the appointment's line" only runs when every invoice is fully
paid. This note proposes running it whenever the line can be identified, and using the Credit Note
first to cancel what is still unpaid on the old invoice.

## 2. What happens today (verified in code and data, 2026-10-01)

### 2.1 Dearer reschedule of an invoiced, partly paid appointment: billed twice

Observed on the dev site, appointment `HLC-APP-2026-00820`, all on 2026-10-01:

| Step | Document | Amount | State now |
|---|---|---|---|
| Booked with the first practitioner, invoiced | `ACC-SINV-2026-01931` | 1,000.00 (no tax) | Partly Paid, **500 outstanding** |
| Cash collected | `ACC-PAY-2026-01358` | 500.00 | Submitted |
| Rescheduled to a practitioner charging 2,000 + 16 % tax | `ACC-SINV-2026-01932` "Reschedule additional payment" | 1,820.00 | Unpaid, 1,820 outstanding |
| History row | Appointment Reschedule History | old fee 1,000 · old paid 500 · new fee 2,000 · delta 1,820 | `Pending` |

The visit now costs 2,320 and 500 has been paid, so the patient owes **1,820**. The books say
1,820 + 500 = **2,320**: the old invoice's unpaid 500 is still owed for a visit that no longer
exists at that price.

Why, in code:

- The delta is the new tax-inclusive fee minus **cash paid**:
  `services/billing.py:2849` `delta = round(new_fee_incl_tax - flt(old_paid_amount), 2)`, with
  `old_paid_amount` from `total_paid_for_appointment` (`api/v1/appointments/api.py:3039`, `:3352`).
  Paid, not billed, is the right basis for what is owed now. The bug is what happens next.
- The "Additional Payment" branch (`services/billing.py:2883-2923`) raises a standalone delta
  invoice and never touches the old invoice. The docstring says so: "Never touches old_invoice's
  own rows/payments when the delta is positive" (`:2831`).
- An unpaid invoiced appointment is the same case with 0 paid. The classifier deliberately
  never defers it (`:1849-1855`), so a 500 unpaid invoice moved to 750 bills 750 plus the open 500.

Two existing tests pin the double bill as correct:
`tests/appointments/test_reschedule_payment.py:377` `test_partially_paid_charges_only_the_remainder`
(500 billed, 300 paid, new 750: asserts a 450 delta and never looks at the 200 left on the old
invoice) and `:388` `test_unpaid_requires_full_new_fee` (asserts 750 while 500 stays open).

### 2.2 Cheaper reschedule of a partly paid appointment: falls back to the legacy refund

`_replace_appointment_lines` returns `None` when any source still has a balance
(`services/billing.py:2548`), so the call falls back to `_allocate_reschedule_refund`
(`:2944-2945`). That path returns the first line with quantity left at a reduced rate, the
behaviour ADR-114 replaced because it uses up the line and can take another appointment's or a
vaccine's line.

### 2.3 Cancel of a partly paid appointment: the paid money is stranded

- `_settle_own_invoice_on_cancel` leaves any invoice with a payment and returns "refund owed"
  (`api/v1/appointments/api.py:2627-2632`).
- `appointment_refund_plan` marks it `blocked_reason = "partly_paid"` and leaves it out of the totals
  (`services/billing.py:2757-2762`).
- `refund_appointment` then has nothing to do and raises "Nothing left to refund" (`:2789-2791`).

The patient's 500 can only be returned by hand in Desk.

## 3. The rule

The appointment's line is where its money lives (ADR-114). Changing or cancelling the appointment
returns that line **in full**. The Credit Note then pays, in this order:

1. what is still **unpaid on the same invoice** for this appointment's line (no money moves; the
   charge is withdrawn);
2. the **replacement invoice** for the new fee, if there is one;
3. what is left goes back as **cash**, through the tender it came in by (`_refund_cash`).

What is owed afterwards is always `new fee incl. tax − cash actually paid`, the figure the preview
already shows today (`_reschedule_quote`, `api/v1/appointments/api.py:3073`). The preview does not
change; the settlement starts agreeing with it.

## 4. Proposed behaviour

### 4.1 Dearer reschedule, old invoice has a balance (fixes §2.1)

Worked on `HLC-APP-2026-00820`:

| # | Document | Effect | Balance after |
|---|---|---|---|
| 1 | Credit Note against `01931`, its appointment line in full | −1,000 | CN −1,000 |
| 2 | Reconcile 500 of the CN against `01931` itself | old unpaid charge withdrawn | `01931` 0 · CN −500 |
| 3 | Replacement invoice for 2,000 + 16 % | +2,320 | replacement 2,320 |
| 4 | Reconcile the CN's remaining 500 against the replacement | the 500 cash moves to the new fee | replacement **1,820** · CN 0 |
| 5 | Pay now: collect 1,820 (`settle_invoice`). Pay later: leave it | | 0 or 1,820 |

One invoice is open, for 1,820, which is what the patient owes. The history row records
`replacement_invoice`, not `additional_invoice`.

A fully paid invoice keeps today's path (a standalone delta invoice for the difference), so the
change is limited to invoices with a balance. §8 Q1 asks whether to unify the two later.

### 4.2 Cheaper reschedule, old invoice has a balance (fixes §2.2)

Example: 1,000 billed, 500 paid, rescheduled to 300 (no tax).

| # | Effect | Balance after |
|---|---|---|
| 1 | Credit Note, line in full: −1,000 | CN −1,000 |
| 2 | 500 against the old invoice's own unpaid balance | old 0 · CN −500 |
| 3 | Replacement for 300, paid from the CN | replacement 0 · CN −200 |
| 4 | 200 back in cash | CN 0 |

The patient paid 500 for a 300 visit and gets 200 back. Today's preview says Refund 200 for this
case, so preview and settlement agree.

### 4.3 Cancel, invoice has a balance (fixes §2.3)

Example: 1,000 billed, 500 paid, cancelled.

| # | Effect | Balance after |
|---|---|---|
| 1 | Credit Note, line in full: −1,000 | CN −1,000 |
| 2 | 500 against the invoice's own unpaid balance | invoice 0 · CN −500 |
| 3 | 500 back in cash | CN 0 |

`appointment_refund_plan` lists the invoice with `cash_back = 500` and an extra
`balance_withdrawn = 500`, instead of `blocked_reason = "partly_paid"`. The Refund dialog shows
both figures. The cancel step itself is unchanged: it still leaves a partly paid invoice alone and
reports "refund owed"; the front desk then refunds through the dialog as for a paid one.

### 4.4 Shared invoice with a balance (answers ADR-114 design note §8 Q5)

On a checkout invoice that also bills other lines, the payment is treated as spread
**proportionally** across lines, the basis `appointment_invoice_share` already uses
(`services/billing.py:1664`). Example from that note, M6: 1,700 billed (A 500, B 1,200), 1,000
paid. A's share is billed 500 and paid 294.12. Cancelling A returns A's line (−500): 205.88 goes
against the invoice's balance and 294.12 goes back in cash. B's line is untouched and still owes
its share. **This needs the accountant's sign-off (§8 Q2)**; until then a shared invoice with a
balance stays on today's path: flagged, not refunded.

### 4.5 Unchanged

- **Pay-later appointment that was never invoiced:** stays "Deferred". The fee changes and checkout bills it (`classify_reschedule_delta`, `:1853`).
- **Fully paid invoices:** both directions behave as today. Dearer raises a delta invoice; cheaper uses ADR-114's replacement.
- **Waiver/Government write-offs:** `outstanding` is already 0 after a write-off, so they never enter the new branch.
- **Lines that can't be identified:** if a line was used up by a legacy refund, or a legacy invoice has no `reference_dn`, the path is today's, including the legacy refund fallback and the "refund remaining" gap ADR-114 left for the accountant.
- **Preview numbers:** the preview figures, the classifier and the money-role checks (ADR-115) are unchanged.

## 5. What must not break

Each item below is checked in code and covered by a test when this is built.

| # | Function, file:line | Risk | Guard |
|---|---|---|---|
| R1 | `_credit_note_reallocated`, `services/billing.py` (feeds `_credit_note_taken`, `_already_taken_by_credit_notes`, `_appointment_funding:1985`) | It counts **every** reconcile of a Credit Note as "taken". Step 2 of §4 (CN against its own invoice) would be counted as money taken off the invoice, so the next reschedule or refund sees the patient as having paid 500 less than they did | Exclude reconcile rows whose counterpart is the Credit Note's own `return_against`. Test: after §4.1, `total_paid_for_appointment` = 500 |
| R2 | `_appointment_funding` `unsourced` loop, `:2010-2016` | An "Additional Payment" row with no `additional_invoice` and status `Paid` is added to `unsourced` on top of its replacement invoice: counted twice | Skip rows that carry `replacement_invoice`. Test: two reschedules in a row, the second sees the right paid total |
| R3 | `_real_cash_paid` / `get_actual_paid_amount`, `:1087`, `:1631` | Withdrawing the unpaid balance zeroes the old invoice's `outstanding`. Anything reading `grand_total − outstanding` as paid would see 1,000 paid | Confirm both read cash documents only (`_real_cash_paid` docstring says so; UNVERIFIED for a CN reconcile). Test: old invoice reads 500 paid, not 1,000 |
| R4 | `appointment_refund_plan`, `:2690` | After §4.1 the old invoice has no returnable line; the replacement is partly paid by credit | Old invoice drops out (no `mine` lines); replacement is planned per §4.3. Test: cancel after §4.1 refunds exactly 500 |
| R5 | `_settle_reschedule_invoices_on_cancel`, `api/v1/appointments/api.py:2580` | A replacement paid partly by credit must never be cancelled whole | Unchanged rule (`outstanding < grand_total` ⇒ refund owed); test that it survives |
| R6 | `reschedule_replacement_invoices`, `:2448` (revenue exclusion) | New replacement invoices must be excluded the same way | It reads every `replacement_invoice`; test the dearer replacement appears in it |
| R7 | Patient Appointment `ref_sales_invoice` / `invoiced` | Healthcare core's checkout must not bill the visit again | Keep `ref_sales_invoice` on the original, as ADR-114 does; test the billables cart stays empty |
| R8 | `_replace_appointment_lines` callers | The dearer path is new; the cheaper path is shared | Keep the function's fully paid behaviour byte-for-byte; add the balance handling as a separate, named step |
| R9 | Reschedule savepoint, `api/v1/appointments/api.py:3355`; `refund_appointment` savepoint, `services/billing.py:2792` | More documents per call; a failure must leave nothing | All new writes stay inside the existing savepoints; test a forced failure after the Credit Note leaves no documents |
| R10 | `create_credit_note` refuse-if-balance rule, `:1430` | The manual Billing-tab refund still refuses a partly paid invoice | Not changed in this work; only the appointment paths (§4) handle a balance |
| R11 | Frontend Refund dialog (`components/appointments/appointment-refund-dialog.tsx`) | It renders `blocked_reason = "partly_paid"` today | Shows `balance_withdrawn` when present; the blocked text stays for shared invoices (§4.4) |
| R12 | Rounding (`_SETTLEMENT_TOLERANCE = 0.05`, `:1789`) | A balance within 0.05 is treated as paid by the plan but refused by `create_credit_note` | Out of scope here, tracked separately; the tests use whole amounts plus one 1,820.01 case from §2.1 |
| R13 | Invoice list and report totals, `api/v1/billing/api.py` (`list_all_invoices`), `api/v1/billing/report.py` (`_billed_and_outstanding`) | Both leave every replacement invoice out of billed **and** outstanding (ADR-114). A dearer replacement still owing 1,820 would vanish from both totals | A replacement counts as its total less the credit moved onto it, plus its whole balance. A cheaper one is paid wholly by credit, so it still adds 0: the existing figures are unchanged. Found while building |
| R14 | Appointment row status, `api/v1/appointments/api.py::_billing_for` | "Refunded" was set when ANY invoice carried a Credit Note. After a replacement the old invoice always does, so a fully paid visit read "Refunded" (true of ADR-114's cheaper reschedules already) | The newest invoice decides. Every existing "Refunded" assertion is a full refund and still passes. Found while building |
| R15 | Invoice preview write-off, `api/v1/billing/api.py::_serialize_invoice` | Write-off is total − outstanding − cash, so the withdrawn balance read "Write-off −500" on the old invoice and its Credit Note (seen live on `ACC-SINV-2026-01933`) | New `balance_withdrawn` field (`services/billing.py::own_balance_withdrawn_bulk`), taken out of write-off; the frontend shows it as "Withdrawn by credit note". Found on the dev site after the change |

Existing tests whose assertions change on purpose: `test_partially_paid_charges_only_the_remainder`
and `test_unpaid_requires_full_new_fee` (§2.1). Their new assertions are on what the patient owes
across **all** the appointment's invoices, not on one invoice's amount. All other 74 tests in
`test_reschedule_payment.py` and the suites in `tests/billing/` must pass unchanged.

## 6. Test plan

Each test fails on `dev` today and passes after the fix.

1. 1,000 billed, 500 paid, dearer to 2,000 + 16 %: one open invoice; patient owes 1,820; old invoice 0 outstanding.
2. Same, then pay now: 0 owed; history `Paid`; one Payment Entry of 1,820.
3. 500 billed, 0 paid, dearer to 750: owes 750, not 1,250.
4. 1,000 billed, 500 paid, cheaper to 300: 200 back in cash; no legacy refund used.
5. 1,000 billed, 500 paid, cancelled: refund plan shows `cash_back 500`, `balance_withdrawn 500`; refunding returns 500; every invoice 0.
6. Test 1 then cancel: refund is 500, not 2,320 and not 0.
7. Two dearer reschedules in a row on a partly paid invoice: the second sees 500 paid (R1, R2).
8. Shared invoice with a balance: unchanged, still flagged (§4.4 until Q2 is answered).
9. Forced failure after the Credit Note in test 1: no Credit Note, replacement or reconcile left (R9).

## 7. What would change (estimate)

- **`services/billing.py`:**
  - a balance-aware step inside the replacement flow, reused by reschedule (both directions) and by `appointment_refund_plan` / `refund_appointment`;
  - the R1 and R2 fixes.
- **`api/v1/appointments/api.py`:** the dearer branch writes `replacement_invoice` to the history row when the replacement path ran.
- **Frontend:** the Refund dialog shows the withdrawn balance. A frontend change, logged in this repo's logs.
- **Tests:** the nine above, plus the two re-asserted ones.
- **Docs:** `docs/api/endpoints/appointments.md` (new plan field), CHANGELOG and WORK_LOG, and this note's §9.

No new doctype or field. The plan's `balance_withdrawn` is a response field only. No migration patch.

## 8. Questions to answer before building

| # | Question | Proposed answer |
|---|---|---|
| Q1 | Should a dearer reschedule of a **fully paid** invoice also replace the line, instead of raising a delta invoice? | Not now. It works, and changing it widens the blast radius. Revisit when the legacy delta invoices are gone |
| Q2 | Shared invoice with a balance: proportional (§4.4) or "this appointment first"? | Proportional, matching `appointment_invoice_share`. Needs the accountant's sign-off |
| Q3 | The 8 rescheduled appointments already in `KNOWN_ISSUES.md` and any double bills like `HLC-APP-2026-00820`: fix existing data? | Separate, approved one-off. This change covers new reschedules only |
| Q4 | Should the old invoice show "Credit Note Issued" or "Paid" after its balance is withdrawn? | Whatever ERPNext sets (`set_status`); not overridden |

## 9. Implementation (2026-10-01)

Branch `fix/reschedule-partly-paid-balance` (backend), `fix/refund-dialog-balance-withdrawn`
(frontend). Q1 answered "not now"; Q2 and Q3 left open (`docs/KNOWN_ISSUES.md`).

- **`services/billing.py`**
  - `_replace_appointment_lines` accepts a source with a balance when the appointment's lines are the whole invoice. It sets `update_outstanding_for_self` on that Credit Note and withdraws the balance first (`_withdraw_own_balance`). `balance_due_ok` lets a dearer replacement keep a remainder.
  - `adjust_payment_for_reschedule` takes that path for a dearer reschedule when `_has_open_balance`; otherwise it raises the delta invoice as before.
  - `appointment_refund_plan` plans such an invoice through `_balance_refund_plan` (`balance_withdrawn` per invoice and in the totals). `refund_appointment` refunds it with `_refund_with_balance`.
  - `_credit_note_journal_rows` leaves out a Credit Note applied to its own invoice (R1, R3). `_appointment_funding` skips rows with a replacement (R2).
  - `own_balance_withdrawn_bulk` and `credit_applied_bulk` are new.
- **`api/v1/appointments/api.py`:** `_billing_for` status (R14).
- **`api/v1/billing/api.py`:** totals (R13); `balance_withdrawn` and the write-off fix (R15).
- **`api/v1/billing/report.py`:** totals (R13).
- **Frontend:**
  - `appointment-refund-dialog.tsx` and `types/appointments.ts`: "Unpaid balance withdrawn".
  - `invoice-preview-sheet.tsx` and `types/billing.ts`: "Withdrawn by credit note".
  - `messages/en.json` and `es.json`.
- **Tests,** `tests/appointments/test_reschedule_payment.py`:
  - Nine new cases (§6, plus a preview check for R15). The two in §2.1 were re-asserted on the amount owed across all invoices. The two plan `totals` assertions gained `balance_withdrawn`.
  - On `dev` all eleven fail; with the change all pass.
  - The full suite and `tests/billing/` (141 tests) fail only where `dev` already fails: the nine in `docs/KNOWN_ISSUES.md`, and `test_cheaper_reschedule_on_a_part_waived_invoice_never_refunds_more_than_was_paid`. That last one also fails on `dev` (150 ≠ 450); its cause is the shared-invoice split, Q2.

Data on the dev site: the one double-billed appointment, `HLC-APP-2026-00820`, was deleted with
its invoices at the owner's request (2026-10-01). A search found no other: a rescheduled
appointment whose old invoice was not fully paid when an additional invoice was raised.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | Accepted and built: §9 implementation and test results; R13–R15 found while building |
| 0.1 | 2026-10-01 | Divyanshu (AI-assisted) | First draft: double bill on a dearer reschedule of a partly paid invoice, stranded refund on cancel, proposed rule, regression list R1–R12, test plan |
