# Frontend Handoff — Immunizations (Patient Chart 360 → Clinical → Immunizations)

**Doc status:** record · **Created:** 2026-06-18 by Anant Sharma · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

**Author:** Backend (Remedisys Healthcare AI)
**Date:** 2026-06-18
**Status:** Backend complete and verified. Active frontend already wired end-to-end. No frontend code change required to show real data — see "What you actually need to do" below.

---

## TL;DR

- The immunization backend is **fully built and serves real data** (43 records live on `remedisys.localhost`).
- The **active** frontend repo's Immunizations tab is **already wired** to that backend — no mock data remains in it. The `0 Administered / 22 Overdue / 9 Upcoming` numbers in the chart are **real computed schedule output**, not placeholders.
- If you are still seeing dummy data, you are almost certainly running the **stale duplicate clone** (`remedisys_front_end` / `Healthcare_next_app`, last commit 2026-06-06). Use the active repo instead — path below.
- One backend stub was wired today: the Patient Chart 360 aggregator `get_patient_immunizations` (previously returned `[]`). The Immunizations **tab does not use it** (it uses the dedicated endpoints), but other chart consumers might — noted in "Backend changes".

---

## Frontend paths (two clones exist — use the right one)

| Repo dir | Git remote | Branch | Last commit | Use |
|---|---|---|---|---|
| `C:\Users\divya\Desktop\EB_Healthcare_Frontend` | `EB_Healthcare_Frontend` | `dev` | 2026-06-17 | ✅ **ACTIVE — use this** |
| `C:\Users\divya\Desktop\remedisys_front_end` | `Healthcare_next_app` | `dev` | 2026-06-06 | ⚠️ stale clone — do not run |

The active repo pairs with this backend (`EB_Healthcare_Backend`) and has the complete immunization wiring (client layer, BFF routes, TanStack hooks). The stale clone lacks `src/lib/api/immunizations.ts` and may still carry the old mock tab.

### Active-repo files involved (all already present)

```
src/components/narzim/patient-chart/immunizations-tab.tsx   ← the tab UI (grid / timeline / records + add/edit/remove)
src/hooks/use-immunizations.ts                              ← TanStack Query hooks
src/lib/api/immunizations.ts                                ← typed client + response types
src/app/api/immunizations/route.ts                          ← BFF: list / get / create / update / delete
src/app/api/immunizations/schedule/route.ts                 ← BFF: schedule-card grid + counts
src/app/api/immunizations/templates/route.ts                ← BFF: vaccine-schedule masters
src/app/api/vaccines/route.ts                               ← BFF: vaccine picker
```

Data flow (BFF pattern, token stays server-side per ADR-011):

```
ImmunizationsTab → use-immunizations.ts (hooks) → lib/api/immunizations.ts (client)
   → /api/immunizations* (Next.js route handler, attaches Bearer JWT)
   → Frappe whitelisted method  remedisys_healthcare_ai.api.v1.immunizations.api.*
```

---

## Backend API contract

Base module: `remedisys_healthcare_ai.api.v1.immunizations.api`
Call as `POST /api/method/<module>.<method>`. All responses use the standard envelope:

```jsonc
// success (single)
{ "status": "success", "data": { ... } }
// success (list)
{ "status": "success", "data": [ ... ], "pagination": { "total": N, "page": 1, "page_size": 20 } }
// error
{ "status": "error", "error": { "code": "...", "message": "..." } }
```

### 0. Option B (2026-06-18, CURRENT): assigned-vaccines model

The chart now shows **only the vaccines assigned to the patient**, not the whole catalog. This is driven by a new doctype and is **already wired** — no frontend change is needed for the grid (same `schedule` shape, now with a `due_date` per dose).

**New doctype `Patient Vaccine`** — one Active row per (patient, vaccine/template) = "this vaccine is assigned to this patient." A vaccine appears on the chart only if it has an Active assignment (even before any dose is given → its overdue doses still show).

**New endpoints** (module `…immunizations.api`):
- `assign_vaccine(patient, immunization_template, assigned_by?, appointment?, encounter?, company?, notes?)` — assign a vaccine (idempotent; returns existing Active assignment if present). HTTP 201/200.
- `list_assigned_vaccines(patient, include_stopped=false)` — the patient's assigned vaccines.
- `unassign_vaccine(name)` — sets status → Stopped (kept, not deleted).
- `create_immunization(...)` — unchanged, but now **auto-assigns** the vaccine when a templated dose is recorded.

**`get_immunization_schedule(patient)` changes:**
- Loops over only the patient's **assigned** vaccines.
- Each dose now includes **`due_date`** (= DOB + dose age, computed — not stored). Overdue = `status:"overdue"` (red).
- The temporary `recorded_only` flag was removed.

**Frontend impact:** the grid/timeline keep working unchanged (same `schedule` shape). To let staff put a patient on a vaccine, add an **"Assign vaccine"** action that calls `assign_vaccine` (template picker = `list_immunization_templates`). The "+ Add immunization" (record a dose) flow is unchanged and now also auto-assigns.

Verified live: demo patient `Vacuna Demo` (18 mo) → 3 assigned vaccines only (Hep B, Pentavalente, MMR), counts given=2 / overdue=5 / due=1 / future=1, each dose carrying a `due_date`. Existing `SchedCI - 5` → only its assigned BCG.

#### Dose anchoring — vaccines not tied to date of birth (2026-06-18)

Each dose now has a **`basis`** ("Count From"): **Age** (default), **Yearly**, or **Previous Dose**. `get_immunization_schedule` computes `due_date` accordingly:

- **Age** — DOB + age. **DOB is now optional**: with no DOB, Age doses come back undated (`due_date: null`, status `future`) instead of erroring. `patient_age_months` is `null` for a patient with no DOB.
- **Yearly** — recurring every `interval_months` (default 12). The vaccine returns one `given` dose per recorded dose plus one **"Next dose"** = last given + interval (due now if never given).
- **Previous Dose** — `interval_months` after the previous dose was given.

Every dose object now also carries `basis` and `interval_months`.

**Grid caveat (frontend):** the Schedule-Card grid places doses by **age-milestone column** (`age_months`). Yearly / Previous-Dose doses have no `age_months`, so they won't appear in that grid — they do carry a `due_date` and render fine in **Records** and **Timeline**. To show them on the card grid, the grid needs to key off `due_date` (or render a non-age section). Backend is ready; this is a frontend rendering choice.

Verified live: `Vacuna Demo` → Influenza (Yearly: Annual given + Next dose overdue), Hep A (Previous Dose: 1st given, 2nd due at 1st+6mo). No-DOB patient `SinFecha Demo` → Yearly flu due now, Age doses undated — no error.

#### Add-immunization picker — `list_pending_vaccines` (2026-06-18)

`list_pending_vaccines(patient)` returns only the vaccines **assigned to the patient that still have a dose to give**, each with its next pending dose:

```jsonc
[ { "template": "Hepatitis B", "template_name": "Hepatitis B", "short_name": "Hep B",
    "category": "Core", "next_dose_label": "2nd", "next_dose_status": "overdue",
    "next_dose_basis": "Age", "next_due_date": "2025-02-18" } ]
```

The "Add immunization" dialog uses this (not the full vaccine catalog). Selecting a vaccine records against its `immunization_template` — `create_immunization` derives the vaccine Item, so no `vaccine` is sent. The filter is computed server-side (shared `_schedule_payload` helper).

Frontend pieces added (this repo): `usePendingVaccines` hook, `immunizationsApi.pending`, BFF `/api/immunizations/pending`, and the picker in `immunizations-tab.tsx`. The grid was also widened so any assigned dose's age keeps its milestone column (far-future doses like Td @ 11y/16y now show their upcoming dots instead of being clipped).

### 1. `get_immunization_schedule(patient)` — the assigned-vaccines grid + stat counters

Powers the **Schedule Card** + **Timeline** views and the four counters (Administered / Overdue / Due now / Upcoming). Requires the patient to have a date of birth.

```jsonc
{
  "patient": "MRN-2026-0000001",
  "patient_age_months": 42,
  "counts": { "given": 0, "due": 0, "overdue": 22, "future": 9, "total": 31 },
  "schedule": [
    {
      "template": "BCG", "template_name": "BCG", "short_name": "BCG",
      "category": "Core",          // Core | Annual | Adolescent | Other
      "doses": [
        {
          "dose_label": "Birth", "milestone": "Birth",
          "age_years": 0, "age_months": 0, "window_months": 1,
          "dose_amount": 0.1, "dose_uom": "ml",
          "status": "given",       // given | due | overdue | future
          "record": "HLC-IMM-2026-00001",   // null when not given
          "date_administered": "2025-12-18" // null when not given
        }
      ]
    }
  ]
}
```

Status meaning (computed server-side from DOB + templates + recorded doses):
- `given` — a matching administered record exists
- `due` — patient is at/within the catch-up window
- `overdue` — past the catch-up window
- `future` — not yet eligible (2-month early-administration grace)

Counter → UI label mapping: `given→Administered`, `overdue→Overdue`, `due→Due now`, `future→Upcoming`.

### 2. `list_immunizations(patient, search?, page?, page_size?)` — the Records view

Paginated, newest first. `data` is an array of records:

```jsonc
{
  "name": "HLC-IMM-2026-00052",
  "patient": "MRN-2026-0000001", "patient_name": "Aaravi Sharma",
  "vaccine": "VAC-TD", "vaccine_name": "Tetanus & Diphtheria",
  "immunization_template": "TD", "scheduled_dose_label": "2nd",
  "date_administered": "2026-06-16",
  "administered_by": "DR-001", "administered_by_name": "Dr. Ariel",
  "administration_site": "Left deltoid", "lot_number": "AX-29841",
  "appointment": null, "company": "Narzim", "notes": null
}
```

### 3. `create_immunization(...)` / `update_immunization(name, ...)` / `delete_immunization(name)`

Required on create: `patient`, `date_administered`, and either `vaccine` or `immunization_template`.
Writable: `patient, vaccine, immunization_template, scheduled_dose_label, date_administered, administered_by, administration_site, lot_number, appointment, company, notes`.
`administration_site` enum: `Left deltoid | Right deltoid | Left thigh | Right thigh | Oral | Nasal | Other`.

### 4. `list_vaccines(search?)` — picker

```jsonc
{ "name": "VAC-TD", "item_code": "VAC-TD", "item_name": "Tetanus & Diphtheria" }
```

### 5. `list_immunization_templates(category?, search?, include_disabled?)` — schedule masters

Returns templates with their `doses` child rows (`dose_label, milestone, age_months, age_years, window_months, dose_amount, dose_uom`). The grid does **not** require this call (the schedule endpoint already embeds doses + status); it's available for an admin/schedule editor.

---

## Backend changes made today (2026-06-18)

`remedisys_healthcare_ai/api/v1/patients/api.py` → `get_patient_immunizations(patient)` was a stale stub returning `[]` ("ERPNext Healthcare does not have an Immunization doctype… until the immunization module is built"). The module now exists, so it was wired to return the patient's real `Immunization` records (15-field shape + `date_administered_display`, newest first, gated on `Patient` read). Verified live.

> Note for FE: the **Immunizations tab does not call** `get_patient_immunizations`. It uses the dedicated `list_immunizations` + `get_immunization_schedule`. The aggregator fix matters only if some other Patient Chart 360 consumer reads `patients.get_patient_immunizations`.

---

## What you actually need to do (frontend)

In most cases: **nothing** — run the active repo and the real data shows. To confirm/verify:

1. Run `EB_Healthcare_Frontend` (not the stale clone), authenticated, against a backend that has immunization data.
2. Open a patient with a DOB → Clinical → Immunizations. Confirm grid/timeline/records and counters populate. (Test backend has 43 records; patient `SchedCI - 5` has 4.)
3. If counters are all zero **and** the page shows "Could not load immunizations", the schedule call failed — check: patient has a DOB (required by `get_immunization_schedule`), JWT is attached by the BFF route, and the patient identifier sent is the one the backend keys on.

### Caveats worth a look (frontend-owned, not blocking)

- **Patient key:** the tab passes `patient.mrn` to the hooks. Confirm `mrn` equals the Frappe `Patient.name` the backend filters on. If your `Patient.name` is the MRN series this is fine; if not, the queries return empty.
- **Grid column matching is exact:** `GridView` matches a dose to a column via `d.age_months === m.ageMonths` against a hardcoded `MILESTONES` array (RN/2m/4m/6m/9m/12m/15m/18m/2y/3y/4y/5y/6y/11y/16y). A template dose at a non-listed age (e.g. 5m, 7m) will not render a cell. Keep template `age_months` aligned to these milestones, or make the grid tolerant.
- **i18n:** `MILESTONES` labels and the legend/age-banner strings are hardcoded in the component (e.g. "RN", "Patient age:"). Per frontend rule 13.10 (bilingual es-MX/en-US) these should route through the message catalog. The screenshot shows "PN" vs the code's "RN" — likely a build/i18n drift to reconcile.

---

## Verification done on the backend

- `python -c "ast.parse(...)"` on the edited `patients/api.py` → syntax OK.
- `bench --site remedisis.localhost console`: `Immunization` row count = 43; `get_patient_immunizations("SchedCI - 5")` returns 4 formatted records (was `[]`).
- BFF route handlers in the active frontend verified to call the exact backend method names listed above.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-18 | Sarvesh | Initial version (header backfilled from git history) |
