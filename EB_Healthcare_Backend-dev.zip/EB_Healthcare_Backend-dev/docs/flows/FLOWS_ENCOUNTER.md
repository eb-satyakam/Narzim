# Encounter flow — one consultation, from the room to a signed record

**Doc status:** living · **Created:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

What a doctor does, in order, and what the system does back. As merged on `dev`
on 2026-08-31.

This is the short version. The long ones are
[`ENCOUNTER_V3.md`](../architecture/ENCOUNTER_V3.md) for the design and
[`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](../architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
for capture. Decisions: [ADR-054](../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md).

---

## 1. The whole flow

```
  1 Capture   ──►   2 Review the note   ──►   3 Fill Encounter   ──►   Sign
  (talk)            (read and fix it)         (the record)             (PDF)
      ◄──────────────────◄────────────────────────◄
                    going back is always free
```

Three rules govern movement.

| Rule | What it means |
| --- | --- |
| **No skipping forward** | A step you have not reached yet is greyed out. You arrive through the button, never by tapping a card |
| **Going back is free** | Re-reading the transcript before you commit to an assessment is normal. Nothing is lost |
| **Sign only from step 3** | Steps 1 and 2 grey the Sign button. The medicines, labs, vitals and diagnoses only appear on step 3 |

**Why "no skipping forward" matters.** Fill Encounter is the signing screen.
Before 2026-08-31 every card was clickable, so it was one tap from Capture. A
doctor could sign an encounter with no transcript, no note and nothing in it.

---

## 2. Which screen you get

One address, `/encounters/[id]`. Two screens behind it.

- **Guided** is the three steps above.
- **Classic** is the old single long page. Everything on one scroll.

The deployment sets the default. Each doctor can switch for themselves from the
top bar, and their choice wins. The switch reloads the page on purpose, so the
incoming screen starts from the saved record.

---

## 3. Step 1 — Capture

**What it does.** Asks consent, then listens, and turns speech into text.

Audio goes from the browser straight to Deepgram. It never reaches our servers
and we never store it. What comes back is text, saved line by line.

**USER STORY.** Dr. Bracamontes opens the encounter → **the screen shows** a
consent question and a microphone that is switched off → he asks the family,
they agree, he taps "They agreed" → **the mic turns on** → the tablet screen
locks during the exam and he unlocks it → **he is not asked again**, because a
human answered for this patient seconds ago, in this tab. A different patient
is always asked. A closed tab is always asked.

**EXAMPLE.** The mic mishears a line. Any line can be fixed, words or speaker.

```
Before :  Patient    pet turt              [pencil]
After  :  Patient    पेट दर्द है            [saved]
```

**Rules here.**
- Recording never starts by itself. There is one code path to the microphone,
  and it is a click.
- Declining creates nothing. No session, no mic, no Deepgram.
- One live session per encounter, guaranteed by a database index, not by
  convention. If a second clinician opens the same encounter, they join the
  session that already exists.

---

## 4. Step 2 — Review the note

**What it does.** The AI writes a first draft into six boxes. You read it and
fix it. What you leave here is what the rest of the system treats as true.

The six boxes are Chief complaint, Subjective, Objective, Assessment, Plan and
Education. Typing autosaves about 1.5 seconds after you stop.

**USER STORY.** Dr. Bracamontes reads the draft, goes back to Capture, asks
three more questions, and presses "Review the note" again → **the system
processes the new speech**, because something new was said → the empty
Education box is filled → his own Assessment is **not** touched. The new
material for Assessment appears as an offer **under** the box, with the exact
words from the consultation beside it. It reaches the note only if he taps Add.

Press it twice with nothing new said and it just navigates. No second AI call,
no charge, no churn.

**EXAMPLE.** A diagnosis may be no more specific than the doctor made it.

```
Doctor said   : "It looks like you have a mild infection."
Note must say : Mild infection
Note must NOT : Viral pharyngitis (J02.9)
                       │        │      └── a billing code nobody assigned
                       │        └───────── the cause. No test was done
                       └────────────────── the site. No throat was examined
```

It may not go the other way either. It may not drop a diagnosis the doctor
did make.

**Two more things happen in this pass.**
- **Vitals said out loud are read by code, not by the model.** "temperature
  36.17, weight 18 kg" fills the vitals fields. Empty fields only. A nurse's
  measured pulse is never replaced. A reading outside human limits is dropped,
  never corrected.
- **Values from an attached lab go into Objective.** Values only, with the
  source and the result date. What the report *means* is cut out in code before
  the AI ever sees it, because the note carries the doctor's signature.

---

## 5. Step 3 — Fill Encounter

**What it does.** Shows the full record before you sign it. Nothing hidden.

Two lanes, and keeping them apart is the point of the screen.

| Lane | What it holds | Can it reach the record? |
| --- | --- | --- |
| **A — Documented** | Read straight out of the note you just approved | Yes. It fills the fields |
| **B — Considerations** | AI ideas. A dashed violet panel, every card marked "Not ordered" | No. Only when you tap Add |

**USER STORY.** A lab result from five weeks ago sits in Objective → **Lane A
must create no lab order** → **otherwise the record gets** a fresh requisition
→ **and so** a five-year-old is stuck for a second blood draw for a test he
already had, and the family pays twice. Nobody in the room decided that.

The rule that prevents it: **orders come from Plan only.** A test named in
Objective came *back*. A test named in Plan is being *sent*. Same words,
opposite direction. The same trap exists for drugs. "Taking paracetamol at
home" is history, not a new prescription.

**EXAMPLE.** A drug named with no dose cannot be saved at all.

```
Prescriptions
  Paracetamol
  Dose      [ __ ]   <- you fill this
  Frequency [ __ ]   <- you fill this
  Duration  [ __ ]   <- you fill this
```

The save builder drops a row with no dosage form and no period. A half-finished
AI row can never reach the record.

**Vitals.** One row per visit. Created once, then updated. If the nurse already
recorded weight at the desk, the doctor's screen finds that row and writes into
it. Before this was fixed one visit grew six rows, five of them holding zero.

Two different checks, and the split is deliberate:

| | Behaviour |
| --- | --- |
| **Impossible** — 980 kg, 4 °C | **Blocked.** That is a misplaced decimal point, not a patient |
| **Improbable** — 17.0 kg down to 9.8 kg | **Warned only.** A sick child really can lose weight, and that is the visit where you must not be locked out |

The comparison is against the patient's own last reading, not an age table.
149 of 306 patients have no date of birth, so an age check would protect half
the clinic and quietly do nothing for the other half.

**If reading the note into the record fails**, a banner says which stage failed
and offers a retry. You still land on Fill Encounter and can type everything by
hand. Before this, the fields were simply empty with nothing on screen to say
why, and pressing again did not even retry.

---

## 6. Sign

The screen saves first. If that save fails it does **not** sign. Signing a note
the record does not hold would attest to the wrong thing.

Then the server checks its own rules: a chief complaint is present, the caller
is a practitioner, and any vaccine has a nurse assigned.

Any practitioner may sign, not only the one the visit was booked under. A
covering doctor finishing a colleague's note is a normal shift. The record
stores who actually signed, so the printed note always names the real author.
Cancelling is different and stays with the assigned practitioner only.

After signing, the doctor can download, email, print or WhatsApp the report.
**The PDF is built in the browser.** Signing does not create it. The doctor
asks for it.

A signed or cancelled encounter is read only. Zero writes.

---

## 7. Where the data lands

`Patient Encounter` has no columns for the SOAP text, so the seven text fields
are packed into one JSON blob on the encounter. Everything else is a real row.

```
Patient Encounter
  encounter_comment (JSON)  chief_complaint · hpi · physical_examination
                            diagnosis · plan · education · notes
  ├─ Patient Encounter Symptom     symptom chips
  ├─ Patient Encounter Diagnosis   diagnosis chips
  ├─ Drug Prescription             medicines
  └─ Lab Prescription              lab orders

Vital Signs                 one row per visit
AI Transcript Segment       the conversation
AI Encounter Chat Message   Narzim chat, and uploaded document readings
AI SOAP Draft               the AI's own draft, versioned
```

**Text and chips are not the same thing.** Assessment is free text in the blob.
Diagnoses are linked rows. Confusing the two caused two live bugs, and one of
them made a whole note unsavable for ever.

---

## 8. Four rules that never bend

1. **The AI proposes. The doctor disposes.** No AI value lands on the record
   without a click.
2. **Never invent a clinical fact.** No dose, no code, no diagnosis nobody made.
3. **An AI failure must not block the doctor.** It must not fail silently
   either. It says what broke, and the manual path is always open.
4. **Never hide what will be signed.** Step 3 shows the whole record.

---

## 9. What is still open

| | Item | Why it matters |
| --- | --- | --- |
| **P0** | Provenance lives in React state. It dies on reload | Nothing can say which values the AI wrote. No Regenerate button is safe until this is fixed |
| P1 | Chat reaches the SOAP, but only the doctor's own turns, capped at 12 | Narzim's replies are deliberately excluded. Feeding its own guess back would amplify it |
| P2 | `encounter.signed` analytics not sent | — |
| P2 | Order slips not offered after signing | — |

---

## Revision history

| Version | Date | Author | Change |
| --- | --- | --- | --- |
| 1.0 | 2026-09-01 | Sarvesh-SocialAngel (AI-assisted) | Created after the 2026-08-31 merge. The short, readable flow doc, with a user story and an example per step |
