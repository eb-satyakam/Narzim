# ToDo Simplification & Nursing Task Assignment — Feature Record

**Doc status:** living · **Created:** 2026-08-20 by ashulockedin · **Updated:** 2026-08-20 by ashulockedin · **Version:** 1.0

> **Status:** Shipped and live on `mysite.localhost`.
> **Repos touched:** `remedisys_healthcare_ai` (backend, this repo) + `EB_Healthcare_EHR` (frontend,
> `Healthcare_next_app`).
> **Backend commit:** `9c9e9a7` — *feat(nursing): implement single assignee model for Nursing Tasks
> and collapse multi-assignee ToDos*.
> **Frontend commit:** `872875c` — *feat: Refactor CreateTodoForm to remove multi-assignee support and
> update related types* — plus a follow-up round of fixes (uncommitted as of this writing; see §7).
> **Primary ADR:** [`adr-041-single-assignee-and-nursing-task-assignment.md`](../adr/adr-041-single-assignee-and-nursing-task-assignment.md)
> — this document is the fuller narrative: the problem reports that triggered the work, the planning,
> and — the part the ADR doesn't cover — the full bug-hunt that followed shipping it, found entirely
> through live manual testing in the browser, not code review.
>
> **§11–§13 are a later round** (2026-08-20): the real Nursing Task state machine (nurse accept/reject,
> doctor-controlled hold), the PRIORITY/STATUS column correction, and what ships. Start at
> **§13** if you only need the deploy checklist.

---

## 1. Summary

"My Work" (`/inbox`) let a task be assigned to *several* people at once, which was fake: `ToDo` only
has one `allocated_to` field, so the app simulated multi-assign by creating one sibling `ToDo` row per
assignee. This produced duplicate rows, an invented `primary_holder`/`assignees` vocabulary, and no
honest single answer to "who owns this?".

Separately, there was no way for a **doctor to hand a clinical task to a specific nurse** and have the
system actually verify the nurse did it — ERPNext Healthcare's `Nursing Task` doctype supports exactly
this (a real assignee, a real completion-proof mechanism), but the app only used it for one narrow case
(vaccine administration) and nothing exposed it from My Work.

This feature:

1. Retired ToDo multi-assign — one assignee, one assigner, everywhere.
2. Added `assign_nursing_task` so a doctor can assign a Nursing Task to a named nurse from My Work.
3. Made "Mark as Complete" for a Nursing Task a **real, backend-verified status write** that core can
   reject — not attestation — and then spent a full round of live testing finding and closing every
   remaining place a task could still be faked complete. That second half (§7) is the bulk of this
   document's value: five distinct bypass paths were found and closed, one at a time, each reported by
   the user actually clicking through the UI.

---

## 2. Problem Statement

The work started from a batch of direct product complaints, reported with screenshots against the live
app, roughly in this order:

1. *"If a doctor created a nursing task for a nurse, that task is only visible to the nurse — not the
   doctor who created it. And if it's completed, how would the doctor ever know?"*
2. *"'Assigned by' should show the doctor's name — instead it shows something else under a 'Department'
   label that's wrong."*
3. *"Open in Nursing Task doesn't make sense as an action — it should say 'Open Patient 360' and land on
   the patient's chart; when the nurse comes back and marks it done, it should show in the Completed tab
   for both nurse and doctor."*
4. *"When a nurse marks a task done, it shows in Completed — but refreshing the page makes it disappear."*
5. *"If a doctor orders 'Administer Vaccine' and the nurse marks it complete without doing it, how do we
   know it was actually done?"*
6. *"I can still mark it complete without doing the work — and for 'Record Vital Signs' specifically, the
   action button should say 'Record Vitals' and recording vitals should auto-complete the task."*
7. *"The error message is a raw, unfriendly string, and there's a duplicate-key error in the console."*
8. *"Even though the single-item detail sheet correctly blocks a fake completion, checking the box and
   clicking the bulk 'Mark as Complete' button still moves it to Completed — please find and fix any
   other instances of this same class of bug."*
9. *"The vaccine task created from an encounter can still be marked complete without administering the
   vaccine — both via the checkbox and the button — and 'Administer Vaccine' should have its Task DocType
   set the same way 'Record Vital Signs' does."*

Items 1–4 shaped the ADR-041 design (§3–4 below). Items 5–9 turned into the bug-hunt in §7 — each one
surfaced only because the user actually exercised the UI, not from re-reading the diff.

---

## 3. Approach & Planning

Before writing code, the actual `Nursing Task` and `ToDo` schemas were read directly (not assumed), and
the existing `nursing/api.py` / `tasks/api.py` code was audited for what already existed vs. what needed
building. Key facts that shaped the design:

- **`Nursing Task` (ERPNext Healthcare core, read-only to this app per Rule 1):**
  - `user` (`Link(User)`, optional) is the single assignee.
  - There is **no `assigned_by` field** — the only assigner signal is Frappe's built-in `owner`.
  - `title`/`description` are read-only, derived by core; `notes` is the only free-text field a caller
    can write.
  - `status == "Requested"` auto-submits the document (`validate()` sets `docstatus = 1`).
  - Completing a task whose `task_doctype` is set requires a non-empty `task_document_name`
    (`on_update_after_submit`) — this is core's *only* verification mechanism, and (as §7 discovers) it
    is weaker than it looks.
  - `on_update_after_submit` computes `task_duration = time_diff_in_seconds(now, task_start_time)` on
    `Completed`; `get_datetime(None)` resolves to *now*, so a task that skips `In Progress` gets a small
    **negative** duration unless `task_start_time` is stamped first.
  - Frappe's `fetch_from` (auto-copying `task_doctype` from the `Healthcare Activity` master onto a new
    `Nursing Task`) is a **Desk-UI-only** behaviour — verified live in console that it does **not** fire
    on a document created via an API call like `assign_nursing_task`. It has to be set explicitly in
    code, every time.
- **Already built, reused rather than rebuilt:** `nursing/api.py`'s `create_nursing_task`,
  `submit_nursing_task`, `update_nursing_task_status`, `list_nursing_tasks`,
  `list_healthcare_activities`; the ADR-020 vaccine handoff (`create_vaccine_administration_task`,
  `_complete_vaccine_task`) as the working precedent for "doctor → nurse, verified" handoffs; the
  Front Desk nurse-picker pattern already in `encounter-screen.tsx`.
- **The multi-assign machinery to delete**, and the one caveat that made the deletion safe: `ToDo`'s
  `reference_type`/`reference_name` is *also* used for genuine references (e.g.
  `encounters.book_follow_up` sets `reference_type="Patient Encounter"`). Only rows with
  `reference_type == "ToDo"` are multi-assign siblings — every cleanup query had to filter on exactly
  that, or real follow-up ToDos would be destroyed.
- **A second multi-assign producer existed outside `tasks/api.py`:** `encounters.api.
  _create_refund_task_for_appointment` fanned the "please refund this appointment" ToDo out to the
  *entire* Front Desk team via the same sibling mechanism. This needed the same treatment.

### Locked product decisions (confirmed before writing code)

1. Assignee is **one named nurse**, chosen from users holding `EB_Nurse` — not a role or a pool.
2. An existing multi-assigned group migrates by **keeping the first/anchor assignee, dropping the rest**.
3. My Work stays **one unified list**; a type badge distinguishes ToDo vs. Nursing Task rows.
4. The system-generated refund ToDo becomes **unassigned and claimable** by any Front Desk user, instead
   of fanned out to all of them.
5. A Nursing Task assigned from My Work is **completed on the existing `/nursing` screen**, never
   in-line in My Work itself — My Work assigns and displays, it does not add a second status-write path
   (this directly resolves an existing internal audit finding, NT3, that My Work's old
   `Start`/`Complete` label did nothing but navigate — a fake action, not a real one).

### How "can a nurse fake a task done?" was decided

Item 5 above (`Administer Vaccine` fake-completion) was explicitly raised as an open question rather
than solved unilaterally. The options considered were: (a) trust the nurse's attestation, (b) require a
linked record for activities that have one, or (c) block completion entirely pending a separate
sign-off step. **Option (b) was chosen** — deliberately reusing core's own
`task_doctype`/`task_document_name` mechanism rather than inventing a parallel one — because it was
already half-built for the vaccine case and generalises cleanly to any future activity with a real
backing document (Vital Signs, in this app's case).

---

## 4. Architecture Decision

The full decision record, alternatives considered, and consequences are in **ADR-041**
(`docs/adr/adr-041-single-assignee-and-nursing-task-assignment.md`) — not duplicated here in full. In
short, seven decisions:

1. ToDo multi-assign machinery deleted outright (not deprecated); one assignee (`allocated_to`), one
   assigner (`assigned_by`, native).
2. The refund-task fan-out becomes a single unassigned, claimable ToDo; `_fetch_todos` widens to show
   Front Desk users their team's unassigned queue.
3. New whitelisted `assign_nursing_task(patient, activity, user, notes, ...)` — create + submit in one
   transaction, so there's never an invisible orphan Draft.
4. Nurse picker (`list_nurse_users`) deliberately bypasses the `User`-doctype read permission gate, same
   reasoning as the existing `list_shareable_users` / `_front_desk_users` patterns.
5. Assigner exposure uses `owner` (native), not a new Custom Field — consistent with ADR-020.
6. My Work assigns/displays only; it never writes Nursing Task status (§3, decision 5 above).
7. The `task_duration` negative-value bug is fixed in passing by stamping `task_start_time` before any
   completion that skipped `In Progress`.

---

## 5. Backend Implementation

All in `remedisys_healthcare_ai/api/v1/`, following the existing whitelisted-method-only pattern (Rule 1
— never touches `apps/healthcare` core).

### `nursing/api.py`

- **`assign_nursing_task`** (new, whitelisted, `require_permission("Nursing Task", "create")`) — the
  doctor-facing endpoint. Validates the patient and activity exist; validates `user` is an **enabled
  account holding `EB_Nurse`**; explicitly rejects `activity == "Administer Vaccine"` by name (see next
  bullet for why); reads the activity's `task_doctype` and — because `fetch_from` doesn't fire on an
  API-created doc — sets it explicitly on the new `Nursing Task`; rejects any activity whose
  `task_doctype` is set to something this module has no auto-complete wiring for (so a doctor can never
  create a task the nurse has no way to actually finish); creates the doc as `Draft` then calls
  `.submit()` in the same call, so it lands in `Requested` and appears on the nurse's worklist
  immediately.
- **Why "Administer Vaccine" is rejected by name, not by the generic `task_doctype` allowlist check:**
  its own `Healthcare Activity` master originally had **no** `task_doctype` set at all — only the
  individual tasks created by `create_vaccine_administration_task` get `task_doctype="Patient Vaccine"`
  stamped in code. The generic check literally cannot see this case, so a manually-assigned vaccine task
  would silently end up requiring nothing at all — the opposite of what item 5 in §2 was asking for.
  (§7.10 revisits this master field.)
- **`list_nurse_users`** / **`list_healthcare_activities`** — the two pickers `AssignNursingTaskForm`
  (frontend) is built on.
- **`_ensure_task_start_time`** — stamps `task_start_time` before a `Completed` write if it's still
  empty, closing the negative-`task_duration` bug (§4, decision 7).
- **`complete_task_for_document(patient, task_doctype, task_document_name, user)`** — the auto-complete
  hook other modules call once real clinical work actually happens (currently: `vital_signs.api.
  submit_vital_signs`). No-op if there's no matching open task, so it's safe to call unconditionally.
- **`update_nursing_task_status`** — the one endpoint both `/nursing` (the nurse's own worklist) and
  My Work's completion actions call to move a task through its work states. Hardened during the bug hunt
  (§7.11) to outright reject a manual `Completed` transition for `task_doctype` values that must only be
  completed by their own dedicated real-event flow (`_MANUAL_COMPLETE_BLOCKED = {"Vital Signs",
  "Patient Vaccine"}`) — this is the load-bearing fix; see §7.11 for exactly why core's own guard wasn't
  enough.

### `tasks/api.py` (the My Work aggregator)

- Deleted outright: `_parse_emails`, `_todo_group_anchor`, `_todo_group_members`,
  `_todo_group_primary_holder`, `_create_sibling_todos`, and the `assignees`/`primary_holder` fields from
  every response shape.
- `create_todo`/`get_todo`/`list_todos`/`update_todo`/`delete_todo` simplified to plain single-row
  operations — `list_todos` went from up to 3 queries per page down to 1.
- `_fetch_tasks`/`_fetch_todos`/`_fetch_nursing_tasks`/`_fetch_clinical_procedures` unified to one
  consistent output shape: `assigned_to` / `assigned_to_full_name` / `assigned_by` /
  `assigned_by_full_name`, plus `is_closed` and `requires_task_document`.
- `_fetch_nursing_tasks` widened with `or_filters = {"user": user, "owner": user}` for non-admin callers
  — this is the direct fix for problem #1 in §2: the assigning doctor is the `owner`, so without this
  widening the task genuinely never appeared in their own feed.
- `_fetch_todos` widened so a non-admin Front Desk caller also sees ToDos with an empty `allocated_to`
  (the unassigned refund-request queue from decision 2 in §4).

### `vital_signs/api.py`

- `submit_vital_signs` calls `nursing.api.complete_task_for_document(patient=doc.patient,
  task_doctype="Vital Signs", task_document_name=doc.name, user=frappe.session.user)` right after
  `doc.submit()` — this is what makes recording real vitals auto-complete the matching task, closing
  problem #6 in §2.

### `immunizations/api.py`

- `create_immunization_record`, when called with a `nursing_task` argument, calls
  `_complete_vaccine_task(nursing_task)` after inserting the dose — the vaccine equivalent of the vitals
  auto-complete above, pre-dating this feature (ADR-020) but reused and hardened here (§7.9, §7.11).
- `_complete_vaccine_task` now also calls `_ensure_task_start_time` before completing (decision 7, §4).

### `encounters/api.py`

- `_create_refund_task_for_appointment` rewritten from the anchor/sibling fan-out to a single
  **unassigned** `ToDo` insert with an idempotency guard; the now-unused `_create_sibling_todos` import
  is dropped.

### Migration patches (all in `patches/v0/`, all idempotent, all registered in `patches.txt`)

| Patch | What it does | Verified |
|---|---|---|
| `seed_nursing_activities_20260818` | Seeds 7 standard `Healthcare Activity` masters (all with empty `task_doctype`) so a fresh/production site has a usable activity picker. | — |
| `collapse_todo_assignee_groups_20260818` | Deletes open sibling ToDos (`reference_type == "ToDo"` only), detaches (doesn't delete) closed/cancelled siblings, keeps the anchor. | Pre-migration: 9 sibling groups, 16 open + 1 closed sibling row. Post-migration: zero `reference_type="ToDo"` rows; the 7 genuine `"Patient Encounter"` follow-ups and 2 `"Patient Appointment"` refund ToDos confirmed untouched. |
| `link_vital_signs_nursing_activities_20260819` | Sets `task_doctype="Vital Signs"` on the "Record Vital Signs" / "Monitor Blood Pressure" activity masters. | — |
| `set_administer_vaccine_task_doctype_20260819` | Sets `task_doctype="Patient Vaccine"` on the "Administer Vaccine" activity master — display/consistency only (§7.10). | Confirmed via console after `bench migrate`: both "Record Vital Signs" → `Vital Signs` and "Administer Vaccine" → `Patient Vaccine`. |

---

## 6. Frontend Implementation

All in `EB_Healthcare_EHR/src/`.

- **`types/my-work.ts`** — `WorkItem` restructured to single `assigned_to` / `assigned_to_full_name` /
  `assigned_by` / `assigned_by_full_name` (+ `activity`, `requires_task_document`, `is_closed`);
  `TodoItem` lost `primary_holder`/`assignees`; new `NurseUser` / `HealthcareActivityOption` types.
- **`hooks/use-nursing.ts`** — `useNurseUsers()`, `useNursingActivities()`, `useAssignNursingTask()`; the
  `NursingTask` type gained `user`/`user_full_name`/`owner`/`owner_full_name`.
- **`hooks/use-my-work.ts`** — `useMyWorkFeed(opts?: { includeClosed?: boolean })`, keyed separately per
  `includeClosed` value so a completed row survives a page refresh (problem #4 in §2 — see §7.2 for the
  bug this was actually fixing).
- **`components/narzim/inbox/assign-nursing-task-form.tsx`** (new) — patient / activity / nurse pickers,
  notes, requested-start-time, mandatory toggle; shows an amber warning when the picked activity has a
  `task_doctype` set, since submission will be rejected server-side if this module has no auto-complete
  wiring for it.
- **`components/narzim/inbox/inbox-tab.tsx`** — the largest single file touched (~1700 lines):
  `mapWorkItemToInbox`'s per-type routing (vaccine → deep-link to the Add-immunization dialog; Vital
  Signs → deep-link to the Record Vitals modal; everything else → Open Patient 360); the detail sheet's
  gated "Mark as Complete"; the `allItems` aggregation merging the open feed, the closed feed, and Todos
  with de-duplication; a type badge per row; the `InboxTabHandle` imperative handle (§7.8).
- **`components/narzim/inbox/work-inbox-client.tsx`** — owns `selectedIds`/`doneIds` state and the bulk
  toolbar action (§7.8).
- **`components/narzim/inbox/todo-tab.tsx`** / **`todo-detail-client.tsx`** — multi-assign UI (the
  `assignToOthers` toggle, assignee pills) removed; simplified to one assignee picker.
- **`app/api/encounters/[id]/followup/route.ts`** — dropped the mock `primary_holder`/`assignees` fields
  from its demo response.
- **`messages/en.json` / `messages/es.json`** — every new label, warning, and error string added to both
  files; parity checked by script (exact key-set diff) after every batch of changes.

---

## 7. Bug Hunt — Issues Found and Fixed Through Live Testing

This is the part of the work that didn't come from a design review — every single item here was found by
the user actually clicking through the running app and reporting exactly what they saw, in most cases
with a screenshot. They're listed in the order they were reported.

### 7.1 — Assigned task invisible to the assigning doctor

**Symptom:** a doctor assigns a Nursing Task to a nurse; the doctor's own My Work never shows it, so
there's no way to know if it was ever done.
**Cause:** `_fetch_nursing_tasks` filtered strictly on `user == caller`; the doctor is never the `user`
(that's the nurse), only the `owner`.
**Fix:** widened the filter to `or_filters = {"user": user, "owner": user}` for non-admin callers.

### 7.2 — Completed task disappears on page refresh

**Symptom:** nurse marks a task done, it correctly moves to the Completed tab — until the page is
refreshed, at which point it's gone.
**Cause:** "done" was tracked only in an in-memory `doneIds` `Set` on the client; nothing re-fetched
closed items after a reload.
**Fix:** a second, separately-cached query (`useMyWorkFeed({ includeClosed: true })`) that the aggregator
merges in, filtered to `is_closed` — a completed item now survives a refresh because it's re-derived from
a real backend field, not client memory.

### 7.3 — "Assigned by" mislabelled as "Department"

**Symptom:** the detail sheet showed the assigning doctor's name under a field literally labelled
"Department".
**Cause:** an earlier, hacky fix had folded an "assigned by" note into the same string rendered under the
Department label.
**Fix:** the Department row was removed entirely (per explicit user instruction — not restored correctly,
just removed) and replaced with proper, separately-labelled `assignedToDisplay` / `assignedByDisplay`
rows.

### 7.4 — First pass at vaccine verification: require a linked record

**Symptom/question:** "if a nurse marks 'Administer Vaccine' complete without doing it, how do we know?"
**Resolution:** see §3, "How 'can a nurse fake a task done?' was decided" — option (b), require a linked
proof document, chosen and implemented as the `task_doctype`/`task_document_name` gate. (This round
turned out to be incomplete — see §7.9 and §7.11.)

### 7.5 — Vitals: still fake-completable, wrong action label, no auto-complete

**Symptom:** even after 7.4's gate, a "Record Vital Signs" task could still be marked complete without
recording vitals; separately, the action button read a generic label instead of "Record Vitals", and
recording real vitals didn't auto-close the task.
**Fix:** three parts — (1) the action button for a Vital-Signs-linked task now deep-links straight to the
patient chart's "Record vitals" modal; (2) `vital_signs.api.submit_vital_signs` calls
`complete_task_for_document` after a successful submit, so recording real vitals auto-completes the
task; (3) with `task_doctype="Vital Signs"` now genuinely set and `task_document_name` genuinely empty
until that real submit, core's own guard correctly rejects a premature manual completion for this case.

### 7.6 — React Query invalidation key mismatch + duplicate-key console error

**Symptom:** after completing or assigning a task, My Work stayed stale for up to 60 seconds; separately,
a React "duplicate key" warning appeared in the console.
**Cause:** `queryClient.invalidateQueries({ queryKey: ["my-work"] })` was called — but
`useMyWorkFeed`'s real key is `["my-work-feed", includeClosed]`. React Query matches key arrays by
per-element deep equality, not string-prefix, so `["my-work"]` never matched `["my-work-feed", ...]` at
all. The two separately-cached feeds (open-only and open+closed) could therefore briefly disagree about
the same task's status right after a mutation, putting it in the merged list twice under the same id.
**Fix:** both `useUpdateNursingTaskStatus` and `useAssignNursingTask` now invalidate `["my-work-feed"]`
(the correct prefix — React Query *does* match on a shared leading segment, just not on an entirely
different string). A defensive `Map`-based de-duplication by item id was also added in `allItems` as a
second layer, keeping the last-written (i.e. most-authoritative, closed-feed) copy when both are present.

### 7.7 — Raw backend error surfaced verbatim to the nurse

**Symptom:** rejecting a premature completion showed the literal string *"Not Allowed to 'Complete'
Nursing Task without linking Task Document"* — accurate, but meaningless to a nurse who never touched
anything called a "Task Document".
**Fix:** the mutation's `onError` now checks the known cases (`requires_task_document` combined with
`reference_doctype === "Vital Signs"`, later also `"Patient Vaccine"` — §7.9) and shows a translated,
specific, friendly message instead; only a genuinely unexpected failure falls back to a generic one.

### 7.8 — Bulk "Mark as Complete" checkbox bypass

**Symptom (user's own words):** *"even though you blocked it from doing mark as complete from here [the
detail sheet] it shows proper msg but when i check the box and do mark as complete it moves to completed
tab."*
**Cause:** the toolbar's bulk action (`work-inbox-client.tsx`) called `selectedIds.forEach(toggleDone)`
directly — a pure client-side dismiss with **zero backend call**, completely bypassing every real
completion path the single-item detail sheet had just been fixed to require. Any item type, checked in
bulk, could be "completed" this way with no verification at all.
**Fix:** `InboxTab` now exposes an imperative handle (`completeSelected(ids)`) via a plain `ref` prop —
React 19 allows a function component to accept `ref` directly, without `forwardRef`, and this was
confirmed to actually thread correctly through `next/dynamic`'s lazy-loading wrapper by reading its
source (`LoadableComponent` is a plain function component that spreads `props`, including `ref`,
straight through to the lazily-resolved component). For every selected id, `completeSelected` calls the
item's real completion action — `item.onComplete` (the gated Nursing Task mutation) or `item.onMarkDone`
(the real ToDo close) — falling back to a plain visual archive only for item types with no backend "done"
state at all (e.g. a clinical note). `work-inbox-client.tsx` now holds a ref to `InboxTab` and calls
`inboxTabRef.current?.completeSelected(selectedIds)` instead of the raw toggle.

### 7.9 — Vaccine task fake-completable via the detail sheet's secondary button

**Found while auditing for other instances of 7.8's bug class**, before the user reported it separately:
the detail sheet's secondary "Mark as Complete" button already correctly preferred `item.onComplete`
when present (fixed as part of 7.7/7.8's work) — but `mapWorkItemToInbox` never wired `onComplete` for
the vaccine-administration branch specifically (only the Vital Signs and generic branches got it). So a
vaccine task hit the exact same fake-dismiss fallback as 7.8, just through a different door, for a
reason nobody had touched yet.
**Fix:** wired `realOnComplete = onComplete` in the vaccine branch too, mirroring Vital Signs; added a
dedicated `nursingCompleteNeedsVaccine` friendly error message (en/es) for when core correctly rejects
it.

### 7.10 — "Administer Vaccine" activity master missing `task_doctype` for display consistency

**User's report:** *"record vital signs is connected with Vital Signs task doctype [in the Desk UI] i
want same for [Administer Vaccine]."*
**Why it had been left empty on purpose:** `assign_nursing_task` (§5) rejects `"Administer Vaccine"` by
**name**, checked before it ever looks at the activity's `task_doctype` — so setting the field doesn't
weaken that gate. The individual Nursing Task documents this activity produces already get
`task_doctype="Patient Vaccine"` stamped directly in code by `create_vaccine_administration_task`,
regardless of what the master shows.
**Fix:** `set_administer_vaccine_task_doctype_20260819` patch sets it (idempotent, only if currently
empty); `nursing.api._ensure_vaccine_activity` (the dev-site fallback creator) does the same for sites
that haven't migrated yet. Purely display/consistency — verified via console that `assign_nursing_task`'s
by-name rejection is unaffected.

### 7.11 — Vaccine task *still* fake-completable, via the generic status endpoint itself

**The user's report, after 7.9's fix was already live:** *"why we are giving option there too mark as
complete without actually doing that task both ways checkbox and button click"* — i.e. the bug from 7.8
and 7.9 was still reproducible for vaccine tasks specifically, from **both** My Work *and* the `/nursing`
worklist screen, even after the frontend routing fixes.

**Root cause (the actual bug, found by re-reading core's guard logic, not by guessing):** core's
`on_update_after_submit` check is simply
`if status == "Completed" and self.task_doctype and not self.task_document_name: throw`. For Vital
Signs, `task_document_name` genuinely stays empty until the real event happens, so this check works. But
`create_vaccine_administration_task` sets `task_document_name = patient_vaccine` — the **order** — at
*assignment* time, before any dose is ever given. That makes core's guard trivially satisfied from the
moment the task is created. Every frontend fix up to this point routed correctly through
`update_nursing_task_status`, but that backend endpoint itself never verified anything beyond what core
already (weakly) checked — so the "real" completion call succeeded regardless.

**Fix:** `update_nursing_task_status` now maintains its own set,
`_MANUAL_COMPLETE_BLOCKED = _AUTO_COMPLETE_DOCTYPES | {"Patient Vaccine"}` (currently `{"Vital Signs",
"Patient Vaccine"}`), and rejects a manual `Completed` transition outright for any task whose
`task_doctype` is in that set — before any mutation happens, regardless of what `task_document_name`
already holds. This also closes a related, previously-theoretical gap for Vital Signs: nothing had
stopped a caller from handing this endpoint an arbitrary `task_document_name` pointing at an unrelated
Vital Signs row for the same patient, which core's "just check it's non-empty" guard would have accepted.
The legitimate auto-complete paths (`complete_task_for_document` from `submit_vital_signs`,
`_complete_vaccine_task` from `create_immunization_record`) are unaffected — they mutate the document
directly and never call `update_nursing_task_status` at all.

**Live verification (bench console, `mysite.localhost`):**
1. Created a real vaccine-administration task via `create_vaccine_administration_task`.
2. Called `update_nursing_task_status(name=task, status="Completed")` as the assigned nurse — rejected
   with *"This task completes automatically once its Patient Vaccine record is created — it can't be
   marked complete manually."* Task status confirmed still `Requested` in the database afterward.
3. Called `create_immunization_record(..., nursing_task=task)` — the real path — and confirmed the task
   status flipped to `Completed` correctly, proving the legitimate flow is untouched by the new guard.
4. Test task and immunization record cleaned up afterward.

---

## 8. Verification Performed

- **Backend:** `bench --site mysite.localhost migrate` — all four patches applied cleanly (three had
  already run in an earlier pass; the fourth, `set_administer_vaccine_task_doctype_20260819`, applied in
  0.125s on this pass). `python3 -c "import ast; ast.parse(...)"` syntax check on every edited file.
  Live `bench console` sessions verified, with real data (not mocks): the doctor-visibility fix (§7.1);
  the migration's before/after row counts (§5's patch table); the `task_doctype` consistency change
  (§7.10); and the full manual-completion rejection + real-completion-still-works round-trip for the
  vaccine case (§7.11).
- **Frontend:** `npx tsc --noEmit` and `npx eslint` on every changed file after every round of fixes —
  confirmed zero new errors or warnings each time (a handful of pre-existing, unrelated warnings — e.g. an
  `e2e` spec file's type error, some dead-code lint warnings elsewhere in `inbox-tab.tsx` — were checked
  against `git diff`/`git log` and confirmed pre-existing, not introduced by this work). `en.json`/
  `es.json` key-set parity checked by script after every batch of new strings (last confirmed: exact
  match, 221 `myWork` keys each, then +1 each for `nursingCompleteNeedsVaccine`).
- **Manual UI testing:** every single item in §7 was reported by the user testing the live app in the
  browser, not found by static review — several fixes in turn introduced or exposed the *next* bug in
  the list, which is why §7 reads as a chain rather than a flat list.

---

## 9. Known Gaps / Out of Scope

Carried over from ADR-041, still true after this round of fixes:

- Core template-generated Nursing Tasks (admission/lab/procedure checklists) still never set `user`, so
  they remain invisible to any nurse's worklist filter — not addressed here.
- Reassignment of an already-submitted Nursing Task is not supported (`user` is not `allow_on_submit`);
  assignment is create-time only, by design (see ADR-041 §"Alternatives Considered", item 3).
- Small negative `task_duration` values written by live vaccine handoffs *before* the `task_start_time`
  fix (§4, decision 7) were not backfilled.
- `_MANUAL_COMPLETE_BLOCKED` (§7.11) is a deny-list maintained by hand — a future `task_doctype` added to
  `_AUTO_COMPLETE_DOCTYPES` for assignment purposes should be reviewed for whether it also needs adding
  here for completion purposes; they are related but not automatically the same set.

---

## 10. File Index

**Backend** (`remedisys_healthcare_ai/`):

- `api/v1/nursing/api.py` — `assign_nursing_task`, `list_nurse_users`, `_ensure_task_start_time`,
  `complete_task_for_document`, `_MANUAL_COMPLETE_BLOCKED`, `update_nursing_task_status` hardening,
  `_ensure_vaccine_activity` update.
- `api/v1/tasks/api.py` — multi-assign machinery removed; `_fetch_*` functions unified and widened.
- `api/v1/vital_signs/api.py` — `submit_vital_signs` auto-complete call.
- `api/v1/immunizations/api.py` — `_complete_vaccine_task` start-time fix.
- `api/v1/encounters/api.py` — `_create_refund_task_for_appointment` rewritten.
- `patches.txt` + `patches/v0/seed_nursing_activities_20260818.py` +
  `patches/v0/collapse_todo_assignee_groups_20260818.py` +
  `patches/v0/link_vital_signs_nursing_activities_20260819.py` +
  `patches/v0/set_administer_vaccine_task_doctype_20260819.py`.
- `docs/adr/adr-041-single-assignee-and-nursing-task-assignment.md`.

**Frontend** (`EB_Healthcare_EHR/src/`, plus root `messages/`):

- `types/my-work.ts`, `hooks/use-nursing.ts`, `hooks/use-my-work.ts`.
- `components/narzim/inbox/assign-nursing-task-form.tsx` (new).
- `components/narzim/inbox/inbox-tab.tsx`, `work-inbox-client.tsx`, `todo-tab.tsx`,
  `todo-detail-client.tsx`.
- `app/api/nursing/tasks/route.ts`, `app/api/nursing/nurses/route.ts`,
  `app/api/nursing/activities/route.ts` (new BFF routes), `app/api/encounters/[id]/followup/route.ts`.
- `messages/en.json`, `messages/es.json`.

---

## 11. State Machine — Accept/Reject and Doctor-Controlled Hold

A later round of work, triggered by a direct question: *"what is requested, accepted, hold, entered in
error and all [these Nursing Task statuses]?"* Investigating the answer surfaced that core enforces
almost none of the 12-value status vocabulary — and once that was clear, the follow-up ask was
explicit: *"doctor made nursing task then it is requested ... nurse has to accept or reject ... doctor
can [put it] on hold [and] nursing can't start it unless doctor removes it from on hold."* This section
documents that implementation.

### 11.1 What core actually enforces (and why it's not enough on its own)

Reading `nursing_task.py` directly, core's *entire* validation is two rules in `on_update_after_submit`:
`status` can't go back to `"Draft"` after submit, and `"Completed"` requires a non-empty
`task_document_name` when `task_doctype` is set. That's it. Nothing stops a submitted task from jumping
from `Requested` straight to `Entered in Error` to `In Progress` to `Ready` — there is no state-machine
graph in core, and no actor/permission distinction between "the assigned nurse" and "anyone with write
access to the doctype." The Desk UI (`nursing_task.js`) *suggests* a flow via which buttons it shows, but
that's presentation, not enforcement — calling the API directly bypasses it entirely.

### 11.2 The state machine this app now enforces

Implemented in `nursing/api.py` as `_TRANSITIONS` (the legal edges) and `_TRANSITION_ACTOR` (who may
drive each edge), both consulted from a new `_validate_transition()` called at the top of
`update_nursing_task_status`, before any other check (including the pre-existing `_MANUAL_COMPLETE_BLOCKED`
guard from §7.11, which still applies on top once a transition is confirmed legal):

```
Requested --nurse accepts--> Accepted --nurse starts--> In Progress --nurse completes--> Completed
        \--nurse rejects--> Rejected [terminal]                     \--nurse can't finish--> Failed [terminal]

Requested   --\
Accepted    --+-- doctor holds --> On Hold -- doctor releases --> (back to whichever
In Progress --/                                                   status it was held from)
```

**Hold is available from every active status, not just `Accepted`** (revised — the first cut allowed it
only from `Accepted`, on the reading that "the doctor blocks her from *starting*"; the actual product
requirement is broader: *"even though nurse accepts or rejects, doctor can place it on hold any time"*).
So the doctor can stop a task before the nurse has even answered, after she accepts, or mid-work.

That raises the question the narrow version didn't have: **where does a release go back to?** Guessing is
not acceptable in either direction — releasing a task the nurse never accepted must not silently mark it
`Accepted` on her behalf, and releasing one she had already started must not demote it and make her redo
the accept/start steps. `Nursing Task` has no spare field to park the pre-hold status in, and ADR-020/041
both deliberately avoid adding Custom Fields to this doctype.

Resolved without any schema change: `Nursing Task` ships with `track_changes: 1`, so Frappe already
records every status change in the `Version` doctype as `["status", <from>, <to>]`.
`resolve_hold_release_status(name)` reads the most recent change *into* `On Hold` and returns its `from`
value; `tasks/api.py` exposes it on the feed as `hold_release_status` (computed only for rows actually
`On Hold`), and the frontend passes it straight back rather than choosing a target itself. Falls back to
`"Accepted"` only when no such history exists — e.g. a task held from the Desk before this shipped, or
pruned history — chosen as the middle of the three so a fallback can neither skip an accept on a task
that had reached `In Progress` nor strand one that had genuinely been accepted. The lookup is wrapped in
`tasks/api.py::_hold_release_status` so a Version-read failure degrades to `null` instead of breaking the
whole My Work feed.

> **Dependency worth knowing:** this relies on `track_changes` staying enabled on `Nursing Task`. It's on
> in core's own doctype JSON (so fresh installs get it) and verified present with no Property Setter
> override on `mysite.localhost`. If a site admin ever disables it via Customize Form, hold-release
> silently degrades to the `"Accepted"` fallback — no crash, but the pre-hold status is no longer
> recoverable. Deliberately not force-enabled by a patch, since that would override an explicit site
> customization on every migrate.

Two things reachable outside that graph:
- **`Entered in Error`** — allowed from *any* non-terminal status, actor restricted to the assigning
  doctor (`doc.owner`) or an admin. This is a correction ("this task record itself was a mistake — wrong
  patient, duplicate"), distinct from `Failed` ("the work was genuinely attempted and didn't succeed").
  It's a special case rather than an edge in `_TRANSITIONS` precisely because it's reachable from
  everywhere, not from one specific state.
- **`Cancelled`** — not reached through `update_nursing_task_status` at all. It's a real Frappe docstatus
  cancel via `cancel_nursing_task` (core's own `on_cancel` hook sets it). That endpoint was also hardened
  in this round: cancelling now requires the assigning doctor or an admin — a nurse who doesn't want to
  do a task uses `Reject`, not `Cancel`; cancelling means the doctor no longer wants it done at all.

**A hold has to block the auto-complete path too — this was a real bug.** The status-write endpoint was
only ever half the story: `nursing.api.complete_task_for_document` (called from
`vital_signs.api.submit_vital_signs`) matched any task whose status wasn't *closed*, and `On Hold` is not
closed. So a nurse who recorded vitals from any other screen — the patient chart, mid-encounter — would
silently auto-complete a task the doctor had explicitly blocked, bypassing the hold entirely. Same gap in
`immunizations.api._complete_vaccine_task`. Both now treat `On Hold` as non-matching, so the hold holds on
*every* path that can close one of these tasks, not just the one the UI happens to call. Verified live:
held task + a real `Vital Signs` document → stayed `On Hold`; after release + start → completed normally.

**Actor rule, precisely** (checked in `_validate_transition`): every edge is tagged `"nurse"` or
`"assigner"` in `_TRANSITION_ACTOR`, matched against `frappe.session.user` vs. `doc.user` (the assigned
nurse) or `doc.owner` (the assigning doctor). An admin (`Administrator` or `EB_Healthcare Admin`) bypasses
every actor check, for support/correction. Attempting an edge with the wrong actor gets a `PermissionError`
("Only the assigned nurse can do this." / "Only the doctor who assigned this task can do this.");
attempting an edge that doesn't exist from the current status gets a `ValidationError` naming the actual
legal options ("This task can't move from Requested to In Progress — from Requested it can only go to:
Accepted, Rejected.").

**Deliberately left unused: `Received` and `Ready`.** Both are real core status values. `Accepted`
already means "the nurse will do this" — adding a mandatory `Received` ("I've seen this") step in front
of it, or a `Ready` ("prerequisites met") step behind it, would be friction with no product ask behind it.
A Desk user can still set either by hand (core doesn't forbid it — `_TRANSITIONS.get(current, set())`
simply returns an empty set for any status with no defined outgoing edges, so a task manually parked in
`Ready` can't move anywhere through this endpoint until an admin intervenes); nothing in this app's own
flow produces or expects them.

### 11.3 Where each action lives in the UI

**The first attempt put this in the wrong screen.** The workflow controls were built only into
`/nursing` — which turned out to have **no sidebar entry at all** (it existed in `route-access.ts` but was
never in the nav), so the Accept/Reject buttons were literally unreachable. The requirement had also been
stated plainly and missed: *"it shows in nurse **my work**, first nurse has to accept or reject."* Both
fixed:

- **Sidebar** — `/nursing` now has a "Nursing" entry under Clinic for nurse / practitioner / clinic-staff
  / admin (`app-sidebar.tsx`; the `sidebar.nursing` i18n key already existed).
- **My Work is now the primary surface**, since that's where both the nurse and the doctor actually work.
  Actions live in **two** places there, backed by one shared hook so they can never disagree:
  - **`useNursingActions(item, viewerEmail)`** — single source of truth for which edges the current viewer
    may drive, mirroring `_TRANSITIONS` + `_TRANSITION_ACTOR`. Consumed by both the table row and the
    detail sheet. The backend remains the real enforcement; this only decides what's worth showing so a
    user is never offered something guaranteed to be rejected.
  - **The ACTION column (`InboxCard`)** — status-aware inline buttons, so the whole flow works from the
    table without opening anything: nurse sees **Accept**/**Reject** at `Requested`, **→ Start task** at
    `Accepted`, the real work (**Record Vitals** / **Administer**) at `In Progress`, and *nothing* while
    `On Hold` (amber "On hold" text, tooltip naming the doctor). The assigning doctor sees **Place on
    hold** at any active status and **Release hold** while held.
  - **The detail sheet (`InboxDetailSheet`)** — a "Workflow" section with the same actions plus the
    explanatory text there's no room for in a table cell (why the nurse is blocked, who placed the hold,
    what happens next). Shows the doctor a note while a task is still `Requested` rather than rendering an
    empty section.

  This is a genuinely new write path from My Work, which ADR-041 §6 otherwise keeps display-only for
  Nursing Tasks. Justified: ADR-041 was guarding against a *second route to the nurse's own completion
  write*, which this isn't — completion still happens only via the real clinical record. Accept/reject/
  start and the doctor's hold have no other home now that the flow lives here.

**Gating the clinical work itself.** A new `InboxItem.actionIsClinicalWork` flag marks the two primary
actions that actually *perform* work rather than navigate (Record Vitals, Administer). Those are disabled
unless the task is `In Progress`, with the reason shown inline — "Accept this task first." / "Start the
task first." / "On hold — release the hold before recording this." Plain navigation ("Open Patient 360")
is never gated. Previously **Record Vitals was live even while a task was `On Hold`**, which defeated the
entire point of a hold. "Mark as Complete" is likewise hidden for vitals/vaccine tasks at every status,
since `_MANUAL_COMPLETE_BLOCKED` (§7.11) guarantees it can only ever error there.

**Two UI bugs found in live testing and fixed:**
1. **The detail sheet didn't update after a transition** — accepting a task left the open sheet showing
   the pre-accept state until it was closed and reopened. Cause: `InboxTab` stored the selected
   *object*, captured at row-click time, so it went stale the moment the mutation refetched the feed.
   Now stores only the `id` and resolves the item live from the current list on every render.
2. **The STATUS column showed dates, not status** — see §12.

**Status vocabulary in the UI.** `NURSING_STATUS_KEY` / `NURSING_STATUS_BADGE` map all 12 core statuses to
translated labels and colours, used by both the table's STATUS column and the detail sheet. `/nursing`'s
own "Done" tab likewise stopped rendering raw English status strings. A held task also re-buckets: since
Hold is reachable from `In Progress` too, `On Hold` is grouped under "To do" only when it hasn't started.

### 11.4 Verification

Every scenario exercised live against **real non-admin accounts** (`doctor@gmail.com`, a plain
`EB_Practitioner`; `nurse@gmail.com`) — not read off the code, and not run as Administrator, whose
admin bypass would have hidden every actor check.

Core state machine (10 scenarios, all as expected):

1. Nurse skips straight to `In Progress` from `Requested` → rejected, names the legal options.
2. Assigning doctor tries to `Accept` on the nurse's behalf → rejected, wrong actor.
3. Nurse accepts → succeeds.
4. Nurse tries to hold her own task → rejected, assigner-only.
5. Doctor holds → succeeds.
6. Nurse tries to `Start` while held → rejected.
7. Nurse tries to release the hold → rejected, wrong actor.
8. Doctor releases → succeeds.
9. Nurse starts → succeeds.
10. Nurse tries to manually `Complete` a Vital-Signs task → still blocked by `_MANUAL_COMPLETE_BLOCKED`
    (§7.11), confirming the new graph and the older verification layer compose rather than bypass.

Hold-from-anywhere + release-target recovery (3 cases, run as a module via `bench execute` — the console
splits heredocs into separate cells and loses function scope, which silently produced `NameError`s on a
first attempt):

| Case | Result |
|---|---|
| Hold from `Requested` → release | returns to **`Requested`** — the nurse still has to accept |
| Hold from `In Progress` → release | returns to **`In Progress`** — her started work isn't undone |
| Nurse attempts hold *or* release | rejected both times, assigner-only |

Also verified: `Reject` is terminal (a later status change is refused before the actor check even runs);
a nurse cannot set `Entered in Error` or cancel the task; a held task is **not** auto-completed when a
real `Vital Signs` document is created (the bug in §11.2), while the same flow completes normally once
released and started; and the feed returns `hold_release_status: "Requested"` for a task held before
acceptance. Every test task was deleted afterward — no residue on `mysite.localhost`, and the temporary
modules used for `bench execute` were removed.

`tsc --noEmit` and `eslint` clean on every changed frontend file (only the same pre-existing, unrelated
warnings noted in §8, confirmed unchanged by `git stash` before/after); `en.json`/`es.json` key-set parity
confirmed exact after every batch of new strings; each round finished with a cold rebuild (`rm -rf .next`,
needed because stale Turbopack cache once reported a `MISSING_MESSAGE` for a key that was present) serving
`/inbox` and `/nursing` with no runtime errors.

### 11.5 File index addition

- **Backend:** `api/v1/nursing/api.py` — `_TRANSITIONS`, `_TRANSITION_ACTOR`, `_HOLDABLE`,
  `_validate_transition`, `resolve_hold_release_status`, `On Hold` exclusion in
  `complete_task_for_document`, actor-gating on `cancel_nursing_task`.
  `api/v1/tasks/api.py` — `_hold_release_status` helper + `hold_release_status` on the nursing-task feed
  rows. `api/v1/immunizations/api.py` — `On Hold` exclusion in `_complete_vaccine_task`.
- **Frontend:** `components/app-shell/app-sidebar.tsx` (the missing `/nursing` nav entry),
  `app/(clinic)/nursing/nursing-client.tsx` (bucket/action rewrite), `inbox-tab.tsx`
  (`useNursingActions`, `NURSING_STATUS_KEY`/`_BADGE`, the ACTION-column state machine, the Workflow
  section, id-based `selectedId` resolution, `actionIsClinicalWork` gating, nullable `priority`),
  `types/my-work.ts` (`hold_release_status`), `messages/en.json` / `messages/es.json`.

---

## 12. Correcting the PRIORITY and STATUS columns

Raised as a direct question — *"the status we are showing for nursing task, this overdue/today, are they
real or fake?"* — and the honest answer was: half real, and one column was actively misleading.

**What was wrong.**

| Column | What it actually showed | Verdict |
|---|---|---|
| STATUS | Overdue / Today, derived purely from the due date (`requested_start_time`) | Real data, wrong question — a column labelled STATUS was showing schedule, while the doctype's actual `status` field was nowhere in it |
| PRIORITY | Urgent / High, **synthesized from the status** (`Requested`/`Accepted` → Urgent, `In Progress` → High) | Fabricated. `Nursing Task` has **no priority field**; the backend sends `"priority": None`. "Urgent" literally meant "Accepted" |
| (grey subtitle) | The real status — but only via `context: … \|\| item.status`, so it vanished entirely whenever the task had a `medical_department` | Real but fragile |

So the same real status was rendered twice — once honestly as grey subtitle text, once disguised as
clinical urgency nobody had expressed — while the column named STATUS showed dates. ADR-041 had explicitly
called for the opposite: *"Nursing Tasks carry no priority … prefer blank; don't invent data."*

**What it does now** (scoped to nursing-task rows; ToDo / Task / encounter rows are untouched):

- **STATUS** → the real workflow status, colour-coded via `NURSING_STATUS_BADGE`: Requested (violet),
  Accepted (teal), In progress (dark teal), On hold (amber), Completed (green), Rejected/Failed (red),
  Cancelled / Entered in error (grey).
- **DUE DATE** → inherits the schedule signal: the date turns red + "Overdue" or amber + "Today".
  Suppressed once the item is closed, since "overdue" is meaningless for finished work.
- **PRIORITY** → an em dash. `InboxItem.priority` became `Priority | null`, and the sort ranks null last
  (`indexOf(null)` was returning `-1`, which would have floated these to the *top*).
- **Detail sheet** → the "Priority" row is replaced by a real "Status" row for nursing tasks.
- **Grey subtitle** → no longer falls back to the raw status for nursing tasks, now that it has a proper
  home.

---

## 13. Deployment / What Ships

Everything in §11–§12 is **pure application code plus one already-registered patch** — no doctype schema
changes, no new fields, no fixtures. Concretely, to get all of this onto pre/prod:

1. **Merge + deploy the code** (both repos).
2. **Run `bench migrate`** as part of the deploy — which is all that's needed for the two
   data-level pieces:
   - `patches/v0/set_administer_vaccine_task_doctype_20260819.py` — registered in `patches.txt`,
     idempotent, sets `task_doctype="Patient Vaccine"` on the "Administer Vaccine" Healthcare Activity
     (display consistency only; §7.10).
   - `patches/v0/eb_docperm_spec.json` — the `Clinical Note` permission block (EB_Practitioner / EB_Nurse
     / EB_Healthcare Admin full, EB_Front Desk **read-only**). This needs no dated patch of its own:
     `hooks.py` runs `rebuild_eb_role_permissions.execute` on **`after_migrate`** *and* `after_install`,
     so editing the spec is the whole deployment step. (That file's own docstring says so explicitly:
     *"To change EB_ permissions, EDIT eb_docperm_spec.json — do NOT add new reapply_* patches."*)

Nothing else requires a patch:

- The state machine, actor rules, `resolve_hold_release_status`, the `On Hold` exclusions and the
  `cancel_nursing_task` gate are all runtime logic in `api/v1/`.
- `hold_release_status` is computed per-request from Frappe's existing `Version` rows — not stored.
- The Nursing Task comment endpoints reuse Frappe's generic `Comment` doctype; nothing to migrate.
- `Clinical Note` is a **core ERPNext Healthcare doctype** already installed with the `healthcare` app —
  only its EB_ role permissions were missing, hence the spec entry above.
- The earlier ADR-041 patches (`seed_nursing_activities_20260818`,
  `collapse_todo_assignee_groups_20260818`, `link_vital_signs_nursing_activities_20260819`) are unchanged
  and already registered; they'll run on any site that hasn't had them yet.

**Verified on `mysite.localhost`:** `bench migrate` completes clean (exit 0), the vaccine-activity patch
applied, and `tabCustom DocPerm` for `Clinical Note` reads
`EB_Front Desk read=1 create=0 write=0` / `EB_Healthcare Admin`, `EB_Nurse`, `EB_Practitioner` full —
i.e. the permission spec really did apply via the hook, not just sit in the JSON.

> One standing dependency, repeated from §11.2 because it's easy to lose: hold-release recovery needs
> `track_changes` to stay enabled on `Nursing Task`. It's on in core's doctype JSON and confirmed with no
> Property Setter override; a site that disables it via Customize Form degrades gracefully to the
> `"Accepted"` fallback rather than breaking.

**One flake to expect, unrelated to this feature.** During verification, one `bench migrate` run aborted
inside Frappe's *own* `frappe/utils/fixtures.py::sync_fixtures` with
`_pickle.PicklingError: Can't pickle <class 'frappe.model.document.LazyUser'>` while enqueueing an RQ job.
The traceback contains **zero** `remedisys_healthcare_ai` frames, and an immediate re-run of the identical
command completed with exit 0 and no error — it's a transient RQ/Redis serialization issue in this
Frappe-on-Python-3.14 environment, not something this change introduced. If a deploy hits it, re-run
`bench migrate`; patches are idempotent, so a partial run is safe to repeat.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | ashulockedin | Initial version (header backfilled from git history) |
