# Gaps — Billing, Screen by Screen

**Doc status:** living · **Created:** 2026-08-20 by Anant Sharma · **Updated:** 2026-08-27 by Divyanshu (AI-assisted) · **Version:** 1.1

Full audit of every billing touchpoint in the backend as it stands on `dev`
(2026-08-20, including the uncommitted `collect_invoice` change in the working
tree). Organised the way the user asked for it: **per screen first**, then the
cross-cutting service-layer gaps that cause several screens to disagree with
each other, then test debt.

Read with: `docs/flows/GAPS_APPOINTMENT_AND_RESCHEDULE.md` (the reschedule
money path in detail — not repeated here), `docs/KNOWN_ISSUES.md`.

**Severity**
| | Meaning |
|---|---|
| **P0** | Money is lost, double-charged, refunded twice, or reported wrong with no operator signal. |
| **P1** | Wrong figure or reachable failure that an operator can eventually catch. |
| **P2** | Missing capability / governance the product needs but never had. |
| **P3** | Hygiene, performance, contract cleanliness, tests. |

**Files in scope**
- `api/v1/billing/api.py` (1,512) · `services/billing.py` (3,045) · `api/v1/billing/report.py` (391)
- `api/v1/insurance/api.py` (191) · `api/v1/insurance/report.py`
- Billing touchpoints in `dashboard`, `appointments`, `encounters`, `immunizations`, `patients`, `labs`, `procedures`, `inbox`, `patient_portal`

---

# Part 1 — Screen by screen

## 1. Dashboard / Mission Control — queue badges + revenue KPIs

**Where:** `api/v1/dashboard/api.py:735-790`, `:895-925`

| | Sev | Gap |
|---|---|---|
| D-1 | **P0** | **"Collected today" counts write-offs as cash.** `collected_today_mxn` sums `_billing_for`'s `paid`, which is `grand_total − due`. A Government-waived invoice cleared by `_write_off_invoice` has `outstanding = 0`, so the full amount lands in today's revenue as if collected. The Billing → Invoices list deliberately does **not** do this — `_serialize_invoice` uses `real_cash_paid_bulk` precisely to avoid it, and even reports a separate `write_off_amount`. Two screens, two revenue numbers, and the dashboard's is the optimistic one. |
| D-2 | **P1** | **"Collected today" is not today.** It is scoped to invoices billing *appointments dated today*, so it includes money collected last week for a visit scheduled today, and excludes everything collected today that has no appointment behind it — every ad-hoc invoice from `create_invoice`, every product sale, every vaccination invoice for a walk-in. The label is `collected_today_mxn`; the number is "ever-collected, on today's appointments". |
| D-3 | **P1** | **Command Center revenue has the same write-off bug plus no return filter.** `_command_center_revenue` (`:895`) computes `grand_total − outstanding_amount` per invoice, and its query (`:1126-1135`) filters only `company` + `docstatus=1` — no `is_return = 0`. Credit notes are pulled in and contribute their own arithmetic to a KPI that is supposed to read "collected today vs target". |
| D-4 | **P3** | Revenue silently degrades to zero. Both revenue blocks are wrapped in bare `except Exception: pass` (`:776`, `:1136`). A role without Sales Invoice read, or a genuine query error, renders MXN 0 collected with no indication the figure is unavailable rather than actually zero. |

## 2. Appointments — Book (Pay now / Pay later / Insurance)

**Where:** `appointments/api.py:1434` `book_appointment_with_payment`, `:1604` `book_appointment_for_patient`; `services/billing.py:504` `invoice_and_settle`

| | Sev | Gap |
|---|---|---|
| B-1 | **P1** | **Two contradictory failure policies for the same action.** `book_appointment_with_payment` keeps the appointment Unpaid and returns 201 with `payment_error` (ADR-012). `book_appointment_for_patient` rolls the whole thing back (2026-06-16 decision, explicitly overriding ADR-012). Which one the front desk gets depends on whether the patient is new. |
| B-2 | **P1** | **`Patient Appointment.paid_amount` means two different things.** `invoice_and_settle` restores it to the **tax-inclusive** amount actually collected (`services/billing.py:597`), while the reschedule path writes the **pre-tax** fee (`appointments/api.py:2398`). `_billing_for`'s no-invoice branch reads this field as the outstanding for an uninvoiced appointment — so that figure is short by the tax on one path and right on the other. |
| B-3 | **P2** | **`insurance` timing creates the invoice but never a claim.** The copay is left outstanding and the payor portion sits on the invoice; nothing creates or tracks an `Insurance Claim` (see §11). The clinic has an unbilled receivable against an insurer with no artifact representing it. |

## 3. Appointments — Reschedule

Covered in full in `GAPS_APPOINTMENT_AND_RESCHEDULE.md` (R-1 … R-10). The
billing-specific ones worth restating because they are *money* gaps:

| | Sev | Gap |
|---|---|---|
| B-4 | **P0** | A refund issued outside the reschedule flow is invisible to it — `_appointment_funding` (`services/billing.py:1335`) derives clawed-back cash only from `Appointment Reschedule History` rows, so a manual Billing-tab refund is not deducted and the next reschedule over-refunds. |
| B-5 | **P0** | `reschedule_appointment` (`appointments/api.py:1921`) moves an appointment with no fee recompute, no history row, no `paid_amount` update — and thereby corrupts the baseline the *next* reschedule computes its delta from. |
| B-6 | **P1** | `old_fee` (tax-inclusive) and `new_fee` (pre-tax) are stored on the same history row with no tax columns to disambiguate. |

## 4. Patient Chart 360 — Billing tab

**Where:** `billing/api.py:371` `list_patient_invoices`, `:712` `get_patient_invoice`

| | Sev | Gap |
|---|---|---|
| B-7 | **P1** | **`list_patient_invoices` uses `frappe.get_all`, bypassing permission query conditions.** `list_all_invoices` (`:445`), `list_draft_invoices` (`:559`) and `list_payment_entries` (`:1032`) all deliberately use `get_list` "so role/user permissions are enforced" and say so in their docstrings. The per-patient list does not, so any User Permission narrowing a user's invoice visibility (by company, by cost center) is silently ignored on this one screen. |
| B-8 | **P1** | **No company scoping.** Neither list filters on `company`. On a multi-clinic site a front-desk user at clinic A sees, and can act on, clinic B's invoices for the same patient. `_soft_resolve_company` exists in the appointments module for exactly this; billing has no equivalent. |
| B-9 | **P3** | `total` is computed as `len(frappe.get_all(..., limit=0))` — every matching invoice name is fetched to produce a count, on every page load, in all four list endpoints. `frappe.db.count` does this in the database. |

## 5. Patient List — billing column

**Where:** `patients/api.py:818` `_batch_patient_billing`, `:504` `_batch_outstanding_balance`

| | Sev | Gap |
|---|---|---|
| B-10 | **P1** | **The column shows the patient's *most recent invoice*, presented as their billing state.** `status` is `"Paid" if that one invoice is Paid else "Pending"`, `total` is that one invoice's outstanding. A patient whose latest invoice is paid but who owes on three older ones reads as **Paid**. |
| B-11 | **P3** | `method`, `paidAt` and `reminderActive` are hardcoded `None`/`None`/`False` in the response — stub fields the frontend cannot distinguish from real "no data". |
| B-12 | **P1** | **`_batch_outstanding_balance` excludes credit notes** (`is_return = 0`), so an unapplied credit the patient holds never reduces their balance due — AR is overstated for exactly the patients who were refunded. It is also unscoped by company, summing every clinic's debt into one figure. |

## 6. Patient Encounter — per-order billing opt-out

**Where:** `encounters/api.py:1806` `_stamp_billing_optout`

| | Sev | Gap |
|---|---|---|
| B-13 | **P1** | **An order the physician chose *not* to bill is recorded as `billing_status = "Invoiced"` with `qty_invoiced = quantity`** — a factual untruth in the data model. There is no way to distinguish "billed" from "deliberately excluded", no way to reverse the decision, and any future revenue report that counts `billing_status="Invoiced"` as billed revenue will over-count. Compare the medication path, which got a proper dedicated flag (`custom_billed_externally`, `billing/api.py:1477`) for the same semantics. The right fix is the same: a distinct `custom_billing_excluded` flag, with the cart filtering on both. |
| B-14 | **P2** | The opt-out decision is carried in the `encounter_comment` JSON blob as a positional `bill_flags` array parallel to the child rows. Any reordering or mid-list insertion of orders between save_draft and submit shifts every subsequent flag by one. There is no key, only an index. |

## 7. Immunization — vaccine billing

**Where:** `immunizations/api.py:430` `_create_vaccine_billables`

| | Sev | Gap |
|---|---|---|
| B-15 | **P0** | **A vaccine billing failure is swallowed silently and the dose is never billed.** The `except Exception` rolls back the savepoint and logs `type(exc).__name__` only — no message, no task, no flag on the Immunization, no retry, nothing on any screen. The clinical record is correct (which is the right priority, Rule 7) but the charge simply ceases to exist. Nobody finds out. This is unmetered revenue leakage, and the identical pattern applies to the product Medication Request created at assignment. **Needs a durable failure marker plus a Front Desk task** — the mechanism already exists (`_create_refund_task_for_appointment` in `encounters/api.py:1960`). |
| B-16 | **P3** | The legacy Flow-B endpoints (`list_billable_immunizations`, `create_vaccination_invoice`, `billing/api.py:1142`/`:1157`) are still whitelisted after ADR-026 retired vaccines as a distinct cart line. `get_patient_billables` no longer emits Immunization lines, so a caller using the old pair bills a dose the new cart also bills — a live double-bill route. |

## 8. Labs / Procedures — order billing

**Where:** `labs/api.py`, `procedures/api.py`, `services/billing.py:2098` `_list_billable_service_requests`

| | Sev | Gap |
|---|---|---|
| B-17 | **P3** | Both modules expose an `invoiced` boolean but neither exposes *which* invoice, nor the amount. The Labs and Procedures screens can say "billed" but cannot link to the charge. |
| B-18 | **P1** | `_list_billable_service_requests` **silently skips** any order whose template reference is dangling or whose item is disabled (`continue`, three times). That is the correct choice versus core's crash-the-whole-cart behaviour — but the skip is invisible. An order that should be billable and isn't never appears anywhere; front desk cannot know the cart is incomplete. Needs a `log()`-equivalent and ideally a `skipped[]` array in the cart response. |

## 9. Billing → Invoices list

**Where:** `billing/api.py:445` `list_all_invoices`

| | Sev | Gap |
|---|---|---|
| B-19 | **P1** | **The scope guard loads every patient customer into an `IN` clause.** `frappe.get_list("Patient", pluck="customer", limit_page_length=0)` then `filters={"customer": ("in", patient_customers)}` — twice per request (rows + count). At 50k patients that is a 50k-element IN list on every page of the billing dashboard, and the same pattern is in `list_draft_invoices` and `list_payment_entries`. The appointments module caps exactly this shape at `_SEARCH_PATIENT_CAP = 500`; billing has no cap. **Fix:** invert it — filter on the invoice's own `patient` field being set, which is what the guard is actually trying to express. |
| B-20 | **P3** | `status` is passed through to the filter unvalidated, so a typo returns an empty page rather than a 400. |

## 10. Billing → New Invoice editor (and drafts)

**Where:** `services/billing.py:2694` `create_sales_invoice`, `:2648` `get_draft_invoice_detail`

| | Sev | Gap |
|---|---|---|
| B-21 | **P0** | **Submit-then-settle with no savepoint.** `si.submit()` runs, then `settle_invoice()` is called. If the settle throws — no Mode of Payment Account for the company, a Bank-type account rejecting the reference, a rounding edge — the request returns an error while the invoice is **already submitted, sources already marked invoiced, GL already posted, and nothing paid**. The front desk sees a failure and retries; the cart is now empty because the first invoice took it. The same shape is in `create_pos_invoice` (`:2339`), `create_invoice` (`:2496`) and `create_vaccination_invoice` (`:1878`). `create_credit_note` (`:931`) **does** wrap itself in a savepoint and documents exactly why. Four of the five write paths are missing that guard. |
| B-22 | **P1** | **Rate override on an insurance-linked line desyncs the coverage split.** The docstring says it outright: "coverage_percentage/coverage_amount are computed from the cart's original rate, so overriding rate there can desync the covered vs. patient-owed split" — and then allows it, calling it the caller's responsibility. The frontend has a rate field on every line. This is a wrong-payer bug the API knowingly permits. **Fix:** reject a rate override on a line carrying `insurance_coverage`, or recompute the split from the new rate. |
| B-23 | **P1** | **The drafts surface is half-retired.** `as_draft` is rejected (draft creation disabled, correctly, to prevent double-billing) — but `list_draft_invoices`, `get_draft_invoice_detail` and the `invoice_name` resume path all remain. So the only drafts reachable are ones made in Desk or before the change. The picker exists for a population that no longer grows, and the resume path is untested. |
| B-24 | **P3** | The resume path clears items, taxes, and both discounts but not `remarks` — a resumed draft keeps the old remark when the caller sends none. |

## 11. Billing → Checkout / POS cart

**Where:** `services/billing.py:2272` `get_patient_billables`, `:2339` `create_pos_invoice`

| | Sev | Gap |
|---|---|---|
| B-25 | **P0** | **The cart is single-company, resolved from the user's default.** `_company()` (`:1991`) is `frappe.defaults.get_user_default("company") or frappe.db.get_default("company")` — no parameter, no argument, no override, used by `get_patient_billables`, `create_pos_invoice`, `create_invoice` and `create_sales_invoice` alike. On a multi-clinic site: a patient's billables from any other clinic are invisible at checkout, and an invoice is raised against whatever company the *operator's* default happens to be, not the one the service was delivered at. That is a wrong-entity posting, and it silently produces an incomplete cart rather than an error. |
| B-26 | **P1** | **No lock against a concurrent double-bill.** `create_pos_invoice` re-derives the authoritative cart and rejects anything already invoiced — correct, and the reason there is no price tampering. But two submits racing from two tabs both pass that check before either submits, and the `set_invoiced` write-back only lands at submit. `test_pos.py::test_no_double_billing` covers the *sequential* case; the concurrent one has no guard. |
| B-27 | **P3** | `create_pos_invoice` does not set `is_pos` and settles via a separate Payment Entry — so despite the name it produces a normal invoice. Harmless, but every reader has to discover that, and `_real_cash_paid`'s POS branch never applies to it. |

## 12. Billing → Invoice detail

**Where:** `billing/api.py:712` `get_patient_invoice`

| | Sev | Gap |
|---|---|---|
| B-28 | **P3** | The strongest endpoint in the module — real per-item tax from `item_wise_tax_details`, honest `None` when a line has mixed rates, `price_list_rate` exposed so the discount reconciles. The only gap: no credit-note back-reference. An invoice that has been refunded shows nothing about the Credit Note against it, so the detail screen cannot show what was returned. |

## 13. Billing → Collect Payment

**Where:** `billing/api.py:806` `collect_payment`, `services/billing.py:432` `settle_invoice`

| | Sev | Gap |
|---|---|---|
| B-29 | **P0** | **No patient scope guard.** `get_patient_invoice` and `create_credit_note` both check `frappe.db.exists("Patient", {"customer": doc.customer})` and refuse otherwise, with a comment saying why. `collect_payment` does **not** — it validates only that the Sales Invoice exists and that the caller can create a Payment Entry. A front-desk user can therefore settle **any** Sales Invoice on the site, including a non-patient/commercial one, through the patient billing API. |
| B-30 | **P0** | **Anyone who can collect a payment can waive an entire invoice.** Passing `mode_of_payment = "Government"` routes to `_write_off_invoice` (`services/billing.py:116`), which zeroes the **full** outstanding via a Journal Entry regardless of the `amount` sent — no role gate beyond `Payment Entry create`, no second signature, no reason field, no dedicated audit record, and the endpoint returns `amount: 0.0` so even the response does not state what was forgiven. For an LFPDPPP / NOM-024 (and DPDPA) jurisdiction this is the single least defensible thing in the billing layer. **Needs:** a distinct role or approval, a mandatory reason, and a write-off record naming the authoriser. |
| B-31 | **P1** | The uncommitted `collect_invoice` / `collect_outstanding` fields in `appointments/api.py:525-534` are the fix for collecting against the right invoice in a reschedule chain (previously: "Payment 740.0 exceeds outstanding 240.0"). Not committed, and no test covers per-invoice collection targeting. Land it with one. |

## 14. Billing → Refund / Credit Note

**Where:** `services/billing.py:931` `create_credit_note`, `:695` `_apply_partial_return_items`

The best-engineered path in the module — cash-vs-write-off separation, per-row
remaining quantities via core's own `get_already_returned_items`, savepoint,
POS/non-POS split all handled and explained. The gaps are at its edges:

| | Sev | Gap |
|---|---|---|
| B-32 | **P1** | **A partial refund does not scale an invoice-level discount.** Declared as a KNOWN LIMITATION in the docstring: `make_return_doc` copies `discount_amount` / `additional_discount_percentage` as-is rather than prorating to the refunded subset. Refunding one line of a discounted invoice therefore returns the wrong amount — and because the discount is copied whole, it can return *more* than that line ever contributed. |
| B-33 | **P1** | **Only fully-paid invoices can be refunded.** `flt(si.outstanding_amount) > 0` → reject. So a partly-paid invoice cannot be reduced by a credit note at all: the only ways out are cancelling the invoice or writing it off. Meanwhile `_create_reschedule_refund` refunds against invoices with no such gate — two refund paths, two rules. |
| B-34 | **P1** | **Refunding an insured invoice does not reverse the coverage.** Cash is correctly bounded to `_real_cash_paid` so the payor's share is never handed to the patient — but nothing un-marks the `Patient Insurance Coverage`, and no claim adjustment is made. The coverage stays Invoiced against a sale that no longer exists. |
| B-35 | **P2** | **No reason, no approver, no refund record.** The only trace is a `frappe.logger` line and the Credit Note itself. There is no reason field, no authoriser, and no queryable refund register — the same governance gap as B-30, on the money-out side. |

## 15. Billing → Payments tab

**Where:** `billing/api.py:1032` `list_payment_entries`

| | Sev | Gap |
|---|---|---|
| B-36 | **P1** | **POS-embedded payments are missing entirely.** The tab lists `Payment Entry` rows only. Every Pay-Now booking that settled inline through `Sales Invoice Payment` — and the report layer explicitly counts these (`report.py:103-130`, with a comment saying the report would undercount without them) — never appears here. The Payments tab and the Payment Methods report disagree by exactly the POS volume. |
| B-37 | **P1** | **Refunds are absent.** Filter is `payment_type = "Receive"`, so refund Payment Entries (`"Pay"`) are excluded. The tab shows gross collections with no way to see money going back out. |

## 16. Insurance / Claims

**Where:** `api/v1/insurance/api.py` (191 lines), `api/v1/insurance/report.py`

| | Sev | Gap |
|---|---|---|
| B-38 | **P2** | **Claims do not exist.** The module has four methods, all policy CRUD: `get_patient_insurance_policies`, `save_patient_insurance_policy`, `delete_patient_insurance_policy`, `list_insurance_payors`. `create_claim` / `submit_claim` / `get_claim_status` / `list_claims` — all four named in CLAUDE.md §12 — are unbuilt. The insurance *reporting* layer already reads the `Insurance Claim` doctype (`report.py:48`), so the Claims Status report renders against a table that nothing in this app ever writes. Its own docstring notes `Patient Insurance Coverage is currently empty`. |
| B-39 | **P1** | With no claim lifecycle, an insured invoice's payor portion has no state machine: it is neither collectible, agable, nor reconcilable. `_build_outstanding_balances` counts it as ordinary patient AR. |
| B-40 | **P2** | No eligibility check, no coverage preview before booking, no copay estimate. The booking screen offers `payment_timing = "insurance"` with no way to tell the patient what they will owe. |

## 17. Reports → Financial

**Where:** `api/v1/billing/report.py`

| | Sev | Gap |
|---|---|---|
| B-41 | **P0** | **AR aging is windowed on posting date, so it cannot age.** `_build_outstanding_balances` (`:173`) filters `posting_date between [start, end]`. With the default `period="month"`, "total outstanding" is only debt *posted this month*; a 90-day-overdue invoice from three months ago is absent, and `oldest_days` is structurally capped by the window it just excluded that invoice with. The `aging` chart's 90+ bucket can only ever be populated by widening the window to include it — at which point it is no longer aging as of today. **Aging must be as-of-a-date across all open invoices; the window belongs on nothing but the trend.** This directly contradicts Phase 3's exit gate ("AR aging correct"). |
| B-42 | **P1** | Same report: unapplied credit notes never reduce the total (`outstanding_amount > 0` excludes their negative balances), so AR is overstated for every refunded patient. `trend` is an admitted stub. The table is truncated at 50 rows without that truncation being declared in `meta.stub_fields`. |
| B-43 | **P1** | **Payment Methods report has no patient scope guard.** `_build_payment_methods` (`:69`) filters `party_type = "Customer"` but never checks the customer maps to a Patient — unlike the Payments tab, which does. Any commercial receipt in the company inflates clinic revenue. It also sums `Receive` only, so refunds are not netted: the report shows gross intake, labelled "collected revenue". |
| B-44 | **P1** | **Revenue by provider double-attributes and mis-attributes.** `_build_revenue_by_provider` (`:268`) joins `Patient Appointment.ref_sales_invoice` and takes "first wins". A batch-checkout invoice covering three appointments is credited **whole** to the first appointment's practitioner. A reschedule delta invoice is not any appointment's `ref_sales_invoice`, so it lands in `Unattributed`. The dashboard already solved this with `appointment_invoice_share`; the report does not use it. |
| B-45 | **P1** | Every financial report computes collected as `grand_total − outstanding_amount` — the write-off-as-revenue bug (D-1) again, in `revenue_by_provider` and the overview. `real_cash_paid_bulk` exists for exactly this and is used only by the invoice list. |

## 18. Inbox / Tasks

| | Sev | Gap |
|---|---|---|
| B-46 | **P0** | **Cancelling a paid appointment raises no refund task** (A-1 in the appointment gaps doc). `cancel_unpaid_invoice_for_appointment` returns `True` to mean "a refund is owed"; `cancel_appointment` and `update_status` both discard it. Only the encounter-cancel cascade acts on it. The Inbox is where that task would land, and for the path front desk actually uses it never arrives. |
| B-47 | **P2** | No billing task types at all beyond that one refund ToDo: no "invoice failed", no "vaccine unbilled" (B-15), no "claim rejected", no "write-off pending approval". |

## 19. Patient Portal

| | Sev | Gap |
|---|---|---|
| B-48 | **P2** | **The portal has no billing whatsoever.** No invoice list, no balance, no receipt, no online payment. `book_my_appointment` has no `payment_timing` parameter (also noted in `KNOWN_ISSUES.md`), so a patient booking through the portal always creates an uninvoiced appointment. If this is picked up, `payment_timing` should be *accepted and restricted* to `pay_later` rather than ignored, so the wire contract is stable for when online payment arrives. |

## 20. Settings / Admin

| | Sev | Gap |
|---|---|---|
| B-49 | **P1** | **Waiver modes are configured in `site_config.json`, not in the app.** `_waiver_modes()` reads `remedisys_compliance_profile`-style config (`remedisys_waiver_payment_modes`, defaulting to `{"Government"}`) — so which Mode of Payment silently forgives an entire invoice is a deploy-time file edit, invisible to Clinic Admin and unauditable from the UI. |
| B-50 | **P1** | **The waiver scheme name is stored in `remarks` free text and recovered by regex.** `_WAIVER_REMARK_RE` parses `"Waived — (.+?) scheme (100% discount)"` back out of the invoice's remarks (`services/billing.py:65`, `:90`) because Sales Invoice has no header-level mode field. Any edit to that remark — or a translated string — breaks the Payment Method column and the waiver's only marker. The reasoning for avoiding a real field is sound; the conclusion (regex over free text as the system of record for *how an invoice was forgiven*) is not. |
| B-51 | **P3** | `list_tax_templates` / `list_item_tax_templates` sum only `charge_type = "On Net Total"` rows for the preview rate, documented as "none of this app's templates use those today". A template using "Actual" or "On Previous Row Total" would preview as 0% tax and then compute correctly at submit — a silent mismatch between what the front desk was shown and what the patient is charged. |
| B-52 | **P2** | Revenue targets exist per company (Command Center) but nothing else billing-related is clinic-configurable: no per-clinic payment modes, no rounding policy, no invoice numbering series, no receipt template. |

---

# Part 2 — Cross-cutting

### X-1 · P0 · Atomicity is applied inconsistently across the five write paths
`create_credit_note` and `book_appointment_for_patient` use savepoints and
document why. `create_sales_invoice`, `create_pos_invoice`, `create_invoice`
and `create_vaccination_invoice` do not — each can leave a submitted invoice
with a failed payment (B-21). One convention, applied everywhere, with the
policy (keep-and-report vs roll-back-all) settled once in an ADR.

### X-2 · P0 · "How much was paid" has four implementations
| Definition | Used by |
|---|---|
| `real_cash_paid` / `real_cash_paid_bulk` (PE allocations + POS `paid_amount`) | Billing invoice list only — **the correct one** |
| `grand_total − outstanding_amount` | Dashboard KPIs, Command Center, every financial report |
| `appointment_invoice_share` (prorated) | Appointments list, appointment detail, dashboard per-row |
| `total_paid_for_appointment` (chain-aware) | Reschedule settlement |
The first two differ by exactly the write-off amount; the third and fourth
exist for good reasons. The fix is not to unify all four — it is to make the
**reporting** layer stop using #2, since it is the only one that is simply
wrong.

### X-3 · P0 · Company is resolved from the operator, not the service
`_company()` in `services/billing.py:1991` is the single point where every
invoice's company is decided, and it reads the *user's* default. No billing
endpoint accepts a `company` argument. Every gap tagged multi-clinic above
(B-8, B-12, B-25) is downstream of this one line.

### X-4 · P1 · No financial governance surface
No approval on a waiver (B-30), no reason on a refund (B-35), no reason on a
`fee_override`, no register of write-offs, no register of refunds, no
distinction between "not billed" and "billed" (B-13). Every one of these is a
question an audit under NOM-024 or DPDPA will ask, and the answer is currently
a `frappe.logger` line and a regex over a remarks field.

### X-5 · P1 · Silent skips throughout the cart
`_list_billable_service_requests` skips dangling templates and disabled items;
`_list_billable_medications` skips medications without an item; the vaccine
biller swallows its own failure. Each individual choice is defensible (never
crash the cart, never block the clinical record). Collectively they mean **the
cart cannot be trusted to be complete and never says so.** Every skip needs to
surface — a `skipped[]` array in the cart response, a durable marker on the
record, or a task.

### X-6 · P3 · Performance
Unbounded patient-customer `IN` lists in three list endpoints (B-19),
`len(get_all(...))` counting in four (B-9), and `get_patient_billables` runs
eleven separate core scans per call — including inside `create_pos_invoice` and
`create_sales_invoice`, so the cart is built twice per checkout.

---

# Part 3 — Test debt

**10 tests total for ~4,900 lines of billing code.**

`tests/billing/test_billing.py` — 5 tests: payment-method listing, and four
`settle_invoice` argument validations.
`tests/billing/test_pos.py` — 5 tests: vaccine consolidation, native
consultation line, unbillable line rejected, empty lines rejected, sequential
no-double-billing.

Untested entirely:
- **Refunds** — `create_credit_note`, partial returns, `_remaining_qty_by_row`, write-off reversal, POS vs non-POS cash paths. The most intricate code in the module has zero coverage.
- **Waivers / write-offs** — `_apply_waiver`, `_write_off_invoice`, `_reverse_write_off`, the remarks regex round-trip.
- **The invoice editor** — `create_sales_invoice`, per-line tax templates, per-line discounts, `Net Total` discount treatment, draft resume.
- **Insurance** — `_create_insured_invoice`, the coverage split, `patient_payable_amount`.
- **Every list endpoint** — pagination, scope guards, search, the `_serialize_invoice` write-off arithmetic.
- **Every report** — all four financial reports, including the AR-aging window bug (B-41), which a single test would have caught.

For contrast, `test_reschedule_payment.py` has 29 tests over one flow, and that
flow is correspondingly the most reliable money path in the codebase. That is
the standard the rest of billing should be held to.

---

# Suggested order

1. **B-29** (collect_payment scope guard) — a few lines, closes a real authorisation hole.
2. **B-21 / X-1** (savepoint the four write paths) — mechanical, removes the orphan-invoice class entirely.
3. **B-41** (AR aging window) — one filter change, fixes the report Phase 3's exit gate depends on.
4. **D-1 / B-45 / X-2** (stop reporting write-offs as revenue) — swap the reporting layer onto `real_cash_paid_bulk`.
5. **B-15** (vaccine billing failure surfaces) — reuse the existing refund-task mechanism.
6. **B-46** (refund task on appointment cancel) — same mechanism, same sitting.
7. **B-30 / X-4** (waiver approval + reason + register) — needs a product decision on who may waive; do the decision now, the code after.
8. **B-25 / X-3** (thread `company` through billing) — larger, touches every endpoint signature; schedule deliberately.
9. **B-22** (block rate override on insured lines), **B-32** (prorate discount on partial refund), **B-34** (reverse coverage on refund) — the insurance-money cluster.
10. **B-13** (stop lying about `billing_status`) — needs a patch and a cart-filter change.
11. **B-10 / B-12** (patient billing column + AR excluding credit notes).
12. **B-16** (retire the Flow-B endpoints), **B-23** (finish retiring drafts), **B-37 / B-36** (Payments tab completeness).
13. **B-38 … B-40** (claims) — Phase 3 remaining scope, not a bug.
14. Tests, alongside each fix above rather than as a separate phase.

---

# What is *not* a gap

Recorded so it is not re-litigated:

- **The refund engine's cash-vs-write-off separation.** `_real_cash_paid` never reads `grand_total − outstanding`, so a refund can never hand back money the clinic did not collect; `_reverse_write_off` cancels the forgiven portion through the accounting entry instead. This is genuinely hard and it is right.
- **Per-row return quantities via core's own `get_already_returned_items`.** Matching core's exact granularity means the API asks for what core will actually allow, instead of failing at submit.
- **No price tampering.** Every cart-sourced line's rate, income account and insurance fields come from the server-rebuilt cart; the client sends only the selection and (deliberately) qty.
- **`apply_discount_on = "Net Total"`** for CFDI treatment — correct for Mexico, and the reasoning is recorded at the call site.
- **Real per-item tax from `item_wise_tax_details`** rather than re-deriving from the header rate, with an honest `None` for genuinely mixed lines.
- **Elevated reads with unelevated writes** (`_aggregate_billables_elevated`) — the cart computation is elevated, the invoice is created as the real user, so the audit trail still names who billed.
- **Rule 1 throughout.** No core file is touched anywhere in the billing layer; every core limitation is worked around through documented core APIs.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Anant Sharma | Initial version (header backfilled from git history) |
