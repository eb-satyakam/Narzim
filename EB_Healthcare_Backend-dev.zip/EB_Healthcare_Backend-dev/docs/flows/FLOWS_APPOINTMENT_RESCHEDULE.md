# Appointment Reschedule Flow — Book Drawer Reuse + Payment Adjustment

**Doc status:** living · **Created:** 2026-08-13 by Anant Sharma · **Updated:** 2026-08-13 by Sarvesh-SocialAngel · **Version:** 1.0

Reschedule reuses the same "Book Appointment" drawer used to create a new
appointment (`NewAppointmentDialog`, `dialogMode="reschedule"`) instead of a
separate UI. Rescheduling to a new doctor/date/time/type recomputes the
consultation fee and settles exactly the difference against what has
actually already been paid — an additional payment if the new fee is
higher, a refund if lower, nothing if equal. The original invoice and
payment are never edited or deleted.

Endpoint: `remedisys_healthcare_ai.api.v1.appointments.api.reschedule_appointment_with_payment`
Route: `POST /api/appointments/{id}/reschedule-with-payment`
Doctype: `Appointment Reschedule History` (audit trail + idempotency key + payment-history source)

---

## 1. High-level flow

```mermaid
%%{init: {'theme':'dark'}}%%
sequenceDiagram
    participant FD as Front Desk (browser)
    participant BFF as Next.js BFF
    participant API as reschedule_appointment_with_payment
    participant Bill as services/billing.py
    participant DB as Patient Appointment / Sales Invoice / Payment Entry

    FD->>FD: Click "Reschedule" on a queue card
    FD->>BFF: GET appointment + patient (prefill)
    FD->>FD: Book drawer opens, dialogMode=reschedule<br/>patient locked, schedule step prefilled
    FD->>FD: Pick new doctor / date / time / type<br/>Payment-adjustment step shows live delta preview
    FD->>BFF: POST /reschedule-with-payment
    BFF->>API: reschedule_appointment_with_payment(...)
    API->>DB: Idempotency check (latest history row only)
    API->>DB: Reassign practitioner/type/department first (set_only_once)
    API->>DB: doc.save() — date/time (core slot-overlap validated against NEW practitioner)
    API->>Bill: adjust_payment_for_reschedule(old_paid, new_fee)
    alt delta > 0
        Bill->>DB: New standalone Sales Invoice for the DELTA only
        opt pay_now
            Bill->>DB: settle_invoice() → Payment Entry
        end
    else delta < 0
        Bill->>DB: Credit Note (value-sized) against the ORIGINAL invoice
        Bill->>DB: Refund Payment Entry (type "Pay"), mode defaulted to original payment mode
    else delta == 0
        Bill-->>API: no document created
    end
    API->>DB: Insert Appointment Reschedule History row
    API-->>BFF: {appointment, history, old, new, adjustment}
    BFF-->>FD: success — old vs new + adjustment shown, queue refreshed
```

---

## 2. Frontend — same drawer, mode-gated

File: `src/components/narzim/dashboard/new-appointment-dialog.tsx`
Wrapper: `src/components/narzim/dashboard/reschedule-dialog.tsx` (fetches appointment + patient, builds the prefill, renders the drawer — same `{appointmentId, onClose, onDone}` props the old standalone dialog had, so the call site in `mission-control-client.tsx` needed no changes)

`NewAppointmentDialog` takes a `dialogMode: "book" | "reschedule"` prop. All four steps are reused; only what differs is gated on `isReschedule`:

| Step | Book mode | Reschedule mode |
|---|---|---|
| 1. Patient | Search / create / lock in | **Locked** — no "Change" button (patient search hidden); visit-type grid + reason field unchanged |
| 2. Schedule | Department → Practitioner (All/Specific toggle) → Date → Time | Same fields, **prefilled** from the current appointment (practitioner name in the search box, current date). Practitioner mode is forced to "Specific" (no All/Specific toggle) and **always opens showing every practitioner**, never pre-filtered to just the current one. A "Current appointment" reference card (old date/time/doctor) sits above the fields, since the new date/time always starts blank — a fresh availability query can't know to exclude the appointment's own current slot, so a slot must always be re-picked. |
| 3. Payment | Fee / discount / insurance / pay-now-or-later | **Replaced** with a payment-ADJUSTMENT panel: Previous fee → Already paid → New fee (live, tracks the selected practitioner), then Additional-amount-due / Refund-amount / No-adjustment depending on the sign of the delta. An additional payment gets a Pay-now/Pay-later choice + method; a refund always settles immediately (no timing choice, mirrors the existing manual refund flow). |
| 4. Confirm | Booking summary | Old → New comparison (type, date, time, practitioner — same date/time format on both sides of the arrow) + the payment adjustment. Button reads "Confirm Reschedule". |

`onConfirmReschedule` payload → `useRescheduleWithPayment()` hook → `appointmentsApi.rescheduleWithPayment()` → `POST /api/appointments/{id}/reschedule-with-payment`.

---

## 3. Backend — `reschedule_appointment_with_payment`

File: `remedisys_healthcare_ai/api/v1/appointments/api.py`

1. **Validate**: appointment exists, not Cancelled/Closed/Checked Out. If the practitioner is changing: role-gated to front desk/admin (`_REASSIGN_ROLES`), must be in `_REASSIGNABLE_STATUSES`, and no non-cancelled encounter can already exist.
2. **Idempotency**: compare the requested target (practitioner/date/time/type) against only the **most recent** `Appointment Reschedule History` row for this appointment — not any historical row. If it matches, replay that row's result instead of reprocessing. (Matching against *any* row, not just the latest, would wrongly treat "reschedule back to a slot visited earlier" as a duplicate of that earlier visit and skip a payment adjustment that's actually needed.)
3. **Snapshot old state**: practitioner, date/time/type/department, the fee actually charged (real invoice's `grand_total` if invoiced, else resolved/override), and `old_paid_amount` via `billing_service.total_paid_for_appointment()`.
4. **Mutate** (inside `frappe.db.savepoint("reschedule_payment_txn")`):
   - `practitioner`, `appointment_type`, and `department` are all `set_only_once` on core Healthcare's Patient Appointment — written through `frappe.db.set_value` (bypassing the doctype-level restriction) **before** the date/time save, then `doc.reload()`. Order matters: core's slot-overlap validation runs at `doc.save()` time and checks whichever practitioner is on the doc *at that moment* — saving with the old practitioner still in place would validate the new slot against the wrong doctor's schedule.
   - `doc.appointment_date` / `doc.appointment_time` / `doc.service_unit` (not `set_only_once`) set normally, then `doc.save()`.
5. **Resolve new fee**: `billing_service.resolve_consultation_fee(new_practitioner, new_type, override=fee_override)` — practitioner's own charge first, then the Appointment Type's, then the front-desk override if supplied.
6. **Settle the delta**: `billing_service.adjust_payment_for_reschedule()` — see §4.
7. **Insert** the `Appointment Reschedule History` row (old/new snapshot, delta, adjustment type/status, linked invoice/credit-note/payment-entry).
8. **Commit** once, outside the try block (same convention as `book_appointment_for_patient`).

Companion read endpoint: `get_reschedule_history(appointment)` — every event for an appointment, oldest first; backs both the appointment-history timeline and the payment-history table (same rows, two renderings).

---

## 4. The money side — `services/billing.py`

```
delta = new_fee − old_paid_amount
```

| Delta | Action | Function |
|---|---|---|
| `> 0` (owe more) | New **standalone** Sales Invoice for exactly the delta (never touches the original invoice). Settled immediately via the existing `settle_invoice()` if `payment_timing == "pay_now"`, else left outstanding. | `_create_reschedule_delta_invoice` |
| `< 0` (owe back) | Credit Note against the **original** invoice, sized by **value** (one refundable row, `qty=-1`, `rate` overridden to the refund amount) rather than by quantity — refunding an arbitrary cash amount, not a whole-unit multiple. Cash-refunded immediately via a `Payment Entry` (`payment_type="Pay"`), defaulted to however the original invoice was actually paid (its POS-embedded mode, or its Payment Entry's mode) since the UI never asks. | `_create_reschedule_refund` |
| `== 0` | Nothing created. | — |

**`total_paid_for_appointment(appointment, original_invoice)`** — the "already paid" side of the formula, and the single most important fix in this feature:

```
paid = (original_invoice.grand_total − original_invoice.outstanding_amount)
      + Σ delta_amount of every prior history row with status Paid/Refunded
```

`grand_total − outstanding_amount` is read directly off the invoice — correct regardless of *how* it was paid (POS-embedded payment with no separate Payment Entry document at all, one Payment Entry, or several). Summing `Payment Entry Reference` rows (the original, buggy implementation) misses POS-embedded payments entirely, since no Payment Entry document exists for them at all.

**Known limitation**: this does not see a credit note issued *outside* this flow (e.g. a manual refund via the Billing tab, unrelated to any reschedule) against the same invoice — a credit note doesn't change the original invoice's own `outstanding_amount`. A manual refund followed by a reschedule of the same appointment would under-count what's actually been returned. Fixing this generally (without double-counting this feature's own refunds) needs a small redesign; flagged, not yet implemented.

**Item resolution** for the delta invoice: `_consultation_charge_item(practitioner, appointment_type)` — practitioner's `op_consulting_charge_item` first, then the Appointment Type's. Neither configured → throws rather than silently invoicing with no item.

**Traceability**: neither the delta invoice nor the credit note is linked via `reference_dt`/`reference_dn` back to the Patient Appointment — doing so would re-trigger Healthcare's "already invoiced" on-submit check (the appointment is already marked invoiced against its *original* invoice). The link lives structurally in `Appointment Reschedule History` instead.

---

## 5. Data model — `Appointment Reschedule History`

One row per completed reschedule event. Not an accounting doctype — a log/link that ties a scheduling change to whichever real Sales Invoice / Payment Entry / Credit Note resulted, and does three jobs:

1. **Idempotency key** — §3 step 2 reads this table to detect a retried request.
2. **Audit trail** — the only place that connects "appointment moved from Dr. X to Dr. Y" to "here is exactly which invoice/credit-note/payment resulted and why." Used directly to diagnose every bug found while building this feature (queried live, not just in theory).
3. **Running payment total** — `total_paid_for_appointment()` sums this table's settled `delta_amount` values on top of the original invoice, so a *second* reschedule of the same appointment starts from the correct baseline.

Key fields: `old_*`/`new_*` (practitioner, date, time, type, department, fee), `old_paid_amount`, `delta_amount` (signed: positive = additional payment, negative = refund — this sign convention is what the running-total sum in point 3 depends on), `adjustment_type` (None/Additional Payment/Refund), `adjustment_status` (Not Required/Pending/Paid/Refunded/Failed), `additional_invoice`/`additional_payment_entry`, `refund_credit_note`/`refund_payment_entry`, `notes`.

---

## 6. Edge cases covered (tests: `tests/appointments/test_reschedule_payment.py`)

- Same fee → no adjustment created.
- Higher fee, fully paid original → additional payment for the difference (not the full new fee).
- Lower fee, fully paid original → refund for the difference.
- Partially paid original → additional payment for `new_fee − partial_paid`.
- Unpaid original → additional payment for the full new fee.
- Multiple Payment Entries against the original invoice → summed correctly (`outstanding_amount` reflects all of them regardless of count).
- **POS-embedded payment** (a real "pay now" booking, no separate Payment Entry document at all) → recognized as paid; the delta is still just the difference, not the full new fee.
- **Practitioner change validates against the correct doctor** — an old-practitioner conflict at the target slot must not block a move to a practitioner who has no such conflict (and vice versa: must not silently miss a real conflict against the new practitioner).
- **Returning to a previously-visited exact slot** (A → B → C → B) is processed as a fresh transition, not replayed from the stale first A→B record.
- **Refund defaults to the original payment mode** rather than leaving the refund Payment Entry's `mode_of_payment` blank.
- **`appointment_type` can be changed** (and `department`) — both are `set_only_once`, same fix as the practitioner-ordering one.
- Retried identical request → idempotent, no duplicate history row / payment / refund.

---

## 7. Files

**Backend**
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/appointment_reschedule_history/` — new doctype
- `remedisys_healthcare_ai/services/billing.py` — `resolve_consultation_fee`, `_consultation_charge_item`, `get_actual_paid_amount`, `total_paid_for_appointment`, `_create_reschedule_delta_invoice`, `_invoice_payment_mode`, `_create_reschedule_refund`, `adjust_payment_for_reschedule`
- `remedisys_healthcare_ai/api/v1/appointments/api.py` — `reschedule_appointment_with_payment`, `get_reschedule_history`, `_history_response`
- `remedisys_healthcare_ai/tests/appointments/test_reschedule_payment.py`

**Frontend** (`remedisys-ai-ehr`)
- `src/components/narzim/dashboard/new-appointment-dialog.tsx` — `dialogMode`/`rescheduleAppointment`/`onConfirmReschedule` props, reschedule-only JSX branches
- `src/components/narzim/dashboard/reschedule-dialog.tsx` — prefill-fetching wrapper (same props as before)
- `src/components/shared/phone-country-select.tsx` — unrelated fix surfaced during testing (searchable country picker, guardian/contact phone fields)
- `src/types/appointments.ts` — `RescheduleSide`, `RescheduleAdjustment`, `RescheduleWithPaymentResult`
- `src/lib/api/appointments.ts` — `rescheduleWithPayment`
- `src/hooks/use-appointments.ts` — `useRescheduleWithPayment`
- `src/app/api/appointments/[id]/reschedule-with-payment/route.ts` — BFF route
- `messages/en.json`, `messages/es.json` — `newAppt.reschedule*` keys

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
