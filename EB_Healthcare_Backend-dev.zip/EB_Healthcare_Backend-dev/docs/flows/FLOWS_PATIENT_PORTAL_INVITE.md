# Patient portal invite & email-collision flow

**Doc status:** living · **Created:** 2026-07-16 by Sarvesh-SocialAngel · **Updated:** 2026-07-16 by Sarvesh-SocialAngel · **Version:** 1.0

Status: implemented 2026-07-16.

## Purpose

Defines exactly which email is sent — and how a login's roles change — when a
Patient is created with an email, covering the three cases: brand-new email,
email that already belongs to a patient login, and email that already belongs
to a **staff** login.

Backdrop: the register-patient dialog auto-sends `invite_user: true` whenever an
email is present, and the front end auto-sends `link_existing_user: true` (no
confirmation dialog) so a duplicate email links instead of failing. Password
links point at the **patient portal** (`patient_portal_url`, port 3003), never
the Frappe desk `/update-password` page (see `FLOWS_AUTH.md`,
`_portal_base_url`).

## The three cases

| Case | Existing `User` for the email? | What happens to the login | Email sent |
|---|---|---|---|
| **A. New email** | none | new Website User created, role → `EB_Patient` | **Set-password welcome** (branded, `/set-password?key=` link to the patient portal) |
| **B. Existing patient login** | yes, non-staff | patient linked to it; `EB_Patient` ensured | **Portal-access notice** (welcome, **no** password link) |
| **C. Existing staff login** | yes, has a staff `EB_` role | patient linked to it; `EB_Patient` **added** — staff roles **kept** (dual role) | **Portal-access notice** (welcome, **no** password link) |

Key rules (per product decision 2026-07-16):

1. **Never send a set-password / reset link to an account that already exists.**
   It already has a password; a link would be a needless reset vector. Existing
   accounts (B and C) get a plain welcome/notice email instead.
2. **Staff roles are preserved.** When a patient's email collides with a staff
   login, `EB_Patient` is *added*, not substituted — the person keeps clinic
   access and gains portal access (dual role). Previously the role-normalisation
   hook overwrote the login to `EB_Patient`-only, silently stripping staff
   access; that is fixed here.
3. **The built-in Frappe `Patient` role is still removed** (it carries
   `desk_access=1` and would promote the user to System User — see
   `patches/v0/fix_customer_role_desk_access_20260716.py`). Only that one role
   is stripped; every `EB_` role is kept.

## Implementation

- `overrides/patient_duplicate_check.py` — `create_website_user()`:
  - **new email** → create user, `send_welcome_email=False` (suppress Frappe
    core's unbranded mail), then `send_set_password_email(..., portal="patient")`.
  - **existing email + `link_existing_user`** → `db_set("user_id", existing)`,
    then `send_portal_access_notice(existing, ..., portal="patient")` (no key,
    no link). Role changes are handled by the on_update hook below.
- `overrides/patient_user_roles.py` — `fix_patient_website_user_roles()`:
  additive. Desired role set = `(current roles − {built-in "Patient"}) ∪
  {EB_Patient}`. Keeps staff `EB_` roles intact; only removes the built-in
  `Patient` role and guarantees `EB_Patient` is present.
- `api/v1/admin/_helpers.py`:
  - `_portal_base_url(portal)` — staff vs patient frontend base URL.
  - `_send_portal_welcome(...)` / `send_set_password_email(...)` — branded
    **set-password** mail (with `/set-password?key=` link). Used for NEW logins
    only (invite_staff, create_practitioner, new-email patient).
  - `send_portal_access_notice(...)` — branded **welcome/notice** mail with **no**
    password link, for a login that already exists. Template
    `templates/emails/portal_access_notice.html`.

## Verification

`bench --site marley.local console`:
1. New-email patient → user `send_welcome_email=0`; queued mail = set-password
   link to `patient_portal_url`.
2. Patient on an existing **staff** email → login keeps its staff role AND gains
   `EB_Patient`; queued mail = portal-access notice with **no** `key=` link.
3. Patient on an existing **patient** email → `EB_Patient` present; notice mail,
   no link.

## Known follow-up

Any staff login already corrupted before this change (role overwritten to
`EB_Patient`-only by the old hook — e.g. `sarveshshahi767@gmail.com`) must have
its staff role re-added manually; the original role can't be recovered from the
overwritten record.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-16 | Sarvesh | Initial version (header backfilled from git history) |
