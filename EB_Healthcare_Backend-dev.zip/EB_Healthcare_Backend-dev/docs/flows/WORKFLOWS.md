# Remedisys — Backend Workflows

**Doc status:** living · **Created:** 2026-06-04 by Sarvesh-SocialAngel · **Updated:** 2026-06-20 by Sarvesh-SocialAngel · **Version:** 1.0

End-to-end request flows through the backend. Every flow shows the exact
API call the frontend makes and the path it takes through the backend layers.

**Last updated:** 2026-06-19
**Legend:** ✅ built · 🔲 Phase 4 (not started)

---

## 1. Authentication Flow

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'activationBkgColor': '#1e3a5f', 'noteBkgColor': '#1e3a5f', 'noteTextColor': '#93c5fd'}}}%%

sequenceDiagram
    autonumber
    actor U as 👤 User
    participant FE as 🖥️ Next.js BFF
    participant OA as 🔐 Frappe OAuth2
    participant API as 🟢 api/v1/auth/api.py
    participant DB as 🗄️ MariaDB

    rect rgb(14, 42, 71)
        Note over U,DB: ── Step 1: OAuth2 Token Exchange ──────────────────────────
        U->>FE: POST /api/auth/login { email, password }
        FE->>OA: POST /oauth2/get_token<br/>{ username, password, grant_type: password,<br/>  client_id, client_secret, scope: "all openid" }
        OA->>DB: validate user + enabled check + roles lookup
        DB-->>OA: ✅ user valid
        OA-->>FE: { access_token, refresh_token, expires_in: 3600 }
    end

    rect rgb(20, 83, 45)
        Note over U,DB: ── Step 2: Session Profile ────────────────────────────────
        FE->>API: GET /api/method/...get_current_user<br/>Authorization: Bearer <access_token>
        API->>DB: get_doc("User") + roles + Healthcare Practitioner
        DB-->>API: user doc + practitioner profile
        API-->>FE: { name, email, roles[], practitioner }
        Note over FE: Store tokens in NextAuth encrypted session<br/>Browser only ever sees httpOnly cookie
        FE-->>U: Set-Cookie: next-auth.session → redirect to role dashboard
    end
```

---

## 2. Every Authenticated API Call

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#22c55e', 'signalTextColor': '#86efac', 'activationBkgColor': '#14532d', 'noteBkgColor': '#1e3a5f', 'noteTextColor': '#93c5fd'}}}%%

sequenceDiagram
    autonumber
    participant FE as 🖥️ Next.js API Route
    participant FR as ☁️ Frappe
    participant API as 🔵 api/v1/<module>/api.py
    participant PERM as 🔑 require_permission()
    participant SVC as 🟢 services/<module>.py
    participant DB as 🗄️ MariaDB

    FE->>FR: POST /api/method/remedisys_healthcare_ai.api.v1.<module>.api.<fn><br/>Authorization: Bearer token
    Note over FR: validate token → set frappe.session.user
    FR->>API: call whitelisted method
    API->>PERM: require_permission(doctype, "read")
    alt Permission denied
        PERM-->>FE: 403 PermissionError
    else Permission granted
        PERM-->>API: ✅ continue
        API->>SVC: delegate with cleaned args
        SVC->>DB: frappe.get_all() / frappe.get_doc()
        DB-->>SVC: result set
        SVC-->>API: processed result
        API-->>FE: { data: [...], total, page, page_size }
    end
```

---

## 3. Patient Registration

> **Status:** ✅ Built — `api/v1/patients/api.py` (2,180+ lines). Full CRUD + Patient 360 tabs.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'activationBkgColor': '#1e3a5f'}}}%%

sequenceDiagram
    autonumber
    participant FE as 🖥️ Frontend Form
    participant API as 🔵 api/v1/patients
    participant SVC as 🟢 services/patients.py
    participant DB as 🗄️ MariaDB

    FE->>API: create_patient({ name, dob, sex, phone, email })
    API->>API: require_permission("Patient", "create")
    API->>SVC: PatientService.create(data)
    SVC->>SVC: validate required fields<br/>check duplicate phone/email<br/>assign patient_name from first+last
    SVC->>DB: frappe.get_doc("Patient").insert()
    DB-->>SVC: { name: "PAT-0001", patient_name: "..." }
    SVC-->>API: patient doc
    API-->>FE: { data: { name, patient_name, mrn } }
```

---

## 4. Appointment Booking

> **Status:** ✅ Built — `api/v1/appointments/api.py` (1,208 lines). Full booking lifecycle including atomic `book_appointment_for_patient`.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'activationBkgColor': '#1e3a5f'}}}%%

sequenceDiagram
    autonumber
    participant FE as 🖥️ New Appointment Dialog
    participant API as 🔵 api/v1/appointments
    participant SVC as 🟢 services/appointments.py
    participant DB as 🗄️ MariaDB

    FE->>API: get_available_slots(practitioner, date)
    API->>SVC: AppointmentService.get_slots(...)
    SVC->>DB: query Healthcare Practitioner Schedule
    DB-->>SVC: slot grid
    SVC-->>FE: { slots: [{ time, available }] }

    FE->>API: book_appointment({ patient, practitioner, date, time, visit_type })
    API->>API: require_permission("Patient Appointment", "create")
    API->>SVC: AppointmentService.book(data)
    SVC->>SVC: validate slot still available<br/>check no duplicate for same patient+date
    SVC->>DB: frappe.get_doc("Patient Appointment").insert()
    DB-->>SVC: { name: "APP-0001", status: "Open" }
    SVC->>SVC: schedule WhatsApp D-1 reminder
    SVC-->>FE: { name, status, appointment_date, appointment_time }
```

---

## 5. Patient Check-in

> **Status:** ✅ Built — `check_in_patient()` in `api/v1/appointments/api.py`

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1'}}}%%

sequenceDiagram
    autonumber
    participant FD as 🖥️ Front Desk
    participant API as 🔵 api/v1/appointments
    participant SVC as 🟢 services/appointments.py
    participant DB as 🗄️ MariaDB

    FD->>API: check_in_patient({ appointment: "APP-0001" })
    API->>API: require_permission("Patient Appointment", "write")
    API->>SVC: AppointmentService.check_in("APP-0001")
    SVC->>DB: get_doc("Patient Appointment", "APP-0001")
    DB-->>SVC: appointment doc
    SVC->>SVC: validate status == "Open"<br/>set status = "Checked-in"<br/>record checked_in_at timestamp
    SVC->>DB: doc.save()
    SVC-->>FD: { status: "Checked-in", checked_in_at }

    Note over FD: 5-second undo window in UI<br/>Nurse queue updates via polling
```

---

## 6. Clinical Encounter

> **Status:** ✅ Built — `api/v1/encounters/api.py` (1,075 lines). Full encounter lifecycle with SOAP JSON storage.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'activationBkgColor': '#1e3a5f'}}}%%

sequenceDiagram
    autonumber
    participant DR as 🩺 Doctor
    participant API as 🔵 api/v1/encounters
    participant SVC as 🟢 services/encounters.py
    participant DB as 🗄️ MariaDB

    DR->>API: create_encounter({ patient, appointment, practitioner })
    API->>API: require_permission("Patient Encounter", "create")
    API->>SVC: EncounterService.create(data)
    SVC->>DB: frappe.get_doc("Patient Encounter").insert()<br/>status = "In Progress"
    DB-->>SVC: { name: "ENC-0001" }
    SVC-->>DR: { encounter_name, status }

    Note over DR: Doctor fills: chief complaint,<br/>diagnosis, prescriptions, lab orders

    DR->>API: save_draft({ encounter, fields... })
    API->>SVC: EncounterService.save_draft(data)
    SVC->>DB: doc.save() (stays In Progress)
    SVC-->>DR: { status: "In Progress" }

    DR->>API: complete_encounter({ encounter })
    API->>SVC: EncounterService.complete(encounter)
    SVC->>SVC: validate: chief complaint present<br/>at least one diagnosis required<br/>all lab orders dispatched
    SVC->>DB: doc.status = "Completed" → doc.submit()
    SVC->>SVC: trigger billing reminder event
    SVC-->>DR: { status: "Completed" }
```

---

## 7. Lab Order and Result

> **Status:** ✅ Partially built — `create_lab_order` and `list_patient_labs` exist. Result entry (`record_result`, `collect_sample`, `mark_result_reviewed`) is deferred to Phase 4.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1'}}}%%

sequenceDiagram
    autonumber
    participant DR as 🩺 Doctor
    participant RN as 💉 Nurse/Lab
    participant API as 🔵 api/v1/labs
    participant SVC as 🟢 services/labs.py
    participant DB as 🗄️ MariaDB

    DR->>API: order_lab_test({ encounter, template, patient })
    API->>SVC: LabService.order(data)
    SVC->>DB: frappe.get_doc("Lab Test").insert()<br/>status = "Ordered"
    SVC-->>DR: { lab_test_name, status: "Ordered" }

    Note over RN: Lab collects sample
    RN->>API: update_lab_status({ lab_test, status: "Sample Collected" })
    API->>SVC: LabService.update_status(data)
    SVC->>DB: doc.status = "Sample Collected" → save()

    Note over RN: Lab enters results
    RN->>API: record_result({ lab_test, result_values[] })
    API->>SVC: LabService.record_result(data)
    SVC->>DB: save result values + status = "Completed"
    SVC->>SVC: flag abnormal values<br/>notify ordering practitioner
    SVC-->>RN: { status: "Completed", has_abnormal: true }
```

---

## 8. Billing and Payment

> **Status:** ✅ Built — `api/v1/billing/api.py` (690 lines) + `services/billing.py` (301 lines). Delegates to ERPNext core invoice builders; no custom accounting.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1'}}}%%

sequenceDiagram
    autonumber
    participant FD as 🖥️ Front Desk
    participant API as 🔵 api/v1/billing
    participant SVC as 🟢 services/billing.py
    participant DB as 🗄️ MariaDB

    Note over FD: After encounter completes — billing banner fires
    FD->>API: get_invoice({ encounter })
    API->>SVC: BillingService.get_or_create_invoice(encounter)
    SVC->>DB: check existing Sales Invoice for encounter<br/>if none → create from encounter fees
    DB-->>SVC: invoice doc
    SVC-->>FD: { invoice, line_items[], total_due }

    FD->>API: record_payment({ invoice, amount, method })
    API->>API: require_permission("Payment Entry", "create")
    API->>SVC: BillingService.record_payment(data)
    SVC->>DB: create Payment Entry → link to invoice
    SVC->>SVC: check if fully paid → mark invoice Paid
    SVC->>SVC: send receipt via WhatsApp/email
    SVC-->>FD: { status: "Paid", receipt_sent: true }
```

---

## 9. AI Encounter Session (Phase 5 — Locked)

> These APIs exist in `api/ai/` and are fully implemented. They are **not exposed to
> the frontend** until the AI phase resumes. Do not modify these files.

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#9ca3af', 'primaryBorderColor': '#6b7280', 'lineColor': '#374151', 'actorBkg': '#111827', 'actorBorder': '#374151', 'actorTextColor': '#9ca3af', 'signalColor': '#6b7280', 'signalTextColor': '#9ca3af', 'noteBkgColor': '#1c1917', 'noteTextColor': '#9ca3af'}}}%%

sequenceDiagram
    autonumber
    actor DR as 🩺 Doctor
    participant FE as 🖥️ AI Sidebar (React)
    participant API as 🔴 api/ai/sessions.py
    participant DG as 🌐 Deepgram
    participant SEG as 🔴 api/ai/segments.py
    participant DB as 🗄️ MariaDB

    Note over DR,DB: LOCKED — not in scope until Phase 5

    DR->>FE: Click "Start Recording" (with consent)
    FE->>API: create_session({ encounter, consent: true })
    API->>DB: insert AI Encounter Session (Draft)
    API-->>FE: { session_id, deepgram_token }
    FE->>DG: Open WebSocket with scoped token
    Note over FE: MediaRecorder → audio chunks → Deepgram WS
    DG-->>FE: finalized transcript segment
    FE->>SEG: append_segment({ session, sequence_number, text, speaker })
    SEG->>DB: insert AI Transcript Segment (append-only)
    DR->>FE: Click "Stop"
    FE->>API: stop_session({ session_id })
    API->>DB: status = "Stopped" + ended_at
    Note over API: Triggers SOAP generation pipeline (async)
```

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-04 | Sarvesh | Initial version (header backfilled from git history) |
