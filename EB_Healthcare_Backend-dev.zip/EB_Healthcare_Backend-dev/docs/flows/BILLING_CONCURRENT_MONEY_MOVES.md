# Two Refunds or Payments at Once on the Same Bill

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

Design note for the product owner. The decision is
[ADR-118](../adr/adr-118-lock-the-bill-before-moving-money.md).

## 1. In one paragraph

Each money step reads the bill, decides, and then writes:

- a refund: "is anything left to refund?";
- a payment: "how much is still owed?";
- a reschedule: "what has this appointment paid?".

Nothing stops a second request from making the same decision in between. Two Refund clicks, or
two clerks on one bill, can both pass the check and both pay out. This note makes every money
step take the bill first and refuse when someone else changed it in the meantime.

## 2. What happens today (verified in code, 2026-10-01)

| Step | Reads | Then writes | Code |
|---|---|---|---|
| Collect a payment | outstanding | Payment Entry | `services/billing.py::settle_invoice` |
| Refund a bill | cash paid, earlier Credit Notes | Credit Note + refund Payment Entry | `services/billing.py::create_credit_note` |
| Refund a cancelled appointment | the refund plan | one Credit Note per bill | `services/billing.py::refund_appointment` |
| Reschedule with payment | what was paid; the last history row (its double-click guard) | invoices, Credit Notes, history row | `api/v1/appointments/api.py::reschedule_appointment_with_payment` |

`services/billing.py` takes no row lock anywhere. No test sends two requests at once. ERPNext's
own "already returned" check does not help, because each request cannot see the other's
uncommitted Credit Note.

**Example.** A 1,000 bill, fully paid. Clerk A and Clerk B both click Refund.

1. Both read: 1,000 paid, 0 refunded.
2. A writes a Credit Note and pays back 1,000.
3. B writes a Credit Note and pays back 1,000.

The clinic hands back 2,000 — unless something else stops B.

Measured on this dev site (2026-10-01, the tests in §6 run on the old code): B does fail, but by
accident. It is refused by MariaDB when it draws the next Credit Note number, because A changed
the same naming-series row (`tabSeries`, error 1020). The clerk gets a 500. That accident needs
both requests on the same naming series and `innodb_snapshot_isolation` on. Production's setting
is UNVERIFIED. It is very likely the "tabSeries deadlock" two real requests on this site have hit.

## 3. Why a plain lock is not enough here

The site runs MariaDB at `REPEATABLE-READ` with `innodb_snapshot_isolation = 1` (measured
2026-10-01). Every request reads from a snapshot taken at its first query.

`SELECT … FOR UPDATE` makes B wait for A. B then carries on with its old snapshot, where A's
Credit Note does not exist. So a lock alone still refunds twice.

The lock therefore comes with a check. B compares the bill as its snapshot shows it with the bill
as the lock returns it. If they differ, B stops instead of deciding on stale numbers.

## 4. The rule

Before any money step reads a bill, it calls `lock_for_money(doctype, name)` on that bill (or on
the appointment, for a reschedule or appointment refund). The helper does three things:

1. **Waits** for any other money step on the same row (`FOR UPDATE`).
2. **Refuses** with HTTP 409 "This bill was just changed by someone else — refresh and try again"
   when the row changed after this request began. With snapshot isolation on, MariaDB raises this
   itself (`ER_CHECKREAD`, which Frappe treats as a deadlock); the explicit comparison covers a
   server with it off.
3. **Marks** the row (`modified`), so a request waiting behind this one sees that it changed.

The lock is released when the request commits or rolls back. A failed step leaves no lock and no
mark.

| Request | Gets |
|---|---|
| The first click | the normal result |
| A second click on the same bill at the same time | 409 "just changed", and nothing written |
| A click after the first has finished | the normal refusal, e.g. "Nothing left to refund" |

## 5. What must not break

| # | Risk | Guard |
|---|---|---|
| C1 | A document loaded before the lock and then `save()`d trips Frappe's timestamp check, because the mark changes `modified` | Lock **before** loading: `reschedule_appointment_with_payment` takes it before `frappe.get_doc`. The money steps only `db_set` the invoice |
| C2 | Locking the same bill twice in one request (`refund_appointment` → `create_credit_note`) | Re-entrant: the request sees its own mark, so the check passes |
| C3 | Two steps locking two bills in opposite order deadlock | A step locks one appointment, or its bills in a fixed order (sorted by name). A deadlock is still reported as 409, never a 500 |
| C4 | A long step makes the other clerk wait | Steps take well under a second; MariaDB gives up after 50 s (`innodb_lock_wait_timeout`) and the helper reports 409 |
| C5 | Tests run in one connection | The check passes when nothing else changed the row, so the existing suites see no difference |

## 6. Tests

`tests/billing/test_concurrent_money_moves.py` runs the second request on a second database
connection, in a thread.

1. A refund committed by another request after this one began: this request's refund gets 409.
   One Credit Note exists, and 1,000 was paid back once.
2. The same for a payment: two 500 collections on a 500 balance. One Payment Entry, 0 owing.
3. The same for refunding a cancelled appointment.
4. A refund with nothing in the way still works, including the re-entrant lock (C2).

## 7. Not in this change

- The POS checkout cart (`create_pos_invoice`) is a different double-submit question: one cart,
  two invoices. It is tracked with the half-written checkout gap.
- Disabling the Confirm button while a request is in flight is a frontend change in the same
  branch pair. It cuts a single person's double-click, but cannot stop two clerks.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | First version: the race, why a plain lock fails at REPEATABLE-READ, the lock-and-check rule, and the old code's measured behaviour |
