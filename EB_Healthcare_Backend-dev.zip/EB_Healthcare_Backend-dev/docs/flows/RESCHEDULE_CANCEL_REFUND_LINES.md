# Reschedule, Cancel and Refund Touch Only the Appointment's Own Line

**Doc status:** living · **Created:** 2026-09-30 by Divyanshu (AI-assisted) · **Updated:** 2026-09-30 by Divyanshu (AI-assisted) · **Version:** 1.3

Design note for the product owner and the clinic's accountant. The decision is recorded as
[ADR-114](../adr/adr-114-appointment-line-owns-its-money.md). What was built, and what was left for
the accountant, is in §9; the open questions are in §8.

## 1. In one paragraph

When an appointment is rescheduled to a cheaper slot, the system gives the difference back by
"returning" the invoice's first line at a lower price. That uses up the line, so a later
cancellation cannot refund what is left. It can also use up the wrong line (a vaccine instead of
the appointment). Separately, cancelling an unpaid appointment cancels the whole invoice, including
vaccines, medicines and the patient's other appointments on it. The proposal is one rule: **every
reschedule, cancellation and refund touches only the line of the appointment it is about.**

## 2. What happens today (verified in code and data, 2026-09-30)

| # | Problem | Where | Evidence |
|---|---|---|---|
| P1 | A cheaper reschedule refunds by returning a line **in full quantity** at a lower rate (`row.qty = -1`, rate overridden). ERPNext allows each unit to be returned once, so the line is used up and a later cancel finds "Nothing left to refund" | `services/billing.py::_create_reschedule_refund` (1971–2063) | ACC-SINV-2026-00760: 1,000 paid, Credit Note ACC-SINV-2026-00840 of −420 returned 1 of 1 units; `get_refundable_items` returns nothing. 8 submitted "Reschedule refund" Credit Notes on the dev site |
| P2 | The returned line is the **first line with quantity left**, in document order, not the appointment's line. The docstring says it prefers the consultation line; the code does not | `services/billing.py:1998` | Code reading. The *amount* is correctly capped to the appointment's share (`_appointment_funding`, 1680) |
| P3 | Cancelling an appointment whose linked invoice is **unpaid** cancels the **whole** invoice | `api/v1/appointments/api.py::cancel_unpaid_invoice_for_appointment` (2435–2474, `inv.cancel()` at 2470) | Code reading. 22 invoices on the dev site carry 2+ appointments (all for one patient each) |

What already works and is kept:

- Each appointment has its own line on a shared invoice (`reference_dt = "Patient Appointment"`,
  `reference_dn = <appointment>`), and `appointment_invoice_share` (`services/billing.py:1486`)
  already computes one appointment's billed and paid share of a shared invoice.
- A dearer reschedule raises a separate **delta invoice** (`_create_reschedule_delta_invoice`,
  1866), deliberately **not** linked by `reference_dt/dn`, because Healthcare's submit hook would
  reject it as "already invoiced"; the link lives in `Appointment Reschedule History`.
- Refunds of paid invoices go through `create_credit_note`, which since today prorates an
  invoice-level discount per line and hides Refund when nothing is left (`fully_refunded`).

## 3. The rule

> **An appointment's money lives on its own line.** A reschedule replaces that line, a cancellation
> refunds or removes that line, and nothing else on the invoice is touched. Vaccines, medicines,
> lab tests and other appointments on the same invoice move only when the front desk selects them
> in the Refund dialog.

## 4. Proposed behaviour

### 4.1 Cheaper reschedule (replaces P1 and P2)

Example: Consultation 500 + Vaccine 400 = 900 paid; the appointment moves to a 300 slot.

1. **Credit Note for the appointment's line only**, full quantity at its **full** (discounted)
   value: −500. This is an ordinary `create_credit_note` partial return of that one line; the line is
   found by `reference_dn`, never by position.
2. **New invoice for the new fee**: 300, linked the same way delta invoices are today (no
   `reference_dt/dn`; recorded in `Appointment Reschedule History`).
3. **Pay the new invoice from the credit**: allocate 300 of the Credit Note's −500 against the new
   invoice (ERPNext Payment Reconciliation of a return against an invoice). No cash moves for this part.
4. **Cash back the difference**: 200 via a Payment Entry against the Credit Note, as refunds do today.

Result: the vaccine line is untouched, and the appointment's money now sits on a clean 300 invoice
that a later cancellation refunds normally.

### 4.2 Cancellation of a paid appointment

The Refund dialog opens from the cancellation with **only this appointment's current line
pre-selected**: its original line if never rescheduled, else the newest replacement or delta
invoice. Other lines stay available but unticked.

### 4.3 Cancellation of an unpaid appointment (replaces P3)

- Invoice holds **only** this appointment → cancel the invoice (today's behaviour).
- Invoice holds **other lines too** → remove only this appointment's line. Two ways, see Q2 in §8.

### 4.4 Unchanged

Same-price reschedule (nothing), dearer reschedule (delta invoice, pay now or later), Government /
waiver (no cash), partly paid invoices (flagged for the front desk, see Q5).

## 5. Every case

Single-appointment invoice with extras: **Consultation 500 + Vaccine 400 = 900**.

| # | Situation | Today | Proposed |
|---|---|---|---|
| 1 | Cheaper reschedule (500 → 300) | 200 back; may use up the vaccine line (P2) | §4.1: −500 on the consultation, new 300 invoice paid from it, 200 cash |
| 2 | Same-price reschedule | Nothing | Nothing |
| 3 | Dearer, pay now (500 → 700) | Delta invoice 200, collected | Same |
| 4 | Dearer, pay later | Delta invoice 200, unpaid | Same |
| 5 | Cheaper twice | Second can fail: "no remaining refundable line" | Each time the newest line is replaced |
| 6 | Dearer, then cheaper | Refunds from the delta invoice first | Same, consultation lines only |
| 7 | Cancel, never rescheduled, paid | Refund dialog, lines chosen by hand | Only the consultation pre-selected |
| 8 | Cancel after a cheaper reschedule | Remaining 300 **cannot** be refunded (P1) | Refund the 300 replacement invoice |
| 9 | Cancel after a dearer reschedule | 500 + 200 across two invoices | Same, vaccine untouched |
| 10 | Cancel, vaccine already given | Front desk must not tick the vaccine | Vaccine not pre-selected |
| 11 | Cancel unpaid, consultation only | Invoice cancelled | Same |
| 12 | Cancel unpaid, invoice has a vaccine | **Whole invoice cancelled** (P3) | Only the consultation removed (Q2) |
| 13 | Cancel partly paid | Nothing; flagged | Same, flagged (Q5) |
| 14 | Invoice-level discount | Reschedule refund ignores the discount share | Line refunded at its discounted value |
| 15 | Government / waiver | No cash (correct) | Same |
| 16 | The 8 already-adjusted invoices, then cancelled | Stuck | "Refund remaining" by journal entry (§6, Q4) |
| 17 | Cheaper reschedule, new fee gets the old discount? | n/a | Business rule (Q3) |

Several appointments on one invoice (always one patient; 22 such invoices on the dev site):
**Appointment A 500 + Appointment B 800 + Vaccine 400 = 1,700**.

| # | Situation | Today | Proposed |
|---|---|---|---|
| M1 | A and B on separate invoices | Independent | Independent, per the table above |
| M2 | A cheaper (500 → 300) | 200 back; may use up B's or the vaccine's line (P2) | §4.1 on A's line only; B and the vaccine untouched |
| M3 | Then A cancelled | A's 300 cannot be refunded | Refund A's 300 replacement invoice |
| M4 | B cancelled, paid | Lines chosen by hand | Only B's line pre-selected |
| M5 | Unpaid, A cancelled | **Whole invoice cancelled**, B and the vaccine lost (P3) | Only A's line removed (Q2) |
| M6 | Partly paid 1,000 of 1,700, A cancelled | Nothing; flagged | A's proportional share refundable: 500/1,700 × 1,000 = 294 (Q5) |
| M7 | A and B both cheaper | Second can fail | Each replaced independently |
| M8 | A dearer | Delta invoice for A | Same |
| M9 | A rescheduled, then B cancelled | B's line may already be used up | B's line never touched |
| M10 | Invoice discount across A, B, vaccine | Ignored by reschedule refunds | Each line carries its share by value |

## 6. The 8 invoices already adjusted (legacy)

Their appointment line is already used up, so no Credit Note can refund the remainder. Proposal: a
**"Refund remaining"** action shown only when `fully_refunded` is true, money is left, and the
appointment is cancelled: a Journal Entry moving the remainder from the income account back to the
customer, then a Payment Entry paying it out. It is recorded differently from every other refund,
so it needs the accountant's approval (Q4). Until then the screen shows these rows as
"Partial · fee adjusted" with a disabled Refund button (already built, uncommitted on
`fix/billing-rounding-and-refund-discount`).

## 7. What would change (estimate)

| Area | Files |
|---|---|
| Backend (certain) | `services/billing.py`; `api/v1/appointments/api.py`; `appointment_reschedule_refund.json` (a `replacement_invoice` field) + a patch + `patches.txt`; `tests/appointments/test_reschedule_payment.py` |
| Backend (to verify) | `api/v1/billing/report.py`, `api/v1/dashboard/report.py`, `api/v1/appointments/report.py`: revenue must neither double-count nor drop the replacement invoice — UNVERIFIED |
| Frontend | 0–2: the cancel-refund pre-selection in `appointments-client.tsx`; possibly `types/appointments.ts` |
| Docs | this note, ADR-114, the regenerated endpoint pages, CHANGELOG, WORK_LOG |

About 1–2 days plus testing. The riskiest step is §4.1.3 (paying the new invoice from the Credit
Note): it needs a test on this bench before anything else — UNVERIFIED on Frappe v16.

## 8. Questions to answer before building

| # | Question | Recommendation |
|---|---|---|
| Q1 | On cancel, should the Refund dialog pre-select only the appointment's line? | Yes |
| Q2 | Unpaid invoice with other lines: cancel and re-issue it without the appointment line (new invoice number), or a small Credit Note for the appointment line only (keeps the number)? | Credit Note: the invoice number the patient holds stays valid |
| Q3 | Cheaper reschedule: does the new fee get the old invoice discount? | Accountant / owner decision |
| Q4 | Accountant: approve a Journal Entry refund for the 8 legacy invoices? | Needed only if one is cancelled |
| Q5 | Partly paid shared invoice: does payment count proportionally across lines, or toward appointments first? | Proportionally (what `appointment_invoice_share` already assumes) |

## 9. Implementation (2026-09-30)

Built on branch `feat/appointment-line-owns-its-money` in both repos, with the recommended answers
to Q1, Q2 and Q5 and **no** change to amounts for Q3. Q4 is not built (see
[KNOWN_ISSUES](../KNOWN_ISSUES.md)).

| Piece | Where |
|---|---|
| Cheaper reschedule replaces the line (§4.1): Credit Note in full per source, replacement invoice for the new fee, paid by core's `reconcile_dr_cr_note`, cash for the rest | `services/billing.py::_replace_appointment_lines`, called from `adjust_payment_for_reschedule` |
| Credit moved from a Credit Note counts as paid on the invoice it paid, and as taken off the invoice the Credit Note reverses | `_credit_applied_bulk`, `_credit_note_reallocated`, `_credit_note_taken`; `_real_cash_paid_by_name`, `real_cash_paid_bulk` |
| Funding follows the money onto the replacement invoice; shared originals read every Credit Note in the refund breakdown | `_appointment_funding` |
| History records the replacement | `Appointment Reschedule History.replacement_invoice` + patch `add_reschedule_replacement_invoice_20260930` |
| Unpaid cancel removes only the appointment's line (§4.3, Q2: Credit Note with `update_outstanding_for_self = 0`) | `remove_appointment_lines_from_unpaid_invoice`; `api/v1/appointments/api.py::cancel_unpaid_invoice_for_appointment` |
| Appointment billing summary: replacement in the chain, per-appointment netting on a shared original, `refund_invoice` | `api/v1/appointments/api.py::_billing_context`, `_billing_for` |
| Revenue totals skip replacement invoices (they re-bill money already billed) | `reschedule_replacement_invoices`; `api/v1/billing/report.py` revenue, `api/v1/billing/api.py` Billed total. Revenue by provider nets Credit Notes already and needed no change |
| Cancel refund opens on `refund_invoice` with only the appointment's line ticked (§4.2, Q1) | frontend `appointments-client.tsx`, `refund-dialog.tsx` (`preselectAppointment`); `get_refundable_items` returns `reference_appointment` |

**Falls back to the legacy value-based refund** (`_allocate_reschedule_refund`) when a line cannot
be replaced safely: a source invoice not fully paid (M6, case 13), a line with no appointment
reference, a line an earlier legacy refund already used up, or money the funding model cannot
place. Cancelling after a dearer reschedule (case 9) still needs one refund per invoice: the dialog
opens on the newest one.

**Verified** in `tests/appointments/test_reschedule_payment.py` (each new test fails on the code
before this change): cheaper reschedule then cancel refunds the kept fee in cash (cases 1, 8); only
the appointment's line moves on a shared invoice (M2) and next to another line (P2); two cheaper
reschedules in a row (case 5); the billing summary reads 300, not 800, and points the refund at the
replacement; unpaid cancel keeps the rest of the invoice (case 12, M5) and still cancels an
appointment-only invoice (case 11).

## 10. Permissions and reassign (2026-09-30, ADR-115)

- **No permission bypass in billing.** Every save/submit in these flows runs on the caller's own
  rights. Only EB_Front Desk and EB_Healthcare Admin move money
  ([ADR-115](../adr/adr-115-billing-without-permission-bypass.md)); the replacement step's Journal
  Entry is allowed only inside billing's own window.
- **Who may do what.** A practitioner can still reschedule when no money moves (same fee, or a
  pay-later difference); a refund or a pay-now difference is refused before anything changes.
  A practitioner cancelling a visit with an unpaid invoice leaves the charge and front desk gets a
  task (cases 11–12 then complete when front desk acts).
- **Reassign now settles the fee.** `reassign_appointment` goes through the reschedule path, so a
  cheaper doctor refunds by line replacement (§4.1) and a dearer one is collected now or at
  checkout. The Appointments screen's reassign dialog shows the difference first; the dashboard's
  reassign dialog already used the reschedule path.

## 11. Cancel after a dearer reschedule (2026-09-30)

- **Dearer, pay later, then cancel (cases 4 and 9 with an unpaid extra invoice):** fixed.
  `cancel_unpaid_invoice_for_appointment` also settles the appointment's reschedule invoices: an unpaid extra invoice is
  cancelled whole; one with any payment is left and counted as a refund owed. The appointment then reads "Paid" with
  nothing outstanding, so its Refund button shows, opening on the invoice that holds the money. Verified on HLC-APP-2026-00813.
- **Dearer, pay now, then cancel (money on two invoices):** fixed, see §12.

## 12. One refund for the whole appointment (2026-09-30)

A cancelled appointment's Refund button now opens one dialog that lists every invoice holding its money (original, extra
invoice from a reschedule, replacement invoice), what is cash back and what is a waiver reversed, and refunds them all
together. `appointment_refund_plan` and `refund_appointment` (`services/billing.py`) do it under one savepoint, so a failure
leaves nothing half refunded. On a shared invoice only this appointment's lines are returned; a partly paid invoice is shown
as blocked and left alone. The button follows the money still held, so it stays until everything is refunded. Front Desk and
Admin only (ADR-115).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-30 | Divyanshu (AI-assisted) | §11 pay-now case built as §12: one refund for the whole appointment |
| 1.2 | 2026-09-30 | Divyanshu (AI-assisted) | §11: cancel after a dearer pay-later reschedule fixed; pay-now case still open |
| 1.1 | 2026-09-30 | Divyanshu (AI-assisted) | §10: ADR-115 permissions (no bypass, front desk/admin move money) and reassign settles the fee |
| 1.0 | 2026-09-30 | Divyanshu (AI-assisted) | Implemented (§9): Q1, Q2, Q5 as recommended, Q3 unchanged, Q4 deferred; revenue double count found and excluded; status draft → living |
| 0.1 | 2026-09-30 | Divyanshu (AI-assisted) | First draft for review: three problems, the one rule, 27 cases, 5 open questions |
