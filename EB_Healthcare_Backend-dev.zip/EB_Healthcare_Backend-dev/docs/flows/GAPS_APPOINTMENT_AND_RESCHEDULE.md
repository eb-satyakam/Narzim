# Gaps — Appointment Flow + Reschedule Flow

**Doc status:** living · **Created:** 2026-08-20 by Anant Sharma · **Updated:** 2026-08-20 by Anant Sharma · **Version:** 1.0

Audit of the booking/lifecycle flow (`api/v1/appointments/api.py`) and the
reschedule-with-payment flow (same file + `services/billing.py`) against the
code as it stands on `dev` (2026-08-20, with the uncommitted
`collect_invoice` change in the working tree).

This is a **gap register**, not a bug report of things believed broken by
accident — several entries are deliberate omissions that were never scoped.
Each entry says which it is.

Companion docs: `docs/flows/FLOWS_APPOINTMENT_RESCHEDULE.md` (how the
reschedule flow is *meant* to work), `docs/KNOWN_ISSUES.md` (the one
appointment-adjacent bug already logged: patient-portal slot overlap).

**Severity**
| | Meaning |
|---|---|
| **P0** | Money is wrong, or a clinical/queue state is wrong, with no operator signal. Fix before more feature work. |
| **P1** | Reachable failure or wrong data, but an operator will notice. |
| **P2** | Missing capability / policy the product needs but never had. |
| **P3** | Hygiene, contract cleanliness, test debt. |

---

## Part A — Appointment (booking + lifecycle) gaps

### A-1 · P0 · Cancelling a *paid* appointment raises no refund task
**Where:** `api/v1/appointments/api.py:1864` (`cancel_appointment`), `:1842` (`update_status`)

`cancel_unpaid_invoice_for_appointment()` (`:1798`) returns `True` precisely to
signal "a paid/partially-paid invoice was left standing — a human owes this
patient a refund." Its own docstring says so. Both callers in this module
**discard the return value**:

```python
cancel_unpaid_invoice_for_appointment(appointment)   # bool dropped
```

The encounter-cancel cascade does honour it —
`api/v1/encounters/api.py:2056` calls `_create_refund_task_for_appointment()`
on `True`. So the *same* clinical event produces a refund task when cancelled
from the encounter and produces **silence** when cancelled from the
appointments screen, which is the path front desk actually uses. Money stays
with the clinic with nothing in anyone's queue.

**Fix:** move `_create_refund_task_for_appointment` out of `encounters/api.py`
into `appointments/api.py` (it is an appointment-level concern; encounters
imports it, not the reverse) and call it from all three cancel paths.

---

### A-2 · P0 · A No-Show'd slot looks free everywhere but core rejects it
**Where:** `_practitioner_conflict` (`:1035`), `get_available_slots` (`:1090`), vs core `validate_overlaps`

Three layers disagree on whether a `No Show` appointment occupies its slot:

| Layer | Excludes from occupancy |
|---|---|
| `get_available_slots` (`:1178`) | `Cancelled`, `No Show` |
| `_practitioner_conflict` (`:1062`) | `Cancelled`, `No Show` |
| core `validate_overlaps` | `Closed`, `Cancelled` — **No Show still blocks** |

So a slot whose only appointment is a No Show renders **available** in the
picker, passes our pre-flight conflict guard, and then dies inside
`doc.insert()` with core's raw `OverlapError` ("Not allowed, cannot overlap
appointment HLC-APP-…"). Untranslated, un-mapped to a 409, and pointing at a
docname front desk cannot see.

Note the mirror image is also true: core excludes `Closed` while we don't, so
a closed appointment blocks our guard when core would allow it.

**Fix:** pick one occupancy definition and use it in all three places. If
No Show should free the slot (it should — that is the point of marking it),
the guard has to also *tell core*, which means either filtering the No Show
appointment out of core's query (not possible without patching core, Rule 1)
or moving the No Show appointment's status to `Cancelled`/`Closed` when it is
marked. That is the tractable route and needs a decision.

---

### A-3 · P1 · Nothing validates that the booked time is inside a real schedule
**Where:** `_create_impl` (`:885`), and core's `validate()` chain

`get_available_slots` is the only thing that knows about Practitioner
Schedules, holidays and leave — and it is **advisory**. It is a read endpoint
the UI calls to render a picker. Nothing re-checks the chosen time at write
time:

- Core `validate()` runs `validate_overlaps`, `validate_service_unit`,
  `validate_practitioner_unavailability`, `set_status`. None of these consult
  `Practitioner Schedule`.
- `check_employee_wise_availability` (holidays + leave) is called **only**
  inside our `get_available_slots` (`:1130`), never on the write path.

Consequences, all reachable through the API and through a stale browser tab:
an appointment at 03:00 on a day the practitioner has no schedule; an
appointment on a clinic holiday or the practitioner's approved leave; an
appointment in a service unit that schedule row never offered.

**Fix:** a `_validate_bookable_slot(practitioner, date, time, duration,
service_unit)` helper reusing the same core calls `get_available_slots`
already delegates to, invoked from `_create_impl` and from both reschedule
endpoints. This is the single highest-value guard missing from the module.

---

### A-4 · P1 · Past-date booking is accepted and silently becomes No Show
**Where:** `_create_impl` (`:885`); core `set_status()`

There is no "not in the past" check anywhere. Core's `set_status()` resolves
`appointment_date < today` to `status = "No Show"` unconditionally. So booking
yesterday returns **201 Created** with a No Show appointment — a
retroactively-missed visit the clinic never had. Same mechanism fires on
reschedule (see R-2).

**Fix:** reject `appointment_datetime < now` in `_create_impl` with a 400,
with an explicit `allow_backdated` escape hatch if retroactive data entry is
a real requirement (it may be — decide, don't infer).

---

### A-5 · P2 · No reminders, no auto-no-show, no scheduler at all
**Where:** `hooks.py:312-328` — `scheduler_events` is entirely commented out

The app registers **no** background jobs. Concretely missing:

- Appointment reminders. `Patient Appointment.reminded` is read and returned
  by `_fmt` (`:680`) but nothing in this app ever writes it. Phase 4's
  `send_whatsapp_reminder` is still unbuilt; the WhatsApp integration
  (`integrations/whatsapp/notifications.py`) is a generic doc-event notifier
  with no appointment reminder wired to it.
- Auto-No-Show sweep. Today's un-arrived appointments sit in `Open` forever
  until a human moves them; core only flips to No Show on a *save* of a
  past-dated doc.
- Stale-queue cleanup (see A-6, R-3).

**Fix:** Phase 4 work, already on the roadmap. Listed here because A-6/R-3
below are consequences of it, not independent bugs.

---

### A-6 · P1 · Check-in has no undo, and check-in time is never cleared
**Where:** `check_in_patient` (`:1890`)

`custom_checked_in_at` is stamped on check-in and **never** reset — not by
`update_status` moving the appointment back to `Confirmed`, not by
`cancel_appointment`, not by either reschedule endpoint. A mis-clicked
check-in permanently poisons the punctuality/wait-time reports that field
exists to feed (Phase 4 `get_queue_wait_times`, `get_check_in_rates`).

**Fix:** clear `custom_checked_in_at` in `update_status` whenever the target
status is behind `Checked In` in the queue order, and on cancel/reschedule.

---

### A-7 · P2 · No booking-side notification on any lifecycle event
Booking, cancellation and reschedule send the patient nothing. Not a
regression — never built. The generic notifier exists
(`integrations/whatsapp/notifications.py` + a Notification Config doctype),
so this is wiring plus templates, not new infrastructure. Reschedule is the
sharpest case: a patient whose appointment moved has no idea unless front
desk phones them.

---

### A-8 · P3 · `book_appointment` and `book_appointment_with_payment` diverge from `book_appointment_for_patient`
Three booking entry points with three different transaction policies:

| Endpoint | On billing failure |
|---|---|
| `book_appointment` (`:1393`) | no billing involved |
| `book_appointment_with_payment` (`:1434`) | keeps the appointment `Unpaid`, returns 201 with `payment_error` (ADR-012) |
| `book_appointment_for_patient` (`:1604`) | rolls **everything** back (2026-06-16 decision, explicitly overriding ADR-012) |

Both policies are defensible; having both, reachable from the same drawer
depending on whether the patient is new, is not. `book_appointment_for_patient`
is the one carrying the newer, deliberate decision — which likely makes
`book_appointment_with_payment` a live endpoint holding the losing policy.
Frontend call sites were not checked as part of this audit.

**Fix:** check whether `book_appointment_with_payment` is still reached from
the BFF routes; if not, delete it, and if so, make it delegate. Either way
record the surviving policy in an ADR that supersedes ADR-012's clause.

---

## Part B — Reschedule gaps

### R-1 · P0 · Two reschedule endpoints, one of which skips the entire money + audit layer
**Where:** `reschedule_appointment` (`:1921`) vs `reschedule_appointment_with_payment` (`:2241`)

The old `reschedule_appointment` is still whitelisted and does:

```python
doc.appointment_date = appointment_date
doc.appointment_time = appointment_time
doc.save(ignore_permissions=True)
```

That is *all*. No `Appointment Reschedule History` row, no fee recompute, no
`paid_amount` update, no delta/refund, no reassign role gate, no conflict
guard, no idempotency. An appointment moved through this endpoint:

- has a hole in its reschedule audit trail — and because
  `_appointment_funding` (`services/billing.py:1335`) derives "what has this
  appointment paid" from history rows, the **next** reschedule through the
  proper endpoint computes its delta from a baseline that silently omits this
  move;
- keeps the previous practitioner's stamped `paid_amount`, so a later
  checkout bills the stale fee (exactly the R-2 bug the payment endpoint was
  built to fix).

It is also the *less* guarded of the two while carrying the more obvious
name — the one an integrator reaches for first.

**Fix:** deprecate it. Either delete it (check the BFF routes first) or
reduce it to a thin wrapper that calls
`reschedule_appointment_with_payment(appointment, new_appointment_date=…,
new_appointment_time=…)`.

---

### R-2 · P0 · Reschedule into the past silently marks the visit No Show
**Where:** `reschedule_appointment_with_payment` (`:2241`), `reschedule_appointment` (`:1921`)

Neither endpoint validates the target datetime is in the future. Core's
`set_status()` then forces `status = "No Show"` for any past date. The API
returns **200 with a full payment settlement** — delta invoice raised or
refund paid out — on an appointment now recorded as a no-show. The money
moved; the visit did not.

**Fix:** same past-date guard as A-4, applied before the savepoint opens.

---

### R-3 · P0 · Rescheduling a checked-in patient leaves them in today's queue
**Where:** `reschedule_appointment_with_payment` (`:2279`)

The status gate blocks only `Cancelled`, `Closed`, `Checked Out`:

```python
if doc.status in ("Cancelled", "Closed", "Checked Out"):
```

`Checked In` passes. Core's `set_status()` **early-returns** for `Checked In`
(it is in the "terminal-ish" list), so moving the appointment to next Tuesday
leaves `status = "Checked In"` and `custom_checked_in_at` stamped at today's
arrival time. Result: a patient who left the building still occupies a
Nursing Room queue column, and the wait-time report has a check-in with no
matching visit.

The practitioner-change branch does gate on `_REASSIGNABLE_STATUSES` (which
includes `Checked In`, deliberately, for coverage) — but a pure date/time move
never reaches that gate at all.

**Fix:** when the target date differs from today, reset status to
`Scheduled`/`Open` per core's own date rule and clear
`custom_checked_in_at`. Decide separately whether a same-day time shift for a
checked-in patient should keep the check-in (it probably should).

---

### R-4 · P1 · No conflict pre-check on reschedule, so front desk gets core's raw error
**Where:** `reschedule_appointment_with_payment` (`:2241`), `reschedule_appointment` (`:1921`)

All three booking endpoints call `_practitioner_conflict` (`:1035`) first and
return a friendly 409 naming the clashing appointment and service unit.
Neither reschedule endpoint does. They rely entirely on core's
`validate_overlaps` firing inside `doc.save()`, which:

- raises `OverlapError` with an untranslated message and a docname;
- is **not** the same rule as our guard — core has no cross-service-unit
  concept, and differs on `No Show`/`Closed` (see A-2);
- fires *after* the `set_only_once` fields (practitioner, appointment_type,
  duration, department) have already been written via `frappe.db.set_value`.
  The savepoint rolls them back, so this is not corruption — but it means the
  failure path is the expensive one, and any future non-savepoint caller
  inherits a half-mutated appointment.

**Fix:** call `_practitioner_conflict` before the savepoint, same as
`book_appointment_for_patient` does at `:1706`.

---

### R-5 · P1 · The preview cannot warn about anything except money
**Where:** `preview_reschedule_payment` (`:2130`)

The preview deliberately ignores `new_appointment_date` /
`new_appointment_time` — documented, and correct for *fee* purposes. But it is
the only dry-run the drawer has, so the confirm step is the first moment the
user learns about:

- a slot conflict (R-4);
- a practitioner-change permission denial — the preview does **not** apply the
  `_REASSIGN_ROLES` / `_REASSIGNABLE_STATUSES` / existing-encounter gates that
  the settlement applies at `:2277-2295`, so a nurse can preview a doctor swap
  that will 403 on confirm;
- a past-date target (R-2);
- an appointment already past the `Cancelled`/`Closed`/`Checked Out` gate.

**Fix:** extend the preview to run every non-mutating precondition the
settlement runs and return them as a `blockers: []` array. The drawer then
disables Confirm rather than discovering the problem after the patient has
been quoted a number.

---

### R-6 · P1 · A refund issued outside this flow is invisible to it
**Where:** `services/billing.py:1335` (`_appointment_funding`)

Already flagged as a known limitation in `FLOWS_APPOINTMENT_RESCHEDULE.md`
§4; restated here because it is still live and it is a money gap, not a
cosmetic one.

`_appointment_funding` builds "cash already clawed back" solely from
`Appointment Reschedule History` rows with a `refund_credit_note`. A Credit
Note raised anywhere else — the Billing tab's manual refund
(`services/billing.py::create_credit_note`), a Desk-side correction — never
reduces the original invoice's own `outstanding_amount`, and has no history
row. So `total_paid_for_appointment` **over-counts** what the patient still
holds.

Concrete: patient pays 800; front desk manually refunds 300 via the Billing
tab; the appointment is then rescheduled to a 700 doctor. The flow believes
800 is held, computes a 100 refund, and hands back money the patient no
longer has — total returned 400 against 100 actually owed.

**Fix:** derive clawed-back cash from the Credit Notes themselves
(`Sales Invoice` where `is_return=1` and `return_against` in the source set),
not from history rows, and keep history only for the *unsourced* legacy case.
Guard against double-counting this flow's own refunds by matching on the
credit note names history already records.

---

### R-7 · P1 · `old_fee` and `new_fee` on the same history row are on different tax bases
**Where:** `reschedule_appointment_with_payment` (`:2428-2433`), `_history_response` (`:2190`)

Stored on `Appointment Reschedule History`:

- `old_fee` = `quote["old"]["fee_incl_tax"]` — **tax-inclusive**
- `new_fee` = `quote["new"]["fee"]` — **pre-tax**
- `old_paid_amount` — tax-inclusive real cash

The code knows: `_new_fee_tax_breakdown` (`:2172`) recomputes the tax on read
so the API response is honest, and the inline comment at `:2429` explains the
choice. But the *stored row* is a trap. Any report, export, or future feature
that does `new_fee - old_fee` off this doctype is wrong by the tax rate, and
the doctype has no tax columns to disambiguate.

**Fix:** add `new_fee_incl_tax` and `new_tax_rate` columns (patch in
`patches.txt`) and store both bases explicitly. Recomputing on read also means
a *later* change to the practitioner's item tax template retroactively rewrites
what an old row reports the settlement to have been — which is the wrong
answer for an audit record.

---

### R-8 · P1 · Idempotency only covers the immediately-previous target
**Where:** `reschedule_appointment_with_payment` (`:2318-2340`)

The replay check compares the request against the **latest** history row only.
That choice is right for A→B→A (documented, tested). But:

- **A→B then A→C in quick succession** (user corrects the slot, double-clicks
  each): both process. Correct behaviour, but two delta invoices exist and the
  operator sees one confirmation. No `Idempotency-Key`/request-id, so the
  client cannot express "this is a retry of *that* submission."
- **Replay does not re-verify state.** If the appointment was moved by another
  path after the history row was written (Desk edit, or `reschedule_appointment`
  per R-1), a retry matches the stale row, returns 200, and reports a
  reschedule that is no longer reflected on the appointment.
- **No row lock.** Two concurrent identical requests both read `latest`, both
  miss, both settle. Core's `validate_overlaps` catches the *slot* collision
  but not the *payment* one when practitioner/date/time are identical and only
  the fee moved.

**Fix:** accept a client-supplied idempotency key and unique-index it on the
history doctype; take a `for update` lock on the Patient Appointment row at
the top of the savepoint.

---

### R-9 · P2 · No reschedule policy: unlimited moves, no lead time, no fee, no reason
**Where:** by omission

Nothing constrains a reschedule. Missing, in rough order of how often clinics
ask for it:

- **Reason capture.** `cancel_appointment` takes a `reason` and appends it to
  notes; reschedule takes none. `Appointment Reschedule History` has a `notes`
  field the endpoint never populates.
- **Lead-time rule.** Moving an appointment 10 minutes before it starts is
  identical to moving it a week out.
- **Reschedule count cap / late-reschedule fee.** History makes both trivially
  computable; neither is enforced or surfaced.
- **`fee_override` has no approval trail.** Front desk can waive a
  consultation to 0 on a reschedule with no second signature, no reason field,
  and no separate log — the override lands in `new_fee` looking like a normal
  rate. For a jurisdiction-audited system (LFPDPPP / NOM-024, DPDPA) that is
  the kind of unattributed financial adjustment an audit asks about.

---

### R-10 · P3 · Smaller correctness snags in the money path

| | Where | Issue |
|---|---|---|
| a | `_reschedule_quote` (`:2086`) | `override=flt(doc.paid_amount) or None` — a legitimately **waived** appointment (`paid_amount = 0`) falls through to "resolve today's rate", so the old side reads back as the practitioner's full fee instead of 0. Use `is not None`, not truthiness. |
| b | `reschedule_appointment_with_payment` (`:2367`) | `duration` is refetched from the new Appointment Type, but an explicit `duration` override the original booking used is discarded. Reschedule silently normalises a custom-length appointment. |
| c | `:2377` | `new_service_unit` is assigned without re-deriving `company` — `_create_impl` (`:959`) does derive it. A cross-company service unit move leaves the appointment on the old company's books. |
| d | `:2398` / `_billing_for` | `paid_amount` is written pre-tax (correct — matches core) while the appointments list's `billing.outstanding` for an uninvoiced appointment is built from it. An uninvoiced appointment therefore under-reports what the patient will actually be charged by the tax amount. |
| e | working tree | The uncommitted `collect_invoice` / `collect_outstanding` addition to `_billing_for` (`:525-534`) is the fix for "payment exceeds outstanding" on a reschedule chain. It is **not committed and not tested** — no test in `test_reschedule_payment.py` covers per-invoice collection targeting. Land it with a test. |

---

## Part C — Cross-cutting

### C-1 · P1 · The staff and patient-portal slot pickers are separate implementations
Already in `docs/KNOWN_ISSUES.md` (paused 2026-07-20):
`patient_portal/api.py::get_my_available_slots` does exact `from_time` string
matching, ignores `duration`, and has no past-slot filter — while
`appointments/api.py::get_available_slots` (`:1090`) does all three correctly.
Listed here because A-2 and A-3 will need fixing in *both* places, so the
extract-a-shared-helper work the known-issues entry describes is now a
prerequisite rather than a nice-to-have.

### C-2 · P2 · No reschedule/cancel path emits a domain event
Neither flow publishes anything other than a `frappe.logger("remedisys")`
line. No realtime push to the queue board (front desk must refresh), no hook
other code can subscribe to. Every future consumer — reminders (A-5),
notifications (A-7), reports — will otherwise reach back into the API.

---

## Part D — Test gaps

### D-1 · P1 · `test_nurse_cannot_check_in_or_cancel` is stale and asserts the opposite of the code
**Where:** `tests/appointments/test_appointments.py:48`

```python
def test_nurse_cannot_check_in_or_cancel(self) -> None:
    with self._roles(["EB_Nurse"]):
        with self.assertRaises(frappe.PermissionError):
            api._assert_can_set_status("Checked In")
        with self.assertRaises(frappe.PermissionError):
            api._assert_can_set_status("Cancelled")
```

`_ROLE_ALLOWED_STATUSES["EB_Nurse"]` (`api.py:135`) contains **both**
`"Checked In"` and `"Cancelled"` — the latter added by the 2026-07-17 policy
change, which is documented in a code comment but never propagated to this
test. The test asserts a policy that no longer exists, so it must be failing
(or the suite is not being run, which is the worse finding). Rename to
`test_nurse_can_check_in_and_cancel` and invert the assertions.

### D-2 · P2 · Nothing covers the appointment write path end-to-end
`test_appointments.py` (12 tests) covers the role matrix and the
new-patient rollback. There is **no** test for: `get_available_slots`
(the most logic-dense function in the module, ~200 lines of ported Desk JS),
`_practitioner_conflict`, `check_in_patient`, `cancel_appointment`, the
invoice-cancel cascade, or `_list_impl`'s filters. `test_reschedule_payment.py`
(29 tests) is by far the best-covered part of the module — the money path is
solid and the scheduling path around it is untested.

### D-3 · P2 · No test for any gap in Part A or B
None of A-1 through A-6, R-1 through R-4, or R-6 has a regression test. Each
fix should land with one; several (A-1, A-2, R-3) are cheap to express.

---

## Suggested order

1. **A-1** (refund task on cancel) — smallest diff, real money, one-line signal already exists.
2. **R-1** (collapse the duplicate reschedule endpoint) — removes a whole class of future divergence, unblocks reasoning about everything else.
3. **R-3** + **A-6** (checked-in state on reschedule, check-in reset) — queue correctness, both in the same code region.
4. **R-2** + **A-4** (past-date guard) — one shared helper, two call sites.
5. **R-4** + **R-5** (conflict pre-check + preview blockers) — same helper again; turns core's raw errors into a contract.
6. **R-6** (external credit notes) — the remaining money bug; needs the redesign the flow doc already flags.
7. **D-1** (stale test) — do this first if the suite is red, since it hides everything else.
8. **A-2** / **A-3** — need a product decision (No Show occupancy; whether off-schedule booking is ever legitimate) before code.
9. **R-7**, **R-10** — patch + small fixes, batch together.
10. **A-5**, **A-7**, **R-9**, **C-2** — Phase 4 scope, not bugs.

---

## What is *not* a gap

Verified sound while auditing, worth recording so it is not re-litigated:

- **The delta/refund arithmetic itself.** Tax bases, shared-invoice
  proration (`appointment_invoice_share`), POS-embedded payments, multi-invoice
  refund allocation, and the pay-later "raise nothing" rule are all correct and
  each is pinned by a test. The comments explaining *why* are unusually good.
- **Preview/settlement agreement.** Both go through `_reschedule_quote`, so
  they cannot disagree — the right structure, and tested (`:486`).
- **`set_only_once` ordering.** Writing practitioner/type/duration before
  `doc.save()` so core validates the new slot against the *new* practitioner is
  subtle, correct, commented, and tested (`:290`).
- **Rule 1 (upgrade-safety).** No core file is touched anywhere in either flow;
  every core-restriction workaround goes through `frappe.db.set_value` with a
  recorded reason.
- **Role gating.** `_assert_can_set_status` is enforced server-side on every
  status path including the two that could have bypassed it, with the
  practitioner own-appointment bypass scoped narrowly.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Anant Sharma | Initial version (header backfilled from git history) |
