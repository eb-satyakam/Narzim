# Medication Request (Core Healthcare) — How It Works

**Doc status:** living · **Created:** 2026-07-09 by Divyanshu · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** reference notes — describes core `healthcare` app behavior only (Rule 1: never modify core; this is documentation of what ships out of the box, not a Remedisys design doc)
**Doctype owner:** core `healthcare` app
**Source:** `apps/healthcare/healthcare/healthcare/doctype/medication_request/`, `apps/healthcare/healthcare/controllers/service_request_controller.py`, `apps/healthcare/healthcare/healthcare/doctype/patient_encounter/patient_encounter.py`, `apps/healthcare/healthcare/healthcare/utils.py`, `apps/healthcare/healthcare/setup.py`, `apps/healthcare/healthcare/public/js/sales_invoice.js`

---

## 1. What it is

`Medication Request` is core ERPNext Healthcare's FHIR-modelled order
document for a prescribed drug. It shares its base class,
`ServiceRequestController`, with `Service Request` (the equivalent order
doctype for labs/procedures/therapy), so most of the lifecycle logic below
applies to both.

It is a real, standalone, **submittable** doctype with its own docstatus,
status, and billing state — distinct from `Drug Prescription`, which is just
a plain child-table row on `Patient Encounter` (dose, route, duration,
comment) with no lifecycle or status of its own.

---

## 2. How core creates it

`PatientEncounter.make_medication_request()` (`patient_encounter.py:237`) is
the only creation path. It loops every `Drug Prescription` row that has a
drug and no `medication_request` link yet, builds the order via
`get_order_details()`, inserts it, and submits it:

```python
def make_medication_request(self):
    if self.drug_prescription:
        for drug in self.drug_prescription:
            if (drug.medication or drug.drug_code) and not drug.medication_request:
                medication = frappe.get_doc("Medication", drug.medication) if drug.medication else ""
                order = self.get_order_details(medication, drug, True)
                order.insert(ignore_permissions=True, ignore_mandatory=True)
                order.submit()
                drug.medication_request = order.name   # linked back onto the child row
```

Two Encounter events call it:

| Trigger | Encounter method | Resulting Encounter status |
|---|---|---|
| Encounter **submitted** (`docstatus 0→1`) | `on_submit()` | `Completed` |
| Encounter **saved** with `submit_orders_on_save` checked | `validate()` | `Ordered` |

`submit_orders_on_save` lets a practitioner fire the order (starting the
pharmacy workflow) without fully submitting/locking the encounter yet. The
loop is idempotent per row — safe to call again, since it only acts on rows
still missing a `medication_request` link.

---

## 3. Field structure

Three logical sections (`medication_request.json`):

**Order Source** — `order_group` (Link → Patient Encounter), `practitioner`,
`order_date`, `order_time`, `medical_department`, `company`.

**Order Specification** — `medication` (Link → Medication master, optional),
`medication_item` (Link → Item — the actual dispensable/billable Item),
`dosage`, `dosage_form`, `period`, `quantity`, `number_of_repeats_allowed`,
`total_dispensable_quantity`, `occurrence_time`, `intent`, `priority`,
`status`.

**Billing** — `qty_invoiced`, `billing_status` (`Pending` / `Partly Invoiced`
/ `Invoiced`).

`quantity` and `total_dispensable_quantity` are computed in `validate()`
(`ServiceRequestController.set_medication_qty` /
`calculate_total_dispensable_quantity`), not entered:

```
quantity = sum(dosage.dosage_strength) × period.get_days()
total_dispensable_quantity = quantity × (1 + number_of_repeats_allowed)
```

`number_of_repeats_allowed` models refills — a prescription with 2 allowed
repeats can be dispensed/billed up to 3× its base quantity before it counts
as fully invoiced.

---

## 4. Status lifecycle — code-enforced, not configurable

`status` is a Link to `Code Value` scoped to the `Medication Request Status`
Code System, seeded in `healthcare/setup.py` directly from the FHIR
`medicationrequest-status` ValueSet. All 9 values exist in the database:

| Code | Meaning (as seeded) |
|---|---|
| `draft` | Work in progress, not yet actionable. |
| `active` | Actionable; not all implied actions have occurred yet. |
| `on-hold` | Temporarily halted; may or may not resume ("suspended"). |
| `stopped` | **Permanently** halted before all administrations occurred. Not for orders entered in error. |
| `ended` | No longer active; subject should no longer take the medication. |
| `completed` | All implied actions have occurred. |
| `cancelled` | Withdrawn before any administration occurred. |
| `entered-in-error` | Recorded in error (wrong patient/drug/dose). |
| `unknown` | Source system doesn't know which status applies. |

### What actually drives transitions

The transitions are enforced in `ServiceRequestController`, not by any
state-machine config:

- **`before_submit`** forces `status = active` unless it's already `active`,
  `on-hold`, or `unknown`. Since `get_order_details()` always builds the doc
  as `draft` and `make_medication_request()` submits it immediately, **every
  core-created Medication Request ends up `active`** — there is no core path
  to anything else at creation time.
- **`before_cancel`** throws if `status` is `completed` or `on-hold`
  ("You cannot Cancel Service Request in {status} status").
- **`on_cancel`** — if `status` was `active`, force-sets it to `cancelled`.
  Any other status is left as-is.
- **`stopped`, `ended`, `entered-in-error`** are valid data-model values that
  **core never sets anywhere** — no Desk button, hook, or scheduled job
  touches them. The one exception: amending a Medication Request (the
  standard Frappe amend-a-cancelled-doc flow) auto-flips the *old*
  (pre-amendment) doc to `stopped` in `before_insert`.

So, using only core, you would only ever observe `active` (or `cancelled`
after an Encounter cancel) in practice.

---

## 5. Effect on Sales Invoice

Core Sales Invoice's **Desk** form (`apps/healthcare/healthcare/public/js/sales_invoice.js`)
adds two separate "Get Items From" buttons:

| Button | Server method | Scope |
|---|---|---|
| **Healthcare Services** | `healthcare.healthcare.utils.get_healthcare_services_to_invoice` | Appointments, Encounters, Lab Tests, Procedures, Inpatient, Therapy, Service Requests, Observations |
| **Prescriptions** | `healthcare.healthcare.utils.get_drugs_to_invoice` | **Medication Request only**, one Patient Encounter at a time |

`get_drugs_to_invoice(encounter, customer)` (`healthcare/utils.py:1166`):

```python
medication_requests = frappe.get_list("Medication Request", filters={
    "patient": patient.name,
    "order_group": encounter.name,
    "billing_status": ["in", ["Pending", "Partly Invoiced"]],
    "docstatus": 1,
})
```

For each one it checks billability (`Medication.is_billable` if linked to a
Medication master, else `Item.disabled == False` for a bare `medication_item`),
computes the still-unbilled quantity (`quantity - qty_invoiced`, extended by
`number_of_repeats_allowed`), and returns a row the Desk dialog turns into a
plain `Sales Invoice Item` (`item_code = drug_code`, `qty`,
`reference_dt = "Medication Request"`, `reference_dn = <name>`).

**Note the filter is on `billing_status`, not `status`** — a `stopped`
Medication Request with `billing_status` still `Pending` is exactly as
billable as an `active` one, for its full original (not reduced) quantity.
Core has no built-in concept of "bill only what was actually dispensed
before it was stopped."

### On Sales Invoice submit/cancel

`set_invoiced` (`healthcare/utils.py:1067`) runs as a Sales Invoice Item
doc_event. For any line whose `reference_dt` is `Medication Request`:

```python
hso = frappe.get_doc("Medication Request", item.reference_dn)
hso.update_invoice_details(item.qty)          # on submit: +qty
# hso.update_invoice_details(item.qty * -1)   # on cancel: -qty
```

`Medication Request.update_invoice_details` (`medication_request.py:45`)
recomputes `qty_invoiced` and derives `billing_status`:

- `qty_invoiced == 0` → `Pending`
- `qty_invoiced < total_dispensable_quantity` (or `< quantity` if no
  repeats) → `Partly Invoiced`
- otherwise → `Invoiced`

`validate_invoiced_on_submit` (called from `set_invoiced` on submit) blocks
adding a Medication Request line to a **second** Sales Invoice once its
`billing_status` is already `Invoiced` — core's built-in double-billing
guard. `Partly Invoiced` can still be picked up again for the remainder
(e.g. refill billing).

---

## 6. Summary

| Question | Answer |
|---|---|
| What creates a Medication Request? | `Patient Encounter.make_medication_request()` — on submit, or on save with `submit_orders_on_save` checked |
| Who/what can create one manually? | No one — there is no manual "new Medication Request" workflow in core |
| Why is everything "Active"? | `before_submit` in `ServiceRequestController` force-sets `active` on creation; nothing else in core ever advances it |
| Which statuses does core ever set on its own? | Only `active` (creation) and `cancelled` (Encounter cancel, if it was `active`); `stopped`/`ended`/`entered-in-error` are unused by any core code path |
| Does stopping it affect billing? | No — `get_drugs_to_invoice` filters on `billing_status`, not `status`; a stopped request is still fully billable for its original quantity |
| How does it reach a Sales Invoice? | Only via the Desk-only "Get Items From → Prescriptions" button (`get_drugs_to_invoice`), separate from the "Healthcare Services" button |
| What updates billing state after invoicing? | The `set_invoiced` doc_event → `Medication Request.update_invoice_details()`, tracking `qty_invoiced` / `billing_status` and guarding against double-billing |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
