# A Few Centavos Left on a Bill: Refund and Waiver Rules

**Doc status:** living · **Created:** 2026-10-01 by Divyanshu (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 1.0

Design note. The decision is [ADR-119](../adr/adr-119-a-rounding-residue-is-not-a-debt-or-a-waiver.md).

## 1. In one paragraph

The billing code uses two different rules for "fully paid". The refund plan forgives up to 0.05
still owing (`_SETTLEMENT_TOLERANCE`). The refund step forgives nothing. A bill short by 0.03
shows "Refund 1,820" and then fails, and the all-or-nothing refund rolls back. Separately, any
gap between a Credit Note and the cash paid back is booked to the write-off account as a reversed
waiver, even a 0.01 rounding gap on a bill that was never waived. This note makes a residue of
0.05 or less mean the same thing everywhere: rounding.

## 2. What happens today (verified in code, 2026-10-01)

| Step | Rule | Code |
|---|---|---|
| Refund plan | refundable when still owing ≤ 0.05 | `services/billing.py::appointment_refund_plan` |
| Refund step | refused when still owing > 0 | `services/billing.py::create_credit_note` |
| After the refund | Credit Note value − cash back > 0.000001 is booked as "Reversal of write-off" | `services/billing.py::create_credit_note` → `_reverse_write_off` |

On the local dev site, neither has happened yet:

- 0 invoices owe between 0.01 and 0.05;
- 0 journal entries of 0.01–0.05 exist.

Bills are rounded to whole pesos (rounded total), so balances land on whole numbers. Both cases
appear when rounding is turned off, or in a currency that rounds to cents.

## 3. The rule

A residue of 0.05 or less (`_SETTLEMENT_TOLERANCE`) is rounding: neither a debt nor a waiver.

- **Gap 6 — a refund of a bill still owing ≤ 0.05 goes through.** The Credit Note first withdraws
  that residue from the bill (`_withdraw_own_balance`, ADR-117), then pays back the cash actually
  paid. Afterwards the bill owes 0, not 0.03 forever. The plan reports the residue as
  `balance_withdrawn`, not as a waiver.
- **Gap 7 — a gap of ≤ 0.05 between the Credit Note and the cash is not a waiver** unless the bill
  really carries a write-off (a waiver Journal Entry against it). No journal entry is booked for
  it. Above 0.05, or on a waived bill, nothing changes.

| Case | Before | After |
|---|---|---|
| Bill 500, paid 499.97, cancelled | Plan "Refund 499.97", then "not refundable"; nothing refunded | 499.97 back, 0.03 withdrawn, bill owes 0 |
| Bill 500, paid 499.94 (0.06 owing) | Refused | Refused (unchanged: not rounding) |
| Bill 500, 200 cash + 300 Government waiver, refunded | 200 back, 300 waiver reversed | Unchanged |

## 4. Not in this change

The line replacement on a reschedule (`_replace_appointment_lines`) still leaves a residue of
≤ 0.05 on a fully paid source invoice. Its Credit Note stands on its own balance, and the residue
moves into the replacement. Unifying that is part of the shared-invoice work (ADR-117 Q2).

## 5. Tests

`tests/billing/test_rounding_residue.py`:

1. A bill short by 0.03 refunds as planned. The bill owes 0 afterwards, and no write-off journal
   entry is booked.
2. A bill short by 0.06 is still refused.
3. A genuine waiver is still reversed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-10-01 | Divyanshu (AI-assisted) | First version |
