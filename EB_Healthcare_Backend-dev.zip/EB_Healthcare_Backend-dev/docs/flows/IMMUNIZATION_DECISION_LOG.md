# Immunization — 2026-08-27 Decision Log

**Doc status:** record · **Created:** 2026-08-27 by Divyanshu (AI-assisted) · **Updated:** 2026-08-27 by Divyanshu (AI-assisted) · **Version:** 1.1

One dated summary of a single day's immunization work: the problem, in a real user
story, and the fix — for each thing found and built, short. Full technical detail is
in `WORK_LOG.md`'s three 2026-08-27 immunization entries; this is the readable version.

---

## How it started

Asked to read the full immunization code, backend and frontend, just to understand it.
That read surfaced three problems nobody had reported yet. Fixed two of them (billing
bugs); left the third alone on purpose (see below). Then testing those fixes, by hand,
surfaced five more.

## 1. A vaccine could be billed twice

**Story:** Front desk clicks "Bill" next to a vaccine in the Immunizations tab → a new
invoice gets created → but the system had *already* auto-billed that same vaccine the
moment it was recorded → the patient is charged for one shot, twice.

**Fix:** Deleted the old "Bill" button and the endpoints behind it. A vaccine now bills
exactly one way, automatically.

## 2. Enrolling a patient in a vaccine program billed nothing

**Story:** A nurse applies a whole routine vaccine bundle to a patient in one click →
the system marks 10 vaccines as assigned → the clinic never gets billed for any of
them → 10 vaccines given away for free, by accident.

**Fix:** Applying a program now bills the same way assigning one vaccine already did.

## 3. A brand-new patient had no way to get a first vaccine at all

**Story:** Front desk opens a new patient's Immunizations tab → "No immunizations on
file" → there's no "Assign" button anywhere in the app to put a vaccine on the card
first → dead end.

**Fix:** Admins can now flag routine vaccines as "Show by default" (Settings → Vaccine
Schedules) — flagged vaccines show up for every patient automatically, even before
anyone formally assigns them. Recording a dose against one just works.

## 4. Clicking a vaccine's dot didn't actually let you record it

**Story:** A nurse sees a red "overdue" dot → clicks it, expecting to record that dose
→ nothing happens → has to open "Add immunization" separately and search for the same
vaccine again.

**Fix:** Every open dot is now clickable — it opens the recording form already filled
in for that vaccine.

## 5. A doctor-ordered rabies shot looked like it never went through

**Story:** A doctor orders a rabies vaccine for a patient during a visit → the nurse
opens the Immunizations tab to check → the row is there, but shows nothing — no dot,
no color, nothing — because that vaccine's dot lives in a part of the table that was
scrolled off-screen, and even when visible it was drawn as an almost-invisible gray
dash → the nurse assumes the order failed and doesn't act on it.

**Fix:** That column is now always visible (pinned, doesn't scroll away). "Not yet due"
now draws as a real, visible circle instead of a near-invisible dash.

## 6. Even once visible, that same rabies shot never told anyone it was needed

**Story:** Same doctor's order, now visible — but it still says "Not yet due,"
forever, because rabies shots have no fixed calendar date (they're only given after a
bite). A dose the doctor *actually ordered* looks identical to one nobody has ever
asked for.

**Fix:** Once a vaccine like this is genuinely assigned to a patient (a real order, not
just a suggestion), it now shows "Due now" — being assigned to this specific patient
*is* the reason it's needed. A vaccine only shown as a generic suggestion (§3) still
correctly shows "Not yet due."

## 7. "Not yet due" and "nothing scheduled" looked identical

**Story:** A nurse scans the chart → doses that aren't due yet and empty cells with no
dose defined are both the same gray → can't tell "later" from "nothing here" at a
glance.

**Fix:** "Not yet due" now has its own color (blue), everywhere it appears — the dot,
the hover text, the legend, the summary tile at the top.

## 8. The most serious one — recording the second dose recorded the first instead

**Story, in the user's own words:** *"suppose that we have two pending doses and we
select the second dose... after submit it update the 1 one."* A vaccine has two open
doses. A nurse deliberately clicks and records **dose 2** → saves it → the chart now
shows **dose 1** as given, and dose 2 as still not given → the record is simply wrong
about which shot the patient actually received.

**Why it happened:** two problems stacked. The click never told the form *which* dose
was meant, only which vaccine — so it always fell back to "whichever dose comes first."
And even fixing that alone wouldn't have been enough: underneath, the system matched a
recorded shot to a dose slot by counting ("1st shot = 1st slot"), never by checking
which dose was actually chosen.

**Fix:** Both, together. The system now matches a recorded shot to its correct slot by
name when one was specified, and the click now tells the form exactly which dose was
meant. Every past record, which never specified a dose by name, is completely
unaffected — the fix only changes behavior for a specific, named dose going forward.

**Tested for real, not just read:** made a test patient, deliberately recorded "dose 2"
before "dose 1," and confirmed the chart correctly showed dose 2 as given and dose 1
as still open.

## What was deliberately not touched

The "Assign vaccine" / "Apply program" buttons still don't exist anywhere in the app.
They were turned off on purpose by someone else back on 2026-07-14 — "disabled for all
roles per product request." Since the reason for that decision isn't known, it wasn't
reversed. The design doc's claim that this button was "verified working" was simply
wrong (11 days stale) and has been corrected — that's a documentation fix, not a
product one.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-08-27 | Divyanshu (AI-assisted) | Rewritten short, as user stories, per explicit request — replaces the longer technical-narrative v1.0 |
| 1.0 | 2026-08-27 | Divyanshu (AI-assisted) | Initial version — full technical account |
