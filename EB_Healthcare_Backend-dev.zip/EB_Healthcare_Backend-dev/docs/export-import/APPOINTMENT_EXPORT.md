# Appointment Export

**Doc status:** living · **Created:** 2026-09-22 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-23 by Anant Sharma (AI-assisted) · **Version:** 1.2

Row selection and bulk export on the `/appointments` list. **Export only — there is no import.**

The shared mechanics (the Access Log audit row, CSV-injection neutralisation, the CSV/xlsx writers,
the row cap) live in [`services/tabular_export.py`](../../remedisys_healthcare_ai/services/tabular_export.py)
and are described once in [`PATIENT_IMPORT_EXPORT.md`](PATIENT_IMPORT_EXPORT.md). This document covers
only what differs.

---

## 1. Why there is no import

Deliberate asymmetry, not an omission.

A patient record is a fact about a person a clinic may legitimately have recorded elsewhere first —
importing it is transcription. An **appointment is a commitment to a slot**, and bulk-creating those
from a spreadsheet would bypass the conflict detection, service-unit capacity and practitioner
availability rules that `create_appointment()` enforces. The failure mode is not a bad row; it is two
patients booked into one slot, discovered when both arrive.

Appointments are booked, not loaded.

---

## 2. Selection, and why both scopes send explicit ids

```
[ ⇅ Data ▾ ]    →   Export appointments…

┌─ Export appointments ────────────────────────────┐
│  What to export                                   │
│   ● Selected appointments (12)        [Clear]     │
│   ○ All appointments in the current view (154)    │
│  Columns  ● Schedule ○ Clinical ○ Billing ○ All   │
│  Format   ● Excel  ○ CSV                          │
│                    [ Cancel ]  [ Export 12 ]      │
└───────────────────────────────────────────────────┘
```

**This list filters and pages in the browser.** `appointments-client.tsx` fetches a date window with
`fetch_all`, then applies status, practitioner and billing filters client-side —
`totalRows = filtered.length`. So "what is on screen" is **not** a filter set the server can
reproduce from parameters.

Rather than approximate it, both scopes send the **ids the client is actually showing**. The file is
then exact by construction, and the whole class of "the export covered more rows than the screen"
problem simply does not arise here. The patients export cannot do this — it pages server-side and the
browser never holds more than 100 of 661 rows — which is why that one carries a
`clientOnlyFilters` warning and this one does not.

Selection survives pagination: building a day sheet means paging through the window, and dropping
ticks on "next page" would defeat the feature. The header checkbox is scoped to **this page** and
labelled "Select all on this page"; the dialog's "current view" scope is what covers the window.

**Identical to the patients list**, deliberately: a checkbox on every desktop row, one on every
**mobile card**, a page-scoped header checkbox, and a full-width selection strip under the header.
The mobile card matters — a front-desk tablet renders the card list, not the table, so a selection
that only existed at `md+` would be missing exactly where it is used most. (It was, in the first
pass; corrected 2026-09-22.)

---

## 3. Scoping — the part that matters most here

Unlike the patient list, **this list genuinely restricts rows by practitioner**. ADR-018:
`_practitioner_read_scope` narrows a practitioner to their own appointments when a clinic's
`practitioners_see_all_appointments` flag is off, and a scoped practitioner with no linked
`Healthcare Practitioner` record sees nothing at all.

An export that resolved its own filters would be a second answer to *"which appointments may this
user see"*, and the two would drift. So the filter logic was **extracted** out of `_list_impl` into
`_build_appointment_filters()`, and both the list and the export call it. A `None` return means
"scoped to nothing" — the list returns an empty page, the export refuses.

A selection is intersected with the scope rather than trusted: ticking a row you may not read must
not become a way to export it.

> ⚠️ **Not exercised on this deployment.** `practitioners_see_all_appointments` is unset on
> `remedisys.localhost`, so `_practitioner_read_scope` returns `ALL` and every role exported all 154
> rows in testing. The structural guarantee — one filter builder, shared with the list — holds
> regardless, but the narrowed path has not been observed end-to-end here. Worth exercising on a site
> that has the flag on before this reaches a clinic that does.

---

## 4. Columns

| Set | Contents |
|---|---|
| **Schedule** | Appointment, date, time, duration, patient, MRN, practitioner, department, status |
| **Clinical** | Adds gender, age, type, service unit, notes |
| **Billing** | Payment method, paid, invoice, billing status, status |
| **Everything** | Every column above, plus clinic and booked-on |

`billing_status` (Unbilled / Pending / Paid) is derived from the linked Sales Invoice the same way the
list's own billing filter derives it — a column that disagreed with the filter that produced the rows
would be worse than no column. A test asserts `full` is a superset of every other set, so
"Everything" cannot quietly lack a column another preset offers.

---

## 5. Permissions

> **Correction, 2026-09-23.** These grants were first written as standalone patches that set
> `Custom DocPerm` rows directly. **Every one of them was silently undone by the next
> `bench migrate`**: `patches.v0.rebuild_eb_role_permissions` reconciles every `EB_` role from
> [`eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json), so a row
> set by hand does not survive. The grants now live in that spec, re-applied by
> `patches.v0.apply_eb_docperm_spec_20260923`, and were verified to survive a migrate.

Gated on Frappe's native `can_export("Patient Appointment")`. Measured 2026-09-22, **before** the
patch below, `EB_Front Desk` held `export = 0` — the role that books, reschedules and chases
appointments all day was the only staff role that could not export the screen it lives on.

[`patches/v0/eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json)
grants it that one flag, and nothing else.

| Role | Export | |
|---|---|---|
| EB_Healthcare Admin | yes | pre-existing |
| EB_Practitioner | yes | pre-existing |
| EB_Nurse | yes | **pre-existing — see below** |
| EB_Front Desk | yes | granted by the patch |
| EB_Patient | no | |

> **Open question, deliberately not decided here.** `EB_Nurse` holds export on Patient Appointment
> but deliberately holds neither export nor import on Patient. That asymmetry may be wrong, but
> *revoking* a permission is a behaviour change with its own consequences, and doing it silently
> inside an unrelated feature would be worse than leaving it visible. Flagged for a decision.

---

## 6. Files

**Backend — new:** [`services/tabular_export.py`](../../remedisys_healthcare_ai/services/tabular_export.py) ·
[`services/appointment_export.py`](../../remedisys_healthcare_ai/services/appointment_export.py) ·
[`patches/v0/eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json) ·
`tests/appointments/test_appointment_export.py`

**Backend — changed:** `api/v1/appointments/api.py` — `_build_appointment_filters` extracted from
`_list_impl`, plus `export_appointments()`. `services/patient_export.py` now delegates its cap,
sanitiser and file writer to `tabular_export`.

**Frontend — new:** `src/components/narzim/shared/export-dialog.tsx` (shared with patients) ·
`src/components/narzim/appointments/appointment-data-menu.tsx` ·
`src/lib/api/appointment-transfer.ts` · `src/app/api/appointments/export/route.ts`

**Frontend — changed:** `appointments-client.tsx` (selection, checkbox column, selection bar, menu) ·
`roles.ts` (`exportAppointments` capability) · `export-patients-dialog.tsx` (now configures the shared
dialog) · message catalogs.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-23 | Anant Sharma (AI-assisted) | Permission grants moved into `eb_docperm_spec.json` — the standalone grant patches were being wiped by every `bench migrate` |
| 1.1 | 2026-09-22 | Anant Sharma (AI-assisted) | Selection brought to parity with the patients list — checkbox on the mobile card list, selection bar moved to page level |
| 1.0 | 2026-09-22 | Anant Sharma (AI-assisted) | Initial version — selection, id-based export scopes, ADR-018 scoping, permissions |
