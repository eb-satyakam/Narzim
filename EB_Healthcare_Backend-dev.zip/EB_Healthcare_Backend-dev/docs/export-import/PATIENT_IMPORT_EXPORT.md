# Patient Import and Export

**Doc status:** living · **Created:** 2026-09-22 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-23 by Anant Sharma (AI-assisted) · **Version:** 2.7

> **Built and verified on `dev`, 2026-09-22.** Both dependencies the draft left open dissolved on
> contact with the code (§10), and two of its claims were wrong — the practitioner-scoping
> requirement in §4.3 and the label contract in §6.1. Both are corrected below with what was
> actually found.

Bulk **export** of the patient directory and bulk **import** of patients, both reached from the
`/patients` list screen. The appointments list has an export too — export only, and scoped differently;
see [`APPOINTMENT_EXPORT.md`](APPOINTMENT_EXPORT.md). The mechanics both share live in
[`services/tabular_export.py`](../../remedisys_healthcare_ai/services/tabular_export.py). This document states what we want, what we will build, and exactly how each
flow works end to end.

**Scope.** Staff-facing only. A patient exporting *their own* record — a data-portability right under
LFPDPPP (Mexico) and DPDPA 2023 (India) — is a different feature, with a different audience, a
different endpoint and a different consent story. It is **out of scope here** and is not addressed by
anything below.

**Phase.** Phase 4 (Operations). Extends the existing `patients` module, which completed in Phase 1.

---

## 1. What we want

### 1.1 Goals

| # | Goal | Why it matters |
|---|---|---|
| G1 | Front desk can export the patients they are looking at, as a spreadsheet | Call lists, vaccination campaigns, reconciliation against paper records — today this is done by hand |
| G2 | Clinic admin can bulk-load patients from a previous system or a spreadsheet | Onboarding a clinic currently means typing every patient into the registration drawer |
| G3 | The person filling the file can tell what format it wants **without being told** | An import feature nobody can work out the format for is an import feature nobody uses |
| G4 | A bulk import can never silently create duplicate charts | Two charts for one child means the allergy sits on the chart the doctor is not reading |
| G5 | Bulk PHI leaving the system is recorded | A CSV of 661 patients is the largest single disclosure surface in the product |

### 1.2 Non-goals

- **Merging** two existing patients. No merge tool exists, and this does not add one.
- **Updating** existing patients from a file. Import **creates** only; an update path is a separate
  design with a separate blast radius.
- Importing appointments, encounters, vitals, invoices or documents. Patients only.
- The patient-facing export of one's own record (see Scope above).

### 1.3 Assumed decisions

Carried into this design; each can be reversed, and §10 tracks them.

| # | Assumption | Outcome as built |
|---|---|---|
| A1 | **Export scope = the current filter set.** No per-row checkboxes | Held. The dialog offers "current filters (N)" or "all (N)" and states the count on the button |
| A2 | **Export:** Front Desk + Clinic Admin. **Import:** Clinic Admin only. Nurse: neither | Held, but implemented through Frappe's **native** `can_export` / `can_import` on Patient rather than a role list in Python, so an administrator changes it in the Role Permissions Manager. Required a patch: nobody held `import`, and Front Desk did not hold `export` |
| A3 | **One guardian per imported row.** Additional guardians are added afterwards on the chart | Held |
| A4 | Direct browser download only. The file is never emailed or pushed to external storage | Held |

---

## 2. What exists today

Verified against `dev` on 2026-09-22.

### 2.1 Nothing in patients imports or exports

[`api/v1/patients/api.py`](../../remedisys_healthcare_ai/api/v1/patients/api.py) is 2,770 lines with
roughly twenty whitelisted methods. None of them import or export. This is new surface.

### 2.2 The patient list has no row selection

The table headers in `patients-client.tsx` (frontend repo, `src/app/(clinic)/patients/`) are Name,
MRN, Gender, Age, Practitioner, Last Visit, Next Appointment, Status. There is **no checkbox column
and no selection state anywhere in the 1,767-line component**. "Select all and export" therefore has
no existing mechanism to build on — which is what decides A1.

### 2.3 An export already exists, in Billing — and it should not be copied

`billing-client.tsx` builds a CSV in the browser and triggers a download. Two defects would be
inherited:

1. The `useCallback` dependency array names `invRows` while the body reads `invFiltered` — a filter
   change can export the previous filter's rows.
2. Values are wrapped in quotes but never escaped, so a name containing a quote breaks column
   alignment silently. No CSV-injection guard either.

### 2.4 An import already exists, for one patient — and its shape is right

[`scan_registration_form()`](../../remedisys_healthcare_ai/api/v1/patients/api.py) reads a
photographed paper registration form and, in its own words:

> "Creates NOTHING. The response is editable form state for the Register Patient drawer;
> `create_patient()` — called afterwards by the human pressing Save — remains the only thing that
> writes (Rule 6)."

Bulk import is this contract at N rows instead of one.

### 2.5 A tiered duplicate matcher is already in production

[`services/patients.py::find_duplicate_candidates()`](../../remedisys_healthcare_ai/services/patients.py)
matches on uid → name + date of birth → name → phone/email, and returns `{tier, candidates,
checked_on}`. `checked_on` names the fields there was actually something to compare, so a caller can
distinguish *"checked, no match"* from *"had nothing to check"*.

Import reuses it unchanged. Its frontend counterpart, `DuplicateMatchDialog` with `shouldBlock`, is
also already written.

### 2.6 The numbers that shape the design

Measured on `remedisys.localhost`, 2026-09-22:

```sql
SELECT COUNT(*), SUM(uid IS NOT NULL AND uid != ''),
       SUM(mobile IS NOT NULL AND mobile != ''), SUM(dob IS NOT NULL)
FROM `tabPatient`;

patients  with_curp  with_mobile  with_dob
661       3          26           82
```

**3 of 661 patients carry a CURP.** The only duplicate check inside `create_patient()` is on CURP, so
it is effective on 0.45% of records. Mobile is present on 4%, date of birth on 12%. This single fact
is why the import preview (§5.2) is not optional and why `find_duplicate_candidates` must be used
instead of the CURP check alone.

### 2.7 Constraints inherited from the existing code

| Constraint | Source | Consequence |
|---|---|---|
| `list_patients` caps `page_size` at 100 | `api.py` | A browser-side export can only ever see one page of a 661-row directory |
| Age, Member Since, Last-Visit range and `Deceased` are **client-side filters only** | `patients-client.tsx` | A server-side export cannot reproduce them — see §4.5 |
| ~~Practitioner scoping is applied **in the UI**~~ — **WRONG, see §4.3** | `patients-client.tsx` | The UI narrows the practitioner *filter's option list*, not the rows. `list_patients` applies no row-level practitioner filter, so a doctor already sees every patient |
| Frappe's built-in Data Import is unavailable | CLAUDE.md §3, §11 | It writes to `Patient` directly, bypassing the MRN naming series, the CURP check, `_validate_links` and guardian/address nesting |
| The browser never talks to Frappe directly | ADR-010 / ADR-011 | Every call goes through a Next.js BFF route handler |

---

## 3. What we will build

Two features, four new endpoints, one new menu.

```
[ 🔍 Search patients… ] [ 📅 Registered ▾ ] [ 📋 List ▾ ] │ [ ⇅ Data ▾ ] [ + Register patient ▾ ]
                                                            │              └─ Scan form
                                                            ├─ ⬇ Export patients…   └─ Manually
                                                            └─ ⬆ Import patients…
```

**Why a separate "Data" menu rather than two more items under Register.** `RegisterPatientButton`
documents itself as *"TWO ROUTES, ONE DESTINATION"* — scan and manual both end at the same drawer, so
they are two ways to do one thing. Import ends at a review table and then N records; export writes
nothing at all. Adding them there would break the invariant the component's own comment states.

**Why the trigger is role-gated, not just the endpoint.** `RegisterPatientButton` returns `null` when
the role cannot create, with the comment *"offering a button that 403s is worse than offering none"*.
Same rule applies.

### 3.1 The write path is unchanged

```
import row ──► create_patient() ──► Patient doctype
```

`create_patient()` remains **the only thing that creates a patient**. Import validates, proposes and
orchestrates; it never writes a row itself. This is what keeps the MRN naming series, the CURP
uniqueness check, `_validate_links`, guardian creation and address creation in one place.

### 3.2 Rejected alternatives

| Approach | Why rejected |
|---|---|
| Frappe Desk Data Import | Bypasses `create_patient()` and therefore the MRN series, the CURP check, `_validate_links` and guardian/address nesting; requires giving front-desk staff Desk access; violates the "custom whitelisted methods only" lock |
| Client-side CSV, as Billing does | Cannot write, so it does not solve import; for export it sees at most 100 of 661 rows, logs no PHI egress, and inherits the two defects in §2.3 |
| ~~Checkbox selection with a "select all" header~~ — **now implemented, see §4.5** | Rejected in v1.0 because a header "select all" can only tick loaded rows. The objection was real but did not justify withholding the feature: it is answered by scoping the header checkbox to **this page** and labelling it so, while the dialog's "All patients" scope covers the whole directory. Selection and filter scope now coexist as three explicit options rather than two competing meanings |
| Background RQ job + an import-status doctype | Correct above a few thousand rows, but needs a new custom doctype (ADR required, CLAUDE.md §12) plus polling and job state, to solve a problem a 500-row cap does not yet have. Revisit when a real file exceeds the cap |

---

## 4. Flow A — Export

### 4.1 The five layers

```mermaid
flowchart TD
    A["① BROWSER — patients-client.tsx<br/>no token, no Frappe URL"] -->|"POST /api/patients/export"| B
    B["② BFF — src/app/api/patients/export/route.ts<br/>getAccessToken() from httpOnly cookie"] -->|"Bearer JWT"| C
    C["③ API — api/v1/patients/api.py::export_patients()<br/>permission · role · rate limit · scope"] --> D
    D["④ SERVICE — services/patient_export.py<br/>query · serialise · sanitise"] --> E
    E["⑤ DB — tabPatient (Frappe ORM only)"]
    C -->|"audit row: who/when/how many — never the data"| F["Export audit"]
```

### 4.2 What the user does

```
Maria (Front Desk) is on /patients
  │
  ├─ types "ram" in search                → globalFilter (debounced)
  ├─ Registered ▾ → This month            → dateScope
  ├─ Gender ▾ → Female                    → filters.gender
  │     chips row:  [This month ×] [Female ×]        table: 43 rows
  │
  ├─ Data ▾ → Export patients…
  │     ● Patients matching current filters (43)
  │     ○ All patients (661)
  │     Columns: ● Directory ○ Contact ○ Clinical ○ Custom
  │     Format:  ● .xlsx  ○ .csv
  │     [ Export 43 ]
  │
  └─ file downloads → toast "43 patients exported."
```

The button reads **"Export 43"**, not "Export". The count comes from the same `totalRows` the list
footer already shows, so the dialog cannot disagree with the screen behind it, and nobody discovers
the scope only after opening the file.

### 4.3 What happens per hop

| Hop | Does |
|---|---|
| **① Browser** | Reuses the filter object the list **already builds** for its own query — `search`, `gender`, `status`, `filter_today`, `filter_new`, `filter_balance_due`, `filter_favorites`, `filter_practitioner`, `filter_min_visits`, `created_from`, `created_to`, `sort_by`, `sort_dir` — minus `page`/`page_size`, plus `columns` and `format` |
| **② BFF route** | `getAccessToken()`; 401 if absent. Forwards with `Authorization: Bearer`. **Streams** the response through, preserving `Content-Type`, `Content-Length` and `Content-Disposition` — the same pattern `src/app/api/drive/[id]/download/route.ts` already uses for bytes |
| **③ API** | `require_permission("Patient", "read")` · `frappe.permissions.can_export("Patient")` · rate limit 10/hour · caps at 5,000 rows, else 413. **No extra practitioner scoping** — see the correction below |
| **④ Service** | Runs the same query builder `list_patients` uses, with the pagination cap lifted internally — it does **not** loop seven pages. Serialises through `_serialize_patient()` and the existing batch helpers (`_batch_primary_guardians`, `_batch_appointment_data`, `_batch_primary_practitioner`), so 43 rows costs a handful of queries, not 215 |
| **③ on the way back** | Writes the audit row · escapes quotes by doubling · neutralises CSV injection (a cell starting `=`, `+`, `-` or `@` is prefixed) · sets `Content-Disposition: attachment` |

### 4.4 Worked example

Request body:

```json
{ "search": "ram", "gender": "Female",
  "created_from": "2026-09-01", "created_to": "2026-09-30",
  "columns": "directory", "format": "xlsx" }
```

File received — `patients_2026-09-22_43.xlsx`:

| first_name | last_name | mrn | gender | dob | age | status |
|---|---|---|---|---|---|---|
| Sofía | Ramírez | MRN-2026-00412 | Female | 2019-03-11 | 6 yrs | Active |

Audit row written: `user=maria@…, rows=43, columns=directory, filters={…}, at=2026-09-22 14:02`.
The patient data itself is **not** in the audit row (CLAUDE.md Rule 10, §9.9 PHI-8).

**USER STORY.** Maria needs a call list for overdue vaccinations. She filters *Registered this month
· Female*, sees 43 rows, opens the dialog → **the system shows** "Patients matching current filters
(43)" and a button reading "Export 43" → **the database actually contains** one new audit row naming
her, the count, the columns and the filters → **consequence:** the file is the set she meant, and six
months later the clinic can answer who extracted patient data and when. Without the audit row that
question is unanswerable, which is the state Billing's export is in today.

### 4.5 Row selection

Added 2026-09-22 at the requester's direction, reversing A1.

**The controls.** A checkbox on every row (desktop table and the mobile card list, since a front-desk
tablet renders the latter), plus a header checkbox that selects **this page**. Ticks survive
pagination — a receptionist building a call list pages through the directory, and dropping the ticks
on "next page" would defeat the only job the feature has. A bar above the table shows `N selected`
with a Clear action whenever anything is ticked, so a stale selection is never invisible.

**The header checkbox covers the page, not the directory, and says so.** Its label and tooltip read
"Select all on this page". It cannot honestly mean all 661: the browser holds at most one page
(`list_patients` caps `page_size` at 100), so a control labelled "all" that ticked 20 rows would be
lying. Exporting everything is the dialog's "All patients" scope.

**Three scopes, in the dialog:**

```
● Selected patients (12)        [Clear]     ← only shown when something is ticked
○ Patients matching current filters (43)
○ All patients (661)
```

When a selection exists the dialog defaults to it, because ticking rows is an explicit act.

**A selection REPLACES the filters; it does not intersect with them.** This is Frappe's own
precedence — `reportview.py::_export_query` overwrites `form_params["filters"]` when
`selected_items` is present. It matters because the two can disagree: a row ticked before the filters
changed is still a row the user asked for, and intersecting would drop it with no explanation. The
API carries the same parameter name, `selected_items`, and caps it at `MAX_EXPORT_ROWS` so an
unbounded `IN ()` list from a client cannot become a slow query or a way around the row cap.

### 4.6 Correction — there is no practitioner row-scoping, deliberately

The draft of this document said the export "must re-apply practitioner scoping server-side, or a
doctor exports the whole clinic". **That was wrong, and the code does not do it.**

What the screen actually does: `patients-client.tsx` restricts which practitioner appears in the
*Primary Practitioner filter's option list* (`practitionerOptions`) when the user is a doctor. It does
not restrict the rows. `list_patients` applies no row-level practitioner filter at all — a doctor
opening /patients today sees all 661 patients.

So scoping the export would have made the file **disagree with the screen it was pressed from**,
which is the precise failure this feature exists to avoid, and it would have refused users who can
already read every one of those rows a page at a time. It also 403'd a real practitioner account on
this site (`ana@narzim.com`), which has no linked `Healthcare Practitioner` record.

The gate on who may bulk-extract is `can_export`, which an administrator controls. If row-level
scoping is wanted, **it belongs in `list_patients` first** so the screen and the file keep agreeing;
`_export_scope_filters` then inherits it for free. This is recorded in that function's docstring.

### 4.7 The known limitation

Age, Member Since, Last-Visit range and the `Deceased` status are applied **in the browser only**.
A server-side export cannot reproduce them, so "export current filters" with one of those active
would return a **wider** set than the screen shows.

Resolution for v1: the dialog names the ignored filters explicitly ("Age and Last Visit filters are
not applied to exports"). Proper fix: move those filters into `list_patients`, tracked separately.
Silently exporting more than the user can see is not acceptable, so this must be visible in the UI.

### 4.8 Failure paths

| Condition | Response |
|---|---|
| No token / expired | 401 → existing re-auth path |
| Nurse calls the endpoint directly | 403 — and the menu item never rendered for them |
| Filters match 12,000 rows | 413 "Too many patients to export (12,000). Narrow your filters — the limit is 5,000." |
| 11th export within the hour | 429 "Export limit reached. Try again later." |
| Frappe unreachable | Toast "Export failed. Nothing was downloaded." The list itself is untouched |

---

## 5. Flow B — Import

Three server calls, in order. **Only the third writes.**

```
Stage 1   GET  template   →  produces a file      writes nothing
Stage 2   POST preview    →  produces a verdict   writes nothing
Stage 3   POST commit     →  produces patients    WRITES
```

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Parsing: upload .xlsx / .csv
    Parsing --> Error: unreadable or not our template (422)
    Error --> Idle: fix the file, re-upload
    Parsing --> Preview: parsed
    Preview --> Idle: back / re-upload
    Preview --> Committing: confirm + idempotency key
    Committing --> Done: created / skipped / failed
    Done --> [*]
    note right of Preview
        Nothing has been written.
        Every arrow before Committing
        is reversible.
    end note
```

### 5.1 Stage 1 — template

```
Admin: Data ▾ → Import patients… → [ ⬇ Download template (.xlsx) ]
  │  GET /api/patients/import/template
  ▼  ② route.ts → ③ get_import_template()  [require_roles(ROLE_ADMIN)]
  ▼  ④ services/patient_import.py::build_template()
```

The template is **generated at runtime from `create_patient()`'s parameter list and the live option
sources** — never hand-written. `create_patient()` takes roughly forty named parameters; a
hand-maintained template is wrong the first time one is added.

- **Sheet 1 "Patients"** — header row, one example row, dropdown validation bound to the value lists.
- **Sheet 2 "Valid values"** — read at generation time from `Gender` (the doctype),
  `_BLOOD_GROUP_OPTIONS` and `_MARITAL_STATUS_OPTIONS`.

### 5.2 Stage 2 — preview (the safety gate)

```
Admin drops migration_300.xlsx
  │  POST /api/patients/import/preview      multipart/form-data, file=<xlsx>
  ▼
② src/app/api/patients/import/preview/route.ts
   Copies scan-form/route.ts exactly: getAccessToken(), rebuild the FormData,
   forward with Authorization: Bearer, pass 422 through as a NORMAL outcome
   (the upload was readable but is not our template) rather than a server fault.
  ▼
③ preview_patient_import()
   require_roles(ROLE_ADMIN) · require_permission("Patient", "create")
   rate limit 20/hour · reject > 500 rows (413)
  ▼
④ services/patient_import.py::preview()   — PER ROW:
     1. parse and trim          — `_clean`, the same helper create_patient uses
     2. required                — first_name, gender
     3. enum checks             — gender ∈ Gender doctype
                                  blood_group ∈ _BLOOD_GROUP_OPTIONS
                                  marital_status ∈ _MARITAL_STATUS_OPTIONS
                                  status ∈ {Active, Disabled}
     4. link checks             — _validate_links(country, language, …)
     5. re-nest                 — guardian_1_* → guardians[] · address_* → address{}
     6. duplicates              — find_duplicate_candidates(first_name, last_name,
                                  dob, mobile, email, uid) → {tier, candidates, checked_on}
     7. in-file duplicates      — row 12 against row 288 of the SAME upload
   RETURNS a verdict per row. INSERTS NOTHING.
```

What the admin then sees:

```
300 rows read · 271 ready · 22 need attention · 7 cannot be imported

[ All ]  [ Needs attention 22 ]  [ Errors 7 ]

✓  1  Sofía   Ramírez  Female  2019-03-11
⚠  2  Mateo   López    Male    2021-07-02
      Possible duplicate — MRN-2026-00412, matched on name + date of birth
      ( ) Skip     (•) Import anyway
✕  3  (blank)  Cruz    Female  —
      First name is required — column A
✕  4  Ana     Díaz     F       2020-01-09
      Gender "F" is not valid — use Male, Female, Other, Transgender,
      Genderqueer, Non-Conforming, Prefer not to say, Unknown

Rows with errors are skipped.              [ Back ]  [ Import 293 rows ]
```

Errors name the **column** and the **allowed values**, not just the row. This is what makes the
format learnable for the person who ignored the template.

### 5.3 Source B — a Google Sheets link

Added 2026-09-22. The same three stages and the same validation; only where the bytes come from
differs.

```
Import dialog, step 3          [ Choose a .xlsx or .csv file ]
                                            or
                               [ 🔗 Paste a Google Sheets link ]  [ Read sheet ]
```

**How it works.** The link goes to `preview_patient_import(google_sheets_url=...)`, which calls
`services/patient_import.py::fetch_google_sheet()`. That wraps Frappe's own two helpers —
`validate_google_sheets_url` then `get_csv_content_from_google_sheets` — so the mechanism is
identical to Frappe's Data Import. The returned CSV goes through `parse_upload()` exactly as an
uploaded file does, which is what guarantees a sheet and a file cannot validate differently.

**The URL is pinned before any request is made, and that is not cosmetic.** This endpoint takes a URL
from a user and makes the *server* fetch it — server-side request forgery unless the target is
constrained. `validate_google_sheets_url` requires `https`, host exactly `docs.google.com`, and
`/spreadsheets/` in the path. Five tests in `test_patient_transfer.py::TestGoogleSheetsSource` assert
the refusals, including `http://169.254.169.254/latest/meta-data/` (the cloud metadata endpoint), so
the pin fails loudly if it is ever refactored away.

**What it requires of the sheet, and why the warning is where it is.** The fetch is
**unauthenticated** — Frappe requests `/export?format=csv` with no credentials. The sheet therefore
has to be shared "anyone with the link can view"; Frappe's own error text is *"invalid or not
publicly accessible"*. A sheet of names, dates of birth and CURPs shared that way is readable by
anyone holding the link, and sheet links get forwarded.

That exposure belongs to the clinic, and the decision happens at the moment someone shares the sheet
— so the warning sits **next to the input**, not behind a site setting a different person enabled
months earlier. A flag set long ago by someone else does not prevent the act it claims to govern; a
sentence at the point of decision might. The warning also names the alternative: download the sheet
and upload the file.

**On PHI-1 — a correction.** This was first argued as a subprocessor problem. It is not. The request
carries a sheet id; the patient data travels **Google → us**. §9.9 PHI-1 governs subprocessors that
*receive* patient data, so it is not triggered, and no `ComplianceProfile` change is needed. The real
and sufficient objection was always the public-sharing requirement above.

### 5.3.1 How strongly a duplicate is claimed

`find_duplicate_candidates` already grades its own evidence, and the preview
now respects that grade rather than treating every candidate alike.

| Tier | Evidence | In the review |
|---|---|---|
| `confirmed` | same national ID (CURP) | **Needs attention** |
| `probable` | same name **and** same date of birth | **Needs attention** |
| `possible` | same full name, nothing to confirm it with | **Needs attention** |
| `contact` | shares a phone/email, or **one word** of the name | Quiet grey note, row stays `ok` |

**Why the split.** In a single registration a weak match is one prompt a receptionist reads. In a
300-row import it is most of the file: Spanish names carry two surnames, so `González`, `Torres` and
`Mendoza` collide constantly. A real 10-row sheet had **6 rows flagged on a single shared word** —
and the one row that mattered, a `name + date of birth` match against an existing MRN, was styled
identically to them. A warning that fires on 60% of a file is one people learn to click through,
which is precisely how the real match gets missed. `DuplicateMatchDialog`'s own comment warns about
this: *"a prompt that appears on every registration is one people learn to click through."*

A weak match is **never hidden** — it is reported in grey as "Shares part of the name with …
probably a different person", following the matcher's own rule: *"shown so nothing is hidden,
labelled so it makes no claim."* A duplicate check that could not run at all still warns, because
`unavailable` means *we do not know*, which must never read as *no match*.

**Two presentation defects fixed at the same time,** both visible in the same screenshot:

- The row read **"Possible duplicate of —"** with the id missing. The frontend type declared the
  candidate's id as `name`; `services/patients.py::_row` calls it **`patient`**. A test now asserts
  the field names so the contract cannot drift silently again.
- The evidence read **`matched on name_part`** — a raw internal token from the matcher, shown to a
  user as if it were a field they should recognise. There is now a label map:
  `name_part` → "part of the name", `dob` → "date of birth", `uid` → "national ID".

### 5.4 Stage 3 — commit (the only writer)

```
[ Import 293 rows ]
  │  POST /api/patients/import/commit
  │  { idempotency_key: "<uuid minted when the preview loaded>",
  │    rows: [ …the 293 the admin approved… ] }
  ▼
③ commit_patient_import()  [require_roles(ROLE_ADMIN)]
   Idempotency: a key already seen returns the ORIGINAL result and writes nothing.
  ▼
④ services/patient_import.py::commit()   — PER ROW:
     re-validate (never trust the client's echo of the preview)
     create_patient(**row)        ← the ONLY write path
         → naming_series MRN-.YYYY.-
         → CURP uniqueness
         → guardian + address creation
         → Frappe's audit trail records the ADMIN as author
     collect {row, ok, mrn} or {row, ok: false, reason}
  ▼
① Result:
     ✓ 291 created   ⚠ 2 skipped (duplicate, as chosen)   ✕ 0 failed
     [ ⬇ Download failed rows ]     ← fix 7 rows, re-upload 7, not 300
     [ View imported patients ]     ← /patients?created_from=<today>
```

**Per-row commit, not one transaction.** 292 successes must not be discarded because of one late
failure. The idempotency key plus the duplicate matcher make re-running the failures safe.

**USER STORY — the failure this design exists to prevent.** Clinic Admin uploads 300 patients from
the old system; 297 have no CURP. Row 214 carries gender `"F"`. Without a preview, the request errors
mid-file, the first 213 inserts have already committed, and he re-uploads the corrected file →
**the system shows** "300 patients created" → **the database actually contains** 213 patients twice,
because the only duplicate check is on a CURP that 297 of them do not have → **consequence:** a child
has two charts; the September vaccination is recorded against one and the penicillin allergy against
the other, and the encounter screen loads whichever the search hits first. Preview catches row 214
before anything is written; the idempotency key makes the retry a no-op.

---

## 6. The file format — how the user knows what to fill

Three mechanisms, all needed, in the order a real person meets them.

### 6.1 The export file **is** the import template

Same columns, same order, same value spellings. The discovery path becomes: export → open in Excel →
see exactly what the system expects → edit or append rows → import. No documentation to find.

This is why **export is built first** (§9): it defines the format before import needs one.

> **Defect found and fixed while building this, 2026-09-22.** The two modules first carried their own
> label lists, and they disagreed on exactly one column: export wrote the header `Date of birth` while
> the importer expected `Date of birth (YYYY-MM-DD)`. The parser matches on the header, so it silently
> **dropped every date of birth** on re-import — no error, no warning, the column simply vanished.
> Proved by exporting two patients and re-importing the file: `{'first_name': 'Bruno', 'gender':
> 'Male'}` with the DOB gone.
>
> The fix is structural rather than a corrected string: `patient_export._LABELS` is now **derived
> from** `patient_import.IMPORT_COLUMNS`, with only export-only columns (MRN, age, patient name,
> registered on) named separately. Two lists that must agree cannot be kept in two places — this is
> the drift the document warned about in §2.3, found in its own implementation within the hour.

### 6.2 The template carries the allowed values

| Column | Required | Accepts |
|---|---|---|
| `first_name` | **yes** | free text |
| `middle_name` | no | free text |
| `last_name` | no | free text |
| `gender` | **yes** | Male · Female · Other · Transgender · Genderqueer · Non-Conforming · Prefer not to say · Unknown |
| `dob` | no | `YYYY-MM-DD` |
| `blood_group` | no | A Positive · A Negative · AB Positive · AB Negative · B Positive · B Negative · O Positive · O Negative |
| `marital_status` | no | Single · Married · Divorced · Widow |
| `status` | no | Active · Disabled (default Active) |
| `uid` | no | CURP — must be unique across all patients |
| `mobile` · `email` · `phone` | no | free text |
| `occupation` | no | free text |
| `allergies` · `medication` · `medical_history` · `surgical_history` | no | free text |
| `guardian_1_name` · `guardian_1_relation` · `guardian_1_mobile` | no | flattened — see §6.4 |
| `address_line1` · `city` · `state` · `country` · `pincode` | no | flattened — see §6.4 |

The gender list is the `Gender` doctype's contents (eight rows on this site), not a hardcoded enum —
`Patient.sex` is a Link to an open-ended doctype. Blood group and marital status come from
`_BLOOD_GROUP_OPTIONS` and `_MARITAL_STATUS_OPTIONS` in `api/v1/patients/api.py`.

### 6.3 Dates are declared, never guessed

**The defect this replaced.** The first implementation validated dates with `frappe.utils.getdate`.
Measured on 2026-09-22, it infers the field order from the values and changes its mind:

```
getdate("18/06/2002")  ->  2002-06-18     day-first  (18 cannot be a month)
getdate("06/07/2002")  ->  2002-06-07     month-first
getdate("6/7/02")      ->  2002-06-07     two-digit year silently assumed 20xx
```

Both live markets write dates **day-first** (`es-MX`, `en-IN`). So a clinic's migration file would
have had every date whose day is 12 or lower imported silently wrong — roughly 39% of them, with no
error anywhere. A wrong date of birth is not cosmetic in a paediatric clinic: it sets the age that
drives weight-based dosing and the immunization schedule.

**What it does instead.** The import dialog asks, before the file is read:

```
Dates in the file are written as   [ DD/MM/YYYY ]  [ MM/DD/YYYY ]  [ YYYY-MM-DD ]
```

`services/patient_import.py::parse_date` then parses with explicit `strptime` formats for that order
only. ISO is accepted under every setting because it cannot be ambiguous. Anything that does not
match is **refused, not reinterpreted** — `18/06/2002` under MM/DD/YYYY is an error, not a silent
swap. Two-digit years are refused outright: for a date of birth, `02` is 1902 or 2002 and nothing in
the file says which. A date of birth in the future is an error.

Parsed dates are rewritten onto the row as ISO before anything downstream sees them, so nothing
re-guesses the order, and the review table shows the **resolved** date — a user who picked the wrong
order sees `2002-06-07` where they meant July and can go back before anything is written.

### 6.4 Typed values are normalised, not rejected

The first real import run against this feature failed on its only row because the gender column said
`male` rather than `Male`. Technically correct; practically useless — a migration file is typed by
people.

Matching is case-insensitive **and accent-insensitive** against the live option list, with alias
tables for the forms a bilingual clinic actually writes. Accent folding is one rule rather than a
table listing `Tía`, `TÍA` and `tia` separately — a table nobody maintains correctly.

The first pass covered gender and blood group only. A real Spanish file then produced **10 rows and
10 rejections** on the three columns it missed, so all five now have tables:

| Column | Typed | Stored |
|---|---|---|
| gender | `male` · `M` · `Masculino` · `Hombre` | `Male` |
| gender | `F` · `Femenino` · `Mujer` | `Female` |
| blood group | `o+` · `AB-` | `O Positive` · `AB Negative` |
| marital status | `Soltero` · `Soltera` | `Single` |
| marital status | `Casado` · `Casada` | `Married` |
| marital status | `Viudo` · `Viuda` | `Widow` (the option list does not distinguish widower) |
| record status | `Activo` · `Activa` | `Active` |
| record status | `Inactivo` · `Deshabilitado` · `Baja` | `Disabled` |
| guardian relation | `Padre` · `Madre` · `Tutor legal` · `Abuela` · `Tía` · `Hermana` · `Esposo` | `Father` · `Mother` · `Legal Guardian` · `Grandparent` · `Aunt` · `Sibling` · `Husband` |

**Two terms are recognised and deliberately refused**, each with its own instruction rather than a
list of thirteen options:

| Typed | Why not resolved | What the row says |
|---|---|---|
| `Cónyuge` · `Pareja` · `Spouse` | `_GUARDIAN_RELATIONS` keeps **Husband** and **Wife** as two literal terms *"so the record says which"*. Collapsing spouse onto either records a fact the file never stated | "Cónyuge does not say which — write Esposo (Husband) or Esposa (Wife)." |
| `Hija` · `Hijo` · `Daughter` · `Son` | The relation list has no Daughter or Son. A daughter genuinely is a caregiver for an adult patient, but mapping her to `Other` silently discards what the file said | "There is no Daughter relation — use Other, or the relation you mean." |

That distinction is the whole design: **alias what is unambiguous, refuse what is not, and never
downgrade.**

Two rules keep this honest: an alias only ever resolves to a value **the doctype actually holds**
(`normalise_value` checks membership, so it can never invent an option), and the row is rewritten to
the **canonical spelling**, so what reaches `create_patient()` is `Male`, never `male`. A genuinely
unknown value is still refused with the full list of what is accepted.

### 6.5 The preview names each error in the user's words

*"Gender 'F' is not valid — use Male, Female, …"* with the column letter, not *"row 4 invalid"*.

All three mechanisms produce user-visible strings, so every one of them goes through the message
catalogs — `es-MX` and `en-US` (CLAUDE.md §13 rule 10). Validation messages included; that is the
part that normally gets hardcoded.

### 6.4 Flat file, nested API

`create_patient()` takes `guardians` as a **list** and `address` as an **object**; a spreadsheet row
is flat. The template therefore flattens to `guardian_1_*` and a single address, and the import
service re-nests before calling.

Consequence, and it is a real limitation: a patient with three guardians cannot be expressed in one
row. Per A3 the import takes one; guardians two and three are added afterwards on the chart. The
alternative — `guardian_2_*`, `guardian_3_*` columns, or a second sheet keyed by row — is rejected
for v1 because it widens the template for a case a migration does not need.

---

## 7. Permissions, PHI and compliance

> **Correction, 2026-09-23.** These grants were first written as standalone patches that set
> `Custom DocPerm` rows directly. **Every one of them was silently undone by the next
> `bench migrate`**: `patches.v0.rebuild_eb_role_permissions` reconciles every `EB_` role from
> [`eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json), so a row
> set by hand does not survive. The grants now live in that spec, re-applied by
> `patches.v0.apply_eb_docperm_spec_20260923`, and were verified to survive a migrate.

| Rule | How this design satisfies it |
|---|---|
| Rule 1 — upgrade-safe | No core files touched; all code in `remedisys_healthcare_ai` |
| Rule 4 / Rule 6 — writes go through the human | Preview creates nothing; `create_patient()` is the only writer; Frappe's audit trail records the admin |
| Rule 10 — no PHI in logs | The export audit row stores who/when/count/columns/filters — **never** the patient data |
| §9.9 PHI-6 — minimum necessary | Column presets: an export defaults to Directory, not every field |
| §9.9 PHI-8 — no PHI to third parties | A4: direct browser download only. Emailing a file or writing it to external storage would make that destination a subprocessor, requiring a `ComplianceProfile` change under PHI-1 |
| §11 — tests on persistence and safety | `tests/patients/test_patient_import.py` is mandatory, not optional |

**Role matrix**

Enforced by Frappe's native `can_export` / `can_import` on the Patient doctype, granted by
[`patches/v0/eb_docperm_spec.json`](../../remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json).
**Verified by calling the endpoints as each role on 2026-09-22:**

| Role | Export | Import template | Import commit |
|---|---|---|---|
| EB_Healthcare Admin / System Manager | file | file | 200 |
| EB_Front Desk | file | 403 | 403 |
| EB_Practitioner | file | 403 | 403 |
| EB_Nurse | 403 | 403 | 403 |

The frontend mirrors this in `mergeCapabilities` (`exportPatients` / `importPatients`), so the menu
never offers an action the API would refuse.

---

## 8. Files touched

### Backend — new

- `remedisys_healthcare_ai/api/v1/patients/api.py` → `export_patients()`, `get_import_template()`,
  `preview_patient_import()`, `commit_patient_import()`
- `remedisys_healthcare_ai/services/patient_export.py`
- `remedisys_healthcare_ai/services/patient_import.py`
- Export audit storage — **open, see §10**
- `remedisys_healthcare_ai/tests/patients/test_patient_import.py`

### Backend — reused unchanged

`create_patient()` · `_clean` · `_validate_links` · `_serialize_patient` · the `_batch_*` helpers ·
`services/patients.py::find_duplicate_candidates()` · `utils.py::require_permission`, `require_roles`,
`rate_limit`

### Frontend — new (`remedisys-ai-ehr`)

- `src/app/api/patients/export/route.ts`
- `src/app/api/patients/import/template/route.ts`
- `src/app/api/patients/import/preview/route.ts`
- `src/app/api/patients/import/commit/route.ts`
- `src/components/narzim/patients/patient-data-menu.tsx`
- `src/components/narzim/patients/export-patients-dialog.tsx`
- `src/components/narzim/patients/import-patients-dialog.tsx`
- Message-catalog entries, `es-MX` + `en-US`

### Frontend — modified

- `src/app/(clinic)/patients/patients-client.tsx` — render `<PatientDataMenu />` beside
  `<RegisterPatientButton />`, expose the filter object it already builds, and hold the row selection
  (checkbox column, page select-all, selection bar)

### Frontend — reused unchanged

`DuplicateMatchDialog` · `getAccessToken` · `frappeFetchSet` · `frappeErrResponse` · `withFrappeDebug`

---

## 9. Build order

| # | Step | Why here |
|---|---|---|
| 1 | `export_patients()` + the dialog | Ships value on its own, and its output file **is** the import template — so it defines the format before import needs one |
| 2 | `get_import_template()` | Same columns as the export |
| 3 | `preview_patient_import()` | The largest piece, and carries no write risk while it is being built |
| 4 | `commit_patient_import()` | Last, behind tests |

---

## 10. Open decisions — both resolved

Both dependencies the draft treated as blocking dissolved once the code was checked. Recorded here
because the reasoning matters more than the outcome: in each case the answer was that Frappe already
does this, so doing it our own way would have been the expensive choice.

1. **~~Where does the export audit row live?~~ RESOLVED — Frappe's `Access Log`.** No new doctype and
   therefore no ADR. `Access Log` is a core doctype whose entire purpose is recording who exported
   what, and `frappe/desk/reportview.py::_export_query` writes one on every Frappe export — so patient
   exports now appear in the same log an administrator already reads, rather than in a bespoke table
   only this feature knows about. Verified: a CSV export by `Administrator` produced
   `{'user': 'Administrator', 'file_type': 'CSV', 'report_name': 'Patient export (directory, 557
   rows)', 'filters': '{"gender": "Female"}'}` — who, when, how many, which filters, and no patient
   data. Note it is written with `deferred_insert()`, so the row appears once the deferred queue
   flushes, not synchronously.
2. **~~`.xlsx` needs `openpyxl`~~ RESOLVED — no new dependency.** Frappe already ships `openpyxl`
   3.1.5 and `xlsxwriter`, and exposes `frappe.utils.xlsxutils.make_xlsx` plus the same two readers
   its own Data Import uses (`read_csv_content`, `read_xlsx_file_from_attached_file`). The feature
   uses those, so a file that opens in Frappe's importer opens in ours.

### What remains genuinely open

- **Row-level practitioner scoping** — not implemented, deliberately (§4.5). If wanted, it belongs in
  `list_patients` first so the screen and the export keep agreeing.
- **Client-side-only filters** (§4.6) — the dialog names them rather than silently exporting a wider
  set. Moving them server-side is the real fix.
- **Async import above 500 rows** — the cap defers it. The trigger to revisit is the first real
  migration file that exceeds it.

## 11. Risks

| Risk | Mitigation |
|---|---|
| Bulk PHI egress with no record | The audit row (§4.3), pending decision 1 |
| Duplicate patients from a re-run import | Preview + `find_duplicate_candidates` + idempotency key |
| Partial commit leaving the file half-applied | Per-row commit + failed-rows download + idempotent retry |
| Export scope wider than the screen shows | The dialog names the ignored client-side filters (§4.5) |
| A doctor exporting the whole clinic | Practitioner scoping re-applied server-side (§4.3) |
| CSV injection when the file opens in Excel | `=`, `+`, `-`, `@` prefixed on export |
| Broken columns from unescaped quotes | Quotes doubled, not merely wrapped — the defect in §2.3 |
| Unbounded request time on a large file | 500-row import cap, 5,000-row export cap; async job deferred until a real file exceeds them |
| Hardcoded English in validation messages | All strings via the message catalogs, `es-MX` + `en-US` |

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.7 | 2026-09-23 | Anant Sharma (AI-assisted) | Permission grants moved into `eb_docperm_spec.json` — the standalone grant patches were being wiped by every `bench migrate` |
| 2.6 | 2026-09-22 | Anant Sharma (AI-assisted) | Export mechanics extracted to `services/tabular_export.py`, shared with the new appointment export; dialog chrome shared too |
| 2.5 | 2026-09-22 | Anant Sharma (AI-assisted) | Duplicate warnings graded by the matcher's own tier — a shared surname no longer reads like a real duplicate (§5.3.1); fixed the blank MRN and the raw `name_part` token in the review row |
| 2.4 | 2026-09-22 | Anant Sharma (AI-assisted) | Spanish aliases extended to marital status, record status and guardian relation (the first pass covered only gender and blood group, and a real Spanish file failed 10 of 10 rows); accent-insensitive matching; ambiguous terms refused with a specific instruction instead of being guessed (§6.4) |
| 2.3 | 2026-09-22 | Anant Sharma (AI-assisted) | Dates now parsed under a declared field order rather than `getdate`'s guess (§6.3) — it mis-read day-first dates whose day was ≤ 12; typed values normalised case-insensitively with es-MX aliases (§6.4) |
| 2.2 | 2026-09-22 | Anant Sharma (AI-assisted) | Google Sheets link accepted as an import source (§5.3), using Frappe's own pinned-URL helpers; corrected the earlier PHI-1 reasoning — Google receives no patient data, the objection is the public-sharing requirement |
| 2.1 | 2026-09-22 | Anant Sharma (AI-assisted) | Row selection added at the requester's direction, reversing A1: checkbox column, page-scoped select-all, selection bar, and a third export scope backed by `selected_items` with Frappe's selection-overrides-filters precedence (§4.5) |
| 2.0 | 2026-09-22 | Anant Sharma (AI-assisted) | Built and verified. Both open decisions resolved (Access Log, no new dependency); corrected the practitioner-scoping requirement (§4.5) and recorded the export/import label-drift defect found in testing (§6.1); role matrix replaced with measured results |
| 1.0 | 2026-09-22 | Anant Sharma (AI-assisted) | Initial draft — goals, flows, format spec, open decisions |
