# Admin — Patient 360 redesign

**Doc status:** living · **Created:** 2026-09-29 by Ashutosh (AI-assisted) · **Updated:** 2026-09-29 by Ashutosh (AI-assisted) · **Version:** 1.0

Rebuilding the Patient 360 chart for the **Admin** role against the Narzim
design. Fourth and last in the series, after
[`frontdesk_redesign_patient360.md`](frontdesk_redesign_patient360.md),
[`nurse_redesign_patient360.md`](nurse_redesign_patient360.md) and
[`doctor_redesign_patient360.md`](doctor_redesign_patient360.md).

Read the front-desk document for the shared groundwork (design tokens,
`.nz-design` scoping, the Tailwind v4 traps, the shared card components) and the
nurse one for `chart-band.tsx` and `vitals-trend.tsx`. **This document records
only what is specific to admin**, plus one open question that belongs to the
whole series (§6).

**Scope of this pass, as set by the user:** match the design's UI and CSS
exactly, show only what is currently present and what the backend actually has,
and add nothing else. That constraint did most of the design work — see §5.

---

## 1. Where the design lives

| | |
|---|---|
| File | `Patients.dc.html`, `role === 'admin'` (around line 545) |
| Purpose line | *"Record quality, money, consents and who opened this chart."* |
| Read via | `DesignSync(get_file)` for the source, plus the live canvas with the other three roles **off** |

**`rail` is dead config — confirmed for the fourth and final time.** Admin
defines one at line 549 (Record / Financial / Care team groups). There is no
`ch.rail` anywhere in the markup. Every role defines a rail; no role renders one.
Do not build it.

**Admin has no `tables` key.** Unlike nurse (`{overview:['vit'], visits:[…]}`)
and doctor (`{overview:['enc'], results:[…]}`), the admin config defines none —
so an administrator's Overview is cards only.

---

## 2. What the design specifies

```
‹ ⬤ Roberto Castillo B+ 38y3m·M [Admin task]      [Access log] [Edit record] [Export record]

● Allergy·Ibuprofen ● Record 71% complete ● Telemedicine consent missing ● No duplicates
                  "Record quality, money, consents and who opened this chart."

● RECORD INTEGRITY  ● LIFETIME BILLED   ● OUTSTANDING    ● CONSENTS
  71%                 $38,600             $0               4 of 5
  5 of 7 complete     since 2021          all settled      telemedicine missing

Overview · Billing & claims · Consents · Communications · Access log

🔒 Clinical notes, diagnoses, results and prescriptions are visible to doctors and nurses only.

[Record integrity  Fix gaps →] [Consents  All →] [Recent access  Full log →] [Account  Billing →]
```

Source, verbatim:

```js
kpis: [K('Record integrity', integ.pct, integ.label, 'warn'),
       K('Lifetime billed', '$38,600', 'since ' + pt.since),        // ← four args, no tone
       K('Outstanding', bal ? $(bal) : '$0', …, bal ? 'warn' : 'ok'),
       K('Consents', '4 of 5', 'telemedicine missing', 'warn')],
notice: HIDE,
cards: { overview: [C('Record integrity','prog',integ,{act:['Fix gaps', say(…)]}),
                    C('Consents','rows',consents.slice(0,4),{act:['All',tabTo('consents')]}),
                    C('Recent access','rows',access.slice(0,3),{act:['Full log',tabTo('audit')]}),
                    C('Account','stats',billStats,{act:['Billing',tabTo('billing')]})], … }
```

**`Lifetime billed` passes no tone at all.** `K(k, v, sub, tone, go)` with four
arguments leaves `tone` undefined, which resolves to `none` — ink value, grey
dot. Reproduced exactly; money already taken is not news.

**No admin KPI passes `go`**, so not one tile is clickable and none renders the
chevron. Front desk remains the only role whose tiles navigate. Verified live:
zero `svg` in all four tiles.

---

## 3. What was built

### 3.1 Per-role tab order

`patient-screen.tsx` → `TAB_ORDER_BY_ROLE.admin`:

```
summary · billing · messages · portalMessages · documents
                    └── the design's "Communications" ──┘
· appointments · activity · orders · medications · immunizations · encounters
· vitals · conditions · history · family · tasks · referrals
  └──────────────────── ours, after the design's ────────────────────┘
```

Three of the design's five tabs do not exist here and are not faked:

| Design tab | Here |
|---|---|
| Billing & **claims** | `insurance/api.py` exposes policies and coverage and **no claims endpoint at all**. So it is our Billing. |
| **Consents** | No consents tab. This app's consent panel lives on the WhatsApp Chat tab, which is where the Overview's Consents card points. |
| **Access log** | Not built — §5. |

### 3.2 `admin-band.tsx`

Renders through the shared `ChartBand`, so every measurement, the `T` tone table
and the value-colour rule are inherited rather than restated.

**Chips**

| Chip | Source | Tone |
|---|---|---|
| `Allergy · <name>` (max 2) | `patient.allergies` | `crit` |
| `Record N% complete` | `profileGaps()` | `warn` |
| `No consent · <channels>` | `usePatientConsents()` | `warn` |
| `Balance due · <amount>` | `usePatientBalance()` | `warn` |

**Tiles**, live on `MRN-2026-0000001`:

```
● RECORD INTEGRITY  ● LIFETIME BILLED  ● OUTSTANDING      ● CONSENTS
  63%                 0 INR              20,400 INR         0 of 3 granted
  5 of 8 complete     since 2026         to be billed       WhatsApp, SMS, Email not on file
  warn                ink (no tone)      warn               warn
```

`since 2026` comes from the real `patient.creation` — added to the payload for
the front-desk chart on 2026-09-28 — not from the design's `pt.since` demo
constant.

### 3.3 Record integrity is the front desk's number

`profileGaps()` from `reception-model.ts`, unchanged. It already drives
reception's Profile tile and its "To complete profile" card; reusing it means an
administrator auditing record quality and a receptionist correcting it are
looking at **one** number. A second, admin-specific definition of "complete" is
exactly the defect that file was written to end.

**The design's seven checks are not ours.** It lists Identity verified,
Duplicates checked, Core consent, Insurance verified, Emergency contact, Photo,
Telemedicine consent. Three have no backing field or reachable endpoint
(duplicates, core consent, telemedicine consent — §5), and two more are
*verification states this app does not record*: it records whether a UID and a
policy are **on file**, which is not the same claim as "verified". So the
checklist is our eight real fields — photo, emergency contact, mobile, address,
email, date of birth, blood group, UID — each a fact about the record rather
than a judgement about it.

### 3.4 `NzProgress` — the design's `prog` card body

New in `nz-card.tsx`. Spec from the `c.isProg` branch plus the `PG()` helper at
line 475, verified live with `getComputedStyle`:

```
body    0 16px 16px · gap 12            ✓
track   h8 · r99 · --ink-25 · overflow hidden   ✓ rgb(242,245,246)
fill    w={pct} · r99                   ✓ 63% · rgb(15,122,111)
pct     800 14px/1                      ✓
label   500 12px/1 --ink-500            ✓ rgb(91,113,120)
checks  grid repeat(2,minmax(0,1fr)) · gap 8px 12px   ✓ 147.75px × 2
mark    16×16 · r50% · #fff · 800 10px/16px          ✓
```

**The colour rule is asymmetric, and that is the design's own:**

```js
bar fill   done === total ? --ok-solid : --teal-500
mark bg    ok ? --ok-solid : --warn-solid
item text  ok ? --ink-800  : --warn-fg
```

So an incomplete record's **bar is teal** — progress, not a fault — while its
missing **rows are amber** — a thing to go and do. Only a finished record turns
the bar green. Copying one colour to both ends would either nag about normal
progress or hide the gaps.

### 3.5 Consents — our three channels

`Patient Communication Consent.channel` offers exactly **WhatsApp / SMS /
Email**, with status Granted / Revoked / Expired / Blocked. The design's five
clinical consents (health-record storage, AI note drafting, research use,
telemedicine) do not exist here, and rows for them would claim a consent
framework this clinic does not operate.

Decision with the user, 2026-09-29: **show the channels we really hold.** The
KPI reads `0 of 3 granted` — not reception's "complete", because a profile field
is complete or not while a consent is *granted* or not, and "complete" reads as
a paperwork score rather than an authorization a patient gave.

**A revoked consent keeps its date.** "Agreed 14 Mar, withdrew 2 Sep" is the
record; an empty row would say nobody ever asked. The backend already returns
the whole history for this reason — see the docstring on `get_consent_status`.

**The `channel` passthrough was a frontend-only fix.** `get_consent_status(patient,
channel="WhatsApp")` has always taken a channel; `/api/consent/status` simply
never forwarded one, so every caller silently got WhatsApp. Omitting it still
does, so the existing consent panel is untouched — the admin chart is the first
caller that needed the other two.

### 3.6 Overview blocks removed for admin

| Removed | Still reachable at |
|---|---|
| Last encounter summary | Encounters tab |
| Patient history box | History tab |
| Vitals table + growth chart | replaced by `VitalsTrend` |

Gated on `role === "admin"`, so no other role's Overview moved. `VitalsTrend` is
the identical component the nurse and doctor read — three roles, one set of
thresholds, so "abnormal" cannot come to mean different things depending on who
opened the chart.

### 3.7 Patient history restored to nurse and doctor

Not an admin change, recorded here because it happened in this pass. The box had
gone out of the nurse and doctor Overview earlier the same day **as a
side-effect**: what was being replaced was the vitals TABLE, and this box went
with it because the two shared one `2xl:grid-cols-[1fr_320px]` row. Restored on
request, same `HistoryTab` component, so it keeps its pencil — the inline edit
for allergies, medication, medical and surgical history, gated on the
`editClinicalHistory` capability rather than on role shape.

`fullHeight` is dropped, deliberately: that prop exists to stretch the card to
fill the 320px sidebar it no longer sits in. It sits **last**, below the vitals
trend, rather than beside it — a 320px sidebar next to a horizontally scrolling
vitals table squeezes the table that is the point of the view.

---

## 4. Backend — nothing new was needed

No backend change was made. Everything shown was already exposed:

| Shown | Endpoint |
|---|---|
| Record integrity | computed in the browser from the `get_patient` payload |
| Lifetime billed | `list_patient_invoices` → sum of `grand_total` |
| Outstanding | `get_patient_total_pending` via `usePatientBalance` |
| Consents | `consent.get_consent_status`, once per channel |
| Account stats | the same invoice list the Billing tab fetches |

**Third time in this series** that a suspected "missing backend" turned out to
be an exposure gap rather than a schema gap — after `Patient.creation` and the
insurance coverage split (front-desk doc §4), and `get_lab_trends` (doctor doc
§3.7). The consent `channel` passthrough is the fourth. **Check the service
layer before reporting a gap.**

---

## 5. NOT BUILT, and why

### The access log — the one that matters

The design's admin view is built around it, and the purpose line names it.
`utils.py:659 audit_view()` writes a `View Log` row on every chart open, and its
docstring explains at length why that had to be built at all (core's
`track_views` is off on every clinical doctype, and core's only caller is the
Desk form loader a Next.js frontend never invokes).

**The rows are being written. Nothing reads them.** Verified by grepping `api/`
and `services/` for any read of `View Log` or `Access Log` — zero hits outside
`utils.py` itself.

So this is an exposure gap of exactly the same shape as the three above, and a
`get_patient_access_log(patient)` method would be small. **Decision with the
user, 2026-09-29: skip it for this pass**, frontend-only, and shorten the
purpose line to *"Record quality, money and consents."* rather than advertise a
capability the view does not have (PHI-5). The Recent access card and the Access
log tab are not built.

**This is the most worthwhile single backend addition left in the series.**

### `No duplicates`

`services/patients.py::find_duplicate_candidates` exists, but is only ever
called from patient import (`patient_import.py:674`) and registration-form
extraction (`registration_form_extraction.py:411`). Never whitelisted, so it
cannot be asked about a patient already on file. A green "No duplicates" chip we
cannot substantiate is worse than no chip.

### `Telemedicine consent missing`

No such consent type — §3.5.

### The `Fix gaps` action

The design's fires `say('2 items sent to front desk')` — a toast in a prototype,
with no queue, task or notification behind it. The gaps are listed, which is the
actionable half; the button would be theatre.

### Insurance claims

No endpoint at all. `insurance/api.py` exposes policies and coverage only.
Confirms CLAUDE.md §12's "Phase 3 remaining — insurance" as still outstanding
for claims specifically.

---

## 6. OPEN QUESTION — admin's clinical visibility

**The design treats admin as a non-clinical role. This app does not.**

The admin config carries `notice: HIDE` — the same bar front desk gets:

> *Clinical notes, diagnoses, results and prescriptions are visible to doctors
> and nurses only.*

Our app shows an administrator the **full clinical Overview**: clinical notes,
the AI clinical summary including its suggested differential, and (until this
pass) the growth chart and patient history.

**This was deliberately left standing, not resolved either way** (user decision,
2026-09-29). Narrowing it is a permissions change that removes access an admin
has today (§13.3), not the UI/CSS work this pass was scoped to.

It has a **PHI-6 dimension** — minimum necessary — and deserves a decision on its
own terms: an administrator auditing record quality, money and consents has no
stated need for an AI-suggested differential. Recorded here rather than silently
changed.

---

## 7. NOT DONE — the admin view is not finished

The Overview is built. The design's other tabs each carry cards that are not:

| Tab | Design's cards |
|---|---|
| Billing & claims | Account (stats) · Invoices (rows) · **Insurance claims (rows)** — no endpoint |
| Consents | Consents (rows, wide) with a `Request missing` action |
| Communications | Communications (stats) · Message log (thread, *"Read-only · clinical content hidden"*) · Activity (rows) |
| Access log | not built — §5 |

The Communications sub-line is a claim about behaviour and must be checked
against what the app actually does before it is shown (PHI-5).

**Carried over from the other roles:** front desk's Messages / Documents /
Timeline tabs, the nurse's History-tab tables, and the doctor's `tables`
(past encounters on Overview, labs + vitals on Results) and Problems & meds
cards. See each role's document.

---

## 8. Bugs found and fixed during this work

**A raw message key rendered on screen.** `useTranslations("chart.billing")`
does not exist — the Billing tab's namespace is `billingPage` — so the Account
card printed `CHART.BILLING.KPICOLLECTI…` where "Collected" belonged. `tsc`,
lint and 630 tests all passed.

**"0 of 3 complete" for consents.** Reused reception's `ofComplete` string,
which describes a paperwork score rather than an authorization. Now
`ofGranted` — "0 of 3 granted".

**A missing message namespace is invisible to `tsc`.** `chart.admin` was used in
the component before it existed in `messages/*.json`; 408 `IntlError:
MISSING_MESSAGE` lines in the console, nothing anywhere else. **Fourth
design-sync defect in this series caught only by reading the live page** — after
the empty `box-shadow`, the swapped tab labels and `clinicalSummaryAiSub`. The
pattern is now clear enough to state as a rule: **write the catalogue keys
before the component that uses them.**

---

## 9. How the roles were verified from one session

The logged-in session held `EB_Healthcare Admin` only, but the nurse and
practitioner branches needed checking in the same pass. Verified with a
**runtime-only `window.fetch` override** that rewrote the `/api/auth/me`
*response* inside the tab:

```js
if (url.includes('/api/auth/me')) { j.frontendRole = 'practitioner'; … }
```

Nothing was sent to the server and nothing stored — `role-context.tsx` reads
`user.frontendRole` and nothing else, so rewriting the response is enough to
render another role's branch. The override was removed and the page reloaded
against the real session afterwards, and the restoration confirmed
(`overrideGone: true`).

Same technique used on 2026-09-28 to verify the `crit` colour path. It is worth
keeping in the toolkit: it is read-only, reversible, and far cheaper than
changing Frappe roles for a UI check.

---

## 10. Files touched

**New**

```
src/components/narzim/patient-chart/admin-band.tsx      the admin's chips + 4 KPIs
src/components/narzim/patient-chart/admin-overview.tsx  Record integrity · Consents · Account
```

**Changed**

```
src/components/narzim/patient-chart/nz-card.tsx              NzProgress (the design's `prog` body)
src/components/narzim/patient-chart/patient-screen.tsx       TAB_ORDER_BY_ROLE.admin
src/components/narzim/patient-chart/overview-tab.tsx         admin branch; history restored to nurse + doctor
src/hooks/use-consent.ts                                     channel param, usePatientConsents, CONSENT_CHANNELS
src/app/api/consent/status/route.ts                          channel passthrough
src/app/(clinic)/patients/[id]/patient-chart-client.tsx      AdminBand
messages/en.json · messages/es.json                          chart.admin (24 keys)
```

No backend change was required for the admin view.

**Verification:** `tsc` clean · 630 tests / 36 files passing · no new lint errors
· en/es key parity · console clean after reload. The band, tab order, cards and
the `prog` body were each confirmed in the browser against a live
`EB_Healthcare Admin` session, every measurement read from `getComputedStyle`
rather than judged by eye. The restored patient-history box was confirmed under
both practitioner and nurse, including that its pencil opens the inline editor
with Cancel / Done — cancelled without saving.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-29 | Ashutosh (AI-assisted) | Initial record of the admin Patient 360 redesign: the band, `NzProgress`, the three-channel consent view, the tab order and the Overview swaps; why the access log, duplicate check and telemedicine consent are not built; the admin-clinical-visibility question left open; and the runtime role-override verification technique |
