# Multi-Panel AI Lab Extraction + Continuous Learning — Design & Milestones

**Doc status:** living · **Created:** 2026-07-02 by Divyanshu · **Updated:** 2026-08-31 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.3

> **Status:** BUILT AND LIVE. This is the design record for a feature that is in
> production, not a plan awaiting approval — it ran four extractions on 2026-08-26
> alone. The extraction step has since been refined by
> [ADR-052](adr/adr-052-one-call-per-upload-with-bounded-recovery.md) (one call per
> upload with bounded recovery); the feature's open gaps — chiefly that every
> extracted parameter currently matches zero templates — are tracked in
> [KNOWN_ISSUES.md](KNOWN_ISSUES.md). **Owner:** backend.
> **Builds on:** `docs/AI_LAB_REPORT_EXTRACTION.md` (base single-template
> feature, M1-M5 complete) — this document does NOT replace it; the existing
> per-Lab-Test upload/extract flow is untouched and remains the primary path
> for an already-ordered test.
> **Decisions locked with the team (2026-07-02):**
> 1. Extraction strategy: **one LLM call per upload, deterministic bucketing
>    in Python** — not "classify templates, then re-extract per template."
>    See ADR-022 for why (cost: ~9x fewer LLM calls; safety: reuses the
>    already-hardened index-based matcher instead of adding a new
>    template-classification step).
> 2. Detected-but-unordered panels are **never auto-ordered** — physician
>    must explicitly create the order.
> 3. Continuous learning (2026-07-02, revised): **no suggestion queue, no
>    background job.** Resolving an unmapped parameter is immediate: adding a
>    synonym alias needs no elevated permission (it never touches a clinical
>    template); adding a new analyte to a template or creating a new template
>    is gated purely by Frappe's existing `Lab Test Template` write
>    permission — that permission check IS the approval, applied the moment
>    someone takes the action, not queued for later review. See ADR-023.
> 4. The synchronized two-pane PDF viewer (click-to-highlight) is a
>    **separate frontend repo task**, out of scope here. This document
>    defines the API contract so that screen can be built later; it does not
>    build it.
> 5. Unit conversion (2026-07-02, ADR-024): moved from save-time-only to
>    **review/display time, for both the single-template AND multi-panel
>    flows** — the review screen now shows a value already converted into
>    the template's unit, not the raw report unit. Applied to both flows for
>    consistency, per explicit instruction, even though the single-template
>    flow was already shipped under ADR-019/020.
> **Governing ADRs:** ADR-022 (multi-panel extraction), ADR-023 (continuous
> learning), ADR-024 (convert at review time, both flows). All **Proposed**
> — flip to **Accepted** once M0 is merged.

---

## 1. Problem

A single uploaded report can contain multiple independent test panels (e.g.
Liver & Kidney Panel, Lipid Profile, Fasting Glucose, Vitamin B12, Vitamin D,
Thyroid Profile, HbA1c, CBC in one PDF). Today's pipeline assumes one PDF ↔
one already-ordered Lab Test and only fills that test's expected analytes.
This feature detects every panel present, buckets the extracted values by
template, never discards unmatched data, and lets a physician turn a
detected-but-unordered panel into a real order on demand.

## 2. How extraction works (see ADR-022 for the full rationale)

```
Upload PDF (against a Patient, not necessarily a specific order)
        │
        ▼
ONE LLM call: transcribe every result line + match against the FULL
site-wide analyte catalog (index-based, same mechanism as the existing
single-template pipeline — ADR-019 G4)
        │
        ▼
Deterministic Python bucketing (services/lab_panel_extraction.py):
  for each matched analyte → look up every Lab Test Template that owns it
  (services/lab_catalog.py) → add the value to ALL owning templates'
  proposal buckets → apply qualifier_conflict per bucket (reusing
  services/lab_qualifiers.py unchanged; unit conversion is deliberately
  NOT applied here — see §4a)
        │
        ▼
AI Prompt Log record (purpose="Multi-Panel Extraction", detected_panels
child table): one row per detected template, each showing matched values +
whether the patient already has an order for it
        │
        ├── Panel already ordered  → physician reviews via the EXISTING
        │                             per-Lab-Test review/save flow
        │                             (record_result — unchanged; the
        │                             bridge in api/ai/lab_extraction.py
        │                             surfaces this panel's proposal there)
        │
        └── Panel NOT ordered      → surfaced as "detected, not ordered";
                                      physician explicitly clicks
                                      create_order_for_panel (creates an
                                      EMPTY Draft — see §4a), or ignore_panel
```

### 4a. Unit conversion — deferred to save time, not proposal time

The pipeline stores each proposed value verbatim, exactly as printed on the
report (value + report's own unit + report's own range) — it never converts
units itself. This matches the existing single-template pipeline exactly:
conversion only ever happens in `services/labs.py::_apply_report`, which
runs when `record_result` is actually called — i.e. only once a physician
takes an explicit save action against a concrete Lab Test row. Two paths
reach that point:

- **Already-ordered panel:** the bridge added to
  `api/ai/lab_extraction.py::get_extraction_status` (see §4) finds this
  panel's proposal via its `existing_lab_test` link and surfaces it in the
  SAME `proposed` list the existing per-test review screen already reads —
  no new review screen, no new save path. `record_result` (unchanged) is
  still the only thing that ever converts or writes a value.
- **Not-yet-ordered panel:** `create_order_for_panel` creates a Service
  Request + empty Draft Lab Test (no values written — Rule 6), then sets
  `existing_lab_test` on the panel row, which makes the SAME bridge above
  pick it up immediately. The physician then reviews/saves through the
  identical existing flow as any other order.

Net effect: there is exactly ONE place unit conversion ever happens
(`_apply_report`), regardless of whether a value arrived via the
single-template flow, an already-ordered multi-panel-detected value, or a
freshly-ordered one. No new conversion logic was written for this feature.

Cross-template duplication is **expected, not an edge case** — Sodium
appears in Basic Metabolic Panel, Serum Electrolytes, and Comprehensive
Metabolic Panel in the seeded data; a single printed Sodium value populates
the proposal for all three. This is a deliberate design choice (§ADR-022
Decision 3), not a bug to fix later.

## 3. New doctypes

| Doctype | Role | ADR |
|---|---|---|
| `AI Lab Panel Extraction Panel` (child) | One row per detected template on a multi-panel run, with its proposed values and ordered/not-ordered state | ADR-022 |
| `Lab Analyte Alias` | Synonym → canonical analyte, consulted when building the catalog. Freely created when resolving an unmapped parameter — no approval gate, since it never touches a clinical template | ADR-022 / ADR-023 |

**Revision (2026-07-02, mid-implementation):** the original design also had a
*parent* doctype (`AI Lab Panel Extraction`) to hold this child table plus
its own copies of `patient`/`model`/`tokens_in`/`tokens_out`/`cost_estimate_usd`/
`status`/`matched_count`/`unmatched`/`qualifier_conflicts`/`error`/etc.
Reviewing that against the existing `AI Prompt Log` doctype found every one
of those fields already exists there (it already carries two purposes —
"Lab Extraction" and "Imaging Transcription" — each using a different subset
of the same shared fields). Rather than duplicate ~13 fields onto a new
parent, `AI Prompt Log` gained a third purpose, `"Multi-Panel Extraction"`,
and one new field, `detected_panels` (Table → `AI Lab Panel Extraction
Panel`). The standalone parent doctype was deleted; `bench migrate` removed
it as an orphan cleanly. See ADR-022's Revision History for the full
reasoning, including the one accepted wrinkle (a "Log" row's child table can
now be mutated after creation, for this purpose only, by
`create_order_for_panel`/`ignore_panel`).

No other new doctypes. ADR-023 was revised (2026-07-02) to drop its original
`AI Extraction Correction` / `AI Extraction Improvement Suggestion` doctypes
and scheduled-job design in favor of immediate, permission-gated resolution —
see ADR-023's Revision History.

`AI Settings` gains config fields only (see M0/M2). `Lab Unit Conversion`
is unchanged — reused, not extended (see §4a).

## 4. Code components

| File | Purpose | Status |
|---|---|---|
| `services/lab_catalog.py` | Build the site-wide analyte→owning-templates catalog (enabled Compound/Descriptive/Single templates; consults `Lab Analyte Alias`) | new |
| `integrations/llm.py` | + `extract_multi_panel_report()` dispatcher (reuses existing `LAB_EXTRACTION_SCHEMA`/`LabExtractionResult` — identical response shape, no new schema needed) | extend |
| `integrations/anthropic.py`, `integrations/openai.py` | + `extract_multi_panel_report()` — thin, reuses existing `_call_claude`/`_call_openai` (already schema-generic, no change needed there) | extend |
| `llm/prompts/multi_panel_extraction_v1.txt` | Versioned, hashed prompt — transcription + index-matching against the big catalog | new |
| `services/lab_panel_extraction.py` | RQ pipeline: load file → call multi-panel LLM → bucket by template via catalog → qualifier check → write `AI Prompt Log` (`purpose="Multi-Panel Extraction"`, proposal only, never a Draft Lab Test) | new |
| `api/ai/lab_panel_extraction.py` | `upload_lab_report_package`, `get_panel_extraction_status`, `create_order_for_panel`, `ignore_panel`, `map_unmapped_as_alias` (no elevated permission), `add_analyte_to_template`, `create_template_from_section` (both gated on `Lab Test Template` write/create permission — ADR-023) — all gated on `AI Settings.enable_lab_extraction` | new |
| `api/ai/lab_extraction.py::get_extraction_status` | + bridge: surfaces a multi-panel-detected panel's proposal for an already-ordered Lab Test in the SAME `proposed` list the existing single-template review already returns. The only pre-existing file this feature modifies — additive only, verified not to change behavior when no multi-panel data exists for a given lab_test | extend |

> This table records what the milestone **created**, not the current state of those
> files. The prompt in particular is versioned and has moved on a long way: the live
> default is `multi_panel_extraction_v14.txt`, not the `v1` named above. See
> `integrations/llm.py::extract_multi_panel_report` for the version actually in use,
> and ADR-052 for how the extraction call is now bounded and recovered.

## 5. Milestones

- **M0 — Prerequisite bug fix (blocking, unrelated to this feature):**
  `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/ai_settings/ai_settings.json`
  was reported with unresolved git merge-conflict markers during design research.
  **Status: verified 2026-07-02 — already resolved on disk (re-checked with a
  direct read + regex grep for conflict markers, both clean). No fix needed.**

- **M1 — Design docs (this deliverable):** ADR-022, ADR-023, this tracking
  doc. **Status: done.**

- **M2 — Analyte catalog + `Lab Analyte Alias`:** `services/lab_catalog.py`
  + doctype + unit tests (cross-template ownership, disabled-template
  exclusion, Single-type inclusion, alias widening + dangling-alias handling
  + never-shadow-a-real-label). **Status: done 2026-07-02.** Verified via
  `bench migrate` (new doctype table created cleanly) + a `bench console`
  run against real seeded data on `remedisis.localhost` — confirmed Sodium
  resolves to all of `Basic Metabolic Panel`, `Comprehensive Metabolic Panel
  (CMP)`, and `Serum Electrolytes` (the real, deliberate cross-template
  duplication ADR-022 is designed around), confirmed disabled-template
  exclusion, confirmed alias widening and dangling-alias safety. `bench
  run-tests` itself is broken site-wide on an unrelated pre-existing
  ERPNext test-bootstrap issue (`Price List 'Standard Buying'` duplicate
  entry) — `tests/labs/test_lab_catalog.py` is written and follows the
  existing test-suite conventions exactly, ready to run once that
  environment issue is fixed, but was verified via `bench console` instead
  for this milestone.

- **M3 — Multi-panel LLM mode:** prompt + dispatcher + both provider
  adapters, unit-tested against a mocked SDK boundary (mirrors
  `tests/ai/test_lab_extraction.py`). **Status: done 2026-07-02.** Reuses
  `LAB_EXTRACTION_SCHEMA`/`LabExtractionResult` unchanged (identical response
  shape — no separate schema needed, a refinement over the original ADR-022
  sketch, see ADR-022 for the note). Verified via `bench console` with a
  mocked SDK boundary: prompt loads (sha256 confirmed), a 50-entry synthetic
  catalog is correctly threaded into the model instruction, matched/
  unmatched parameters resolve correctly, and provider dispatch (Claude/
  OpenAI) routes correctly from `AI Settings.llm_provider`.

- **M4 — Extraction pipeline + doctype:** `AI Lab Panel Extraction Panel`
  child doctype (attached to `AI Prompt Log`, not a standalone parent — see
  §3 Revision), `services/lab_panel_extraction.py`, bucketing + qualifier
  reuse, tests. **Status: done 2026-07-02.** Verified via `bench migrate`
  (child doctype table created cleanly; the standalone parent doctype built
  first, then deleted, was removed as a clean orphan) + a `bench console`
  run with a mocked LLM boundary: a shared analyte (Sodium) correctly
  fanned out to both owning templates with `matched_count=1` (counted once,
  not once per template); a qualifier-conflicting match (Direct vs Total
  Bilirubin) was correctly held back from every panel; an unmatched
  parameter (Ferritina) was preserved verbatim, not discarded. Unit
  conversion is deliberately NOT applied at proposal time — see §4a.

- **M5 — API layer:** `api/ai/lab_panel_extraction.py` (upload, status,
  create-order, ignore) + unmapped-parameter resolution actions
  (`map_unmapped_as_alias` — unrestricted; `add_analyte_to_template` /
  `create_template_from_section` — gated on `Lab Test Template` write/create
  permission per ADR-023) + the `get_extraction_status` bridge (§4a).
  **Status: done 2026-07-02.** Verified via `bench console`: upload flag
  gate, status polling, `create_order_for_panel` creates a genuinely empty
  Draft (no auto-applied values) and is idempotent on a second call,
  `ignore_panel` transitions state, the bridge surfaces an already-ordered
  panel's proposal through the EXISTING single-template review endpoint
  with zero change to that endpoint's behavior when no multi-panel data
  exists (explicit regression check run), `map_unmapped_as_alias` creates
  aliases with no permission escalation, and both template-structure
  endpoints are confirmed rejected without `Lab Test Template` permission
  and successful with it. **Bug found and fixed during verification:**
  `create_template_from_section` was inserting new templates with
  `ignore_mandatory=True`, silently skipping the required `department` and
  `lab_test_group` (Item Group) fields — harmless at insert time, but a
  LATER plain `.save()` from `add_analyte_to_template` on that same
  template would then fail with a stale `MandatoryError` the caller never
  saw coming. Fixed by resolving both fields properly (mirroring
  `scripts/seed/seed_lab_panels.py`'s own fallback pattern) and dropping
  `ignore_mandatory` entirely, so a real gap now surfaces immediately
  instead of being deferred to a confusing later failure. Test fixtures
  across M2/M4/M5 updated to set `lab_test_group` too, so they exercise
  realistic, fully-valid templates.

- **M5a — Convert at review time, both flows (ADR-024):** `services/lab_units.py::resolve_display_value`
  (shared decision, extracted from `_apply_report`), `services/labs.py::_apply_report`
  refactored to a thin wrapper around it, `services/lab_extraction.py` (single-template)
  and `services/lab_panel_extraction.py` (multi-panel, via new
  `lab_catalog.py::template_analyte_meta`) both convert at proposal time now.
  **Status: done 2026-07-02.** Verified in two layers: (1) the full **pre-existing**
  `tests/labs/test_labs.py` (42 tests) and `tests/ai/test_lab_extraction.py` (23 tests)
  suites — neither file modified — pass unchanged, confirming the refactor and the
  single-template flow's new conversion behavior introduced zero regressions; (2) new
  `TestResolveDisplayValue` (5 tests) plus the multi-panel pipeline/API suites, all
  green after fixing several test-only bugs (two field-name mistakes conflating
  `Normal Test Template.lab_test_event` with `Normal Test Result.lab_test_name`/
  `lab_test_event`, two fixtures colliding with real seeded analyte names on this
  shared dev site, one assertion missing the new `converted`/`original_value`/
  `original_unit` fields, one shared-fixture leak between test methods).

  **Test-runner limitation found, root-caused, and fixed** (not a product bug):
  `utils.py::handle_api_errors` calls `frappe.db.rollback()` on every 4xx/5xx
  response — correct for a real HTTP request. `bench run-tests` normally wraps each
  test in its own savepoint so that rollback only undoes that test's own writes; the
  substitute runner used throughout this feature (`bench run-tests` itself is broken
  site-wide on an unrelated pre-existing bug) has no such savepoint, so a test that
  deliberately triggers an error response rolls back past `setUpClass`, wiping
  fixtures for whatever test runs next. **A prior session had already root-caused and
  solved this exact problem** — `reference_handle_api_errors_rollback_wipes_test_fixtures`
  (memory) documents the fix and points at `tests/ai/test_imaging_extraction.py` as a
  working example, which was not consulted before this was independently re-diagnosed
  in this session. Fix applied: `_FixtureMixin._setup_fixtures` made fully idempotent
  (including the Patient row, which was the one non-idempotent fixture), and every
  test method that either deliberately triggers an error response or runs after one
  alphabetically now re-calls `_setup_fixtures()` at its start to self-heal. All 14
  tests in `tests/ai/test_lab_panel_extraction_api.py` pass cleanly as a result.

- **M6 — retired, folded into M5.** The original design (batched
  correction-log + suggestion-queue doctypes + a daily aggregation job) was
  replaced 2026-07-02 by immediate, permission-gated resolution — see ADR-023
  Revision History. No separate milestone remains; its work is now part of M5.

- **M7 — End-to-end verification:** real multi-panel scenario on
  `remedisis.localhost` against real seeded templates (LLM boundary mocked;
  everything else real — real patient, real order, real file upload, real
  DB writes). **Status: done 2026-07-02.** Confirmed: a shared analyte
  (Sodium) fanned out to all 4 real templates that contain it, correctly
  flagging the one with a pre-existing order as `is_ordered=1` with its
  real `existing_lab_test`; a detected Vitamin D panel stayed unordered
  until `create_order_for_panel` created a real Service Request + Lab Test,
  after which the bridge in `get_extraction_status` correctly surfaced its
  proposed value through the existing single-test review endpoint;
  `ignore_panel` transitioned a panel without ordering it; an unmapped
  parameter (Ferritina) was preserved and successfully resolved via
  `map_unmapped_as_alias` with no elevated permission; `add_analyte_to_template`
  was confirmed rejected without `Lab Test Template` permission and
  successful with it; the newly-added analyte was confirmed visible in the
  very next `build_analyte_catalog()` call. All scratch data (plus one
  unrelated stray template left over from earlier debugging) cleaned up
  afterward.

- **M8 — Frontend API handoff (this repo's responsibility ends here):**
  publish the response shape of every new/changed endpoint to the frontend
  team. **Building the actual viewer screen is explicitly out of scope for
  this backend effort.** **Status: done 2026-07-02 — see §9.** One
  correction from the original scope: page/section location metadata for a
  future sync-highlight viewer does **not** exist in the current
  implementation (the extraction schema never asked the model for it) —
  flagged explicitly in §9 rather than silently handed off as if it did.

  **2026-08-21 correction:** "explicitly out of scope for this backend
  effort" described the *building* of a viewer, not a permanent boundary —
  a real review UI has since been built against this contract in
  `EB_Healthcare_Frontend`: a grouped review screen for unmatched/standalone
  parameters (`lab-order-dialog.tsx`), and a multi-document source-report
  viewer (`lab-center-tab.tsx`, tabs/toggle design as of 2026-08-21, one
  document shown at a time). See `WORK_LOG.md`'s 2026-08-19 through
  2026-08-21 entries for the frontend history; not re-narrated here since
  this file's scope is backend design.

- **M9 — Post-launch catalog + attachment fixes, and catalog-maintenance
  tooling (2026-08-20/21):** three defects and one new capability found
  after M0–M8 shipped, all in code already covered by this document's own
  components:
  - **Single-type template blind spot** (`services/lab_catalog.py::
    build_analyte_catalog`). A `Single`-type Lab Test Template stores its
    one analyte's unit/range directly on the template document, never as a
    `Normal Test Template`/`Descriptive Test Template` child row — so the
    original owner-lookup loop (which only ever scanned those two child
    doctypes) could never associate a Single template with its own Lab
    Parameter. Every auto-created single-analyte template (e.g. from
    `create_template_from_section` for a standalone numeric result) stayed
    permanently flagged "needs review" even after the exact template
    existed for it — found live via `Parathormona (PTH - Intacta)`. Fixed
    by matching a Single template the same way a child row is matched: by
    its own name against a Lab Parameter's name.
  - **Multi-file source-report misattachment.** `create_order_for_panel`/
    `finalize_section_order` only ever attached `doc.source_file` (the
    first uploaded file) to the resulting Lab Test — when a physician
    uploaded two genuinely separate reports together in one batch, a result
    from the second document showed the first, unrelated document as its
    "source report." Fixed via a new `_attach_source_files()` helper
    (attaches every file in `doc.source_files`) and, on the read side,
    `api/v1/labs/api.py::_source_file_urls()` changed from
    `dict[str, str]` (most-recent-file-only, via `setdefault`) to
    `dict[str, list[str]]` — both `_serialize_lab_row`/`_serialize_lab_full`
    now emit a new `source_file_urls` field (full list) alongside the
    existing `source_file_url` (kept as `urls[0]`, unchanged shape for
    callers that only want one file).
  - **`services/lab_parameter_dedup.py` (new) — on-demand duplicate Lab
    Parameter merge.** `normalize_analyte_key` (existing) only catches
    *cosmetic* duplicates (spacing/case/punctuation); it structurally cannot
    catch two different WORDINGS of the same analyte ("Total Cholesterol"
    vs "Cholesterol, Total"). `run_dedup_cleanup()` asks the LLM
    (`llm/prompts/lab_parameter_dedup_v1.txt`, catalog metadata only — no
    patient/result data ever reaches the model, so Rule 10 doesn't merely
    apply, it's moot) to group same-analyte names under different wording,
    then deterministically repoints every `Normal Test Template`/
    `Descriptive Test Template` row naming a duplicate onto its canonical
    name and disables the duplicate (never deletes — the disabled row plus
    the full before/after snapshot on the triggering `AI Prompt Log`
    (`purpose="Lab Parameter Dedup"`) is the reversal path). Merges apply
    **automatically, with no confirmation step** — an explicit, documented
    product decision (this module's own docstring), not an oversight: it
    follows the same "the permission check IS the approval" pattern ADR-023
    already established for `add_analyte_to_template`. Exposed as
    `api/ai/lab_panel_extraction.py::run_lab_parameter_dedup()`, gated on
    `Lab Test Template` **write** permission (not `enable_lab_extraction` —
    this is catalog maintenance, not part of the patient-facing extraction
    flow, same reasoning as `add_analyte_to_template`). **Status: shipped,
    not yet run in anger** — zero `Lab Parameter Dedup` `AI Prompt Log` rows
    exist yet as of 2026-08-21.
  - **Status: done 2026-08-21.** Verified live on `remedisis.localhost`:
    `enable_lab_extraction=1`, `llm_provider=OpenAI`, 16 real `Multi-Panel
    Extraction` log rows exist — this feature is in active real use, not
    "pending," which is itself a gap this revision surfaces (see
    `docs/AI_LAB_REPORT_EXTRACTION.md` §M6 — that doc still states the
    compliance gate is pending and the flag should be off; it currently
    isn't, and closing that contradiction is a decision for whoever owns
    the M6 gate, not this revision).

## 6. Rules kept

Rule 1 (core never touched), Rule 4 (LLM never touches DB), Rule 6
(physician/admin in control — panels never auto-ordered; template/analyte
changes gated by the same write permission Frappe already enforces), Rule 9
(deterministic pipeline — bucketing is a lookup, not another LLM guess),
Rule 10 (no PHI in logs), §12 (every new doctype has an ADR).

## 7. Risks

- **Cross-template duplication surfacing confusion** — a physician seeing
  the same value proposed under 3 different panel names needs the review UI
  (frontend, later) to make that clear; backend risk is low since the
  behavior is intentional and logged.
- **Catalog growth over time** — as more templates are added, the numbered
  catalog sent to the LLM grows; still one call, so cost grows linearly with
  catalog size, not with panel count. Acceptable at current scale (~15
  templates, ~100 analyte rows); revisit if the catalog reaches the low
  thousands.
- **Unrestricted alias creation** — anyone who can review a lab extraction
  can add an alias with no elevated permission (ADR-023 Decision 1). Accepted
  risk since an alias only ever widens catalog *recognition*, never changes a
  clinical form; a bad alias is corrected the same way a bad correction
  anywhere else is, by editing/disabling the `Lab Analyte Alias` row.
- **Compliance gate** — this feature sends the same PHI to the same
  third-party LLM as the base feature; it does not introduce a new
  compliance surface, but does not reduce the existing one either. Still
  gated OFF by `enable_lab_extraction` until that gate clears.

## 8. Verification

Per-milestone exit gates above; `bench console` (flat statements) + pytest
on `remedisis.localhost`, following the same verification pattern as
`docs/AI_LAB_REPORT_EXTRACTION.md` §11.

### 8a. Test-runner limitation — found, root-caused, and fixed (2026-07-02)

`bench run-tests` is broken site-wide on a pre-existing, unrelated ERPNext
test-bootstrap bug (`Price List 'Standard Buying'` duplicate entry). The
substitute used throughout this feature — loading each test module directly
via `unittest.TestLoader()` inside `bench console` — mostly works and caught
several real test-fixture bugs (fixed: two field-name mistakes confusing
`Normal Test Template`'s `lab_test_event` with `Normal Test Result`'s
`lab_test_name`/`lab_test_event`, two test fixtures colliding with real
seeded analyte names on this shared dev site, one outdated assertion missing
the new ADR-024 fields, one shared-fixture leak between test methods).

One class of failure in `test_lab_panel_extraction_api.py` was a genuine
limitation of the substitute runner, not a bug: `bench run-tests` wraps each
test method in its own savepoint, so `utils.py::handle_api_errors`'s
`frappe.db.rollback()` (called on every 4xx/5xx response — correct, existing
production behavior) only undoes that one test's own changes. The raw
`unittest.TestLoader()` substitute has no such savepoint, so a test that
deliberately triggers an error response rolls back all the way past
`setUpClass`, wiping fixtures for whichever sibling test (or the same test's
own later assertions) runs next. This exact problem, including the fix, was
already documented in a prior-session memory
(`reference_handle_api_errors_rollback_wipes_test_fixtures`) with a working
example already in this codebase (`tests/ai/test_imaging_extraction.py`) —
not consulted before this was independently re-diagnosed from scratch in
this session, which cost avoidable time. **Fixed** by applying that same
documented pattern: `_FixtureMixin._setup_fixtures` made fully idempotent
(the Patient row was the one fixture inserted unconditionally), and every
test method that either deliberately triggers an error response or runs
after one alphabetically now re-calls `_setup_fixtures()` at its start to
self-heal regardless of execution order. All 14 tests in
`tests/ai/test_lab_panel_extraction_api.py` now pass cleanly. Revisit only
if the underlying `bench run-tests` bootstrap bug is ever fixed separately —
these tests would also pass unmodified under that real runner, since it
provides the savepoint protection this workaround exists to replace.

## 9. Frontend API Contract (M8 handoff)

All endpoints below live in `api/ai/lab_panel_extraction.py` unless noted.
All are gated on `AI Settings.enable_lab_extraction` (currently OFF pending
the M6 compliance gate shared with the base single-template feature — see
`docs/AI_LAB_REPORT_EXTRACTION.md`). Every response follows this app's
standard envelope (`utils.py::set_response`) — success responses shown
below are the `data` payload; errors are `{"status": "error", "error":
{"code", "message"}}` with the HTTP status noted per endpoint.

**`upload_lab_report_package(patient)`** — multipart `file` in the request body.
- 202: `{"extraction": "<AI Prompt Log name>", "file": "<file_url>", "status": "Extracting"}`
- 403 flag off / permission · 404 patient not found · 400 no file uploaded

**`get_panel_extraction_status(extraction)`** — poll with the `extraction` id from upload.
```json
{
  "name": "...", "patient": "...",
  "status": "Extracting | Success | Failed",
  "model": "claude-sonnet-4-6",
  "matched_count": 2,
  "unmatched": "Ferritina",
  "qualifier_conflicts": "",
  "error": null,
  "panels": [
    {
      "name": "<child row id — pass to create_order_for_panel/ignore_panel>",
      "lab_test_template": "Basic Metabolic Panel",
      "matched_count": 1,
      "is_ordered": 1,
      "existing_lab_test": "HLC-LAB-2026-00104",
      "action_status": "Pending Review | Order Created | Ignored",
      "proposed_values": [
        {
          "analyte": "Sodium", "value": "138", "unit": "mmol/L",
          "reference_range": "135-145", "converted": false,
          "original_value": "138", "original_unit": "mmol/L"
        }
      ]
    }
  ]
}
```
- 404 extraction not found · 400 not a multi-panel extraction · 403 permission

**`create_order_for_panel(extraction, panel, practitioner, company?)`**
- 200: `{"lab_test": "...", "service_request": "...", "action_status": "Order Created"}`
- Idempotent: calling it again on an already-ordered panel returns the same
  `lab_test`, no duplicate order.
- Writes NO result values — the created Lab Test is an empty Draft. The
  physician reviews/saves through the *existing* single-test flow
  (`get_extraction_status(lab_test)` → `record_result`), which now also
  surfaces this panel's proposal via the bridge below.

**`ignore_panel(extraction, panel)`** → 200: `{"panel": "...", "action_status": "Ignored"}`

**`map_unmapped_as_alias(parameter_name, canonical_analyte, source?)`** — no
elevated permission required (never touches a clinical template).
- 201 (new) / 200 (already existed): `{"alias": "...", "created": true|false}`

**`add_analyte_to_template(template, analyte_name, normal_range?, uom?)`** —
requires `Lab Test Template` **write** permission; the permission check IS
the approval (ADR-023), no separate review step.
- 200: `{"template": "...", "analyte_name": "..."}` · 403 without permission

**`create_template_from_section(lab_test_name, lab_test_code, template_type, analytes)`** —
`template_type` is `"Compound"` or `"Descriptive"`; `analytes` is
`[{"name": "...", "normal_range"?: "..."}]`. Requires `Lab Test Template`
**create** permission.
- 201: `{"template": "..."}` · 403 without permission

**Existing endpoint, extended — `api/ai/lab_extraction.py::get_extraction_status(lab_test)`**
(signature unchanged): its `proposed` list may now also include values a
multi-panel upload detected for this same, already-ordered Lab Test, in the
exact same item shape single-template proposals already use —
`{"test_name", "result_value", "uom", "reference_range", "converted",
"original_value", "original_unit"}`. No frontend change is required to pick
this up if the existing single-test review screen already renders
`proposed` generically.

### Known gap — no PDF location metadata (do not assume sync-highlight is possible today)

Every extraction call only ever asks the model for `parameter_name`,
`value`, `unit`, and `reference_range` — never a page number, coordinate, or
text anchor. **The synchronized two-pane "click a value, it highlights on
the PDF" viewer described in the original product request cannot be built
against the current API** — there is nothing in any response above that
says where on the document a value came from. A frontend built against this
contract today can show the grouped-by-template review list next to a
plain, unsynchronized PDF viewer. Wiring real synchronization would require,
as a future backend change: extending the extraction schema with a location
field (e.g. `page_number`, or a text snippet to search for), updating both
provider adapters and the prompt files to request it, and threading it
through `proposed_values`/`filled_rows`. Not built here — flagged so the
frontend team scopes accordingly rather than discovering the gap mid-build.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-08-31 | Sarvesh-SocialAngel (AI-assisted) | Two ADR-045 citations repointed to ADR-052 — the lab-upload ADR was renumbered to clear a collision with push-notifications. No design change |
| 1.2 | 2026-08-26 | Divyanshu (AI-assisted) | Corrected the status: the feature is live, not "pending final go-ahead"; pointed at ADR-052 and KNOWN_ISSUES; noted that the Code-components table records what the milestone created (prompt is now v14, not v1) |
| 1.1 | 2026-08-21 | Divyanshu (AI-assisted) | M9: Single-type catalog fix, multi-file attachment fix, `lab_parameter_dedup.py`; corrected M8's "viewer out of scope" claim (frontend since built); flagged the M6 compliance-gate contradiction in the base doc |
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
