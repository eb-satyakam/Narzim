# Clinical Document Drive — Document ID & API Reference

**Doc status:** living · **Created:** 2026-08-13 by Anant Sharma · **Updated:** 2026-08-18 by Sarvesh-SocialAngel · **Version:** 1.0

> **Narzim Drive.** The staff-facing personal document drive (notes +
> image/PDF/spreadsheet attachments, ownable and shareable) surfaced in the
> Narzim frontend. Backed by the custom `Clinical Document` doctype and
> `api/v1/clinical_documents/api.py`.
>
> **Not to be confused with** the patient-chart **Documents** tab (Screen 13 —
> lab reports, imaging, referrals filed against a *patient*, see
> `docs/PATIENT_DOCUMENTS.md`). Clinical Document has no `patient` field and no
> `Document Category` link — it is a personal work document, scoped to its
> owner and whoever the owner explicitly shares it with. The similarity in
> naming is a known point of confusion between the two features; this doc
> exists to keep them distinct.

**Status:** Built.
**Owner:** Backend.
**Last updated:** 2026-08-18.
**Tests:** `remedisys_healthcare_ai/tests/clinical_documents/test_clinical_documents.py` (44 tests, all passing).

---

## 1. What it is

A private-by-default document (title + rich-text notes + free-text tags) that
its owner can optionally share — either with specific staff users or with the
whole team — and attach images/PDFs/spreadsheets to. This is the backend for
the Narzim Drive UI's document cards.

Doctypes:

| Doctype | Kind | Purpose |
|---|---|---|
| `Clinical Document` | standalone | one row per document |
| `Clinical Document Share` | child table (`shared_with`) | one row per user the document is shared with, when `visibility=Shared` and `share_with_team=0` |

---

## 2. Document ID

`Clinical Document.autoname` is `"hash"` (`naming_rule: "Random"`) — the
doctype's Frappe `name` is a random opaque token (e.g. `a1b2c3d4e5`), **not**
derived from title, owner, or a naming series.

- Every API response exposes this as the field **`id`** (`_document_fmt()` in
  `services/clinical_documents.py` maps `d.get("name") → id`). The frontend
  must treat `id` as an opaque string — never parse it, sort by it, or infer
  ownership/date from it.
- Every mutating/read endpoint takes this same value back as its `id` /
  `name` parameter (naming is inconsistent at the boundary — see §4).
- Because the ID is random rather than sequential or owner-prefixed, it leaks
  no information (owner, creation order, count) if it appears in a URL or is
  shared out of context. This is deliberate for a personal-document feature
  and matches the private-by-default model in §5.
- Attachments have their own, separate ID: the native Frappe `File.name`
  (also hash-based), returned as `id` inside each entry of `images` /
  `_attachment_fmt()`. A document ID and an attachment ID are never
  interchangeable — attachment operations key off `file_id`, not `id`.

---

## 3. Schema

### `Clinical Document`

| Field | Type | Notes |
|---|---|---|
| `name` (→ `id`) | random hash | the document ID, see §2 |
| `title` | Data, required | |
| `notes` | Text Editor | rich text; HTML stripped for `notes_preview` (160 chars) in list responses |
| `tags` | Small Text | JSON array of strings, max 20 tags, 40 chars each — parsed/validated in the service, never rendered raw |
| `visibility` | Select: `Private` \| `Shared` | default `Private` |
| `share_with_team` | Check | only meaningful when `visibility=Shared`; if set, `shared_with` is ignored |
| `shared_access_level` | Select: `View` \| `Edit` | owner-only setting; governs what shared recipients may do to content (title/notes/tags/attachments) — sharing settings themselves are always owner-only regardless of this value |
| `shared_with` | Table → `Clinical Document Share` | specific recipients; only used when `Shared` and not team-wide |
| `status` | Select: `Saved` \| `Deleted` | system-managed; `Deleted` is a soft-delete, hidden from every read path for every caller including the owner |
| `owner` | Frappe standard | the creator; drives all permission checks |

### `Clinical Document Share` (child table)

| Field | Type | Notes |
|---|---|---|
| `user` | Link → User, required | one row per shared recipient |

---

## 4. API surface (`api/v1/clinical_documents/api.py`)

All whitelisted, all wrapped in `@handle_api_errors` (standard envelope —
`{status, data}` or `{status, error: {code, message}}`), all delegate to
`services/clinical_documents.py` — the API layer parses input and shapes the
response only; every privacy/permission decision lives in the service.

```python
list_documents(search=None)
    # -> list of documents visible to the caller (owned, team-shared, or
    #    individually shared), each with a `notes_preview`

get_document(id)
    # -> single document, includes full `notes` and `shared_with` user list

create_document(title, notes=None, visibility="Private", shared_with=None,
                 share_with_team=False, tags=None)
    # -> the created document

update_document(id, title=None, notes=None, tags=None, visibility=None,
                 shared_with=None, share_with_team=False,
                 shared_access_level=None)
    # -> the updated document (single Save-button call from the frontend —
    #    content and sharing fields together)

delete_document(id)
    # -> {"deleted": id}   (soft delete — status="Deleted")

upload_attachment(id)         # file via multipart form field "file"
    # -> {id, file_name, file_url, size}   (id = File.name, not a document id)

delete_attachment(id, file_id)
    # -> {"deleted": file_id}

list_shareable_users()
    # -> [{email, full_name}, ...] for the share-picker dialog
```

**Parameter naming note:** the whitelisted functions take `id`, but the
service functions underneath take `name` (Frappe's native primary-key
convention). Both refer to the same document ID from §2 — there is no
separate "name" concept for this doctype.

---

## 5. Visibility & permission model

- **Owner always** sees and may edit/delete/share/attach.
- **Non-owner access requires a clinic staff role.** `_is_staff()`
  (`services/clinical_documents.py:176`) checks the caller against
  `_STAFF_ROLES` — `System Manager`, `EB_Healthcare Admin`, `EB_Practitioner`,
  `EB_Nurse`, `EB_Front Desk`, `EB_Finance`, `EB_Clinic Staff` — plus
  `Administrator`. Anyone else (notably an `EB_Patient` portal account) sees
  nothing they do not own, *including* team-shared documents. This gate is
  enforced in code, not by the doctype permission table, because every read
  path here uses `frappe.get_all` / `frappe.get_doc`, which do not apply
  doctype permissions. It was missing until 2026-08-18 — see §9.
  - `_STAFF_ROLES` (the *view* gate, 7 roles) is deliberately **wider** than
    `_SHAREABLE_ROLES` (the *share-picker* list, 4 roles): Finance and Clinic
    Staff must keep seeing team-shared documents without being offered as
    share targets. Both are positive allowlists — a newly added role sees
    nothing here until it is listed.
- **Private** (default): visible only to the owner. A non-owner request for a
  private document 404s — see below.
- **Shared**: visible to either (a) every enabled **staff** user, if
  `share_with_team=1`, or (b) only the **staff** users listed in `shared_with`
  (a non-staff user placed in `shared_with` by a direct API call is still
  denied).
- **Shared recipient's edit rights** depend on `shared_access_level`:
  `View` (default) is read-only; `Edit` lets them change title/notes/tags/
  attachments — never sharing settings (`visibility`, `shared_with`,
  `share_with_team`, `shared_access_level` itself) and never delete. Those
  four fields, plus delete, are owner-only unconditionally, even for an
  `Edit`-level recipient.
- **404, never 403**, for any caller who can't see the document
  (`_get_visible_or_404`) — a private document behaves as if it never
  existed to anyone but the owner, and a soft-deleted document 404s for
  everyone including the (former) owner. Do not build frontend error
  handling that expects a 403 here.
- `list_shareable_users()` restricts the share-picker to the four clinic
  staff roles (`EB_Practitioner`, `EB_Healthcare Admin`, `EB_Nurse`,
  `EB_Front Desk`), excluding `Administrator`, `Guest`, and the caller
  themselves — deliberately not gated by `require_permission`, since
  choosing a share target needs no elevated doctype permission.

---

## 6. Attachments

- Native Frappe file attachments (`attached_to_doctype="Clinical Document"`,
  `attached_to_name=<document id>`) — not a child table, so a document can
  hold any number of files.
- Always private (`save_private_file`, immune to Frappe's cross-record
  content-hash dedup — see `utils.py`); never a public `/files/` URL.
- 25 MB per file. Allowed extensions: images (`jpg jpeg png gif webp bmp
  tiff svg`), `pdf`, spreadsheets (`xlsx xls csv`). Anything else is
  rejected at upload.
- Adding or removing an attachment requires the same content-edit permission
  as editing notes (§5) — a `View`-level shared recipient cannot attach or
  remove files.

---

## 7. Test coverage

`remedisys_healthcare_ai/tests/clinical_documents/test_clinical_documents.py`
— 44 tests, 6 classes. Run it with:

```bash
# from the app root; the harness is pytest + the repo conftest.py, not bench run-tests
../../env/bin/python -m pytest \
    remedisys_healthcare_ai/tests/clinical_documents/test_clinical_documents.py \
    --site <site> -q
```

| Class | Covers |
|---|---|
| `TestClinicalDocumentCrud` | create defaults (Private/Saved/View), title required, unknown `visibility` coerced to Private, opaque `id`, full `notes` + `shared_with` on get, stripped 160-char `notes_preview`, title search, content update, soft delete invisible to its own owner |
| `TestClinicalDocumentTags` | JSON-string parsing, case-insensitive dedupe, 40-char and 20-tag caps, non-list and malformed-JSON rejection, clearing tags |
| `TestClinicalDocumentVisibility` | private → 404 for a non-owner, specific share reaching only the named recipient, team share reaching all staff and overriding `shared_with`, Shared→Private revoking recipients, soft-deleted document vanishing for recipients, malformed `shared_with` |
| `TestClinicalDocumentSharedEditRights` | `View` recipient cannot edit (403, not 404), `Edit` recipient can edit content without taking ownership, `Edit` recipient blocked from all four sharing fields *and* from delete |
| `TestClinicalDocumentAttachments` | private-file upload + read-back through `get_document`, extension allowlist (both directions), 25 MB cap, filename/content required, missing multipart part → 400, cross-document `file_id` → 404, `View` recipient cannot attach or detach, attachment ops on an invisible document → 404 |
| `TestClinicalDocumentNonStaffAccess` | the §9 regression guard: a patient-portal user sees neither a team-shared nor an explicitly-shared document, while staff recipients still do |
| `TestListShareableUsers` | staff included; caller, `Administrator`, `Guest`, patients and disabled users excluded; callable by Front Desk with no `User` read permission |

Two tests deliberately pin **current, non-ideal** behaviour so that changing it
shows up as a failing test rather than a silent contract change:
`test_share_with_team_alone_is_a_noop` and
`test_unknown_share_target_reports_404` (both in §10).

Fixture notes for whoever extends this: the service commits on every successful
mutation, so `FrappeTestCase`'s rollback does **not** undo these rows — users
are created in `setup_module` and every document is swept in `teardown_module`
by the `CDTEST-` title prefix. Fixture users are created once per module, not
per class: doing it per class made Frappe unlink each auto-created `Contact` six
times in one connection and hit MariaDB error 1020 on `tabContact`.

---

## 8. Logging (Rule 10 — no PHI in logs)

`create_document` logs `id`, `owner`, `visibility` only — never `title` or
`notes`. Follow the same pattern for any new log line touching this doctype:
IDs and enum/status values only.

---

## 9. Fixed 2026-08-18 — non-staff read leak

**What it was.** `_can_view` / `_visible_document_names` checked ownership and
share state but never the caller's role. Because both read paths use
`frappe.get_all` / `frappe.get_doc` — which bypass the doctype permission table
by design — the `Clinical Document` permissions (no grant to `EB_Patient`) never
ran. Any authenticated patient-portal account could therefore
`list_documents()` and `get_document()` any document with `share_with_team=1`,
receiving the full `notes` body and its private attachment URLs.

**Confirmed on live data**, not in theory: all five `EB_Patient` accounts on
`remedisys.localhost` could read a team-shared document (`shared_access_level`
= `Edit`), including its ~1,900-character notes body. Writes were *not*
reachable — `update_document` ends in `doc.save()`, which does consult the
permission table — so this was confidentiality only, not integrity.

**Fix.** `_is_staff()` (§5), applied in both `_can_view`
(`services/clinical_documents.py:198`) and `_visible_document_names`
(`:246`). Owner-based access is untouched, so no staff user loses anything;
verified after the change that Front Desk / Practitioner / Healthcare Admin
still see exactly the same documents and both patient accounts now see none.
Regression guard: `TestClinicalDocumentNonStaffAccess`.

**Worth noting for other modules:** the root cause is generic. Any service that
reads via `frappe.get_all`/`get_doc` and relies on doctype permissions for role
scoping has the same hole. This module is now explicit about it; others in
`api/v1/` have not been audited for it.

---

## 10. Known gaps

- **`share_with_team` alone is silently ignored.** In `update_document` the
  owner-only sharing block only runs when `visibility` is supplied, so
  `share_with_team=True` without `visibility` returns 200 and changes nothing.
  The frontend's single Save always sends both, which is why this has not
  surfaced — but the coupling is undocumented in the signature. Pinned by
  `test_share_with_team_alone_is_a_noop`.
- **A shared `Edit` recipient must not echo sharing fields back.** Any non-None
  `visibility` / `shared_with` / `shared_access_level`, or a truthy
  `share_with_team`, from a non-owner is a 403 — even when the value is
  identical to what is already stored. A frontend that submits the whole
  document on Save will break for `Edit`-level recipients unless it strips
  those four fields when the caller is not the owner.
- **Unknown share target answers 404.** `_clean_user_list` raises
  `DoesNotExistError` for a user id that does not exist, so `create_document`
  answers 404 even though the *document* was fine. 400 would be the honest
  code; changing it is a frontend-visible contract change, so it is pinned by
  `test_unknown_share_target_reports_404` rather than quietly altered.
- **`list_documents` is unpaginated.** It resolves every visible document name,
  then fetches all of them with their attachments. Fine at current volume
  (tens of rows), but it has no `limit`/`offset` and the team-shared query is
  clinic-wide — this is the first thing to change if the drive grows.
- **`get_document` shows recipients to recipients.** `shared_with` is returned
  to anyone who can view the document, not just the owner, so a recipient
  learns who else it was shared with.
- **`svg` is an accepted attachment type.** Files are private, but an SVG
  served inline can carry script. Not exploited here (the same allowlist is
  used by the patient Documents tab) and left as-is rather than narrowed
  unilaterally — flagged so the decision is deliberate.
- Not documented in `docs/FRONTEND_FEATURE_AUDIT.md` — this file fills that
  gap for the backend side; the frontend Narzim Drive component path itself
  is outside this repo and not enumerated here.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
