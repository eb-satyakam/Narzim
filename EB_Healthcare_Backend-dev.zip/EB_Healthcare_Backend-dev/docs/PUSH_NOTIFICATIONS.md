# Push Notifications — End-to-End Design

**Doc status:** living · **Created:** 2026-08-24 by Ashutosh (AI-assisted) · **Updated:** 2026-09-25 by Ashutosh (AI-assisted) · **Version:** 2.16

How a notification travels from the moment something happens in Remedisys to the moment a person
sees it.

**Two transports, deliberately.** **SSE** delivers while an app is open; **FCM** delivers when it is
closed. Neither replaces the other — see [§3](#3-the-shape-of-the-solution) for why one transport
cannot cover both. **Scope today is browser-only** (staff EHR on `:3000`, patient portal on `:3003`);
the patient React Native app is deferred, and nothing in this design changes when it arrives.

**This document owns the mechanism.** The decision and the rejected alternatives are owned by
[`adr/adr-045-push-notifications-fcm-and-sse.md`](adr/adr-045-push-notifications-fcm-and-sse.md);
this document does not restate them. Project and phase status lives only in
[`STATUS.md`](STATUS.md).

**Status of the build:** see [§9](#9-build-order) for the per-step table. In short: **steps 1 and 2
are complete.** Live delivery works in both apps, 11 polling intervals are gone, and the patient portal
has a notification bell and feed of its own. An authenticated `EventSource` against each app's real dev
server received a backend-published event within a second, and upstream sockets were shown to be
released on disconnect (2 → 5 → 2 across three concurrent streams). **FCM (step 3) is not built**, and
**no notification or chat surface in either app polls any more** — 13 intervals removed in total.
Three items are unresolved — see [Open items](#open-items).

---

## 1. Scope

| In scope | Out of scope |
|---|---|
| In-app live delivery (the bell updating while you watch) | Email notifications (Frappe core handles these; `type="Alert"` is never emailed) |
| Out-of-app push (browser closed, phone locked) | WhatsApp as a **delivery channel** — sending a message *to* a patient over WhatsApp is a separate thing, see [`WHATSAPP_INTEGRATION.md`](WHATSAPP_INTEGRATION.md) |
| **Notifying staff that a WhatsApp message arrived** — that is a notification and belongs here (see §4.5) | — |
| Staff EHR (web) and patient portal (web + React Native) | SMS |
| The bell and `/notifications` screen in **both** apps, and the patient-facing feed behind them | AI encounter realtime, which has its own channel (`api/ai/realtime.py`) |

## 2. Why polling had to go

The short version, because the ADR carries the evidence: **every notification in both apps is
delivered by a fixed-interval HTTP poll, and there is no push path at all.** Four hooks in the EHR
poll at 30 s; chat threads poll at 10–15 s; the patient portal polls its chat every 5 s. An EHR tab
with a thread open issues roughly **44 authenticated requests per minute while idle**. A staff member
sees a patient's message up to 30 seconds after it exists.

On a React Native client the same approach would mean **17,280 requests per device per day**, waking
the radio every five seconds. Polling does not survive contact with mobile.

## 3. The shape of the solution

### Why two transports rather than one

A user is in one of three states, and no single transport covers all three:

| State | What the user should experience | Only mechanism that can do it |
|---|---|---|
| **App open** | Counter increments live, no refresh | **SSE** |
| **App closed, returns later** | The notification is waiting in the bell on page load | **`Notification Log`** — persistence, already built |
| **App closed, user elsewhere** | An OS notification appears on their desktop | **FCM** |

The middle row is free: `notify()` writes the row whether or not anyone is connected, so the bell is
correct on next load regardless. The first and third rows need different transports, which is why
this design has two.

**Why not FCM for the open-app case too** (it can, via its foreground `onMessage` handler): FCM
delivery requires notification permission. Clicking "Block" on a browser prompt means *"don't
interrupt me when I'm away"* — it does not mean *"don't show me a message in the app I'm looking
at"*. FCM-only conflates those two consents, so a patient who dismissed a popup weeks ago would sit
in an open chat and never see the reply. It would also route every in-app update through Google,
making an FCM outage break liveness for users who are present. SSE avoids both.

### The four steps

A notification is four steps. Only the last one differs per platform, and that is the entire reason
the design looks the way it does.

| Step | What happens | Same on every platform? |
|---|---|---|
| 1 | **Event** — a patient sends a message, a lab result arrives, an appointment is cancelled | Yes |
| 2 | **Audience + wording** — who should be told, and what the text says | Yes |
| 3 | **Persist** — write the record that backs the bell and the `/notifications` screen | Yes |
| 4 | **Wake the device** | **No** — service worker vs native module |

Building "browser notification logic" and "mobile notification logic" would duplicate steps 1–3 —
the parts carrying all the judgement — to solve a difference that exists only in step 4. So:

**One backend logic, one token registry, one send path, and a thin adapter per platform.**

```
            something happens (patient sends a message)
                              │
                              ▼
        notify(recipients, event_type, ref_doctype, ref_name, link, …)
                    services/notifications.py  ← THE ONLY WAY TO NOTIFY
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
  Notification Log       SSE publish           enqueue push
  (bell + list,         (instant, if the      (for everyone whose
   every platform)       app is open now)      app is not open)
                                                     │
                                                     ▼
                                        look up that user's devices
                                          in Push Device Token
                                                     │
                                    web token ──┐
                                    iOS token   ├──► one FCM send call
                                    android     ──┘
```

Because web **and** React Native both produce FCM registration tokens, step 4's *server* side is
also a single code path. The backend never learns whether it is talking to Chrome or an iPhone.

## 4. Layer by layer

### 4.1 The chokepoint — `services/notifications.py`

Today at least three places create `Notification Log` rows independently, and they have already
drifted apart:

| Site | Behaviour before consolidation |
|---|---|
| `api/v1/patient_portal/chat.py` | Checked `is_notifications_enabled(user)`. Used `type="Alert"` deliberately — the one type Frappe never emails, which is what makes naming the patient safe. **Upserted**, so a chatty patient produced one row always showing their latest message, with `creation` refreshed so it re-surfaced at the top. This one was right, and became the model. |
| `integrations/whatsapp/chat_api.py` | Raw inline `frappe.get_doc`. No preference check. No dedupe. Subject a hardcoded English string not wrapped in `_()` — a visible defect in an `es-MX` deployment. **And it never fired at all:** it filtered recipients on `User.company`, a column that does not exist on this bench (verified against the live DB), so every call raised and was swallowed by a bare `except`. |
| `api/v1/notifications/api.py` (`_notify_assignee`) | Raw insert with **`type="Assignment"`**, which Frappe *does* email — only `"Alert"` is in core's `notification_skip_email_types` (`frappe/hooks.py:82`). Its subject embeds a patient name, so for any user without a Notification Settings row a patient name reached an SMTP subject line. No preference check either. |

That divergence happened without anyone deciding it should, and it is the strongest argument for a
single entry point. Two of the three carried live defects that the consolidation fixed as a side
effect — which is what a chokepoint buys you. `notify()` becomes the only way to raise a notification, mirroring the existing
rule in `api/ai/realtime.py` that all realtime emits go through `publish_to_encounter`.

```python
def notify(
    recipients: list[str],      # user ids
    event_type: str,            # "portal_chat_message", "lab_result_ready", …
    ref_doctype: str,           # "Portal Conversation"
    ref_name: str,              # the conversation id
    link: str,                  # RELATIVE frontend path, never a /app/… Desk URL
    subject: str,               # in-app wording; MAY name the patient
    body: str = "",             # in-app body; MAY carry a preview
    dedupe: bool = True,        # upsert an existing unread row rather than adding one
) -> None:
```

Two things deliberately **not** parameters:

- **The push payload.** It is derived, never supplied, so no caller can accidentally push PHI. See
  [4.4](#44-out-of-app--fcm).
- **The transport.** Callers describe an event; they do not choose SSE or push.

### 4.2 Persistence — `Notification Log`

Unchanged from today's behaviour, which is already correct in the portal-chat path and becomes
universal:

- One **unread** row per `(user, ref_doctype, ref_name)`. A second message updates that row's subject,
  body and `creation` instead of inserting a new one. `creation` is rewritten deliberately: both the
  bell and the list order by it, so leaving it stale would hide a new message behind older rows.
- `type="Alert"` always, so Frappe never emails it. This matters: `Notification Log.before_insert`
  mirrors `title` ↔ `subject` and `description` ↔ `email_content`, so there is no PHI-free in-app-only
  field to hide behind. **The type is the control.**
- `is_notifications_enabled(user)` is respected, the way core's `make_notification_logs` does.

This layer is what makes the whole design degrade safely: if both transports fail entirely, the bell
still works on next page load, because the record exists independently of its delivery.

### 4.3 In-app — SSE through the BFF

The browser must not hold a JWT ([`adr/adr-011-auth-eb-frappe-jwt.md`](adr/adr-011-auth-eb-frappe-jwt.md)),
so the connection is relayed:

```
browser ──EventSource──► Next.js route handler ──socket.io-client──► Frappe SocketIO :9000
        (same-origin,        (holds the JWT,                        (authenticates via the
         no credentials)      server-side only)                      Authorization header)
```

> **Simpler than originally specified.** Earlier versions of this section defined a custom
> `remedisys:user:<id>` channel plus a `subscribe`/authorize whitelisted method. Neither is needed:
> Frappe already provides per-user rooms. `frappe.publish_realtime(user=…)` targets
> `user:<user>` (`frappe/realtime.py:167::get_user_room`), and a connecting socket **auto-joins its
> own authenticated user's room** (`frappe/realtime/handlers.js:5`). The authorize endpoint was
> deleted before it was written.

| Concern | How it is handled |
|---|---|
| ⚠️ **`Origin` must be the Frappe WEB host, not the socket host** | The single most confusing failure in this design. Frappe's middleware builds its auth callback to `frappe.realtime.get_user_info` **from the `Origin` header the client sends** (`apps/frappe/realtime/utils.js::get_url`). Point `Origin` at the socket service (`:9000`) and that callback hits a bare `http.createServer()` with **no request handler**, so the fetch never returns, `next()` is never called, and the handshake hangs with **no `connect` and no `connect_error`** — completely silent. Send `Origin: <FRAPPE_URL>` (`:8000`) while connecting to `:9000`. The middleware's own origin check (`authenticate.js:22`) compares **hostnames only, never ports**, so both conditions hold. Found by testing, 2026-08-25. |
| Backend emit | `services/notifications.py::publish_to_user()` — the only place this app publishes notification events, mirroring `api/ai/realtime.py`'s rule for encounter events. Calls `frappe.publish_realtime(event=…, message=…, user=…, after_commit=True)`. |
| Socket event name | **`remedisys:notification`** — one event for every notification kind. The payload's `event_type` tells the client which query to invalidate, so a new notification kind never needs a new listener. |
| Room / authorisation | Frappe's built-in `user:<user_id>`, joined automatically from the socket's **authenticated identity**. A client cannot request another user's stream because it never names one — there is nothing to authorize. |
| Event vocabulary | Closed set in `EVENT_TYPES` — **22 events**, listed in full in [§4.5](#45-channels-that-raise-notifications). A typo fails loudly instead of producing an unroutable event. The key is the client's routing value: it becomes the push payload's `data.type` and drives the EHR's per-event icon and action buttons, so adding one means adding a presentation entry too. |
| Reconnection | Native to SSE. The browser reconnects automatically and sends `Last-Event-ID`; the handler replays missed events from `Notification Log`. |
| Duration limits | Vercel's default `maxDuration` is **300 s** (verified 2026-08-24; neither frontend sets it or ships a `vercel.json`). The stream is cut **mid-frame** every 5 minutes, so the client must parse frames defensively and resume by `Last-Event-ID`. Raising it to 800 s needs Pro + Fluid Compute. |
| **Concurrency cost** | Was the bigger constraint. Every open tab holds a function invocation for as long as it is connected — 20 staff x 8 h is roughly **4,800 function-hours/month** — and raising `maxDuration` does not reduce that, since you are connected either way. Only **Fluid Compute** does, by letting one instance serve many mostly-idle connections. **Confirmed enabled on the Vercel Pro project, 2026-08-25**, so this is addressed. Do not disable it without re-costing the SSE connections. |
| Event payload | **IDs only** — exactly `{"event_type", "ref_doctype", "ref_name"}`, asserted by test. No subject, no preview, no patient name (Rule 10). The client refetches through the normal authenticated API, as itself, under its own permissions. |
| Emit ordering | `after_commit=True`, and `_fanout` only emits for rows that **actually persisted** — a preference-suppressed recipient gets no event, and rolled-back work cannot ring a browser and send it fetching a row that does not exist. |
| React Native (later) | Consumes the same endpoint unchanged. SSE is plain HTTP and needs no socket library, which is why one transport serves every client. |

**Both apps get rows, and two counts that are allowed to differ.** Earlier versions of this section
said patients got the realtime event *only*, on the reasoning that a notification row would duplicate
the portal's chat unread count. **That was reversed on 2026-08-25** when the portal gained a bell and a
`/notifications` page: a page needs records, and per-item read state is precisely what
`Notification Log` provides.

So the two numbers now mean different things, in both apps:

| Surface | Counts | Source |
|---|---|---|
| Bell (EHR sidebar · portal header) | unread **notifications** | `Notification Log` |
| Chat widget (EHR) · Chat nav item (portal) | unread **messages** | `Chat Message` / `/api/chat/unread` |

They are permitted to disagree — reading a chat clears its messages, not the notification about it —
and that is the same split the staff EHR has always had between its bell and its chat widget.

The one genuine asymmetry that remains is **team chat**: `team_message` emits a realtime event but no
row, because the widget's unread badge is derived from `Chat Message` against the reader's
`last_read_at` (`messages/api.py::_unread_count`). A row there would be a second store for a number
that is already computed.

`portal_chat.py::_notify_patient_of_staff_message` resolves the recipient through `Patient.user_id`,
the same mapping `patient_portal/api.py::_session_patient` uses in the other direction.

> ### ⚠️ `description` and `email_content` mirror each other
>
> `Notification Log.before_insert` copies `description` → `email_content` (or the reverse) whenever
> **one of the two is blank**. So a non-empty `email_content` placeholder on a bodyless notification is
> copied *into* `description`, and the UI renders the placeholder as the notification's text — which is
> exactly what shipped for about an hour on 2026-08-25 ("Open the record to read this notification."
> appearing as a patient's message preview).
>
> `notify()` therefore sets `email_content` **only when there is a body to protect**. Both blank is a
> no-op, and an empty field cannot leak anything. Do not "fix" this by putting a placeholder back.

### 4.4 Out-of-app — FCM

**The registry.** One new doctype, `Push Device Token`:

| Field | Purpose |
|---|---|
| `user` | who to reach |
| `token` | the FCM registration string (same shape for web, iOS, Android) |
| `platform` | `Web` / `iOS` / `Android` — for debugging and payload quirks only, never for routing |
| `app` | `Portal` / `EHR` — so a staff device never receives patient-app notifications |
| `last_seen` | refreshed on every app open; drives pruning |
| `active` | cleared when FCM reports the token invalid |

Indexed on `user` and `token`. `track_changes: 1`. Permissions: a user may read and delete only their
own rows; only the service layer writes.

**The payload contract — normative.** A push is a *doorbell*, never an *envelope*.

| Field | Value | Why |
|---|---|---|
| `title` | A **generic** localised string — "New message from your clinic" / "Nuevo mensaje de tu clínica" | Renders on a lock screen and transits Google |
| `body` | Empty | Same |
| `data.type` | `portal_chat_message` | Lets the client route the tap |
| `data.ref` | The document id | Lets the client fetch the real content |
| `data.link` | Relative frontend path | Deep link on tap |
| Anything else | **Forbidden** | — |

A *data-only* push will not reliably display anything on iOS, which is why the rule is not "send
nothing" but **"send nothing patient-specific."**

**What the staff banner actually reads, and why that is not a breach of the row above.** Since
2026-09-25 an EHR banner says *"Khalid Kashmiri sent a message"*, not *"New message from a patient"*.
The **payload is unchanged** — still a generic title and the three identifiers. The name is resolved
by the service worker at display time, from **our own origin**:

```
FCM  ──► { title: "New message from a patient", data: { type, ref } }   ← Google sees only this
SW   ──► GET /api/push/preview?type=&ref=   (session cookie, same origin)
BFF  ──► api/v1/push/api.py::notification_preview
         → the `subject` of the Notification Log row addressed to THIS caller
banner ► "Khalid Kashmiri sent a message"
```

Three properties make this safe, and all three are load-bearing:

- **Google receives nothing new.** That is what keeps FCM out of the subprocessor register on the same
  argument `compliance/profiles/mx.py` makes for NCBI, and keeps the pending data-terms check the same
  size.
- **The lookup is filtered by `for_user = <the caller>`**, so it returns only a notification already
  addressed to them — the same string their bell shows. A guessed `ref` returns `""`.
- **It fails open.** 401, error, or slower than 2.5 s → the generic title is used. A banner that says
  slightly less is a non-event; one that never appears is a missed patient message.

Decision and the accepted risk (a named banner on an unattended front-desk screen, no per-clinic
toggle): [ADR-093](adr/adr-093-patient-name-in-staff-push-banners.md).

```python
# WRONG — patient name to Google, message text on a lock screen
title = payload["subject"]        # "Titan Sharna sent a message"
body  = content[:_PREVIEW_LEN]    # "mi hijo tiene fiebre de 39°"

# RIGHT — generic string; identifiers only, in data
title = _("New message from your clinic")
body  = ""
data  = {"type": "portal_chat_message", "ref": conversation, "link": link}
```

Note the trap this closes: `chat.py:437` already sets `subject` to the patient's name, which is
correct for the in-app row and must **never** be forwarded to FCM verbatim. The payload builder
derives its own strings and ignores `subject` entirely.

Google sees: a device token, `"portal_chat_message"`, and a timestamp.

**Why the push must be visible, not silent.** A WebSocket or SSE connection belongs to the app's
*process*. It is gone the moment the app is suspended — iOS tears down connections within seconds of
the user pressing home, so you do not even need the app killed for it to stop being useful. Push
works because the **operating system** holds one permanent connection to APNs/FCM on behalf of every
app, and renders the notification itself without the app running. Reaching a closed app is an OS
privilege, not something an app can implement.

| App state | SSE / WebSocket alive? | FCM / APNs works? |
|---|---|---|
| Open, on screen | Yes | Yes |
| Just backgrounded | Briefly, then suspended | Yes |
| Suspended / long-backgrounded | No | Yes |
| Killed by the OS under memory pressure | No | Yes |
| **Force-quit by the user** (swiped away) | No | **Visible alerts yes · silent pushes no** |
| Rebooted, app never reopened | No | Yes |

The force-quit row is the one that constrains the payload. On iOS a force-quit stops delivery of
**silent** pushes (`content-available: 1`, data-only) — the system reads it as "the user does not want
this app running" — but a **visible alert** is still displayed, because the OS draws it without
involving the app at all. So the generic `title` above is not only the PHI-safe choice; it is the
**only variant that survives force-quit on iOS**. The privacy constraint and the reliability
constraint point the same way, which is why the contract mandates a generic title rather than an
empty one.

There is no workaround worth proposing later: Android can hold a socket in a *foreground service*,
but that requires a permanent status-bar notification, drains battery measurably, and Play Store
policy restricts which apps may use one — "new message" does not qualify. iOS has no equivalent API
at all.

**Two decisions worth stating, because the code alone does not explain them.**

*Push is sent unconditionally, without checking for a live SSE connection.* The server cannot know
presence reliably — a stream can be open on a laptop the user walked away from and closed on the phone
in their hand. So the decision belongs on the client: the service worker calls `clients.matchAll()` and
suppresses the banner when a visible window already has the event. This fails safe. A missed
suppression costs one redundant banner; a missed push loses the message.

*Two gates, not one.* `is_enabled()` requires **both** a `firebase_service_account` credential **and**
the `remedisys_push_enabled` flag. They answer different questions — *can* we send versus *should* we —
and §9 requires feature flags to default OFF in production. Push is therefore inert on a site that has
credentials but has not opted in, which is exactly the state a fresh deployment should be in.

**Why not Frappe's relay.** `frappe/push_notification.py` would do much of this, but its address comes
from `frappe.conf["push_relay_server_url"]` and pointing it at Frappe's hosted service inserts Frappe
as a second sub-processor alongside Google. We call FCM HTTP v1 directly instead;
`push_relay_server_url` stays unset. Reasoning in the ADR.

**The Firebase project, as provisioned (2026-08-24).**

| Item | Value / state |
|---|---|
| Project | `remedisys-notifications-8cb48` · Sender ID `240705583255` · **Spark (free)** plan — FCM needs no Blaze upgrade. Created 2026-08-25 |
| Firebase Cloud Messaging API (V1) | **Enabled**. Legacy Cloud Messaging API: **Disabled** — correct, we use v1 only |
| Web apps | **Two**, one per frontend, sharing the project. Different `appId`; the `app` field on `Push Device Token` mirrors the split, which is what stops a staff device receiving patient-app notifications |
| Web Push (VAPID) key | Generated and placed. **Project-level**, so the same value goes in both frontends — one key pair despite two web apps |
| Service-account credential | Pending placement in `site_config.json` |
| Superseded project | `remedisys-notifications` (sender `221959994218`) was **abandoned unused** — its Google Cloud organisation enforced `constraints/iam.disableServiceAccountKeyCreation`, so no service-account key could ever be issued for it. Nothing was ever deployed against it |

**Configuration contract.** Frontend values are public by design (embedded in client JS; access is
governed by project rules, not secrecy) and live in each app's gitignored `.env.local`:

```bash
NEXT_PUBLIC_FIREBASE_API_KEY
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN
NEXT_PUBLIC_FIREBASE_PROJECT_ID
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
NEXT_PUBLIC_FIREBASE_APP_ID      # differs per app
NEXT_PUBLIC_FIREBASE_VAPID_KEY   # project-level, same in both
```

The backend secret is a single `site_config.json` key, `firebase_service_account` (the whole
service-account JSON as a nested object) — matching the existing `openai_api_key` /
`deepgram_api_key` pattern. It is **never** in either repo and never `NEXT_PUBLIC_`.

### 4.5 Channels that raise notifications

`notify()` is channel-agnostic: any feature that needs to tell someone something calls it.

**The complete event vocabulary.** Verified against `EVENT_TYPES` and every `notify()` call site on
2026-09-24. The event key is the routing value the clients switch on, so this table is the contract —
a key with no emitter is a rendering path that can never fire, and a key missing from here is one the
frontend has no icon for.

| Event key | Raised by | Recipients | Delivery |
|---|---|---|---|
| `portal_chat_message` | `patient_portal/chat.py::_notify_staff_of_patient_message` | **`_TRIAGE_ROLES`** — Patient Coordinator + Front Desk | row + realtime · push → EHR |
| `portal_chat_reply` | `patient_portal/portal_chat.py::_notify_patient_of_staff_message` | the patient | row + realtime + **push (live)** → Portal. The row carries a preview of the clinic's reply: the patient's own conversation is their own data, and it beats a bare "you have a message" |
| `team_message` | `messages/api.py:308` — **`publish_to_user()` directly, not `notify()`** | every thread member except the sender | realtime **only**, no row, by design (§4.3) |
| `whatsapp_patient_message` | `integrations/whatsapp/chat_api.py::_notify_whatsapp_inbox` | **`_WA_TRIAGE_ROLES`** — Patient Coordinator + Front Desk | row + realtime · push → EHR |
| `whatsapp_chat_assigned` | `notifications/api.py::_notify_assignee` | the assignee | row + realtime · push → EHR. Links to the patient's CHART, not the shared inbox |
| `portal_chat_assigned` | `patient_portal/portal_chat.py::_notify_portal_assignee` | the assignee | ditto — its portal twin, added 2026-09-25 |
| `whatsapp_appointment_cancelled` | **nothing — see the orphan note below** | — | — |
| `appointment_booked` | `appointment_notifications.py::_send`, from `on_appointment_created` (`after_insert`) | the patient | row + realtime + **push (live)** → Portal |
| `appointment_cancelled` | `_send`, from `on_appointment_updated` (`status` → `Cancelled`) and `notify_cancelled()` | the patient | ditto. The cancellation **reason is deliberately withheld**: it can be "patient did not pay" or "practitioner unavailable", which is staff-facing |
| `appointment_rescheduled` | `_send`, from `on_appointment_updated` (`appointment_date`/`appointment_time` changed) | the patient | ditto, carrying the old date in `params` |
| `appointment_reassigned` | `_send`, from `on_appointment_updated` (`practitioner` changed) | the patient | ditto — their doctor changed, which they would want to know |
| `appointment_booked_by_patient` | `appointment_notifications.py::notify_front_desk_booked`, called from `patient_portal/api.py:753` | `_clinic_ops_recipients()` — EB_Front Desk + EB_Healthcare Admin | row + realtime · **no push** ⚠️ |
| `appointment_cancelled_by_patient` | `notify_front_desk_cancelled`, from `patient_portal/api.py:834` | ditto | ditto — **no push** ⚠️ |
| `appointment_rescheduled_by_patient` | `notify_front_desk_rescheduled`, from `patient_portal/api.py:911` | ditto | ditto — **no push** ⚠️ |
| `practitioner_availability_declared` | `providers/api.py::set_my_availability_override` | front desk | row + realtime · **no push** ⚠️. Sent with **`force_sync=True`** — the async path silently delivers nothing here (see the call site's own note) |
| `practitioner_unavailable_conflict` | **nothing — see the orphan note below** | — | — |
| `todo_assigned` | `tasks/api.py::_notify_todo_assignee`, on ToDo create and on reassignment | the new owner | row + realtime · **no push** ⚠️ |

**Who is told about an inbound patient message changed on 2026-09-25.** It used to be every holder
of five roles — measured at 39 users, so one message wrote 38 rows carrying the patient's name and
their words. It is now the triage desk only (Patient Coordinator + Front Desk), and a clinician hears
about a conversation when a coordinator **assigns** it to them, by name, rather than because they
hold a clinical role. Narrowing the notification did NOT narrow access: every conversation is still
readable by every staff member, which is why `_STAFF_ROLES` (who may look) and `_TRIAGE_ROLES` (who
is told) are now separate constants.
[`notifications_patient_coordinator.md`](planning/notifications_patient_coordinator.md)

**Why the staff-facing appointment events are separate keys.** A patient acting on their own
appointment triggers `_send()`, which self-skips (`frappe.session.user == user`) — so the
patient-facing event notifies nobody, while the clinic's day has just changed with no one at the
clinic touching it. The three `*_by_patient` keys exist for that, and are deliberately NOT the
patient-facing keys with a different recipient list: the key drives what the client renders, and
"your appointment is confirmed" is not "a patient booked, your schedule changed".

> #### ~~Six events are never pushed~~ — RESOLVED 2026-09-24
>
> All 22 events are now in `_APP_FOR_EVENT` and `_TITLES`. The six that were missing — the three
> `*_by_patient`, both `practitioner_*` and `todo_assigned` — would have gone silently un-pushed the
> moment EHR push (step 3c) shipped, with a missing dictionary entry as the invisible cause.
>
> The rule that allowed it still stands, so keep it in sight: `app_for_event()` returns `None` for an
> unlisted event and **`None` means do not push**, deliberately, so an unclassified event is never
> broadcast to every device a user owns on a guess. Adding an event means adding a routing entry and
> a title in the same change.
>
> The `Delivery` column above distinguishes two states: **push (live)** — classified, with a service
> worker in the receiving app (both Portal and EHR as of 2026-09-25); and **no push** — not classified
> at all, which no event currently is. The third state, "classified but no receiver", is gone: it
> described EHR events between the routing landing and step 3c shipping.

> #### ⚠️ Two declared events have no emitter
>
> Both are in `EVENT_TYPES` and neither is ever passed to `notify()` (verified 2026-09-24):
>
> - **`whatsapp_appointment_cancelled`** — a leftover. Cancellation over WhatsApp was **retired** in
>   favour of the portal flow, where the patient signs in and sees which appointment they are
>   cancelling; the front desk is still told, through `notify_front_desk_cancelled`. The reasoning is
>   at `integrations/whatsapp/chat_api.py:35-41`. Earlier versions of this table listed this row as
>   live and cited `chat_api.py::_notify_front_desk_cancellation`, **a function that does not exist**.
> - **`practitioner_unavailable_conflict`** — declared alongside
>   `practitioner_availability_declared` (ADR-062 addendum), but nothing raises it. The EHR has a full
>   presentation entry for it (`notification-presentation.ts:292`) and a type-union member
>   (`types/notifications.ts:32`), so there is a rendering path for a notification that cannot occur.
>
> Neither is harmful — an unraised key delivers nothing — but both are a claim the code does not
> honour. Each needs either an emitter or removal from the set, and removal is the breaking one:
> the frontend union would have to drop it in the same change.

> ### ~~Known gap~~ — RESOLVED 2026-08-25
>
> `on_whatsapp_message_created` links the message to its conversation, increments the conversation's
> unread count and updates the preview — and stops. It writes **no `Notification Log` row and emits no
> realtime event.** Verified by reading the whole function (2026-08-24).
>
> **Consequence:** staff discover a WhatsApp message only if they already have the inbox screen open,
> where `use-whatsapp.ts` polls the list every 15 s and the thread every 10 s. Close that tab and a
> patient's message sits unseen — no bell, no counter, no alert. This is arguably worse than the
> portal gap, because WhatsApp is where patients in the Mexico deployment actually are.
>
> **Its two polling intervals went in the same change**, which is the rule: never remove an interval
> without adding the event, or the widget silently goes stale. With WhatsApp done, **no notification or
> chat surface in either app polls any more.** What remains in the EHR is `use-dashboard` (30 s KPIs)
> and `use-my-work` (60 s task list) — different features, and event-driving them would need a
> `notify()` call wherever tasks are assigned.
>
> **Fixed** by `_notify_whatsapp_inbox`, which is one `notify()` call plus a recipient lookup. It
> inherited the preference check, the upsert-so-a-chatty-patient-does-not-flood-the-panel behaviour,
> `type="Alert"` email safety, the realtime emit and the never-raises guarantee — none of it written
> again. That is the payoff of the chokepoint in §4.1.
>
> **Recipients: every WhatsApp staff member. Assignment is deliberately not consulted.**
> `get_whatsapp_conversations` already treats the inbox as shared — everyone sees every conversation
> regardless of assignment — and the notification follows that, so nothing depends on a conversation
> having been assigned first. An unassigned message is precisely the case that most needs picking up.
>
> An assignment-routed variant (assignee alone when assigned, everyone otherwise) was built first and
> **withdrawn on request**: it layered routing logic onto the WhatsApp integration for a benefit —
> less notification noise — that was not wanted here. Recorded because the trade-off is real and will
> come back if the inbox ever gets busy: a shared notification is simple and never misses anyone, at
> the cost of pinging people about conversations someone else is handling.
>
> `_WA_ROLES` was extracted so the fan-out cannot drift from the access check — notifying someone who
> cannot open the conversation is worse than not notifying them. That extraction changes no behaviour;
> `_require_whatsapp_role` reads the same list it always did.
>
> **Subject** names the patient when the number is known, and otherwise the number itself, which is
> more use to front desk triaging a first contact than "A patient".
>
> **Follow-ups:**
>
> 1. **No deep link yet.** `link` is `/messages`, not `/messages?conversation=<id>`, because that screen
>    does not read a conversation id from the query string. Worth adding.
> 2. ~~**No filter tab.**~~ **Done 2026-08-25.** The notifications screen now has a **WhatsApp** tab
>    beside Portal chat, with its own count from `get_notification_counts`. The two channels are kept
>    visually distinct because staff triage them differently — WhatsApp carries a 24-hour reply window,
>    portal chat does not — and a single merged "chats" tab would have hidden that.

### 4.6 Appointment lifecycle — one hook, ten write points

`services/appointment_notifications.py` hooks `Patient Appointment` (`after_insert` + `on_update`).

**Why a hook and not a call per endpoint.** There are **ten** ways an appointment changes: four booking
paths, two cancel paths, three reschedule paths and three patient-portal self-service paths. The count
grows — the four booking variants exist because payment options were added over time. Calling `notify()`
from each would be more explicit, and was rejected: the eleventh path gets written by someone who does
not know to add the notification, and the omission is **silent**. That is the drift the chokepoint in
§4.1 exists to end.

> ### ⚠️ The hook does NOT cover all ten. It cannot.
>
> This was claimed here on 2026-08-26 and it was **wrong** — corrected the same day, after a
> cancellation produced no notification.
>
> `cancel_appointment` and `update_status` write with `frappe.db.set_value` — a direct SQL UPDATE. No
> `validate`, no `on_update`, so **no hook of any kind runs**. And they must stay that way: core
> Healthcare's `Patient Appointment.validate()` calls `set_status()` on every save, which recomputes
> status from `appointment_date` versus today, and `"Cancelled"` is not in the list it preserves.
> Saving therefore **silently reverted every cancellation back to "Open" while reporting success** —
> the bug documented at length in `patient_portal/api.py::cancel_my_appointment`.
>
> So the real design is a **hybrid**, not a single hook:
>
> | Path | Mechanism | Covered by |
> |---|---|---|
> | booking (×4), `reschedule_appointment`, `reschedule_appointment_with_payment`, `reassign_appointment` | `doc.save()` | the **hook** |
> | `cancel_appointment`, `update_status` → Cancelled | `db.set_value` | an **explicit** `notify_cancelled()` call |
> | `check_in_patient` | `db.set_value` | nothing — check-in is not notified |
> | `cancel_my_appointment` (portal) | core's helper | nothing — the patient's own action |
>
> Both routes funnel into the same `_send`, so wording, recipient resolution, the self-service skip and
> the dedupe cannot drift apart. The hook's own cancellation branch is kept even though the two real
> endpoints bypass it, so a future path that *does* save its way to `Cancelled` is not silently missed.
>
> **The general lesson:** "a doctype hook catches every write" is only true of writes that go through
> the document lifecycle. `frappe.db.set_value` is invisible to hooks, and in this codebase it is used
> deliberately, with reasons, in several places.

**The cost, stated honestly:** intent is inferred from a field diff rather than declared by a caller. So
the guard *is* the design:

| Change | Result |
|---|---|
`status` → `Cancelled` | notify (cancellation **wins** over a simultaneous reschedule) |
`appointment_date` / `appointment_time` changed | notify |
`practitioner` changed | notify |
`status` → `Confirmed` / `Checked In` / `Closed` / `No Show` | **silent** — internal workflow |
Anything else (check-in, invoice link, department backfill, `set_only_once` reconciliation) | **silent** |
The patient acting on their own appointment | **silent** — three of the ten paths are self-service |

> ### ⚠️ Two bugs this hook had, both found by testing through the real API
>
> Recorded because both were silent, and both would be easy to reintroduce.
>
> **1. A status change must not short-circuit the other checks.** The first version returned as soon as
> `status` had changed, assuming a status change and a reschedule were separate saves. **They are not** —
> core normalises `status` in the *same* save that moves the date (observed: `Closed → Scheduled` when a
> past appointment is moved into the future). So every reschedule also changed status and was silently
> swallowed. The checks are now evaluated together and prioritised, with no early return on an
> uninteresting status change.
>
> **2. A Frappe field's type depends on how it was loaded.** `appointment_datetime` is a `datetime` when
> read from the DB but a plain **`str`** during the save cycle this hook runs inside. Calling
> `.strftime()` threw `AttributeError` on every real reschedule — caught by the never-raises guard and
> logged, so the notification simply never arrived. Now normalised through `frappe.utils.get_datetime()`.
>
> Both passed an earlier test that used a freshly-loaded document. **A test that loads the doc itself is
> not testing this code path.**

Never derive the time from `appointment_time`: it is a `timedelta` (seconds since midnight), so
interpolating it yields `7:21:00`-style nonsense. Use `appointment_datetime`.

### 4.7 What the message says — event keys, not sentences

Governed by [`adr/adr-046-notification-event-keys-and-channel-roles.md`](adr/adr-046-notification-event-keys-and-channel-roles.md).

A notification stores **a stable event key plus parameters**, and the client renders it:

```
remedisys_event  : "appointment_rescheduled"
remedisys_params : {"date": "2026-09-08", "time": "16:45", "datetime": "...",
                    "practitioner": "Om Birla", "department": "...", "old_date": "..."}
subject          : "Appointment rescheduled"        ← server-rendered FALLBACK
description      : "Moved to 2026-09-08 at 16:45"   ← server-rendered FALLBACK
```

**Why.** `subject`/`description` go through `_()`, which resolves in the **writer's** session language,
not the reader's — a receptionist working in English produces an English notification for a
Spanish-speaking patient. The **`subject`/`description` fallbacks are still absent from `locale/es.po`**,
so they render in English on an `es-MX` site regardless. That is a real problem for
*"Moved to 2026-09-08 at 16:45"*, which a parent needs as `martes 8 de septiembre a las 16:45` or they
arrive on the wrong day. (The **push** titles and bodies are a separate string set and *are* translated
now — see "Push is the exception" below.)

**The fallback is kept, not replaced.** A client that does not know a key, a row written before this
existed, and the Desk itself all still show something. Adding params to an event is additive and never
breaks an older client — verified: pre-existing rows return `event: ""`, `params: {}` without error.

**Rendered client-side, in the portal.** `components/portal/notification-text.tsx` takes the row and
returns `{title, body}` — from the catalogue when it knows the `event`, from `subject`/`description`
when it does not. The date is formatted with `Intl.DateTimeFormat` in the device's locale, so the same
stored row reads:

```
en-US   Appointment rescheduled   ·  Moved to Tuesday, September 8 at 16:45
es-MX   Cita reprogramada         ·  Movida al martes, 8 de septiembre a las 16:45
```

Three implementation notes, each of which cost a bug:

1. **Rendering needs a hook, and a hook cannot be called inside `.map()`** — so each row is its own
   `NotificationRow` component.
2. **Do not use ICU `select` to make a parameter optional.** `select` matches exact strings, so an
   empty value still hits `other` and renders a dangling separator. Caught by testing both catalogues.
3. **`next-intl` does NOT throw on a missing message.** It logs a console error and **returns the key
   path as the string**, so `notifications.portal_chat_replyBody` renders as if it were text. Both of
   the original guards here were `try`/`catch` around `t()` and were therefore **completely inert** —
   including the one deciding whether an event was known at all, which meant *any* unrecognised event
   would have printed its raw key as the title. Key existence is now checked against `useMessages()`:

   ```ts
   function useHasMessage(key: string): boolean {
     const messages = useMessages();
     return typeof messages?.notifications?.[key] === "string";
   }
   ```

   Title and body are checked **independently**, because "title but no body" is a legitimate shape —
   chat is exactly that: a translated label with the clinic's own message passed through verbatim.
   There is deliberately **no `portal_chat_replyBody` key**, and a test asserts its absence.

**Push is the exception, and needs a server-side render.** A push payload has no client to render it —
the string in it *is* what the OS displays. So `push.py::recipient_language()` resolves
`User.language` around `build_payload`. The payload stays content-free; only its generic title and
body are translated.

All 22 event titles and the 8 patient-facing bodies are in `locale/es.po` as of 2026-09-25. Patient
strings use informal *tú*, matching the portal's own catalogue; staff strings stay neutral:

```
appointment_reminder    en  See you soon 👋 / Tap to see your appointment details
                        es  Nos vemos pronto 👋 / Toca para ver los detalles de tu cita
appointment_missed      en  We missed you today
                        es  Hoy no pudimos verte
```

Staff (EHR) events deliberately carry **no body** — their titles already say the whole thing
(*"A task was assigned to you"*), and an invented second line would only pad the banner.

> **The trap that made this look done when it was not.** `_()` does **not** read `locale/es.po`. It
> reads a compiled `es.mo` under `sites/assets/locale/es/LC_MESSAGES/`, which is a build artefact and
> is **not** in the repo. Editing the `.po` alone changes nothing — the strings came back English and
> looked like a routing bug. `bench build` compiles it (`bench migrate` does **not**), so a deploy is
> fine, but locally you must run `bench build` or compile the one file directly. The `.mo` on this
> bench had been stale since 2026-07-01, holding 150 of the catalogue's 181 messages.

**Tabs.** The portal's notification page filters by channel — All / Messages / Appointments — with
per-tab unread counts from `get_my_notification_counts`. The `document_type` filter is **intersected
with** `_PATIENT_VISIBLE_DOCTYPES` server-side rather than replacing it, so a crafted
`document_type=Patient Encounter` returns nothing instead of widening what a patient can see. Verified
against four probe doctypes.

### 4.8 Service-worker strategy (portal)

**One service worker, not two.** The conventional FCM setup ships a `firebase-messaging-sw.js` at the
root. The portal already has `sw-custom.js` there, owning the offline shell — and **two service workers
at root scope conflict, because only one can control a page.** So push is handled inside the existing
worker, and the SDK is pointed at it via `getToken({ serviceWorkerRegistration })`.

**No Firebase SDK inside the worker either.** FCM delivers a standard Web Push payload, so a plain
`push` listener suffices — and handling it ourselves is what makes the suppression below possible.

| Concern | How it is handled |
|---|---|
| Banner suppression | `clients.matchAll()`; if any window is `visible`, no banner. The SSE stream has already put it on screen. |
| Deep link | `notificationclick` reads `data.link` and reuses an existing tab (`focus()` + `navigate()`) rather than piling up new ones. It previously hardcoded `openWindow("/")`, discarding the link the backend produced. |
| Repeat collapsing | `tag: data.ref` — a chatty clinic replaces its own banner instead of stacking. |
| Permission timing | **Never on page load.** An unprompted request is reflexively blocked, and a blocked permission is sticky, so one bad prompt costs push permanently. `syncPushRegistration()` is silent and acts only when permission is already granted; the opt-in card on `/notifications` does the asking, from a click. |
| Token rotation | Re-registered on every load. FCM reissues tokens unannounced and the backend upserts by token, so re-registering *is* the rotation mechanism. |
| Logout | `disablePush()` runs **before** the session is torn down, since unregistering is an authenticated call. It also `deleteToken()`s, so the browser stops being addressable rather than merely ignored. On a shared device this is what stops the next person receiving the previous user's notifications. |
| SDK weight | Imported lazily inside the functions that need it — a static import would put Firebase in every route's bundle. |
| Branding | `icon` and `badge` are portal-local paths; the FCM payload deliberately carries **no** icon field, so the worker is the only place they are set. |

**Icon assets (portal).** All derived from `src/app/icon.png` (660x660, the Narzim pulse mark) — the
one source of truth, and the same art `src/app/apple-icon.png` already used:

| File | Size | Used by | Why it is shaped that way |
|---|---|---|---|
| `public/icon-192.png` | 192 | `showNotification({icon})`, manifest `any` | The full-colour mark, shown beside the banner text |
| `public/icon-512.png` | 512 | manifest `any` | Install prompt and app listings |
| `public/icon-maskable-512.png` | 512 | manifest `maskable` | The disc **bleeds to the canvas edge** over a `#0D4E54` fill. Android clips launcher icons to a device-defined shape, so transparent corners get letterboxed into a white square |
| `public/icon-badge-96.png` | 96 | `showNotification({badge})` | **Alpha stencil only** — the white pulse glyph on transparency. Android discards the badge's colour and masks it, so a full-colour disc renders as a solid grey blob |

Two things were wrong before 2026-09-25 and both showed on a real device: `icon-192.png` was a
navy-square-with-a-white-cross placeholder that had never been the product's logo, and `badge` pointed
at that same full-colour file. The manifest also never listed a maskable entry at all, and its
`theme_color` was `#2563eb` — a blue from no part of the brand.

**Icon assets (EHR).** The EHR ships `public/icon-192.png` and `public/icon-badge-96.png` only — it has
no manifest, so no install or maskable variants. Both are **byte-identical to the portal's**, and the
660x660 source is copied into the EHR as `public/narzim-mark.png` so its icons can be regenerated
without reaching into the other repository.

They were first generated from the EHR's own `public/narzim-logo.png`, which is a **rounded square**.
Side by side in macOS Notification Centre the two apps then showed different shapes for the same
product — reported from a real device. `narzim-logo.png` is still the in-app header logo and is
unchanged; only the notification icons were switched to the circular mark. The rule that follows:
**notification icons come from `narzim-mark.png` in both apps, and the two files should hash the
same.**

## 5. Client adapters

This is the only code written twice — roughly 40–60 lines each.

| Job | Browser (Next.js portal) | React Native |
|---|---|---|
| Ask permission | `Notification.requestPermission()` | `messaging().requestPermission()` (iOS); `POST_NOTIFICATIONS` (Android 13+) |
| Get a token | Firebase JS SDK + `firebase-messaging-sw.js` | `@react-native-firebase/messaging` |
| Register it | `POST` to `register_device_token` | identical endpoint, identical body |
| Receive, app open | `onMessage` | `onMessage` |
| Receive, app closed | service worker `push` event | OS displays it; `setBackgroundMessageHandler` |
| Handle a tap | `notificationclick` in the service worker | `onNotificationOpenedApp` / `getInitialNotification` |

**The portal is already most of the way there.** `src/app/manifest.ts` declares a standalone PWA,
`pwa-controls.tsx:18` registers `/sw-custom.js`, there is an install prompt, and `sw-custom.js:62`
already handles `notificationclick`. Two gaps:

1. **No `push` listener** in `sw-custom.js` — without it an FCM web message is silently dropped.
2. **`sw-custom.js:62-67` hardcodes `openWindow("/")`**, discarding the deep link. The backend already
   produces a relative path (`chat.py:452`), so every notification currently dumps the user on the
   home screen instead of the conversation.

**iOS Safari caveat.** Web push on iOS (16.4+) requires the site to be installed to the home screen;
it does not work in a normal Safari tab. This is an Apple constraint, not a Firebase one, and it
applies to standard Web Push equally. Practical consequence: **browser push on iOS is best-effort,
and the React Native app is what makes iOS reliable.** Do not let the roadmap assume otherwise.

**EHR scope — shipped 2026-09-25.** The EHR now has its own push worker, `public/sw-push.js`, and
`src/lib/push.ts`. It needed **no backend change**: `_APPS` already accepted `"EHR"` and every staff
event was already routed there, so the only thing missing was a receiver.

Three deliberate differences from the portal's copy, each of which would be a bug if copied blindly:

| | Portal | EHR |
|---|---|---|
| Worker | `sw-custom.js`, which also owns an **offline shell cache** | `sw-push.js`, push only. An offline EHR would serve a **stale patient chart**, which is worse than an honest network error |
| Registration | Already registered for the offline shell; FCM is pointed at it via `getToken({serviceWorkerRegistration})` | Registered **on demand** from `lib/push.ts`. `navigator.serviceWorker.ready` never resolves until something registers, so the portal's `ready` call would hang here forever |
| `app` value | `"Portal"` | `"EHR"` — this is what stops a staff browser ever receiving patient-app notifications |

The banner is suppressed whenever any EHR window is visible, exactly as in the portal. That matters
more here: staff keep the app open all day, so without it every SSE update would be doubled by an OS
banner.

## 6. End-to-end walkthrough

**Patient → staff.** A mother sends "mi hijo tiene fiebre de 39°" from the portal at 21:04:03.

| Time | What happens | Where |
|---|---|---|
| 21:04:03 | `POST` reply → message row written | `api/v1/patient_portal/chat.py` |
| 21:04:03 | `notify(recipients=<staff>, event_type="portal_chat_message", ref="PC-0001", …)` | `services/notifications.py` |
| 21:04:03 | Unread row for this conversation exists? Update it and refresh `creation`. Else insert. | `Notification Log` |
| 21:04:03 | SSE publish on `remedisys:user:<id>`, **after DB commit** | `services/notifications.py` |
| 21:04:04 | Front-desk tab, open: bell goes to 1, list prepends the row. **~1 s, no poll.** | EHR |
| 21:04:04 | Push enqueued for users with no live SSE connection | RQ worker |
| 21:04:05 | Doctor at home, every EHR tab closed: **desktop banner**, if they enabled notifications on that machine | EHR |
| 21:12 | Front desk replies. Same path in reverse. | |
| 21:12:01 | Mother's phone is locked. Lock screen shows **"Nuevo mensaje de tu clínica"** — no name, no content. | FCM → APNs |
| 21:12:20 | She unlocks, taps, app opens the conversation via `data.link`, fetches the text over JWT | RN app |

**What a bystander at her dinner table learned:** that she has a clinic app. Not her child's
temperature, not that she contacted a doctor. That second clause is the entire reason for §4.4's
payload rule.

**After-commit ordering matters.** The SSE publish and the push enqueue both fire *after* the DB
transaction commits — the same discipline `publish_to_encounter` already applies with
`after_commit=True`. Emitting before commit means a rolled-back write can still ring a phone, and the
client then fetches a document that does not exist.

## 7. Failure modes

Constitution Rule 7: infrastructure failure must never break healthcare. Each layer degrades
independently, which is the point of persisting before delivering.

| What breaks | Effect | Clinical impact |
|---|---|---|
| SSE route down | No live updates. Bell still correct on page load/navigation. | None |
| Frappe SocketIO down | Same as above. | None |
| FCM credentials revoked / Google outage | No out-of-app push. In-app unaffected. Send failures logged with **ids only**, per Rule 10. | None — but staff/patients lose out-of-app alerting silently, so this needs a monitor |
| RQ worker backlog | Push and fan-out delayed. `Notification Log` write is synchronous in the request, so the bell is still correct. | None |
| Device token stale/invalid | FCM returns `UNREGISTERED`; the row is marked `active = 0` and never retried. | None |
| `notify()` itself raises | Must **never** propagate to the caller. Wrapped in try/except with `frappe.log_error`, exactly as `_notify_staff_of_patient_message` does today — a notification failure must not fail a patient's send. | None |

The one failure with no automatic mitigation is a **silent** FCM outage: nothing user-visible
happens, so it needs alerting on the send-failure rate rather than a UI state.

## 8. Security and compliance

- **Rule 10 — no PHI in logs, and now no PHI in payloads.** §4.4's contract is the binding form. The
  test named in the ADR's Verification section enforces it in code rather than prose.
- **Google/FCM becomes a sub-processor.** It requires the same data-processing-terms check against the
  active `ComplianceProfile` (`mx` = LFPDPPP + NOM-024-SSA3-2012; `in` = DPDPA 2023 + ABDM) that
  [`adr/adr-026-llm-provider-allowlist.md`](adr/adr-026-llm-provider-allowlist.md) requires of an LLM
  vendor. **Not started** — this gates the first production send, not the code.
- **FCM only.** Firebase Auth, Firestore, Realtime Database and Cloud Functions are rejected:
  `eb_frappe_jwt` stays the only identity provider and MariaDB the only source of truth. No clinical
  data may enter a Firebase product.
- **Secrets.** Firebase service-account credentials and the APNs auth key live in environment
  variables only, never in the repo (`../CLAUDE.md` §9). Rotate quarterly minimum.
- **Token ownership.** A `Push Device Token` row is readable and deletable only by its own user.
  Logout must unregister the device — otherwise the next person to use a shared clinic tablet receives
  the previous user's notifications. This is a real risk on shared front-desk hardware, and it is why
  `app` and `user` are both on the row.
- **CSP is a precondition for EHR browser push.** Neither frontend sets a `Content-Security-Policy`
  today. Loading a Google SDK onto pages that render patient charts without one is not acceptable. The
  portal-only scope avoids the issue for now; the missing CSP is a pre-existing defect worth its own
  ticket regardless.

## 9. Build order

The sequence is chosen so each step is independently useful and the last one is nearly free.

| Step | Work | Status |
|---|---|---|
| 1 | `notify()` + migrate the three fan-out sites onto it. Fixed the unwrapped English string and the dead `User.company` filter found on the way. | **Done** — 18 checks passing |
| 1b | Route inbound **WhatsApp** messages through `notify()` (§4.5), and delete its 2 polling intervals in the same change. | **Done** — 14 checks + verified end to end (row written, event delivered) |
| 2a | Backend realtime: `publish_to_user()`, emit from `_fanout`, and the staff→patient path that did not exist. | **Done** — 17 checks passing |
| 2b | One SSE route handler + one hook per frontend; `socket.io-client@4.8.3` added to both. | **Done** — both verified end to end, authenticated, through their real dev servers |
| 2c | Delete the polling the SSE stream replaces: **4** notification intervals + **2** portal-chat + **2** team-chat in the EHR, **3** chat intervals in the portal. Team chat needed a backend event first (`team_message` → `_notify_thread_members`), so it was built rather than merely deleted. | **Done** — 11 intervals gone. WhatsApp's 2 remain: its backend emits nothing yet (§4.5) |
| 2d | Patient-facing notification feed: `api/v1/patient_portal/notifications.py` (list · count · mark-read · mark-all-read, all session-scoped), a BFF route, hooks, a **bell in the portal header** and the `/notifications` page. 13 bilingual keys with parity asserted. | **Done** — cross-patient isolation verified (404, leaking nothing) |
| 3a | **Backend push:** `Push Device Token` doctype (migrated), `services/push.py` (payload builder · FCM v1 send · token pruning · per-event app routing), `api/v1/push/api.py` (register / unregister), `google-auth` declared in `pyproject.toml`, and push enqueued from the `notify()` chokepoint so no call site changed. | **Done** — 60 checks passing |
| 3b | **Portal push:** `push` listener added to the portal's EXISTING `sw-custom.js` (no second service worker), `lib/push.ts`, `/api/push` BFF route, registration on login, **unregister on logout**, an opt-in card on the notifications page, and the `notificationclick` deep-link fix. | **Done** — 8 checks against Google's real API |
| 3c | **EHR push:** worker, `lib/push.ts`, `/api/push`, opt-in card, unregister-on-logout. The CSP precondition was already met — the EHR has had a policy since 2026-09-02; it needed two Firebase origins added to `connect-src`, not a policy written. | **Done 2026-09-25** |
| 4 | React Native adapter. | Deferred — no mobile app yet |

**The test that tells you the layering is right:** step 4 must require **zero backend changes**. If
mobile needs backend work, decisions 1 and 6 of the ADR have been violated.

Do not leave a poll running beside a live push channel "just in case" — that doubles the load the
change exists to remove. Delete the interval in the same PR that lands its channel.

## 10. Testing

| Test | Asserts |
|---|---|
| Payload builder unit test | Never emits a patient name, message content, or any key outside the §4.4 allow-list. **The most important test in this change.** |
| Fan-out integration test | Repeated patient messages produce exactly **one** `Notification Log` row per recipient; `creation` refreshes; marking read on one client clears it everywhere |
| Preference test | `is_notifications_enabled(user) == False` produces no row and no push |
| Rule 7 test | FCM credentials revoked **and** SSE returning 500: both apps load, bell renders from `Notification Log`, no clinical action blocked |
| Token lifecycle test | `UNREGISTERED` from FCM sets `active = 0`; logout unregisters; a pruned token is never retried |
| Auth test | A user cannot subscribe to another user's SSE channel |
| i18n test | Every push title resolves in both `es-MX` and `en-US` |

## Open items

1. **The Firebase project is outside company governance — must be resolved before production.**
   The original project `remedisys-notifications` sat under the Google Cloud organisation
   `socialangel.org`, which enforces `constraints/iam.disableServiceAccountKeyCreation`. That policy
   blocks *downloadable* service-account keys for every account in the project, so
   *"Generate new private key"* could never succeed. The policy exists for a good reason: a downloaded
   key never expires, and a leaked one grants send rights indefinitely — a real risk on a clinical
   system.

   Rather than wait for an exception, the project was recreated **outside the organisation** as
   `remedisys-notifications-8cb48` (2026-08-25), where no org policy applies and key creation works.
   That unblocks development, and it is the right call for moving now — but it leaves a real gap:
   **the credential path for a clinical system is not currently governed by the company's cloud
   organisation.** Under `adr-018-multi-jurisdiction-compliance` that is not an acceptable production
   posture, and it must be closed before the first production send, not after.

   Three ways to close it, in preference order:

   1. **Migrate the project into the organisation and get a project-scoped policy exception** from an
      Organization Policy Administrator (`roles/orgpolicy.policyAdmin`), leaving the org-wide policy
      enforced. Cleanest end state: company-owned project, one narrowly-scoped exception.
   2. **Workload Identity Federation** — no static key at all, which is what the org policy is
      steering toward and the correct long-term answer. Blocked today because the backend runs on
      Frappe Cloud rather than GCP, so there is nothing to federate from.
   3. **Service-account impersonation** with short-lived tokens. No static key, but it needs `gcloud`,
      the Token Creator role and a human login, so it cannot serve a background worker — development
      only.

   **Also required whenever a static key exists:** `CLAUDE.md` §9 mandates quarterly rotation minimum.
   Put it on a calendar; a key nobody rotates is the exact failure the org policy was guarding
   against.

2. **SSE on Vercel — one of three questions answered.**
   - **Duration: RESOLVED (2026-08-24).** Default `maxDuration` is **300 s**; neither frontend sets it
     or ships a `vercel.json`, so both run on the default. A 5-minute reconnect cycle is fine given
     native SSE reconnection plus `Last-Event-ID` replay from `Notification Log`. Pro + Fluid Compute
     raises the ceiling to 800 s, but see the next point for why that is not the interesting number.
   - **Fluid Compute: RESOLVED (2026-08-25).** Enabled on the Vercel Pro project. This was the item
     with real money attached — without it, one instance per connection turns 4,800 function-hours into
     4,800 *instance*-hours. With it, mostly-idle SSE connections share instances. It also removes the
     cost argument that could have moved this design off SSE onto a managed gateway.
   - **Streaming vs buffering: still UNVERIFIED, though the risk is now low.** `maxDuration` says when
     a function is killed; it says nothing about whether the response streams incrementally or is
     buffered and flushed at the end. Buffering would mean SSE **cannot work at all** — a different and
     worse failure than a periodic reconnect, and a silent one. Two things make it unlikely: Vercel's
     Node runtime supports streaming responses, and streaming is Fluid Compute's headline use case
     (it exists largely for long-running AI streaming), so a project with it enabled buffering an
     `event-stream` would be surprising. Still worth ten minutes on a preview deploy, because the
     failure is silent and the remedy would be a different architecture rather than a fix.

   Note there is **no working SSE precedent in the stack**: `useAnalyzeStream.ts` has no callers, the
   route it fetches does not exist, and production logs show zero requests to that path in 24 h. It is
   dead code, not evidence.
3. **Google/FCM data-terms check against both ComplianceProfiles — not started.** Gates the first
   production send. Documentation work, not code.
4. **~~EHR out-of-app push — explicitly skipped~~ — SHIPPED 2026-09-25.** The evening-cover gap this
   entry described is closed: a staff member who has enabled notifications on a machine now gets a
   desktop banner with every EHR tab shut.

   **What the estimate got wrong, recorded because it was the reason this sat deferred.** The entry
   said the CSP was a precondition and cited `KNOWN_ISSUES.md`. By the time the work was done the EHR
   had had a Content-Security-Policy for three weeks (`src/lib/security/csp.ts`, since 2026-09-02,
   with `worker-src 'self' blob:` already in place). The actual change was **two origins added to
   `connect-src`** — `fcmregistrations.googleapis.com` and `firebaseinstallations.googleapis.com` —
   plus updating the test that asserts no third-party origin creeps in. The precondition had been
   quietly satisfied by other work and nobody re-checked, so a one-line change read as a blocker.

   **Still open, and now the real constraint:** the policy is
   `Content-Security-Policy-Report-Only` in both apps. Push works either way, but the protection this
   was gated on is not actually being enforced yet. See [§8](#8-security-and-compliance).

   **Not solved by this:** iOS Safari still needs the site installed to the home screen, and macOS
   Chrome shows Chrome's own icon on the banner rather than Narzim's unless the app is installed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.16 | 2026-09-25 | Ashutosh (AI-assisted) | Staff banners now name the patient, resolved by the service worker from our own BFF so the FCM payload stays content-free (ADR-093) |
| 2.15 | 2026-09-25 | Ashutosh (AI-assisted) | EHR notification icons switched from the rounded-square `narzim-logo.png` to the circular mark, so both apps show the same shape; they are now byte-identical |
| 2.14 | 2026-09-25 | Ashutosh (AI-assisted) | **EHR out-of-app push shipped** (step 3c), so the "classified but no receiver" state is gone. Records the three ways the EHR worker differs from the portal's, and that the CSP precondition had already been met three weeks earlier |
| 2.13 | 2026-09-25 | Ashutosh (AI-assisted) | Push icon assets documented (all four derived from `src/app/icon.png`; badge must be an alpha stencil). Push titles/bodies translated to `es`, and the `.po` vs compiled `.mo` trap recorded — `_()` never reads the `.po` |
| 2.12 | 2026-09-25 | Ashutosh (AI-assisted) | 22 events. Inbound patient messages go to the triage desk only, not 39 staff; `portal_chat_assigned` added; the six-unpushed warning resolved |
| 2.11 | 2026-09-24 | Ashutosh (AI-assisted) | §4.5 rebuilt from the code: the vocabulary was documented as 5 keys and is 16; the producer table omitted every staff-facing path and cited a function that no longer exists. Records two declared-but-unraised events, and that 6 of 16 are absent from `_APP_FOR_EVENT` and so are never pushed |
| 2.10 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 2.9 | 2026-08-26 | Ashutosh (AI-assisted) | §4.7: next-intl does not throw on a missing message, so both try/catch guards were inert — key existence now checked via useMessages(); title and body checked independently |
| 2.8 | 2026-08-26 | Ashutosh (AI-assisted) | Corrected §4.6: the hook does NOT cover all ten write points — db.set_value bypasses the lifecycle, so cancellation needs an explicit call. The design is a hybrid |
| 2.7 | 2026-08-26 | Ashutosh (AI-assisted) | Portal frontend: client-side rendering of event keys in the reader's locale, channel tabs with server-validated filtering |
| 2.6 | 2026-08-26 | Ashutosh (AI-assisted) | Appointment lifecycle notifications: §4.5 gains four events, new §4.6 (the ten write points and the transition guard, with the two silent bugs found) and §4.7 (event keys instead of pre-rendered sentences, per adr-046) |
| 2.5 | 2026-08-25 | Ashutosh (AI-assisted) | WhatsApp filter tab added to the notifications screen with its own count; the §4.5 follow-up closed |
| 2.4 | 2026-08-25 | Ashutosh (AI-assisted) | Fluid Compute confirmed enabled — the concurrency-cost open item is resolved, and the buffering risk downgraded with it |
| 2.3 | 2026-08-25 | Ashutosh (AI-assisted) | EHR out-of-app push explicitly skipped, with the cost and the remaining scope written down so it is a decision rather than a gap |
| 2.2 | 2026-08-25 | Ashutosh (AI-assisted) | Step 3b: portal push live end to end; new §4.6 records the one-service-worker strategy, banner suppression, permission timing and logout teardown; EHR push deferred with the CSP |
| 2.1 | 2026-08-25 | Ashutosh (AI-assisted) | Step 3a: backend push built — doctype, send path, payload contract, registration endpoints, wired into the chokepoint; documented why push is unconditional and why enabling it needs two gates |
| 2.0 | 2026-08-25 | Ashutosh (AI-assisted) | WhatsApp notifications go to every staff member; the assignment-routed variant was withdrawn on request, and the trade-off recorded rather than dropped |
| 1.9 | 2026-08-25 | Ashutosh (AI-assisted) | WhatsApp inbound now notifies (assignment decides recipients, per the rule the code already stated); its 2 intervals removed, so nothing polls any more; corrected the wa- query keys my earlier invalidation map got wrong |
| 1.8 | 2026-08-25 | Ashutosh (AI-assisted) | Patients now get Notification Log rows — §4.3's realtime-only asymmetry reversed, with the reason; portal bell + /notifications feed recorded; team_message channel documented; the description/email_content mirroring trap written up |
| 1.7 | 2026-08-25 | Ashutosh (AI-assisted) | Step 2b done: SSE live in both apps, 7 polling intervals deleted; §4.3 records the Origin-header trap that makes the handshake hang silently |
| 1.6 | 2026-08-25 | Ashutosh (AI-assisted) | Firebase project recreated outside the org as `remedisys-notifications-8cb48` to unblock key creation; Open item 1 reframed from "key blocked" to "project outside company governance, close before production" |
| 1.5 | 2026-08-24 | Ashutosh (AI-assisted) | §4.5 added: every channel that raises notifications, and the verified gap that inbound WhatsApp messages notify nobody; §1 scope clarified (WhatsApp as a delivery channel is out, notifying staff about WhatsApp is in); build order gains step 1b |
| 1.4 | 2026-08-24 | Ashutosh (AI-assisted) | §3 why two transports (three user states, and why FCM alone conflates two consents); §4.3 corrected to what was actually built — Frappe's built-in per-user room, real payload shape, no authorize endpoint; §4.4 records the provisioned Firebase project and the env contract; §9 marked done/next/blocked; org-policy blocker added |
| 1.3 | 2026-08-24 | Ashutosh (AI-assisted) | Vercel duration resolved (300 s); concurrency/Fluid-Compute recorded as the real constraint; no SSE precedent exists (useAnalyzeStream.ts is dead code) |
| 1.2 | 2026-08-24 | Ashutosh (AI-assisted) | Step 1 built; §4.1 corrected to all three call sites, two of which carried live defects |
| 1.1 | 2026-08-24 | Ashutosh (AI-assisted) | §4.4: why the push must be visible, not silent — app-state table and the iOS force-quit constraint |
| 1.0 | 2026-08-24 | Ashutosh (AI-assisted) | Initial version — design agreed, not yet implemented |
