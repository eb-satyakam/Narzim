# Known Issues / Paused Work

**Doc status:** living · **Created:** 2026-07-20 by Sarvesh-SocialAngel · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 3.12

Tracks known bugs and partially-scoped work that isn't currently being
worked on, so nobody re-discovers or duplicates the investigation from
scratch. Remove an entry once it's fixed (the fix commit is the record).

---
## A checkout invoice that bills more than the appointment, and is not fully paid or part waived, still settles the old way

**Status:** Open, waiting on the accountant (ADR-117 design note §4.4, Q2). Found 2026-10-01.

ADR-117 replaces an appointment's line when its invoice still has a balance, but only when that
line is the whole invoice. On a checkout invoice that also bills a vaccine, a medicine or another
appointment, whose part of the payment is unpaid has not been decided, so it is left as before:

- **A dearer reschedule** raises a top-up invoice while the old invoice keeps its unpaid share.
  The patient is billed that share twice (as `HLC-APP-2026-00820` was).
- **A cancel** is shown as "partly paid" in the Refund dialog and refunds nothing.
- **A part-waived invoice:** visit 750 paid in cash and a vaccine 500 waived, moved to a 300
  doctor. It refunds 150, not 450. Cash is spread across lines in proportion
  (`appointment_invoice_share`), so the visit counts 450 as paid. This fails
  `test_cheaper_reschedule_on_a_part_waived_invoice_never_refunds_more_than_was_paid`, on `dev` as well.

**Fix, once the accountant chooses** "proportional" or "this appointment first": extend
`_replace_appointment_lines` and `_balance_refund_plan` to shared invoices with that rule.

## Eight rescheduled appointments cannot refund what is left if cancelled

**Status:** Open, waiting on the accountant (design note Q4). Found 2026-09-30.

Before ADR-114, a cheaper reschedule refunded the fee difference by returning the invoice line in
full quantity at a lower price, which used the line up. On the 8 invoices that carry such a
"Reschedule refund" Credit Note (for example ACC-SINV-2026-00760: 1,000 paid, −420 by
ACC-SINV-2026-00840), the fee the patient kept (580) has no line left to return, so if that
appointment is cancelled no Credit Note can refund it. None of the 8 appointments is cancelled
today. New reschedules no longer do this. The billing list shows these rows as
"Partial · fee adjusted" with a disabled Refund button.

**Fix, once approved:** a "refund remaining" action by Journal Entry plus Payment Entry, only for
these rows — [design note §6](flows/RESCHEDULE_CANCEL_REFUND_LINES.md).

## Nine billing and reschedule tests fail before any assertion

**Status:** Open. Found 2026-09-30; each fails identically on the code before ADR-114/115.

- `tests/appointments/test_reschedule_payment.py`: `test_preview_matches_what_the_settlement_actually_does`
  and `test_preview_labels_both_tax_bases` read `frappe.response["http_status_code"]` / `["data"]`
  after `preview_reschedule_payment`, and the key is absent (`KeyError`).
- `tests/billing/test_pos.py` (3 tests): `Could not find Patient: _POS Test Patient` — the fixture
  patient is not created on this site.
- `tests/billing/test_dashboard_payment_summary.py` (4 tests): `TypeError: cannot unpack
  non-iterable NoneType` in ERPNext `_get_item_tax_template` — an Item Group on this site carries a
  tax row pointing at a missing Item Tax Template.

Not investigated beyond that.

## 47 past refunds left the bank account with no payment mode

**Status:** Open, for the accountant. Found 2026-09-30; new refunds are fixed (WORK_LOG 2026-09-30).

Before the fix, a refund made from the Refund dialog — and the 1,000 refund PAY-2026-01128 of a
reschedule's replacement invoice — was a Payment Entry with no Mode of Payment, posting to
BANCO X MXN, whatever the original tender was. On the dev site 47 submitted "Pay" entries are
mode-less and out of BANCO X (9 went out of CAJA PRINCIPAL by Cash, 3 by Bank Draft). For any that
repaid cash, the till is over and the bank under by that amount; the Payment Methods report lists
them under no method. Example: PAY-2026-00827 (13,804) refunded invoice ACC-SINV-2026-01116, whose
cash was taken by PAY-2026-00825.

Not corrected in place: a posted Payment Entry should not be edited. One journal entry per affected
entry (bank to cash) puts the balances right; the list comes from
`Payment Entry` where `payment_type = "Pay"`, `mode_of_payment` is empty, matched to the original
invoice's receipt.

## `ignore_permissions` is still used in ~96 files outside billing

**Status:** Open. Billing is bypass-free since ADR-115 (2026-09-30); the rest is not yet.

Largest users: `api/ai/lab_result_summary.py`, `services/drive.py`,
`integrations/whatsapp/webhook.py`, `services/providers.py`, `api/v1/nursing/api.py`, seed scripts.
In `api/v1/appointments/api.py` the booking insert (`_create_impl`) and the booking consent record
(`_record_booking_consent`) remain. Many run with no logged-in user (webhooks, scheduler, seeds), so
they need a system-context decision per module, not role grants.

---
## Reports v3 AI findings: rebuilt except the prompt, the flag and the tests

**Status:** Partly rebuilt 2026-09-30. The two Python sources are back; the feature still cannot be
switched on, and returns no findings if it were. Nothing else on the Reports screens is affected.

**What is back.** Rewritten against [ADR-095 (reports v3)](adr/adr-095-reports-v3-ai-insights.md),
not restored — no copy of the originals survived, so the comments are new reasoning, not the
original author's.

| Path | What it holds |
|---|---|
| `remedisys_healthcare_ai/api/v1/reports/api.py` | `get_report_insights`, `get_pinned_reports`, `set_pinned_reports` — see [`api/endpoints/reports.md`](api/endpoints/reports.md) |
| `remedisys_healthcare_ai/services/report_insights.py` | the digest builder, the grounding validator and the LLM call |

Pins are stored in `DefaultValue` via `frappe.defaults`, so there is no `Report Pin` doctype, no
migration patch and nothing to uninstall. No `__init__.py` is needed: no module under
`api/v1/` has one.

**What is still missing**, and what each costs:

| Path | Effect while absent |
|---|---|
| `prompts/report-insights-v1.txt` | `_call_llm` cannot load the prompt, logs a failed `AI Prompt Log` row and returns `None` — the endpoint answers with no findings rather than raising (BE-7) |
| `AI Settings.enable_report_insights` (field + patch) | `is_enabled()` reads a field that does not exist, so it is always false (`report_insights.py:88`). The feature cannot be turned on at all |
| `remedisys_healthcare_ai/tests/reports/test_report_insights.py` | the grounding validator — the deterministic check the feature's safety case rests on — has no test |

**Ask Orin is not coming back.** The third endpoint ADR-095 describes was removed on 2026-09-29 by
explicit instruction and stays removed; `api/v1/reports/api.py` records that.

**How it was lost** (kept, because the lesson is the point). The files were written 2026-09-29 and
were gone the same evening: untracked sources deleted, `.gitignore`d `__pycache__` intact, tracked
modifications untouched — the signature of a `git clean -fd`. Nothing was recoverable from git;
only bytecode survived.

**What this means on screen.** `useReportInsights` sets `retry: false` and `ReportFindings` returns
`null` unless the payload says `enabled`, so an empty findings payload degrades to no panel. Every
figure, chart, table, funnel and export on all 17 reports is unaffected.

**ADR-095 is now a duplicate number, and the gate fails because of it.** The parked ADR reached
`dev` in commit `7997cc92`, where `adr-095-encounter-canvas-storage-format.md` already held 095.
`scripts/check_adr_numbering.py` therefore fails on `dev` itself with two groups — a new duplicate
095, and `adr-095-reports-v3-ai-insights.md` missing from `adr/README.md`. ADR-042 freezes numbers,
so this is resolved by superseding with a free number, never by renumbering. Not done here: it
predates this work and blocks every branch cut from `dev`.

**Next step:** write `prompts/report-insights-v1.txt` and add the `enable_report_insights` field
with its patch, or drop the feature and delete the frontend half. Anant's call — still not made.

---
## Inbound WhatsApp depends on a hand-started ngrok tunnel that nothing monitors

**Status:** Working again 2026-09-28, but fragile by construction. Not a code defect — an
environmental dependency with no alert on it.

**Where:** the Meta app's subscription, readable with the app secret:
`GET /1095875596728624/subscriptions`

```
callback_url: https://observant-flier-shorts.ngrok-free.dev/api/method/...whatsapp.webhook.webhook
active      : true
fields      : messages, message_template_status_update
```

**What happened:** that tunnel was down. Meta POSTed every inbound patient message and every delivery
status to a 404, so **patient replies were silently discarded** and every outbound row stayed at
`Sent`. Measured before the fix: 0 inbound messages in 6 hours against 23 outbound.

**Resolved by** restarting the tunnel on the same reserved domain, so the URL already registered with
Meta became live again — no re-subscription needed:

```
ngrok http 8000 --host-header=mysite.localhost
```

`--host-header` is **required**. Frappe resolves the site from the `Host` header, and without the
rewrite every request returns *"observant-flier-shorts.ngrok-free.dev does not exist"*. Verified end
to end: the GET handshake echoes `hub.challenge`, and a signed POST through the public URL created the
inbound row and fired `auto_reply_reschedule_v3` one second later.

**Why it stays listed:** inbound WhatsApp silently stops the moment that laptop tunnel drops, with no
error anywhere and no alert. The same stale URL also sat in `whatsapp_header_image_url` and silently
dropped every branded outbound template for days before anyone noticed (that half now points at
`https://mycare.narzim.com/narzim-logo.png`).

**Next step:** in production set `callback_url` to the deployed backend domain **once**, and add a
reachability probe on both URLs so a dead endpoint fails loudly instead of silently. See
[`WHATSAPP_INTEGRATION.md`](WHATSAPP_INTEGRATION.md) §17.

---
## Every Lab Test save queues two AI summary jobs, even when nothing relevant changed

**Status:** Not being worked on. Found 2026-09-24 during the lab gap review; verified in code.

**Files:** `hooks.py:277-285` (Lab Test `on_update` and `on_submit` → `patient_clinical_summary.on_patient_activity`
and `lab_result_summary.on_lab_report_activity`); `services/patient_clinical_summary.py:1904`
(`mark_stale_and_enqueue`, job `clinical_summary::<patient>`); `services/lab_result_summary.py:1415, 1623`
(job `patient_lab_summary::<patient>`). Both on the `long` queue, deduplicated per patient, after commit.

**Gap:** every save and every submit of a Lab Test queues both jobs, and each job that runs makes an
LLM call. No check skips the call when the patient's lab data is unchanged (none found by grep). One
AI-reviewed result is created, has its values saved, and is submitted — three triggers; dedup
collapses them only when they arrive while a job is still queued. A Draft saved with no values
still triggers both. On a single worker the jobs share the `long` queue with lab uploads.

**Evidence:** on `remedisis.localhost`, 2026-09-20 to 09-24: 213 Patient Lab Summary calls (avg 8 s) and
31 Patient Clinical Summary calls (avg 19 s). On 2026-09-24, ~125 such calls in 18 minutes (from test
runs) delayed a real upload to 252 s.

**What it would take:** any of — skip the LLM call when a fingerprint of the patient's lab inputs is
unchanged; trigger on submit rather than on every Draft save; generate on demand when the chart is
opened; and a separate queue for uploads (planned in ADR-092 §4).

---
## Saved analyte aliases are never used in matching

**Status:** Not being worked on. Found 2026-09-24; verified by grep.

**Files:** `api/ai/lab_panel_extraction.py:755-787` (`map_unmapped_as_alias` writes
`Lab Analyte Alias`); nothing else reads that doctype. `services/lab_catalog.py` builds the catalog
without it, and the labels sent to the model are name + context only
(`services/lab_panel_extraction.py:1140`).

**Gap:** mapping "Hb" to "Haemoglobin" is stored and has no effect: the next upload still leaves "Hb"
unmatched. The frontend hook for it (`useMapUnmappedAsAlias`) is also never called, so today nobody
can reach the dead path — but the endpoint and doctype suggest a feature that does not work.

**What it would take:** read aliases into the catalog labels (or the post-match name fallback), or
remove the endpoint and doctype.

---
## The uploader's note is never shown in the AI upload flow

**Status:** Not being worked on. Found 2026-09-24; verified in code, not confirmed in the running app.

**Files (frontend):** `src/components/narzim/patient-chart/lab-order-dialog.tsx:2741-2755` — the note
box renders only on the standalone upload step with `panelMode` on; the AI upload continues from
Step 1 straight to Step 3 (`:2100-2107`, whose own comment says "we never route to the standalone
upload step").

**Gap:** ADR-080's uploader note reaches both extraction stages when sent, but the box to type it is
not on the path clinicians use, so `upload_note` is almost always empty.

**What it would take:** move the note to Step 1 — or into the template-review step planned in ADR-092.

---
## "Lab Test Template" is declared twice in `hooks.py`, so one hook never runs

**Status:** Not being worked on. Found 2026-09-24; verified with an `ast` check.

**Files:** `hooks.py:211` (clinical-lexicon cache invalidation on update/trash) and `hooks.py:339`
(`lab_template_sync.sync_lab_parameters`). Python keeps the second key of a dict literal.

**Gap:** the clinical-vocabulary cache is not cleared when a Lab Test Template is edited or deleted,
so the vocabulary the AI sees can lag behind the catalog until the cache expires or is cleared.

**What it would take:** merge the two entries into one `"Lab Test Template"` dict with `on_update` as
a list of both handlers and `on_trash` kept.

---
## Both compliance profiles promise a right to erasure, and no erasure path exists

**Status:** Not being worked on. Found 2026-09-18 while building `AI Source Cache` (ADR-079), which
needed something to hook into and found nothing.

**Files:** `compliance/profiles/mx.py:16` and `compliance/profiles/india.py:16` (`right_to_erasure=True`);
`remedisys_healthcare_ai/doctype/ai_source_cache/ai_source_cache.py::purge_for_patient` (a handle
with no caller).

**Gap:** Both markets declare `right_to_erasure=True` — LFPDPPP Art. 16 "Cancelación" in Mexico,
DPDPA 2023 S.12 in India. Grepped across the app on 2026-09-18: **there is no function that erases a
patient.** No API method, no service, no scheduled job. The field is a declaration nothing
implements, in the same class as `audit_retention_years` and `ai_scribe_enabled`.

**Why it surfaced now:** PHI-4 says a design that copies patient data into a second store must add
that store to erasure *in the same change*, "or record explicitly that it did not and why". The
source cache is such a store — a clinician can paste a link to another clinical system's page about
a real patient. So `purge_for_patient(patient)` was written and tested and is ready. **Nothing calls
it, because there is nothing to call it from.**

**What this is NOT:** it is not a bug in the cache. The cache is the first store in this app that
arrived with its erasure handle already built. The gap is that the app-wide path those handles
should hang off has never been written.

**What it would take:** a `services/patient_erasure.py` that enumerates every store holding
patient-linked data (Patient and its ERPNext children, Narzim threads with `context_patient`, AI
session/transcript/SOAP rows, the source cache, Drive documents) and a decision per store between
delete, anonymise and retain-for-legal-obligation — which is where `audit_retention_years` and the
right to erasure genuinely conflict and a human has to choose. That conflict is the reason this is
not a small task.

---
## Queue Stage Log rows never get closed if a visit is abandoned mid-queue

**Status:** Not being worked on — first flagged as a "deeper root cause" in ADR-064 v1.9
(2026-09-10), recurred and re-confirmed live 2026-09-12 while investigating an unrelated Nurse
feature request.

**Files:** `services/queue_stage_log.py` (the only writer — no code path closes an abandoned row);
`docs/adr/adr-064-queue-tips-llm-summary.md` §3g (v1.9), §3l (v1.16).

**Gap:** A Queue Stage Log row opens (`entered_at` set) whenever an appointment moves into a room,
and is normally closed (`exited_at`/`duration_min` set) when it moves to the next one. If a visit is
abandoned instead of moved on — the patient leaves, the appointment gets cancelled some other way,
or the card is simply forgotten — **nothing ever closes that row.** It stays open indefinitely.

**Confirmed live twice, on two different dates:** v1.9 (2026-09-10) found `HLC-APP-2026-00326` and
`HLC-APP-2026-00378` open from the prior evening, corrupting a live-duration fact with an impossible
"1381 minutes overdue." Checking a Nurse-facing feature live on 2026-09-12 found the same pattern
again, worse: **22 Nursing Room rows still open from 2026-09-11**, one read as a 1655-minute
(27hr 39min) wait by a standalone check that didn't apply this app's own today-only date filter.

**Why this hasn't broken `regenerate_queue_tips` itself:** the v1.9 fix scopes `live` to today's
`appointment_date` before any fact runs, so every fact this function computes is already immune —
confirmed again during the 2026-09-12 investigation. The risk is anything that reads Queue Stage Log
open rows WITHOUT independently re-applying that same scope (as happened in the 2026-09-12
diagnostic script itself, which is exactly how the recurrence was caught).

**USER STORY.** A patient is moved into Nursing Room on 2026-09-11 and, for whatever reason, never
formally checked out or moved on before the clinic closed → **the database still contains** an open
Queue Stage Log row, `entered_at` yesterday evening, no `exited_at` → **the next day**, any new code
that queries "open Nursing Room rows" without an explicit today filter reports that patient as still
waiting, for over a day → **consequence:** a wrong, alarming number reaches whoever built that new
check, and there is no way to tell from the row alone whether it is a live problem or an old,
forgotten one.

**Fix when picked up:** an end-of-day sweep job (RQ, scheduled) that closes any row still open past
its own day, or an explicit "abandon"/"close out" action a user can trigger — either is new
mechanism, not a one-line fix, which is why it has been recorded rather than patched twice now.

---
## Narzim Drive "Restricted" does not restrict reading inside the team

**Status:** Not being worked on — found 2026-09-09 while wiring the Share dialog. Needs a decision,
not a patch.

**Files:** `drive/api/permissions.py::get_user_access` lines 72-81 (upstream);
`remedisys_healthcare_ai/services/drive.py::_context` (`_ensure_team_member`);
`docs/adr/adr-063-drive-access-list.md`.

**Gap:** Drive grants **every member of the Drive team `read: 1` on every file in that team**, with
no permission row involved. `_context()` adds any staff user who opens Narzim Drive to the team, so
over time every staff member can open every document in the drive. Sharing therefore controls the
explicit grant list and the **write** level — it does **not** gate reading among staff, and removing
someone from the list does not stop them opening the file.

Verified 2026-09-09 on `remedisys.localhost`: a file with **zero** `Drive Permission` rows returned
`read = True` for four separate team members (`anantdoctor@`, `anant@`, `adrian@`, plus
Administrator), `write = False` for all but the owner.

**USER STORY.** A nurse uploads a scanned court order about a safeguarding case into her own Narzim
Drive and leaves it **Private** → **the system shows** "Restricted", and the People-with-access list
names only her → **the database actually contains** a `Drive File` with no permission rows, which
Drive resolves as readable by all 19 staff accounts in the team → **consequence:** she believes the
document is hers alone; any colleague who opens Narzim Drive can read it.

**Mitigated for now:** the dialog no longer claims otherwise. "Only people with access can open with
the link" was replaced with "Not shared with anyone outside the clinic team", which is true, and the
"Anyone with the link — anyone on the internet can view" option was removed outright (the backend
always refused it; see `test_share_never_writes_a_public_permission_row`). The behaviour is pinned
by `test_a_team_member_can_read_without_any_grant`, which fails if the model changes.

**Fix when picked up:** four options, none free. (1) Accept and document — a staff drive is a shared
workspace; keep the honest wording. (2) Per-file owner-private default — write an explicit denial row
for the team on create, so Private really is private; costs a permission row per file and diverges
from Drive's model. (3) A Drive team per user, sharing across teams for collaboration; heaviest, and
`_ensure_team_member` would have to go. (4) Stop auto-adding users to the team in `_context()` — the
narrowest change, but it breaks Drive access for anyone not explicitly added. This is a permission-model
decision and needs an ADR.

---
## Narzim Drive folders exist only in the browser

**Status:** Not being worked on — found 2026-09-09 while scoping the Drive migration.

**Files:** `EB_Healthcare_EHR/src/components/narzim/inbox/clinical-documents-tab.tsx:2731`.

**Gap:** The redesigned Documents screen offers **New Folder**, but folders are held in React state
(`React.useState<DocFolder[]>([])`) — no API call, no `localStorage`, no persistence of any kind.
The backing doctype `Clinical Document` is flat: it has no `parent`, no `is_folder`, no tree, so
there is nothing to persist them to.

**USER STORY.** Dr. Bracamontes files eleven referral scans into a folder he names *"Referencias
pendientes"* → **the system shows** the folder with the documents inside it, working correctly for
the rest of the session → he refreshes the tab → **the database actually contains** no folder at
all, because none was ever created → **consequence:** the folder and the filing are gone, the
documents are back in one flat list, and no error was shown at any point. He concludes the system
lost his documents.

**Fix when picked up:** this is the main functional driver for
[the Drive migration](narzim-drive/DRIVE_MIGRATION_PLAN.md) — `Drive File.parent_entity` is a real
tree. If that migration is not taken, the alternative is a `parent` link plus `is_folder` on
`Clinical Document`, with visibility resolved at the root of a subtree rather than per node.

---
## Narzim Drive's share dialog says "Anyone with the link" when it is not

**Status:** Not being worked on — found 2026-09-09. Frontend-only; independent of the Drive migration.

**Files:** `EB_Healthcare_EHR/src/components/narzim/inbox/clinical-documents-tab.tsx:1375`.

**Gap:** The share dialog labels a `Shared` document **"Anyone with the link"** and offers a Copy
link button producing `${origin}/documents/${id}`. The backend does no such thing: a shared document
is readable only by an authenticated user holding one of the seven roles in `_STAFF_ROLES`
(`services/clinical_documents.py`), and everyone else gets a 404. This is a `CLAUDE.md` **PHI-5**
violation — stating in the UI something the code does not do.

**USER STORY.** A nurse shares a document, reads "Anyone with the link", copies it and sends it to a
parent on WhatsApp → **the system shows** nothing wrong → **the database actually contains** a
staff-only share → **consequence:** the parent gets a login wall or a 404, the nurse believes she
sent it successfully, and nobody finds out until the parent calls back.

**Fix when picked up:** reword through the `messages/en.json` + `messages/es.json` catalogs to
describe the real behaviour (shared with named colleagues / the whole team), and drop or re-scope
the Copy link affordance. Do not implement public links to match the label — see
[the migration plan](narzim-drive/DRIVE_MIGRATION_PLAN.md) §6.1.

---
## Patient invite and reset emails fall back to `localhost:3003`

**Status:** Not being worked on — found 2026-09-07 while moving the QR's portal URL to
`site_config.json`; deliberately not fixed in that change.

**Files:** `remedisys_healthcare_ai/api/v1/admin/_helpers.py` (`_portal_base_url`), called from
`api/v1/auth/api.py:222` and `_helpers.py:200,271`.

**Gap:** `_portal_base_url("patient")` returns `frappe.conf.get("patient_portal_url")` **or the
hardcoded `http://localhost:3003`**. On a site where that key is unset, a patient welcome or
password-reset email links the recipient to `http://localhost:3003/set-password?key=…` — a host that
exists only on a developer's laptop. The patient sees a dead link and cannot set a password; nothing
errors server-side, so no one is told.

**USER STORY.** Front desk registers a patient on a freshly provisioned production site → **the
system shows** "invite sent" → **the patient's inbox actually contains** a link to
`http://localhost:3003/set-password?key=abc` → **consequence:** the link fails on their phone, the
account is never activated, and the clinic concludes the portal is broken.

**Why not fixed in the QR change:** that change added `patient_portal_url_configured()`, which
returns `None` rather than a fallback, and the QR uses it. Altering how *email* links resolve changes
behaviour for every provisioning flow (`invite_staff`, `create_practitioner`, patient auto-invite),
which is a wider blast radius than a display-only page and wants its own change plus tests.

**Fix when picked up:** make `_portal_base_url` raise or skip sending when the key is unset on a
non-dev site, rather than silently producing a localhost link. The dev default is fine *as* a dev
default — the defect is that nothing distinguishes dev from production.

---
## Holiday/leave enforcement in assert_bookable is a silent no-op

**Status:** Not currently being worked on — found 2026-09-09 while scoping the read-only holiday-list
display (ADR-062 decision 9), recorded rather than fixed since it's a separate, larger change (booking
enforcement) than what was being built (a read-only view).

**Files:** `remedisys_healthcare_ai/services/availability.py::assert_bookable` (the guard);
`healthcare/healthcare/doctype/patient_appointment/patient_appointment.py::check_employee_wise_availability`
(the core function it calls, lines 778-788).

**Gap:** `assert_bookable`'s first check, per its own docstring, is "Holiday / approved leave — core's
`check_employee_wise_availability`." That core function resolves the practitioner's Employee via
`practitioner_doc.employee`, or failing that, an Employee whose `user_id` matches the practitioner's
`user_id`. **ADR-062's Alternative 4 already verified zero `Healthcare Practitioner` records in this app
carry an `employee` link** — so `employee` always resolves to `None`, and both the holiday check
(`is_holiday`) and the leave check are skipped silently. No exception, no log line, nothing — the function
returns as if the date were confirmed clear.

**User story:** the clinic's Holiday List marks 2026-12-25 as a holiday. A patient books Dr. Bracamontes for
10:00 AM that day through the normal booking screen. The system shows the booking succeeding — no error, no
warning, at any point — because `assert_bookable` called `check_employee_wise_availability`, which found no
Employee to check and returned without raising.

**Why this wasn't caught by the existing tests:** `tests/appointments/test_availability_enforcement.py`'s
"holiday mock" test (per `docs/PRACTITIONER_AVAILABILITY.md` file #7) mocks `check_employee_wise_availability`
directly to force it to raise — which proves `assert_bookable`'s `try/except` wiring correctly re-raises as
its own message, but never exercises the real Employee-resolution code path against this app's actual data.
No test with real data has ever shown a holiday actually blocking a booking, because it doesn't.

**Next step:** needs a product decision, not just a code fix — either (a) start populating
`Healthcare Practitioner.employee` (own scope: who creates these Employee records, and when), or (b) replace
`check_employee_wise_availability` with a Company-resolved check mirroring `get_practitioner_holidays`'s own
resolution path (`custom_company` -> `Company.default_holiday_list`), so the guard uses the same source of
truth the new read-only display already reads from `services/providers.py::get_practitioner_holidays`. Not
attempted here — read-only display and write-time enforcement are different changes with different blast
radii, and this file exists so the gap isn't lost between them.

---
## Both frontends run their CSP in Report-Only, so it blocks nothing yet

**Status:** Partly fixed. The policy that this entry originally said did not exist now exists in both
apps; promoting it from reporting to enforcing is what remains. Rewritten 2026-09-25.

**Files:** `EB_Healthcare_EHR/src/lib/security/csp.ts` + `src/proxy.ts`,
`EB_Healthcare_PatientPortal/src/lib/security/csp.ts` + `src/proxy.ts`.

**What changed since this was written.** The entry claimed "no `headers()` block in either; no
`vercel.json`" and concluded no CSP was set anywhere. That is no longer true, and the reason it was
missed is worth recording: **the policy is not set in `next.config.ts` at all.** It is built per
request in `csp.ts` and stamped on both the request and the response in `proxy.ts` — the request copy
because Next reads the nonce off the incoming headers to stamp its own RSC bootstrap scripts. Anyone
grepping `next.config.ts`, as this entry did, concludes there is no CSP.

**The remaining gap:** `CSP_HEADER = "Content-Security-Policy-Report-Only"` in both apps. The browser
reports violations and blocks nothing, so today the policy documents intent rather than enforcing it.
That was the right first step — an over-tight policy that blanks a patient chart is worse than the
injection it guards against — but it is a step, not the destination.

**Why it has not been promoted:** nobody has yet done the ten minutes of real use with the console
open. Static analysis cannot substitute for it: a violation only appears when a page actually tries
to load something, so upload flows, the encounter copilot, chart printing and PDF previews each have
to be exercised.

**Resolved sub-items**, so they are not re-investigated:

- `www.gstatic.com`, `fcmregistrations.googleapis.com`, `firebaseinstallations.googleapis.com` —
  listed here as "needed once Firebase web push goes into the EHR". EHR push shipped 2026-09-25. Only
  the latter two were actually required (the SDK is bundled, so no script CDN is contacted), and both
  are in the EHR's `connect-src` with a test asserting nothing else joins them.
- `style-src 'unsafe-inline'` — present in both, for the reason given.
- The XSS surface this was paired with (the unsanitised task-description render) was fixed separately.

**Next step:** exercise the flows above with the console open in each app, add a `report-uri` endpoint
if violations should be collected rather than watched, then flip `CSP_HEADER` to
`"Content-Security-Policy"` — a one-line change in each app, deliberately kept that way.

---

## The backend test suite cannot run on `marley.local` (currency mismatch in ERPNext's test bootstrap)

**Status:** Not currently being worked on — the fix requires a decision, not investigation
(diagnosed 2026-08-24). **Blocks running any backend test on `marley.local`.**

**Files:** `apps/erpnext/erpnext/tests/utils.py:2989` (vendored, must not be edited — `RULES.md`),
`apps/healthcare/healthcare/tests/utils.py:3` (vendored), and the site's `Price List` master data.

**Gap:** `bench --site marley.local run-tests --app remedisys_healthcare_ai --module <anything>`
fails during environment preparation, before a single test runs, with:

```
MySQLdb.IntegrityError: (1062, "Duplicate entry 'Standard Buying' for key 'PRIMARY'")
```

**Root cause — the full chain, traced 2026-08-24:**

```
frappe test runner
  → make_test_records(<doctype>)                     frappe/testing/environment.py
  → generators.get_modules → load_doctype_module(..., "test_")
  → imports healthcare/.../patient_encounter/test_patient_encounter.py
  → from healthcare.tests.utils import HealthcareTestSuite
  → from erpnext.tests.utils import ERPNextTestSuite
  → erpnext/tests/utils.py:2989  BootStrapTestData()   ← module-level, unconditional
  → make_master_data → make_price_list → make_records → INSERT → duplicate primary key
```

Two vendored behaviours combine:

1. **ERPNext bootstraps test master data as an import side effect.** Line 2989 is a bare
   `BootStrapTestData()` at module scope, so merely *importing* `erpnext.tests.utils` writes
   records. The healthcare app imports it to get `ERPNextTestSuite`, and Frappe imports the
   healthcare `Patient Encounter` test module while creating test-record dependencies. Nothing in
   our app is in this chain.
2. **Its skip-check is currency-sensitive.** `make_records` skips an existing record only when
   `frappe.db.exists()` matches on **every** key field, and for `Price List` those keys include
   `currency`:

   ```
   marley.local:      Standard Buying · currency=MXN
   ERPNext expects:   Standard Buying · currency=INR   (utils.py:272-280, hardcoded)
   exists() with the test filters → False   →  it inserts  →  duplicate primary key
   ```

   So the trigger is the **Mexico currency** this platform is built for (ADR-007 / ADR-018) meeting
   ERPNext's hardcoded **INR** test fixture. Any site whose `Standard Buying` is neither INR nor
   absent hits this.

   > **Correction (2026-08-24, same day):** an earlier version of this entry — and §8 G3 of
   > [`audit/2026-08-24-help-support-form-audit.md`](audit/2026-08-24-help-support-form-audit.md) —
   > said the fixture expects **USD**. It expects **INR** (`utils.py:276`). The mechanism and the
   > conclusion are unchanged; the value was wrong. The audit is `record` status and has not been
   > rewritten.

**Not caused by the Help & Support work.** Verified: `tests.billing.test_billing`, untouched by that
feature, fails identically. `--skip-before-tests` does **not** help — ERPNext declares no
`before_tests` hook, and the import happens inside
`_create_global_test_record_dependencies`, which runs regardless of that flag.

**Also note:** `bench run-tests` exits **0** on this failure, so CI would report green while running
no tests at all. That is the more dangerous half of this issue.

**Which kind of problem this is** — the distinction matters for who fixes it:

| Layer | Verdict |
|---|---|
| **Vendor defect** | **Yes.** `BootStrapTestData()` at module scope (`erpnext/tests/utils.py:2989`) writes to the database as an import side effect, and its skip-check is currency-sensitive. Both are upstream design choices |
| **Site configuration** | **Contributing, and correct.** `marley.local` is MXN because the product is Mexican. The site is not misconfigured; ERPNext's fixture simply assumes INR |
| **Test-environment problem** | **Yes, and this is the tractable one.** Tests belong on a site provisioned for testing, not on the main dev site |
| **Remedisys problem** | **No.** Nothing in this app appears in the failing import chain. `tests.billing.test_billing`, untouched by any recent work, fails identically |

**SAFE WORKAROUND — verified working 2026-08-24. Run backend tests on `test.marley.local`.**

That site already carries ERPNext's test fixtures (`_Test Company*`, `_Test Price List*`) and its
`Standard Buying` is **INR**, so the skip-check matches and the bootstrap is a no-op. `helpdesk` was
installed there on 2026-08-24 so the support tests can run; nothing on `marley.local` was touched.

```bash
bench --site test.marley.local run-tests --app remedisys_healthcare_ai \
      --module remedisys_healthcare_ai.tests.support.test_support
# 2026-08-24: Ran 9 tests OK · Ran 4 tests OK · exit 0 · 0 bootstrap errors
```

Two cautions when reading any run:

- **`bench run-tests` exits 0 when the ENVIRONMENT crashes** before the runner starts — as it does on
  `marley.local`. It exits 1 correctly when tests actually fail. So an exit code alone is not
  evidence: always confirm a `Ran N tests` line and the `OK`/`FAILED` verdict.
- Installing `helpdesk` **hijacked Portal Settings on the test site too** (`default_role` →
  `HD Customer`, `default_portal_home` → `/helpdesk`), reproducing the behaviour recorded in the
  integration plan §10.2 on a second, independent site. It was restored immediately. That warning is
  therefore confirmed reproducible, not a one-off.

**Remaining options for a permanent fix, none taken — each needs an owner's decision:**

| Option | Effect | Cost / risk |
|---|---|---|
| **Make `test.marley.local` the documented test site** (done ad hoc, not yet written into CI or contributor docs) | Matches what CI already does — it provisions its own `test_site` (`.github/helper/install.sh`) | Needs `helpdesk` added to `.github/helper/site_config.json`'s `install_apps`, otherwise CI cannot run the support tests either |
| Change `Standard Buying.currency` on `marley.local` | Would unblock the main dev site | **Rejected.** Edits billing master data to satisfy a test harness, and it is wrong for a Mexico deployment |
| Ask upstream ERPNext to guard line 2989 | Fixes every non-INR site | Not in our control; vendored code we must not patch |

**Status:** the first option is verified to work and is the recommendation. Until it is written into
CI, a green run on `marley.local` is impossible and a green *CI* run does not cover the support
module, because CI's site has no `helpdesk`.

---

## No reference ranges exist for native vital signs, so they can never be flagged

**Status:** Not currently being worked on — needs a clinical decision, not an engineering fix
(flagged 2026-08-21).

**Files:** `remedisys_healthcare_ai/scripts/seed/seed_vital_signs_templates.py`,
`remedisys_healthcare_ai/api/v1/vital_signs/api.py`.

**Gap:** `Vital Signs Template` fields carry `normal_range_low` / `normal_range_high`, and the
seed defines them for the CUSTOM readings (SpO₂ 95–100, pain score 0–3, HbA1c 4–5.7, and so on).
The NATIVE columns — `bp_systolic`, `bp_diastolic`, `pulse`, `temperature`, `respiratory_rate` —
have no range anywhere in the backend or the frontend. Nothing in this codebase states what a
normal pulse is.

Consequence: the Activity timeline renders a blood pressure of 210/130 with exactly the same
visual weight as 120/80. The frontend deliberately does NOT invent a threshold, because doing so
would mean this repository asserting clinical norms it was never given.

**Next step:** whoever owns clinical configuration decides the ranges (they are age-dependent for
paediatrics, which is the hard part — a pulse of 120 is normal in an infant and tachycardic in an
adult). Once they exist on the template, `rangeTone` picks them up with no code change on either
side. Do not hardcode numbers in the frontend to close this.

---

## Nothing grades a lab result as CRITICAL, only abnormal

**Status:** Not currently being worked on — needs a clinical decision (flagged 2026-08-21).

**Files:** `remedisys_healthcare_ai/services/labs.py::result_flag`.

**Gap:** `result_flag` returns `Normal | Low | High | Abnormal | None`. There is no panic/critical
grade, so a potassium of 7.9 and one of 5.2 are both simply "High". The frontend implements and
renders a third `crit` tone and maps `"Critical"`/`"Panic"` defensively, but no backend path can
currently produce either, so it is unreachable.

**Next step:** if clinically wanted, add critical bounds to `Lab Test Template` analytes and a
`Critical` branch to `result_flag`; the frontend already honours it. Same rule as the vitals entry
above — the thresholds are a clinical input, not an engineering one.

---

## Lab Test tab fetches one detail record per completed order, eagerly

**Status:** Not currently being worked on — noticed while fixing the same problem on the Activity
timeline (flagged 2026-08-21).

**Files:** frontend `src/components/narzim/patient-chart/lab-center-tab.tsx` (~line 394),
`remedisys_healthcare_ai/api/v1/labs/api.py`.

**Gap:** The tab's `useQueries` fires a `get_lab_test` per completed order the moment it opens —
12 requests for a typical patient, one per lab for a heavy one. The Activity timeline had the same
N+1 and it was fixed by adding `results_summary` to the list projection (2026-08-21), but that
capped, abnormal-first summary CANNOT serve this tab: it needs the full result set for its
abnormal-count chip, its expandable analyte table and its Trends series. Feeding it the capped six
would show "6 abnormal" on a panel with nine.

**Next step:** add an `abnormal_count` (and possibly `analyte_count`) to the list projection — a
cheap aggregate in the same batched query `_result_summaries` already runs. That removes the eager
fetch for collapsed rows, leaving detail requests only for rows the user actually expands.

---

## Two AI-extracted Lab Tests have no attached report, so "View Report" cannot appear

**Status:** Not currently being worked on — small data gap, not a code defect (flagged 2026-08-21).

**Files:** `remedisys_healthcare_ai/api/ai/lab_panel_extraction.py` (~line 1055).

**Gap:** `source_file_url` comes only from a `File` row attached to the Lab Test, so a test with no
attachment correctly offers no "View Report". On `marley.local`, 68 of 70 `ordered_via = "Self"`
tests have theirs; `HLC-LAB-2026-00102` and `HLC-LAB-2026-00104` (both 2026-08-19) do not. The
imaging path attaches the file on a best-effort basis — it reads `source_file` off the `AI Prompt
Log` row and skips silently when that row has been purged.

Those two also group by test name rather than into an "Uploaded report" section in the Lab Test
tab, which is the same root cause surfacing differently.

**A read-side fallback was considered and rejected:** zero `AI Prompt Log` rows carry a `lab_test`
link to any unattached test, so it would recover nothing; the only remaining join is patient +
upload time, and guessing wrong puts another patient's PDF beside this patient's result.

**Next step:** re-upload the report against those two tests to fix the data. The durable fix
belongs in the write path — make the attachment non-optional, or record the extraction on the Lab
Test — not in a read-side heuristic.

---

## Lab extraction M6 compliance gate says "pending"; the live site says otherwise

**Status:** Not currently being worked on — needs a decision from whoever owns the M6 gate,
not an engineering fix (flagged 2026-08-21).

**Files:** `docs/AI_LAB_REPORT_EXTRACTION.md` §8 M6, `docs/AI_MULTI_PANEL_LAB_EXTRACTION.md` §9.

**Gap:** Both design docs state the PHI→LLM compliance gate (data-processing agreement +
patient consent, Mexico LFPDPPP + NOM-024-SSA3-2012 per ADR-007) is still **pending**, and that
`AI Settings.enable_lab_extraction` should stay OFF ("dev/test only") until it clears. Checked
`remedisis.localhost` directly on 2026-08-21: `enable_lab_extraction = 1` and `llm_provider =
OpenAI`, with 16 real `AI Prompt Log` rows (`purpose="Multi-Panel Extraction"`) already on
record — the feature is in active use.

**Not determined:** whether M6 was actually cleared at some point and the docs were simply
never updated to say so, or whether real PHI has been reaching OpenAI without the gate the docs
say is required. Both docs' provenance headers were last touched 2026-07-02, well before this
was noticed.

**Next step:** whoever owns the LFPDPPP/NOM-024-SSA3-2012 compliance decision needs to confirm
the actual status. If cleared: flip both docs' M6 status to done/accepted with a date and who
signed off. If not cleared: this is a live gap, not a documentation one, and needs escalation
above the engineering team.

---

## Patient portal: `get_my_available_slots` under-blocks partially-overlapping bookings

**Status:** Not currently being worked on (paused 2026-07-20).

**File:** `remedisys_healthcare_ai/api/v1/patient_portal/api.py` — `get_my_available_slots` (~line 393).

**Bug:** This endpoint checks whether a slot is booked by exact `from_time`
string match against existing `Patient Appointment` rows (`booked_counts`
dict keyed by `from_time`). It ignores appointment `duration`. A booking that
doesn't start exactly on a generated slot boundary (e.g. a 20-minute
appointment starting at 10:10 when slots are generated at 10:00/10:15) does
not correctly block every slot it actually overlaps — only the one slot
whose `from_time` happens to match exactly. It also has no past-slot
filtering (today's already-elapsed slots still show as available).

**Compare against:** `remedisys_healthcare_ai/api/v1/appointments/api.py` —
`get_available_slots` (~line 803, staff-facing). That version already does
this correctly: delegates slot/schedule assembly to core Frappe Healthcare's
own `get_available_slots(practitioner_doc, date)`
(`healthcare.healthcare.doctype.patient_appointment.patient_appointment`),
then computes availability with a true interval-overlap check
(`appointment_time` + `duration` vs each slot's `[from_time, to_time)`) and
filters out past slots for today.

**Discussed fix (not implemented):** Extract the computation in
`appointments/api.py`'s `get_available_slots` into a shared private helper
(e.g. `_compute_available_slots(prac, date, date_obj)`), call it from both
the staff endpoint and `get_my_available_slots`, and have the patient-portal
wrapper strip per-slot patient identity (`appointments`, `patient_name`)
before returning — matching this module's existing "never duplicate, always
reuse the staff module's helpers" convention (see the file's module
docstring). Note: the shared helper's `Patient Appointment` fetch needs
`ignore_permissions=True` — the patient-portal caller's own
`has_permission`/`permission_query_conditions` hooks
(`overrides/patient_portal_perms.py`) would otherwise narrow that query down
to the caller's own appointments only, making every other patient's booked
slot look free.

**Also discussed, also not implemented:** `book_my_appointment` in the same
file has no `payment_timing` param. The staff-side equivalent
(`book_appointment_for_patient` in `appointments/api.py`) supports
`pay_now` / `pay_later` / `insurance`; the patient portal has no
pay-now/online-payment flow yet, so if this is picked up, `payment_timing`
should be accepted but only `"pay_later"` (or unset) allowed — reject
anything else with a 400 rather than silently ignoring it, so the wire
contract stays stable for whenever pay-now is added on the portal side.

**No code has been changed for this yet** — `appointments/api.py` and
`patient_portal/api.py` are both at their `dev` state as of this note.

## Documents are dropped from multi-file uploads because the request says they are one report

**Status:** Diagnosed 2026-08-26, fix designed, **ADR not yet written** (the agreed next step).

**Files:** `remedisys_healthcare_ai/services/lab_panel_extraction.py::_pdf_text_layer`,
`remedisys_healthcare_ai/integrations/llm.py::build_reference_text_instruction`,
`remedisys_healthcare_ai/integrations/openai.py::_content_part` (and the Anthropic
`_document_block`).

**Gap:** A multi-file upload sends every PDF with the **identical filename `report.pdf`** (the
`file_name` parameter of `_content_part` exists but is never passed at any of its six call sites),
images with no name at all, no separator between attachments, and no statement of how many files
there are. It then sends ONE merged `REFERENCE TEXT` block introduced as *"the exact text extracted
from **this report's** own PDF text layer, every page"* — `_pdf_text_layer`'s docstring states the
assumption outright: *"multi-file = pages of one report"*. The prompt then asks, in five places, for
a `source_file_index` numbering the files 1..N in upload order.

We merge the documents ourselves, then ask the model to un-merge them. The reported indices are wrong
in every multi-file run on record — `{2,3,4}` for three files, `{1,3}` with the middle document
dropped, `{1,5,7}` for six, and **index 8 for a seven-file upload**.

The clean natural experiment, twenty minutes apart on the same file: a 13-page Invitae genetic report
was reported *"Could not read"* inside a 3-file upload (`jkl2o1q61l`, 01:04) and extracted
**successfully on its own** (`10s6jka2ln`, 01:27). The file is fine; the multi-document request is
what loses it.

A second, separate cause hits the same document: the non-shortcut branch of the reference-text
instruction ends *"Do NOT transcribe this text back into a narrative"*, and that report's full
40,615 characters — 79% of the merged block — are inside that text. For the one document whose
content is in the reference block, we explicitly instruct the model not to write it out.

**Next step:** ADR, then make the reference text **per file** (one labelled block per attachment,
`FILE 3 of 7` — never the real filename: two files in the 2026-08-26 upload are named
`926-1004 HERRERA CACERES BEATRIZ EUGENIA.pdf`, and that must not reach the model). That single
change removes the "one report" framing, makes `source_file_index` answerable, and lets the marker
shortcut be substituted per file — which in turn removes the `_single_pdf_file` restriction and the
40,000-character re-transcriptions that time out.

---

## Recovery LLM calls are invisible — nothing writes them to AI Prompt Log

**Status:** Not currently being worked on (flagged 2026-08-26).

**Files:** `remedisys_healthcare_ai/services/lab_panel_extraction.py::_recover_missing_file`.

**Gap:** `_recover_missing_file` calls `llm.extract_multi_panel_report` directly. The logging happens
in the service layer around the MAIN call only, so a per-file recovery call writes **no `AI Prompt
Log` row at all** — no latency, no tokens, no error, no cost.

This contradicts CLAUDE.md §9 ("Every LLM call ... logged to `AI Prompt Log` with prompt_version,
model, tokens_in, tokens_out, cost_estimate_usd, latency_ms, error, session_id"), and it has already
cost real diagnostic time: on 2026-08-26 whether two re-checks had timed out or returned empty could
only be **inferred by subtracting wall-clock times** (job 1,176 s − main call 300 s ≈ two calls at
their ceiling), never read.

Consequence: recovery is the most expensive and least reliable part of the pipeline and it is the one
part with no telemetry. Its cost is also missing from every per-upload cost figure.

**Next step:** write an `AI Prompt Log` row per recovery call (purpose e.g. "Multi-Panel Recovery"),
linked to the parent extraction. Cheap, and it makes the next diagnosis a query instead of arithmetic.

---

## HEIC files uploaded before 2026-08-26 are still stored as .heic and will never preview

**Status:** Known and accepted; no backfill written (flagged 2026-08-26).

**Files:** `remedisys_healthcare_ai/services/lab_extraction.py::stage_uploads_for_storage`.

**Gap:** Uploads are now transcoded to JPEG *at upload*, so the stored file is previewable. Files
uploaded BEFORE that change remain `.heic` on disk (e.g. `IMG_94040577d3f165df.HEIC` on extraction
`pa8ndq37l9`). No browser except Safari renders HEIC, so those records show "No preview available"
permanently — even though their values were extracted correctly.

Consequence: a small, bounded set of existing records where the physician cannot see the source
document beside the extracted values. Re-uploading the file fixes an individual case.

**Next step:** decide whether it is worth a patch that finds `File` rows ending `.heic` attached to
Lab Tests / extractions, converts them and rewrites `file_url`. Given the small number involved,
"re-upload if it matters" may be the right answer — but the decision should be recorded rather than
left implicit.

---

## A practitioner's normal-schedule slots and their Available-override slots can show different durations on the same day

**Status:** Narrowed, not closed (2026-09-10, same day — see ADR-062 decision 11). Override slots now
use the *booked appointment type's* own `default_duration` when one is known, instead of always the
single clinic-wide default — genuinely reduces how often this mismatch actually shows up in practice,
but does not make an override slot match the *practitioner's own* schedule granularity, which is the
gap this entry is actually about. Still not being worked on beyond that narrowing.

**Files:** `remedisys_healthcare_ai/services/availability.py::generate_override_slots` /
`_default_slot_minutes` / `_slot_minutes_for`; `healthcare.healthcare.doctype.practitioner_schedule` /
`Healthcare Schedule Time Slot.duration` (core).

**Gap:** A practitioner's normal recurring schedule carries its own per-row `duration` (set whenever
that schedule was configured — e.g. 15 minutes). `Available`-override slots, generated separately by
`generate_override_slots`, use `_default_slot_minutes()` instead — the clinic's configured
`Healthcare Settings.default_appointment_type` duration (commonly 20 minutes), with no awareness of
what that specific practitioner's own schedule uses. The two numbers have no reason to agree.

**USER STORY.** Anant Sharma's normal Thursday schedule is booked in 15-minute slots (9:00, 9:15,
9:30…); he also has an `Available` override for the same Thursday evening → **the system shows** one
booking grid where morning reads 9:00/9:15/9:30 and evening reads 5:00/5:20/5:40 → front desk assumes
the granularity is a display bug and asks why the evening "skips" 5:10 and 5:15 → **consequence:**
time spent explaining a difference that is real (two different generators, two different configured
durations), not a rendering fault.

**Not a booking-correctness issue** — every generated slot, at either duration, is individually real
and bookable; nothing here allows double-booking or a phantom slot. Purely a UX inconsistency.

**Next step — corrected 2026-09-10, same day this was first written.** The obvious-sounding fix —
read the practitioner's own normal-schedule duration for that weekday, falling back to the clinic
default only when no schedule exists — **does not work, not just "hasn't been decided yet."**
`generate_override_slots` exists specifically so an `Available` override works on a day the
practitioner has **no** normal schedule at all (ADR-062 decision 4) — the one case that most needs a
duration is exactly the case with nothing to derive one from. A practitioner can also carry more than
one `Practitioner Schedule` at once, at different durations, so even "read the schedule's duration" has
no single well-defined answer when a schedule does exist. See ADR-062 alternative 13 (rejected) and
decision 10's Consequences bullet.

The only option that doesn't depend on a schedule existing: let the override state its **own** explicit
duration at write time — a new optional `slot_duration` on `set_my_availability_override` /
`set_availability_override`, defaulting to today's clinic-wide value when omitted. Still not built;
still the real candidate for whatever case has no sensible `appointment_type` to resolve from (e.g. a
booking flow that hasn't picked one yet, or the patient-portal caller, which nothing in this repo wires
an `appointment_type` into today).

**Also unresolved — confirmed, not just suspected (2026-09-11).** Decision 11 only reaches the three
callers verified to already carry an `appointment_type` in state (`new-appointment-dialog.tsx`, the
reassign dialog). The patient portal is a fourth, separate repo
(`EB_Healthcare_PatientPortal`, `c:/Users/divya/Desktop/EB_Healthcare_PatientPortal`) not previously
checked from this codebase — now checked directly, and it does **not** supply one, for a structural
reason, not an oversight:

`src/components/portal/booking-wizard.tsx`'s 7-step wizard asks for the **time slot at step 4** and
the **purpose of visit (appointment type) at step 5** — the type is picked *after* the time, not
before. Step 4's own slot fetch (`src/app/api/appointments/slots/route.ts`) reads only `practitioner`
and `date` off the request; `appointment_type` is not read, sent, or referenced anywhere in that
route at all. So by the moment `patient_portal/api.py::get_my_available_slots` actually runs and
decides override-slot duration, the wizard itself does not yet know what type of visit this is —
there is nothing to pass even if the parameter were wired end to end. `book_my_appointment` at step 7
does send `appointment_type` (matching `Patient Appointment.appointment_type`'s own `reqd: 1`), so the
*saved* appointment is never missing one — only the earlier time-slot step is generated without it.

Fixing this would mean reordering the wizard (ask purpose before time) or re-fetching slots once the
purpose is chosen later — a product/UX decision about step order, not a one-line backend wiring fix.
Not built; still open.

---

## Slot picker buttons show only a start time, not a range — a covered slot can look like a gap

**Status:** Not currently being worked on (found 2026-09-10, live-testing decision 11's per-appointment-
type durations).

**Files:** `EB_Healthcare_Frontend/src/components/narzim/dashboard/new-appointment-dialog.tsx` (the slot
grid button, `formatSlotTime(slotTime)` — start time only); the same underlying mechanism as
`services/availability.py::generate_override_slots`'s boundary behaviour, documented in
`docs/PRACTITIONER_AVAILABILITY.md` §4.

**Gap:** a slot button is labeled only by its start time (e.g. "11:00 PM"), never its end time, even
though its actual duration can now vary by appointment type (20, 45 minutes, whatever the resolved type
carries). A slot silently covering a wide window (e.g. 45 minutes) reads, at a glance, exactly like the
grid simply stopped offering times after it — nothing on the button says otherwise.

**USER STORY.** Front desk books "QA Reschedule Long" (45-minute slots) for Anant Sharma, available
5:00 PM–11:59 PM → **the system shows** a grid ending at an "11:00 PM" button → front desk sees a ~1-hour
gap between that button and the practitioner's stated 11:59 PM cutoff and asks why a slot is missing →
**actual consequence:** nothing is missing — "11:00 PM" already covers 11:00 PM–11:45 PM — but the label
alone can't tell anyone that, so the same question gets re-asked each time a longer duration is used.

**Not a booking-correctness issue** — every rendered slot is exactly as long as it should be; this is
purely about what the button's label communicates.

**Next step:** show each slot's end time on its button (e.g. "11:00 – 11:45 PM"), not just its start.
Frontend-only, no backend change — the end time is already computed (`to_time` on every slot object),
just not rendered. Not built here.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.12 | 2026-10-01 | Divyanshu (AI-assisted) | Added: a shared checkout invoice with a balance or a waiver still settles the old way (ADR-117 Q2) |
| 3.10 | 2026-09-30 | Divyanshu (AI-assisted) | 47 past refunds left the bank account with no payment mode |
| 3.9 | 2026-09-30 | Divyanshu (AI-assisted) | Nine pre-existing test failures listed; ignore_permissions outside billing |
| 3.8 | 2026-09-30 | Divyanshu (AI-assisted) | Added: 8 legacy reschedule refunds cannot refund the rest; two reschedule preview tests fail |
| 3.6 | 2026-09-28 | Ashutosh (AI-assisted) | Inbound WhatsApp restored: the tunnel was restarted on the same reserved domain, so the URL already registered with Meta went live again. Records that `--host-header=mysite.localhost` is required, and keeps the entry open because nothing monitors that tunnel |
| 3.5 | 2026-09-28 | Ashutosh (AI-assisted) | Added: inbound WhatsApp is dead because the Meta webhook callback URL points at a dead ngrok tunnel; the same tunnel had also been silently dropping every outbound branded template |
| 3.4 | 2026-09-26 | Ashutosh (AI-assisted) | The CSP entry claimed neither frontend sets one; both have since 2026-09-02, built in `csp.ts` and applied in `proxy.ts` rather than `next.config.ts`, which is why a grep missed it. Rewritten around what is actually still open: Report-Only, not enforcing. Renumbered from 2.9 on rebase so it sits above dev's separately-authored 2.9-3.3 rather than colliding |
| 3.3 | 2026-09-24 | Divyanshu (AI-assisted) | Rebased `feature/lab-two-stage-extraction` onto `dev`: renumbered this branch's 2.8-3.1 rows to 2.9-3.2 so they sit above dev's own separately-authored 2.8 (Nishant) rather than colliding with it; no row's content changed |
| 3.2 | 2026-09-24 | Divyanshu (AI-assisted) | Added: every Lab Test save queues two AI summary jobs with no unchanged-input skip |
| 3.1 | 2026-09-24 | Divyanshu (AI-assisted) | Removed the AI-path submit-permission entry: fixed — `create_order_for_panel` and `finalize_section_order` now require Lab Test submit before creating anything (`tests/labs/test_ai_panel_submit_permission.py`) |
| 3.0 | 2026-09-24 | Divyanshu (AI-assisted) | Withdrew the Draft Lab Test reuse entry added in 2.9: reuse is intended — an open Draft is the pending order the report fills, and it prevents duplicate orders (`services/labs.py:350-358`) |
| 2.9 | 2026-09-24 | Divyanshu (AI-assisted) | Added five lab-flow issues found while mapping the flow for ADR-092: AI path submits with write permission; Draft Lab Test reuse; aliases unused; uploader note unreachable; duplicate `hooks.py` key. The 2.7 in the prior header has no row here — not introduced by this edit |
| 2.8 | 2026-09-23 | Nishant | Mexican healthcare standard cited as NOM-024-SSA3-2012, the revision in force (compliance plan §4.2, verified 2026-09-14) |
| 2.6 | 2026-09-16 | Sarvesh-SocialAngel (AI-assisted) | Removed the `custom_encounter_done_by` User Permission entry added in 2.5 — fixed and verified live (`fixtures/custom_field.json`, `ignore_user_permissions` 0 → 1, `bench migrate`); see `WORK_LOG.md` 2026-09-16 for the full record |
| 2.5 | 2026-09-15 | Sarvesh-SocialAngel (AI-assisted) | Added: `custom_encounter_done_by` was never exempted from the practitioner User Permission lock, found investigating Jira NH-135 — 70 of 166 signed encounters unreadable by every doctor account tested |
| 2.3 | 2026-09-11 | Divyanshu (AI-assisted) | Resolved a stash-pop conflict against Anant Sharma's separately-committed header bump (1.8) — his three Narzim Drive entries (Restricted does not restrict reading; folders exist only in the browser; share dialog's "Anyone with the link" wording) merged into the body cleanly and are unaffected; only the header line itself conflicted, resolved to one line above both prior versions |
| 2.2 | 2026-09-11 | Divyanshu (AI-assisted) | Confirmed, not just flagged as unverified: checked the patient-portal repo (`EB_Healthcare_PatientPortal`) directly. Its booking wizard picks the time slot at step 4 and the appointment type at step 5 — the type is genuinely not known yet when slots are generated, so `get_my_available_slots` there always falls back to the clinic-wide default. Not a missing-wiring oversight; the wizard's own step order structurally prevents it without a UX change |
| 2.1 | 2026-09-10 | Divyanshu (AI-assisted) | Added a new entry: slot picker buttons show only a start time, not a range, so a wide slot (now duration varies by appointment type) can look like a gap — found live-testing a 45-minute appointment type, where the last "11:00 PM" button already covers 11:00-11:45 PM but reads like the grid stopped an hour before the practitioner's actual cutoff |
| 2.0 | 2026-09-10 | Divyanshu (AI-assisted) | Narrowed (not closed) the entry from 1.9: override slots now use the booked appointment type's own duration when known (ADR-062 decision 11), reducing how often the mismatch actually surfaces without eliminating it. Added an unresolved note: the patient-portal caller has no confirmed frontend wiring for the new `appointment_type` param, unverified rather than assumed fine |
| 1.9 | 2026-09-10 | Divyanshu (AI-assisted) | Corrected the "Next step" on the entry added in 1.8, same day — "derive the override duration from the practitioner's own schedule" was written as an open decision when it's actually not viable at all (the feature's core use case is a day with no schedule to derive from); replaced with the one option that doesn't need a schedule to exist |
| 1.8 | 2026-09-10 | Divyanshu (AI-assisted) | Added the normal-schedule-vs-override-slot duration mismatch, found while replacing a hardcoded 20-minute constant in `services/availability.py` with a Healthcare-Settings-resolved value (ADR-062 decision 10). Note: the header's prior "1.7" has no corresponding row in this table (same gap as the pre-existing 1.2-1.4 jump below) — not introduced by this edit, flagging rather than silently renumbering history |
| 1.5 | 2026-08-26 | Divyanshu (AI-assisted) | Merged with `dev` after a stash-pop conflict. Added three AI lab-extraction gaps (documents dropped from multi-file uploads, recovery AI calls never logged, legacy .heic files unpreviewable) and **withdrew** a fourth claiming lab results never match a test — that was a misdiagnosis; see ADR-028's Verification section |
| 1.1 | 2026-08-21 | Divyanshu (AI-assisted) | Added the lab-extraction M6 compliance-gate contradiction |
| 1.0 | 2026-07-20 | Sarvesh | Initial version (header backfilled from git history) |
