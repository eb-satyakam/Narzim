# Operational Suggestions — Mechanism

**Doc status:** living · **Created:** 2026-09-10 by Divyanshu (AI-assisted) · **Updated:** 2026-09-12 by Divyanshu (AI-assisted) · **Version:** 1.27

Companion mechanism doc for [`adr-064-queue-tips-llm-summary.md`](adr/adr-064-queue-tips-llm-summary.md)
(decision + alternatives + why). This doc explains, layer by layer, how a suggestion actually gets
built — the shape every future suggestion type in this app should follow, not just the two
described here.

## 0. v1.6 — every fact may carry a fixed next step

Added 2026-09-10 after feedback that a facts-only summary "isn't helpful": each fact below may now
carry a **fixed, deterministic next step**, written directly into `prompts/ops-tip-summary-v1.txt`
per fact — never a field the LLM invents. "Move a patient from Waiting Room to Nursing Room,"
"record their vitals," "collect the pending payment," "check them in," "review staffing" are all
logistics, never a clinical action — the existing prompt rule against clinical suggestions is
unchanged and still enforced. Nothing here clicks anything for the reader; it is still just a
sentence, and the actual move/record/collect control is exactly the one that role already had.

**v1.9 (2026-09-10) — cover every applicable fact, not just one.** Every earlier revision picked
the single highest-priority fact and phrased only that one — verified live that a board can genuinely
have 3+ facts true at once, silently discarding the rest. `prompts/ops-tip-summary-v1.txt` rewritten
to cover every present fact, in the same fixed order, as 1-4 short sentences instead of always
exactly one. **Flagged, not fixed:** `QueueInsightBar`'s summary line truncates to one line
(`mission-control-client.tsx:2655`) — a longer, multi-fact summary will now clip visually (full text
still reachable via hover `title`). **Also confirmed:** `EB_Practitioner` sees nothing anywhere in
this app because no frontend screen calls `get_my_workload_suggestion` — zero references, confirmed
by grep — a pre-existing open item (see §4), not a new bug.

**v1.11 (2026-09-10) — a bare Practitioner now rides this same mechanism, scoped to their own day.**
`_resolve_audiences` now matches "practitioner" — a bare Practitioner session (holding no other
mapped role) filters `live` to only their own appointments across all five rooms before any fact
runs (Rule 10/PHI-6). Every existing fact applies unchanged over the narrower set, except
`idle_room`/`overdue_rollup`, which don't apply (no lever a lone practitioner has over either). A new
`own_appointments_only` stats flag tells the prompt to phrase room facts as "your own patients,"
never the room's real total — without it, a practitioner-scoped count would misstate what the room
actually holds. Live-verified against a real practitioner account with one appointment on a
five-appointment board.

**v1.12 (2026-09-11) — durations over 60 minutes now show as hours.** A new shared
`format_minutes()` (`services/queue_stage_log.py`) turns every duration handed to the LLM into
"8hr 10min" (or "45min" under an hour), matching the Live Queue board's own card badges — a raw
"533" was previously read as "533 minutes" in the phrased sentence. Applied only to the LLM-facing
`stats` dict; `get_my_workload_suggestion`'s actual JSON response keeps plain integer minutes,
unchanged. Live-verified against a real, temporarily-created 95-minute-overdue scenario. **Also
found and recorded, not fixed here:** the three test files this ADR's coverage depended on
(`test_queue_tips.py`, `test_queue_stage_log.py`, `test_workload_suggestion.py`) are missing from
disk — see ADR-064 §3i for detail.

**v1.13 (2026-09-11) — "cover reassign and practitioner availability too."** New fact:
`practitioner_unavailable_count` — how many currently-reassignable appointments (arriving_soon/
waiting_room/nursing_room; matches `reassign_appointment`'s own `_REASSIGNABLE_STATUSES` exactly)
have an assigned practitioner who is unavailable for that specific appointment's own time. Gated
to Admin/Nurse/Front Desk (`_REASSIGN_ROLES`) — never a bare Practitioner. A plain count only —
never names which appointment, room, or practitioner, and never recommends a specific substitute
(this app's own `get_reassignment_candidates` doesn't filter by availability either, so a named
recommendation would itself be a guess). **A real design bug caught via live testing:** the first
version checked only `assert_bookable()`; adding a real entry to a practitioner's actual Company
Holiday List and re-testing showed the fact never fired, because `assert_bookable`'s own holiday
check is the Employee-linked-leave path, already dead in this deployment. Fixed by also composing
`get_practitioner_holidays()` (the real, live holiday signal this app has). Re-tested the same way
— fact fired correctly at the practitioner's true reassignable-appointment count — then the test
holiday entry was removed and the baseline re-confirmed clean.

## 1. The one rule every suggestion in this app follows

**Code decides *what* is worth telling someone and *whether* a threshold was crossed. An LLM, if
used at all, only turns already-decided numbers into a readable sentence.** The LLM never sees a
raw database row, never picks which suggestion to show, and never runs on a timer — only on an
explicit user click. This is not a style preference; it is what makes every suggestion this app
produces auditable: if a suggestion is ever wrong, there is one calculation to point at, not a
model's judgment call to guess at. See ADR-064's Context for why this matters even more for the
higher-stakes suggestion type (§3 below).

## 2. The three layers, for any suggestion type

```
[1] Deterministic compute          [2] Optional LLM phrasing           [3] Delivery
 real numbers, no PHI,       -->    "make this one sentence      -->    frontend panel,
 threshold decided in Python        readable" — nothing else            regenerate on click only
```

| Layer | Owns | Never does |
|---|---|---|
| **Compute** (Python, this repo) | The actual math, the actual threshold, the actual list of what to show, and which facts are relevant to the caller's role (an `audience` tag — see §3) | Free-text generation |
| **Phrasing** (LLM, via `get_llm_client()`) | Turning a small numbers-only dict into one sentence, using `audience` to decide which given fact to lead with | Deciding what counts as noteworthy, seeing a patient name, seeing a raw record, adding a fact not in the dict |
| **Delivery** (frontend) | One plain-text line, re-fetching on click | Pills/badges, an expand/collapse interaction, auto-polling the backend |

## 3. Suggestion type A — Live Queue congestion tips

**Where:** `QueueInsightBar`, embedded directly in the Live Queue screen's header row, between the
title and the search box (`EB_Healthcare_Frontend/src/components/narzim/dashboard/mission-control-client.tsx`)
— not a separate panel/row. Product owner asked, after seeing the first pill-based build live, for
plain text in that exact spot instead of dismissible pill badges — see revision history.

**Compute layer:**
- `services/queue_stage_log.py::get_open_row_durations()` — for every open `Queue Stage Log` row
  (no `exited_at` yet), returns `now() - entered_at` per appointment. This is what makes the bar
  "live" — the gap ADR-063 §9 recorded and this closes.
- `api/v1/appointments/report.py::_build_queue_stage_breakdown()` — already built, already tested,
  reused as-is for the historical per-room average `duration_min` to compare the live number
  against.
- **Role tailoring, resolved server-side, not client-side:** `_resolve_audience(roles)` maps the
  caller's frontend `RoleId`s to one of `"admin"`/`"nurse"`/`"frontdesk"`/`None` (mirrors the
  role groupings the original, now-retired local `computeQueueTips` used — nurse/admin saw
  longest-wait, front-desk/admin saw payment-pending, admin alone saw busiest-room). A role with
  no mapping (practitioner/billing/patient) gets **nothing at all** — the LLM is not even called,
  matching what those roles already saw before this feature existed.
- Front Desk's payment-pending count (previously a separate, disconnected local-only tip) is now
  folded into the same mechanism: the frontend still computes it client-side from data
  `get_dashboard_data` already returns, but sends it as `payment_pending_count` for the backend to
  fold into one coherent summary instead of a second, unrelated pill.

**Phrasing layer:**
- Whitelisted method `regenerate_queue_tips(company=None, roles=None, payment_pending_count=0)`
  assembles a stats dict — **room names, counts, minutes, and an `audience` tag only** — and calls
  `get_llm_client().generate_ops_tip_summary(stats)`.
- `generate_ops_tip_summary()` is added to both `integrations/openai.py` and
  `integrations/anthropic.py` (ADR-026's shared-interface requirement), modeled on the existing
  `generate_thread_title()` (`integrations/openai.py:1262`) — same shape: tiny, disposable,
  single-purpose, its own prompt file (`prompts/ops-tip-summary-v1.txt`).
- The prompt file itself, not Python, holds the mapping from `audience` to "which given fact to
  lead with" — the LLM still never invents a fact, only chooses emphasis among facts Python
  already supplied (Rule 9).
- Logged via `services/ai.py::log_prompt_call_general(purpose="Queue Tips Summary", ...)` — the
  sibling already built for non-encounter, by-construction-no-PHI calls.

**Delivery layer:**
- `QueueInsightBar` shows one plain-text line — the LLM-phrased `summary`, or a placeholder before
  the first click. One button re-fetches `regenerate_queue_tips()`. No pills, no dismiss buttons,
  no expand/collapse — a deliberate simplification requested after the pill-based v1 was seen live
  (see revision history). LLM failure or a role with nothing to show → `summary` stays `null`,
  the bar just shows the placeholder; nothing breaks (Rule 7).

**Status: built and unit-tested, 2026-09-10 (7/7 passing) — not yet exercised in a running browser.**
The facts below in §3 are this shipped state. §3.1 immediately after describes a **planned
extension (ADR-064 v1.4) — decision recorded, not yet built** — kept clearly separate so this
section never reads as more finished than it is.

| File | Change |
|---|---|
| `services/queue_stage_log.py` | `get_open_row_durations(appointments)` — new |
| `api/v1/dashboard/api.py` | `regenerate_queue_tips(company=None, roles=None, payment_pending_count=0)`, `_resolve_audience()` — new |
| `integrations/openai.py`, `integrations/anthropic.py` | `generate_ops_tip_summary(stats)` — new, modeled on `generate_thread_title()` |
| `prompts/ops-tip-summary-v1.txt` | New — shared by both suggestion types (§3 and §4); now also carries the audience-to-emphasis mapping |
| `tests/appointments/test_queue_tips.py` | New — live-duration math, PHI-free stats-key allowlist, LLM-failure degrade, role-with-no-mapping gets nothing (and no LLM call), front-desk payment-pending folding. **7/7 passing**, run via `bench --site remedisis.localhost console` (documented workaround) |

**Frontend — `EB_Healthcare_Frontend` — built, 2026-09-10 (revised same day after live product-owner
feedback — see revision history for what the first build looked like):**

| File | Change |
|---|---|
| `src/app/api/dashboard/queue-tips/route.ts` (new) | BFF route — POST only, forwards `company`/`roles`/`payment_pending_count` to `regenerate_queue_tips` |
| `src/hooks/use-dashboard.ts` | `useRegenerateQueueTips()` — a `useMutation`, deliberately not a `useQuery` with a refetch interval, so nothing could accidentally poll this (Rule 9); takes `{company?, roles?, paymentPendingCount?}` |
| `src/types/dashboard.ts` | `QueueLiveTip`, `QueueTipsResponse` (the `tips[]` field is still returned by the backend for audit value; the frontend no longer renders it) |
| `src/components/narzim/dashboard/mission-control-client.tsx` | `QueueTipsPanel` (pill-based) replaced by `QueueInsightBar` — a small inline widget embedded in the Live Queue header's own row (between the title and the search box), showing only the LLM-phrased `summary` as plain text plus a refresh button. The pre-existing local `computeQueueTips`/`formatLiveTip` pill-rendering code is removed entirely, not left dead |
| `messages/en.json`, `messages/es.json` | Net 3 `queue.tips.*` keys remain (placeholder/refresh/regenerating) — the 7 pill-text keys from the first build (`longestWaiting`/`paymentPending`/`busiestRoom`/`dismiss`/3 live-tip templates) were removed as unused, not left orphaned |

Verified: `npx tsc --noEmit` (zero new errors — the one remaining is the repo's existing, already-documented `e2e/encounter-submit.spec.ts` error), `eslint` on all 4 changed/new files (zero new findings — same 3 pre-existing errors elsewhere in the file, at shifted line numbers), `i18n-parity-check` (6977 keys, en↔es aligned). Not yet exercised in a running browser.

## 3.1 Role-scoped facts (ADR-064 v1.4, built and verified 2026-09-10)

Three new facts, each scoped to the room pair (or, for Admin, the whole board) that role can
actually act on — verified against `EB_Healthcare_Frontend`'s real role/capability code before
being scoped this way, not assumed. See `docs/adr/adr-064-queue-tips-llm-summary.md` v1.4 for the
full decision and the alternatives considered for the room-crowding signal specifically.

**Why role-scoped, not just role-tailored phrasing (as §3 already does):** §3's existing
`audience` field changes which of the *same* facts get emphasized in the sentence. This extension
goes further — the facts themselves differ per role, because a fact about a room neither Nurse nor
Front Desk can move a patient in or out of is trivia, not a suggestion.

**Role → action map this design is built on** (verified 2026-09-10 against
`EB_Healthcare_Frontend/src/lib/narzim/roles.ts` `Capabilities`/`ROOM_ROLES`, and backend
`require_permission`/role-matrix checks in `api/v1/appointments/api.py`,
`api/v1/vital_signs/api.py`, `api/v1/encounters/api.py`, `api/v1/billing/api.py`):

| Action | Front Desk | Nurse | Practitioner | Admin |
|---|---|---|---|---|
| Move Arriving Soon → Waiting Room | Yes | backend allows, frontend hides (unrelated pre-existing gap, not addressed here) | No (unless own patient) | Yes |
| Move Waiting Room → Nursing Room | Yes | Yes | Only own patient | Yes |
| Record vitals | No | Yes | Backend allows, no board entry point | Yes |
| Open/sign encounter | No | Draft only | Full | Yes |
| Collect payment | Yes | No | Backend allows, board hides (deliberate — lives on the chart) | Yes |
| Reassign room/practitioner | Yes | Yes | No — excluded by design | Yes |

**New facts, one per role that has an actionable pair:**

- **Nurse — idle downstream room:** compare `by_room["waiting_room"]` and `by_room["nursing_room"]`
  live counts only (the one move a Nurse can make from this board). Nursing Room at 0 while
  Waiting Room is not → the fact. No history, no threshold — a plain "this is 0, that isn't" check.
- **Front Desk — most overdue vs. scheduled slot:** `wait_minutes = now − appointment_datetime`,
  computed only for open appointments currently in `arriving_soon`/`waiting_room` (the rooms Front
  Desk owns and can reassign out of). This reuses the exact math `_wait_minutes()`
  (`api/v1/dashboard/api.py:63-77`) already uses for the live delay badge on every queue card — not
  a new computation, a new *use* of an existing, already-trusted one. Reports the raw largest
  value, same restraint the existing `longest_wait` tip already applies.
- **Admin — board-wide imbalance + a lateness rollup:** the Nurse check with no room-pair
  restriction (Admin can act anywhere) — any room at 0 while another is meaningfully ahead of it,
  across all five. Plus a count of currently-open appointments with `wait_minutes > 0` and the
  worst value among them. Both raw numbers; neither asserts a count is "too many" — see the ADR's
  new "Alternatives considered" subsection for why an imbalance fact was chosen over a capacity
  threshold (this app has no capacity/historical-count concept to derive one from, and ADR-063
  already declined to make an equivalent judgment call for room *duration*).
- **Practitioner:** unchanged, gets nothing from this mechanism — a practitioner-facing lateness
  fact belongs to the separate §4 workload/slack mechanism below, not here.
- **Nurse — vitals not yet recorded (v1.6, added 2026-09-10):** for every appointment currently in
  Nursing Room, check for an existing Vital Signs record — reusing the exact existence-check
  `get_dashboard_data` already performs for its own `vital_by_appt` lookup
  (`api/v1/dashboard/api.py:344-361`), not a new query shape. `vitals_missing_count` is the count
  with none. A plain existence check, no threshold to invent — same category as `payment_pending`.

**v1.6 (2026-09-10) — a next step, not just a fact:** every fact above may now carry a fixed,
deterministic next step in the phrased sentence (move a patient, record vitals, collect a payment,
check someone in, review staffing) — see §0 above and ADR-064 §3c for why this stays inside Rule 9
and Rule 6.

**v1.8 (2026-09-10) — vitals done but still stuck, for Nurse and the practitioner.** New shared fact
`patient_ready_and_waiting_fact()` in `services/queue_stage_log.py` — a patient with vitals already
recorded but still in Nursing Room longer than its historical average (the mirror case of
`vitals_missing`). Wired to Nurse (board-wide) and, new, `get_my_workload_suggestion` for the
practitioner (pre-filtered to their own patients only — Rule 10/PHI-6). A third, independent fact
alongside slack and pace — verified live carrying the response alone when neither of the other two
applied. Prompted directly by a real reported scenario (B Praak: vitals recorded, 7h47min in
Nursing Room); live-verified against that exact patient for both roles.

**v1.7 (2026-09-10) — Practitioner Room attention, multi-role users, and a live bug fixed.**
- **Nurse — new: a patient stuck with the practitioner.** `_room_duration_outlier_fact` — a live
  duration in Practitioner Room exceeding that room's own historical average, no baseline means no
  fact. Awareness only, no forced next step. Admin deliberately excluded this round, per direct
  instruction, not broadened on a guess.
- **Multi-role users.** `_resolve_audiences()` returns every matched role a user holds, not just
  one. The board-wide facts that share stats keys (`idle_room`/`most_overdue`/`overdue_rollup`)
  still come from a single `primary` role to avoid two verdicts overwriting each other; the
  additive, uniquely-keyed facts (`vitals_missing_count`, `practitioner_room_*`,
  `payment_pending_count`) now fire whenever the relevant role is held at all. The prompt's three
  separate per-audience priority lists collapsed into one fixed list keyed on field presence — this
  is what actually makes the multi-role case work without a combinatorial prompt.
- **A real bug found live, fixed before shipping.** The original board-wide `idle_room` check
  compared *any* empty room against the overall busiest room, with no regard for pipeline order —
  verified live, it recommended moving a patient from Arriving Soon straight to Checkout, skipping
  four real stages. Fixed: restricted to **adjacent pairs only**, walked in actual pipeline order.
  Re-verified live: the same board now correctly names Practitioner Room → Checkout instead.

**What does NOT change:** the response shape (`{summary, tips[], generated_at, model}`), the
frontend (`QueueInsightBar` needs no edits — it already just renders whatever `summary` string
comes back), the PHI-free stats-dict discipline (new keys are room/count/minute values only, added
to the existing key-allowlist test as a deliberate, reviewed addition, never a name/MRN).

**Status: built and verified, 2026-09-10.** The three fact computations are pure functions with no
DB access (`_idle_room_fact`, `_most_overdue_fact`, `_overdue_rollup_fact` in
`api/v1/dashboard/api.py`), deliberately not tested against this site's real Queue Stage Log rows —
this dev site has real, live queue data (an appointment sat in Nursing Room for hours during this
feature's own design discussion), so a test asserting "this room is empty" against the live DB
would be fragile for reasons unrelated to a code bug. Unit-tested with synthetic data instead
(`tests/appointments/test_queue_tips.py::TestIdleRoomFact`, `TestMostOverdueFact`,
`TestOverdueRollupFact`) — 20/20 passing overall. Additionally verified live: called for all three
audiences against the running site's real board, confirming Front Desk's most-overdue fact
correctly excluded a worse (1351-minute) appointment sitting in Practitioner Room — not an owned
room — while Admin's unrestricted rollup correctly counted it.

| File | Change |
|---|---|
| `api/v1/dashboard/api.py` | `_idle_room_fact`, `_most_overdue_fact`, `_overdue_rollup_fact` (new, pure) + `regenerate_queue_tips` wiring |
| `prompts/ops-tip-summary-v1.txt` | Per-audience phrasing priority for the new optional fields |
| `tests/appointments/test_queue_tips.py` | New key-allowlist entries; `TestIdleRoomFact`/`TestMostOverdueFact`/`TestOverdueRollupFact` (13 new pure-function tests) |

**v1.6 addition (2026-09-10):** `_vitals_missing_count` (pure) + wiring in `api/v1/dashboard/api.py`;
`prompts/ops-tip-summary-v1.txt` extended with the fixed next-step phrase per fact;
`tests/appointments/test_queue_tips.py::TestVitalsMissingCount` (3 new tests) + a new allowlist key.

## 3.3 Pace/throughput fact for Front Desk, Nurse, and Admin (ADR-064 v1.15 — decision recorded, not yet built)

**The ask, in the product owner's own words:** "we have this much time and these appointments, but
we have completed only this much — if we go with this pace we would not cover all; how much time we
have to spend on each [remaining one] to cover all." §4 below already built exactly this for a
practitioner's own day (the `_pace_fact` mid-day pace check). This section is the same fact,
generalized to every other role that already gets a `regenerate_queue_tips` summary — Admin, Nurse,
Front Desk. A bare Practitioner already has it via §4/§3h and needs nothing new.

**Why not simply reuse §4 as-is:** `_pace_fact()` only needs four numbers
(`appointments_today`, `scheduled_minutes`, `completed_count`, `time_spent_minutes_today`) and does
not care whose day they describe — it is already role-agnostic. What a practitioner has that Front
Desk/Nurse/Admin do not is a real `scheduled_minutes` figure, sourced from their own `Practitioner
Schedule`/`Practitioner Availability` rows. **No equivalent "how much time is left" concept exists
in this app for a room, a role, or the clinic as a whole** — confirmed by grep: nothing named
operating hours, business hours, or clinic-close exists anywhere in this codebase. Resolving that
one gap is the entire design decision here; everything else reuses existing machinery.

**Four approaches considered for the missing "time left" figure** (full pros/cons in
`adr-064-queue-tips-llm-summary.md` §3k's new Alternatives subsection):

| # | Approach | Chosen? |
|---|---|---|
| 1 | Sum every practitioner's own scheduled minutes into one clinic-wide budget | No — doesn't correspond to what Front Desk/Nurse actually do; a practitioner missing a schedule silently understates the sum |
| 2 | Rate + projected finish time, no deadline, no "won't cover all" claim | No — under-delivers on the actual ask |
| 3 | A new clinic-operating-hours setting (e.g. a `Company` field) | No — a new field/migration/ADR before anything ships, and one field wouldn't even be correct for all three roles (a Nurse's shift end ≠ a Front Desk shift end ≠ clinic close) |
| 4 | **Derive the deadline from the last actually-booked appointment of the day** (`max(appointment_datetime + duration)` across today's real bookings) | **Yes** — zero new schema/config, reuses already-trusted booking data, errs conservative (can under-warn on a day staff work late, never over-warns) |

**Compute layer, once built:**

- `_pace_fact()` moves from `api/v1/providers/api.py` into `services/queue_stage_log.py`, alongside
  `patient_ready_and_waiting_fact()` and `format_minutes()` — the same reason those were centralized
  there (§3.1's v1.8 note): more than one API module needs the identical judgment over a different
  scope. `get_my_workload_suggestion()` keeps calling it exactly as today; `regenerate_queue_tips()`
  becomes a second caller.
- New pure helper `_remaining_window_minutes(now, deadline)` — trivial subtraction, kept as its own
  function so it is independently unit-testable.
- One new query per call (not per role) computing the deadline: `max(appointment_datetime +
  duration)` across today's non-Cancelled/No-Show appointments, optionally company-scoped. No
  appointments today → no deadline → no fact, same "no real data, no fact" rule as everything else
  in this app.
- Per-role `completed_count`/`time_spent_minutes_today`, each an existing query shape summed instead
  of averaged:
  - **Admin:** completed Practitioner Room stays today, clinic-wide — same shape as
    `_avg_practitioner_room_minutes(None)`.
  - **Nurse:** completed Nursing Room stays today, clinic-wide — same shape as
    `_avg_nursing_room_minutes()`. Scoped to Nursing Room specifically, not the whole board, matching
    every other Nurse fact already in §3.1 (`idle_room`'s waiting/nursing pair, `vitals_missing`,
    `ready_but_stuck` — all Nursing-Room-specific, never board-wide).
  - **Front Desk:** completed Arriving Soon stays today (a completed `arriving_soon` row is a
    check-in, by this app's own room model) — matching `most_overdue`'s existing
    `owned_rooms=(arriving_soon, waiting_room)` scoping, never the whole board.
- Gating: additive, same as every uniquely-keyed fact since v1.7 — fires whenever the relevant role
  is anywhere in `audiences`, so a Nurse+Front Desk user gets both their own pace facts.
- New stats keys, `pace_`-prefixed to stay unambiguous from the practitioner branch's own unprefixed
  keys: `pace_completed_count`, `pace_time_spent_minutes`, `pace_remaining_count`,
  `pace_expected_remaining_minutes`, `pace_remaining_window_minutes`. PHI-free — counts and minutes
  only, same allowlist discipline as every existing key.

**Phrasing layer:** a new numbered fact in `prompts/ops-tip-summary-v1.txt`'s `rooms`-key branch,
phrased the same way the practitioner branch already does ("you've completed N in M, K remain, at
this pace expect roughly J more — about Y min each to cover all of them") — informational only, no
invented urgency beyond what the numbers say.

**Status: decision recorded, not yet built.** No code, prompt, or test file has been touched for
this section — see ADR-064 §3k for the full alternatives analysis this decision rests on.

## 3.4 Worst wait among vitals-missing patients (ADR-064 v1.16 — built)

Direct Nurse feedback, from a real live session: `vitals_missing_count` restates a number already
visible on the board (the Nursing Room column's own count) and gives no prioritization — which of
the N patients should she see first? `nurse_pace` (§3.3) doesn't fill that gap either: it needs at
least one completed Nursing Room stay today and a real projected shortfall, so a Nurse early in her
shift, or on a day that's genuinely on pace, still gets nothing to prioritize between patients.

**Live investigation before building, not assumed:** checking the real session directly turned up
two real anomalies in the demo data (not in the production code):

- `nurse_pace` correctly found no gap — 60 "completed" Nursing Room rows today had
  `entered_at`/`exited_at` **30-90 milliseconds apart** (a bulk seed script, not real consultations),
  so the average time per patient is ≈0 and `pace_fact` honestly reports nothing worth flagging.
- A naive "longest current wait" check (bypassing `regenerate_queue_tips`'s own date scoping)
  produced 27hr 39min — traced to 22 Nursing Room rows still open from **2026-09-11**, a recurrence
  of the exact stale-row bug §3.1's v1.9 note already found and fixed once for this same function.
  `regenerate_queue_tips` itself is unaffected (its `live` is already filtered to today before any
  fact runs); a fresh, unscoped check is not. With that same today-only scoping applied, the real
  figure was 61 minutes.

**What was built:** `_vitals_missing_worst_wait(nursing_appts, has_vitals, live_minutes_by_appt)` —
a pure function, max `live_minutes` among Nursing Room patients not in `has_vitals`, `None` when
nobody is missing vitals. Wired directly after the existing `vitals_missing_count` computation in
`regenerate_queue_tips`, reusing the same `nursing_appts`/`has_vitals`/`live` this function already
built for that fact — no new query. New stats key `vitals_missing_worst_wait_minutes`, formatted via
`format_minutes` like every other duration field. Never names a patient (Rule 10/PHI-6) — the same
restraint `most_overdue`/`ready_but_stuck` already apply to a room or a duration.

**Status: built and unit-tested, 2026-09-12.**

## 3.5 Checkout excluded from "most overdue" and the overdue rollup (ADR-064 v1.17 — built)

Direct instruction after seeing Admin's live summary flag Checkout as "5hr 59min past its slot" and
count toward "66 appointments retrasadas, revise la dotación de personal": Checkout shouldn't be
treated as a delay at all — its real, actionable signal is whether payment is still pending.

**Why the old behavior was actually wrong, not just noisy:** `wait_minutes` measures time since the
appointment's *original scheduled slot* — by the time a visit reaches Checkout it has already
passed through four earlier stages, so a large value there is close to structural, not a sign
anything is going wrong. The fixed "review staffing" next step this ADR attaches to
`overdue_rollup` is the wrong instruction for a patient who has already been fully seen and is
simply waiting to pay.

**What changed:** new `_OVERDUE_ELIGIBLE_ROOMS` constant (every room except `checkout`) in
`api/v1/dashboard/api.py`. Admin's `_most_overdue_fact` call now passes this instead of `None`
("unrestricted"); `_overdue_rollup_fact`'s input (`wait_by_appt`) is pre-filtered to the same room
set before the call. Neither pure function's own signature changed — only what the wiring feeds
them. `payment_pending_count` (§3, built 2026-09-10, widened to all five rooms 2026-09-11) is
unchanged and remains Checkout's real signal.

**Status: built and unit-tested, 2026-09-12.**

## 3.6 A room running slow gets a decision, not just a restated number (ADR-064 v1.18 — built)

Direct feedback, from the exact scenario reported: "Waiting Room live wait is 16min versus a
historical 5min, the largest slowdown on the board. It is showing this for frontend which is good
but what do I have to do with that — give some suggestion so I can reduce this waiting time; help
[the reader] make a decision, not just read the data and convert it into text."

**Root cause:** `slowest_vs_average` (§3a) was the one fact in this ADR that never got promoted to
"always covered when true" at v1.9 — it lives in the LLM prompt's fallback branch, used only when
*no other* fact is true. On a board busy enough to have any other fact firing (the normal case —
almost certainly true whenever a slowdown is actually worth explaining), the fact is silently
dropped from the phrased sentence entirely, even though it still reaches `tips[]` for the frontend
to render. That mismatch — visible on the board, absent from the reasoning — is the actual
complaint.

**The real decision, not a canned phrase:** whether the very next pipeline stage is free right now.
If it's empty, that's already `_idle_room_fact`'s own territory (move a patient in — already
built). If it's **also occupied**, the one-patient-move lever isn't available, and that's new,
useful information nobody currently states out loud: the slowdown likely needs attention at the
next stage's capacity/staffing, not a simple nudge.

**What was built:**
- New pure `_slowdown_next_step_fact(slowest_room, by_room)` — `None` when the next stage is idle
  (already `idle_room`'s case) or `slowest_room` is the last stage (Checkout); otherwise
  `{"next_room", "next_room_count"}`.
- `slowest_vs_average` moved out of the prompt's fallback-only branch into the normal numbered-fact
  list every other fact already lives in, gated to the same room-pair capability each role already
  has for `idle_room` (Nurse: Waiting Room only; Front Desk: Arriving Soon only; Admin: unrestricted;
  bare Practitioner: excluded, no lever).
- New stats keys: `slowdown_room`, `slowdown_live_avg_minutes`, `slowdown_avg_minutes`,
  `slowdown_next_room`, `slowdown_next_room_count`.

**Status: built, unit-tested, and live-verified, 2026-09-12.** Confirmed against the real board:
Admin's summary correctly said the downstream stage was also occupied, not just idle-vs-busy noise.
**Also found live, recorded rather than hidden:** the Python side reaches the LLM correctly every
time (confirmed by intercepting the exact stats dict); the LLM's phrasing of a 3-fact Nurse summary
(`vitals_missing` + `slowdown` + `nurse_pace` all true at once) covered all three in 3 of 4 repeated
live calls and silently dropped the slowdown clause in the 4th — a stochastic under-coverage risk at
a fact-count this feature has never previously reached for one audience, distinct from v1.9's
deterministic "always stops after the first" bug (already fixed). `tips[]` is unaffected — always
carries every fact regardless. See ADR-064 §3n for the full finding and possible follow-ups.

## 3.7 A real decision for "busiest AND slowest" (ADR-064 v1.19 — built)

Reported live: "Practitioner Room is busiest with 30 patients and a live average of 34min versus a
historical 25min. What do I have to do with this?" Follow-up: show a suggestion with the fact, not
only the fact.

**Why `busiest_room` alone never gets a suggestion:** a room simply having the most patients doesn't
mean anything is wrong — Practitioner Room naturally holds more people for longer than Arriving
Soon. Attaching "review staffing" to a plain count would invent urgency, which this ADR has
consistently refused to do for a count alone.

**The real, non-invented trigger:** `busiest_room` and `slowest_vs_average` (§3a/§3n) naming the
SAME room — unusual volume and unusual duration coinciding is a genuine capacity signal, built from
two facts already computed, not a new threshold.

**What was built:** new pure `_capacity_strain_fact(busiest_room, slowest_room)` — fires only when
they match. Wired Admin-only (staffing is an admin lever, matching `overdue_rollup`'s existing
Admin-only "review staffing" precedent exactly) as a new `capacity_strain_room` stats key and
`capacity_strain` tip.

**Status: built, unit-tested, and corrected live within the hour, 2026-09-12** — see below.

**Raised, not decided:** whether board-wide-only facts (`busiest_room`, `longest_wait`, the LLM
fallback branch) should be scoped to each role's own rooms, the way every actionable fact already
is — today Front Desk/Nurse can still be told about a room they have no lever over, as unscoped
awareness. Two options discussed directly, no decision made yet; see ADR-064 §3o.

**v1.20 correction (2026-09-12) — the trigger above was too narrow, found live within the hour.**
Reported with a screenshot: "Practitioner Room is busiest with 30 patients and a 46min live
average" — no comparison, no suggestion, the exact complaint §3.7 was built to fix. Root cause:
the fact required `busiest_room` to also be `slowest_vs_average`'s own separately-computed "single
worst-ratio room" — at that moment Waiting Room (50min vs. 5min, 10× ratio) beat Practitioner Room
(46min vs. 25min, 1.8× ratio) for that unrelated title, so a smaller, far less consequential room
silently crowded out a real signal on the room actually affecting the most patients. **Fixed:** the
fact now checks the busiest room's own live-vs-historical ratio directly, never a comparison to
whichever room wins a separate contest, and now states the actual numbers in the sentence instead of
a bare "may need staffing."

## 3.8 A projected clock-time finish, not just a duration (ADR-064 v1.21 — built)

A reference design showed *"projected clinic finish is 17:45 — 35 minutes beyond plan"* alongside a
red "Operationally critical" severity label. Direct instruction: build the useful planning number,
explicitly **not** the severity label — a label would invent a new judgment threshold ("how many
problems make a day 'critical'?") this ADR has consistently declined to add without a real,
separate product decision. What was asked for is squarely "useful info to help manage the day," not
a verdict.

**Why this needed no new judgment call:** the pace facts (§3.3) already compute
`expected_remaining_minutes` and `remaining_scheduled_minutes` — the reference's "17:45, 35 min
beyond plan" is those same two numbers as a clock time instead of two durations:
`projected_finish_time = now + expected_remaining_minutes`; `beyond_plan_minutes =
expected_remaining_minutes - remaining_scheduled_minutes` (always positive whenever a pace fact
exists at all).

**Scope:** Admin/Nurse/Front Desk's pace facts only — they already have a real deadline **datetime**
to project against. The practitioner's own workload pace fact has only a total-minutes schedule
figure, not a single end-of-day clock time, so a wall-clock projection there would need new work,
not a reuse — recorded as a follow-up, not built here.

**What was built:** new pure `format_clock_time(dt)` in `services/queue_stage_log.py` ("5:45 PM"
style); new stats keys `admin_pace_projected_finish_time`/`admin_pace_beyond_plan_minutes` (and the
`nurse_pace_`/`frontdesk_pace_` equivalents).

**Status: built and unit-tested, 2026-09-12.**

## 3.9 Compressed phrasing for a heavily multi-role account (ADR-064 §3r — built, prompt-only)

Reported from a real 4-role account (Admin + Practitioner + Nurse + Front Desk): "make this summary
a bit shorter, [the] facts and recommendation are correct" — confirming content was accurate,
wanting only the wording tightened once 7 facts fired at once. Prompt-only fix: merge facts naming
the exact same room into one clause instead of two sentences, and say a staffing recommendation
once even when two different facts both suggest it. No code, fact-selection, or stats-key change.

## 3.10 Auto-fetch once on first page load (ADR-064 §3s — built, frontend)

Direct instruction: show the summary automatically the first time a user opens the Command Center;
the existing Refresh button stays manual for every update after that. A single, bounded fetch tied
to opening the page (someone is demonstrably there to read it) — not a recurring timer, so it does
not reopen the Alternatives Considered rejection of scheduled/polled regeneration.

`QueueInsightBar` (`EB_Healthcare_Frontend/.../mission-control-client.tsx`) gained a `useEffect`
guarded by a `useRef` flag so the existing `handleRefresh()` fires exactly once per mount, never
again on later prop changes. No backend code changed. Accepted cost note: one additional LLM call
per page load that would not previously have happened.

**Status: built, 2026-09-12.** `tsc --noEmit` and `eslint` both clean (only the same pre-existing
findings this file/repo has carried since 2026-09-10). Not yet exercised in a running browser.

## 3.11 Fact-vs-recommendation rebalance, a refused streaming request (ADR-064 §3t — built)

Ask: shorten the fact, expand the recommendation; also "apply streaming" for perceived latency.
**Streaming was refused** — CLAUDE.md Hard Don'ts explicitly bans streaming LLM tokens to the UI;
every fact here is delivered as one complete sentence, never a partial fragment. The real complaint
(page "feels slow" on first load) was a missing loading state, not the LLM call's actual latency —
fixed with an honest "Generating today's insights…" pulse instead of the old, now-stale "click
Refresh" placeholder. Separately, the prompt now spends fewer words on the fact and more on the
recommendation within each clause. **Status: built, 2026-09-12.**

## 3.12 Auto-fetch-on-mount reverted; root cause was an OneDrive-synced project folder (ADR-064 §3u)

The v1.23 auto-fetch behavior (§3.10 above) was reverted per direct instruction: "whenever user
clicks on refresh then only generate." Investigated first, not guessed at — a "stuck Refreshing"
report led through ruling out a hung LLM call, a re-firing effect, and a mutation-wiring bug (each
with real evidence), plus a real, separate problem found and fixed along the way (two duplicate dev
server processes). The actual root cause: the project folder is inside an actively-syncing OneDrive
path, causing the dev server to rebuild itself unprompted and strand any in-flight request — an
environment issue no code change can reliably prevent. Reverting the auto-fetch reduces exposure (a
request is now only ever in flight during a deliberate click) without fixing the underlying
environment problem, which remains the user's to resolve (move the project out of OneDrive's synced
scope, or exclude it from sync). The `queue.tips.generating` loading state from §3.11 is kept —
still useful feedback for an explicit click's own wait.

## 3.13 A real defect fixed: client-claimed roles no longer decide WHOSE data gets summarized (ADR-064 §3v)

Reported: the summary claimed clinic-wide numbers (104 booked, 60 vitals done, 15 in Nursing Room)
for a real account whose own board showed only 26 patients. Root cause, confirmed against the
database: the account's REAL Frappe role is `EB_Practitioner` only; the board correctly scoped it
via `_practitioner_read_scope()` (ADR-018), but `regenerate_queue_tips` derived its own scope purely
from the client-sent `roles` parameter — which for this account claimed
`admin+nurse+frontdesk+practitioner`, a mismatch with reality (a separate frontend bug). This ADR
had always said the client-sent `roles` is "never a security boundary" for *which fact to lead
with* — that was never true for *whose appointments get counted*, and the endpoint had conflated
the two.

**Fix:** `regenerate_queue_tips` now calls the same `_practitioner_read_scope()` the board uses, and
lets it override the client's claim whenever more restrictive — never widening beyond what the
client already claimed, only tightening to match server-verified reality. A genuinely multi-role
account is completely unaffected.

**Status: built and unit-tested, 2026-09-12.** See ADR-064 §3v for the full root-cause trace and the
new `TestPractitionerScopeOverride` test class.

## 3.14 Rebranded as Nova, using her own portrait (ADR-064 §3w, frontend)

The panel's generic alert icon was first replaced with a named "Nova Insights" text badge, then —
per direct follow-up instruction — with Nova's own circular portrait image and no text at all,
reusing the exact same portrait asset the AI Workforce directory already uses for this persona
(`/avatars/agents/nova.png`). Frontend only, no backend change. **Status: built and verified,
2026-09-12.**

## 4. Suggestion type B — practitioner workload/slack tip (single-clinic version)

**Where:** `api/v1/providers/api.py::get_my_workload_suggestion()` — a self-service endpoint
(`_session_practitioner()`, same ownership convention as `get_my_holidays`/`set_my_availability_override`).
Frontend surface not yet decided (see open item 2 below) — no UI wired yet.

**The original ask, and why it's not what got built.** The product owner described a practitioner
working at two clinics, scheduled for the same hours at each even when one clinic booked far fewer
appointments — "you have this many appointments here, you could leave early." Verified 2026-09-10
(see ADR-064 Context) that **this app has no working data model for a practitioner belonging to
more than one clinic today**: `Healthcare Practitioner.custom_company` is a single Link, confirmed
orphaned by `docs/audit/settings/07-practitioners.md` PR5 (never populated by any API or UI), and
`Practitioner Schedule` carries no company field at all. `CHANGELOG.md`'s 2026-09-03 entry
independently confirms this deployment is single-clinic today. **Per direct product-owner
instruction, the cross-clinic comparison is deferred; the single-clinic version below is what
ships now**, designed so that adding a real second clinic later is an extension (add a `company`
grouping), not a rewrite.

**Compute layer (all deterministic, one practitioner, one clinic, one day):**

| Number | Source |
|---|---|
| `appointments_today` | `frappe.db.count("Patient Appointment", {practitioner, appointment_date: today, status not in [Cancelled, No Show]})` |
| `avg_consult_minutes` | `_build_queue_stage_breakdown(practitioner=<self>, room="practitioner_room")`'s `avg_duration_min`. **Fallback resolved, not left open:** when this practitioner has no history yet, the same call with no `practitioner` filter (the clinic-wide average for that room) is tried instead — a computed fallback from real data, never a hardcoded constant (`[[feedback_no_hardcoded_limits]]`). If even that is `None` (no completed consultation exists anywhere yet), the endpoint returns `available=False, reason="not_enough_history"` — an honest "no basis to estimate" rather than a guess |
| `scheduled_minutes` | New `services/availability.py::get_scheduled_minutes_for_date()` — reuses ADR-062's own primitives (`_normal_schedule_ranges`, `_override_ranges`, `_subtract_ranges`), so it can never disagree with what booking actually allows |
| `slack_minutes` | `scheduled_minutes - expected_minutes_needed` |

**Threshold, resolved:** rather than invent a percentage cutoff, the gate is simply
`scheduled_minutes > 0 and slack_minutes > 0` — the suggestion appears only when there is real,
positive spare time and a real schedule to compare against. No magic number; `available=False,
reason="no_notable_slack"` otherwise. This is a deliberately conservative default, not a validated
threshold — worth revisiting once real usage exists.

**Phrasing layer:** the same `generate_ops_tip_summary()` used by §3, fed
`{language, appointments_today, expected_minutes_needed, scheduled_minutes, slack_minutes}` — no
patient data, and the practitioner is only ever shown a suggestion about their own day. Logged
under `purpose="Workload Tip Summary"`.

**Delivery layer:** informational only, confirmed directly by the product owner — no button edits
the practitioner's schedule. They read it and decide for themselves (Rule 6).

**Status: backend built and unit-tested, 2026-09-10** (`api/v1/providers/api.py::get_my_workload_suggestion`,
`services/availability.py::get_scheduled_minutes_for_date`,
`tests/providers/test_workload_suggestion.py` — **4/4 passing**, run via
`bench --site remedisis.localhost console`). **Not built:** the frontend surface, and the
cross-clinic comparison (see below — permanently out of scope until the data model exists for
real, not just re-attempted later on a guess).

**v1.6 addition (2026-09-10) — mid-day pace check.** Independent of the start-of-day slack forecast
above (which relies on the *historical* average consult time and reports "not_enough_history" when
none exists), this uses **today's actual completed Practitioner Room stays** —
`completed_count`/`time_spent_minutes_today` from Queue Stage Log rows for this practitioner,
`entered_at` today, `exited_at` set — to project whether the remaining appointments
(`remaining_count = appointments_today − completed_count`) are likely to fit in the time actually
left in the schedule (`remaining_scheduled_minutes = scheduled_minutes − time_spent_minutes_today`).
Fires only when the projection genuinely exceeds what's left (`_pace_fact`, pure function, no DB
access) — same "no invented threshold" rule as every other fact in this app. The two facts (slack,
pace) are independent: a day with zero prior history — previously an automatic
`not_enough_history` — can now still surface a pace warning once a couple of today's patients are
done. Phrasing: "you've completed N in M minutes, K remain, you may be running long" — informational
only, same as the slack fact; nothing here edits the schedule.
Tests: `tests/providers/test_workload_suggestion.py::TestPaceFact` (5 pure-function tests) plus two
wiring tests that mock `_pace_fact` at the boundary rather than engineering exact real minute counts
against the practitioner schedule/override system — 11/11 passing overall in this file.

**Two real bugs found and fixed while getting these green, worth recording so they aren't
re-discovered blind:**

1. **`_build_queue_stage_breakdown`'s built-in practitioner-scope enforcement
   (`report_practitioner_scope()`) silently defeated the clinic-wide fallback.** It exists to stop
   a plain practitioner seeing another's figures on the *report* endpoint — correct there. Reused
   here for the fallback average, it re-narrowed a `practitioner=None` "clinic-wide" query back
   down to "this one practitioner only" for any non-admin caller, so a practitioner with zero
   history got `not_enough_history` even when the clinic as a whole had real data. **Fixed** by
   adding a small dedicated `_avg_practitioner_room_minutes()` in `providers/api.py` that queries
   Queue Stage Log directly, with no report-layer scope coupling — this is a first-person
   self-service computation, not a delegated report, and the two should not have shared scoping
   logic in the first place.
2. **A practitioner is never actually schedule-less in this app.** `overrides/practitioner_default_schedule.py`
   auto-attaches a clinic-wide "Default Schedule" (09:00-21:00, every day) to every new
   `Healthcare Practitioner` on creation. A practitioner with two schedules whose windows overlap
   (the common case: the auto-default plus any second one a clinic adds) would have had the
   overlapping minutes **double-counted** by `get_scheduled_minutes_for_date`, since it summed raw
   ranges without merging overlaps first. **Fixed** by adding `_merge_ranges()` and applying it to
   the normal-schedule ranges before summing.

**Open items still real, listed so nobody assumes otherwise:**

1. **Cross-clinic comparison stays out of scope** until a second real clinic exists in this
   deployment with real practitioners and appointments to design and test against — inventing the
   multi-company data model now, against nothing real, was rejected (see the earlier discussion in
   this repo's own SU2/2026-09-03 precedent of deferring the same question for the same reason).
2. **Which screen/role shows this** — the practitioner's own dashboard, the Providers screen, or
   elsewhere — is still a product decision, not made yet. The backend is screen-agnostic (a plain
   whitelisted method), so this doesn't block backend work, only the frontend step.

## 5. What stays out of every stats dict, no exceptions

- Patient name, MRN, DOB, or any other patient-identifying field — never, for either suggestion
  type (Rule 10, PHI-6).
- Raw rows of any kind — only pre-aggregated counts/minutes/names of rooms or clinics.
- A practitioner's own name/id is not a patient-PHI concern in the workload suggestion (it's a
  suggestion about their own day, shown to them), but stays scoped to that one practitioner —
  never surfaced about a different practitioner without their own view requesting it.

## 6. Testing shape (applies to both types)

- Assert the compute-layer math against known inputs (live duration, historical average, slack
  minutes) — independent of any LLM call.
- Assert the threshold decision is deterministic and never delegated to the LLM response.
- Assert the stats dict handed to the phrasing call contains only an explicit allowlist of keys —
  not a blocklist, so a newly added field must be deliberately added to the allowlist to pass.
- Assert an LLM/provider failure degrades to "no summary line, full deterministic detail still
  shown" — never an error, never a blocked panel (Rule 7).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.27 | 2026-09-12 | Divyanshu (AI-assisted) | §3.14 updated — the "Nova Insights" text badge replaced with Nova's own circular portrait image, no text, per direct follow-up instruction |
| 1.26 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.14 — rebranded the panel's icon as "Nova Insights", matching the AI Workforce screens' existing brand identity |
| 1.25 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.13 — fixed a real defect: the client-sent `roles` was being trusted to decide whose appointments get counted, not just which fact to phrase. Now defers to the same server-verified `_practitioner_read_scope()` the board itself uses whenever it is more restrictive |
| 1.24 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.12 — reverted the v1.23 auto-fetch-on-mount per direct instruction, after investigating a "stuck Refreshing" report through to its real root cause: the project folder sits inside an actively-syncing OneDrive path, causing the dev server to rebuild itself and strand in-flight requests |
| 1.23 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.11 — refused a streaming request (CLAUDE.md Hard Don't) and fixed the real underlying complaint instead (missing loading feedback on first page load); prompt rebalanced to favor the recommendation over the fact within each clause |
| 1.22 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.9 — prompt-only compression fix for a heavily multi-role account (merge same-room facts, dedupe repeated staffing recommendations). New §3.10 (frontend) — `QueueInsightBar` auto-fetches once on first mount per direct instruction; Refresh button unchanged |
| 1.21 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.8 — a projected wall-clock finish time ("5:45 PM, 35min beyond plan") for the Admin/Nurse/Front Desk pace facts, pure arithmetic on already-computed numbers. A reference design's severity-label styling was explicitly declined per direct instruction |
| 1.20 | 2026-09-12 | Divyanshu (AI-assisted) | §3.7 corrected — found live within the hour: the trigger required busiest_room to also win a separate "single worst ratio" contest, letting a smaller room with a more extreme ratio silently crowd out a real signal on the busiest room. Fixed to check the busiest room's own ratio directly; the sentence now states the actual numbers |
| 1.19 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.7 — an Admin-only "review staffing" decision when a room is both busiest AND running slower than its own history — reuses two already-computed facts as the trigger, never a plain count. Raised, not yet decided: whether board-wide-only facts should be scoped to each role's own rooms |
| 1.18 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.6 — `slowest_vs_average` promoted from fallback-only to a normal, always-covered fact, plus a new decision (is the next pipeline stage free right now, or occupied too) instead of a restated number. Fixes the reported gap directly: a room's slowdown was silently dropped from the phrased summary whenever any other fact was also true — the normal case |
| 1.17 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.5 — Checkout excluded from `most_overdue`/`overdue_rollup`'s room pool; its own real signal (`payment_pending_count`) was already built and unchanged. Direct instruction after Admin's live summary flagged a fully-seen Checkout patient as needing a staffing review, which was the wrong instruction |
| 1.16 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.4 — worst current wait among Nursing Room patients still missing vitals, a priority signal added to the existing flat `vitals_missing_count`, after direct Nurse feedback that the count alone just restates the board's own header. Live investigation surfaced two demo-data anomalies (near-zero synthetic durations; a recurrence of the v1.9 stale-open-row bug in a standalone check) — both traced to the data, not the production code |
| 1.15 | 2026-09-12 | Divyanshu (AI-assisted) | New §3.3 — pace/throughput fact for Front Desk, Nurse, and Admin (ADR-064 §3k, decision recorded, not yet built): the same mid-day pace check §4 already has for a practitioner's own day, generalized to every other role. The one real design gap — no clinic/room/role has a "scheduled hours" concept the way a practitioner does — resolved by deriving the deadline from the last actually-booked appointment of the day, not a new setting |
| 1.14 | 2026-09-11 | Divyanshu (AI-assisted) | New `practitioner_unavailable_count` fact — an appointment whose practitioner is unavailable needs reassigning, gated to Admin/Nurse/Front Desk. Live-testing caught a real design bug (holiday check via `assert_bookable` alone was inert; fixed by also using `get_practitioner_holidays`) before it shipped |
| 1.13 | 2026-09-11 | Divyanshu (AI-assisted) | Durations over 60 minutes now phrase as hours ("8hr 10min"), matching the board's card badges, via a new `format_minutes()`. Live-verified against a real scenario. Also recorded: the three test files this ADR's coverage depended on are missing from disk |
| 1.12 | 2026-09-10 | Divyanshu (AI-assisted) | A bare Practitioner now rides `regenerate_queue_tips`, scoped to their own appointments across the whole queue for the day — resolves the "sees nothing" gap the 1.11 entry below had only confirmed, not fixed. New `own_appointments_only` flag so room facts are phrased correctly. 69/69 tests, live-verified |
| 1.11 | 2026-09-10 | Divyanshu (AI-assisted) | Prompt rewritten to cover every applicable fact at once instead of only the single leading one. Confirmed by grep: `EB_Practitioner` sees nothing because no frontend screen calls the practitioner workload endpoint — pre-existing open item. Flagged, not fixed: the frontend summary line truncates to one line |
| 1.10 | 2026-09-10 | Divyanshu (AI-assisted) | New shared fact for a vitals-checked patient still stuck in Nursing Room, wired to Nurse and (new) the practitioner's own workload endpoint, pre-filtered to their own patients. Prompted by a real reported scenario; live-verified against that exact patient for both roles. 64/64 tests |
| 1.9 | 2026-09-10 | Divyanshu (AI-assisted) | New Nurse fact (Practitioner Room duration outlier); multi-role support (`_resolve_audiences` — a user holding more than one role gets every held role's additive facts); a real bug found live and fixed (board-wide idle-room check recommended a physically nonsensical 4-stage-skip move — restricted to adjacent pipeline pairs). 44/44 tests, re-verified live |
| 1.8 | 2026-09-10 | Divyanshu (AI-assisted) | New §0 — every fact may now carry a fixed, deterministic next step (feedback: facts-only wasn't helpful). New Nurse fact (vitals not yet recorded, §3.1) and new Practitioner fact (mid-day pace check using today's actual completed consultations, §4) — both built, tested (34/34 total across both mechanisms), live-verified |
| 1.7 | 2026-09-10 | Divyanshu (AI-assisted) | §3.1 status updated from "planned, not yet built" to built and verified: pure-function implementation, 20/20 tests passing, live-verified against the real board for all three audiences |
| 1.6 | 2026-09-10 | Divyanshu (AI-assisted) | New §3.1 — planned extension (ADR-064 v1.4, decision recorded, not yet built): role-scoped facts (Nurse idle-room, Front Desk most-overdue-vs-slot, Admin board-wide imbalance + rollup), each scoped to a room pair verified against the frontend's real role/capability code, plus the role→action map that scoping is built on |
| 1.5 | 2026-09-10 | Divyanshu (AI-assisted) | Two more live bugs found and fixed after the product owner tried the redesigned bar in a real browser: (1) the raw internal room key ("waiting_room") was being sent to the LLM verbatim instead of a human label — fixed with `_ROOM_LABELS`, locked in with a regression test; (2) EVERY call to `log_prompt_call_general` for both suggestion types was silently failing — `AI Prompt Log.purpose` is a closed Select field and "queue_tips_summary"/"workload_tip_summary" were never added as options, so 9 real, successful LLM calls over an hour left zero audit rows, a genuine violation of the "every LLM call is logged" rule that the try/except swallowing the error had hidden. Fixed by adding "Queue Tips Summary"/"Workload Tip Summary" to the doctype's options and using those exact strings |
| 1.4 | 2026-09-10 | Divyanshu (AI-assisted) | Revised same day, after the product owner saw the pill-based v1 live (screenshot) and asked for plain text instead, placed inline in the header row between the title and search box, and made genuinely role-tailored rather than identical for every viewer. `QueueTipsPanel` (pills, expand/collapse) replaced by `QueueInsightBar` (one plain-text line, one refresh button). Backend gained `_resolve_audience()` and an `audience` stats field so the LLM's phrasing — not just raw numbers — varies by admin/nurse/frontdesk; a role with no mapping (practitioner/billing/patient) gets nothing and the LLM isn't even called. Front Desk's payment-pending count, previously a separate local-only tip, is folded into the same summary. 7/7 backend tests passing (was 5/5) |
| 1.3 | 2026-09-10 | Divyanshu (AI-assisted) | §3a frontend built in `EB_Healthcare_Frontend` (`QueueTipsPanel` collapse + regenerate button, new BFF route, new mutation hook, new i18n keys) — typecheck/lint/i18n all clean, not yet browser-verified. §3b (workload tip) frontend still not started — screen ownership undecided |
| 1.2 | 2026-09-10 | Divyanshu (AI-assisted) | Both test files run green (5/5, 4/4) via `bench console`. Two real bugs found and fixed while verifying: the report layer's practitioner-scope enforcement was silently defeating the clinic-wide average fallback; overlapping practitioner schedules (the auto-attached default plus any second one) were double-counted in scheduled-minutes |
| 1.1 | 2026-09-10 | Divyanshu (AI-assisted) | Both suggestion types built (backend). §4 rewritten: cross-clinic workload deferred per product-owner instruction (no real second clinic exists to design against); single-clinic workload/slack version shipped instead. The `avg_consult_minutes` fallback and the threshold, both previously open items, are resolved (clinic-wide average fallback; positive-slack-only gate) rather than left as hardcoded guesses |
| 1.0 | 2026-09-10 | Divyanshu (AI-assisted) | Initial version — mechanism doc for ADR-064, covering both suggestion types |
