# Front desk — Patient 360 redesign

**Doc status:** living · **Created:** 2026-09-29 by Ashutosh (AI-assisted) · **Updated:** 2026-09-29 by Ashutosh (AI-assisted) · **Version:** 1.0

Rebuilding the Patient 360 chart for the **Front Desk** role against the Narzim
design, screen by screen. This document records what was built, what was
deliberately not built, and what is left — so the next person picking this up
does not have to re-derive any of it.

**Scope:** the front-desk view only. Nurse, doctor and admin views of the same
screen are untouched and are not covered here.

---

## 1. Where the design lives

| | |
|---|---|
| Project | **Narzim EHR** — `claude.ai/design/p/e5b92eb1-ae6c-4761-b326-1f6c3d74c417` |
| File | `Patients.dc.html` — the `isChart` branch is Patient 360 |
| Front-desk config | the `role === 'frontdesk'` block, around line 528 |
| Read via | the `DesignSync` tool (`get_file`), not a screenshot |

**Read the source, not a picture of it.** The design is plain HTML with inline
CSS, so every measurement is a declaration you can copy exactly —
`padding:13px 16px`, `border-radius:var(--radius-xl)`, `font:700 14px/1.2`.
Measuring a screenshot is strictly worse.

**But also open it rendered.** Two things are only visible that way, and both
changed the build:

- Switching `roleNurse` and `roleDoctor` **off** in the canvas drops the design
  from 8 tabs to 6 and removes the `More ▾` button. That is the only way to see
  what reception *alone* gets — the extra tabs after the divider belong to the
  user's *other* roles, not to front desk.
- It exposed that two of our tab labels were **swapped** relative to the design
  (§6). No amount of source-reading would have shown that.

The rendered canvas is cross-origin, so its computed styles cannot be read and
its internal tab state cannot be driven by a click from outside. The source
covers the first; for the second, click the tab in the canvas by hand.

---

## 2. Design tokens

Ported from the design's `tokens/*.css` into `src/app/globals.css`, **scoped to
a `.nz-design` class — never `:root`**.

Several token names (`--radius-md`, `--border-default`, `--font-sans`) already
mean something else in this app's Tailwind/shadcn layer. On `:root` they would
silently restyle every existing screen. Scoped, they change nothing until an
element opts in, which is what makes porting one screen at a time safe.

**`--font-sans` is deliberately NOT ported.** The design specifies Manrope; this
app replaced it with Inter, and `layout.tsx` records why — Inter disambiguates
`1/l/I` at small sizes, and a misread digit is a dosing event, not a cosmetic
slip. The type *scale* is ported; only the face differs.

### Two Tailwind traps that cost real time

Both produce **silently missing styles** that pass `tsc`, pass the test suite,
and pass a Tailwind compile check — because all three only prove a class
*exists*, never that it *paints*.

```
text-[var(--x)]            ambiguous: colour or font-size → use text-[color:var(--x)]
border-[var(--x)]          ambiguous: colour or width     → use border-[color:var(--x)]
shadow-[var(--x)]          compiles to --tw-shadow inside Tailwind's composed
                           chain and computed to rgba(0,0,0,0) 0 0 0 0
                           → use [box-shadow:var(--x)]
```

And the classic one, hit first: **`font: 700 14px/1.2 inherit` is invalid CSS.**
`inherit` is not a valid family inside the `font` shorthand, so the browser drops
the *entire* declaration — every size, weight and line-height disappears at once.
Set them as separate properties.

---

## 3. What was built

### 3.1 Header

Matches the design's `isChart` header exactly (`14px 24px`, gap 16, avatar 46px
round):

```
‹  ⬤  Khalid Kashmiri  [B+]  24 yrs · Male  [Desk task · opened from Patients]  ● Active  [Edit]
      MRN MRN-2026-0000035 · CURP … · +52 6738921991 · khalid@gmail.com · Patient since 2026
                                                        [ Book appointment ]  [ Check out ]
```

- Name `800 19px/1.2 −.01em`, blood badge `h20 · 0 7px · r6 · --crit-bg`
- Identity line `500 11.5px --ink-400`, mono values `--ink-600`, 3px `--ink-200`
  dot separators
- Actions `h36 · 0 14px · --nz-radius-md · 700 13px`; Check out is `--teal-500`
- **Context pill** `h22 · 0 9px · r999 · --teal-200 / --teal-50 / --teal-700`

**What the header replaced.** The previous strip rendered each fact as a
labelled cell (icon + label above, value below). That was a deliberate fix for
an unreadable run-on line and it worked — but the design puts identity on one
line and spends the saved height on the alert chips and KPI band above the tabs.
Every fact the cells showed is still there.

**The context pill is a label, not a control.** In the design it is a dropdown
that reopens the chart under another role the user holds, with the note
*"Changes the layout only. Your access stays the same."* It renders **without a
chevron for a single-role user** — confirmed by switching the other roles off in
the canvas. And `role-context.tsx` records that *"role switching now happens by
changing Frappe roles, not in the UI"*. A pill with a chevron that opens nothing
would promise a feature this app deliberately removed. When the switcher is
built, it attaches here. The source half reads `?from=`, the same parameter the
design reads, and is omitted when nothing set it.

**`Book appointment` replaced the breadcrumb's `New Appointment`** on this screen
only (`showPrimaryAction={false}`). Both called `openNewAppointment(patient)` —
the same pre-filled modal, twice on one screen. The design separates them by
*scope*: its top bar books for anyone, the patient header books for this patient.

### 3.2 Alert chips + KPI band

Sits **between the header and the tab strip**, so it stays visible on every tab.

- Chips `h26 · 0 10px · r999 · 7px gap · 6px dot · 700 11.5px` — Allergy (crit),
  Unread message (ok), Profile incomplete (warn)
- Band `grid auto-fit minmax(170px,1fr)`, tile `12px 24px · gap 7`, rules by
  `inset box-shadow` not borders — that is what makes the dividers seamless
- Label `700 10px uppercase .08em --ink-400`; value `800 19px −.01em tabular-nums`
- Four tiles: **Next visit · Balance · Insurance · Profile**
- Balance and Insurance carry the design's `˅` and open the Billing tab

**The unread chip reads real data.** It was previously an `unreadCount` **prop
that no call site ever passed** — it defaulted to `0`, so the chip could never
appear regardless of what the patient sent. It now sums unread across both
channels this app has (WhatsApp + patient portal; the design has one Messages
concept, we have two).

### 3.3 Overview tab

Three cards, `grid auto-fill minmax(340px,1fr) · gap 14 · align-items:start`.

**`auto-fill`, not `auto-fit`, and not `xl:grid-cols-3`.** Three fixed columns
stretched the cards to fill a 1790px row — 580px each — which marooned every
value at the far right of its own card. `auto-fill` keeps the empty tracks, so a
card stays ~340px and the row simply ends. And without `align-items:start`, grid
stretches every card to the height of the tallest.

| Card | Contents |
|---|---|
| **Today** | Status · Appointment — both from the real next visit |
| **To complete profile** | one row per gap, `Complete →` opens the edit sheet |
| **Contact** | Email · Mobile · Address · Emergency contact · Policy (when on file) |

The third card is titled **"Contact"** and becomes **"Contact & insurance"** only
when a policy exists — a heading must not promise a section the record cannot
fill.

### 3.4 Appointments tab

Three wide cards of design rows.

```
Upcoming                                          Book appointment →
  28 SEP   General consultation            5:31 PM  [Confirmed]  ⋯
           HLC-APP-2026-00320 · Doctor carloz · fever
Missed          N no-show(s) to follow up
Past
  28 SEP   General consultation            4:16 PM  [Cancelled]  ⋯
```

The design has **Upcoming + Missed** and states past visits live in Timeline. A
third **Past** card was added deliberately: nothing in this app moves settled
visits to Timeline automatically, so following the design exactly would have
removed them from the one place a receptionist looks.

**Bucketing is by what the desk does next, not by date.** An appointment earlier
today that nobody closed is still *Upcoming*, because it is still the desk's to
close. Only settled-and-past lands in Past. No-shows always go to Missed.

The `All / Appointments / Encounters` segmented control was removed — the cards
*are* the filter, and encounters now always render alongside appointments (what
the old "All" segment did). The status dropdown is kept.

### 3.5 Billing tab

Two wide cards.

- **Account** — `stats` body, `grid auto-fill minmax(118px,1fr) · gap 8`, stat
  `10px 12px · r10`, label `700 9.5px uppercase .07em`, value `800 18px tabular`
- **Invoices** — design rows: `40px` date block, title, sub-line, amount, badge, `⋯`

**The four coloured icon tiles were removed.** In the design a tint *means*
something — `warn` tints the block, `ok` colours only the value. Four decorative
colours assigned one per card carry no meaning and compete with the one that
does. Only Outstanding tints now, and only above zero.

**Nothing was lost from the nine-column table.** Provider, Paid, Payment method
and Balance fold into the sub-line the way the design already folds detail
(`INV-2026-418 · GNP 80 % · patient 20 %`); Status is the badge; both row actions
moved to the `⋯` menu; pagination is untouched. Empty parts are **omitted**, not
dashed — the design's sub-line is a sentence, not a set of slots.

### 3.6 Edit sheet — "Complete →"

The card lists five gaps; the sheet must be able to fill all five. Two could not:

- **Emergency contact was gated on `isMinor`.** The card said *"Emergency contact
  — Missing"* for every adult while the only editor for it stayed hidden — the
  app asked for something it gave no way to supply. Now ungated. The heading
  adapts because the obligation does: **Guardian** for a minor (legally
  required), **Emergency contact** for an adult. One record, one fieldset.
- **Photo had no control in the sheet at all.** The only way in was clicking the
  avatar in the chart header, which nothing pointed at. The sheet now has a photo
  row that opens the **existing** `PatientPhotoDialog` rather than a second
  capture implementation.

> The photo dialog uploads immediately, so a photo saves on upload rather than on
> **Save changes**. That is the existing dialog's behaviour, left unchanged.

### 3.7 Tabs

Order and labels now match the design's front-desk strip:

```
design   Overview · Messages · 1 · Appointments · Billing · Documents · Timeline
ours     Overview · WhatsApp Chat · Portal Chat · Appointments · Billing · Documents · Timeline · Family
```

Strip geometry: `gap 22px · h42 · padding 0 2px`, active underline is the
button's **own 2px bottom border** — so it spans exactly the label. Padding each
tab by 14px and drawing an inset bar is what made ours read as a boxed tab bar
instead of the design's underlined words.

Display order lives in a new `TAB_ORDER` list, deliberately separate from
`SECTION_ORDER`: sections decide which component renders and which permission
gate applies, so moving a sub-tab between them to fix the strip would change
behaviour too. An unranked key sorts to the end rather than disappearing.

### 3.8 Permissions

`chart-permissions.ts`, `frontdesk` — narrowed to match the design and PHI-6
(minimum necessary):

```
encounters · vitals · orders · medications · conditions · history · immunizations   hidden
documents                                                                           full
showClinicalStats false · showAllergyAlert true · showRiskBanner false · showAiInsights false
```

**Immunizations was hidden on 2026-09-28**, reversing an earlier decision to keep
it `readonly`. The justification for keeping it was wrong: it attributed the
`readonly` to an operational need, but that setting came from commit `2d6ac7bd`
(Anant Sharma, 14 Sep), whose subject is that reception must not **write** a
vaccine record. It never argued reception should **read** one. Three things then
point the same way — the design gives front desk six tabs and this is not one,
PHI-6 makes clinical data hidden-by-default, and it was the odd one out
(reception cannot see vitals, conditions, medications or history). *If the
paediatric desk really needs the vaccination card, that is a print need and
`documents` is already `full`.*

**The Zoomo / Patient Intelligence rail is hidden for reception.** It answers
questions about labs, medications, history and vitals — the exact four things
marked `hidden` above, and the exact four the disclosure line promises stay with
doctors and nurses. Leaving it mounted made that line false.

### 3.9 Shared components created

One definition each, on purpose — two copies of a card is how the four list
tables drifted apart on eight dimensions before `list-table.ts` was written.

| File | Holds |
|---|---|
| `patient-chart/nz-card.tsx` | `NzCard` · `NzStats` · `NzRow` · `NzRowsEmpty` |
| `patient-chart/reception-model.ts` | `profileGaps` · `pickNextVisit` · `fmtTime` |
| `hooks/use-patient-balance.ts` | the one balance derivation |
| `patients/patients-table-chrome.ts` | the Patients **list** table chrome (a documented fork of `list-table.ts`) |

---

## 4. Backend changes

Two, both **exposure gaps rather than schema gaps** — the fields already existed
and simply were not returned.

| Change | File |
|---|---|
| `creation` added to the patient payload — backs *"Patient since 2026"* | `api/v1/patients/api.py` |
| `get_patient_insurance_coverage(patient)` — new whitelisted endpoint | `api/v1/insurance/api.py` |

`Patient Insurance Policy` carries only the payor and policy number; the
percentages live on **`Patient Insurance Coverage`** (`coverage`, `discount`,
`price_list_rate`, `patient_payable`, `mode_of_approval`), one doctype further
out. `Patient Appointment.insurance_coverage` links that row and our appointments
API returns the link — **as a name only**, so the browser got an id it could not
resolve.

PHI-6 applied: the endpoint returns the money split and the amounts, and **not**
`code_value` / `item_eligibility` / `template_dt`. A receptionist collecting a
co-pay needs the amount, not the coded clinical reason the insurer priced it.
Permission-checked and PHI-audited like the policy endpoint beside it. Cancelled
and Rejected rows are excluded — a desk told "80 % covered" by a rejected row
collects the wrong amount.

> **Testing note that cost an hour.** Frappe answers *any* unauthenticated call
> to a `@frappe.whitelist()` method with `"is not whitelisted"`. A `curl` with no
> session will always say that, including for endpoints in daily use. Verify with
> a session, or directly:
> `cd sites && python -c "import frappe; frappe.init(site='…'); frappe.connect(); …"`

---

## 5. Bugs found and fixed along the way

All four share one root cause: **fields read off the `Patient` TYPE without
checking they are on the `get_patient` PAYLOAD.** They are on the type because it
is shared with the queue and dashboard, where they *are* populated.

| Symptom | Cause |
|---|---|
| `Next visit: No visit today · Active` for a patient with three appointments that day | `patient.time` / `patient.pract` absent; `patient.status` is the **patient record** status |
| `Balance: 0 · all settled` for a patient owing 400 | `patient.billing` is **not on the payload at all** |
| `Today: Status Active · Appointment —` | same three fields |
| Profile tile said 3 gaps, the card listed 1 | two separate lists — 8 fields vs 4 |

`patient.activity` is not a substitute: on 2026-09-28 at 20:36 it returned the
17:31 appointment — three hours past — because it selects by date without
comparing time. **That is a live backend bug and anything else reading that field
inherits it.**

Also fixed: the invoice number printed twice (real invoices carry `remarks: ""`,
so the title fell back to the number that the sub-line already opened with); and
`Sep 7, 20…` truncating in a 118px stat track at `800 18px`.

---

## 6. Two tab labels were swapped

| Key | Was | Now | Shows |
|---|---|---|---|
| `appointments` | "Timeline" | **"Appointments"** | the appointments/encounters worklist |
| `activity` | "Activity" | **"Timeline"** | the chronological feed |

A tab called *Timeline* was showing appointments. Anyone moving between the
design and the app read the wrong tab. Spanish moved with it (`Citas`,
`Cronología`). Keys and routes unchanged.

---

## 7. NOT DONE — three tabs

These have design cards that were never built. **This is the remaining
front-desk work.**

### 7.1 Messages

```js
msgs: [C('WhatsApp & SMS with ' + first, 'thread', thread, {
  wide: true,
  sub: 'Clinical messages are routed to the doctor',
  act: ['Open in Messages', …],
  compose,
})]
```

One wide card holding a WhatsApp/SMS thread with an inline composer. We have
**WhatsApp Chat** and **Portal Chat** as two separate tabs, in no card, with no
sub-line and no action.

**Take this one first.** The sub-line *"Clinical messages are routed to the
doctor"* is a PHI boundary stated in the UI, not decoration — it is the only one
of the three where the gap is more than presentation.

### 7.2 Documents

```js
docs: [C('Documents & IDs', 'rows', docs, { wide: true, act: ['Upload', …] })]
```

One wide rows card with an `Upload →` action. Ours is a chip bar
(`All / Lab Reports / Imaging / Prescriptions / Consents / Other`) plus a search
box and a bare empty state, in no card. Ours also has type filters the design
does not — the same shape of decision already taken on Appointments.

### 7.3 Timeline

```js
timeline: [C('Timeline', 'rows', activity.concat(…), {
  wide: true,
  sub: 'Visits, messages, payments and paperwork · newest first',
})]
```

One wide rows card, newest first, mixing visits, messages, payments and
paperwork. Ours is a purpose-built chronological feed with type chips, date
grouping and left-rail timestamps.

**Largest divergence, and the one where ours may genuinely be better.** Worth
deciding rather than converting reflexively.

---

## 8. NOT DONE — other

### 8.1 Insurance rows (parked)

The endpoint is built and verified; the UI was parked deliberately. Four design
rows are waiting on it:

| Row | Source |
|---|---|
| `Coverage · 80 % consult · 20 % co-pay` | `coverage` / derived `patient_share` |
| `Est. co-pay · $290 · 20 % of $1,450` | `patient_payable` / `price_list_rate` |
| `At checkout · Collect co-pay` | derived |
| `Pre-auth · Not required for OPD` | `mode_of_approval` → `preauth_required` |

### 8.2 Not buildable without a schema change

| Design element | Verified absent |
|---|---|
| Token `A-07` | Every field on `Patient Appointment` was checked. Only `position_in_queue` is token-like; there is no token field |
| Insurance `verified 24 Sep` | `Patient Insurance Policy` has `date` and `policy_expiry_date`, **no verification date**. We show `valid to <expiry>`, which is a real fact |

### 8.3 Wired but unpopulated

`position_in_queue` (on the appointment, returned by our API) reads `0` for every
row; `insurance_payor` / `insurance_coverage` / `coverage_status` on the
appointment read `null`. The plumbing exists, the data does not — a different and
smaller problem than "missing".

### 8.4 Open question

**All ~10 appointment actions now sit behind `⋯`**, including **Check in** and
**Move to Waiting Room** — the desk's most frequent action, on every patient. It
was built this way by decision, and the design's rows carry no action controls at
all. Pulling the single primary action back inline is a small change if it proves
slow in use.

---

## 9. Files touched

**Frontend** (`EB_Healthcare_EHR`)

```
new  src/components/narzim/patient-chart/nz-card.tsx
new  src/components/narzim/patient-chart/reception-band.tsx
new  src/components/narzim/patient-chart/reception-model.ts
new  src/components/narzim/patient-chart/reception-overview.tsx
new  src/components/narzim/patients/patients-table-chrome.ts
new  src/hooks/use-patient-balance.ts
     src/app/globals.css                                    design tokens, .nz-design
     src/app/(clinic)/patients/[id]/patient-chart-client.tsx header, pill, actions
     src/app/(clinic)/patients/patients-client.tsx           list table chrome
     src/components/narzim/patient-chart/patient-screen.tsx  tab strip, TAB_ORDER, rail gate
     src/components/narzim/patient-chart/overview-tab.tsx    reception branch
     src/components/narzim/patient-chart/appointments-tab.tsx three cards, design rows
     src/components/narzim/patient-chart/billing-tab.tsx     Account + Invoices
     src/components/narzim/patient-chart/edit-patient-sheet.tsx photo + emergency contact
     src/lib/narzim/chart-permissions.ts                     frontdesk narrowing
     src/types/patients.ts                                   creation
     messages/en.json · messages/es.json                     ~70 keys, parity verified
```

**Backend** (`remedisys_healthcare_ai`)

```
     remedisys_healthcare_ai/api/v1/patients/api.py     creation in _serialize_patient
     remedisys_healthcare_ai/api/v1/insurance/api.py    get_patient_insurance_coverage
     CHANGELOG.md · WORK_LOG.md
```

**Verification at time of writing:** `tsc` clean · 630 tests / 36 files passing ·
no new lint errors · en/es key parity. Header, chips, KPI band, cards, tab strip,
Billing and Appointments were each confirmed in the browser by reading
`getComputedStyle` on the live page, not by eye.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-29 | Ashutosh (AI-assisted) | Initial record of the front-desk Patient 360 redesign: what was built, the decisions behind it, the bugs found, and the three tabs still outstanding |
