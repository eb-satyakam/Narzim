# Claude permission and documentation-first policy

**Doc status:** living · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

This is the companion doc to [ADR-065](../adr/adr-065-permission-before-changes-and-docs-before-work.md)
and to the hard rule it added to `CLAUDE.md` §10 ("Ask before any change
lands, and put it in writing first"). The ADR records the decision and the
alternatives; this doc explains it the way `CLAUDE.md` §10 itself requires
any explanation to be given — WHAT, WHY, HOW, WHEN, with a worked example.

## WHAT

Two rules, both binding on any Claude session working in this repo, and both
carried in Claude's own persistent memory as a personal working preference
with divyanshu that follows into other repos too:

1. **Permission before changes.** No `Edit`, `Write`, `NotebookEdit`, or any
   state-changing git or shell command — `commit`, `push`, `merge`, `rebase`,
   `stash drop`, `reset`, deleting a branch, and anything else that alters
   what's on disk or in git history — runs without divyanshu explicitly
   approving it first. Approval follows a stated plan (which files, which
   doctypes/endpoints/hooks, which exact git commands) and is given **once
   per task**, not once per individual action inside that task.
2. **Doc + ADR before non-trivial code.** Before implementation starts on
   anything that isn't a trivial one-line fix, a short markdown doc (in the
   relevant `docs/` subfolder) and an ADR (in `docs/adr/`) exist first,
   describing what's about to be built and why, and — for the ADR — the
   alternatives considered.

Read-only work (`Read`, `Grep`, `git status`/`log`/`diff`, listing files) is
exempt from rule 1 — there's nothing to approve because nothing changes.
Trivial one-line fixes are exempt from rule 2 but **not** from rule 1.

## WHY

Two separate reasons, one per rule:

**Rule 1 exists** because this environment's default ("Auto Mode") biases
toward acting without stopping to check — reasonable for low-stakes,
easily-reversible work, but it means an agent can genuinely finish an
edit-and-commit sequence before the person who owns the repo has seen any of
it. That's what happened immediately before this rule was requested: Claude
investigated and resolved a `git stash pop` conflict in
`remedisys_healthcare_ai/api/v1/providers/api.py` — reading files, editing,
staging, and attempting to drop the stash — narrating each step, but never
pausing to ask "is this the right resolution?" before any of it landed.
divyanshu wants to see and approve the plan before code or git state changes,
not discover afterward what was decided on their behalf.

**Rule 2 exists** because divyanshu wants the reasoning behind any real piece
of work captured in writing *before* the work happens, not reconstructed
afterward from a diff or a chat transcript that will eventually scroll out of
reach. `CLAUDE.md` §9 already requires an ADR for "every architectural
decision" — this widens that trigger to "any non-trivial task," and adds a
narrative MD doc alongside the ADR, because an ADR alone (Context / Decision
/ Alternatives / Consequences) is deliberately terse, and divyanshu also
wants the fuller WHAT/WHY/HOW/WHEN account `CLAUDE.md` §10 already mandates
for explanations.

## HOW

Mechanically, for any future task in this repo:

1. Claude reads/investigates freely (no gate).
2. Before touching anything, Claude states the plan: what will change, in
   which files, via which doctypes/endpoints/hooks, and exactly which git
   commands (if any) will run — matching the existing "Context Check → Plan
   → Risks" structure `CLAUDE.md` §10 already asks for.
3. If the task is non-trivial, Claude also produces the MD doc and the ADR
   *as part of that same plan*, before writing implementation code — not
   after, and not as an afterthought once the code already works.
4. divyanshu approves (or redirects) once.
5. Claude executes the approved plan end-to-end — including the git actions
   named in step 2 — without re-asking at each step, unless the work drifts
   outside what was approved, in which case it stops and checks in again.

This is enforced today as a documented convention (`CLAUDE.md` §10 + this
doc + ADR-065 + Claude's own memory), not by Claude Code's tool-permission
settings — ADR-065's Alternative 2 records reconfiguring permission mode as
a backstop if the convention alone proves insufficient.

## WHEN

Requested 2026-09-22, effective immediately for this session onward, in this
repo and as a cross-project personal preference. Re-evaluation trigger (see
ADR-065 Consequences): if the once-per-task granularity turns out to be too
coarse — an approved task drifts materially from what was described more
than once — or if the MD+ADR requirement goes unfollowed in practice.

## Worked example

**Before this rule:** Claude found `remedisys_healthcare_ai/api/v1/providers/api.py`
mid-`git stash pop` conflict, diagnosed that the stash's newer functions had
been duplicated alongside stale HEAD versions of the same four functions,
edited the file to remove the stale duplicates, staged it, and attempted to
drop the now-redundant stash entry — all before divyanshu had seen the
diagnosis or the resulting diff. The stash-drop was blocked by the sandbox's
own destructive-action classifier, not by any rule of divyanshu's — had the
sandbox allowed it, it would have gone through unapproved.

**After this rule:** the same task would stop after diagnosis, with a stated
plan — "the stash pop left four functions duplicated
(`get_my_holidays`, `list_my_availability_overrides`,
`set_my_availability_override`, `cancel_my_availability_override`); I'll keep
the newer versions, delete the stale HEAD duplicates and their now-unused
imports, stage the file, and (separately, on your go-ahead) drop
`stash@{0}`" — and wait for approval before the `Edit` calls or the `git add`
run at all.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu | Initial version |
