# Configurable Notifications — making the Settings screen actually do something

**Doc status:** living · **Created:** 2026-09-24 by Ashutosh (AI-assisted) · **Updated:** 2026-09-24 by Ashutosh (AI-assisted) · **Version:** 2.0

> **BUILT 2026-09-24.** This was a plan; the backend is now implemented and the doctype, the cron and
> the five events exist. §10 records what building it turned up — three bugs that only appeared when
> the code was actually run, one of them a live user-facing defect that predates this work.
>
> ⚠️ **All three settings are currently `Disabled` on `mysite.localhost`.** Turn them on from
> Settings → Notifications when you are ready; the job does nothing until you do.
>
> **Read this first if you only read one line:** the Settings → Notifications screen saves your
> choices correctly, and **nothing in the system ever reads them**. It is a working form attached to
> nothing.

---

## 1. What we checked, and what we found

Settings → System → **Notifications** has four dropdowns: Appointment reminders, No-show alerts, Lab
result notifications, Payment reminders.

We traced each one from the screen all the way down to the database and back. Here is the honest
result.

| Step | Works? | Evidence |
|---|---|---|
| The screen shows the dropdowns | ✅ | `src/components/settings/preferences-section.tsx` |
| Your choice is sent to the server | ✅ | `useUpdateClinicSettings` |
| The server saves it | ✅ | `EB Clinic Settings` doctype has all four fields |
| The server gives it back on reload | ✅ | `api/v1/admin/settings.py:397-400` |
| **Anything reads it and acts on it** | ❌ | **Nothing. Anywhere.** |

The four field names are `appointment_reminder_timing`, `no_show_alert_timing`,
`lab_result_notification` and `payment_reminder_timing`. Searching the whole backend for those names
returns **only** the doctype that defines them, the default values, and the settings API that reads
and writes them. No other code mentions them.

**So: the screen is real, the saving is real, the effect is imaginary.** If you set "1h before" today,
nothing changes — because nothing sends appointment reminders at all.

### 1.1 Why nothing happens — the three missing pieces

**(a) There is no clock.** Sending something "24 hours before an appointment" needs a job that wakes
up on a timer, looks for appointments coming up, and sends. The app registers five scheduled jobs and
none of them is about reminders:

```
sweep_orphan_sessions        (every 15 min — AI sessions)
run_access_review            (weekly — compliance)
ai_template_edit_session     (cleanup)
ai_source_cache              (cleanup)
run_consent_lifecycle        (consent expiry)
```

**(b) WhatsApp messages are triggered by changes, not by time.** The WhatsApp sender
(`integrations/whatsapp/notifications.py::process_notifications`) is hooked to `after_insert`,
`on_update`, `on_submit` — it runs *when a document is saved*. That is the right design for "your
appointment is confirmed", and it physically cannot do "24 hours before", because nothing saves the
appointment 24 hours before.

**(c) Nothing decides a patient is a no-show.** "No Show" is a real appointment status, but the code
only ever *reads* it — for reports and filters. No code ever *sets* it. Someone has to mark it by
hand. So a "no-show alert after 15 minutes" has nothing to alert on.

**And labs never notify at all** — there is no notification call anywhere in the lab code.

---

## 2. What we want instead

Three settings that genuinely work, and one removed.

The screen keeps **one** control per row: *when* to send. **Who receives it is fixed** — it follows
from what the notification is, not from a preference.

| Setting | When (the configurable part) | Who always receives it | Default |
|---|---|---|---|
| **Appointment reminders** | 24h / 12h / 1h before · Disabled | the patient | 24h before |
| **No-show alerts** | After 15 / 30 / 60 min · Disabled | **front desk *and* the patient** | After 15 min |
| **Lab result notifications** | Immediate / Hourly / Daily · Disabled | the patient *and* the ordering practitioner | Immediate |
| ~~Payment reminders~~ | **Remove from the screen.** See §6 | — | — |

"Disabled" switches the whole row off, for everyone on it. That is the only off switch, and it is
enough: a clinic that does not want no-show alerts turns no-show alerts off.

### 2.1 Why there is no "send to" choice

An earlier draft of this plan gave each row a second dropdown for recipients. That was wrong, and it
is worth recording why so nobody re-proposes it:

- **The recipient is not a preference, it is the definition.** A no-show matters to the front desk
  because a slot is empty, and to the patient because they missed care. Those are not two options to
  choose between — both are simply true. A dropdown implies a real choice exists.
- **Every option would be a way to break it.** "Front desk only" means the patient is never told they
  missed an appointment. "Patient only" means the clinic stares at an empty chair. Neither is a state
  anyone should be able to reach by accident.
- **It doubles the surface for no benefit.** Two more fields, two more dropdowns, two more states to
  test — and the honest default is "everyone who needs to know" in every case.

If a specific clinic ever needs one of these suppressed, that is a request with a reason behind it and
should be designed then. Pre-building it as an empty dropdown is exactly how this screen reached its
current state.

### 2.2 The no-show message is not one message

Sending no-show to both audiences does **not** mean sending them the same thing:

| Reader | What they need to hear | Why |
|---|---|---|
| Front desk | "Nina Martinez has not arrived — 15 min past 14:30 with Dr Carloz" | An operational prompt: call them, or release the slot |
| Patient | "It looks like you missed your appointment — tap to rebook" | An apology-shaped nudge with an action |

Same trigger, two different sentences, two different links, two different apps. That is why §4.1 gives
them **separate event keys** rather than one key with two recipients — exactly the reasoning
`EVENT_TYPES` already records for `appointment_cancelled` versus `appointment_cancelled_by_patient`.

⚠️ **Tone is the real risk.** A patient who is 20 minutes late in traffic and walking through the door
should not get "you missed your appointment" on their phone. Since the patient always receives it, the
safeguard has to be in the *timing* — see §5, decision 3b.

---

## 3. How it will work, in plain terms

One job that wakes up **every 5 minutes** and asks three simple questions.

```
        every 5 minutes
              │
              ▼
   ┌──────────────────────────────┐
   │  Read the clinic's settings  │  when: 24h before / After 15 min / Immediate
   │  (the WHEN for each row)     │  (recipients are fixed — §2.1)
   └──────────┬───────────────────┘
              │
     ┌────────┴──────────┬────────────────────┐
     ▼                   ▼                    ▼
 Reminders           No-shows             Lab results
     │                   │                    │
 "starts in ~24h    "past start by 15+    "verified since I
  and not yet        min and still         last looked, and
  reminded?"         'Scheduled'?"         not yet sent?"
     │                   │                    │
     ▼                   ▼                    ▼
  notify()        ┌──────┴──────┐      ┌──────┴──────┐
  the patient     ▼             ▼      ▼             ▼
              front desk     patient  patient    practitioner

Every arrow always fires. The only switch is the timing dropdown, and "Disabled"
stops the whole row — both arrows together.
```

Everything goes through `notify()`, the one function every notification in this system already passes
through. That gives us the bell, the live update and the push for free, and means we are not building
a second notification path that can drift from the first.

### 3.1 The "don't send it twice" rule

This is the part that matters most, because the job runs every 5 minutes and will see the same
appointment again and again.

Every appointment gets a small marker saying "the 24h reminder for this one has been sent". The job
skips anything already marked. Without this, a patient gets a reminder every 5 minutes for a day.

We do this with a **new small doctype**, `EB Notification Dispatch`, holding one row per
*(thing, kind of notification)* that has been sent — for example *(appointment HLC-APP-2026-00297, `appointment_no_show`)*. The event key is part
of the pair, so the front-desk alert and the patient's "you missed it" are tracked separately — one
can send while the other is switched off, and neither can block the other. A unique index on that pair means the database itself refuses a duplicate,
rather than us relying on the code remembering to check.

> **Why not a checkbox on the appointment?** Because there are three kinds of reminder and more will
> come, and each would need its own column on a core ERPNext doctype we are not supposed to be adding
> columns to. A separate log also tells us *when* something was sent, which is the first question
> anyone asks when a patient says "nobody told me".

### 3.2 Catching up after downtime

If the server is off for two hours, the job wakes up to a backlog. The rule: **send what is still
useful, skip what is not.** A reminder for an appointment that already started is not useful — it is
confusing. So each reminder has a window: send it if we are inside "the right time, up to 2 hours
late", otherwise mark it skipped and move on. We record the skip so nobody wonders later.

---

## 4. The work, step by step

Each step is useful on its own and can ship separately.

| # | Step | What it delivers |
|---|---|---|
| 1 | `EB Notification Dispatch` doctype + the "already sent?" helper | The safety net. Nothing user-visible yet |
| 2 | Register one scheduled job every 5 minutes | An empty heartbeat, proving the schedule runs on this site |
| 3 | **Appointment reminders** — read the setting, find due appointments, `notify()` the patient, record the dispatch | The first setting that really works |
| 4 | **No-show alerts** — find overdue arrivals, then `notify()` the front desk **and** the patient, as two separate events | The second |
| 5 | **Lab results** — `Immediate` on verification (`Lab Test.status` → `Approved`); `Hourly`/`Daily` batched by the same job. Patient **and** ordering practitioner | The third |
| 6 | Remove **Payment reminders** from the screen, and the field | The screen stops making a promise nothing keeps |
| 7 | Tests, and a line in `PUSH_NOTIFICATIONS.md` §4.5 for each new event | The docs stay true |

**Suggested order of value:** step 3 first. Appointment reminders are the setting people actually
expect to work, and no-shows drop when patients are reminded.

### 4.1 New notification events

Three new keys in `EVENT_TYPES`, following the existing naming:

Five new keys in `EVENT_TYPES`, following the existing naming. Five rather than three because two
of the three notifications have two audiences, and each audience reads a different sentence in a
different app:

| Event | Goes to | App | Setting that controls it |
|---|---|---|---|
| `appointment_reminder` | the patient | Portal | Appointment reminders |
| `appointment_no_show` | front desk + admin | EHR | No-show alerts (timing only) |
| `appointment_missed` | the patient | Portal | No-show alerts (timing only) — see §5 decision 3b |
| `lab_result_ready` | the patient | Portal | Lab results (timing only) |
| `lab_result_for_review` | the ordering practitioner | EHR | Lab results (timing only) |

`Lab Test` carries both `patient` and `practitioner`, so both recipients are resolvable from the
record itself — no extra lookup and no guessing.

⚠️ **Each also needs an entry in `services/push.py::_APP_FOR_EVENT`.** An event missing from that map
is silently never pushed — six existing events are in exactly that state today. This is the easiest
part of the job to forget.

Each also needs an icon and label in the EHR and portal so the notification renders properly.

---

## 5. Decisions we need before building

These change the work, so they are worth settling first.

1. **One clinic or many?** `EB Clinic Settings` is a single record for the whole site. If different
   clinics ever need different timings, that is a bigger change and should be decided now, not later.
2. **Which channel does a reminder use?** In-app only, or WhatsApp too? WhatsApp means a template
   approved by Meta for each message, which takes days and is a separate piece of work.
3. **Does a no-show alert also mark the appointment "No Show"?** Alerting is safe. *Changing the
   status automatically* affects billing and reports, and a patient who is 20 minutes late in traffic
   is not a no-show. **Recommendation: alert only, let a human set the status.**
3b. **Should the patient's "you missed it" wait longer than the front desk's alert?** This is now the
   *only* protection against the tone problem in §2.2, since the patient always receives it. They
   share one dropdown. Telling the front desk at 15 minutes is useful; telling the patient at 15
   minutes may reach someone parking the car. Options: one shared delay (simplest, occasionally
   rude), or a fixed extra delay on the patient half — e.g. always front desk + 15 min, no new
   control. **Recommendation: the fixed extra delay.**
3c. **Who receives a lab notification — is the ordering practitioner right?** The patient is
   obvious. The practitioner is my assumption, not your instruction: they ordered the test, so the
   result coming back is theirs to act on. Confirm, because it is fixed rather than configurable.
   Also: what happens when a lab has **no** ordering practitioner recorded — skip that half silently,
   or fall back to the front desk?
4. **"Immediate" for labs — how immediate?** Truly instant means notifying at the moment the result is
   verified (a document hook), not waiting up to 5 minutes for the job. That is a slightly different
   mechanism, and worth it.
5. **Who may change these settings?** Today the screen sits under Administration. Confirm it is admin
   only.

---

## 6. Why Payment reminders is being removed, not built

It is being taken off the screen rather than implemented, for three reasons:

- **It is not a clinical reminder.** The other three are about care. This one is about money, and it
  belongs with Billing, next to invoices and outstanding balances — not in a clinical notifications
  panel.
- **The options do not describe a reminder.** "At checkout" is not a reminder; it is something that
  happens while the patient is standing there. The dropdown mixes two different ideas.
- **Nobody has asked for it.** Building an unrequested money-chasing message to patients is the kind
  of thing that should start from a request, not from an empty dropdown that happens to exist.

Removal means: take it out of `preferences-section.tsx`, and drop `payment_reminder_timing` from the
doctype and the settings API. Removing a field needs a migration patch, and per **FE-12** dead code is
not deleted without approval — so this step needs an explicit yes.

---

## 7. Risks, plainly

| Risk | Why it matters | What we do about it |
|---|---|---|
| **Duplicate messages** | A patient reminded every 5 minutes for a day. The single worst outcome here | The unique index in §3.1 — the database refuses the second one |
| **Messaging the wrong person** | A reminder is PHI — it says someone has an appointment | Reuse `notify()`, which already resolves recipients and honours preferences. Do not hand-roll a recipient list |
| **A fixed recipient does not exist on the record** | A lab with no ordering practitioner, or an appointment whose patient has no portal user, delivers silently nothing | Resolve recipients first; if a half is empty, record a dispatch row marked *skipped, no recipient*. Silence must leave evidence — this is §5 decision 3c |
| **Telling a patient they missed an appointment they are walking into** | The one message here that can read as an accusation, and it is no longer suppressible per clinic | §5 decision 3b — a fixed extra delay on the patient half. If that is not enough, the answer is a better delay, not a dropdown |
| **A lab notification that leaks the result** | "Your result is ready" is fine; the value is PHI | The payload is already IDs-only by contract (`PUSH_NOTIFICATIONS.md` §4.3). Do not add the result to `params` |
| **The scheduler is not running** | Everything silently does nothing, and it looks like it works | Step 2 exists precisely to prove the schedule runs before anything depends on it |
| **Timezone mistakes** | "24h before" computed in the wrong zone sends at 3am | Do the arithmetic the way `resolve_report_window()` already does, in the site's timezone, with tests |
| **Settings changed mid-flight** | Someone switches 24h → 1h while reminders are pending | Read the setting at send time, not at schedule time. The dispatch log makes the behaviour inspectable |
| **A test run messages real patients** | This bench has no test site; the suites write to the live database | Guard every sender with `frappe.in_test`, and test the *decision* functions as pure functions with no database |

---

## 8. How we will know it works

- Set reminders to "1h before", book an appointment 90 minutes out, wait — the patient gets exactly
  one notification, about an hour before.
- Run the job by hand five times in a row. Still exactly one notification.
- Set it to "Disabled". Nothing is sent, and a dispatch row records that it was skipped and why.
- Mark the same appointment in two tabs at once. One row, not two — the database index proves it.

---

## 10. What building it turned up

Four things that no amount of reading would have found. Each was caught by running the code.

**1. `EB Clinic Settings` is not a Single.** It is one record *per company*, named after the company
(`api/v1/admin/settings.py::_get_or_create_settings`). The first version of the job called
`frappe.get_single()`, got `DoesNotExistError`, and every feature silently stayed off. This also
settles §5 decision 1: the system is already multi-clinic, so the job iterates companies and every
query is scoped by `company`.

**2. The screen offered values the doctype rejected — a live bug, older than this work.** The Select
options and the dropdowns had never matched:

| Field | Doctype allowed | Screen offered | Overlap |
|---|---|---|---|
| `appointment_reminder_timing` | 24h before · 2h before · Off | 24h / 12h / 1h before · Disabled | **1 of 4** |
| `no_show_alert_timing` | Immediate · After 15 min · After 30 min · Off | After 15/30 min · After 1h · Disabled | 2 of 4 |
| `lab_result_notification` | Immediate · Daily Summary · Off | Immediate · Hourly · Daily · Disabled | **1 of 4** |
| `payment_reminder_timing` | At checkout · After 3/7 days · Off | At checkout · 1 hour after · 24h after · Disabled | **1 of 4** |

`update_clinic_settings` does no validation of its own, so Frappe's Select check threw: **choosing
"12h before" and pressing Save produced a ValidationError, not a saved setting.** The doctype has been
aligned to the screen, and `patches/v0/align_clinic_notification_options_20260924.py` maps the legacy
values for any site holding them.

**3. `notify()`'s async path would have dropped most of the notifications.** Its own `force_sync`
docstring records that a background job enqueued after any document write in the same call silently
delivers nothing. This job writes a dispatch row per item, so from the *second* item in any loop the
fan-out would vanish — no error, no failed job, no row. Observed exactly that here: dispatch row
written, `Notification Log` row absent. Every `notify()` in the job now passes `force_sync=True`,
which costs nothing on a cron with no user waiting.

**4. `Open` is a real "has not arrived" status, and omitting it made the feature dead.** The first
no-show filter used `Scheduled`/`Confirmed`. The Healthcare controller sets a new appointment to
`Open`, so a probe 40 minutes past its start matched nothing. The filter is now
`Scheduled`/`Open`/`Confirmed` — `Checked In`/`Checked Out` mean they arrived, and `No Show` is
excluded so that a human marking the status cannot trigger the alert they were reacting to.

### 10.1 What is verified, and what is not

| | Status |
|---|---|
| Duplicate guard | **Proven.** Two inserts of the same pair: first `True`, second `False`, one row. The unique index rejected it at the database |
| Appointment reminders | **Proven end to end.** Probe appointment 55 min out, setting "1h before" → one dispatch row, one `Notification Log` row for the right user with `remedisys_event = appointment_reminder`. Ran twice: still one and one |
| Timing decisions | **17 unit tests**, no database. Includes the leap-year and Sunday-equivalent edges |
| No-show, both halves | **Not executed.** The query was confirmed to match (1 row) and recipients resolve (18 users), but creating a conforming probe fought `validate_overlaps`, and running it against the 15 real overdue appointments would have messaged 18 real staff |
| Lab results | **Not executed**, same reason |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-24 | Ashutosh (AI-assisted) | Built. §10 added: EB Clinic Settings is per-company not Single; the screen offered values the doctype rejected (live bug, now fixed + patched); notify()'s async path would have dropped most sends; `Open` is a no-show status. Status draft → living |
| 1.2 | 2026-09-24 | Ashutosh (AI-assisted) | Corrected: recipients are FIXED, not configurable — v1.1 misread "clinic can decide" as being about recipients when it was about timing. §2.1 records why a recipient dropdown is the wrong shape |
| 1.1 | 2026-09-24 | Ashutosh (AI-assisted) | No-show goes to front desk AND patient. Five events rather than three, because each audience reads a different sentence in a different app |
| 1.0 | 2026-09-24 | Ashutosh (AI-assisted) | Initial plan. Records that all four settings are saved but never read, and that no scheduler, no no-show detection and no lab notification exist |
