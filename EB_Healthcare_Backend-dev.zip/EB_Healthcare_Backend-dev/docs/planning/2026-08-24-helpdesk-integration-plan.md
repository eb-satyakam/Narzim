# Help & Support — Frappe Helpdesk integration plan

**Doc status:** living · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

> **Scope of this document.** How Remedisys creates support tickets in Frappe Helpdesk, and the
> work required to ship it. Helpdesk itself — what it is, its 36 doctypes, its licence, its
> feature set — is researched in
> [`2026-08-21-helpdesk-research-and-plan.md`](2026-08-21-helpdesk-research-and-plan.md); this
> document does not restate it. Installation state is owned by that document's §13. Project phase
> status is owned by [`docs/STATUS.md`](../STATUS.md).

---

## 1. Executive summary

**Remedisys can create native `HD Ticket` records with attachments, using a documented Helpdesk
endpoint, with zero customization of Helpdesk.** This was proven on `marley.local` on 2026-08-24 —
ticket `0003` exists, filed by a real EHR staff account, carrying a PNG, a PDF and a WebM voice
note. It is evidence, not a design sketch (§3).

| Question | Answer |
|---|---|
| Native ticket creation without custom doctypes? | **Yes** — `helpdesk...hd_ticket.api.new` |
| Custom Helpdesk doctype required? | **No** |
| Helpdesk source modification required? | **No** |
| Parallel Remedisys ticket table + sync? | **No — and it must not be built** |
| Attachments (png/jpg/pdf) | **Native**, two-step: upload → create |
| Voice note (webm/m4a/ogg) | **Native**, an ordinary attachment; no audio-specific work |
| Existing Remedisys auth reusable? | **Yes** — the ADR-011 Bearer JWT, unchanged |
| New role needed per staff user | **`HD Customer`**, one role, `desk_access = 0` |
| Customization verdict | **NONE** for the scoped requirement; **MINIMAL** only for structured EHR context (§8) |

Helpdesk remains the single source of truth for support tickets. Remedisys owns the entry point and
the context it attaches — nothing else.

**Not decided yet.** Four questions in §12 change the data model and must be answered before Phase 2
begins. Phase 1 is safe to build against any of the answers.

---

## 2. Requirement

Every EHR staff user gets a **Help & Support** entry point inside Remedisys, from which they can file
a support request without leaving the EHR or learning a second product.

```mermaid
flowchart TD
    EHR[Remedisys EHR] --> HS[Help & Support]
    HS --> CSR[Create Support Request]
    CSR --> S[Subject]
    CSR --> D[Description]
    CSR --> SC[Screenshot]
    CSR --> FA[File attachment]
    CSR --> VN[Voice note]
    CSR --> HD[Frappe Helpdesk]
    HD --> T[Native HD Ticket]
```

**USER STORY.** Dr. Bracamontes is mid-encounter when the prescription drawer stops saving. She
clicks **Help & Support**, types "Rx drawer will not save", records an 8-second voice note
describing what she clicked, pastes a screenshot, and submits → **the system shows** a ticket number
and a confirmation → **the database actually contains** a native `HD Ticket` with
`raised_by = her user`, `status = Open`, an SLA with `response_by` set, and three `File` rows
attached → **consequence:** the support agent opens `/helpdesk`, sees the screenshot and hears the
voice note, and never has to ask "what were you doing when it broke?". No second login, no email
thread, no Remedisys-side ticket table to reconcile.

---

## 3. Validated capability — evidence, 2026-08-24

Verified against the installed source and a live write on `marley.local`, not against
documentation. Anything not listed here was not tested.

| Fact | Evidence |
|---|---|
| Helpdesk `1.29.0`, Frappe `16.31.0` | `helpdesk.__version__`; `frappe.__version__` |
| `HD Ticket` has exactly **one** mandatory field: `subject` | `frappe.get_meta("HD Ticket")`, `reqd = 1` scan |
| Native creation endpoint | `helpdesk.helpdesk.doctype.hd_ticket.api.new(doc, attachments=[])` — the endpoint Helpdesk's **own** portal uses (`desk/src/pages/ticket/TicketNew.vue:253`) |
| Contact and customer are **not** required | `hd_ticket.py::set_customer` leaves `customer` empty when the contact has no linked HD Customer; it does not raise |
| Staff user **cannot** file a ticket without a Helpdesk role | `admin@narzim.com` (4 `EB_` roles) → `api.new` → `PermissionError` |
| `HD Customer` alone is sufficient | same user, role added → ticket `0003` created |
| `HD Customer.desk_access` | `0` — satisfies our Website-User rule |
| Attachments land on the ticket | 3 `File` rows with `attached_to_doctype = "HD Ticket"`, `attached_to_name = "0003"` |
| Audio needs no configuration | `voice-note.webm` accepted, `file_type = WEBM`; `System Settings.allowed_file_extensions` is empty → no extension restriction |
| Read isolation holds by default | own ticket `0003` readable; `0001` (another user's) → `PermissionError` |
| Portal Settings untouched by any of this | `default_role = 'Patient'`, `default_portal_home = None`, still 1 Version row |

**EXAMPLE — what the native defaults produced.** Ticket `0003` was created passing **only**
`subject` and `description`. Everything below was set by Helpdesk itself:

```
status      = 'Open'                    contact  = 'Admin'  (auto-resolved from the email)
priority    = 'Medium'                  customer = None     (not required, stayed empty)
sla         = 'Default'                 raised_by / owner = admin@narzim.com
response_by = 2026-08-25 14:51          resolution_by = 2026-08-27 14:51
via_customer_portal = 1                 opening_date = 2026-08-24
ticket_type = ''                        <- HD Settings.default_ticket_type is unset

Files attached to HD Ticket 0003:
  screenshot2e913f72b221.png | PNG  |  70 B | private=1
  examplea5ae35.pdf          | PDF  | 431 B | private=1
  voice-note.webm            | WEBM | 515 B | private=1
```

### 3.1 Two findings that change implementation

1. **Frappe parses every uploaded PDF.** `frappe/core/doctype/file/file.py:474` calls
   `pdf_contains_js`, which runs the file through `pypdf` to scan for embedded JavaScript. A
   malformed PDF is rejected at upload with `PdfReadError: startxref not found` — found the hard way
   while building the POC. Genuine PDFs pass. **Implication:** the UI must surface a readable
   "this PDF could not be read" message, not a 500.
2. **`max_file_size` is unset → 10 MB per file** (`frappe/utils/file_manager.py:212`). Not the 25 MB
   often assumed. **Implication:** voice notes must be recorded compressed (WebM/Opus), and the limit
   must be raised together with nginx `client_max_body_size` before this ships to `pre` (§10).

---

## 4. Architecture

```mermaid
flowchart TD
    U["Remedisys EHR staff user<br/>Website User + HD Customer"]
    UI["Help & Support UI<br/>subject · description · screenshot · file · voice"]
    BFF["Remedisys BFF<br/>POST /api/support/tickets<br/>multipart, reuses the user's Bearer JWT"]
    SVC["remedisys_healthcare_ai<br/>api/v1/support/api.py::create_support_ticket"]
    FILES["save_private_file → File rows<br/>created unattached"]
    NEW["helpdesk...hd_ticket.api.new<br/>doc + attachments"]
    T["Native HD Ticket<br/>source of truth"]
    C["Description Communication"]
    F["File rows re-parented<br/>png · pdf · webm"]
    SLA["Native SLA · status · priority"]
    AR["Native Assignment Rules → HD Team / Agent"]
    AGENT["Support agent in /helpdesk"]

    U --> UI --> BFF --> SVC
    SVC --> FILES
    FILES --> NEW
    SVC --> NEW
    NEW --> T
    T --> C --> F
    T --> F
    T --> SLA
    T --> AR
    T --> AGENT
```

**Why the integration layer sits in `api/v1/support/`, not in the BFF.** Three reasons, all
constitutional: locked assumption "custom whitelisted methods only — never `/api/resource/`"; the
context assembly and the PHI decisions of §9 are policy that belongs in the permission-checked
service layer, not in a Next.js route; and one backend method means one round trip from the browser
instead of an upload-then-create sequence the client has to keep consistent.

**What Remedisys owns:** the entry point, the context block, the file staging, and one whitelisted
method. **What Helpdesk owns:** the ticket, its numbering, status, SLA, priority, assignment,
notifications, agent UI, and the audit trail. There is no Remedisys-side ticket record, and there is
nothing to synchronise.

### 4.1 Approaches considered

Required by `CLAUDE.md` §10 — this decision is consequential and shapes a data model, so the
alternatives are written out rather than asserted.

| Approach | Pros | Cons |
|---|---|---|
| **A. Remedisys custom ticket doctype + sync to Helpdesk** | Full control of fields; works offline from Helpdesk | Two sources of truth; every field is a sync bug waiting; duplicates Helpdesk's SLA/assignment/notification engines; explicitly what the requirement forbids |
| **B. Direct `frappe.client.insert` on `HD Ticket` from the BFF** | No backend module to write | Bypasses `api.new`'s `raised_by`/`via_customer_portal`/attachment handling, so we would reimplement Helpdesk's own creation semantics and inherit none of its fixes; breaks the "no `/api/resource/`-style generic CRUD" lock |
| **C. Native `api.new` via a thin Remedisys service method** *(chosen)* | Uses Helpdesk's own portal path; SLA, status, priority, contact resolution and attachment re-parenting all come free; nothing to keep in sync; survives Helpdesk upgrades | One new role per staff user; context beyond native fields needs §8's decision |
| **D. Redirect / iframe the Helpdesk portal at `/helpdesk`** | Zero integration code | Second UI and second mental model for clinicians; cannot attach EHR context at all; Helpdesk's portal hijacks Portal Settings expectations (§10); loses the in-context screenshot and voice capture that is the entire point |

**Chosen: C.** B loses specifically because `api.new` is not a convenience wrapper — it sets
`raised_by` from the session, flags `via_customer_portal`, and drives the `after_insert` chain that
re-parents attachments onto the description `Communication`; reimplementing that is copying Helpdesk
internals into our app, which is the maintenance burden Rule 1 exists to prevent. A loses because it
inverts the stated requirement and creates a reconciliation surface with no owner. D loses because
the requirement is *in-context* support capture — a redirect throws away the screenshot, the voice
note and the route the user was on, which is the only thing that makes a support ticket actionable.

---

## 5. API contract

### 5.1 Backend — `api/v1/support/api.py`

```python
@frappe.whitelist()
@handle_api_errors
def create_support_ticket(subject: str, description: str, context: str | None = None) -> None:
    """Create a native Helpdesk HD Ticket for the logged-in staff user.

    Reads multipart 'file' parts (screenshot / attachment / voice note) from the
    request, stages them as private File rows, then hands both the ticket body and
    the file names to Helpdesk's own creation endpoint. Remedisys stores no ticket
    record of its own — HD Ticket is the source of truth.

    subject     — ticket subject (required; the ONLY field HD Ticket mandates)
    description — HTML body; the EHR context block is appended server-side
    context     — JSON: route, encounter, clinic, user_agent, captured_at
    """
```

- Staging uses the existing `utils.save_private_file()` helper, which already works around Frappe's
  cross-record content-hash dedup — a real problem here, because two users screenshotting the same
  screen produce byte-identical PNGs.
- Files are created **unattached**; `api.new`'s `after_insert` chain re-parents them to the
  description `Communication` and then to the ticket. Proven in §3.
- Returns `set_response(201, data={"ticket": name, "subject": ...})` — the standard envelope, so the
  frontend's existing error handling applies unchanged.

### 5.2 BFF — `POST /api/support/tickets`

`multipart/form-data`, forwarded straight through with the Bearer token, following the established
pattern of `src/app/api/labs/panel-upload/route.ts` (multipart cannot go through the JSON
`frappeFetch` helpers).

| Field | Type | Notes |
|---|---|---|
| `subject` | string | required |
| `description` | string | HTML from the editor |
| `context` | string | JSON blob assembled client-side (§8) |
| `file` | File × n | screenshot, attachments, voice note — all under one field name |

Response `201 { ticket: "0004" }`. Errors pass through the existing `frappeErrResponse` mapping, so
`417` validation messages reach the user as text rather than a generic 502.

### 5.3 Field mapping

| HD Ticket field | Source | Set by |
|---|---|---|
| `subject` | user | Remedisys |
| `description` | user + context block | Remedisys |
| `raised_by`, `owner` | session user | **Helpdesk** (`api.new`) |
| `contact` | resolved from email | **Helpdesk** |
| `status`, `priority`, `sla`, `response_by`, `resolution_by` | defaults + SLA | **Helpdesk** |
| `ticket_type` | `HD Settings.default_ticket_type` | **Helpdesk** — currently unset, see §10 |
| `agent_group`, assignment | Assignment Rules | **Helpdesk** |
| `customer` | §12 decision 1 | undecided |

We set three fields. Helpdesk sets the rest. That ratio is the point of this design.

---

## 6. Attachments

Two steps, because that is Helpdesk's own design:

1. **Stage** each file as a private `File` row → get its docname.
2. **Create** the ticket, passing `attachments=[{"name": …, "file_url": …}, …]`.

Both happen inside one whitelisted method, so the browser makes one request.

| Constraint | Value | Action |
|---|---|---|
| Extension restriction | none (`allowed_file_extensions` empty) | leave empty; enforce an allowlist in **our** method, not site-wide |
| Size limit | **10 MB per file** (`max_file_size` unset) | raise on `pre`/prod **with** nginx `client_max_body_size` |
| PDF | parsed by `pypdf` for embedded JS | surface a readable error (§3.1) |
| Privacy | `is_private = 1` | mandatory — support attachments may contain a screenshot of a patient chart |

**Screenshot privacy is a first-class concern, not a footnote.** A screenshot of the EHR is by
definition a screenshot of PHI. Every support attachment is private, and §9 governs who can see it.

---

## 7. Voice note

**No Helpdesk work at all.** The voice note is an ordinary attachment; §3 proved a `.webm` upload
needs zero configuration.

- **Recording** is the Remedisys frontend's job — `MediaRecorder`, `audio/webm;codecs=opus`, with
  `audio/mp4` as the Safari fallback.
- **No custom voice-note doctype.** Explicitly out of scope, permanently.
- **Compressed only.** Opus at ~24 kbps keeps a 3-minute note near 0.5 MB; the same note as raw
  `.wav` exceeds the 10 MB ceiling in under two minutes.
- **Cap the recording client-side** (suggested 3 minutes) so the failure is a friendly UI limit
  rather than a rejected upload.
- Deepgram is **not** involved. Transcribing support audio is a separate proposal with its own PHI
  question; do not conflate it with this.

---

## 8. EHR context

| Context | Native home | Custom field needed? |
|---|---|---|
| Staff user | `raised_by`, `owner`, `contact` | **No** |
| Timestamp | `creation`, `opening_date`, `opening_time` | **No** |
| Clinic | `HD Customer`, or `agent_group` (HD Team) | **No** — but see §12 decision 1 |
| Support category | `ticket_type`, `priority` | **No** |
| Coarse facets | native tags (`add_tag` / `_user_tags`) | **No** |
| **EHR route / page** | only inside `description` | **Yes**, for structured filtering |
| **Encounter ID** | only inside `description` | **Yes**, for a real link |
| **Browser / device** | only inside `description` | **Yes**, for structured filtering |

**The honest split:** everything needed to *route and attribute* a ticket is native. What needs a
custom field is *structured, queryable* diagnostics.

**Zero-customization interim — do this in Phase 1.** Append a context block to `description`, which
is a Text Editor field agents read as the first message:

```html
<hr><p><strong>Remedisys context</strong></p>
<ul>
  <li>Route: /encounters/HLC-ENC-2026-00144</li>
  <li>Clinic: Narzim</li>
  <li>Encounter: HLC-ENC-2026-00144</li>
  <li>App version: 2026.08.24 · Browser: Chrome 141 / macOS 15</li>
  <li>Captured: 2026-08-24 14:51 (America/Mexico_City)</li>
</ul>
```

You lose filtering, not information. If support later needs "every ticket from the encounter
screen", that is the moment to add Custom Fields — Frappe's own extension mechanism, and **not** a
Helpdesk fork or a parallel system.

---

## 9. Security, permissions and PHI

### 9.1 Permission model

- **One grant per staff user: `HD Customer`.** Proven sufficient (§3). `desk_access = 0`, so it
  cannot open the Desk — consistent with every `EB_` role.
- **`Agent` is not required to file a ticket**, so `Agent Manager` — which implies `System Manager`,
  and therefore read access to every patient record — stays unused. The §11 landmine in the research
  document is avoided rather than mitigated.
- `EB_` roles are untouched: 7 roles, none with `desk_access = 1`.

### 9.2 Read scope — the one thing that can leak

Non-agents are scoped by `get_customer_criteria` (`api.py:153`):

```
contact == user  OR  raised_by == user  OR  owner == user  OR  customer IN user's customers
```

With `customer` empty, each staff member sees only their own tickets — verified. **But the moment
"clinic" is modelled as an `HD Customer` and staff contacts are linked to it, every staff member can
read every colleague's support ticket in that clinic** — including its screenshots. For a clinic
admin that may be desirable; as a default it is a leak. This is §12 decision 1, and it must be
answered before Phase 2.

### 9.3 PHI

- Every attachment is private (`is_private = 1`). A support screenshot is a PHI screenshot.
- **Recommendation: carry identifiers, never content.** Encounter ID and clinic, never patient name,
  DOB, MRN or clinical text in the subject, description or context block.
- Helpdesk supports **email intake and notification**, which is a route by which ticket content can
  leave the estate. Confirm with §12 decision 4 before enabling any email account.
- Rule 10 applies unchanged: no PHI in logs. Log the ticket name, not the body.

---

## 10. Deployment

Nothing here ships until the following are true.

1. **`bench migrate` completes.** Same gate as
   [`docs/release/2026-08-24-pre-to-main.md`](../release/2026-08-24-pre-to-main.md) — Helpdesk added
   36 doctypes, and a partial migrate is an access-control problem, not only a feature problem.
2. **Restore Portal Settings after installing Helpdesk on any new site.** Verified behaviour, not a
   prediction: on `marley.local`, install at `19:33:30` set `default_role = "HD Customer"` and
   `default_portal_home = "/helpdesk"`; a human reverted both at `19:34:26`. The `Version` row is the
   evidence. Left un-reverted, **every patient portal login lands in the support console.** This
   revert currently exists only as a manual step in one person's memory — see §12 decision 3.
3. **Set `HD Settings.default_ticket_type`** — unset today, so tickets are created with
   `ticket_type = ''`.
4. **Raise `max_file_size` and nginx `client_max_body_size` together.** Either alone fails.
5. **Grant `HD Customer`** to staff users by the mechanism chosen in §12 decision 2.
6. **Do not enable an incoming email account** until §12 decision 4 is answered.

---

## 11. Implementation phases

Phase 1 is deliberately buildable under **any** answer to §12.

### Phase 1 — Minimum viable Help & Support

| # | Work item | Files |
|---|---|---|
| 1 | `create_support_ticket` whitelisted method | `api/v1/support/api.py` (new), `modules.txt` unchanged |
| 2 | Context-block renderer + attachment allowlist/size guard | `services/support.py` (new) |
| 3 | BFF route, multipart pass-through | `src/app/api/support/tickets/route.ts` (new) |
| 4 | Help & Support UI — subject, description, file/screenshot picker | `src/components/support/` (new) |
| 5 | Entry point in the app shell | existing nav component |
| 6 | i18n keys, `en` + `es-MX` in parity | `messages/en.json`, `messages/es.json` |
| 7 | Backend tests — creation, permission denial, attachment landing, PHI-free logging | `tests/support/test_support.py` (new) |
| 8 | `HD Settings.default_ticket_type`, ticket types, one clinic-shaped SLA | configuration, not code |

**Exit gate:** a staff user files a ticket with a screenshot from inside the EHR; it appears in
`/helpdesk` with the attachment and the context block; a second staff user cannot read it; no PHI in
logs.

### Phase 2 — Voice note

Recording UI, Opus encoding, Safari `audio/mp4` fallback, duration cap, and the "recording" consent
affordance. Backend needs **no change** — §3 already proved the attachment path.

**Exit gate:** an agent plays the note from the Helpdesk UI.

### Phase 3 — Structured context, only if §12 decision 3 says so

Custom Fields on `HD Ticket` for route / encounter / device, shipped as fixtures with a dated patch,
plus the corresponding Helpdesk list filters. **Not** a Helpdesk fork.

### Explicitly out of scope, permanently

- A Remedisys ticket doctype, or any parallel support store.
- Any modification to the Helpdesk app or an override of `HD Ticket`.
- Synchronisation logic of any kind.
- A custom voice-note doctype.
- Transcribing support audio.

---

## 12. Decisions required before Phase 2

| # | Decision | Why it blocks | Owner |
|---|---|---|---|
| 1 | **Ticket read scope** — isolate each staff member (leave `customer` empty), or model clinic-as-`HD Customer` so colleagues and admins see each other's tickets? | Changes the data model and the §9.2 exposure | gaurav (product) + Sarvesh (security) |
| 2 | **How staff get `HD Customer`** — a dated patch like `rebuild_eb_role_permissions`, a grant at user provisioning, or Helpdesk's own invite flow? | Determines whether existing staff are migrated or onboarded | Sarvesh |
| 3 | **EHR context** — description block only (zero customization), or Custom Fields for filterability? | Decides whether Phase 3 exists | gaurav |
| 4 | **Patient/encounter context and email intake** — carry the encounter ID, or nothing? Enable email intake at all? | PHI boundary; LFPDPPP | Sarvesh (security/compliance) |

A follow-up **ADR** should record the §4.1 architecture choice together with decisions 1 and 3 once
they are made. It is deliberately not written yet, and deliberately unnumbered here: citing a number
before the file exists is what `scripts/check_adr_numbering.py` fails on, and reserving a number for
an undecided question is how a plan starts masquerading as a decision record.

---

## 13. Test artefacts on `marley.local`

Created by the 2026-08-24 validation, on the developer site only. Reversible; delete when the POC is
no longer useful as a reference.

- `HD Ticket 0003` + 3 `File` rows (`screenshot*.png`, `example*.pdf`, `voice-note.webm`)
- `HD Customer` role granted to `admin@narzim.com`
- No code was written, no doctype created, no Helpdesk file touched, Portal Settings unchanged

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Created from the validated 2026-08-24 POC: native `api.new` path, attachment and voice findings, permission model, and the four open decisions |
