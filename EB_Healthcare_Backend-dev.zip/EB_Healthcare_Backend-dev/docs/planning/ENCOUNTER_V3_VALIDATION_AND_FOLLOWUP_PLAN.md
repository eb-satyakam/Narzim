# Encounter V3 — SOAP propagation, deferred follow-up, and signing validation

**Doc status:** draft · **Created:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-04 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.1

Implementation plan for four requirements raised on 2026-09-04. **No code has been written.**

| # | Requirement |
|---|---|
| 1 | Editing the SOAP and continuing populates step 3 — symptoms, diagnoses, medications, labs, procedures. Match-or-create. Doctor can edit or remove. Re-editing reconciles rather than duplicating |
| 2 | Keep the follow-up card. Prefill the interval from the Plan. **Do not create the ToDo until the encounter is Signed** |
| 3 | Remove the BEFORE YOU SIGN trio |
| 4 | Port V1's genuine mandatory validations into V3 and resolve the UI/server contradiction |

**Constraints given:** no additional AI request for the propagation; do not resurrect the dead
autopopulate route; the doctor must be able to edit or remove populated data before Sign.

---

## 0. Findings that change the requirements

Three things the investigation established that alter what needs building.

### 0.1 Requirement 1 is ~85% already implemented

`goToFillEncounter` (`encounter-flow.tsx:1454-1509`) is already a propagation trigger, not a
navigation. It reads the SOAP boxes as edited, skips the call when the text is byte-identical to the
last run, and otherwise re-extracts and applies.

| Sub-requirement | Status | Evidence |
|---|---|---|
| Symptoms populated from SOAP | **Built** | `applyExtraction` → `keepCreated(listItems("symptoms"), createComplaint)`, `encounter-flow.tsx:1178` |
| Match existing master or create | **Built** | `create_complaint` / `create_diagnosis`, `api/v1/encounters/api.py:1333-1384` — exact match, else insert |
| Diagnoses, same | **Built** | `encounter-flow.tsx:1179` |
| Labs / procedures from Plan | **Built** | catalog search first, `create_master` on miss, `encounter-flow.tsx:1191-1226` |
| Medications from Plan | **Built**, deliberately without master creation | `encounter-flow.tsx:1056-1061` — an extracted drug the physician deletes must not create a Medication master |
| Re-edit reconciles, no duplicates | **Built** | retract-then-append, `encounter-flow.tsx:1238-1295` |
| **Follow-up interval** | **Missing** | `prompts/note-extract-v1.txt:142-159` names five targets and forbids a sixth |
| **Doctor's removal survives re-extraction** | **Missing** | §0.3 |

The work in requirement 1 is therefore the follow-up target plus one real defect, not a new pipeline.

### 0.2 The constraint "no additional AI request" is already satisfied

`goToFillEncounter` makes exactly one extraction call today. Adding `followUp` as a sixth target to
`extract_note_structured` adds **a field to that same response**, not a second call. Net AI requests
per continue: unchanged.

The alternatives all violate the constraint or a design rule, which is why they are rejected in §2.1.

### 0.3 A real defect the requirements expose: deliberate removals are undone

Two of your requirements collide:

> *"Doctor must remain able to edit/remove populated data before Sign"*
> *"If SOAP is edited again, Step 3 should reconcile/update instead of creating duplicates"*

**Sequence:** AI extracts "fever". The doctor deletes that chip in step 3 — deliberately, because it
is wrong. Back to step 2, fixes a typo in the Plan, continues again. The SOAP still says "fever".
Extraction still returns "fever". Reconciliation sees it is absent and appends it.

**The deletion is silently undone.** The retract-then-append pass
(`encounter-flow.tsx:1238-1295`) tracks what the **AI added** (`lastExtract.current.added`), never
what the **doctor removed**. There is no record of a deliberate deletion.

This is not currently reported as a bug because re-continuing after a manual edit is uncommon. Your
requirement makes it the normal path. It needs a **dismissed set** — §2.2.

### 0.4 Requirement 4 contained a new product rule — since withdrawn

You listed diagnoses among "V1's mandatory validations". **V1 does not require a diagnosis and
neither does the server.** There is an explicit decision:

> `api/v1/encounters/api.py:1976` — *"Diagnosis/treatment plan are NOT required to sign — 2026-07-02 decision."*

Making diagnoses mandatory would have been a **new clinical policy** reversing a recorded decision,
not a port. Raised on 2026-09-04 and **withdrawn the same day** — diagnoses stay optional. §4.4.

### 0.5 A P0 defect found on the way, not requested

**V3 can fail to sign and show nothing.** Independent of all four requirements, and it should ship
first. Full detail in §5.

---

## 1. Architecture: how the follow-up becomes deferred

### 1.1 The problem your requirement creates

`buildSaveDraftPayload` (`encounter-screen.tsx:103-150`) sends:

```
chief_complaint · hpi · plan · education · diagnoses · symptoms
drug_prescription · lab_test_prescription · procedure_prescription
```

**There is no follow-up field in it.** The follow-up has never been part of the encounter draft. It
exists only as a Frappe `ToDo`, created by its own separate call — `submitFollowUp`
(`encounter-screen.tsx:302`) → `book_follow_up` (`api/v1/encounters/api.py:2316`).

**Correction, verified 2026-09-04: V3 already creates the ToDo only at Sign.** Requirement 2's
headline ask is already satisfied. There are exactly three creation paths, and none of them is a
draft save:

| Path | Trigger | Note |
|---|---|---|
| `afterSign` safety net (`encounter-flow.tsx:1423-1445`) | "Sign & finish" succeeds, and `followUpStatus === "editing"` | The **only** path that books a *new* follow-up |
| "Update follow-up" button (`encounter-screen.tsx:5853-5867`) | Clicked | Rendered **only** when one is already booked (`:6012`) |
| Chat tool `add_follow_up` (`encounter-flow.tsx:2234-2264`) | Physician asks in chat | Sets state only; **does not persist**. Relies on the first path |

V1's `saveDraftOnly` does book on draft save (`encounter-screen.tsx:1563-1567`). **V3 has no
equivalent block** — confirmed, `submitFollowUp` never appears in `use-encounter-save.ts`.

**So the real gap is not "stop persisting early". It is that the value does not survive a reload.**

> The doctor sees "3 days" prefilled at step 3. They get called away, come back, reload. The mount
> effect (`encounter-flow.tsx:183-198`) calls `getFollowUp`, finds no ToDo — because none was ever
> booked — and sets `followUpStatus("none")`, **discarding what the doctor saw**.

Requirement 2 is therefore **"persist the intent without creating the task"**, and only the *persist*
half is missing. That is still an architecture change, because the payload has nowhere to put it.

### 1.2 Options

| | Approach | Pros | Cons |
|---|---|---|---|
| A | Keep it in React state only | Zero backend work. Trivially satisfies "not persisted until Sign" | **Silent data loss on reload.** The doctor is shown a value the system will not remember. Worse than today |
| B | Create the ToDo early but inactive (`status = "Cancelled"`), activate at Sign | Reuses `book_follow_up` | Writes rows for encounters never signed. Pollutes the Front Desk queue's source table. "Cancelled" would mean two different things |
| C | Add a `follow_up` block to `save_draft`, stored in the existing SOAP blob; **create the ToDo server-side inside `complete_encounter`** | Survives reload. **Atomic with signing** — one request, cannot half-succeed. Mirrors the existing pattern exactly: `_create_encounter_immunizations` is already called from `complete_encounter` (`api.py:2053`) for the same reason | Backend change to `save_draft` and `complete_encounter`. Blob schema grows |
| D | New custom field or child table on Patient Encounter for the pending follow-up | Explicit, queryable | A doctype change plus a migration patch (§9) for one integer and two optional strings. Disproportionate |

### 1.3 Decision: **C**

**Why the others lose specifically.**

**A** shows the doctor a value it does not keep. A clinical interval that silently disappears on
reload is a worse failure than today's behaviour, where at least the ToDo exists.

**B** puts rows in `ToDo` for encounters that may never be signed, and overloads `status =
"Cancelled"` to mean both "the doctor cancelled it" and "not yet real". The Front Desk queue reads
that table.

**D** is a schema change with a migration patch for three values that fit in a blob the encounter
already stores.

**C** additionally fixes something the requirement did not ask for: doing the write **server-side
inside `complete_encounter`** makes ToDo creation atomic with the signature. A client-side
"sign, then book" is two calls that can half-fail — leaving a signed encounter with no follow-up and
nobody aware. The vaccine-immunization path already solved this the same way.

**What would falsify C:** if the SOAP blob has a size or schema constraint that a follow-up block
breaks. `_parse_soap` / `encounter_comment` should be checked before building.

### 1.4 Shape

```
Step 2  extract_note_structured  ──► followUp: {days: 3}
                                       │
Step 3  applyExtraction ───────────────┘
          enc.orders.followUp.in = "3d"        (visible, editable, removable)
          followUpStatus = "editing"
                                       │
        save_draft  ◄──────────────────┘        NEW: carries follow_up intent
          (survives reload — no ToDo yet)
                                       │
        complete_encounter ◄───────────┘        NEW: creates the ToDo here, atomically
```

**There is no way to cancel a booked follow-up.** `book_follow_up` is create-or-update only, with no
cancel or delete branch (`api.py:2318-2432`); the API client exposes only `getFollowUp` and
`bookFollowUp` (`src/lib/api/encounters.ts:169-177`); and the UI's Cancel button only resets React
state (`encounter-screen.tsx:6023-6039`). Deferring creation to Sign makes this *less* pressing —
before signing there is nothing to cancel — but it remains true after signing, and is worth its own
ticket.

Removal must be explicit: an absent follow-up and a doctor-deleted follow-up have to be
distinguishable in the payload, or a deletion will look like "unchanged" and the old intent will
persist. Send an explicit cleared marker, matching `save_draft`'s existing contract — *"omit to
leave untouched, pass `[]` to clear"* (`encounter-screen.tsx:110-117`), which exists because omitting
a key on removal left stale rows forever (found 2026-07-25).

---

## 2. Architecture: propagation and reconciliation

### 2.1 Follow-up extraction — options

| | Approach | Verdict |
|---|---|---|
| A | Regex the Plan text for "follow up in N days" | **Reject.** Brittle in a bilingual product. "in 3 days or sooner if symptoms worsen", "seguimiento en 3 días", "review after 72 hours". A parser that is right most of the time on a clinical interval is worse than none |
| B | Relax Lane B's prompt so it re-raises a documented follow-up | **Reject.** Lane B exists to surface what is *missing* (`copilot-consider-v1.txt:59-70`). Making it echo what is present destroys the distinction between the lanes and risks it re-raising other documented items. It is also a second AI call — violates your constraint |
| **C** | **Sixth target on `extract_note_structured`** | **Chosen.** Same call, same review path, same verbatim-sourcing rule. Zero extra AI requests |
| D | Dedicated follow-up endpoint | **Reject.** A second LLM call and a second prompt to maintain, for one integer, against a note the existing call already reads. Violates your constraint |

**Shape:** target `followUp`, value `{"days": <int>}`, sourced verbatim under the prompt's existing
no-inference rule — a Plan with no interval yields nothing. New prompt version
`note-extract-v2.txt`; the version is recorded in `AI Prompt Log` per §9 and the v1 file stays.

**Mapping:** `daysToFollowUpKey(days)` → `enc.orders.followUp.in`, `followUpStatus("editing")`.
`onAddConsideration` (`encounter-flow.tsx:1349-1374`) already does exactly this, so `applyExtraction`
reuses it rather than reimplementing.

**Unmappable intervals:** `FU_IN` keys are `3d/1w/2w/1mo/3mo/6mo`. "10 days" matches none.
**Recommend leaving unset rather than rounding** — silently changing a clinical interval is worse
than not filling it. There is precedent: a prior bug wrote a raw day count into `followUp.in`, no
`<option>` matched, and `FU_IN[...] ?? 7` silently booked **7 days** (`encounter-screen.tsx:368-370`).

**TYPE and ASSIGN TO** are not in the Plan text and are not filled. Only `IN`.

### 2.2 The dismissed set — making removal stick

The defect in §0.3 needs a record of deliberate removal.

| | Approach | Pros | Cons |
|---|---|---|---|
| A | Session-scoped ref alongside `lastExtract` | Matches the existing mechanism's scope exactly. No backend change | Lost on reload. After a reload `lastExtract` is null too, so a full re-extract re-adds the removed item |
| B | Persist the dismissed set in the draft, alongside the follow-up intent (§1.3) | Removal survives reload and a next-day return | More payload; needs a reset rule |
| C | Do not re-add anything not present in `enc`, ever | Trivial | Breaks reconciliation — a genuinely new symptom from an edited SOAP would never appear |

**Recommend A first, B if reload-loss proves painful in use.** A fixes the common case — edit,
continue, edit, continue within one sitting — with no backend surface. B is strictly better and can
be added later without rework, because the storage location is the same blob §1.3 already
introduces.

**Be explicit about A's limit:** after a page reload, a removed-but-still-in-the-SOAP item comes
back. That must be stated in the ticket, not discovered.

**Reset rule (either option):** a dismissal is keyed to the item, and clears when the doctor adds
that item back by hand. Editing the SOAP does **not** clear it — the doctor removed it knowing what
the note said.

---

## 3. Removing the BEFORE YOU SIGN trio

The three cards are `fill-step.tsx:325-355`. The request is to delete them, and the investigation
supports it for stronger reasons than presentation:

1. **"Blocks signing (N)" cannot report a chief complaint.** `N` derives from `noNurse` alone
   (`fill-step.tsx:267,328-337`). The line *"Nothing. The server also requires a chief complaint"* is
   static prose with no live check behind it. The card claims nothing blocks signing while naming
   something that does.
2. **"Not recorded (N)" is stale.** It reads `data.missing`, computed from the last-fetched server
   record (`use-encounter-v3.ts:112-142,224`), not from the screen. Step 2 already fixed this — it
   uses `liveMissing`, recomputed each render (`encounter-flow.tsx:1689-1725`), introduced precisely
   because the stale list kept announcing "Chief complaint" as missing after the AI had filled it.
   Step 3 never received the fix. **The doctor can fill the chief complaint and watch the card keep
   saying it is missing.**

**Hard sequencing constraint.** These cards are the only thing in step 3 that says anything about
readiness. Delete them before §4 lands and the doctor gets **no signal at all** — strictly worse than
a misleading one. Replacement first, removal second, **same release**.

**Exact removal:** the whole `<section>` at `fill-step.tsx:325-355`.

**Becomes unused, remove with it:**
- the `cn` import (`fill-step.tsx:26`) — its only use in the file is line 328
- `SectionHeading` from the `./chrome` import (`:36`) — used once, at line 326. **Keep `Card`**, used 7 more times

**Do NOT remove:**
- `noNurse` (`:267`) — still used at `:416` for `vaxNurseInvalid`
- `EncounterV3Data.missing` (`use-encounter-v3.ts:81,112-142,224`) — step 2's banner still falls back to it (`steps.tsx:1329`). Only the two references *inside* `fill-step.tsx` (`:340,343`) go

**One test breaks and must be updated:** `e2e/copilot-fill-extraction.spec.ts:276` asserts
`getByText("You are attesting")` as its proxy for "Fill Encounter was reached". That string only
exists in the card being deleted. It needs a different anchor.

`e2e/copilot-soap-generation.spec.ts:322` asserts *"Not recorded on this encounter (2)"* — that is
**step 2's** banner (`steps.tsx:1361`), a different component. It does **not** break.

---

## 4. Validation

### 4.1 What V1 genuinely enforces

| Validation | V1 | V3 | Gap |
|---|---|---|---|
| Chief complaint **or ≥1 symptom** | Blocking, client-side, with scroll + focus (`encounter-screen.tsx:1489-1501`) | **No client check** — `canSign` has no such term (`encounter-flow.tsx:1746`) | **Downgraded to server-only** |
| Practitioner role to sign | Blocking — a non-practitioner is shown "Save draft" (`app/(clinic)/encounters/[id]/page.tsx:79`) | **No gate.** `canWrite = !readOnly` only (`encounter-flow.tsx:225`) | **Missing** |
| Cancel-encounter confirmation | Present (`encounter-screen.tsx:2210-2244`) | Absent — zero matches in `v3/` | **Missing feature** |
| Vaccine nurse per row | Blocking, checked twice | Blocking (`encounter-flow.tsx:1746`) | Parity |
| Follow-up two-button trap | Present | Ported (`encounter-flow.tsx:1423-1436`) | Parity — **but §1 changes it** |
| Rx dropped when `dosage_form`/`period` empty | Silent | Silent, shared code | Parity — silent in both, own ticket |
| Diagnosis / treatment plan required | **No** | **No** | Parity, and deliberate (§0.4) |
| Allergy / interaction checks | Absent | Absent | Parity |
| Vitals bounds block the save | **No** — silently dropped (`encounter-screen.tsx:1325`) | **Yes** (`use-encounter-save.ts:296-309`) | **V3 better** |
| Vitals history warnings shown | Not shown | Shown (`fill-step.tsx:285`) | **V3 better** |

**Three real gaps.** V3 is not broadly weaker; it is weaker in exactly three places, and stricter in
two.

### 4.2 Chief complaint (P1)

Mirror the server rule exactly, because the server derives one from the other:

```
enc.symptoms.length > 0 || enc.chiefComplaint.trim()
```

`_derive_chief_complaint_if_missing` (`api.py:151-177`) synthesises a chief complaint from up to
three symptom rows **during save**. That is why V1's condition is a disjunction, and why a
symptoms-only encounter must be signable.

- Add the term to `canSign` (`encounter-flow.tsx:1746`) so the button is disabled.
- Re-check in the sign handler, so reaching it another way still stops (V1 checks twice for the
  vaccine nurse, for the same reason).
- Port V1's UX: scroll to the field, focus it, mark it invalid. A greyed-out button whose reason is
  elsewhere on the page is not an explanation.
- **Feed it from `liveMissing`**, which already computes this live. Do not create a second source of
  truth for "what is missing".

### 4.3 Practitioner role gate (P2)

Port `isPractitionerRole && !!user?.practitioner?.name` from `page.tsx:79`. A nurse sees **Save
draft**, not a Sign button that cannot work.

This matters more with §5 unfixed: today a nurse pressing Sign gets the silent nothing.

### 4.4 Diagnoses — **NOT mandatory. Closed 2026-09-04.**

The original request listed diagnoses among "V1's mandatory validations". They are not: V1 does not
require one, and neither does the server (`api/v1/encounters/api.py:1976`, the 2026-07-02 decision).

**Confirmed by the requester on 2026-09-04: do not make diagnoses mandatory.** The 2026-07-02
decision stands, no ADR is needed, and nothing changes here. Recorded so this is not re-raised as a
gap by the next reader.

The same applies to the treatment plan, which that decision covers in the same sentence.

### 4.5 Resolving the UI/server contradiction

After §4.2 there is exactly one rule — `symptoms || chiefComplaint` — computed from live state,
enforced client-side, and matching `api.py:2000-2012` server-side. Both step 2 and step 3 read the
same `liveMissing`. The static prose *"The server also requires a chief complaint"* disappears with
the cards, because it is then true and enforced rather than announced.

---

## 5. P0 — the silent sign failure (not requested, ship first)

Click **Sign & finish**, the server rejects, **the screen does not change.** No error, no spinner.
Click again, same silence.

| Step | Code | Effect |
|---|---|---|
| Server rejects | `api/v1/encounters/api.py:2000-2012` | ValidationError |
| Error stored | `use-encounter-save.ts:394-399` | `signer.error` set |
| Failure returns early | `encounter-flow.tsx:1838` — `if (!ok) return;` | **`previewing` never reset to `false`** |
| Component stays in first return | `encounter-flow.tsx:1784-1847` | report overlay still mounted |
| Error rendered in the **second** return | `encounter-flow.tsx:1966-1970` | **never reached** |

`SignedReportOverlay` takes no `error` or `loading` prop (`encounter-report.tsx:99-125`); its Sign
button has no state tied to `signer.signing` (`:334-347`); there is no toast in `encounter-flow.tsx`.

V1 has the same shape (`encounter-screen.tsx:1471-1476`) but it is **latent**, because V1's client
checks stop the common rejections first. V3 removed those checks, so in V3 this is the ordinary path.

**Fix:** reset `previewing` on the failure path so the existing banner is reached, **and** pass
`error` / `signing` into the overlay so the message appears where the click happened.

---

## 6. Sequencing

| Order | Item | Depends on |
|---|---|---|
| 1 | **P0 silent sign failure** (§5) | Nothing. Ship alone, today |
| 2 | Chief complaint check (§4.2) | — |
| 3 | Practitioner role gate (§4.3) | — |
| 4 | **Remove BEFORE YOU SIGN** (§3) | **2 and 3 must be in the same release** |
| 5 | Follow-up: `save_draft` + `complete_encounter` carry and create (§1) | Backend first, then frontend |
| 6 | Follow-up extraction target (§2.1) | 5 — prefill is pointless if it is not persisted |
| 7 | Dismissed set (§2.2) | — |
| 8 | Cancel confirmation | A product decision |

~~Diagnoses mandatory~~ — dropped 2026-09-04, see §4.4. Not a gap.

Items 2–4 are one release. Item 5 is backend-then-frontend, and the backend must deploy first — the
2026-09-04 incident in this repo was exactly that ordering failure.

---

## 7. Edge cases

**Propagation**
1. Doctor removes an AI item, edits SOAP, continues → must stay removed (§2.2). After reload it
   returns under option A — a stated limitation.
2. Doctor hand-types an item the AI later extracts with different wording → two rows. Dedupe is
   case-insensitive string match only (`encounter-flow.tsx:1259`).
3. Extraction returns a name whose master creation fails → dropped and surfaced via `extractError`
   (`:1148-1161`), never written. Correct, because one unmatched Link fails the entire encounter save
   — incident `HLC-ENC-2026-00656`.
4. Doctor edits SOAP to remove a diagnosis → retract-then-append must remove the chip.
5. SOAP unchanged → no AI call at all (`:1456-1459`). Confirm the follow-up still prefills from the
   previous result rather than silently doing nothing.
6. Empty Assessment → no diagnoses. Prompt rule, must survive the v2 prompt.

**Follow-up**
7. Doctor deletes the prefilled follow-up before signing → **no ToDo may be created**. Needs the
   explicit cleared marker (§1.4).
8. Doctor edits 3 days → 1 week → the signed ToDo must carry 1 week.
9. Sign fails after the follow-up intent is saved → no orphan ToDo. Server-side creation makes this
   structural.
10. Encounter saved as draft, never signed → no ToDo, ever.
11. Plan says "10 days" → unmappable, leave unset (§2.1). Never round.
12. Plan has no interval → no prefill, card stays empty.
13. An already-booked follow-up from a prior session, then re-sign → must not double-book.
14. Sign fails **after** `doc.submit()` but during ToDo creation → does Frappe roll the submit back?
    The equivalent claim for vaccines (`api.py:2051-2052`) is **UNVERIFIED**. Must be tested here.

**Validation**
15. Symptoms present, chief complaint empty → **must be signable** (server derives it).
16. Both empty → blocked client-side, with focus.
17. Chief complaint typed then cleared → block must re-apply live.
18. Nurse opens an encounter → sees Save draft, no Sign.
19. Vaccine row with no nurse → still blocking; must not regress when the cards go.

---

## 8. Tests

**Backend** (`remedisys_healthcare_ai/tests/`)
- `save_draft` accepts and persists a follow-up intent; round-trips through `get_encounter`.
- Cleared marker removes a stored intent; an omitted key leaves it untouched.
- `complete_encounter` creates exactly one ToDo from a stored intent, with the right date and
  assignee.
- No intent → no ToDo.
- Signing twice → no duplicate ToDo.
- A ToDo-creation failure rolls back the sign (edge case 14 — the untested claim).
- `create_complaint` / `create_diagnosis` remain idempotent (regression).
- Chief-complaint gate still throws for empty symptoms **and** empty chief complaint; passes with
  symptoms only.

**Prompt / extraction**
- `note-extract-v2` emits `followUp` only when the Plan states an interval.
- No interval → no `followUp` key.
- Spanish Plan text → same behaviour.
- The five existing targets are unchanged by the v2 prompt (regression against v1 fixtures).

**Frontend** (vitest, `environment: "node"` — pure functions only; there is no React testing library)
- `daysToFollowUpKey` for each `FU_IN` key, plus unmappable values → unset, never rounded.
- The dismissed-set reducer: removed item is not re-added on re-extract; re-added by hand clears the
  dismissal.
- Reconciliation: edited diagnosis replaces rather than duplicates.
- The chief-complaint predicate: symptoms-only passes, both-empty fails, whitespace-only fails.

Follow the pattern used for ADR-059: where a rule matters, extract it as a pure function so it can be
tested without adding jsdom and `@testing-library/react`.

**Manual, against the local bench**
- Full loop: record → SOAP → edit → continue → verify step 3 → remove an item → edit SOAP → continue
  → confirm it stays removed.
- Reload before signing → follow-up interval survives.
- Sign → exactly one ToDo appears in the Front Desk queue.

---

## 9. Open decisions

1. Dismissed set: session-scoped (A) or persisted (B)? §2.2. **Recommend A first.**
2. Unmappable interval: leave unset or round? §2.1. **Recommend unset.**
3. Should V3 offer cancel-encounter at all?
4. Does a failure after `doc.submit()` roll the sign back? Edge case 14, currently UNVERIFIED.

**Closed:** diagnoses mandatory — **no**, confirmed 2026-09-04 (§4.4).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.1 | 2026-09-04 | Sarvesh-SocialAngel (AI-assisted) | Diagnoses confirmed NOT mandatory; §4.4 closed, dropped from sequencing and open decisions |
| 2.0 | 2026-09-04 | Sarvesh-SocialAngel (AI-assisted) | Rewritten as an implementation plan: deferred follow-up architecture (save_draft intent + server-side creation at sign), dismissed set, edge cases, test plan |
| 1.0 | 2026-09-04 | Sarvesh-SocialAngel (AI-assisted) | Initial analysis |
