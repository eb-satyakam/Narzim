# Frappe Helpdesk — research and Remedisys implementation plan

**Doc status:** draft · **Created:** 2026-08-21 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.1

> Research done against the **official repository and docs only**, on 2026-08-21.
> Sources: [github.com/frappe/helpdesk](https://github.com/frappe/helpdesk) (v1.29.0,
> released 2026-08-05, AGPL-3.0) and [docs.frappe.io/helpdesk](https://docs.frappe.io/helpdesk).
> Frappe Framework facts were verified against **our own installed source**,
> `apps/frappe` at **v16.31.0**, not against documentation.
>
> Nothing here is assumed. Every capability is labelled:
> **[NATIVE]** Frappe Helpdesk · **[FRAMEWORK]** Frappe itself ·
> **[CUSTOM]** we must build it · **[EXTERNAL]** needs a third-party service.

---

> **Superseded for integration decisions (2026-08-24).** How Remedisys actually creates tickets —
> the endpoint, the permission model, attachments, voice, and the work plan — is owned by
> [`2026-08-24-helpdesk-integration-plan.md`](2026-08-24-helpdesk-integration-plan.md), written
> against a validated POC. This document remains the **research** record: what Helpdesk is, what it
> ships, and what the install looked like on 2026-08-21. Where the two differ, the plan wins.

## 1. Executive summary

Frappe Helpdesk is a real, actively maintained ticketing product. It gives us
tickets, SLAs, teams, auto-assignment, a knowledge base, email replies, a
customer portal and a feedback rating **out of the box**. Installing it is a
day's work, not a project.

The interesting question is not *"can it do tickets"* — it can. It is
**how much of it we expose to doctors**, and **what a screen recording of a
clinical screen means for patient data**.

Three conclusions drive everything below.

**One — do not send doctors to the Helpdesk portal.** Helpdesk ships its own
customer portal at `/helpdesk`. It is a separate Vue app with its own look, its
own login and its own navigation. Dropping a doctor into it mid-consultation
breaks the product. We should build a small **"Report a Problem"** form inside
Remedisys and create the ticket through the Helpdesk API. We already have the
right place to put it: the app has a route-aware Help drawer
(`src/components/help/help-drawer.tsx`).

**Two — screen recording is the hard part, and it is not a Helpdesk problem.**
Helpdesk accepts any file Frappe accepts. But Frappe's default limit is
**10 MB** (`max_file_size`, verified in `frappe/utils/file_manager.py:212`), and a
minute of screen recording is comfortably larger. This needs a deliberate
decision about size, storage and — more importantly — about a doctor
accidentally recording a patient's chart.

**Three — screenshots and recordings of Remedisys contain patient data by
default.** This is the single biggest risk in the whole feature. A support agent
looking at a bug report would be looking at a real patient's record. This needs
answering before we build, not after.

**Recommendation:** install Helpdesk, build a thin native form, ship screenshots
first, and treat screen recording as its own phase with its own decision.

---

## 2. What is Frappe Helpdesk?

A ticket management app built by Frappe Technologies. In plain terms:

- A **customer** (in our case, a doctor or clinic user) raises a ticket.
- An **agent** (our support team) picks it up, replies, and resolves it.
- An **SLA** measures whether we replied and resolved in time.
- A **knowledge base** lets users find the answer without raising a ticket.

It is two user interfaces over one database:

| Portal | Route | Who uses it |
|---|---|---|
| Agent portal | `/helpdesk` | our support team |
| Customer portal | `/helpdesk/my-tickets` | end users |

Both are Vue apps built with Frappe UI. They are **not** Frappe Desk (see §4).

**Key fact for us:** `hooks.py` declares `required_apps = ["telephony"]`. We
already have the `telephony` app in our bench, so this dependency is satisfied.

---

## 3. Official capabilities — verified

### 3.1 Doctypes that actually exist

Read directly from the repository (`helpdesk/helpdesk/doctype/`). This is the
real feature list, not a marketing page.

| Area | Doctypes | Meaning |
|---|---|---|
| Tickets | `HD Ticket`, `HD Ticket Activity`, `HD Ticket Comment` | ticket + history + internal notes |
| Classification | `HD Ticket Type`, `HD Ticket Status`, `HD Ticket Priority` | **all three are data, not code — fully configurable** |
| People | `HD Agent`, `HD Team`, `HD Team Member`, `HD Customer`, `HD Customer Member` | agents, teams, customer orgs |
| SLA | `HD Service Level Agreement`, `HD Service Level Priority`, `HD Service Day`, `HD Service Holiday List` | response/resolution targets, working hours, holidays |
| Knowledge base | `HD Article`, `HD Article Category`, `HD Article Feedback` | help articles |
| Productivity | `HD Saved Reply`, `HD Saved Reply Team` | canned responses |
| **Forms** | `HD Ticket Template`, `HD Ticket Template Field`, `HD Field Layout` | **the portal form is configurable without code** |
| Scripting | `HD Form Script` | client-side scripts on the ticket form |
| Feedback | `HD Ticket Feedback Option`, `HD Email Feedback` | CSAT rating + reasons |
| Search | `HD Stopword`, `HD Synonym`, `HD Synonyms` | full-text search tuning |
| Other | `HD Notification`, `HD View`, `HD Settings`, `erpnext_hd_settings` | in-app notifications, saved views, settings |

### 3.2 `HD Ticket` fields — the 62 that ship

Grouped, from `hd_ticket.json`:

- **Core:** `subject`, `description` (rich text), `raised_by` (email), `status`,
  `priority`, `ticket_type`, `agent_group` (team)
- **SLA:** `sla`, `response_by`, `resolution_by`, `agreement_status`,
  `on_hold_since`, `total_hold_time`
- **Timing:** `first_responded_on`, `first_response_time`, `avg_response_time`,
  `opening_date`, `opening_time`, `resolution_date`, `resolution_time`,
  `user_resolution_time`
- **Resolution:** `resolution_details`
- **Links:** `contact`, `customer`, `email_account`, `via_customer_portal`
- **Attachments:** `attachment`, `content_type`
- **Feedback:** `feedback`, `feedback_rating`, `feedback_extra`
- **Workflow:** `is_merged`, `merged_with`, `ticket_split_from`, `status_category`
- **Activity:** `last_agent_response`, `last_customer_response`, `summary`

**Note there is no `assigned_agent` field.** Assignment uses Frappe's standard
`_assign` mechanism (ToDo records) — confirmed by `get_assignee(_assign)` in
`hd_ticket/api.py`. This matters: assignment is **[FRAMEWORK]**, not a Helpdesk
field, so anything that works on `_assign` works here.

### 3.3 Defaults created on install

From `helpdesk/setup/install.py`:

- **Statuses:** Open, Replied, Resolved, Closed.
  Note `Replied` is shown to the customer as **"Awaiting Response"** —
  agent-facing and customer-facing labels are separate fields.
- **Priorities:** Low, Medium, High, Urgent (Medium is default).
- **Ticket types:** Question, Bug, Incident.
- **Roles:** `Agent`, `Agent Manager`, `HD Customer`, `HD Customer Manager`.
- **A default SLA and holiday list.**

### 3.4 Framework capabilities we get for free

Verified against `apps/frappe` v16.31.0 in our own bench.

| Capability | Where | Details |
|---|---|---|
| **Notifications** [FRAMEWORK] | `frappe/email/doctype/notification` | Channels: **Email, Slack, System Notification, SMS**. Events: New, Save, Submit, Cancel, Value Change, Days/Minutes Before/After, Method, Custom. Supports a `condition` and `send_to_all_assignees`. |
| **Assignment Rules** [FRAMEWORK] | `frappe/automation/doctype/assignment_rule` | Strategies: **Round Robin, Load Balancing, Based on Field, Weighted Distribution**. Has assign/unassign/close conditions and working days. Helpdesk overrides the class to add its own behaviour. |
| **Webhooks** [FRAMEWORK] | `frappe/integrations/doctype/webhook` | Events: after_insert, on_update, on_submit, on_cancel, on_trash, on_change, on_update_after_submit, workflow_transition. POST/PUT/DELETE with a condition. |
| **Custom Fields** [FRAMEWORK] | `Custom Field` doctype | Add fields to `HD Ticket` without forking Helpdesk. |
| **Attachments** [FRAMEWORK] | `File` doctype | Any file type. **Default limit 10 MB** (`conf.max_file_size`). |
| **Full REST/RPC API** [FRAMEWORK] | `/api/method/...`, `/api/resource/...` | Helpdesk adds its own whitelisted methods on top. |
| **Scheduler** [FRAMEWORK] | cron-style | Helpdesk uses it for `close_tickets_after_n_days` (daily) and `update_sla_status_in_ticket` (hourly). |
| **Row-level permissions** [FRAMEWORK+NATIVE] | `permission_query_conditions`, `has_permission` | Helpdesk registers both for `HD Ticket`, so customers only see their own tickets. |

### 3.5 Helpdesk's own API

From `helpdesk/api/` — `ticket.py`, `agent.py`, `article.py`, `knowledge_base.py`,
`saved_replies.py`, `search.py`, `dashboard.py`, `auth.py`, `permission.py`,
`assignment_rule.py`, `contact.py`, `customer.py`, `doc.py`, `general.py`,
`onboarding.py`, `analytics_utils.py`.

The one that matters most for us:

```python
# helpdesk/helpdesk/doctype/hd_ticket/api.py
def new(doc: dict, attachments: list[dict] = []):
```

**Ticket creation natively accepts attachments.** That is the whole integration.

---

## 4. Frappe Helpdesk vs Frappe Desk

These are constantly confused. They are different things.

**Frappe Desk** is the generic admin UI that ships with the Frappe Framework —
the `/app` interface with lists, forms and reports for *every* doctype. It is
built for administrators and developers. It is powerful and ugly.

**Frappe Helpdesk** is a purpose-built support application with its own modern
Vue interface at `/helpdesk`. It only knows about tickets.

| | Frappe Desk (`/app`) | Frappe Helpdesk (`/helpdesk`) |
|---|---|---|
| Audience | admins, developers | support agents and customers |
| Scope | every doctype | tickets only |
| Interface | generic forms | purpose-built |
| Requires | `desk_access = 1` | its own `Agent` role |

### How they should work together in Remedisys

```text
DOCTOR / CLINIC USER          SUPPORT AGENT              PLATFORM ADMIN
        │                            │                          │
        ▼                            ▼                          ▼
  Remedisys app              /helpdesk agent UI            /app (Desk)
  "Report a Problem"         triage, reply, resolve      SLA, teams, config
        │                            │                          │
        └────────────┬───────────────┴──────────────────────────┘
                     ▼
             HD Ticket (one database)
```

- **Doctors never see Desk, and never see the Helpdesk portal either.** They
  see a Remedisys form and a Remedisys ticket list.
- **Support agents live in `/helpdesk`.** It is genuinely good; there is no
  reason to rebuild it.
- **Configuration lives in Desk** — SLAs, teams, ticket types, email accounts.
  Admin-only, rarely touched.

⚠️ **Watch out:** `update_agent_role()` in `hd_agent.py` grants **`System
Manager`** to an Agent Manager. On a healthcare platform that is a very large
grant — it is effectively full site admin. See §12.

---

## 5. Remedisys requirements

Users are doctors and clinic staff. They are busy and non-technical. They need
to report:

Bug · Feature not working · Clinical workflow problem · UI/UX problem ·
Data problem · Account/access problem · General question · Suggestion

…using text, screenshots, files, and ideally a screen recording.

The experience must be:

```text
Help → Report a Problem → describe → attach → submit → track
```

**Non-negotiable:** it must feel like Remedisys. A doctor should never notice
there is a separate ticketing product behind it.

---

## 6. Recommended UI/UX

### We already have the right place

Remedisys has a **route-aware Help drawer**:
`src/components/help/help-drawer.tsx` exposes `HelpProvider` / `useHelp()`, and
`src/lib/help-content.ts` maps the current path to help content. The sidebar
user menu already has a **Help** item that opens it.

This is the correct home for "Report a Problem", and it gives us something
valuable for free: **the drawer already knows what page the user is on**, so we
can capture the module and URL with no extra work.

### Recommended placements

| Placement | Recommendation | Why |
|---|---|---|
| **Help drawer → "Report a Problem"** | ✅ **Build first** | The user is already there when stuck. Zero new navigation. Page context is free. |
| **Help drawer → "My Tickets"** | ✅ **Build first** | Tracking belongs next to reporting. One place to remember. |
| **Global floating button** | ❌ Skip | Permanently covers UI on clinical screens. The Help menu is enough. |
| **Sidebar top-level "Support"** | ❌ Skip | The sidebar is clinical navigation. Support is not a daily task. |
| **Error states / crash screens** | ✅ **Phase 2** | Highest-value context of all — we know exactly what broke. |
| **Contextual button in each module** | ⚠️ Later | Only if data shows users can't find the Help menu. Avoid clutter first. |
| **Settings page** | ❌ Skip | Nobody looks for support in Settings. |

**Verdict:** one entry point (Help drawer, two items), plus an automatic one on
error screens. Resist adding more until usage data justifies it.

### The form itself — keep it to four things

```text
┌─ Report a Problem ──────────────────────────┐
│  What kind of problem?   [ dropdown ]       │
│  What happened?          [ text area ]      │
│  Attach                  [ screenshot… ]    │
│                          [ record screen ]  │  ← Phase 4
│                                             │
│  We'll include: page, browser, your clinic  │  ← transparency
│                                    [Submit] │
└─────────────────────────────────────────────┘
```

That last line matters. Tell the user what we attach automatically. Do not
collect context silently.

---

## 7. Ticket workflow

Designed around what Helpdesk **actually** does, not a generic flow.

```text
Doctor hits a problem
        │
        ▼
Help drawer → "Report a Problem"
        │
        ▼
Picks type · describes · attaches            [CUSTOM form]
        │
        ▼
Remedisys BFF adds context automatically     [CUSTOM]
  page URL · module · role · clinic · browser
        │
        ▼
POST → helpdesk ticket.new(doc, attachments) [NATIVE]
        │
        ▼
HD Ticket created, status = Open             [NATIVE]
   ├── SLA attached, response_by set         [NATIVE]
   └── Assignment Rule routes to a team      [FRAMEWORK]
        │
        ▼
Agent works it in /helpdesk                  [NATIVE]
   ├── replies (email + portal)              [NATIVE]
   ├── internal comments                     [NATIVE]
   └── status → Replied  (user sees          [NATIVE]
        "Awaiting Response")
        │
        ▼
User replies from Remedisys or email         [NATIVE]
        │
        ▼
Agent sets Resolved                          [NATIVE]
        │
        ▼
Feedback rating requested                    [NATIVE]
        │
        ▼
Auto-close after N days of no reply          [NATIVE — daily scheduler]
```

**Everything after submission is native.** We only build the front door.

---

## 8. Ticket data model

### Fields Helpdesk already gives us — do not rebuild

| Our requirement | Native field |
|---|---|
| Ticket ID | `name` |
| Subject | `subject` |
| Description | `description` |
| Category | `ticket_type` |
| Priority | `priority` |
| Status | `status` |
| Reporter | `raised_by` / `contact` |
| Assigned team | `agent_group` |
| Assigned agent | `_assign` [FRAMEWORK] |
| Attachments | `File` records [FRAMEWORK] |
| Created time | `opening_date` + `opening_time` |
| First response time | `first_responded_on`, `first_response_time` |
| Resolution time | `resolution_date`, `resolution_time` |
| Resolution | `resolution_details` |
| User feedback | `feedback`, `feedback_rating`, `feedback_extra` |
| Internal notes | `HD Ticket Comment` |

**That is 15 of our 22 requirements, already built.**

### Fields we must add [CUSTOM — via `Custom Field`, no fork]

| Field | Type | Why |
|---|---|---|
| `custom_clinic` | Link → Company | Multi-clinic. Which clinic reported it. |
| `custom_reported_role` | Data | A doctor's bug differs from a front-desk bug. |
| `custom_module` | Data | Which Remedisys area (patients, encounter, labs…). |
| `custom_page_url` | Data | Exact route, for reproduction. |
| `custom_client_info` | Small Text | Browser, OS, viewport, app version. |
| `custom_contains_phi` | Check | **Critical.** See §12. |
| `custom_sub_category` | Data / Link | Only if `ticket_type` proves too coarse. **Defer.** |

**Do not add a `screen_recording` field.** Recordings are `File` attachments like
anything else — a dedicated field would fight the framework.

### Map our 8 problem types onto `HD Ticket Type`

`HD Ticket Type` is a doctype, so this is configuration, not code:
Bug · Feature not working · Clinical workflow · UI/UX · Data problem ·
Account/access · Question · Suggestion.

Each type can carry a default priority, which gives us basic auto-prioritisation
with **zero custom code**.

---

## 9. Attachments and screen recording

### Screenshots — easy [NATIVE]

Helpdesk's `ticket.new()` takes attachments. Files go to Frappe's `File`
doctype. Nothing to build beyond the upload control.

### Screen recording — the honest analysis

**Can Helpdesk store video?** Yes — it is just a file. There is no video-specific
handling, but none is needed.

**The real constraint:** `get_max_file_size()` returns
`conf.max_file_size or 10485760` — **10 MB default**
(`frappe/utils/file_manager.py:212`). Screen recording at 1080p is roughly
2–5 MB per minute even when compressed. A two-minute recording will fail.

There is also a web-server body-size limit (nginx `client_max_body_size`) that
must be raised in step, or the upload dies before Frappe sees it.

### Four options considered

| Option | How | Verdict |
|---|---|---|
| **A. Browser recording → upload to Frappe** | `navigator.mediaDevices.getDisplayMedia()` + `MediaRecorder`, upload as a file | ✅ **Recommended.** No third party. PHI never leaves our infrastructure. Needs a size cap. |
| **B. External service** (Loom etc.) | Record there, paste a link | ❌ **Reject.** Sends patient data to a third party. |
| **C. Ask users to record themselves** | They attach a file | ⚠️ Fallback only. Poor UX, and file sizes are uncontrolled. |
| **D. Session replay** (rrweb etc.) | Continuous DOM capture | ❌ **Reject for now.** Records everything, including charts the user never meant to send. Enormous privacy surface. |

### Recommended architecture — Option A, with guard rails

```text
User clicks "Record screen"
        ↓
Browser asks which window/tab to share   ← the OS dialog; user chooses
        ↓
MediaRecorder captures, VP9/WebM
        ↓
HARD CAP: 60 seconds, ~10 MB            ← stops before limits bite
        ↓
User PREVIEWS the recording             ← ⚠️ mandatory, see §12
        ↓
Explicit "This contains no patient data" confirmation
        ↓
Upload → Frappe File → attached to HD Ticket
```

**Non-negotiable design rules:**

1. **Cap the duration.** 60 seconds. Long recordings are worse bug reports anyway.
2. **Force a preview.** The user must watch it before sending. This is the only
   realistic protection against accidentally recording a patient's chart.
3. **Private files only.** `is_private = 1`. Never a public URL.
4. **Raise both limits together** — `max_file_size` in `site_config.json` *and*
   nginx `client_max_body_size`. Raising one without the other fails confusingly.

**Browser support note:** `getDisplayMedia` works in current Chrome, Edge and
Firefox. **Safari support is limited, and iOS Safari does not support it at
all.** Screenshots must remain available as the fallback everywhere.

---

## 10. Automation and triggers

| Trigger | Action | Type |
|---|---|---|
| Ticket created | Notify support team | **[NATIVE]** + [FRAMEWORK] Notification |
| Ticket created | Auto-assign to a team/agent | **[FRAMEWORK]** Assignment Rule |
| Ticket assigned | Notify agent | **[FRAMEWORK]** Notification (`send_to_all_assignees`) |
| Priority changed | Notify team | **[FRAMEWORK]** Notification (event: Value Change) |
| User replies | Update ticket, reopen | **[NATIVE]** |
| Agent replies | Status → Replied | **[NATIVE]** |
| Ticket resolved | Notify user | **[NATIVE]** |
| Ticket closed | Ask for feedback | **[NATIVE]** feedback + rating |
| SLA breached | Mark `agreement_status` = Failed | **[NATIVE]** hourly scheduler |
| SLA about to breach | Escalate | **[FRAMEWORK]** Notification (Minutes Before) |
| Ticket inactive N days | Auto-close | **[NATIVE]** `close_tickets_after_n_days` |
| Any ticket event | Call an external system | **[FRAMEWORK]** Webhook |

### Remedisys-specific automations

| Automation | Type | Phase |
|---|---|---|
| Capture the module the user was in | **[CUSTOM]** — free from the Help drawer's route awareness | 2 |
| Capture the current URL | **[CUSTOM]** — same | 2 |
| Capture user, role and clinic | **[CUSTOM]** — from our JWT session | 2 |
| Capture browser/OS/app version | **[CUSTOM]** | 2 |
| Route clinical issues to a clinical team | **[FRAMEWORK]** Assignment Rule on `ticket_type` | 5 |
| Auto-priority by type | **[NATIVE]** — `HD Ticket Type.priority` | 1 |
| Flag possible-PHI attachments for restricted handling | **[CUSTOM]** | 4 |
| Auto-categorise from description text | **[CUSTOM]** + AI | 7 |

**Most of what we want is configuration, not code.** The only genuinely custom
piece in Phase 2 is context capture.

---

## 11. Roles and permissions

### Helpdesk's own roles

| Role | Desk access | Purpose |
|---|---|---|
| `HD Customer` | **0** | end user; sees only their own tickets |
| `HD Customer Manager` | **0** | sees the whole clinic's tickets |
| `Agent` | — | support agent |
| `Agent Manager` | — | ⚠️ also granted **System Manager** |

**Good news for us:** `HD Customer` and `HD Customer Manager` are created with
`desk_access = 0`, which matches our rule that all app users are Website Users
with no Desk access.

### ⚠️ Two real conflicts with our setup

**1. Portal Settings gets overwritten.** `setup_customer_role()` sets, on fresh
install:

```python
portal_settings.default_role = "HD Customer"
portal_settings.default_portal_home = "/helpdesk"
```

This is **site-wide**. If Remedisys relies on Portal Settings for its own
patient portal, installing Helpdesk will change it. **Check and restore this
immediately after install.**

> ✅ **CONFIRMED on `marley.local`, 2026-08-24 — this is observed behaviour, not a prediction.**
> The `Version` audit row proves it fired and was reverted by hand 56 seconds later:
> install at `19:33:30` → at `19:34:26`, `default_role` `"HD Customer"` → `"Patient"` and
> `default_portal_home` `"/helpdesk"` → `null`. Left un-reverted, every patient portal login lands
> in the support console. The revert exists only as a manual step — see the integration plan §10.2.

**2. `Agent Manager` implies `System Manager`.** On a healthcare site that means
a support lead can read every patient record. This needs a deliberate decision:
either accept it for a very small number of trusted staff, or avoid the Agent
Manager role entirely and manage configuration through a separate admin account.

---

## 12. Security considerations

> These are **technical recommendations**. Whether they satisfy LFPDPPP,
> NOM-024-SSA3-2010 or any other regime is a **legal determination** and must be
> made by whoever owns compliance for Remedisys. Nothing here is legal advice.

### The core risk

A doctor reporting "the encounter screen is broken" will screenshot the
**encounter screen** — with a real patient's name, diagnosis and medication on
it. The bug report is now a clinical record sitting in a ticketing system, and
support agents who have no clinical role can read it.

**This is the defining risk of the feature.** It is not hypothetical; it is the
expected case.

### Recommended controls

| Risk | Control | Type |
|---|---|---|
| Screenshots contain patient data | Warn before attaching; require the user to confirm | [CUSTOM] |
| Recordings contain patient data | Mandatory preview + explicit confirmation; 60s cap | [CUSTOM] |
| Attachments publicly reachable | Always `is_private = 1` | [FRAMEWORK] |
| Agents over-privileged | Avoid `Agent Manager`/`System Manager` for routine staff | config |
| Cross-clinic leakage | `custom_clinic` + Assignment Rules + row-level permission checks | [FRAMEWORK] + [CUSTOM] |
| No audit trail | Frappe versioning + `HD Ticket Activity` | [NATIVE] + [FRAMEWORK] |
| Data kept forever | Retention policy on tickets and attachments | [CUSTOM] — **no native retention** |
| Encryption in transit | HTTPS everywhere | infrastructure |
| Encryption at rest | Disk/DB-level | infrastructure |

### Options for reducing PHI exposure — pick one before Phase 4

1. **Warn and confirm** — cheapest, weakest. Relies on the user.
2. **Automatic blurring** of patient-name regions before upload — [CUSTOM],
   significant work, imperfect.
3. **Restricted attachment access** — only agents with a specific role can open
   attachments; ticket text stays open to all. [CUSTOM] Good balance.
4. **Demo-data-only policy** — ask users to reproduce on a test patient.
   Strongest, but unrealistic mid-clinic.

**Recommendation:** start with 1 + 3, and revisit blurring only if incidents
occur.

---

## 13. Installation plan

> Commands taken from the official README's local-development section. Verify
> against the repo before running — **do not paste these from memory.**

### Prerequisites (already satisfied)

| Requirement | Our status |
|---|---|
| Frappe Framework v15 or v16 | ✅ v16.31.0 |
| `telephony` app (required dependency) | ✅ already in our bench |
| Bench | ✅ |
| Python 3.14 (our v16 baseline) | ✅ |

### Steps

```bash
# 1. Fetch the app (telephony is already present in our bench)
bench get-app helpdesk https://github.com/frappe/helpdesk

# 2. Install onto a NON-PRODUCTION site first
bench --site <dev-site> install-app helpdesk

# 3. Rebuild and restart
bench build
bench --site <dev-site> migrate
```

Access: `http://<site>/helpdesk`.

### Immediately after install — required checks

1. **Verify Portal Settings were not hijacked** (see §11). Record the previous
   values *before* installing.
2. Confirm our `EB_` roles and their `desk_access = 0` are untouched.
3. Confirm the Remedisys patient portal still works.
4. Review the four new roles.
5. Configure ticket types, SLA and teams.

### Production considerations

- **Install on staging (`pre`) first and live with it for a sprint.**
- Helpdesk adds ~36 doctypes; the migration is not trivial to reverse.
- `after_migrate` runs a search-index build and corpus download — expect a
  slower first migration.
- Raise `max_file_size` **and** nginx `client_max_body_size` together (§9).
- Set up an incoming email account only when we actually want email intake.
- **AGPL-3.0:** we are self-hosting an unmodified app, which is the ordinary
  case — but if we ever fork and modify Helpdesk itself, the licence obligations
  deserve a legal read.

---

## 14. Remedisys integration architecture

```text
        DOCTOR / CLINIC USER                    SUPPORT AGENT        ADMIN
                 │                                    │                │
                 ▼                                    │                │
   ┌──────────────────────────────┐                   │                │
   │   Remedisys (Next.js)        │                   │                │
   │   Help drawer                │                   │                │
   │    ├── Report a Problem      │                   │                │
   │    └── My Tickets            │                   │                │
   └──────────────┬───────────────┘                   │                │
                  │ context added here:               │                │
                  │ page · module · role · clinic     │                │
                  ▼                                   │                │
   ┌──────────────────────────────┐                   │                │
   │  Next.js BFF  /api/support/* │  ← auth boundary  │                │
   └──────────────┬───────────────┘                   │                │
                  │ Bearer JWT (eb_frappe_jwt)        │                │
                  ▼                                   ▼                ▼
   ┌────────────────────────────────────────────────────────────────────────┐
   │                      FRAPPE SITE (one database)                        │
   │                                                                        │
   │   helpdesk.…hd_ticket.api.new()      /helpdesk agent UI     /app Desk  │
   │                    │                                                   │
   │                    ▼                                                   │
   │   HD Ticket ──┬── File attachments (private)                           │
   │               ├── HD Ticket Comment (internal)                         │
   │               ├── Communication (email thread)                         │
   │               └── _assign → ToDo                                       │
   │                    │                                                   │
   │   SLA ── Assignment Rule ── Notification ── Webhook   [FRAMEWORK]      │
   └────────────────────────────────────────────────────────────────────────┘
```

**Key architectural decisions:**

1. **Tickets are created through our BFF, never from the browser directly.** The
   browser has no business holding Helpdesk credentials, and the BFF is where we
   attach context and enforce our own rules.
2. **One Frappe site, not two.** Helpdesk installs alongside Remedisys. A second
   site would mean a second login and cross-site identity work for no benefit.
3. **Agents use the native `/helpdesk` UI.** Rebuilding it would be weeks of work
   for a worse result.
4. **Users never leave Remedisys.**

---

## 15. Custom development required

| # | What | Effort | Phase |
|---|---|---|---|
| 1 | "Report a Problem" form in the Help drawer | S | 2 |
| 2 | BFF route `POST /api/support/tickets` | S | 2 |
| 3 | Context capture (page, module, role, clinic, browser) | S | 2 |
| 4 | Custom Fields on `HD Ticket` | XS — config | 2 |
| 5 | "My Tickets" list + detail in Remedisys | M | 3 |
| 6 | Reply-from-Remedisys | M | 3 |
| 7 | Screenshot attach + PHI warning | S | 3 |
| 8 | Screen recording (capture, cap, preview, upload) | **L** | 4 |
| 9 | Restricted attachment access | M | 4 |
| 10 | Retention policy job | S | 6 |
| 11 | i18n (en / es-MX) for all of the above | S | with each |

**Everything else is configuration.**

---

## 16. Native vs custom matrix

| Capability | Native | Framework | Custom | External |
|---|---|---|---|---|
| Ticket CRUD | ✅ | | | |
| Statuses / priorities / types | ✅ | | | |
| SLA + working hours + holidays | ✅ | | | |
| Teams and agents | ✅ | | | |
| Auto-assignment | | ✅ | | |
| Email in/out | ✅ | ✅ | | |
| Internal comments | ✅ | | | |
| Attachments | ✅ | ✅ | | |
| Knowledge base | ✅ | | | |
| Saved replies | ✅ | | | |
| Feedback / CSAT | ✅ | | | |
| Agent portal | ✅ | | | |
| Customer portal (generic) | ✅ | | | |
| **Customer portal (Remedisys-native)** | | | ✅ | |
| Notifications | ✅ | ✅ | | |
| Webhooks | | ✅ | | |
| Custom fields | | ✅ | | |
| Row-level permissions | ✅ | ✅ | | |
| Auto-close inactive tickets | ✅ | | | |
| Full-text search | ✅ | | | |
| Analytics dashboard | ✅ | | | |
| **Context capture** | | | ✅ | |
| **Screen recording** | | | ✅ | |
| **PHI safeguards** | | | ✅ | |
| **Data retention** | | | ✅ | |
| SMS / Slack notifications | | ✅ | | ✅ provider |
| AI features | | | ✅ | ✅ LLM |

---

## 17. Future AI capabilities

We already run an LLM stack (`AI Prompt Log`, Claude/GPT integration), so these
are feasible — but **none should be built now**.

| Capability | Value | Build when |
|---|---|---|
| Auto-categorisation | Medium | 500+ tickets of training signal |
| Priority prediction | Low | Later — `HD Ticket Type` defaults cover most of it |
| **Duplicate detection** | **High** | After Phase 6 — best early win |
| Similar-ticket retrieval | High | With duplicate detection |
| Suggested solutions from KB | High | Once the KB has real articles |
| Agent draft replies | Medium | After agents build up saved replies |
| Ticket summaries | Medium | Note: `HD Ticket.summary` already exists |
| User-facing troubleshooting bot | Medium | Last — highest risk of wrong clinical advice |

**Why not now:** every one of these needs ticket history to be any good. Build
the pipeline first, collect real tickets, then automate what the data shows is
repetitive. And a support bot on a clinical product must never be allowed to
answer a clinical question — that boundary needs designing before a line of code.

---

## 18. Implementation roadmap

### Phase 1 — Install and validate *(1–2 days)*
Install on dev · verify Portal Settings and our roles survive · configure the 8
ticket types, SLA, one team · create test tickets in the native UI.
**Exit:** Helpdesk works, Remedisys is unaffected.

### Phase 2 — Basic integration *(3–5 days)*
Custom Fields · BFF ticket route · "Report a Problem" in the Help drawer ·
context capture · en/es strings.
**Exit:** a doctor can report a problem without leaving Remedisys.

### Phase 3 — Native ticket UI *(5–7 days)*
"My Tickets" list and detail · reply from Remedisys · screenshot attach with the
PHI warning · status shown in the user's language.
**Exit:** the full loop runs inside Remedisys.

### Phase 4 — Screen recording *(5–8 days)* ⚠️ decisions needed first
Browser capture · 60s cap · **mandatory preview** · private upload · restricted
attachment access · raise both size limits.
**Exit:** a doctor can safely record a bug.

### Phase 5 — Automation and routing *(2–3 days)*
Assignment Rules per ticket type · escalation notifications · SLA alerts ·
clinical vs technical routing.
**Exit:** tickets reach the right person without manual triage.

### Phase 6 — Analytics and feedback *(2–3 days)*
Native dashboard · CSAT · retention job · a monthly review habit.
**Exit:** we know what users struggle with.

### Phase 7 — AI *(not scheduled)*
Duplicate detection first. Only after real ticket volume exists.

---

## 19. Risks and open questions

### Risks

| Risk | Severity | Mitigation |
|---|---|---|
| **Screenshots/recordings carry PHI** | 🔴 **High** | Warn + confirm + restricted access; decide policy before Phase 3 |
| Portal Settings overwritten on install | 🟠 Medium | Record values before install; verify after |
| `Agent Manager` grants System Manager | 🟠 Medium | Avoid the role, or restrict to 1–2 trusted staff |
| 36 new doctypes on a clinical site | 🟠 Medium | Staging first, full sprint of soak time |
| 10 MB file limit blocks recordings | 🟡 Low | Cap duration; raise both limits together |
| Safari/iOS cannot screen-record | 🟡 Low | Screenshots always available |
| AGPL obligations if we fork Helpdesk | 🟡 Low | Don't fork; use Custom Fields and hooks |
| Support workload underestimated | 🟠 Medium | Start with one team; measure before scaling |

### Open questions — **answer before development starts**

1. **Who is the support team?** Helpdesk needs real agents. Who are they, and
   what are their hours? SLA configuration depends entirely on this.
2. **Is a support agent allowed to see patient data?** The single most important
   question. If no, Phase 3 needs the attachment-restriction work, not Phase 4.
3. **How long do we keep tickets and attachments?** There is no native retention.
4. **Do we want email intake?** Should a doctor be able to just email support?
5. **One clinic or all clinics per user?** Does a clinic admin see their whole
   clinic's tickets (`HD Customer Manager`) or only their own?
6. **Spanish first or English first?** Our users are es-MX. Helpdesk's own UI
   translation coverage needs checking if agents will be Spanish-speaking.
7. **Same site or separate site?** This document recommends the same site.
   Confirm that is acceptable.

---

## 20. Recommended next steps

### Build first
1. **Phase 1** — install on dev and prove Remedisys is unaffected.
2. **Configure** the 8 ticket types and one SLA. No code.
3. **Phase 2** — the Help drawer form + BFF route + context capture.

### Do not build yet
- ❌ Screen recording — needs the PHI decision first.
- ❌ Any AI feature — needs ticket history first.
- ❌ A custom agent UI — the native one is good.
- ❌ Contextual "Report" buttons in every module — prove the Help menu is
  insufficient first.
- ❌ Sub-categories — `ticket_type` is probably enough.

### Decide before writing code
1. Can support agents see patient data? **(blocks Phase 3/4 design)**
2. Who are the agents, and what are their hours? **(blocks SLA)**
3. Retention period for tickets and attachments?
4. Same site or separate?

**Suggested immediate action:** do Phase 1 on a throwaway dev site this week.
It is cheap, it is reversible, and it will answer more questions than further
research will.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-21 | Sarvesh-SocialAngel | Initial research and plan — verified against helpdesk v1.29.0 and our own Frappe v16.31.0 |
