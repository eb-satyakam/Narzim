# Grafana Observability for Remedisys — Research, Architecture & Implementation Plan

**Doc status:** living · **Created:** 2026-08-11 by Sarvesh-SocialAngel · **Updated:** 2026-08-11 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** Research and design only. Nothing implemented, nothing installed.
**Date:** 2026-08-11
**Scope:** Grafana ecosystem evaluated against Remedisys' actual deployment constraints.

---

## 0. Two corrections before the design

These change the design materially, so they come first rather than buried in an appendix.

### 0.1 The frontend stack in the brief does not match the repository

The brief describes the frontend as *React + Vite + TanStack Router + Zustand*. The repository disagrees:

| Component | Brief | `Healthcare_next_app/package.json` |
|---|---|---|
| Framework | React + Vite | **Next.js 16.2.7** |
| React | — | 19.2.4 |
| Router | TanStack Router | Next.js App Router |
| State | Zustand | **absent** |
| Vite | yes | **absent** |
| Data fetching | React Query | React Query 5.100.14 ✓ |
| i18n | — | next-intl 4.13.0 |

This is not pedantry — it inverts the frontend instrumentation answer. A Vite SPA would need a hand-rolled browser OTel setup. Next.js on Vercel has **first-class OpenTelemetry support** through `instrumentation.ts` + `@vercel/otel`, and Vercel can drain traces and logs natively.¹ The recommended design below assumes Next.js. If the brief's stack is the intended future state, the frontend sections need revisiting.

### 0.2 Observability is not greenfield — PostHog is already live

As of today `preehr.narzim.com` runs PostHog with masked session replay. Product analytics is therefore **already solved**, and PostHog already contains a reviewed PHI-sanitisation layer (`src/lib/analytics/sanitize.ts`, `templateRoute`, `scrubEvent`, a URL `property_denylist`). That layer is directly reusable for observability and should not be rebuilt.

What does *not* exist anywhere: metrics, structured logs shipped off-box, traces, error tracking, or alerting. `frappe.logger("remedisys")` is called in exactly one place in the backend.

---

## 1. Executive Summary

**The single most important finding: Frappe Cloud will not let you run a metrics agent, so the classic Grafana architecture is not available to you for the backend.**

Frappe Cloud documents, in its own words, that it does **not** provide root access inside a bench, that system packages should be added "in your app itself" rather than installed, and that SSH runs over a proxy so `scp` and tools depending on it do not work.² SSH exists only on *private* bench groups, not shared ones.

That single constraint eliminates `node_exporter`, `mysqld_exporter`, `redis_exporter`, and a host-resident Grafana Alloy. Consequently **host CPU/memory/disk, MariaDB internals, and Redis internals are not collectible by you.** Any plan that shows those dashboards is describing infrastructure you do not control.

What remains is genuinely useful and is what the design targets:

| Signal | How | Feasible today |
|---|---|---|
| Uptime / latency from outside | Grafana Cloud Synthetic Monitoring (Grafana-hosted probes, no agent)³ | ✅ |
| Frontend traces + runtime logs | Vercel Drains → OTLP (Pro plan, $0.50/GB)⁴ | ✅ |
| Backend app metrics | `opentelemetry-sdk` inside the Frappe app → OTLP push | ✅ |
| AI operational metrics | Already in `AI Prompt Log` / `AI Encounter Session` DocTypes | ✅ |
| Host / DB / Redis internals | — | ❌ not without a Dedicated Server |

**Recommendation: Grafana Cloud free tier, push-based (OTLP), no self-hosting, no Alloy, no Tempo initially.** The free tier covers 10k active series, 50 GB logs, 50 GB traces, 14-day retention, 3 users⁵ — comfortably above what a single-clinic pilot generates.

**Do not self-host the Grafana stack.** A self-hosted Prometheus/Loki/Tempo becomes a second production system holding healthcare-adjacent telemetry, requiring its own TLS, auth, backups, retention policy, patching and — under LFPDPPP/DPDPA — its own compliance treatment. For a 3-backend-engineer team it is a poor trade against a free managed tier.

**Grafana does not replace Sentry.** They answer different questions and the correct end state is both, added in that order.

---

## 2. Grafana Fundamentals — what each piece actually is

The most common architectural misunderstanding is treating "Grafana" as one product that monitors things. It is not.

### 2.1 The five layers

```
Application          emits telemetry (needs instrumentation — nothing is automatic)
      ↓
Collector/Exporter   collects, batches, filters, redacts, forwards
      ↓
Storage/Backend      Prometheus (metrics) · Loki (logs) · Tempo (traces)
      ↓
Grafana              queries, visualises, explores — STORES NOTHING
      ↓
Alerting             evaluates rules → routes notifications
```

Grafana's own documentation states it lets you "query, visualize, alert on, and explore your metrics, logs, and traces **wherever they are stored**."⁶ The emphasis is theirs in effect: Grafana is a query and presentation layer. Installing Grafana alone gives you an empty dashboard tool with nothing to point it at.

### 2.2 Component roles

| Component | Role | Do we need it? |
|---|---|---|
| **Grafana** | Visualisation, query, alerting UI | ✅ yes — the whole point |
| **Prometheus** | Time-series metrics store, pull-based scraping | ⚠️ as a *hosted* backend, yes. Self-hosted with scraping — no, we have nothing scrapeable |
| **Loki** | Log aggregation, indexes **labels only**, not log contents⁷ | ✅ yes, as hosted backend |
| **Tempo** | Trace backend, stores spans in object storage, ingests OTLP⁸ | ⏸ later — see §6 |
| **Alloy** | Telemetry collector (OTel Collector distribution)⁹ | ❌ not initially — nowhere to run it |
| **OpenTelemetry** | Vendor-neutral instrumentation + wire protocol | ✅ yes — this is the actual integration point |

### 2.3 Why Alloy is *not* required here

Grafana's docs recommend Alloy as "the recommended architecture for production observability" because a collector gives you retries, buffering, enrichment and multi-backend routing.¹⁰ That is sound advice — but it presumes somewhere to run a long-lived process.

Crucially, the same documentation confirms **Grafana Cloud accepts OTLP directly without an agent**: "The Grafana Cloud OTLP endpoint is OTLP compliant, and the recommended endpoint to send OpenTelemetry metrics, logs, and traces to Grafana Cloud," at `https://otlp-gateway-<REGION>.grafana.net/otlp` with bearer-token auth.¹¹

That is what makes this whole design possible on managed hosting. We trade Alloy's buffering for zero infrastructure. Given our volumes, that is the right trade.

---

## 3. Official Documentation Research

### 3.1 Grafana

- **What it is:** query/visualise/alert/explore across metrics, logs, traces wherever stored.⁶
- **What it is NOT:** a datastore. In Grafana Cloud it is *bundled with* backends; in OSS you supply your own.⁶
- **Alerting model:** alert rules contain queries + conditions; one rule can produce many alert *instances* (one per series). Contact points define destination and message format (email, Slack, webhook, PagerDuty). Notification policies route by label matching in a tree with a mandatory default. Silences pause one-off; mute timings pause recurring windows. Only `firing` and `resolved` instances generate notifications.¹²
- **Source:** https://grafana.com/docs/grafana/latest/introduction/ · https://grafana.com/docs/grafana/latest/alerting/fundamentals/

### 3.2 Prometheus

- **Model:** time series identified by metric name + key/value labels; purely numeric samples.¹³
- **Collection:** **pull** over HTTP; push gateway only for short-lived jobs.¹³
- **Fits:** "any purely numeric time series… both machine-centric monitoring as well as monitoring of highly dynamic service-oriented architectures."¹³
- **Does NOT fit — quoted directly:** "If you need 100% accuracy, such as for per-request billing, Prometheus is not a good choice, as the collected data will likely not be detailed and complete enough."¹³
  → **Direct consequence for us:** Prometheus must never be the system of record for AI spend or per-clinic billing. `AI Prompt Log` in MariaDB stays authoritative; Prometheus only trends it.
- **Source:** https://prometheus.io/docs/introduction/overview/

### 3.3 Loki

- **Key property:** "does not index the contents of the logs, but only indexes metadata about your logs as a set of labels for each log stream."⁷
- **Cost model:** cheap because the index is small; log bodies compressed into chunks in object storage.⁷
- **Cardinality warning:** "a well-chosen, low-cardinality set of labels is key to fast queries."⁷
  → **Direct consequence for us:** never label by `patient`, `encounter`, `user`, `request_id`, or MRN. That is both a cardinality catastrophe *and* a PHI leak. Labels stay to `service`, `env`, `level`, `route_template`.
- **Components:** agent → Loki server → Grafana.⁷
- **Source:** https://grafana.com/docs/loki/latest/get-started/overview/

### 3.4 Tempo

- **Storage:** "Tempo stores all trace data in object storage" — S3/GCS/Azure Blob; local filesystem is development-only.⁸
- **Ingest:** OTLP (recommended), Jaeger, Zipkin.⁸
- **No separate index:** requires no Elasticsearch; columnar Parquet enables attribute queries.⁸
- **Modes:** monolithic (single process) or microservices (with Kafka as WAL).⁸
- **Source:** https://grafana.com/docs/tempo/latest/introduction/architecture/

### 3.5 Grafana Alloy

- **What it is:** "an open source telemetry collector" — an OpenTelemetry Collector distribution with native Prometheus, Loki, Pyroscope support.⁹
- **Signals:** metrics, logs, traces, profiles in one binary.⁹
- **When required:** when you have somewhere to run it and need buffering/enrichment/multi-routing. Not a hard requirement — Grafana Cloud takes OTLP directly.¹¹
- **Source:** https://grafana.com/docs/alloy/latest/introduction/

### 3.6 OpenTelemetry

- **Python:** `opentelemetry-instrument` gives zero-code auto-instrumentation at system boundaries; manual instrumentation for business logic. `opentelemetry-bootstrap -a install` pulls framework-specific libraries. OTLP exporters available over gRPC and HTTP.¹⁴
  ⚠️ **Marked as assumption:** the Python getting-started guide does not address gunicorn pre-fork workers, which is how Frappe serves web requests. Auto-instrumentation under a pre-fork server typically requires initialising in a post-fork hook. **This must be validated in a Phase-2 spike before committing.**
- **Vercel/Next.js:** `@vercel/otel` + `instrumentation.ts` with `registerOTel({ serviceName })`. Next.js 13.4+ propagates incoming trace context automatically. Custom spans are **not supported on the Edge runtime**. Manual OTel SDK setup (without `@vercel/otel`) forfeits Session Tracing and Trace Drains.¹
- **Source:** https://opentelemetry.io/docs/languages/python/getting-started/ · https://vercel.com/docs/tracing/instrumentation

---

## 4. Infrastructure Constraints — verified, not assumed

The brief said not to assume Frappe Cloud capabilities. Here is what its documentation actually says.

### 4.1 Frappe Cloud

| Question | Verified answer | Source |
|---|---|---|
| Root access in bench? | **No.** "We do not provide root access within the bench. You very likely do not need it." | ² |
| SSH? | Yes, **private bench groups only** (not shared). Certificate valid 6 hours. | ² |
| Install system packages? | Not via SSH — "If you need dependencies installed. You can add them in your app itself." | ² |
| `scp` / file transfer? | **No.** "Our ssh sessions are provided over a proxy connection and thus scp and other tools that depend on it will not work." | ² |
| VS Code Remote? | No — depends on scp. | ² |
| Persistent custom daemons? | Not documented as supported. | ² |
| Prometheus endpoint / remote_write / metrics API? | **Not documented.** Monitoring is dashboard-only. | ¹⁵ |
| Metrics shown in dashboard | Requests/min, CPU usage, background jobs, background job CPU, usage counter, uptime (web worker + scheduler), request duration by path, background job duration by path, DB storage (6-hourly sync) | ¹⁵ |
| Health check | `GET /api/method/ping` → `{"message":"pong"}` + HTTP 200 | ¹⁵ |
| Logs | `web.log`, `web.err.log`, `worker.log`, `worker.err.log` via dashboard or SSH | ¹⁶ |
| Log drain / syslog / S3 export? | **Not documented.** | ¹⁶ |
| Dedicated Servers | Dedicated compute, unlimited sites/benches, deployed in App+DB pairs. **Docs do not state whether root or agent installation is permitted.** | ¹⁷ |

**Security posture worth noting for a healthcare deployment:** the Frappe Cloud security FAQ confirms ISO 27001:2022 and SOC-2 Type-2, daily OS patching, VPC isolation — but also documents gaps: **no EDR, no IPS/IDS, no database encryption at rest, no EBS volume encryption.**¹⁸ That is a compliance input for LFPDPPP/DPDPA independent of observability, and someone should own it.

### 4.2 The four-bucket classification the brief asked for

**Metrics we control (application-level, we instrument):**
- HTTP request rate / error rate / latency per whitelisted API method
- Business-safe counters: encounters signed, appointments booked, invoices created
- AI operational metrics from `AI Prompt Log` (latency, tokens, cost, error, model, provider_ms, tool_ms) and `AI Encounter Session` (duration, status, error_code)
- Background job outcomes via RQ hooks
- Frontend: Web Vitals, route render timing, BFF→Frappe call latency

**Metrics Frappe Cloud provides (dashboard only, not exportable):**
- Requests/min, CPU time, background job counts, worker/scheduler uptime, request duration by path, DB storage

**Metrics requiring Frappe Cloud support / a plan change:**
- Anything host-level. Would need a **Dedicated Server** and written confirmation from Frappe support that agents may be installed. **Open question — do not assume.**

**Metrics we cannot access:**
- Host CPU / memory / disk / network
- MariaDB: connections, query throughput, locks, InnoDB internals, slow-query stream
- Redis: memory, evictions, hit/miss, command stats, latency
- nginx access/error logs
- OS-level saturation

### 4.3 Vercel

| Capability | Verified | Source |
|---|---|---|
| OTel instrumentation | `@vercel/otel` + `instrumentation.ts`; Next.js 13.4+ auto-propagates inbound context | ¹ |
| Custom spans on Edge runtime | **Not supported** | ¹ |
| Drains — data types | Logs, Traces (OTLP format), Speed Insights, Web Analytics, Audit Logs | ⁴ |
| Drains — plan | **Pro or Enterprise.** Audit Log Drains Enterprise-only | ⁴ |
| Drains — cost | **$0.50 per GB**, billed on uncompressed JSON serialisation regardless of delivery encoding | ⁴ |
| Drains — destinations | Custom HTTP endpoint (any data type) + native integrations (Dash0, Braintrust). **No native Grafana integration** — Grafana requires the custom-endpoint route | ⁴ |
| Sampling | Inbound `traceparent` decision AND Vercel's own sampling must both agree to emit | ¹ |

✅ Your team shows **Pro** in the Vercel dashboard, so Drains are available.

---

## 5. Healthcare Privacy & Security Model

This is the section that matters most, and the one where a generic Grafana tutorial will actively harm you.

### 5.1 The distinction that governs everything

| | Technical observability data | Clinical / business data |
|---|---|---|
| Examples | latency_ms, status code, error class, queue depth, token count | patient name, MRN, diagnosis, transcript, SOAP text, medication |
| Belongs in | Grafana stack | MariaDB only |
| Retention | 14–30 days | per clinical retention policy |
| Access | engineering | clinical staff under RBAC |

**Masking is not a safety mechanism, it is a mitigation.** A masked field is still a field that was collected, transmitted to a processor, and stored. The only reliably safe posture is *never emitting it*. This mirrors the position already taken in `src/lib/analytics/replay.ts`: "Masking off does not make a recording safe — it makes it unsafe somewhere that hopefully does not matter."

### 5.2 Absolute prohibitions — never enters telemetry

- Patient names, DOB, MRN, addresses, phone, email
- Diagnoses, ICD codes tied to an individual, medications, dosages
- Clinical notes, SOAP content, chief complaints
- **Deepgram transcript text — under any circumstance**
- AI-generated clinical suggestions, `AI Prompt Log.raw_response`
- Access tokens, refresh tokens, `rm_access` / `rm_refresh` cookie values, `Authorization` headers
- API keys, `ANALYTICS_ID_SECRET`, LLM provider keys
- Full request/response bodies from any `/api/v1/*` endpoint

This is not new policy — CLAUDE.md **Rule 10** already mandates it ("Logs carry IDs… never content"). Observability must inherit it, not renegotiate it.

### 5.3 Codebase-specific leak paths already identified

These are real, in your code today, and each needs an explicit decision before Phase 3.

| # | Leak path | Detail | Treatment |
|---|---|---|---|
| 1 | **Next.js route paths** | `/patients/MRN-2026-0000024` — the URL *is* an identifier | Reuse the existing `templateRoute()` from `sanitize.ts` → `/patients/[id]`. Already solved for PostHog |
| 2 | **`frappe.monitor` request.ip** | `monitor.py:69` captures `frappe.local.request_ip` | IP is personal data under both regimes. Drop or truncate to /24 before export |
| 3 | **`frappe.monitor` path** | `monitor.py:71` captures `frappe.request.path` | ✅ **Low risk** — our API is `/api/method/<dotted.method>`; Werkzeug's `path` excludes the query string. Verify no GET endpoint puts an MRN in the path |
| 4 | **`AI Prompt Log`** | Contains `patient`, `encounter`, `raw_response`, `unmatched_details` | Never export the row. Export only numeric aggregates: `latency_ms`, `tokens_in/out`, `cost_estimate_usd`, `status`, `error` class, `model` |
| 5 | **`AI Encounter Session`** | Contains `patient`, `practitioner`, `error_message` | Export `duration_seconds`, `status`, `close_reason`, `error_code` only. `error_message` is free text → prohibited |
| 6 | **Vercel runtime logs** | Drains ship *everything* the app writes to stdout | `FRAPPE_DEBUG=true` logs every BFF→Frappe call. **Must be `false` in every drained environment** (already correct on Vercel per PRODUCTION_ENV.md) |
| 7 | **Exception messages** | Frappe builds messages from record data — `"Patient MRN-… already exists"` | Send exception *type* + stack, never `str(e)`, unless scrubbed. This is the same reason `capture_exceptions: false` is set in PostHog |
| 8 | **OTel auto-instrumentation** | Auto-instrumented HTTP spans capture `http.url` **with query string** by default | Must configure attribute filtering before enabling. This is the single biggest auto-instrumentation risk |

### 5.4 Treatment matrix

| Data | Treatment | Retention |
|---|---|---|
| Route template (`/patients/[id]`) | allow | 14–30d |
| HTTP method, status, duration | allow | 14–30d |
| Patient identifier | **exclude** | never |
| User identity | **hash** — reuse the existing HMAC `analyticsId` from `/api/auth/me` | 14–30d |
| Client IP | truncate to /24, or exclude | 14d |
| Exception type + stack | allow | 30d |
| Exception message | **exclude** pending scrub | — |
| Request/response body | **exclude** | never |
| Transcript / SOAP / suggestions | **exclude** | never |
| Tokens, cookies, keys | **exclude** | never |
| AI numeric metrics | allow | 30d+ |

### 5.5 A compliance point that is easy to miss

Under LFPDPPP (Mexico) and DPDPA 2023 (India), an observability vendor receiving anything derived from patient interaction is a **processor/encargado** and needs a data-processing agreement — the same reasoning already applied to PostHog. Grafana Labs would need the same treatment **before** any telemetry that could carry PHI is sent.

The safe path, and the one recommended here, is to keep telemetry strictly technical so the DPA is a formality rather than a control you are depending on.

---

## 6. Architecture Options Compared

### Option A — Self-hosted Grafana + Prometheus + Loki + Tempo + Alloy

| Dimension | Assessment |
|---|---|
| Cost | VM + object storage; cheap in cash |
| Complexity | **High** — 5 systems, each with its own config, scaling and failure modes |
| Maintenance | Ongoing: upgrades, retention tuning, disk pressure, Loki cardinality incidents |
| Scalability | Excellent if you invest |
| Security | **You** own TLS, auth, network isolation, patching for a system holding healthcare-adjacent data |
| Privacy | Data stays on your infra — genuine advantage |
| Frappe Cloud compat | ❌ **Alloy cannot run on the bench.** Backend collection would still be push-only |
| Vercel compat | ✅ via Drains → custom endpoint (must be public + authenticated) |
| Operational burden | **Very high** for 3 backend engineers |
| **Verdict** | **Reject.** You would build a second production system to monitor the first, and the Frappe Cloud constraint means you still don't get host metrics |

### Option B — Self-hosted Grafana + Prometheus + Loki

Same as A minus tracing. Slightly less work, same fatal problem: nothing on Frappe Cloud to scrape, and you still own a production system. **Reject.**

### Option C — Grafana Cloud (managed)

| Dimension | Assessment |
|---|---|
| Cost | **Free tier:** 10k series, 50 GB logs, 50 GB traces, 14d retention, 3 users⁵ |
| Complexity | Low — no infrastructure |
| Maintenance | Grafana Labs' problem |
| Scalability | Managed |
| Security | TLS + token auth out of the box; you configure access |
| Privacy | ⚠️ Third-party processor → **DPA required** |
| Frappe Cloud compat | ✅ OTLP push needs no agent¹¹ |
| Vercel compat | ✅ Drains → OTLP endpoint |
| Operational burden | **Low** |
| **Verdict** | **Recommended** |

### Option D — "Start smaller than any of the above" *(recommended sequencing)*

Option C is the destination, but not on day one. Ordered by value-per-hour:

1. **Synthetic monitoring only.** Grafana Cloud hosted probes hitting `/api/method/ping` and the Vercel login page. No code, no instrumentation, no PHI risk whatsoever. Answers "is it up?" — the question you cannot answer today.
2. **Add Vercel Drains → Grafana Cloud.** Config only, no application code.
3. **Add backend app metrics** via OTLP push from the Frappe app.
4. **Add tracing** only once 1–3 are in use and a real cross-service debugging need has been felt.

**Recommendation: Option D as the path, Option C as the destination.**

---

## 7. System Design

### Diagram 1 — High-Level Architecture

```mermaid
flowchart TB
    subgraph clients["Clients"]
        U["Clinic staff<br/>Front desk · Nurse · Doctor"]
    end

    subgraph vercel["Vercel — Pro"]
        FE["Next.js 16 App Router<br/>React 19"]
        BFF["BFF route handlers<br/>/api/*"]
        VD["Vercel Drains<br/>logs · traces"]
    end

    subgraph fc["Frappe Cloud — managed, no root"]
        FR["Frappe v16 + ERPNext Healthcare"]
        API["api/v1/* whitelisted methods"]
        RQ["RQ background workers"]
        DB[("MariaDB 11")]
        RD[("Redis 7")]
    end

    subgraph ext["External services"]
        DG["Deepgram ASR"]
        LLM["LLM providers<br/>Anthropic · OpenAI"]
    end

    subgraph gc["Grafana Cloud — managed"]
        OTLP["OTLP gateway"]
        SYN["Synthetic probes<br/>Grafana-hosted"]
        PROM[("Mimir / Prometheus")]
        LOKI[("Loki")]
        TEMPO[("Tempo — Phase 5")]
        GRAF["Grafana<br/>dashboards · Explore"]
        ALERT["Grafana Alerting"]
    end

    U --> FE --> BFF --> API
    API --> DB
    API --> RD
    RQ --> DB
    API --> DG
    API --> LLM

    FE -.->|"@vercel/otel"| VD
    VD -->|"custom endpoint"| OTLP
    API -.->|"OTLP push<br/>app-level only"| OTLP

    SYN -->|"blackbox probe"| FE
    SYN -->|"/api/method/ping"| FR

    OTLP --> PROM
    OTLP --> LOKI
    OTLP -.-> TEMPO
    SYN --> PROM

    PROM --> GRAF
    LOKI --> GRAF
    TEMPO -.-> GRAF
    GRAF --> ALERT

    DB -.->|"NOT collectible<br/>no agent possible"| X1["✖"]
    RD -.->|"NOT collectible"| X2["✖"]

    classDef blocked fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    classDef managed fill:#0d2818,stroke:#1a7f45,color:#c6f6d5
    classDef later fill:#1f2430,stroke:#5b6478,color:#c8cddb,stroke-dasharray:4 3
    class X1,X2 blocked
    class gc,OTLP,SYN,PROM,LOKI,GRAF,ALERT managed
    class TEMPO later
```

### Diagram 2 — Metrics Flow

```mermaid
flowchart LR
    subgraph sources["Sources — what we can actually instrument"]
        A1["Frappe app<br/>api/v1/* methods"]
        A2["RQ job hooks"]
        A3["AI Prompt Log<br/>numeric fields only"]
        A4["Synthetic probes"]
    end

    subgraph sdk["In-process — no agent"]
        M["OpenTelemetry Python SDK<br/>MeterProvider"]
        F["Attribute filter<br/>drop patient/encounter/user"]
    end

    subgraph cloud["Grafana Cloud"]
        G["OTLP gateway<br/>otlp-gateway-REGION.grafana.net"]
        P[("Prometheus / Mimir")]
        D["Dashboards"]
    end

    A1 --> M
    A2 --> M
    A3 -->|"scheduled aggregate job"| M
    M --> F --> G --> P --> D
    A4 -->|"Grafana-hosted"| P

    NOTE["No node_exporter · No mysqld_exporter<br/>No redis_exporter · No Alloy<br/>Frappe Cloud gives no root"]
    NOTE -.-> sources

    classDef warn fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    class NOTE warn
```

### Diagram 3 — Logs Flow

```mermaid
flowchart TB
    subgraph app["Application"]
        L1["Next.js runtime logs<br/>Vercel stdout"]
        L2["Frappe logger<br/>structured JSON"]
    end

    subgraph redact["Redaction — BEFORE anything leaves"]
        R1["templateRoute()<br/>/patients/MRN-x → /patients/[id]"]
        R2["Drop: tokens · cookies<br/>Authorization · bodies"]
        R3["Exception TYPE only<br/>never str(e)"]
        R4["IP → /24 or dropped"]
        R5["FRAPPE_DEBUG=false<br/>enforced in drained envs"]
    end

    subgraph ship["Transport"]
        VD["Vercel Drains<br/>Pro · $0.50/GB"]
        OT["OTLP logs exporter"]
    end

    subgraph cloud["Grafana Cloud"]
        LK[("Loki<br/>labels: service, env, level, route")]
        EX["Explore / LogQL"]
    end

    L1 --> R1 --> R2 --> VD --> LK
    L2 --> R3 --> R4 --> OT --> LK
    R5 -.-> L1
    LK --> EX

    CARD["Label cardinality rule:<br/>NEVER label by patient, encounter,<br/>user or request_id"]
    CARD -.-> LK

    classDef danger fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    classDef safe fill:#0d2818,stroke:#1a7f45,color:#c6f6d5
    class CARD danger
    class redact,R1,R2,R3,R4,R5 safe
```

### Diagram 4 — Tracing Flow *(Phase 5 — deferred)*

```mermaid
flowchart LR
    subgraph fe["Frontend — Vercel"]
        N["Next.js server<br/>@vercel/otel"]
        E["Edge runtime<br/>custom spans NOT supported"]
    end

    subgraph be["Backend — Frappe Cloud"]
        PY["opentelemetry-sdk<br/>manual spans on api/v1/*"]
        TID["frappe.monitor.get_trace_id()<br/>existing correlation id"]
    end

    subgraph cloud["Grafana Cloud"]
        TD["Trace Drain / OTLP"]
        TP[("Tempo<br/>object storage")]
        GR["Grafana<br/>trace → log correlation"]
    end

    N -->|"traceparent"| PY
    PY --> TID
    N --> TD
    PY --> TD
    TD --> TP --> GR

    E -.->|"unsupported"| X["✖"]

    NOTE["Browser tracing deliberately EXCLUDED:<br/>URLs carry MRNs · high volume · low value"]
    NOTE -.-> fe

    classDef blocked fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    class X,NOTE blocked
```

### Diagram 5 — Alerting Flow

```mermaid
flowchart TB
    S1["Synthetic check<br/>probe_success"]
    S2["App metrics<br/>error rate · latency"]
    S3["Loki<br/>log-based counts"]

    RULE["Grafana Alert Rule<br/>query + condition"]
    EVAL["Evaluation<br/>interval + pending period"]
    STATE{"State"}

    NP["Notification policy<br/>label-tree routing"]
    CP1["P0 → PagerDuty / phone"]
    CP2["P1 → Slack #alerts-critical"]
    CP3["P2 → Slack #alerts"]

    SIL["Silences · mute timings<br/>clinic closed hours"]

    S1 --> RULE
    S2 --> RULE
    S3 --> RULE
    RULE --> EVAL --> STATE
    STATE -->|"firing / resolved"| NP
    STATE -->|"pending"| Z["no notification"]
    NP --> CP1
    NP --> CP2
    NP --> CP3
    SIL -.-> NP

    classDef p0 fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    class CP1 p0
```

### Diagram 6 — Healthcare Data Protection

```mermaid
flowchart TB
    subgraph clinical["Clinical domain — MariaDB only"]
        C1["Patient · name · MRN · DOB"]
        C2["Diagnoses · medications"]
        C3["SOAP notes · encounters"]
        C4["Deepgram transcripts"]
        C5["AI suggestions · raw_response"]
        C6["Tokens · cookies · keys"]
    end

    APP["Remedisys application"]

    subgraph filter["Observability filter — fail closed"]
        F1{"Is it an identifier?"}
        F2{"Is it free text?"}
        F3{"Is it a credential?"}
        F4["Allowlist only:<br/>counters · durations · status<br/>route templates · error types"]
    end

    BLOCK["✖ BLOCKED<br/>never leaves the application"]

    subgraph safe["SAFE TELEMETRY"]
        T1["http_requests_total"]
        T2["request_duration_seconds"]
        T3["ai_session_failures_total"]
        T4["route=/patients/[id]"]
        T5["user=HMAC hash"]
    end

    GS["Grafana Cloud stack"]

    C1 --> APP
    C2 --> APP
    C3 --> APP
    C4 --> APP
    C5 --> APP
    C6 --> APP

    APP --> F1
    F1 -->|yes| BLOCK
    F1 -->|no| F2
    F2 -->|yes| BLOCK
    F2 -->|no| F3
    F3 -->|yes| BLOCK
    F3 -->|no| F4
    F4 --> safe --> GS

    classDef danger fill:#3b1219,stroke:#b4232c,color:#ffd7dc
    classDef good fill:#0d2818,stroke:#1a7f45,color:#c6f6d5
    class BLOCK,clinical danger
    class safe,T1,T2,T3,T4,T5 good
```

---

## 8. Dashboard Specification

Designed against **what is actually collectible**. Where a dashboard the brief requested is not collectible, that is stated rather than filled with panels that will never populate.

### Dashboard 1 — Infrastructure ❌ **Not buildable**

CPU, memory, disk, network and saturation require host access. Frappe Cloud gives none, and Vercel is serverless (no hosts to monitor).

**Substitute — "Platform Health":**

| Panel | Source |
|---|---|
| Site uptime % (30d) | synthetic `probe_success` |
| Probe latency p50/p95 by region | synthetic |
| TLS certificate expiry | synthetic TLS check |
| Vercel function error rate | Drains logs |
| Vercel function duration p95 | Drains |

Real CPU/memory stays in the **Frappe Cloud dashboard** — link to it from Grafana rather than pretending to replicate it.

### Dashboard 2 — Application

| Panel | Metric | Notes |
|---|---|---|
| Request rate | `http_server_requests_total` by route template | never raw path |
| Error rate % | 5xx ÷ total | primary SLO |
| Status distribution | by class 2xx/4xx/5xx | |
| Latency p50 / p95 / p99 | histogram | p99 drives P2 alerts |
| Slowest endpoints | top 10 by p95 | |
| BFF → Frappe latency | client-side timing | isolates network vs backend |

### Dashboard 3 — Frappe

Only realistically available signals:

| Panel | Source | Feasible |
|---|---|---|
| Whitelisted method call rate | app instrumentation | ✅ |
| Method error rate | app | ✅ |
| Background job success/failure | RQ hooks | ✅ |
| Job queue wait time | `frappe.monitor` job.wait | ✅ |
| Scheduler heartbeat | app-emitted gauge | ✅ |
| Worker/scheduler uptime | Frappe Cloud dashboard | ⚠️ not exportable |
| Requests/min, CPU time | Frappe Cloud dashboard | ⚠️ not exportable |

### Dashboard 4 — MariaDB ❌ **Not buildable**

Connections, query activity, locks, InnoDB internals need `mysqld_exporter` on the DB host. Not possible without a Dedicated Server plus written confirmation from Frappe support.

**Partial substitute:** slow-query analytics exist in the Frappe Cloud dashboard; DB storage syncs 6-hourly there.¹⁵ Application-side you *can* emit query count and duration per request from `frappe.monitor` data.

### Dashboard 5 — Redis ❌ **Not buildable**

Memory, evictions, hit/miss, command stats need `redis_exporter` on the host.

**Partial substitute:** cache hit/miss ratio can be instrumented *in application code* around `frappe.cache` calls if it proves worth the effort.

### Dashboard 6 — AI Encounter ✅ **Fully buildable, highest value**

This is the strongest dashboard available, because `AI Prompt Log` and `AI Encounter Session` already store exactly the right numeric fields.

| Panel | Source field | Safe? |
|---|---|---|
| Sessions started / completed | `AI Encounter Session.status` | ✅ |
| Session success rate | status + `close_reason` | ✅ |
| Session duration p50/p95 | `duration_seconds` | ✅ |
| Deepgram connect success rate | app counter | ✅ |
| Transcription reconnect count | app counter | ✅ |
| LLM latency p50/p95/p99 | `latency_ms` | ✅ |
| Provider vs tool time split | `provider_ms`, `tool_ms` | ✅ |
| LLM error rate by model | `error`, `model` | ✅ |
| Token consumption trend | `tokens_in`, `tokens_out` | ✅ |
| Cost trend (indicative) | `cost_estimate_usd` | ⚠️ trend only — Prometheus is explicitly unsuitable as a billing source of record¹³ |
| Failure reasons | `error_code` | ✅ enum only |

**Prohibited on this dashboard:** `raw_response`, `unmatched_details`, `error_message`, `patient`, `encounter`, transcript text, any suggestion content.

---

## 9. Alert Specification

Principle: an alert must correspond to **a human action**. If nobody would do anything at 3am, it is a dashboard panel, not an alert. This is the main defence against alert fatigue.

### P0 — Critical (wake someone)

| Field | Value |
|---|---|
| **Name** | Backend unreachable |
| Signal | `probe_success == 0` on `/api/method/ping` |
| Source | Synthetic monitoring |
| Threshold | 2 consecutive failures, ≥2 regions |
| Evaluation | 1 min interval, 2 min pending |
| Action | Check Frappe Cloud status, escalate to support |
| Notification | PagerDuty + phone |
| **Why** | Clinic cannot see patients. Two regions avoids single-probe false positives |

| Field | Value |
|---|---|
| **Name** | Frontend unreachable |
| Signal | `probe_success == 0` on login page |
| Threshold | 2 consecutive, ≥2 regions |
| Evaluation | 1 min / 2 min pending |
| Notification | PagerDuty |
| **Why** | Staff cannot log in even if the backend is healthy |

| Field | Value |
|---|---|
| **Name** | Sustained 5xx |
| Signal | 5xx rate > 25% of requests |
| Threshold | 5 min sustained |
| Notification | PagerDuty |
| **Why** | Partial outage — up but not working. Catches what a ping check cannot |

### P1 — High (same working day)

| Name | Signal | Threshold | Eval | Action | Notify |
|---|---|---|---|---|---|
| Error rate spike | 5xx rate | >5% for 10 min | 1m | Triage in Explore | Slack #alerts-critical |
| Latency degradation | p95 request duration | >3s for 10 min | 1m | Identify slow endpoint | Slack #alerts-critical |
| AI session failure rate | failed ÷ started | >20% for 15 min | 5m | Check Deepgram/LLM status | Slack #alerts-critical |
| Login failure spike | auth failure counter | >30% for 10 min | 1m | Possible auth/JWT breakage | Slack #alerts-critical |
| TLS expiry | cert days remaining | <14 days | 1h | Renew | Slack |
| Background jobs stalled | job completion rate | 0 for 15 min while requests flow | 5m | Check workers | Slack #alerts-critical |

### P2 — Medium (next working day)

| Name | Signal | Threshold | Eval | Notify |
|---|---|---|---|---|
| Latency creep | p95 | >1.5s for 1h | 5m | Slack #alerts |
| Error trend rising | 5xx rate | >1% for 1h | 5m | Slack #alerts |
| LLM latency degradation | `latency_ms` p95 | >2× 7-day baseline | 15m | Slack #alerts |
| AI cost anomaly | daily `cost_estimate_usd` | >2× 7-day mean | 1h | Slack #alerts |
| Job queue backlog | job wait p95 | >60s for 30 min | 5m | Slack #alerts |

### Anti-spam rules

- **Mute timings** for clinic closed hours on P2 only — never P0
- **Group by** `service` + `severity`, 5-minute group wait
- Every alert carries a runbook link in its annotation
- Any alert firing >3×/week without action gets deleted or retuned — a standing review item
- No alert on a signal nobody has agreed to own

---

## 10. Phased Implementation Plan

### Phase 0 — Research & Design ✅ *this document*

**Goal:** know what is possible before spending engineering time.
**Output:** this document. **Remaining:** the four open questions in §13.
**Complexity:** — **Rollback:** n/a

---

### Phase 1 — Synthetic Monitoring Only

| | |
|---|---|
| **Goal** | Answer "is Remedisys up?" — currently unanswerable |
| **Why** | Highest value per hour of any phase. Zero code, zero PHI risk, works despite every Frappe Cloud constraint |
| **Components** | Grafana Cloud free account + Synthetic Monitoring |
| **Prerequisites** | Grafana Cloud signup; agreement on notification channel |
| **Steps** | 1. Create Grafana Cloud stack (free tier, **US** region) 2. Enable Synthetic Monitoring 3. API Endpoint check → `https://chavitosclinic.frappe.cloud/api/method/ping`, valid status `200`, regex body match `pong` 4. API Endpoint check → `https://ehr.narzim.com/login`, valid status `200`, regex body match `Narzim` 5. 3 US probe locations 6. Import the stock synthetic dashboard |
| **Config** | **Frequency 180s — not 60s. See the execution budget below.** No auth headers in checks (both endpoints are public). TLS validation left ON. |
| **Execution budget** | Free tier includes **100k API test executions/month**. Executions ≈ checks × probes × minutes-per-month, so 2 checks × 3 probes at 60s = **259,200/month — 2.6× over the free limit**. Workable: 2 checks × 3 probes @ **180s** = 86,400 ✅, or 2 checks × 2 probes @ 120s = 86,400 ✅. Cost: detection time rises to ~6 min. *Verify in the Synthetic Monitoring UI's built-in calculator before saving.* Note that accounts created after 2026-02-13 get **no** active-series/log credits, so probe metrics consume the 10k-series quota. |
| **No separate TLS check** | HTTP checks already emit SSL/cert-expiry metrics. A dedicated TLS check would only consume execution budget. *Confirm the metric name in Explore after the first run, then build the TLS alert.* |
| **Security** | ⚠️ **Probe only unauthenticated endpoints.** Never store a real session token in a synthetic check |
| **Expected output** | Uptime %, latency by region, TLS expiry |
| **Validation** | Deliberately break a check (wrong path) → confirm it goes red and notifies |
| **Rollback** | Delete checks. No production impact whatsoever |
| **Complexity** | **Very low** — half a day |

---

### Phase 2 — Vercel Drains → Grafana Cloud

| | |
|---|---|
| **Goal** | Frontend/BFF logs and function metrics in Grafana |
| **Why** | Config-only; no application code; Pro plan already active |
| **Components** | Vercel Drains (logs), Grafana Cloud Loki via OTLP |
| **Prerequisites** | Phase 1; `FRAPPE_DEBUG=false` verified in every drained environment |
| **Steps** | 1. Obtain OTLP endpoint + token from Grafana Cloud 2. Create a log drain → custom endpoint 3. Enable drain signature verification⁴ 4. Confirm labels are low-cardinality (`service`, `env`, `level`) 5. Build the Application dashboard 6. Set a Vercel spend alert on drain volume |
| **Security** | Verify drain signatures; token in Vercel env only; **audit one hour of real drained logs by eye for PHI before considering it done** |
| **Expected output** | Searchable logs, function error rate/duration |
| **Validation** | Trigger a known 500 → find it in Explore within 60s |
| **Rollback** | Disable drain in Vercel — instant, no deploy |
| **Cost** | $0.50/GB uncompressed⁴ |
| **Complexity** | **Low** — 1–2 days including the PHI audit |

---

### Phase 3 — Backend Application Metrics

| | |
|---|---|
| **Goal** | Request rate, error rate, latency, job outcomes, AI operations from Frappe |
| **Why** | The core observability gap. Nothing today reports whether the API is healthy |
| **Components** | `opentelemetry-sdk` + `opentelemetry-exporter-otlp-proto-http` inside `remedisys_healthcare_ai` |
| **Prerequisites** | ⚠️ **Spike first:** validate OTel init under Frappe's gunicorn pre-fork workers. This is an unvalidated assumption (§3.6) and could invalidate the approach |
| **Steps** | 1. Spike: OTel MeterProvider in a post-fork hook; confirm no duplicate/lost series 2. `services/telemetry.py` — single init point, feature-flagged **off** by default 3. Decorator on `api/v1/*` recording method, status, duration — **method name only, never args** 4. Attribute-filter allowlist (mirror `sanitize.ts` discipline) 5. RQ hooks for job success/failure/wait 6. Scheduled job aggregating `AI Prompt Log` numerics → gauges 7. OTLP HTTP push; endpoint + token via `site_config.json` 8. Build Application + Frappe + AI dashboards |
| **Config** | Feature flag per Section 9 of CLAUDE.md — default OFF, enable per environment |
| **Security** | Allowlist attributes, never denylist. Unit-test that a patient id cannot reach an attribute. Token never in repo |
| **Expected output** | Dashboards 2, 3, 6 populated |
| **Validation** | Load-test staging; confirm counts match Frappe Cloud's own request count within tolerance; assert no PHI in 24h of series labels |
| **Rollback** | Feature flag off → SDK never initialises |
| **Complexity** | **Medium-high** — 1–2 weeks. The gunicorn spike is the risk |

---

### Phase 4 — Alerting

| | |
|---|---|
| **Goal** | Find out about outages before the clinic phones |
| **Components** | Grafana Alerting, contact points, notification policies |
| **Prerequisites** | Phases 1–3; an agreed on-call owner |
| **Steps** | 1. Contact points: PagerDuty (P0), Slack (P1/P2) 2. Notification policy tree by `severity` 3. P0 rules first, run one week, tune 4. Then P1, then P2 5. Runbook link on every rule 6. Mute timings for closed hours on P2 only |
| **Security** | Alert annotations must not template patient data into notifications — a firing alert containing an MRN in Slack is a breach |
| **Validation** | Trigger each P0 deliberately; confirm delivery and that resolution clears |
| **Rollback** | Pause rules — evaluation continues, notifications stop |
| **Complexity** | **Medium** — 3–5 days plus a tuning week |

---

### Phase 5 — Tracing *(only if justified)*

**Do not start this by default.** Enter only when a real incident has been hard to diagnose *because* request flow across Vercel → Frappe was opaque. Tracing is the most expensive signal to collect and the easiest to leak identifiers through.

| | |
|---|---|
| **Components** | `@vercel/otel`, Vercel Trace Drains, OTel Python, Tempo |
| **Steps** | 1. `instrumentation.ts` with `registerOTel` 2. Configure `propagateContextUrls` for the Frappe domain only¹ 3. Backend manual spans on `api/v1/*`, correlated via existing `frappe.monitor.get_trace_id()` 4. **Strip `http.url` query strings** before export 5. Trace drain → Tempo 6. Trace↔log correlation |
| **Security** | ⚠️ Auto-instrumentation captures full URLs by default — the single biggest leak risk in the entire plan. Explicitly excluded: **browser/RUM tracing** (URLs carry MRNs, high volume, low value) |
| **Complexity** | **High** |

---

### Phase 6 — Production Hardening

| | |
|---|---|
| **Steps** | SSO for Grafana; RBAC (engineers ≠ clinic admins); dashboards as code in git; token rotation; retention per §5.4; cost alerts on drain volume and series count; a synthetic check *on Grafana itself*; document the "observability is down" procedure |
| **Note** | Monitoring the monitoring: if Grafana Cloud is down you must still learn about outages. A second cheap uptime service (or Better Stack free tier) as an independent watchdog is reasonable here |
| **Complexity** | **Medium**, ongoing |

---

## 11. Cost & Operational Analysis

### Self-hosted

| Item | Cost |
|---|---|
| VM (4 vCPU / 16 GB) | ~$40–80/mo |
| Object storage (Loki + Tempo chunks) | ~$5–25/mo |
| Backups | ~$5–10/mo |
| **Infrastructure subtotal** | **~$50–115/mo** |
| **Engineering** | ~20–40h setup, then **4–8h/month** ongoing |

At any realistic loaded engineering rate the maintenance time dominates the cash cost by an order of magnitude. That is the real price, and it is why self-hosting is rejected.

### Grafana Cloud

Official pricing⁵:

| Signal | Free tier | Pro |
|---|---|---|
| Metrics | 10k series, 14d | $19/mo platform fee (incl. 10k series), then $6.50/1k series, 13mo retention |
| Logs | 50 GB, 14d | $19/mo (incl. 50 GB); $0.05/GB process + $0.40/GB write + $0.10/GB retain + $0.003/GB query, 30d |
| Traces | 50 GB, 14d | same structure as logs, 30d |
| Users | 3 | — |

**Plus Vercel Drains: $0.50/GB uncompressed⁴** — independent of Grafana, and billed on uncompressed JSON regardless of delivery encoding, so budget above what Grafana reports receiving.

### Expected monthly cost for Remedisys

| Phase | Grafana | Vercel Drains | Total |
|---|---|---|---|
| 1 (synthetic) | $0 | $0 | **$0** |
| 2 (+ logs) | $0 (within free) | ~$5–15 | **~$5–15** |
| 3 (+ metrics) | $0 (single clinic well under 10k series) | ~$5–15 | **~$5–15** |
| 4 (+ alerting) | $0 | same | **~$5–15** |
| 5 (+ tracing) | possibly Pro | ~$15–40 | **~$50–90** |

**Marked as estimate:** volumes are extrapolated from a single-clinic pilot, not measured. Re-forecast after Phase 2 gives real numbers. The 3-user Grafana limit is the most likely first thing to force a paid tier — not data volume.

---

## 12. What Grafana Is NOT

| Claim | Reality |
|---|---|
| Stores application data | **No.** Query/visualisation layer; backends store⁶ |
| Replaces MariaDB | **No.** Never a source of record. Prometheus is explicitly unsuitable where 100% accuracy is needed¹³ |
| Replaces application logs | **No.** Loki *aggregates* what you ship; you still emit them |
| Replaces error tracking | **No.** No stack-trace grouping, no release regression tracking, no source maps, no issue assignment |
| Replaces Sentry | **No.** See §13 |
| Monitors everything automatically | **No.** It visualises what you instrument. Nothing is automatic |
| Auto-discovers backend metrics | **No.** Prometheus service discovery finds *targets*, not meaning. Frappe exposes no metrics endpoint — verified: no `opentelemetry` or `prometheus_client` anywhere in the Frappe source tree |
| Understands Frappe | **No.** No Frappe/ERPNext awareness. Every DocType metric is ours to write |
| Understands business logic | **No.** "Encounter signed" is meaningless until you emit it |
| Provides instrumentation | **No.** That is OpenTelemetry's job, and it is application work |

---

## 13. Grafana vs Sentry vs Better Stack

| Capability | Grafana Stack | Sentry | Better Stack |
|---|---|---|---|
| Infrastructure metrics | ✅ strong | ❌ | ⚠️ basic |
| Application metrics | ✅ strong | ⚠️ limited | ⚠️ basic |
| Logs | ✅ Loki | ⚠️ breadcrumbs only | ✅ strong |
| Tracing | ✅ Tempo | ✅ good | ⚠️ limited |
| **Error tracking** | ❌ **weak** | ✅ **best in class** | ⚠️ basic |
| Performance monitoring | ✅ metrics-level | ✅ code-level | ⚠️ basic |
| Alerting | ✅ very flexible | ✅ error-focused | ✅ good |
| Incident management | ⚠️ Grafana IRM (paid) | ⚠️ basic | ✅ strong |
| Uptime monitoring | ✅ synthetic | ❌ | ✅ **best in class** |
| Developer debugging | ⚠️ aggregate view | ✅ **stack + release + suspect commit** | ⚠️ basic |
| Healthcare privacy control | ✅ you control emission | ⚠️ needs aggressive scrubbing | ⚠️ moderate |
| Self-hosting | ✅ fully | ✅ possible, heavy | ❌ |
| Operational complexity | high self-hosted / low cloud | low | **lowest** |

### Recommendation: **Grafana + Sentry**, in that order — not either alone

They answer different questions and neither substitutes:

- **Grafana** answers *"is the system healthy, and is it getting worse?"* — aggregate, trend, threshold.
- **Sentry** answers *"what exactly broke, in which release, on which line, for how many users?"* — stack traces, grouping, regression detection, release health.

Trying to debug a `TypeError` in a Next.js route from Loki logs is genuinely miserable work. Equally, Sentry will never tell you p95 latency is drifting, and it has no synthetic uptime checks.

**Better Stack** is the pragmatic third option, and honestly the fastest path to *something* — excellent uptime monitoring plus incident management with almost no setup. Its weakness is depth: it will not give you PromQL, custom application metrics, or the AI operational dashboard that is arguably the highest-value artefact in this whole plan.

**Suggested end state:**

```
Grafana Cloud   → metrics, logs, uptime, dashboards, alerting
Sentry          → error tracking + release health (add after Phase 4)
PostHog         → product analytics (already live)
```

**Marked as assumption:** I have not verified Better Stack's current pricing or healthcare/DPA posture. If it is seriously considered, that needs checking against their official documentation before any decision.

---

## 14. Final Recommendation

### Deploy now
1. **Grafana Cloud free tier** — managed, no infrastructure
2. **Synthetic monitoring** — `/api/method/ping` + frontend login, 3 US probes @ 180s
3. **Two P0 alerts** — backend down, frontend down

That is Phase 1: roughly half a day, $0, zero PHI risk, and it closes the single biggest gap — **you currently have no way to know the system is down except a phone call from the clinic.**

### Do NOT deploy yet
- ❌ Self-hosted anything — a second production system holding healthcare-adjacent data
- ❌ Grafana Alloy — nowhere to run it
- ❌ Tempo / distributed tracing — highest leak risk, lowest current value
- ❌ Browser/RUM tracing — URLs carry MRNs
- ❌ Any MariaDB/Redis/host exporter — **not possible on Frappe Cloud**

### Add later
- Phase 2 Vercel Drains → when frontend debugging hurts
- Phase 3 backend metrics → after the gunicorn spike passes
- Phase 4 alerting → once there is an on-call owner
- Sentry → after Phase 4
- Phase 5 tracing → only after a specific incident justifies it

### What each component receives

| Component | Receives |
|---|---|
| Synthetic probes | HTTP status, latency, TLS expiry. **No application data at all** |
| Loki | Structured logs: level, service, route template, error type, hashed user |
| Prometheus | Numeric series with low-cardinality labels only |
| Tempo *(later)* | Spans with query strings stripped |

### What must never enter

Patient names · MRNs · DOB · diagnoses · medications · clinical notes · SOAP content · **Deepgram transcripts** · AI suggestions · `raw_response` · access/refresh tokens · cookies · `Authorization` headers · API keys · raw request/response bodies · free-text exception messages.

### Expected cost
**$0/month** through Phase 1. **~$5–15/month** through Phase 4, dominated by Vercel Drains rather than Grafana.

### Operational complexity
**Very low** for Phases 1–2. **Medium** at Phase 3 — that is where real engineering time goes.

### Security risks (ranked)

1. **OTel auto-instrumentation capturing full URLs with query strings** — the single most likely way PHI leaks. Must be explicitly configured, never left to defaults
2. **Vercel Drains shipping whatever the app logs** — `FRAPPE_DEBUG=true` anywhere drained would ship every BFF→Frappe call
3. **Exception messages built from record data** — Frappe does this routinely
4. **High-cardinality labels** — a `patient` label is both a cost incident and a breach
5. **Grafana Labs as processor** — DPA required before any PHI-adjacent telemetry
6. **Alert notifications templating patient data into Slack**

### First implementation task

**Create a Grafana Cloud free account and add one synthetic HTTP check against `/api/method/ping`.**

Nothing else. No code, no dependency, no deploy, nothing to roll back. It will tell you something true within five minutes that you cannot currently find out at all.

---

## 15. Phase-1 Task List

**Targets verified live 2026-08-11** — see the verification table in §16.

- [ ] Create Grafana Cloud account (free tier), **US region** (backend is AWS us-east-1)
- [ ] Enable Synthetic Monitoring
- [ ] API Endpoint check `remedisys-backend-ping`: `https://chavitosclinic.frappe.cloud/api/method/ping` — valid status `200`, regex body `pong`, **180s**, 3 US probes, labels `service=backend env=production`
- [ ] API Endpoint check `remedisys-frontend-login`: `https://ehr.narzim.com/login` — valid status `200`, regex body `Narzim`, **180s**, same 3 probes, labels `service=frontend env=production`
- [ ] Confirm monthly executions in the UI calculator are **under 100k**
- [ ] Contact point: Slack `#alerts` (PagerDuty deferred until an on-call owner exists)
- [ ] P0 alert: backend unreachable — `sum by (instance) (probe_success{job="remedisys-backend-ping"}) < 2`, eval 1m, pending 5m
- [ ] P0 alert: frontend unreachable — same query, frontend job
- [ ] Deliberately break one check; confirm it fires and then resolves
- [ ] Record the Grafana Cloud stack URL and token location in `docs/platform/`
- [ ] Decide the DPA question with Grafana Labs **before** Phase 2 ships any application log

**Not blocking Phase 1, but resolve soon:**

- [ ] Confirm production vs pre `FRAPPE_URL` — only `chavitosclinic.frappe.cloud` resolves, so production and pre may share **one backend**. If so, test data and real clinic data are in the same database, which is a bigger problem than observability
- [ ] Confirm whether the Frappe Cloud plan is a **shared** or **private** bench group (determines whether SSH exists at all)
- [ ] Ask Frappe Cloud support, in writing: *can any monitoring agent be installed on a Dedicated Server?* — determines if infrastructure metrics are ever reachable
- [ ] Confirm the team actually uses Slack — there is no reference to it anywhere in either repository

**Explicitly not in Phase 1:** no application code, no dependency added, no `instrumentation.ts`, no OTel SDK, no exporter, no Alloy.

---

## 16. Phase-1 Readiness Verification

Performed 2026-08-11 against the live environment. Every row was probed, not assumed.

| # | Item | Result |
|---|---|---|
| 1 | Production frontend | **`https://ehr.narzim.com`** → `/login`, HTTP 200, Vercel `dpl_Dhfm5j9MABJvyoxpUE6vi` |
| 2 | Pre frontend | `https://preehr.narzim.com` → `dpl_3NkSKyJ5UapDGoxsexvsP` (separate deployment) |
| 3 | Marketing site | `https://www.narzim.com` → separate deployment, out of scope |
| 4 | `app.narzim.com` | NXDOMAIN |
| 5 | Backend | **`https://chavitosclinic.frappe.cloud`** — the only Frappe site that resolves; other candidates return 307 |
| 6 | **Ping contract** | `GET /api/method/ping` → **HTTP 200, `{"message":"pong"}`, 0.75s** ✅ |
| 7 | Auth required? | **No** — both targets respond to fully anonymous requests |
| 8 | Rate limiting | `x-ratelimit-limit: 7200000000`, 7.1B remaining — no concern at 180s |
| 9 | Backend host | `ec2-34-226-39-121.compute-1.amazonaws.com` → **AWS us-east-1** (Ashburn, VA) |
| 10 | **Grafana Cloud region** | **US** — matches the backend region |
| 11 | Correlation header | `x-frappe-request-id` present — useful for Phase 3/5 |
| 12 | TLS | All Let's Encrypt, platform-managed: backend 2026-09-15, prod frontend 2026-09-27, pre 2026-10-04 |
| 13 | Vercel plan | **Pro** — relevant to Phase 2 Drains, **not** to Phase 1 |
| 14 | PostHog on production | **Off** — no `phc_` key in any of 21 production chunks. The unmasked-replay issue never reached production |

**Blockers found:**

1. No Grafana Cloud account exists yet.
2. No evidence the team uses Slack — no reference in either repository. A notification channel must be chosen.
3. The 60s/3-region configuration originally written in §10 **exceeds the free tier by 2.6×**. Corrected to 180s in §10 and §15.

**Note on terminology:** Synthetic Monitoring is a Grafana Cloud feature and is unrelated to the Vercel plan. Vercel Pro matters only for Drains in Phase 2.

**Safety confirmation:** no application code, no dependency, and no production deployment is required for Phase 1. Probes run from Grafana-hosted locations against endpoints that are already public, and observe only HTTP status, latency, and a fixed string. No patient data can enter this telemetry.

---

## Open Questions

1. ~~Production frontend and backend URLs~~ — **resolved**, see §16.
2. ~~Grafana Cloud region~~ — **resolved: US**, see §16.
3. **Production vs pre backend.** Only one Frappe site resolves. If both environments share it, test data and real clinic data live in one database — a bigger problem than observability. Needs the `FRAPPE_URL` value from both Vercel projects.
4. **Shared or private bench group?** Determines whether SSH exists. Does not change the recommendation, but changes what is diagnosable during an incident.
5. **Dedicated Server agent policy?** The only route to real infrastructure metrics. Frappe Cloud docs are silent — needs a written answer from support.
6. **Who owns on-call?** Phase 4 is meaningless without this. An alert nobody receives is worse than no alert, because it creates false confidence.
7. **Notification channel** — Slack, or email to start with?
8. **Is the brief's React+Vite stack a future migration, or was it a mistake?** The frontend design assumes Next.js as it exists today.

---

## References

1. Vercel — Instrumentation. https://vercel.com/docs/tracing/instrumentation (updated 2026-02-17)
2. Frappe Cloud — SSH Access. https://docs.frappe.io/cloud/benches/ssh
3. Grafana Cloud — Synthetic Monitoring. https://grafana.com/docs/grafana-cloud/testing/synthetic-monitoring/
4. Vercel — Working with Drains. https://vercel.com/docs/drains (updated 2026-07-22)
5. Grafana — Pricing. https://grafana.com/pricing/
6. Grafana — Introduction. https://grafana.com/docs/grafana/latest/introduction/
7. Grafana Loki — Overview. https://grafana.com/docs/loki/latest/get-started/overview/
8. Grafana Tempo — Architecture. https://grafana.com/docs/tempo/latest/introduction/architecture/
9. Grafana Alloy — Introduction. https://grafana.com/docs/alloy/latest/introduction/
10. Grafana Cloud — OTLP (architecture recommendation). https://grafana.com/docs/grafana-cloud/send-data/otlp/send-data-otlp/
11. Grafana Cloud — Send data via OTLP. https://grafana.com/docs/grafana-cloud/send-data/otlp/send-data-otlp/
12. Grafana — Alerting fundamentals. https://grafana.com/docs/grafana/latest/alerting/fundamentals/
13. Prometheus — Overview. https://prometheus.io/docs/introduction/overview/
14. OpenTelemetry — Python getting started. https://opentelemetry.io/docs/languages/python/getting-started/
15. Frappe Cloud — Site Monitoring. https://docs.frappe.io/cloud/sites/monitoring
16. Frappe Cloud — Logs. https://docs.frappe.io/cloud/logs
17. Frappe Cloud — Servers Introduction. https://docs.frappe.io/cloud/servers/servers-introduction
18. Frappe Cloud — FAQ, Architecture and Security. https://docs.frappe.io/cloud/faq/architecture-and-security

**Repository facts verified locally, not from documentation:** `Healthcare_next_app/package.json` (Next.js 16.2.7, no Vite/TanStack Router/Zustand); `apps/frappe/frappe/monitor.py` (captures `request_ip`, `path`; no OpenTelemetry or `prometheus_client` anywhere in the Frappe tree); `ai_prompt_log.json` and `ai_encounter_session.json` field lists; `site_config.json` (`monitor` not enabled).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-11 | Sarvesh | Initial version (header backfilled from git history) |
