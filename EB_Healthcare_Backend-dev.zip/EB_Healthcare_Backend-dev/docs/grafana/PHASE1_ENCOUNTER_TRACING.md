# Phase 1 (revised) — Guided Encounter Tracing on Grafana Cloud

**Doc status:** draft · **Created:** 2026-09-23 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.0

**Status:** Proposed. Nothing installed, no Grafana Cloud account exists yet. Do not cite as decided.
**Scope:** The Guided Encounter (V2) flow only. Frontend, BFF and Frappe.
**Amends:** [`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md) §10. See §1 below.

---

## 1. What changed, and why this document exists

### 1.1 Phase 1 has been redefined

[`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md) (2026-08-11) defined the phases like this:

| Phase | Old scope |
|---|---|
| 1 | Synthetic monitoring only |
| 2 | Vercel Drains to Grafana Cloud |
| 3 | Backend application metrics |
| 4 | Alerting |
| 5 | Tracing, *"only if justified"*, complexity High |

Phase 1 is now **tracing the Guided Encounter end to end**. That is the old Phase 5, pulled to the front.

**Why the change.** The Guided Encounter is the highest-risk flow in the product. It crosses three
runtimes, two external vendors (Deepgram, the LLM provider), and a token rotation step. When it
fails today, nobody can say where. Synthetic monitoring would tell us the site is up. It would not
tell us why one clinician's encounter lost its transcript.

The old document's reasoning still holds in general: tracing is the most expensive signal and the
easiest to leak identifiers through. That reasoning is not overruled. It is accepted, and §5 below
is the price of admission.

### 1.2 This reverses one prior exclusion

Old Phase 5 explicitly excluded browser tracing:

> Explicitly excluded: **browser/RUM tracing** (URLs carry MRNs, high volume, low value)

**That exclusion is reversed for Phase 1**, for one reason: the requirement is frontend to backend
correlation. Without the browser leg we cannot tell a slow encounter caused by the API from one
caused by the clinician's laptop or the clinic's wifi. That distinction is the whole point.

The MRN-in-URL objection is real and is answered, not waved away. We already solved it for PostHog
with `templateRoute()` in `sanitize.ts`. The same function is reused here, and Faro is configured to
send only templated routes. See §5.3.

### 1.3 Relationship to the Splunk evaluation

Splunk Observability Cloud Free Edition was evaluated on 2026-09-23 against the same Phase 1 scope.
Full evaluation: [`prompts/2026-09-23-splunk-observability-phase1-evaluation.md`](../_archive/prompts/2026-09-23-splunk-observability-phase1-evaluation.md).

Outcome: **does not satisfy Phase 1.** Three structural failures.

| Requirement | Splunk Free | Grafana Cloud Free |
|---|---|---|
| Distributed tracing across three tiers | ✅ Excellent (NoSample, 100% of traces) | ✅ Tempo, no sampling needed at our volume |
| Logs stored and correlated with traces | ❌ **Observability Cloud stores no logs at all.** Log Observer Connect only queries logs already in Splunk Cloud Platform, a separate paid product | ✅ Loki, 50 GB free, same platform |
| Trace retention | ❌ 8 days default | ⚠️ 14 days free, 30 days on Pro |
| Search traces by `encounter_id` | ✅ Trace Analyzer | ✅ TraceQL |
| Admin-readable encounter timeline | ❌ No supported way to build one | ⚠️ Partial. See §8 |
| BAA available | ❌ Explicitly excluded for free licences | ❓ Unconfirmed. See §11 |
| Cost at our scale | Paid floor is five figures per year plus a second product | $0 within free tier |

The deciding factor was logs. Splunk's paid tiers do not fix it either, which is unusual and is why
the evaluation landed on "do not proceed" rather than "start free, upgrade later".

---

## 2. What Phase 1 must deliver

Taken from the 2026-09-23 scope statement, unchanged:

1. Complete technical trace of one Encounter.
2. Admin or support can search by `encounter_id` and understand what happened.
3. The traced path: Encounter open → consent → AI session → Deepgram → recording → transcript
   autosave → token rotation → SOAP generation → encounter save → sign.
4. Frontend → BFF → Frappe correlation.
5. Latency, status, errors, warnings, failures.
6. `session_id` + `encounter_id` + `trace_id` correlation.
7. Dashboards and alerts.
8. PHI-safe. No transcript, audio, SOAP content, patient details, tokens, JWTs, or LLM
   prompt/response in telemetry.
9. Telemetry never blocks or breaks the Encounter flow.
10. Maximum use of free tier. Pay only when forced.
11. No custom telemetry database, no custom observability platform.

---

## 3. Architecture

### 3.1 The constraint that shapes everything

From [`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md) §4.1, verified against Frappe Cloud's
own documentation: **no root access inside a bench, no system packages, no host-resident agent.**

This has a consequence that is easy to get wrong. The textbook OpenTelemetry design puts a Collector
next to the application and does attribute scrubbing there, because a Collector is one place to fix
a leak for every service at once. **We cannot run a Collector next to Frappe.**

So redaction has to move into the process. For Frappe that means a custom `SpanProcessor` inside
`remedisys_healthcare_ai` that runs on every span before export. For the BFF it means a span
processor registered in `instrumentation.ts`. For the browser it means a Faro beforeSend hook.

Three redaction points instead of one. Each needs its own test. This is the single biggest
difference between this design and any Grafana tutorial you will read.

### 3.2 Diagram 1 — Phase 1 trace flow

```mermaid
flowchart TD
    subgraph BROWSER["Browser — clinician's laptop"]
        FARO["Grafana Faro Web SDK<br/>@grafana/faro-web-sdk<br/>+ faro-web-tracing"]
        SAN["sanitize.ts :: templateRoute()<br/>reused from PostHog"]
        FBS["beforeSend hook<br/>drop event if attribute not on allowlist"]
        FARO --> SAN --> FBS
    end

    subgraph VERCEL["Vercel — Next.js 16 BFF (Fluid Compute, Node runtime)"]
        VOTEL["@vercel/otel + OTLP exporter"]
        BFFSP["RedactingSpanProcessor<br/>strip http.url query, headers, bodies"]
        ST["emit Server-Timing: traceparent<br/>+ Access-Control-Expose-Headers"]
        WU["waitUntil(forceFlush)<br/>never blocks the response"]
        VOTEL --> BFFSP --> WU
    end

    subgraph FRAPPE["Frappe Cloud — remedisys_healthcare_ai"]
        POTEL["opentelemetry-sdk (Python)<br/>WSGI + requests + redis + pymysql"]
        FSP["RedactingSpanProcessor<br/>in-process, no Collector possible"]
        RQ["RQ worker instrumentation<br/>autosave + SOAP jobs"]
        POTEL --> FSP
        RQ --> FSP
    end

    subgraph VENDORS["External"]
        DG["Deepgram WS<br/>manual spans only"]
        LLM["LLM provider<br/>GenAI spans, content capture OFF"]
    end

    subgraph GC["Grafana Cloud — free tier, US region"]
        TEMPO["Tempo — traces, 50 GB, 14d"]
        LOKI["Loki — logs, 50 GB, 14d"]
        MIMIR["Mimir — metrics, 10k series, 14d"]
        ALERT["Grafana Alerting"]
    end

    subgraph VIEW["Consumers"]
        ENG["Engineer<br/>Explore + TraceQL"]
        ADMDASH["Admin dashboard<br/>aggregate health"]
        LOOKUP["Encounter Lookup page<br/>Next.js, see §8.3"]
    end

    FBS -->|"OTLP/HTTP"| TEMPO
    WU -->|"OTLP/HTTP"| TEMPO
    FSP -->|"OTLP/HTTP"| TEMPO
    FSP --> LOKI
    FSP --> MIMIR
    WU --> LOKI

    FBS -.->|"traceparent"| VOTEL
    ST -.->|"Server-Timing"| FARO
    VOTEL -.->|"traceparent"| POTEL
    POTEL --> DG
    POTEL --> LLM

    TEMPO --> ENG
    MIMIR --> ADMDASH
    TEMPO --> LOOKUP
    MIMIR --> ALERT
    LOKI --> ALERT
```

### 3.3 Components and endpoints

| Leg | Library | Destination |
|---|---|---|
| Browser | `@grafana/faro-web-sdk` + `@grafana/faro-web-tracing` | Faro Collector endpoint from the Frontend Observability app |
| BFF | `@vercel/otel` with an OTLP/HTTP exporter | `https://otlp-gateway-prod-<region>.grafana.net/otlp` |
| Frappe | `opentelemetry-sdk` + `opentelemetry-instrumentation-*` | same OTLP gateway |
| Auth | HTTP Basic. Username is the Grafana Cloud **instance ID**, password is an **access policy token** with the OTLP scopes | — |
| Region | **US.** The backend is AWS `us-east-1` per [`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md) §16 | — |

**No Grafana Alloy anywhere.** Not on Frappe Cloud (impossible), not on Vercel (no sidecar), not
self-hosted (a second production system holding healthcare-adjacent telemetry, rejected in §6 of the
research doc). Everything pushes OTLP directly.

**No Vercel Drains in Phase 1.** The old Phase 2 assumed Drains at $0.50/GB. Application traces do
not need them. `@vercel/otel` exports straight to Grafana. Drains remain a Phase 2 option for
platform-level logs that the application never sees. This saves real money and one moving part.

---

## 4. Trace model

### 4.1 One trace per step, linked by `encounter_id`

A Guided Encounter can run 30 minutes or more. Do **not** model it as one trace.

| Step | Trace root | Typical duration |
|---|---|---|
| Encounter open | `encounter.open` | < 2s |
| Consent capture | `encounter.consent` | < 1s |
| AI session start | `ai.session.start` | < 3s |
| Deepgram connect | `deepgram.connect` | < 2s |
| Recording segment | `deepgram.segment` | per segment |
| Transcript autosave | `transcript.autosave` | < 1s, repeats |
| Token rotation | `auth.token.rotate` | < 1s |
| SOAP generation | `ai.soap.generate` | 5–40s |
| Encounter save | `encounter.save` | < 2s |
| Encounter sign | `encounter.sign` | < 2s |

Every root span in that table carries the same `encounter_id`. That attribute is what stitches the
story together, not the trace ID.

**Why not one long trace.** Three reasons. A single 30-minute trace renders as an unreadable
waterfall. Partial traces are hard to alert on. And a long-running trace is held in memory by the
SDK, which is exactly the kind of thing that can degrade the flow we promised not to degrade.

> **Open question OQ-1.** Tempo assembles spans by trace ID at query time and does not impose
> Splunk's hard 10-minute accumulation window. Verify how Tempo behaves for a trace whose spans
> arrive over 30+ minutes before relying on any long-trace behaviour. Test before Phase 1 exit.

### 4.2 Context propagation

```
Browser (Faro)  --traceparent-->  BFF  --traceparent-->  Frappe
Browser (Faro)  <--Server-Timing--  BFF
```

Two things must be configured or the browser leg silently detaches:

1. BFF emits `Server-Timing: traceparent;desc="00-<traceid>-<spanid>-01"` on every response.
2. BFF sets `Access-Control-Expose-Headers: Server-Timing`, and allows `traceparent` in
   `Access-Control-Allow-Headers` if the origins differ.

Faro propagates `traceparent` outbound only to URLs you explicitly allow. Set that allowlist to the
BFF origin only. Never to Deepgram, never to the LLM provider, never to a third party.

`encounter_id` and `session_id` travel down the stack in **OTel baggage**, set once at the browser or
at the BFF entry point, then read by each downstream span processor and written onto every span.

---

## 5. PHI controls

§5 of [`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md) is the governing policy. It is not
restated here. This section covers only what tracing adds on top.

### 5.1 The attribute contract

**Allowlist, not denylist.** A denylist fails the first time someone adds an attribute. The span
processors drop any attribute not on this list.

| Attribute | Type | Example | Cardinality | Metric label? |
|---|---|---|---|---|
| `encounter_id` | string | `ENC-2026-004411` | **unbounded** | ❌ **never** |
| `session_id` | string | `ais_9f2c…` | **unbounded** | ❌ never |
| `rum_session_id` | string | Faro session | **unbounded** | ❌ never |
| `practitioner_hash` | string | HMAC from `/api/auth/me` | bounded | ⚠️ low value, avoid |
| `clinic_id` | string | `narzim-01` | ~10 | ✅ |
| `company` | string | `Narzim` / `Remedisys` | 2 | ✅ |
| `encounter.step` | enum | `soap_generate` | ~10 | ✅ |
| `app.version` | string | git sha | ~100/mo | ✅ |
| `http.method` | enum | `POST` | ~5 | ✅ |
| `http.route` | **template** | `/patients/[id]` | bounded | ✅ |
| `http.status_code` | int | `502` | ~20 | ✅ |
| `error.type` | class name | `DeepgramTimeout` | ~50 | ✅ |
| `error.code` | enum | `DG_1011` | ~50 | ✅ |
| `deepgram.close_code` | int | `1006` | ~15 | ✅ |
| `llm.model` | string | `gpt-5-mini` | ~5 | ✅ |
| `llm.tokens_in` / `llm.tokens_out` | int | `1840` | — | ✅ as metric |
| `llm.latency_ms` | int | `8210` | — | ✅ as metric |

Everything else is dropped. Explicitly including: `http.url` (carries query strings),
`http.target`, `db.statement`, request bodies, response bodies, `error.message`, exception
`str(e)`, Deepgram payloads, LLM prompts and completions.

### 5.2 `encounter_id` is a trace attribute, never a metric label

This is worth stating twice because getting it wrong is expensive and silent.

`encounter_id` is unbounded. Putting it on a Prometheus/Mimir metric creates one active series per
encounter. The free tier is 10,000 active series. At 60 encounters a day we would exhaust it in
under three days, and the cardinality would then cost real money on Pro.

Tempo is built for exactly this. Unbounded attributes on spans are fine and searchable. Keep
`encounter_id` there and nowhere else.

### 5.3 Tracing-specific leak paths

These extend the eight paths already catalogued in §5.3 of the research doc.

| # | Leak path | Treatment |
|---|---|---|
| 9 | **Faro captures `window.location.href` by default** and our routes contain MRNs | `beforeSend` rewrites through `templateRoute()` before any send. Same function PostHog already uses |
| 10 | **Faro error capture includes the message string**, and our errors are built from record data | Send error `name` and stack. Drop `message` unless it passes a scrub. Mirrors `capture_exceptions: false` in PostHog |
| 11 | **OTel GenAI instrumentations capture prompt and completion content**, sometimes by default | Set content capture off explicitly. Add a CI assertion. Same pattern as the GA4 barrier |
| 12 | **`pymysql` auto-instrumentation records `db.statement`** and Frappe queries embed values | Disable statement capture. Keep operation name and duration only |
| 13 | **Deepgram manual spans could carry transcript text** if written carelessly | The span helper accepts a typed struct with no free-text field. Make it impossible, not just discouraged |
| 14 | **`requests` auto-instrumentation records the full outbound URL**, including any signed Deepgram URL with a token | Strip query string in the span processor. Deepgram URLs carry credentials |

Leak path 14 is new and is the one most likely to be missed. A Deepgram temporary key in a span
attribute is a credential leak, not only a privacy problem.

### 5.4 Enforcement

Three gates, because policy that is not enforced is documentation.

1. **Unit tests per span processor.** Feed a span carrying every prohibited attribute, assert the
   exported span carries none of them.
2. **CI assertion on GenAI content capture.** Fails the build if the flag is on.
3. **A canary test in the integration suite** that runs a fake encounter and asserts the exported
   span set matches the §5.1 allowlist exactly. Anything new fails until it is added deliberately.

---

## 6. Telemetry must not break the encounter

| Risk | Control |
|---|---|
| Exporter blocks the request | `BatchSpanProcessor` only. Never `SimpleSpanProcessor` in any runtime |
| Vercel freezes the function before the flush | `waitUntil(forceFlush())` so the flush runs after the response is sent |
| Grafana Cloud is slow or down | Export timeout 2s, max 1 retry, then drop. Never queue to disk, never block |
| Queue fills under load | Bounded queue, drop-oldest. Emit a local counter for dropped spans |
| Frappe worker boot cost | Initialise the SDK once in `post_fork`, not per request |
| Instrumentation raises | Wrap SDK init in try/except. A telemetry failure must never surface as a 500 |

The last row is not theoretical. An OTel init failure inside a Frappe hook will take down request
handling if it is not guarded.

---

## 7. Free tier budget

### 7.1 Trace volume arithmetic

Estimates, not measurements. Re-forecast once real data exists.

| Input | Value |
|---|---|
| Spans per encounter (all three tiers, incl. DB and retries) | ~150 |
| Bytes per span, compressed, with our attribute set | ~500 B |
| Bytes per encounter | ~75 KB |
| Encounters per day, single-clinic pilot | 60 |
| **Traces per month** | **~135 MB** |
| Free tier | 50 GB |
| **Utilisation** | **~0.3 %** |

Stress test the number. At 1,000 encounters a day across every clinic, it is ~2.25 GB a month, or
4.5 % of free. **Trace volume is not a constraint and will not become one.**

### 7.2 What actually binds

| Resource | Free | Our Phase 1 need | Binding? |
|---|---|---|---|
| Traces | 50 GB, 14d | ~135 MB | No |
| Logs | 50 GB, 14d | low | No |
| Metrics | 10k active series | low, if §5.2 is obeyed | No, unless `encounter_id` leaks into a label |
| Faro sessions | 50,000 | ~6,000/mo est. | No, watch it |
| **Users** | **3** | engineering + support + clinic admin | ⚠️ **Yes, first thing to break** |
| **Retention** | **14 days** | support needs 30–90 | ⚠️ **Yes** |

The research doc predicted the 3-user limit would force the paid tier before data volume did. That
prediction holds and is now the main upgrade trigger, together with retention.

### 7.3 Retention is the real Phase 1 risk

14 days is better than Splunk's 8. It is still short for clinical support, where a complaint about a
consultation routinely arrives two or three weeks later.

Three ways to handle it, in order of preference:

1. **Accept 14 days for the pilot.** Measure how often support actually needs a trace older than
   that. Decide on evidence.
2. **Grafana Cloud Pro** takes traces to 30 days. Cost starts at the $19/mo platform fee.
3. **Persist a per-encounter summary row in Frappe** at encounter close: `encounter_id`, `trace_id`s
   per step, durations, statuses, error codes. Numeric and enum only, no PHI beyond the encounter
   link we already own. This is not a telemetry database. It is ten columns on a DocType, it lives
   under our own retention policy, and it survives long after Tempo has expired the trace.

Option 3 is cheap and worth doing regardless. It also answers "was this encounter healthy" for an
admin without touching Grafana at all.

---

## 8. The admin experience

This is the requirement Splunk failed outright. Grafana does better, but be honest about how far it
gets on its own.

### 8.1 Searching by encounter ID — works

TraceQL handles unbounded span attributes directly:

```traceql
{ span.encounter_id = "ENC-2026-004411" }
```

Add a dashboard variable of type *textbox* named `encounter_id`, then a Traces panel querying
`{ span.encounter_id = "$encounter_id" }`. An engineer types an ID and gets every span across all
three tiers.

### 8.2 What a non-technical admin actually gets

Two dashboards, different audiences. Do not try to make one serve both.

**Dashboard A — Encounter Health (clinic admin, non-technical).** Aggregate only, from metrics.

| Panel | Query source |
|---|---|
| Encounters started today | counter |
| Encounters completed and signed | counter |
| Encounters that failed, by step | counter by `encounter.step` |
| Transcription connection failures | `deepgram.close_code != 1000` |
| SOAP generation success rate | counter |
| SOAP generation p95 duration | histogram |
| Slowest step right now | histogram by `encounter.step` |

**Dashboard B — Encounter Trace Lookup (support engineer).** The textbox variable from §8.1 plus a
span table and a waterfall.

### 8.3 The honest gap

Grafana's trace view is a span waterfall with service and operation names. It is an engineer's tool.
A clinic admin will not read it, whatever we call the panel.

**No observability vendor ships a clinical-language encounter timeline.** Not Grafana, not Splunk,
not Datadog. If requirement 2 means a genuinely non-technical reader, it needs a small page in the
Next.js staff app:

```
/admin/encounters/[encounterId]/timeline
  → BFF route handler
  → Tempo HTTP API, TraceQL { span.encounter_id = "…" }
  → map span names to plain language
  → render an ordered step list with ✅ / ⚠️ / ❌ and a duration
```

Roughly one route handler, one mapping table and one component. **This is not a custom telemetry
database.** It stores nothing. It is a read-only view over Tempo, and it works the same way if we
ever change backend. Building it is what makes requirement 2 true rather than nearly true.

---

## 9. Alerts

Alerts fire on metrics, not on individual traces. Emit low-cardinality counters alongside the spans.

| # | Alert | Condition | Severity |
|---|---|---|---|
| A1 | SOAP generation failing | error rate > 20% over 15 min | P0 |
| A2 | Deepgram cannot connect | connect failure rate > 30% over 10 min | P0 |
| A3 | Encounter save failing | any 5xx on `encounter.save` over 5 min | P0 |
| A4 | Token rotation failing | failure rate > 5% over 15 min | P1 |
| A5 | SOAP latency degraded | p95 > 60s over 30 min | P1 |
| A6 | Transcript autosave failing | failure rate > 10% over 15 min | P1 |
| A7 | Spans being dropped | dropped-span counter > 0 over 15 min | P2, telemetry health |
| A8 | Faro session budget | > 40,000 sessions in the month | P2, cost |

Anti-spam rules from §9 of the research doc apply unchanged.

> **Blocking.** There is still no notification channel and no on-call owner. This was open question 4
> in the research doc on 2026-08-11 and is still open. **A1 to A3 are meaningless until someone owns
> them.** Resolve before building alerts, not after.

---

## 10. Frappe-specific checks

| # | Check | Why |
|---|---|---|
| F1 | **Python 3.14 wheel availability** for `opentelemetry-sdk` and every `opentelemetry-instrumentation-*` package we need | Frappe v16 is pinned to 3.14 per ADR-004 and [`project_frappe_v16_python_314`]. OTel's 3.14 support is recent. **Verify before committing to this design.** If wheels are missing, Phase 1 stalls |
| F2 | **Gunicorn `post_fork` init** | Preload forking breaks SDK state. Init per worker |
| F3 | **RQ worker instrumentation** | Transcript autosave and SOAP generation run in workers. Untraced workers mean a hole in the middle of the flow |
| F4 | **`frappe.monitor` overlap** | `monitor.py` already has `get_trace_id()`. Reuse it as the OTel trace ID rather than running two ID schemes |
| F5 | **`request_ip` at `monitor.py:69`** | Personal data under LFPDPPP. Drop or truncate to /24. Already flagged as leak path 2 |
| F6 | **Everything lives in `remedisys_healthcare_ai`** | Hooks and overrides only. No edit to Frappe, ERPNext or Healthcare. RULES.md |

F1 is the one that can kill the plan. Check it first.

---

## 11. Open questions

| # | Question | Blocks | Owner |
|---|---|---|---|
| OQ-1 | How does Tempo handle a trace whose spans arrive over 30+ minutes? | §4.1 trace model | eng |
| OQ-2 | **Does Grafana Labs sign a BAA, on which plan, at what price?** Not published. Must be asked directly | Production use with any patient-linked identifier | Sarvesh |
| OQ-3 | Is `encounter_id` in third-party telemetry acceptable under LFPDPPP with a DPA, or does it need pseudonymising first? | §5.1 | compliance |
| OQ-4 | Python 3.14 OTel wheels (F1) | The whole backend leg | eng |
| OQ-5 | Notification channel and on-call owner. Open since 2026-08-11 | §9 | Sarvesh |
| OQ-6 | Do 3 Grafana users cover engineering plus support plus clinic admin? | §7.2 | Sarvesh |

**OQ-2 and OQ-3 are the serious ones.** `encounter_id` is a code that maps one-to-one to a patient
encounter in our own database. Under HIPAA Safe Harbor that is "any other unique identifying number,
characteristic, or code" and would not be considered de-identified. Mexico's LFPDPPP reaches the same
place by a different route: Grafana Labs becomes an *encargado* and needs a processing agreement.

§5.5 of the research doc already set the policy: keep telemetry strictly technical so the DPA is a
formality rather than a control we depend on. `encounter_id` is the one attribute that tests that
policy, because we cannot deliver requirement 2 without it.

One mitigation worth considering if OQ-3 goes badly: send an HMAC of `encounter_id` instead of the
raw value, using the existing `ANALYTICS_ID_SECRET` pattern. Support then pastes the encounter ID
into the lookup page from §8.3, which hashes it before querying Tempo. Grafana never holds the real
identifier. The cost is that raw TraceQL search in Explore stops being human-friendly.

---

## 12. Phase 1 task list

Ordered. Each item is independently verifiable.

| # | Task | Depends on | Complexity |
|---|---|---|---|
| 1 | Answer **OQ-4** — Python 3.14 OTel wheels | — | S |
| 2 | Answer **OQ-2** — Grafana BAA, in writing | — | S |
| 3 | Answer **OQ-3** — raw vs hashed `encounter_id` | 2 | M |
| 4 | Create Grafana Cloud free account, **US region**, access policy token with OTLP scopes | — | S |
| 5 | Write the §5.1 attribute allowlist as a shared constant, one per runtime | 3 | S |
| 6 | Frappe: OTel SDK + `RedactingSpanProcessor` + `post_fork` init | 1, 5 | L |
| 7 | Frappe: instrument the encounter API path, autosave and SOAP worker jobs | 6 | L |
| 8 | Frappe: manual Deepgram and LLM spans, typed struct, no free-text field | 7 | M |
| 9 | BFF: `@vercel/otel`, OTLP exporter, redacting processor, `waitUntil` flush | 5 | M |
| 10 | BFF: emit `Server-Timing: traceparent` + CORS expose header | 9 | S |
| 11 | Browser: Faro SDK, `templateRoute()` in `beforeSend`, propagation allowlist = BFF origin only | 5, 10 | M |
| 12 | Baggage: set `encounter_id` + `session_id` once, read on every span | 7, 9, 11 | M |
| 13 | Redaction unit tests, all three processors | 6, 9, 11 | M |
| 14 | CI assertion: GenAI content capture off | 8 | S |
| 15 | Canary integration test: fake encounter, assert exported attribute set | 13 | M |
| 16 | Dashboard A — Encounter Health | 12 | M |
| 17 | Dashboard B — Trace Lookup, textbox variable | 12 | S |
| 18 | Encounter summary row on close (§7.3 option 3) | 7 | M |
| 19 | Resolve **OQ-5**, then build alerts A1–A8 | 16 | M |
| 20 | `/admin/encounters/[id]/timeline` page (§8.3) | 12 | M |
| 21 | ADR recording the platform decision and the Splunk rejection | 2, 3 | S |

**Phase 1 exit criteria.** Paste an `encounter_id` into Dashboard B and see every step from open to
sign, across all three tiers, with durations and statuses, and no attribute outside the §5.1
allowlist anywhere in the exported spans.

---

## 13. What this design deliberately does not do

- **No Alloy, no self-hosted Grafana stack.** Rejected in §6 of the research doc and unchanged.
- **No Vercel Drains in Phase 1.** Application traces go direct. See §3.3.
- **No session replay.** PostHog already covers that ground, with masking, and a second replay tool
  doubles the PHI surface for no new answer.
- **No synthetic monitoring in this phase.** The old Phase 1 work is not cancelled, only resequenced.
  It is cheap and should still happen, but it answers a different question.
- **No custom telemetry database.** The §8.3 lookup page stores nothing. The §7.3 summary row is ten
  columns on an existing DocType under our own retention policy, not a telemetry store.
- **No replacement for Sentry.** §13 of the research doc stands: Grafana and Sentry answer different
  questions and the end state is both.

---

## References

1. Grafana Cloud free tier — https://grafana.com/products/cloud/free-tier/
2. Grafana Cloud pricing — https://grafana.com/pricing/
3. Send data to the Grafana Cloud OTLP endpoint — https://grafana.com/docs/grafana-cloud/send-data/otlp/send-data-otlp/
4. TraceQL — https://grafana.com/docs/tempo/latest/traceql/
5. Construct a TraceQL query — https://grafana.com/docs/tempo/latest/traceql/construct-traceql-queries/
6. Instrument Next.js applications with Faro — https://grafana.com/docs/grafana-cloud/monitor-applications/frontend-observability/get-started/instrument-nextjs/
7. Faro session tracking — https://grafana.com/docs/grafana-cloud/monitor-applications/frontend-observability/instrument/session-tracking/
8. Faro Next.js example — https://github.com/grafana/faro-nextjs-example
9. Grafana Faro OSS — https://grafana.com/oss/faro/
10. Splunk Observability Free Edition Terms — https://www.splunk.com/en_us/legal/splunk-observability-free-edition-terms.html
11. Splunk's Business Associate Agreement — https://www.splunk.com/en_us/legal/splunk-baa.html
12. Splunk Log Observer Connect — https://help.splunk.com/en/splunk-observability-cloud/manage-data/view-splunk-platform-logs/introduction-to-splunk-log-observer-connect
13. Data retention in Splunk Observability Cloud — https://help.splunk.com/en/splunk-observability-cloud/administer/org-reference-info/data-retention-in-splunk-observability-cloud
14. Internal — [`OBSERVABILITY_RESEARCH.md`](OBSERVABILITY_RESEARCH.md)
15. Internal — [`prompts/2026-09-23-splunk-observability-phase1-evaluation.md`](../_archive/prompts/2026-09-23-splunk-observability-phase1-evaluation.md)

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-23 | Sarvesh (AI-assisted) | Initial version. Redefines Phase 1 as Guided Encounter tracing, amends OBSERVABILITY_RESEARCH.md §10, reverses the browser-tracing exclusion, records the Splunk rejection |
