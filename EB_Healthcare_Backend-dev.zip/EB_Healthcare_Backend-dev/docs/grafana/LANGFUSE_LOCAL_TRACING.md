# Langfuse Local Tracing — full LLM and tool-call visibility on a dev site

**Doc status:** living · **Created:** 2026-09-25 by Satyakam (AI-assisted) · **Updated:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.1

**Status:** Implemented for local development only. Not a production observability plan; that remains [`PHASE1_ENCOUNTER_TRACING.md`](PHASE1_ENCOUNTER_TRACING.md). Design decisions: [ADR-120](../adr/adr-120-langfuse-encounter-tracing.md).

---

## 1. What it answers

`AI Prompt Log` records *that* a call happened (purpose, model, tokens, cost, tool names, argument
shapes) and deliberately never the content (BE-10, PHI-8). During development that leaves the real
questions unanswerable: what exactly was sent to the model, what came back, which tools ran with
which arguments, what they returned, and how one patient visit flowed through the whole API.

This module records all of it, to a Langfuse instance running on the developer's machine, and only
when the site is a developer site.

## 2. The gate

`remedisys_healthcare_ai/integrations/langfuse_trace.py::enabled()` is true only when
`site_config.json` has **all** of:

| Key | Value |
|---|---|
| `developer_mode` | `1` |
| `langfuse_enabled` | `1` |
| `langfuse_public_key` | `pk-lf-…` |
| `langfuse_secret_key` | `sk-lf-…` |
| `langfuse_host` | optional, default `http://localhost:3010` |
| `langfuse_trace_scope` | optional. `all` (default): every request to a `remedisys_healthcare_ai.*` method. `ai`: only requests that call a model (the 1.0 behaviour) |

Frappe Cloud sites have no `developer_mode`, so a stray key there records nothing. The `langfuse`
package is imported lazily and is **not** a declared dependency; it is installed by hand into the
bench env. Every SDK call is wrapped: a failure logs to `logs/langfuse.log` and never reaches a
clinical path (BE-7).

## 3. What is recorded

**One trace per request** to a `remedisys_healthcare_ai.*` method (scope `all`), opened by the
`before_request` hook and closed by `after_request`. Named after the method.

| Trace field | Value |
|---|---|
| Input | the request arguments, secret-looking keys masked by pattern (`pwd`, `token`, `secret`, `api_key`, …), strings cut at 2,000 chars, uploads as name + content type |
| Output | the response status and body (cut at 8,000 chars). A 4xx/5xx marks the trace `ERROR` |
| User | the logged-in clinic user (`user_id` = login, `user_name` in metadata). Re-stamped after `validate_auth()`, because `before_request` runs before Bearer-token auth |
| Session | see §4 |
| Tags | `remedisys`, the site |

**Inside a trace:**

| Span | Where | Input | Output |
|---|---|---|---|
| `openai.chat · <prompt>` (generation) | `integrations/openai.py::_call_with_tools` | full `messages`, model parameters, offered tool names | assistant message (content or `tool_calls`), usage incl. cached/reasoning tokens |
| `openai.chat.stream · <prompt>` (generation) | `integrations/openai.py::_stream_chat` | `messages` | concatenated text, usage, `finish_reason` |
| `openai.chat.structured · <prompt>` (generation) | `integrations/openai.py::_call_openai` | system + user parts (binary parts replaced by a size marker) | JSON text or refusal |
| `anthropic.messages` (generation) | `integrations/anthropic.py::_call_with_tools` | system + `messages` | content blocks |
| `tool.<name>` (tool) | agent loops in both adapters, around `call_tool()` | the model's arguments | the tool's result dict |
| events, e.g. `soap_draft.json_parse_failed` | where the code detects a silent failure | — | sizes and counts only, never text |

Each generation's metadata carries `prompt_version` (last prompt loaded), `prompt_versions` (every
prompt composed into the call, base first, e.g. `["soap-v1", "soap-v1-assessment-plan-propose-addendum"]`),
`prompt_hashes` and `prompt_source`, from `integrations/llm.py`'s loaders via `note_prompt()`.

**Background jobs** (Overview clinical summary, lab summaries) get their own trace, named after the
job method, closed and flushed by a `frappe.local.job.after_job` callback.

Provider errors (timeout, 429, 5xx) are recorded on the generation as `level=ERROR` with the
exception text, then re-raised unchanged.

Streaming endpoints (`send_message_stream`) produce their spans while the response body is being
iterated, after `after_request` has closed the root; `identity_scope()` gives those spans the same
user and session.

**Not traced:** the browser, and the live Deepgram audio stream (browser → Deepgram, ADR-009). The
Anthropic `_call_claude` and `_stream_messages` paths are not wrapped yet.

## 4. Sessions: one encounter, one session

Langfuse → **Sessions** groups traces by `session_id`. In order of precedence:

1. `set_session()` from the caller: Narzim GPT's chat thread.
2. **The encounter the request acts on**, as an opaque id: `enc-` + 16 hex of
   `sha256(site + ":" + encounter)`. Read from the `encounter` argument, or resolved from `session`
   (AI Encounter Session) or `draft_name` (AI SOAP Draft), or a job's `encounter` kwarg.
3. The Frappe request id.

The encounter id itself never becomes a trace attribute (team rule: attributes name the clinic user,
never a patient or a visit; `test_a_patient_identifier_never_reaches_a_trace_attribute`). To find an
encounter's session:

```bash
bench --site marley.local execute \
  remedisys_healthcare_ai.integrations.langfuse_trace.session_for --args "['HLC-ENC-2026-01547']"
# enc-…  → Langfuse → Sessions → paste it into the search
```

`create_encounter` has no encounter yet when it starts, so its trace has the request-id session.

## 5. Running it

### 5.1 Langfuse in Docker (once per machine)

Langfuse v4 needs web, worker, Postgres, ClickHouse, Redis and MinIO (about 4 GB of RAM). The
official compose file publishes ports that collide with a bench: web 3000 (a Next.js dev server)
and Redis 6379. Keep it in its own folder, outside the repos:

```bash
mkdir -p ~/langfuse && cd ~/langfuse
curl -fsSL -o docker-compose.yml https://raw.githubusercontent.com/langfuse/langfuse/main/docker-compose.yml
```

`docker-compose.override.yml` (every host port on 127.0.0.1 only, because traces hold patient
content; web on 3010; Redis, Postgres and ClickHouse not published):

```yaml
services:
  langfuse-web:
    ports: !override
      - 127.0.0.1:3010:3000
  minio:
    ports: !override
      - 127.0.0.1:9090:9000
      - 127.0.0.1:9091:9001
  redis:
    ports: !reset []
  postgres:
    ports: !reset []
  clickhouse:
    ports: !reset []
```

`.env` (mode 600, never committed) replaces every `# CHANGEME` default with a random value
(`openssl rand -hex 32`) and sets `NEXTAUTH_URL=http://localhost:3010` plus the headless-init
variables, so the project and its API keys exist on first start:

```
LANGFUSE_INIT_ORG_ID / _ORG_NAME / _PROJECT_ID / _PROJECT_NAME
LANGFUSE_INIT_PROJECT_PUBLIC_KEY=pk-lf-<random>   LANGFUSE_INIT_PROJECT_SECRET_KEY=sk-lf-<random>
LANGFUSE_INIT_USER_EMAIL / _USER_NAME / _USER_PASSWORD
```

```bash
docker compose up -d          # first start: ~5 GB of images, 2–3 min until web is Ready
curl -s http://localhost:3010/api/public/health     # {"status":"OK","version":"4.x"}
```

Everyday: `docker compose stop` / `start`. `docker compose down -v` deletes every trace.

### 5.2 The bench (once)

```bash
cd ~/marley-bench && env/bin/pip install langfuse      # SDK 4.x; not in pyproject.toml
bench --site marley.local set-config developer_mode 1
bench --site marley.local set-config langfuse_enabled 1
bench --site marley.local set-config langfuse_host http://localhost:3010
bench --site marley.local set-config langfuse_public_key pk-lf-…    # from ~/langfuse/.env
bench --site marley.local set-config langfuse_secret_key sk-lf-…
```

Restart `bench start` **once**: stop the running one first. A second `bench start` cannot bind the
ports, does nothing, and leaves the old processes (and old code in the workers) running.

```bash
# Smoke test without spending provider credits:
bench --site marley.local execute remedisys_healthcare_ai.integrations.langfuse_trace.selftest
```

Then open **http://localhost:3010 → project → Tracing** (one row per request) or **Sessions**
(one row per encounter). `bruno/encounter-flow/` runs the whole v9 encounter flow and produces one
session.

### 5.3 Reading it through the API

Langfuse v4 runs in events-only mode: `/api/public/traces` and `/api/public/observations` are gone.
Use `/api/public/v2/observations?traceId=…&fields=core,basic,io,usage,model,metadata` with basic
auth `public_key:secret_key`.

## 6. Rules this must keep

- Never enable on a site with real patients. The gate is `developer_mode`, not a promise.
- Do not add `langfuse` to `pyproject.toml`; the production build must not carry an exporter.
- Do not point `langfuse_host` at Langfuse Cloud or any hosted instance. Sending prompts off the
  machine needs a BAA and an entry in the active `ComplianceProfile` (PHI-1).
- Keep every published Langfuse port on 127.0.0.1.
- No patient or encounter id in a trace attribute (user, session, metadata, tags). Content (inputs,
  outputs) is where PHI already lives in this store.
- `AI Prompt Log` remains the audit record. This is a debugging aid.

## 7. Findings

**2026-09-25.** The first real trace showed `openai.chat.structured` (the Narzim scope check, via
the OpenAI SDK) failing with `429 credit_balance_exhausted` while `openai.chat` (raw HTTP) succeeded
in the same request. Cause: `_api_key()` in `integrations/openai.py` prefers the `OPENAI_API_KEY`
environment variable over `site_config.openai_api_key`, and the developer's shell exported a
different, exhausted key. The raw-HTTP path reads only `site_config`. Two code paths, two keys.

**2026-10-01, one full v9 encounter** (`bruno/encounter-flow/`, 31 traces, `gpt-5-mini`):

| Step | Model calls | Time | Input tokens | Output tokens |
|---|---|---|---|---|
| Ask AI (2 questions) | 8 | 53.7 s | 96,767 | 1,227 |
| SOAP draft + Regenerate | 2 | 31.7 s | 20,667 | 5,285 |
| Clinical summary (background job, 3 runs) | 3 | 72.4 s | 9,320 | 5,898 |
| Lab photo reading | 1 | 70.1 s | 5,858 | 3,906 |
| Speaker check | 1 | 6.1 s | 860 | 920 |
| **Whole encounter** | | | **133,472** | **17,236** |

- Ask AI is 72% of the encounter's input tokens: each round trip re-sends the system prompt, 44
  tool definitions and the conversation.
- One v9 SOAP draft: 8,689 input tokens, of which ~4,300 system prompt and ~4,000 catalogs
  (complaints 1,397, diagnoses 995, labs 604, medicines 490); the transcript was 16.
- The clinical summary regenerated three times during one visit, triggered by saves.
- The lab photo took 70 s to read.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.1 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Renumbered from 117 to 120: open billing PRs #482/#483 also took that number, and no branch uses 120 (ADR-042: the unmerged side moves) |
| 2.0 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | ADR-120: every app request traced with input/output and errors; encounter sessions (opaque id); background jobs closed; composed prompts recorded; user re-stamped after auth; Docker v4 runbook for a bench machine; v2 observations API; first full-encounter measurement |
| 1.0 | 2026-09-25 | Satyakam (AI-assisted) | Initial: module, gate, span map, runbook, first finding |
