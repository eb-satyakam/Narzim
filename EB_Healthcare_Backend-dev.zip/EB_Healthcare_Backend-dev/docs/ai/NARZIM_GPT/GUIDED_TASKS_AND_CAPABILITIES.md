# Narzim GPT — Guided Clinical Tasks (Look up · Work up · Treat)

**Doc status:** draft · **Created:** 2026-09-08 by Ashutosh (AI-assisted) · **Updated:** 2026-09-26 by Satyakam (AI-assisted) · **Version:** 4.0

> **This is still a `draft`.** Per `CLAUDE.md` §9 a draft must not be cited as decided; the
> decisions recorded in §6 below need an ADR before anything not already shipped is built.
> Condensed 2026-09-26 from `NARZIMGPT_CAPABILITIES.md` v3.3 — see
> [`../NARZIMGPT_CAPABILITIES.md`](../NARZIMGPT_CAPABILITIES.md) for the full negotiation history,
> including the rejected alternatives and the measurements behind each decision.

**What's actually shipped vs. still draft, per [`ARCHITECTURE.md`](./ARCHITECTURE.md) /
`NARZIM_AI_ASSISTANT_DESIGN.md` §17–18:** the PHI/scope prerequisite (§2 below) is live — the
domain scope gate and `phi_input_guard` both ship ahead of any guided-task work, per decision D1.
The frontend guided-task shell (chips, task panels, stems, curated typeahead with shuffled-deck
rotation, 280 reviewed-but-not-clinically-approved suggestion strings) also shipped 2026-09-08. The
**backing tools** — the deterministic dose calculator, risk-score calculators, a licensed drug
interaction dataset — remain draft/undecided as of this consolidation; verify against current code
before assuming any specific task in §3–§5 below is backed by more than model knowledge plus the
formulary/catalog cross-check that already exists (`ARCHITECTURE.md` §2.1).

---

## 1. Why this pattern, and what it is not

Heidi Health's pattern: a row of task chips under the composer, each opening a short list of
concrete tasks, each prefilling the composer with a fill-in-the-blank stem completed by
typeahead. Scope here: three categories — **Look up**, **Work up**, **Treat**. Heidi's other three
(Prepare, Write, Fill form) are out of scope — see §6.

Two reasons this earns its place, and the second is the stronger one:

1. **It says what the assistant is for**, before the user finds out by being refused by the scope
   gate.
2. **Every stem is patient-free by construction**, so the fast path has nowhere to put a name —
   `Is it safe to use [drug] in [situation]?` has no slot for a person.

**The limit of that second claim, stated precisely:** the composer stays free text. Guided tasks
*prefill*, they do not *lock*. A closed set of tasks would make the assistant useless for the long
tail of real clinical questions. So:

| | What it actually does |
|---|---|
| Guided tasks | Change the **default** — a nudge, valuable and measurable, **not** enforcement |
| The PHI pre-filter (§2) | The **control** — server-side, deterministic, applied to every message regardless of how it was composed |

Guided tasks reduce how often a patient identifier gets typed; they cannot make it impossible.
The pre-filter is what makes it safe, and is a prerequisite of this work, not a follow-up.

## 2. The prerequisite (now shipped)

Verified in code at design time: `redact_text()` ran only on uploaded document text, never on the
user's typed message — a question naming a patient left the process twice (a scope-check call and
the answer call) and was persisted once, all before the system prompt's "decline if you recognize
a patient" instruction had any chance to matter. Fixed by `services/phi_input_guard.py` — a
deterministic pre-filter (MRN format, patient-name token match) running before any provider call.
See `ARCHITECTURE.md` §3.3 for the current, shipped guard chain.

## 3. Anatomy of a guided task

| Part | What it is | Rule |
|---|---|---|
| Chip | `Look up` / `Work up` / `Treat` | Verbs, not nouns — pick by intent |
| Task list | 5 tasks per chip | Five is the ceiling; a scrolling list is a menu, and a menu is work |
| Stem | Prefills the composer, ending mid-sentence | A sentence to *finish*, not a form to *fill* |
| Slots | Typed placeholders as tab-navigable pills | A drug slot autocompletes from the clinic's own formulary |
| Typeahead | Completes the stem with realistic full questions | Curated/static per task, **not generated per request** (§3.1) |

One level of sub-menu nesting is supported (e.g. "Compare treatment options" → efficacy / risks /
management strategies); two levels is a form.

**Standing disclaimer**, shipped: *"Medical knowledge only. Not for autonomous decisions. Check
sources and use your clinical judgement."* A middle clause about "no access to patient records" was
considered and dropped — since the PHI pre-filter ships first, a question naming a patient is now
refused outright with an explanation, which teaches the limit at the moment it matters rather than
via permanent small print nobody reads (per PHI-5, removing a *true* statement doesn't create a
compliance problem the way adding a false one would).

### 3.1 Suggestion variety (decision D6, shipped 2026-09-08)

Runtime generation per click was considered and rejected on four grounds: latency (this composer
is tuned for speed — `AI Settings.narzim_assistant_max_tokens = 350`), cost per panel-open with no
answer produced, loss of reviewability (clinical content generated live can't be signed off), and
the scope gate potentially refusing the assistant's own generated suggestion. Shipped instead: a
curated pool (10 suggestions × 14 tasks × 2 locales = 280 strings), 4 shown at a time, dealt from a
**shuffled deck per task** (not random picks — guarantees every item appears once before any
repeat, and a reshuffle pushes the currently-shown items to the back so wrap-around can't
immediately re-show them). Deck lives in a ref, dealt indices in state, reseeded only on a click or
task-open (never during render — `Math.random()` during render is a hydration mismatch). Filtering
searches the whole pool, not just the four dealt.

**These 280 strings are drafted, not clinically approved** — they are clinical content in a code
file and need a named reviewer (§7, item 5). The Spanish set is localised, not translated, for a
pediatric-and-general clinic with `es-MX` default (febrile infant under 3 months, Westley croup
score, Cartilla Nacional de Vacunación, etc.).

The longer-term target (approach C in the original design — not yet built) is an offline
generation-then-review step so the pool can vary in phrasing while staying reviewable, ideally
seeded from this clinic's own most common presentations (de-identified diagnosis/complaint
aggregates) rather than a general model's US-adult-inpatient default distribution.

## 4. Task catalog

### Look up — "I need a fact, fast"

| Task | Stem | Backed by |
|---|---|---|
| Check dosing of a drug | `Dosing for [drug] in [population]?` | **Design target:** a deterministic calculator + `search_medication_catalog` (§4.1 below). Verify whether the calculator has shipped |
| Check drug safety or interactions | `Is it safe to use [drug] in [situation]?` | Model knowledge — no licensed interaction dataset as of the source design. Must ship with an explicit "not a complete interaction check" line, never silently relying on model recall alone |
| Look up a guideline recommendation | `What does [guideline] recommend for [condition]?` | Model knowledge + this clinic's own vaccine catalog (`get_vaccine_catalog`) for anything vaccine-specific — leads with Mexico's NOM norms / Cartilla Nacional de Vacunación (ADR-018's `mx` default), not a US-first guideline set |
| Get advice on tapering a medication | `How do I taper [drug] after [duration]?` | Model knowledge |
| Look up something in my documents | *(opens the upload picker)* | **Shipped** — the existing redacted-document path (`ARCHITECTURE.md` §3.4) |

**§4.1 — why dosing is the highest-value task.** Weight-based pediatric dosing is arithmetic an LLM
does badly while sounding certain, and contraindications/dosing exist today mostly as prompt text,
not code. The design calls for a deterministic calculator (declared units, an explicit max-dose
ceiling, refusal on a missing required input rather than a silent default) combined with
`search_medication_catalog` (already verified PHI-free and reusable, `ARCHITECTURE.md` §2.1), so
an answer can say not just the correct dose but which formulation this clinic actually stocks.
**This second half — reconciling against the real formulary — is the differentiator no general
assistant can match**, and the pattern (answer from guideline knowledge, then cross-check the
clinic's own catalog) repeats across the Treat category below.

### Work up — "help me think about this presentation"

| Task | Stem | Backed by |
|---|---|---|
| Plan a diagnostic workup | `Workup for [presentation]` | Model knowledge + `search_lab_catalog` (surfaces a clinic's own combined-panel entries, e.g. a combined ESR+CRP test, so the answer doesn't suggest ordering something already covered) |
| Evaluate a clinical finding | `How should I evaluate [finding]?` | Model knowledge |
| Calculate a clinical risk score | `Calculate [score] for [inputs]` | **Must be deterministic code, never the model** (Rule 9) — CHA₂DS₂-VASc, Wells, CURB-65, Centor, qSOFA, GCS, PEWS, Westley croup score, bilirubin-nomogram risk zone. Returns the score, every input used, and the interpretation band, so a clinician can check the inputs rather than trust the total. Refuses rather than assumes a missing input |
| Help interpret test results | `What does [result] suggest in [context]?` | Reference ranges should come from `Lab Test Template` (this clinic's own analyser-specific ranges), not a generic textbook interval. The PHI-nearest task in the catalog — a pasted result block often carries a name/MRN, so this should route through the redacted-document path when the input is a pasted block, not just a typed stem |
| Generate a differential diagnosis | `Differential for [presentation]` | Model knowledge — framed as considerations to rule out, never a ranked verdict (Rule 6) |

### Treat — "what do I actually do"

| Task | Stem | Notes |
|---|---|---|
| Compare treatment options *(sub-menu)* | `Compare [first drug] vs [second drug] for [condition]?` | Level one picks the axis (efficacy / risks / management strategies) — "compare A vs B" alone is under-specified. Each drug slot autocompletes from `search_medication_catalog` |
| Find first-line medication | `First-line treatment for [condition]` | Cross-check the formulary — the pattern from §4.1 repeated: guideline answer, then "you stock it at X mg; the guideline's second-line option is not in your formulary, nearest item is Y" |
| Escalate or step up treatment | `How do I step up treatment for [condition] when [current therapy] is failing?` | Model knowledge |
| Treat an acute condition | `Initial management of [acute condition]` | Model knowledge |
| Find add-on therapy options | `Add-on options for [condition] already on [drug]` | Cross-check the formulary |

## 5. What backs an answer, bounded

| Backing | Compliance shape |
|---|---|
| Model general knowledge | PHI-free; carries the standing clinical caveat |
| Catalog tools (7, verified PHI-free — `ARCHITECTURE.md` §2.1) | ADR-030-compliant already; log tool **names** only to `AI Prompt Log`, never arguments (Rule 10) |
| Deterministic calculators (dosing, risk scores) | Code, not model output; returns inputs alongside the result |
| `Lab Test Template` ranges | This clinic's own ranges, PHI-free |
| Redacted document path | Existing — masked, never persisted |

**No general web-search source** — adds an unnamed subprocessor, which PHI-1 forbids without a
`ComplianceProfile` entry. See `ARCHITECTURE.md` §4 for the Clinical Web source that *is* built,
which is narrower than general web search and gated the same way.

**Formulary claims are positive-only, no row-count threshold** (decision D5). Measured on the live
dev site's `Medication` master: a misspelled generic name (`Amoxiclin` for amoxicillin) and a
zero-strength row both proved that "wait until the catalog has N rows" does not predict whether a
*particular* answer is trustworthy — a catalog of any size can have a bad row. So: a match is
stated as fact; a miss says nothing about stock (a miss is ambiguously *not stocked* / *spelled
differently* / *never populated*, and asserting "not in your formulary" would be a false statement
a clinician could act on); a strength of 0 or below is dropped from the rendered line, but the drug
is still named. This is implemented as retrieved context folded into the prompt as text, never as
a tool call — a tool loop would reintroduce the guardrail `answer_general_question` is built
specifically not to have.

## 6. Deliberately out of scope

| Chip | Why deferred |
|---|---|
| **Write** | Drafting a referral/letter is patient-specific by nature — that's the encounter copilot's job, where the record is already open and attribution survives (PHI-7) |
| **Fill form** | Same, plus it implies writing to the record — do not add a sixth path bypassing physician review alongside the five already tracked as a known gap (`ARCHITECTURE.md` §2) |
| **Prepare** | Overlaps encounter preparation, which needs the patient |

Also explicitly not this: free-form SQL / "ask anything about the database" (ADR-030 bans it for
PHI flows); autonomous actions (Rule 6/9 — the assistant proposes, a human acts); a vector store
over patient notes (Rule 5, plus this codebase's deliberate no-vector-DB decision); any UI copy
claiming "HIPAA compliant" (unconditional hard don't).

## 7. Open items (as of the source design, 2026-09-08 — verify current status)

1. Build order: Look up first (highest volume, strongest single capability), then Work up, then
   Treat last (highest harm from a wrong answer, so it should ship after citations and formulary
   cross-checking are proven elsewhere).
2. Drug interaction data — license a real dataset (a new subprocessor, needs a `ComplianceProfile`
   entry in the same commit) or ship with an explicit limitation line.
3. Risk score list — which scores, and who signs off on each rubric/cut-off. A wrong cut-off in
   code is worse than no calculator.
4. Typeahead curation ownership — the 280 strings need a named clinical reviewer, not a
   developer's judgement.
5. Guided-only mode for non-clinical roles (Front Desk/Clinic Staff) — a real product judgement,
   not recommended either way in the source design; if adopted, must fail *open* to guided mode,
   never closed to no assistant at all.
6. Whether the shell (chips/stems/typeahead) should ship ahead of the backing tools (formulary
   cross-check, dose calculator) — the shell alone is real value and is days of work; the tools are
   the actual differentiator and are weeks.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 4.0 | 2026-09-26 | Satyakam (AI-assisted) | Consolidated from `NARZIMGPT_CAPABILITIES.md` v3.3 into `NARZIM_GPT/`; trimmed repeated justification and dated negotiation narrative, kept the decisions, task catalog, and open items; added a status note distinguishing shipped shell from draft backing tools |
| 3.3 | 2026-09-08 | Ashutosh (AI-assisted) | (see `../NARZIMGPT_CAPABILITIES.md` for full prior history) |
