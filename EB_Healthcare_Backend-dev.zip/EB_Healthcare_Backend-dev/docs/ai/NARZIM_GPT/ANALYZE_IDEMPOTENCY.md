# Analyze Idempotency, Meaningful-Change Detection & Incremental Context — Design

**Doc status:** living · **Created:** 2026-08-04 by Sarvesh-SocialAngel · **Updated:** 2026-09-26 by Satyakam (AI-assisted) · **Version:** 2.0

Design for the **encounter copilot's** "Analyze" caching layer — not the sidebar assistant. Ships
in `c778ad5`. Condensed 2026-09-26 from `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` v1.0 — see
[`../AI_ANALYZE_IDEMPOTENCY_DESIGN.md`](../AI_ANALYZE_IDEMPOTENCY_DESIGN.md) for the full version,
kept in place because `services/transcript_digest.py`, `services/clinical_lexicon.py`,
`services/ai_tools.py`, and `tests/ai/test_analyze_fingerprint.py` all cite it by exact section
number.

**Cache defaults OFF** (`AI Settings.enable_analyze_cache`) — verify current default before
assuming this is live in a given deployment.

Three problems addressed: (1) repeated Analyze wastes a full LLM call, (2) trivial transcript
edits ("okay") trigger a full re-analysis, (3) whether to roll up the transcript incrementally.

## 0. Three findings that shape the design

- **The store already exists.** `AI Encounter Chat Message` already persists every Analyze result
  (`kind="analysis"`, `content`, `actions_json`, model/tokens/latency) — no new doctype needed for
  the cache, just two indexed fields.
- **The rolling-summary pattern already exists.** `patient_clinical_summary.py` already implements
  a watermark-gated incremental summary; Problem 3 (§4) is a port of that module, not a new
  invention.
- **The transcript is not the token problem.** `get_current_transcript` is capped at ~1,500
  tokens; the agent's fixed prefix is ~10,816 tokens per round-trip. The transcript is ~1% of a
  full Analyze turn — summarizing it to save tokens optimizes the wrong term (it has a different,
  real justification: fidelity on long consultations, §4.1).

## 1. Architecture

```
Doctor clicks Analyze
  -> L0 identity gate: transcript bytes + draft fingerprint byte-identical? -> hit
  -> L1 clinical_digest(): deterministic normalization, no LLM (§3.2)
  -> L2 materiality gate: delta tokens vs. catalog-derived clinical lexicon (§3.4)
       not material -> REUSE stored result + a zero-cost "Cached" AI Prompt Log row
       material     -> run ask_copilot_agent, persist result + its input_fingerprint
```

**Governing principle — fail open, always.** A false "nothing changed" hides a real clinical
change (a safety event); a false "something changed" costs one LLM call (~4.5¢). Every threshold
in this design is tuned toward re-analysing when uncertain, and that asymmetry must stay in code
comments so a future tuner doesn't "improve" precision at recall's expense.

## 2. Problem 1 — Idempotent Analyze

### 2.1 The fingerprint must cover more than the transcript

Analyze's output depends on the transcript *and* the existing draft (`_ANALYZE_PROMPT`: "never
duplicate what is already in the draft"), so the same transcript against a different draft
legitimately produces different output. The cache key:

```python
FINGERPRINT_VERSION = 1

def analyze_fingerprint(encounter, *, focus, transcript, ctx, draft) -> str:
    payload = {
        "v": FINGERPRINT_VERSION, "focus": focus or "",
        "prompt": _prompt_hash("ask-copilot-v2.txt", _ANALYZE_PROMPTS[focus or ""]),
        "model": f"{_get_model()}:{_get_reasoning_effort()}",
        "lang": resolve_chat_language(), "country": resolve_suggestion_country() or "",
        "transcript": clinical_digest(transcript),          # §3
        "draft": _draft_fingerprint(draft),                  # §2.2
        "summary": _sha(ctx.get("existing_summary") or ""),
        "chat_head": _latest_chat_message_name(encounter),   # monotonic, cheap
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                       separators=(",", ":")).encode()).hexdigest()
```

- `prompt` hashes the file contents — editing a prompt must invalidate every cached result.
- `model` includes `reasoning_effort` — flipping the AI Setting must invalidate.
- `chat_head` — a new chat turn is a genuine input change (Analyze reviews the whole
  conversation); using the row name rather than hashing every message keeps this one indexed
  lookup.
- `FINGERPRINT_VERSION` is the global kill switch — bump it to invalidate everything in one line.

### 2.2 The draft fingerprint

Reuses the exact field set `_tool_get_encounter_state` already returns. Order-insensitive per list
(reordering rows is not a clinical change). **Deliberately excludes** `review_details` free text
and clinician-typed exam/assessment prose — those are physician output, not agent input, and
including them would invalidate the cache on every keystroke-save.

### 2.3 Storage

Two fields on `AI Encounter Chat Message` (`input_fingerprint` Data(64) sha256 hex, indexed;
`fingerprint_version` Int) and one new `AI Prompt Log.status` option: **`Cached`**. No new doctype.

### 2.4 Lookup and serve

A cache hit returns the stored `content`/`actions_json` with `cached: true`; a miss runs
`ask_copilot` as today. Two operational details:

- **The `Cached` prompt-log row is not optional** — a cache hit is not an invocation, but leaving
  no trace makes the audit trail look like the physician never clicked Analyze.
- **`force=1` must always exist** — a physician wanting a second opinion, or genuine model
  nondeterminism, is a legitimate use; never remove the escape hatch.

### 2.5 The stale-suggestion hazard

If a physician gets 6 suggestions, rejects 3, and clicks Analyze again with nothing else changed:
the fingerprint is unchanged → cache hit → the 3 rejected suggestions are re-served. Fix is
frontend-only: filter served actions against locally-rejected suggestion ids (`use-copilot`
already tracks `SuggestionStatus`) before applying to the draft. Requires suggestion ids to be
stable across a cache hit (they are — `actions_json` is byte-identical on a hit) but not across a
genuine re-generation, where re-proposing a rejected item is acceptable behaviour.

### 2.6 Double-click collapse

Independent of caching and worth doing first (≈20 minutes): an in-flight guard in `use-copilot`
plus a short-TTL Redis lock keyed on `f"analyze::{encounter}::{fp}"`, so a double-tap either waits
for or reuses the first call rather than duplicating it.

## 3. Problem 2 — Meaningful clinical change detection

### 3.1 Approach chosen

| Approach | Verdict |
|---|---|
| Raw string hash | Rejected — "okay" invalidates, which is the stated problem |
| Embedding similarity | Rejected — a new dependency and model call to *avoid* a model call; an unprincipled threshold on clinical text (a 0.98 cosine can hide "no penicillin allergy" → "penicillin allergy") |
| LLM-as-judge | Deferred to an optional Layer 3 (§3.6) — cheap but adds latency and a new failure mode; build only if measurement shows Layer 2 is insufficient |
| **Normalized digest + catalog-derived lexicon** | **Chosen** — deterministic, no LLM, no new dependency, consistent with this codebase's existing preference (`pii_redaction.py` chose regex over NER for the same reason) |

### 3.2 Layer 1 — `clinical_digest()`

New module `services/transcript_digest.py`, no AI, no network: NFKC normalize + lowercase +
collapse whitespace → keep speaker labels (who said something is clinically meaningful) → strip
standalone acknowledgement utterances (§3.3) → collapse immediate disfluency repeats → canonicalise
measurements ("38.5 c" / "38,5 °C" → "38.5c").

### 3.3 The filler problem

A naive bilingual stopword list is clinically dangerous: "Doctor: any allergy to penicillin? /
Patient: yes" — stripping "yes" as a filler deletes an allergy. Filler removal is therefore
**position-aware**: remove an acknowledgement token only when it is the entire utterance of a
segment ≤2 tokens **and** that segment is not immediately preceded by a question from the other
speaker. `yes`/`sí`/`no` are deliberately **absent** from the acknowledgement lexicon — they are
answers or negation, never filler, and the position rule alone isn't protection enough for tokens
this load-bearing.

### 3.4 Layer 2 — materiality gate

Delta computed over new transcript segments only (using the segment sequence number as a
watermark). Fail-open ordering — any rule returning `True` makes the change material; only falling
through all of them is "not material":

```python
def is_material(delta_tokens, delta_text, prior_tokens) -> bool:
    if _has_measurement(delta_text): return True        # "38.5c", "120/80", "5mg", "2 days"
    if delta_tokens & clinical_lexicon(): return True    # §3.5
    if _negation_flip(delta_text, prior_tokens): return True  # "no fever" after "fever"
    if len(delta_tokens) >= MATERIAL_MIN_TOKENS: return True   # start at 12
    return False
```

`_negation_flip` is the highest-value rule and the easiest to get wrong: detect a negation cue
(`no`, `sin`, `niega`, `denies`, `not`, `ningún`) within N=4 tokens of a term already present in
prior tokens — "patient denies chest pain" after "chest pain" is material even though it adds only
three tokens.

### 3.5 The clinical lexicon is derived, not hand-written

From the six catalogs `build_encounter_context()` already resolves (`Complaint`, `Diagnosis`,
`Medication.generic_name`, `Lab Test Template`, `Clinical Procedure Template`, `Therapy Type`, plus
the patient's own allergy terms) — tokenized, lowercased, short/generic tokens dropped, cached 1h,
invalidated on `on_update` of those six doctypes. This is tenant-specific, bilingual to whatever
extent the masters are, grows with the catalog, and needs zero new data to maintain — and gives the
agent's already-resolved-then-discarded catalogs a second consumer.

### 3.6 Layer 3 — optional, off by default

If measurement shows Layer 2 has a high false-positive rate, add a micro-judge (cheap model,
`json_schema` → `{"material": bool, "reason": str}`, delta text + current draft's one-line state
only — roughly 450× cheaper than the Analyze call it would prevent). **Do not build this
speculatively** — ship Layers 0–2, log every decision for two weeks, then decide from data.

## 4. Problem 3 — Incremental transcript summarization

### 4.1 The real problem is fidelity, not cost

The stated goal (save tokens) doesn't hold — the transcript is already ~1% of an Analyze turn's
input. **The real problem:** `_tool_get_transcript` truncates by keeping the *tail*
(`text[-_MAX_TRANSCRIPT_CHARS:]`). In a 30-minute consultation, the chief complaint established in
minute 2 is silently gone by minute 25, and `_ANALYZE_PROMPT` forbids filling gaps from prior-visit
history — so the agent produces an incomplete draft with no signal anything was lost. Build the
rolling summary for **fidelity on long consultations**, not for cost; the success metric is
"does a 40-minute consultation retain its chief complaint," not tokens saved.

### 4.2 Structured JSON, not free text

A JSON summary can be diffed (feeds the fingerprint directly); the downstream pipeline is already
JSON-shaped; re-revising structured fields doesn't compound paraphrase loss the way re-summarizing
free text does.

```jsonc
{
  "schema_version": 1, "chief_complaint": "string|null", "hpi": "string",
  "symptoms": ["string"], "negatives": ["string"],
  "vitals_mentioned": {"temperature_celsius": 38.5},
  "meds_mentioned": [{"name": "...", "dose": "...", "home_or_new": "home|new"}],
  "allergies_mentioned": ["string"], "history_mentioned": ["string"],
  "plan_discussed": ["string"], "verbatim_quotes": ["string"]
}
```

`negatives[]` and `verbatim_quotes[]` are the safety-critical fields — without `negatives`,
successive revisions silently lose "denies chest pain," the exact information most dangerous to
drop.

### 4.3 Anti-drift mechanisms

1. **Never summarize a summary** — always `summary(n) = revise(summary(n-1), delta_text)`; raw
   transcript segments remain ground truth, so a full rebuild is always possible.
2. **Bound the revise chain** — force a rebuild after `MAX_REVISIONS = 8` incremental steps.
3. **Checkpoint rebuilds** after `resegregate_transcript` (speaker labels changed — every
   attribution in the summary is now questionable) and before Sign.
4. **A `rebuild=True` force flag**, mirroring `patient_clinical_summary`.

### 4.4 Storage

Mirror `patient_clinical_summary`'s watermark semantics: capture before the gather, advance only
on success. Three fields on `AI Encounter Session` (`rolling_summary_json`,
`summary_watermark_seq`, `summary_version`), with carry-forward when a new session starts for an
encounter that already has one — a real, if small, complexity, chosen over a new single-row
doctype because this codebase has a clear precedent against inventing doctypes for this shape
(chat threads are a `Data` field, not a `Session` doctype).

### 4.5 Tool integration — add, don't swap

**Do not change what `get_current_transcript` returns** — the agent's behaviour is tuned against
verbatim text, and silently substituting a summary is a clinical-behaviour change disguised as an
optimization. Instead **add** `get_transcript_summary` and instruct the model to call it first
(cheap, complete) and fall back to `get_current_transcript` only when exact wording is needed.

## 5. Speculative pre-warming

Caching (§2) makes a *repeat* Analyze instant; this makes the *first* one instant. After ~20s of
silence with a material delta pending (gated on `AI Settings.enable_suggestions`, at most once per
delta), run Analyze speculatively in the background and store the result under its fingerprint —
the click path then takes the ordinary cache-hit branch, no new serving code. Risk: paying for
analyses nobody looks at — bound hard (one in flight, max N per encounter) and track
`speculative_hit_rate`; kill if it falls below ~50%.

## 6. Cache invalidation summary

| Event | Effect |
|---|---|
| Material transcript change | invalidate (`clinical_digest` changes) |
| Trivial transcript change ("okay") | no invalidation |
| Draft edited (any of the 9 tracked fields) | invalidate |
| Suggestion accepted | invalidate (draft changed) |
| Suggestion rejected | no invalidation — §2.5 handles the UX |
| New chat turn / patient summary changed / prompt edited / model or reasoning_effort changed / language or country changed | invalidate |
| Schema or bug fix | invalidate everything — bump `FINGERPRINT_VERSION` |
| Physician wants a second opinion | bypass via `force=1` |
| Encounter signed | stop caching entirely |
| Master catalogs changed | lexicon only (1h TTL + `on_update` hook) |

## 7. Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Cache serves a result that misses a real clinical change | **High — the only clinical risk here** | Fail-open at every layer; `force=1` always available; ship with decision logging before trusting it |
| Rejected suggestions re-proposed on a hit | Medium | §2.5 client-side filter |
| Cache hit reads as a broken button | Medium | Explicit UI: "No changes since last analysis · Re-analyze anyway" |
| Filler stripping deletes a clinical answer | **High** | Position-aware rule; yes/sí/no excluded from the lexicon entirely |
| Summary drift loses a negative finding | High | `negatives[]` + `verbatim_quotes[]`; bounded revise chain; checkpoint rebuilds |
| Fingerprint too coarse ⇒ stale results | High | `FINGERPRINT_VERSION` bump invalidates globally |
| Speculative runs waste money | Low | Hard bound + hit-rate kill switch |

## 8. Rollout order

**Quick wins (days, no LLM changes):** measure actual Analyze re-click rate before building
anything further (a mean near 1.1 means §2 isn't worth it yet; ≥2 makes it the highest-ROI change
in the AI stack) → double-click guard (§2.6) → memoize prompt/tool-array loads → add `Cached`
status + `prompt_hash` write → fix `_tool_get_transcript` to warn when it truncates (makes the
§4.1 fidelity bug visible before fixing it).

**Medium (1–2 sprints):** `transcript_digest.py` (Layers 1–2, unit-tested, no LLM) →
catalog-derived lexicon + cache + invalidation hook → fingerprint + storage fields + reuse path →
frontend cache-hit UI + rejected-id filter → two weeks of decision logging, then tune
`MATERIAL_MIN_TOKENS` from data.

**Advanced (only after the above is measured):** rolling structured transcript summary as a
fidelity fix → `get_transcript_summary` tool + prompt amendment → speculative pre-warming →
Layer-3 LLM materiality judge, only if the medium phase's data justifies it.

Deliberately not on this roadmap: embedding-based similarity, a new cache doctype, and swapping
`get_current_transcript`'s contents for a summary.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.0 | 2026-09-26 | Satyakam (AI-assisted) | Consolidated into `NARZIM_GPT/`; trimmed dated meeting-log framing and superseded companion-document references, kept the design, roadmap, and risk table intact |
| 1.0 | 2026-08-04 | Sarvesh-SocialAngel | Initial version (header backfilled from git history) |
