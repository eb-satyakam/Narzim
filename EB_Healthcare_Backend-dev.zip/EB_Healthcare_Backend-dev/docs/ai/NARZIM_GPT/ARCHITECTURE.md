# Narzim GPT — Architecture Reference

**Doc status:** living · **Created:** 2026-09-26 by Satyakam (AI-assisted) · **Updated:** 2026-09-26 by Satyakam (AI-assisted) · **Version:** 1.0

Consolidated from `NARZIM_AI_ASSISTANT_DESIGN.md`, `NARZIM_AI_ENCOUNTER_SYSTEM.md`,
`NARZIM_SCOPE_GATE.md`, and the still-relevant architecture facts in
`NARZIM_GPT_BACKEND_INVENTORY.md` (a September 2026 backend-vs-frontend gap analysis; its
PR-negotiation narrative is dropped here, its durable facts kept). See
[`README.md`](./README.md) for why those originals still exist unmodified.

**Maintenance policy:** if this document and the code disagree, the code is authoritative —
correct this document in the same commit, per `CLAUDE.md` §7.

---

## 1. The two surfaces

| | Sidebar assistant ("Narzim GPT") | Encounter copilot ("Ask Narzim AI" / Analyze) |
|---|---|---|
| Frontend | `EB_Healthcare_Frontend` sidebar item, own page | `NarzimAIChatBar.tsx`, inside an open encounter |
| Backend module | `api/v1/narzim_assistant/api.py` + `services/narzim_assistant.py` | `api/v1/ai/api.py` + `services/ai_tools.py` |
| Default scope | None — patient-agnostic. A turn may **link** a patient and/or a visit (§3) | Always the one open encounter and its one patient |
| Persistence | `AI Narzim Assistant Message` (private per `session_user`) | `AI Encounter Chat Message` (ADR-034) |
| Tool access | None by default; read-only chart tools only on a linked turn (§3) | Full read + suggestion-staging tool registry (§2), every turn |
| Governing ADRs | ADR-026 (provider allowlist), ADR-050 (scope gate), ADR-075 (patient-aware context) | ADR-030 (curated tool access), ADR-034 (chat persistence) |

A genuine, historical naming collision, noted because it still shows up in filenames: this repo
has two different ADRs both numbered "030" — `adr-030-llm-curated-tool-access.md` (encounter
copilot tool registry) and `adr-030-ai-patient-chat-persistence.md` (patient-portal lab
assistant, a third, separate surface not covered by this document).

---

## 2. Encounter copilot — request flow

Both the "Analyze" pill and the free-text chat box are the same backend mechanism: a bounded
agent loop (`ask_copilot_agent`, ADR-030) granting the LLM a fixed, typed tool registry.

```
Physician clicks Analyze / types a question
  -> BFF POST /api/ai/analyze or /api/ai/encounter-chat
  -> api/v1/ai/api.py::ask_copilot / analyze_encounter
       _require_auth + _require_encounter_read
       allow_write = has_permission(Encounter, "write")
       ctx = build_encounter_context(encounter)
  -> ask_copilot_agent(prompt, history, ctx, tools)     up to 20 round-trips
       model requests tool call(s)
         READ tool  -> execute_tool -> bounded/summarised DB query -> result back to model
         WRITE tool -> validates args against schema -> returns a SUGGESTION object, never a DB write
  -> model's final text + {reply, actions[], patient_draft, follow_up}
  -> log_prompt_call() -> one AI Prompt Log row (model, tokens, cost, tool names — no content)
  -> persist turn -> AI Encounter Chat Message
  -> frontend: fillFormFromSuggestions -> each suggestion lands in the draft with a "AI" badge, editable
Physician reviews/edits/discards each item, then Save (draft) or Sign (submit) — the only steps
that persist anything to the permanent record.
```

**Known frontend gap (last verified 2026-08-13 — re-verify against current frontend code before
relying on this):** 5 patient-level write tools (`add_allergy`, `add_patient_medication`,
`add_medical_history`, `add_surgical_history`, `set_patient_summary`) returned a `patient_draft`
patch that the frontend auto-applied to the permanent `Patient` record via
`updatePatient.mutate(...)` — before Save, before Sign, with no confirmation. The backend tool
layer itself makes zero DB mutations (verified by code inspection of `services/ai_tools.py`); the
bypass, if still present, is entirely frontend-side. UNVERIFIED as of this consolidation whether
it has since been fixed.

### 2.1 Tool registry (encounter copilot)

**Read tools** — bounded, summarised JSON, never a full dump (Rule 5):

| Tool | Returns | Bound |
|---|---|---|
| `get_patient_labs` | Recent completed lab results | max 8 tests, 6 items/test |
| `get_previous_encounters` | Prior encounter summaries | max 5, default 3 |
| `get_current_transcript` | Live doctor–patient transcript | max 6,000 chars (tail-truncated — see `ANALYZE_IDEMPOTENCY.md` §4.1 for the fidelity issue this causes on long consultations) |
| `get_encounter_state` | Everything in the current draft | — |
| `get_appointment_details` | The originating appointment, if any | — |
| `get_vaccine_catalog` | This facility's immunization schedule | blocking check for `add_vaccine` |
| `get_lab_analysis` | AI interpretation of one named lab test | cached if previously analyzed |
| `search_medication_catalog` / `search_lab_catalog` / `search_diagnosis_catalog` / `search_procedure_catalog` / `search_therapy_catalog` / `search_complaint_catalog` | Real catalog-master rows matching a name | non-blocking (a zero-match result still lets the model propose a new entry) |

The six `search_*_catalog` tools share one shape: `require_permission` on the target doctype, a
bounded `frappe.get_all(..., limit_page_length=10)`, `{"matches": [...], "match_count": N}`. All
seven catalog tools (six search + `get_vaccine_catalog`) take `patient`/`encounter` kwargs only
because the registry has a uniform signature — **none of them actually reads either one**; they
are PHI-free and reusable outside an encounter context (this is exactly what §3.2's
`answer_with_context` and the sidebar assistant's formulary context, §4, reuse).

**Write tools** — validate args against a schema, return a draft suggestion, never touch the DB:

| Tool | Draft target | DB-validated at suggestion time? |
|---|---|---|
| `add_medication` / `add_lab` / `add_procedure` / `add_therapy` / `add_diagnosis` / `add_symptom` | `orders.*` / `diagnoses` / `symptoms` | Non-blocking — calls the matching `search_*_catalog` tool first, reuses an exact match verbatim, otherwise proposes a new entry |
| `add_vaccine` | `orders.vaccines` | **Yes, blocking** — must match `get_vaccine_catalog`; the sole blocking case, because an unmatched vaccine has no dose schedule to fall back on |
| `add_vital` / `add_chief_complaint` / `add_review_details` / `add_follow_up` | corresponding draft field | `add_follow_up` validated against a fixed enum |
| `add_allergy` / `add_patient_medication` / `add_medical_history` / `add_surgical_history` / `set_patient_summary` | Patient-level (`patient_draft.*`) | — (see the frontend auto-apply caveat above) |
| `remove_*` | Mirrors each `add_*` | Removes a previously suggested draft item |

### 2.2 Prompt inventory (encounter copilot)

Runtime files under `prompts/*.txt`, manifest in `prompts/README.md` (keep both in sync on any
add/rename/delete).

| File | Consumer | Purpose |
|---|---|---|
| `ask-copilot-v2.txt` | `ask_copilot_agent()` | Serves both Analyze and chat; role, scope, tool-usage rules |
| `soap-v1.txt`, `suggest-v2.txt` | `generate_soap_draft` / `generate_suggestions` | Pre-agent single-call suggestion generators; both receive real catalog rows and instruct exact-match reuse |
| `review-details-v1.txt` | `generate_review_details()` | Patient-facing visit summary at Sign |
| `resegregate-v1.txt` | `resegregate_transcript()` | Rebuilds a garbled speaker-diarized transcript |
| `medication-fields-v1.txt`, `lab-fields-v1.txt` | manual "create new medication/lab" flow | Not the encounter agent |

### 2.3 Cost model (encounter copilot)

```
cost_usd = (tokens_in / 1e6 * input_rate) + (tokens_out / 1e6 * output_rate)
```

Model pricing resolved by **longest-prefix match** (`_pricing_for_model`), not exact string
comparison — providers return dated snapshot ids (e.g. `gpt-5-mini-2025-08-07`) that would miss an
exact match and silently fall back to a wrong, more expensive default. Every invocation logged to
`AI Prompt Log` (model, tokens, cost, latency, tool names — never content, per Rule 10). Cost
driver: no prompt caching on this loop as of last verification — every round-trip re-transmits the
entire accumulated message list. **Cost/latency figures are point-in-time measurements and decay
fast — read `docs/STATUS.md` or `CURRENT_SYSTEM_AUDIT.md` for current numbers, not this document.**

---

## 3. Sidebar assistant — request flow

```
send_message(thread, message, file?, context?, sources?, urls?, template_id?, library_doc_ids?)
  -> persist user turn (AI Narzim Assistant Message)
  -> _extract_document()                 if a file/URL/library doc was attached — extract text
  -> phi_input_guard                     refuses a typed message carrying an MRN, appointment/
                                          encounter id, or multi-word patient name — BEFORE any
                                          provider call and before scope check (§3.3)
  -> _check_scope() / _check_scope_vision()   domain scope gate (§3.1) — refuses out_of_scope
  -> branch:
       context.patient or context.encounter set
         -> answer_with_context() = ask_copilot_agent(system_prompt=narzim-assistant-context-v*,
              tools=build_openai_tools(allow_write=False), call_tool=execute_tool,
              ctx={patient, encounter})          -- read-only, same audited loop as §2
       else
         -> answer_general_question()           -- no tools, no chart access at all
  -> if urls/library/clinical_web requested: fetch/extract/redact -> fold into prompt as context,
     never as a tool call (keeps the "no tools" guarantee intact for the no-context path)
  -> if template_id: instruct the model to fill body_markdown sections
  -> persist assistant turn + AI Source Reference[] rows (citations)
  -> NEVER writes to the encounter or the permanent chart
```

### 3.1 Domain scope gate (ADR-050)

Three permitted buckets; everything else refused.

| Bucket | Includes |
|---|---|
| `clinical` | Medications, dosing, interactions, diagnoses, symptoms, labs, imaging, anatomy, physiology, nursing care, procedures, devices, preventive/public health, medical research |
| `platform` | How to use this EHR/Narzim — appointments, billing/insurance workflow, clinic admin, roles/permissions |
| `conversational` | Greetings, "what can you do", operating on the assistant's own prior in-scope answer (translate/shorten/explain) |
| `out_of_scope` | Everything else — general programming, trivia, news, finance, travel, unrelated writing/homework |

Call flow: `_check_scope(history, message, redacted_document)`, placed after `_extract_document()`
and before the user turn is answered (before the first `yield` on the streaming path, so a refusal
is a normal reply, never an SSE error frame — ADR-048).

Verdict schema (identical across OpenAI and Anthropic adapters — ADR-026):

```json
{ "in_scope": true, "category": "clinical | platform | conversational | out_of_scope",
  "reason": "<audit trail only, never shown to the user>" }
```

**Fails open** — a provider error, timeout, or unparseable verdict answers the question rather
than refusing it. Deliberately the opposite of the document-upload PHI gate (§3.4), which fails
closed: this gate's failure is one off-topic answer in a private thread; that gate's failure would
write a non-clinical file into a patient's chart.

Gate model: the cheap model of the configured provider (`gpt-5-mini` / `claude-haiku-4-5`), a
per-adapter constant. Configuration: `AI Settings.narzim_scope_mode` — `Enforce` (default, refuse)
/ `Warn` (record verdict, answer anyway — shadow mode) / `Off` (skip entirely).

A guard now runs **before** the scope gate (added alongside ADR-075, §3.3): the scope check is
itself an LLM call carrying the raw message, so a patient-identifying guard placed after it would
already have disclosed what it exists to protect.

### 3.2 `answer_with_context` (ADR-075 — patient/visit linking)

The mechanism behind "link a patient" / "link a visit" in the composer.

- **Not a new agent** — reuses `ask_copilot_agent` (the same audited loop as §2), with
  `system_prompt`, `context_block`, and `history_labels` parameters added (default `None`,
  reproducing byte-for-byte behaviour for every existing caller) so there is exactly one place
  where the iteration cap, tool dispatch, and usage accounting can drift.
- **`allow_write=False` is a literal at the call site**, not a permission lookup — no permission
  configuration can make this surface write a chart.
- **Authorised twice** — once when the linked ids are accepted (`parse_turn_inputs`), again inside
  `answer_with_context` immediately before the provider call, separated by a persist and a commit.
- **Patient-scope tools only** — the 3 encounter-bound read tools (transcript, encounter draft,
  appointment) are withheld entirely when only a patient (no visit) is linked, so the model never
  burns an iteration on a tool that cannot work.
- **Bounded context (Rule 5)** — the chart is never dumped into the prompt. The injected context
  block carries only the patient id, sex, and age, asserted by test to stay under 400 characters.
  Everything clinical the model states must come from an audited tool call, which is what makes
  it citable.
- **A linked-patient turn is answered on the non-streaming path** — delivered as one delta. The
  tool loop is multi-round-trip, not a token stream, so there is nothing to stream until it
  finishes.

Prompt lineage is intentionally separate from the no-context lineage: `narzim-assistant-context-v1
/ -v2` (context turns) vs. `narzim-assistant-v1` through `-v3` (context-free turns, still most
turns). The context prompt drops the "you have no access to any database" opening (false the
moment a chart is linked) and adds a **linked patient** section: read-only, call a tool rather than
guess, an empty tool result means *not documented*, not *none*, and only the linked patient is in
scope.

### 3.3 Layered PHI guardrails (sidebar assistant)

In the order they run on a single turn:

1. **`phi_input_guard`** — refuses a typed message carrying an MRN, appointment/encounter id, or a
   multi-word patient name, before any provider call and before anything is persisted. Ids are
   matched **by shape**, never by DB lookup (a lookup would make the refusal an existence oracle).
   Only multi-word names are matched — a bare first name is not caught (measured against a real
   patient list: single-token matching would refuse a large share of ordinary Spanish-language
   questions, since common name-tokens overlap common words like "de").
2. **Domain scope gate** (§3.1).
3. **Narrowed identifier guard, on a linked turn only** — `assert_no_other_patient_identifier`
   allows the *linked* patient's id/name (that's the point of linking), refuses any *other*
   patient's, resolves an encounter/appointment id to its patient first, and — importantly — an id
   that resolves to **nobody** is refused rather than ignored (it cannot be cleared as "the linked
   patient" without becoming a bypass for a not-yet-existing id).
4. **`redact_text()` on any uploaded document/URL/library text** — deterministic, regex + bilingual
   (es-MX/en-US) labelled-field matching (`Name:`/`Nombre:`, DOB, email, MRN, CURP, phone, address),
   never an LLM call. Known limit, stated in its own docstring: cannot catch a name in unlabelled
   prose or embedded in a URL string.
5. **Clinical Web outbound query gate** (§4.1), for anything that leaves to a third party with no
   BAA (PubMed, a pasted URL).

A dedicated document-upload PHI classifier (`check_document_for_patient_phi`) existed at one
point in this pipeline's history and was later superseded by the local-redaction approach in item
4 — the file-bytes-never-leave-the-process design is the current state; do not reintroduce a
classify-and-refuse step that transmits raw bytes without checking against current code first.

**One standing, deliberate exception:** an image with no OCR-extractable text (e.g. an X-ray
photo) is sent to the model as raw bytes via `answer_document_question` — the only code path in
this feature where raw file bytes reach a provider. This was an explicit, user-directed decision
(not a default), because there is no text to redact from an image at all. The only safeguard on
that path is a prompt instruction to decline if a visible name/MRN/ID is spotted in the image —
model judgment, not an architectural block, same class of guarantee as every other prompt-level
safeguard in this codebase.

Conversations can be removed from a user's history, but only as a **soft delete**
(`hidden`/`hidden_on`/`hidden_by` on `AI Narzim Assistant Message`, filtered from every read path).
`delete` permission stays 0 for every role — partly because §164.312(c)(1) requires ePHI be
protected from improper destruction, partly because `scope_verdict`/`scope_category` on every row
are how the scope gate's false-positive rate gets measured on real traffic, and a hard delete
would let a user erase exactly the turns most worth reading.

### 3.4 Upload handling

Every format feeds the same pipeline: extract locally → `redact_text()` → fold into
`answer_general_question()`'s user turn as plain text. No raw file bytes reach a provider for any
of: PDF (`pypdf` text layer), Excel/Word/PowerPoint/CSV/plain text, or a scanned/photographed PDF
(rendered to an image, then OCR'd). Excel/CSV get an extra masking pass by **column header** (a
"Name" column is masked by position, not by an inline `Label:` match). Images/scans use
`pytesseract` + `tesseract-ocr` (a system binary — confirm it is actually installed wherever this
is deployed; its Frappe Cloud availability was flagged as unconfirmed as of the source design
document). OCR is a materially weaker guarantee than the other extractors — it infers text from
pixels and can misread or drop characters. A PDF/image with no extractable text, or an unsupported
type, is rejected outright with a message pointing the user at a text-based format or the
in-encounter assistant instead (except the vision fallback in §3.3).

---

## 4. Clinical Web / citations

No knowledge-source stack existed in this codebase before this feature — no embeddings, no source
cache, no outbound-fetch infrastructure. Built in a fixed order because later steps needed earlier
ones' guarantees in place first.

### 4.1 Outbound search query gate (`services/clinical_web_query.py`)

Runs before anything is allowed to leave the process, independent of whether a fetcher exists yet
— built first so the rule exists before anything can violate it. Strips exactly three things from
a search query, deliberately narrower than an earlier "is this word medical?" version that was
measured to strip so much (including real clinical terms not present in the clinic's own small
catalog lexicon) that searches came back empty and the feature would get switched off:

| Stripped | How |
|---|---|
| A patient's name and record id | Exact token match against the `Patient` table — a lone surname is still caught |
| An email address | By shape |
| A contact number | By length — 1–3 digits travel (doses, ages, frequencies), 4+ do not (phone numbers, record numbers, years) |

Re-checked again immediately before transmission (`is_safe_to_send`) by the code that opens the
connection — a guarantee enforced only at creation stops being one the moment a second creator is
added. An empty query means **do not search**, never "search for everything." Fails closed on a
database error (if the patient list can't be read, the gate can't work, so it refuses rather than
searching unprotected).

This closes a specific leak: ADR-075 allows naming the *linked* patient in a chat message (correct
— the chart is already open). Without this gate, that same text would ride inside a PubMed query
URL into a third party's access logs — a party with no BAA, unlike OpenAI/Anthropic — with nothing
in the pipeline (no prompt log, no consent surface) positioned to catch it.

### 4.2 Compliance register (`ComplianceProfile`)

Three new fields, every default the refusing value:

```
retrieval_providers          = ()      nothing approved
url_fetch_allowed            = False   the server fetches no user-supplied address
source_cache_retention_days  = 0       nothing is cached
```

Before these fields existed, PHI-1 ("an integration must refuse to run against a provider the
active profile does not name") was not merely unsatisfied for Clinical Web, it was structurally
unsatisfiable — there was nowhere to name a retrieval provider even if one were approved.

### 4.3 `AI Source Cache` / `AI Source Reference`

- **`AI Source Cache`** — keyed by `sha256(url)` or `sha256(pubmed_query)`, PII-redacted extract,
  `ttl_hours` (default 24, driven by `source_cache_retention_days`). The retention number *is* the
  on/off switch for caching, not a separate flag.
- **`AI Source Reference`** — child table on `AI Narzim Assistant Message`, serialised as
  `references[]` on `send_message`, the streaming `done` event, and `get_thread`. **A citation may
  only be created from something that was actually retrieved** — rows are written at fetch time by
  the code that fetched, the model is never asked to produce one, and the array is built from
  stored rows rather than parsed out of the reply text. This is what prevents a fabricated
  citation, which is worse than none because it looks verified. A row is refused at write time if
  it has no title, an index below 1, or `kind="library"` with no `library_doc`. Always returned as
  an array, never omitted or null, ordered by index.

### 4.4 Fetching (PubMed + pasted URLs)

- **PubMed** — `esearch` + `esummary`, top 5, cached 24h.
- **Pasted URLs** — a dedicated SSRF-safe fetcher (`services/safe_fetch.py`) that re-validates the
  resolved address at connection time (not just at input-validation time — the classic
  DNS-rebinding gap), http(s) only, no private/internal hosts, max 5 URLs per turn.
- Both providers gated by `list_sources()` reporting `clinical_web.enabled` computed from whether
  the active `ComplianceProfile` actually names a retrieval provider — never hardcoded true.
- `library` (the second source type) reports enabled based on whether Frappe Drive is installed
  *and* has a configured clinic team — both failure modes (Drive absent, Drive present but
  unconfigured) are real states this reports distinctly, because their fixes differ (a deployment
  decision vs. a setup step).

### 4.5 Library as a source

Browse/upload/delete reuses Frappe Drive (`api/v1/drive/api.py`) — **not** a `Clinical Documents`
concept from an earlier iteration; that doctype was migrated away from. A pinned library file is
authorised through `services/drive.py::get_entry` (Drive's own private-by-default sharing model),
not generic `require_permission`, and a missing/unauthorized file raises `DoesNotExistError` rather
than a 403 — for a file titled after a patient, "403 Forbidden" is itself a disclosure. The import
is lazy, so a deployment without Drive installed can still send ordinary messages; only pinning
requires Drive.

---

## 5. Chat output templates (`AI Chat Template`)

Filled note structures (SOAP, referral letter) — not to be confused with `AI Prompt Template`
(system-prompt overrides, a different, unrelated doctype).

| Method | What it does |
|---|---|
| `list_templates` / `get_template` / `create_template` / `update_template` / `delete_template` | Standard CRUD. Own rows + system rows readable by all; only own rows writable; a system row cannot be deleted (403, "duplicate it first") |
| `apply_template(template_id, thread, context=None, sources=None)` | Fills the outline into the chat thread, reusing `answer_with_context` when a patient/visit is linked. With nothing to fill from, returns the outline unchanged and makes no model call. Never writes the encounter |
| `generate_template(encounter_ids, name="", category="encounter")` | Builds a **blank form** (headings + slot wording) from up to 5 past encounters. **Nothing derived from a patient's record reaches the model** — not "redacted before"; the prompt is assembled only from a fixed, hand-written vocabulary list, and reading the visits yields vocabulary *keys* and integer counts, never values. An unrecognised key is counted but never named, so even a future or hand-edited key whose name carried content cannot leak. A provider failure falls back to the deterministic skeleton (real, usable, plainer wording), never an error |
| `suggest_templates(thread, context=None, message="")` | No model call — string/keyword matching of the clinician's own recent turns against template titles/descriptions/section headings (never bodies, to avoid every template matching every message). Returns ranked suggestions plus `offer_to_save` when the conversation already looks like a filled template with nothing existing to match it |
| `start_template_edit_session` / `edit_template_chat` / `save_template_session` | A session doctype (not Redis — survives `bench clear-cache` and a restart), holding only the working outline, never a filled example (synthetic, generated on demand, never cached) and never a patient/encounter (so this surface cannot become an unexpected PHI location). `context` is accepted and explicitly unused (`context_used: false`) |

Clone-from-system (`duplicate_from`) is how a clinician gets an editable copy of a system template
without being able to overwrite the shipped original.

---

## 6. Data model (doctypes)

| Doctype | Role |
|---|---|
| `AI Narzim Assistant Message` | Sidebar assistant chat log — role, content, model/tokens/cost, `context_patient`/`context_encounter`, `sources_requested`/`sources_used`, `template_used`, `reply_format`, `scope_verdict`/`scope_category`, `hidden`/`hidden_on`/`hidden_by` |
| `AI Encounter Chat Message` | Encounter copilot chat/analysis log (ADR-034) — `kind` (chat\|analysis), `actions_json`, `input_fingerprint`/`fingerprint_version` (see `ANALYZE_IDEMPOTENCY.md`) |
| `AI Prompt Log` | Audit row for every LLM invocation across both surfaces — model, tokens, cost, latency, status, tool names. Never content (Rule 10). `purpose` values include `Narzim Assistant Chat`, `Narzim Assistant Scope Check`, plus the encounter-copilot purposes |
| `AI Settings` (Single) | `llm_provider`, model selection, `narzim_scope_mode`, `narzim_sources_enabled`, `narzim_assistant_max_tokens` |
| `AI Chat Template` / `AI Template Edit Session` | Output-template system (§5) |
| `AI Source Cache` / `AI Source Reference` | Clinical Web caching + citations (§4.3) |
| `AI Patient Clinical Summary` | Separate cross-encounter patient summary feature (ADR-029) — distinct from the per-visit `set_patient_summary` tool |
| `AI Subscription Plan` (+`Company`/`Seat`), `AI Usage Counter` | Credit/seat metering scaffolding (ADR-027) — **not wired into the current BYOK model**; do not build against these without confirming they are live |

## 7. Response envelope — read before writing a frontend caller

Three response shapes exist across this app's API surface, verified in `utils.py`:

```
(a) single object   {"status":"success","data":{...}}                  set_response
(b) paginated list   {"status":"success","data":[...],"pagination":{}}  set_list_response
(c) raw return       {"message":{...}}                                  narzim_assistant.* and ai.* only
```

`data` in (b) **is** the array; `pagination` is its sibling, not nested inside `data` (a stale
docstring in `utils.py` says `{"items": [...]}` — the code, not that docstring, is right). Both
Narzim surfaces (`api/v1/narzim_assistant/*` and `api/v1/ai/*`) deliberately use the bare
`{"message": ...}` shape, matching each other, not the `set_response`/`set_list_response`
convention used elsewhere in this app. A caller that assumes one shape for all three will break on
whichever one it didn't expect.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-26 | Satyakam (AI-assisted) | Initial consolidated architecture reference |
