# Narzim GPT (PR #493) — backend inventory: what exists, what to build

**Doc status:** living · **Created:** 2026-09-17 by Divyanshu (AI-assisted) · **Updated:** 2026-09-17 by Divyanshu (AI-assisted) · **Version:** 3.12

Answers one question for [PR #493](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/493):
**for every capability that PR's UI needs, does a backend API already exist — and if so, what is
its exact endpoint, payload, response, and frontend use?**

Verified against `dev` on 2026-09-17 by reading the code, not the docs.

> **The decision that unblocks this is [ADR-075](../adr/adr-075-narzim-gpt-patient-aware-context.md).**
> Narzim GPT is deliberately patient-blind today (§3.5); PR #493 makes it patient-aware. ADR-075
> accepts that reversal in a specific, narrowed shape — linked ids only, read-only, free-text
> patient names still blocked. **Clinical Web (§3.4 item 4) still needs a second ADR** for its
> subprocessors and `ComplianceProfile` entry (PHI-1) before any outbound call is built.

---

## 0. Two conventions you must know before reading anything below

### 0.1 Endpoint form

Every backend method is a Frappe whitelisted call. There is no REST resource routing (that is
banned — `CLAUDE.md` §3, "never use `/api/resource/`"). The URL is the **dotted Python path**:

```
POST https://<site>/api/method/remedisys_healthcare_ai.api.v1.<module>.api.<function>
Authorization: Bearer <jwt>            # eb_frappe_jwt, ADR-011
Content-Type: application/json
```

Arguments are sent as a **JSON body** (or form fields for multipart). The Next.js BFF holds the
token server-side; the browser never sees it (ADR-010/011).

### 0.2 ⚠️ Two different response envelopes — this WILL bite the frontend

There are **three** shapes, not two. Verified in `remedisys_healthcare_ai/utils.py`.

**(a) Single object** — `set_response`, used by `patients.get_patient`, `billing`, etc.

```json
{ "status": "success", "data": { "...": "..." } }
```

**(b) Paginated list** — `set_list_response`, used by `list_patients`, `list_encounters`:

```json
{ "status": "success",
  "data": [ {"...": "..."} ],
  "pagination": { "total": 137, "page": 1, "page_size": 10 } }
```

⚠️ **`data` IS the array, and `pagination` is its SIBLING — not nested inside `data`.**
`utils.py:404` documents this as `{"items": [...]}`, but `utils.py:412` actually writes
`frappe.response["data"] = items`. **The code is right and that docstring is wrong** — read
`res.data`, never `res.data.items`.

**(c) Raw return** — `narzim_assistant` and `ai` only:

```json
{ "message": { "...": "..." } }
```

Deliberate: `api/v1/narzim_assistant/api.py`'s docstring says it is *"deliberately bare-
whitelisted-method style (no `handle_api_errors` envelope), matching `api/v1/ai/api.py`"*.

So chat is `res.message.reply`, the patient picker is `res.data[…]`. **The PR's mock returns one
flat shape for all three** — the BFF must normalise per module, or the picker and the chat break
in different ways the day mock is switched off.

---

# PART 1 — WHAT WE ALREADY HAVE

## 1.1 Chat core — `api/v1/narzim_assistant/api.py` (205 lines, 8 methods)

Service behind it: `services/narzim_assistant.py` (1,094 lines).

### `send_message` — ✅ live, **must be extended**

```
POST /api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.send_message
```

**Payload today** — this is the entire signature, `send_message(thread, message="")`:

| Field | Type | Required | Notes |
|---|---|---|---|
| `thread` | str | ✅ | client-generated conversation id (ChatGPT style — new chat mints a new uuid) |
| `message` | str | — | required unless a file is attached |
| `file` | multipart | — | **PDF only** on this path |

**Response**

```json
{"message": {
  "reply": "Amoxicillin dosing in children is…",
  "message_name": "AINAM-2026-00123",
  "thread": "a1b2c3…",
  "model": "gpt-5-mini",
  "tokens_in": 1234,
  "tokens_out": 567,
  "cost_usd": 0.003,
  "refused": false
}}
```

**Frontend use:** the chat composer. **Every extra field PR #493 sends (`context`, `sources`,
`urls`, `template_id`, `library_doc_ids`) is silently discarded** — the signature has nowhere to
put them. `references[]` does not exist, so the citation list has nothing to render.
`reply_format` **now exists** (see §3.6) but reports `"plain"` until
`AI Settings.narzim_reply_markdown` is switched on.

### `send_message_stream` — ✅ live, **PR does not mention it**

```
POST …narzim_assistant.api.send_message_stream     → text/event-stream (SSE)
```

Same `(thread, message="")` contract, token-by-token. `send_message` is kept as a working
fallback. **If only `send_message` is extended, the two paths diverge** and streaming silently
loses context/citations — which is exactly what happened on 2026-09-18 and was fixed the same
day by deleting the duplicated assembly (§3.22). A parity test now fails if it recurs.

### `get_thread` — ✅ live, **must be extended**

```
POST …narzim_assistant.api.get_thread      { "thread": "a1b2c3…" }   // empty → most recent thread
```

```json
{"message": {
  "thread": "a1b2c3…",
  "messages": [{
    "id": "AINAM-2026-00123", "role": "user|assistant", "content": "…",
    "model": "gpt-5-mini", "tokens_in": 0, "tokens_out": 0, "cost_usd": 0.0,
    "attached_file": null, "feedback": "", "feedback_note": ""
  }]
}}
```

**Frontend use:** replaying a conversation. On reload, **linked-patient chips, source toggles, URL
chips and citations would all vanish** — none of those fields are stored or returned.

### `list_threads` — ✅ live, no change needed

```
POST …narzim_assistant.api.list_threads    {}
→ {"message":[{"thread":"…","preview":"…","count":12,"last":"2026-09-17 14:02:11"}]}
```

**Frontend use:** the thread sidebar (`narzim-thread-list.tsx`). Works as-is.

### `set_feedback` — ✅ live, **PR documents it wrongly**

```
POST …narzim_assistant.api.set_feedback
{ "message": "AINAM-2026-00123", "feedback": "Up|Down|", "note": "optional" }
```

The handoff says `set_feedback(message, thread, feedback, note?)`. **There is no `thread`
parameter.** Sending one is harmless but it is not part of the contract.

### `hide_thread` / `hide_all_threads` / `get_usage_summary` — ✅ live

```
POST …narzim_assistant.api.hide_thread       { "thread": "…" }
POST …narzim_assistant.api.hide_all_threads  {}
POST …narzim_assistant.api.get_usage_summary { "from_date":"YYYY-MM-DD", "to_date":"…" }  // admin only
```

**Frontend use:** thread delete / clear-all; usage is admin reporting, not in this PR.

---

## 1.2 Pickers — reuse exactly as the PR says

### `list_patients` — ✅ live, no change needed

```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.list_patients
{ "search": "mar", "page_size": 10 }
```
Response envelope (b) — see §0.2. Full row shape in §2.2.

`search` substring-matches **MRN, patient name, mobile, email, or a linked guardian's name**.
21 other filters exist and are irrelevant here.

**Frontend use:** the "Link patient" picker. Send `Patient.name` (the MRN) as
`send_message.context.patient`. **Do not build `search_patients`** — the PR correctly says so.

### `list_encounters` — ✅ live, no change needed

```
POST …encounters.api.list_encounters
{ "patient": "MRN-2026-0001433", "page_size": 10 }
```

Filters: `patient`, `date`, `from_date`/`to_date`, `practitioner`, `status`, `status_in`,
`exclude_cancelled`, `page`, `page_size`.

**Frontend use:** the "Link visit" picker, scoped to the patient just linked. Send
`Patient Encounter.name` as `context.encounter`. **Do not build `search_encounters`.**

---

## 1.3 Library / files — ⚠️ the PR points at the wrong module

The handoff says My Library is `clinical_documents.api`. **That module does not exist** —
`api/v1/clinical_documents/` contains only `__pycache__`. Two real surfaces exist instead:

### `api/v1/drive/api.py` — the actual Clinical Document surface (22 methods)

```
POST …drive.api.list_entries      { "parent": null, "search": "" }
POST …drive.api.upload            multipart, field "file", + "parent"
POST …drive.api.trash             { "id": "…" }
POST …drive.api.share             { "id": "…", "users": [...], "level": "View" }
GET  …drive.api.download          { "id": "…" }
POST …drive.api.summarize_entry   { "id": "…", "lang": "es" }
POST …drive.api.ask_entry         { "id": "…", "question": "…" }
```

`summarize_entry` / `ask_entry` are notable — **document Q&A already exists here**, which overlaps
what the PR wants "My Library" to do.

⚠️ `_ALLOWED_EXT` (`services/drive.py:60`) is
`jpg jpeg png gif webp bmp tiff svg pdf xlsx xls csv` — **no `docx`, no `txt`**. The PR's
"one-line allowlist change" is real and lands here.

### `api/v1/documents/api.py` — a *different* thing

```
POST …documents.api.list_documents   { "patient": "MRN-…", "category": "", "search": "" }
POST …documents.api.upload_document  multipart
POST …documents.api.get_download_url { "document_id": "…" }
POST …documents.api.delete_document  { "document_id": "…" }
```

These are **Patient Medical Record rows** (`custom_is_uploaded_document=1`), i.e. the patient's
chart files — not the doctor's personal library. **Frontend use:** the optional "patient files as
extra context", not My Library.

---

## 1.4 Chart reading — the engine for "Link patient"

`services/ai_tools.py` holds `TOOL_REGISTRY` = **38 tools: 15 read, 23 write**.
(`CLAUDE.md` says 36 — stale.)

```python
build_openai_tools(allow_write=False)     # drops all 23 write tools
build_anthropic_tools(allow_write=False)  # same registry, Claude envelope
ask_copilot_agent(prompt, history, ctx, tools, call_tool)   # bounded loop, ≤20 iterations
execute_tool(name, args, *, encounter, patient, transcript, ctx)
```

### Which read tools work with a patient but **no** encounter — verified in code

| Tool | Patient-only? |
|---|---|
| `get_patient_labs` | ✅ |
| `get_patient_allergies` | ✅ |
| `get_lab_analysis` | ✅ |
| `get_vaccine_catalog` | ✅ |
| `search_medication_catalog` | ✅ |
| `search_lab_catalog` | ✅ |
| `search_diagnosis_catalog` | ✅ |
| `search_procedure_catalog` | ✅ |
| `search_therapy_catalog` | ✅ |
| `search_complaint_catalog` | ✅ |
| `get_previous_encounters` | ✅ **works** — uses `encounter` only as `name != encounter`, so `""` excludes nothing |
| `get_current_medications` | ✅ **works** — same exclusion-only pattern |
| `get_current_transcript` | ❌ needs an encounter |
| `get_encounter_state` | ❌ `require_permission("Patient Encounter","read",doc=encounter)` then `get_doc` → throws on `""` |
| `get_appointment_details` | ❌ needs an encounter |

**12 of 15 reads work patient-only.** This is the single most important finding for scoping: a
patient linked without a visit still gets labs, allergies, prior encounters, prior medications and
every catalog. Only the 3 "this visit" tools must be withheld.

**Frontend use:** none directly — this is what makes a linked patient actually *do* something.

---

## 1.5 Supporting pieces that already exist

| Need | Where | Reuse as |
|---|---|---|
| PHI masking | `services/pii_redaction.redact_text` | mask URL/library text **and the outbound PubMed query** |
| File text extraction | `_extract_document` in `services/narzim_assistant.py` | reuse for URL/library extraction |
| Prompt load + SHA | `integrations/openai.py::_load_prompt` / `_prompt_sha` | load the new v4 prompt |
| LLM audit | `AI Prompt Log` doctype | every new call must log here (§9) |
| Encounter-less audit | `services/ai.log_prompt_call_general(purpose=…)` | for dictation / context-free turns |
| Token budget | `AI Settings.llm_context_token_budget` | Rule 5 cap on context turns |
| Domain gate | `_check_scope` + `prompts/narzim-scope-check-v1.txt` (ADR-050) | **unchanged** — linking a patient does not widen topics |

### Mic — `transcribe_audio`

```
POST /api/method/remedisys_healthcare_ai.api.v1.ai.api.transcribe_audio
{ "encounter": "HLC-ENC-2026-00008", "audio_b64": "<base64 webm/opus>" }
→ {"message": {"segments":[…], "transcript":"Doctor: …\nPatient: …"}}
```

`encounter` is **required today** (`def transcribe_audio(encounter: str, audio_b64: str)`), and
Narzim's composer mic is not inside a visit. Audio is never stored. **Frontend use:** dictation in
the chat composer and the template editor — blocked until `encounter` is optional.

---

# PART 2 — WHERE EACH API IS USED (UI → BFF → backend)

The chain is always three hops. The browser never calls Frappe directly (ADR-010): a React
component calls a **Next.js BFF route**, which holds the JWT server-side and calls the **Frappe
whitelisted method**.

```
React component  →  /api/ai/narzim-assistant/<route>  →  /api/method/remedisys_healthcare_ai.…
 (PR #493)           (PR #493, BFF)                       (this repo)
```

**Legend** — 🟢 live now · 🟡 live but must be extended · 🔴 must be built

Payloads below are marked **VERIFIED** (read from this repo's code today) or **PROPOSED** (from
the PR's `NARZIM_GPT_FEATURE_HANDOFF.md` — a contract, not yet built). Do not treat PROPOSED as
fact.

## 2.1 Chat screen — `/narzim-ai`

| UI element | Component (PR #493) | BFF route | Backend method | Status |
|---|---|---|---|---|
| Send a message | `narzim-chat-panel.tsx` | `POST /send` (multipart) | `narzim_assistant.api.send_message` | 🟢 **DONE** — accepts `context`, `sources`, `urls`, `template_id`, `library_doc_ids` (§3.8) |
| Live-typing reply | `narzim-chat-panel.tsx` | *(none yet)* | `narzim_assistant.api.send_message_stream` | 🟡 **exists, PR ignores it** — now at full parity with the blocking path incl. retrieval and citations (§3.22) |
| Render markdown | `markdown-viewer.tsx` | — (renders `send`/`thread` payload) | `reply_format` 🟢 **built, flag-gated OFF** (§3.6) |
| `[n]` citations | `citation-list.tsx` | — (`msg.references`) | `references[]` 🟢 **DONE** — library, literature and pasted pages, one shared numbering (§3.18 · §3.20 · §3.21) |
| Reopen a conversation | `narzim-chat-panel.tsx` | `POST /thread` | `narzim_assistant.api.get_thread` | 🟢 **DONE** — replays every new field incl. `references[]` and `sources_used` (§3.8) |
| Conversation sidebar | `narzim-thread-list.tsx` | `POST /threads` | `narzim_assistant.api.list_threads` | 🟢 use as-is |
| Delete / clear threads | `narzim-thread-list.tsx` | *(add)* | `hide_thread` / `hide_all_threads` | 🟢 use as-is |
| 👍 / 👎 on a reply | `narzim-chat-panel.tsx` | `POST /feedback` | `narzim_assistant.api.set_feedback` | 🟢 **no `thread` arg** |
| Empty-state prompt cards | `narzim-chat-panel.tsx` | `POST /suggestions` | `get_suggestions` | 🟢 **DONE 2026-09-18 — §3.25.** Role-aware, localised, grounded in this clinic's own formulary. Deterministic, no model call |
| Mic dictation | `narzim-chat-panel.tsx` | `POST /api/ai/transcribe` | `ai.api.transcribe_audio` | 🟢 backend **DONE** · ⚠️ **BFF still blocks it** — see note below |

> ⚠️ **The backend change alone does NOT unblock the mic — a frontend one-liner is still required.**
> `EB_Healthcare_Frontend/src/app/api/ai/transcribe/route.ts:19` rejects the request before it ever
> reaches Frappe:
> ```ts
> if (!body?.encounter || !body?.audioB64) {
>   return Response.json({ error: "encounter and audioB64 are required" }, { status: 400 })
> }
> ```
> It must become `if (!body?.audioB64)`, and `TranscribeBody.encounter` must become optional
> (`encounter?: string`). The backend now accepts either shape, so this change is safe to make at
> any time and breaks nothing that works today. **Owned by the frontend dev** — not changed here,
> per `CLAUDE.md` §13.

### Payloads — chat

> Postman / Bruno variables: `{{base_url}}` (e.g. `http://127.0.0.1:8003`), `{{access_token}}`
> (eb_frappe_jwt bearer, ADR-011). Same names the repo's `bruno/environments/local.bru` already uses.

#### 1. `send_message` — ✅ VERIFIED (works today)

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.send_message
Authorization: Bearer {{access_token}}
Content-Type: multipart/form-data
```
Body → **form-data**:

| Key | Type | Value |
|---|---|---|
| `thread` | Text | `a1b2c3-4d5e-6f70-8901-234567890abc` |
| `message` | Text | `amoxicillin dosing in an 18 kg child` |
| `file` | File | *(optional — `application/pdf` ONLY on this path)* |

**200 OK**
```json
{
  "message": {
    "reply": "For an 18 kg child, amoxicillin is usually dosed at 40-50 mg/kg/day…",
    "message_name": "AINAM-2026-00123",
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "model": "gpt-5-mini",
    "tokens_in": 1234,
    "tokens_out": 567,
    "cost_usd": 0.003,
    "refused": false
  }
}
```

**403 Forbidden** — the PHI guard fired (message named a patient):
```json
{
  "exception": "frappe.exceptions.PermissionError",
  "_server_messages": "[\"Narzim GPT cannot see patient records…\"]"
}
```

#### 2. `send_message` — 🟢 **SHIPPED 2026-09-17** (the 5 new fields) — §3.8

Same URL and form-data, plus these keys. **Each is a JSON string inside a form field**, not a
nested object — multipart has no nesting.

| Key | Type | Value |
|---|---|---|
| `context` | Text | `{"patient":"MRN-2026-0001433","encounter":"HLC-ENC-2026-00008"}` |
| `sources` | Text | `["clinical_web","library"]` |
| `urls` | Text | `["https://publications.aap.org/pediatrics/article/..."]` (max 5) |
| `template_id` | Text | `TMPL-00004` |
| `library_doc_ids` | Text | `["CLIN-DOC-0001"]` |

**200 OK**
```json
{
  "message": {
    "reply": "## Assessment\n\nLikely viral upper respiratory infection [1].\n\n## Plan\n\n- Supportive care\n",
    "reply_format": "markdown",
    "message_name": "AINAM-2026-00124",
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "model": "gpt-5-mini",
    "tokens_in": 4210,
    "tokens_out": 830,
    "cost_usd": 0.011,
    "sources_used": ["clinical_web"],
    "template_used": "TMPL-00004",
    "references": [
      {
        "index": 1,
        "kind": "guideline",
        "title": "Bright Futures / AAP periodicity schedule",
        "url": "https://www.aap.org/en/practice-management/bright-futures/",
        "snippet": "Annual well-child visits are recommended from age 3…",
        "publisher": "American Academy of Pediatrics",
        "published_date": "2026-01-01",
        "authors": null,
        "pmid": null,
        "doi": null
      }
    ]
  }
}
```
`sources_used` lists only sources that actually returned text. **Never emit a citation without a
retrieve.**

#### 3. `send_message_stream` — ✅ VERIFIED (SSE)

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.send_message_stream
Authorization: Bearer {{access_token}}
Content-Type: application/json
Accept: text/event-stream
```
```json
{ "thread": "a1b2c3-4d5e-6f70-8901-234567890abc", "message": "amoxicillin dosing" }
```
**200 OK** — `text/event-stream`, not JSON. Postman shows raw chunks:
```
data: {"type":"token","text":"For "}
data: {"type":"token","text":"an 18 kg "}
data: {"type":"done","message_name":"AINAM-2026-00123","tokens_out":567}
```

#### 4. `get_thread` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.get_thread
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "thread": "a1b2c3-4d5e-6f70-8901-234567890abc" }
```
> Send `{"thread": ""}` or `{}` to get the user's **most recent** thread.

**200 OK**
```json
{
  "message": {
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "messages": [
      {
        "id": "AINAM-2026-00122",
        "role": "user",
        "content": "amoxicillin dosing in an 18 kg child",
        "model": null,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost_usd": 0.0,
        "attached_file": null,
        "feedback": "",
        "feedback_note": ""
      },
      {
        "id": "AINAM-2026-00123",
        "role": "assistant",
        "content": "For an 18 kg child…",
        "model": "gpt-5-mini",
        "tokens_in": 1234,
        "tokens_out": 567,
        "cost_usd": 0.003,
        "attached_file": null,
        "feedback": "Up",
        "feedback_note": ""
      }
    ]
  }
}
```
`reply_format` (`"plain"` | `"markdown"`) is **already returned** per message — see §3.6.
🟢 **SHIPPED 2026-09-17** (§3.8) — per message, all optional so old rows still parse:
user turn `context`, `sources_requested`, `urls`, `library_doc_ids`;
assistant turn `sources_used`, `template_used`. `template_used` carries a real value as of
§3.11. `sources_used` and `references[]` carry real values as of §3.20 (library) and §3.23
(literature and pasted pages), on both the blocking and the streaming paths (§3.22).

#### 5. `list_threads` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.list_threads
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{}
```
**200 OK**
```json
{
  "message": [
    {
      "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
      "preview": "amoxicillin dosing in an 18 kg child",
      "count": 12,
      "last": "2026-09-17 14:02:11"
    }
  ]
}
```

#### 6. `set_feedback` — ✅ VERIFIED (⚠️ no `thread` argument)

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.set_feedback
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "message": "AINAM-2026-00123", "feedback": "Up", "note": "clear and correct" }
```
`feedback` ∈ `"Up"` | `"Down"` | `""` (clears). **200 OK** → `{"message": {"ok": true}}`

#### 7. `hide_thread` / `hide_all_threads` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.hide_thread
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "thread": "a1b2c3-4d5e-6f70-8901-234567890abc" }
```
`hide_all_threads` takes `{}`.

#### 8. `transcribe_audio` — ✅ VERIFIED · `encounter` is now OPTIONAL

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.ai.api.transcribe_audio
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
In-encounter scribe (unchanged):
```json
{ "encounter": "HLC-ENC-2026-00008", "audio_b64": "GkXfo59ChoEBQveBAULyg..." }
```
Narzim / template-editor dictation — **no encounter**:
```json
{ "audio_b64": "GkXfo59ChoEBQveBAULyg..." }
```
**200 OK**
```json
{
  "message": {
    "segments": [
      { "speaker": "doctor", "text": "How long has the fever lasted?",
        "start": 0.0, "end": 2.4, "confidence": 0.98 }
    ],
    "transcript": "Doctor: How long has the fever lasted?\nPatient: About three days."
  }
}
```
Both return the identical shape. Audio is never stored either way. Deepgram usage is audited on
both paths — with an encounter via `log_prompt_call`, without one via
`log_prompt_call_general(purpose="narzim-dictation")`, so billed usage is never unaccounted (§9).

**400 Bad Request** when `audio_b64` is missing:
```json
{ "exception": "frappe.exceptions.ValidationError", "_server_messages": "[\"audio_b64 is required.\"]" }
```

## 2.2 Plus menu — linking context

| UI element | Component | BFF route | Backend method | Status |
|---|---|---|---|---|
| "Link patient" picker | `narzim-chat-panel.tsx` | `GET /search-patients?q=` | **`patients.api.list_patients`** `{search, page_size:10}` | 🟢 **do not build `search_patients`** |
| "Link visit" picker | `narzim-chat-panel.tsx` | `GET /search-encounters?q=&patient=` | **`encounters.api.list_encounters`** `{patient, page_size:10}` | 🟢 **do not build `search_encounters`** |
| Chip → next turn | `use-narzim-assistant.ts` | `POST /send` | `send_message.context = {patient, encounter}` | 🟢 **DONE — §3.8** |
| Answering *from* the chart | — (server-side) | — | `answer_with_context()` → `ask_copilot_agent(tools=build_openai_tools(allow_write=False))` | 🟢 **DONE — §3.10** (ADR-075) |
| Patient's chart files as extra context | `narzim-source-bar.tsx` | existing documents BFF | `documents.api.list_documents` `{patient}` | 🟢 use as-is |

> **Picker id mapping:** patient = `Patient.name` (the MRN, e.g. `MRN-2026-0001433`);
> encounter = `Patient Encounter.name` (e.g. `HLC-ENC-2026-00008`). Send the **id**, never the
> name — §3.5 and ADR-075 depend on identity arriving as a structured id.

### Payloads — pickers

#### 9. `list_patients` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.patients.api.list_patients
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "search": "renata", "page": 1, "page_size": 10 }
```
**200 OK** — envelope **(b)**: `data` IS the array, `pagination` is a sibling.
```json
{
  "status": "success",
  "data": [
    {
      "mrn": "MRN-2026-0001433",
      "name": "Renata Martínez Cruz",
      "first_name": "Renata",
      "last_name": "Martínez Cruz",
      "gender": "Female",
      "sex": "F",
      "dob": "12-03-1981",
      "age": "45 Yrs 06 months 05 days",
      "status": "Active",
      "mobile": "+52 55 1234 5678",
      "phone": null,
      "email": "renata@example.com",
      "blood_group": "",
      "image": null,
      "guardian": null,
      "activity": { "kind": "none" },
      "nextAppointment": null,
      "lastVisit": "2026-09-17",
      "isNew": false,
      "lastEncounter": null,
      "balanceDue": 0.0,
      "primaryPractitioner": "HLC-PRAC-2026-00045"
    }
  ],
  "pagination": { "total": 137, "page": 1, "page_size": 10 }
}
```
➡️ **Send `data[i].mrn` as `send_message.context.patient`.**
`search` substring-matches MRN, patient name, mobile, email, or a linked guardian's name.

#### 10. `list_encounters` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.encounters.api.list_encounters
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "patient": "MRN-2026-0001433", "page": 1, "page_size": 10, "exclude_cancelled": 1 }
```
**200 OK**
```json
{
  "status": "success",
  "data": [
    {
      "name": "HLC-ENC-2026-00008",
      "patient": "MRN-2026-0001433",
      "patient_name": "Renata Martínez Cruz",
      "practitioner": "HLC-PRAC-2026-00045",
      "practitioner_name": "Anant Sharma",
      "encounter_date": "2026-09-17",
      "encounter_time": "14:45:00",
      "appointment": "HLC-APP-2026-00716",
      "appointment_type": "General Consultation",
      "medical_department": "General Physician",
      "company": "Narzim",
      "status": "Open",
      "docstatus": 0,
      "invoiced": 0
    }
  ],
  "pagination": { "total": 3, "page": 1, "page_size": 10 }
}
```
➡️ **Send `data[i].name` as `send_message.context.encounter`.**
Filters: `patient`, `date`, `from_date`/`to_date`, `practitioner`, `status`, `status_in`,
`exclude_cancelled`, `page`, `page_size`. `date` and the range are mutually exclusive.

#### 11. `list_documents` (patient chart files) — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.documents.api.list_documents
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "patient": "MRN-2026-0001433", "category": "", "search": "" }
```
These are Patient Medical Record rows — the patient's **chart** files, **not** My Library.

## 2.3 Sources bar — "Clinical Web" / "My Library"

| UI element | Component | BFF route | Backend method | Status |
|---|---|---|---|---|
| Which sources exist | `narzim-source-bar.tsx` | `GET /sources` | `list_sources()` | 🟢 **DONE — §3.19** |
| Clinical Web toggle | `narzim-source-bar.tsx` | `POST /send` | `send_message.sources:["clinical_web"]` | 🟢 **DONE — enabled 2026-09-18 under ADR-077** (§3.21 · §3.23) |
| Paste a URL | `narzim-source-bar.tsx` | `POST /send` | `send_message.urls:[…]` max 5 | 🟢 **DONE — enabled 2026-09-18 under ADR-077**, with the pasted address screened for patient identifiers (§3.23) |
| Browse My Library | `narzim-source-bar.tsx` | `GET /library` | **`drive.api.list_entries`** | 🟢 **not `clinical_documents.api`** |
| Upload to My Library | `narzim-source-bar.tsx` | `POST /library` (multipart) | **`drive.api.upload`** | 🟢 ⚠️ `_ALLOWED_EXT` lacks `docx`/`txt` |
| Delete from My Library | `narzim-source-bar.tsx` | `DELETE /library/:id` | **`drive.api.trash`** | 🟢 use as-is |
| Pin a library doc on a turn | `narzim-source-bar.tsx` | `POST /send` | `send_message.library_doc_ids:[…]` | 🟢 **DONE — §3.20.** Text reaches the prompt and a `[1]` cites it |
| Cite what was used | `citation-list.tsx` | — | `references[]` + `AI Source Reference` | 🟢 **WORKS for library sources — §3.18, §3.20.** PubMed/URL citations wait on ADR-076 |

> `drive.api.summarize_entry` and `drive.api.ask_entry` already do **document Q&A**. Check these
> before writing new library-search code — the overlap is real.

### Payloads — sources & library

#### 12. `drive.api.list_entries` (browse My Library) — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.drive.api.list_entries
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "parent": null, "search": "" }
```

#### 13. `drive.api.upload` — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.drive.api.upload
Authorization: Bearer {{access_token}}
Content-Type: multipart/form-data
```
| Key | Type | Value |
|---|---|---|
| `file` | File | *(the document)* |
| `parent` | Text | *(folder id, optional)* |

⚠️ `_ALLOWED_EXT` (`services/drive.py:60`) = `jpg jpeg png gif webp bmp tiff svg pdf xlsx xls csv`
— **no `docx`, no `txt`.** A `.docx` upload is rejected today. Adding them is the PR's
"one-line allowlist" change.

#### 14. `drive.api.trash` (delete) — ✅ VERIFIED

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.drive.api.trash
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "id": "CLIN-DOC-0001" }
```

#### 15. `drive.api.ask_entry` / `summarize_entry` — ✅ VERIFIED

Document Q&A that **already exists** — check before writing new library-search code.

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.drive.api.ask_entry
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "id": "CLIN-DOC-0001", "question": "what was the HbA1c?" }
```
```json
{ "id": "CLIN-DOC-0001", "lang": "es" }
```

#### 16. `list_sources` — 🟢 **SHIPPED 2026-09-18** (§3.19)

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.list_sources
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{}
```
**200 OK**
```json
{
  "message": {
    "sources": [
      {
        "type": "clinical_web",
        "enabled": true,
        "label": "Clinical Web",
        "description": "PubMed, WHO, CDC, AAP, and clinical practice guidelines"
      },
      {
        "type": "library",
        "enabled": true,
        "label": "My Library",
        "description": "Your files and URLs"
      }
    ]
  }
}
```
One toggle: `clinical_web` = PubMed esearch/esummary (top 5, 24h cache) + allowlisted hosts
`cdc.gov`, `who.int`, `aap.org`, `publications.aap.org`. Token budget 2,000.
**URL attach is not a source type** — it rides on `send_message.urls`.

## 2.4 Template library — `/narzim-ai/templates`

| UI element | Component / page | BFF route | Backend method | Status |
|---|---|---|---|---|
| Template list | `narzim-template-list.tsx`, `templates/page.tsx` | `GET /templates` | `list_templates(category)` | 🟢 **DONE — §3.9** |
| Open one | `templates/[id]/page.tsx` | `GET /templates/:id` | `get_template(id)` | 🟢 **DONE — §3.9** |
| Create | `templates/new/page.tsx`, `narzim-template-dialog.tsx` | `POST /templates` | `create_template(...)` | 🟢 **DONE — §3.9** |
| Update (own only) | `narzim-template-editor.tsx` | `PUT /templates/:id` | `update_template(...)` → `version += 1` | 🟢 **DONE — §3.9** |
| Delete (own only) | `narzim-template-list.tsx` | `DELETE /templates/:id` | `delete_template(id)` | 🟢 **DONE — §3.9** |
| Pick one in chat | `narzim-template-picker.tsx` | `POST /send` | `send_message.template_id` | 🟢 **DONE — §3.11.** `template_used` is no longer always null |
| Apply to a thread | `narzim-template-picker.tsx` | `POST /apply-template` | `apply_template(...)` — draft turn, never writes the encounter | 🟢 **DONE — §3.11** |
| Build from past visits | `narzim-template-dialog.tsx` | `POST /generate-template` | `generate_template(encounter_ids)` — ≤5 ids, **unsaved**; no PHI to strip, none is sent (§3.13) | 🟢 **DONE — §3.13** |
| Suggest / offer to save | `narzim-chat-panel.tsx` | `POST /suggest-templates` | `suggest_templates(thread, …)` | 🟢 **DONE — §3.14** |

### Payloads — templates (#17–23 🟢 **ALL SHIPPED** — §3.9, §3.11, §3.13, §3.14)

`AI Chat Template` fields: `title`, `description`, `category`
(`encounter` | `document` | `analysis` | `general`), **`body_markdown` canonical**, `is_default`,
`is_system`, `version`, `duplicate_from`, `owner`.

#### 17. `list_templates`

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.list_templates
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "category": "" }
```
**200 OK**
```json
{
  "message": [
    {
      "id": "TMPL-00004",
      "name": "Pediatric SOAP Note",
      "description": "Standard paediatric consultation note",
      "category": "encounter",
      "is_default": true,
      "is_system": true,
      "version": 1,
      "updated_at": "2026-09-17T14:02:11"
    }
  ]
}
```

#### 18. `get_template`

```json
{ "template_id": "TMPL-00004" }
```
Returns the list row **plus** `body_markdown` and `sections[]`.

#### 19. `create_template`

```json
{
  "name": "My SOAP",
  "description": "",
  "category": "general",
  "body_markdown": "## Subjective\n\n- [Reason for visit] (State the primary reason…)\n",
  "duplicate_from": "TMPL-00004"
}
```

#### 20. `update_template` / `delete_template`

```json
{ "template_id": "TMPL-00007", "body_markdown": "## Subjective\n…" }
```
Own rows only. A `body_markdown` change bumps `version`.
Permissions: System Manager all · Practitioner own CRUD + system read · Nurse / Front Desk read
own + system. Editing or deleting an `is_system` row → **403 `"Duplicate it first."`**

#### 21. `apply_template`

```json
{
  "template_id": "TMPL-00004",
  "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
  "context": { "patient": "MRN-2026-0001433", "encounter": "HLC-ENC-2026-00008" },
  "sources": ["clinical_web"]
}
```
Fills `body_markdown` into a **draft turn**. Never writes the encounter.

#### 22. `generate_template`

```json
{
  "encounter_ids": ["HLC-ENC-2026-00008", "HLC-ENC-2026-00011", "HLC-ENC-2026-00014"],
  "name": "",
  "category": "encounter"
}
```
≤5 ids. Returns **unsaved** `{"id": null, "body_markdown": "…", "sections_used": […], …}`.
**"PHI stripped" is the wrong description of what was built** — nothing patient-derived is sent at
all, so there is nothing to strip (approach D, §3.13).

#### 23. `suggest_templates`

```json
{ "thread": "a1b2c3-…", "context": { "patient": "MRN-2026-0001433" }, "message": "" }
```

#### `body_markdown` language

```markdown
## Subjective

- [Reason for visit or chief complaint] (State the primary reason for the consultation. Only
  include if explicitly mentioned in the transcript or clinical note; otherwise leave blank.)
- [Vital signs] (Include temperature, pulse, blood pressure, oxygen saturation…)
```

Fill rules: replace `[slot]` only with a value you actually have; treat the parenthetical as
instructions and **never print the parentheses**; if nothing was said leave the bullet blank — do
**not** write "not mentioned"; never invent patient details. Legacy `{{placeholders}}` +
`<!-- AI instructions -->` may appear on system rows — accept both, persist the
`[slot] (instruction)` form after an edit.

## 2.5 Template editor — Structure / Example tabs

| UI element | Component | BFF route | Backend method | Status |
|---|---|---|---|---|
| Open editor session | `narzim-template-editor.tsx` | `POST /templates/edit-session` | `start_template_edit_session(id)` | 🟢 **DONE — §3.12** |
| Edit outline by hand | `markdown-editor.tsx`, `structure-canvas.tsx` | `POST /templates/edit-session/chat` | `edit_template_chat(session_id, structure_markdown=…)` | 🟢 **DONE — §3.12** |
| "What would you like to change?" | `narzim-template-editor.tsx` | `POST /templates/edit-session/chat` | `edit_template_chat(session_id, message=…)` | 🟢 **DONE — §3.12** |
| Example tab preview | `narzim-template-editor.tsx` | `POST /templates/generate-example` | `generate_template_example(body_markdown)` — **never persisted** | 🟢 **DONE — §3.11** |
| Save | `narzim-template-editor.tsx` | `POST /templates/edit-session/save` | `save_template_session(...)` — **structure only** | 🟢 **DONE — §3.12** |
| Mic in the editor | `narzim-template-editor.tsx` | `POST /api/ai/transcribe` | `ai.api.transcribe_audio` | 🟢 backend **DONE** · ⚠️ same BFF block |

> **Do not store `example_markdown` on `AI Chat Template`** — a filled example is synthetic PHI.
> Generate on demand, cache in the session, never persist.

### Payloads — template editor (#24–#27 🟢 **ALL SHIPPED** — §3.11, §3.12)

Session lives in the `AI Template Edit Session` doctype (**not** Redis — §3.12 says why), TTL 24h, purged daily.

#### 24. `start_template_edit_session`

```http
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.templates.start_template_edit_session
Authorization: Bearer {{access_token}}
Content-Type: application/json
```
```json
{ "template_id": "TMPL-00004" }
```
**200 OK**
```json
{
  "message": {
    "session_id": "tes-7f3a91c2",
    "template_id": "TMPL-00004",
    "title": "Pediatric SOAP Note",
    "structure_markdown": "## Subjective\n\n- [Reason for visit] (…)\n",
    "version": 1,
    "is_copy": true
  }
}
```
`is_copy: true` when the source is `is_system` → Save must call
`create_template(duplicate_from=…)` rather than `update_template`.

#### 25. `edit_template_chat`

```json
{
  "session_id": "tes-7f3a91c2",
  "message": "Add a follow-up slot under Plan",
  "structure_markdown": "## Subjective\n…",
  "context": { "patient": "MRN-2026-0001433", "encounter": "HLC-ENC-2026-00008" }
}
```
Returns the patched `structure_markdown`. When `context` is present, load **read** tools so the
model can reason about the chart **without writing it, and without copying chart text into the
stored structure**.

#### 26. `generate_template_example`

```json
{ "body_markdown": "## Subjective\n\n- [Reason for visit] (…)", "context": null }
```
**200 OK**
```json
{ "message": { "example_markdown": "## Subjective\n\n- Fever for three days…" } }
```
⚠️ **Never persisted** — a filled example is synthetic PHI. The session may cache it in memory
only; Save must not write it to `AI Chat Template`.

#### 27. `save_template_session`

```json
{ "session_id": "tes-7f3a91c2", "name": "" }
```
Persists **structure only**.

## 2.6 One-line summary of reuse

**Already built, wire straight up (7):** `list_threads` · `get_thread` · `set_feedback` ·
`hide_thread` / `hide_all_threads` · `list_patients` · `list_encounters` · `drive.api.*` ·
`documents.api.list_documents`

**Extend (4):** `send_message` · `send_message_stream` · `get_thread` payload ·
`transcribe_audio` — ✅ **all four done**

**Build (≈17 methods + 5 doctypes):** sources, URL fetch, citations, templates CRUD, template
editor sessions, `answer_with_context`, `list_sources`, `get_suggestions` — ✅ **all done as of
2026-09-18.** The 5th doctype (`AI Source Cache`) landed under ADR-079 and `get_suggestions`, the
last method, under §3.25.

> **The backend for PR #493 is complete.** The one remaining item in the whole mapping is a
> **frontend** one-liner that still blocks the mic — `route.ts:19` rejects a visit-less transcribe
> before it reaches Frappe. Owned by the frontend dev (§13 rule 2), not changed here.

---

# PART 3 — WHAT WE HAVE TO BUILD

## 3.1 Doctypes — 5, all confirmed missing

| Doctype | Purpose | Why it can't be reused |
|---|---|---|
| ~~`AI Chat Template`~~ ✅ **built** | SOAP/referral structures, `body_markdown` canonical | `AI Prompt Template` exists but is **system-prompt overrides**, a different concept |
| ~~`AI Chat Template Section`~~ ✅ **built** | parsed sections (cache only, rebuilt on save) | — |
| ~~`AI Source Cache`~~ ✅ **built 2026-09-18** (§3.24, ADR-079) | PubMed / URL fetch cache, 30-day retention | Built for reproducibility, not speed: a stored copy is what lets a reopened conversation show what the model actually read. Purge and erasure handle shipped in the same change |
| ~~`AI Source Reference`~~ ✅ **built** | child on the assistant message → `references[]` (§3.18) | — |
| ~~`AI Template Edit Session`~~ ✅ **built** | editor session, TTL 24h, purged daily (§3.12) | — |

## 3.2 `AI Narzim Assistant Message` — new fields

Current schema has **none** of what the PR needs. Add: `context_patient`, `context_encounter`,
`sources_requested`, `sources_used`, `urls`, `library_doc_ids`, `template_used`, `reply_format`,
plus a `references` child table (`AI Source Reference`).

Without these, reload loses everything — which is exactly gap #2 in the PR's own list.

## 3.3 `AI Settings` — 5 new fields (46 exist, none of these)

`narzim_sources_enabled` · `pubmed_api_key` · `guideline_domains` · `source_cache_ttl_hours` ·
`narzim_reply_markdown`

## 3.4 API work

| # | Build | Effort | Reason |
|---|---|---|---|
| 1 | ~~`send_message` + `send_message_stream` accept and persist the 5 extras~~ | M | ✅ **DONE 2026-09-17 — §3.8.** `sources_used`/`template_used` return empty until items 4–5; `references[]` still blocked (§3.7) |
| 2 | ~~`get_thread` returns the same extras~~ | S | ✅ **DONE 2026-09-17 — §3.8.** Replays `context_patient`/`context_encounter`, `sources_requested`, `urls`, `library_doc_ids`, `template_requested`, `sources_used`, `template_used` |
| 3 | ~~`answer_with_context()` + **patient-only tool subset** (12 tools) + permission check on the linked ids~~ | M–L | ✅ **DONE 2026-09-17 — §3.10** (ADR-075). 21 tests |
| 4 | `list_sources()` + PubMed/guideline fetch + SSRF-safe URL fetch + cache + citations | L | ✅ **COMPLETE 2026-09-18** — enabled under ADR-077 (§3.23); `AI Source Cache` built under ADR-079 (§3.24). Previously: **ALL CODE BUILT** — §3.15–§3.21. Library citations work today; PubMed and URL fetch are built but **REFUSE** until ADR-076 is accepted and a profile names the provider. `AI Source Cache` deferred: only external fetches need caching, and nothing fetches yet |
| 5 | ~~`AI Chat Template` — CRUD, fill, editor, generate, suggest~~ | L | ✅ **COMPLETE 2026-09-18** — §3.9 · §3.11 · §3.12 · §3.13 · §3.14. 2 doctypes, 13 whitelisted methods, 5 prompts, 80 tests |
| 6 | ~~`transcribe_audio`: make `encounter` optional~~ | **XS** | ✅ **DONE 2026-09-17** — `encounter` optional, visit-less calls audited via `log_prompt_call_general(purpose="narzim-dictation")`. 5 tests in `tests/ai/test_transcribe_audio_encounter_optional.py`, all passing |
| 7 | ~~`prompts/narzim-assistant-v4.txt`~~ | S | ✅ **DONE 2026-09-17 — §3.6.** Ships with the markdown flag OFF |

## 3.5 The guardrail change (ADR-075)

`services/narzim_assistant.py:444` calls `assert_no_patient_identifier(message)` **first**, and
`phi_input_guard.py:144` throws *"Narzim GPT has no access to patient records."*

Per [ADR-075](../adr/adr-075-narzim-gpt-patient-aware-context.md) this is **narrowed, not removed**: identifiers of the **linked** patient are allowed;
every other patient still throws; with nothing linked, behaviour is unchanged. The user-facing
refusal copy must change with it (**PHI-5** — never state in the UI what the code does not do).

---

## 3.6 `reply_format` — ✅ DONE 2026-09-17, shipped OFF

Item 2 of 7. The assistant can answer in GitHub-flavoured markdown, and every reply now states
which it is. **Gated behind a flag that ships OFF**, for a concrete reason:

- `prompts/narzim-assistant-v3.txt:39-40` tells the model *"Do not build out multi-section
  structure (headers, multiple bullet groups…)"* and *"Prefer one tight paragraph"* — the live
  prompt actively discourages markdown.
- The **shipped** chat surface renders replies with `whitespace-pre-wrap`
  (`narzim-chat-panel.tsx`) — plain text. Markdown would print raw `##`, `**` and `|` to a
  clinician.

So `CLAUDE.md` §9's "feature flags default OFF in production" is not ceremony here; ON by default
would have been a visible regression for every current user.

| Piece | What |
|---|---|
| `AI Settings.narzim_reply_markdown` | new `Check`, **default 0** |
| `AI Narzim Assistant Message.reply_format` | new `Select` `plain\|markdown`, default `plain`, read-only |
| `prompts/narzim-assistant-v4.txt` | **v3 + a Formatting section, nothing else** — verified by diff |
| `integrations/openai.py`, `anthropic.py` | `_narzim_prompt_file() -> (filename, version)`; 5 call sites rewired per provider |
| `services/narzim_assistant.py` | persisted on the message, returned by `send_message`, replayed by `get_thread`, emitted in both SSE `done` events |

**Flag OFF = byte-identical to before.** v3 is loaded, `narzim-assistant-v3` is recorded, and
`reply_format` is `"plain"`. An unreadable `AI Settings` also falls back to v3 — failure lands on
the current behaviour, never the new one.

Two decisions worth keeping:

1. **`reply_format` is derived from the prompt version the reply was actually generated with**
   (`_MARKDOWN_PROMPT_VERSIONS`), never by reading the setting a second time. The flag can be
   flipped between generating a reply and persisting it; re-reading would stamp a v3 reply
   `"markdown"` and render its literal `**` to the clinician.
2. **It is stored per MESSAGE, not per thread.** A conversation can span the flip, and replies
   written before it must keep replaying as plain text forever.

### Why the non-markdown value is `"plain"`, not `"text"` — decided 2026-09-17

**The two words mean the same thing.** Both say "this reply is ordinary prose, not formatted".
There is no behavioural difference whatsoever; this is `colour`/`color`. The only thing that
matters is that **both sides spell it identically**, because the client compares the string
literally:

```ts
// the comparison this has to survive
if (msg.reply_format === "plain") { /* render as prose */ }
```

A backend sending `"text"` does not fail loudly there — it falls silently to the `else` branch and
a plain reply gets treated as formatted. That class of bug is expensive to find precisely because
nothing looks broken.

It shipped as `"text"` earlier the same day and was changed. **The basis for choosing `"plain"`:**

| | Backend (ours) | Frontend (PR #493) |
|---|---|---|
| Already written | yes | yes — `types.ts:59` `reply_format?: "markdown" \| "plain"` |
| Live consumers | **none** — flag ships OFF, nothing reads the value | this is the shipped direction |
| Cost to change | one rename + one data patch | editing another repo's file |
| Whose call | ours | the frontend dev's (`CLAUDE.md` §13) |

So: the side with **no live consumer** moves, and the side already written stays. Changing ours was
free *today* and would not have been in a month, once saved data and client code depended on it.
Changing theirs would have meant editing `EB_Healthcare_Frontend` without the frontend dev, which
§13 does not allow. Neither word being technically better is exactly why the cheap, reversible,
in-our-own-repo option wins — there is nothing to trade off against it.

**Cost paid:** `bench migrate` applies a new column's default to rows that already exist, so 244
messages were already stamped `"text"` on the dev site. Those values are no longer valid Select
options, so the rename needed a real migration
(`patches/v0/rename_narzim_reply_format_text_to_plain_20260917.py`, registered in `patches.txt`
— §9 forbids manual schema fixes). Safe by construction: every one of those replies was generated
by `narzim-assistant-v3`, the plain-prose prompt, so it is a rename of the same meaning and not a
reinterpretation. Nothing was ever stored as `"markdown"` — the flag has never been switched on.
A test fails if any row is left on the retired value.

### Turning it on

```
AI Settings → "Narzim Assistant Replies in Markdown" → ✅
```
Do this only once the chat surface renders markdown (PR #493's `markdown-viewer.tsx`). Nothing
else changes; the switch is reversible and affects only replies generated after it.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_reply_format.py` — **9 cases, all passing**
(plus item 1's 5 re-run as a regression check: 14/14).

---

## 3.7 `references[]` — 🟢 **WORKING for library sources (§3.18 + §3.20).** Web citations wait on ADR-076

### What it is

The numbered source list under an assistant reply. The model writes `[1]` inline in its markdown;
`references[1-1]` is the entry that `[1]` points at. Without it the chat can render **formatting**
(done, §3.6) but has **no sources to show**, so PR #493's `citation-list.tsx` never renders.

### Why it is not built — and why it could not be built yet

**A citation needs something retrieved to cite.** Narzim today answers purely from the model's own
knowledge (`answer_general_question`) — it fetches nothing, so there is nothing to attribute. The
prompt rule the PR specifies is *"no citation without a retrieve"*, and honouring it means the
retrieval has to exist first.

So `references[]` is blocked on **a retrieval existing**, not on the citation plumbing itself.
Building the array first would leave exactly one way to populate it — letting the model invent
sources — which is the failure mode this feature exists to avoid, and worse than showing no
citations at all.

⚠️ **Corrected 2026-09-18: that is NOT the same as "blocked on Clinical Web".** Item 4 has three
sources, and **My Library is not one that leaves the building** — pinning the clinician's own
uploaded file sends nothing to any third party, and `drive.api` already stores, serves and answers
questions about those files. So a `kind: "library"` citation needs **no ADR and no
`ComplianceProfile` entry**, and can ship while PubMed and URL fetch wait for sign-off.

Three concrete pieces are missing:

| Missing | Why it blocks citations |
|---|---|
| A retrieval that returns text + provenance | nothing to cite |
| `AI Source Reference` child doctype on the message | nowhere to persist them, so a reload loses them |
| `AI Source Cache` | refetching on every reload, and no stable snippet to quote |

### The contract — read from PR #493, not from the handoff prose

`src/components/narzim/narzim-ai/types.ts:16-28`:

```ts
export type NarzimReferenceKind = "pubmed" | "guideline" | "literature" | "url" | "library"

export interface NarzimReference {
  index: number            // 1-based; matches the [n] in the markdown
  kind: NarzimReferenceKind
  title: string            // the only field besides index that is REQUIRED
  url?: string
  snippet?: string
  publisher?: string
  published_date?: string
  authors?: string
  pmid?: string
  doi?: string
  library_doc?: string     // set when kind === "library"
}
```

⚠️ **`library_doc` is in the frontend type but NOT in the handoff's JSON example.** Set it to the
`Clinical Document` id for `kind: "library"`, or the citation cannot link back to the doctor's file.

### Where it is used on the frontend

| | |
|---|---|
| **Rendered by** | `src/components/narzim/narzim-ai/citation-list.tsx` |
| **Mounted from** | `narzim-chat-panel.tsx:548-549` — `{!isUser && saved && msg.references?.length ? <CitationList references={msg.references} /> : null}` |
| **Gated on** | assistant turn · message saved · `references.length > 0`. An empty array renders nothing, so omitting it is safe and never breaks the panel |
| **Fields actually read** | `index`, `title`, `url`, `publisher`, `snippet` — the component reads **only these five**. `kind`, `pmid`, `doi`, `authors`, `published_date` are carried in the type but not displayed today |
| **Link behaviour** | `url` present → title becomes an external link (`target="_blank" rel="noopener noreferrer"`); absent → plain bold text |

So the **minimum useful payload is `{index, title}`**, with `url`, `publisher` and `snippet` being
what makes a citation worth showing.

### Payload / response

`references[]` rides on two existing responses. Both are additive — a client that predates them
ignores the key, and `citation-list.tsx` treats absent and `[]` identically.

**On `send_message`** (see §2.1 request #2):

```json
{
  "message": {
    "reply": "## Assessment\n\nLikely viral URI; supportive care is appropriate [1]. Antibiotics are not indicated [2].",
    "reply_format": "markdown",
    "message_name": "AINAM-2026-00124",
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "sources_used": ["clinical_web"],
    "references": [
      {
        "index": 1,
        "kind": "guideline",
        "title": "Bright Futures / AAP periodicity schedule",
        "url": "https://www.aap.org/en/practice-management/bright-futures/",
        "snippet": "Annual well-child visits are recommended from age 3…",
        "publisher": "American Academy of Pediatrics",
        "published_date": "2026-01-01",
        "authors": null, "pmid": null, "doi": null
      },
      {
        "index": 2,
        "kind": "pubmed",
        "title": "Antibiotics for acute upper respiratory tract infections in children",
        "url": "https://pubmed.ncbi.nlm.nih.gov/00000000/",
        "snippet": "No significant benefit over placebo for symptom duration…",
        "publisher": "Cochrane Database Syst Rev",
        "published_date": "2025-11-02",
        "authors": "Smith J, Patel R", "pmid": "00000000", "doi": "10.1002/14651858.CD000247"
      }
    ]
  }
}
```

**On `get_thread`**, per assistant message, so a reload still shows them:

```json
{ "id": "AINAM-2026-00124", "role": "assistant",
  "content": "## Assessment\n\n… [1]",
  "reply_format": "markdown",
  "references": [ { "index": 1, "kind": "library", "title": "Clinic antibiotic policy 2026",
                    "library_doc": "CLIN-DOC-0001", "snippet": "…" } ] }
```

### Rules the backend must honour

1. **Never emit a citation without a retrieve.** `[n]` in the text must have a matching
   `references[n-1]`, and every entry must come from text actually fetched.
2. **`index` is 1-based and contiguous**, matching the inline markers. A gap renders a `[3]` the
   reader cannot resolve.
3. **`sources_used` lists only sources that returned text.** An empty retrieve omits the source
   rather than reporting it with zero citations.
4. **Persist them** as `AI Source Reference` rows (`parentfield = references`) so `get_thread`
   replays them. A reply whose citations vanish on reload is worse than one that never had them.
5. **`snippet` is quoted text from the source** — it is third-party content, not PHI, and must never
   be back-filled with anything from the chart.

---

## 3.8 The five composer extras — ✅ TRANSPORT DONE 2026-09-17

Item 3 of 7. `send_message` and `send_message_stream` now **accept, authorise,
persist and replay** `context`, `sources`, `urls`, `template_id` and
`library_doc_ids`; `get_thread` replays them so a reload no longer drops the chips.

**Transport only, deliberately.** None of it *acts* yet — `context` does not reach a tool
(`answer_with_context`, §3.4 item 3), `sources`/`urls` are not fetched (Clinical Web, item 4),
`template_id` is inert until `AI Chat Template` exists (item 5). The composer already sent these
and the backend silently dropped them, so accepting them correctly is independently useful and
independently reviewable.

### The two things that make accepting them safe

**1. Authorisation — `services/narzim_turn_inputs.py`.** Every linked id is re-checked against the
session user with `require_permission`, every turn. The picker filtered the list, but it runs in the
browser and the id arrives as a plain string: a client can send any id at all. Lose this check and
one clinician can attach another's patient to a thread with nothing visibly broken (ADR-075 §3).

**2. SSRF.** A pasted URL is fetched **by our server** on a later turn, so an unchecked value turns
the assistant into a proxy for whatever the server can reach. Refused at the boundary: non-`http(s)`
schemes, `localhost`, and literal private / loopback / link-local / reserved / multicast addresses —
including `169.254.169.254`, the cloud metadata endpoint.

> ⚠️ **Not sufficient alone.** A public hostname can still resolve to a private address (DNS
> rebinding). The fetcher built in item 4 **must re-check the resolved IP at connection time**. This
> makes the obvious cases impossible; it does not make the fetch safe by itself.

### Validation rules

| Field | Rule |
|---|---|
| `context` | JSON object. Patient and encounter must exist **and be readable by the session user**. A mismatched pair is **refused** — otherwise the two halves could describe different people. Linking only an encounter **resolves and stores its patient**, so a later tool call never re-derives it |
| `sources` | subset of `clinical_web`, `library`. An unknown value is **refused, not ignored** — silently dropping it would leave the clinician believing a source was searched. `urls` is **not** a source type |
| `urls` | max 5, `http(s)` only, SSRF-checked, de-duped |
| `library_doc_ids` | max 20, each must exist and be readable — pinning another user's document would put its text into a later prompt |
| `template_id` | shape-checked only (≤140 chars). **Not** link-validated: `AI Chat Template` does not exist yet, and losing the choice is worse than recording an unresolvable id |

Malformed JSON is refused **with the field named**, before anything is persisted or sent to a
provider. On the streaming path this happens **before the `Response` is built**, so a bad id is a
real HTTP error rather than an SSE `error` frame after a 200 has already gone out.

### Storage — 10 new fields on `AI Narzim Assistant Message`

User turn: `context_patient` (Link → Patient), `context_encounter` (Link → Patient Encounter),
`sources_requested`, `urls`, `library_doc_ids` (JSON text), `template_requested` (Data).
Assistant turn: `sources_used` (JSON text), `template_used` (Data).

An empty list stores as **NULL, not `"[]"`**, so "never sent" stays distinguishable from "sent
empty", and the common case (no extras) costs nothing. Reading back never raises — a row hand-edited
in the Desk replays as empty rather than breaking the whole thread reload.

**A refused turn records them too**, for the same reason ADR-034 keeps the refused question itself:
a reload that drops the chips reads as if nothing was ever attached.

⚠️ **PHI-4 consequence:** a Narzim message can now Link a `Patient`. Retention and erasure must
cover these rows — ADR-075 records this and it is **not yet implemented**.

### Response / replay

`send_message` always returns `sources_used: []` and `template_used: null` (empty until items 4–5),
so the client never treats "absent" as a third case. `get_thread` returns, per message: `context`
(**omitted entirely when nothing was linked**, so the client can test truthiness), `sources_requested`,
`urls`, `library_doc_ids`, `template_requested`, `sources_used`, `template_used`.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_turn_inputs.py` — **20 cases**, covering the
permission refusal, every SSRF class, the mismatched pair, and malformed input. 35/35 across all
three shipped items.

---

## 3.9 `AI Chat Template` CRUD — ✅ PART A DONE 2026-09-17

Item 5 of 7, **part A: the deterministic half**. Two doctypes and six methods, no LLM anywhere.
Part B (`apply_template`, `generate_template`, `generate_template_example`, the edit-session trio)
is still to build — those need prompts and carry a real PHI question, so they get their own pass.

### Doctypes

| Doctype | |
|---|---|
| `AI Chat Template` | `title`, `category`, `description`, **`body_markdown` (canonical)**, `is_default`, `is_system`, `version`, `duplicate_from`, `sections`. Named `TMPL-.#####` |
| `AI Chat Template Section` | child — `heading`, `level`, `slot_count`. **A cache**, rebuilt wholesale on every save, never the source of truth |

### Methods — `api/v1/narzim_assistant/templates.py`

Its own module, not `api.py`: that file is the chat turn, and templates are a different resource
with their own permission model.

```
POST …narzim_assistant.templates.list_templates      { "category": "", "page": 1, "page_size": 50 }
POST …narzim_assistant.templates.get_template        { "template_id": "TMPL-00004" }
POST …narzim_assistant.templates.create_template     { "name", "description", "category",
                                                       "body_markdown", "duplicate_from" }
POST …narzim_assistant.templates.update_template     { "template_id", + any subset of the above }
POST …narzim_assistant.templates.delete_template     { "template_id": "TMPL-00007" }
POST …narzim_assistant.templates.preview_sections    { "body_markdown": "## S\n- [Slot] (x)\n" }
```

Raw-return envelope (`res.message`), matching `api.py`'s deliberate style for the AI family.
List rows carry `can_edit` so the client can grey out the buttons without re-deriving the rule —
the server stays authoritative.

### The rule the tests are mostly about

**A system template is editable and deletable by NOBODY through this API — including an admin.**
Shipping a curated set only works if a clinician cannot quietly rewrite it; *"duplicate it first"*
is the product behaviour, not a limitation. `frappe.has_permission` cannot express "nobody", so it
is enforced in the API **and backstopped in the controller's `on_trash`** — a Desk delete or a patch
never passes through the API. Both paths are tested.

Two consequences that had to hold with it:

- **`is_system` cannot be set through `create_template`.** Otherwise a client could mint a row
  nobody, including its author, may ever edit or delete.
- **Duplicating actually works.** The refusal message promises an escape hatch; if that broke, the
  refusal would be a dead end. Tested end-to-end — the copy carries the structure, is editable, and
  records `duplicate_from` as provenance.

### ⚠️ The permissions hole this closed

The first DocPerm attempt gave `EB_Practitioner` two rules — one with `if_owner`, one without, to
expose the shipped system set. Frappe **merges** them, and the rule without `if_owner` grants read
on **every row**: one practitioner could read another's private template, with nothing visibly
broken.

Frappe's role rules cannot express *"own OR is_system"*. So the roles grant the wider right and two
hooks narrow it — the only direction that works, because **a `has_permission` hook can deny but
never grant** (see the comment above `permission_query_conditions` in `hooks.py`):

| Hook | Covers |
|---|---|
| `template_query_conditions` | list / report queries |
| `has_permission` | a direct `frappe.get_doc` on a known name |

**Both are required.** One without the other leaves the row reachable by the other route, and there
is a test asserting each closes its own path.

### Smaller decisions

- **`version` bumps only when `body_markdown` changes.** A thread records which version it was
  filled from; a version that moves on a rename makes that record meaningless. Tested against
  rename and `is_default`.
- **`preview_sections` parses without saving.** The Structure tab needs the heading/slot breakdown
  as the clinician types, and saving per keystroke would version-bump dozens of times per edit.
- **Legacy `{{placeholder}}` counts as a slot** alongside `[slot]`, so an older seeded template is
  not reported as empty in the picker. `[]` is deliberately not a slot.
- **100 KB body cap** — this text is pasted verbatim into a prompt on every fill (Rule 5).

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_templates.py` — **20 cases**. 55/55 across all
four shipped items.

---

## 3.10 `answer_with_context` — ✅ DONE 2026-09-17 (Narzim GPT is now patient-aware)

Item 3 of 7, and the one ADR-075 was written for. A turn with a linked patient is now answered
**from the chart, read-only, through the same bounded tool loop the encounter copilot uses**.

### Not a new agent

It reuses `llm.ask_copilot_agent` — the audited loop from ADR-030 — with a different system prompt
and a read-only tool set. Reimplementing the loop would mean a second place where the iteration cap,
the tool dispatch and the usage accounting could drift, and only one of them would be tested.

That required a **backward-compatible change to the shared loop**: `ask_copilot_agent` /
`_stream` now accept `system_prompt`, `context_block` and `history_labels`, all defaulting to
`None`, which reproduces the copilot's behaviour byte for byte. Existing callers pass none of them.
Done in **both** providers.

### Four things make it safe

| | |
|---|---|
| **Read-only, always** | `allow_write=False` is a **literal** at the call site, not a permission lookup — there is no permission that should ever let this surface write a chart |
| **Authorised twice** | `parse_turn_inputs` checked the ids before persisting; `answer_with_context` re-checks before anything reaches a provider. The two are separated by a persist and a commit |
| **Patient-scope tools** | the 3 encounter-bound reads are **withheld**, not offered-and-failing, so the model never burns an iteration on a tool that cannot work |
| **Bounded context (Rule 5)** | the chart is **not** dumped into the prompt. The context block carries the patient **id**, sex and age — under 400 chars, asserted by test. Everything clinical arrives as an audited tool result the UI can cite |

### The narrowed PHI guard

`assert_no_other_patient_identifier(text, linked_patient)` sits alongside the original, which is
untouched and still used when nothing is linked (byte-for-byte previous behaviour).

- The **linked** patient's id/name in the message is allowed.
- **Any other** patient's is still refused — before transmission, and the refusal never echoes what
  matched (Rule 10).
- An **encounter or appointment id resolves to its patient**, so a visit id is treated as a patient
  identifier by proxy rather than an opaque string.
- ⚠️ An id that resolves to **nobody** is **refused, not ignored**. It cannot be attributed to the
  linked patient, so it cannot be cleared as the linked patient either — failing open there would
  make the guard bypassable by typing an id that does not exist yet.

**Refusal copy rewritten (PHI-5).** The old text promised *"Narzim GPT has no access to patient
records"*, which is now false. It points the clinician at the **+ link** button instead.

### Prompts — a separate lineage

`narzim-assistant-context-v1.txt` (and `-v2` when markdown is on). **Not** `v4`: that number went to
the markdown prompt first. v1–v4 are versions of the *no-data-access* prompt and both lineages stay
in use — context-free turns are still most turns. ADR-075 §6 carries the correction.

The context prompt drops v3's *"you have no access to any database, tool, patient record"* opening —
false the moment a chart is linked, and it would have the model refuse its own tools — and adds a
**Linked patient** section: read-only, call a tool rather than guessing, **an empty result means NOT
DOCUMENTED and not "none"**, only the linked patient is in scope. Every clinical guardrail from v3 is
kept, asserted by test.

### Streaming

A linked-patient turn is answered on the **non-streaming** path and delivered as one delta, joining
the two cases already handled that way (vision, and a provider with no stream adapter). The tool
loop is a multi-round-trip agent, not a token stream, so there is nothing to stream until it
finishes — and streaming a context-*free* reply instead would be the worst option, because a
clinician who linked a chart and silently got a generic answer could not tell the difference.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_context_answer.py` — **21 cases**. 73/73 across
all five shipped items.

---

## 3.25 `get_suggestions` — ✅ BUILT 2026-09-18 (the last item from PR #493)

**WHAT.** The starter cards on an empty chat. `{"suggestions": [{"title", "prompt"}, ...]}`.

**WHY IT IS A BACKEND METHOD AT ALL — the question worth answering before building it.** A list of
fixed strings belongs in the client, and moving fixed strings to a server buys nothing but a round
trip and a failure mode. This was marked "may stay rule-based" for exactly that reason. It is worth
building because it does three things a browser cannot:

| | |
|---|---|
| **Role** | Server-side truth. A front-desk clerk is not offered a prescribing question, and the browser should not be the thing deciding which set it may see |
| **Language** | §13 rule 10 forbids hardcoded user-visible strings in a bilingual product. These go through `_()` and the app's own `locale/es.po` |
| **This clinic's formulary** | A card naming a medication the clinic actually stocks is a question worth clicking; a generic one is filler |

**Deterministic — no model call.** An LLM on every empty chat would be the most frequent AI call in
the product and the least valuable (Rule 9, and cost).

### The bug that live verification caught, and code review would not have

The first version ordered the formulary by `modified desc` and took the first row. Called against
the real site, it returned:

```
[Pediatric dosing] What is the weight-based pediatric dose of C?
```

This site's `Medication` table contains a row whose `generic_name` is literally **`C`** (alongside
`Test`, `Test Medication`, `Dolo`). That question would have been on a clinician's **very first
screen**. Two defects, both real:

1. **No plausibility filter.** Now: letters, spaces and hyphens only, minimum 5 characters — a shape
   check, not a judgement about medicine, because there is no general way to tell a real drug from a
   test row and pretending otherwise would be worse.
2. **`order_by modified` is arbitrary.** It picks whichever row somebody last touched, so the card
   changed for no reason a clinician could perceive, and on a site whose newest edit is a test row it
   picks the test row. Now ordered by name, scanning up to 20 candidates for the first plausible one.

Live output now: *"What is the weight-based pediatric dose of Paracetamol?"*

### Two fields per card, deliberately

`title` for the card face, `prompt` for what is sent. PR #493's exact TypeScript type could not be
read from this repo, and a client that needs one field can ignore the other, whereas a client that
needs two cannot invent the first.

### What it deliberately does NOT do

**No suggestion is derived from patient data or from the user's own thread history.** Narzim threads
may now hold patient-linked answers (ADR-075), so history-derived cards would surface patient-specific
text on a **fresh chat screen** — a screen with no patient context, often open in a shared consulting
room and frequently the one on display when somebody walks in. Asserted by a test that fails if
`Patient`, `Patient Encounter` or the message table is ever read while building them.

**Every card is in scope for ADR-050.** A suggestion the domain gate would then refuse is worse than
no suggestion: the first thing a new user clicks would be declined by the product that offered it.

Tests: `tests/ai/test_narzim_suggestions.py` — **22 cases**, including six regression tests named
after the `C` defect.

---

## 3.24 `AI Source Cache` — ✅ BUILT 2026-09-18 (ADR-079)

**WHAT.** The last doctype from PR #493. Stores what was fetched from outside — a pasted page, a
PubMed response — keyed by (kind, what was requested, **which user** requested it), with a 30-day
retention in both markets.

**WHY IT IS STORED AND NOT JUST HELD IN MEMORY.** The speed case alone did not justify it. An
in-process cache would have fixed the repeated downloads (5 URLs a turn, each re-fetched on every
follow-up; two PubMed calls a turn against a ~3/sec shared rate limit) and created **no obligations
at all**. It is persisted for the other reason:

> A source changes. A guideline is revised, a page is taken down, a server is briefly unreachable.
> Without a stored copy, reopening a conversation re-fetches, and the answer the clinician read
> yesterday can no longer be traced to the words that produced it.

`AI Source Reference` already keeps a short **snippet** on the message forever, so the smallest proof
never expires. This keeps the full text the model was given, for as long as the profile permits.

### The retention number IS the switch

`source_cache_retention_days = 0` → nothing is stored. A market enables caching only by naming a
period it is willing to be held to. **There is deliberately no second boolean**, because two facts
that can disagree is the defect this area keeps producing.

| | |
|---|---|
| mx / india | **30 days** |
| Purge | `purge_expired`, daily, in `hooks.py` — **shipped in the same change** (PHI-3) |
| Expiry on read | `get()` filters `expires_at > now` — the job is a cleaner, not the enforcement |
| Erasure handle | `purge_for_patient()` — see the ⚠️ below |
| `track_changes` | **0**, a deliberate §7 exception — see below |

### Four things that could have gone wrong and are tested

1. **A cache hit must never skip a gate.** The compliance check and the pasted-address identifier
   screen run *before* the cache is consulted. Otherwise fetching a bad URL once would make it
   permanently allowed for as long as the row lived.
2. **One clinician's fetch is never served to another.** The key includes the session user: a page
   reachable with one person's access is not necessarily one the next person may see.
3. **A rate-limit page is never cached** — only a response that parsed. Caching one would turn a
   throttled minute into days of "no literature".
4. **Expiry is enforced on read**, so a declared 30 days does not quietly mean "up to 31".

### `track_changes: 0` — an exception to §7, and why

§7 requires `track_changes: 1` on every custom doctype. This one is 0. Frappe's version history would
keep a copy of `text_content` in the `Version` doctype — **including content this doctype exists to
delete on schedule**. Versioning a cache would defeat the retention promise it was built to keep,
which is worse than the audit value §7 protects. The rows are derived data; the original is the
website.

### ⚠️ PHI-4 is satisfied in form, not yet in practice

`purge_for_patient()` exists and is tested. **Nothing calls it, because no patient-erasure path
exists anywhere in this app** — verified 2026-09-18, while both profiles declare
`right_to_erasure=True`. PHI-4 permits shipping a duplicated store only when the change "records
explicitly that it did not and why"; this is that record, and the gap is now in
[`docs/KNOWN_ISSUES.md`](../KNOWN_ISSUES.md).

### A hazard worth remembering: a stored cache made the tests lie

One test fetched `https://g/f`; the next reused the URL, got a **cache hit**, and never called its
own mock — so a test asserting *"a page that cannot be fetched raises"* passed **without ever
attempting a fetch**. Both suites now set `source_cache_retention_days=0` in their profile helper, so
a test that wants the cache says so. This is a general hazard of persistent caches in test suites.

Tests: `tests/ai/test_source_cache.py` — **18 cases**, 0 skipped (the PHI-4 ones run against a real
`Patient` row). Verified load-bearing: crippling the cache read makes the "does not refetch" case
fail. **155/155 across the retrieval suites; zero regressions app-wide**, confirmed by an id-level
diff against a baseline captured on the same migrated site.

---

## 3.23 Clinical Web unblocked — ✅ 2026-09-18 (ADR-077)

**WHAT.** Both outbound capabilities are now permitted: `retrieval_providers=("ncbi",)` and
`url_fetch_allowed=True`, in **both** shipped markets. Literature search and pasted links work.

**WHY it took an ADR rather than a one-line edit.** PHI-1 makes the compliance profile *the* record
of who receives data on a patient's behalf, and a flip of that record with no written decision
behind it is exactly the state CLAUDE.md calls *"worse than none, because it will be relied on"*.
The artefact ADR-075 demanded did not exist — and had been misidentified as ADR-076 for days. It is
now [ADR-077](../adr/adr-077-clinical-web-outbound-retrieval.md), which records what leaves, what
does not, the four options weighed, and what would falsify the choice.

### The guard that only became necessary when the switch flipped

**WHAT.** `clinical_web_query.is_url_safe_to_send()` — new. A pasted address is screened for a
patient name, an email and a record number **before this server opens it**, and `fetch_pages`
refuses rather than fetching.

**WHY it did not exist before.** While `url_fetch_allowed=False`, the address never travelled, so
there was nothing to screen. Enabling the feature is what created the exposure, so the guard landed
in the same change rather than as a follow-up.

**USER STORY.** Dr. Bracamontes has a patient's record open in the hospital's old portal, copies the
address bar into Narzim to ask about it → the URL is
`https://portal.example/report?patient=Maria+Gonzalez&mrn=12345` → **without the guard**, our server
sends that entire string to `portal.example` as the request target, and the patient's name and MRN
land in a third party's access logs **before a single byte of page comes back** → **with it**, the
turn is refused with *"That link cannot be opened because the address itself contains patient
information. Nothing was sent."*

### Why it could not reuse `is_safe_to_send`

```
is_safe_to_send("https://pubmed.ncbi.nlm.nih.gov/12345678/")      -> False   ← refuses the article
is_url_safe_to_send("https://pubmed.ncbi.nlm.nih.gov/12345678/")  -> True
```

The query gate refuses any run over three digits, because in a search string that is a phone or a
record number. In a URL it is usually an article id, and refusing it would break the commonest paste
this feature exists to serve. So **the digit rule applies to the query string and fragment only** —
where a record identifier travels — and never to the host or path. Names and emails are screened
across the whole address.

⚠️ **The narrowing is real and is asserted as a test, not hidden:** `/records/00123456` in a *path*
is indistinguishable from an article id by shape and **passes**. `test_url_identifier_screen.py`
asserts that deliberately, so nobody "fixes" it and breaks every PubMed link.

### The bug the awkward test case caught, before it shipped

The first version screened the raw URL. `Ram%C3%ADrez` tokenises to `ram` / `c3` / `adrez` and
matches no patient — so **every accented name would have passed**, in a product whose primary market
is Mexico. A name in a real URL is always percent-encoded, so this was not an edge case; it was the
normal case. The address is now decoded first, up to three rounds (once is not enough: `%2543` →
`%43` → `C`). Found by the test, not by review — which is the argument for writing the ugly case.

### What the flip did NOT change

- **The gates are untouched.** They still raise, and still refuse anything the register does not
  name — `assert_retrieval_provider_allowed("openevidence")` fails with `ncbi` approved, asserted.
- **`source_cache_retention_days` stays 0.** Nothing caches a fetched page, so there is no period to
  declare; a number with no purge job would be a false promise (PHI-3).
- **The DNS-rebinding residual risk in `safe_fetch.py` is unchanged — and is now live.** Narrowed,
  never solved; it is why the two capabilities remain separate switches, and why disabling pasted
  links alone is a one-line revert per market.

**Still open and NOT settled by an engineer:** whether NCBI needs the data-processing-terms check
ADR-026 requires of an LLM vendor. No personal data is sent, which argues no; PHI-1 names the
register rather than the payload, which argues yes. Flagged for the compliance owner in ADR-077.

Tests: `test_url_identifier_screen.py` (**15**, incl. the wiring check that `fetch_pages` refuses
before calling `fetch`). Two pre-existing tests that pinned the shipped-off values were updated to
pin the shipped-on ones. **119/119 across the clinical-web and Narzim retrieval suites.**

---

## 3.22 The streaming path had no sources — ✅ FIXED 2026-09-18

**WHAT.** There are two ways to ask Narzim a question, and they are two functions:
`send_message` (the whole reply at once) and `send_message_stream` (word by word, SSE).
Retrieval was added to the first one only. A streamed reply therefore answered **without the
files the clinician pinned**, cited nothing, and said nothing was wrong.

**WHY it happened, which is the part worth keeping.** The two functions assembled the prompt
from **two identical copies** of the same sequence — catalogue, template directive, uploaded
document. Adding retrieval meant editing one copy. ADR-075 had predicted this in writing before
any of it was built:

> `send_message_stream` shares the contract and **must receive the same changes**, or the
> streaming and non-streaming paths diverge.

It diverged anyway, because a warning in a document cannot fail a build. **The duplication was
the defect**, so the fix deletes it rather than adding a fourth copy.

**USER STORY.** Dr. Bracamontes attaches his clinic's asthma protocol and asks about a step-2
dose → **the system shows** a normal answer, typed out, **with no source underneath** → **the
database actually contains** an assistant row with zero `AI Source Reference` children and
`sources_used` empty → **consequence:** he believes the answer came from his clinic's protocol
when it came from the model's general knowledge. No error, nothing to notice.

**WHEN it would have bitten.** Not yet: PR #493's composer calls the blocking `send_message`
(§0 — *"exists, PR ignores it"*). It would have bitten silently the day the composer switched to
streaming, which is a frontend change nobody would think to test for citations.

### What changed

| | |
|---|---|
| `_build_llm_message()` | **New. One implementation**, called by both paths — catalogue, template directive, document, retrieval, in that order |
| `send_message` | Calls it. Behaviour unchanged (verified: same prompt as before) |
| `send_message_stream` | Calls it. **Gains retrieval**, citations and `sources_used` |
| `_persist_stream_reply()` | Takes `references` / `sources_used` and writes them — **including on a partial row** |
| the `done` SSE event | Gains `sources_used`; its existing `references` key now carries real rows |

### Three ordering decisions, each with a reason

1. **Retrieval runs after the scope gate.** An off-topic question must not trigger a Drive read —
   or, once a provider is named, an **outbound literature search** — before being refused.
   Retrieving first would have sent a question to NCBI that the system was about to decline to
   answer at all.
2. **And before the first yield.** Once a byte of the answer has been sent, the HTTP status is
   long gone and a refusal can only be delivered as an error frame mid-stream (adr-048). A pinned
   file that cannot be read must still be a real status code.
3. **Sources are written to a stopped/partial row too.** The text the user already read WAS
   produced from them. The same reasoning already applied to `template_used`.

### What was deliberately NOT changed

`apply_template_turn` still returns `"sources_used": []`, and that is **accurate rather than
lazy**: its endpoint (`templates.py::apply_template`) accepts `context` and `sources` but not
`urls` or `library_doc_ids`, so no file can reach it — and there is no question to retrieve
against, since the input is a stored outline rather than something the clinician typed. Wiring
retrieval there would mean inventing a query. It is recorded here so the next reader does not
have to re-derive it. **`sources` is still accepted-and-recorded-but-unused there**, unchanged.

### The test is verified to fail

`tests/ai/test_narzim_stream_parity.py` — **9 cases**. The first compares the prompt both paths
build from identical inputs. A regression test that would pass either way is worse than none, so
the drift was **deliberately reintroduced** and the suite re-run: **5 of the 9 failed**, then
passed again once reverted.

**349 tests run across the Narzim suite: 342 pass, 2 skipped, 7 pre-existing errors** in
`test_formulary_context` (4) and `test_narzim_assistant` (3, OCR-dependent). Those 7 were
**confirmed identical against the pre-change file** — not introduced here, and outside the module
set the earlier "270/270" figure covered.

---

## 3.21 PubMed and pasted-URL fetch — ✅ BUILT 2026-09-18, ✅ **ENABLED the same day (ADR-077)**

Item 4's last code. **Built refusing, then enabled** once the missing ADR was written — the unblock
and what it required are §3.23. Register state on this site now:

```
active profile  : mx
retrieval hosts : ('ncbi',)
url fetch       : True
cache retention : 0 days
```

**A correction worth keeping.** While this was refusing, the blocker was described — here, in the
CHANGELOG and in conversation — as *"waiting on ADR-076"*. That was wrong. ADR-076 restructures
jurisdiction profiles into a central table and has nothing to do with outbound retrieval; the
artefact ADR-075 actually demanded **did not exist at all**. It is now
[ADR-077](../adr/adr-077-clinical-web-outbound-retrieval.md). ADR-076 is still Proposed and is
unaffected either way.

### Two capabilities, separate all the way down

| | What leaves | Gate |
|---|---|---|
| `clinical_web` | the MODEL's question, to a known named host (NCBI) | `retrieval_providers` |
| `urls` | nothing — but OUR SERVER opens the clinician's address | `url_fetch_allowed` |

They are never merged, because they are separate decisions with separate approvers: one is a named
subprocessor, the other is "any website on the internet". A deployment may reasonably permit the
first and refuse the second, and that is the likely shape.

### `services/safe_fetch.py` — the SSRF work `_validate_url` said someone must do

Its docstring has said since the composer extras that it is "not sufficient alone" and that the
fetcher "MUST re-check the resolved IP at connection time". That is now implemented:

1. **Resolves and refuses unless EVERY address is public.** Not the first — a name with one public
   and one private A record would otherwise pass while connecting to the private one.
2. **Re-checks on EVERY redirect.** A public URL that 302s to `169.254.169.254` is the standard
   bypass, so redirects are followed one hop at a time rather than by `requests`.
3. **Caps the body during the read** — `Content-Length` is the server's claim, and a chunked response
   has none.
4. **Separate connect and read timeouts** — a host that accepts and then stalls is the case one
   timeout handles worst.
5. **Document content types only.**

⚠️ **Residual risk, stated rather than hidden:** validating the resolved addresses and then letting
`requests` resolve again leaves a DNS-rebinding window. Closing it means pinning the socket to the
validated address while keeping TLS hostname verification, which `requests` does not expose cleanly.
Every address must be public and the attacker must win the race — **narrowed, not solved.** It is one
reason `url_fetch_allowed` is a separate switch that ships off.

### Three gates before a search leaves

`assert_retrieval_provider_allowed("ncbi")` → `build_query` → `is_safe_to_send`, in that order. The
third is a re-check by the code that builds the URL: a guarantee enforced only where it is created
stops being one the moment somebody adds a second creator. An empty query after gate 2 means **do not
search**, never "search for everything".

### Smaller decisions

- **One shared citation numbering** across library, literature and pages — the `[n]` markers are one
  sequence in one reply, and a per-source list would put two different documents behind `[1]`.
  Renumbering runs right-to-left so a rewrite cannot collide with a number it is about to produce.
- **A citation records where the chain ENDED**, not what was pasted. Naming the typed URL when the
  content came from three redirects away cites the wrong thing.
- **No snippet is invented from a PubMed title.** `esummary` returns metadata, not abstract text; a
  snippet made from the title would be a quotation that was never quoted.
- **An unreadable NCBI response raises** rather than being reported as "no results" — a rate-limit
  page read as "the literature says nothing" is a clinical claim made by an HTTP error.
- **A page that cannot be fetched raises.** A link the clinician pasted and did not get is something
  they need told.
- **Markup is stripped with our own crude stripper**, not `html2text`. That package is on the bench
  only as a Drive dependency, and depending on another app's transitive package is how a future
  `bench update` breaks this quietly.

Tests: `test_safe_fetch.py` (**12**) · `test_pubmed.py` (**11**) · `test_narzim_web_context.py`
(**12**). **270/270 across the Narzim suite.**

---

## 3.20 Library retrieval — ✅ THE FIRST WORKING CITATION 2026-09-18 (Clinical Web, step 5)

Pin one of your own files to a turn; its text goes into the prompt and a `[1]` comes back pointing at
it. **The first retrieval in this codebase**, and deliberately the one needing no sign-off: a My
Library file is already inside this system, so nothing reaches a third party.

Verified end to end against a real Drive file:

```
reply        : "Step 2 adds an inhaled corticosteroid [1]."
sources_used : ['library']
references   : [{"index": 1, "kind": "library", "title": "...",
                 "snippet": "...", "library_doc": "j4bijms9lq"}]
prompt had the document? True
after reload : identical
```

`citation-list.tsx` has had nothing to draw since the PR was written. It does now.

### What it reuses rather than rebuilds

`services/drive_summary.py::pages_for()` already extracts per-page text and caches it, and carries
two properties this would otherwise have reinvented badly:

- **Permission first, cache second.** The cache is keyed by document, not by viewer — returning it
  before checking would hand one user's document text to anyone who knew the id. That module found
  exactly that leak in production.
- **Redaction before anything is cached or sent**, with the same `pii_redaction.redact_text` the
  assistant applies to its own uploads. A pinned library file therefore gets the *same* treatment as
  a file dragged into the chat, not a quieter one.

`_relevant_pages` is reused for the same reason, including its rule that **a document which fits is
never subsetted** — retrieval exists to stay inside the budget, and running it on a short file only
risks dropping the page that held the answer.

### Decisions

- **An unreadable pinned file RAISES; it is never skipped.** A clinician who pinned three files and
  got an answer from two has no way to tell, and would reasonably believe all three were used. That
  is the exact failure this whole citation feature exists to prevent, so it is not softened here.
- **A file with no extractable text is still cited** — an image, or a scan OCR could not read. The
  clinician pinned it; a citation list that silently omits it misrepresents what was considered.
- **The budget is split across pinned files** (Rule 5), not spent by the first. Five files each
  contributing a little beats one contributing everything and four contributing nothing — the
  clinician pinned all five.
- **The snippet is stored, not refetched**, so a reload shows the words the model was actually given
  (§3.18).
- **`sources_used` reports `library` only when a file was actually read.** A source that returns
  nothing is omitted, never listed with zero citations.
- **The block instructs the model to cite `[n]` and to say so when the documents do not answer** —
  never to fill a gap from memory and cite a document for it. The row exists either way, so the worst
  case is a citation list the reply did not reference, never a reference to something unread.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_library_context.py` — **10 cases**.
**235/235 across the Narzim suite.**

---

## 3.19 `list_sources()` — ✅ DONE 2026-09-18 (Clinical Web, step 4)

Payload #16. The Sources bar draws one toggle per entry and greys out the disabled ones, so this is
the single place deciding what a clinician may even attempt.

### `enabled` is computed, never hardcoded

Each entry reports the truth about **this** site:

| Source | On when |
|---|---|
| `clinical_web` | the active `ComplianceProfile` names a retrieval provider (**PHI-1**) |
| `library` | Frappe Drive is **installed** *and* has a configured clinic team |

Live on the dev site right now:

```
clinical_web   enabled=False   "No literature provider has been approved for this clinic yet."
library        enabled=True    "Your files and URLs"
```

A toggle that is offered and then fails is worse than one that is visibly unavailable — which is not
hypothetical: both library failure modes were live on this bench in the same week (Drive absent
entirely, then Drive present with no clinic team). They are reported **differently** because the
fixes differ: one is a deployment decision, the other a setup step.

### Two additions to the spec's payload

- **`reason`** — additive, not in the PR's example. A greyed toggle with no explanation sends the
  clinician to support. A client that predates the field ignores it.
- **URL fetching is deliberately NOT a third entry.** It is gated separately
  (`ComplianceProfile.url_fetch_allowed`) and has no fetcher yet, so listing it would advertise
  something that cannot run.

### Rule 7

A broken compliance profile does not take the Sources bar down — `clinical_web` reports unavailable,
which is also the safe answer, and `library` is unaffected. Asserted by test.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_sources.py` — **9 cases**, including both
library failure modes and the "Drive not installed at all" state that let §3.17's bug survive.
**225/225 across the Narzim suite.**

---

## 3.18 `references[]` — ✅ THE CITATION DOCTYPE IS BUILT 2026-09-18 (Clinical Web, step 3)

`AI Source Reference`, a child table on `AI Narzim Assistant Message`, serialised out as
`references[]` on **three** responses: `send_message`, `send_message_stream`'s `done` event, and
`get_thread`.

### The rule it exists to make enforceable

**A citation may only be created from something that was actually retrieved.** Rows are written at
fetch time by the code that fetched; the model is never asked to produce one. The only way it could
is by inventing it, and a fabricated reference in a clinical tool is worse than none — it *looks*
verified. That is why the array is built from stored rows and never parsed out of the reply text.

### Why build it before anything retrieves

Every source kind needs it — a library file, a PubMed record, a pasted page — so whichever lands
first plugs into machinery that is already built and tested. Until then `references` is simply always
`[]`, exactly as `sources_used` has been since §3.8: **a change of inputs later, not a change of
shape.**

### Matched to PR #493's type, field by field

`src/components/narzim/narzim-ai/types.ts` — `index`, `kind`, `title`, `url`, `snippet`, `publisher`,
`published_date`, `authors`, `pmid`, `doi`, `library_doc`. Two decisions inside that:

| | |
|---|---|
| `idx_number` | `idx` is a **reserved child-table column** in Frappe, so the field cannot be named what the client names it. Serialised back out as `index` |
| `library_doc` | **`Data`, not a Link to `Drive File`.** Frappe Drive is a third-party app that may not be installed, and a Link would make this doctype unloadable on a site without it — the exact class of breakage that made the library pin fail (§3.17) |

**Empty optional fields are OMITTED, not sent as null.** The frontend type marks them optional, and a
present-but-null field makes a client check two things where one would do. `index` and `title` are
always present: `citation-list.tsx` renders `title` *as* the citation, and reads only five fields in
total (`index`, `title`, `url`, `publisher`, `snippet`).

### What cannot be stored

- **No title** → refused. The row would render as a numbered blank, which reads as a source the
  reader cannot check.
- **Index below 1** → refused. The model writes `[1]` first; a `0` would never match a marker.
- **`kind: "library"` with no `library_doc`** → refused. Without it the citation cannot link back to
  the clinician's own file, which is the only thing that makes a library citation useful. This is
  spec correction **#9** — present in the frontend type, missing from the handoff's example.

### Smaller decisions

- **Always an array, never absent**, on all three responses. The client renders on
  `references?.length`, so "no citations" and "this reply predates citations" must look identical.
- **Ordered by index on the way out**, so the list matches the `[n]` markers even if rows were stored
  out of order.
- **The snippet is stored, not refetched.** A reload must show the words the model was actually
  given; refetching could return different text, and a citation whose snippet has drifted is worse
  than none.
- **One query for the whole thread.** `get_all` does not return child tables and a thread can hold
  2000 rows, so the citations are fetched in a single filtered read rather than one per message.
- **The streaming `done` event carries them too**, unlike `sources_used` — otherwise a streamed
  reply's citations would not appear until reload.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_references.py` — **12 cases**, covering the
contract rather than a feature, since nothing retrieves yet. **216/216 across the Narzim suite.**

---

## 3.17 The library pin was refused for every file — ✅ FIXED 2026-09-18

A bug I shipped in the composer-extras commit, found while trying to build library citations.

### What was wrong

`_validate_library_doc_ids` authorised a pinned file against the **`Clinical Document`** doctype.
That is the doctype Narzim Drive **migrated away from** — `services/drive.py` says so in its own
opening paragraph — and it does not exist on this deployment. So **every** pin was refused with
"Unknown library document", and the parameter, though accepted and stored, could never resolve.

### Why it survived review

**Frappe Drive was not installed on the dev bench at all**, so the code path could not be exercised
by anyone. The inventory even recorded the right answer — PART 4 correction #3 says My Library is
`api/v1/drive/api.py`, not `clinical_documents.api` — and the wrong doctype was used anyway.

### The fix

Authorised through `services/drive.py::get_entry`, **not** `require_permission`. My Library is
Frappe Drive, which has its own sharing model that Frappe's generic doctype permissions know nothing
about, and `services/drive.py` layers a narrower private-by-default rule on top. `get_entry` applies
both and raises `DoesNotExistError` rather than a 403 — for a file titled after a patient, "403
Forbidden" is itself a disclosure.

The import is lazy, so a deployment **without** Drive can still send ordinary messages; only pinning
needs Drive present, and it fails with "My Library is not available on this site."

Proven end to end against real Drive data, which was impossible before:

```
PIN A REAL FILE  ->  accepted: ['j4bijms9lq']
PIN A FAKE ID    ->  refused:  DoesNotExistError | "Document not found"
```

### ⚠️ The bench problem underneath it, which is the bigger finding

Installing Drive to test this took four attempts and produced corrections to
[`docs/api/DRIVE_FRONTEND_INTEGRATION.md`](../api/DRIVE_FRONTEND_INTEGRATION.md), which now carries
them in full. In short:

- **`bench get-app` installs `develop`**, which has **no `Drive File` doctype at all** — it
  restructured onto core `File`. `services/drive.py` cannot run on it. You need `--branch main`.
- **Both branches report `0.3.0`**, so the version string cannot distinguish them. `main` = `0bd11d8`.
- **`main` needs OpenCV**; `develop` does not.
- The Drive suite (`tests/security/test_drive_service.py`, 76 tests) **had never run on this bench**.
  It now does: 0 failures, 1 error inside Drive's own `get_home_folder`, 2 skipped.

Narzim suite unaffected: **204/204**.

---

## 3.16 The compliance register can now name a retrieval host — ✅ DONE 2026-09-18 (Clinical Web, step 2)

Item 4's second piece, and like the first it makes **no outbound call** — so it needed no sign-off.

### What was structurally impossible before this

`ComplianceProfile` had slots for the LLM vendor and the ASR vendor **and nothing else**. So PHI-1 —
*"an integration must refuse to run against a provider the active profile does not name"* — was not
merely unsatisfied for Clinical Web, it was **unsatisfiable**: there was nowhere to name PubMed even
if somebody approved it. The feature could not be built correctly, only incorrectly.

Three fields now exist, and **every default is the refusing value**:

```
retrieval_providers         = ()      nothing approved
url_fetch_allowed           = False   the server fetches no user-supplied address
source_cache_retention_days = 0       nothing is cached
```

Both markets state them explicitly rather than inheriting the defaults — this file is the register a
person reads to answer *"who receives data on a patient's behalf"*, and that answer should not
require knowing what a dataclass default is.

### Two gates, deliberately separate

`compliance.assert_retrieval_provider_allowed(vendor)` and `compliance.assert_url_fetch_allowed()`.

Searching a **known, named** host and fetching an **arbitrary user-supplied** one are different
exposures with different approvers, and a deployment may reasonably permit the first and refuse the
second. One flag could not express that.

Both **raise** rather than returning False: a caller that forgets to check a boolean sends the
request anyway; a caller that forgets to call these does not get past them.

They live in `compliance/__init__.py`, not in the integration, because
`services/registration_form_extraction.py` already hand-rolls the same comparison for
`llm_provider` — and a second hand-rolled copy is how the two eventually disagree.

### Why `url_fetch_allowed` ships False

Four reasons, in order of weight: **no fetcher exists**, so True would declare a permission for code
that is not there; CLAUDE.md §9 says feature flags ship OFF; the SSRF protection it depends on (the
connection-time address re-check) is **specified in `_validate_url`'s own docstring and not built**;
and "any website on the internet" admits no data-terms review, so nobody could have approved it.

### ⚠️ What this measurement exposed, which is larger than the feature

Counting readers of every `ComplianceProfile` field across the app (excluding `compliance/` and
tests):

| Field | Readers |
|---|---|
| `llm_provider` | 10 — **the only real enforcement in the register** |
| `primary_language` | 3 |
| `country_name` · `jurisdiction_code` · `audio_retention_days` | 1 each |
| `privacy_law` · `healthcare_standard` · `display_badge` · `regulator` · `audit_retention_years` · `right_to_erasure` · `breach_notification_hours` · `consent_required` · `consent_type` · `ai_scribe_enabled` · **`audio_provider`** | **0** |

**Eleven of nineteen fields are declared and consulted by nothing** — including `audio_provider`,
which names who receives patient *audio*. `right_to_erasure=True` is a statement that patients may
have their data deleted, and no code implements it (PHI-3; NH-191 is a live instance of the same
shape).

That finding, plus a requirement to expand countries without a release and to follow HIPAA **and**
local law, is why [ADR-076](../adr/adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md)
is proposed. It is **not accepted** — it supersedes ADR-018, whose author has to agree first.

Tests: `remedisys_healthcare_ai/tests/ai/test_clinical_web_compliance.py` — **11 cases**.
**204/204 across the whole Narzim suite.**

---

## 3.15 The outbound search gate — ✅ DONE 2026-09-18 (Clinical Web, step 1)

Item 4's first piece, and the only one that needed no sign-off: **nothing here makes an outbound
call.** It is the gate a fetcher will have to pass through, built first so the rule exists before
anything can break it.

`services/clinical_web_query.py` · `tests/ai/test_clinical_web_query.py` — **17 tests**.

### What cannot leave

Three things, and only these three — scope set deliberately with the user on 2026-09-18:

| | How it is caught |
|---|---|
| **A patient's name, and their record id** | Exact, from the `Patient` table — 85 name-words across 160 patients on the dev site. Token-level, so a lone surname is refused: a query is a bag of words and "Ramírez" alone is still Ramírez |
| **An email address** | By shape, not by lookup — a patient may write from an address we never stored, and it identifies them either way |
| **A contact number** | By length: **1–3 digits travel, 4+ do not** |

A colleague's name, a hospital, a place: these travel. That is the agreed scope, and it is narrower
than the first implementation — see below.

### The leak this closes

ADR-075 deliberately allows a clinician to name the **linked** patient in a message. Correct for
chat, which already has that chart open. Without this gate the permission granted for one
destination would silently extend to a third party:

```
typed  : "asthma dosing for María Ramírez, she's 4, penicillin allergy"
allowed: yes — María is the linked patient (ADR-075)
naive  : ...?term=asthma+dosing+María+Ramírez+4+penicillin   ← her name, in NCBI's logs
here   : ...?term=asthma+dosing+penicillin                    ← she never survived
```

The query rides inside a URL, so it reaches a third party's access logs **without passing through
anything that looks like an AI call** — no prompt log, no consent surface, nothing that would catch
it. That is why it needed its own control rather than relying on the existing guards.

⚠️ **This is not about OpenAI or Anthropic.** They hold a signed BAA and already receive chart data
on every linked-patient turn (§3.10). The risk is the party with **no** agreement — NCBI today, a
pasted site later.

### The first version was airtight and unusable — and measurement said so

It asked *"is this word medical?"*, allowing only words in the clinic's own catalogues
(`services/clinical_lexicon.py`). Measured live, that lexicon holds **95 tokens**, and a real
question collapsed to one word:

```
"asthma dosing for María Ramírez, MRN-2026-0001433, penicillin allergy"  ->  "dosing"
```

The name, record number and date were correctly gone — and so were **asthma** and **penicillin**,
because nobody had created them as catalogue rows. A literature search needs general medical
vocabulary a clinic's transactional masters will never hold, and a gate so tight that searches come
back empty protects nothing, because the feature gets switched off.

So the question was inverted. *"Is this word medical?"* needs a dictionary of all medicine, which
nobody has. *"Is this word one of our patients?"* is answerable **exactly**, from our own table — and
it is also the risk actually being protected: not vocabulary leaving, but a **person** leaving.

**This is a weaker promise than the first version, accepted deliberately.** Something personal that
is not one of our patients could travel. The trade was made with that stated.

### Why 1–3 digits

Clinical numbers are short — a dose, a weight, a frequency, an age — and a search is materially
better for having them. Identifiers are longer: a phone number, a record number, a year of birth.
The cut falls cleanly between the two. An earlier version dropped **every** digit; safe, but it threw
away the dosing detail a clinician actually wants searched.

Verified against a real record:

```
typed : asthma dosing for Divyanshu Chauhan, MRN-2026-0000049,
        mobile +52 8077329802, email dcrc807732@gmail.com
sent  : 'asthma dosing mobile 52'

typed : amoxicillin dosing 18 kg child 4 years old every 8 hours
sent  : 'amoxicillin dosing 18 child 4 every 8 hours'
```

### Smaller decisions

- **Checked again immediately before transmission** (`is_safe_to_send`), by the code that opens the
  connection. A guarantee enforced only where it is created stops being one the moment somebody adds
  a second creator.
- **The dropped words are never returned** — only a count. The dropped set is exactly where a patient
  name would be, so returning it would hand the caller the thing this withholds (Rule 10).
- **An empty query means DO NOT SEARCH**, never "search for everything".
- **Fails closed on a database error**: if the patient list cannot be read the gate cannot work, so it
  raises rather than searching unprotected.
- **Cache invalidated on Patient update** (`hooks.py`), because the newest patient is the one most
  likely to be asked about next.
- **Identifier-context words dropped** — `born`, `aged`, `phone`, `nacido`, `expediente`. Found by
  running against real data: `born 12/03/2021` left `born` in an otherwise clean query.

### Still to come in item 4

The `ComplianceProfile` fields (there is **no** field for a retrieval provider today, so PHI-1 cannot
be satisfied without a schema change), `AI Source Cache`, `AI Source Reference`, the PubMed client,
the SSRF-safe fetcher with a connection-time address re-check, and `references[]`. **All of those need
the ADR accepted first**; this step did not, because nothing leaves.

---

## 3.14 `suggest_templates` — ✅ DONE 2026-09-18 · **ITEM 5 COMPLETE**

Payload #23, and the last method in item 5. Answers two things in one call, because the UI element
is one control ("Suggest / offer to save"):

| | |
|---|---|
| `suggestions` | templates matching what is being discussed, ranked, each with the words that caused the match |
| `offer_to_save` | the assistant has produced something already shaped like a template and no existing template covers it |

### No model call, deliberately

Ranking a handful of the caller's own templates against a few sentences is string matching. Asking a
provider instead would send the conversation — which may be about a real patient — out of the process
purely to sort a list the clinician is about to look at anyway. Same minimum-necessary reasoning as
§3.13 (**PHI-6**), reaching the same answer more easily: nothing leaves, so there is nothing to
protect. It is also instant and free, which matters for something the chat panel may call every turn.

`context` is accepted and unused (`context_used: false`): which template fits *"write up this
vaccination visit"* does not depend on WHICH patient the visit was with.

### What it matches on, and what it does not

- **Only the clinician's own turns.** The assistant echoes the question back, so counting its replies
  would double the weight of whatever the model happened to repeat rather than of what was asked.
- **Title, description, category and section HEADINGS — never the body.** The headings say what a
  template is *for*; the body is mostly instructions to the fill model, and matching on it makes
  every template match every message. Asserted by test.
- **Accent-insensitive.** A clinician types `vacunacion` as often as `vacunación`, and on a bilingual
  product a template written with one must match a message written with the other. That is the common
  case here, not an edge case.
- **Words of 4+ characters, minus a short bilingual stopword list.** Deliberately short: a longer list
  starts removing real clinical signal, and below 4 characters the noise is mostly `de/la/of/to`.
- **Last 6 turns.** The question is what is being discussed *now*; a suggestion list reflecting the
  start of a long thread is worse than none.

### Two queries, not one per template

The obvious `get_list` + `get_doc`-in-a-loop is invisible with six templates on a dev site and a real
cost for a clinic with two hundred, on an endpoint the panel may call on every turn. Section headings
are fetched in a single child-table read filtered to the already-permission-scoped names, so it
inherits that scoping rather than needing its own.

### Writes nothing

`save_candidate` is returned for the client to prefill a "save as template" dialog; the clinician
still creates it themselves (Rule 6). `offer_to_save` is false when a template already fits — offering
to save something the clinician already has is noise — but the candidate is still returned so the
client may offer it anyway.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_template_suggest.py` — **15 cases**.
**176/176 across the whole Narzim suite.**

---

## 3.13 `generate_template` — ✅ PART B2b DONE 2026-09-18 (approach D)

Payload #22, "build a template from past visits". The only piece of the Narzim build that reads
several patients' real records, and the reason part B was split twice.

### The safety property

> **Nothing derived from a patient's record reaches the model.**

Not "is redacted before it reaches the model" — never reaches it. The prompt is assembled
exclusively from `_VOCABULARY` in `services/narzim_template_generate.py`, a fixed list of English
section names written in that file by a person. Reading the visits yields a set of vocabulary KEYS
and integer counts and nothing else, so a chart value has no path into a prompt. An unrecognised JSON
key is **counted but never named**, which is what makes the property hold even against a future or
hand-edited key whose *name* carried content.

`tests/ai/test_narzim_template_generate.py::test_no_chart_value_can_reach_the_prompt` plants real
values (a name, an MRN, a drug, a staff email) in the shape a chart holds them and asserts none
reaches the captured prompt. The promise is only worth that assertion.

### Why D, of four options

The output is a **blank form** — headings and empty slots — so the clinical content is not needed to
produce one. Sending it anyway shares more than the task requires, which **PHI-6** forbids
("the narrowest patient context that answers the question"). A signed BAA permits sending PHI to a
subprocessor; it does not waive minimum-necessary, which is part of HIPAA itself.

Two measurements decided it rather than taste, both on the dev site:

| Measured | Result |
|---|---|
| Notes stored as structured JSON | **84 of 84 populated encounters. Zero free prose** (150 total, 66 blank) |
| Keys actually present | `chief_complaint` 84 · `bill_flags` 84 · `vaccines` 44 · `education` 41 · `plan` 10 |

The rejected option's one genuine advantage was the model seeing the clinician's own phrasing. With
zero prose notes that advantage barely exists here, while `services/pii_redaction.py::redact_text` —
which that option rested on — states in its own docstring that it cannot catch a name in prose with
no adjacent label.

⚠️ **This reasoning is measurement-dependent.** A deployment whose clinicians write real prose notes
should revisit it; the 84/84 figure is what it turns on.

*(An earlier draft of this argument also claimed sending notes would be a disclosure to a new outside
party. That was wrong and was withdrawn: `compliance/profiles/mx.py` names `llm_provider="openai"`,
and `answer_with_context` already sends chart data there. The case rests on minimum-necessary, not on
novelty of the recipient.)*

### Two stages

```
stage 1  visits -> which sections, how often     deterministic, in-process
stage 2  section names -> headings + slot wording   the model, no chart input
```

Stage 2 never sees stage 1's input. Sections come back in **clinical reading order, not frequency
order** — a note opening with the plan because the plan was commonest would be a worse form.

### Rule 7, and what "worded_by_model" is for

A provider failure returns stage 1's skeleton on its own: a real, usable template with plainer
wording, never an error. The same fallback catches a reply that is *not a template* — a refusal or an
apology must not be handed to a clinician as their new form, so a reply with no heading in it is
discarded. `worded_by_model` is derived from the same condition that chose the body, so the flag
cannot disagree with what was returned, and the UI can say "wording is basic because the assistant
was unavailable" instead of silently offering something worse.

Verified against real data with the provider forced to fail (4 visits on the dev site):

```
sections found: Reason for visit (4), Medications (1), Immunisations (4), Patient education (4)
worded_by_model: False | cost: 0.0 | id: None
```

### Smaller decisions

- **Returns an UNSAVED template** (`id: null`). The clinician saves it through `create_template`, so
  an unwanted suggestion costs nothing to discard and nothing is written on their behalf (Rule 6).
- **`sections_used` is returned with counts**, so the UI can show *why* a heading is there — the
  honest way to present a generated artefact is to let the clinician check the reasoning.
- **Every visit id is permission-checked** before its shape is read. Being able to NAME a visit must
  not be enough to learn anything about it.
- **Capped at 5 visits.** Each adds only integers to the prompt, but an uncapped list is an unbounded
  permission-check loop for no extra signal.
- **Prose notes contribute nothing rather than falling back to reading the text.** Tested.
- **`bill_flags` is deliberately outside the vocabulary** — billing state is not something a clinician
  writes in a note.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_template_generate.py` — **16 cases**.
**161/161 across the whole Narzim suite.**

---

## 3.12 The template editor session — ✅ PART B2a DONE 2026-09-18

Payloads #24, #25 and #27. Three calls around one row: open a session, change the outline in it,
save it back to a template.

### Why the session is a doctype, not Redis

The frontend contract settles it: Save sends `{session_id, name}` and **no markdown** (#27), so the
working outline has to live server-side between calls. Given that, a row beats the cache for a
reason specific to this bench — `bench clear-cache` is routine here (CLAUDE.md tells you to run it
after touching `hooks.py`) and would silently destroy a half-finished template. A row survives that,
survives a restart, and an administrator can see what happened.

`AI Template Edit Session`: `template`, `template_title`, `structure_markdown`, `base_version`,
`is_copy`, `status`, `expires_at`. Named by hash — a session id is an opaque token, and a sequential
one is a guessable one.

### What the row deliberately does NOT hold

- **No filled example.** The Example tab's output is synthetic PHI, generated on demand (§3.11). Not
  caching it is what makes "never persisted" true *by construction* rather than by discipline.
- **No patient or encounter.** Editing a note structure needs no chart, so this row cannot become an
  unexpected PHI location (PHI-4).

Consequently `edit_template_chat` **accepts the spec's `context` and refuses to use it**, returning
`context_used: false` — the same treatment `generate_template_example` gives it. The inventory
floated giving this surface read tools so the model could "reason about the chart". Its output is an
object that is copied between clinicians and can be published clinic-wide; putting real chart text
one model slip away from that needs its own decision, not a side entrance through an editor feature.

### Smaller decisions

- **`if_owner` alone is the whole permission model** — and that is the point. `AI Chat Template`
  needed two hooks because it had to express "my rows **or** the shipped system rows"; a session is
  one person's scratch space, so there is no second case and nothing to get wrong.
- **Opening needs only READ.** A clinician opens a system template, edits freely, and Save creates
  their own copy — `is_copy` is returned at open time so the editor can say "Save as a copy" *before*
  the work is invested rather than after.
- **Save delegates to part A** (`create_template` / `update_template`) rather than writing the row
  itself, so the system-template rule, the ownership check, the category validation and the
  save-time PHI guard all apply on this path too, in one place. Tested: an outline naming a patient
  is refused at Save, and the session stays **Open** so it can be fixed.
- **A copy must be named.** A copy that silently inherits its parent's title is indistinguishable
  from it in the template list.
- **A blank outline can be edited** (but not filled or illustrated). "Add a Subjective section" to an
  empty canvas is how a clinician starts from scratch, so `edit_structure` size-checks without
  requiring content, while `fill_template` and `generate_example` still refuse empty — filling
  nothing is meaningless.
- **A hand edit and a request in one call apply in order**: the canvas edit lands first, then the
  request is applied to *that*, not to the outline as it was when the session opened.
- **24-hour TTL enforced by a daily purge** registered in `hooks.py`, not merely described in a field
  (**PHI-3**). Bounded per run and never raises (Rule 7). A saved session is closed rather than
  deleted — until the TTL it is the record of what the editor actually wrote.

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_template_editor.py` — **18 cases**.
**145/145 across the whole Narzim suite.**

### ⚠️ A test leak fixed at the same time

`test_narzim_templates.py` had been leaking one `AI Chat Template` row per run since part A — 7 were
found on the dev site. Cause: the cleanup called `doc.save()` to clear `is_system` before deleting,
and that save re-validates the `duplicate_from` **Link**, which by then pointed at a row deleted
earlier in the same loop. The resulting `LinkValidationError` was swallowed by a blanket
`except Exception: pass`, so the delete never ran and nothing ever said so. Now `db.set_value` +
reverse order, and a cleanup failure prints instead of vanishing.

---

## 3.11 Filling a template — ✅ PART B1 DONE 2026-09-17

Item 5, **part B1: the fill engine and its two callers.** Part B was split again because it is
seven methods across three unrelated risk profiles, and the one carrying the real PHI question
(`generate_template`, which reads 3–5 encounters) should not be reviewed inside a 900-line commit.
B2 — `generate_template`, `suggest_templates` and the edit-session trio — is next.

### One engine, two callers that are deliberate opposites

| | reads a real chart | may invent |
|---|---|---|
| `fill_template()` — Apply, and a template chosen in the composer | **yes**, read-only via tools | **never** |
| `generate_example()` — the editor's Example tab | **never** | **yes, that is its job** |

They share `services/narzim_template_fill.py` because the contrast **is** the safety property and a
reader who sees only one of them cannot check it. They do **not** share a prompt: "never invent a
clinical detail" and "invent a plausible case" cannot live in one file without one of them being
hedged. So there are two — `prompts/narzim-template-fill-v1.txt` and
`prompts/narzim-template-example-v1.txt` — and a test asserts they still disagree, because a
well-meaning edit that converges them produces either a real note full of invented findings or an
example too empty to judge a structure by.

### Methods

```
POST …narzim_assistant.templates.apply_template             { template_id, thread, context?, sources? }
POST …narzim_assistant.templates.generate_template_example  { body_markdown, context? }
```

Both live in `templates.py`, not `api.py` — payloads #21 and #26 above spell them
`…narzim_assistant.api.<fn>`, which predates part A moving templates into their own module. The
route is `…narzim_assistant.templates.<fn>`.

`apply_template` persists a **user turn** ("Apply template: <title>") and an **assistant turn**
carrying the filled structure, through the same `_insert_message` every other turn uses — so
`get_thread` replays it with no new branch. It never writes the encounter (Rule 6): the output is a
draft in a chat thread that a clinician reads, edits and carries across deliberately.

### Five decisions worth the argument

- **A fill with no chart and no conversation never calls a provider.** There is nothing to fill
  *from*, so the only honest output is the blank structure, returned verbatim with `filled: false`.
  Asking a model for it spends money to produce a guaranteed-empty result and gives it an
  opportunity to invent one. `filled` is on the response because a blank form and a filled form
  whose slots were all legitimately empty are **indistinguishable from the text alone**.
- **`template_used` is no longer permanently null** — the promise §3.8 made when the five composer
  extras shipped as transport only. It records what the model was actually *given*, which is why it
  is a different field from the user turn's `template_requested`: the two differ exactly when a
  template was asked for and could not be applied. A **vision** turn is answered from the raw image
  and never reads `llm_message`, so it records `template_used: null` and keeps the ask on the user
  row — recording a use that did not happen would be a false claim in the audit trail.
- **A templated reply is always `reply_format: "markdown"`**, independent of
  `AI Settings.narzim_reply_markdown`. That flag governs whether the assistant writes markdown
  *prose*; a filled template is markdown *by construction*, because the clinician typed
  `## Subjective` into their own outline. Labelling it "plain" renders their own headings back at
  them as literal hashes. This is the one place where the format follows the **input**, not the
  prompt lineage.
- **`generate_template_example` accepts `context` and refuses to use it**, returning
  `context_used: false`. An example is rendered into an editor preview and cached in an edit
  session — outside every retention and erasure path that covers a thread (**PHI-4**) — so it must
  be *incapable* of containing a real chart, not merely instructed not to. Reported rather than
  dropped silently: a client that sent it is entitled to know it had no effect.
- **The fill reads at most 8 prior turns**, deliberately less than the chat window's 16. The source
  for a note is what was said about *this* visit; reaching further back starts pulling in a previous
  one, whose findings would be filled into today's note as though they were today's (**Rule 5**).

### ⚠️ The permission hole this closed

The first version of `_resolve_template` loaded the chosen template with `frappe.get_doc` and a
comment claiming that call "carries the permission model". **It does not** — `frappe.get_doc` loads
the row and returns it; nothing checks read permission. Part A's own `_load()` calls
`require_permission` first for exactly this reason.

Left as written, `send_message(template_id=<another practitioner's private template>)` would have
folded that template's body into the prompt and returned its headings in the structured reply —
the same disclosure part A closed with the own-plus-system hooks, reopened through a different door.
Caught in the self-review pass before the tests ran; there is now a test asserting the check happens
and that nothing is written to the thread when it fails.

### Two corrections to shipped code, found on the way

- **`answer_with_context` never appended the default language.** Every Narzim prompt ends by telling
  the model to fall back to "the default language noted below (appended after this prompt)", and on
  the patient-aware path nothing appended it — the model got a dangling reference and no fallback
  for a message carrying no language signal. Now `with_default_language()`, named once and used by
  both surfaces. The copies inside the two provider adapters are left alone: that is the provider
  boundary, and consolidating them is a separate cleanup.
- **`services/narzim_assistant.py`'s module docstring was false.** It claimed the assistant "is
  never given a patient, an encounter, or any tool access — there is no code path back to a clinical
  record here at all", which stopped being true when ADR-075 shipped. Replaced with the guarantee
  that actually holds: nothing here ever *writes* a clinical record, and a turn with no linked
  patient still reaches no chart.

### ⚠️ And the gap that guard did NOT close — fixed straight after

Guarding the body at fill time stops it reaching a provider. It does not stop it being **stored**,
and that framing was too narrow: `body_markdown` is a copyable, promotable object, so a pasted name
is a durable exposure, not a transient one.

- it sits outside every retention and erasure path, because nobody looks for PHI in a template
  library (**PHI-4**);
- `create_template(duplicate_from=…)` copies a body verbatim;
- an `is_system` row is readable by **every** user, so one promotion in the Desk turns one
  clinician's paste into a clinic-wide disclosure.

So the identifier is now refused **at the point it would be written**: in `create_template` /
`update_template` for the message, and in the controller's `validate()` as the backstop — the same
API-plus-controller shape part A used for the system-row rule, for the same reason (a Desk edit, a
patch or a script never passes through `templates.py`).

Three details that are the whole design:

- **Exempt during migrate / install / patch / import.** The check queries the `Patient` table, so a
  shipped template whose wording collided with a real patient's name on some site would make
  `bench migrate` **fail** — a worse failure than the one being prevented, and one the clinic could
  not fix itself. Not exempt during tests.
- **Only when `body_markdown` actually changed.** A rename or an `is_default` tick must not pay for
  a Patient lookup — and a legacy row that already carries an identifier stays renameable rather
  than becoming unsaveable.
- **Its own message, not the chat guard's.** `assert_no_patient_identifier` tells the user to link
  the patient with the composer's **+** button, which means nothing in a template editor. This uses
  `find_patient_identifiers` and names the KIND found ("patient name", "document id") — that
  function returns type labels and never the matched value (Rule 10) — then points at `[Patient
  name]` as the fix.

Verified before shipping: **6 template rows on the dev site, 0 trip the guard** — no migration cost.

**Known limitation, pre-existing and shared with every caller of this guard:** `_phrases` stops at
`_MAX_CANDIDATES = 400` and builds 2-word windows first, so on a long body only roughly the first
**400 words** are name-checked. MRN-shaped ids are regex-matched across the whole text; a patient
name buried deep in a 100 KB template is missed. Recorded, not fixed here.

### Shared plumbing

`integrations/{openai,anthropic}.py` gain `complete(system, user)` — one completion against a
caller-supplied system prompt, no tools, returning cost and latency like `answer_general_question`.
`answer_lab_question` has done this since the lab summaries landed, but its name is wrong everywhere
except labs, and a call site reading `answer_lab_question(...)` to render a SOAP outline is the kind
of thing that survives review and confuses everyone for a year. It is left untouched.

`AI Prompt Log.purpose` gains **Narzim Template Fill** and **Narzim Template Example**. It is a
Select, so without the doctype change the log write fails validation — silently, because
`log_prompt_call_general` is best-effort by design (Rule 7).

Tests: `remedisys_healthcare_ai/tests/ai/test_narzim_template_fill.py` — **21 cases**, most of them
asserting a negative, plus **6** in `test_narzim_templates.py` for the save-time guard.
**127/127 across the whole Narzim suite.**

---

# PART 4 — CORRECTIONS TO THE PR'S SPEC

| # | PR says | Reality |
|---|---|---|
| 1 | "wrap `ask_copilot_agent`, don't reimplement" | Right in spirit, but `execute_tool` takes `encounter` as a **mandatory kwarg** and 3 tools hard-require it. A patient-only subset is real work |
| 2 | write `prompts/narzim-assistant-v2.txt` | **v2 already exists and is superseded; production loads v3.** The new one is **v4** |
| 3 | My Library = `clinical_documents.api` | That module does not exist. It is **`api/v1/drive/api.py`** |
| 4 | `set_feedback(message, thread, feedback, note?)` | No `thread` parameter |
| 5 | (silent) | **`send_message_stream` exists** and needs the same extensions |
| 6 | (silent) | **Two different response envelopes** — §0.2 |
| 7 | "13 read tools" | **15** read tools (38 total) |
| 8 | `reply_format?: "markdown" \| "plain"` (`types.ts:59`) | ✅ **resolved 2026-09-17** — backend now emits `"plain"` to match; rationale and the 244-row data patch in §3.6 |
| 9 | `NarzimReference.library_doc` (`types.ts:27`) | ✅ **resolved 2026-09-18** — set for every `kind: "library"` row (`services/narzim_library_context.py:100,119`), so a citation links back to the file |

---

# PART 5 — BUILD ORDER

| Phase | Work | Unblocks |
|---|---|---|
| **0** | ✅ ADR-075 (patient-aware Narzim) · ✅ **ADR-077** (Clinical Web subprocessors + `ComplianceProfile`, PHI-1) · ✅ ADR-078 (PHI-1 enforced) · ✅ ADR-079 (source cache) | **done** |
| **1** | ~~#6 mic~~ ✅ · ~~`reply_format`~~ ✅ · ~~#1/#2 persist + return the extras~~ ✅ | **done** — the mock demo is real transport |
| **2** | ~~#5 templates (2 doctypes + 13 methods)~~ ✅ | **done** |
| **3** | ~~#3 `answer_with_context` + 12-tool subset + context prompt + guard/refusal change~~ ✅ | **done** — "Link patient" works |
| **4** | ~~#4 Clinical Web + URL fetch + citations + cache~~ ✅ | **done** — enabled under ADR-077, cached under ADR-079 |
| **5** | ~~`get_suggestions`~~ ✅ | **done** (§3.25) |

> ## ✅ THE BACKEND FOR PR #493 IS COMPLETE — 2026-09-18
>
> Verified mechanically on that date, not read off this document: all **10 methods** the mapping
> names exist in `api/v1/narzim_assistant/`; all **5 doctypes** are installed; all **10 new fields**
> on `AI Narzim Assistant Message` are present.
>
> **One item remains in the whole mapping and it is NOT backend:** the mic is still blocked by
> `EB_Healthcare_Frontend/src/app/api/ai/transcribe/route.ts:19`, which rejects a visit-less
> transcribe before it reaches Frappe. The backend has accepted both shapes since 2026-09-17.
> Owned by the frontend dev (CLAUDE.md §13 rule 2).

---

# PART 6 — COMPLIANCE GATES (`CLAUDE.md` §9.9)

- **PHI-1** — PubMed/NCBI and arbitrary URL fetching are **new subprocessors**. The active
  `ComplianceProfile` must name them *in the same commit*, and the integration must refuse to run
  against a provider the profile does not name.
- **Rule 10 / PHI-8** — the **outbound** PubMed query must pass through `redact_text`, not only the
  retrieved text. If the model composes a query from the chart, PHI leaves inside a URL.
- **Rule 5 / PHI-6** — context turns respect `AI Settings.llm_context_token_budget`, with logged
  truncation.
- **PHI-4** — a Narzim thread can now hold PHI-derived answers; retention and erasure must cover it.
- **Rule 6** — `allow_write=False` always. Narzim GPT must never write a chart. ✅ matches the PR.
- **ADR-030** — no raw SQL, no arbitrary Python, no generic CRUD to the LLM. ✅ unchanged.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.12 | 2026-09-18 | Divyanshu (AI-assisted) | Part 5 closed out and Part 4 item 9 resolved, after a mechanical verification of all 10 methods, 5 doctypes and 10 message fields against the code |
| 3.11 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.25 — `get_suggestions` built; **PR #493's backend is now complete**. Records the "dose of C" defect that only a live call surfaced |
| 3.10 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.24 — `AI Source Cache` built (ADR-079): stored for reproducibility, retention number as the switch, purge and erasure handle in the same change |
| 3.9 | 2026-09-18 | Divyanshu (AI-assisted) | §2.1 and §2.x mapping rows re-verified against the code after the Clinical Web, streaming and PHI-1 work — five rows were stale; `get_suggestions` confirmed as the only backend method from PR #493 never built |
| 3.8 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.23 — Clinical Web enabled under ADR-077; pasted addresses screened for identifiers; §3.21 corrected (the blocker was never ADR-076) |
| 3.7 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.22 — the streaming path had no retrieval or citations; prompt assembly deduplicated into `_build_llm_message` and covered by a parity test verified to fail on the drift |
| 3.6 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.21 — PubMed + SSRF-safe URL fetch built on instruction while ADR-076 is still Proposed, behind gates that refuse; records the DNS-rebinding residual risk and the shared citation numbering |
| 3.5 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.20 — library retrieval: the FIRST working citation, verified end to end against a real Drive file. §3.7 upgraded from "doctype built" to "working for library sources" |
| 3.4 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.19 — `list_sources()`, with `enabled` computed per site from the compliance register and Drive's real state rather than hardcoded |
| 3.3 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.18 — `AI Source Reference` built and wired onto all three responses; §3.7 downgraded from NOT BUILT to "doctype built, retrieval missing" |
| 3.2 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.17 — the library pin was refused for every file (wrong doctype, shipped by me); fixed and proven against real Drive, plus the bench/branch trap that hid it |
| 3.1 | 2026-09-18 | Divyanshu (AI-assisted) | New §3.16 — the compliance register can now name a retrieval host (it structurally could not before), the two refusal gates, and the measurement showing 11 of 19 register fields have no reader at all |
| 3.0 | 2026-09-18 | Divyanshu (AI-assisted) | Item 4 started — new §3.15, the outbound search gate (name/email/contact only, and why the stricter first version was measured and replaced). Two corrections: `library_doc_ids` exists, and `references[]` is blocked on retrieval rather than on Clinical Web specifically |
| 2.9 | 2026-09-18 | Divyanshu (AI-assisted) | `suggest_templates` shipped — new §3.14 — and **item 5 is complete**. Only item 4 (Clinical Web) remains, blocked on its own ADR |
| 2.8 | 2026-09-18 | Divyanshu (AI-assisted) | `generate_template` shipped on approach D — new §3.13: the fixed-vocabulary safety property and the test behind it, the two measurements that chose D, the Rule 7 fallback, and a withdrawn claim from the earlier argument |
| 2.7 | 2026-09-18 | Divyanshu (AI-assisted) | Part B2a shipped — new §3.12: the editor session doctype and why it is not Redis, what the row deliberately does not hold, and the part-A test leak fixed alongside |
| 2.6 | 2026-09-17 | Divyanshu (AI-assisted) | PART 2 status markers reconciled with the code — items 1, 2, 3, 7 and template CRUD were shipped but still read "must be built", which made the remaining work look roughly twice its real size |
| 2.5 | 2026-09-17 | Divyanshu (AI-assisted) | §3.11: a template is now refused at SAVE time if its text names a patient, not only at fill time — storage is its own exposure (PHI-4), with the migrate exemption and the known 400-word limit recorded |
| 2.4 | 2026-09-17 | Divyanshu (AI-assisted) | Item 5 part B1 shipped — new §3.11: the one fill engine and its two opposite callers, the five decisions, the `frappe.get_doc` permission hole closed in self-review, and two corrections to shipped code |
| 2.3 | 2026-09-17 | Divyanshu (AI-assisted) | `answer_with_context` shipped — new §3.10: the reused bounded loop, the four safety properties, the narrowed PHI guard and the separate context prompt lineage |
| 2.2 | 2026-09-17 | Divyanshu (AI-assisted) | Item 5 part A shipped — new §3.9 records the two template doctypes, the six CRUD methods, the system-template rule and the own-plus-system visibility hooks |
| 2.1 | 2026-09-17 | Divyanshu (AI-assisted) | Item 3 shipped — new §3.8 records the five composer extras: authorisation, SSRF rules, storage and replay; Phase 1 complete |
| 2.0 | 2026-09-17 | Divyanshu (AI-assisted) | `reply_format`'s non-markdown value settled as `"plain"` to match PR #493's union; §3.6 records the basis for the choice and the 244-row rename patch |
| 1.9 | 2026-09-17 | Divyanshu (AI-assisted) | New §3.7 — `references[]`: why it is blocked on Clinical Web, the real contract read from PR #493's types.ts, where it renders, and the payload on both responses |
| 1.8 | 2026-09-17 | Divyanshu (AI-assisted) | Item 2 verified — 14/14 tests pass, §3.6 marked done |
| 1.7 | 2026-09-17 | Divyanshu (AI-assisted) | Item 2 built — new §3.6 records `reply_format`, the v4 prompt and why the flag ships OFF; build order, PART 2 and the payload notes updated |
| 1.6 | 2026-09-17 | Divyanshu (AI-assisted) | Corrected the item-6 status: the backend accepts a missing encounter, but the BFF route still returns 400 before calling it — the mic needs a frontend one-liner too |
| 1.5 | 2026-09-17 | Divyanshu (AI-assisted) | §3.4 item 6 SHIPPED — `transcribe_audio.encounter` is optional; marked done in the build table, PART 2 mic rows, payload #8 and the build order |
| 1.4 | 2026-09-17 | Divyanshu (AI-assisted) | Rewrote all payloads as copy-paste Postman/Bruno HTTP blocks (method, URL, headers, body, status) using the repo's existing `{{base_url}}`/`{{access_token}}` variables; numbered 1-27 |
| 1.3 | 2026-09-17 | Divyanshu (AI-assisted) | Added request/response payloads to every PART 2 section, marked VERIFIED vs PROPOSED; corrected §0.2 — `set_list_response` puts the array in `data` with `pagination` as a sibling (its own docstring is wrong) |
| 1.2 | 2026-09-17 | Divyanshu (AI-assisted) | Added PART 2 — UI → BFF → backend map: every screen element to its component, BFF route and backend method |
| 1.1 | 2026-09-17 | Divyanshu (AI-assisted) | Linked ADR-075 now that the guardrail decision is recorded |
| 1.0 | 2026-09-17 | Divyanshu (AI-assisted) | Initial inventory — verified against `dev`, endpoints/payloads/responses, 7 spec corrections |
