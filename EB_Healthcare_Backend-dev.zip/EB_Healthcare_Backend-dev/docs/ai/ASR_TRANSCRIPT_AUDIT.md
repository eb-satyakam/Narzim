# AI Transcript / ASR — Full Audit, Plan & Workflow

**Doc status:** record · **Created:** 2026-07-22 by Sarvesh-SocialAngel · **Updated:** 2026-08-12 by Sarvesh-SocialAngel · **Version:** 1.0

**Created:** 2026-07-22 · **Last verified against code + live site:** 2026-08-12
**Trigger:** Scottish-English speech is not transcribing correctly.
**Branch:** Phase 1 landed via `feature/ai_v3`; verified present on `dev` 2026-08-12.
**Status:** ✅ **RESOLVED — Phase 1 shipped, transcription confirmed working.**
Phase 2 (ASR provider switch / Whisper) deferred, not needed.

> **2026-08-12 close-out.** Verified every finding against the current code and the
> live `marley.local` AI Settings, then confirmed the outcome with the clinician:
> **Deepgram is transcribing correctly** on `nova-3` + `multi` + keyterm boosting,
> for the Scottish-accented doctor with EN/ES patients. The symptom that opened
> this audit is gone.
>
> No open action items remain. F3/F4/F10 are recorded as accepted-and-not-scheduled
> so a future reader doesn't re-file them as bugs; F6/F7 fold into Phase 2 if it
> ever happens.
>
> Sections 8–10 were written for the abandoned `en-GB` single-accent plan and
> contradicted the §6 decision. They are corrected in place, with the original
> wording called out where it stood rather than silently overwritten.

---

## 1. Pipeline map (A → Z)

1. **Mic capture** (browser, `real-provider.ts`): single-mic → `MediaRecorder`
   `audio/webm;codecs=opus`, 250 ms chunks. (Dual-mic path sends raw linear16 PCM @48 kHz.)
2. **Token mint**: FE `POST /api/ai/session` → `sessions.py::start_session` →
   `deepgram.mint_session_token()` → Deepgram `/v1/auth/grant` → returns
   `{url, token, ttl_seconds, params}`.
3. **Live stream**: FE opens WS to `session.deepgram.url` **verbatim** (FE builds
   no params itself) and streams the opus chunks.
4. **Results**: Deepgram → interim + final over WS → FE builds segments →
   `POST /api/ai/segment` (`append_segment`).
5. **Downstream LLM**: transcript → `generate_suggestions` / `generate_soap_draft`
   → output normalized to `ComplianceProfile.primary_language` (LLM instruction
   `Output language: …`).

There is also a **batch** path: `POST /api/ai/transcribe` → `api.py::transcribe_audio`
→ **Deepgram** `deepgram_client.transcribe()` (Nova-3 Medical). Used by lab
imaging-result dictation, not the live encounter sidebar.

---

## 2. Current live config (dev, marley.local)

Read from the live site on **2026-08-12** (`frappe.get_single("AI Settings")`), not from
memory. The 2026-07-22 values are kept alongside so the change is auditable.

| param | value (2026-08-12) | was (2026-07-22) | source |
|---|---|---|---|
| model | **`nova-3`** | `nova-3-medical` | AI Settings.deepgram_model *(now a Select)* |
| language | **`multi`** | `en` (generic) | AI Settings.deepgram_language *(now a Select)* |
| diarize / multichannel | true / false | true / false | AI Settings |
| keyterm boosting | **on** — `_drug_keyterms()`, capped 50, `nova-3*` only | absent | `deepgram.py:58,202` |
| interim_results / endpointing / punctuate / numerals | true / 800 ms / on / on | same | `deepgram.py` constants |
| smart_format | **STILL NOT sent** on live `mint_session_token` | not sent | `deepgram.py` — present only at `:345` (batch) and `:425` (browser token) |
| audio codec | webm/opus, MediaRecorder default rate | same | `real-provider.ts` |
| cost basis | `0.0077` USD/min | — | AI Settings.deepgram_cost_per_minute_usd |

---

## 3. Findings (ranked) — status verified 2026-08-12

**The ASR problem this audit was opened for is CLOSED** — transcription is confirmed
working on `nova-3` + `multi` + keyterms (§7). Nothing here is an open action item.
Every status was checked against the current code, with the file:line that proves it.

| ID | Finding | Status (2026-08-12) | Evidence |
|---|---|---|---|
| F1 | **ROOT CAUSE:** model+language wrong for a Scottish accent | ✅ **FIXED** (by config, not by `en-GB`) | live site now `nova-3` + `multi`; see §2 |
| F2 | `en` should be `en-GB` | ⛔ **SUPERSEDED — deliberately rejected** | §6: `en-GB` is English-only and cannot transcribe the Spanish-speaking patients |
| F3 | `smart_format` off in the live path | 🔵 **ACCEPTED — not scheduled** | absent from `mint_session_token`; present at `deepgram.py:345` (batch) and `:425` (browser token). Affects number/date formatting only, not accuracy |
| F4 | audio codec (secondary) | 🔵 **ACCEPTED — not scheduled** | `real-provider.ts` webm/opus at MediaRecorder defaults; quality is adequate in practice |
| F5 | no keyterm boosting for drug names | ✅ **FIXED** | `_drug_keyterms()` `deepgram.py:58`, applied `:202` for `nova-3*`, cap 50, `doseq=True` at `:142` |
| F6 | Whisper built but unwired | 📦 **DEFERRED — Phase 2** | zero imports of `integrations/groq.py`. Not needed while Deepgram performs |
| F7 | compliance/code mismatch, no `get_asr_client()` | 📦 **DEFERRED — Phase 2** | `audio_provider="groq"` at `compliance/profiles/mx.py:24` and `india.py:24`; no `get_asr_client` symbol. Documentation/code drift, no runtime effect — Deepgram is what runs |
| F8 | `transcribe_audio` docstring implies Groq | ✅ **FIXED** | docstring at `api/v1/ai/api.py:495` now reads "via Deepgram Nova-3 Medical" |
| F9 | model/language are free-text `Data` fields | ✅ **FIXED** | both are `Select` in `ai_settings.json`; language gained `es-MX` (6 options, not the 5 planned) |
| F10 | two divergent Deepgram param builders | 🔵 **ACCEPTED — not scheduled** | F3 is its symptom; a tidy-up, not a defect |

**Net:** 4 fixed, 1 rejected on purpose, 3 accepted as-is, 2 folded into Phase 2.
F3/F4/F10 are recorded so the next reader doesn't re-discover them as bugs — they
are known and deliberately not being worked on. F7 is worth keeping visible because
the compliance profile still *names* a provider the code does not dispatch on; that
becomes real work only if Phase 2 happens.

---

## 4. Deepgram config-acceptance probe (2026-07-22)

Tiny silent WAV → `/v1/listen` per combo. **All accepted (HTTP 200):**
`nova-3-medical{en,en-GB}`, `nova-2-medical{en,en-GB}`, `nova-2{en-GB,en-US}`,
`nova-3{en-GB,multi}`.

**Caveat:** 200 = "not rejected", it does **not** prove real en-GB acoustic
tuning for a given model. True accent quality needs an **audio A/B** on a real
Scottish sample.

---

## 5. Key constraints

- **Deepgram = live streaming** (word-by-word interim results). **Whisper/Groq =
  batch** (record → stop → transcribe whole blob; no live preview). Switching to
  Whisper changes the recording UX.
- **Accent-tuning vs multilingual is a trade-off**: `en-GB` (best Scottish) is
  English-only; `multi` (code-switching) uses a generic acoustic model (accent
  accuracy drops). Can't have both at top quality in one Deepgram config.
- **Probe ≠ proof**: only an audio A/B tells us the true best combo.

---

## 6. Decisions locked (from user, 2026-07-22)

- Doctor = Scottish English; **patients speak English OR Spanish (or other)** →
  genuinely multilingual consultations. This ruled out the `en-GB` single-accent
  config (can't transcribe Spanish).
- Transcript output = **as spoken** (no forced single-language / translation).
  (SOAP + suggestions already normalized to the decided language by the LLM.)
- Scope now = **Phase 1**: Deepgram model+language dropdowns **+ keyterm boosting**.
- **Chosen config: `nova-3` + `language=multi` + keyterm prompting** — keeps live
  streaming + multilingual, and recovers drug-name accuracy (lost by not using
  the English-only nova-3-medical) via catalog keyterms.
- Whisper large-v3 (better accent + multilingual, but batch) — parked for Phase 2.

---

## 7. Plan

### Phase 1 — SHIPPED, verified on `dev` 2026-08-12
1. `deepgram_model` `Data → Select`: nova-3-medical, nova-2-medical, nova-3, nova-2. ✅
2. `deepgram_language` `Data → Select`: en, en-US, en-GB, es, **es-MX**, multi. ✅
   *(shipped with 6 options — `es-MX` was added beyond the 5 planned here)*
3. **Keyterm boosting** (`deepgram.py`): `_drug_keyterms()` (capped 50) added to
   `mint_session_token` for nova-3* models; `_build_stream_url` uses doseq. ✅
   Recovers drug-name accuracy on general nova-3 so `multi` is viable.
4. Dev set to **`nova-3` + `multi`** (multilingual); dropdown allows one-click A/B. ✅
5. Prod default stays `es` (Mexico). ✅ Deepgram keyterm cap = 500 sub-word
   tokens (verified); the 50-term cap keeps the live WS URL safely under it (Rule 7).

### Phase 2 — LATER (real feature, needs its own go)
- New `asr_provider` (Deepgram / Whisper) + backend `get_asr_client()` dispatch.
- Whisper path is batch-only → live sidebar needs a record-then-transcribe
  fallback (frontend work). Fix F6/F7/F8 alignment with compliance.
- Optional: add `smart_format` + keyterm boosting to the live path (F3/F5).

### Verification — ✅ CONFIRMED WORKING IN PRACTICE (2026-08-12)
- **User-confirmed 2026-08-12: Deepgram transcription is working correctly** on the
  live `nova-3` + `multi` + keyterm config, with the Scottish-accented doctor and
  EN/ES patients this was built for. The reported symptom that triggered this whole
  audit is resolved.
- This is real-world confirmation from the clinician using it, **not** the formal
  matrix A/B below. That distinction matters only if quality regresses — the
  outcome we cared about is met, so the A/B is no longer a blocker.
- **Still available if needed** (e.g. a future accent complaint, or evaluating
  Whisper in Phase 2): record a 20–30 s Scottish sample and batch-transcribe across
  `{nova-2-medical, nova-3-medical, nova-3} × {en-GB, en, multi}` (± Whisper
  large-v3), comparing by ear. Keep it as the escalation path, not a to-do.

---

## 8. Workflow (Phase 1 execution steps) — COMPLETED

> **Correction (2026-08-12):** step 4 below originally read *"Set dev value to
> `nova-2-medical` + `en-GB`"*, which contradicted the §6 decision. `en-GB` was
> rejected precisely because it cannot transcribe the Spanish-speaking patients.
> What actually shipped is `nova-3` + `multi`. Corrected in place.

1. ✅ Prompt archive written: `prompts/2026-07-22-deepgram-asr-settings-dropdowns.md`.
2. ✅ `ai_settings.json`: two `Data → Select` conversions + options + descriptions.
   (AI Settings is our custom doctype — Rule 1 OK; additive field-type change,
   applied on `bench migrate`.)
3. ✅ `python -c json.load` validate → `bench migrate` → fields render as dropdowns
   and stored values are within the option lists.
4. ✅ Dev value set to **`nova-3` + `multi`** (config, not code) — *not* the
   `nova-2-medical` + `en-GB` originally written here.
5. ✅ Dev restarted; in-browser test done, dropdown allows one-click A/B.
6. ✅ Landed via `feature/ai_v3`; present on `dev` as of 2026-08-12.

---

## 9. Risks / rollback

- ~~**Risk:** stored value not in the new Select options → field shows blank.~~
  **Not hit** — options include the previously-live values (`nova-3-medical`, `en`).
- ~~**Risk:** `en-GB` on `nova-3-medical` silently falls back.~~ **Moot** — `en-GB`
  was never adopted (§6).
- ~~**Live risk:** `multi` trades Scottish accuracy for code-switching.~~ **Closed
  2026-08-12** — transcription confirmed working in practice on this config (§7).
  The theoretical trade-off is real but is not costing anything observable.
- **Rollback:** revert the field-type to `Data` (single JSON edit + migrate); no
  data loss (values are plain strings either way). Model/language themselves are
  config — switch from the dropdown, no deploy.
- **Prod safety:** prod keeps `es`; nothing here flipped a production default.

---

## 10. Out of scope (explicitly)

> **Correction (2026-08-12):** this section previously read *"Multilingual/
> code-switching (`multi`) … out of scope — user chose single-accent"*. That was
> the pre-decision position and directly contradicted §6. `multi` is what shipped
> and is now the live config.

- **Transcript translation** — out of scope. Transcript stays as-spoken; only SOAP
  and suggestions are normalised to the ComplianceProfile language by the LLM.
- **Whisper wiring / ASR-provider switch** (F6/F7) — Phase 2, separate go.
- **`smart_format` on the live path + builder unification** (F3/F10) — small, still
  open, not yet scheduled.
- **Codec change to linear16 for single-mic** (F4) — marginal, not scheduled.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-22 | Sarvesh | Initial version (header backfilled from git history) |
