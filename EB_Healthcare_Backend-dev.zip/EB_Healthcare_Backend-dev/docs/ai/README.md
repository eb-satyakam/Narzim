# AI Documentation — Index

**Doc status:** living · **Created:** 2026-08-13 by Sarvesh-SocialAngel · **Updated:** 2026-08-18 by Sarvesh-SocialAngel · **Version:** 1.0

Remedisys AI documentation, in reading order.
**Last reviewed against `dev` @ `450aace` + live site `marley.local` on 2026-08-13.**

---

## Where this is going

**Today:** an AI that drafts a clinical encounter from the consultation — transcription,
extraction, suggestions into a draft the physician edits and signs.

**Long-term:** a **clinical evidence platform**. Remedisys observes real clinical work —
conversation, orders, decisions, what the doctor changed about the AI's suggestions, and
what happened to the patient afterwards — and turns that governed, provenance-tracked
record into evidence that improves future care:

> *"I found 32 comparable historical cases. 18 received X, 9 received Y, 5 received
> supportive management."*

Other clinics eventually buy the curated general intelligence and layer their own local
knowledge on top, tenant-isolated. **The doctor makes every clinical decision; the AI
supplies evidence and explanation.**

Three things to internalise before reading anything else:

| | |
|---|---|
| **The asset is the dataset and the retrieval layer, not model weights** | The flagship feature above is a cohort query. ~90% of the long-term value needs zero model training |
| **Reasoning is unbounded; authority is bounded** | The LLM may reason about anything and assert nothing it did not retrieve |
| **Not "every encounter trains the model"** | Every clinical event becomes a *governed learning signal*, and we decide whether it improves retrieval, evaluation, tools, prompts, safety, knowledge — or, only when measured, weights |

**Blocking today:** the doctor's accept/edit/reject signal is computed in the browser and
discarded (`use-copilot.ts:443`), and AI output already reaches the permanent patient
record unreviewed (`encounter-screen.tsx:3217-3263`). Until both are fixed, every
additional encounter is a partly wasted one. Full reasoning and the sequenced fix: **#1 §2
and §13**.

---

## Start here

| # | Document | What it is | Status |
|---|---|---|---|
| **1** | [REMEDISYS_AI_MASTER_PLAN.md](./REMEDISYS_AI_MASTER_PLAN.md) | **The plan. Authoritative.** Strategy, target architecture, provenance model, feedback schema, roadmap P0–P3, scale strategy, what-not-to-do. Where any document disagrees with this one, this one wins | Authoritative — 2026-08-13 |
| **2** | [REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md](./REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md) | **The explainer.** What the system is today, in plain English, in ~10 minutes. Read this before touching AI code | Current — 2026-08-13 |
| **3** | [CURRENT_SYSTEM_AUDIT.md](./CURRENT_SYSTEM_AUDIT.md) | **The evidence base.** Every claim in #1 and #2 traced to a `file:line`, plus live DB measurements, known bugs, documentation drift, and explicit unknowns | Current — 2026-08-13 |
| **4** | [DECISION_LOG.md](./DECISION_LOG.md) | **The history.** Date-wise record of what the plan was, who changed it, and what was decided — from 2026-05-13 to today. Includes decisions made implicitly and never written down, and the open ones | Current — 2026-08-13 |
| **5** | [P0_IMPLEMENTATION_PLAN.md](./P0_IMPLEMENTATION_PLAN.md) | **The next sprint.** Concrete plan for the six P0 items in #1 §13 — doctype definitions, exact file changes, tests, definition of done, and the three decisions needed before starting | **3 of 6 done — 2026-08-14** |

**#1 tells you what to build. #2 tells you what exists. #3 proves it. #4 tells you how it got here. #5 is what to do on Monday.**

## Narzim GPT — consolidated reference

**[`NARZIM_GPT/README.md`](./NARZIM_GPT/README.md)** is the consolidated, day-to-day reference for
both Narzim AI surfaces (the sidebar assistant and the encounter copilot) — architecture, tool
registry, domain scope gate, Clinical Web/citations, and the template system, condensed 2026-09-26
from documents #6, #7, #9 below plus `NARZIMGPT_CAPABILITIES.md` and `NARZIM_SCOPE_GATE.md`.
**Those originals were kept in place, not deleted**, because they are cited by exact section number
from dozens of places outside this folder — service code comments, tests, `CHANGELOG.md`,
`WORK_LOG.md`, ADRs, and `prompts/README.md`. Read `NARZIM_GPT/` for the current architecture; use
the originals below only when you need to resolve one of those section-numbered citations.

## Component references

| # | Document | What it is | Status |
|---|---|---|---|
| **6** | [NARZIM_AI_ENCOUNTER_SYSTEM.md](./NARZIM_AI_ENCOUNTER_SYSTEM.md) | Encounter Copilot reference — tool registry, prompt inventory, data model. **Accurate on structure, stale on numbers** (superseded by #3 §15) | Living — structure current, figures stale |
| **7** | [NARZIM_AI_ASSISTANT_DESIGN.md](./NARZIM_AI_ASSISTANT_DESIGN.md) | The separate patient-agnostic sidebar assistant, plus its PHI incident history (§10–§16). Distinct feature from the Encounter Copilot | Living |
| **8** | [ASR_TRANSCRIPT_AUDIT.md](./ASR_TRANSCRIPT_AUDIT.md) | Deepgram pipeline — the shipped `nova-3` + `multi` + keyterm config. **Covers transcription accuracy, not speaker attribution** — for that see #3 §5 | ✅ Resolved 2026-08-12 |
| **9** | [AI_ANALYZE_IDEMPOTENCY_DESIGN.md](./AI_ANALYZE_IDEMPOTENCY_DESIGN.md) | **Design reference for shipped code.** The Analyze fingerprint, clinical digest, and catalog-derived lexicon. Cited at section level by `services/transcript_digest.py` (§3), `services/clinical_lexicon.py` (§3.5), `services/ai_tools.py` (§4) and `tests/ai/test_analyze_fingerprint.py` (§6) — **do not delete while those citations stand** | Shipped `c778ad5` · header still says "not yet built" (wrong) · cache defaults OFF |

## Removed 2026-08-13

| Removed | Why | Where its content lives now |
|---|---|---|
| `AI_ENCOUNTER_OPTIMIZATION_PLAN.md` | P0–P10 optimization plan. Its headline claim — "ASR is >50% of per-encounter AI spend" — measured **23.7%**. Its baseline figures were superseded | Ranked work absorbed into **#1** §13; measurements in **#3** §15 |
| `AI_TOKEN_COST_MODEL.md` | Cost model from 485 calls. Superseded by direct measurement (302 agent calls, avg 53,414 input not 21,748). Its claim that `cached_tokens` "appears nowhere" is false — it is captured and is 46% of agent input | **#3** §15, with re-runnable SQL. ⚠️ `integrations/llm.py` and `services/ai.py` still cite its §6.3 in comments |
| `REMEDISYS_LONG_TERM_AI_VISION.md` | First long-term architecture review. Fully absorbed | **#1** |

Earlier removals (spent plans and checklists) are recorded in this file's git history.
**Everything above remains recoverable via `git show 450aace:docs/ai/<file>`.**

## Reading paths

- **New engineer on AI:** #2, then #3 §17 (known bugs) and §5 (speaker flow)
- **Doing the work now:** #5 — the P0 sprint plan
- **Planning work:** #1 §13 (roadmap), then #3 §17–§19 for what's broken and unknown
- **"Why is it like this?":** #4 — including decisions made implicitly and never written down
- **Touching Narzim GPT (either surface) day to day:** [`NARZIM_GPT/README.md`](./NARZIM_GPT/README.md) first
- **Touching the agent or tools:** #6 for the registry, #3 §8 for what's verified about it
- **Touching transcription:** #8 for the ASR config, #3 §5 for speaker attribution
- **Touching the fingerprint / digest / lexicon:** #9 — it is the design rationale for that code
- **Cost or latency questions:** #3 §15 only. The two removed docs are stale on every number

## Maintenance rule

When code and a document disagree, **the code is authoritative** — fix the document in the
same commit. Two documents here are knowingly stale in specific ways (#6's figures, #9's
"not yet built" header); both are labelled above rather than silently left to drift.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |

<!-- BEGIN GENERATED INDEX -->

_15 document(s) in this directory, 1 subdirectory/ies. Generated by `scripts/gen_doc_indexes.py` — do not edit by hand._

| Document | Status | Updated | Title |
|---|---|---|---|
| [`AI_ANALYZE_IDEMPOTENCY_DESIGN.md`](AI_ANALYZE_IDEMPOTENCY_DESIGN.md) | living | 2026-08-13 | Analyze Idempotency, Meaningful-Change Detection & Incremental Context — De… |
| [`ASR_TRANSCRIPT_AUDIT.md`](ASR_TRANSCRIPT_AUDIT.md) | record | 2026-08-12 | AI Transcript / ASR — Full Audit, Plan & Workflow |
| [`CURRENT_SYSTEM_AUDIT.md`](CURRENT_SYSTEM_AUDIT.md) | record | 2026-08-18 | Remedisys AI — Current System Audit |
| [`DECISION_LOG.md`](DECISION_LOG.md) | living | 2026-09-08 | Remedisys AI — Decision Log |
| [`LAB_EXTRACTION_PERFORMANCE.md`](LAB_EXTRACTION_PERFORMANCE.md) | record | 2026-09-22 | Lab extraction — where the time and the money actually go |
| [`NARZIMGPT_CAPABILITIES.md`](NARZIMGPT_CAPABILITIES.md) | draft | 2026-09-08 | Narzim GPT — Guided Clinical Tasks (Look up · Work up · Treat) |
| [`NARZIM_AI_ASSISTANT_DESIGN.md`](NARZIM_AI_ASSISTANT_DESIGN.md) | living | 2026-09-08 | Narzim AI — General Assistant (Sidebar): Design Proposal |
| [`NARZIM_AI_ENCOUNTER_SYSTEM.md`](NARZIM_AI_ENCOUNTER_SYSTEM.md) | living | 2026-08-13 | Narzim AI — Encounter Copilot: System Reference |
| [`NARZIM_GPT_BACKEND_INVENTORY.md`](NARZIM_GPT_BACKEND_INVENTORY.md) | living | 2026-09-17 | Narzim GPT (PR #493) — backend inventory: what exists, what to build |
| [`NARZIM_SCOPE_GATE.md`](NARZIM_SCOPE_GATE.md) | living | 2026-09-08 | Narzim General Assistant — Domain Scope Gate |
| [`NARZIM_TEMPLATE_STUDIO_FIXES.md`](NARZIM_TEMPLATE_STUDIO_FIXES.md) | living | 2026-09-30 | Narzim GPT template studio — backend fixes |
| [`P0_IMPLEMENTATION_PLAN.md`](P0_IMPLEMENTATION_PLAN.md) | living | 2026-08-14 | P0 — Implementation Plan |
| [`REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md`](REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md) | living | 2026-08-13 | Remedisys AI — Architecture Explained |
| [`REMEDISYS_AI_MASTER_PLAN.md`](REMEDISYS_AI_MASTER_PLAN.md) | living | 2026-08-14 | Remedisys AI — Master Plan |
| [`WHATSAPP_AI_ASSISTED_REPLIES.md`](WHATSAPP_AI_ASSISTED_REPLIES.md) | draft | 2026-09-14 | AI-assisted replies to patient WhatsApp messages — research and options |

**Subdirectories**

- [`NARZIM_GPT/`](NARZIM_GPT/README.md) — 4 document(s)

<!-- END GENERATED INDEX -->
