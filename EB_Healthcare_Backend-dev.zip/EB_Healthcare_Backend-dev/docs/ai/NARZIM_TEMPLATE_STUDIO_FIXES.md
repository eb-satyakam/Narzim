# Narzim GPT template studio — backend fixes

**Doc status:** living · **Created:** 2026-09-30 by Satyakam (AI-assisted) · **Updated:** 2026-09-30 by Satyakam (AI-assisted) · **Version:** 1.1

The design behind [adr-105](../adr/adr-105-template-studio-drafts-delete-and-example-cache.md). The
ADR records the decisions and the alternatives; this document says what each change does and how to
check it. Status is owned by [`docs/STATUS.md`](../STATUS.md); the callable surface by the generated
[endpoint index](../api/endpoints/narzim_assistant.md).

## User story

A doctor opens Templates, asks for "a SOAP note with a problem-based plan", and reads the outline.
She asks for a Follow-up section, sees it named as added, opens the Example tab, and saves. Next
week she deletes a template she no longer uses.

Before these changes: the first request could fail on a long heading and leave a blank template
behind; the follow-up request gave no sign it had worked; the example took about five seconds every
time and printed bare values with no labels; and the delete was refused.

## What changes

| # | Change | Where | Schema change |
|---|---|---|---|
| R1 | Deleting a template deletes its edit sessions first | `AIChatTemplate.on_trash` | No |
| R2 | `draft_template_outline(message)` writes a first outline and saves nothing | `api/v1/narzim_assistant/templates.py` | No |
| R3 | `save_template_session` accepts `category` and `description` | same | No |
| R4 | `edit_template_chat` returns `changed`, `sections_added`, `sections_removed` | same, `services/narzim_template_fill.py::outline_change` | No |
| R5a | A section heading is indexed without its instruction and cut to 140 characters | `ai_chat_template.py::_section_heading` | No |
| R5b | A generated example is cached for 7 days, keyed by structure, prompt and language | `services/narzim_template_fill.py::generate_example` | No |
| R5c | The outline prompt writes a printed label in front of a form slot and keeps headings short | `prompts/narzim-template-edit-v3.txt` | No |
| R5d | The example and fill prompts keep a label and handle a repeating block the same way | `prompts/narzim-template-example-v3.txt`, `prompts/narzim-template-fill-v2.txt` | No |

No doctype changes, so there is no patch and no `bench migrate` (BE-9).

## Details that are not obvious

**R1 depends on hook order.** Frappe runs `on_trash` before its link check. The test
`test_a_template_that_was_opened_in_the_editor_can_be_deleted` fails with `LinkExistsError` if that
order ever changes.

**R4 is computed, not asked for.** `changed` compares the two outlines as text. The model is not
asked what it did, so the answer cannot disagree with the outline.

**R5b is a cache, not a store.** The example never reaches a doctype. It expires through Redis, it
is not copied when a template is duplicated, and `clear_example_cache()` or `bench clear-cache`
removes every entry. An example is checked with `find_patient_identifiers` before it is cached; one
that collides with a real patient's name is shown once and not kept.

**R5c changes new templates only.** An existing template keeps its bare slots until it is edited.
A clinician can add a label by typing it in front of the slot.

**R5d changes real notes.** `narzim-template-fill-v2` is the prompt behind Apply template. It adds
two rules and removes none: keep a label that sits in front of a slot, and write a `#{n}` block once
per item the sources contain. The "never invent" rules are unchanged.

## Not in this change

- The 140-character limit on `AI Source Reference.title` and `.url`, which loses a chat reply.
- A language parameter for transcription.
- Visit search and recent patients for the pickers.
- `created` and last-used values on the template list.

## Verification

| Check | Result on `marley.local`, 2026-09-30 |
|---|---|
| `tests/ai/test_narzim_template_studio_fixes.py` | 23 pass |
| The R1 and R5a tests with the fix patched out | both fail (`LinkExistsError`, `CharacterLengthExceededError`) |
| `test_narzim_template_editor`, `_fill`, `_templates`, `_generate`, `_suggest` | 21, 23, 26, 16, 15 pass |
| On screen, against a real provider | Not done yet |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-30 | Satyakam (AI-assisted) | ADR citation adr-103 -> adr-105 (renumbered on merge with `dev`) |
| 1.0 | 2026-09-30 | Satyakam (AI-assisted) | Initial version |
