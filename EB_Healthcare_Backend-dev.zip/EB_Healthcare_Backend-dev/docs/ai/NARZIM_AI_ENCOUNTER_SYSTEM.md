# Narzim AI — Encounter Copilot: System Reference

**Doc status:** living · **Created:** 2026-07-28 by Sarvesh-SocialAngel · **Updated:** 2026-08-13 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Document type** | System Reference (living document) |
| **Component** | Encounter Copilot ("Analyze" pill + "Ask Narzim AI" chat) |
| **Status** | Current — verified directly against the running code |
| **Last verified against code** | 2026-08-13 (against `dev` @ `450aace`) |
| **Governing ADRs** | ADR-030 (curated LLM tool access), ADR-034 (encounter chat persistence), ADR-026 (LLM provider allowlist), ADR-029 (patient clinical summary) |
| **Governing rules** | `CLAUDE.md` Rules 4, 5, 6, 7, 9, 10 |
| **Supersedes** | `ENCOUNTER_COPILOT_AGENT_DESIGN.md`, `ENCOUNTER_COPILOT_AGENT_PLAN.md`, `copilot-revised-plan.md`, `ENCOUNTER_FILL_FORM_AUDIT.md` — all four deleted 2026-07-28; content consolidated here (see §9) |

**Maintenance policy:** if this document and the code ever disagree, the code is authoritative.
Every claim below was checked against a specific file and line at the verification date above,
not carried forward from memory or an earlier plan. Update this document when the
implementation changes materially — do not let it drift the way its predecessors did.

## Changes since the previous verification (2026-07-29 → 2026-08-13)

Verified against `dev` @ `450aace`. **Only merged work is described in this document** —
anything still in an open PR is listed at the end of this section, so this file never
claims behaviour the running system does not have.

| Landed | What changed | Where |
|---|---|---|
| 2026-07-30 | Paediatric drug safety, unexcluded contraindications, duplicate-order guard | `4458b33` |
| 2026-07-30 | Consolidated AI record for signed encounters (transcript + chat + suggestions) | `9daa464` |
| 2026-07-30 | AI Settings language overrides dropped — output language now comes from the ComplianceProfile alone | `836b40f` |
| 2026-07-31 | Non-clinical chat attachments refused; AI output language fixed | `b9e960f` |
| 2026-07-31 | "Fix speakers" correction now actually persists | `1834afe` |
| 2026-08-04 | **Analyze is idempotent** — a re-run with nothing clinically material changed reuses the previous result instead of re-billing a call | `c778ad5`, design in `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` |
| 2026-08-04 | Prompt reads and tool specs cached; `Cached` status and `prompt_hash` on AI Prompt Log | `7892ae8` |
| 2026-08-04 | Agent instrumented; discarded catalogs no longer resolved on the agent path | `baa04f5` |
| 2026-08-12 | ASR moved to `nova-3` + `language=multi` + drug keyterm boosting | `ASR_TRANSCRIPT_AUDIT.md` |

⚠️ **§3's sequence diagram is now stale on one point:** it annotates the agent loop with
"send ENTIRE growing message list (no prompt caching)". Prompt/tool-spec caching landed in
`7892ae8`. Re-verify that note before relying on it.

**Tried and reverted — do not re-attempt without reading why:**

- **Tool-call batching** (`ef0f3df`, reverted in `34171e7`).
- **Streamed Analyze over SSE** (`27b435f`, reverted in `a711e66`) — nginx buffering could not
  be verified, so the surface was withdrawn. Design and measurements are deliberately retained
  in that design document, which was removed 2026-08-13 and remains in git history.

**Registry size:** 36 entries in `services/ai_tools.py::TOOL_REGISTRY` at this verification.

### Not yet on `dev` — open PRs

- **PR #301 — prescription grounding + AI Clinical Considerations.** Removes the prompt
  permissions that let a diagnosis authorise a medication and let the model infer a standard
  adult strength; adds transcript-evidence validation on `add_medication`, an examination-claim
  guard, a demographics guard, and a new `add_clinical_consideration` tool. Root-caused on
  `HLC-ENC-2026-00152`, where an unordered polyethylene glycol prescription and an
  "On exam we concluded…" narrative reached a **signed** record.
- **PR #373 (frontend)** — the paired "AI Clinical Consideration — Requires Clinician Review"
  section that keeps such suggestions out of the signed note.

Fold both into the body of this document when they merge.

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Scope and Boundaries](#2-system-scope-and-boundaries)
3. [Architecture — Request Flow](#3-architecture--request-flow)
4. [Component Reference — Tool Registry](#4-component-reference--tool-registry)
5. [Prompt Inventory](#5-prompt-inventory)
6. [End-to-End Clinical Workflow](#6-end-to-end-clinical-workflow)
7. [Cost Model](#7-cost-model)
8. [Data Model](#8-data-model)
9. [Technical Debt and Open Issues](#9-technical-debt-and-open-issues)
10. [Source Code Map](#10-source-code-map)
11. [References](#11-references)

---

## 1. Executive Summary

Narzim AI is an in-encounter, tool-calling assistant reachable two ways in the product UI: the
**"Analyze" pill** (reviews the whole encounter and fills the draft in one pass) and the
**free-text chat box** ("Ask Narzim AI anything about this encounter"). Both surfaces are
served by the same backend mechanism — a bounded agent loop that grants an LLM access to a
fixed set of typed, code-defined functions ("tools"). Some tools read real clinical data (labs,
prior encounters, the live transcript, the facility's vaccine catalog); others stage a **draft
suggestion** into the encounter form. The model never queries the database directly, never
receives or generates raw SQL, and never finalizes a clinical decision — every write-tool
result is a suggestion the physician must review, edit, or discard.

⚠️ **CORRECTED 2026-08-13 — "persistence happens only on Save or Sign" is true for 18 of the 23
write tools, not all of them.** The five patient-level tools (`add_allergy`,
`add_patient_medication`, `add_medical_history`, `add_surgical_history`, `set_patient_summary`)
return a `patient_draft` patch which the frontend auto-applies to the permanent `Patient` record
via `updatePatient.mutate(...)` (`encounter-screen.tsx:3217-3263`) — before Save, before Sign,
with no confirmation. **The backend tool layer is clean**: `services/ai_tools.py` contains zero
DB mutations, verified by exhaustion. The bypass is entirely frontend. See
`CURRENT_SYSTEM_AUDIT.md` §8.5 and `CLAUDE.md` Rule 6.

---

## 2. System Scope and Boundaries

Two distinct AI chat surfaces exist in this product. They must not be conflated when
discussing "Narzim AI" — they have different backends, different data scope, and different
persistence.

| Surface | Frontend component | Backend entry point | Scope | Chat persisted? |
|---|---|---|---|---|
| **Encounter Copilot** (this document) | `NarzimAIChatBar.tsx` | `api/v1/ai/api.py::ask_copilot` / `analyze_encounter` | The current encounter and its one patient | Yes — `AI Encounter Chat Message` (ADR-034) |
| Patient-portal lab assistant (separate feature, out of scope here) | `lab-ai-sidebar.tsx` | `api.ai.lab_result_summary.ask_lab_question` | The whole patient record, read-only | Yes — `AI Patient Chat Message`¹ |

¹ **Naming note:** this repository contains two different ADRs both numbered "030" —
`adr-030-llm-curated-tool-access.md` (governs the Encounter Copilot tool registry documented
here) and `adr-030-ai-patient-chat-persistence.md` (governs the patient-portal surface above).
This is a genuine numbering collision, not an error in this document. Any future reference to
"ADR-030" should specify which. See §9, item 1.

---

## 3. Architecture — Request Flow

Verified against `api/v1/ai/api.py`, `services/ai_tools.py`, and `integrations/openai.py`.

```mermaid
sequenceDiagram
    participant Dr as Physician
    participant FE as NarzimAIChatBar<br/>(encounter-screen.tsx)
    participant BFF as Next.js BFF<br/>/api/ai/analyze or /api/ai/encounter-chat
    participant API as ask_copilot / analyze_encounter<br/>(api/v1/ai/api.py)
    participant Loop as ask_copilot_agent()<br/>(integrations/openai.py)
    participant Tools as execute_tool()<br/>(services/ai_tools.py)
    participant DB as Frappe / MariaDB

    Dr->>FE: click "Analyze" or type a question
    FE->>BFF: POST {encounter, transcript/prompt, history}
    BFF->>API: whitelisted call, injects physician's own Bearer token
    API->>API: _require_auth + _require_encounter_read
    API->>API: allow_write = has_permission(Encounter, "write")
    API->>API: ctx = build_encounter_context(encounter)
    API->>Loop: ask_copilot_agent(prompt, history, ctx, tools)

    loop up to _MAX_TOOL_ITERATIONS = 20 round-trips
        Loop->>Loop: send ENTIRE growing message list (no prompt caching)
        Loop-->>Loop: model requests one or more tool calls
        Loop->>Tools: execute_tool(name, args)
        alt READ tool
            Tools->>DB: query (bounded/summarised, Rule 5)
            DB-->>Tools: result
        else WRITE tool
            Tools-->>Tools: validate args against schema
            Note over Tools: returns a suggestion object —<br/>NEVER writes to the DB
        end
        Tools-->>Loop: tool result fed back as a "tool" message
    end
    Loop-->>Loop: model replies with final text, loop ends

    Loop-->>API: {reply, usage, cost_usd, tools_used}
    API->>DB: log_prompt_call() → one AI Prompt Log row<br/>(model, tokens, cost, tools_used — no content, Rule 10)
    API->>DB: persist turn → AI Encounter Chat Message (ADR-034)
    API-->>FE: {reply, actions[], patient_draft, follow_up}
    FE->>FE: onApplyActions → fillFormFromSuggestions → applySuggestionToEnc
    Note over FE: each suggestion lands in the draft with a ✦ AI badge, editable
    FE-->>Dr: reply shown; draft updated

    Dr->>FE: review, edit, or discard each item
    Dr->>API: Save (draft) or Sign & close encounter
    Note over API,DB: THIS is the only step that persists anything (Rule 6)
```

This chain honours Rule 4 (as refined by ADR-030): LLM → typed/scoped/audited tool → Frappe
(read) or suggestion (write) → physician → database. At no point does the model have a path to
the database that bypasses a named, reviewed tool function.

---

## 4. Component Reference — Tool Registry

Source of truth: `services/ai_tools.py::TOOL_REGISTRY`. Treat this table as a snapshot — consult
the file directly if a discrepancy is suspected; it will change faster than this document is
updated.

### 4.1 Read tools

Query real Frappe data and return bounded, summarised JSON (Rule 5 — never a full dump).

| Tool | Returns | Bound / notes |
|---|---|---|
| `get_patient_labs` | This patient's recent completed lab results | `_MAX_LABS = 8`, `_MAX_LAB_ITEMS_PER_TEST = 6` |
| `get_previous_encounters` | Summaries of prior encounters (diagnosis, orders, plan, date, status) | `_MAX_PREV_ENCOUNTERS = 5`, default 3 |
| `get_current_transcript` | The live doctor–patient transcript for this encounter | `_MAX_TRANSCRIPT_CHARS = 6000` |
| `get_encounter_state` | Everything currently in the draft — symptoms, diagnoses, medications, labs, procedures, therapies, vitals, allergies | The model is instructed to call this before asserting an absence (e.g. "no vitals recorded") |
| `get_appointment_details` | The Patient Appointment this encounter originated from | `has_appointment: false` for a walk-in with no linked appointment |
| `get_vaccine_catalog` | Every vaccine on this facility's own immunization schedule | Blocking catalog check — `add_vaccine` cannot proceed without a match (see 4.2) |
| `get_lab_analysis` | AI interpretation of one named lab test | Cached if previously analyzed; generated fresh otherwise |
| `search_medication_catalog` | Real `Medication` master rows matching a name (generic_name substring) | **Added 2026-07-28.** Non-blocking catalog check — `add_medication` still proceeds on zero matches (see 4.2); mirrors `encounters/api.py::search_medications`, the same lookup the physician's own medication search box uses |
| `search_lab_catalog` | Real `Lab Test Template` rows matching a name | **Added 2026-07-29.** Non-blocking; watch for a COMBINED entry (e.g. `"ESR and CRP"`) that covers what might look like two separate tests |
| `search_diagnosis_catalog` | Real `Diagnosis` rows matching a name | **Added 2026-07-29.** Non-blocking; entries here often already carry their ICD-10 code baked into the name — a match should be reused verbatim, not re-coded |
| `search_procedure_catalog` | Real `Clinical Procedure Template` rows matching a name (includes imaging) | **Added 2026-07-29.** Non-blocking |
| `search_therapy_catalog` | Real `Therapy Type` rows matching a name | **Added 2026-07-29.** Non-blocking |
| `search_complaint_catalog` | Real `Complaint` rows matching a name | **Added 2026-07-29.** Non-blocking; backs `add_symptom` only, not `add_chief_complaint` (a synthesized sentence, not a catalog pick) |

All six `search_*_catalog` tools share one shape: `require_permission` on the target doctype, a bounded `frappe.get_all(..., filters=[["disabled","=",0], [<name_field>, "like", f"%{query}%"]], limit_page_length=10)`, returning `{"matches": [...], "match_count": N}`. None of them touch anything beyond a read (Rule 4/5).

### 4.2 Write tools

Validate arguments against a JSON schema and return a draft suggestion object. **No write tool
touches the database.**

| Tool | Draft target | Database-validated at suggestion time? |
|---|---|---|
| `add_medication` | `orders.rx` | **Non-blocking, added 2026-07-28.** Model calls `search_medication_catalog` first; on a match it reuses the exact catalog name/dosage_form/strength, on zero matches it still proceeds with its own free-text `drug_name` (unlike `add_vaccine`, an unmatched medication is not blocked — the physician can add it as new) |
| `add_lab` | `orders.labs` | **Non-blocking, added 2026-07-29.** Model calls `search_lab_catalog` first; same reuse-or-propose-new pattern as medications |
| `add_procedure` | `orders.procedures` | **Non-blocking, added 2026-07-29.** Model calls `search_procedure_catalog` first; same pattern |
| `add_therapy` | `orders.therapies` | **Non-blocking, added 2026-07-29.** Model calls `search_therapy_catalog` first; same pattern |
| `add_diagnosis` | `diagnoses` | **Non-blocking, added 2026-07-29.** Model calls `search_diagnosis_catalog` first; a match is reused verbatim (ICD-10 code included, if the catalog entry has one) rather than re-derived |
| `add_symptom` | `symptoms` | **Non-blocking, added 2026-07-29.** Model calls `search_complaint_catalog` first; same pattern |
| `add_vital` | `vitals.*` | Not applicable — numeric field, no catalog |
| `add_chief_complaint` | `chiefComplaint` | — |
| `add_review_details` | Review Details section | — |
| `add_follow_up` | Follow-up section | Validated against a fixed enum (`_VALID_FOLLOWUP_IN`), not a database catalog |
| `add_vaccine` | `orders.vaccines` | **Yes** — must match an entry from `get_vaccine_catalog` (`_match_immunization_template`) |
| `add_allergy` | Patient-level (`patient_draft.allergies`) | — |
| `add_patient_medication` | Patient-level home-medication history (`patient_draft.medications`) — distinct from `add_medication`, which records this visit's prescription | — |
| `add_medical_history` / `add_surgical_history` | Patient-level history | — |
| `set_patient_summary` | Patient-level summary (overwrite semantics, not append) | — |
| `remove_*` | Mirrors each `add_*` above | Removes a previously-suggested draft item |

**Finding, stated directly (updated 2026-07-29): every write-tool category the model can suggest
or add now has a matching catalog check, in both the Analyze/Chat agent and the incremental
suggestions/SOAP engine (§5).** `search_medication_catalog` (2026-07-28) was the first;
`search_lab_catalog`, `search_diagnosis_catalog`, `search_procedure_catalog`,
`search_therapy_catalog`, and `search_complaint_catalog` (all 2026-07-29) followed, each
identical in shape. Every one of these is **non-blocking** — a zero-match result still lets the
model propose a new entry, which the physician can accept as a new master record (per
`_CREATABLE_MASTERS` in `api/v1/ai/api.py`). `add_vaccine` remains the sole **blocking**
exception: a non-match is refused outright, never auto-created, because a vaccine needs an
admin-configured dose schedule a bare name can't supply. The formerly-dormant
`autopopulate_encounter()` mechanism that used to be the only thing doing this kind of matching
(and was unreachable from the UI) has been fully removed — see §9, item 2.

---

## 5. Prompt Inventory

Runtime prompt files live under `prompts/*.txt`, loaded by
`integrations/openai.py::_load_prompt` from `<repo_root>/prompts/<name>.txt`. Prompts are
edited directly as text files; none are embedded in Python source. **`prompts/README.md`**
(repo root, added 2026-07-29) is the maintained manifest of every file below — check there
before assuming a file in `prompts/` is live, and update it in the same commit as any add/
rename/delete.

Only **7 prompt files** remain, and every one is live — confirmed by tracing each to a real,
reachable caller. `chat-v1.txt`, `encounter-autopopulate-v1.txt`, and `suggest-v1.txt` were all
all deleted 2026-07-28 after confirming zero live references, and unlike an initial narrower pass earlier that same day (which deleted just the prompt files, leaving the dead Python functions that loaded them),
`chat_reply()`, `autopopulate_encounter()`, `build_master_catalogs()`,
`build_autopopulate_message()`, `parse_autopopulate()`, `resolve_prescription_fields()`, and
every helper that fed only them were also fully removed from `integrations/openai.py`,
`integrations/anthropic.py`, `api/v1/ai/api.py`, and `services/ai.py` the same day — there is
no longer any dangling `_load_prompt(...)` call pointing at a missing file (§9, item 2).

| File | Consumer | Purpose |
|---|---|---|
| `ask-copilot-v2.txt` | `ask_copilot_agent()` — serves **both** the Analyze pill and the chat box | Agent system prompt: role, scope, tool-usage rules, the 2026-07-28 scope-restriction rule, and (2026-07-29) six `search_*_catalog` tool-usage rules covering every write-tool category |
| `soap-v1.txt`, `suggest-v2.txt` | `generate_soap_draft` / `generate_suggestions` | Pre-agent, single-call suggestion generators — still live (see §9, item 4). **2026-07-29: both now receive the real Medication/Lab Test Template/Therapy Type/Clinical Procedure Template/Diagnosis/Complaint catalogs** (`suggest-v2` gets all six; `soap-v1` gets five — it has no `orders.therapies`/`orders.procedures` target) and instruct the model to reuse an exact match rather than inventing a near-duplicate. Previously only labs had any catalog awareness here, and even that instruction was self-contradictory ("do NOT invent" vs. the system prompt's own "you may propose new") — fixed to be consistently non-blocking. `soap-v1.txt` also previously had **zero** validated-value lists at all (not even the `rx_periods`/`rx_dosages` enums `suggest-v2` already had), risking the same "one bad value 400s the whole encounter save" bug class fixed 2026-07-24 for chat — also fixed 2026-07-29. |
| `review-details-v1.txt` | `generate_review_details()` | Patient-facing visit summary shown at Sign |
| `resegregate-v1.txt` | `resegregate_transcript()` | Rebuilds a garbled speaker-diarized transcript |
| `medication-fields-v1.txt`, `lab-fields-v1.txt` | `infer_medication_fields` / lab-field inference | Used by the manual "create new medication/lab" flow (`create_master`), not the encounter agent |

The `_ANALYZE_PROMPT` constant sent as the user message for "Save & analyze" is Python source,
not a `.txt` file — `api/v1/ai/api.py`, near line 955. It instructs the agent to review the
entire transcript and conversation, call every relevant `add_*` tool for anything not already
present, and always call `set_patient_summary` (changed 2026-07-27; previously skipped for
visits assessed as routine).

---

## 6. End-to-End Clinical Workflow

The room-state machine below is shared across the dashboard queue, the patient chart, and the
encounter agent. Verified by execution, not inferred from code inspection alone.

```mermaid
flowchart TD
    A["1. Book (atomic)<br/>appointments/api.py::book_appointment_for_patient<br/>Patient + Appointment created in ONE transaction"]
    A --> A2["status: Open<br/>room: Arriving Soon"]
    A2 --> B["2. Front desk confirms<br/>update_status → Confirmed"]
    B --> B2["room: Waiting Room"]
    B2 --> C["3. Nurse records vitals<br/>POST /api/vital-signs<br/>Vital Signs (Draft), linked to the appointment"]
    C --> C2["check_in_patient → status: Checked In<br/>room: Nursing Room"]
    C2 --> D["4. Doctor starts encounter<br/>encounters/api.py::start_encounter(appointment)<br/>idempotent"]
    D --> D2["Draft Vital Signs from step 3 AUTO-LINKED<br/>onto the new encounter<br/>(_link_vitals_to_encounter)"]
    D2 --> D3["Healthcare core's on_update sets the<br/>appointment's OWN status to Closed<br/>the instant the draft exists — not only once signed"]
    D3 --> D4["room: Practitioner Room"]
    D4 --> E["5. Doctor uses Narzim AI"]
    E --> E1["Analyze pill → analyze_encounter<br/>whole transcript, fills every relevant<br/>field via tools"]
    E --> E2["Ask Narzim... → ask_copilot<br/>one typed question, same tool registry,<br/>persisted as chat"]
    E1 --> F["Every suggestion lands as an editable<br/>draft item with a ✦ AI badge —<br/>nothing is saved yet (Rule 6)"]
    E2 --> F
    F --> G{"6. Doctor reviews, edits,<br/>then decides"}
    G -->|"Sign & close encounter"| H["complete_encounter()<br/>chief_complaint required<br/>docstatus 0 → 1 (submit)"]
    H --> H2["auto-submits any Draft Vital Signs<br/>creates native Immunization docs for admin'd vaccines<br/>Healthcare core's on_submit creates<br/>lab orders/invoicing from the signed draft"]
    G -->|"Cancel"| I["cancel_encounter()<br/>cascades to cancel the linked appointment too"]
    I --> I2["cancels an UNPAID linked invoice —<br/>a PAID one is left for a deliberate refund<br/>via Billing's credit-note flow<br/>(fixed 2026-07-27/28)"]

    style F fill:#e0f2f1,stroke:#006067
    style H2 fill:#e8f5e9,stroke:#2e7d32
    style I2 fill:#fce4ec,stroke:#c62828
```

---

## 7. Cost Model

> **⚠️ THIS SECTION'S NUMBERS ARE STALE.** `AI_TOKEN_COST_MODEL.md` was removed 2026-08-13,
> superseded by direct measurement. See [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) §15,
> which is authoritative on cost and performance. Measured 2026-08-13 across 302 agent calls:
> **avg 53,414 input tokens** (not 21,748), **avg 16.0 s** (not 10.7 s), max **98.6 s** /
> **265,189 tokens**, and **46% of all agent input is cached** — so the per-call cost below is
> overstated. The Anthropic 8× pricing bug is confirmed and still live. Round-trips are typically
> 1–5, not 15.4.

**Formula** (`integrations/openai.py::_estimate_cost`, `_pricing_for_model`):

```
cost_usd = (tokens_in / 1,000,000 × input_rate) + (tokens_out / 1,000,000 × output_rate)
```

Model pricing is resolved by **longest-prefix match**, not exact string comparison. OpenAI
returns a dated snapshot identifier (e.g. `gpt-5-mini-2025-08-07`), which would silently miss
an exact-match lookup and fall back to an incorrect, more expensive default. This was a real
defect, corrected 2026-07-13 — see the code comment on `_pricing_for_model`.

```python
_COST_PER_MTOK = {
    "gpt-4o":      (2.5,  10.0),
    "gpt-4o-mini": (0.15,  0.60),
    "gpt-5":       (15.0, 60.0),
    "gpt-5-mini":  (0.25,  2.0),   # currently configured model — AI Settings.openai_model
}
```

**Cost driver:** the agent loop is a standard Chat Completions loop with no prompt caching.
Every tool round-trip re-transmits the entire accumulated message list for that turn (system
prompt plus every prior tool call and result). Consequently, `tokens_in` for a single Analyze
invocation is the **sum across every round-trip**, not the size of one call's input.

**Measured example** (fever-and-cough transcript, executed live 2026-07-28 against a disposable
test encounter, subsequently deleted):

| Metric | ~~2026-07-28 single run~~ | **Measured 2026-08-13, n=302** |
|---|---|---|
| Tool calls this turn | 18 | — |
| Round-trips | ~19 | typically **1–5**; 20-cap hit on real encounters |
| tokens_in (summed) | ~~166,672~~ | **avg 53,414** · max **265,189** |
| tokens_out | 1,813 | avg **703** |
| Cost | ~~$0.0453~~ | **overstated** — `_estimate_cost` ignores the 46% of input that is cached |
| Latency | ~~50.4 s~~ | **avg 16.0 s** · max **98.6 s** |

**~~Conclusion~~ — SUPERSEDED.** The 2026-07-28 single-run figures above were one worst-case
Analyze, not a representative one. Verified 2026-08-13 across 302 logged calls: a typical turn is
1–5 round-trips at ~16 s, and **87–96% of input tokens are cached** on multi-trip calls — so the
"no caching discount applies" claim is false and the logged cost is overstated. The
retransmission mechanism itself is confirmed (`tokens_in ≈ round_trips × ~11,500`).
**`docs/ai/CURRENT_SYSTEM_AUDIT.md` §15 is authoritative on all cost and latency numbers.**

Every invocation is logged to **`AI Prompt Log`** (`services/ai.py::log_prompt_call`):
encounter, patient, model, tokens_in, tokens_out, cost_estimate_usd, latency_ms, status,
tools_used (names only). Prompt text, model replies, and transcript content are never logged
(Rule 10).

---

## 8. Data Model

Doctypes currently installed and in active use, plus scaffolding that exists but is not wired
in.

| Doctype | Role |
|---|---|
| `AI Encounter Chat Message` | Persisted Narzim encounter chat (ADR-034) — role, content, `actions_json`, `kind` (chat\|analysis), model/tokens/latency |
| `AI Prompt Log` | Audit row for every LLM invocation (cost/tokens/latency/tools_used) — no content |
| `AI Settings` (Single) | `llm_provider`, `openai_model` (currently `gpt-5-mini`), `anthropic_model`, `llm_max_tokens_out`, `enable_suggestions` |
| `AI Prompt Template` | Runtime-editable prompt storage (ADR-031) — whether this is read at runtime versus aspirational was not independently verified in this pass; confirm before relying on it |
| `AI Patient Clinical Summary` | Separate cross-encounter patient summary feature (ADR-029) — distinct from `set_patient_summary`'s per-visit summary string |
| `AI Subscription Plan` (+ `...Company`, `...Seat`), `AI Usage Counter` | Credit/seat metering scaffolding (ADR-027) — **doctypes exist but are not wired into the current Phase-1 BYOK model.** Every write-tool and generate-function docstring notes "No credit/seat metering — Phase 1 is BYOK." Confirm before assuming this billing layer is active. |
| `AI Patient Chat Message` | The patient-portal chat surface (§2) — distinct from `AI Encounter Chat Message` |
| `AI Encounter Session`, `AI Transcript Segment` | Live-recording session state and transcript segments (Deepgram ASR) |
| `AI Lab Panel Extraction Panel` | Multi-panel lab report extraction — a separate feature |
| `AI SOAP Draft` | Output of the pre-agent, single-call `generate_soap_draft` path |

---

## 9. Technical Debt and Open Issues

1. **Duplicate ADR numbering.** `adr-030-llm-curated-tool-access.md` and
   `adr-030-ai-patient-chat-persistence.md` share the number "030." Recommendation: renumber one
   the next time either is amended.

2. **RESOLVED 2026-07-28 — orphaned catalog-matching code path fully removed, not just its
   prompt file.** `autopopulate_encounter()`, `build_master_catalogs()`,
   `build_autopopulate_message()`, `parse_autopopulate()`, `resolve_prescription_fields()`,
   `chat_reply()`, and every helper that fed only them (`_resolve_current_vitals`,
   `_resolve_previous_encounters`, `_parse_soap_blob`, `_CATALOG_SPEC`, `_transcript_tokens`,
   `build_autopopulate_context`, `_resolve_output_language`, `_resolve_country`) were deleted from
   `integrations/openai.py`, `integrations/anthropic.py`, `api/v1/ai/api.py`, and `services/ai.py`
   the same day, after confirming (via `bench console` import checks and a full grep sweep) that
   nothing else depended on any of them. Their prompt files (`encounter-autopopulate-v1.txt`,
   `chat-v1.txt`) were deleted the day before. **This mechanism no longer exists in the
   codebase in any form.** The functionality it would have provided (matching every category
   against a real catalog in one pass) is superseded by item 3's per-tool approach, which now
   covers every category individually instead.
   <br><br>
   **Frontend note (not addressed by this pass — a separate repo):** the frontend call chain that
   would have invoked this (`real-provider.ts`'s `autopopulate()` method → `use-copilot.ts` →
   `CopilotHost.tsx`'s `onAutopopulate` prop → `CopilotPanel.tsx`'s unused `_onAutopopulate`
   destructure) is untouched and still dead code in `Healthcare_next_app`. It was already
   unreachable before this backend cleanup; now it would also fail immediately if ever wired up,
   since the endpoint it calls no longer exists. Cleaning that up is a `Healthcare_next_app`-side
   change, out of scope for this pass.

3. **RESOLVED 2026-07-29 (labs/procedures/therapies/diagnoses/symptoms) — every write-tool category now has a non-blocking catalog check, in
   both the agent and the suggestion/SOAP engine.** Medication was first (2026-07-28,
   `search_medication_catalog`). The same day, `suggest-v2.txt`/`soap-v1.txt` were also given real
   Medication/Lab Test Template/Therapy Type/Clinical Procedure Template/Diagnosis/Complaint
   catalogs (§5) — previously only labs had any check there, and it was inconsistently worded.
   The chat agent then received five more tools mirroring `search_medication_catalog` exactly:
   `search_lab_catalog`, `search_diagnosis_catalog`, `search_procedure_catalog`,
   `search_therapy_catalog`, `search_complaint_catalog` (§4.1). Every category — labs, procedures,
   therapies, diagnoses, symptoms, medications — now behaves identically: reuse an exact catalog
   match verbatim when one exists, otherwise propose a new entry (auto-created via
   `create_master` when the physician confirms it). Only `add_vaccine` remains blocking. No
   category has zero catalog awareness anymore.

4. **Two still-live mechanisms outside this document's scope.** `generate_suggestions`
   (`suggest-v2.txt`) drives **incremental suggestions during active recording** via
   `use-copilot.ts`'s `onSuggestions` callback — a separate, currently active pathway from the
   Analyze/Chat agent documented here. This document does not describe its full mechanics in
   detail (batching, focus-splitting, frontend rendering) — read the code directly, or the
   2026-07-21 checklist/audit in git history (both removed 2026-08-13)
   before relying on it, as both predate this document. §5 does now cover its catalog-matching
   behavior specifically (2026-07-29), since that's directly relevant to items 2 and 3 above.

5. **Four documents were deleted 2026-07-28, not merely marked historical, because their
   content was fully superseded:** `ENCOUNTER_COPILOT_AGENT_DESIGN.md` and
   `ENCOUNTER_COPILOT_AGENT_PLAN.md` (dated 2026-07-23; stated a 5-iteration cap where the code
   has 20, listed 6 write tools and 4 read tools where the code has approximately 19 and 7
   respectively, named a `/api/ai/ask` endpoint that does not exist, and listed vaccine support
   as a non-goal despite it being implemented); `copilot-revised-plan.md` (dated 2026-07-01,
   pre-dating the agent architecture entirely); and `ENCOUNTER_FILL_FORM_AUDIT.md` (documented
   the auto-apply/autopopulate mechanism that item 2 above establishes has since been fully
   removed, not merely dead).

6. **`docs/README.md`'s AI Copilot index previously listed 2 of the roughly 8 documents actually
   present in `docs/ai/`.** Corrected alongside this document.

7. **`prompts/README.md` added 2026-07-29** — a manifest of every runtime prompt file, its
   loader function, and the actual whitelisted endpoint that reaches it, kept next to the prompt
   files themselves (not buried in this document) so a maintainer doesn't have to grep the
   codebase to answer "is this prompt still live?" Cross-linked from `docs/README.md`. Update it
   in the same commit as any prompt add/rename/delete — the same discipline items 2 and 5 above
   show what happens when that discipline lapses (a prompt gets deleted, but its wiring, or a
   claim about it, doesn't follow).

---

## 10. Source Code Map

```
Backend (remedisys_healthcare_ai/)
├── api/v1/ai/api.py                     ask_copilot, analyze_encounter, generate_review_details,
│                                        resegregate_transcript, generate_suggestions,
│                                        generate_soap_draft, create_master
├── services/ai.py                       build_encounter_context, log_prompt_call,
│                                        parse_medication_fields (+ _match_catalog_value),
│                                        _resolve_medication_names/_lab_templates/_therapy_types/
│                                        _procedure_templates/_diagnosis_names/_complaint_names
│                                        (2026-07-29 — the six catalog resolvers behind §5's fix)
├── services/ai_tools.py                 TOOL_REGISTRY — every read/write tool, executors + schemas
│                                        (incl. the six search_*_catalog tools, §4.1)
├── integrations/openai.py               ask_copilot_agent (the loop), _estimate_cost,
│                                        _pricing_for_model, _MAX_TOOL_ITERATIONS
├── integrations/anthropic.py            same contract, Claude provider
├── prompts/*.txt                        runtime prompt files (§5), README.md manifest (§9 item 7)
└── remedisys_healthcare_ai/doctype/ai_* every AI doctype (§8)

Frontend (Healthcare_next_app/)
├── src/app/api/ai/analyze/route.ts       "Analyze"/"Labs" pills → analyze_encounter
├── src/app/api/ai/encounter-chat/route.ts  persisted chat load/save
├── src/app/api/ai/autopopulate/route.ts  orphaned (§9, item 2) — now calls a backend endpoint
│                                        that no longer exists at all, not merely unreached
├── src/components/narzim/encounter/NarzimAIChatBar.tsx   the chat UI, real implementation
├── src/components/narzim/encounter/copilot/CopilotHost.tsx / CopilotPanel.tsx
│                                        live transcript/recording panel (separate from chat)
├── src/components/narzim/encounter/copilot/real-provider.ts / use-copilot.ts
│                                        the orphaned autopopulate call site (§9, item 2) —
│                                        untouched by the 2026-07-28 backend cleanup, a separate repo
└── src/components/narzim/encounter/encounter-screen.tsx  fillFormFromSuggestions,
                                         applySuggestionToEnc — where suggestions enter the draft
```

---

## 11. References

**Governing (binding architecture):**
- `docs/adr/adr-030-llm-curated-tool-access.md` — the tool-calling contract
- `docs/adr/adr-034-encounter-chat-persistence.md` — chat persistence design
- `docs/adr/adr-026-llm-provider-allowlist.md` — LLM provider pluggability
- `docs/adr/adr-029-ai-patient-clinical-summary.md` — the separate clinical-summary feature

**Adjacent features** (not covered by this document — consult directly):
  flow (§9, item 4); verify against current code before use
- `docs/ai/ASR_TRANSCRIPT_AUDIT.md` — Deepgram transcription/ASR
- `docs/ai/AI_LAB_REPORT_EXTRACTION.md`, `AI_MULTI_PANEL_LAB_EXTRACTION.md` — lab report
  extraction (unrelated to the encounter agent)
- `docs/adr/adr-027-ai-copilot-credit-metering.md` — billing layer (not active; §8)
- `docs/adr/adr-028-narzim-central-ai-platform.md` — Narzim-as-separate-platform direction
- `docs/adr/adr-031-ai-prompt-template-doctype.md` — runtime-editable prompts (verify if live)

**Session history** (chronological work log, not a reference source):
`prompts/2026-07-*.md` in the prompt archive.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-28 | Sarvesh | Initial version (header backfilled from git history) |
