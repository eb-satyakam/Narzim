# Narzim AI — General Assistant (Sidebar): Design Proposal

**Doc status:** living · **Created:** 2026-07-31 by Divyanshu · **Updated:** 2026-09-08 by Ashutosh (AI-assisted) · **Version:** 1.3

| | |
|---|---|
| **Document type** | Design proposal, now built (see §10) |
| **Component** | Top-level sidebar "Narzim AI" — general, patient-agnostic Q&A assistant with PDF upload |
| **Status** | Live. One post-launch incident fixed 2026-07-30 — see §10 before trusting §4.5's guardrail description on its own |
| **Written against code at** | 2026-07-30 |
| **Governing ADRs** | ADR-026 (LLM provider allowlist), ADR-030 (curated tool access — *not* applicable to this feature, see §3.4), Rule 4/5/6/9/10 in `CLAUDE.md` |
| **Related but distinct** | `docs/ai/NARZIM_AI_ENCOUNTER_SYSTEM.md` — the existing "Ask Narzim AI" encounter copilot. Read §1 below before assuming these are the same feature. |

**Maintenance policy:** once implementation starts, keep this document in sync with the code the
same way `NARZIM_AI_ENCOUNTER_SYSTEM.md` does — if they disagree, the code wins, and this file
gets corrected in the same commit, not left to drift.

## Table of Contents

1. [Naming Collision — Read This First](#1-naming-collision--read-this-first)
2. [What Was Found: Current AI Architecture](#2-what-was-found-current-ai-architecture)
3. [Requirements](#3-requirements)
4. [Proposed Backend Design](#4-proposed-backend-design)
5. [Proposed Frontend Design](#5-proposed-frontend-design)
6. [Reused vs. New — Summary Table](#6-reused-vs-new--summary-table)
7. [Open Questions](#7-open-questions)
8. [Phased Implementation Plan](#8-phased-implementation-plan)
9. [Risks](#9-risks)
10. [Post-Launch Incident — PHI Exposure via Document Upload (2026-07-30)](#10-post-launch-incident--phi-exposure-via-document-upload-2026-07-30)
17. [Domain Scope Gate — §11 Reversed (2026-08-29)](#17-domain-scope-gate--11-reversed-2026-08-29)

---

## 1. Naming Collision — Read This First

The product already has a feature branded **"Narzim AI"** / **"Ask Narzim AI"** — the
in-encounter copilot (`NarzimAIChatBar.tsx`, backed by `api/v1/ai/api.py::ask_copilot`). It is
patient- and encounter-scoped, has tool access to that one patient's clinical data, and persists
chat to `AI Encounter Chat Message`. Full reference: `docs/ai/NARZIM_AI_ENCOUNTER_SYSTEM.md`.

**This document is about a different, new, third surface**: a top-level sidebar item, reachable
from anywhere (not just inside a patient's chart), for general medication/clinical-knowledge
questions with **no patient data in scope at all** — plus PDF upload (e.g. a drug insert) and
per-prompt cost/token visibility. The user has asked for it to also be called "Narzim AI" in the
sidebar. That is fine functionally (this document treats it as a go), but it **will** create
user-facing ambiguity between "Narzim AI" (this new general assistant) and "Ask Narzim AI"
(the existing encounter copilot) unless the two are visually/textually distinguished in the UI
(e.g. sidebar label "Narzim AI" vs. the in-encounter label stays "Ask Narzim AI", plus maybe a
one-line subtitle "General medication assistant — no patient data" on first open). Flagged here;
see §7 Q1.

A second, pre-existing naming collision (unrelated to this feature, noted for completeness
because it shows up in file/ADR names below): the repo has two different ADRs both numbered
"030" (`adr-030-llm-curated-tool-access.md` and `adr-030-ai-patient-chat-persistence.md`).

---

## 2. What Was Found: Current AI Architecture

Full detail lives in `NARZIM_AI_ENCOUNTER_SYSTEM.md`; this section only extracts what's directly
reusable for the new feature, plus corrections to stale claims elsewhere.

### 2.1 CLAUDE.md is stale on this subsystem — correct this before trusting its file map

`CLAUDE.md` §6 labels `api/v1/ai/api.py` a "🔴 Phase 5 stub" and several `services/*.py` files as
empty stubs. **This is wrong.** `api/v1/ai/api.py` is 1,358 lines of built, live functionality
(`ask_copilot`, `analyze_encounter`, chat persistence, document upload-and-analyze, etc.), and
`services/ai.py`, `services/ai_tools.py`, `services/lab_extraction.py`,
`services/patient_clinical_summary.py` are all fully built. The AI custom-doctype list in
`CLAUDE.md` §7 (5 doctypes) is also incomplete — at least `AI Encounter Chat Message`,
`AI Patient Chat Message`, `AI Patient Clinical Summary`, `AI Usage Counter`,
`AI Subscription Plan(+Company/Seat)`, `AI Prompt Template`, `AI Lab Panel Extraction Panel` also
exist. Recommend a `CLAUDE.md` refresh as a separate follow-up (not part of this feature) — do
not plan new work off `CLAUDE.md`'s AI-related file map without checking the code directly.

### 2.2 Multi-provider abstraction — already built, directly reusable

`services/llm.py::get_llm_client()` returns either `integrations/anthropic.py` or
`integrations/openai.py` based on `AI Settings.llm_provider`, both implementing the same
function names. This is exactly ADR-026's pluggable-allowlist mechanism, already working, and is
what the new feature should call through — **no new provider-selection code needed.**

There is a real, pre-existing wrinkle worth not repeating: **cost-per-model pricing is
duplicated in 4+ places** (`integrations/anthropic.py`, `integrations/openai.py`,
`services/lab_extraction.py`, `services/patient_clinical_summary.py`), and two of those
duplicates hardcode Sonnet pricing regardless of the actually-configured provider — a live bug.
**The new feature must not add a 5th copy.** It should call the cost estimator that already
lives inside whichever adapter module `get_llm_client()` returns (`_estimate_cost` /
`_pricing_for_model` in each integration file), the same way `ask_copilot_agent` and
`generate_suggestions` already do (both return `cost_usd` computed internally, not by the
caller).

### 2.3 Closest existing precedent: `answer_lab_question`

`integrations/{anthropic,openai}.py::answer_lab_question(system, user, *, max_tokens=700) ->
{"text", "model", "tokens_in", "tokens_out"}` is a plain single/multi-turn text Q&A call with
**no tool access at all** — the patient-portal lab assistant (`lab-ai-sidebar.tsx` →
`api.ai.lab_result_summary.ask_lab_question`) uses it today for patient-scoped lab questions.
Structurally, this is the right shape for the new feature too (system prompt + user turn +
history, no tools, plain request/response) — just needs a sibling function that (a) doesn't
receive patient lab context in its system prompt, and (b) can optionally take an uploaded
document.

### 2.4 PDF handling precedent: `summarize_document`

`integrations/{anthropic,openai}.py::summarize_document(files) -> dict` already sends a PDF's raw
bytes as a native multimodal content block (Claude "document" block / OpenAI "file" part,
base64) directly to the model — **no OCR step**, synchronous, single request/response. This is
the established, working mechanism for "upload a PDF, have the model read it" anywhere in this
codebase (also used by `api/v1/ai/api.py::upload_and_analyze_document`, the encounter copilot's
file-attach feature). The async version (`services/lab_extraction.py`'s RQ-job pipeline) exists
only because lab-report extraction has a heavier review/matching workflow — not needed here.
**The new feature should follow the synchronous pattern**, not the async one.

`pypdf` (`services/pdf_pages.py`) exists for local text-layer extraction but is used only as a
supplementary cross-check elsewhere, never as the primary reading mechanism — no need to invoke
it for this feature at all; native multimodal upload is sufficient and simpler.

### 2.5 Chat persistence precedent: `AI Encounter Chat Message`

There is **no separate "session" doctype** for chat in this codebase — `AI Encounter Chat
Message` (the existing per-turn chat log for the encounter copilot) has no sibling "session"
doctype; a conversation is just every message row sharing the same `thread` (a client-generated
UUID, `Data` field, not a Link) filtered by `encounter`. The "history" sidebar in
`NarzimAIChatBar.tsx` is built by grouping messages by `thread` server-side
(`get_encounter_threads`), not by reading a session doctype. **This repo's own precedent argues
against inventing a new "Session" doctype for the new feature too** — one message doctype with a
`thread` field is simpler, consistent with the existing pattern, and sufficient (see §4.1).

### 2.6 Existing-but-unwired: `AI Usage Counter` / `AI Subscription Plan`

`AI Usage Counter` (`user`, `plan` [Link, **required**], `date`, `credits_used`, `tokens_used`,
autoname `{user}-{date}`) already models exactly "how much a user consumed, per day" — but every
write-tool docstring in the codebase notes "Phase 1 is BYOK — no credit/seat metering," and
`plan` being a required Link to `AI Subscription Plan` (itself unwired scaffolding, ADR-027)
means this doctype cannot be populated today without first standing up subscription-plan
records that don't exist yet. **Recommendation: do not wire the new feature's per-user token
visibility through `AI Usage Counter`.** It's the wrong tool for a "just show me who used how
much" requirement — that's a straightforward aggregation over `AI Prompt Log` (which already has
`tokens_in`/`tokens_out`/`cost_estimate_usd` per row), not a billing/metering concern. Revisit
`AI Usage Counter` only if/when real seat-based billing (ADR-027) gets built.

---

## 3. Requirements

Confirmed with the user before writing this document:

1. New top-level sidebar item, "Narzim AI" — reachable independent of any patient/encounter
   context.
2. General medication/clinical-knowledge Q&A. **No patient data exposed** — this assistant must
   have zero path to any patient/encounter/PHI data (stronger than "must not leak it" — it
   should be architecturally incapable of reaching it, by simply never being given any patient
   context or DB tool access).
3. User can upload a PDF (e.g. a drug package insert) and ask questions about it.
4. Per-prompt cost tracked (using the existing `AI Prompt Log` doctype).
5. Token usage tracked per user, so an admin can see who used how many tokens (visibility only —
   **no hard cap/blocking for v1**, confirmed by the user).
6. Multi-provider — must work the same regardless of whether `AI Settings.llm_provider` is
   Anthropic or OpenAI (already satisfied by reusing `get_llm_client()`, §2.2).
7. Chat sessions are stored/persisted (ChatGPT-style: a history of past conversations, resumable).
8. **Confirmed decisions**: sessions are **private per user** (not clinic-shared); cost/token
   tracking is **visibility only, no enforcement**, but must support a **per-user usage
   breakdown** for admins; **reuse the shared `AI Settings` model/provider config** — no separate
   model override for this feature in v1.

---

## 4. Proposed Backend Design

### 4.1 New doctype: `AI Narzim Assistant Message`

One doctype, no separate session doctype (§2.5). Modeled directly on `AI Encounter Chat Message`
with the encounter/patient/appointment/practitioner fields removed (there is no patient context)
and cost/attachment fields added (this feature needs per-message cost, which the encounter chat
message doctype doesn't currently store — it relies on the separate `AI Prompt Log` row for
that; here we want it inline too so the frontend can show a per-message cost chip without an
extra join).

| Field | Type | Notes |
|---|---|---|
| `naming_series` | Select, default `AINAM-.YYYY.-.#####` | |
| `thread` | Data, `search_index` | Client-generated UUID, same convention as `AI Encounter Chat Message.thread` — one thread = one conversation |
| `session_user` | Link User, `read_only`, set in `before_insert` | Owner of this message/thread. Drives the private-per-user visibility rule (§4.4) |
| `role` | Select `user\nassistant` | |
| `content` | Text | The message text |
| `attached_file` | Attach, optional | Set only on the `user` turn that included a PDF upload |
| `model` | Data, `read_only` | e.g. `claude-sonnet-4-6`, `gpt-5-mini` |
| `prompt_version` | Data, `read_only` | |
| `tokens_in` / `tokens_out` | Int, `read_only` | |
| `cost_estimate_usd` | Currency, `read_only` | Computed via the provider's existing `_estimate_cost`, not a new pricing table (§2.2) |
| `latency_ms` | Int, `read_only` | |
| `prompt_log` | Link `AI Prompt Log`, `read_only` | Cross-reference to the audit row (§4.2) |

Permissions: System Manager (full), EB_Practitioner / EB_Nurse / EB_Front Desk /
EB_Clinic Staff / EB_Healthcare Admin / Physician (create + read + write, no delete) — matching the
existing `AI Prompt Log`/`AI SOAP Draft` shape (§12 of the backend deep-dive).

**Corrected 2026-09-07.** This line previously gave EB_Healthcare Admin **read only**, on the
reasoning that admin needed the doctype solely for §4.3's usage breakdown. That was written before
open question 2 (§7) resolved to "visible to every role", and the resolution was applied to
EB_Front Desk / EB_Clinic Staff and to the frontend nav — which became unconditional — but never
to the admin row. An admin-role account therefore saw Narzim GPT in the sidebar, typed a message,
and got `You do not have permission to perform this action.` from
`api/v1/narzim_assistant/api.py`'s `require_permission(..., "create")`. Admin now holds
create + read + write like every other staff role. `delete` stays 0 for all of them; the read-only
usage-breakdown rationale is unchanged and still holds — admin simply also gets to use the
assistant.

### 4.2 Reuse `AI Prompt Log`, add one purpose value

Add `Narzim Assistant Chat` to the `purpose` Select options
(currently: `Lab Extraction\nImaging Transcription\nMulti-Panel Extraction\nLab Result
Summary\nPatient Lab Summary\nReport Lab Summary\nPatient Clinical Summary\nLab Chat\nCopilot
Transcribe\nCopilot Suggestions\nCopilot SOAP Draft\nCopilot Chat\nCopilot Review Details`).
`patient`/`encounter`/`lab_test`/`service_request` are left blank for this purpose (all are
optional Link fields already — no schema conflict). `source_file` is populated when a PDF was
attached to that turn.

**Do not reuse `log_prompt_call()`** as-is — it hardcodes `encounter` as a required parameter and
does an unconditional `Patient Encounter` lookup (`services/ai.py:234`). Add a small sibling,
`log_prompt_call_general(*, purpose, model, tokens_in, tokens_out, cost_usd, latency_ms,
source_file=None, error=None)` in the same module, sharing the structured-logger line but
skipping the encounter/patient resolution. This avoids duplicating the whole function while not
forcing an encounter-shaped call site to pretend it has one.

### 4.3 Per-user usage visibility (no `AI Usage Counter`, §2.6)

A single admin-facing whitelisted method, e.g. `get_narzim_assistant_usage_summary(from_date,
to_date)`, gated to System Manager / EB_Healthcare Admin, doing a grouped aggregate directly over
`AI Prompt Log` (`purpose = "Narzim Assistant Chat"`, group by the message doctype's
`session_user` via a join, or simpler: group `AI Narzim Assistant Message` by `session_user`
summing `tokens_in + tokens_out` and `cost_estimate_usd` — this doctype already carries both, so
no join is even needed). Returns `[{user, tokens_used, cost_usd, message_count}]`. This is a
report/aggregation, not a new metering mechanism — consistent with the "visibility only, no cap"
decision.

### 4.4 Privacy: sessions private per user

New `permission_query_conditions` entry in `hooks.py` for `AI Narzim Assistant Message`,
restricting non-admin roles to `session_user = frappe.session.user` — same mechanism already used
elsewhere in this app for scoping (e.g. the patient-portal/WhatsApp query-condition entries in
`hooks.py`). System Manager / EB_Healthcare Admin bypass the filter (needed for §4.3's usage
report). This is a query-condition, not a doctype permission change — regular
create/read/write grants stay as in §4.1.

### 4.5 No-PHI guardrail — architectural, not just a prompt instruction

Per requirement 2, this must be **structurally** incapable of reaching patient data, not just
told not to:

- The whitelisted API method never accepts or resolves any `patient`/`encounter` identifier.
- No `tools`/`call_tool` are passed to the LLM call at all (unlike `ask_copilot_agent`, ADR-030's
  bounded tool loop) — there is no `TOOL_REGISTRY` wiring here, so there is no code path back to
  the database of any kind. This is a stronger guarantee than "the model was told not to," and
  simpler to build than the encounter copilot (no tool schemas, no `execute_tool` dispatch).
- The system prompt (new `prompts/narzim-assistant-v1.txt`, following the existing convention of
  runtime-editable `.txt` files, never inline strings, Rule 9/CLAUDE.md §9) instructs the model:
  general clinical/medication knowledge only; if asked about a specific patient, decline and
  redirect to the patient's chart / the encounter copilot instead.
- No patient-scoped permission checks are needed anywhere in this feature (a genuine
  simplification versus every other existing AI feature, all of which gate on `Patient`/`Patient
  Encounter` read/write — see backend deep-dive §12).

> **Amended 2026-09-08 — the second bullet's "no code path back to the database of any kind" is no
> longer literally true, and the distinction matters.** The feature now reads two tables:
> `Medication` and `Lab Test Template`, via `services/formulary_context.py` (§18.2). Neither holds
> patient data, no `patient`/`encounter` identifier is accepted or resolved, and **no tools are
> passed to the LLM** — the guardrail this section is really about is intact. But the accurate
> statement is now "no code path to *patient* data", not "no code path to the database". A `living`
> document that overstates a guardrail is worse than one that understates it, because the
> overstatement is what gets quoted.
>
> Also amended: the third bullet names `narzim-assistant-v1.txt`. The live prompt is
> **`narzim-assistant-v3.txt`** (§18.3).

### 4.6 New whitelisted API — new module, not `api/v1/ai/api.py`

`api/v1/ai/api.py` is already 1,358 lines and is explicitly the Encounter Copilot's file per
`NARZIM_AI_ENCOUNTER_SYSTEM.md`'s scope table. Per `CLAUDE.md`'s own API convention
("`api/v1/<module>/api.py`"), this is a distinct module and should get its own:

```
remedisys_healthcare_ai/api/v1/narzim_assistant/api.py
  send_message(thread, message, attached_file=None) -> {reply, model, tokens_in, tokens_out,
                                                          cost_usd, prompt_log}
  list_threads() -> [{thread, preview, count, last_activity}]   # scoped to session_user, §4.4
  get_thread(thread) -> [AI Narzim Assistant Message...]
  get_usage_summary(from_date, to_date) -> [...]                # admin-only, §4.3

remedisys_healthcare_ai/services/narzim_assistant.py
  business logic: builds message history for a thread, calls get_llm_client(), calls
  log_prompt_call_general(), inserts the message row(s)
```

`send_message` dispatches to one of two provider-module functions depending on whether
`attached_file` is present:
- No file: a new `answer_general_question(system, history, message) -> {text, model, tokens_in,
  tokens_out}` sibling of `answer_lab_question` (§2.3) — same shape, no lab context.
- With file: a new `answer_document_question(files, question, history=None) -> {text, model,
  tokens_in, tokens_out}` sibling of `summarize_document` (§2.4), open-ended Q&A instead of a
  fixed summary schema. Both added to `integrations/anthropic.py` and `integrations/openai.py`,
  reusing each file's existing `_estimate_cost` (§2.2) — no new pricing table.

Streaming: **no LLM response streaming exists anywhere in this codebase today** (confirmed —
every call is a blocking request/response; the existing "streaming" chat UI is client-side
word-chunking of an already-complete response). This feature should follow the same pattern
(whole-response reply) unless real token streaming is explicitly scoped in later — it is not a
requirement stated by the user.

---

## 5. Proposed Frontend Design

(Repo: `EB_Healthcare_Frontend`, per the deep-dive above.)

### 5.1 Routing

`src/app/(clinic)/narzim-ai/page.tsx` — thin wrapper (same pattern as
`(clinic)/messages/page.tsx`) delegating to a new `NarzimAiClient` component. Automatically
inherits the sidebar/header shell from `(clinic)/layout.tsx` — no layout changes needed.

### 5.2 Layout — two-pane, forked from the messages precedent

Fork `messages-client.tsx` + `conversation-list.tsx`'s `w-80` list-pane + `flex-1` detail-pane
layout (the closest existing "list of sessions + detail view" precedent in this codebase) rather
than `NarzimAIChatBar`'s in-panel slide-over history — a dedicated full page should show the
thread list persistently, not behind a toggle.

- **List pane**: "+ New chat" button, search box, list of threads (preview = first/last message
  text truncated, per-thread last-activity time) — sourced from `list_threads()` (§4.6).
- **Detail pane**: forked from `NarzimAIChatBar.tsx`'s message list / input box / file-attach
  button / send button, with all encounter-specific props removed (no `encounterId`,
  `getTranscript`, `onApplyActions`, `onPatientDraft` — none of that applies to a patient-agnostic
  assistant). File input restricted to `accept=".pdf"` only (current chat bar accepts
  `.pdf,.png,.jpg,.jpeg,.doc,.docx` — narrower here per requirement 3).
- **Cost/token chip**: new UI element (confirmed nothing like this exists anywhere in the
  frontend today — zero matches for `token_usage|cost_usd` etc. in `src/`) — a small subtitle
  under each assistant message, e.g. "1,204 tokens · $0.004", sourced directly from
  `send_message`'s response.

### 5.3 BFF routes

`src/app/api/ai/narzim-assistant/{send,threads,thread}/route.ts` — same shape as
`encounter-chat/route.ts`: `getAccessToken()` from the httpOnly cookie → `frappeFetch("remedisys_
healthcare_ai.api.v1.narzim_assistant.api.<method>", {token, body})` → `frappeErrResponse()` on
failure. No vendor API keys touch this repo at any point (unchanged from every other AI route).

### 5.4 Navigation

Add one `NavItem` to `buildNav`'s arrays in `app-sidebar.tsx` (e.g. its own entry in the `today`
group, consistent with "top-level" per the requirement), a `Sparkles`-style icon, `sidebar.narzimAi`
label key. `NavGroup` itself needs no changes (already generic).

### 5.5 i18n

- `sidebar.narzimAi` in both `messages/en.json` and `messages/es.json`.
- New top-level namespace `narzimAi: {...}` — copy/adapt `encounter.aiChat`'s ~35 keys
  (placeholder, send, newChat, history, historyEmpty, error, uploadTitle, etc.) as the starting
  template, since it's the closest existing string set for this kind of chat UI.

---

## 6. Reused vs. New — Summary Table

| Concern | Reused as-is | New |
|---|---|---|
| Provider selection | `services/llm.py::get_llm_client()` | — |
| Cost calculation | Each provider module's own `_estimate_cost`/`_pricing_for_model` | — |
| PDF reading mechanism | Native multimodal upload pattern (`summarize_document`'s approach) | `answer_document_question()` (open-ended Q&A variant) |
| Plain Q&A call shape | `answer_lab_question()`'s pattern (no tools, system+history+user) | `answer_general_question()` |
| Chat persistence shape | `AI Encounter Chat Message`'s thread-as-a-field pattern (no session doctype) | `AI Narzim Assistant Message` |
| Cost/token audit | `AI Prompt Log` (+1 new `purpose` value) | `log_prompt_call_general()` sibling helper |
| Per-user usage view | Aggregation query over the new message doctype | `get_narzim_assistant_usage_summary()` |
| Private-per-user scoping | `permission_query_conditions` mechanism (pattern reused) | New entry for the new doctype |
| Frontend chat internals | `NarzimAIChatBar.tsx` (message list, input, file-attach) | Forked/trimmed copy, no encounter props |
| Frontend list+detail layout | `messages-client.tsx` + `conversation-list.tsx` | Forked copy for threads |
| Sidebar nav mechanism | `buildNav()` in `app-sidebar.tsx` | One new `NavItem` entry |
| Not reused (explicitly) | `AI Usage Counter`/`AI Subscription Plan` (§2.6 — wrong tool, unwired billing scaffolding) | — |
| Not reused (explicitly) | `ask_copilot_agent`'s tool-calling loop (ADR-030) — no tools needed/wanted here (§4.5) | — |

---

## 7. Open Questions

These don't block writing this document but should be resolved before or during implementation:

1. **Naming/UX disambiguation** (§1): confirm the sidebar label stays "Narzim AI" as asked, and
   decide whether a first-open subtitle or tooltip is worth adding to reduce confusion with the
   existing "Ask Narzim AI" encounter copilot.
2. **RESOLVED 2026-07-30** — visible to every role, Front Desk included (user request). Backend
   grants EB_Front Desk/EB_Clinic Staff create+read+write on `AI Narzim Assistant Message` in
   `eb_docperm_spec.json`, matching EB_Practitioner/EB_Nurse; frontend nav entry in `app-sidebar.tsx`
   is now unconditional in the `today` group, same as Dashboard/My Work/Documents.
3. **Retention**: `AI Settings` already has a `prompt_log_retention_days` field (365 default)
   that would cover the `AI Prompt Log` rows this feature creates. Should
   `AI Narzim Assistant Message` rows get their own retention window, or follow the same
   365-day default? Not specified.
4. **CLAUDE.md refresh**: separate from this feature, but §2.1 found CLAUDE.md's AI architecture
   map (file stub labels, doctype list) is materially out of date. Worth a follow-up task,
   independent of this build.

---

## 8. Phased Implementation Plan

1. **Backend data model**: new `AI Narzim Assistant Message` doctype (fixture/migration), add
   `Narzim Assistant Chat` to `AI Prompt Log.purpose`, add the `permission_query_conditions`
   entry to `hooks.py`, add the new EB-role grants to `eb_docperm_spec.json` (per the existing
   convention — not a one-off patch, §11 of the backend deep-dive).
2. **Backend LLM functions**: `answer_general_question()` / `answer_document_question()` in both
   `integrations/anthropic.py` and `integrations/openai.py`; `prompts/narzim-assistant-v1.txt`;
   `log_prompt_call_general()` in `services/ai.py`.
3. **Backend API**: `api/v1/narzim_assistant/api.py` (`send_message`, `list_threads`,
   `get_thread`, `get_usage_summary`) + `services/narzim_assistant.py`.
4. **Backend tests**: auth/permission tests (private-per-user scoping actually holds), a
   PDF-upload happy path, a provider-swap test (Anthropic ↔ OpenAI via `AI Settings`).
5. **Frontend routing/nav**: `(clinic)/narzim-ai/page.tsx`, `app-sidebar.tsx` nav entry, i18n
   strings in both locales.
6. **Frontend BFF routes**: `api/ai/narzim-assistant/*`.
7. **Frontend UI**: `NarzimAiClient` (list pane forked from `conversation-list.tsx`, detail pane
   forked from `NarzimAIChatBar.tsx`), cost/token chip, PDF-only upload restriction.
8. **End-to-end verification**: exercise both providers, verify AI Prompt Log rows are correct,
   verify one user cannot see another's threads, verify the usage-summary aggregation.

---

## 9. Risks

- **Cost-estimate divergence**: if the new provider functions don't call each adapter's existing
  `_estimate_cost`/`_pricing_for_model` and instead hardcode a rate, this repeats the exact
  duplication bug already present elsewhere (§2.2). Must be caught in code review.
- **Guardrail is prompt-only if tool-wiring discipline slips**: the "no PHI" guarantee here comes
  from *never wiring any tools or patient context in the first place* (§4.5) — if a future change
  adds a "quick patient lookup" convenience tool to this feature, the architectural guarantee is
  gone and it becomes prompt-only (weaker, same class of risk as any other LLM guardrail). Any
  such change should be treated as a scope change requiring the same review this document got.
- **Private-per-user via query condition, not row ownership alone**: `permission_query_conditions`
  is an established pattern in this codebase, but it's easy to add a new report/list view later
  that queries `AI Narzim Assistant Message` directly via `frappe.db.sql`/`get_all` with
  `ignore_permissions=True` and accidentally bypass the privacy scoping — anything touching this
  doctype should go through the whitelisted API, not raw ORM calls, outside the admin usage-report
  path (which is deliberately privileged).
- **Two "030" ADRs and a stale CLAUDE.md are pre-existing confusion risks**, not caused by this
  feature, but worth fixing opportunistically rather than adding a third layer of drift on top.

---

## 10. Post-Launch Incident — PHI Exposure via Document Upload (2026-07-30)

**What happened.** Within hours of launch, a Front Desk user uploaded a real patient's discharge
note (a "Nota de Prealta" PDF) to this assistant. §4.5's guardrail only checked the *question text*
for patient-identifying references ("if a question names or clearly refers to a specific patient,
decline") — it never inspected the *uploaded document itself*. The assistant read the PDF and
produced a full clinical summary: patient name, admission/discharge dates, diagnosis, treatment,
microbiology, imaging findings. That summary was displayed in the chat, persisted in full to
`AI Narzim Assistant Message.content`, and the source PDF was saved as a private `File` attached to
that message — a permanent copy of a real patient's record sitting outside the Patient record
system entirely, with none of its retention/access controls. §4.5 and §9's "Guardrail is
prompt-only if tool-wiring discipline slips" risk both anticipated a *future* tool-wiring gap;
neither anticipated that the upload path itself was already an open door on day one. A follow-up
message asking to translate the summary was refused — not because the guardrail caught it, but
because the model noticed the patient's name already sitting in its own prior turn in the
conversation history. By then the exposure had already happened and was already persisted.

**Fix, three parts:**

1. **Dedicated PHI pre-check gate** (not a prompt bullet added to the answer call). A new function,
   `check_document_for_patient_phi()`, added to both `integrations/anthropic.py` and
   `integrations/openai.py` (dispatched via the existing `get_llm_client()`, no new dispatcher),
   using its own prompt file (`prompts/narzim-assistant-phi-check-v1.txt`) whose *only* instruction
   is classify-and-refuse. `services/narzim_assistant.py::send_message` now calls this BEFORE
   `answer_document_question` for every upload; if `contains_patient_phi` is true,
   `answer_document_question` is never called at all — the assistant's reply is the classifier's own
   `refusal_message` (guaranteed content-free by its schema/prompt), and the check call itself is
   logged to `AI Prompt Log` under a new purpose, `Narzim Assistant Document Check`, so its
   cost/tokens are still auditable. This is a separate call precisely because folding the
   instruction into the answer prompt (the original approach) let it get crowded out.
   - **Caveat, stated plainly:** this call still transiently sends the file bytes to the LLM
     provider — it stops the answer and the at-rest copy in our own database, not the one-time
     transmission to the provider, which is inherent to any AI document-Q&A feature that accepts
     uploads at all. It is a strong mitigation, not an absolute guarantee; an LLM classifier can
     still misjudge a document (see the residual risk noted below).
2. **Uploads are no longer persisted, at all.** `send_message` no longer calls `save_private_file`
   for the uploaded PDF under any circumstances — not for a blocked document, not for an allowed
   one. The file is held in memory for that one exchange and discarded. `AI Narzim Assistant
   Message.attached_file` is kept in the schema (no migration needed to drop it) but is
   intentionally never populated by current code — see its updated field description. This removes
   the at-rest exposure surface even for a mistaken upload of a genuinely non-patient document.
3. **The specific exposure was purged.** The exact thread (`AI Narzim Assistant Message` rows), its
   `AI Prompt Log` rows, and the two `File` records it created were deleted from
   `remedisis.localhost` on 2026-07-30, after confirming byte-for-byte that the physical file paths
   involved were NOT shared with the same patient's legitimately-stored copies elsewhere (that
   patient's own `Patient`-attached documents and the encounter copilot's own
   `upload_and_analyze_document` audit trail were left untouched — separate feature, separate
   access controls, working as designed).

**Residual risk, stated directly:** the pre-check is an LLM call, not a deterministic filter — it
can still misclassify an ambiguous document (e.g. a heavily redacted note, a document in an unusual
format, or one where "is this patient-specific" is a genuinely hard call). This is the same class of
risk as every other LLM-based guardrail in this codebase (Rule 4/5's own framing acknowledges
prompt-level controls are not infallible). If this happens again, the next escalation is a
deterministic pattern-based pre-filter (e.g. MRN-format detection, a hint in the filename) layered
in front of the classifier — not implemented here, since it wasn't needed to close this specific
incident, and over-engineering a detector for a hypothetical failure mode before a second real one
is observed would be premature.

## 11. Scope Widened to General-Purpose (2026-07-30) — REVERSED 2026-08-29

> **This widening no longer describes the system.** The topic scope was re-narrowed on
> 2026-08-29 by [`adr-050-narzim-assistant-domain-scope-gate`](../adr/adr-050-narzim-assistant-domain-scope-gate.md);
> see §17. The UPLOAD widening in §12–§15 is unaffected and still stands. The paragraph
> below is kept as the record of what was decided on 2026-07-30 and why.

Following the incident fix above, the topic scope was deliberately widened: `narzim-assistant-v1.txt`
no longer restricts the assistant to "medication/clinical-knowledge questions" — it now answers any
topic, the same as a general assistant, on explicit request. **What did NOT change**: the patient-PHI
hard rules (§10) apply unconditionally, regardless of topic — a question or document that touches a
real, identifiable patient is refused the same way whether the surrounding conversation is about
medicine or anything else. The per-topic safety-note rule (dosing/formulary caveats) is now scoped to
apply only when the topic is actually clinical, so it doesn't get forced onto unrelated answers.
Frontend copy (`narzimAi.subtitle`/`placeholder`/`emptyStateHint` in both locale files) was updated to
match — "general assistant, no patient data" rather than "medication assistant only."

## 12. Redesign — Local Redaction Instead of Classify-and-Refuse (2026-07-31)

**Why:** §10's fix stopped this codebase's own copy of an exposure (no more full-summary answer,
no more at-rest persistence), but its own "residual risk" note said plainly: the classify call
itself still transmits the raw file bytes to the LLM provider before any decision is made. On
review, that one-time transmission was judged not acceptable for this feature — general Narzim AI
is explicitly meant to have zero path to patient data (§3, requirement 2), and "the file still
reached the provider, we just didn't act on it" falls short of that.

**What changed.** `send_message` no longer sends file bytes to any LLM call, for any reason:

1. A PDF's embedded text layer is extracted **locally** — `services/pdf_pages.py::extract_text_layer()`
   (already existed, reused as-is, no AI, pypdf only).
2. That text is run through a new **local, deterministic** module, `services/pii_redaction.py::redact_text()`
   — regex + bilingual (es-MX/en-US) labeled-field matching (`Name:`/`Nombre:`, `DOB:`/`Fecha de
   Nacimiento:`, email, MRN, CURP, address, phone — under a label only, not a bare digit run) —
   masking each as `[REDACTED]`. No AI call anywhere in this module.
3. The masked text is folded into a normal `answer_general_question()` call (system prompt +
   history + user turn) — the same function already used for plain text questions. There is no
   longer a separate `answer_document_question()`/multimodal-file code path in this feature at all.
4. A PDF with no extractable text layer (a scan or a photo of a document) and any non-PDF upload
   (PNG/JPEG/WEBP/GIF) are **rejected outright**, with a clear message telling the user to use a
   text-based PDF or the in-encounter assistant instead. Without a text layer there is nothing to
   search-and-mask, and sending the bytes anyway just to check would reintroduce the exact
   transmission this redesign exists to remove. **This is a real capability reduction** — image
   uploads (e.g. a photo of a drug package insert) worked before this change and do not now.

**Residual risk, stated directly (same spirit as §10's own residual-risk note):** `redact_text()` is
regex/label matching, not language understanding. A name mentioned in plain prose with no adjacent
label (e.g. "please see Maria's results") will not be caught. This is a materially different,
smaller risk surface than before (no LLM ever sees the raw file, at all, for any document), but it
is not a guarantee that every possible personal detail in unstructured prose is masked. Closing that
gap fully would require true entity recognition (NER) or OCR-for-images, neither of which exists in
this codebase and neither of which was built here — flagged as a possible future escalation, not
implemented, the same way §10 flagged a deterministic pre-filter as a future escalation it also did
not build.

**Now orphaned, not deleted — an open decision:** `prompts/narzim-assistant-phi-check-v1.txt`
(already empty) and its caller `check_document_for_patient_phi()`, plus `answer_document_question()`,
in both `integrations/anthropic.py` and `integrations/openai.py`. Nothing in this feature calls
either anymore. See `prompts/README.md`'s note on the same point before deciding whether to remove
them or keep them as available building blocks.

**Frontend updated to match, same pass as §14 below** — see §14 for the final state; the note that
used to be here (frontend still only accepting PDF/image extensions) is stale, superseded by §14.

## 13. Format Coverage Expanded — Excel/Word/PowerPoint (2026-07-31)

Extended the same extract-locally-then-redact pattern from §12 to three more upload types, using
the same non-AI, zero-transmission approach:

- **Excel (.xlsx/.xls)** — `services/office_text_extraction.py::extract_excel_text()`, via
  `openpyxl` (.xlsx) or `xlrd` (.xls, its only remaining supported format) — both already present
  in this app's dependency tree, no new package added. Gets an extra masking pass plain
  `redact_text()` cannot do on its own: a spreadsheet's personal-detail column is usually
  identified by its **header cell** ("Name" as a column title, values below), not a same-line
  "Label: value" pattern — so every data cell under a header matching
  `pii_redaction.PERSONAL_DETAIL_LABELS` is masked by column position before the sheet is
  flattened to text. Verified: a "Name" column's values never reached the model even though no
  cell contained the word "Name:" inline.
- **Word (.docx)** — `extract_docx_text()`, via the newly added `python-docx` dependency (pure
  Python, no system binary). Paragraph and table-cell text only.
- **PowerPoint (.pptx)** — `extract_pptx_text()`, via the newly added `python-pptx` dependency
  (same — pure Python). Text-frame text only, slide by slide.

All three feed into the same `redact_text()` pass already used for PDF, then the same
`answer_general_question()` call — no new LLM-facing code path.

**At the time this section was written, images/scans/legacy `.doc` were deliberately deferred** —
OCR needs a system binary (`tesseract-ocr`) whose Frappe Cloud availability was unconfirmed, and
legacy `.doc` needs a separate parser entirely. **Superseded by §14 the same day**: asked to cover
these anyway, accepting the Frappe Cloud risk explicitly rather than leaving it unconfirmed.

## 14. Format Coverage Completed — OCR (Images + Scanned PDFs), Legacy .doc, CSV, Plain Text (2026-07-31)

Same day as §13, on explicit request to cover every remaining common format rather than stop at
what avoided new system dependencies.

- **Images (PNG/JPEG/WEBP/GIF)** — `services/ocr_text_extraction.py::extract_image_text()`, via
  the new `pytesseract` + `tesseract-ocr` (system binary) + `tesseract-ocr-spa` (Spanish trained
  data — this app's locked es-MX/en-US pair, ADR-018). **The §13 concern about Frappe Cloud is
  still genuinely unresolved** — `tesseract-ocr`/`tesseract-ocr-spa`/`antiword` were added to
  `pyproject.toml`'s `[deploy.dependencies.apt]` list on the expectation that mechanism installs
  them there the same way it would any other apt package, but this has NOT been verified against
  an actual Frappe Cloud deploy. If that assumption is wrong, OCR and `.doc` extraction will simply
  return `""` in production (every `except Exception: return ""` in `ocr_text_extraction.py`/
  `office_text_extraction.py::extract_doc_text()` degrades to the existing "could not read any
  text" rejection, not a crash) — a silent capability gap, not a broken feature, but worth an
  explicit deploy-time check the first time this ships to Frappe Cloud.
- **Scanned/photographed PDFs** — `extract_scanned_pdf_text()`, same module: when
  `pdf_pages.extract_text_layer()` returns `""` (no real text layer), each page is rendered to an
  image locally via `pymupdf` (bundles its own rendering, no extra system binary for that part) and
  OCR'd the same way as a standalone image. Verified end-to-end: a genuinely scanned PDF (an image
  with no embedded text object at all) had its diagnosis correctly read and its patient name
  correctly masked before the model ever saw it.
- **Legacy `.doc`** (pre-OOXML binary Word) — `office_text_extraction.py::extract_doc_text()`, via
  the new `antiword` system binary (`python-docx` cannot read this format at all — it only
  understands the modern `.docx` zip container). No legacy `.ppt` equivalent was built; only `.doc`
  was requested.
- **CSV** — `extract_csv_text()`, same module, Python's built-in `csv` — no new dependency. Reuses
  the same column-header masking as Excel (factored out into `_mask_columns_by_header()` so the
  logic isn't duplicated a second time).
- **Plain text (.txt)** — `extract_txt_text()`, same module — there is nothing to extract, the
  bytes already are the text; relies entirely on `redact_text()`'s pattern/label pass, same as
  Word/PowerPoint content.

All of the above still feed into the same `redact_text()` pass and the same `answer_general_question()`
call as every other format — no new LLM-facing code path was added by any of this.

**OCR is a materially weaker guarantee than the other extractors, stated directly.** Every other
extractor reads data that already existed as real text — OCR *infers* text from pixels, and can
misread or drop characters, especially on messy handwriting, poor photo quality, or an unusual
layout. `redact_text()` can only mask what OCR actually produced as recognizable text; an OCR
misread of a name into something not matching the label pattern is a different failure mode than
the "unlabeled prose" gap already noted for the other formats, and is not solved by this feature.

**Full current test coverage:** every format above (Excel, Word, PowerPoint, CSV, TXT, PDF with a
text layer, image OCR, scanned-PDF OCR fallback) was verified end-to-end with a real answer +
real masking, plus graceful rejection (no crash) for corrupt/unreadable input of each type. See the
chat history around 2026-07-31 for the specific test transcripts; no permanent test fixtures were
added to `tests/narzim_assistant/` for these paths — an open follow-up, not done as part of this
pass.

**Frontend updated to match** (`EB_Healthcare_Frontend` — `narzim-chat-panel.tsx`, both locale
files): the upload picker now accepts every format above; the BFF `send/route.ts` route was fixed
to extract the backend's real validation message (`lib/api/client.ts::frappeErrMessage()`, the same
helper the other narzim-assistant routes already used) instead of its own prior logic that
preferred `exc_type` (just the exception class name) over the actual message — that bug meant every
upload-rejection reason was showing up to users as the unhelpful literal string "ValidationError"
before this fix.

## 15. Raw-Image Vision Fallback — Explicit, Confirmed Exception to "Never Send Raw Bytes" (2026-07-31)

**What triggered this.** A real upload — a photograph of an X-ray displayed on a monitor — was
correctly rejected by §14's OCR path: there was no recognizable text in the image (only tiny
orientation/window-level markers like "R", "LM", "W: 4096"), so `extract_image_text()` returned `""`
and the upload was refused with "could not read any text." This is not a bug — an X-ray's entire
value is the pixels, not text, so there was genuinely nothing for `redact_text()` to mask.

**The request, and the pushback given first.** Asked to make this assistant handle exactly this
case — accept an image with no text at all — the tradeoff was stated plainly before implementing
anything: this assistant has no patient/encounter scope and is reachable by every role, including
Front Desk (§3, §11, requirement 2 — "architecturally incapable of reaching patient data"). The
already-built, already-safe equivalent for this exact need is the in-encounter "Ask Narzim AI"
copilot's `upload_and_analyze_document` (`api/v1/ai/api.py`), which sends images to a real vision
pipeline (`summarize_document`) but is safe specifically because `_require_encounter_read(encounter)`
gates it to a patient the caller is already authorized to see. Building the same raw-image
transmission into the *general*, patient-agnostic assistant reintroduces the identical shape of risk
as the 2026-07-30 incident (§10) that this whole feature was rebuilt around — just via image pixels
instead of document text, and with no possible mitigation (there is no text to redact from an image
at all). This was put to the user directly as a yes/no question, with the consequence spelled out
before asking. **The explicit answer, verbatim: "yes proceed with no patient authorization."**

**What was built, given that instruction.** In `services/narzim_assistant.py::send_message`: for an
image (PNG/JPEG/WEBP/GIF) where `extract_image_text()` (§14) returns no text at all, the code no
longer rejects the upload — it calls `get_llm_client().answer_document_question()` (the same
function `office_text_extraction`'s design already relied on for documents, §4.6 — never removed,
just unused by this feature since §12's redesign) with the **raw image bytes**, not extracted text.
This is the *only* code path in this entire feature where raw file bytes reach the LLM. Every other
upload path (PDF, Excel, Word, PowerPoint, CSV, TXT, legacy .doc, and an image OCR **can** read text
from) is unaffected and still masks-before-sending exactly as §12/§13/§14 describe.

**What this means concretely:** any user of this assistant, in any role including Front Desk, can
upload any image and have it visually interpreted by the configured LLM provider, with **no check
of any kind** on whether that image belongs to a patient the uploader has any right to see. The only
remaining safeguard is a prompt-level instruction (`prompts/narzim-assistant-v1.txt`, "Uploaded
images with no text" section) telling the model to look for a visible name/MRN/ID burned into the
image itself and decline if it sees one — this is the exact class of guardrail (LLM judgment, not an
architectural block) that §9's risk section and the original 2026-07-30 incident both already showed
is not reliable on its own. It is a mitigation, explicitly not a guarantee, same as every other
prompt-level safeguard in this codebase (Rule 4/5's own framing).

**Why this is recorded as its own numbered decision rather than folded into §14:** every other
change in this document extends the "extract locally, mask, send text only" pattern. This one
doesn't — it is a deliberate, user-directed departure from that pattern for one specific,
narrow case (an image with zero extractable text), made with the risk stated first and an explicit
answer given in response. Future maintainers should not assume this assistant is uniformly
"architecturally incapable of reaching patient data" (§11's original framing) — that guarantee now
holds for every upload type except this one.

**Verified:** a synthetic no-text image and the actual X-ray photo that triggered this request were
both tested — OCR correctly found no text on both, both fell through to the vision path, and both
received a real, non-refused description back from the model instead of a rejection.

## 16. Model No Longer Second-Guesses Masking on the Text Path (2026-08-01)

**What triggered this.** A user uploaded a PNG — a screenshot of this very app's Patient Chart page
— and got a refusal: *"...contiene información que identifica claramente a un paciente real."* Tracing
it: OCR correctly extracted the on-screen text, but the patient's name appeared in the **browser
address bar URL** (`localhost:3000/patients/Divyanshu Chauhan - 1`), not in any `Label: value` line —
`redact_text()`'s label-keyword matching (§16 of `pii_redaction.py`'s own docstring, "cannot reliably
catch a name in unlabeled prose") has no structural pattern to catch a name embedded in a URL string,
so it passed through unmasked. `narzim-assistant-v1.txt`'s §"Uploaded documents" then told the model
to decline if the remaining text *still* clearly identified a real patient — which correctly fired,
since the raw name was, in fact, still sitting right there.

**The request.** Stop the model from refusing on this path at all: mask what `redact_text()` catches,
then always answer using whatever remains — full stop, no model-level "does this still look
identifying" second-guessing on top of the deterministic mask.

**What changed.** Removed the "decline if the remaining text still clearly identifies a specific real
patient" bullet from the "Uploaded documents" section of `narzim-assistant-v1.txt`. The model is now
told explicitly: masking is the safeguard, not its own judgment layered on top — answer normally
using what's left, and the surrounding content still reading as being "about one particular person"
is not itself a reason to stop. **The §15 image-with-no-text-at-all instruction (declining if a
visible name/MRN/ID is spotted in a raw, unredacted image) was deliberately left untouched** — that
path has no masking step at all (raw bytes go straight to the vision model), so the model's own
judgment is the *only* safeguard there, unlike the text path where `redact_text()` already ran first.

**Residual risk, stated directly — this is a real, not hypothetical, gap:** anything `redact_text()`
fails to catch (a name in a URL, a name in unlabeled prose, an unusual label wording not on the
keyword list) will now reach the final answer instead of triggering a refusal, exactly as it did in
the incident that prompted this. This trades a false-refusal annoyance for a real chance of a
masking gap surfacing in the answer. Not mitigated further here — extending `redact_text()` to catch
free-floating names/URLs would need NER or a much larger, fragile pattern set, and was explicitly
out of scope for this fix (the ask was to stop the refusal, not to chase every possible masking
gap). If masking gaps in specific patterns (e.g. this app's own `/patients/<name> - <id>` URL shape)
turn out to recur often, a targeted regex for that one shape would be a cheap, low-risk follow-up —
not implemented here since it wasn't asked for.

## 17. Domain Scope Gate — §11 Reversed (2026-08-29)

The general-purpose widening in §11 was reversed for **topics**. Narzim GPT was answering "what is
firebase fcm" with a full Firebase Cloud Messaging explainer and an offer to write client code;
the thread list also held "Retrieval Augmented Generation Explained" and "Firebase Crashlytics
Overview". That was `narzim-assistant-v1.txt` doing exactly what §11 told it to.

**Decision and full rationale:**
[`adr-050-narzim-assistant-domain-scope-gate`](../adr/adr-050-narzim-assistant-domain-scope-gate.md).
**Implementation spec:** [`NARZIM_SCOPE_GATE.md`](NARZIM_SCOPE_GATE.md). One fact, one owner — this
section only records that §11 no longer holds and points at the two documents that do own it.

In short: three permitted buckets (clinical, platform, conversational), everything else refused;
enforced by a schema-locked classifier call in front of the answering call rather than by prompt
wording alone; identical in both providers per
[`adr-026-llm-provider-allowlist`](../adr/adr-026-llm-provider-allowlist.md); resolved before the
first `yield` so a refusal streams as a normal reply rather than an SSE error frame
([`adr-048`](../adr/adr-048-narzim-streaming-sse-not-background-jobs.md)); and **fails open**,
deliberately unlike the document-upload gate.

Three things in this document that §17 changes:

- `narzim-assistant-v1.txt` is superseded by `narzim-assistant-v2.txt`, and v2 in turn by
  **`narzim-assistant-v3.txt`** as of 2026-09-08 (§18.3). v1 stays on disk for prompt
  history only — do not pin it; it still carries the "you answer any topic" clause.
- The upload path gained a topical gate it never had. §12–§15 govern *how* an upload is read and
  redacted; they never asked whether the file was on-topic, so a product-specification PDF was
  summarised as readily as a package insert.
- `AI Narzim Assistant Message` gained `scope_verdict` / `scope_category`, and `AI Prompt Log`
  gained the `Narzim Assistant Scope Check` purpose.

What §17 does **not** change: every PHI rule in §10 and §12–§16 applies unconditionally and is
untouched. The scope gate runs after `_extract_document()`, so redaction still happens first, and a
refusal on scope grounds is never a substitute for a refusal on PHI grounds.


## 18. Guided Tasks, Removable History, and the Formulary Context (2026-09-08)

Full design and the decisions behind it: [`NARZIMGPT_CAPABILITIES.md`](NARZIMGPT_CAPABILITIES.md).
Recorded here because that document is a `draft` proposal and this one is the `living` record of
what the assistant actually is.

### 18.1 Conversations can be removed — as a hide, never a delete

Three fields added to `AI Narzim Assistant Message`: `hidden` (Check), `hidden_on`, `hidden_by`.
Filtered out of **all four** read paths — `list_threads`, `get_thread`, `get_thread`'s
most-recent-thread resolution, and `_load_history` (a stale client could otherwise post to a removed
thread and feed hidden turns back to the model). New endpoints `hide_thread` and
`hide_all_threads`, both scoped to `session_user`.

Nothing is deleted. `content` is free text a human types into, so PHI can reach these rows despite
the guardrail in §4.5 — and on 2026-07-30 it did (§10). The rows also carry `scope_verdict`, which
is how §17's gate gets measured on real traffic. **§164.312(c)(1)** requires ePHI be protected from
improper destruction, and a user tidying their sidebar must not be able to destroy any of that.

`delete` therefore stays **0** for every EB_ role, unchanged from §4.1: hiding is a `write`, which
they all already hold, so this needed no permission change at all. A test asserts that, so
reimplementing removal as a real delete would have to change the spec in review.

### 18.2 The clinic's own catalogue reaches the answer

`services/formulary_context.py` retrieves matching rows from `Medication` and `Lab Test Template`
and folds them into the prompt as text. Deliberately **not** a tool call: §4.5's guarantee is that
no tools are passed to the LLM, and a tool loop would have changed it. One injection point in
`narzim_assistant.py` covers both providers and both the streaming and non-streaming paths.

**Positive claims only.** The assistant may state what the catalogue holds; it may never state that
anything is absent from it. A catalogue miss is ambiguous — not stocked, spelled differently, or
never populated — and this site proves the middle case: the `Medication` master holds `Amoxiclin`,
so a question about "amoxicillin" matches nothing. Rendering that as "not in your formulary" would
be a false statement a clinician could act on. A strength of 0 or below is dropped from the rendered
line while the drug is still named.

### 18.3 Prompt v3

`prompts/narzim-assistant-v3.txt` adds a "This clinic's own catalogue" section carrying the
positive-only rule. A new version rather than an edit to v2, so an answer stays attributable to the
prompt that produced it; all 14 `narzim-assistant-v2` references were bumped, including the logged
fallback default in `narzim_assistant.py` which would otherwise have recorded v2 while v3 ran.

### 18.4 The typed question is now guarded — §4.5's remaining hole, closed

`services/phi_input_guard.py` refuses a message carrying an MRN, appointment or encounter id, or a
multi-word patient name — **before** any provider call and before anything is persisted.

This closes a real gap in §4.5. The system prompt's instruction to decline patient-specific
questions was a **content** control, not a **disclosure** control: the raw message had already
reached the provider twice (the scope check and the answer call) and been stored once. The refusal
was describing a disclosure that had already happened.

Ids are matched by shape, never by existence — a lookup would make the refusal an existence oracle,
and a mistyped MRN is nearly always a typo of a real one. Only **multi-word** names are matched:
measured against all 464 patients on this site, the name-token list includes `de`, `dev`, `m`, `qa`
and `leo`, and `de` is the commonest word in Spanish with `es-MX` as the default locale. Single-token
matching would refuse a large share of ordinary questions, and a guard that fires constantly gets
switched off. A bare first name is therefore **not** caught; `redact_text()` and the system prompt
remain layers two and three.

### 18.5 Guided tasks (frontend)

Three chips — **Look up · Work up · Treat** — each opening five tasks that prefill the composer with
a stem ending mid-sentence, completed by typeahead. Free text is unchanged for every role: guided
tasks change the default, not the rules, and §18.4 is the actual control. Suggestions rotate from
pools of ten via a shuffled deck. The 280 suggestion strings are **drafted and not clinically
approved** — they are clinical content in a code file and need a named reviewer.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-08 | Ashutosh (AI-assisted) | §18 added (removable history, formulary context, prompt v3, the typed-question guard, guided tasks); §4.5's "no code path to the database" claim amended to "no code path to patient data" |
| 1.2 | 2026-09-07 | Anant Sharma (AI-assisted) | §4.1 corrected — EB_Healthcare Admin gets create+write, closing the gap between §7's "every role" resolution and the read-only admin row |
| 1.1 | 2026-08-29 | Anant Sharma (AI-assisted) | §17 added — topic scope re-narrowed by adr-050; §11 marked reversed |
| 1.0 | 2026-07-31 | Sarvesh | Initial version (header backfilled from git history) |
