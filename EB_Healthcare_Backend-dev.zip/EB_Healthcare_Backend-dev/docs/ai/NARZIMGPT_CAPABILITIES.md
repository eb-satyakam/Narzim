# Narzim GPT — Guided Clinical Tasks (Look up · Work up · Treat)

**Doc status:** draft · **Created:** 2026-09-08 by Ashutosh (AI-assisted) · **Updated:** 2026-09-08 by Ashutosh (AI-assisted) · **Version:** 3.3

> **This is a `draft`.** Per `CLAUDE.md` §9 a draft must not be cited as decided. It is a design
> proposal; the decisions in §10 belong in an ADR before anything is built.

**What this specifies.** Turning Narzim GPT from an empty text box into a set of **guided clinical
tasks** — the pattern Heidi Health uses: a row of task chips under the composer, each opening a
short list of concrete tasks, each of which prefills the composer with a fill-in-the-blank stem and
completes it with typeahead.

**Scope of this version:** three categories — **Look up**, **Work up**, **Treat**. Heidi's other
three (Prepare, Write, Fill form) are deliberately out of scope; see §9.

**The problem it solves.** An empty box with "Ask anything…" is the worst possible interface for a
clinician with ninety seconds between rooms. It requires them to *invent* a question, gives no clue
what the assistant is good at, and — the part that matters here — the most natural thing to type is
a patient's name. Today's screen tells them nothing except that they may ask anything, which is
also the one thing that isn't true.

**Related:** [`NARZIM_AI_ASSISTANT_DESIGN.md`](NARZIM_AI_ASSISTANT_DESIGN.md) (the assistant as
built) · [`NARZIM_SCOPE_GATE.md`](NARZIM_SCOPE_GATE.md) (the classifier every stem must pass) ·
[`NARZIM_AI_ENCOUNTER_SYSTEM.md`](NARZIM_AI_ENCOUNTER_SYSTEM.md) (the *other* assistant, which does
have patient access) · [ADR-030](../adr/adr-030-llm-curated-tool-access.md) (what tools may do).

---

## 1. Why this pattern is the right one here — and it is not mainly about UX

Guided tasks are usually justified as discoverability. In this product they earn their place twice
over, and the second reason is the stronger one.

**Reason one — they say what the assistant is for.** The scope gate already refuses everything
outside clinical / platform / conversational, but the user only discovers that *by being refused*.
Your own screenshots show it: two of the visible history threads are "what is firebase fcm" and
"Retrieval Augmented Generation Explained" — a user probing the boundary, getting refused, and
learning nothing about what the tool actually does well. Chips answer that question before the
first keystroke.

**Reason two — every stem is patient-free by construction, so the fast path has nowhere to put a
name.** This is a privacy control wearing a UX costume:

> `Is it safe to use [drug] in [situation]?`
> `Workup for [presentation]`
> `Compare [first drug] vs [second drug] for [condition]?`

None of those has a slot for a person. A clinician who wants an answer in five seconds takes the
guided path, and that path gives them nowhere to put a name.

**State the limit of that claim precisely, because it is easy to overstate — including in this
document's own earlier draft.** The composer remains free text. Guided tasks *prefill* it; they do
not lock it. A user can clear the stem, or take `Workup for ` and edit it into
`what meds is Karim on`. Nothing in this pattern prevents that, and nothing should: a closed set of
fifteen tasks would make the assistant useless for the long tail of real clinical questions, which
is most of them.

So the two mechanisms do different jobs, and only one of them is a control:

| | What it actually does |
|---|---|
| **Guided tasks** | Change the **default**, and therefore the *distribution* of what gets typed. A nudge. Valuable, measurable, and **not** enforcement |
| **§2 pre-filter** | The **control**. Server-side, deterministic, applied to every message regardless of how it was composed |

The correct reading is therefore: guided tasks reduce how often a patient identifier gets typed;
they cannot make it impossible. **§2 is what makes it safe, and it is a prerequisite of this work
rather than a follow-up to it.** Anyone citing this design as a privacy improvement on its own is
citing it wrongly.

---

## 2. The prerequisite: today the typed question is not redacted

**Verified in code, and it must be fixed alongside this work — not after it.**

`redact_text()` is applied only to **uploaded document text**
(`services/narzim_assistant.py:384`, inside `_extract_document`). The user's typed message is not.
The system prompt instructs the model to decline when the user names a real patient — but that
instruction runs **after transmission**. Tracing `send_message`, the raw message leaves the process
twice and is stored once:

1. `_check_scope(history, message, redacted_document)` — an LLM call carrying the raw message
2. `answer_general_question(history, llm_message)`, where `llm_message = message`
3. `_insert_message(content=message)` — persisted at rest in `content`

**USER STORY.** Dr. Bracamontes types *"what antibiotics is Karim Benzema already on"* → **the
system shows** a refusal telling him to use the patient's chart → **the database contains** a row
whose `content` is that sentence, and **the provider has already received it twice** →
**consequence:** a patient name plus a clinical fact was disclosed to a subprocessor with no BAA,
and the UI reported that as the assistant protecting privacy.

**Why guided tasks make this both better and more urgent.** Better, because most traffic moves to
stems with no name-shaped slot. More urgent, because a more useful assistant gets used more, and
the free-text box does not go away.

**Recommended fix:** a deterministic pre-filter *before any provider call* — our own MRN format,
plus a token lookup against `Patient.patient_name` — refusing locally on a hit, with
`redact_text()` as a second layer. `redact_text()` alone is the trap: it is tuned for labelled
document fields (`Name:`, `DOB:`) and will not catch a bare name in prose, so it would pass review
while catching almost nothing. Full four-option comparison: this document's v1.0 §2, in git history.

---

## 3. Anatomy of a guided task

Five parts. Getting the third and fourth right is what separates this from a row of decorative
buttons.

| Part | What it is | Design rule |
|---|---|---|
| **Chip** | `Look up` · `Work up` · `Treat` under the composer | Verbs, not nouns. A clinician picks by intent, not by category |
| **Task list** | 5 tasks per chip, opening in a panel | Five is the ceiling. A scrolling list is a menu, and a menu is work |
| **Stem** | Prefills the composer, e.g. `Is it safe to use ` | Ends mid-sentence so the cursor lands where the user must type. This is why it works: it is a sentence to *finish*, not a form to *fill* |
| **Slots** | Typed placeholders, e.g. `Compare [first drug] vs [second drug] for [condition]?` | Rendered as pills, tab-navigable. Each slot declares its type, so a drug slot can autocomplete **from the clinic's own formulary** |
| **Typeahead** | Completes the stem with whole realistic questions | **Curated, static, per task — not LLM-generated.** See below |

**Why typeahead is curated rather than generated at request time, and how it still varies —
see §3.1.** The short version: it has to appear instantly, it must be reviewable clinical content,
and variety comes from pool size and rotation rather than from a live model call.

**Sub-menus.** One task in Heidi's Treat panel carries a chevron — *Compare treatment options*
opens a second level (compare efficacy / risks / management strategies). Support one level of
nesting, no more. Two levels is a form.

**The standing disclaimer.** Heidi keeps a permanent line under the composer: *"Medical knowledge
only. Not for autonomous decision making. Check sources and use your clinical judgement."* Adopt the
same, with one change — ours must also say the assistant has no access to patient records, because
ours genuinely doesn't and users will otherwise assume it does. Exact wording in §10.6. Per
**PHI-5**, it must not claim anything the code does not do.

---

## 3.1 Suggestion variety (decision D6)

**The observation.** Heidi's suggestions differ every time a task is opened. Comparing two opens of
the same stem:

```
open 1:   How to evaluate  new onset atrial fibrillation?
open 2:   How to evaluate  a patient with new onset atrial fibrillation?

open 1:   How to evaluate  a patient with chest pain?
open 2:   How to evaluate  chest pain in the emergency department?
```

Same topic, **differently phrased**. A shuffle of a fixed list returns byte-identical strings, so
Heidi is generating these with a model rather than rotating a pool. Worth having: variety is what
communicates the *breadth* of what the assistant can be asked, which is the whole point of the
guided surface.

**Four ways to get it.**

| Approach | Pros | Cons |
|---|---|---|
| **A.** Rotate a larger curated pool — ~12 per task, show 4 per open *(do now)* | Instant. Zero marginal cost. Stays a reviewable clinical artefact. Roughly a day, most of it writing suggestions | Phrasing never varies for a given topic, and a frequent user eventually sees the whole pool |
| **B.** Generate on every chip click, as Heidi appears to | Genuinely fresh, including rephrasing | Four costs, below. Rejected |
| **C.** Generate **offline** as an authoring step → clinician reviews → pool → rotate at runtime *(the target)* | Variety of B with the runtime cost and safety of A. The pool stays reviewable. Refreshable on a cadence | Needs an owner for the review, and somewhere to keep the pool |
| **D.** Scheduled job regenerates the pool weekly, unreviewed | Refreshes itself with no human in the loop | Drops the review, which is the part that matters clinically. C without its main benefit |

**Why B is rejected — four specific costs, the first being decisive:**

1. **Latency on the fastest surface in the product.** `AI Settings.narzim_assistant_max_tokens` is
   350 precisely because this assistant is tuned for speed. Heidi's suggestions appear instantly,
   which means they are pre-generated or cached; generating on click puts a spinner where text
   should already be.
2. **Cost per panel-open, with no answer produced.** Users open a panel to browse and close it
   again. Every glance would bill tokens.
3. **The suggestions stop being reviewable.** Regenerated each time, there is no artefact anyone can
   inspect, so nobody can ever assert that the clinic's suggestions are clinically appropriate.
   This matters more here than for Heidi: its own examples are visibly adult and inpatient
   ("acute kidney injury in hospitalized patients", "secondary causes of hypertension"), whereas
   this product is pediatric-and-general with `es-MX` as the default locale. Unreviewed generation
   will drift toward the US adult literature the model was trained on.
4. **The system argues with itself.** A generated suggestion can be one the scope classifier then
   refuses.

**Recommended: A now, C as the target.** A delivers the variety being asked for, today, with no new
risk. C is where it should end up, and it needs the reviewer question in §11.5 answered first —
which is the same blocker, so answering it once unblocks both.

### 3.1.1 A, as shipped (2026-09-08)

**Pools.** 10 suggestions per task, 14 tasks, both locales — **280 strings**, up from 52. Four are
shown at a time. Written for a pediatric-and-general clinic with `es-MX` as default, deliberately
not the adult/inpatient slant a general model produces: the pools carry the febrile infant under
three months, failure to thrive, croup severity, the Westley score, BMI percentile, corrected age
for a preterm infant, and the Cartilla Nacional de Vacunación. The Spanish set is localised, not
translated (`vida suero oral`, `falla de medro`, `escabiosis`, `TDAH`).

**These are DRAFTED, NOT CLINICALLY APPROVED.** They are clinical content living in a code file and
they need the named reviewer §11.5 asks for. Nothing about them is signed off.

**Rotation is a shuffled deck, not random picks.** Random picking repeats, and a repeat is the exact
thing the feature exists to avoid. Dealing from a shuffle guarantees every suggestion in a pool
appears once before any repeats, and on reshuffle the indices currently on screen are pushed to the
back of the new deck — so the wrap-around cannot re-show the same four. One deck per task, so tasks
rotate independently.

**Where the deal happens, and why it matters.** In the click handler for the chip (rotating every
task in the group) and for the task itself — never during render, because `Math.random()` during
render is a Next.js hydration mismatch. The deck lives in a ref (bookkeeping, must not trigger a
render); the dealt indices live in state (they are what renders).

**Filtering searches the whole pool, not the dealt four.** Once the user types past the stem, a real
match sitting outside the four on screen would otherwise be invisible. Only the untouched-stem case
shows the dealt subset.

**Guards worth keeping:** a pool at or below four is not rotated (dealing would re-show the same
items), and a deck sized for a stale pool is discarded rather than indexed off the end — which is
what happens on a locale switch.

Tested in `guided-tasks.test.ts` (11 cases). The wrap-around no-repeat assertion runs 200 times,
because a randomised invariant can pass once by luck.


**What makes C better than Heidi rather than equal to it.** Under C the *candidate topics* need not
come from the model's general knowledge. They can be seeded from **this clinic's own most common
presentations** — aggregate counts over `Diagnosis` and chief complaints, de-identified, with the
minimum cell size §5.1 already requires. "Workup for…" would then offer what this clinic actually
sees rather than fever of unknown origin in adults. That is the same argument as the formulary
(§4.1), and no external assistant can reproduce it.

**Implementation notes, recorded because both are easy to get wrong:**

- **The rotation seed must be set in an event handler or an effect, never during render.**
  `Math.random()` during render produces a Next.js hydration mismatch.
- **The seed must stay stable while the user types**, or the list reshuffles on every keystroke.
  Re-seed when a task is opened or the stem changes, not on each render.
- Avoid repeating the previous set, so two consecutive opens visibly differ rather than differing
  only on average.

## 4. Look up — "I need a fact, fast"

The reference-lookup category: dosing, safety, guidelines. Highest expected volume.

| Task | Stem | Backed by |
|---|---|---|
| Check dosing of a drug | `Dosing for [drug] in [population]?` | **Deterministic calculator + formulary** |
| Check drug safety or interactions | `Is it safe to use [drug] in [situation]?` | Model knowledge + drug data source (§10.3) |
| Look up a guideline recommendation | `What does [guideline] recommend for [condition]?` | Model knowledge + curated NOM/AAP set |
| Get advice on tapering a medication | `How do I taper [drug] after [duration]?` | Model knowledge |
| Look up something in my documents | *(opens the upload picker)* | **Existing** redacted-document path |

### 4.1 Check dosing of a drug — where we can beat a general assistant

**WHY THIS ONE FIRST.** `CLAUDE.md` §1 names clinical AI safety as *"live, and the weakest area"*:
contraindications, interactions, age-appropriateness and weight-based dosing exist as **prompt
text, not code**. Weight-based pediatric dosing is the highest-consequence arithmetic in this
product, and an LLM does arithmetic badly while sounding completely certain.

**HOW.** Two things behind one answer:

1. A **deterministic calculator tool** — declared units, an explicit max-dose ceiling, and a refusal
   when a required input is missing rather than a silent assumption of 10 kg. It returns the
   arithmetic *and its inputs* so the answer is checkable.
2. **`search_medication_catalog`**, which reads this site's real `Medication` master.

**The formulary is the differentiator, and it is verified available.** All seven catalogue tools in
`services/ai_tools.py`'s `TOOL_REGISTRY` take `patient` and `encounter` kwargs only because the
registry has a uniform signature — **none of them reads either one.** Confirmed by reading every
body: `search_medication_catalog`, `search_lab_catalog`, `search_diagnosis_catalog`,
`search_procedure_catalog`, `search_therapy_catalog`, `search_complaint_catalog` and
`get_vaccine_catalog` are all PHI-free and reusable here with no modification. They already satisfy
ADR-030: typed, permission-checked, bounded, audited, no raw SQL.

**USER STORY.** A nurse taps `Look up → Check dosing of a drug`, and the composer reads
`Dosing for ` → she types *"amoxicillin for a 18 kg child"* → **the system shows**
"45 mg/kg/day divided BID = **405 mg per dose**, twice daily (810 mg/day). Ceiling for this
indication is 90 mg/kg/day, so this is within range. Your formulary stocks 250 mg/5 mL and
500 mg/5 mL — 405 mg is 8.1 mL of the 250 mg/5 mL suspension. There is no 125 mg/5 mL item."
→ **the database contains** an `AI Prompt Log` row naming the tools called, with tokens and no PHI
→ **consequence:** a dose that is right, visibly right, and dispensable from her own shelf.

**EXAMPLE of the gap today.** The same question returns a correct textbook answer listing
125 / 250 / 400 mg/5 mL — two of which this clinic cannot dispense. Not a hallucination; the
pharmacology is right. Just unactionable, and she cannot tell the difference. A general assistant
cannot fix this, because it does not know your pharmacy. **This is the capability no external tool
can match.**

**Tier:** PHI-free. Weight is a number the user typed. The moment it is read from a `Patient`
record this becomes a different feature with a different approval.

### 4.2 Check drug safety or interactions

**Stem:** `Is it safe to use [drug] in [situation]?`

**Curated typeahead** (the shape Heidi uses, adapted to a pediatric-and-general clinic):

- `…metformin during pregnancy?`
- `…amoxicillin in a patient with a penicillin allergy?`
- `…ibuprofen in a child with dehydration?`
- `…combination oral contraceptives with a history of DVT?`
- `…azithromycin with a prolonged QT interval?`

**The honest limitation, stated plainly.** Interaction checking from model recall is not a drug
database. It will be right most of the time and confidently wrong occasionally, and "occasionally"
is unacceptable for interactions. Two options, and this needs a decision (§10.3): license a real
interaction dataset, or ship this task with an explicit "verify against the insert" line and no
claim of completeness. **Do not ship it silently relying on model recall** — that is precisely the
prompt-text-not-code weakness the constitution already flags.

### 4.3 Look up a guideline recommendation

**Stem:** `What does [guideline] recommend for [condition]?`

**Our jurisdiction is the differentiator.** [ADR-018](../adr/adr-018-multi-jurisdiction-compliance.md)
sets `mx` as default, and the immunization module is already built against the **Mexico EPI
schedule** and NOM-036-SSA2. So the curated guideline set should lead with **NOM norms and the
Cartilla Nacional de Vacunación**, then AAP/WHO — not the US-first default a general assistant
gives. `get_vaccine_catalog` returns *this facility's actual schedule*, so a vaccine question can be
answered against what the clinic really offers rather than the universe of vaccines.

### 4.4 Get advice on tapering a medication

**Stem:** `How do I taper [drug] after [duration]?` — e.g. prednisone after 3 weeks, an SSRI after
long-term use, a benzodiazepine. Model knowledge with a clinical caveat; low complexity, real value.

### 4.5 Look up something in my documents

**This already exists** — it is the upload path in `send_message`. The task chip surfaces a feature
users currently have to discover via a paperclip.

**Compliance note, unchanged from today:** extracted text is masked by `redact_text()` before it
reaches the model, uploads are **never persisted** (`send_message` no longer calls
`save_private_file` under any circumstances), and a dedicated PHI pre-check refuses patient-specific
documents before the answer call. The one standing exception is an image with no OCR-extractable
text — an X-ray photo — which goes to the model as raw bytes by explicit prior decision
(`NARZIM_AI_ASSISTANT_DESIGN.md` §15). Surfacing this task will increase upload volume, so that
exception deserves a fresh look, not a silent inheritance.

---

## 5. Work up — "help me think about this presentation"

Reasoning support. Highest clinical value, and the category where a wrong answer costs most.

| Task | Stem | Backed by |
|---|---|---|
| Plan a diagnostic workup | `Workup for [presentation]` | Model knowledge + `search_lab_catalog` |
| Evaluate a clinical finding | `How should I evaluate [finding]?` | Model knowledge |
| Calculate a clinical risk score | `Calculate [score] for [inputs]` | **Deterministic — code, never the model** |
| Help interpret test results | `What does [result] suggest in [context]?` | Model + `Lab Test Template` ranges |
| Generate a differential diagnosis | `Differential for [presentation]` | Model knowledge |

### 5.1 Plan a diagnostic workup

**Stem:** `Workup for ` · **typeahead:** `…new-onset atrial fibrillation` · `…chest pain with
suspected myocardial infarction` · `…fever of unknown origin in adults` · `…acute pancreatitis` ·
`…the febrile infant under 3 months`.

**The improvement over a general assistant:** cross-check the suggested panel against
`search_lab_catalog`, which reads this site's real `Lab Test Template` master. Its own docstring
warns about exactly the trap that matters — *"watch for a COMBINED entry (e.g. 'ESR and CRP') that
already covers what might otherwise look like two"*. So the answer becomes "order these four; CRP is
already inside your combined ESR+CRP panel; ferritin isn't in your catalogue and needs a send-out."
That is a workup a clinician can actually order.

### 5.2 Calculate a clinical risk score — deterministic, non-negotiable

**Stem:** `Calculate [score] for ` · CHA₂DS₂-VASc, Wells, CURB-65, Centor, qSOFA, GCS; pediatric:
PEWS, the Westley croup score, bilirubin-nomogram risk zone.

**This must be code.** A risk score is arithmetic over a fixed rubric with a documented cut-off, and
an LLM will produce a plausible number with an undetectable error. **Rule 9** (deterministic
pipelines, explicit state) applies directly. The tool returns the score, **every input it used**,
and the interpretation band — so a clinician can check the inputs rather than trust the total.
Refuse rather than assume when an input is missing.

**Inputs are values the user types.** Age and sex are risk-score inputs, and typed as bare values
they are not an identifier — but this is the task closest to the PHI line, so its stem must ask for
values, never for a patient.

### 5.3 Help interpret test results

**Stem:** `What does [result] suggest in [context]?`

**Reference ranges should come from `Lab Test Template`, not the model** — the clinic's own
lab-specific ranges, not a generic textbook interval that may not match the analyser that produced
the number.

**The PHI-nearest task in the whole design.** A clinician's instinct will be to paste a result
block, which in real life arrives with a name and an MRN attached. Two mitigations, both needed:
route this task through the **document path** (which redacts) when the user pastes a block, and make
the stem itself ask for values. The §2 fix is what stops the typed-prose case.

### 5.4 Evaluate a clinical finding · 5.5 Generate a differential diagnosis

`How should I evaluate ` (an incidental finding, a murmur, microcytic anaemia) and
`Differential for ` (a presentation, not a patient). Model knowledge with the clinical caveat.
Differentials must be framed as *considerations to rule out*, never a ranked verdict — **Rule 6**,
and the LLM must not be the thing that decides.

---

## 6. Treat — "what do I actually do"

| Task | Stem | Notes |
|---|---|---|
| Compare treatment options *(sub-menu)* | `Compare [first drug] vs [second drug] for [condition]?` | Second level: efficacy · risks · management strategies |
| Find first-line medication | `First-line treatment for [condition]` | **Cross-check the formulary** |
| Escalate or step up treatment | `How do I step up treatment for [condition] when [current therapy] is failing?` | |
| Treat an acute condition | `Initial management of [acute condition]` | |
| Find add-on therapy options | `Add-on options for [condition] already on [drug]` | Cross-check the formulary |

### 6.1 Compare treatment options — the sub-menu case

**Level one** sets the axis of comparison, because "compare A vs B" is under-specified — a clinician
means efficacy, or risk, or cost, and the answer differs completely:

- `Compare efficacy of [first drug] vs [second drug] for [condition]?`
- `Compare risks of [first therapy] vs [second therapy] for [condition]?`
- `Compare management strategies for [condition A] vs [condition B]?`

**Curated typeahead:** `…efficacy of metformin vs glipizide for type 2 diabetes` ·
`…risks of statin therapy vs lifestyle changes for hyperlipidemia` · `…management strategies for
acute vs chronic pancreatitis`.

**UI note:** the slot pills are the mechanism that makes this usable. `Compare [first drug] vs
[second drug] for [condition]?` prefilled with three tab-navigable pills is three short answers,
where the same request typed as a sentence is a paragraph of composition. Each drug pill
autocompletes from `search_medication_catalog` — so the comparison is between two things the clinic
can actually dispense.

### 6.2 Find first-line medication — the formulary answer again

**The pattern worth repeating across Treat:** answer the clinical question from guideline knowledge,
then reconcile it against `search_medication_catalog`. "First-line is X. You stock it at 250 mg and
500 mg. The guideline's second-line Y is not in your formulary — the nearest item you have is Z."

No general-purpose assistant can produce that second paragraph. It is the whole argument for
building this inside the EHR rather than telling staff to open one in another tab.

---

## 7. What backs an answer, and how it is bounded

| Backing | Used by | Compliance shape |
|---|---|---|
| Model general knowledge | most tasks | PHI-free. Needs the clinical caveat (already in the prompt) |
| **Catalogue tools** (7, verified PHI-free) | dosing, workup, first-line, add-on, compare, vaccines | ADR-030-compliant already. Log tool **names** to `AI Prompt Log`, never arguments (**Rule 10**) |
| **Deterministic calculators** | dosing, risk scores | Code. Returns inputs alongside the result |
| `Lab Test Template` ranges | interpret results | Clinic's own ranges, PHI-free |
| Redacted document path | documents, pasted results | Exists. Masked, never persisted |

**Sources selector.** Heidi exposes a `Sources` control in the composer. The equivalent worth having
is narrow and honest: let the user scope an answer to **our formulary/catalogues**, to **general
medical knowledge**, or to **their uploaded document**. Do not build a general web-search source —
that adds an unnamed subprocessor and **PHI-1** requires every subprocessor to be named in the
active `ComplianceProfile`.

**Citations.** Clinical staff calibrate on provenance, and an unattributed paragraph and "per the
2024 AAP guideline" deserve different weight. Two cautions: an LLM can fabricate a citation, and a
fabricated one is worse than none — so instruct omission when unsure, and spot-check before anyone
is told to trust it.

---

## 8. Scope gate and i18n

**Every stem in this document classifies as `clinical`** under
[`NARZIM_SCOPE_GATE.md`](NARZIM_SCOPE_GATE.md) — drugs, dosing, interactions, diagnoses, lab values,
procedures, vaccines are all explicitly permitted. So guided tasks need **no change to the
classifier**, which is a strong signal the design fits the assistant that exists.

Two consequences worth stating:

- **Guided tasks must not skip the scope check, and must not skip the §2 pre-filter either.** A
  prefilled stem is an editable string, not a constrained input — treat a message identically
  whether it started as a stem or as free text. The check is cheap, and the audit row
  (`scope_verdict`, `scope_category`) is how the gate's false-positive rate gets measured on real
  traffic.
- **Every stem, task label and typeahead string is user-visible text**, so all of it goes through
  the message catalogues — `CLAUDE.md` §13 rule 10, `es-MX` + `en-US`. This is not a translation
  afterthought: a Spanish-speaking clinician gets `¿Es seguro usar …?`, and the typeahead examples
  should be *localised, not translated* — Mexican brand names and NOM references, not literal
  renderings of a US list.

---

## 9. Deliberately out of scope in v2.0

**Prepare · Write · Fill form** are Heidi's other three chips and are not specified here, for one
reason each:

| Chip | Why deferred |
|---|---|
| **Write** | Drafting a referral or letter is patient-specific by nature. That is the encounter copilot's job, inside an encounter where the record is available and attribution survives (**PHI-7**) |
| **Fill form** | Same, plus it implies writing to the record. Note the master plan already tracks **5 write tools bypassing physician review in the frontend** — do not add a sixth path |
| **Prepare** | Overlaps encounter preparation, which needs the patient. Revisit after the AWS/Bedrock migration gives a BAA |

**Also explicitly not this, whatever the chip:** free-form SQL or "ask anything about the database"
(banned by ADR-030 — the specific reason Frappe_Assistant_Core is disallowed for PHI flows);
autonomous actions (**Rule 6**, **Rule 9** — the assistant proposes, a human acts); a vector store
over patient notes (**Rule 5**, plus the deliberate no-vector-DB decision in `CLAUDE.md` §3); and
any UI copy claiming the product is "HIPAA compliant" (`CLAUDE.md` §11, unconditional).

---

## 10. Decisions taken (2026-09-08)

Answered by the product owner. Recorded here; the items still open follow in §11.

| # | Decision | Consequence |
|---|---|---|
| **D1** | **§2 pre-filter lands FIRST**, before any guided task | Guided tasks ship onto a clean base, and the launch can honestly be called a privacy improvement. Sequence: MRN-format + patient-name pre-filter → `redact_text()` as second layer → guided tasks |
| **D2** | First build is **shell + formulary context** | Chips, task panels, stems and typeahead *plus* this clinic's own formulary and lab catalogue folded into the prompt. The deterministic dose calculator is phase 3 |
| **D5** | **Positive-only catalogue claims. No row-count threshold** | Added 2026-09-08 after measuring the live data — see §6.1. The assistant may state what the catalogue *holds*; it may never state that something is absent. A miss produces silence, not a denial |
| **D6** | **Suggestions vary by rotating a curated pool, not by generating per click** | Rotate ~12 per task showing 4, now; pre-generated-and-reviewed pool as the target. Runtime model generation rejected on latency, cost, reviewability and scope-gate grounds — see §3.1 |
| **D3** | **Include** "Check drug safety or interactions", with an explicit limitation line | Ships with *"Not a complete interaction check — verify against the product insert"* on every such answer, and makes no completeness claim. Revisit if a real interaction dataset is licensed (§11.1) |
| **D4** | **No guided-only mode.** Free text stays for every role | Same composer for `EB_Front Desk` as for `EB_Practitioner`. The §2 pre-filter is the control regardless of role, and a wall would just be worked around by asking a clinician to type it. No `AI Settings` flag is built |

## 10.1 Why the formulary claim is positive-only (D5)

**The measurement that decided it.** The `Medication` master on the live dev site holds three rows:

```
generic_name   form      strength   uom
Amoxiclin      Capsule      10.00   Milligram    <- misspelled "amoxicillin"; 10 mg is also nonsense
Paracetamol    Tablet        0.00   Milligram    <- zero strength
Paracetamol    Tablet      500.00   Milligram    <- the only sane row
```

The tool filters on `generic_name`, so a question about **amoxicillin returns zero matches** — not
because the clinic does not stock it, but because it is spelled `Amoxiclin`. And a question about
paracetamol returns a row claiming **0 mg**.

**What that rules out.** A row-count threshold ("only make formulary claims once the catalogue has
N entries") was the original plan and is wrong, because row count does not predict whether any
*particular* answer is trustworthy. At **any** catalogue size a misspelled entry still yields a
false negative and a zero-strength entry a false positive. It also needs a number nobody can
justify: a specialist clinic legitimately stocking forty drugs is indistinguishable from an
unpopulated one.

**What replaces it.** `match_count == 0` is ambiguous — it means *not stocked* **or** *spelled
differently* **or** *never populated*. So:

- **A match** → state it. *"Your formulary lists Paracetamol 500 mg tablets."* True and useful
  whether the catalogue holds three items or three thousand.
- **No match** → say **nothing** about stock. The answer is exactly what it is today. No
  regression, and no false negative.
- **A strength of 0 or below is dropped from the rendered line**, but the drug is still named — it
  genuinely *is* in the catalogue, so saying so is true, while quoting "0 Milligram" would not be.

The failure mode this avoids is asymmetric and clinical: telling a clinician they cannot get a drug
they can get is consequential, and it is a statement the system has no basis to make.

**How it is implemented, and why not as a tool call.**
`integrations/*.py::answer_general_question` has no tools deliberately — its docstring calls that
*"the whole guardrail (§4.5 of the design doc), not a prompt instruction alone."* A tool loop would
change that guardrail. So `services/formulary_context.py` retrieves deterministically **before** the
call and the result is folded into the prompt as text, exactly as the redacted document block
already is. Same guardrail, and one edit covers both providers and both the streaming and
non-streaming paths.

The rule lives in the system prompt (**`narzim-assistant-v3.txt`**, a new version rather than an
edit to v2, so an answer stays attributable to the prompt that produced it) *and* is repeated in the
retrieved block itself — a rule that exists only in the system prompt is one prompt edit away from
being lost.

**Lab names needed fuzzy matching, not exact.** The real templates on this site are
`C-reactive protein (CRP)`, `PERFIL LIPÍDICO`, `GLICEMIA Y FUNCIÓN RENAL` — multi-word, accented,
parenthesised. Exact matching missed every one of them, which would have left the entire lab half of
this feature silently dead. Matching is now accent-insensitive with parenthesised-abbreviation
support, so "CRP" and "perfil lipidico" both resolve.

**Separately: this data is a live bug independent of Narzim GPT.** `Amoxiclin` at 10 mg means a
clinician cannot find amoxicillin in the physician's own medication search box either
(`encounters/api.py::search_medications` uses the same matching), and `search_medication_catalog`
exists precisely so the encounter copilot does not create duplicates. Populating and correcting the
`Medication` master is a data task for the clinic and is where most of this feature's value
actually comes from — D5 only ensures that shipping does not wait for it, and that every corrected
row starts helping immediately with no flag to flip.

## 11. Decisions still open

1. **Build order within the shell.** Recommended: **Look up** first (highest volume, and §4.1 is the strongest single
   capability), then **Work up**, then **Treat**. Treat last deliberately — it is the category where
   a wrong answer does most harm, so it should ship after citations and formulary cross-checking are
   proven in the two lower-stakes categories.
3. **Drug interaction data (§4.2)** — license a real dataset, or ship with an explicit
   "verify against the insert" limitation? A licensed source is a new subprocessor and needs a
   `ComplianceProfile` entry in the same commit (**PHI-1**).
4. **Risk score list (§5.2)** — which scores, and who signs off on each rubric and cut-off? A wrong
   cut-off in code is worse than no calculator, because it will be trusted.
5. **Typeahead curation** — who owns the clinical accuracy of the suggestion lists? They are
   clinical content in a code file, and they need a named clinical reviewer, not a developer's
   judgement.
6. **RESOLVED 2026-09-08 — disclaimer wording.** Shipped as
   *"Medical knowledge only. Not for autonomous decisions. Check sources and use your clinical
   judgement."*

   I had argued for a middle clause — *"Narzim GPT has no access to patient records"* — on the
   grounds that ours genuinely has none and users would assume otherwise. The product owner removed
   it, and on reflection the argument for keeping it was weaker than it looked: since D1 landed, a
   question naming a patient is **refused outright with an explanation naming the patient's chart
   and the encounter copilot**. The user now learns the limit at the moment it matters, from a
   message they cannot miss, instead of from a line of permanent small print they will read once.
   A shorter standing disclaimer that people actually read beats a longer one they tune out.

   No **PHI-5** concern either way: that rule forbids claiming what the code does *not* do, and
   removing a true statement does not engage it.
7. **Measurement.** `scope_verdict` and `scope_category` are already recorded on every message. A
   month of them would show which tasks staff actually reach for and which refusals dominate,
   replacing the prioritisation guesswork in item 2 with data.

8. **Guided-only mode for non-clinical roles?** Free text is the residual risk §1 cannot remove, and
   it is not equally necessary for every role. `EB_Front Desk` and `EB_Clinic Staff` today get the
   same open box as a physician, but their legitimate use is almost entirely platform how-to and
   catalogue lookups — which the guided tasks cover. Restricting those two roles to stems would
   remove most of the free-text surface at little cost to them, while `EB_Practitioner` /
   `EB_Nurse` / `EB_Healthcare Admin` keep the open box they genuinely need.

   The cost is real and should not be waved away: a front-desk user with an unusual but legitimate
   question hits a wall, and walls get worked around — most likely by asking a clinician to type it,
   which achieves nothing. **Not recommended either way here; it is a product judgement.** If
   adopted it is a `ComplianceProfile` or `AI Settings` flag, not a hardcode, and it must fail
   *open* to guided mode rather than closed to no assistant at all.

9. **First-build scope.** The UI shell (chips → tasks → stems → typeahead) and the backing tools
   (formulary cross-check, dose calculator) are separable. The shell alone is a real improvement and
   is days of work; the tools are the differentiator (§4.1, §6.2) and are weeks. Shipping the shell
   first means the first version answers from model knowledge only — better discovery, same answers.
   Shipping together means a longer wait for a materially better product.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.3 | 2026-09-08 | Ashutosh (AI-assisted) | §3.1.1: approach A shipped — 280 curated suggestions, shuffled-deck rotation, and the hydration/filtering constraints it had to respect |
| 3.2 | 2026-09-08 | Ashutosh (AI-assisted) | §3.1 and decision D6: suggestion variety by pool rotation, with runtime generation costed and rejected; clinic-seeded candidate topics named as the differentiator |
| 3.1 | 2026-09-08 | Ashutosh (AI-assisted) | §11.6 resolved: the disclaimer ships without the no-patient-access clause, since D1 now refuses such questions at the point of asking |
| 3.0 | 2026-09-08 | Ashutosh (AI-assisted) | Decision D5 and §10.1: catalogue claims are positive-only, the row-count threshold is rejected on measured data, and the retrieval is prompt-context rather than a tool call so `answer_general_question`'s no-tools guardrail survives |
| 2.2 | 2026-09-08 | Ashutosh (AI-assisted) | §10 items 8-9 added: guided-only mode per role, and first-build scope (shell vs shell+tools) |
| 2.1 | 2026-09-08 | Ashutosh (AI-assisted) | §1 corrected: guided tasks are a nudge, not a control — the free-text box remains, so §2 is a prerequisite rather than a follow-up |
| 2.0 | 2026-09-08 | Ashutosh (AI-assisted) | Rewritten as a guided-task design (Look up · Work up · Treat) on the Heidi Health pattern, replacing the tiered capability inventory. Records that all seven catalogue tools are verified PHI-free and reusable |
| 1.0 | 2026-09-08 | Ashutosh (AI-assisted) | Initial capability roadmap: three-tier PHI model, the unredacted-question finding, recommended sequence |
