# Remedisys AI — Current System Audit

**Doc status:** record · **Created:** 2026-08-13 by Sarvesh-SocialAngel · **Updated:** 2026-08-18 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Document type** | Factual audit. No recommendations in §1–19; §20 only after them |
| **Date** | 2026-08-13 |
| **Verified against** | `dev` @ `450aace` (backend), `/Users/apple/Healthcare_next_app` (frontend), live site `marley.local` (DB + AI Settings) |
| **Method** | Code read directly; every claim carries a `file:line`. Numbers re-queried from `tabAI Prompt Log` / `tabAI Transcript Segment` / `tabAI Encounter Record` on 2026-08-13, not taken from prior docs |
| **Rule** | Where code and documentation disagree, code wins and the drift is recorded in §18 |
| **Production code changed** | None. Read-only audit |

---

## 1. Executive summary

Remedisys AI is **one bounded tool-calling agent, plus eight single-shot LLM
generators, sitting on top of a deterministic Frappe/ERPNext clinical core.**

- **There is exactly one agent.** `ask_copilot` is it. "Analyze" is not a second
  system — `analyze_encounter()` calls `ask_copilot()` with a fixed instruction string
  (`api/v1/ai/api.py:1285`). Same model, same 36 tools, same loop, same prompt file.
  Every difference between the two surfaces is the *user message*.
- **The LLM never touches the database.** Verified by exhaustion: `services/ai_tools.py`
  contains **zero** `.insert(` / `.save(` / `db_set` / `set_value` calls. Reads go through
  13 bounded read tools; writes return suggestion objects.
- **But five write tools do reach the permanent record — via the frontend.**
  `encounter-screen.tsx:3217-3263` auto-applies the `patient_draft` patch with an
  immediate `updatePatient.mutate(...)`, no confirmation step. So the claim
  "23 write tools return suggestion objects only and do not write to DB" is
  **true of the backend tool layer and false end-to-end** (§5.5).
- **Retrieval already exists, under other names.** Structured tool retrieval, six
  keyword `LIKE` catalog searches, a rolling patient summary with a watermark, and a
  deterministic transcript digest. Zero embeddings, zero vector store, zero pgvector —
  confirmed by grep; the only hit is a comment in `transcript_digest.py:14-16`
  explaining why semantic similarity was *rejected*.
- **The two clinical defects you named are both real, both found, and neither is
  the LLM's fault.** "0 months / neonate" is an integer-division bug in
  `services/ai.py:880`. The `equimosis fácil` carry-over is a prompt-layer failure whose
  fix is now hardcoded in three places. Both are §17.
- **Speaker attribution is a positional guess with three silent fallbacks to
  "doctor."** That, not Deepgram, is the most likely source of `Doctor: … Doctor: …`
  runs (§5).
- **The instrumentation is better than the docs claim and the cost numbers are worse.**
  `cached_tokens` *is* captured now (46% of all agent input is cached). The Anthropic
  8× pricing bug is still live and verified arithmetically. `AI Prompt Log` also holds
  ~180 rows of unit-test `MagicMock` pollution with fabricated costs (§15).

**Where the LLM actually sits:** it is a *transcript-to-draft-suggestion transducer*
and a *clinical-reasoning chat surface*. It is not the system of record, not the
validator, not the persistence layer, and not the speaker identifier. Every clinical
value it produces is re-validated against a Frappe master before it can be saved —
except drug strength, dose rationale, and patient-level history, which are validated
by nothing (§16).

---

## 2. Actual architecture

```
┌─ BROWSER (Healthcare_next_app, Next.js 14 App Router, Vercel) ──────────────┐
│  encounter-screen.tsx  (6.6k lines — draft state, Save/Sign, vitals)        │
│  NarzimAIChatBar.tsx   (chat + Analyze pill + Labs pill)                    │
│  copilot/real-provider.ts (1296 lines — mic capture, Deepgram WS, speakers) │
└───────┬─────────────────────────────────────────┬───────────────────────────┘
        │ audio: direct WSS, bypasses our server  │ JSON: BFF route handlers
        ▼                                         ▼
┌─ DEEPGRAM ─────────────────┐   ┌─ NEXT.JS BFF (src/app/api/ai/*/route.ts) ──┐
│ nova-3 · language=multi    │   │ injects the physician's Bearer JWT          │
│ diarize=true               │   │ browser never holds a token                 │
└────────────────────────────┘   └───────┬─────────────────────────────────────┘
                                         ▼
┌─ FRAPPE v16 (remedisys_healthcare_ai) ──────────────────────────────────────┐
│  api/v1/ai/api.py  (1778 lines)  ← 16 whitelisted methods                   │
│      ask_copilot ─────────────────────────► THE ONLY AGENT                  │
│      analyze_encounter ── calls ask_copilot with _ANALYZE_PROMPT             │
│      generate_suggestions / generate_soap_draft / resegregate_transcript /   │
│      generate_review_details / create_master / analyze_lab /                │
│      upload_and_analyze_document        ← single-shot, NO tools              │
│                                                                             │
│  services/llm.py::get_llm_client()   ← provider switch (defaults ANTHROPIC)  │
│  integrations/openai.py (1511)  ask_copilot_agent_stream, _MAX_TOOL_ITER=20  │
│  integrations/anthropic.py (1312) same contract, Claude wire format          │
│  services/ai_tools.py (1707)  TOOL_REGISTRY — 36 tools, 13 read / 23 write   │
│  services/ai.py (946)  build_encounter_context, log_prompt_call, fingerprint │
│  services/transcript_digest.py (305)  deterministic digest, no LLM           │
└───────┬─────────────────────────────────────────────────────────────────────┘
        ▼
   MariaDB — ERPNext Healthcare core doctypes + 18 AI doctypes
```

**Scale of the AI surface (measured, not documented):** 63 `@frappe.whitelist()`
methods across `api/v1/ai/`, `api/ai/{sessions,segments,auth,realtime,lab_extraction,
lab_panel_extraction,lab_result_summary,imaging_extraction,patient_clinical_summary}.py`
and `api/v1/narzim_assistant/api.py`. The docs describe roughly seven.

---

## 3. Full AI call flow

### 3.1 The two surfaces, side by side

| | **Analyze pill** | **Ask Narzim AI** |
|---|---|---|
| Frontend | `NarzimAIChatBar.tsx` (pill) | `NarzimAIChatBar.tsx` (text box) |
| BFF route | `src/app/api/ai/analyze/route.ts` | `src/app/api/ai/encounter-chat/route.ts` + `chat/route.ts` |
| Backend | `analyze_encounter()` `api.py:1201` | `ask_copilot()` `api.py:751` |
| Service | **`ask_copilot()` — identical** | `ask_copilot()` |
| Agent loop | `ask_copilot_agent_stream()` `openai.py:1278` | same |
| Provider | `AI Settings.llm_provider` = **OpenAI** (live) | same |
| Model | **`gpt-5-mini`** → API reports `gpt-5-mini-2025-08-07` | **same** |
| Prompt file | **`prompts/ask-copilot-v2.txt`** | **same** |
| User message | `_ANALYZE_PROMPT` (fixed, `api.py:966-1009`) or `_ANALYZE_LABS_PROMPT` | physician's typed text |
| Tools | 36 (23 write only if caller has Encounter write) | same |
| Max iterations | **20** (`openai.py:1275`) | same |
| Streaming | **Non-streaming to the client.** A generator exists (`ask_copilot_agent_stream`) but `ask_copilot_agent()` drains it (`openai.py:1424-1439`); no SSE endpoint consumes it | same |
| Result cache | **Yes** — fingerprint reuse, `AI Settings.enable_analyze_cache` | No |
| Persisted as | `AI Encounter Chat Message` `kind="analysis"` (assistant turn only) | `kind="chat"` (both turns) |
| DB writes by the call | `AI Prompt Log` ×1, `AI Encounter Chat Message` ×1–2 | same |
| Doctor approval | Required for encounter fields; **NOT required for patient-level** (§5.5) | same |

### 3.2 The chain, step by step

```
1. Dr clicks Analyze / types a question
2. BFF route handler → getAccessToken() from httpOnly cookie → frappeFetch(...)
3. api.py::analyze_encounter  or  ask_copilot
     _require_auth()                          api.py:23   — rejects Guest
     _require_encounter_read(encounter)       api.py:385   — frappe.has_permission
     [analyze only] fingerprint → cache probe api.py:1225-1283
     allow_write = has_permission(..,"write") api.py:808   — gates the 23 write tools
     ctx = build_encounter_context(enc,
                include_catalogs=False)       api.py:819   — the ONLY patient data block
     tools = build_openai_tools(allow_write)  ai_tools.py:1653  (lru_cache, 2 entries)
4. llm.ask_copilot_agent(prompt, history, ctx, tools, call_tool)
5. LOOP, up to 20 iterations (openai.py:1351):
     POST api.openai.com/v1/chat/completions
       model, max_completion_tokens=3700, reasoning_effort="low",
       tools=[36], tool_choice="auto", timeout=60s
     no tool_calls  → reply = message.content; BREAK
     tool_calls     → for each: execute_tool(...)  ai_tools.py:1687
                      append {"role":"tool", content: json} and loop
   loop exhausted → reply = "I've gathered some information but need you to ask again…"
6. execute_tool dispatch:
     READ  → require_permission → frappe.get_all (bounded) → dict
     WRITE → validate args → return {"action": <ClinicalSuggestion>} (no DB)
           → or {"patient_draft": {...}} for the 5 patient-level tools
7. back in ask_copilot:
     log_prompt_call(...)                     services/ai.py:416
     _persist_chat_turn(...)                  api.py:1023
     return {reply, actions[], patient_draft, follow_up}
8. FRONTEND:
     actions       → fillFormFromSuggestions → applySuggestionToEnc → local draft state
     patient_draft → onPatientDraft → aiDraft effect → updatePatient.mutate() ⚠ WRITES NOW
9. Dr reviews/edits encounter draft
10. Save   → save_draft()        encounters/api.py:1446 — atomic PATCH, re-validates all
    Sign   → complete_encounter()encounters/api.py:1864 — chief_complaint required, docstatus 0→1
```

**Step 8 is where Rule 6 holds for encounter fields and breaks for patient fields.**

### 3.3 Non-agent LLM entry points (no tools, single call)

| Endpoint | Prompt | Tools | Output | Writes |
|---|---|---|---|---|
| `generate_suggestions` `api.py:545` | `suggest-v2.txt` | none | `ClinicalSuggestion[]` | `AI Prompt Log` |
| `generate_soap_draft` `api.py:610` | `soap-v1.txt` | none | suggestions + version | `AI SOAP Draft`, `AI Prompt Log` |
| `resegregate_transcript` `api.py:711` | `resegregate-v1.txt` | none | `[{speaker,text}]` | `AI Prompt Log` |
| `generate_review_details` `api.py:1304` | `review-details-v1.txt` | none | free text | `AI Prompt Log` |
| `create_master` `api.py:219` | `medication-fields-v1.txt` / `lab-fields-v1.txt` | none | master fields | **`Medication`/`Item`/`Lab Test Template` — real inserts** |
| `analyze_lab` `api.py:1428` | lab-summary family | none | narrative | `Lab Test.custom_ai_summary` |
| `upload_and_analyze_document` `api.py:1483` | `document_summary_v2` schema | none | narrative + `is_medical` | `Patient Medical Record` + `File` if `is_medical` |
| `enhance_text` `api.py:439` | inline constant `api.py:427` | none | text | none |

`create_master` is the one place an LLM output becomes a **master record** —
`_create_medication_master` `api.py:118` inserts a `Medication` **and** a linked `Item`.
It is physician-triggered ("Add to master?"), but the *field values* (dosage form,
strength, strength UOM, class) are LLM-inferred and only enum-validated
(`parse_medication_fields` `services/ai.py:747`). Strength has **no** validation.

---

## 4. ASR / diarization flow

### 4.1 The pipeline, as built

```
Mic (getUserMedia)
  │  single-mic  → MediaRecorder "audio/webm;codecs=opus", 250 ms timeslice
  │  dual-mic    → AudioContext @48 kHz → 2-ch interleaved linear16 PCM
  ▼
Browser WebSocket ── DIRECT to wss://api.deepgram.com/v1/listen?<params>
  │   audio never reaches the Frappe server (ADR-009)
  │   token minted by api.py::mint_deepgram_token → deepgram.py::mint_browser_token
  ▼
Deepgram (streaming)
  │   returns interim + final "Results" messages, word-level speaker indices
  ▼
real-provider.ts::_handleMessage  (line ~1172)
  │   multichannel → channel_index[0] → channelToSpeaker()
  │   diarize      → _groupBySpeaker(alt.words) → _mapSpeaker()
  ▼
finalSegments[] (browser memory)
  │   autosave every 20 s → POST /api/ai/session/segments
  │   stop() → _persistTranscript() → then _syncTranscript() (in-place correction)
  ▼
AI Transcript Segment rows  (speaker ∈ doctor|patient|unknown|system)
  ▼
_buildTranscript() → "Doctor: …\nPatient: …"   (real-provider.ts:1013-1020)
  ▼
LLM — via get_current_transcript tool, tail-truncated at 6000 chars
```

### 4.2 Live configuration (read from `marley.local` AI Settings, 2026-08-13)

| Param | Live value | Source |
|---|---|---|
| `deepgram_model` | **`nova-3`** | AI Settings |
| `deepgram_language` | **`multi`** | AI Settings |
| `deepgram_diarize` | **`1`** (true) | AI Settings |
| `deepgram_multichannel` | **`0`** (false) → **diarization path is the live one** | AI Settings |
| `interim_results` | `true` | `deepgram.py:42` (hardcoded) |
| `endpointing` | `800` ms | `deepgram.py:43` (hardcoded) |
| `punctuate` / `numerals` | `true` / `true` | `deepgram.py:44-45` |
| `smart_format` | **`true` in `mint_browser_token` (`:345`), ABSENT in `mint_session_token`** | divergent builders |
| `utterances` | **NOT sent on the live streaming path.** Only in the unused batch `transcribe()` (`deepgram.py:424`) | — |
| keyterm boosting | on, `nova-3*` only, capped 50 | `deepgram.py:55,201-204` |
| `max_session_minutes` | 60 | AI Settings |

**Two divergent param builders exist** — `mint_session_token` (`:145`, used by
`api/ai/sessions.py`) and `mint_browser_token` (`:267`, used by
`api/v1/ai/api.py::mint_deepgram_token`). They do not produce the same params.
`smart_format` is in one and not the other.

### 4.3 What is and is not captured

| Signal | Captured? | Where |
|---|---|---|
| Word-level confidence | Yes → averaged per segment | `real-provider.ts` `_groupBySpeaker` avgConf |
| Segment confidence | Yes → `AI Transcript Segment.confidence` | live avg **0.837 doctor / 0.848 patient / 0.828 unknown** |
| **Speaker confidence** | **No — Deepgram does not emit one, and nothing derives a proxy** | — |
| **Raw Deepgram speaker index** | **NO — discarded.** `speaker_label` is `NULL` on **all 5,933** live segment rows | `_persistTranscript` never sends it |
| `deepgram_segment_id` | No — never sent | `append_segment` accepts it; caller omits it |
| Interim results | Shown, never persisted | `id:"interim"` replaced in place |

---

## 5. Speaker-role flow — and why `Doctor: … Doctor: …` happens

This is the answer to your specific question. **It is not primarily Deepgram.**
There are five distinct failure points, three of which silently produce "doctor."

### 5.1 The mapping is positional and hardcoded, in two places

```ts
// real-provider.ts:52-55  (the live path)
const SPEAKER_MAP: Record<number, TranscriptSegment["speaker"]> = { 0: "doctor", 1: "patient" };
private _mapSpeaker(raw: number) { return SPEAKER_MAP[raw] ?? "unknown"; }
```
```python
# integrations/deepgram.py:105  (batch path, unused live)
_SPEAKER_ROLES: dict[int, str] = {0: "doctor", 1: "patient"}
```

**Failure 1 — whoever speaks first becomes the Doctor.** Deepgram assigns diarization
indices in order of first appearance. Nothing in this codebase checks *who* speaker 0
is: no voice enrolment, no channel identity, no "the physician started the recording"
heuristic, no confirmation prompt. If the parent or child speaks first — which in a
paediatric clinic is common ("¿Cómo está?" answered before the doctor's first framed
question, or a crying child) — **every patient line is labelled Doctor and every
doctor line is labelled Patient for the whole encounter.** The transcript is then
internally consistent and completely inverted.

**Failure 2 — a third voice becomes `unknown`.** `?? "unknown"` catches index ≥ 2.
In paediatrics there are routinely three speakers (doctor, parent, child). Live data:
**1,307 of 5,933 segments (22%) are `unknown`.** Those reach the LLM as
`Unknown: …` (`real-provider.ts:1018`).

### 5.2 Three silent fallbacks to "doctor"

**Failure 3 — the no-words fallback is hardcoded to doctor.**
```ts
// real-provider.ts, _groupBySpeaker
if (words.length === 0) {
  return [{ id: `seg-${++this.segSeq}`, speaker: "doctor", text: fallbackText.trim(), … }];
}
```
Any final Deepgram result that carries a transcript but no word array is attributed
to the doctor **unconditionally**. No `unknown`, no confidence penalty, no log line.

**Failure 4 — the interim fallback defaults to 0 (= doctor).**
```ts
const speaker = (alt.words?.[0]?.speaker ?? 0) as number;   // ?? 0 → "doctor"
```

**Failure 5 — multichannel defaults to channel 0 (= doctor).**
```ts
const channel = msg.channel_index?.[0] ?? 0;                // ?? 0 → "doctor"
function channelToSpeaker(idx) { return idx === 1 ? "patient" : "doctor"; }
```
Not on the live path (`multichannel=0`), but note `channelToSpeaker` is
*not* symmetric — anything that is not exactly `1` is "doctor", so a 3-channel or
malformed `channel_index` also lands on doctor.

**The observable signature of failures 3–5 is exactly what you reported:** consecutive
`Doctor:` bubbles where the speakers actually alternated. Live data corroborates the
skew — **2,978 doctor vs 1,648 patient segments, a 1.8 : 1 ratio** in a two-party
consultation that should be roughly balanced.

### 5.3 Grouping is per-message, not per-conversation

`_groupBySpeaker` runs on **one `is_final` message at a time**. There is no
cross-message reconciliation, no re-clustering, no post-hoc majority vote. Streaming
diarization also has less context than batch diarization with `utterances=true` — and
`utterances` is **not** sent on the live path (§4.2). The system therefore has strictly
less speaker information available than the unused batch path had.

### 5.4 What the LLM receives

**Never raw speaker IDs. Always role labels.**

- Live/client path: `_buildTranscript()` emits `Doctor: …` / `Patient: …` / `Unknown: …`
- Persisted path: `ai_tools.py:171` emits `f"{(r.speaker or 'unknown').capitalize()}: {r.text}"`

So the LLM sees an **assertion** of role, with no confidence, no
"this may be mislabelled" marker, and no access to the underlying index. It cannot
detect or correct an inversion, and it is not told one is possible. When the mapping is
wrong, the model reasons confidently over a transcript in which the patient prescribes
and the doctor reports symptoms.

### 5.5 The two correction paths (both post-hoc, both physician-initiated)

| Path | Mechanism | Guardrail |
|---|---|---|
| Per-line swap | `setSegmentSpeaker()` `real-provider.ts:816` → debounced `_syncTranscript()` | in-place row update; `append_segment` alone cannot change a stored speaker (`stop()` comment 3a-ii) |
| "Fix speakers" | `resegregate_transcript` → `resegregate-v1.txt` → LLM re-splits + re-labels | **word-multiset check, rejects the whole result if >10% divergence** (`services/ai.py:853-867`) — a genuine deterministic anti-hallucination guard |

Neither runs automatically. Until a physician notices and acts, the mislabelled
transcript is what the agent, `suggest-v2`, `soap-v1` and `review-details-v1` all read.

---

## 6. LLM configuration

All values read from the live site, not from documentation.

| Property | Value | Source |
|---|---|---|
| Provider (live) | **OpenAI** | `AI Settings.llm_provider` |
| Provider (code default) | **Anthropic** — `provider = settings.llm_provider or "Anthropic"`, and `except: provider = "Anthropic"` | `services/llm.py:20-24` |
| Model — Analyze | **`gpt-5-mini`** (API returns `gpt-5-mini-2025-08-07`) | `AI Settings.openai_model` |
| Model — Ask Narzim AI | **`gpt-5-mini` — identical** | same `_get_model()` `openai.py:552` |
| Anthropic model (if switched) | `claude-sonnet-4-6` | `AI Settings.anthropic_model` |
| **Temperature** | **`0.4` is passed and then DROPPED.** `_is_reasoning_model("gpt-5*")` → `reasoning_effort` sent *instead of* `temperature` (`openai.py:708-717`) | so temperature is effectively **provider default (1)** |
| `reasoning_effort` | **`low`** | `AI Settings.openai_reasoning_effort`, default `low` `openai.py:585` |
| Max output / round-trip | **3,700** = `_effective_max_tokens(700)` = 700 + 3,000 reasoning headroom | `openai.py:1353`, `:604-608` |
| `llm_max_tokens_out` | 16,000 — used by the *non-agent* paths, **not** the agent | `AI Settings` |
| Context window | **Not enforced anywhere.** No tokenizer in the app; no pre-flight budget check | max observed input **265,189** tokens |
| Timeout | 60 s per round-trip (agent); 120 s for SOAP/resegregate | `openai.py:684`, `:1154` |
| **Retry** | **None on the agent path.** 429/5xx/timeout → `LLMTransientError` → `frappe.throw` → caught in `ask_copilot` `api.py:873` → logged `Failed` + apology text. Suggestion/SOAP paths retry once on `JSONDecodeError` | `openai.py:740-760` |
| Tool protocol | OpenAI Chat Completions function-calling, `tool_choice: "auto"`, parallel `tool_calls` supported by the loop | `openai.py:705-707`, `:1383` |
| Prompt caching | Active and **measured** — 46% of all agent input tokens cached; 89–96% per instrumented call. **Not applied in `_estimate_cost`** | §15 |

### 6.1 Prompt assembly — the actual path

There is **no separate developer prompt.** Three layers only.

```python
# integrations/openai.py:1301-1344 — verbatim structure

system_prompt = _load_prompt("ask-copilot-v2.txt")        # LAYER 1: system

context_block = (
    f"Patient: {ctx.get('age', 'Unknown')}\n"                        # ← §7 age bug
    f"Known allergies: {', '.join(ctx.get('allergies') or []) or 'None documented'}\n"
    f"Current medications: {', '.join(ctx.get('meds') or []) or 'None documented'}\n"
    f"Chief complaint: {ctx.get('chief_complaint') or 'Not recorded'}\n"
    f"PATIENT SUMMARY FROM PREVIOUS VISITS — BACKGROUND HISTORY ONLY, NOT this visit's "
    f"presentation. Never take a chief complaint, symptom, diagnosis, vital sign, lab, "
    f"procedure or medication for THIS encounter from it. …: "
    f"{ctx.get('existing_summary') or 'None on record'}\n"
    f"Output language: {resolve_chat_language()}"
    + (f"\nCountry / clinical setting: {country}" if country else "")
    + f"\nValid add_medication \"period\" values (MUST match EXACTLY …): {rx_periods}"
    + f"\nValid add_medication \"dosage\" values (MUST match EXACTLY …): {rx_dosages}"
)

history_text = ""
for msg in (history or [])[-6:]:                          # ← only the LAST 6 turns
    role_label = "Physician" if msg.get("role") == "doctor" else "Assistant"
    history_text += f"{role_label}: {msg.get('text','')}\n"

user_message = (
    f"ENCOUNTER CONTEXT:\n{context_block}\n\n"                        # LAYER 2
    + (f"PRIOR CONVERSATION:\n{history_text}\n" if history_text else "")
    + f"Physician question: {prompt}"                                # LAYER 3
)

messages = [{"role":"system","content":system_prompt},
            {"role":"user","content":user_message}]
```

Then, per iteration, appended: `{"role":"assistant","tool_calls":[…]}` and one
`{"role":"tool","content":json.dumps(result)}` per call. **The entire accumulated list
is re-sent every round-trip** — that is the token profile in §15.

**Two history bounds, and they disagree.** `_load_chat_context` fetches **16** turns
(`api.py:949`), then the assembly above uses only the **last 6** (`openai.py:1331`).
Ten fetched turns are discarded every call.

**The transcript is not in the prompt.** It is only reachable via the
`get_current_transcript` tool — a deliberate choice (`openai.py:1290-1291`). So a turn
where the model does not call that tool reasons with **no transcript at all**.

---

## 7. Prompt architecture

### 7.1 Instruction hierarchy, as actually assembled

```
LAYER 1  SYSTEM        prompts/ask-copilot-v2.txt   (150 lines, 30,506 bytes)
LAYER 2  TOOL SCHEMAS  36 × {description, parameters}  ← ai_tools.py TOOL_REGISTRY
                       (peer-level with system in the API payload, not subordinate)
LAYER 3  USER MSG      ENCOUNTER CONTEXT block  (age, allergies, meds, chief complaint,
                       prior summary + its inline anti-carry-over warning,
                       output language, country, rx_periods, rx_dosages)
                     + PRIOR CONVERSATION (last 6 turns)
                     + Physician question  ← _ANALYZE_PROMPT for the pill
LAYER 4  TOOL RESULTS  role:"tool" messages, appended as the loop runs
                       (transcript arrives HERE, not in the prompt)
```

**There is no developer-role message.** `_ANALYZE_PROMPT` — a 43-line Python string
constant at `api/v1/ai/api.py:966-1009` — occupies the position a developer prompt
would, but is delivered as the **user** turn. It is not a `.txt` file, so it is
excluded from `prompts/README.md`, and until the fingerprint work it was excluded from
`prompt_hash` too (it is now folded in via `extra_prompt`, `services/ai.py:347`).

### 7.2 The 10 live prompt files

Docs say 7. There are **10**, one of which is empty.

| File | Purpose | Caller | Variables injected | Tools |
|---|---|---|---|---|
| `ask-copilot-v2.txt` | **The agent.** Serves Analyze *and* chat | `ask_copilot_agent_stream` | none (all context is in the user msg) | **36** |
| `suggest-v2.txt` | Post-recording clinical suggestions | `generate_suggestions` | transcript, ctx, 6 catalogs, rx enums, focus directive | none |
| `soap-v1.txt` | Versioned SOAP draft | `generate_soap_draft` | transcript, ctx, 5 catalogs, rx enums | none |
| `resegregate-v1.txt` | Rebuild garbled speaker turns | `resegregate_speakers` | transcript only (no labels, so a wrong label can't bias it) | none |
| `review-details-v1.txt` | Patient-facing visit summary at Sign | `generate_review_details` | full `encounter_state` + transcript + existing text | none |
| `medication-fields-v1.txt` | Infer dosage form/strength/UOM/class | `infer_medication_fields` | name + allowed enum lists | none |
| `lab-fields-v1.txt` | Infer lab template type/UOM/range | `infer_lab_fields` | name + allowed UOM list | none |
| `narzim-assistant-v1.txt` | General sidebar assistant (no patient scope) | `answer_general_question` | history + message | none |
| `narzim-thread-title-v1.txt` | Thread title generation | `generate_thread_title` | first message | none |
| `narzim-assistant-phi-check-v1.txt` | **EMPTY FILE (0 bytes) — orphaned** | `check_document_for_patient_phi`, no live caller | — | — |

### 7.3 Safety instructions that are real

`ask-copilot-v2.txt`, by line:
- **:5** paediatric practice declared; adult regimen = "HARD REFUSAL, not a caution"
- **:106** "Do not invent lab values, vitals, medications, allergies, or any clinical fact"
- **:107** the anti-carry-over rule, **with the `equimosis fácil` incident quoted verbatim in the prompt itself**
- **:110** prompt-injection defence: transcript is DATA, not instructions
- **:118-126** AGE APPROPRIATENESS — 6 numbered rules; :122 forbids listing adult
  secondary-prevention drugs even when asked directly ("presenting a menu IS offering")
- **:128-137** UNEXCLUDED-CONTRAINDICATION PRIORITY — nitrate/HOCM, beta-blocker/asthma,
  anticoagulant/bleeding, steroid/infection
- **:139-143** ALLERGY AND INTERACTION PRIORITY

This is a genuinely careful safety prompt. Its weakness is that **all of it is
prompt-layer**: none of §7.3 is enforced by code. The only deterministic safety checks
in the whole AI path are the four in §16.2.

### 7.4 Conflicting instructions — and which wins

**Conflict A — the one you named. `soap-v1.txt` lines 5 and 6, adjacent:**
```
:5  Aim for completeness across chief complaint, history of present illness,
    diagnoses, plan, and any orders/education actually discussed. A thin, partial
    draft is a failure of this task even if each individual item is accurate.
:6  Still omit any target with no basis in the transcript — never invent content
    to "fill in" a section.
```
**Which wins: line 5.** Three structural reasons, not a guess.
1. Line 5 states the **task objective** ("a failure of this task"); line 6 is phrased
   as a subordinate carve-out ("Still omit…"). An objective outranks a caveat when the
   two collide on a specific item.
2. Line 5 is **measurable by the model** (is the draft thin?); line 6 requires
   adjudicating "has basis in the transcript", which is exactly the judgement a
   truncated or mislabelled transcript makes unreliable.
3. Line 5's failure mode is **rewarded** — a fuller draft looks like better work and
   there is no downstream signal that punishes an unsupported item, because nothing
   validates clinical *support*, only catalog membership (§16).

Note the scope: this conflict lives in `soap-v1.txt`, which is `generate_soap_draft` —
**not** the Analyze path. `enable_soap_generation` is `1` on the live site, so it is
reachable. `ask-copilot-v2.txt` has no "thin draft" line; its equivalent pressure is
`_ANALYZE_PROMPT`'s "add **every** clinically appropriate item that is not already
present" (`api.py:981`), balanced by the explicit "an empty draft is the correct output
for an empty consultation" (`api.py:978`) — a much better-formed pairing, because the
permissive clause and the restrictive clause name the same decision.

**Conflict B — "never invent" vs three explicit licences to infer.** These are the
prescription-safety ones, and they are not accidents; each is a deliberate carve-out.

| Restrictive | Permissive | Which governs |
|---|---|---|
| `ask-copilot-v2.txt:106` "Do not invent … medications" | `:101` "AND you cannot confidently infer **the standard adult strength** for this drug, ASK" | **:101** — it defines when asking is *unnecessary*, so inference is the default path |
| `:106` | `:45` "Only add what the physician actually asked for, **or the standard, clearly-indicated item for a diagnosis they state**" | **:45** — an explicit exception |
| `suggest-v2.txt:5` "Never invent clinical FACTS" | `:32` §2 RECOMMENDED: "you **SHOULD** also suggest the standard-of-care workup and management for THAT diagnosis … This is **the primary value of this feature**" | **:32** — self-declared primary value |

`:101` is the sharpest: **"standard adult strength" in a prompt whose line 5 declares a
paediatric practice, and whose line 125 says never state an adult dose without a
weight check.** The prompt contradicts itself on the single highest-risk field.

### 7.5 Outdated instructions still live

| Line | Instruction | Status |
|---|---|---|
| `ask-copilot-v2.txt:96` | "one tool call per item (e.g. … = **8 separate calls**)" | **Live and costly.** The loop already handles parallel `tool_calls` (`openai.py:1383`) and OpenAI allows them by default. This line is the direct cause of the round-trip profile in §15. Flagged as the cheapest win on 2026-07-29 and again 2026-08-04; still unfixed |
| `ask-copilot-v2.txt:5, :119` | `"16G" = 16 years old` | Teaches the model to read `age` as **years**. Combined with §10's bug, this is what turns a 5-month-old into a neonate |
| `soap-v1.txt:5` | "thin draft is a failure" | Live; see §7.4 |
| `narzim-assistant-phi-check-v1.txt` | — | Empty file, orphaned caller |

---

## 8. Tool registry

Source of truth: `services/ai_tools.py::TOOL_REGISTRY` (`:1260-1649`).
Extracted programmatically on 2026-08-13: **36 entries — 13 `kind:"read"`, 23 `kind:"write"`.**

**Universal properties, verified by exhaustion:**
- **No tool mutates the database.** `grep -n "\.insert(\|\.save(\|db_set\|frappe.db.set_value\|\.submit()\|\.delete("` over `services/ai_tools.py` returns **zero matches**.
- Dispatch is `execute_tool` (`:1687`) — unknown names return a structured error rather than raising, so a hallucinated tool name cannot fail the turn.
- `frappe.PermissionError` → `{"error": "Not permitted to access that data."}`; any other exception → logged + returned as an error string.
- **Audit granularity: tool NAMES only.** `tools_used=",".join(names)` → `AI Prompt Log.tools_used`. **Arguments and results are never stored anywhere** (Rule 10). This is the single biggest reproducibility gap (§14).
- Write tools are withheld entirely when the caller lacks Encounter `write` (`api.py:808` → `build_openai_tools(allow_write=False)`).

### 8.1 READ tools (13)

| Tool | Args | Returns | DB read | Bound |
|---|---|---|---|---|
| `get_patient_labs` | — | recent completed labs + result items | `Lab Test`, `Normal Test Result` | `_MAX_LABS=8`, `_MAX_LAB_ITEMS_PER_TEST=6`, status ∈ Approved/Completed |
| `get_previous_encounters` | `limit` | date, status, chief complaint, diagnoses, medications, vitals | `Patient Encounter` + children + `Vital Signs` | `_MAX_PREV_ENCOUNTERS=5`, default 3, **`docstatus=1` (signed only)**; reports `unsigned_drafts_excluded` |
| `get_current_transcript` | — | transcript text, `source`, `truncated` | client-passed, else `AI Transcript Segment` | `_MAX_TRANSCRIPT_CHARS=6000`, **keeps the TAIL** |
| `get_encounter_state` | — | full draft: chief complaint, symptoms, diagnoses, meds, labs, procedures, therapies, vitals, allergies | `Patient Encounter` + `Vital Signs` (docstatus 0) | whole draft, inherently bounded |
| `get_appointment_details` | — | type, date, time, status, dept, notes, duration | `Patient Appointment` | one row |
| `get_vaccine_catalog` | — | active immunization template display names | `Immunization Template` | unbounded (small master) |
| `get_lab_analysis` | `lab_test_name` | narrative + flags | `Lab Test.custom_ai_summary` | 1 match, `LIKE %name%` |
| `search_medication_catalog` | `query` | matches + count | `Medication` | `limit_page_length=10` |
| `search_lab_catalog` | `query` | matches + count | `Lab Test Template` | 10 |
| `search_diagnosis_catalog` | `query` | matches + count | `Diagnosis` | 10 |
| `search_procedure_catalog` | `query` | matches + count | `Clinical Procedure Template` | 10 |
| `search_therapy_catalog` | `query` | matches + count | `Therapy Type` | 10 |
| `search_complaint_catalog` | `query` | matches + count | `Complaint` | 10 |

**One read tool is not read-only in effect.** `get_lab_analysis` (`ai_tools.py:296`) calls
`lab_result_summary.generate_summary_sync(lab_test)` on a cache miss — which makes **a
second, nested LLM call inside the agent loop** and writes `Lab Test.custom_ai_summary`
+ `custom_ai_summary_status`. Its docstring acknowledges this. Consequences:
one physician action can produce two `AI Prompt Log` rows under different purposes, and
the agent turn's own logged cost **excludes** the nested call's cost.

### 8.2 WRITE / SUGGESTION tools (23)

All return `{"tool_result": …, "action": <ClinicalSuggestion>}` — or `patient_draft` for
the five marked ⚠.

| Tool | Draft target | Validation in the tool |
|---|---|---|
| `add_medication` | `orders.rx` | dosage/period must be exact master values **else silently moved to `comment`**; strength folded into `drug_name` if absent from it; **duplicate guard** (`_rx_already_present`); allergy check |
| `add_lab` | `orders.labs` | duplicate guard (`_order_already_present`) |
| `add_procedure` | `orders.procedures` | duplicate guard |
| `add_therapy` | `orders.therapies` | duplicate guard |
| `add_diagnosis` | `diagnoses` | non-empty only |
| `add_symptom` | `symptoms` | non-empty only |
| `add_vital` | `vitals.<key>` | key ∈ 8-value enum; **value must parse as float** (rejects `"null"`, `"N/A"`) |
| `add_chief_complaint` | `chiefComplaint` (overwrite) | non-empty |
| `add_review_details` | `education` (overwrite) | non-empty |
| `add_follow_up` | follow-up section | `in` ∈ `_VALID_FOLLOWUP_IN` enum |
| `add_vaccine` | `orders.vaccines` | **BLOCKING catalog match** — the only one |
| `remove_medication` / `_lab` / `_diagnosis` / `_procedure` / `_therapy` / `_symptom` / `_vaccine` (7) | `{kind:"remove", match}` | non-empty; matching is client-side, single-match-only |
| ⚠ `add_allergy` | `patient_draft.allergies` | non-empty |
| ⚠ `add_patient_medication` | `patient_draft.medications` | non-empty |
| ⚠ `add_medical_history` | `patient_draft.medical_history` | non-empty |
| ⚠ `add_surgical_history` | `patient_draft.surgical_history` | non-empty |
| ⚠ `set_patient_summary` | `patient_draft.summary` (overwrite) | non-empty |

### 8.3 SAFETY / VALIDATION tools

**There are none.** No tool in the registry has `kind:"safety"` or exists to validate.
What exists instead is embedded deterministic logic inside write tools (§16.2):
`_allergy_conflict`, `_rx_already_present`, `_order_already_present`,
`_match_immunization_template`, and `add_vital`'s float check. `AI Settings.enable_safety_validators`
is **`0`** on the live site and is not read by any code path in `services/ai_tools.py`
or `api/v1/ai/api.py`.

### 8.4 CATALOG SEARCH tools

The six `search_*_catalog` tools. Identical shape: `require_permission` → bounded
`frappe.get_all(filters=[["disabled","=",0],[field,"like",f"%{q}%"]], limit_page_length=10)`
→ `{"matches":[…], "match_count":N}`. **All non-blocking** — a zero-match result still
lets the model propose a new value, which `create_master` may then auto-create.

### 8.5 Verdict on the claim

> "23 write tools return suggestion objects only and do not write to DB."

- **Backend tool layer: TRUE.** Zero DB mutations in `ai_tools.py`.
- **End-to-end: FALSE for 5 of the 23.** `add_allergy`, `add_patient_medication`,
  `add_medical_history`, `add_surgical_history`, `set_patient_summary` return a
  `patient_draft` patch which `encounter-screen.tsx:3217-3263` applies with an immediate
  `updatePatient.mutate(...)` to the permanent `Patient` record — **before Save, before
  Sign, with no confirmation**. The code comment states it plainly:

  > "NOTE: patient history persists to the permanent Patient record immediately
  > (unlike encounter fields), so this writes the AI-suggested allergies/meds/history
  > to the chart on fill; once applied the 'review & add' panel below auto-hides"

  The panel that would let a physician review these **hides itself once the write has
  already happened** (its "new item" lists become empty by construction).
- Also outside the claim: `get_lab_analysis` (a *read* tool) writes
  `Lab Test.custom_ai_summary`, and `create_master` (not a tool, but AI-driven) inserts
  real `Medication` + `Item` + `Lab Test Template` masters.

**Accurate restatement:** *18 of 23 write tools are suggestion-only and honour Rule 6.
5 write directly to the permanent Patient record via frontend auto-apply. 1 read tool
writes an AI-summary cache. 0 encounter-level clinical fields are ever written by a tool.*

---

## 9. Prescription flow — "Give paracetamol"

### 9.1 The chain

```
TRANSCRIPT   "Doctor: … le vamos a dar paracetamol …"
   │  (reaches the model ONLY if it calls get_current_transcript)
   ▼
LLM decides → ask-copilot-v2.txt:19 says ALWAYS call search_medication_catalog first
   ▼
search_medication_catalog(query="paracetamol")
   → Medication rows LIKE %paracetamol%, limit 10  → e.g. "Tablet Paracetamol 500Milligram"
   ▼
LLM calls add_medication(drug_name=…, dosage=…, period=…, strength=…, strength_uom=…,
                         interval=…, comment=…)
   ▼
_tool_add_medication  (ai_tools.py:654)
   1. drug_name required, else error
   2. period  ∈ ctx.rx_periods  ELSE ""  and the raw text appended to `comment`
   3. dosage  ∈ ctx.rx_dosages  ELSE ""  and the raw text appended to `comment`
   4. if strength and strength not in drug_name: drug_name = f"{drug_name} {strength}{uom}"
   5. _rx_already_present(...) → refuse with `already_present`
   6. _allergy_conflict(drug_name, ctx.allergies) → safety[] entry
   → returns action{target:"orders.rx", value:{kind:"rx", items:[item]}, confidence:0.6}
   ▼  NO DB WRITE
FRONTEND  fillFormFromSuggestions → applySuggestionToEnc → enc.orders.rx[] (local state)
          rendered with a ✦ AI badge, editable, removable
   ▼
Dr edits / accepts / removes
   ▼
SAVE  save_draft()  encounters/api.py:1446  → _apply_drug_prescriptions()  :487
   drug_code       REQUIRED — resolved from `medication`'s linked Item, else THROW
   drug_code       must exist in `Item`, else THROW
   dosage_form     REQUIRED and must exist in `Dosage Form`, else THROW
   period          REQUIRED and must exist in `Prescription Duration`, else THROW
   dosage          if present and not in `Prescription Dosage` → moved to comment, NOT rejected
   strength_uom    if present must exist in `UOM`, else THROW
   strength        ***NO VALIDATION OF ANY KIND***
   ▼
SIGN  complete_encounter()  encounters/api.py:1864
   chief_complaint must be non-empty (:1898)  → docstatus 0 → 1
   Healthcare core on_submit creates the downstream orders/invoicing
```

### 9.2 Field provenance — where each value comes from

| Field | Source | Inference possible? |
|---|---|---|
| **drug** | LLM `drug_name`, ideally the catalog match verbatim | Yes — free text on zero match |
| **formulation** | Catalog `dosage_form` on match; else LLM-inferred by `medication-fields-v1` at `create_master`; else `"N/A"` sentinel | **Yes** |
| **strength** | LLM `strength` arg, or parsed back out of `drug_name` by `infer_medication_fields` | **Yes — explicitly licensed by `ask-copilot-v2.txt:101`** |
| **dose** (`dosage`) | LLM, must match `Prescription Dosage` master | Constrained enum, else demoted to comment |
| **frequency** | Same field as `dosage` (e.g. `"1-0-1"`) + optional `interval`/`interval_uom="Hour"` | Constrained |
| **duration** (`period`) | LLM, must match `Prescription Duration` master | Constrained enum, else demoted to comment |
| **route** | **DOES NOT EXIST in the AI path.** Not a tool arg, not in the action item | n/a |
| **quantity** | **DOES NOT EXIST** | n/a |
| **refill** | **DOES NOT EXIST** | n/a |
| **PRN** | **DOES NOT EXIST** as a field — survives only as free text in `comment` | n/a |
| **indication** | **DOES NOT EXIST** as a field — only in `reasoning[]`, which is display-only and never persisted to the prescription row | n/a |

Five of the eleven fields you asked about are not modelled at all. Anything the model
says about route, quantity, refills, PRN status or indication lands in `comment` — an
unvalidated free-text field — or is discarded.

### 9.3 Your eight specific questions, answered from code

| Question | Answer and exact mechanism |
|---|---|
| **Can the model invent 500 mg?** |**Yes — explicitly permitted** — `ask-copilot-v2.txt:101`: ask for strength only if "you cannot confidently infer **the standard adult strength**". Inference is the licensed default. No numeric validation exists at any layer: `_tool_add_medication` passes `strength` through as a string, `_apply_drug_prescriptions` validates `strength_uom` against `UOM` but **never** `strength`|
| **Can it invent TID?** |**Only if TID is a real master value** — `dosage` must be in `Prescription Dosage`. If "TID" is not a row, `ai_tools.py:673-683` blanks the structured field and appends the text to `comment`. So it appears in the record as prose, never as structured frequency. Silent — the physician sees it in a comment, not as a rejected value|
| **Can it invent 3 days?** | **Same** — `period` must be in `Prescription Duration`; "3 days" usually *is* a real row, so yes, and it is accepted as structured data with no clinical check |
| **Can it infer PEG 3350?** | **Yes.** Nothing restricts *which* drug may be proposed. `search_medication_catalog` is non-blocking (`ask-copilot-v2.txt:46`: "If it returns no match, proceed with add_medication using your own clinical judgment"). A zero-match drug becomes free-text `drug_name`, and `create_master` will mint a `Medication` + `Item` for it on physician confirmation |
| **Can a diagnosis trigger a medication?** |**Yes — by design, in both engines** — Agent: `ask-copilot-v2.txt:45` "or **the standard, clearly-indicated item for a diagnosis they state**". Suggestions: `suggest-v2.txt:32` §2 RECOMMENDED — "you **SHOULD** also suggest the standard-of-care workup and management for THAT diagnosis … **This is the primary value of this feature**". Marked confidence 0.35–0.65 vs 0.7–0.95 for extracted facts — the only signal distinguishing them, and it is display-only|
| **Can a conditional medication become an active prescription?** | **Yes. Nothing models conditionality.** The action item has no `prn`, `conditional`, or `status` field. "Give paracetamol **if** she spikes a fever" and "give paracetamol" produce the identical `orders.rx` row. The condition survives only if the model volunteers it into `comment`, and `comment` is never parsed |
| **Can missing strength become 0 mg?** |**Yes — documented in-code as a real past defect** — `ai_tools.py:688-707`: `_create_medication_master` derives strength from `drug_name` alone; `medication-fields-v1` correctly answers `0` when the name states none; `parse_medication_fields` (`services/ai.py:769-771`) coerces to `float(... or 0)` → `0.0`. Real records observed: `"N/A Ondansetron 0Milligram"`, `"N/A PARACETAMOL 0Milligram"`. **Partially mitigated** by folding `strength` into `drug_name` — but only when the model supplies a `strength` arg. Supply neither and it is still 0|
| **Can a medication mentioned as "given" become a take-home prescription?** |**Yes, and the prompt actively invites the confusion** — `_ANALYZE_PROMPT` (`api.py:993-997`) instructs: capture "a medication the patient already takes or reports having taken at home/OTC before this visit, **e.g. Tylenol/paracetamol/any over-the-counter remedy** (`add_patient_medication` — separate from the medications you are prescribing THIS visit via `add_medication`)". The distinction is stated, but it is stated **in prose only**. Both tools accept the same free-text name, neither can see the other's intent, and there is no code check. A "given in clinic" paracetamol can land in `orders.rx` (a prescription), in `patient_draft.medications` (permanent home-med history), or both|

### 9.4 Every place a default or inference can enter

1. `ask-copilot-v2.txt:101` — standard adult strength inference (prompt licence)
2. `ask-copilot-v2.txt:45` / `suggest-v2.txt:32` — diagnosis → standard-of-care order
3. `_ANALYZE_PROMPT` `api.py:981` — "use a standard dose only when one is well established"
4. `ai_tools.py:673-674` — non-matching `dosage`/`period` → `""` (silent blank)
5. `ai_tools.py:706-707` — `drug_name` rewritten to embed strength
6. `parse_medication_fields` `services/ai.py:769-780` — `strength → 0.0`; `dosage_form → "N/A"`; `strength_uom → "Milligram"`; `medication_class → "Uncategorized"`
7. `_match_catalog_value` `services/ai.py:728` — case/whitespace-tolerant enum coercion
8. `_apply_drug_prescriptions` `encounters/api.py:582-585` — bad `dosage` → comment
9. `_apply_drug_prescriptions` `encounters/api.py:590` — missing `drug_name` ← `Item.item_name`
10. `_create_medication_master` `api.py:167-168` — whole-number float → int for autoname
11. `_derive_chief_complaint_if_missing` `encounters/api.py:150` — chief complaint synthesised from symptom rows so Sign is not blocked
12. `ai_tools.py:734` — `interval_uom` hardcoded `"Hour"`

---

## 10. Patient data flow — and the exact source of "0 months / neonate"

### 10.1 THE BUG — found, root-caused, and reproduced on live data

```python
# services/ai.py:874-890
def _resolve_age(enc, patient) -> str:
    """Return a compact age+sex string like '44F'. Falls back gracefully."""
    sex_code = (patient.sex or "")[:1].upper()
    if patient.dob:
        try:
            age_years = int(date_diff(nowdate(), str(patient.dob)) / 365)   # ← LINE 880
            return f"{age_years}{sex_code}" if sex_code else str(age_years)
        except Exception:
            pass
    patient_age = getattr(enc, "patient_age", None)
    if patient_age:
        return f"{patient_age}{sex_code}".strip()
    return "Unknown"
```

`int(days / 365)` **truncates toward zero.** For any patient under 12 months the result
is literally `0`. That single string is the *only* age information the LLM ever receives
(`openai.py:1305`: `f"Patient: {ctx.get('age', 'Unknown')}\n"`).

**Verified against the live database, 2026-08-13:**

| Patient | DOB | True age | `age` string sent to the LLM |
|---|---|---|---|
| `MRN-2026-0000003` | 2026-03-03 | **5 months** | **`0G`** |
| `MRN-2026-0000013` | 2026-03-03 | 5 months | `0M` |
| `HLC-PAT-2026-00001` | 2025-09-09 | 11 months | `0M` |
| `MRN-2026-0000012` | 2026-07-09 | 1 month | `0M` |
| `MRN-2026-0000193` | 2026-07-28 | 0 months | `0M` |

`MRN-2026-0000003` — DOB 2026-03-03, five months old — is the case you described.

**The second half of the bug is in the prompt.** `ask-copilot-v2.txt:5` and `:119` both
teach: `Read the patient's age (context "age", e.g. "16G" = 16 years old)`. So the model
is explicitly instructed to interpret the integer as **years**. It receives `0`,
correctly applies the documented convention, and concludes *0 years old* — a neonate.

**The model did nothing wrong.** It was handed `0`, told `0` means years, and reasoned
faithfully. Three compounding factors:
- Precision is destroyed before the model sees it — no months, no DOB, no `patient_age`
  string. The encounter's own denormalised `patient_age` field (which Healthcare core
  formats as e.g. `"5 Months"`) is used **only** as a fallback when DOB is missing —
  i.e. the accurate value is available and deliberately preferred against.
- `/365` also drifts on leap years: a child born 2012-02-29 reads a year young near
  their birthday.
- The whole paediatric safety block (`:118-126`) — weight-based dosing, age-appropriate
  differentials, the adult-protocol refusal — keys off this one corrupted integer. For
  every infant in the practice, the age-appropriateness logic runs on `0`.

### 10.2 The complete encounter data map

Everything in `build_encounter_context()` (`services/ai.py:11-95`) plus what tools return.

| Data | Source | Authoritative? | Sent to LLM? | Prompt location | LLM can modify? | LLM can write back? |
|---|---|---|---|---|---|---|
| **age** | `Patient.dob` → `int(days/365)` | **NO — lossy** | Yes, always | user msg, line 1 (`Patient: {age}`) | No | No |
| **sex** | `Patient.sex[:1].upper()` | Yes | Yes — fused into the age string (`"0G"`) | same token | No | No |
| **DOB** | `Patient.dob` | Yes | **NO — never sent** | — | No | No |
| **allergies** | `Allergy` child table | Yes | Yes, always | user msg `Known allergies:` | No | **YES — `add_allergy` → auto-write ⚠** |
| **current medications** | `Patient Encounter.drug_prescription` (this draft) | Yes | Yes, always | user msg `Current medications:` | Yes (add/remove) | Only via Save |
| **home medications** | `Patient.medication` free text | Yes | **In `ctx` (`existing_medications`) but NOT in the prompt block** | — | Yes | **YES — `add_patient_medication` ⚠** |
| **chief complaint** | `encounter_comment` JSON, ≤300 chars | Yes | Yes, always | user msg `Chief complaint:` | Yes | Only via Save |
| **patient summary** | `Patient.patient_details`, truncated 2,000 chars **head-first** | Yes | Yes, always | user msg, with a 6-line inline warning | **Overwrites** | **YES — `set_patient_summary` ⚠** |
| **medical history** | `Patient.medical_history` | Yes | **In `ctx`, NOT in the prompt** | — | Append | **YES ⚠** |
| **surgical history** | `Patient.surgical_history` | Yes | **In `ctx`, NOT in the prompt** | — | Append | **YES ⚠** |
| **transcript** | client `finalSegments`, else `AI Transcript Segment` | Yes-ish (§5) | **Tool only**, tail-truncated 6,000 chars | tool result | No | No |
| **current symptoms** | `Patient Encounter.symptoms` | Yes | Tool only (`get_encounter_state`) | tool result | Yes | Only via Save |
| **vitals** | `Vital Signs` docstatus 0 | Yes | Tool only | tool result | Yes | Only via Save |
| **labs** | `Lab Test` + `Normal Test Result` | Yes | Tool only (`get_patient_labs`) | tool result | Order new | Only via Save; **`custom_ai_summary` written by `get_lab_analysis`** |
| **diagnoses** | `Patient Encounter.diagnosis` | Yes | Tool only | tool result | Yes | Only via Save |
| **orders** | lab/procedure/therapy/rx child tables | Yes | Tool only | tool result | Yes | Only via Save |
| **existing draft** | whole `encounter_state` | Yes | Tool only | tool result | Yes | Only via Save |
| **previous encounters** | signed `Patient Encounter` ×3 | Yes | Tool only | tool result | No | No |
| **clinician notes** | physician-typed exam/assessment prose | Yes | **NO — never sent, and deliberately excluded from the fingerprint** (`services/ai.py:285-295`) | — | No | No |
| **rx_periods / rx_dosages** | `Prescription Duration` / `Prescription Dosage` | Yes | Yes, always | user msg, last 2 lines | No | No |
| **country / language** | `ComplianceProfile` / `User.language` | Yes | Yes | user msg | No | No |
| **6 big catalogs** | 6 masters | Yes | **NOT on the agent path** (`include_catalogs=False`, `api.py:819`) — suggest/SOAP only | prompt body there | No | Via `create_master` |

**Three fields are resolved into `ctx` and then never used by the agent** —
`existing_medications`, `existing_medical_history`, `existing_surgical_history`. They are
not in `context_block` (`openai.py:1304-1328`). So the agent is told to append to the
patient's history without being shown what is already there — which is precisely the
duplicate/contradiction risk the comment at `services/ai.py:85-91` says they were added
to prevent. The comment describes an intent the assembly does not implement.

---

## 11. Historical encounter flow — the `equimosis fácil` incident

### 11.1 What the AI receives from previous encounters

**Two channels, and only one of them is a "previous encounter."**

**Channel A — `get_previous_encounters` (a tool; opt-in; the model must choose to call it):**
per encounter — `name`, `date`, `status`, `chief_complaint`, `diagnoses[]`,
`medications[]` (drug + dosage + period), `vitals{}` (8 fields). Bounded to 3 by
default, 5 max, **signed only** (`docstatus=1`).

Not sent: full note text, HPI, previous transcript, exam findings, labs from that visit
(those come via `get_patient_labs`, which is patient-scoped not encounter-scoped),
review details.

**Channel B — `existing_summary` (always in the prompt, unconditionally):**
`Patient.patient_details`, truncated to 2,000 chars **head-first**. This is the
LLM-authored rolling summary that `set_patient_summary` overwrites each Analyze.

So: **the AI never sees a previous transcript, and never sees a full previous
encounter.** It sees selected fields on request, plus a cumulative LLM-written summary
it cannot avoid.

### 11.2 The exact path the defect took

The incident (2026-07-29): a prior visit's summary read `queja principal de equimosis
fácil` ("chief complaint of easy bruising"). On a **fever/headache** visit, the agent
adopted it as *today's* chief complaint and drafted "Bruising easily", diagnosis
`Unexplained bruising (R23.3)`, and PT/INR + aPTT + CBC — none of it in that day's
consultation.

Traced through the code, the mechanism is four steps, and **Channel B, not Channel A**:

```
1. build_encounter_context(encounter)                     services/ai.py:83
      "existing_summary": _truncate_patient_summary(patient.patient_details)
      → the string "…queja principal de equimosis fácil…", head-first truncation
        (so the OLDEST content — the bruising line — is exactly what survives)

2. context_block                                          openai.py:1317-1323
      the summary is interpolated into the SAME flat block as, and immediately
      after, "Chief complaint: {…}". Four consecutive f-string lines, one
      newline apart, no structural separation, no section header, no delimiter.

3. Chief complaint: '' (empty — nothing recorded yet on a fresh encounter)
   Meanwhile _ANALYZE_PROMPT says: "complete the clinical draft" and
   "add every clinically appropriate item that is not already present"

4. The model resolves the contradiction the only way the layout allows:
   the nearest available chief-complaint-shaped string is one line below the
   empty "Chief complaint:" field, and it is literally labelled
   "queja principal" ("chief complaint") in its own text.
```

The root cause is **prompt-layout adjacency plus an unlabelled field**, amplified by a
"complete the draft" objective with no "from what?" scoping. It is not a retrieval bug —
`get_previous_encounters` was never called. Head-first truncation made it worse by
guaranteeing the oldest, most-likely-stale content is the part retained.

### 11.3 The three fixes now in code (all prompt-layer, all live)

| Fix | Location | Text |
|---|---|---|
| 1. Emphatic in-context label | `openai.py:1317-1323` | `PATIENT SUMMARY FROM PREVIOUS VISITS — BACKGROUND HISTORY ONLY, NOT this visit's presentation. Never take a chief complaint, symptom, diagnosis, vital sign, lab, procedure or medication for THIS encounter from it.` |
| 2. Analyze-prompt guard | `api.py:970-978` | `EVERYTHING you add must come from TODAY'S transcript … never from the PATIENT SUMMARY FROM PREVIOUS VISITS block and never from get_previous_encounters … an empty draft is the correct output for an empty consultation.` |
| 3. System-prompt absolute rule | `ask-copilot-v2.txt:107` | The rule, **with this incident quoted verbatim inside the prompt**, followed by `:108` which deliberately preserves the *reasoning* use of history while forbidding it as draft content |

**Assessment:** the layout flaw that caused it is unchanged — the summary still sits in
the same flat block, one line from `Chief complaint:`. What changed is that three
overlapping natural-language prohibitions now sit on top of it. There is **no
deterministic guard**: nothing compares a proposed `add_chief_complaint` /
`add_diagnosis` value against the summary text to detect a carry-over. The same input
that produced the defect would now have to defeat three instructions instead of zero —
better odds, same class of control.

Two structural weaknesses remain, both independently verified:
- **Head-first truncation** (`services/ai.py:105-115`) retains the oldest text by
  design. The rationale given is that durable history lives at the head — but that is
  also where a stale chief complaint lives.
- **`set_patient_summary` overwrites.** The model is told to merge and never discard,
  so the summary accumulates every visit's content indefinitely — growing the surface
  of prior-visit text sitting one line from `Chief complaint:` on every future call.

---

## 12. RAG / retrieval — current state

**Retrieval already exists in this system, extensively, under other names.**
What does not exist is anything vector-based.

### 12.1 Confirmed absent

`grep -rln "embedding\|pgvector\|cosine\|faiss\|vector_store"` over the whole app
returns **exactly one file** — `services/transcript_digest.py` — and the only matches
are lines 14–16 of its module docstring:

> "No LLM call, no embeddings, no network. That is a deliberate choice over semantic
> similarity: a cosine of 0.98 can sit between 'no penicillin allergy' and 'penicillin
> allergy', and an embedding call to avoid an LLM call is still a model call."

No vector DB, no pgvector extension, no embedding calls, no similarity search, no
chunking, no reranking, no `AI Prompt Template` runtime read (it is a seeded snapshot —
no code reads it).

### 12.2 The six retrieval mechanisms that DO exist

| # | Mechanism | What is retrieved | Why | From where | How selected | How it enters context |
|---|---|---|---|---|---|---|
| 1 | **Structured tool retrieval** (the real one) | labs, prior encounters, transcript, draft state, appointment | ground the answer instead of guessing | Frappe ORM, 8 doctypes | **Model decides** which tool, when. Bounded by `_MAX_*` constants | `role:"tool"` JSON message, mid-loop |
| 2 | **Keyword catalog search** ×6 | ≤10 master rows per query | reuse the real catalog entry rather than minting a near-duplicate | `Medication`, `Lab Test Template`, `Diagnosis`, `Clinical Procedure Template`, `Therapy Type`, `Complaint` | `LIKE %query%`, `disabled=0`, `limit_page_length=10` | tool result |
| 3 | **Eager catalog injection** | all 6 catalogs, ~457 entries | same goal, single-shot paths have no tools | same masters, **unbounded `frappe.get_all`, no limit** | none — everything | inlined in `suggest-v2` / `soap-v1` prompt body |
| 4 | **Rolling patient summary** | `Patient.patient_details`, 2,000 chars | cross-visit continuity | `Patient` | head-first truncation | **always** in the prompt |
| 5 | **Cache-or-generate lab analysis** | one lab's narrative + flags | avoid regenerating an existing interpretation | `Lab Test.custom_ai_summary`, else generate now | most recent `LIKE %name%` | tool result |
| 6 | **Deterministic transcript digest** | normalised digest + materiality verdict | decide whether Analyze may reuse its prior result | `AI Transcript Segment` | NFKC + filler stripping + **catalog-derived clinical lexicon** | never sent — used only for the fingerprint |

Mechanism 6 deserves note: `services/transcript_digest.py` (305 lines) derives a
**tenant-specific clinical lexicon from the site's own six masters** and uses it to
decide whether a transcript delta is clinically material. That is keyword-based
relevance scoring over domain vocabulary — retrieval machinery in everything but name,
built deliberately without a model.

### 12.3 Honest characterisation

The system is a **tool-calling agent over structured, permission-checked, bounded
queries with keyword catalog grounding** — i.e. "RAG" where the retriever is the Frappe
ORM and the index is the relational schema. For an EHR this is a stronger baseline than
vector RAG on two axes that matter here: every retrieval is permission-checked at the
doctype level, and every retrieved value is a real primary-key-resolvable record rather
than a similar-looking passage.

Its measured weaknesses are not "no semantics" — they are:
- **Tail-only transcript truncation** at 6,000 chars, which drops the opening of any
  long consultation (`ai_tools.py:173-189` — the code logs when this bites but keeps the tail).
- **Retrieval is opt-in.** If the model does not call `get_current_transcript`, it
  reasons with no transcript. Nothing forces the call.
- **Mechanism 3 is unbounded** and scales with tenant catalog size, not usage.

---

## 13. Database / doctypes

**18 AI doctypes exist.** `CLAUDE.md` §7 lists 5.

| Doctype | Purpose | Who writes | When | Raw transcript? | AI response? | Tool args? | Prompt ver? | Model? | Evidence? | Provenance? | Dr approval? |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `AI Prompt Log` | Per-call audit | `log_prompt_call` `services/ai.py:416` | after every LLM call | No | **No** | **No** | Yes + `prompt_hash` | Yes | **No** | encounter, patient, purpose | **No** |
| `AI Encounter Chat Message` | Chat + Analyze turns | `_persist_chat_turn` `api.py:1023` | after every turn | No | **Yes (`content`)** | **Partial — `actions_json` holds the resulting suggestions, not the tool call** | Yes (field exists, rarely set) | Yes | No | encounter, thread, kind, fingerprint | **No** |
| `AI Transcript Segment` | Finalised transcript | `append_segment` / `sync_transcript` | 20 s autosave + stop | **YES — verbatim** | No | No | No | No | timings + confidence | session, seq, speaker | No |
| `AI Encounter Session` | Recording lifecycle | `sessions.py` | start/stop | No | No | No | No | No | No | encounter, consent, timings | consent gate |
| `AI SOAP Draft` | Versioned SOAP | `generate_soap_draft` `api.py:647` | on generate | No | **Yes (`suggestions_json`, `raw_response`)** | n/a | Yes | Yes | No | version, status | **YES — `accept_soap_draft` / `discard_soap_draft`** |
| `AI Settings` (Single) | Flags + model config | admin | manual | — | — | — | — | — | — | — | — |
| `AI Encounter Record` | Consolidated per-encounter AI record | on sign | at sign | Yes (joined) | Yes | No | No | Yes | No | `asr_cost_usd`, `cost_usd`, `total_cost_usd` | signed encounter |
| `AI Patient Clinical Summary` | Cross-encounter summary | `patient_clinical_summary.py` | bg job, watermarked | No | Yes | No | Yes | Yes | No | `last_synced_at` | No |
| `AI Patient Chat Message` | Patient-portal chat | portal | per turn | No | Yes | No | Yes | Yes | No | patient | No |
| `AI Narzim Assistant Message` | General assistant | `narzim_assistant.py` | per turn | No | Yes | No | Yes | Yes | No | `session_user`, thread | No |
| `AI Lab Panel Extraction Panel` | Multi-panel lab extraction | `lab_panel_extraction.py` | on upload | No | Yes | No | Yes | Yes | source file | panel | review flow |
| `AI Prompt Template` | Runtime-editable prompts | seed patch only | migrate | — | — | — | — | — | — | — | — |
| `AI Usage Counter` | Per-user metering | **nothing** | never | — | — | — | — | — | — | — | — |
| `AI Subscription Plan` (+`…Company`, `…Seat`) | Billing scaffolding | **nothing** | never | — | — | — | — | — | — | — | — |

**`AI Prompt Template` is not read at runtime** — confirmed: seeded by
`patches/v0/seed_ai_prompt_templates_20260723.py`, and every live prompt load goes
through `repo_prompt()` → the filesystem (`integrations/llm.py`). Editing a row changes
nothing. The docs flag this as "verify before relying on it"; it is now verified: **not live.**

**`AI Usage Counter` / `AI Subscription Plan` ×3 are dead scaffolding** — no writer
anywhere in the app.

### 13.1 Can we reconstruct WHY the AI produced a particular recommendation?

**No. Not for the agent path.** This is the audit's most consequential structural gap.

Given `AI Prompt Log` row + `AI Encounter Chat Message` row for one Analyze, you can recover:

| Recoverable | Not recoverable |
|---|---|
| ✅ Which prompt file, by SHA-256 (when set — see §14) | ❌ **Which tools were called with which arguments** |
| ✅ Which model + reasoning effort | ❌ **What each tool returned** |
| ✅ Token counts, cached count, cost, latency, round-trip count | ❌ **The transcript state at call time** (segments mutate later via `sync_transcript`/resegregate) |
| ✅ The final assistant reply text | ❌ **The rendered prompt** (deliberate — it is PHI, `AI_TOKEN_COST_MODEL.md` §7) |
| ✅ The resulting suggestions (`actions_json`) | ❌ **Which transcript line justified a given suggestion** |
| ✅ *That* tools were used, by name, comma-joined | ❌ **The order of tool calls, or which round-trip each fell in** |
| ✅ The input fingerprint (Analyze only) | ❌ **Whether the physician accepted, edited, or rejected each suggestion** |

The decisive gap is the middle column of the causal chain. You can prove *what* the AI
proposed and *what instructions* it ran under, but not *what data it was looking at when
it proposed it*. For a clinical AI decision — "why did it order PT/INR?" — the answer
lives entirely in tool arguments and results, and those are stored nowhere.

**Acceptance/rejection is not recorded at all.** `actions_json` holds what was
*proposed*. Whether it reached the signed record is only inferable by diffing the
signed encounter against the suggestion list — and `remove_*` tools plus manual edits
make that inference unreliable. The one exception is `AI SOAP Draft`, which has a real
`status` field (`Generated` → `Accepted` / `Discarded`).

---

## 14. Observability

### 14.1 What `AI Prompt Log` actually stores

Verified from `log_prompt_call` (`services/ai.py:472-500`) — 21 fields:

| Field | Populated? | Notes |
|---|---|---|
| `encounter`, `patient` | ✅ | patient resolved from encounter |
| `purpose` | ✅ | via `_PROMPT_FILE_PURPOSE` map; **unmapped files silently fall back to "Copilot Suggestions"** with a warning (`:247-267`) |
| `model` | ✅ | dated snapshot id, e.g. `gpt-5-mini-2025-08-07` |
| `prompt_version` | ✅ | filename stem |
| `prompt_hash` | ⚠️ **NULL on 239 of 329 ask-copilot-v2 rows (73%)** | auto-resolution was added recently; historical rows never backfilled |
| `status` | ✅ | Success / Failed / **Cached** / Summarizing |
| `tokens_in`, `tokens_out` | ✅ | summed across round-trips |
| `cost_estimate_usd` | ⚠️ | **overstated — see §15** |
| `latency_ms` | ✅ | wall clock, whole turn |
| `error` | ✅ | 50 Failed rows live |
| `tools_used` | ⚠️ **NULL on 64 of 329** | **names only, comma-joined — never args, never results** |
| `reasoning_tokens`, `cached_tokens` | ✅ | **contradicts the docs, which say `cached_tokens` is never captured** |
| `round_trips`, `provider_ms`, `tool_ms`, `prompt_build_ms`, `serialize_ms` | ✅ | span instrumentation, request-scoped via `frappe.local` |
| `source_file` | ✅ | document paths only |

`collect_spans()` also returns a per-round-trip `trips[]` array (in/cached/out/reasoning/ms/tools
per trip) — **and `log_prompt_call` drops it.** Only the scalar aggregates are persisted.
That per-trip detail is computed on every call and thrown away.

### 14.2 Your checklist, item by item

| Wanted | Status |
|---|---|
| model | ✅ |
| prompt version | ✅ (+ hash on 27% of agent rows) |
| input tokens | ✅ |
| output tokens | ✅ |
| cost | ⚠️ recorded but wrong (§15) |
| latency | ✅ (+ 5-way span breakdown) |
| tool calls | ⚠️ **names only** |
| **tool arguments** | ❌ **not stored anywhere** |
| **tool results** | ❌ **not stored anywhere** |
| final response | ✅ `AI Encounter Chat Message.content` |
| errors | ✅ |
| **transcript reference** | ❌ **no link.** No `session` or segment-range field on `AI Prompt Log`; and segments are mutable after the fact, so even a link would not pin the version read |
| encounter ID | ✅ |

### 14.3 What blocks reproducing an AI decision

1. **Tool arguments and results are not stored** — the largest gap. The docstring cites
   Rule 10 (PHI), which is a correct concern; but tool *names* + *arg keys* + result
   *shape/counts* would be recoverable without content, and none of that is kept either.
2. **`prompt_hash` NULL on 73% of agent rows** — `prompt_version` records only a
   filename, and `ask-copilot-v2.txt` has been edited repeatedly under the same name
   (its byte size has grown from 22,916 to 30,506 since the docs were measured). Rows
   labelled identically ran materially different instructions.
3. **`_ANALYZE_PROMPT` is a Python constant**, so its version is captured only
   indirectly, via the fingerprint's `extra_prompt` — and only when the cache is enabled.
4. **No transcript version pin.** `sync_transcript` and `resegregate_transcript` mutate
   segments in place after the fact.
5. **No acceptance tracking** for encounter-level suggestions.
6. **`trips[]` discarded** — per-round-trip detail exists in memory and is not persisted.
7. **Nested LLM calls are attributed elsewhere.** `get_lab_analysis` inside an agent
   turn logs its own row under a different purpose; the agent row's cost excludes it.
8. **Test pollution in the production log table** (§15.4) — ~180 rows with `MagicMock`
   model names and fabricated costs, plus 65 rows with `model='m'`.

---

## 15. Cost / performance — documented vs measured

All figures re-queried from `marley.local` `tabAI Prompt Log` on **2026-08-13**.
The documented figures date from 2026-07-29 / 2026-08-04.

### 15.1 The agent path, measured now

`prompt_version = 'ask-copilot-v2'`, `status = 'Success'`, **302 calls**:

| Metric | Measured 2026-08-13 | Docs claim | Verdict |
|---|---|---|---|
| Calls | 302 | 199 | grown |
| Total tokens in | **16,131,063** | 4,327,755 | grown 3.7× |
| **Avg tokens in** | **53,414** | 21,748 | **docs stale by 2.5×** |
| Avg tokens out | 703 | 457 | grown |
| Total tokens out | 212,194 | 90,955 | — |
| **Avg latency** | **15,958 ms** | 10,700 ms | grown |
| **Max latency** | **98,624 ms (98.6 s)** | 50,400 ms | **worse than documented** |
| **Max tokens in** | **265,189** | 166,672 | **worse than documented** |
| Logged cost | $4.4571 | $1.2638 | — |
| **`cached_tokens`** | **7,414,400 (46% of all input)** | *"never captured"* | **docs contradicted** |
| `reasoning_tokens` | 32,064 | not tracked | now tracked |
| Share of all app input tokens | **92.93%** | 89.9% | confirmed, higher |

### 15.2 Round-trips — the retransmission claim, verified directly

The docs *inferred* 15.4 round-trips by dividing tokens by a measured prefix. The
`round_trips` column now measures it. Instrumented rows only:

| round_trips | n | avg tokens_in | avg cached | cached % | avg latency |
|---:|---:|---:|---:|---:|---:|
| 1 | 2 | 10,894 | 9,728 | 89% | 4,198 ms |
| 2 | 6 | 22,948 | 20,352 | 89% | 6,035 ms |
| 4 | 7 | 47,264 | 43,666 | 92% | 15,815 ms |
| 5 | 3 | 57,595 | 55,296 | 96% | 19,611 ms |
| 8 | 2 | 110,858 | 98,496 | 89% | 32,293 ms |
| 12 | 3 | 178,407 | 154,411 | 87% | 37,555 ms |
| 14 | 7 | 173,057 | 163,675 | 95% | 37,026 ms |
| 16 | 7 | 233,636 | 225,463 | 96% | 43,685 ms |
| 20 (cap) | 3 | 243,298 | 231,296 | 95% | 32,730 ms |

**Confirmed:** `tokens_in ≈ round_trips × ~11,500`. The fixed-prefix retransmission
model is exactly right, and the prefix is now **~11,500 tokens** (docs measured 10,816 —
the system prompt has grown from 22,916 to 30,506 bytes since).

**Refuted:** "15.4 round-trips" is not typical — it is the **top of the distribution**.
Most turns land at 1–5. The 20-cap is hit on real encounters (3 rows).

**New, and it changes the cost conclusion entirely: 87–96% of input is cached on every
multi-trip call.** OpenAI bills cached input at a fraction of the full rate. The
retransmission is real in tokens and largely discounted in dollars.

### 15.3 The pricing bug — arithmetically confirmed, still live

```python
# integrations/anthropic.py:563-567  — UNCHANGED
def _estimate_cost(usage: dict, model: str) -> float:
    inp_rate, out_rate = _COST_PER_MTOK.get(model, (3.0, 15.0))   # ← Sonnet fallback
```

Proof from live data. `prompt_version='v3'`, `model='gpt-5-mini'`: 483,757 in /
438,923 out, logged **$8.0351**.

```
At Claude Sonnet rates:   483757×3/1e6  + 438923×15/1e6 = 1.4513 + 6.5838 = $8.0351  ← EXACT MATCH
At real gpt-5-mini rates: 483757×0.25/1e6 + 438923×2/1e6 = 0.1209 + 0.8778 = $0.9987
```

**Overstated 8.05×.** Same for `v2` ($7.1761 logged vs ~$0.89 real). `openai.py` was
fixed (longest-prefix match, `:985-996`); `anthropic.py` never was — and the lab
extraction path routes gpt-5-mini calls through it.

`openai.py::_estimate_cost` has a second, opposite-direction error: it applies the
**full** input rate to all `tokens_in`, ignoring the 46% that were cached. So agent-path
cost is overstated too, by roughly 4–5× on the input term at 92% cache rates.

**Net: every cost figure in `AI Prompt Log` is wrong, in both directions, on both adapters.**

### 15.4 Test pollution in the production log

| Pattern | Rows | Fabricated cost |
|---|---:|---:|
| `model LIKE '%MagicMock%'` (`mock.generate_thread_title()...`) | **~180** | **$1.00–2.00 each ≈ $180** |
| `model = 'm'` | 65 | $0.0012 |
| `model = 'cache'` (legitimate — `status='Cached'`) | 23 | $0.00 |

Unit tests are inserting into the live site's `AI Prompt Log` with `cost_estimate_usd`
values of 1.0 and 2.0. **This alone dwarfs all real spend** and makes any
`SUM(cost_estimate_usd)` meaningless. Total row count 1,654 (1,576 Success, 50 Failed,
23 Cached, 5 Summarizing).

### 15.5 The ASR claim — refuted by real data

`tabAI Encounter Record`, 23 rows with real cost data:

| Metric | Measured | Docs claim |
|---|---:|---|
| Avg ASR cost | **$0.0095** | — |
| Avg LLM cost | **$0.0305** | — |
| Avg total | **$0.0400** | — |
| **ASR share** | **23.7%** | **">50% of per-encounter AI spend"** |

**The headline claim that ASR is the majority of AI spend is not supported.** ASR is
under a quarter. Caveat, stated rather than hidden: n=23 and these are likely short
dev/test encounters, so the *absolute* figures are not production-representative — but
the *ratio* is measured from the same rows on both sides, and the ratio is what the
claim was about. `AI Encounter Record` records both costs per encounter, so this is
directly re-runnable at any scale.

### 15.6 Verdict per documented number

| Documented | Verdict |
|---|---|
| 166k input tokens per Analyze | **Superseded** — that was a worst case; current worst is 265,189, current avg 53,414 |
| 1,813 output | **Plausible for that one run**; current avg 703 |
| ~50 s | **Superseded** — current avg 16 s, max 98.6 s |
| ~4.5 ¢ | **Wrong** — that used the uncached rate. Real cost is ~4–5× lower on cached input |
| 15.4 round-trips | **Refuted as typical**, confirmed as the tail |
| Retransmitted prefix | **Confirmed**, now ~11,500 tokens/trip, and **87–96% cached** |
| `ask-copilot-v2` ≈ 90% of input | **Confirmed** — 92.93% |
| ASR > 50% of spend | **Refuted** — 23.7% |
| gpt-5-mini pricing fallback bug | **Confirmed, exact, still live** |
| `cached_tokens` never captured | **Refuted** — captured, logged, not applied to cost |

---

## 16. Safety controls

### 16.1 Authorization and gating (deterministic, working)

| Control | Location | Enforces |
|---|---|---|
| `_require_auth()` | `api.py:23` | rejects Guest |
| `_require_encounter_read()` | `api.py:385` | `frappe.has_permission("Patient Encounter","read",doc=…)` per call |
| `allow_write` tool filtering | `api.py:808` → `ai_tools.py:1666` | a read-only caller is **never offered** the 23 write tools |
| `require_permission` per read tool | each `_tool_*` | doctype-level check inside the tool |
| `_require_suggestions_enabled()` | `api.py:39` | `AI Settings.enable_suggestions` |
| Lab ownership check | `api.py:1446` | `row.patient != patient` → throw |
| `_require_encounter_read` on SOAP accept/discard | `api.py:677` | ownership on draft mutation |
| Sign gate | `encounters/api.py:1898` | `chief_complaint` non-empty required to submit |
| Save re-validation | `encounters/api.py:487-600` | every prescription field re-checked against masters |
| Consent gate | `AI Encounter Session` | recording requires consent state |

**Encounter ownership is checked on every AI call.** This is solid.

### 16.2 Deterministic clinical safety — the complete list

There are **five**, and that is all.

| # | Control | Location | Strength |
|---|---|---|---|
| 1 | **Allergy name match** | `_allergy_conflict` `ai_tools.py:374` | Substring both ways + shared ≥5-char family prefix. Its own docstring: *"NOT a clinical authority (no real cross-reactivity database)"*. Catches Sulfametoxazol↔Sulfamidas. **Advisory only — never blocks; the drug is still added** |
| 2 | **Duplicate prescription guard** | `_rx_already_present` `ai_tools.py:636` | Normalised text + shared linked `Item` + strength comparison. Genuinely good: survives re-wording across Analyze runs ("Topical hydrocortisone cream 1%" vs "Hydrocortisone cream 1%"). **Blocks** |
| 3 | **Duplicate order guard** | `_order_already_present` `ai_tools.py:819` | Same idea for labs/procedures/therapies, incl. abbreviation↔full-title collapse. **Blocks** |
| 4 | **Vaccine catalog match** | `_match_immunization_template` `ai_tools.py:1114` | Exact-then-substring, returns `None` on ambiguity. **The only BLOCKING catalog check** |
| 5 | **Vital numeric parse** | `_tool_add_vital` `ai_tools.py:1007-1018` | `float(value.replace(",","."))` — rejects `"null"`, `"None"`, `"N/A"`. Added after the model literally sent `add_vital(temp,"null")`. **Blocks** |

Plus two adjacent guards worth naming:
- **Resegregate word-multiset check** (`services/ai.py:853-867`) — rejects the entire
  re-segregation if the output's word multiset diverges >10% from the input. A real
  anti-hallucination guarantee: the LLM cannot add or drop transcript words.
- **Document classification gate** (`api.py:1664`) — a non-clinical attachment is never
  filed to the patient chart; fail-closed to non-medical on unparseable output.

### 16.3 What has NO deterministic validation

| Not validated | Consequence |
|---|---|
| **Drug strength value** | `0` mg or any number passes to the signed record. No range, no age band, no weight check |
| **Weight-based paediatric dosing** | Prompt-only (`ask-copilot-v2.txt:125`). Nothing reads `Vital Signs.weight` to check a dose |
| **Drug–drug interactions** | Nothing. No interaction database anywhere in the app |
| **Age-appropriateness of any drug** | Prompt-only (`:118-126`) — and it keys off the corrupted `age` integer (§10) |
| **Contraindication rules** | Prompt-only (`:128-137`) |
| **Diagnosis→medication justification** | Nothing. Explicitly permitted (§9.3) |
| **Transcript grounding of any suggestion** | Nothing. No check that a proposed item appears in the transcript |
| **Patient-level writes** | Nothing — and they bypass Save/Sign entirely (§8.5) |
| **Chief-complaint provenance** | Nothing compares it against the prior-visit summary (§11.3) |

`AI Settings.enable_safety_validators = 0` on the live site, **and no code reads that
flag** in `api/v1/ai/api.py` or `services/ai_tools.py`. It gates nothing.

### 16.4 The paediatric vitals thresholds — verified

**Yes, they are live. They are frontend-only, cosmetic, and duplicated.**

```tsx
// encounter-screen.tsx:3644-3646  (read-only vitals display)
(key === "temp" && parseFloat(val) > 37.5) ||
(key === "hr"   && parseInt(val) > 110)    ||
(key === "spo2" && parseInt(val) > 0 && parseInt(val) < 95);
// :3668
const bpWarn = parseInt(newVitals.sys) > 140 || parseInt(newVitals.dia) > 90;

// encounter-screen.tsx:3758-3760, :3790  — the SAME four rules again, editable inputs
```

| Question | Answer |
|---|---|
| Are they used? | **Yes** — two independent copies, display + input panels |
| Where? | `encounter-screen.tsx` only. **Zero backend references** |
| What do they do? | Set `text-rose-600/700` styling and render an `abnormal` label |
| Do they gate anything? | **No.** Not Save, not Sign, not an alert, not a notification |
| Does the LLM see them? | **No.** `add_vital` and `get_encounter_state` pass raw numbers with no flag |
| Are they age-banded? | **No.** Single fixed adult set for every patient |

Clinical consequence in a paediatric practice, restated from the code:
- Infant HR 110–160 is **normal** → flags red on every healthy infant (alarm fatigue).
- Neonate HR 90 is **bradycardic** → does **not** flag (`90 > 110` false).
- Infant RR 40–60 is normal; `rr` **has no rule at all** in either block.
- Systolic 140/90 is a hypertensive threshold no child reaches; a hypotensive infant at
  70/40 flags nothing.

It over-warns and under-warns simultaneously, and the under-warning is the dangerous
half. Because the flag is display-only, its real cost is that it trains clinicians to
ignore red vitals text.

---

## 17. Known bugs — found in this audit

> **Status update 2026-08-14.** B1, B8, B9 and B10 are **fixed** (PRs #310 / #311, open).
> B3 is **now measurable** but deliberately unfixed. B11 is **resolved as won't-backfill**,
> with the reasoning recorded. Everything else stands as written. Each entry below carries
> its current status inline.

Ordered by clinical severity. Every entry has a `file:line` and, where possible, live evidence.

### B1 — Infant age truncated to `0`, then read as "0 years" — ✅ **FIXED 2026-08-14, PR #310 (open)**
`services/ai.py:880` — `int(date_diff(nowdate(), dob) / 365)`.
Every patient under 12 months is sent to the LLM as `0`. `ask-copilot-v2.txt:5` and
`:119` teach that the integer means **years**, so `0` reads as neonate. The entire
paediatric safety block keys off this value.
**Live evidence:** `MRN-2026-0000003`, DOB 2026-03-03 (5 months) → `0G`; 5 more patients
confirmed. The accurate `patient_age` string ("5 Months") exists on the encounter and is
used only as a DOB-missing fallback. Also drifts a year on leap-year births.

### B2 — Five write tools bypass Rule 6 entirely 🔴 CRITICAL
`encounter-screen.tsx:3217-3263` — the `aiDraft` effect calls `updatePatient.mutate(...)`
immediately. `add_allergy`, `add_patient_medication`, `add_medical_history`,
`add_surgical_history`, `set_patient_summary` write to the permanent `Patient` record
before Save, before Sign, with no confirmation. The "review & add" panel auto-hides once
the write has happened, because its new-item list is now empty. Comment acknowledges the
behaviour but not that it contradicts Rule 6.
**This is the mechanism behind "paracetamol taken at home" appearing unsupported:**
`_ANALYZE_PROMPT` (`api.py:993-997`) names paracetamol/Tylenol as the example OTC drug to
capture, the model obliges, and the value auto-writes to the chart.

### B3 — Speaker attribution: positional guess + three silent doctor fallbacks — ⚠️ **NOW MEASURABLE, PR #380 (open). Deliberately NOT fixed** — the raw index is persisted so the mapping's true error rate can be measured; changing attribution before measuring it would be guessing
`real-provider.ts:52-55` maps index 0→doctor unconditionally; nothing verifies who
speaker 0 is, so a patient-first recording inverts the whole transcript.
Three fallbacks default to doctor: `_groupBySpeaker` no-words case (hardcoded
`speaker:"doctor"`), interim `?? 0`, multichannel `?? 0` / non-`1`.
**Live evidence:** 2,978 doctor vs 1,648 patient segments (1.8:1 in a two-party setting);
1,307 (22%) `unknown` from `?? "unknown"` on index ≥2 (third speaker — routine in paediatrics).
The LLM receives asserted role labels with no confidence and no "may be wrong" marker,
so it cannot detect an inversion.

### B4 — Prompt licenses adult-strength inference in a paediatric practice 🔴 HIGH
`ask-copilot-v2.txt:101` — ask for strength only if you "cannot confidently infer the
standard **adult** strength". Directly contradicts `:5` (paediatric practice) and `:125`
(never state an adult dose without a weight check). No numeric validation exists at any
layer (§16.3), so an inferred strength reaches the signed record unchallenged.

### B5 — `strength = 0` reaches real prescriptions 🟠 MEDIUM
`parse_medication_fields` `services/ai.py:769-771` coerces to `float(... or 0)`.
Real records cited in-code: `"N/A Ondansetron 0Milligram"`, `"N/A PARACETAMOL 0Milligram"`.
Mitigated only when the model supplies a `strength` arg (`ai_tools.py:706`); supply
neither name-strength nor arg and it is still 0.

### B6 — Transcript truncation drops the opening of long consultations 🟠 MEDIUM
`ai_tools.py:189` — `text[-_MAX_TRANSCRIPT_CHARS:]` keeps the **tail**. The chief
complaint from minute 2 is gone by minute 25, while `_ANALYZE_PROMPT` forbids filling the
gap from history. The code logs when it bites and surfaces `truncated:true` to the model,
which is good; the fidelity loss is unfixed.

### B7 — Adult vitals thresholds in a paediatric clinic 🟠 MEDIUM
`encounter-screen.tsx:3644-3646, 3668, 3758-3760, 3790` — duplicated adult rules,
display-only, not age-banded, no `rr` rule. Over- and under-warns (§16.4).

### B8 — Anthropic pricing fallback: cost overstated 8.05× — ✅ **FIXED 2026-08-14, PR #311 (open).** $8.0351 → $0.9988
`integrations/anthropic.py:564` — `.get(model, (3.0, 15.0))`. Arithmetically confirmed
against live rows (§15.3). `openai.py` was fixed; this was not.

### B9 — Cached tokens captured but not discounted — ✅ **FIXED 2026-08-14, PR #311 (open).** Agent call $0.01476 → $0.00923
`openai.py:999-1003` applies the full input rate to all `tokens_in`, while 46% of agent
input (87–96% per multi-trip call) is cached. Overstates the input term ~4–5×.

### B10 — Unit tests write to the production `AI Prompt Log` — ✅ **FIXED 2026-08-14, PR #311 (open).** 234 rows purged ($169 fabricated cost); `_skip_prompt_log()` prevents recurrence
~180 rows with `model='<MagicMock name=mock.generate_thread_title()…>'` and
`cost_estimate_usd` of 1.0–2.0, plus 65 rows with `model='m'`. Fabricated cost exceeds
all real spend, making cost aggregates meaningless.

### B11 — `prompt_hash` NULL on 73% of agent rows — ✅ **RESOLVED as WON'T-BACKFILL 2026-08-14, PR #311 (open).** New rows are populated; historical ones stay NULL because the prompt file has changed and a fabricated hash is worse than an honest gap
239 of 329. `prompt_version` records only a filename, and `ask-copilot-v2.txt` grew from
22,916 to 30,506 bytes under the same name. Identical labels, different instructions.

### B12 — History window mismatch: 16 fetched, 6 used 🟡 LOW
`_load_chat_context(limit=16)` `api.py:949` vs `(history or [])[-6:]` `openai.py:1331`.
Ten turns fetched and discarded per call.

### B13 — Three `ctx` fields resolved and never sent 🟡 LOW
`existing_medications`, `existing_medical_history`, `existing_surgical_history` are built
(`services/ai.py:92-94`) but absent from `context_block`. So the agent appends to patient
history blind — exactly the risk the comment at `:85-91` says they prevent.

### B14 — `soap-v1.txt` self-contradiction 🟡 LOW
Line 5 "a thin, partial draft is a failure" vs line 6 "never invent content to fill in a
section". Line 5 wins structurally (§7.4). `enable_soap_generation=1` live.

### B15 — A read tool writes to the DB and makes a nested LLM call 🟡 LOW
`get_lab_analysis` `ai_tools.py:296` → `generate_summary_sync` writes
`Lab Test.custom_ai_summary` and logs its own `AI Prompt Log` row under a different
purpose; the agent turn's cost excludes it.

### B16 — Non-matching dosage/period silently demoted 🟡 LOW
`ai_tools.py:673-683` and `encounters/api.py:582-585` move unparseable dosing text into
`comment`. Correct choice (the alternative 400s the whole autosave) but silent — the
physician sees prose where structured frequency should be, with no marker.

### B17 — `smart_format` missing from the live streaming path 🟡 LOW
Present in `mint_browser_token:345`, absent from `mint_session_token`. Two divergent
param builders. Affects number/date formatting only.

### B18 — Dead scaffolding and an empty prompt 🟡 LOW
`AI Usage Counter`, `AI Subscription Plan` ×3 have no writer. `AI Prompt Template` is
seeded and never read at runtime. `prompts/narzim-assistant-phi-check-v1.txt` is 0 bytes
with an orphaned caller.

---

## 18. Documentation drift

> **Note (2026-08-13, after this audit):** `AI_TOKEN_COST_MODEL.md` (D4, D6, D7, D16) and
> `AI_ENCOUNTER_OPTIMIZATION_PLAN.md` (D5) were **removed** once this audit superseded their
> figures. The rows below record what they claimed, for traceability. Both are recoverable via
> `git show 450aace:docs/ai/<file>`. `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` (D13) was **retained** —
> four source files cite it by section as the design rationale for shipped code.

| # | Doc claim | Code reality | Severity |
|---|---|---|---|
| D1 | `CLAUDE.md` §6: `api/v1/ai/api.py` is a "🔴 Phase 5 stub"; `services/*.py` "empty stubs"; AI is "deferred to Phase 5, do not build" | **1,778 lines live in production.** `services/ai.py` 946, `ai_tools.py` 1,707, `openai.py` 1,511, `anthropic.py` 1,312. AI has been shipping for weeks | 🔴 |
| D2 | `CLAUDE.md` §7: "All 5 custom doctypes" | **18 AI doctypes** exist | 🔴 |
| D3 | `CLAUDE.md` §3/§8: LLM is "AI phase only", Phase 5 not started | Live: OpenAI `gpt-5-mini`, 1,654 prompt-log rows | 🔴 |
| D4 | `AI_TOKEN_COST_MODEL.md` §6.2: "`cached_tokens` appears nowhere in the codebase" | Captured (`usage_detail` `openai.py:668`), logged, **46% of agent input** | 🔴 |
| D5 | `AI_ENCOUNTER_OPTIMIZATION_PLAN.md` §2: "ASR is >50% of per-encounter AI spend" | **23.7%** measured from `AI Encounter Record` | 🔴 |
| D6 | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §7: avg 21,748 in, 10.7 s, 4.5¢, 15.4 round-trips | avg **53,414** in, **16.0 s**, max **98.6 s** / **265,189** tokens; round-trips typically **1–5**, not 15.4; cost overstated by the uncached rate | 🔴 |
| D7 | Docs: `services/llm.py::get_llm_client()`. Also `AI_TOKEN_COST_MODEL.md` §6.3: "`prompt_hash` is not among them" | `services/llm.py` is correct (32 lines) — but `integrations/llm.py` (1,023 lines) also exists and is the prompt/schema layer. `prompt_hash` **is** now written, auto-resolved (`services/ai.py:482`) — just NULL on 73% of historical rows | 🟠 |
| D8 | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §5 + `prompts/README.md`: "Only **7** prompt files remain, and every one is live" | **10 files.** Missing from the manifest: `narzim-assistant-v1.txt`, `narzim-thread-title-v1.txt`, `narzim-assistant-phi-check-v1.txt` (0 bytes, orphaned) | 🟠 |
| D9 | `README.md`: idempotency "Shipped `c778ad5`"; the design doc header still says "Design proposal (not yet built)" | Shipped **and** default-OFF (`_analyze_cache_enabled()` `api.py:1292`). Enabled on `marley.local` (23 `Cached` rows). Both statements are wrong in different directions | 🟠 |
| D10 | §1 doc: "Streamed Analyze over SSE — reverted, **code removed**" | `ask_copilot_agent_stream()` is the **primary implementation** in both adapters; `ask_copilot_agent()` drains it. Only the SSE *endpoint* was removed | 🟠 |
| D11 | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §3 diagram: "no prompt caching" (self-flagged stale) | Confirmed stale — caching active and measured | 🟠 |
| D12 | Docs describe ~7 encounter-copilot endpoints | **63** whitelisted AI methods across 11 files | 🟠 |
| D13 | `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` §0.3: transcript ≈1,500 tokens = "~1% of an Analyze turn" | Directionally right but based on the stale 166k figure; the prefix is now ~11,500/trip | 🟡 |
| D14 | `ASR_TRANSCRIPT_AUDIT.md` F3: `smart_format` "absent from `mint_session_token`" | Confirmed accurate | ✅ |
| D15 | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §4: 36 tools, 13 read / 23 write | Confirmed exactly | ✅ |
| D16 | `AI_TOKEN_COST_MODEL.md` §6.1: Anthropic 8× pricing bug | Confirmed exactly, arithmetically, still live | ✅ |
| D17 | Docs: `ask-copilot-v2` ≈90% of all input tokens | Confirmed — 92.93% | ✅ |
| D18 | Docs: paediatric vitals thresholds are adult values in `encounter-screen.tsx` | Confirmed, and duplicated in two blocks | ✅ |
| D19 | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §11 references `docs/ai/AI_LAB_REPORT_EXTRACTION.md` | Files exist at `docs/`, not `docs/ai/`. Also one bullet lost its document name in the 2026-08-13 deletion pass | 🟡 |
| D20 | Two ADRs numbered 030 | Confirmed, unfixed | 🟡 |

**Pattern.** The living design docs (`NARZIM_AI_ENCOUNTER_SYSTEM.md`,
`AI_TOKEN_COST_MODEL.md`) are accurate about *structure* and stale about *numbers* —
their maintenance policy worked for the tool registry and the pricing bug, and did not
survive two weeks of traffic growth. `CLAUDE.md` is the outlier: it is not stale, it is
**inverted** — it instructs the reader not to build the system that is already in
production. Anyone onboarding from `CLAUDE.md` alone would conclude Remedisys has no AI.

---

## 19. Unknowns — needing instrumentation, not assumption

Recorded rather than guessed.

| # | Unknown | Why it cannot be answered from code | What would answer it |
|---|---|---|---|
| U1 | **How often is speaker 0 actually the doctor?** The single most important number in this audit | The raw Deepgram index is discarded — `speaker_label` NULL on all 5,933 rows | Persist `speaker_label` (raw index) alongside the mapped role, then compare against physician corrections |
| U2 | **How often do physicians correct speakers?** | `setSegmentSpeaker`/`sync_transcript` update rows in place with no audit of the prior value | Log a correction event with (old, new, segment) |
| U3 | **How often is B3's no-words fallback hit?** | No log line on that branch | One counter in `_groupBySpeaker` |
| U4 | **Acceptance rate of AI suggestions** | `actions_json` records proposals; nothing records outcomes | Persist per-suggestion accept/edit/reject at Save/Sign |
| U5 | **How much of the signed record originated with the AI?** | No provenance flag on any encounter child row | A `source` field, or diff the signed doc against `actions_json` |
| U6 | **True production cost** | Both cost formulas wrong (B8, B9) + ~$180 test pollution (B10) | Fix both formulas, purge `MagicMock`/`m` rows, re-aggregate |
| U7 | **Real Analyze re-click rate** | 23 `Cached` rows exist but the enable flag flipped mid-history, so the denominator is unstable | The `AI Encounter Chat Message` clicks-per-encounter query, once the flag has been stable |
| U8 | **Does `pause()` bill Deepgram for silence? Is multichannel billed per channel?** | Deepgram-side billing semantics; not observable from this repo | Deepgram usage dashboard vs session durations |
| U9 | **Whether `nova-3`+`multi` diarization is materially worse than `nova-3-medical`+`en`** | Never A/B'd on real audio; the clinician confirmed transcription *accuracy*, which is not diarization *attribution* | Recorded 3-speaker paediatric sample across model×language, compare attribution not words |
| U10 | **Whether truncation (B6) has actually lost a chief complaint in production** | The warning log exists but was not queried in this audit | `grep "transcript truncated for agent"` in site logs |
| U11 | **Frequency of the 20-iteration cap in production** | 3 rows observed, denominator too small | `round_trips = 20` count over a stable window |
| U12 | **`is_medical` classifier false-negative rate** | Only the fail-closed outcome is logged, never the ground truth | Sample review of `attachment_not_filed` log lines |
| U13 | **Whether OCR/`antiword` work on Frappe Cloud** | Documented as unverified; degrades to `""` silently | Deploy-time check |
| U14 | **Whether `trips[]` per-round-trip detail would change any conclusion** | Computed then discarded by `log_prompt_call` | Persist it |

---

## 20. AI vs software responsibility — who owns what today

Owner is what the code actually does, not what should own it.

| Task | Current owner | Evidence |
|---|---|---|
| Audio capture | **Frontend** | `real-provider.ts` MediaRecorder / AudioContext |
| Speech-to-text | **External service** | Deepgram `nova-3`, direct browser WSS |
| Diarization (voice separation) | **External service** | Deepgram `diarize=true` |
| **Speaker identification (who is the doctor)** | **Frontend** — a hardcoded positional map, not a model | `real-provider.ts:52-55`; three `?? doctor` fallbacks |
| Speaker correction | **Frontend** (manual) → **LLM** ("Fix speakers") + **Backend rule** (word-multiset veto) | `setSegmentSpeaker`; `resegregate-v1` + `services/ai.py:853` |
| Transcript assembly | **Frontend** | `_groupBySpeaker`, `_buildTranscript` |
| Transcript persistence | **Backend + Database** | `append_segment` → `AI Transcript Segment` |
| Transcript truncation | **Backend rule** | `ai_tools.py:189`, tail-keep at 6,000 chars |
| **Symptom extraction** | **LLM** | `add_symptom`, `suggest-v2` |
| **Chief-complaint extraction** | **LLM**, with a **Backend rule** fallback | `add_chief_complaint`; `_derive_chief_complaint_if_missing` `encounters/api.py:150` |
| **Diagnosis suggestion** | **LLM** | `add_diagnosis`; catalog match advisory only |
| **Prescription suggestion** | **LLM** | `add_medication` |
| **Dose / strength selection** | **LLM** — licensed by **Prompt**, validated by **nothing** | `ask-copilot-v2.txt:101`; no numeric check anywhere |
| Dose vocabulary (dosage/period enums) | **Database** (masters) + **Backend rule** | `Prescription Dosage`/`Duration`; `ai_tools.py:673`, `encounters/api.py:582` |
| **Patient demographics** | **Database** — but **age is corrupted by a Backend bug** | `Patient`; `services/ai.py:880` |
| **Patient history (allergies, meds, PMH, PSH)** | **LLM proposes → Frontend auto-writes**, no approval | `encounter-screen.tsx:3217-3263` |
| **Patient summary** | **LLM authors and overwrites** | `set_patient_summary` → auto-write when empty |
| Previous-encounter retrieval | **Tool** (LLM-invoked) + **Backend rule** (`docstatus=1`) | `ai_tools.py:74-153` |
| Lab retrieval | **Tool**, bounded | `get_patient_labs`, `_MAX_LABS=8` |
| Lab interpretation | **LLM** (cached) | `get_lab_analysis` |
| Medication catalog | **Database** + **Tool** (keyword) | `Medication`; `search_medication_catalog` |
| Master creation from an AI name | **LLM infers fields → Backend inserts** | `create_master` → `Medication` + `Item` |
| Catalog grounding (non-vaccine) | **Prompt** — advisory, non-blocking | `ask-copilot-v2.txt:46-47` |
| Vaccine grounding | **Backend rule** — blocking | `_match_immunization_template` |
| Allergy conflict detection | **Backend rule** — advisory, name-similarity only | `_allergy_conflict` |
| Duplicate order/prescription detection | **Backend rule** — blocking | `_rx_already_present`, `_order_already_present` |
| Vitals numeric sanity | **Backend rule** | `add_vital` float parse |
| **Vitals abnormal flagging** | **Frontend** — cosmetic, adult thresholds | `encounter-screen.tsx:3644` |
| **Drug interactions / age-appropriateness / contraindications** | **Prompt only** | `ask-copilot-v2.txt:118-137` |
| Authorization | **Backend rule** | `_require_encounter_read`, `allow_write` |
| Encounter-draft state | **Frontend** (local until Save) | `encounter-screen.tsx` |
| Persistence + field validation | **Backend rule + Database** | `save_draft` → `_apply_drug_prescriptions` |
| Sign gate | **Backend rule** | `complete_encounter`, chief complaint required |
| **Doctor approval — encounter fields** | **Frontend** (explicit review) | ✅ Rule 6 holds |
| **Doctor approval — patient fields** | **Nobody** | ❌ Rule 6 broken (B2) |
| Cost/token accounting | **Backend** — wrong in both directions | `_estimate_cost` ×2 |
| Analyze result reuse | **Backend rule** (deterministic fingerprint) | `analyze_fingerprint` |
| Materiality detection | **Backend rule**, no LLM | `transcript_digest.py` |

**Reading the table:** the LLM owns *extraction and proposal*. Backend rules own
*vocabulary, duplication, authorization and persistence*. The gaps are the four rows
where an LLM output is owned by **Prompt only** or **nothing** — dose selection, drug
interactions, age-appropriateness, and patient-level history — plus the two rows where a
**Frontend** owns something clinical: speaker identity and vitals flagging.

---

## 21. The real production flow

Each box replaced with its actual implementation name.

```
AUDIO            getUserMedia → MediaRecorder(webm/opus, 250ms)          real-provider.ts
                 [dual-mic: AudioContext 48kHz → 2ch linear16 PCM]
                       │  direct WSS — never touches the Frappe server
                       ▼
ASR              Deepgram /v1/listen · nova-3 · language=multi
                 interim_results=true · endpointing=800 · punctuate · numerals
                 keyterm×≤50 (drug names)     [smart_format only on the other minter]
                       ▼
DIARIZATION      Deepgram diarize=true → per-WORD speaker index
                 (multichannel=0 live, so no channel-based path)
                       ▼
SPEAKER ROLE     _groupBySpeaker() + SPEAKER_MAP{0:doctor,1:patient}     ⚠ B3
                 index≥2 → "unknown"  ·  no words → "doctor"  ·  interim ?? 0 → "doctor"
                       ▼
TRANSCRIPT       finalSegments[] → 20s autosave + stop() flush
                 → append_segment → AI Transcript Segment (role only; raw index discarded)
                 → _buildTranscript() → "Doctor: …\nPatient: …"
                       ▼
API              Next.js BFF route (injects physician Bearer JWT)
                 → api/v1/ai/api.py::analyze_encounter | ask_copilot
                   _require_auth · _require_encounter_read · allow_write
                   build_encounter_context(include_catalogs=False)        ⚠ B1 age
                   [Analyze] analyze_fingerprint → cache probe → status="Cached"
                       ▼
AGENT            integrations/openai.py::ask_copilot_agent_stream
                 system = prompts/ask-copilot-v2.txt (150 lines)
                 user   = ENCOUNTER CONTEXT + last-6 history + question/_ANALYZE_PROMPT
                 loop ≤ _MAX_TOOL_ITERATIONS = 20 · whole message list re-sent each trip
                       ▼
LLM              OpenAI Chat Completions · gpt-5-mini-2025-08-07
                 reasoning_effort=low · max_completion_tokens=3700 · timeout=60s
                 temperature=0.4 PASSED THEN DROPPED (gpt-5 family)
                 tools=[36] · tool_choice=auto · no retry · 87–96% input cached
                       ▼
TOOLS            services/ai_tools.py::execute_tool → TOOL_REGISTRY (36)
                 13 READ  → require_permission → frappe.get_all (bounded) → JSON
                 23 WRITE → validate → ClinicalSuggestion  (zero DB writes here)
                 guards: _rx_already_present · _order_already_present
                         _match_immunization_template (blocking) · _allergy_conflict (advisory)
                       ▼
DRAFT            actions[]       → fillFormFromSuggestions → applySuggestionToEnc
                                 → enc.* local state, ✦ AI badge, editable
                 patient_draft{} → aiDraft effect → updatePatient.mutate()   ⚠ B2 WRITES NOW
                       ▼
DOCTOR REVIEW    encounter-screen.tsx — edit / accept / remove
                 (patient-level items already persisted; the review panel has auto-hidden)
                       ▼
SAVE / SIGN      save_draft()        → _apply_drug_prescriptions: drug_code, dosage_form,
                                       period, UOM re-validated vs masters
                                       strength ***NOT VALIDATED***
                 complete_encounter()→ chief_complaint required · docstatus 0→1
                       ▼
DATABASE         MariaDB — ERPNext Healthcare core (Patient Encounter + children,
                 Vital Signs, Lab Test, Drug Prescription, Immunization)
                 + AI Prompt Log · AI Encounter Chat Message · AI Transcript Segment
                 + AI Encounter Record (consolidated at sign)
```

---

## 22. What is real vs documentation

### A. CONFIRMED FROM CODE
1. One agent only — `analyze_encounter` calls `ask_copilot` (`api.py:1285`).
2. Both surfaces: same model, prompt file, 36 tools, 20-iteration cap.
3. `services/ai_tools.py` contains **zero** DB-mutating calls.
4. 36 tools = 13 read + 23 write, extracted programmatically.
5. `_MAX_TOOL_ITERATIONS = 20` in both adapters.
6. Temperature is dropped for gpt-5 models; `reasoning_effort` sent instead.
7. No retry on the agent path; transient errors → apology reply + `Failed` row.
8. Three-layer prompt assembly; **no developer-role message**; `_ANALYZE_PROMPT` is a
   Python constant delivered as the user turn.
9. Transcript reaches the model **only** via a tool, tail-truncated at 6,000 chars.
10. `_resolve_age` = `int(days/365)` → `0` for all infants.
11. `ask-copilot-v2.txt:5,:119` teach that `age` means years.
12. `encounter-screen.tsx:3217-3263` writes AI patient-level output immediately.
13. `SPEAKER_MAP{0:doctor,1:patient}` in the frontend, `_SPEAKER_ROLES` in the backend.
14. Three fallbacks to "doctor"; index ≥2 → "unknown".
15. The LLM receives role labels, never raw speaker indices.
16. Five deterministic clinical safety rules, one blocking catalog check (vaccines).
17. Zero validation of drug strength at any layer.
18. Zero embeddings / vector store / pgvector; the only match is a rejection rationale.
19. Six retrieval mechanisms exist under other names.
20. `AI Prompt Template` is seeded and never read at runtime.
21. `ask_copilot_agent_stream` is the primary implementation in both adapters.
22. `anthropic.py:564` Sonnet pricing fallback unchanged.
23. Adult vitals thresholds live in two frontend blocks, display-only, no `rr` rule.
24. `ask-copilot-v2.txt:96` still instructs one tool call per item.
25. 10 prompt files, one empty and orphaned.
26. 63 whitelisted AI methods across 11 files; 18 AI doctypes.
27. `soap-v1.txt` lines 5/6 contradict each other.
28. History: 16 fetched, 6 used.
29. Three `ctx` history fields resolved and never sent to the agent.
30. `get_lab_analysis` (read tool) writes the DB and makes a nested LLM call.
31. Resegregate word-multiset guard genuinely blocks hallucinated transcript text.

### B. CONFIRMED FROM DATABASE / LOGS (`marley.local`, 2026-08-13)
1. Live config: OpenAI · `gpt-5-mini` · `reasoning_effort=low` · `llm_max_tokens_out=16000`.
2. Deepgram: `nova-3` · `multi` · `diarize=1` · `multichannel=0`.
3. `enable_safety_validators = 0`; `enable_analyze_cache = 1`.
4. `ask-copilot-v2`: 302 calls, 16,131,063 in / 212,194 out, avg 53,414 in / 703 out.
5. Avg latency 15,958 ms; **max 98,624 ms**; **max input 265,189 tokens**.
6. `cached_tokens` = 7,414,400 → **46% of all agent input**; 87–96% per multi-trip call.
7. `tokens_in ≈ round_trips × ~11,500` — retransmission confirmed directly.
8. Round-trips are typically 1–5; the 20-cap is reached on real encounters (3 rows).
9. `ask-copilot-v2` = **92.93%** of all app input tokens.
10. `v3` logged $8.0351 = **exactly** Sonnet rates on gpt-5-mini → 8.05× overstated.
11. **Age bug reproduced**: `MRN-2026-0000003`, DOB 2026-03-03 (5 months) → `0G`; 5 more.
12. `AI Transcript Segment`: `speaker_label` NULL on **all 5,933** rows.
13. Segment skew: 2,978 doctor / 1,648 patient / **1,307 unknown (22%)**.
14. Segment confidence avg: 0.837 / 0.848 / 0.828.
15. `prompt_hash` NULL on **239 of 329** agent rows (73%).
16. `tools_used` NULL on 64 of 329.
17. Log status: 1,576 Success · 50 Failed · 23 Cached · 5 Summarizing.
18. **~180 `MagicMock` rows** at $1–2 fabricated cost each, plus 65 `model='m'` rows.
19. `AI Encounter Record` (n=23): ASR $0.0095 / LLM $0.0305 / total $0.0400 → **ASR = 23.7%**.

### C. DOCUMENTED BUT NOT VERIFIED IN THIS PASS
1. Anthropic adapter behaviour end-to-end (live provider is OpenAI; the code was read, not exercised).
2. Deepgram accepting every model×language combination (the 2026-07-22 probe was not re-run).
3. That `nova-3`+`multi` transcribes the Scottish-accented doctor well — clinician-confirmed
   for *word accuracy*; **diarization attribution was never tested** and is a different property.
4. Frappe Cloud `apt` installation of `tesseract-ocr`/`antiword` (documented as unverified).
5. Narzim general-assistant redaction coverage (`pii_redaction.py` read only in outline).
6. Whether `AI Encounter Record`'s 23 rows are production-representative.
7. Lab-extraction and patient-portal chat paths (read in outline; not the audit's scope).

### D. DOCUMENTATION CONTRADICTS CODE
Full table in §18. The consequential five:
1. **`CLAUDE.md` says AI is unbuilt and forbidden before Phase 5.** It is in production. (D1, D3)
2. **`CLAUDE.md` lists 5 AI doctypes.** There are 18. (D2)
3. **`cached_tokens` "appears nowhere".** It is captured, logged, and 46% of input. (D4)
4. **"ASR > 50% of AI spend".** Measured 23.7%. (D5)
5. **Cost/latency figures** (21,748 in / 10.7 s / 4.5¢ / 15.4 trips) are all superseded. (D6)
Plus: streaming "code removed" is the primary implementation (D10); 7 prompt files vs 10 (D8);
idempotency "shipped" vs "not built" — both wrong, it shipped default-OFF (D9).

### E. UNKNOWN / NEEDS INSTRUMENTATION
The 14 items in §19. The four that matter most:
- **U1 — how often speaker 0 is actually the doctor.** Unanswerable today because the raw
  index is discarded. This is the single highest-value missing measurement in the system.
- **U4/U5 — suggestion acceptance rate and AI provenance in the signed record.** Nothing
  records whether an AI suggestion survived to the chart.
- **U6 — true production cost.** Blocked by two wrong formulas and $180 of test pollution.
- **U9 — whether the live ASR config is worse at *attribution* than the alternative.**
  Never tested; the clinician confirmation covers a different property.

No unknown above has been filled with an assumption.

---

## 23. Recommended architecture — AFTER the factual audit

Answers grounded in §1–22 only. Each cites the finding that drives it. Nothing here is
implemented; §17's bugs are separable from these and mostly cheaper.

### Q1 — Should Remedisys use an LLM as the core intelligence?

**No — and it already doesn't, which is why it works.** The measured division (§20) is:
LLM owns extraction and proposal; backend rules own vocabulary, duplication,
authorization and persistence. Every place that division is respected has held up. Every
defect in §17 sits where it was violated — dose selection is prompt-only (B4), patient
history has no approval gate (B2), age is a backend bug the LLM was blamed for (B1),
speaker identity is a frontend guess dressed as data (B3).

Keep the LLM as a **transducer at the edges**: unstructured input (speech, documents) →
structured proposal, and clinical reasoning surfaced as text a physician reads. It should
never be the authority on a value that has a canonical source. The tell is B1: the
model's "neonate" was a faithful reading of a corrupted integer. Corrupt the input,
corrupt the output — that is exactly the failure mode of an LLM in a core position.

### Q2 — Should Remedisys use RAG?

**It already does, and the retriever is the right one.** §12 found six mechanisms —
structured tool retrieval, six keyword catalog searches, a watermarked rolling summary, a
cache-or-generate lab reader, and a catalog-derived clinical lexicon. The retriever is
the Frappe ORM and the index is the relational schema. For an EHR that beats vector RAG
on two axes that matter here: every retrieval is permission-checked at the doctype level,
and every value returned is a primary-key-resolvable record rather than a similar-looking
passage. `transcript_digest.py:14-16` already rejected embeddings for a specific clinical
reason — a cosine of 0.98 between "no penicillin allergy" and "penicillin allergy" — and
that reasoning still holds.

**Adding vector RAG now would be solving the wrong problem.** The measured retrieval
failures are not semantic:
- **Retrieval is opt-in.** If the model doesn't call `get_current_transcript`, it reasons
  with no transcript. Nothing forces the call. Fix: make the transcript a mandatory first
  tool result, or inject a bounded structured digest.
- **Tail-only truncation** drops the opening of long consultations (B6). Fix: the rolling
  structured summary already designed in `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` §4 — as a
  fidelity fix, which is how that document correctly reframed it.
- **Eager catalog injection is unbounded** and scales with tenant size, not usage.

Fix those three before considering embeddings. If a semantic layer is ever warranted it
is for Q7's use case, not for patient data.

### Q3 — Should historical encounters be used as RAG?

**They already are — via `get_previous_encounters`, and that channel is well built.** It
is bounded (3 default / 5 max), field-selected, and correctly filtered to `docstatus=1`
so an abandoned draft is never presented as history — a fix whose absence had previously
surfaced five "Open" drafts as clinical record.

**The damage came from the other channel.** §11 traced `equimosis fácil` to
`existing_summary` — always in the prompt, unconditional, head-first-truncated, sitting
one newline from `Chief complaint:` in the same flat block. Not retrieval. Prompt layout.

So the architectural answer is: **keep historical encounters as a bounded, tool-gated,
opt-in retrieval channel; stop pushing prior-visit prose into the always-on context
block.** Three concrete changes follow from §11.3:
1. Move the prior summary **out of the flat context block** into a delimited section, or
   better, behind a tool — so it is retrieved when reasoning needs it, not adjacent to
   the field it keeps contaminating.
2. Replace head-first truncation with **structured fields** (problem list, med list,
   allergies) rather than a prose blob. A structured summary cannot be misread as a chief
   complaint because it has no chief-complaint-shaped slot.
3. Add the **one deterministic guard that does not exist**: compare a proposed
   `add_chief_complaint` / `add_diagnosis` value against the summary text and flag a
   near-match. Three natural-language prohibitions currently do this job; a string
   comparison would do it reliably.

### Q4 — Should historical encounters be used for fine-tuning?

**No. Not now, and the audit shows why concretely.**
- **The labels are wrong.** 22% of transcript segments are `unknown` and the
  doctor:patient ratio is 1.8:1 in a two-party setting (B3). Fine-tuning on that teaches
  the model the current speaker-attribution bug as ground truth.
- **There is no outcome signal.** U4/U5: nothing records whether a suggestion was
  accepted, edited or rejected. Without that there is no target variable — you would be
  fitting to what the model already proposed, not to what physicians accepted.
- **The corpus is small and dev-contaminated.** 302 agent calls, and the same site holds
  ~180 `MagicMock` rows and 65 `model='m'` rows (B10).
- **It would freeze the prompt-layer safety work.** §7.3's paediatric refusals,
  contraindication rules and age gating are actively iterated; weights are not.

Prerequisite order, if it is ever revisited: fix B3 → instrument U4/U5 → accumulate
accepted/rejected pairs at volume → *then* evaluate, and even then prefer few-shot
selection from accepted examples over weight updates.

### Q5 — What should remain structured / tool-based?

Everything currently tool-based, plus the four rows §20 shows are owned by Prompt or
nothing:

| Keep tool-based (working) | Move to tool/structured (currently not) |
|---|---|
| Catalog lookup ×6 (keyword, bounded) | **Dose selection** — a weight+age-banded dosing table, not `:101`'s "standard adult strength" |
| Lab retrieval (`_MAX_LABS=8`) | **Drug interactions** — a real interaction dataset behind a tool, not prompt knowledge |
| Previous encounters (signed-only, field-selected) | **Age** — pass months+DOB+`patient_age` string, never a lossy integer |
| Encounter draft state | **Weight** — read `Vital Signs.weight` and make it a required input to any paediatric dose |
| Vaccine catalog (blocking) | **Patient-history writes** — through the same review pipeline as encounter fields |
| Appointment details | |

The pattern that has worked: **the LLM proposes a name; a Frappe master decides whether
that name is real.** Extend it from names to *quantities*. Strength is the only clinical
value in the system with no canonical source consulted, and it is the highest-risk one.

### Q6 — What should be deterministic backend validation?

§16.2 has five deterministic rules; §16.3 lists nine gaps. In priority order, driven by
severity in §17:

1. **Patient-level writes must pass through physician approval** (B2). This is the only
   Rule 6 violation in the system and it is a frontend change.
2. **Age must be computed correctly and passed with units** (B1). One-line class of fix,
   highest clinical leverage in the audit.
3. **Strength/dose validation** — reject or hard-flag a strength outside an age/weight
   band; reject `0` outright (B5).
4. **Speaker-role plausibility** — persist the raw index (U1), and flag a segment run
   that exceeds a threshold of consecutive same-speaker turns rather than silently
   defaulting to doctor (B3).
5. **Chief-complaint provenance check** against the prior summary (§11.3).
6. **Age-banded vitals thresholds**, backend-owned, surfaced to *both* the UI and the
   LLM — today the thresholds are frontend-cosmetic and the model never sees them (B7).
7. **Cost correctness** — the Anthropic prefix match and the cached-rate discount (B8, B9),
   plus purging test pollution (B10). Not clinical, but every cost decision is currently
   made on wrong numbers.

Design rule that the codebase already follows well and should keep: **fail loudly for
correctness, fail soft for availability.** `_apply_drug_prescriptions` throws on a bad
master; `dosage` demotion to `comment` avoids 400ing a whole autosave; `log_prompt_call`
swallows its own failures. That instinct is right — B16's only flaw is that the soft
failure is *silent*, not that it is soft.

### Q7 — Where should clinical knowledge RAG sit?

**Not in the encounter agent, and not on patient data.** Two reasons from the audit: the
agent path is already 92.93% of all input tokens and re-sends ~11,500 tokens per
round-trip (§15.2), so adding retrieved text multiplies against the round-trip count; and
the general assistant (`narzim-assistant-v1.txt`) already exists as a patient-agnostic
surface with a deliberate architectural guarantee of no patient data.

If clinical-reference retrieval is wanted (formulary, dosing tables, guidelines), it
belongs **behind a curated tool on the general-assistant surface**, and any dosing content
should reach the encounter path as a **deterministic lookup** (Q5/Q6), not as retrieved
prose for the model to interpret. A dosing table consulted by code is a validator; the
same table retrieved into a prompt is a suggestion — and §7.4 shows which way that
resolves under pressure.

### Q8 — Where should patient-specific retrieval sit?

**Exactly where it is: `services/ai_tools.py`, behind typed, permission-checked, bounded
tools.** This is the strongest part of the system and ADR-030's contract is being honoured
— verified by exhaustion, not assertion (zero DB mutations in the tool layer).

Three changes, all inside that boundary:
1. **Make transcript retrieval non-optional** (a turn with no transcript is the precondition
   for reasoning from history instead).
2. **Add a `get_transcript_summary` tool** rather than changing what
   `get_current_transcript` returns — the design already argued this correctly:
   substituting a summary silently is a clinical-behaviour change disguised as an
   optimization.
3. **Persist tool arguments and result shapes** (not content) so §13.1's reconstruction
   gap closes. Today you can prove what the AI proposed and under which instructions, but
   not what it was looking at — which for a clinical decision is the whole question.

### Q9 — Where should the LLM sit?

Four places, and nowhere else:

1. **Speech → structured proposal.** Its genuine comparative advantage.
2. **Clinical reasoning as text the physician reads** — differentials, "worth noting the
   fever 6 days ago". `ask-copilot-v2.txt:108` already draws this line well: history may
   inform the *reply*, never the *draft*. That distinction is the best idea in the prompt.
3. **Repair operations with deterministic verification.** `resegregate_transcript` is the
   model to copy: the LLM re-splits speakers, and a word-multiset check vetoes the entire
   result on >10% divergence. LLM proposes, code verifies, code can veto.
4. **Free-text generation with no clinical authority** — review details, patient summary,
   document narratives.

It should sit **nowhere** in: speaker identity (B3), demographics (B1), dose quantity
(B4), interaction checking, persistence, or authorization.

### Q10 — What is the safest production architecture?

The current one, with the LLM's boundary tightened rather than moved. Concretely:

```
  Speech ──► Deepgram ──► DIARIZATION ──► speaker role
                                          ├─ raw index PERSISTED (U1)          [new]
                                          └─ plausibility check, no ?? doctor  [new]
                                             fallback = "unknown", never "doctor"
     │
     ▼
  TRANSCRIPT ──► rolling structured summary (fidelity, not cost)               [new]
     │            raw segments remain ground truth
     ▼
  AGENT (unchanged shape: bounded, ≤20 iterations, curated registry)
     │  system prompt · tool schemas · context block · tool results
     │  age passed WITH UNITS + months + DOB                                   [fix B1]
     │  transcript retrieval mandatory                                         [new]
     │  prior summary behind a tool, structured, not in the flat block         [fix §11]
     ▼
  TOOLS ── 13 read (bounded, permission-checked)   ← unchanged, this works
        └─ 23 write → ClinicalSuggestion            ← unchanged, this works
     │
     ▼
  DETERMINISTIC VALIDATION GATE                                               [new layer]
     │  dose vs age/weight band · strength ≠ 0 · interaction check
     │  chief-complaint provenance vs prior summary
     │  age-banded vitals, shared by UI and LLM
     ▼
  PHYSICIAN REVIEW ── encounter fields ✅ already
                   └─ patient fields ⚠ MUST join this path                    [fix B2]
     ▼
  SAVE / SIGN ── master re-validation (works) + strength validation           [new]
     ▼
  DATABASE + AUDIT
        AI Prompt Log + tool args/result shapes + accept/reject outcomes      [new]
        correct cost (prefix match + cached rate), test pollution purged      [fix B8-B10]
```

The single most important property to preserve: **the LLM's output is a proposal that a
deterministic layer can reject.** That holds today for names (catalogs), duplicates
(guards), vaccines (blocking match), and transcript words (multiset veto). It does not
hold for quantities, patient-level history, or speaker identity — and those three are
where every clinical defect in §17 landed.

The second most important, and the cheapest: **stop hiding provenance.** Persist the raw
speaker index, tool arguments, and acceptance outcomes. Three of §19's four highest-value
unknowns are unanswerable today not because the system is complex but because it discards
the evidence.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
