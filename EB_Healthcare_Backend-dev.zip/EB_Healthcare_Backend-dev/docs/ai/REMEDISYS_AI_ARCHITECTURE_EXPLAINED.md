# Remedisys AI — Architecture Explained

**Doc status:** living · **Created:** 2026-08-13 by Sarvesh-SocialAngel · **Updated:** 2026-08-13 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Purpose** | Answer one question: *what exactly is Remedisys AI today, how does it work, and what is the role of the LLM?* |
| **Audience** | A technical founder or an engineer joining the project. Readable in ~10 minutes |
| **Date** | 2026-08-13 |
| **Source of truth** | The code, verified against `dev` @ `450aace`, `/Users/apple/Healthcare_next_app`, and live site `marley.local` |
| **Companion** | [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) — the full evidence base. This document explains; that one proves |
| **Not in scope** | No redesign, no proposals, no code changes. §15 lists open questions and deliberately does not answer them |

**Rule used throughout:** where documentation and code disagree, the code wins and the
disagreement is stated explicitly. Anything not verifiable is marked
**UNKNOWN — needs verification**, never guessed.

---

## 1. Executive Summary

### What Remedisys AI is today

**One AI agent, plus eight single-purpose text generators, bolted onto a conventional
Frappe/ERPNext clinical application.**

It listens to a consultation, turns speech into a transcript, and proposes clinical
content — symptoms, diagnoses, prescriptions, lab orders — into an on-screen draft that
the physician edits and signs. It is a *drafting assistant*. The clinical application
underneath works completely without it.

There is exactly **one agent**. "Analyze" and "Ask Narzim AI" look like two products in
the UI; in the code they are the same function with a different sentence typed into it
(§3.3).

### What the LLM does

- Understands Spanish/English speech transcripts
- Extracts clinical facts from conversation ("she's had fever for two days" → a symptom)
- Reasons about the case and writes an explanation the physician reads
- Decides **which tool to call** and **what arguments to pass**
- Proposes values: a drug name, a diagnosis string, a lab test name, a dose

### What the LLM does **not** control

- It cannot reach the database. Not directly, not indirectly. Verified by exhaustion:
  `services/ai_tools.py` contains **zero** `.insert(`, `.save(`, `db_set`, or
  `frappe.db.set_value` calls — the entire tool layer is read-or-propose.
- It cannot see raw SQL, run code, or query a doctype that has no tool for it.
- It cannot decide whether a drug, lab, diagnosis or vaccine **exists** — a Frappe master
  decides that.
- It cannot save anything. Persistence happens only when the physician clicks Save or Sign.
- It never learns. There is no fine-tuning, no memory beyond the last 6 chat turns and a
  stored patient summary.

### What the tools do

36 Python functions in `services/ai_tools.py::TOOL_REGISTRY` (line 1260). **13 read**
real clinical data with hard limits; **23 write** — but "write" is a misnomer: they
validate arguments and return a *suggestion object*. They do not touch the database.

Think of tools as a **menu the LLM may order from, where the kitchen checks every order**.

### What the database does

MariaDB holds the truth: `Patient`, `Patient Encounter`, `Vital Signs`, `Lab Test`,
`Drug Prescription`, plus the master catalogs (`Medication`, `Diagnosis`,
`Lab Test Template`, `Prescription Dosage`, `Prescription Duration`). Every clinical
value the LLM proposes is re-checked against these masters at save time
(`api/v1/encounters/api.py::_apply_drug_prescriptions`, line 487).

### What the frontend does

More than you would expect, and this matters. `Healthcare_next_app` owns:
- Microphone capture and the direct WebSocket to Deepgram (audio never touches our server)
- **Deciding who is the Doctor and who is the Patient** (§4) — this is a frontend
  decision, not an AI one
- The entire draft state. Suggestions live in browser memory until Save
- Applying suggestions to fields, and the ✦ AI badge

### What the doctor controls

- Every encounter-level field: edit, accept, or delete any suggestion before Save
- Signing, which is what makes anything a medical record
- **Everything except five tools.** `add_allergy`, `add_patient_medication`,
  `add_medical_history`, `add_surgical_history` and `set_patient_summary` write to the
  permanent Patient record *immediately*, with no confirmation step
  (`encounter-screen.tsx:3217-3263`). This is the single biggest exception to the model
  above, and §7.3 explains it in full.

### The mental model, with real names

```
Doctor speaks
   ↓  getUserMedia + MediaRecorder                real-provider.ts
Audio (webm/opus, 250 ms chunks)
   ↓  direct WebSocket, bypasses our server
Deepgram nova-3 · language=multi · diarize=true
   ↓  word-level speaker indices (0, 1, 2…)
Speaker role assignment                           real-provider.ts:52-55  ← frontend guess
   ↓  "Doctor:" / "Patient:" / "Unknown:" text
Transcript                                        AI Transcript Segment
   ↓  fetched only if the model calls a tool for it
Agent loop (≤20 round-trips)                      integrations/openai.py:1278
   ↓  system prompt + context + question
LLM  gpt-5-mini                                   OpenAI Chat Completions
   ↕  36 tools                                    services/ai_tools.py
Suggestion objects (no DB writes)
   ↓  fillFormFromSuggestions
Draft in browser memory                           encounter-screen.tsx
   ↓  physician edits / deletes / accepts
Save → save_draft()                               encounters/api.py:1446  ← re-validates
Sign → complete_encounter()                       encounters/api.py:1864  ← docstatus 0→1
   ↓
Frappe / MariaDB — the medical record
```

---

## 2. The Most Important Concept

> **The LLM is the intelligence layer. It is not the source of truth.**

This one sentence explains almost every design decision in the system, and every defect
in it comes from a place where the sentence was violated.

### Six different things people call "the AI"

They are genuinely distinct. Confusing them is how architecture arguments go wrong.

| Layer | What it is | Can it be wrong? | Who catches it |
|---|---|---|---|
| **LLM reasoning** | The model's judgement: "this looks like a UTI, consider a urinalysis" | Yes, freely | The physician reading the reply |
| **Structured patient data** | `Patient.dob`, `Vital Signs.temperature`, `Allergy` rows | Only if the data-entry or a code bug is wrong | Nothing — it is assumed true |
| **Tools** | Typed Python functions that fetch or propose | They enforce limits and permissions | Their own code |
| **Database** | MariaDB + the master catalogs | It *is* the definition of correct | — |
| **Deterministic validation** | Code that rejects a value: does this drug exist? is this dosage a real master value? | It is a rule, so it is right or absent | — |
| **Doctor approval** | The physician clicking Save/Sign | The final authority | — |

### The rule the system follows when it works

> **The LLM proposes a *name*. A database master decides whether that name is *real*.
> The physician decides whether it is *right*.**

Concretely, when a physician says "order a CBC":

1. **LLM reasoning** — decides a lab is warranted and picks the words "CBC"
2. **Tool** — `search_lab_catalog("CBC")` queries `Lab Test Template`
3. **Database** — returns the real entry, e.g. `"Complete Blood Count (CBC)"`
4. **LLM** — calls `add_lab` with the exact catalog name
5. **Deterministic validation** — `_order_already_present()` blocks it if already ordered
6. **Doctor approval** — the physician sees it with a ✦ AI badge and can delete it
7. **Persistence** — only on Save, and `save_draft` re-validates everything again

Seven layers. The LLM occupies exactly one of them, and every value it produced was
checked by something that cannot hallucinate.

### Where the rule is broken

Three places, and all the clinical defects in §9 live in them:

| Broken | What happens instead |
|---|---|
| **Drug strength** | The LLM proposes a number and **nothing checks it.** No master, no range, no age band. `500` and `5000` are equally acceptable to the system |
| **Patient-level history** | The LLM proposes; the frontend writes it to the permanent record with **no approval step** |
| **Speaker identity** | Not decided by the LLM at all — decided by a hardcoded lookup table in the browser (§4) |

**Say it this way to another engineer:** *"The LLM is allowed to be wrong. The system is
designed so that being wrong is caught. Where nothing catches it, that is not an AI
problem — it is a missing validation layer."*

---

## 3. Complete Request Flow

### 3.1 "Analyze" — end to end

The physician finishes the consultation and clicks the **Analyze** pill.

```
1  BROWSER          NarzimAIChatBar.tsx — Analyze pill
                    POST /api/ai/analyze { encounter, transcript }

2  BFF              src/app/api/ai/analyze/route.ts
                    getAccessToken() from the httpOnly cookie, injects the
                    physician's own Bearer JWT. The browser never holds a token.

3  BACKEND ENTRY    api/v1/ai/api.py::analyze_encounter        (line 1201)
                    _require_auth()                            (line 23)
                    _require_encounter_read(encounter)         (line 385)
                         → frappe.has_permission("Patient Encounter","read")

4  CACHE PROBE      analyze_fingerprint(...)                   services/ai.py:315
                    A SHA-256 over: clinical transcript digest, draft state, prompt file
                    hash, model + reasoning effort, language, country, prior summary,
                    newest chat turn. If an identical fingerprint already has a stored
                    result → return it, log status="Cached", zero cost, no LLM call.
                    Controlled by AI Settings.enable_analyze_cache (default OFF; ON live).

5  DELEGATION       result = ask_copilot(encounter, _ANALYZE_PROMPT, ...)   (line 1285)
                    ← THIS IS THE WHOLE OF "ANALYZE". It is ask_copilot with a
                      43-line fixed instruction string (api.py:966-1009) as the question.

6  CONTEXT BUILD    allow_write = has_permission(..., "write")  (line 808)
                         → a read-only user is never offered the 23 write tools
                    ctx = build_encounter_context(encounter, include_catalogs=False)
                                                                services/ai.py:11
                    tools = ai_tools.build_openai_tools(allow_write)   ai_tools.py:1653

7  PROMPT ASSEMBLY  integrations/openai.py:1301-1344
                    system = prompts/ask-copilot-v2.txt (150 lines)
                    user   = "ENCOUNTER CONTEXT:\n<age, allergies, meds, chief complaint,
                              prior summary + warning, language, country, valid dosage
                              and duration values>"
                           + "PRIOR CONVERSATION:\n<last 6 turns>"
                           + "Physician question: <_ANALYZE_PROMPT>"
                    NOTE: the transcript is NOT in the prompt. The model must fetch it.

8  AGENT LOOP       ask_copilot_agent_stream()                 openai.py:1278
                    for _ in range(_MAX_TOOL_ITERATIONS = 20):       (line 1275)
                        POST api.openai.com/v1/chat/completions
                        no tool_calls → reply = content; BREAK
                        tool_calls    → execute each, append results, loop

9  LLM              gpt-5-mini · reasoning_effort=low · max_completion_tokens=3700
                    tools=[36] · tool_choice=auto · timeout 60 s · no retry

10 TOOL EXECUTION   ai_tools.py::execute_tool                  (line 1687)
                    READ  → require_permission → frappe.get_all (bounded) → JSON
                    WRITE → validate → ClinicalSuggestion object   NO DB WRITE

11 RESPONSE         log_prompt_call(...)                       services/ai.py:416
                    _persist_chat_turn(...)                    api.py:1023
                    return { reply, actions[], patient_draft, follow_up }

12 FRONTEND         actions[]       → fillFormFromSuggestions → applySuggestionToEnc
                                    → local draft state, ✦ AI badge, editable
                    patient_draft{} → aiDraft effect → updatePatient.mutate()
                                    ⚠ THIS WRITES TO THE PATIENT RECORD NOW

13 DOCTOR REVIEW    encounter-screen.tsx — edit, accept, delete

14 SAVE             save_draft()                               encounters/api.py:1446
                    → _apply_drug_prescriptions()              (line 487)
                      drug_code, dosage_form, period, strength_uom re-validated

15 SIGN             complete_encounter()                       encounters/api.py:1864
                    chief_complaint required (line 1898) → docstatus 0 → 1
                    Healthcare core on_submit creates lab orders + invoicing
```

Steps 1–11 are the AI. Steps 12–15 are ordinary clinical software, and that is where the
record is actually made.

### 3.2 "Ask Narzim AI" — end to end

Identical, minus two steps.

```
1  BROWSER          NarzimAIChatBar.tsx — physician types a question
2  BFF              src/app/api/ai/encounter-chat/route.ts
3  BACKEND          api/v1/ai/api.py::ask_copilot               (line 751)
   … steps 6-11 are byte-for-byte the same code path …
   Differences:  • no fingerprint cache (step 4)
                 • the user question is the physician's typed text, not _ANALYZE_PROMPT
                 • both turns are persisted (kind="chat"); Analyze stores only the
                   assistant turn, because a button press is not a message
```

### 3.3 Are they two AI systems? **No.**

They are **two user interfaces over one agent.** The proof is a single line:

```python
# api/v1/ai/api.py:1285 — inside analyze_encounter()
result = ask_copilot(encounter, prompt, transcript=transcript,
                     kind="analysis", fingerprint=fingerprint)
```

Everything is shared: model, provider, prompt file, all 36 tools, the 20-iteration cap,
the context builder, the logging, the persistence doctype. The *only* difference is the
user message — a fixed string for Analyze, the physician's typing for chat.

**Practical consequence:** any change to `ask-copilot-v2.txt` or the tool registry
affects both surfaces simultaneously. There is no way to tune one without the other.

---

## 4. Speech / Audio Pipeline

### 4.1 In plain English

The browser records audio and streams it **straight to Deepgram** — it never passes
through the Remedisys server. Deepgram returns text with a number attached to each word
saying which voice said it (0, 1, 2…). The browser then converts those numbers to
"Doctor" and "Patient" using a **fixed lookup table**, and it is this converted text —
never the numbers — that reaches the LLM.

**Deepgram separates voices. It does not identify people.** The mapping from "voice #0"
to "the doctor" is a Remedisys assumption, and it is the weakest link in the pipeline.

### 4.2 The pipeline with real names

```
Microphone            getUserMedia → MediaRecorder("audio/webm;codecs=opus", 250 ms)
                      real-provider.ts
     ↓ direct WSS (token minted by api.py::mint_deepgram_token → deepgram.py:267)
Deepgram              wss://api.deepgram.com/v1/listen
                      model=nova-3 · language=multi · diarize=true
                      interim_results=true · endpointing=800 ms · punctuate · numerals
                      keyterm=<≤50 drug names from the Medication catalog>
     ↓ JSON "Results" messages, word-level speaker indices
Speaker mapping       _groupBySpeaker() + SPEAKER_MAP     real-provider.ts:52-55
     ↓ TranscriptSegment { speaker: "doctor"|"patient"|"unknown", text, confidence }
Storage               POST /api/ai/session/segments → append_segment
                      → AI Transcript Segment  (role only — the raw index is discarded)
     ↓ _buildTranscript()                       real-provider.ts:1013-1020
Text                  "Doctor: …\nPatient: …\nUnknown: …"
     ↓ ONLY if the model calls get_current_transcript, tail-truncated at 6,000 chars
LLM
```

Live configuration read from `marley.local` AI Settings on 2026-08-13:
`nova-3` · `multi` · `diarize=1` · `multichannel=0`.

### 4.3 What each stage actually does

**Deepgram — transcription.** Speech → words. `nova-3` with `language=multi` handles
code-switching between Spanish and English mid-sentence, which is why it was chosen over
the English-only `nova-3-medical`. Drug-name accuracy is recovered by feeding up to 50
generic names from the site's own `Medication` catalog as `keyterm` hints
(`deepgram.py:58-85`).

**Deepgram — diarization.** Voice separation. It clusters the audio by voice and tags each
word with an index. **It assigns indices in order of first appearance.** The first voice
it hears is 0, the second is 1, the third is 2. It has no idea which is the clinician.

**Remedisys — role assignment.** A hardcoded table:

```ts
// real-provider.ts:52-55
const SPEAKER_MAP: Record<number, TranscriptSegment["speaker"]> = { 0: "doctor", 1: "patient" };
private _mapSpeaker(raw: number) { return SPEAKER_MAP[raw] ?? "unknown"; }
```

There is an identical table on the backend for the (currently unused) batch path:
`_SPEAKER_ROLES: dict[int, str] = {0: "doctor", 1: "patient"}` — `integrations/deepgram.py:105`.

### 4.4 Where the mapping fails — four distinct ways

**1. Whoever speaks first becomes the Doctor.** Nothing verifies who voice 0 is. No voice
enrolment, no "the physician started the recording" heuristic, no confirmation prompt. If
a parent or child speaks first — common in paediatrics — **every line is inverted for the
whole consultation**, and the transcript stays internally consistent while being exactly
backwards.

**2. A third speaker becomes `unknown`.** `?? "unknown"` catches index ≥ 2. A paediatric
consultation routinely has three voices: doctor, parent, child. On the live database,
**1,307 of 5,933 segments (22%) are `unknown`.**

**3. Three silent fallbacks default to "doctor."**

| Situation | Code | Result |
|---|---|---|
| A final result arrives with text but no word array | `_groupBySpeaker`: `if (words.length === 0) return [{ …, speaker: "doctor", … }]` | **hardcoded doctor** |
| Interim (in-progress) result | `const speaker = (alt.words?.[0]?.speaker ?? 0)` | `?? 0` → doctor |
| Multichannel message with no channel index | `msg.channel_index?.[0] ?? 0` | `?? 0` → doctor |

None of these logs anything or downgrades confidence. This is the direct cause of
consecutive `Doctor:` bubbles where the speakers actually alternated. The live data shows
the skew: **2,978 doctor vs 1,648 patient segments — 1.8 : 1 in a two-party consultation.**

**4. The raw index is thrown away.** `_persistTranscript()` sends `speaker`, `text`,
timings and confidence — but never `speaker_label`, the field that exists to hold the raw
Deepgram index. On the live database it is **NULL on all 5,933 rows**. So you cannot
retrospectively determine whether a mislabel came from Deepgram's clustering or from
Remedisys's mapping.

### 4.5 Does the LLM receive speaker IDs or role labels?

**Role labels only. Always. Never the raw indices.**

- Live path: `_buildTranscript()` — `real-provider.ts:1018`
- Stored path: `ai_tools.py:171` — `f"{(r.speaker or 'unknown').capitalize()}: {r.text}"`

The LLM receives an **assertion** of who spoke, with no confidence value and no marker
that it might be wrong. It cannot detect an inversion and it is not told one is possible.

### 4.6 Concrete example

The doctor says *"Give paracetamol."* The patient says *"I have fever."*

**What Deepgram returns** (simplified, real message shape):
```json
{ "type": "Results", "is_final": true, "start": 12.4, "duration": 1.8,
  "channel": { "alternatives": [ {
      "transcript": "Give paracetamol I have fever",
      "confidence": 0.94,
      "words": [
        { "word": "give",        "speaker": 0, "confidence": 0.97, "start": 12.4 },
        { "word": "paracetamol", "speaker": 0, "confidence": 0.91 },
        { "word": "i",           "speaker": 1, "confidence": 0.95 },
        { "word": "have",        "speaker": 1, "confidence": 0.96 },
        { "word": "fever",       "speaker": 1, "confidence": 0.93 }
      ] } ] } }
```

Note: Deepgram says **"voice 0"** and **"voice 1"**. It does not say doctor or patient.

**What `_groupBySpeaker` produces** — it walks the word list and cuts a new segment
whenever the speaker index changes:
```
segment 1: speaker index 0 → SPEAKER_MAP[0] = "doctor"  · "Give paracetamol"  · conf 0.94
segment 2: speaker index 1 → SPEAKER_MAP[1] = "patient" · "I have fever"      · conf 0.947
```

**What is stored** (`AI Transcript Segment`) — note what is missing:
```
seq 0 | speaker="doctor"  | text="Give paracetamol" | confidence=0.94  | speaker_label=NULL
seq 1 | speaker="patient" | text="I have fever"     | confidence=0.947 | speaker_label=NULL
```

**What the LLM receives** — one flat string, via the `get_current_transcript` tool:
```
Doctor: Give paracetamol
Patient: I have fever
```

**Now the failure case.** Suppose the patient spoke first — the parent said "Buenos días"
before the doctor's first word. Deepgram assigns the parent index 0. Same audio, same
words, and the LLM receives:
```
Doctor: I have fever
Patient: Give paracetamol
```
The model now believes the *doctor* is reporting fever and the *patient* is prescribing.
Nothing in the system detects this. There is no confidence signal, no plausibility check,
and no record of the original indices to audit against afterwards.

---

## 5. Patient Data Pipeline

For each field: where it comes from, what transformation happens, whether the LLM sees
it, and whether it can write back.

| Data | Source (authoritative) | Transformation | Sent to LLM? | Can the LLM write it? |
|---|---|---|---|---|
| **name** | `Patient.patient_name` | none | **NO — never sent.** Verified: absent from `build_encounter_context` and from every tool result | No |
| **age** | `Patient.dob` | `int(date_diff(now, dob) / 365)` — **integer years, lossy** `services/ai.py:880` | Yes, always — first line of the context block | No |
| **DOB** | `Patient.dob` | — | **NO — never sent** | No |
| **sex** | `Patient.sex` | `[:1].upper()`, fused into the age string → `"5F"`, `"0M"` | Yes, in the same token as age | No |
| **allergies** | `Allergy` child table | names only, joined with commas | Yes, always | **YES — `add_allergy` writes to the Patient record immediately** ⚠ |
| **medications (this visit)** | `Patient Encounter.drug_prescription` | `"drug dosage form"` strings | Yes, always | Proposes; persisted at Save |
| **medications (home)** | `Patient.medication` free text | — | **Resolved into `ctx` but NOT placed in the prompt** — see note below | **YES — `add_patient_medication`** ⚠ |
| **patient summary** | `Patient.patient_details` | truncated to 2,000 chars, **keeping the oldest text** `services/ai.py:105-115` | Yes, always, with a 6-line warning | **YES — `set_patient_summary` OVERWRITES** ⚠ |
| **medical history** | `Patient.medical_history` | — | **In `ctx`, NOT in the prompt** | **YES — `add_medical_history`** ⚠ |
| **surgical history** | `Patient.surgical_history` | — | **In `ctx`, NOT in the prompt** | **YES — `add_surgical_history`** ⚠ |
| **previous encounters** | `Patient Encounter` where `docstatus=1` | date, status, chief complaint, diagnoses, medications, vitals — **signed only** | **Tool only** — `get_previous_encounters`, max 5 / default 3 | No |
| **labs** | `Lab Test` + `Normal Test Result` | last 8 completed, ≤6 result items each | **Tool only** — `get_patient_labs` | Orders new; `get_lab_analysis` writes an AI-summary cache |
| **current encounter draft** | `Patient Encounter` + children | full draft state | **Tool only** — `get_encounter_state` | Proposes; persisted at Save |
| **transcript** | client memory, else `AI Transcript Segment` | **tail-truncated to 6,000 chars** | **Tool only** — `get_current_transcript` | No |
| **vitals** | `Vital Signs` where `docstatus=0` | 8 named fields | **Tool only**, inside `get_encounter_state` | Proposes via `add_vital` (numeric check) |
| **diagnosis** | `Patient Encounter.diagnosis` | list of strings | **Tool only** | Proposes via `add_diagnosis` |
| **orders** | lab / procedure / therapy / rx child tables | lists | **Tool only** | Proposes; duplicate guards apply |
| **chief complaint** | `encounter_comment` JSON | parsed, ≤300 chars | Yes, always | Proposes via `add_chief_complaint` |
| **clinician's own notes** | physician-typed exam/assessment prose | — | **NO — never sent** | No |
| **valid dosages / durations** | `Prescription Dosage`, `Prescription Duration` | full lists | Yes, always, at the end of the context block | No |

### Two things worth knowing

**The patient's name never reaches the LLM.** Only an age+sex token like `"5F"`.
`ask-copilot-v2.txt:111` also tells the model never to repeat identifiers, but that
instruction is belt-and-braces — the name is not in the payload to begin with.

**Three fields are computed and then silently dropped.** `existing_medications`,
`existing_medical_history` and `existing_surgical_history` are built by
`build_encounter_context` (`services/ai.py:92-94`) but **do not appear** in the prompt
assembly (`openai.py:1304-1328`). So the agent is asked to append to the patient's history
without being shown what is already there. The code comment at `services/ai.py:85-91`
describes an intent that the prompt assembly does not implement.

### Which source is authoritative

The **database**, in every case. The LLM never originates a patient fact — it originates
*proposals about* patient facts. The one place this breaks down is age, where the
authoritative source (`Patient.dob`) is correct and the *transformation* corrupts it
before the model ever sees it (§9, Example 1).

---

## 6. The LLM

### 6.1 Configuration (read from the live site, not from docs)

| Property | Value | Where |
|---|---|---|
| **Provider** | OpenAI | `AI Settings.llm_provider` |
| *Code default if unset* | **Anthropic** | `services/llm.py:20-24` — worth knowing: a fresh site runs the untested path |
| **Model — Analyze** | `gpt-5-mini` (API reports `gpt-5-mini-2025-08-07`) | `AI Settings.openai_model` |
| **Model — Ask Narzim AI** | **identical** | same `_get_model()` — `openai.py:552` |
| **Temperature** | `0.4` is passed and then **dropped** — gpt-5 models reject non-default temperature, so `reasoning_effort` is sent instead | `openai.py:708-717` |
| **reasoning_effort** | `low` | `AI Settings.openai_reasoning_effort` |
| **Max output per round-trip** | 3,700 (= 700 + 3,000 hidden-reasoning headroom) | `openai.py:1353`, `:604-608` |
| **Max iterations** | **20** | `openai.py:1275` |
| **Timeout** | 60 s per round-trip | `openai.py:684` |
| **Retry** | **None on the agent path.** A 429/5xx/timeout becomes an apology message + a `Failed` log row | `openai.py:740-760`, `api.py:873` |
| **Context window** | **Not enforced.** No tokenizer in the app, no pre-flight budget check | max observed input: 265,189 tokens |

### 6.2 Instructions — there are three layers, not four

**There is no developer-role message.** People assume one exists because the structure
looks like it. It does not.

```
LAYER 1  SYSTEM   prompts/ask-copilot-v2.txt — 150 lines
                  role, scope, tool-usage rules, paediatric rules,
                  contraindication rules, allergy rules, response style

LAYER 2  TOOL     36 × { name, description, parameters } — sent as a peer of the
         SCHEMAS  system prompt in the API payload, not subordinate to it

LAYER 3  USER     ENCOUNTER CONTEXT block  (age, allergies, meds, chief complaint,
                  prior summary + warning, language, country, valid dosage/duration)
                + PRIOR CONVERSATION (last 6 turns)
                + the question — physician's text, or _ANALYZE_PROMPT

LAYER 4  TOOL     role:"tool" messages appended as the loop runs.
         RESULTS  ← the transcript arrives HERE, not in the prompt
```

`_ANALYZE_PROMPT` sits where a developer prompt would (a 43-line constant at
`api/v1/ai/api.py:966-1009`) but is delivered as the **user** turn. It is Python source,
not a `.txt` file, so it is absent from `prompts/README.md`.

**Two history limits disagree.** `_load_chat_context` fetches 16 turns
(`api.py:949`); the assembly uses the last 6 (`openai.py:1331`). Ten are fetched and
discarded on every call.

### 6.3 Can the LLM write to the database? **No.**

Verified by exhaustion, not by assertion:

```
grep -n "\.insert(\|\.save(\|db_set\|frappe.db.set_value\|\.submit()\|\.delete("
     services/ai_tools.py
→ zero matches
```

The LLM's *only* interface to the system is `execute_tool` (`ai_tools.py:1687`), which
dispatches to a fixed dictionary. An unrecognised tool name returns a structured error
rather than raising, so a hallucinated tool cannot even break the turn.

### 6.4 After the LLM responds

1. `log_prompt_call()` — one `AI Prompt Log` row: model, tokens, cached tokens, cost,
   latency, round-trips, **tool names only** (never arguments, never results)
2. `_persist_chat_turn()` — one or two `AI Encounter Chat Message` rows with the reply and
   the resulting suggestions as `actions_json`
3. Return `{ reply, actions[], patient_draft, follow_up }`
4. Frontend applies `actions[]` to local draft state — nothing persisted
5. Frontend applies `patient_draft{}` **directly to the Patient record** ⚠

### 6.5 The dividing line, stated plainly

| The LLM is allowed to reason/suggest… | …but software controls |
|---|---|
| that a lab is warranted | whether that lab **exists** (`Lab Test Template`) |
| a drug by name | whether the drug resolves to a real `Item` (Save throws if not) |
| a dosing phrase | whether it is a valid `Prescription Dosage` — if not, it is moved to a free-text comment |
| a duration | whether it is a valid `Prescription Duration` |
| a vaccine | **hard block** — no catalog match, no suggestion |
| that a drug should be added | whether it is already on the draft (`_rx_already_present`) |
| a vital reading | whether it parses as a number |
| a re-segregated transcript | whether the words match the original (>10% divergence ⇒ whole result rejected) |
| **a drug strength** | **nothing — this is the gap** |
| **patient allergies/history/summary** | **nothing — written on arrival** |

---

## 7. The 36 Tools

`services/ai_tools.py::TOOL_REGISTRY` (line 1260). Counted programmatically:
**36 total — 13 read, 23 write.**

### 7.1 Read tools (13) — fetch real data, with hard limits

Every one calls `require_permission` first, then a bounded `frappe.get_all`.

| Group | Tools | What they retrieve | Limit |
|---|---|---|---|
| **Clinical history** | `get_patient_labs` | recent completed labs + result values | 8 labs × 6 items |
| | `get_previous_encounters` | prior visits — **signed only** (`docstatus=1`) | 5 max, 3 default |
| **This encounter** | `get_current_transcript` | the consultation transcript | 6,000 chars, **tail kept** |
| | `get_encounter_state` | everything currently on the draft | whole draft |
| | `get_appointment_details` | the booking this encounter came from | one row |
| **Interpretation** | `get_lab_analysis` | AI reading of one named lab | 1 match |
| **Catalogs** | `get_vaccine_catalog` | this facility's immunization schedule | full (small) |
| | `search_medication_catalog`, `search_lab_catalog`, `search_diagnosis_catalog`, `search_procedure_catalog`, `search_therapy_catalog`, `search_complaint_catalog` | real master rows matching a name | **10 each**, `LIKE %query%` |

The `get_previous_encounters` filter is worth calling out: it returns **only signed
encounters**. Before that filter existed, abandoned half-finished drafts were being
presented to the model as settled clinical history.

**One read tool is not read-only in effect.** `get_lab_analysis` (`ai_tools.py:296`) makes
a **second, nested LLM call** on a cache miss and writes `Lab Test.custom_ai_summary`.
Its docstring acknowledges this. The agent turn's logged cost excludes the nested call.

### 7.2 Suggestion / write tools (23) — return objects, not database rows

They validate arguments and return a `ClinicalSuggestion`:

```python
{ "target": "orders.rx",
  "value":  { "kind": "rx", "items": [ { drug_name, dosage, period, strength, … } ] },
  "display": "Paracetamol 500mg",
  "confidence": 0.6,
  "reasoning": ["Added to the draft at the physician's explicit request via chat."],
  "safety": [ … ] }
```

The frontend applies this to browser state. Nothing is written.

| Group | Tools |
|---|---|
| Encounter orders | `add_medication`, `add_lab`, `add_procedure`, `add_therapy`, `add_vaccine` |
| Encounter content | `add_diagnosis`, `add_symptom`, `add_vital`, `add_chief_complaint`, `add_review_details`, `add_follow_up` |
| Removals (7) | `remove_medication`, `remove_lab`, `remove_diagnosis`, `remove_procedure`, `remove_therapy`, `remove_symptom`, `remove_vaccine` |
| **Patient-level (5)** | `add_allergy`, `add_patient_medication`, `add_medical_history`, `add_surgical_history`, `set_patient_summary` |

### 7.3 The distinction that matters most: *suggested* vs *persisted*

**For the 18 encounter-level write tools, the suggestion model holds perfectly.**
A tool returns an object → the frontend puts it in local state with a ✦ AI badge → the
physician can edit or delete it → nothing exists in the database until Save. If the
physician closes the tab, the suggestion evaporates.

**For the 5 patient-level tools, it does not.** They return `patient_draft` instead of
`action`, and the frontend handles that differently:

```tsx
// encounter-screen.tsx:3217-3263 — runs automatically when aiDraft arrives
React.useEffect(() => {
  if (!aiDraft || readOnly || appliedDraftRef.current === aiDraft) return;
  …
  updatePatient.mutate({ id: patient.name, ...updates });   // ← PATCH to the Patient record
}, [aiDraft, readOnly]);
```

The code comment states it outright:

> *"NOTE: patient history persists to the permanent Patient record immediately (unlike
> encounter fields), so this writes the AI-suggested allergies/meds/history to the chart
> on fill; once applied the 'review & add' panel below auto-hides"*

Read that last clause carefully: **the review panel disappears because the write already
happened.** Its "new items" list is empty by construction once the values are on the chart.

So the accurate statement is:

> **18 of 23 write tools are suggestion-only. 5 write directly to the permanent patient
> record with no approval step. 1 read tool writes an AI-summary cache. No tool ever
> writes an encounter-level clinical field.**

The backend honours the contract completely. The exception is entirely in the frontend.

---

## 8. Prescription Flow

### 8.1 The base case — "Give paracetamol."

```
TRANSCRIPT   "Doctor: … le vamos a dar paracetamol …"
   │  reaches the model ONLY if it calls get_current_transcript
   ▼
LLM          ask-copilot-v2.txt:19 instructs: ALWAYS call search_medication_catalog first
   ▼
TOOL 1       search_medication_catalog("paracetamol")
             → Medication rows LIKE %paracetamol%, limit 10
             → e.g. "Tablet Paracetamol 500Milligram"
   ▼
TOOL 2       add_medication(drug_name=…, dosage=…, period=…, strength=…, …)
             _tool_add_medication — ai_tools.py:654
             1. drug_name required
             2. period ∈ ctx.rx_periods  ELSE ""  and the raw text appended to `comment`
             3. dosage ∈ ctx.rx_dosages  ELSE ""  and the raw text appended to `comment`
             4. if strength not already in drug_name → fold it in
             5. _rx_already_present() → refuse if this drug is already on the draft
             6. _allergy_conflict()   → attach a safety warning (does NOT block)
   ▼  NO DATABASE WRITE
DRAFT        orders.rx row in browser state, ✦ AI badge, fully editable
   ▼
DOCTOR       edits / accepts / deletes
   ▼
SAVE         _apply_drug_prescriptions — encounters/api.py:487
             drug_code    REQUIRED, must resolve to a real Item, else THROW
             dosage_form  REQUIRED, must exist in Dosage Form, else THROW
             period       REQUIRED, must exist in Prescription Duration, else THROW
             dosage       if not a master value → moved to comment (not rejected)
             strength_uom must exist in UOM, else THROW
             strength     ***NO VALIDATION OF ANY KIND***
   ▼
SIGN         complete_encounter — chief_complaint required, docstatus 0 → 1
```

**Five prescription fields do not exist anywhere in the AI path:** route, quantity,
refill, PRN, indication. Anything the model says about them survives only as free text in
`comment`, which nothing parses.

### 8.2 Why four similar sentences behave completely differently

#### Case A — Complete: *"Paracetamol 500 mg every 8 hours for 3 days."*

Every field maps to a validated slot.

| Spoken | Argument | Validated against | Outcome |
|---|---|---|---|
| Paracetamol | `drug_name` | `search_medication_catalog` (advisory) | catalog name reused |
| 500 mg | `strength` + `strength_uom` | UOM only — **the number is unchecked** | passes |
| every 8 hours | `dosage` / `interval=8` | `Prescription Dosage` master | valid → structured; invalid → demoted to comment |
| for 3 days | `period` | `Prescription Duration` master | `"3 Day"` is a real row → structured |

**Result:** a complete, structured prescription. This is the case the system handles well —
because every value except the strength number had a master to check it against.

#### Case B — Incomplete: *"Give paracetamol."*

No strength, no dose, no duration. Two paths, and the prompt chooses between them:

```
prompts/ask-copilot-v2.txt:101
"add_medication's dosage/strength fields are optional, but leaving strength unspecified
 … produces a clinically meaningless '0 mg' record. If the physician's instruction
 doesn't include a strength … AND you cannot confidently infer the standard adult
 strength for this drug, ASK for the strength before calling add_medication"
```

The model asks **only if it cannot infer**. For paracetamol — a drug whose adult strength
any model knows — it will infer. **In a paediatric clinic, "the standard adult strength"
is the wrong quantity by definition**, and line 125 of the same prompt says never to state
an adult dose without a weight check. The prompt contradicts itself on the single
highest-risk field.

If it neither infers nor is given a strength, the other branch fires:
`_create_medication_master` derives fields from the drug name alone, and
`parse_medication_fields` (`services/ai.py:769-771`) coerces a missing strength to `0.0`.
Real records from this path are cited in the code: `"N/A Ondansetron 0Milligram"`,
`"N/A PARACETAMOL 0Milligram"`.

**Result:** either an inferred adult strength or a `0 mg` record. Nothing validates either.

#### Case C — Conditional: *"If pain continues, I'll give a laxative."*

**The system has no concept of conditionality.** The suggestion object has no `prn`,
`conditional`, or `status` field. `_tool_add_medication` builds:

```python
item = { "drug_name", "dosage", "interval", "interval_uom", "period",
         "strength", "strength_uom", "comment" }
```

"Give a laxative" and "if pain continues, I'll give a laxative" produce the **identical
row**. The condition survives only if the model volunteers it into `comment` — and
`comment` is free text that nothing reads.

**Result:** a *possible future* treatment can become an *active* prescription. Whether it
does depends entirely on the model's judgement, with no structural check. Section 9,
Example 4 explains why this is the most dangerous of the four.

#### Case D — Diagnosis only: *"You have constipation."*

No medication is mentioned at all. Yet a prescription may still appear, because both
engines explicitly permit it:

```
ask-copilot-v2.txt:45
"Only add what the physician actually asked for, or the standard, clearly-indicated
 item for a diagnosis they state."

suggest-v2.txt:32 §2 RECOMMENDED
"Once a diagnosis or a clear clinical impression is present … you SHOULD also suggest
 the standard-of-care workup and management for THAT diagnosis … This is the primary
 value of this feature."
```

**Result:** "constipation" can produce a laxative suggestion with no drug ever spoken.
This is **intended behaviour**, not a bug — it is the feature's stated purpose. The only
signal distinguishing it from a transcribed instruction is a lower confidence score
(0.35–0.65 vs 0.7–0.95), and that score is display-only.

### 8.3 Why the four cases differ — the underlying reason

| Case | Has a master to validate against? | Has provenance in the transcript? | Outcome |
|---|---|---|---|
| A — Complete | Yes for form/dosage/period; **no for strength** | Yes, fully spoken | Safe apart from the strength |
| B — Incomplete | Same | Drug yes, quantity **no** | Quantity invented or zero |
| C — Conditional | Yes — the drug is real | Yes, but **the condition is unmodelled** | Conditional becomes active |
| D — Diagnosis only | Yes — the drug is real | **No — the drug was never spoken** | Inference by design |

**The pattern:** the system validates *identity* (does this thing exist?) rigorously and
does not model *provenance* (was this actually said?) or *quantity* (is this number safe?)
at all. Cases B, C and D are all failures of provenance or quantity, not of identity.

**Worth knowing:** the correct paediatric answer already exists in the database.
`scripts/seed/seed_treatment_plan_templates.py` seeds six age-banded paediatric
`Treatment Plan Template` records with structured drug rows — the URTI template contains
Paracetamol with `strength: 500`, `dosage: "TID"`, `period: "5 Day"`, and instructions
reading *"10–15 mg/kg/dose every 6–8 hours as needed for fever or pain. Max 5 doses/day.
Use paediatric syrup formulation."* These are reachable from the manual encounter flow
(`encounters/api.py:1317` `search_treatment_plan_templates`, `:1355`
`get_treatment_plan_orders`) — and **they have zero references in the AI path.** No tool
exposes them, no prompt mentions them. Verified by grep across `services/ai_tools.py`,
`services/ai.py` and every `prompts/*.txt`.

---

## 9. Why the Current AI Can Make Clinical Mistakes

Six concrete failure modes, each traced to code. **None of them is the model being
unintelligent.** Every one is a data, mapping or provenance problem.

### Example 1 — Wrong age: a 5-month-old becomes a neonate

**What happens:** the UI shows a 5-month-old patient. The AI reasons about a newborn.

**The code path:**

```python
# services/ai.py:874-890
def _resolve_age(enc, patient) -> str:
    sex_code = (patient.sex or "")[:1].upper()
    if patient.dob:
        age_years = int(date_diff(nowdate(), str(patient.dob)) / 365)   # ← LINE 880
        return f"{age_years}{sex_code}" if sex_code else str(age_years)
    patient_age = getattr(enc, "patient_age", None)     # ← the accurate value, used only
    if patient_age:                                     #    when DOB is MISSING
        return f"{patient_age}{sex_code}".strip()
    return "Unknown"
```

`int(days / 365)` truncates toward zero. Every patient under 12 months becomes `0`. That
string is the **only** age information the model ever receives:
`f"Patient: {ctx.get('age', 'Unknown')}\n"` — `openai.py:1305`.

**Then the prompt completes the error.** `ask-copilot-v2.txt:5` and `:119` both teach:
`Read the patient's age (context "age", e.g. "16G" = 16 years old)`. The model is
explicitly instructed to read the integer as **years**. It receives `0`, applies the
documented convention correctly, and concludes *zero years old* — a neonate.

**Verified on the live database (2026-08-13):**

| Patient | DOB | True age | Sent to the LLM |
|---|---|---|---|
| `MRN-2026-0000003` | 2026-03-03 | **5 months** | **`0G`** |
| `HLC-PAT-2026-00001` | 2025-09-09 | 11 months | `0M` |
| `MRN-2026-0000012` | 2026-07-09 | 1 month | `0M` |

**The model did nothing wrong.** It was handed `0` and told `0` means years. Three
aggravating factors: precision is destroyed before the model sees it (no months, no DOB);
the accurate `patient_age` string exists on the encounter and is deliberately preferred
against; and the entire paediatric safety block (`:118-126` — weight-based dosing,
age-appropriate differentials, adult-protocol refusal) keys off this one corrupted integer.

### Example 2 — Speaker confusion

Covered in detail in §4.4. In short: `SPEAKER_MAP{0:"doctor"}` is a positional assumption
that nothing verifies, plus three code paths that silently default to "doctor". Live data
shows a 1.8:1 doctor:patient skew and 22% `unknown`.

**Why it matters clinically:** the LLM receives asserted role labels with no confidence
value. A full inversion produces a transcript in which the patient prescribes and the
doctor reports symptoms — internally consistent, entirely wrong, and undetectable by the
model. And because the raw index is never stored (`speaker_label` NULL on all 5,933 rows),
it is also undetectable afterwards.

### Example 3 — Medication inference

Covered in §8.2 Case B. `ask-copilot-v2.txt:101` licenses inferring **"the standard adult
strength"** in a clinic whose own prompt declares itself paediatric on line 5 and forbids
adult doses without a weight check on line 125.

**Why nothing catches it:** `_tool_add_medication` passes `strength` through as a string
with no numeric check; `_apply_drug_prescriptions` validates `strength_uom` against the
`UOM` master but never the number; there is no weight lookup, no mg/kg calculation, and no
age band anywhere in the AI path. A weight *is* available in `Vital Signs.weight` and is
never read for this purpose.

### Example 4 — Conditional medication

*"If symptoms continue, I'll give a laxative."*

**Why this must not become a prescription:** it is a statement of *intent under a future
condition*, not an order. If it becomes an active prescription, the patient is dispensed a
drug the physician deliberately deferred, the pharmacy sees no condition, and the signed
record misrepresents the clinical decision.

**Why the system cannot currently prevent it:** conditionality is not modelled anywhere.
The suggestion object has no field for it (§8.2 Case C). Both "give a laxative" and "if
pain continues, I'll give a laxative" produce byte-identical rows. The only thing standing
between the two is the model's own reading of the sentence — no schema, no validator, no
flag. The physician might catch it in review, but the draft gives them no signal that the
item was conditional.

### Example 5 — Previous encounter contamination

**What happened (real, 2026-07-29):** a prior visit's summary read *"queja principal de
equimosis fácil"* (chief complaint of easy bruising). On a **fever/headache** visit, the
agent adopted it as *today's* chief complaint and drafted "Bruising easily", the diagnosis
`Unexplained bruising (R23.3)`, and PT/INR + aPTT + CBC — none of it discussed that day.

**How the context allowed it.** Not retrieval — `get_previous_encounters` was never
called. It was **prompt layout**:

```python
# integrations/openai.py:1304-1323 — four consecutive f-string lines
f"Chief complaint: {ctx.get('chief_complaint') or 'Not recorded'}\n"
f"PATIENT SUMMARY FROM PREVIOUS VISITS — BACKGROUND HISTORY ONLY, NOT this visit's "
f"presentation. …: {ctx.get('existing_summary') or 'None on record'}\n"
```

Four steps:
1. The prior summary is **always** in the prompt — no tool call needed, no opt-in.
2. It sits in the **same flat block** as `Chief complaint:`, one newline away, with no
   structural separator or section header.
3. On a fresh encounter `Chief complaint:` is **empty**, while `_ANALYZE_PROMPT` says
   "complete the clinical draft" and "add every clinically appropriate item".
4. The nearest chief-complaint-shaped string is one line below the empty field — and it is
   literally labelled *queja principal* ("chief complaint") in its own text.

Made worse by truncation: `_truncate_patient_summary` keeps the **first** 2,000 characters
(`services/ai.py:105-115`), so the oldest — most likely stale — content is exactly what
survives.

**What changed since:** three overlapping natural-language prohibitions were added
(the emphatic in-context label above, `_ANALYZE_PROMPT`'s "EVERYTHING you add must come
from TODAY'S transcript", and `ask-copilot-v2.txt:107` which quotes this very incident
verbatim inside the prompt). The layout flaw is unchanged, and **there is no deterministic
guard** — nothing compares a proposed chief complaint against the summary text.

### Example 6 — Unsupported patient history

**What happens:** the chart gains "Paracetamol taken at home" when the transcript never
established it.

**How provenance gets lost, in three steps:**

1. **The prompt names the example.** `_ANALYZE_PROMPT` (`api.py:993-997`) instructs the
   model to capture *"a medication the patient already takes or reports having taken at
   home/OTC before this visit, **e.g. Tylenol/paracetamol/any over-the-counter remedy**"*.
   Paracetamol is the worked example in the instruction — the most primed token available
   when the model is looking for a home medication.
2. **The tool carries no evidence.** `_tool_add_patient_medication` (`ai_tools.py:1070`)
   accepts one argument, a name, and returns `{"patient_draft": {"medications": [name]}}`.
   There is no `evidence`, `quote`, or `transcript_offset` parameter. **The tool schema
   makes it structurally impossible to record why the model believed this.**
3. **The frontend writes it immediately.** `encounter-screen.tsx:3217-3263` appends it to
   `Patient.medication` via `updatePatient.mutate(...)` with no review step, and the
   review panel then hides itself because the item is no longer "new".

**Result:** an unsupported clinical fact enters the permanent record, and nothing anywhere
records the transcript line it supposedly came from — because no field exists to hold it.
The same three steps apply to `add_allergy`, which is worse: a fabricated allergy can
suppress a correct future prescription.

---

## 10. Current Retrieval

### 10.1 The direct answers

| Question | Answer | Evidence |
|---|---|---|
| Does Remedisys use vector RAG? | **No** | grep for `vector_store`, `faiss`, `pinecone`, `chroma` → zero |
| Does it use embeddings? | **No** | grep `embedding` → one file, `transcript_digest.py`, and only in a comment explaining why they were rejected |
| Does it use pgvector? | **No** — and the database is MariaDB, not Postgres | ADR-006 |
| Does it use structured retrieval? | **Yes, extensively** | 13 read tools + 6 catalog searches |
| Which tools retrieve previous encounters? | `get_previous_encounters` | `ai_tools.py:74`, signed only, max 5 |
| Which tools retrieve labs? | `get_patient_labs` (list) and `get_lab_analysis` (one interpretation) | `ai_tools.py:39`, `:296` |
| Which tools retrieve medications? | `search_medication_catalog` (catalog) and `get_encounter_state` (this visit's) | `ai_tools.py:405`, `:216` |

The one `embedding` hit, in full:

```python
# services/transcript_digest.py:14-16
# No LLM call, no embeddings, no network. That is a deliberate choice over semantic
# similarity: a cosine of 0.98 can sit between "no penicillin allergy" and
# "penicillin allergy", and an embedding call to avoid an LLM call is still a model call.
```

### 10.2 The accurate statement

> **Remedisys already has retrieval, but it is structured/tool-based retrieval rather
> than semantic vector RAG.** Confirmed by code.

Six distinct mechanisms exist:

| # | Mechanism | Retrieved how |
|---|---|---|
| 1 | Tool retrieval | Model chooses a tool; Frappe ORM query with hard limits |
| 2 | Keyword catalog search ×6 | `LIKE %query%`, `disabled=0`, limit 10 |
| 3 | Eager catalog injection | All 6 catalogs (~457 rows) inlined into `suggest-v2`/`soap-v1` — **unbounded** |
| 4 | Rolling patient summary | `Patient.patient_details`, first 2,000 chars, always in the prompt |
| 5 | Cache-or-generate lab reading | stored `custom_ai_summary`, else generate now |
| 6 | Deterministic clinical lexicon | `transcript_digest.py` derives a tenant-specific vocabulary **from the site's own six masters** to score whether a transcript change is clinically material |

Mechanism 6 is worth noticing: it is keyword relevance-scoring over domain vocabulary,
built deliberately without any model.

### 10.3 Why the distinction matters

Do not confuse these four things — they are separate decisions:

| Term | What it means here | Present? |
|---|---|---|
| **Prompting** | Instructions in `ask-copilot-v2.txt` | Yes — 150 lines |
| **Tool calling** | The model requests a typed function; code executes it | Yes — 36 tools |
| **Structured retrieval** | Fetching records by key/filter from a relational schema | Yes — that is what the tools do |
| **Semantic / vector RAG** | Embedding text, similarity search, injecting passages | **No** |
| **Fine-tuning** | Changing model weights | **No** |

"We have RAG" and "we have vector search" are different claims. The first is true here;
the second is not.

---

## 11. What Is NOT Currently in the System

Each item verified by search, not assumed.

| Capability | Present? | Verification |
|---|---|---|
| Vector RAG | **No** | no vector store, index, or similarity search |
| pgvector | **No** | database is MariaDB (ADR-006) |
| Embeddings | **No** | one `embedding` hit, a comment rejecting them |
| Fine-tuning | **No** | grep `fine_tune`, `finetune`, `training_data` → **0 files** |
| Custom medical model | **No** | `gpt-5-mini` / `claude-sonnet-4-6` — stock models via `AI Settings` |
| SpeechBrain | **No** | grep `speechbrain` → **0 files** |
| Speaker verification / voice enrolment | **No** | grep `pyannote`, `speaker_verification`, `voiceprint`, `enroll` → **0 files each**. Speaker roles come from `SPEAKER_MAP{0:"doctor",1:"patient"}` |
| Medical knowledge RAG | **No** | no knowledge corpus, no retriever over reference material |
| Clinical guideline RAG | **No** | `guideline` appears in 2 files, both as prose in prompts/comments — no guideline data or retriever |
| Drug interaction engine | **No** | `interaction` appears in 7 files: 3 prompt files (as instructions to the model), 2 test files, `ai_settings.json` (a field *description*), 1 archived prompt log. **No interaction dataset and no checking code** |
| Paediatric dose engine | **No engine — but the data partly exists.** `seed_treatment_plan_templates.py` holds 6 age-banded paediatric templates with real mg/kg instructions, reachable from the **manual** flow only (`encounters/api.py:1317`, `:1355`). **Zero references in the AI path** | verified by grep across `ai_tools.py`, `ai.py`, `prompts/*.txt` |
| Deterministic contraindication engine | **No** | `contraindicat` appears in 3 files, **all prompt text** (`ask-copilot-v2.txt:124,128`, `soap-v1.txt:94`, `suggest-v2.txt:121`). The rules exist as English instructions to the model, not as code |
| Allergy checking | **Partial** | `_allergy_conflict` (`ai_tools.py:374`) — string similarity + shared ≥5-char prefix. Its own docstring: *"NOT a clinical authority (no real cross-reactivity database)"*. **Advisory — never blocks** |

**The pattern:** contraindications, interactions, age-appropriateness and weight-based
dosing all exist in the system **as prompt instructions**, and none exists as code. The
safety prompt (`ask-copilot-v2.txt:118-143`) is genuinely careful and well written — but
it is guidance to a model, not a control.

Also confirmed inactive: `AI Settings.enable_safety_validators` is `0` on the live site,
**and no code reads that flag** in `api/v1/ai/api.py` or `services/ai_tools.py`. It gates
nothing today.

---

## 12. Where the LLM Fits

Your table, corrected against the code.

| Responsibility | Current owner | Correction / evidence |
|---|---|---|
| Speech recognition | **Deepgram** | ✅ `nova-3`, `language=multi` |
| Speaker diarization | **Deepgram** | ✅ `diarize=true` — separates *voices*, does not identify *people* |
| Speaker role assignment | **Remedisys — specifically the browser** | ⚠️ Not the backend and not the LLM. `real-provider.ts:52-55`, a hardcoded lookup with three silent doctor-defaults |
| Natural language understanding | **LLM** | ✅ |
| Clinical reasoning | **LLM** | ✅ — bounded by 20 iterations and a fixed tool set |
| Patient facts | **Database, via tools** | ✅ — **except age**, which a backend bug corrupts before the LLM sees it (`services/ai.py:880`) |
| Historical data retrieval | **Tools** | ✅ `get_previous_encounters`, signed-only — **but the prior *summary* bypasses tools entirely and is always in the prompt** |
| Medication catalog | **Database, via tools** | ✅ `search_medication_catalog` — advisory, non-blocking |
| Prescription suggestion | **LLM + tools** | ✅ |
| Prescription validation | **Backend** | ⚠️ **Partial.** Identity is validated hard (drug_code, dosage_form, period, UOM — all throw). **Strength is not validated at all** |
| Persistence | **Backend** | ⚠️ **For encounter fields, yes.** For 5 patient-level tools the **frontend** persists directly |
| Final approval | **Doctor** | ⚠️ **For encounter fields, yes.** For patient-level fields, **nobody** |

**Rows worth adding, because they are load-bearing and absent from the original table:**

| Responsibility | Current owner |
|---|---|
| Duplicate order/prescription detection | **Backend rule** — `_rx_already_present`, `_order_already_present` (blocking, and good) |
| Vaccine grounding | **Backend rule** — the only *blocking* catalog check |
| Transcript anti-hallucination on re-segregation | **Backend rule** — word-multiset veto, >10% divergence rejects the whole result |
| Dose/strength selection | **LLM, licensed by prompt, validated by nothing** |
| Drug interactions / contraindications / age-appropriateness | **Prompt only** |
| Vitals abnormal flagging | **Frontend** — adult thresholds, cosmetic, and **the LLM never sees them** |
| Analyze result reuse | **Backend rule** — deterministic fingerprint, no LLM |

---

## 13. What Should Be AI vs Software

**This section describes the boundary the code already implements, and marks where
current behaviour departs from it. It is not a redesign.**

### The boundary the system was built around

| The LLM handles | Software / tools handle |
|---|---|
| Language understanding | Authoritative patient data |
| Extracting clinical information from speech | Permissions |
| Reasoning over the encounter | Database access |
| Generating draft suggestions | Catalog lookup |
| Asking the clinician for missing information | Deterministic validation |
| Summarization | Persistence, audit trail, Save/Sign |

### Where CURRENT behaviour matches it ✅

- **Database access** — the LLM has no path to the database except 36 named functions.
  Verified by exhaustion (zero mutation calls in `ai_tools.py`).
- **Permissions** — `_require_encounter_read` on every call; write tools withheld entirely
  from read-only callers (`api.py:808`).
- **Catalog lookup** — six search tools plus a blocking vaccine match.
- **Persistence** — encounter fields persist only through `save_draft`, which re-validates.
- **Audit trail** — every LLM call produces an `AI Prompt Log` row.
- **Asking for missing information** — `ask-copilot-v2.txt:101` does instruct the model to
  ask for a strength rather than guess… but only conditionally (§13, next section).
- **Deterministic validation where a master exists** — drug identity, dosage form,
  duration, UOM, vaccine, duplicates, vital numerics, transcript word-preservation.

### Where CURRENT behaviour departs from it ⚠️

Stated as observation, not recommendation:

| Boundary | Current departure |
|---|---|
| *Software handles authoritative patient data* | The LLM **authors and overwrites** `Patient.patient_details` via `set_patient_summary` |
| *Software handles persistence* | The **frontend** persists 5 patient-level tools directly, skipping Save/Sign |
| *Software handles deterministic validation* | Dose, interactions, contraindications and age-appropriateness are **prompt-layer only** |
| *The LLM asks for missing information* | It asks **only if it cannot infer** the adult strength — inference is the default path |
| *The LLM handles language understanding* | It does — but **speaker role assignment**, arguably a language/audio task, is a hardcoded frontend table |
| *Software handles the audit trail* | Tool **names** are logged; **arguments and results are not**, so an AI decision cannot be reconstructed |

**The honest summary:** the architecture is sound and mostly implemented. Every departure
above is a place where a boundary was crossed for convenience — a frontend write that
avoided a review UI, a prompt instruction that avoided building a dose table, a log field
that avoided a PHI question.

---

## 14. Current Production Readiness

Honest assessment, colour-coded. No numeric scores.

### 🟢 GREEN — solid, production-grade

| Area | Why |
|---|---|
| **Tool-layer isolation** | Zero DB mutations in `ai_tools.py`, verified exhaustively. ADR-030's contract is genuinely honoured |
| **Authorization** | `_require_auth` + `_require_encounter_read` on every call; per-tool `require_permission`; write tools withheld from read-only callers |
| **Read bounding (Rule 5)** | Every read tool has a hard limit in code, not in a prompt |
| **Encounter-level Rule 6** | 18 of 23 write tools are genuinely suggestion-only; nothing persists before Save |
| **Save-time validation of identity** | `_apply_drug_prescriptions` throws on any unresolvable master |
| **Duplicate guards** | `_rx_already_present` survives re-wording across Analyze runs — a real, well-built deterministic control |
| **Vaccine blocking** | The one catalog check that refuses rather than warns, for a well-reasoned clinical cause |
| **Transcript anti-hallucination** | Word-multiset veto on re-segregation is a genuine guarantee, not a mitigation |
| **Rule 7 (AI failure is non-blocking)** | Provider failures degrade to an apology + a logged row; the encounter form keeps working |
| **PHI discipline in logs** | No transcript, prompt, or reply text in `AI Prompt Log` |
| **Cost/latency instrumentation** | Tokens, cached tokens, reasoning tokens, round-trips, and a 5-way latency span breakdown |
| **Analyze idempotency** | A deterministic fingerprint over every load-bearing input — well designed, correctly excludes physician prose |

### 🟡 YELLOW — works, needs work

| Area | Issue |
|---|---|
| **Transcript fidelity** | Tail-truncation at 6,000 chars drops the opening of long consultations. The code *does* log it and flags `truncated:true` to the model — visible, not fixed |
| **Retrieval is opt-in** | If the model never calls `get_current_transcript`, it reasons with no transcript. Nothing forces the call |
| **Cost accuracy** | Two independent errors: Anthropic's Sonnet-rate fallback (8.05× overstatement, arithmetically confirmed) and OpenAI's failure to apply the cached rate to the 46% of input that is cached |
| **Log hygiene** | ~180 unit-test `MagicMock` rows with fabricated $1–2 costs are in the live `AI Prompt Log`, exceeding all real spend |
| **`prompt_hash` coverage** | NULL on 239 of 329 agent rows (73%). `ask-copilot-v2.txt` grew from 22,916 to 30,506 bytes under the same filename |
| **Prompt efficiency** | `ask-copilot-v2.txt:96` still instructs one tool call per item; the loop already supports parallel calls |
| **History window** | 16 turns fetched, 6 used |
| **Dead code / config** | `AI Usage Counter` + `AI Subscription Plan`×3 have no writer; `AI Prompt Template` is seeded and never read; `narzim-assistant-phi-check-v1.txt` is 0 bytes with an orphaned caller; `enable_safety_validators` gates nothing |
| **Documentation** | `CLAUDE.md` describes AI as unbuilt and forbidden before Phase 5, and lists 5 doctypes where 18 exist |

### 🔴 RED — safety or architecture concerns

| Area | Concern |
|---|---|
| **Age corruption** | `int(days/365)` sends `0` for every infant, and the prompt teaches that the integer means years. The entire paediatric safety block reasons off this value. Reproduced on 6 live patients |
| **Patient-record writes without approval** | 5 tools reach the permanent `Patient` record via `updatePatient.mutate()`, before Save, before Sign, with the review panel auto-hiding afterwards. This is the one place Rule 6 is broken |
| **Unvalidated drug strength** | The only clinical quantity in the system with no canonical source consulted, in a paediatric practice, with a prompt that licenses inferring the **adult** value |
| **Speaker role assignment** | A positional assumption with three silent doctor-defaults, no confidence signal to the LLM, and the raw index discarded so it cannot be audited |
| **Conditional treatment unmodelled** | "If pain continues, I'll give X" and "give X" produce identical rows |
| **No provenance on suggestions** | The tool schemas have no evidence/quote field, so an unsupported clinical claim cannot be traced to a transcript line — by construction, not by omission |
| **Safety rules are prompt-only** | Contraindications, interactions, age-appropriateness and weight-based dosing exist as English instructions, not code |

### Missing (not yet built, not necessarily wrong)

- Any record of whether a suggestion was **accepted, edited or rejected**
- Tool arguments and results in the audit trail — so *why* the AI proposed something cannot be reconstructed
- Age-banded vitals thresholds (current ones are adult, frontend-only, and invisible to the LLM)
- Any link between the seeded paediatric `Treatment Plan Template` dosing data and the AI path

---

## 15. Questions We Need to Answer Next

**Deliberately unanswered.** The purpose of this document is a shared factual baseline
before any architectural decision. Each question is listed with the findings that bear on
it, so the discussion starts from evidence rather than preference.

1. **Should we add medical knowledge RAG?**
   *Bears on it:* no knowledge corpus exists today; contraindication and interaction rules
   currently live as prompt text; the agent path is already 92.93% of all input tokens and
   re-sends ~11,500 tokens per round-trip.

2. **Should historical encounters be used as RAG?**
   *Bears on it:* `get_previous_encounters` already retrieves them, bounded and
   signed-only. The `equimosis` defect came from the *always-on prior summary*, not from
   that tool.

3. **Should historical encounters be used for fine-tuning?**
   *Bears on it:* 22% of transcript segments are labelled `unknown` and the
   doctor:patient ratio is 1.8:1; no acceptance/rejection outcome is recorded anywhere;
   the corpus is 302 agent calls on a site containing test pollution.

4. **Should we build speaker verification?**
   *Bears on it:* role assignment is `SPEAKER_MAP{0:"doctor"}` with three silent
   doctor-defaults; the raw Deepgram index is discarded, so **we cannot currently measure
   how often the mapping is wrong**.

5. **Should we build deterministic medication safety?**
   *Bears on it:* strength has no validation anywhere; six age-banded paediatric
   `Treatment Plan Template` records with real mg/kg data already exist in the database
   and have zero references in the AI path; `Vital Signs.weight` is available and unread.

6. **Should we improve Deepgram diarization?**
   *Bears on it:* the live config is `nova-3` + `multi`; `utterances` is not sent on the
   streaming path; grouping is per-message with no cross-message reconciliation.
   **UNKNOWN — needs verification:** whether the observed mislabelling originates in
   Deepgram's clustering or in the Remedisys mapping. The data needed to tell them apart
   (`speaker_label`) is not being stored.

7. **Which parts should remain tool-based?**
   *Bears on it:* the tool layer is the strongest part of the system — bounded,
   permission-checked, and verified free of DB mutations.

8. **Which parts should remain LLM-based?**
   *Bears on it:* §12 shows the LLM currently owns extraction, reasoning and proposal —
   and that every clinical defect in §9 sits where an LLM output had no deterministic
   layer beneath it.

---

## 16. One-Page Mental Model

```
                          REMEDISYS AI

  Doctor / Patient
        │   speech in a consultation room, Spanish and/or English
        ▼
  Audio                          getUserMedia → MediaRecorder(webm/opus, 250 ms)
        │                        real-provider.ts · streams DIRECT to Deepgram
        │                        (audio never touches the Remedisys server)
        ▼
  Deepgram                       nova-3 · language=multi · diarize=true
        │                        endpointing 800 ms · ≤50 drug keyterms
        │   returns words + a VOICE INDEX (0,1,2…) assigned by order of
        │   first appearance — it separates voices, it does not identify people
        ▼
  Transcript + Speaker Info      _groupBySpeaker() + SPEAKER_MAP{0:"doctor",1:"patient"}
        │                        ⚠ positional guess · index≥2 → "unknown"
        │                        ⚠ 3 silent fallbacks to "doctor"
        │                        ⚠ raw index discarded (speaker_label NULL, 5,933 rows)
        │   stored as AI Transcript Segment; flattened to "Doctor: …\nPatient: …"
        ▼
  Remedisys AI Agent             api/v1/ai/api.py::ask_copilot
        │                        (analyze_encounter calls this — ONE agent, two UIs)
        │   auth + per-encounter permission + allow_write gate
        │   builds: system prompt · encounter context · last 6 turns · the question
        │   ⚠ the transcript is NOT in the prompt — it must be fetched by a tool
        ▼
  LLM                            gpt-5-mini · reasoning_effort=low
        │                        ≤20 round-trips · 3,700 output tokens each
        │                        whole message list re-sent every trip (87–96% cached)
        ▲                        no retry · no memory beyond the stored chat
        │
        ▼   ▲
  36 Tools                       services/ai_tools.py::TOOL_REGISTRY
        │   │                    13 READ  → permission-checked, hard-limited Frappe reads
        │   │                    23 WRITE → return objects · ZERO DB writes, verified
        │   │                    guards: duplicates (block) · vaccine catalog (block)
        │   │                            allergy similarity (warn only)
        ▼
  Clinical Draft / Suggestions   fillFormFromSuggestions → applySuggestionToEnc
        │                        browser memory only · ✦ AI badge · fully editable
        │                        ⚠ EXCEPT patient_draft → updatePatient.mutate()
        │                          → 5 tools write to the Patient record RIGHT HERE
        ▼
  Doctor Review                  encounter-screen.tsx — edit / accept / delete
        │                        the only clinical authority in the system
        ▼
  Save / Sign                    save_draft()        → re-validates every field vs masters
        │                        complete_encounter() → chief_complaint required
        │                                               docstatus 0 → 1
        ▼
  Frappe / Patient Record        MariaDB — ERPNext Healthcare doctypes
                                 + AI Prompt Log · AI Encounter Chat Message
                                 + AI Transcript Segment · AI Encounter Record
```

### What each arrow actually does

| Arrow | What happens | Trust boundary |
|---|---|---|
| Doctor → Audio | Browser captures the mic; consent gate on `AI Encounter Session` | — |
| Audio → Deepgram | Direct WSS with a short-lived scoped token; **no server hop** | Audio leaves our control |
| Deepgram → Transcript | Words + voice indices + per-word confidence | **Deepgram decides voices, not roles** |
| Transcript → Agent | Index→role mapping, flattened to labelled text, stored | ⚠️ **The weakest link.** A guess presented to the LLM as fact |
| Agent → LLM | System prompt + context + question. Transcript fetched separately | Age arrives already corrupted here |
| LLM ↔ Tools | Model requests; code executes; results fed back | ✅ **The strongest boundary.** No path to the DB exists |
| Tools → Draft | Suggestion objects applied to browser state | ✅ Nothing persisted… |
| Tools → Patient record | `patient_draft` written immediately | ⚠️ …**except here** |
| Draft → Doctor | Rendered with a ✦ AI badge, editable | ✅ Rule 6 for encounter fields |
| Doctor → Save | `save_draft` re-validates identity against masters | ✅ Strong — **but strength is unchecked** |
| Save → Sign | `complete_encounter`, chief complaint required, docstatus 0→1 | ✅ This is what makes it a medical record |

---

## Appendix — where to look in the code

| Question | File |
|---|---|
| What are the entry points? | `api/v1/ai/api.py` (1,778 lines) |
| What can the LLM do? | `services/ai_tools.py::TOOL_REGISTRY` (line 1260) |
| How does the agent loop work? | `integrations/openai.py:1278-1439` |
| What is the LLM told? | `prompts/ask-copilot-v2.txt` + `api.py:966-1009` |
| What patient data is sent? | `services/ai.py::build_encounter_context` (line 11) |
| Where is the age bug? | `services/ai.py:880` |
| How are speakers assigned? | `real-provider.ts:52-55` and `_groupBySpeaker` |
| Where do patient-level writes happen? | `encounter-screen.tsx:3217-3263` |
| What is validated at Save? | `api/v1/encounters/api.py::_apply_drug_prescriptions` (line 487) |
| What is logged? | `services/ai.py::log_prompt_call` (line 416) |
| Full evidence for every claim here | [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
