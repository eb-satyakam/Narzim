# Lab extraction — where the time and the money actually go

**Doc status:** record · **Created:** 2026-09-22 by Divyanshu (AI-assisted) · **Updated:** 2026-09-22 by Divyanshu (AI-assisted) · **Version:** 1.0

> A dated measurement, not a plan that stays current. The numbers below were taken on
> 2026-09-22 against `remedisis.localhost`, on `feature/lab-two-stage-extraction`, with
> OpenAI `gpt-5-mini` and prompt `multi_panel_extraction_v15`. Re-measure before relying on
> them — the pipeline changed twice on the day they were taken.

---

## 1. Why this exists

An uploaded report takes tens of seconds to come back. Before changing anything, the
question is which part of that is slow. This records the measurement and what follows from
it, so the optimisation work is aimed rather than guessed.

**USER STORY.** A nurse uploads a patient's outside report at the front desk and waits with
the patient in front of her → **the system shows** a spinner for the better part of a minute
→ **the database actually contains** an `AI Prompt Log` row whose `latency_ms` is anywhere
between 10,000 and 54,000 → **consequence:** on a busy morning she stops waiting for it, and
either re-uploads (doubling the cost) or walks away and the result is reviewed by nobody.

## 2. What was measured

Ten successful multi-panel extractions, read straight from `AI Prompt Log`. Every figure
below is a stored field, not an estimate.

| `tokens_out` | `latency_ms` | `tokens_in` | `cost_estimate_usd` |
|---|---|---|---|
| 1,060 | 10,306 | 8,723 | 0.042 |
| 2,812 | 27,869 | 9,338 | 0.070 |
| 3,049 | 29,671 | 9,338 | 0.074 |
| 3,281 | 33,986 | 12,018 | 0.085 |
| 3,459 | 46,262 | 11,846 | 0.087 |
| 3,636 | 37,791 | 11,846 | 0.090 |
| 4,029 | 40,855 | 9,338 | 0.088 |
| 4,132 | 43,248 | 11,846 | 0.098 |
| 4,832 | 51,497 | 12,300 | 0.109 |
| 5,602 | 53,568 | 12,018 | 0.120 |

## 3. The finding

**Latency tracks output tokens almost linearly — roughly 10 ms per output token. Input size
makes no visible difference.** Input ranged 8,723-12,300 tokens across the same set and the
fastest run had nearly the same input as the slowest.

Two things follow, and they are not intuitive:

- **Sending the rendered page image is close to free in time.** Page rendering (ADR-080) adds
  a ~885 KB PNG to the request. It is input, and input is not the bottleneck.
- **The only lever that moves the clock is writing less.** The model spends the time typing
  the transcription. Anything that shortens what it must produce is a direct time saving;
  anything that shortens what it must read is not.

**EXAMPLE.** The OCT transcription prints the scan parameters twice — once as a table under
`## Scan Parameters` and again as a plain line near the end (`Scan Angle: 0° Spacing: 0.3 mm
Length: 9 mm`). At ~10 ms per token that duplication is paid on every upload of that report
type, forever, until the template is edited.

## 4. What is NOT known, and why

**The selection call (ADR-080 Stage 1) is not written to `AI Prompt Log` at all.** It was
added without a log row, which breaks the §9 rule that every LLM call is logged with
prompt version, model, tokens, cost and latency.

So every number in §2 is the **extraction call only**. A report now costs two calls, and
half of the wall-clock time is unmeasured. Fixing the logging is therefore not a tidiness
task — it is the precondition for trusting any before/after comparison.

`cached_tokens` is **0** on every row. Prompt caching is not in effect for either call.

## 5. What to do, in order

| # | Change | Expected effect | Where it lives |
|---|---|---|---|
| 1 | **Log the selection call** to `AI Prompt Log` | No speed change. Makes the other two measurable, and closes a §9 gap | `services/lab_panel_extraction.py` |
| 2 | **Skip the selection call when the report type is already known** — try the deterministic matcher (`services/narzim_template_suggest.py`, no model call) first, fall back to the model only when it is not confident | Removes one of two calls on the common path, once the library has the report type. Also the cost halves | `services/lab_panel_extraction.py` |
| 3 | **Trim repetition out of the report templates** | Direct: every token not written is ~10 ms not spent | `AI Chat Template.body_markdown` — data, editable live, no deploy |
| 4 | **Enable prompt caching** (~6,000 tokens of stable system prompt, re-sent on every call) | Mostly a cost saving. Small latency effect, because the bottleneck is output | `integrations/openai.py`, `integrations/anthropic.py` |

Item 3 is deliberately a **template** change, not a prompt change: how a given report type
should be read belongs in the template, and a template edit is live data rather than a code
release (the prompt version is a hardcoded Python literal — see §6).

## 6. Cost

At $0.042-$0.120 per extraction call and two calls per upload, a report currently costs
roughly **$0.10-$0.20**. Item 2 approximately halves that on repeat report types; item 4
reduces the remainder.

`prompt_version` is a hardcoded default in `integrations/llm.py`, and `AI Settings` has no
prompt field, so changing or rolling back a prompt is a code deploy and cannot vary per
clinic. This is why items 2 and 3 are preferred over prompt edits.

## 7. Method, so this can be repeated

Rows were read directly from `AI Prompt Log` (`purpose = "Multi-Panel Extraction"`,
`status = "Success"`), newest ten, no sampling or exclusion. All ten ran against the same
site, model and prompt version. The same file was used for several of them, so the set is
not a representative sample of report types — it is enough to establish the latency/output
relationship, and not enough to quote an average time per report.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-22 | Divyanshu (AI-assisted) | Initial measurement — latency is output-token bound; selection call unlogged; four ranked actions |
