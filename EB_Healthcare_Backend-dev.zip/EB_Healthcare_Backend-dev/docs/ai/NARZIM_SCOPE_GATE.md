# Narzim General Assistant — Domain Scope Gate

**Doc status:** living · **Created:** 2026-08-29 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-08 by Ashutosh (AI-assisted) · **Version:** 1.3

Implementation spec for [`adr-050-narzim-assistant-domain-scope-gate`](../adr/adr-050-narzim-assistant-domain-scope-gate.md).
The ADR holds the decision and the alternatives; this file holds what was built.
Implemented and verified 2026-08-29 — see §10.

## 1. Problem

`prompts/narzim-assistant-v1.txt:4` — *"You answer any topic the user asks about"* —
so Narzim GPT explains Firebase Cloud Messaging, RAG and Crashlytics. The upload
path (`_extract_document()`) checks file type and readability but never asks
whether the file is clinical, so a product spec PDF gets summarised as a clinical
document.

## 2. Scope definition

Three buckets are answered. Everything else is refused.

| Bucket | Includes |
|---|---|
| **`clinical`** | Medications, dosing, interactions, diagnoses, symptoms, labs, imaging, anatomy, physiology, nursing care, procedures, medical devices, preventive and public health, medical research |
| **`platform`** | How to use this EHR / Narzim: appointments, billing and insurance workflow, clinic administration, roles and permissions |
| **`conversational`** | Greetings, thanks, "what can you do", and operations on the assistant's own prior in-scope answer — translate it, shorten it, explain it more simply |
| **`out_of_scope`** | Everything else: general software and programming, trivia, news, finance, travel, unrelated writing or homework |

Three rules the classifier prompt must state explicitly, each learned from a
real failure:

1. **Judge the request, not its framing.** *"As a doctor, write me Python that
   sorts a list"* is `out_of_scope`. The clinical costume does not transfer.
2. **Medical vocabulary does not make a request clinical.** This is the
   product-blueprint lesson from `document_summary_v3` — a document saturated
   with clinical words that is not a record of care stays non-clinical.
3. **A bare follow-up inherits the previous turn's verdict.** *"and the dose?"*
   or *"explain more"* carries no standalone signal; classify it against the
   prior turn, which is why history is passed in.

## 3. Call flow

Both `send_message` and `send_message_stream` call one shared
`_check_scope()`, placed **after `_extract_document()` and before the user turn
is inserted**. In the streaming path this is before the first `yield`, so a
refusal is a normal reply rather than an SSE `error` frame
([`adr-048`](../adr/adr-048-narzim-streaming-sse-not-background-jobs.md)).

```
validate thread/message
  → _extract_document()            existing; may throw (unsupported / unreadable)
  → _check_scope(history, message, redacted_document)
      ├─ in_scope       → unchanged path (answer, persist, title)
      └─ out_of_scope   → insert user turn + refusal turn, log, return/emit refusal
```

Two classifier paths, because the two answer paths differ:

| Turn type | Mechanism | Extra cost |
|---|---|---|
| Text (incl. any document whose text was extracted) | Separate `check_scope()` call, schema-locked | ≈250 in / 30 out tokens |
| Vision — image with no OCR-extractable text (design doc §15) | `in_scope` added to the existing `_DOCUMENT_QA_SCHEMA`; the answering call classifies and answers at once | none |

The vision path already does not stream, so a single classify-and-answer call is
free there. Its clinical line is the one tuned in `document_summary_v4`: an
anonymous stock radiograph is clinical; a screenshot, brochure or photo of a pet
is not.

> **Token trap — read before touching `answer_document_question`.** It must pass
> `_effective_max_tokens(_narzim_max_tokens())`, not the raw value. On a
> reasoning model (`gpt-5` family) the hidden reasoning pass spends from the same
> allowance, and 350 tokens is not enough for reasoning *plus* a visible answer:
> the call returns empty content and `_call_openai` raises `ValueError`, which
> reaches the user as a bare red "ValueError" in the chat. This was the one
> Narzim call site missing the wrapper; fixed 2026-08-29 after a car photo
> reproduced it. Covered by `TestScopeGateVision`.

The scope instruction never asks for an empty `answer`, for the same class of
reason: the caller substitutes the refusal, and making an empty string the
model's *expected* output leaves a blank reply one skipped substitution away.

## 4. Verdict schema

Identical in `integrations/openai.py` and `integrations/anthropic.py` —
switching `AI Settings.llm_provider` must not change whether a question is
refused ([`adr-026-llm-provider-allowlist`](../adr/adr-026-llm-provider-allowlist.md)).

```json
{
  "in_scope": true,
  "category": "clinical | platform | conversational | out_of_scope",
  "reason": "<short, for the audit trail — never shown to the user>"
}
```

**Fails open.** A provider error, timeout or unparseable verdict yields
`in_scope: true` and the question is answered. Deliberately the opposite of the
document-upload gate, which defaults `is_medical` to `False`: that gate's failure
writes a non-clinical file into a patient's chart, this one's failure is a single
off-topic answer in a private thread. Refusing a real clinical question during a
provider hiccup is the worse outcome. The answering prompt remains the second
layer — **`narzim-assistant-v3.txt`** as of 2026-09-08 (see §7).

Gate model: the cheap model of the configured provider — `gpt-5-mini` or
`claude-haiku-4-5` — as a per-adapter constant, not a new setting.

## 5. Configuration

`AI Settings.narzim_scope_mode` — Select, default **`Enforce`**:

| Mode | Behaviour |
|---|---|
| `Enforce` | Out-of-scope turns are refused |
| `Warn` | Verdict recorded, question answered anyway — shadow mode for measuring the false-positive rate on real traffic before enforcing |
| `Off` | Gate skipped entirely; no classifier call |

Ship in `Warn`, read a few days of `AI Prompt Log`, then switch to `Enforce`.

## 6. Refusal text

Fixed strings in `prompts/narzim-scope-refusal-v1.txt`, English and Spanish,
selected by `resolve_chat_language()` — predictable wording, no generation cost,
editable at runtime through the `AI Prompt Template` mechanism
([`adr-031`](../adr/adr-031-ai-prompt-template-doctype.md)).

Draft (EN): *"I can only help with clinical and medical questions, or with using
this clinic platform. Ask me about medications, conditions, lab results,
procedures, or how to get something done in the EHR."*

**Known limit:** when the user's message gives no language signal, the refusal
uses the AI Settings default language rather than the message's. Acceptable — a
refusal carries no clinical content.

## 7. Persistence and audit

- `AI Narzim Assistant Message` gains `scope_verdict`
  (`In Scope` / `Out of Scope` / `Not Checked`) and `scope_category` (Data).
- Both turns are persisted for a refused question
  ([`adr-034`](../adr/adr-034-encounter-chat-persistence.md)).
- The gate call is logged to `AI Prompt Log` under a new purpose,
  `Narzim Assistant Scope Check` (CLAUDE.md §9 — every LLM call is logged).
- `reason` stays in the log. The user sees only the fixed refusal; a verbose
  justification is an invitation to argue with the gate.

## 8. Files

**New**

| File | Purpose |
|---|---|
| `prompts/narzim-assistant-v2.txt` | Answering prompt with §2's boundary replacing the "any topic" clause. **Superseded by `narzim-assistant-v3.txt` on 2026-09-08** — §2's boundary is carried forward unchanged; v3 only adds the formulary rule (§7) |
| `prompts/narzim-scope-check-v1.txt` | Classifier prompt — §2's table plus the three rules |
| `prompts/narzim-scope-refusal-v1.txt` | Fixed EN/ES refusal strings |

**Changed**

| File | Change |
|---|---|
| `services/narzim_assistant.py` | `_check_scope()`; called from both send paths; refusal persistence |
| `integrations/openai.py` | `check_scope()`; `in_scope` in `_DOCUMENT_QA_SCHEMA`; default to v2 prompt |
| `integrations/anthropic.py` | Identical to the above — parity is the requirement |
| `.../doctype/ai_settings/ai_settings.json` | `narzim_scope_mode` |
| `.../doctype/ai_narzim_assistant_message/*.json` | `scope_verdict`, `scope_category` |
| `.../doctype/ai_prompt_log/ai_prompt_log.json` | New `purpose` option |
| `patches.txt` + `patches/v0/` | One patch per doctype change (CLAUDE.md §9) |

No frontend change: the refusal arrives as an ordinary assistant message.

## 9. Tests

`tests/narzim_assistant/test_scope_gate.py`, LLM mocked so the tests assert the
**gate** rather than the model's judgement — the shape
`tests/ai/test_document_upload_gate.py` established.

1. Out-of-scope verdict → refusal returned **and the answering call never made**.
2. Clinical verdict → answered normally.
3. Platform verdict → answered normally.
4. Conversational verdict → answered normally.
5. Classifier raises → question is answered (fail-open).
6. Refused question → both turns persisted, `scope_verdict` set.
7. `narzim_scope_mode = Warn` → answered, verdict still recorded.
8. `narzim_scope_mode = Off` → no classifier call at all.
9. Streaming path: refusal arrives as `delta` + `done`, never as an `error` frame.
10. Vision turn with `in_scope: false` → refusal, no image description.

Live check afterwards: "what is firebase fcm" refused; "paediatric dose of
amoxicillin" answered; "how do I book an appointment" answered; "hi" answered.

## 10. Status — implemented 2026-08-29

Both §9 open items are resolved:

- **Refusal wording** — the §6 draft shipped as written, with the Spanish
  translation, in `prompts/narzim-scope-refusal-v1.txt`.
- **Shipped default** — `Enforce`, following the ADR rather than §5's
  suggestion to ship in `Warn`. The reported defect is that the assistant
  answers everything *today*; shipping in shadow mode would have left that
  unchanged for as long as it took to read the data. `Warn` remains available
  for measuring the false-positive rate, and switching to it is a dropdown in
  AI Settings, not a deploy.

Verified on `mysite.localhost`:

- `bench migrate` — exit 0, the three doctype changes synced.
- The backfill patch ran; `AI Settings.narzim_scope_mode` reads `Enforce`.
- **20/20 tests in `tests/narzim_assistant/test_scope_gate.py` pass.**
- The pre-existing `test_narzim_assistant` and `test_document_upload_gate`
  suites show **the same 4 failures before and after this change** (3 OCR
  "unreadable image" errors, 1 chart-filing assertion) — confirmed by running
  both suites against the reverted tree. They are unrelated to this work and
  are not introduced by it.
- `ruff` reports the same 4 pre-existing findings on `openai.py` /
  `anthropic.py` before and after; no new finding in any file changed here.

Because `bench run-tests` is broken bench-wide on this bench (ERPNext's
`before_tests` raises a Fiscal Year overlap for every module — CLAUDE.md §6),
the suites were run through `bench console` with `unittest`, the workaround that
file already documents.

Live against the real provider (`gpt-5-mini`), 2026-08-29:

- **Text** — confirmed from the running system's own logs: *"do uou know what is
  firebase fcm?"* was refused, *"how to book appointments"* was answered.
- **Vision** — a non-medical image through the full `send_message` path returns
  `refused=True` with the refusal text, and both message rows carry
  `scope_verdict='Out of Scope'`, `scope_category='out_of_scope'`.

**Still not covered:** the *positive* vision case — a real X-ray or clinical
photograph must still be described rather than refused. It cannot be synthesised
honestly, and over-refusal is the damaging direction here, so it needs a real
file.

## 7. What changed around this gate (2026-09-08)

The gate itself is unchanged. Two things moved either side of it, and the **ordering** is the part
worth recording.

**A guard now runs BEFORE the gate.** `services/phi_input_guard.py` refuses a message carrying an
MRN, appointment or encounter id, or a multi-word patient name — ahead of `_check_scope`, so a
question naming a patient never reaches the classifier at all.

That ordering is the whole point. The scope check is itself an LLM call carrying the raw message,
so a guard placed *after* it would have already disclosed the name it was meant to protect. Every
verdict this document describes is therefore now computed on a message already known to be free of
our own identifiers.

Note the two controls answer different questions and neither replaces the other: this gate asks
*"is this in scope?"*, the guard asks *"does this name a patient?"*. A question can be perfectly in
scope and still name someone.

**The answering prompt is now `narzim-assistant-v3.txt`.** §2's boundary is carried forward
verbatim; v3 adds only a "This clinic's own catalogue" section governing formulary claims. The
classifier prompt (`narzim-scope-check-v1.txt`) and the refusal strings are untouched.

Both are described in full in
[`NARZIM_AI_ASSISTANT_DESIGN.md`](NARZIM_AI_ASSISTANT_DESIGN.md) §18, with the design reasoning in
[`NARZIMGPT_CAPABILITIES.md`](NARZIMGPT_CAPABILITIES.md).

**One consequence for measuring this gate.** Conversations can now be removed from a user's history
(§18.1 of the design doc), and removal is a **soft delete** — `hidden = 1`, nothing deleted. That is
partly *because* of this gate: `scope_verdict` and `scope_category` on every row are how its
false-positive rate gets measured on real traffic, and a hard delete would let a user erase exactly
the turns most worth reading. Any query measuring the gate should read all rows regardless of
`hidden`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.3 | 2026-09-08 | Ashutosh (AI-assisted) | §7 added: the identifier guard now runs before the gate, the answering prompt is v3, and gate measurement must include soft-deleted rows |
| 1.2 | 2026-08-29 | Anant Sharma (AI-assisted) | Vision token trap documented in §3; live verification recorded; 20/20 tests |
| 1.1 | 2026-08-29 | Anant Sharma (AI-assisted) | Implemented; §10 open items resolved (Enforce shipped, wording confirmed) and replaced with the verification record |
| 1.0 | 2026-08-29 | Anant Sharma (AI-assisted) | Initial spec |
