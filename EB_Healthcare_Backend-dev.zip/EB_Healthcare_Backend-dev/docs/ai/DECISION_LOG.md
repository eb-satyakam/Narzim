# Remedisys AI — Decision Log

**Doc status:** living · **Created:** 2026-08-13 by Sarvesh-SocialAngel · **Updated:** 2026-09-08 by Ashutosh (AI-assisted) · **Version:** 1.1

| | |
|---|---|
| **Purpose** | Date-wise record of what the plan was, what was decided, and what changed |
| **Compiled** | 2026-08-13, from git history · ADRs · prompt archive · in-code decision comments |
| **Rule** | Dates and authors are from **git**, not reconstructed. Where a decision is inferred rather than recorded, it says so |
| **⚠️ On "Who"** | The name is the **git commit author** — who wrote the code. For product decisions (marked **PRODUCT**) the decider is the founder; the named person implemented it. Git cannot distinguish the two, so do not read authorship as accountability |
| **Reads with** | [`REMEDISYS_AI_MASTER_PLAN.md`](./REMEDISYS_AI_MASTER_PLAN.md) — the current plan · [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) — the evidence |

---

## Who built this

Every commit touching `prompts/`, `services/ai*.py`, `api/v1/ai/`, `api/ai/`,
`integrations/`, `docs/ai/`:

| Author | Commits | What they own |
|---|---:|---|
| **Sarvesh-SocialAngel** | **117** | Essentially all of it — the agent, tools, prompts, ASR, chat persistence, safety work, performance, docs |
| **Divyanshu** | 22 | OCR + multi-format text extraction (`fceb059`), provider error handling (`a373332`) |
| **tech4651** | 9 | — |
| **Anant Sharma** | 3 | — |
| **Divyanshu44-55** | 1 | — |
| **ashulockedin** | 1 | — |

**77% of the AI system is one author's work**, and every architectural decision below is
authored by that one person. Two consequences worth stating plainly:

- **Bus factor is 1.** The design rationale for the agent, the tool registry, the prompt
  safety architecture and the ASR pipeline lives with one engineer. That is the reason the
  audit and explainer documents now exist.
- **It mirrors a risk already identified for the clinical data.** The master plan warns
  that a dataset from 3–5 doctors models *those individuals*, not medicine. The same is
  true of the codebase: the current design encodes one engineer's judgement. Both are
  reasons to build evaluation and review, not reasons to distrust the work.

---

## The headline

**The original plan said "no AI before Phase 5." The AI shipped anyway, in production, over
seven weeks — and the planning documents were never updated to say so.**

| | Planned | Actual |
|---|---|---|
| When AI starts | After Phases 0–4 complete (`CLAUDE.md` §2: "ALL 23 screens working with real data → THEN AI starts") | Started 2026-05-15, live since ~2026-07-23 |
| Phase 3 (Billing) | Complete before AI | Insurance still 🔲 not started |
| Phase 4 (Ops/Reports) | Complete before AI | 🔲 Not started |
| `api/v1/ai/api.py` | "🔴 Phase 5 stub" | 1,778 lines, production |
| AI doctypes | 5 | 18 |
| Free-text "ask the AI" | `ROADMAP.md` §892: **"anti-pattern to never implement"** | `NarzimAIChatBar.tsx` — shipped, it is the headline feature |

This is not a criticism of the sequencing decision — building AI early may well have been
right. It is a criticism of the **record**: the plan was overtaken by reality and nobody
wrote it down, so `CLAUDE.md` and `ROADMAP.md` now actively mislead anyone onboarding.

---

## Phase A — Foundations (2026-05-13 → 2026-06-30)

AI capture was built here, *before* the "no AI until Phase 5" rule was written.

| Date | Who | Decision / change | Evidence |
|---|---|---|---|
| 2026-05-13 | Sarvesh | App scaffolded on Frappe v16 | `006694c` |
| 2026-05-13 | Sarvesh | **ADR-004/005/006** — Frappe v16 (not v15) · Frappe Cloud, sidecar FastAPI suspended · MariaDB (not Postgres) | ADRs |
| 2026-05-15 | Sarvesh | **ADR-009 — audio goes browser → Deepgram directly.** Server mints a scoped token; audio never touches Frappe | `b8d8141`, `999d6fc` |
| 2026-05-16 | Sarvesh | **ADR-007** — jurisdiction locked to Mexico; India/HIPAA dropped | ADR-007 |
| 2026-05-19 | Sarvesh | Deepgram capture client + audio-capture hardening | `2ae00c7`, `0b75917` |
| 2026-06-03 | Sarvesh | **ADR-010** — clinical frontend is Next.js on Vercel; Frappe becomes backend-only | ADR-010 |
| **2026-06-04** | Sarvesh | **⚠️ "AI is a future feature. Do not build AI features until Phases 0–4 are fully working."** Product-scope clarification written into `CLAUDE.md` | `CLAUDE.md` amendment block |
| 2026-06-05 | Sarvesh | **ADR-011** — auth switches to eb_frappe_jwt Bearer JWT | ADR-011 |
| 2026-06-30 | Sarvesh | **ADR-018** — jurisdiction reopened to **India + Mexico**, pluggable via `ComplianceProfile`. Supersedes ADR-007 | ADR-018 |

**Note the contradiction inside this phase:** ADR-009 (AI audio capture) shipped
2026-05-15, then the "don't build AI" rule was written 2026-06-04. The rule was already
untrue when written.

---

## Phase B — The agent is built (2026-07-09 → 2026-07-28)

Seven weeks in which the entire Encounter Copilot went from nothing to production.

| Date | Who | Decision / change | Evidence |
|---|---|---|---|
| 2026-07-09 | Sarvesh | Consent + recording flow designed | `prompts/2026-07-09-ai-copilot-consent-recording.md` |
| **2026-07-13** | Sarvesh | **ADR-026 — LLM is no longer single-vendor.** Approved allowlist (Anthropic, OpenAI) via `AI Settings.llm_provider`. Resolved the conflict where the constitution said Anthropic-only while the live system ran OpenAI | ADR-026 |
| 2026-07-13 | Sarvesh | **Pricing bug fixed on the OpenAI side** — dated snapshot ids (`gpt-5-mini-2025-08-07`) missed exact-match lookup and silently billed at gpt-5 rates. Changed to longest-prefix match. *(The Anthropic adapter was never given the same fix — still live, §D)* | `openai.py:985-996` |
| 2026-07-15 | Sarvesh | **Dual-mic multichannel** chosen as an alternative to diarization: channel 0 = doctor, 1 = patient, deterministic | `prompts/2026-07-15-dual-mic-multichannel.md` |
| 2026-07-18 | Sarvesh | **Product decision: AI-created masters are non-billable, zero-rate.** An AI-created master must never silently become billable | `api/v1/ai/api.py:47` |
| 2026-07-21 | Sarvesh | `reasoning_effort` made an admin setting, default **`low`** — tested sweet spot, catches all safety flags at ~38 s | `openai.py:585` |
| 2026-07-22 | Sarvesh | **ASR audit opened** — Scottish-accented doctor not transcribing correctly | `ASR_TRANSCRIPT_AUDIT.md` |
| **2026-07-22** | Sarvesh | **Decision: reject `en-GB`, choose `nova-3` + `language=multi` + drug keyterms.** Reason: patients speak English *or* Spanish, so an English-only model cannot transcribe them. Accepts a known accent-accuracy trade-off | ASR audit §6 |
| **2026-07-23** | Sarvesh | **ADR-030 — Rule 4 refined: curated LLM tool-calling allowed.** Raw SQL, arbitrary Python and generic CRUD stay banned. This is the decision that made the whole agent possible | ADR-030 |
| 2026-07-23 | Sarvesh | **Product decision: labs auto-create like any other master** (was Settings-only). Vaccines stay Settings-only — they need an admin-configured dose schedule | `0df4918`, `api.py:326` |
| 2026-07-23 | Sarvesh | Tool-iteration cap set at **5** | `openai.py` history |
| 2026-07-24 | Sarvesh | **Cap raised 5 → 12.** "Add all" on a multi-category list needed ~9 write calls and genuinely ran out mid-request | `openai.py:1261-1267` |
| 2026-07-24 | Sarvesh | Remove-tools added; patient-history tools added (`add_allergy` etc.) after the model improvised a fake "Allergy: X" *diagnosis* | `6269263`, `dc305d7` |
| **2026-07-25** | Sarvesh | **ADR-034 — Narzim encounter chat is persisted** (`AI Encounter Chat Message`), ChatGPT-style threads | `672da3a`, `b8aeece` |
| **2026-07-25** | Sarvesh | **⚠️ Consent gate REMOVED** — auto-start/resume recording, "removing consent gate… for seamless navigation" | `183c783` |
| 2026-07-25 | Sarvesh | Review Details generated at sign time | `64cea2d` |
| **2026-07-27** | Sarvesh | **Cap raised 12 → 20.** Analyze now always checks allergy/home-med/history *and* always calls `set_patient_summary`; at 12 the summary call was never reached | `openai.py:1269-1274` |
| **2026-07-27** | Sarvesh | **Decision: Analyze ALWAYS updates the patient summary** — previously skipped for visits assessed as routine. Also began capturing home/OTC meds, with **paracetamol/Tylenol named as the worked example** in the prompt | `4a310d4`, `api.py:993-997` |
| 2026-07-28 | Sarvesh | **Scope restriction added** — the agent refuses off-topic requests (code, maths, general chat) | `de35e30` |
| 2026-07-28 | Sarvesh | **Dead-code purge** — `autopopulate_encounter()`, `chat_reply()`, `build_master_catalogs()` and every helper feeding only them removed, plus their prompt files | `01b5e0b` |
| 2026-07-28 | Sarvesh | `search_medication_catalog` added — first catalog-grounding tool | `NARZIM_AI_ENCOUNTER_SYSTEM.md` §4.1 |

---

## Phase C — Safety incidents and hardening (2026-07-29 → 2026-08-01)

Four days that produced most of the current safety architecture — all of it prompt-layer.

| Date | Who | Incident / decision | Evidence |
|---|---|---|---|
| **2026-07-29** | Sarvesh | **🔴 INCIDENT — prior-visit contamination.** A previous summary reading *"queja principal de equimosis fácil"* was adopted as today's chief complaint on a **fever/headache** visit; the agent drafted "Bruising easily", diagnosis `R23.3`, and PT/INR + aPTT + CBC — none of it discussed that day | quoted verbatim in `ask-copilot-v2.txt:107` |
| 2026-07-29 | Sarvesh | **Fix (3 layers, all prompt-level):** emphatic in-context label on the summary block · `_ANALYZE_PROMPT` "EVERYTHING must come from TODAY'S transcript" · absolute rule quoting the incident. **No deterministic guard was added** | `openai.py:1317`, `api.py:970` |
| 2026-07-29 | Sarvesh | **`get_previous_encounters` restricted to signed encounters** (`docstatus=1`). It had been returning unsigned drafts — verified live, all five "previous encounters" on one patient were abandoned drafts presented as settled history | `ai_tools.py:81-88` |
| 2026-07-29 | Sarvesh | Five more `search_*_catalog` tools added — every write category now has catalog grounding | `14c752d` |
| 2026-07-29 | Sarvesh | Historical vitals added to `get_previous_encounters`; `spo2`/`height`/`weight` added to `add_vital` | `280fab7` |
| **2026-07-30** | Sarvesh | **Paediatric drug safety block added** — adult secondary-prevention refusal, unexcluded-contraindication priority (nitrate/HOCM etc.), weight-based dosing instruction | `4458b33`, `ask-copilot-v2.txt:118-143` |
| 2026-07-30 | Sarvesh | Duplicate-order and duplicate-prescription guards added — **deterministic**, after the model re-worded a drug between Analyze runs and both phrasings landed | `ai_tools.py:636`, `:819` |
| **2026-07-30** | Sarvesh<br/>**PRODUCT** | **🔴 INCIDENT — PHI exposure in the general Narzim assistant.** Within hours of launch a Front Desk user uploaded a real discharge note; the assistant summarised name, dates, diagnosis, microbiology, and **persisted it** outside the patient record system | `NARZIM_AI_ASSISTANT_DESIGN.md` §10 |
| 2026-07-30 | Sarvesh | Fix v1: dedicated PHI pre-check classifier; uploads no longer persisted; the specific exposure purged | §10 |
| **2026-07-30** | Sarvesh<br/>**PRODUCT** | **Decision (user): the general assistant is visible to every role, Front Desk included** | §7 Q2 |
| **2026-07-30** | Sarvesh<br/>**PRODUCT** | **Decision (user): scope widened from "medication/clinical questions" to general-purpose** | §11 |
| 2026-07-30 | Sarvesh | AI Settings language overrides dropped — output language now from `User.language` → ComplianceProfile | `836b40f` |
| 2026-07-30 | Sarvesh | `AI Encounter Record` added — consolidated per-encounter AI record at sign | `9daa464` |
| **2026-07-31** | Sarvesh | **Fix v2 — redesign: no file bytes ever reach the LLM.** Local text extraction (`pdf_pages`) + deterministic regex/label redaction (`pii_redaction`). Reason given: the v1 classifier still transmitted the raw file to the provider | §12 |
| 2026-07-31 | **Divyanshu** | Format coverage extended: Excel/Word/PowerPoint, then OCR for images + scanned PDFs, legacy `.doc`, CSV, TXT | `fceb059`, §13–§14 |
| **2026-07-31** | Sarvesh<br/>**PRODUCT** | **⚠️ Decision (user, verbatim): "yes proceed with no patient authorization."** Raw image bytes go to the vision model when OCR finds no text — the single exception to "never send raw bytes", in a patient-agnostic assistant reachable by every role. Risk was stated before the decision was taken | §15 |
| 2026-07-31 | Sarvesh | "Fix speakers" correction made to actually persist (it had been silently lost on reload) | `1834afe` |
| 2026-07-31 | Sarvesh | Signing/cancelling restricted to the assigned practitioner | `c155e99` |
| **2026-08-01** | Sarvesh<br/>**PRODUCT** | **Decision (user): stop the model second-guessing the deterministic mask.** Removed the "decline if the text still identifies a patient" rule. Trades false refusals for a real chance of a masking gap surfacing | §16 |

---

## Phase D — Performance, and two reversals (2026-08-04 → 2026-08-12)

| Date | Who | Decision / change | Outcome |
|---|---|---|---|
| 2026-08-04 | Sarvesh | Optimization plan + idempotency design written | `f3186c9` |
| 2026-08-04 | Sarvesh | **Prompt reads and tool specs cached**; `Cached` status and `prompt_hash` added to the log | ✅ Shipped `7892ae8` |
| 2026-08-04 | Sarvesh | **Analyze made idempotent** — composite fingerprint; a re-run with nothing clinically changed reuses the result. **Defaults OFF** (`enable_analyze_cache`) | ✅ Shipped `c778ad5` |
| 2026-08-04 | Sarvesh | Agent instrumented (round-trips, spans); discarded catalogs no longer resolved on the agent path | ✅ Shipped `baa04f5` |
| 2026-08-04 | Sarvesh | **Tool-call batching attempted** — let the agent batch instead of one call per round-trip | ❌ **Reverted same day** `34171e7` — the edit was proven inert (`bc36779`) |
| 2026-08-05 | Sarvesh | **SSE endpoint for streamed Analyze** — verified end-to-end | ✅ Shipped `27b435f` |
| **2026-08-06** | Sarvesh | **Streamed Analyze reverted** — nginx buffering could not be verified | ❌ **Reverted** `a711e66`. *Note: only the endpoint went; `ask_copilot_agent_stream` remains the primary implementation* |
| **2026-08-12** | Sarvesh | **ASR audit closed.** Clinician confirms transcription works on `nova-3` + `multi` + keyterms. Phase 2 (Whisper) deferred, not needed | ✅ `760db0c` |

**Two reversals in three days.** Both were correct calls — an unverifiable production risk
and a change proven to have no effect. Worth noting as a pattern: performance work on this
path has a poor hit rate, which is an argument for the measurement-first sequencing in the
current plan.

---

## Phase E — Audit and re-plan (2026-08-13, today)

| Decision | What changed |
|---|---|
| **Audit the running system against code, not docs** | `CURRENT_SYSTEM_AUDIT.md` — 20 sections, every claim at `file:line`, live DB measurements |
| **Produce a plain-English explainer** | `REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md` |
| **Review the long-term vision adversarially** | Long-term AI vision review (later absorbed) |
| **Merge with the external ChatGPT plan** | `REMEDISYS_AI_MASTER_PLAN.md` — now authoritative |
| **Reframe: evidence platform, not trained model** | ~90% of the described value needs zero model training. The asset is the dataset + retrieval layer |
| **Adopt the 5-value provenance enum** | From the external plan — better than a binary AI flag |
| **Fine-tuning = an experiment, not a milestone** | From the external plan — compare architectures on a fixed eval set; do not gate on encounter count |
| **RULED OUT: training on "case → approved final decision"** | Imitation learning on practice entrenches error. Resolved a contradiction in the external plan |
| **HARDENED: clinic data never trains the global model** | Was "must be governed"; now a clear no, on four independent grounds |
| **Doc consolidation** | Removed `AI_ENCOUNTER_OPTIMIZATION_PLAN.md`, `AI_TOKEN_COST_MODEL.md`, `REMEDISYS_LONG_TERM_AI_VISION.md`; kept `AI_ANALYZE_IDEMPOTENCY_DESIGN.md` because four source files cite it by section; both README indexes rewritten; ASCII diagrams → Mermaid |

### Measurements taken today that changed prior conclusions

| Prior claim | Measured 2026-08-13 |
|---|---|
| avg 21,748 input tokens / 10.7 s | **53,414 / 16.0 s**; max **98.6 s** and **265,189 tokens** |
| "`cached_tokens` appears nowhere in the codebase" | **Captured — 46% of all agent input** |
| "ASR is >50% of per-encounter AI spend" | **23.7%** |
| "15.4 round-trips typical" | Typically **1–5**; 15+ is the tail |
| Analyze idempotency "not yet built" | **Shipped 2026-08-04, defaults OFF** |

### New findings from today's audit

| Finding | Status |
|---|---|
| Doctor accept/edit/reject computed in the browser and **discarded** (`use-copilot.ts:443`) | 🔴 Blocks the entire learning strategy |
| 5 write tools reach the permanent Patient record **unreviewed** (`encounter-screen.tsx:3217-3263`) | 🔴 Rule 6 broken; contaminates any future dataset |
| Every patient under 12 months sent to the LLM as age **`0`** (`services/ai.py:880`) — verified on 6 live patients | 🔴 Paediatric safety block reasons off a corrupted integer |
| Raw Deepgram speaker index discarded — `speaker_label` **NULL on all 5,933 rows** | 🔴 Makes the diarization question unanswerable |
| 22% of segments `unknown`; doctor:patient skew 1.8:1 | 🔴 Label noise |
| Anthropic 8× pricing bug **still live** — confirmed arithmetically | 🟠 |
| ~180 unit-test `MagicMock` rows with fabricated costs in the production log | 🟠 |
| **Paediatric mg/kg dosing already exists** in `Treatment Plan Template`, unwired from the AI | 🟠 Highest-value fix, no new data needed |
| **ADR numbers collide at 018, 026, 027, 028, 030** — five pairs, not the one pair previously recorded | 🟡 |

---

## Phase F — P0 execution begins (2026-08-14)

Three of the six P0 items shipped in one day — the three that needed no decisions.
**All three PRs are OPEN, not merged.** Nothing below is live until a Maintainer merges.

| Date | Who | What was fixed | Evidence |
|---|---|---|---|
| 2026-08-14 | Sarvesh | **Item 4 — infant age.** `int(days/365)` sent every patient under 12 months to the model as `0`, and the prompt taught the number meant *years*. Fixed to exact calendar months with a unit-bearing string | **PR #310 (open)** · `services/ai.py` |
| 2026-08-14 | Sarvesh | **Item 5 — raw speaker index.** `speaker_label` was NULL on all 5,933 rows, so a mislabelled turn could not be attributed to Deepgram vs our own mapping. Now persisted with its source | **PR #380 (open, frontend)** · `real-provider.ts` |
| 2026-08-14 | Sarvesh | **Item 6 — observability + cost.** Four defects: the Anthropic 8.05× overstatement, cached input never discounted, ~234 unit-test rows polluting the live log, and tool arguments recorded nowhere | **PR #311 (open)** · `anthropic.py`, `openai.py`, `services/ai.py`, `api/v1/ai/api.py` |

### Measured before / after

| | Before | After |
|---|---|---|
| `MRN-2026-0000003` (5 months old) | `0G` | **5 months old, genderqueer** |
| `MRN-2026-0000193` (17 days old) | `0M` | **17 days old, male** |
| `gpt-5-mini` via the Anthropic adapter | $8.0351 | **$0.9988** |
| Agent call, 46% cached | $0.01476 | **$0.00923** |
| `AI Prompt Log` rows | 1,654 | **1,420** (234 test rows purged) |
| Total logged cost | ~$191 | **$21.99** |
| `speaker_label` populated | 0 of 5,933 | new segments tagged |

### Decisions taken during execution

| Decision | Reasoning |
|---|---|
| **Age is a unit-bearing string, not an integer** | The old format required the prompt to teach a convention. When the number was wrong the model applied that convention faithfully to corrupted input. Stating the unit means a future arithmetic bug produces an obviously wrong sentence rather than a plausible one |
| **The silent `"doctor"` fallbacks were labelled, NOT fixed** | Behaviour is byte-identical; only their frequency became measurable. Changing attribution without first measuring it would be guessing |
| **`prompt_hash` NOT backfilled** | NULL on 239 of 329 rows. The prompt file has changed since, so the historical hash is unrecoverable. Writing today's hash would assert a call ran against instructions it never saw — a fabricated audit trail is worse than an honest gap |
| **Tool arguments logged as shape, never content** | Rule 10 is why this was never built. `{"drug_name":"<str:17>"}` reconstructs the decision path without creating a second copy of the clinical record in a table with different permissions and retention |
| **Purge patch matches only two observed signatures** | A real row wrongly deleted is an audit hole — worse than a test row left behind. The patch verifies no real model is caught before deleting |

### Note on execution

The purge migration was **run against `marley.local`** — 234 rows deleted from a live table, dry-run first. Recorded here because it is a destructive operation on real data, not something to discover later.

`tools_used` was found missing from `AI Prompt Log.field_order` — a pre-existing oversight meaning it never rendered in the Desk. Fixed alongside the new field.

---

## Phase G — Narzim GPT becomes a clinical tool (2026-09-08)

Six product decisions in one day, all taken explicitly by the product owner and all costed before
being taken. Design and the rejected alternatives:
[`NARZIMGPT_CAPABILITIES.md`](NARZIMGPT_CAPABILITIES.md).

| Date | Who | Decision | Ref |
|---|---|---|---|
| **2026-09-08** | Ashutosh<br/>**PRODUCT** | **Removing a conversation is a hide, never a delete.** Asked first whether HIPAA even permits deleting AI chat history — it does; HIPAA sets no retention period for clinical content (§164.316(b)(2)(i) covers Security Rule *documentation*), and both active jurisdictions grant a right to erasure HIPAA does not. Decision, verbatim: *"we should not delete anything from backend rather any user can remove any particular history or remove all of them"* | `NARZIM_AI_ASSISTANT_DESIGN.md` §18.1 |
| **2026-09-08** | Ashutosh | **D1 — the identifier guard lands FIRST**, before any guided-task work. It closed a live defect: the prompt's instruction to decline patient-specific questions ran *after* transmission, so the provider already held the name the UI claimed to be protecting | §18.4 |
| **2026-09-08** | Ashutosh<br/>**PRODUCT** | **D2 — first build is shell + formulary context**, not shell alone. The formulary cross-check is what no external assistant can reproduce | §18.2 |
| **2026-09-08** | Ashutosh<br/>**PRODUCT** | **D3 — interaction checking ships with an explicit limitation line** ("not a complete interaction check — verify against the insert") rather than being deferred until a drug dataset is licensed, or shipped silently on model recall | capabilities §4.2 |
| **2026-09-08** | Ashutosh<br/>**PRODUCT** | **D4 — no guided-only mode. Free text stays for every role**, `EB_Front Desk` included. A wall would be worked around by asking a clinician to type it, and D1 is the control regardless of role | capabilities §1 |
| **2026-09-08** | Ashutosh | **D5 — catalogue claims are positive-only; the row-count threshold I had recommended was withdrawn.** Measuring the live `Medication` master killed it: three rows, `Amoxiclin` misspelled and `Paracetamol` at 0 mg. Row count does not predict per-answer correctness — at any size a misspelling gives a false negative and a zero strength a false positive | §18.2 |
| **2026-09-08** | Ashutosh | **D6 — suggestion variety by rotating a curated pool, not generating per click.** Runtime generation rejected on latency (this assistant is tuned to 350 max tokens for speed), cost per panel-open with no answer produced, loss of reviewability, and the scope gate refusing a suggestion the system itself offered | capabilities §3.1 |
| **2026-09-08** | Ashutosh<br/>**PRODUCT** | **Disclaimer shortened** — "Narzim GPT has no access to patient records" removed. I had argued to keep it; since D1 refuses such questions with an explanation, users meet the limit where it matters rather than in small print | capabilities §11.6 |

### Note on execution

**Two of my own claims were withdrawn after measurement**, both recorded because the pattern is the
point: I recommended a row-count threshold before defining the number, and I sold the formulary
feature with an example (`"your formulary stocks 250 and 500"`) the data did not support. Both were
caught by looking at the live table rather than by review.

**A test of mine hid 39 real conversations.** `hide_all_threads()` is "clear MY history" by design
and the test ran as Administrator. They were recoverable *because* removal is a soft delete — a hard
delete would have destroyed them, which is a fairly direct argument for the decision above.

**Still unresolved, and now blocking three items:** nobody owns clinical sign-off on the 280
suggestion strings, the risk-score rubrics, or the pre-generated pool that would replace D6's
curated one. All three are clinical content living in code files.

---

## Decisions that were made *implicitly* — never written down

Recorded because they carry real weight and nobody signed off on them.

| Implicit decision | Where it lives | Why it matters |
|---|---|---|
| **Speaker 0 = doctor** | `real-provider.ts:52-55` | A positional guess with no verification. If the patient speaks first the whole transcript inverts |
| **Unrecognised speaker → "doctor"** | three code paths, all `?? 0` / hardcoded | Silently biases the transcript toward the clinician |
| **Patient-level AI output needs no review** | `encounter-screen.tsx:3217-3263` | The only Rule 6 exception in the system |
| **The model may infer "the standard adult strength"** | `ask-copilot-v2.txt:101` | In a clinic whose own prompt declares itself paediatric on line 5 |
| **A diagnosis may trigger a medication** | `ask-copilot-v2.txt:45`, `suggest-v2.txt:32` | Deliberate and reasonable — but never recorded as a decision |
| **Conditional treatment is not modelled** | no field exists | "If pain continues, give X" and "give X" are byte-identical |
| **Provider default is Anthropic** | `services/llm.py:20-24` | A fresh site runs the untested, uncached, mispriced path |
| **`enable_safety_validators` gates nothing** | no code reads it | Setting exists, reads `0`, has no effect |

---

## Open decisions — not yet made

| # | Decision | Blocked on |
|---|---|---|
| 1 | Definition of "outcome" per presentation | A clinician |
| 2 | Definition of "similar case" | Product + clinical |
| 3 | Consent model for secondary use of care data | Legal — LFPDPPP + DPDPA |
| 4 | Whether to build speaker verification | **Cannot decide** until `speaker_label` is persisted |
| 5 | Source of curated medical knowledge — licensed vs in-house | Commercial |
| 6 | Regulatory posture — documentation aid vs clinical decision support | Counsel. `ROADMAP.md` already flags COFEPRIS SaMD classification as "to be confirmed before Phase 5" — Phase 5 has effectively arrived |
| 7 | Data ownership terms | Before clinic #2 |
| 8 | Whether to update `CLAUDE.md` / `ROADMAP.md` to match reality | Founder — see below |

---

## The record-keeping problem

Three documents currently describe a system that does not exist:

| Document | Says | Reality |
|---|---|---|
| `CLAUDE.md` §6 | `api/v1/ai/api.py` is a "🔴 Phase 5 stub"; several services are "empty stubs" | 1,778 lines live; 18 AI doctypes not 5 |
| `CLAUDE.md` §8 | "Do not start Phase 5 until Phase 4 is complete and validated in production" | Phase 4 not started; AI in production |
| `ROADMAP.md` §892 | Free-text "ask the AI" input is an **anti-pattern to never implement** | It is the headline feature |
| Root `README.md` | Build table ends at Phase 4 | AI is not mentioned at all |

The AI docs under `docs/ai/` have been kept current. The **planning** documents have not,
and they are the ones a new engineer reads first. Someone onboarding from `CLAUDE.md`
today would conclude Remedisys has no AI.

**This log exists so that the next divergence is visible when it happens, not seven weeks
later.**

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-08 | Ashutosh (AI-assisted) | Phase G added — the six Narzim GPT decisions of 2026-09-08, plus the two claims of mine that measurement withdrew |
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
