# P0 — Implementation Plan

**Doc status:** living · **Created:** 2026-08-14 by Sarvesh-SocialAngel · **Updated:** 2026-08-14 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Scope** | The six P0 items from [`REMEDISYS_AI_MASTER_PLAN.md`](./REMEDISYS_AI_MASTER_PLAN.md) §13 |
| **Date** | 2026-08-13 |
| **Size** | ~1 sprint. Two items are near one-liners; one is a new doctype |
| **Repos** | `remedisys_healthcare_ai` (backend) · `Healthcare_next_app` (frontend) |
| **Status** | **3 of 6 shipped 2026-08-14 (PRs open, not merged).** Items 1, 2, 3 blocked on decisions — see Handover |
| **Evidence for every claim** | [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) |

## Status board — 2026-08-14

| # | Item | Status | PR |
|---|---|---|---|
| 4 | Fix infant age | **DONE** | [#310](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend/pull/310) — open |
| 5 | Persist raw speaker index | **DONE** | [#380](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/380) — open, frontend repo |
| 6 | Observability + cost | **DONE** | [#311](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend/pull/311) — open |
| 2 | Field-level provenance | **BLOCKED** | decision (1) |
| 3 | Patient-tool review gate | **BLOCKED** | decision (1) |
| 1 | Persist doctor feedback | **BLOCKED** | decisions (2) and (3) |

**Every item that needed no decision is complete.** The remaining three are blocked on
answers, not on engineering.

**All three PRs are OPEN.** Nothing is live until a Maintainer merges — developers cannot
merge their own PRs (`CONTRIBUTING.md`).

---

**What P0 is:** not features. Six prerequisites — three live safety/compliance gaps and three
data-capture gaps that block the entire learning strategy. Until 1, 2 and 3 ship, every
additional encounter is a partly wasted one.

---

## Conventions confirmed before planning

| Thing | Convention in this repo |
|---|---|
| New doctype | JSON under `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/<snake_name>/`, `autoname: "naming_series:"`, `track_changes: 1` |
| Custom fields on core doctypes | `fixtures/custom_field.json` — **never** edit core (Rule 1) |
| Migrations | `remedisys_healthcare_ai/patches.txt` + `patches/v0/<name>_<YYYYMMDD>.py` |
| Role grants | `patches/v0/eb_docperm_spec.json` → `permissions{doctype: [{role, permlevel, flags}]}`, EB_ roles |
| Frontend → backend | Next.js BFF route: `getAccessToken()` → `frappeFetch(...)` → `frappeErrResponse()` |
| Logging | IDs only, never content (Rule 10) |
| Feature flags | Default OFF |

**Two findings that shrink the work:**

1. **`append_segment` already accepts and persists `speaker_label`** —
   `api/ai/segments.py:75, :157`, and `sync_transcript` handles it at `:246, :264, :280`.
   Item 5 is a **frontend-only** change. No backend, no migration.
2. **The frontend already computes accept/edit/reject** — `use-copilot.ts:443` maintains
   `SuggestionStatus` correctly and simply never sends it. Item 1 is *persistence*, not new UX.

---

## Dependency order

```
        ┌─ Item 4 (age)  ─────────────── independent, ship first, ~1 hour
        ├─ Item 5 (speaker_label) ────── independent, frontend only, ~2 hours
        │
Item 2 (provenance) ──┬──► Item 3 (patient-tool review gate)
                      │       needs provenance to mark reviewed vs not
                      └──► Item 1 (feedback capture)
                              needs provenance on the feedback row
                                  │
                                  └──► Item 6 (observability)
                                          evidence_span rides the same tool-schema change
```

**Recommended sequence:** 4 → 5 → 2 → 3 → 1 → 6. Items 4 and 5 are independent and
deliver measurable value on day one; do them while item 2's schema is being reviewed.

---

## Item 4 — Fix infant age 🔴 SAFETY · ~1 hour

> **SHIPPED 2026-08-14 — PR #310 (open).** Verified live: `MRN-2026-0000003` `0G` -> **5 months old, genderqueer**; `MRN-2026-0000193` `0M` -> **17 days old, male**. 20 tests.

**Problem.** `services/ai.py:874-890`:

```python
age_years = int(date_diff(nowdate(), str(patient.dob)) / 365)   # ← line 880
return f"{age_years}{sex_code}"
```

`int(days/365)` truncates. Every patient under 12 months becomes `0`. That string is the
**only** age the LLM receives (`integrations/openai.py:1305`), and
`prompts/ask-copilot-v2.txt:5` teaches that the integer means **years** — so the model reads
`0` as a neonate and correctly applies the documented convention to corrupted input.

Reproduced live: `MRN-2026-0000003` (DOB 2026-03-03, 5 months) → `0G`. Five more confirmed.
The entire paediatric safety block (`ask-copilot-v2.txt:118-126`) keys off this value.

**Fix**

| File | Change |
|---|---|
| `services/ai.py::_resolve_age` | Return an unambiguous, unit-bearing string. Under 24 months → months. Use `frappe.utils.date_diff` for days and compute months from the date parts, not `days/30`. Also fixes the leap-year drift on `/365` |
| `services/ai.py::build_encounter_context` | Add `age_months: int` and `dob: str` as separate keys alongside `age` — structured beats parsing a string |
| `integrations/openai.py:1305` | Context line becomes explicit, e.g. `Patient: 5 months old, female (DOB 2026-03-03)` |
| `integrations/anthropic.py` | Same context-block change — do not fix one adapter only |
| `prompts/ask-copilot-v2.txt:5, :119` | Update the worked example so `"16G"` no longer teaches years-as-integer. **Prompt edit invalidates the Analyze cache by design** (`prompt` component of the fingerprint) — expected, not a bug |

**Target format.** `"5 months old, female"` for < 24 months; `"16 years old, female"` above.
Never a bare integer. `"Unknown"` when DOB is absent, falling back to the encounter's own
`patient_age` **only** if it is populated (verified empty on all live rows, so treat it as
unreliable).

**Tests** — `remedisys_healthcare_ai/tests/ai/test_context.py` (new):
DOB today → `0 months`; 5 months → `5 months`; 11 months; 23 months; 24 months → `2 years`;
leap-year birth 2012-02-29 checked the day before/after the birthday; `dob=None` → `Unknown`.

**Unblocks.** Every paediatric safety rule in the prompt starts reasoning on real ages.
**Do this first — it is the only item that is actively wrong on live patients right now.**

---

## Item 5 — Persist the raw speaker index 🔴 MEASUREMENT · ~2 hours

> **SHIPPED 2026-08-14 — PR #380 (open).** Frontend only, exactly as scoped — no backend, no migration. Role assignment byte-identical; the silent "doctor" fallbacks are labelled, not fixed. 9 branches verified.

**Problem.** `AI Transcript Segment.speaker_label` is **NULL on all 5,933 live rows**. The
frontend maps Deepgram's speaker index to a role and then discards the index, so you cannot
retrospectively tell whether a mislabel came from Deepgram's clustering or from
`SPEAKER_MAP{0:"doctor",1:"patient"}` (`real-provider.ts:52-55`).

Live symptoms: 2,978 doctor vs 1,648 patient segments (1.8:1 in a two-party consultation),
and 1,307 (22%) `unknown`.

**Backend is already done.** `append_segment(… speaker_label=None)` accepts it
(`api/ai/segments.py:75`) and writes it (`:157`); `sync_transcript` preserves it (`:246`,
`:264`, `:280`). **No backend change, no migration.**

**Fix — `Healthcare_next_app` only**

| File | Change |
|---|---|
| `copilot/real-provider.ts` — `TranscriptSegment` type | Add `rawSpeaker?: number` and `speakerSource?: "diarize" \| "channel" \| "fallback-nowords" \| "fallback-interim"` |
| `_groupBySpeaker` | Carry `run[0].speaker` into `rawSpeaker`; set `speakerSource` per branch. The no-words branch currently hardcodes `speaker: "doctor"` — keep behaviour for now, but **label it** `fallback-nowords` |
| multichannel branch | `rawSpeaker = channel`, `speakerSource: "channel"` |
| interim branch | `speakerSource: "fallback-interim"` when `alt.words?.[0]?.speaker` was absent |
| `_persistTranscript` / `_autosaveTranscript` | Send `speaker_label: seg.rawSpeaker != null ? \`${seg.speakerSource}:${seg.rawSpeaker}\` : seg.speakerSource` |

**Why encode source in the same field:** `speaker_label` is a free `Data` field, needs no
migration, and the two facts you must separate are *"which voice did Deepgram say"* and
*"did we actually get an index at all"*. `fallback-nowords:` with no number is precisely the
case that silently becomes "doctor".

**Rule 10 check:** an integer and an enum. No PHI. ✅

**Measurement this unlocks** — after ~2 weeks:

```sql
SELECT speaker_label, speaker, COUNT(*)
FROM `tabAI Transcript Segment`
WHERE speaker_label IS NOT NULL
GROUP BY speaker_label, speaker ORDER BY 3 DESC;
```

- `fallback-*` share → how often the silent doctor-default fires
- `diarize:0 → patient` corrections → how often speaker 0 is **not** the doctor
- index ≥ 2 share → how often a third speaker appears

**Unblocks.** The SpeechBrain / speaker-verification decision, which is currently
**undecidable** — you cannot size a fix for a problem you cannot attribute.

---

## Item 2 — Field-level provenance 🔴 FOUNDATION · ~2 days

**Problem.** Nothing distinguishes doctor-authored from AI-authored values. So AI output
already flows into "doctor-approved" records (item 3), and any future learning corpus would
train partly on the model's own unreviewed output.

**The enum** (from the master plan §5 — adopted from the external plan, better than a boolean
because it captures *review state*, not just origin):

```
DOCTOR                   clinician authored it
AI                       AI-authored, NOT reviewed        ← must not exist after item 3
AI_ACCEPTED_BY_DOCTOR    reviewed, accepted unchanged
AI_EDITED_BY_DOCTOR      reviewed, modified               ← richest learning signal
AI_REJECTED_BY_DOCTOR    proposed, declined
```

**Where it is stored.** Two different problems, two mechanisms:

| Target | Mechanism | Notes |
|---|---|---|
| **Encounter child rows** (`Drug Prescription`, `Lab Prescription`, diagnoses, symptoms…) | `custom_ai_provenance` (Select) via `fixtures/custom_field.json` | Core doctypes — custom fields only (Rule 1). Uninstall-safe (Rule 2) |
| **Patient-level fields** (`allergies`, `medication`, `medical_history`, `patient_details`) | Free text, no per-item row → record provenance on the **feedback row** (item 1) and on the review action, not on the field | Do **not** try to annotate free text |
| **Encounter free text** (`encounter_comment` JSON: chief complaint, HPI, education) | One key inside the existing JSON blob, e.g. `_provenance: {chief_complaint: "AI_EDITED_BY_DOCTOR"}` | No schema change; already a JSON field |

**Backend changes**

| File | Change |
|---|---|
| `fixtures/custom_field.json` | Add `custom_ai_provenance` Select to the encounter child doctypes that carry AI-suggestible rows |
| `api/v1/encounters/api.py::save_draft` | Accept and persist provenance per row; **default `DOCTOR`** when absent, so a manual save is never mislabelled |
| `api/v1/encounters/api.py::_apply_drug_prescriptions` (and the lab/procedure/therapy equivalents) | Pass provenance through the existing validation path |
| `patches/v0/backfill_ai_provenance_<date>.py` | Set existing rows to `NULL`, **not** `DOCTOR`. Historical rows are genuinely unknown; asserting `DOCTOR` would be a fabrication and would poison the very corpus this exists to protect |

**Frontend changes** — `encounter-screen.tsx`

`applySuggestionToEnc` already knows a value came from a suggestion. Stamp `AI` at that
moment; flip to `AI_ACCEPTED_BY_DOCTOR` / `AI_EDITED_BY_DOCTOR` when the physician confirms
or edits; send with `save_draft`.

**Test** — `tests/encounters/test_provenance.py`: manual save → `DOCTOR`; AI suggestion
accepted unchanged → `AI_ACCEPTED_BY_DOCTOR`; accepted then edited → `AI_EDITED_BY_DOCTOR`;
absent provenance → `DOCTOR` not `NULL`; backfilled rows stay `NULL`.

**Unblocks.** Items 1 and 3, exclusion of AI-influenced cases from any future evidence pool
(master plan §8.3 — practice entrenchment), and the ability to answer "how much of this
signed record did the AI write?"

---

## Item 3 — Route the 5 patient-level tools through review 🔴 RULE 6 + COMPLIANCE · ~2 days

**Problem.** `encounter-screen.tsx:3217-3263` — a `useEffect` fires on `aiDraft` and calls
`updatePatient.mutate(...)` immediately:

```tsx
if (!aiDraft || readOnly || appliedDraftRef.current === aiDraft) return;
…
updatePatient.mutate({ id: patient.name, ...updates });   // ← permanent Patient record
```

`add_allergy`, `add_patient_medication`, `add_medical_history`, `add_surgical_history`,
`set_patient_summary` write **before Save, before Sign, with no confirmation** — and the
"review & add" panel then hides itself, because its new-items list is empty by construction.
The in-code comment states the behaviour plainly.

This is the **only** Rule 6 violation in the system, and it makes `ROADMAP.md`'s NOM-024
§6.2 claim ("AI never auto-writes; physician approval required") inaccurate.

**The backend is already correct** — `services/ai_tools.py` contains **zero** DB mutations,
verified by exhaustion. This is a frontend fix.

**Fix**

| Step | Change |
|---|---|
| 1 | **Delete the auto-apply `mutate` call.** The effect becomes state-only: put the patch into a pending-review state |
| 2 | Render the existing "review & add" panel from that pending state, so it **stays visible until acted on** — it currently disappears because the write already happened |
| 3 | Per-item Accept / Edit / Reject, matching the encounter-suggestion pattern already in `SuggestionCard.tsx` |
| 4 | On accept → `updatePatient.mutate` with `custom_ai_provenance` = `AI_ACCEPTED_BY_DOCTOR` (item 2) |
| 5 | Emit an `AI Suggestion Feedback` row for every decision (item 1) |
| 6 | `set_patient_summary` needs its own treatment — it **overwrites** rather than appends. Show a diff against the current summary; never apply silently, even when the field is empty |

**Migration question to decide, not to guess:** existing `Patient` rows already contain
AI-written allergies/history from this path. They are indistinguishable from
doctor-entered data. Options: (a) leave and accept the contamination, marking the cutoff
date; (b) flag records touched during the affected window as `unknown` provenance. **(b) is
recommended** — the window is knowable from `AI Encounter Chat Message` creation dates —
but it is a data decision, so it needs sign-off.

**Test** — `tests/ai/test_patient_draft_review.py`: `patient_draft` returned → **no**
`Patient` write occurs; panel state populated; on accept → write with provenance; on reject →
no write and a feedback row; `set_patient_summary` never overwrites without explicit accept.

**Unblocks.** Rule 6 restored. NOM-024 §6.2 claim becomes true. Dataset contamination stops
at source — which is the precondition for *any* learning work.

---

## Item 1 — Persist doctor feedback 🔴 THE STRATEGIC ONE · ~1 week

**Problem.** `use-copilot.ts:443-445` is the entire implementation:

```ts
const setStatus = React.useCallback((id: string, status: SuggestionStatus) => {
  setSuggestions((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
}, []);
```

React state. No network call; no BFF route under `src/app/api/ai/` receives a suggestion
status. On tab close it is gone. **~1,000 encounters have produced ~0 usable
(suggestion → doctor action) pairs.**

### New doctype: `AI Suggestion Feedback`

Path: `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/ai_suggestion_feedback/`
`autoname: "naming_series:"` → `AISF-.YYYY.-.#####` · `track_changes: 1`

| Field | Type | Notes |
|---|---|---|
| `naming_series` | Select | `AISF-.YYYY.-.#####` |
| `suggestion_id` | Data, `search_index` | Stable within the encounter |
| `encounter` | Link `Patient Encounter`, `search_index` | |
| `patient` | Link `Patient`, `search_index` | Strip on any export |
| `prompt_log` | Link `AI Prompt Log` | **Ties the decision to the LLM call that produced it** |
| `thread` / `turn_index` | Data / Int | Which conversational turn |
| `suggestion_type` | Select | medication, lab, diagnosis, vital, procedure, therapy, symptom, chief_complaint, allergy, patient_medication, medical_history, surgical_history, patient_summary, follow_up, review_details |
| `target` | Data | `orders.rx`, `diagnoses`, `vitals.temp`, … |
| `ai_output_json` | Long Text | The full suggestion object, verbatim |
| `ai_confidence` | Float | As emitted |
| `evidence_span_json` | Long Text | Transcript offsets — **item 6** |
| `retrieval_sources_json` | Long Text | Tools/cohorts that informed it |
| `tools_called_json` | Long Text | Names + args + result **shape** — item 6 |
| `model` · `prompt_version` · `prompt_hash` · `reasoning_effort` | Data | |
| `doctor_action` | Select | `accepted`, `edited`, `rejected`, `ignored`, `superseded` — **`ignored` ≠ `rejected`, never merge them** |
| `doctor_final_value_json` | Long Text | What was actually signed |
| `field_level_diff_json` | Long Text | *Which* field changed — "right drug, wrong dose" is a different lesson from "wrong drug" |
| `reason_code` | Select | Mandatory on reject/edit — list below |
| `reason_note` | Small Text | Optional free text |
| `time_to_decision_ms` | Int | **Automation-bias detector.** A 400 ms accept is not a review |
| `decided_at_stage` | Select | `inline`, `at-save`, `at-sign` |
| `provenance` | Select | The item-2 enum |
| `practitioner` | Link `Healthcare Practitioner` | Inter-doctor variation |
| `patient_age_months` | Int | **Months** — not the broken integer years |
| `patient_weight_kg` | Float | Without it no dose label is interpretable |
| `encounter_signed` | Check | |
| `schema_version` | Int | Default 1 |

**Reason codes** (controlled — free text is analytically worthless at scale):
`wrong_drug` · `wrong_dose` · `wrong_frequency` · `wrong_duration` · `wrong_formulation` ·
`contraindicated` · `already_prescribed` · `not_available` · `patient_refused` ·
`not_indicated` · `insufficient_evidence` · `duplicate` · `other`

**Permissions** — `patches/v0/eb_docperm_spec.json`, following the `AI Encounter Session`
pattern: `EB_Practitioner` / `EB_Nurse` create+read+write, no delete; `EB_Healthcare Admin`
read; `System Manager` full.

### Backend

| File | Change |
|---|---|
| `api/v1/ai/api.py` | New `record_suggestion_feedback(encounter, feedback_json)` — **batch**, accepting an array. One request per decision would be chatty during a busy review |
| | `_require_auth` + `_require_encounter_read`; best-effort insert (Rule 7 — a feedback failure must never block clinical work); log IDs only (Rule 10) |
| `services/ai_feedback.py` (new) | Validation, reason-code enforcement, diff computation, insert |
| `api/v1/ai/api.py::ask_copilot` | Return the `prompt_log` name in the response so the frontend can attach it to feedback |

### Frontend

| File | Change |
|---|---|
| `use-copilot.ts:443` | `setStatus` also records `decidedAt` timestamp and pushes to a pending-feedback queue |
| | Reason-code prompt on reject/edit — a small inline select, not a modal. **If this adds friction, capture `other` and move on**; a rejection without a reason is still better than nothing, but the codes are what make the data usable |
| `encounter-screen.tsx` | Flush the queue on save, on sign, and on unmount (`sendBeacon` for unmount) |
| `src/app/api/ai/suggestion-feedback/route.ts` (new) | Standard BFF: `getAccessToken()` → `frappeFetch(...)` → `frappeErrResponse()` |

**Test** — `tests/ai/test_suggestion_feedback.py`: accept/edit/reject each persist correctly;
reject without `reason_code` is refused; `ignored` distinct from `rejected`; batch insert;
permission denied cross-encounter; an insert failure does not raise to the caller.

**Unblocks.** Everything in the master plan §4 and §14. Also the first genuinely useful
report: **rejection clusters by reason code** — most will be fixable by a tool or a prompt
line in an afternoon, which is worth far more than any model work.

---

## Item 6 — Observability 🟠 ~3 days

> **SHIPPED 2026-08-14 — PR #311 (open).** All four parts. Anthropic $8.0351 -> **$0.9988**; cached input discounted; **234 test rows purged** ($169 fabricated cost); tool args logged as shape. 21 tests.

Four independent pieces. Ship in this order.

### 6a — `evidence_span` on clinical write tools *(the important one)*

Today the tool schemas make grounding **structurally unrecordable** — there is no field for
"which transcript line justified this". That is why an unsupported claim like "paracetamol
taken at home" cannot be traced.

| File | Change |
|---|---|
| `services/ai_tools.py::TOOL_REGISTRY` | Add an `evidence` parameter to the clinical write tools — `{quote: str, start_char?: int, end_char?: int}`. Start with `add_medication`, `add_diagnosis`, `add_allergy`, `add_patient_medication`, `add_vital`; extend after |
| each `_tool_add_*` | Pass `evidence` through onto the returned action |
| `prompts/ask-copilot-v2.txt` | Require a verbatim quote from the transcript. **Do not make it blocking yet** — measure adherence first, then consider a deterministic substring check |

⚠️ **Token cost:** the tool array is ~4,087 tokens and re-sent every round-trip. Adding a
parameter to 5 tools is small, but measure it — the agent path is 92.93% of all input tokens.

### 6b — Tool args and results in the audit trail

`AI Prompt Log.tools_used` stores comma-joined **names only**. Add `tools_detail_json`:
per call, `{name, args_redacted, result_shape, result_count, ms}`.

**Rule 10 boundary — the reason this was never built:** args can contain PHI (`drug_name`,
`diagnosis`). Store **keys and value types**, plus catalog-resolvable identifiers, never free
text. `{"name":"add_medication","args":{"drug_name":"<str:11>","strength":"500"},"result":"added_to_draft"}`
gives you reproducibility without a second copy of the clinical record.

### 6c — Purge test pollution and fix both cost formulas

| Fix | Where |
|---|---|
| Delete ~180 `MagicMock` rows + 65 `model='m'` rows from `AI Prompt Log` | `patches/v0/purge_test_prompt_logs_<date>.py`. **Count and log what is deleted** |
| Stop tests writing to the live log | Tests should use a test site; if they must run against a dev site, guard `log_prompt_call` on `frappe.flags.in_test` |
| Anthropic Sonnet-rate fallback — 8.05× overstatement, confirmed arithmetically | `integrations/anthropic.py:564` — give it the longest-prefix match `openai.py:985-996` already has, over a table containing both vendors |
| Cached-input rate not applied — 46% of agent input is cached | `integrations/openai.py:999-1003` — apply the cached rate to `cached_tokens` |

### 6d — Backfill `prompt_hash`

NULL on 239 of 329 agent rows (73%). New rows are fine (`services/ai.py:482` resolves it).
Historical rows cannot be recovered — the file has changed. **Leave them NULL and document
why**; a fabricated hash is worse than an honest gap.

---

## Sprint shape

| Day | Work |
|---|---|
| 1 | Item 4 (age) — ship it. Item 5 (speaker_label) — ship it |
| 2–3 | Item 2 — provenance schema + fixtures + `save_draft`; decide the item-3 backfill question |
| 4–5 | Item 3 — review gate for the 5 patient-level tools |
| 6–8 | Item 1 — doctype, API, BFF route, frontend queue, reason codes |
| 9 | Item 6a + 6c |
| 10 | Item 6b + 6d; verification queries; update the audit's §17/§19 |

**Two PRs, not one:** items 4+5+6c are independent bug fixes and can merge immediately;
items 1+2+3+6a+6b are the coupled schema change and want a single review.

---

## Definition of done

Each verifiable, not a judgement call:

| Item | Done when |
|---|---|
| 4 | `_resolve_age` returns `"5 months old, female"` for `MRN-2026-0000003`; tests cover 0/5/11/23/24 months + leap year |
| 5 | `SELECT COUNT(*) … WHERE speaker_label IS NOT NULL` climbs from 0 on new sessions; `fallback-*` share is queryable |
| 2 | New encounter rows carry provenance; manual saves read `DOCTOR`; historical rows stay `NULL` |
| 3 | `patient_draft` produces **zero** `Patient` writes until explicit accept; review panel persists until acted on |
| 1 | `AI Suggestion Feedback` row count > 0 and rising; rejects carry a reason code; `time_to_decision_ms` populated |
| 6 | `tools_detail_json` populated with no free-text PHI; `MagicMock` rows = 0; `v3` cost re-computes to ≈$1.00 not $8.04 |

## Explicitly out of scope for P0

Medical knowledge RAG · similar-case retrieval · outcome capture (that is P1) · dose engine ·
interaction engine · any fine-tuning · vector search · SpeechBrain. All of them depend on P0
landing first — and two of them (dose engine, SpeechBrain) cannot even be *sized* until items
4 and 5 give you the data.

## Decisions needed before starting

1. **Item 3 backfill** — flag AI-contaminated historical `Patient` rows as unknown provenance, or leave and mark a cutoff date?
2. **Reason codes** — is an inline select on reject acceptable UX, or should v1 capture the action only and add codes after?
3. **`AI Recommendation Log`** — item 6b largely satisfies what `ROADMAP.md`'s NOM-024 §7 claim needs. Retire the name and point the claim at `AI Prompt Log` + `AI Suggestion Feedback`, or create the doctype?

---

## Handover — picking this up

Everything a new person needs. Last updated 2026-08-14.

### 1. Merge what is already written

Three PRs are open and reviewed-ready. **Merge these before writing anything new** — items 2
and 3 touch `services/ai.py` and would conflict.

| PR | Repo | What |
|---|---|---|
| [#310](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend/pull/310) | Backend | Item 4 — infant age |
| [#311](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend/pull/311) | Backend | Item 6 — observability + cost |
| [#380](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/380) | Frontend | Item 5 — raw speaker index |

**After merging #310, watch for one expected effect:** it edits `ask-copilot-v2.txt`, and the
prompt hash is a component of the Analyze fingerprint — so stored Analyze results are
invalidated and cache hit rate drops to zero until encounters are re-analysed. Correct
behaviour, not a regression.

**After merging #311**, run `bench --site <site> migrate` to apply the purge patch. It was
already applied on `marley.local` (234 rows, $169 fabricated cost). It is idempotent — a
second run finds nothing and logs "table already clean".

### 2. Answer three questions — they block the other half of P0

| # | Question | Blocks | Why it cannot be defaulted |
|---|---|---|---|
| **1** | Existing `Patient` rows already contain unreviewed AI content (allergies, history, summaries) written by the bypass in item 3. Flag the affected window as unknown-provenance, or leave it and record a cutoff date? | Items **2 + 3** | Deciding wrong means either fabricating provenance on real clinical data, or carrying contamination into every future analysis. The window is knowable from `AI Encounter Chat Message` creation dates |
| **2** | Reason codes on reject — an inline select, or capture the action only in v1 and add codes later? | Item **1b** | Reversible, so a default is safe if you want one: capture action-only, add codes in v1.1. But a rejection without a reason is not a label (see §6) |
| **3** | `AI Recommendation Log` is cited by `CLAUDE.md` Rule 6 and `ROADMAP.md` x6 but does not exist. Create the doctype, or repoint the NOM-024 §7 traceability claim? | Item **1a** | This is a regulatory claim, not a naming preference. **Item 6b materially strengthened the second option** — tool arguments and results are now recorded, which is what traceability actually needs |

### 3. Then build, in this order

`2 (provenance) -> 3 (review gate) -> 1 (feedback capture)`

The order is a real dependency, not a preference: item 3's review action must record
provenance, and item 1's feedback row carries it. Full specs are in the sections above.

### 4. What was learned during execution — read before estimating

| Finding | Consequence |
|---|---|
| The backend already accepted `speaker_label` | Item 5 took ~2 hours, not a day. **Check what already exists before scoping** |
| `tools_used` was missing from `field_order` | The doctype JSON has pre-existing inconsistencies. Validate `fields` against `field_order` after any edit |
| `test_analyze_e2e` and `test_document_upload_gate` fail on clean `dev` | A fiscal-year fixture issue, unrelated to AI. **Do not chase it** — verify against clean `dev` before assuming you broke something |
| The frontend has no unit-test runner | Playwright e2e only, no copilot unit tests. Item 1b and 3 are frontend-heavy; decide whether to add vitest, or verify by execution as item 5 did |
| `_estimate_cost` is duplicated per adapter | Both were wrong in different directions. Any pricing change must touch both files |

### 5. Verification queries

After item 5 has been live ~2 weeks — this is the measurement that decides whether speaker
verification is worth building:

```sql
SELECT speaker_label, speaker, COUNT(*) n
FROM `tabAI Transcript Segment`
WHERE speaker_label IS NOT NULL
GROUP BY speaker_label, speaker ORDER BY n DESC;
```

- `fallback-*` share -> how often the silent doctor-default fires
- `diarize:0` rows later corrected to `patient` -> how often speaker 0 is **not** the doctor
- `diarize:2+` share -> how often a third speaker is present

Cost sanity after #311:

```sql
SELECT model, COUNT(*) n, ROUND(SUM(cost_estimate_usd),4) cost
FROM `tabAI Prompt Log` GROUP BY model ORDER BY n DESC;
```

No row should show a `MagicMock` model. Nothing on `gpt-5-mini` should price near Sonnet rates.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-14 | Sarvesh | Initial version (header backfilled from git history) |
