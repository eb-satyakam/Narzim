# Remedisys AI — Master Plan

**Doc status:** living · **Created:** 2026-08-13 by Sarvesh-SocialAngel · **Updated:** 2026-08-14 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Status** | **Authoritative.** The single document to work from |
| **Date** | 2026-08-13 |
| **Supersedes** | `REMEDISYS_LONG_TERM_AI_VISION.md` (deleted 2026-08-13 — fully absorbed here) and the external `REMEDISYS_AI_COMPLETE_VISION_AND_EXECUTION_PLAN.pdf`. Where this and the PDF disagree, **this document wins** |
| **Factual basis** | [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) · [`REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md`](./REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md). Every current-state claim carries a `file:line` |
| **Scope** | Strategy, architecture, and a sequenced plan. No code changes were made producing it |

**How this document was built.** Two independent analyses were merged: a code-grounded
audit of the running system, and an external strategy plan. They agreed on the major
conclusions. Where the strategy plan was better — the provenance model, and treating
fine-tuning as an experiment rather than a milestone — its version was adopted. Where it
was generic, the code-grounded version was kept, because priorities must be calibrated to
what is actually broken. Two internal contradictions in it were resolved, and one
deliberately soft position was hardened.

---

## Table of Contents

1. [What we are building](#1-what-we-are-building)
2. [Current state — the four facts that set the agenda](#2-current-state--the-four-facts-that-set-the-agenda)
3. [The target architecture](#3-the-target-architecture)
4. [The learning loop](#4-the-learning-loop)
5. [Provenance — the foundation](#5-provenance--the-foundation)
6. [The feedback schema](#6-the-feedback-schema)
7. [Decision framework: prompt vs tool vs RAG vs model](#7-decision-framework-prompt-vs-tool-vs-rag-vs-model)
8. [Historical case retrieval — and its safeguards](#8-historical-case-retrieval--and-its-safeguards)
9. [Outcomes](#9-outcomes)
10. [Fine-tuning — as an experiment, not a milestone](#10-fine-tuning--as-an-experiment-not-a-milestone)
11. [Multi-clinic architecture](#11-multi-clinic-architecture)
12. [Privacy and governance](#12-privacy-and-governance)
13. [The roadmap](#13-the-roadmap)
14. [Scale strategy: 1k → 10k → 100k → 1M](#14-scale-strategy-1k--10k--100k--1m)
15. [What not to do](#15-what-not-to-do)
16. [Open questions](#16-open-questions)
17. [Diagrams](#17-diagrams)

---

## 1. What we are building

### The one-paragraph version

Remedisys is a healthcare platform that observes real clinical work — conversations,
tests, drugs, decisions, what the doctor changed about the AI's suggestions, and what
happened to the patient afterwards — and turns that governed, provenance-tracked record
into an evidence system that improves future care. Other clinics eventually buy the
curated general intelligence and layer their own local knowledge on top, isolated. The
doctor makes every clinical decision; the AI supplies evidence and explanation.

### The reframe that changes the plan

The flagship feature is:

> *"I found 32 comparable historical cases. 18 received X, 9 received Y, 5 received
> supportive management."*

**That is a cohort query, not a model.** Define similarity → retrieve → aggregate →
display. No weights, no training.

| | Evidence platform | Trained medical model |
|---|---|---|
| Needs | Structured data + outcomes + similarity definition | All that **plus** 6–7 figures of clean labels, ML staff, eval infra |
| First value | Months | Years |
| Explain a recommendation? | Yes — show the 32 cases | Not reliably |
| Fix a bad recommendation? | Change the query, same day | Retrain, and hope |
| Wrong-answer failure | Visible, traceable | Silent, diffuse |
| Deletion request | Delete the row | Retrain from scratch |

**Roughly 90% of the described value requires zero model training.** The asset is the
**dataset and the retrieval layer**, not the weights. "Remedisys Medical AI" is a fine
external name; internally, know what the asset is.

### The strategic sentence

> **Every appropriate clinical event becomes a governed learning signal, and Remedisys
> decides whether that signal should improve retrieval, evaluation, tools, prompts,
> safety, knowledge — or, only when measurement proves it, model weights.**

Not "every encounter trains the model."

---

## 2. Current state — the four facts that set the agenda

Everything in §13 follows from these. All verified in code, not inferred.

### Fact 1 — The doctor's feedback is computed and then destroyed

```ts
// Healthcare_next_app/src/components/narzim/encounter/copilot/use-copilot.ts:443-445
const setStatus = React.useCallback((id: string, status: SuggestionStatus) => {
  setSuggestions((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
}, []);
```

That is the whole implementation. React state. No network call; no BFF route under
`src/app/api/ai/` receives a suggestion status. On tab close it is gone.

**Consequence:** ~1,000 encounters have produced approximately **zero** usable
(suggestion → doctor action) pairs. The good news is that the UI already computes the
signal correctly — this is a persistence job, not a new feature.

### Fact 2 — AI output is already becoming "ground truth" without review

`encounter-screen.tsx:3217-3263` auto-applies the `patient_draft` patch with an immediate
`updatePatient.mutate(...)`. Five tools — `add_allergy`, `add_patient_medication`,
`add_medical_history`, `add_surgical_history`, `set_patient_summary` — write to the
permanent `Patient` record before Save, before Sign, with no confirmation. The review
panel then hides itself, because its "new items" list is empty by construction.

Separately, `_derive_chief_complaint_if_missing` (`encounters/api.py:150`) machine-generates
a chief complaint so Sign is not blocked.

**Consequence:** the premise *signed = reviewed = ground truth* is false today. Train on
signed encounters now and the model learns partly from its own unreviewed output — model
collapse, which is self-confirming and hard to detect from the inside. **This is an active
bug, not a principle to adopt later.**

### Fact 3 — Input labels are materially noisy, and the noise is unmeasurable

| Problem | Evidence |
|---|---|
| 22% of transcript segments labelled `unknown` | 1,307 of 5,933 live rows |
| Doctor:patient skew 1.8 : 1 in two-party consultations | 2,978 vs 1,648 |
| Three code paths silently default to `"doctor"` | `_groupBySpeaker` no-words case, interim `?? 0`, multichannel `?? 0` |
| Raw Deepgram speaker index discarded | `speaker_label` **NULL on all 5,933 rows** |
| Every patient under 12 months has age `0` | `services/ai.py:880` — `int(date_diff(now,dob)/365)`; verified on 6 live patients incl. `MRN-2026-0000003` (5 months → `0G`) |
| No `evidence_span` field exists in any of the 36 tools | grounded vs invented is **structurally** indistinguishable |

**Consequence:** label noise at the input propagates into every downstream learning signal.
And because the raw speaker index is not stored, *we cannot currently measure whether the
speaker problem is Deepgram's clustering or our mapping* — which blocks the diarization
decision entirely.

### Fact 4 — Assets already exist that the AI cannot see

- **`Treatment Plan Template`** — six age-banded paediatric templates with real structured
  dosing (`scripts/seed/seed_treatment_plan_templates.py`). The URTI template carries
  Paracetamol at `strength: 500`, `dosage: "TID"`, `period: "5 Day"`, instructions
  *"10–15 mg/kg/dose every 6–8 hours… Max 5 doses/day. Use paediatric syrup formulation."*
  Reachable from the **manual** flow (`encounters/api.py:1317`, `:1355`). **Zero references
  in the AI path** — verified across `ai_tools.py`, `ai.py`, and every `prompts/*.txt`.
- **Six retrieval mechanisms**, none vector-based (structured tools, six keyword catalog
  searches, rolling patient summary, cache-or-generate lab reading, catalog-derived
  clinical lexicon, deterministic transcript digest).
- **A well-built tool layer** — 36 tools, bounded, permission-checked, and verified to
  contain **zero** database mutations.

**Consequence:** the highest-value clinical fix available needs no new data, and retrieval
does not need building from scratch.

### What this means for sequencing

The strategy is sound. The dataset it depends on does not exist yet, and three of the four
facts above are things that get **multiplied** by scale rather than fixed by it. Data
quality problems are cheapest to fix at 1,000 encounters.

---

## 3. The target architecture

```
┌─ GLOBAL — Remedisys owns, curates, versions. NO patient data ───────────────┐
│                                                                             │
│  Medical Knowledge Base  → RAG        guidelines · drug refs · dosing · SOPs │
│  Deterministic Engines                paediatric dosing · interactions ·    │
│                                       contraindications · allergy classes   │
│  Tool registry · prompts · extraction logic · evaluation suites              │
│  [only if measured to help] ONE narrow fine-tuned extraction model —         │
│      consented, de-identified, curated data. Never raw records              │
└──────────────────────────────┬──────────────────────────────────────────────┘
                               │  ▲ LESSONS flow up. RECORDS never do.
┌──────────────────────────────┴─ PER CLINIC (isolated tenant) ───────────────┐
│  Patient records              → structured tools (today's 36, extended)     │
│  Historical cases + outcomes  → controlled cohort retrieval (§8 safeguards) │
│  Clinic protocols / formulary → tenant-scoped RAG                          │
│  Feedback + outcomes + evals  → local; drives global tool/prompt changes    │
└──────────────────────────────┬──────────────────────────────────────────────┘
                               ▼
                    LLM — reasoning and language only
             may reason about anything · may assert nothing it did not retrieve
                               ▼
                    Deterministic validation gate
             dose · interaction · contraindication · duplicate · allergy
                               ▼
                    DOCTOR — reviews, edits, signs
                               ▼
        Signed record + provenance + structured feedback + outcome
                               │
                               └──► improves TOOLS · PROMPTS · KNOWLEDGE · EVALS
                                    (weights only rarely, narrowly, and last)
```

**The property that makes this safe:** the improvement loop terminates in tools, prompts,
knowledge and evaluations — all inspectable, versionable, instantly reversible, and
explainable to a regulator. Weights are none of those.

**The rule that makes the LLM safe:** *reasoning is unbounded; authority is bounded.*

### On keeping the LLM central

Tools do not make the LLM a thin caller. They constrain its **authority**, not its
**reasoning**. Today it reads a whole consultation, chooses among 36 tools and their
ordering, synthesises results, weighs allergies against contraindications, and writes
clinical prose. That is deep reasoning.

What is wanted from it — comparing historical evidence, using medical knowledge — is not
blocked by the tool architecture. It is blocked by **those tools not existing yet**. The
answer is more and better tools, not fewer constraints. An LLM that asserts only what it
retrieved can be trusted with harder problems.

---

## 4. The learning loop

```
   CLINICAL ACTIVITY
   conversation · vitals · labs · imaging · orders · procedures · therapies
        ▼
   AI UNDERSTANDING
   Deepgram → transcript (+ raw speaker_label persisted)
   ask_copilot agent · 36 tools · medical RAG · historical cohorts
        ▼
   RECOMMENDATION + EVIDENCE
   every clinical suggestion carries an evidence_span
        ▼
   SAFETY VALIDATION
   deterministic: dose · interaction · contraindication · duplicate
        ▼
   DOCTOR REVIEW
   sees the suggestion, its transcript evidence, and any deterministic warning
        ▼
   ACCEPT / EDIT / REJECT        ← ✱ CAPTURED, NOT DISCARDED ✱   (broken today)
   + reason_code + field-level diff + time_to_decision
        ▼
   FINAL SIGNED DECISION
   every value carries a provenance value (§5)
        ▼
   FOLLOW-UP OUTCOME
   structured, at a defined point
        ▼
   GOVERNED LEARNING SIGNAL
        ├──► EVALUATION SET        highest value · available immediately
        ├──► COHORT EVIDENCE       §8 safeguards · AI-influenced cases excluded
        ├──► GOVERNANCE REPORTS    guideline divergence · treatment variance
        └──► TRAINING CANDIDATE    only via §10's experiment · consented · de-identified
        ▼
   BETTER AI — tools · prompts · knowledge · validators (weights last)
```

**The two arrows that do not exist today:** `ACCEPT/EDIT/REJECT → captured` and
`SIGNED → outcome`. Everything else already runs.

### What one encounter produces

| Artifact | Value | Available when |
|---|---|---|
| **Evaluation case** | Highest — makes every other change measurable | From ~200 cases, immediately |
| **Governance data** | Guideline divergence, treatment variance | ~1,000+ |
| **Aggregate evidence** | "In 32 similar cases…" | ~5–10k *per presentation* |
| **Retrieved example** | Shown to doctor or given to the LLM | ~10k+, with §8 safeguards |
| **Training example** | Changes weights | Only via §10, possibly never |

The order of value is the reverse of where most teams start.

---

## 5. Provenance — the foundation

Every clinically meaningful value carries one of five values:

```
DOCTOR                    the clinician authored it
AI                        AI-authored, NOT reviewed        ← must be visible and excluded
AI_ACCEPTED_BY_DOCTOR     AI-authored, reviewed, accepted unchanged
AI_EDITED_BY_DOCTOR       AI-authored, reviewed, modified  ← the richest learning signal
AI_REJECTED_BY_DOCTOR     AI proposed, doctor declined
```

Why this and not a boolean: it captures the **review state**, not just the origin. That is
exactly the filter a learning corpus needs, and exactly what tells you whether Fact 2's
contamination is still occurring.

**Rules derived from it:**

| Rule | Reason |
|---|---|
| `AI` (unreviewed) is **excluded** from every learning corpus and evidence pool | Otherwise the model learns from itself |
| `AI` should not exist at all after P0 | Fact 2 is a bug; the fix is routing those 5 tools through review |
| `AI_EDITED_BY_DOCTOR` is the highest-value signal | It shows *what specifically* was wrong |
| Cohort queries **exclude AI-influenced encounters**, or track them separately | Prevents §8.2 entrenchment |
| Provenance is per **field**, not per document | "Right drug, wrong dose" needs field granularity |

---

## 6. The feedback schema

```
AI Suggestion Feedback
──────────────────────────────────────────────────────────────────────────────
IDENTITY
  suggestion_id             stable across the encounter lifetime
  encounter_id · patient_id link
  prompt_log_id             ← links the suggestion to the LLM call that produced it
  thread_id · turn_index    which conversational turn produced it

WHAT THE AI PROPOSED
  suggestion_type           medication | lab | diagnosis | vital | procedure | …
  target                    orders.rx | diagnoses | vitals.temp | …
  ai_output_json            the FULL suggestion object, verbatim
  ai_confidence             as emitted
  ai_reasoning              the model's stated basis
  evidence_span             transcript offsets / quote the suggestion rests on   ★ NEW
  retrieval_sources_json    which tools/RAG docs/cohorts informed it            ★ NEW
  tools_called_json         names + ARGUMENTS + result shape                    ★ NEW
  model · prompt_version · prompt_hash · reasoning_effort

WHAT THE DOCTOR DID
  doctor_action             accepted | edited | rejected | ignored | superseded
                            ('ignored' ≠ 'rejected' — never merge them)
  doctor_final_value_json   what was actually signed, if anything
  field_level_diff_json     WHICH field changed                                 ★ NEW
  reason_code               controlled vocabulary, mandatory on reject/edit      ★ NEW
  reason_note               optional free text
  time_to_decision_ms       automation-bias detector                            ★ NEW
  decided_at_stage          inline | at-save | at-sign                          ★ NEW

CONTEXT (required for any later analysis)
  provenance                the §5 enum                                         ★ NEW
  doctor_id                 pseudonymous — for inter-doctor variation
  patient_age_months        MONTHS, not the broken integer years                ★ NEW
  patient_weight_kg         without this no dose label is interpretable         ★ NEW
  baseline_severity         if captured — the confounding control (§9)          ★ NEW
  encounter_signed          bool

VERSIONING
  created_at · schema_version · feature_flags_snapshot
```

**Reason codes — controlled, ~12 to start, mandatory on reject and edit:**

`wrong_drug` · `wrong_dose` · `wrong_frequency` · `wrong_duration` · `wrong_formulation` ·
`contraindicated` · `already_prescribed` · `not_available` · `patient_refused` ·
`not_indicated` · `insufficient_evidence` · `duplicate` · `other`

Free-text reasons feel friendlier and are analytically worthless at scale.

### Why a rejection without a reason code is not a label

"Doctor rejected X" is at least seven different signals:

| The doctor meant | Correct signal |
|---|---|
| X is clinically wrong here | **Negative** — real error |
| X is right but already prescribed elsewhere | **Neutral** — fix retrieval, not the model |
| X is not on formulary / unavailable | **Neutral** — operational |
| Patient cannot afford X | **Neutral** — socioeconomic |
| Patient or parent refused | **Neutral** — preference |
| I prefer Y, both acceptable | **Weak preference** — style |
| I was in a hurry and Y was one click away | **Noise** — actively harmful if learned |

Train on the raw flag and you optimise for *suggestions that get accepted*, which is not
*suggestions that are correct*. That is how a sycophantic model gets built.

### The three highest-value additions

1. **`evidence_span`** — without it, grounded and hallucinated suggestions are
   indistinguishable. Note this is a **tool-schema change**, not a data-collection task:
   no field for it exists in any of the 36 tools today.
2. **`reason_code`** — without it a rejection is not a label.
3. **`time_to_decision_ms`** — the only cheap detector for the fact that *the approval
   signal degrades as adoption grows*. Better AI → less careful reading → your quality
   metric erodes exactly when volume rises. A 400 ms accept is not a review.

---

## 7. Decision framework: prompt vs tool vs RAG vs model

### What each actually changes

> **Retrieval changes what the model KNOWS. Fine-tuning changes how it BEHAVES.
> Tools change what it can DO. Prompting changes what it TRIES to do.**

| Technique | Good for | Bad for | Time to change |
|---|---|---|---|
| **Prompting** | Behaviour, format, safety rules | Facts; reliability under pressure | Minutes |
| **Tools** | Authoritative facts, permissions, writes, catalogs | Judgement, language | Hours |
| **RAG** | Facts that change; large reference bodies; citations | Behaviour, format, skill | Minutes (re-index) |
| **Fine-tuning** | Format adherence, domain vocabulary, narrow repeated tasks | **Facts.** Anything that changes or needs a citation or must be deletable | Days–weeks per update |

**Clinical facts must never live in weights.** They change, they cannot be cited, and they
cannot be removed on request — which matters under both applicable privacy regimes.

### The diagnostic table — use this when something is wrong

| Symptom | Fix |
|---|---|
| Missing or wrong dose | **Deterministic validator** + schema (not a prompt line) |
| Missing current patient medication | **Structured tool** |
| Missing guideline knowledge | **RAG** |
| Missing similar cases | **Historical retrieval** |
| Wrong output format | **Prompt**, then schema-locked output |
| Wrong tool chosen | **Prompt** + better tool descriptions |
| Repeated reasoning error | **Evaluation case first** → then prompt/tool/retrieval → fine-tuning only if measured |
| Suggestion not grounded in transcript | **`evidence_span`** + validator |

### Which concepts apply to Remedisys

| Concept | Verdict |
|---|---|
| **LLM** | ✅ Core — reasoning and language |
| **Tools / structured retrieval** | ✅ Core; already built and good |
| **RAG** | ✅ For reference knowledge only (§11 global layer) |
| **Fine-tuning** | ⏳ Only via §10's experiment; narrow tasks; never medical knowledge |
| **Continual / online learning** | ❌ Unvalidatable and un-auditable clinically. "Continual" here means continual *data growth*, i.e. retrieval |
| **RL / DPO / preference optimisation** | ⏳ Needs clean preference pairs with reason codes. Far off |
| **Structured clinical data** | ✅ The actual asset |

---

## 8. Historical case retrieval — and its safeguards

The flagship feature. Achievable. Also has a failure mode nobody mentions.

### 8.1 The three-way distinction to keep in the UI language

| | Meaning | Allowed phrasing |
|---|---|---|
| **Historical practice** | What doctors here previously did | "18 of 32 received X" |
| **Clinical evidence** | What current trusted evidence supports | "Guidelines recommend…" (from RAG, cited) |
| **AI recommendation** | What may be worth considering now | "Consider…" with its basis named |

Never let the first be presented as the second. *"X was used most often"* is not
*"X is proven."*

### 8.2 Mandatory safeguards

| Risk | Safeguard |
|---|---|
| Small samples | Hard minimum **n ≥ 20**; never display n < 10 |
| **Duplicate encounters** | Deduplicate **by patient, not by encounter** — one asthmatic child with 14 visits is not 14 cases |
| **Data leakage** | **Exclude the current patient's own history** — otherwise the system shows the doctor their own note as evidence |
| Outdated practice | Recency window (e.g. 24 months); always display the date range |
| Different context | Show the **cohort definition on screen** — age band, sex, presentation, comorbidities — so the doctor can disagree with it |
| Selection bias | State what was excluded, especially patients lost to follow-up |
| Copying old mistakes | **Never rank by outcome.** Show the distribution of what was done |
| Correlation as causation | Language discipline enforced in **both** the prompt and the UI template: "was used", never "works" |
| Confounding | No outcome comparison at all in v1 (§9) |
| Entrenchment | §8.3 |

### 8.3 The failure mode nobody mentions: practice entrenchment

The panel says *"18 of 32 received X."* Doctors are busy and it is right there. X gets
prescribed a little more often. Next quarter: 22 of 34. Then 28 of 36.

**You have built a machine that amplifies your clinic's existing habits and presents the
amplification as evidence** — including the parts it was doing wrong. Rising consensus
looks exactly like rising quality. This is invisible from inside the product.

Three defences:

1. **Exclude AI-influenced encounters from the evidence pool** (needs §5 provenance). If
   you cannot distinguish influenced from independent cases, the evidence base is eating
   itself.
2. **Monitor treatment variance as an alarm, not a success metric.** Falling diversity for
   a presentation is a warning.
3. **Always show the outliers.** "5 of 32 were treated differently" is often the
   clinically interesting line.

### 8.4 The structural limitation to be honest about

Similar-case retrieval is most reliable for common presentations, where an experienced
doctor needs least help — and least reliable for rare ones, where help matters most.
**The feature is most reliable where it is least needed.** Real value remains: consistency,
training juniors, locum support. Just do not expect a clinical breakthrough.

---

## 9. Outcomes

### 9.1 Capture now, analyse much later

Outcomes cannot be backfilled, so start immediately. Do not build analytics on them for
years.

**Taxonomy:** `resolved` · `improved` · `unchanged` · `worse` · `referred` ·
`hospitalized` · `lost_to_follow_up` · `other`

Plus, per condition: a defined **measurement point** ("at day 7", not "eventually").

### 9.2 Why naive outcome analysis produces backwards answers

The specific killer is **confounding by indication**: doctors give stronger treatment to
sicker patients. In observational data the stronger treatment therefore appears to have
*worse* outcomes — not because it is worse, but because of who received it. A naive
"which treatment had the best outcomes?" query on EHR data reliably produces inverted
results. This is one of the most repeatable errors in health data science, and it is why
randomised trials exist.

### 9.3 What would be needed for outcome analysis to be meaningful

| Requirement | Have it? |
|---|---|
| Structured outcome definition per condition | ❌ |
| Defined measurement point | ❌ |
| **Baseline severity at presentation** | ❌ — without it, confounding is unaddressable |
| Adherence (did the patient take it?) | ❌ |
| **Loss-to-follow-up tracking** | ❌ — patients who worsen often go elsewhere, so successes are over-observed |
| Adverse-event capture | ❌ |
| Comorbidities, structured | ⚠️ Free text |
| Weight, linked to dosing | ⚠️ In `Vital Signs`, unlinked from the AI path |
| Enough cases per condition | ❌ Not yet |

Items 3, 4 and 5 are what turn outcome analysis from "hard" into "actively misleading."

### 9.4 Describe, do not infer — for a long time

| Safe | Unsafe |
|---|---|
| "In 32 similar cases, 18 received X" | "X works better" |
| "3 of 32 returned within 7 days" | "X has a 10% failure rate" |
| "This clinic's usual approach is…" | "The recommended treatment is…" |

The descriptive version is genuinely useful and defensible. The causal version needs a
study design, an epidemiologist, and a regulatory conversation.

---

## 10. Fine-tuning — as an experiment, not a milestone

### 10.1 The decision procedure

Do **not** gate on encounter count. Encounter count is not the constraint; clean labelled
examples for one specific task are. Run this instead:

```
                    ONE FIXED CLINICAL EVALUATION SET
                                  │
        ┌─────────────────┬───────┴────────┬──────────────────┐
        ▼                 ▼                ▼                  ▼
  Base LLM          Base LLM +      Base LLM + RAG      Fine-tuned +
  + tools           tools + RAG     + tools + few-shot  RAG + tools
                                    from accepted cases
        └─────────────────┴────────────────┴──────────────────┘
                                  │
                                  ▼
                    Score: clinical quality · safety flags
                           latency · cost · explainability
                                  ▼
                    Ship the winner. Often it is not the fine-tuned one.
```

Fine-tune only when it produces a **measured** benefit on a frozen eval set that the
cheaper options do not. Note the third column — few-shot retrieval from accepted examples
captures much of fine-tuning's benefit, updates instantly, and stays auditable. It usually
wins on total cost.

### 10.2 Candidate training targets — and the one that is ruled out

| Target | Verdict |
|---|---|
| **Transcript → structured extraction** (symptoms, vitals, meds mentioned) | ✅ **Best candidate.** Narrow, objectively checkable, no clinical judgement |
| **Speaker re-segregation** | ✅ Good candidate — already has a deterministic verifier (word-multiset veto) |
| **Schema/format adherence** for suggestion objects | ✅ Good candidate |
| **AI suggestion → doctor correction** (with reason codes) | ⚠️ Later, and only with clean reason codes. Without them it is noise (§6) |
| **Clinical case → approved final decision** | ❌ **RULED OUT.** This is imitation learning on practice. It trains the model to reproduce your clinic's habits *including its errors*, fluently and confidently. It directly contradicts §8.3 and §13's guideline-divergence goal. Retrieve practice; never train on it |
| **Outcome-linked cases** | ❌ Not until §9.3's requirements are met |

**Note:** the external plan listed "clinical case + approved final decision" as a training
candidate while elsewhere warning that historical practice amplifies mistakes. Those two
positions are incompatible. This document resolves it against training on practice.

### 10.3 What fine-tuning cannot fix

Facts, currency, citations, deletability. If the answer needs to be *correct today* and
*attributable*, it belongs in retrieval or a validator.

---

## 11. Multi-clinic architecture

### 11.1 The shape

```
        ┌──────────── REMEDISYS GLOBAL ───────────────────────┐
        │  Curated · versioned · NO patient data              │
        │                                                     │
        │   Medical Knowledge (RAG)    Deterministic Engines  │
        │   guidelines · drug refs     paediatric dosing      │
        │   dosing tables · SOPs       interactions           │
        │                              contraindications      │
        │   Tools · prompts · extraction · evaluation suites   │
        └───────────────────────┬─────────────────────────────┘
                    ▲ LESSONS   │ knowledge, tools, validators
      ┌─────────────┼───────────┼───────────────┐
      ▼             ▼           ▼               ▼
 ┌ CLINIC A ─┐ ┌ CLINIC B ─┐ ┌ CLINIC C ─┐
 │ Patient   │ │ Patient   │ │ Patient   │   → structured tools
 │ Cases     │ │ Cases     │ │ Cases     │   → controlled retrieval
 │ Protocols │ │ Protocols │ │ Protocols │   → tenant-scoped RAG
 │ Feedback  │ │ Feedback  │ │ Feedback  │   → local evals
 └─────┬─────┘ └─────┬─────┘ └─────┬─────┘
       ▼             ▼             ▼
   Clinic AI     Clinic AI     Clinic AI      (global + local)
       ▼             ▼             ▼
   Doctor        Doctor        Doctor

 ══════════════════════════════════════════════════════════════════
  NO PATIENT DATA CROSSES A TENANT BOUNDARY.
  What flows up: aggregate LESSONS — "dose rejections cluster on
  paediatric syrups" — which become better global TOOLS, PROMPTS and
  VALIDATORS, flowing back to every clinic.
  Cross-clinic improvement WITHOUT cross-clinic data.
 ══════════════════════════════════════════════════════════════════
```

### 11.2 Should clinic data ever train the global model? **No.**

This is a clear position, not a "to be governed later." Four independent reasons, any one
sufficient:

1. **Legal.** Under LFPDPPP (Mexico) and DPDPA 2023 (India) — both active per ADR-018 —
   secondary use for building a commercial model is a **different purpose** from care
   delivery. It generally requires explicit, informed, revocable consent.
   De-identification does not by itself create a lawful basis.
2. **Contractual.** Clinic B will ask in the first sales call: *"is my data training a
   model my competitor uses?"* "Your data never leaves your tenant" is a **feature**.
3. **Technical.** Weights cannot be unlearned. One clinic leaving, one consent withdrawn,
   one deletion request — the only correct remedy is retraining from scratch.
4. **Quality.** Clinic A's habits become Clinic B's defaults. That is one clinic's practice
   style exported under a scientific label.

**If cross-clinic pooling is ever wanted**, the path is a **separate, explicitly consented
research dataset** with its own governance — never a side effect of using the product.

---

## 12. Privacy and governance

### 12.1 Why removing the name is not enough

**Re-identification from quasi-identifiers.** Name removed; the record still reads:
5-month-old male, DOB 2026-03-03, this clinic, rare congenital condition. In one paediatric
clinic in one city that is very likely one identifiable child. A handful of innocuous
fields — DOB, sex, postcode — uniquely identify most people, and rare diagnoses make it
worse.

**Free text is where PHI hides.** *"the mayor's daughter"*, *"works at the pharmacy on the
corner"*, *"seen with her twin brother"*. Your own `pii_redaction.py` documents this limit
honestly — regex and label matching cannot catch a name in unlabelled prose. Note it
protects the *general assistant*, not the encounter path.

**Model memorisation inverts intuition.** Fine-tuned models reproduce rare training
sequences verbatim, and the *rarer and more distinctive* a record is, the more likely it is
memorised. **Your most sensitive patients are at the highest risk of leaking.** This alone
argues against training on raw clinical text.

**Consent is a purpose question, not an anonymity question.** Whether you may use care data
for product development is not settled by de-identifying it.

**Retrieval scope is a privacy decision.** Every token retrieved into a prompt is
transmitted to OpenAI or Anthropic. Improving retrieval *increases* PHI transmission. That
can be an acceptable trade — but it must be a decision, not a side effect of a relevance
tweak.

### 12.2 The controls, in order

| Control | Meaning | When |
|---|---|---|
| **Tenant isolation** | Every query, index and cache scoped to one clinic. No shared vector index, no content-keyed shared cache | 🔴 Before clinic #2 |
| **Field-level provenance** | §5 enum on every clinical value | 🔴 P0 |
| **Auditability** | Who saw which patient's data, when, through which feature. Extend the existing per-call logs to retrieval | 🟠 With retrieval features |
| **Consent model** | Separate *care* use from *product-improvement* use, per patient, revocable | 🟠 Before any cross-encounter learning |
| **De-identification pipeline** | Structured stripping + free-text scrubbing + **date shifting** + **quasi-identifier generalisation** (age bands, not DOB) | 🟠 At the export boundary only |
| **k-anonymity checks** | Refuse to release a cohort where a field combination identifies fewer than k patients | 🟠 With cohort features |
| **Training-data governance register** | What data, whose consent, which model version, retention, deletion path | 🟡 Before any fine-tuning |

**De-identification belongs at the export boundary, not in the main pipeline.** Inside the
tenant, for the treating clinician, you need the real record.

---

## 13. The roadmap

Priorities calibrated to §2. Every P0 item is justified by a verified defect, not by
best practice in the abstract.

### P0 — now (roughly one sprint)

> **Progress 2026-08-14: items 4, 5 and 6 are DONE** (PRs #310, #380, #311 — open, not merged).
> Those were the three needing no decisions. Items 1, 2 and 3 are blocked on the three
> decisions in §16, not on engineering. Live status and handover:
> [`P0_IMPLEMENTATION_PLAN.md`](./P0_IMPLEMENTATION_PLAN.md).

| # | Item | Why it is P0 |
|---|---|---|
| 1 | **Persist Accept/Edit/Reject with reason codes** (§6) | Nothing in the plan works without it. The UI already computes it (`use-copilot.ts:443`) and discards it. **Every day is permanently lost data** |
| 2 | **Field-level provenance** — the §5 five-value enum | Prerequisite for excluding AI output from learning, and for §8.3 |
| 3 | **Route the 5 patient-level tools through doctor review** (`encounter-screen.tsx:3217-3263`) | Closes the Rule 6 gap **and** stops dataset contamination at source. One fix, two problems |
| 4 | **Fix age** — send months + DOB, not `int(days/365)` (`services/ai.py:880`) | Every infant record is corrupted, in a paediatric clinic |
| 5 | **Persist `speaker_label`** (raw Deepgram index) | One field. Without it the diarization question is unanswerable and the SpeechBrain decision cannot be made |
| 6 | **Observability**: `evidence_span` + tool args/results + purge test rows + fix both cost formulas | Reproducing an AI decision is currently impossible; every cost figure is wrong |

### P1 — next

| # | Item |
|---|---|
| 7 | **Wire `Treatment Plan Template` as a tool** — age-banded paediatric dosing already exists in the DB. Highest-value clinical fix available, no new data needed |
| 8 | **Deterministic dose validator** — reject strength `0`; check against age/weight band; read `Vital Signs.weight` |
| 9 | **Evaluation suite — 300 curated cases**, frozen and versioned |
| 10 | **Outcome capture** at follow-up (§9.1 taxonomy + measurement point) |
| 11 | **Rejection-cluster analysis** — most rejections will be fixable by a tool or prompt line in an afternoon |
| 12 | **Tenant-isolation review** — before clinic #2 |

### P2 — after P1 is measured

| # | Item |
|---|---|
| 13 | Medical knowledge base + RAG (global layer) |
| 14 | Deterministic interaction and contraindication engines |
| 15 | Historical case retrieval with **all** §8 safeguards |
| 16 | Clinical cohort engine (structured features first, not embeddings) |
| 17 | Governance reports — guideline divergence, treatment variance over time |
| 18 | Few-shot retrieval from accepted examples |

### P3 — only when P2 is measured

| # | Item |
|---|---|
| 19 | Consented, de-identified research corpus with its own governance |
| 20 | §10's fine-tuning experiment on narrow subtasks |
| 21 | Cross-clinic *lesson* aggregation (never record pooling) |

**P0 items 1–5 are worth more to the long-term vision than a year of model work.**

---

## 14. Scale strategy: 1k → 10k → 100k → 1M

**The gate is never encounter count. It is clean labelled examples for one specific task.**
1M encounters without reason codes are worth less for learning than 20,000 with them.

| Stage | What you actually have | Do | Do NOT |
|---|---|---|---|
| **~1,000 (today)** | ~0 usable labels · contaminated provenance · corrupted infant ages | P0 in full. Start the eval set. Connect existing structured data | Anything ML |
| **10,000** | ~5–8k feedback events *if capture ships now*. Top 5 presentations viable | Rejection-cluster analysis → tool/prompt fixes. Eval set → 500. Medical RAG. Outcomes accumulating | Fine-tune. Show similar cases yet |
| **100,000+** | Meaningful cohorts for common presentations. Real follow-up data | Historical retrieval with §8 safeguards. Few-shot from accepted cases. Cohort analytics. Governance reports. Identify narrow ML tasks | Causal claims. Cross-clinic training |
| **500k–1M+** | A substantial governed clinical asset, multi-clinic, multi-doctor | Run §10's experiment. Decide per component what is shared / retrieved / fine-tuned / clinic-specific | Assume scale fixed label quality — it never does |

---

## 15. What not to do

1. **Do not train automatically from every signed encounter.** Signature ≠ correctness.
2. **Do not treat a signature as proof of correctness.** It is a responsibility marker.
3. **Do not let AI output silently become ground truth.** It is happening today (Fact 2).
4. **Do not treat prescription frequency as efficacy.** Frequency is habit, not evidence.
5. **Do not train on "clinical case → approved final decision."** Imitation learning on
   practice entrenches error (§10.2).
6. **Do not use RAG for exact patient retrieval.** Patient facts stay on structured tools.
7. **Do not add a vector database yet.** The retrieval failures are structural — opt-in
   retrieval, tail truncation, unbounded catalogs — not semantic. Six retrieval mechanisms
   already exist.
8. **Do not pool clinic patient data across tenants.** §11.2.
9. **Do not build a foundation model.** The asset is the dataset and retrieval layer.
10. **Do not do online / continual weight learning.** Unvalidatable and un-auditable.
11. **Do not infer causation from observational data.** Confounding by indication (§9.2).
12. **Do not build SpeechBrain / speaker verification yet.** The problem cannot currently be
    measured (P0 item 5). Measure first.
13. **Do not show similar cases without every §8 safeguard**, including dedup-by-patient and
    excluding the current patient's own history.

---

## 16. Open questions

Ordered by how much they block.

1. **What is an "outcome" for the top 10 presentations?** Clinically defined, structured,
   measurable at a stated point. A clinician must answer this; nothing in §9 works until
   they do.
2. **What defines two cases as similar?** Structured criteria the doctor can see and
   override — not an embedding.
3. **Do patients consent to secondary use?** Required before any learning leaves the care
   context.
4. **How many distinct doctors are in the data?** If 3–5, you are modelling individuals,
   not medicine.
5. **What is the follow-up rate?** Low rates bias outcome data toward those who returned.
6. **Is the speaker problem Deepgram's or ours?** **UNKNOWN — needs verification.**
   Unanswerable today; P0 item 5 fixes that.
7. **Where does curated medical knowledge come from** — licensed, or clinician-authored?
   Determines the whole global layer.
8. **Regulatory intent** — documentation aid, or clinical decision support? Different
   obligations in both jurisdictions.
9. **Who owns clinic data contractually?** Answer before clinic #2.
10. **What are the top 20 rejection reasons?** Unknowable today. Likely to reshape this
    roadmap more than anything else in it.

---

## 17. Diagrams

Mermaid, so they render in GitHub/GitLab and stay diffable. Colour convention throughout:
**green = built and verified · amber = partial or stale · red = broken or missing.**

### A. The learning loop

The two red edges are the ones that do not exist today. Everything else already runs.

```mermaid
flowchart TD
    A["CLINICAL ACTIVITY<br/>conversation · vitals · labs<br/>orders · procedures"]
    B["AI UNDERSTANDING<br/>Deepgram → transcript<br/>ask_copilot · 36 tools"]
    C["RECOMMENDATION + EVIDENCE<br/>every suggestion carries<br/>an evidence_span"]
    D["SAFETY VALIDATION<br/>dose · interaction<br/>contraindication · duplicate"]
    E["DOCTOR REVIEW<br/>suggestion + evidence + warnings"]
    F{"ACCEPT / EDIT / REJECT"}
    G["CAPTURED<br/>+ reason_code<br/>+ field-level diff<br/>+ time_to_decision"]
    H["FINAL SIGNED DECISION<br/>every field carries provenance"]
    I["FOLLOW-UP OUTCOME<br/>structured, defined measurement point"]
    J["GOVERNED LEARNING SIGNAL"]
    K["EVALUATION SET<br/>highest value · available now"]
    L["COHORT EVIDENCE<br/>§8 safeguards<br/>AI-influenced excluded"]
    M["GOVERNANCE REPORTS<br/>guideline divergence<br/>treatment variance"]
    N["TRAINING CANDIDATE<br/>§10 experiment only<br/>consented · de-identified"]
    O["BETTER AI<br/>tools · prompts · knowledge · validators<br/>weights last"]

    A --> B --> C --> D --> E --> F
    F -.->|"NOT PERSISTED TODAY"| G
    G --> H
    H -.->|"NOT CAPTURED TODAY"| I
    I --> J
    J --> K & L & M & N
    K & L & M --> O
    N -.->|"only if measured to help"| O
    O -.->|"next encounter"| B

    classDef ok fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef gap fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef target fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    class A,B,C,E,H ok
    class G,I gap
    class D,K,L,M,N,O target
```

### B. Multi-clinic architecture

The invariant: **no patient data crosses a tenant boundary; lessons do.**

```mermaid
flowchart TD
    subgraph GLOBAL["REMEDISYS GLOBAL — curated · versioned · NO patient data"]
        direction LR
        KB["Medical Knowledge Base<br/>guidelines · drug refs<br/>dosing tables · SOPs<br/><b>→ RAG</b>"]
        DE["Deterministic Engines<br/>paediatric dosing · interactions<br/>contraindications · allergy classes"]
        TL["Tools · prompts<br/>extraction · evaluation suites"]
    end

    subgraph A["CLINIC A — isolated tenant"]
        direction TB
        A1["Patient records → structured tools"]
        A2["Cases + outcomes → controlled retrieval"]
        A3["Protocols → tenant-scoped RAG"]
        A4["Feedback + evals"]
    end

    subgraph B["CLINIC B — isolated tenant"]
        direction TB
        B1["Patient records → structured tools"]
        B2["Cases + outcomes → controlled retrieval"]
        B3["Protocols → tenant-scoped RAG"]
        B4["Feedback + evals"]
    end

    subgraph C["CLINIC C — isolated tenant"]
        direction TB
        C1["Patient records → structured tools"]
        C2["Cases + outcomes → controlled retrieval"]
        C3["Protocols → tenant-scoped RAG"]
        C4["Feedback + evals"]
    end

    GLOBAL -->|"knowledge · tools · validators"| A & B & C
    A4 -.->|"LESSONS only<br/>never records"| GLOBAL
    B4 -.->|"LESSONS only"| GLOBAL
    C4 -.->|"LESSONS only"| GLOBAL

    A --> AI1["Clinic AI<br/>global + local"] --> D1["Doctor"]
    B --> AI2["Clinic AI<br/>global + local"] --> D2["Doctor"]
    C --> AI3["Clinic AI<br/>global + local"] --> D3["Doctor"]

    NOTE["❌ Clinic data NEVER trains the global model<br/>§11.2 — legal · contractual · technical · quality"]

    classDef global fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef clinic fill:#f3e5f5,stroke:#6a1b9a,color:#4a148c
    classDef warn fill:#ffebee,stroke:#c62828,color:#b71c1c
    class KB,DE,TL global
    class A1,A2,A3,A4,B1,B2,B3,B4,C1,C2,C3,C4 clinic
    class NOTE warn
```

### C. The patient safety boundary

The rule: **reasoning is unbounded; authority is bounded.**

```mermaid
flowchart LR
    PD["PATIENT DATA<br/>name · age · allergies<br/>labs · vitals · meds"]
    MK["MEDICAL KNOWLEDGE<br/>guidelines · drug refs<br/>dosing · SOPs"]
    HE["HISTORICAL EVIDENCE<br/>prior cases · outcomes"]

    ST["STRUCTURED TOOLS<br/>permission-checked · bounded<br/>✅ 36 tools, zero DB writes<br/>⚠️ age corrupted pre-LLM"]
    RG["RAG<br/>curated · versioned · cited<br/>❌ does not exist yet"]
    CR["CONTROLLED RETRIEVAL<br/>n≥20 · dedup by patient<br/>current patient excluded<br/>❌ does not exist yet"]

    LLM["LLM — REASONING<br/>may reason about anything<br/><b>may assert nothing<br/>it did not retrieve</b><br/>✅ correctly bounded"]

    SV["DETERMINISTIC VALIDATORS<br/>code, not prompts<br/><b>can REJECT the LLM</b><br/>⚠️ 5 rules; rest is prompt text<br/>⚠️ dosing data exists, unwired"]

    DR["DOCTOR — FINAL DECISION<br/>✅ encounter fields<br/>❌ bypassed for 5 patient tools"]

    DB[("MEDICAL RECORD")]

    PD --> ST --> LLM
    MK --> RG --> LLM
    HE --> CR --> LLM
    LLM --> SV --> DR --> DB

    classDef ok fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef partial fill:#fff8e1,stroke:#f57f17,color:#e65100
    classDef missing fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef src fill:#eceff1,stroke:#455a64,color:#263238
    class PD,MK,HE src
    class ST,SV,DR partial
    class RG,CR missing
    class LLM ok
```

### D. End-to-end future encounter

What one visit looks like once P0–P2 have shipped.

```mermaid
flowchart TD
    P["Patient arrives"]
    T["Transcript / clinical activity<br/>Deepgram + raw speaker_label persisted"]
    U["LLM understanding<br/>ask_copilot agent"]

    T1["Patient tools<br/>meds · allergies · vitals<br/>labs · history"]
    T2["Medical RAG<br/>current guidance, cited"]
    T3["Historical cohorts<br/>comparable cases<br/>§8 safeguards"]

    R["Clinical reasoning<br/>synthesis across all three"]
    S["Safety validation<br/>dose · interaction · contraindication"]
    V{"Doctor review<br/>suggestion + evidence_span + warnings"}

    AC["Accept"]
    ED["Edit<br/><i>richest learning signal</i>"]
    RJ["Reject<br/>+ reason_code"]

    F["Final record<br/>every field carries provenance"]
    O["Outcome<br/>structured, defined measurement point"]
    L["Governed learning signal<br/>evals · retrieval · governance<br/>rarely: training"]

    P --> T --> U
    U --> T1 & T2 & T3
    T1 & T2 & T3 --> R --> S --> V
    V --> AC & ED & RJ
    AC & ED & RJ --> F --> O --> L
    L -.->|"improves tools · prompts<br/>knowledge · validators"| U

    classDef now fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef new fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef signal fill:#fff8e1,stroke:#f57f17,color:#e65100
    class P,T,U,R,V,AC,F now
    class T1,T2,T3,S new
    class ED,RJ,O,L signal
```

### E. Current vs target — what actually changes

```mermaid
flowchart LR
    subgraph TODAY["TODAY"]
        direction TB
        t1["Transcript<br/>speaker = positional guess"]
        t2["36 tools<br/>no evidence_span"]
        t3["LLM<br/>gpt-5-mini"]
        t4["Suggestions → draft"]
        t5["Doctor reviews"]
        t6["Feedback DISCARDED<br/>in the browser"]
        t7["Signed record<br/>no provenance"]
        t1 --> t2 --> t3 --> t4 --> t5 --> t6 --> t7
    end

    subgraph TARGET["TARGET — after P0/P1"]
        direction TB
        n1["Transcript<br/>+ raw speaker_label"]
        n2["36 tools + evidence_span<br/>+ dosing reference tool"]
        n3["LLM<br/>same"]
        n4["Suggestions → draft"]
        n5["Deterministic validators<br/>dose · duplicate · allergy"]
        n6["Doctor reviews<br/>ALL fields, incl. patient-level"]
        n7["Feedback PERSISTED<br/>+ reason_code + timing"]
        n8["Signed record<br/>+ field-level provenance"]
        n9["Outcome captured"]
        n1 --> n2 --> n3 --> n4 --> n5 --> n6 --> n7 --> n8 --> n9
    end

    TODAY ==>|"P0 items 1–6<br/>≈ one sprint"| TARGET

    classDef broken fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef fixed fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    class t1,t2,t6,t7 broken
    class n1,n2,n5,n6,n7,n8,n9 fixed
```

## Final recommendation

**Build the learning infrastructure before the custom model.**

Keep the LLM central — as the reasoning and language layer, never as the source of truth.
Use structured tools for authoritative patient facts, RAG for trusted medical knowledge,
controlled retrieval for comparable cases, and deterministic validators for high-risk
fields. Capture doctor feedback, provenance and outcomes as first-class data.

Three sentences to hold onto:

> **The asset is the dataset and the retrieval layer, not the weights.**
>
> **Reasoning is unbounded; authority is bounded.**
>
> **Every appropriate clinical event becomes a governed learning signal — and Remedisys
> decides whether that signal improves retrieval, evaluation, tools, prompts, safety,
> knowledge, or, only when measured, model weights.**

The next move is P0 items 1–5. Until doctor feedback is persisted with reason codes and
provenance, and until age, speaker labels and the patient-record bypass are fixed, every
additional encounter is a partly wasted one.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-13 | Sarvesh | Initial version (header backfilled from git history) |
