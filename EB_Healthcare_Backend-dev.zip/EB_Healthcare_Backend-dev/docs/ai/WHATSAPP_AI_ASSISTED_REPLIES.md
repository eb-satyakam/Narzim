# AI-assisted replies to patient WhatsApp messages — research and options

**Doc status:** draft · **Created:** 2026-09-14 by Ashutosh (AI-assisted) · **Updated:** 2026-09-14 by Ashutosh (AI-assisted) · **Version:** 1.2

> **Nothing has been built.** This is the research asked for before implementation. It exists because
> the request, as stated, **reverses the two rules the WhatsApp design is built on** — and that is a
> decision to take deliberately, not to discover in a diff. §4 gives four ways to satisfy the intent,
> §6 lists what only the product owner can answer.

---

## 1. What was asked for

Today a patient message that matches no keyword receives a fixed fallback template:

> *Thanks for your message! Our team will see it. To view your appointments or message us securely,
> tap below. If it's urgent, please seek medical care.* → **[ Open portal ]**

The request: when a patient writes free text — *"I have high fever"* — an AI should **read it and
compose an appropriate reply**. Not send it. The draft appears in the staff WhatsApp inbox, and a
doctor or nurse **approves or rejects** it. Example given: for a fever the AI might suggest home
remedies, and add *"please seek medical care as soon as possible"* if it reads as serious.

The physician-in-the-loop part is right, and it matches Rule 6 and the existing `AI SOAP Draft`
pattern. The difficulty is not the approval step. It is **what the approved message is allowed to
contain, and how it can be delivered.**

---

## 2. What the system does today

| | Today |
|---|---|
| Inbound free text | Logged, staff inbox notified, fallback template sent |
| Outbound | **Templates only.** `phi_policy.refuse_free_form()` throws on every free-text path |
| Clinical content on WhatsApp | **Forbidden.** WhatsApp says *that* something happened; the portal says *what* |
| LLM | OpenAI `gpt-5-mini`, named in the `mx` ComplianceProfile as a subprocessor |
| Safety validators | `AI Settings.enable_safety_validators = 0` — **off** |
| Portal | Already has monitored two-way chat: `send_my_chat_message` / `send_portal_message` |

---

## 3. The two collisions

### 3.0 What the product owner specified, and why it matters to R-1

> **Staff may not compose messages. Only the AI writes; a doctor or nurse may approve or reject,
> nothing else.** Specified 2026-09-14.

This is a stronger control than the one R-1 removed, and it is worth being precise about why rather
than treating it as a detail.

`refuse_free_form()` was written to close **clinic-originated free text** — a staff member typing
whatever they judged appropriate into a channel with no BAA. That is unbounded in content and
unauditable in substance: nothing constrains what is typed, and afterwards there is only the message
itself.

The specified design leaves that closed. What goes out is instead:

- **bounded by a prompt** that can forbid dosing, drug names and diagnosis;
- **checkable in code before a human ever sees it** — a draft containing a number-plus-unit can be
  rejected automatically;
- **attributable**: a draft record carries the model, the prompt version, the inbound message and
  the approver, so an approved message is reconstructable months later;
- **refusable** by a clinician who did not write it, and therefore has no authorship bias towards
  sending it.

So the "who may compose" half of R-1 is arguably satisfied **better** than by the status quo ante.

**What this does not change is R-2.** The disclosure to Meta is identical whoever composed it: a
clinical statement about a named patient, to a processor that has refused to sign for it. Authorship
is not the issue there; content is. That is why §6 question 2 is the one that actually decides this
feature.

### 3.1 R-1 — outbound is template-only

`WHATSAPP_HIPAA_COMPLIANT.md` §5 R-1, enforced by `phi_policy.refuse_free_form()`, which throws a
`PermissionError` on every clinic-originated free-text path. Its docstring is explicit that this is
a capability removed rather than a UI hidden:

> *There is deliberately no path for the clinic to originate free text, a file, or clinical content
> on this channel, because Meta has signed no BAA and content the patient never authorized is an
> impermissible disclosure however careful the sender is.*

**An AI-composed reply is free text by definition.** A template is fixed, pre-approved wording; a
composed answer to "I have high fever" cannot be one. So this feature cannot be delivered over
WhatsApp without reopening the exact path that was closed — and that path is also what made the
third-party chatbot app unusable (`docs/Discuss_frappe_whatsapp_chatbot.md`).

Note the 24-hour window makes this *technically* possible: an inbound message opens a window in
which Meta permits free-form replies. Meta permitting it is not the constraint. **We are.**

### 3.2 R-2 — the clinic never originates clinical content

Home remedies for a fever are clinical advice. R-2 exists so that WhatsApp — a channel with no BAA —
carries no clinical fact at all. "Take paracetamol and fluids" is a clinical fact about a named
patient, sent to a processor that has refused to sign for it.

### 3.3 And a third thing, which is not a rule but is the real risk

> **Corrected 2026-09-14 by the product owner: this platform is for ANY clinic type, not paediatric
> only.** `CLAUDE.md` §2 still says "paediatric clinics in Mexico" and is stale on that point. The
> correction widens the risk rather than narrowing it — the first draft of this section reasoned
> about weight-based dosing and Reye's syndrome, which is one specialty's version of a general
> problem.

Generated clinical advice is risky across every population the software serves, in different ways:
paediatric dosing, drug interactions in a polypharmacy elderly patient, anything in pregnancy,
cardiac symptoms presenting atypically. There is no clinic type for which "an LLM suggested a home
remedy" is a low-stakes sentence.

Two facts from this codebase, both already recorded in `CLAUDE.md`:

- contraindication, interaction and age-appropriateness checks **exist as prompt text, not code**;
- `AI Settings.enable_safety_validators` is **`0`**.

The physician approval step is a real mitigation and should not be waved away. But approval is a
human reading a plausible-sounding draft under time pressure, and plausible-sounding wrong advice is
the specific failure mode LLMs are best at producing. **A draft that is 95% good is more dangerous
than one that is obviously bad**, because it gets approved.

---

## 4. Four ways to satisfy the intent

### A. AI drafts → staff approve → send as WhatsApp free text

What was literally asked for.

- **Pros:** exactly the requested experience; patient gets a real answer where they asked the question.
- **Cons:** reverses R-1 **and** R-2. Reopens `refuse_free_form`, which is the single control making
  "no PHI on WhatsApp" true rather than aspirational. Every future feature will point at this
  precedent. Clinical advice to a no-BAA processor, about a named patient, now that ADR-067 puts the
  name in the channel too.

### B. AI drafts → approved text goes into a template variable

- **Pros:** feels like it preserves "template-only".
- **Cons:** it does not. The variable *is* the content; a template with an arbitrary body variable is
  free text with extra steps, and Meta would reject the template anyway (a body cannot be a single
  unbounded variable). **Rejected as self-deception rather than a design.**

### C. AI classifies rather than composes; staff send a curated template

The AI reads the message and *recommends which approved template fits* — "this looks like a booking
request", "this looks clinical, send the seek-care template" — with the staff member choosing.

- **Pros:** R-1 and R-2 both intact. No new disclosure. No generated clinical advice, so the
  paediatric risk disappears. Cheap to build on the existing keyword matcher.
- **Cons:** does not answer the patient's actual question. A fever message still gets a "contact us"
  template, just a better-chosen one. **Does not deliver what was asked.**

### D. AI drafts → staff approve → reply is delivered in the PORTAL, with a WhatsApp nudge

The draft appears in the staff inbox exactly as requested. On approval it is posted to the patient's
**portal chat** — which already exists, is authenticated, and is the channel where clinical detail is
permitted. The patient gets a WhatsApp template: *"You have a reply from the clinic"* → **[ Open portal ]**.

- **Pros:** the patient gets a real, substantive answer. Doctor/nurse approve exactly as asked. R-1
  and R-2 both hold — WhatsApp still carries no clinical content. No new subprocessor disclosure:
  the LLM already processes patient text elsewhere and is named in the profile. Builds on rails that
  already exist on both sides (`send_portal_message`, `send_my_chat_message`).
- **Cons:** the patient must open the portal to read the answer — one extra step, and the step this
  whole design has been pushing them towards anyway. Response is not "in WhatsApp".

### Recommendation

**D**, and it is not a compromise — it is the only option that delivers a real clinical answer to the
patient without putting clinical content on a channel that cannot carry it.

**A's objection is narrower than it was**, given §3.0: with staff unable to compose, the authorship
risk largely goes away, and what remains is purely the R-2 disclosure — clinical content to a
no-BAA processor. If the answer to §6 question 2 is "non-clinical help only", **option A becomes
genuinely defensible**, because a message that carries no clinical fact does not engage R-2 at all.
That is the single answer that most changes this recommendation.

**C loses** because it does not answer the patient. **B** is not a real option.

The honest cost of D, stated plainly: **the patient reads the answer one tap later than they would
have.** That is the entire difference, and it buys keeping both rules.

---

## 5. What D would involve

| Piece | What it does |
|---|---|
| New doctype `AI WhatsApp Reply Draft` | inbound message, AI draft, status (Pending/Approved/Rejected), approver, sent-at. Mirrors `AI SOAP Draft`'s accepted-by-physician shape |
| `services/whatsapp_reply_draft.py` | builds the prompt, calls `services/llm.py::get_llm_client()` (never a direct provider call — ADR-026), writes the draft, logs to `AI Prompt Log` |
| Staff inbox UI | the draft under the inbound message, with Approve / Edit / Reject — as sketched |
| On approve | posts to portal chat + sends the existing "you have an update" WhatsApp template |
| Prompt | must forbid dosing, drug names, and diagnosis; must always include a seek-care line for anything red-flag |

**Minimum safety, non-negotiable if this is built:**

1. **Never auto-send.** No timeout-based approval, no "approve all".
2. **A red-flag list evaluated in code, not by the LLM** — chest pain, breathing difficulty, infant
   under 3 months with fever, seizure, bleeding. On a match the draft is suppressed entirely and the
   inbox shows an urgent banner. An LLM must not be the thing deciding an emergency is not one.
3. **No dosing, ever.** Not "give paracetamol 250mg", not "the usual dose". The prompt forbids it and
   a post-check rejects any draft containing a number followed by a unit.
4. **The draft is stored with the model and prompt version** so an approved message is reconstructable.

---

## 5a. DECIDED — 2026-09-14, by the product owner

All five questions in §6 were put and answered. Recorded here because each one moves a control, and
three of them move a different one.

| # | Question | Decision | What it moves |
|---|---|---|---|
| 1 | Clinical advice, or non-clinical only? | **Clinical advice** | — |
| 2 | Delivered where? | **WhatsApp directly**, not the portal | **Reverses R-2** |
| 3 | Drafts for unknown senders? | **Yes** | — |
| 4 | Clinical reply to unknown senders too? | **Yes** | **Reverses R-3** for this path |
| 5 | Before approval? | **Nothing is sent** | Reverses the ADR-066 fallback rationale |
| 6 | Who composes? | **Only the AI.** Staff may approve or reject, never type | Strengthens R-1 (see §3.0) |
| 7 | Who approves? | **Doctor or nurse** | — |

**So this feature reverses R-2 and R-3, and narrows the fallback behaviour of ADR-066.** It does not
reverse R-1's substance — §3.0 explains why AI-composed-and-checked text is a stronger control than
the human free text R-1 removed.

The full reasoning, including what was argued against each reversal, is in
[ADR-068](../adr/adr-068-ai-drafted-whatsapp-clinical-replies.md). This section is the index, not
the record.

> **One point raised and, at the time of writing, awaiting a final word: decision 5.** ADR-066
> created the fallback specifically because *"silence is indistinguishable from being heard"* — a
> parent texting about a febrile child at night and receiving nothing believes the clinic was told.
> Decision 5 reinstates that silence for exactly the clinical messages where it matters most.
> Sending the fallback immediately AND creating the draft costs nothing and loses no clinical
> control. Recorded here so the trade-off is visible whichever way it lands.

---

## 6. The questions that were put

1. **Is the portal-delivery trade-off acceptable (option D), or is an in-WhatsApp answer a hard
   requirement?** If it is hard, that is option A and it needs an ADR reversing R-1 and R-2, with the
   HIPAA readiness document updated to match.

2. **Should the AI give clinical advice at all, or only non-clinical help?** There is a large gap
   between *"Our clinic opens at 9am"* and *"for a fever, fluids and paracetamol"*. The first is
   safe and useful; the second is the paediatric risk in §3.3. **These could be different features
   with different rules**, and separating them may be better than one AI that does both.

3. **Who may approve — nurse as well as doctor?** The request says both. For advice on a febrile
   child that is a scope-of-practice question, not a permissions one.

4. **What happens when nobody approves?** A draft sitting unapproved overnight means the patient got
   only the fallback. Is that acceptable, or does the fallback need rewording to set expectations?

5. **Does this run for unknown senders?** A message from a number matching no patient has no
   context, no consent record, and no clinician who owns it.

---

## References

- [`docs/security/WHATSAPP_HIPAA_COMPLIANT.md`](../security/WHATSAPP_HIPAA_COMPLIANT.md) — §5 R-1, R-2
- [`ADR-066`](../adr/adr-066-whatsapp-keyword-auto-replies.md) — the auto-reply design this extends
- [`ADR-067`](../adr/adr-067-patient-name-in-whatsapp-templates.md) — the patient name now on this channel
- [`ADR-026`](../adr/adr-026-llm-provider-allowlist.md) — LLM must go through `get_llm_client()`
- [`ADR-030`](../adr/adr-030-llm-curated-tool-access.md) — curated tools, no raw access
- [`docs/Discuss_frappe_whatsapp_chatbot.md`](../Discuss_frappe_whatsapp_chatbot.md) — the third-party app rejected partly for this exact capability
- [`CLAUDE.md`](../../CLAUDE.md) — Rule 6 physician in control, Rule 7, Rule 9 pipelines over agents, §9.9 PHI-6

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-14 | Ashutosh (AI-assisted) | Records the seven decisions. Clinical advice, delivered on WhatsApp, to known and unknown senders alike, nothing sent before approval — reversing R-2 and R-3 and narrowing ADR-066's fallback. Flags decision 5 as recreating the harm the fallback was built to prevent |
| 1.1 | 2026-09-14 | Ashutosh (AI-assisted) | Two corrections from the product owner: the platform serves any clinic type (not paediatric only — `CLAUDE.md` §2 is stale), and staff may not compose messages at all. The second adds §3.0 and narrows the objection to option A, since AI-composed-and-checked text is a stronger control than the human free text R-1 removed |
| 1.0 | 2026-09-14 | Ashutosh (AI-assisted) | Initial research. Records that the request as stated reverses R-1 and R-2; offers four options and recommends portal delivery with a WhatsApp nudge; lists the paediatric safety constraints and five open questions |
