# Analyze Idempotency, Meaningful-Change Detection & Incremental Context — Design

**Doc status:** living · **Created:** 2026-08-04 by Sarvesh-SocialAngel · **Updated:** 2026-08-13 by Sarvesh-SocialAngel · **Version:** 1.0

|                        |                                                                                                                                                                                                                                                                                                                                                             |
| ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Document type**      | ~~Design proposal (not yet built)~~ → **SHIPPED `c778ad5` (2026-08-04).** Design reference for live code                                                                                                                                                                                                                                                    |
| **Date**               | 2026-08-04                                                                                                                                                                                                                                                                                                                                                  |
| **Problems addressed** | (1) repeated Analyze wastes a full LLM call, (2) trivial transcript edits trigger re-analysis, (3) whether to roll up the transcript incrementally                                                                                                                                                                                                          |
| **Companion**          | `AI_ENCOUNTER_OPTIMIZATION_PLAN.md` — removed 2026-08-13 (stale figures); its ranked work is now in [`REMEDISYS_AI_MASTER_PLAN.md`](./REMEDISYS_AI_MASTER_PLAN.md) §13, its measurements in [`CURRENT_SYSTEM_AUDIT.md`](./CURRENT_SYSTEM_AUDIT.md) §15                                                                                                      |
| **⚠️ Header status**   | This document says "not yet built" below. **That is wrong** — the design shipped in `c778ad5`. `services/transcript_digest.py`, `services/clinical_lexicon.py`, `services/ai_tools.py` and `tests/ai/test_analyze_fingerprint.py` all cite it by section, which is why it is retained. Note the cache defaults **OFF** (`AI Settings.enable_analyze_cache`) |
| **Precedent to copy**  | `services/patient_clinical_summary.py` — the rolling-summary-with-watermark pattern already exists in this codebase and is the model for §4                                                                                                                                                                                                                 |

---

## 0. Three findings that shape the design

**0.1 — The store already exists.** `AI Encounter Chat Message` already persists every Analyze
result: `kind="analysis"`, `content` (the reply), `actions_json` (the suggestions), plus
`model`/`prompt_version`/`tokens_in`/`tokens_out`/`latency_ms`. **No new doctype is needed for the
cache** — two indexed fields on this doctype turn it into one.

**0.2 — The rolling-summary pattern already exists.** `patient_clinical_summary.py` implements
exactly what Problem 3 asks for: a `last_synced_at` watermark captured *before* the gather and
advanced *only on success*, an incremental gate on `(prior content AND watermark)`, a `rebuild`
force flag, a deduplicated per-subject background job, and "nothing changed ⇒ no LLM call at
all." Problem 3 is a port of this module, not a new invention.

**0.3 — The transcript is not the token problem.** Measured: `get_current_transcript` is capped at
`_MAX_TRANSCRIPT_CHARS = 6000` ≈ 1,500 tokens. The agent's fixed prefix is 10,816 tokens *per
round-trip*. The transcript is ~12% of one round-trip and ~1% of a full Analyze turn.
**Summarizing the transcript to save tokens optimizes the wrong term.** It has a different, real
justification — see §4.1.

---

## 1. High-level architecture

```
                      ┌─────────────────────────────────────────┐
  Doctor clicks       │  L0  identity gate                      │  transcript bytes + draft
  Analyze  ─────────► │      (byte-equal? → hit)                │  fingerprint identical
                      └────────────────┬────────────────────────┘
                                       │ miss
                      ┌────────────────▼────────────────────────┐
                      │  L1  clinical_digest()                  │  normalize + strip standalone
                      │      deterministic, no LLM              │  fillers → stable digest
                      └────────────────┬────────────────────────┘
                                       │
                      ┌────────────────▼────────────────────────┐
                      │  L2  materiality gate                   │  delta tokens vs
                      │      catalog-derived clinical lexicon   │  clinical trigger set
                      └────────────────┬────────────────────────┘
                          material?    │
                   ┌──────── no ───────┴──── yes ────────┐
                   ▼                                      ▼
        ┌──────────────────────┐            ┌─────────────────────────┐
        │ REUSE stored result  │            │ RUN ask_copilot_agent   │
        │ from AI Encounter    │            │ persist result + its    │
        │ Chat Message         │            │ input_fingerprint       │
        │ + AI Prompt Log row  │            └─────────────────────────┘
        │   status = "Cached"  │
        └──────────────────────┘
```

**Governing principle — fail open, always.** A false "nothing changed" hides a real clinical
change: a safety event. A false "something changed" costs 4.5¢. **When any layer is uncertain,
run the analysis.** Every threshold below is tuned in that direction, and this asymmetry must be
stated in code comments so a future tuner doesn't "improve" precision at recall's expense.

---

## 2. Problem 1 — Idempotent Analyze

### 2.1 Why hashing the transcript alone is wrong

Analyze's output is a function of far more than the transcript. `_ANALYZE_PROMPT` explicitly says
*"Never duplicate what is already in the draft"* and *"merge into the patient's EXISTING
patient-level summary"* — so the **same transcript against a different draft legitimately produces
different output**. A transcript-only key would serve a stale result after the physician accepted
half the suggestions.

The cache key must cover every semantically load-bearing input:

```python
FINGERPRINT_VERSION = 1

def analyze_fingerprint(encounter, *, focus, transcript, ctx, draft) -> str:
    payload = {
        "v":          FINGERPRINT_VERSION,
        "focus":      focus or "",
        "prompt":     _prompt_hash("ask-copilot-v2.txt", _ANALYZE_PROMPTS[focus or ""]),
        "model":      f"{_get_model()}:{_get_reasoning_effort()}",
        "lang":       resolve_chat_language(),
        "country":    resolve_suggestion_country() or "",
        "transcript": clinical_digest(transcript),          # §3
        "draft":      _draft_fingerprint(draft),            # §2.2
        "summary":    _sha(ctx.get("existing_summary") or ""),
        "chat_head":  _latest_chat_message_name(encounter),  # monotonic, cheap
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    ).hexdigest()
```

Notes on specific components:

- **`prompt`** — hash the *file contents* plus `_ANALYZE_PROMPT`. Editing a prompt must invalidate
  every cached result. This also finally gives `AI Prompt Log.prompt_hash` a writer (it is
  currently never populated — `AI_TOKEN_COST_MODEL.md` §6.3).
- **`model`** — includes `reasoning_effort`. Flipping the AI Setting must invalidate.
- **`chat_head`** — the name of the newest `AI Encounter Chat Message` row. Analyze reviews
  *"everything in our conversation so far"*, so a new chat turn is a genuine input change. Using
  the row name rather than a digest of every message keeps this to one indexed lookup.
- **`FINGERPRINT_VERSION`** — the global kill switch. Bumping it invalidates every cached result
  in one line, which is what you want the day you change the schema or discover a bug.

### 2.2 The draft fingerprint

Reuse the exact field set `_tool_get_encounter_state` already returns — that is, by construction,
the state the agent is told about:

```python
def _draft_fingerprint(state: dict) -> str:
    # Order-insensitive per list (the physician reordering rows is not a clinical change);
    # order-sensitive nowhere, because none of these lists carry meaning in their order.
    norm = {
        "chief_complaint": (state.get("chief_complaint") or "").strip().lower(),
        "symptoms":   sorted(x.strip().lower() for x in state.get("symptoms")   or []),
        "diagnoses":  sorted(x.strip().lower() for x in state.get("diagnoses")  or []),
        "medications":sorted(x.strip().lower() for x in state.get("medications")or []),
        "labs":       sorted(x.strip().lower() for x in state.get("labs")       or []),
        "procedures": sorted(x.strip().lower() for x in state.get("procedures") or []),
        "therapies":  sorted(x.strip().lower() for x in state.get("therapies")  or []),
        "vitals":     state.get("vitals") or {},
        "allergies":  sorted(x.strip().lower() for x in state.get("known_allergies") or []),
    }
    return _sha(json.dumps(norm, sort_keys=True, ensure_ascii=False))
```

Deliberately **excluded**: `review_details` free text and clinician-typed exam/assessment prose.
Those are physician-authored output, not agent input, and including them would invalidate the
cache on every keystroke-save. If that turns out to be wrong (i.e. Analyze visibly reacts to them)
add them behind a `FINGERPRINT_VERSION` bump.

### 2.3 Storage — two fields, no new doctype

Migration patch adding to `AI Encounter Chat Message`:

| Field | Type | Notes |
|---|---|---|
| `input_fingerprint` | Data (64), `search_index: 1` | sha256 hex |
| `fingerprint_version` | Int | denormalised so a version bump is a filterable no-match, not a re-hash of history |

And one new option on `AI Prompt Log.status`: **`Cached`**.

### 2.4 Lookup and serve

```python
@frappe.whitelist()
def analyze_encounter(encounter, transcript="", focus="", force=0):
    _require_auth(); _require_encounter_read(encounter)

    ctx   = build_encounter_context(encounter)
    draft = ai_tools.encounter_state(encounter, ctx)      # extracted from the tool fn
    fp    = analyze_fingerprint(encounter, focus=focus, transcript=transcript,
                                ctx=ctx, draft=draft)

    if not cint(force):
        hit = frappe.db.get_value(
            "AI Encounter Chat Message",
            {"encounter": encounter, "kind": "analysis", "role": "assistant",
             "input_fingerprint": fp, "fingerprint_version": FINGERPRINT_VERSION},
            ["name", "content", "actions_json", "creation"],
            order_by="creation desc", as_dict=True,
        )
        if hit:
            log_prompt_call(encounter=encounter, model="cache",
                            prompt_file="ask-copilot-v2", tokens_in=0, tokens_out=0,
                            cost_usd=0.0, latency_ms=0, status="Cached")
            return {"reply": hit.content,
                    "actions": json.loads(hit.actions_json or "[]"),
                    "cached": True, "generated_at": str(hit.creation),
                    "source_message": hit.name}

    result = ask_copilot(encounter, _ANALYZE_PROMPTS.get(focus, _ANALYZE_PROMPT),
                         transcript=transcript, kind="analysis", fingerprint=fp)
    result["cached"] = False
    return result
```

Two details that matter operationally:

- **The `Cached` prompt-log row is not optional.** `CLAUDE.md` §9 requires every LLM invocation to
  be logged; a cache hit is *not* an invocation, but leaving no trace makes the audit trail look
  like the physician never clicked Analyze. A zero-cost row with `status="Cached"` keeps
  attribution intact and gives you the hit-rate metric for free.
- **`force=1` must always exist.** Model nondeterminism is sometimes the point — a physician
  wanting a second opinion is a legitimate use. Never remove the escape hatch.

### 2.5 The stale-suggestion hazard — the one real risk

Consider: the physician clicks Analyze, gets 6 suggestions, **rejects 3**, clicks Analyze again.

Rejecting does not change the draft, so the fingerprint is identical → cache hit → the 3 rejected
suggestions are re-proposed. Today the model would *probably* re-suggest them too, but caching
makes it deterministic and therefore feel like a bug.

**Fix is frontend-only, and the machinery already exists.** `use-copilot` already tracks
`SuggestionStatus` per suggestion, exposes `setStatus`, and derives `pending` as
"suggestions still awaiting a decision." Filter served actions against locally-rejected ids
before `fillFormFromSuggestions`:

```ts
const rejected = new Set(suggestions.filter(s => s.status === "rejected").map(s => s.id));
const toApply  = actions.filter(a => !rejected.has(a.id));
```

This requires suggestion ids to be **stable across a cache hit** — they are, since the cached
`actions_json` is byte-identical. It does *not* hold across a genuine re-generation, where the
model re-indexes (`sg-ai-1`…). Accept that: on a real re-analysis, re-proposing something the
physician rejected is defensible behaviour.

### 2.6 Double-click collapse

Separate from caching, and worth doing first because it is 20 minutes of work: a physician
double-tapping Analyze today fires two 50-second calls. Add an in-flight guard in `use-copilot`
(the pattern already exists as `soapDraftLoading` / `resegregateLoading`) plus a server-side
short-TTL Redis lock keyed on `f"analyze::{encounter}::{fp}"` so a second request either waits for
or reuses the first result rather than duplicating it.

---

## 3. Problem 2 — Meaningful clinical change detection

### 3.1 Approach chosen, and what was rejected

| Approach | Verdict |
|---|---|
| Raw string hash | **Rejected** — "okay" invalidates. This is the stated problem. |
| Embedding similarity | **Rejected** — adds a model call and a new dependency to *avoid* a model call, and the threshold is unprincipled on clinical text. A cosine of 0.98 can hide "no penicillin allergy" → "penicillin allergy". |
| LLM-as-judge | **Deferred to Layer 3** — genuinely cheap (~300 tokens vs 55,000) but adds latency and a new failure mode. Build only if measurement shows Layer 2 is insufficient. |
| **Normalized digest + catalog-derived lexicon** | **Chosen** — deterministic, no LLM, no new dependency, and consistent with this codebase's existing instinct (`pii_redaction.py` chose regex over NER for the same reason). |

### 3.2 Layer 1 — `clinical_digest()`

New module `services/transcript_digest.py`. No AI, no network.

```
1. NFKC normalize, lowercase, collapse whitespace.
2. Keep speaker attribution ("doctor:" / "patient:") — WHO said something is
   clinically meaningful. Normalize the labels, don't strip them.
3. Strip standalone acknowledgement utterances (see §3.3).
4. Collapse immediate disfluency repeats: "the the" → "the", "fever fever" → "fever".
5. Canonicalise measurements: "38.5 c" / "38,5 °C" / "38.5°c" → "38.5c".
   (Number-word expansion — "thirty-eight" → 38 — is OPTIONAL and deferred;
   bilingual number words are a large surface for little gain.)
6. Emit the digest string. Hash it for the fingerprint; keep the token list for Layer 2.
```

### 3.3 The filler problem, and the subtlety that matters

A naive bilingual stopword list is **clinically dangerous**. Consider:

> Doctor: any allergy to penicillin?
> Patient: **yes**

Strip `yes` / `sí` as a filler and you have deleted an allergy. So filler removal must be
**position-aware**:

> Remove an acknowledgement token **only when it constitutes the entire utterance of a segment
> whose length is ≤ 2 tokens AND the segment is not immediately preceded by a question from the
> other speaker.** Never remove it from inside a longer sentence.

`AI Transcript Segment` gives you exactly what this needs — per-segment `text` and `speaker`, so
"is this a standalone utterance" and "did the other speaker just ask something" are both cheap
local checks rather than guesses over a flattened blob.

Lexicon (en + es-MX), as *acknowledgements*, not general stopwords:

```
en: ok, okay, okey, mm, mmm, uh, um, ah, right, yeah, yep, alright, sure, i see, got it
es: ok, okey, mmm, eh, ah, este, pues, bueno, ya, claro, a ver, entonces, órale, ándale
```

Note `yes`/`sí`/`no` are **deliberately absent** — they are answers, never fillers, and the
position rule is not protection enough for a token this load-bearing. Same for `no`: it is
negation.

### 3.4 Layer 2 — materiality gate

Compute the delta over **new segments only**, using `AI Transcript Segment.sequence_number` as the
watermark (this field already exists — no schema change). Then:

```python
def is_material(delta_tokens: set[str], delta_text: str, prior_tokens: set[str]) -> bool:
    if _has_measurement(delta_text):          return True   # "38.5c", "120/80", "5mg", "2 days"
    if delta_tokens & clinical_lexicon():     return True   # §3.5
    if _negation_flip(delta_text, prior_tokens): return True # "no fever" after "fever"
    if len(delta_tokens) >= MATERIAL_MIN_TOKENS:  return True  # start at 12
    return False
```

Fail-open ordering: every rule *returns True*. The only path to "not material" is falling through
all of them. Adding a rule can only ever make the gate more conservative.

**`_negation_flip` is the highest-value rule and the easiest to get wrong.** Detect a negation
cue (`no`, `sin`, `niega`, `denies`, `not`, `ningún`) within N=4 tokens of a term already present
in `prior_tokens`. "Patient denies chest pain" after "chest pain" is a material clinical change
even though it adds only three tokens.

### 3.5 The clinical lexicon comes free from your own masters

Do not hand-write a medical vocabulary. Derive it from the six catalogs
`build_encounter_context()` already resolves:

```
Complaint.complaints ∪ Diagnosis.diagnosis ∪ Medication.generic_name
  ∪ Lab Test Template.lab_test_name ∪ Clinical Procedure Template.template
  ∪ Therapy Type.therapy_type ∪ (patient's own allergy terms)
  → tokenize, lowercase, drop tokens < 4 chars and a small generic set
    ("test", "panel", "prueba", "total", "left", "right")
  → frappe.cache().set_value("clinical_lexicon", ..., expires_in_sec=3600)
```

Properties this gets you for free: **tenant-specific** (a cardiology clinic's lexicon differs
from a paediatric one), **bilingual to whatever extent the masters are**, **grows with the
catalog**, and **zero new data to maintain**. Invalidate on `on_update` of those six doctypes via
a `doc_events` hook — the same mechanism `patient_clinical_summary`'s `on_patient_activity`
already uses.

This is also the answer to a waste item in the optimization plan: the agent path currently
resolves all six catalogs and **discards** them. Now they have a second consumer.

### 3.6 Layer 3 — optional LLM gate, off by default

If measurement shows Layer 2 has a high false-positive rate (materially changed = re-analysed when
a human would say nothing changed), add a micro-judge: `gpt-5-mini`, `reasoning_effort=minimal`,
strict `json_schema` → `{"material": bool, "reason": str}`, given only the delta text plus the
current draft's one-line state. ~300 tokens in, ~30 out ≈ **$0.0001 against $0.045** — 450× cheaper
than the call it prevents.

**Do not build this speculatively.** Ship Layers 0–2, log every decision (`material`,
`delta_token_count`, `trigger_rule`) for two weeks, then decide from data.

---

## 4. Problem 3 — Incremental transcript summarization

### 4.1 Evaluation: right pattern, wrong stated reason

**Your stated goal (save tokens) does not hold.** The transcript is already hard-capped at 6,000
chars ≈ 1,500 tokens — roughly 1% of an Analyze turn's input (§0.3). A rolling summary would save
almost nothing.

**But there is a real problem behind the question, and it is worse than a cost problem.**
`_tool_get_transcript` truncates with `text[-_MAX_TRANSCRIPT_CHARS:]` — it keeps the **tail**. In a
30-minute consultation, the chief complaint established in minute 2 is *silently gone* by minute
25. The agent is then told to "complete the draft" from a transcript missing its own opening —
and `_ANALYZE_PROMPT` forbids it from filling gaps from prior-visit history, so it will simply
produce an incomplete draft with no signal that anything was lost.

**So build the rolling summary — for fidelity on long consultations, not for cost.** That reframing
changes the priority (it is a correctness fix, not an optimization) and the success metric (does a
40-minute consultation retain its chief complaint, not tokens saved).

### 4.2 Structured JSON, not free text

Reasons specific to this codebase:

1. A JSON summary can be **diffed**, which feeds §2's fingerprint directly. Free text cannot.
2. The whole downstream pipeline is already JSON-shaped (`ClinicalSuggestion`).
3. Re-summarizing free text compounds paraphrase loss; re-revising structured fields does not.
4. The strict `json_schema` helper already exists (`integrations/openai.py:145`).

```jsonc
{
  "schema_version": 1,
  "chief_complaint": "string|null",
  "hpi": "string",                    // ≤ 600 chars
  "symptoms": ["string"],
  "negatives": ["string"],            // explicitly denied — the anti-hallucination anchor
  "vitals_mentioned": {"temperature_celsius": 38.5, "...": null},
  "meds_mentioned":  [{"name": "...", "dose": "...", "home_or_new": "home|new"}],
  "allergies_mentioned": ["string"],
  "history_mentioned":   ["string"],
  "plan_discussed":      ["string"],
  "verbatim_quotes":     ["string"]   // ≤ 5, physician wording that MUST survive intact
}
```

`negatives[]` and `verbatim_quotes[]` are the two fields that make this safe. Without `negatives`,
successive revisions lose "denies chest pain" — the exact information a summary is most likely to
drop and most dangerous to drop.

### 4.3 Anti-drift — four mechanisms

1. **Never summarize a summary.** Always `summary(n) = revise(summary(n-1), delta_text)`. The raw
   `AI Transcript Segment` rows remain ground truth, so a full rebuild is always possible.
2. **Bound the revise chain.** After `MAX_REVISIONS = 8` incremental steps, force a rebuild from
   raw segments regardless of state.
3. **Checkpoint rebuilds** at two events where the summary is definitionally suspect:
   after `resegregate_transcript` (speaker labels changed ⇒ every attribution in the summary is
   questionable) and before Sign (the record must be right).
4. **A `rebuild=True` force flag**, exactly as `patient_clinical_summary` has.

### 4.4 Versioning and storage

Mirror `patient_clinical_summary`'s watermark semantics exactly: capture the watermark **before**
the gather, advance it **only on success**, so a failed revision retries the same delta and the
last good summary stays visible.

Storage: three fields on **`AI Encounter Session`** (`rolling_summary_json`,
`summary_watermark_seq` Int, `summary_version` Int), with carry-forward when `start_session`
creates a new session for an encounter that already has one.

*Trade-off, stated honestly:* the natural cardinality is per-*encounter*, not per-*session*, and an
encounter can have several sessions — so carry-forward is a real (if small) piece of complexity.
The alternative is a new single-row-per-encounter doctype. This design chooses fields-on-existing
because this codebase has a clear precedent against inventing doctypes for this shape (chat threads
are a `Data` field, not a `Session` doctype — `NARZIM_AI_ASSISTANT_DESIGN.md` §2.5). If
carry-forward gets awkward in practice, the new doctype is the correct escalation.

### 4.5 Tool-calling integration — add, don't swap

**Do not change what `get_current_transcript` returns.** The agent's behaviour is tuned against
verbatim transcript text, and silently substituting a summary is a clinical-behaviour change
disguised as an optimization.

Instead **add** `get_transcript_summary` (structured, cheap, complete) and amend the system prompt:

> Call `get_transcript_summary` first — it covers the whole consultation. Call
> `get_current_transcript` only when you need the exact wording (a dose the patient reported, a
> phrase you intend to quote); it may be truncated on a long consultation.

That keeps verbatim access available where it is clinically necessary, makes the complete-and-cheap
call the default, and — because the summary is complete where the raw transcript is truncated —
*improves* fidelity on exactly the long consultations where today's behaviour is worst.

---

## 5. Speculative pre-warming — the "feels instant" piece

Caching makes a *repeat* Analyze instant. This makes the *first* one instant.

While the physician is still consulting, run Analyze speculatively in the background at a
debounce, store the result with its fingerprint. When they click Analyze, if the fingerprint still
matches (nothing material said since), it is already there.

- **Trigger:** a single speculative run after ~20 s of silence with a material delta pending, gated
  on `AI Settings.enable_suggestions`, at most **once per material delta**.
- **Compose with §2:** the speculative run writes an ordinary `kind="analysis"` row with its
  fingerprint. The click path then takes the ordinary cache-hit branch. **No new serving code.**
- **Risk:** you pay for analyses nobody looks at. Bound it hard (one in flight, max N per
  encounter, e.g. 2) and log a `speculative_hit_rate` so the spend is visible. Kill it if hit rate
  falls below ~50%.

---

## 6. Cache invalidation summary

| Event | Effect | Mechanism |
|---|---|---|
| Material transcript change | invalidate | `clinical_digest` changes → new fp |
| Trivial transcript change ("okay") | **no** invalidation | digest unchanged |
| Draft edited (any of the 9 tracked fields) | invalidate | `_draft_fingerprint` |
| Suggestion accepted | invalidate | draft changed |
| Suggestion rejected | **no** invalidation | draft unchanged — §2.5 handles the UX |
| New chat turn | invalidate | `chat_head` |
| Patient summary changed | invalidate | `summary` hash |
| Prompt file edited | invalidate | `prompt` hash |
| Model / reasoning_effort changed | invalidate | `model` component |
| Language / country changed | invalidate | `lang` / `country` |
| Schema or bug fix | invalidate **everything** | bump `FINGERPRINT_VERSION` |
| Physician wants a second opinion | bypass | `force=1` |
| Encounter signed | stop caching | no Analyze after submit |
| Master catalogs changed | lexicon only | `frappe.cache()` 1 h TTL + `on_update` hook |

---

## 7. Estimated impact — and the measurement to run first

**The ROI of §2 is entirely a function of how often Analyze is actually re-clicked, which has never
been measured.** Run this before building anything:

```sql
SELECT clicks, COUNT(*) AS encounters FROM (
  SELECT encounter, COUNT(*) AS clicks
  FROM `tabAI Encounter Chat Message`
  WHERE kind = 'analysis' AND role = 'assistant'
  GROUP BY encounter
) t GROUP BY clicks ORDER BY clicks;
```

If the mean is ~1.1, §2 is not worth building yet and §3 + §4 carry the value. If it is ≥ 2, §2 is
the highest-ROI change available anywhere in the AI stack. **Decide from that query, not from this
document.**

While you are in there, this settles the ASR-vs-LLM cost question from the optimization plan —
`AI Encounter Record` already stores both:

```sql
SELECT ROUND(AVG(asr_cost_usd),4)   AS avg_asr,
       ROUND(AVG(cost_usd),4)       AS avg_llm,
       ROUND(AVG(total_cost_usd),4) AS avg_total,
       ROUND(AVG(asr_cost_usd / NULLIF(total_cost_usd,0)) * 100, 1) AS asr_pct
FROM `tabAI Encounter Record` WHERE total_cost_usd > 0;
```

**Projections, conditional on ~2.2 Analyze clicks/encounter with ~55% redundant:**

| Metric | Today | After §2 | After §2 + §5 |
|---|---:|---:|---:|
| Repeat-Analyze latency | 50.4 s | **<200 ms** | <200 ms |
| First-Analyze perceived latency | 50.4 s | 50.4 s | **~0** |
| Analyze calls per encounter | 2.2 | ~1.0 | ~1.0 (pre-paid) |
| Analyze input tokens/encounter | ~367k | **~166k** | ~166k |
| Total app input tokens | baseline | **−45–50%** | −45–50% |
| Cost per encounter (LLM) | ~$0.099 | **~$0.045** | ~$0.045 |

The total-input-token figure is large because `ask-copilot-v2` is 89.9% of all input tokens in the
app (`AI_TOKEN_COST_MODEL.md` §3.1) — halving its call count moves the whole system.

Stacked with the optimization plan's P1 (let the model batch tool calls, −67% input on a genuine
miss), a real Analyze miss lands near **55k tokens / ~20 s**, and a hit near **0 / instant**.

---

## 8. Risks and trade-offs

| Risk | Severity | Mitigation |
|---|---|---|
| **Cache serves a result that misses a real clinical change** | **High — the only clinical risk here** | Fail-open at every layer; every Layer-2 rule returns True; `force=1` always available; ship with logging before trusting it |
| Rejected suggestions re-proposed on a hit | Medium (trust/UX) | §2.5 client-side filter using existing `SuggestionStatus` |
| Cache hit reads as a broken button | Medium | Explicit UI: "No changes since last analysis · Re-analyze anyway" |
| Filler stripping deletes a clinical answer | **High** | Position-aware rule; `yes`/`sí`/`no` excluded from the lexicon entirely |
| Summary drift loses a negative finding | High | `negatives[]` + `verbatim_quotes[]` fields; bounded revise chain; checkpoint rebuilds |
| Fingerprint too sensitive ⇒ hit rate ~0 | Low | Excluded physician-authored prose from the draft fingerprint; measure hit rate |
| Fingerprint too coarse ⇒ stale results | High | Bump `FINGERPRINT_VERSION`, which invalidates globally in one line |
| Speculative runs waste money | Low | Hard bound, `speculative_hit_rate` metric, kill below 50% |
| Complexity added to a working system | Medium | §2 is 2 fields + ~120 lines; §3 is one new pure module (unit-testable with no LLM); §4 is a port of an existing module |

---

## 9. Roadmap

### Quick wins — days, no LLM changes

| # | Item | Why first |
|---|---|---|
| Q1 | Run the two SQL queries in §7 | Decides whether §2 is worth building at all |
| Q2 | Double-click / in-flight guard (§2.6) | 20 minutes; removes duplicate 50 s calls today |
| Q3 | `lru_cache` on `_load_prompt`; memoize the 2 tool arrays | Trivial; removes a 30 KB disk read per round-trip |
| Q4 | Add `Cached` to `AI Prompt Log.status`; write `prompt_hash` | Prerequisite for measuring everything below |
| Q5 | Fix `_tool_get_transcript` to warn when it truncates | Makes the §4.1 fidelity bug *visible* before you fix it |

### Medium — 1–2 sprints

| # | Item |
|---|---|
| M1 | `services/transcript_digest.py` — Layers 1 & 2, pure functions, unit-tested with no LLM |
| M2 | Catalog-derived clinical lexicon + Redis cache + invalidation hook (§3.5) |
| M3 | Fingerprint + 2 fields on `AI Encounter Chat Message` + reuse path (§2) |
| M4 | Frontend: cache-hit UI, "Re-analyze anyway", rejected-id filter (§2.5) |
| M5 | Two weeks of decision logging, then tune `MATERIAL_MIN_TOKENS` from data |

### Advanced — after the above is measured

| # | Item |
|---|---|
| A1 | Rolling structured transcript summary (§4) — as a **fidelity fix** for long consultations |
| A2 | `get_transcript_summary` tool + prompt amendment (§4.5) |
| A3 | Speculative pre-warming (§5) |
| A4 | Layer-3 LLM materiality judge — **only if M5's data justifies it** |

Deliberately **not** on this roadmap: embedding-based similarity (§3.1), a new cache doctype
(§2.3), and swapping `get_current_transcript`'s contents (§4.5).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-04 | Sarvesh | Initial version (header backfilled from git history) |
