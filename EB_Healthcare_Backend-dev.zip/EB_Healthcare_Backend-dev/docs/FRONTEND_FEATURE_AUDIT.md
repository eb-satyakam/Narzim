# Frontend Feature Audit — Remedisys (Healthcare_next_app)

**Doc status:** record · **Created:** 2026-06-30 by Invincible · **Updated:** 2026-06-30 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-06-30
**Scope:** `Healthcare_next_app` (Next.js 14 App Router) against the backend API in `EB_Healthcare_Backend`.
**Method:** Four parallel source-level investigations (Auth/Account, Appointments/Scheduling, Clinical, Billing/Admin/Ops). Status is evidence-based — read from components, hooks, route handlers, and the backend whitelisted methods they call.

**Status legend**
- ✅ **WORKS E2E** — UI present and wired to a real backend endpoint with persistence.
- 🟠 **PARTIAL** — UI present, partially wired, or wired but with a known gap.
- 🔴 **DATA-LOSS / STUB** — UI accepts input but nothing is persisted, or mock-only.
- ⬜ **MISSING** — no UI (and usually no backend).

> The most important section is [§3 The Danger Zone](#3-the-danger-zone--ui-accepts-input-backend-drops-it). Those are not missing features — the UI implies success while the data is lost.

---

## 1. Headline

- ~80 user-facing features exist; all 23 roadmap screens are present and bilingual (`es-MX` / `en-US` via `next-intl`).
- Core journeys (auth, appointments, billing, payments, reports, admin) are genuinely end-to-end.
- The primary risk is **silent non-persistence** in a handful of places — including **encounter clinical documentation** and **cash handling**.

---

## 2. What works end-to-end

### 2.1 Authentication & account
| Feature | Status | Backend endpoint |
|---|---|---|
| Login (email + password, JWT) | ✅ | `eb_frappe_jwt.api.get_token` + `auth.api.get_current_user` |
| Remember-me (8h vs 30d TTL) | ✅ | cookie TTL logic |
| Logout | ✅ | `eb_frappe_jwt.api.revoke_token` |
| Silent token refresh on 401 | ✅ | `eb_frappe_jwt.api.refresh_token` |
| Forgot password → email reset | ✅ | `auth.api.request_password_reset` |
| Reset / set password (invite + reset) | ✅ | `frappe...user.update_password` |
| Change password (logged-in) | ✅ | `auth.api.change_password` |
| Profile view/edit, avatar, language | ✅ | `auth.api.update_profile`, `/api/file/avatar` |
| Notification preferences (email/WhatsApp per event) | ✅ | `auth.api.update_notification_prefs` |
| Admin: invite staff, assign roles, enable/disable | ✅ | `admin.api.list_staff` / `invite_staff` / `update_user` |
| Role & permission matrix | ✅ | `admin.api` role-permissions (ERPNext-enforced) |

### 2.2 Appointments & front desk
| Feature | Status | Backend endpoint |
|---|---|---|
| Book appointment (existing or new patient, atomic) | ✅ | `appointments.api.book_appointment_for_patient` |
| Pay-now booking (appointment + invoice + payment) | ✅ | `appointments.api.book_appointment_with_payment` |
| Live slot fetch | ✅ | `appointments.api.get_available_slots` |
| Reschedule | ✅ | `appointments.api.reschedule_appointment` |
| Cancel (with reason) | ✅ | `appointments.api.cancel_appointment` |
| Mark no-show | ✅ | status update (PATCH) |
| Calendar (week/day) | ✅ | `appointments.api.list_appointments` |
| List with filters (date/status/practitioner/search) | ✅ | `appointments.api.list_appointments` |
| Check-in | ✅ | `appointments.api.check_in_patient` |
| Patient queue — 6 stages | ✅ | `list_appointments?date=today` |
| Provider schedule management | ✅ | `admin.api.get/update/assign_practitioner_schedule` |

### 2.3 Clinical
| Feature | Status | Backend endpoint |
|---|---|---|
| Patient registration | ✅ | `patients.api.create_patient` |
| Demographics edit | ✅ | `patients.api.update_patient` |
| Chart 360 (overview, appts, contact, vitals, encounters, meds, immun., docs, billing) | ✅ | multiple |
| Encounter SOAP draft (chief complaint, HPI, plan, education) | ✅ | `encounters.api` PATCH (`encounter_comment`) |
| Encounter: symptoms, diagnoses (text) | ✅ | child tables |
| Encounter: drug prescriptions | ✅ | `drug_prescription` child table |
| Encounter: lab orders | ✅ | `lab_test_prescription` → Service Request |
| Encounter: procedures | ✅ | `procedure_prescription` → Service Request |
| Encounter: therapies | ✅ | `therapies` → Service Request |
| Vitals entry (nurse queue + doctor encounter) | ✅ | `vital_signs.api.create_vital_signs` |
| Immunization schedule grid | ✅ | `immunizations.api` schedule |
| Immunization records CRUD (lot/site) | ✅ | `immunizations.api` |
| Immunization bulk program (Mexico EPI) | ✅ | `immunizations.api.apply-program` |
| Allergies (add/edit/remove/pin/comments) | ✅ | `patients.api` allergies |
| Conditions / problem list | ✅ | `patients.api` conditions |
| Medication history (view + resume/stop) | ✅ | `patients.api` medications |
| Document upload/view (categorized) | ✅ | `documents.api.upload_document` |

### 2.4 Billing, reports, admin, ops
| Feature | Status | Backend endpoint |
|---|---|---|
| Appointment invoice | ✅ | `billing.api.create_appointment_invoice` |
| Consolidated POS checkout (one invoice/visit) | ✅ | `billing.api.create_pos_invoice` + `get_patient_billables` |
| Collect payment (cash/card/transfer) | ✅ | `billing.api.collect_payment` |
| Invoice list (clinic-wide + patient) | ✅ | `billing.api.list_all_invoices` / `list_patient_invoices` |
| Payment history | ✅ | `billing.api.list_payment_entries` |
| AR / outstanding balances report | ✅ | `billing.report.get_outstanding_balances` |
| **Refund / credit note** (new on `dev`) | ✅ | `billing.api.create_credit_note` |
| Insurance policy management | ✅ | `insurance.api` policy CRUD |
| Claims status report (read-only) | ✅ | `insurance.report.get_claims_status` |
| All 16 reports + overview | ✅ | `*.report.*` |
| Settings masters (practitioners, meds, labs, dx, symptoms, items, insurance) | ✅ | `admin.api` |
| Admin command centre, multi-clinic, company profile, price lists | ✅ | `admin.api`, `company.api.get_companies` |
| WhatsApp messaging (send/receive/contacts/read) | ✅ | `/api/messages/*` |
| Work inbox (role-filtered tasks) | ✅ | `/api/my-work` |
| Search: patient / item / medication | ✅ | various search endpoints |
| Command palette (Cmd+K, patient chart) | ✅ | client-side |

---

## 3. The Danger Zone — UI accepts input, backend drops it

These let a user act, show no error, and **lose the data**. Ranked by risk.

| # | Area | User action | Reality | Source |
|---|---|---|---|---|
| 1 | **Cash register / shift** | Open float, collect, close, hand over drawer | **Local-state / localStorage only — never persisted to backend.** Reconciliation lost on cache clear | `cash-client.tsx` uses `lib/narzim/shift` |
| 2 | **Encounter → Vaccines administered** | Record vaccine, lot, site during visit | **Lost on Sign** — no doctype. Breaks Cartilla Nacional (legal, pediatric) | `encounter-screen.tsx` `TODO(backend)`; BACKEND_PENDING #3 |
| 3 | **Encounter → Screenings** | Order vision/hearing/dev screening | **Lost on Sign** — no doctype | BACKEND_PENDING #4 |
| 4 | **Encounter → Follow-up appointment** | "Follow up in 2 weeks" | **No appointment created** | BACKEND_PENDING #5 |
| 5 | **Encounter → Primary diagnosis flag** | Mark a diagnosis primary | **Flag silently dropped** (no `is_primary` field) | BACKEND_PENDING #8 |
| 6 | **Encounter → Rx (partial)** | Enter drug name without form/period | **Row silently dropped** — no validation warning | `encounter-screen.tsx` save guard |
| 7 | **Encounter → ROS / Physical Exam** | (sections in code) | Hidden/commented out — not saved | BACKEND_PENDING #1, #2 |
| 8 | **Lab results entry** | — | **No UI to enter result values**; read-only display only | `lab-center-tab.tsx` |
| 9 | **Referrals tab** | Create outbound/inbound referral | **Mock only — no backend endpoints** | `referrals-tab.tsx` |
| 10 | **Insurance coverage split tab** | View payor breakdown | Placeholder ("available when linked") | `billing-client.tsx` InsuranceTab |
| 11 | **Provider availability/stats** | View provider load | Deterministic **mock** (name-hash) | `providers-client.tsx` |

**Top two to act on:** #1 (unrecorded money handling — liability) and #2 (legally-required pediatric vaccine record).

---

## 4. Missing features a clinic SaaS should have

### 4.1 Legal / Mexico-specific (highest)
- ⬜ **CFDI / factura electrónica (SAT timbrado)** — no electronic tax invoice
- ⬜ **Cartilla Nacional de Vacunación** print/PDF export
- 🟠 **Invoice PDF / printed receipt** — button exists, no handler

### 4.2 Pediatric clinical
- ⬜ **Growth charts / percentiles** (WHO/CDC) — shown as mock insight only
- ⬜ **Weight-based dosing calculator** — doses computed by hand
- ⬜ **Drug-interaction / allergy alerts** — no contraindication warnings
- ⬜ **Developmental screening** tracking (Denver/ASQ)
- ⬜ Sibling / family-unit linking

### 4.3 Scheduling / operations
- 🔴 **Appointment reminders** UI — WhatsApp backend exists, no trigger
- ⬜ Recurring/follow-up series, **waitlist**, **double-booking guard**, **holiday/blackout blocking**, **walk-in** intake, telehealth/video, room assignment (button not wired)

### 4.4 Billing / finance
- ⬜ **Partial refunds** (only full credit-note today), payment plans/installments
- 🔴 **End-of-day reconciliation** report (only per-shift, local-state)
- ⬜ Discount/package management UI, batch invoicing, dunning/collections

### 4.5 Insurance
- ⬜ Claims **submission** workflow (only status report), pre-authorization, eligibility check, EOB/denial management, deductible tracking

### 4.6 Security / platform / admin
- 🔴 **2FA flow** — backend detects `two_factor_required`, no OTP screen
- ⬜ **App-level global search** (only patient-scoped today)
- ⬜ **Audit log viewer** (who changed what — compliance)
- ⬜ Session/device management, bulk import/export, message templates, API-key/webhook admin

---

## 5. Recommended priority

1. **Encounter persistence (Danger Zone #2, #4, #5, #7)** — backend work in `EB_Healthcare_Backend`. These corrupt the medical record today. See `docs/BACKEND_PENDING.md` in the frontend repo for the itemized list.
2. **Cash register (#1)** — persist shifts to the backend, or clearly label as non-authoritative. Unpersisted money handling is a liability.
3. **CFDI / facturación + invoice PDF** — operational blocker for a Mexican clinic.
4. **Rx validation (#6)** — make `dosage_form` + `period` hard-required so partial Rx can't be silently dropped (cheap, high safety value).
5. **Pediatric aids** (growth charts, weight-based dosing) — high value, can phase post-launch.

---

## 6. Notes & caveats
- Cross-references to `BACKEND_PENDING.md` are to the file in the **frontend** repo (`Healthcare_next_app/docs/`), which itemizes the encounter gaps with effort estimates.
- "Local-state" items (cash register) work within a browser session but are not durable and are invisible to other users/devices.
- This audit reflects `dev` as of the date above; the refund/credit-note flow landed recently and is included.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-30 | Sarvesh | Initial version (header backfilled from git history) |
