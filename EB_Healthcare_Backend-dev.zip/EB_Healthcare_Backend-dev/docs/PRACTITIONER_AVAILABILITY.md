# Practitioner Self-Service Availability — How It Works

**Doc status:** living · **Created:** 2026-09-08 by Divyanshu (AI-assisted) · **Updated:** 2026-09-15 by Divyanshu (AI-assisted) · **Version:** 5.1

**Status of the build: Done.** See [§6](#6-build-order) for the full per-file record.

**This document owns the mechanism.** The decision and rejected alternatives are owned by
[`adr/adr-062-practitioner-self-service-availability.md`](adr/adr-062-practitioner-self-service-availability.md);
this document does not restate them.

## 1. Scope

| In scope | Out of scope |
|---|---|
| A practitioner declaring themselves `Unavailable` for a date/time range (reduced hours or full day off) | Admin marking a practitioner unavailable (unchanged — full Desk access already exists) |
| A practitioner declaring themselves `Available` for extra time, including on a day with no normal schedule | Holiday List / company calendar **management** (unchanged — admin-only setup) |
| A practitioner **viewing** their own company's Holiday List, read-only (§5, added 2026-09-09) | Holiday/leave **enforcement** at booking time — pre-existing, and currently a no-op; see §5 and `docs/KNOWN_ISSUES.md` |
| Both staff and patient-portal booking screens reflecting either direction | — |
| Write-time booking enforcement covering self-declared time off **and** holidays/approved leave | — |

## 2. Matching core directly — no invented concepts

Earlier drafts of this design asked the practitioner to pick from their own named `Practitioner Schedule`
rows ("Morning Shift," etc.) as on/off toggles. That's dropped. **The screen mirrors core's own
`Practitioner Availability` fields exactly:**

- **Type** — Available or Unavailable
- **Start date, end date** — a continuous range, not a single date
- **Start time, end time**
- **Repeat** — Never / Daily / Weekly / Monthly, and (only for Weekly) which weekdays
- **Reason** (Unavailable only, matching core's own dropdown: Time Off / Break / Training / Travel / Emergency)
- **Note** — free text, both types (core's `note` field carries no `depends_on`, unlike `reason`)

No schedule names, no computed "leftover" time. A practitioner who wants to leave early types the window
they're **out for** ("Unavailable, 1pm–5pm"), not the window they're keeping. A single day off is a range
where start date equals end date — no separate control needed.

**Why Repeat needed its own fix, not a thin pass-through.** Core's `Practitioner Availability` stores
`repeat` and seven weekday checkboxes, but nothing in core itself ever reads them when deciding whether a
date is blocked — `get_practitioner_unavailability()`, the function this app originally called directly, is
a pure `start_date<=date<=end_date` check. A practitioner declaring "Weekly, Monday only" across a month
would, before the fix below, have been silently treated as unavailable **every day** in that range — the
screen would offer weekday checkboxes that don't actually change what gets blocked. See §4 for the fix.

## 3. The write path

```
Practitioner picks a type (Available/Unavailable), a start/end date,
a time range, and optionally Repeat + weekdays
                              │
                              ▼
   set_my_availability_override(type, start_date, end_date, start_time,
                                 end_time, reason?, repeat?, weekdays?)
              providers/api.py  ← ownership check: _session_practitioner()
                              │
                              ▼
     Insert Practitioner Availability
       scope=<practitioner>, start_date, end_date, repeat,
       monday..sunday flags set only when repeat == "Weekly"
       doc.insert(ignore_permissions=True)
                              │
                              ▼
     Core's validate() still runs (ignore_permissions bypasses DocPerm,
     not document validation) — an existing Patient Appointment inside an
     Unavailable window rejects the save here, with no new code for that
     check; overlapping Available records are rejected the same way.
```

`cancel_my_availability_override(name)` reverses a declaration — cancels the submitted record, same
ownership check.

**Multiple windows per day.** Each override is its own independent record, so this is already supported
without any backend change — the screen just needs to render a *list* of the date's existing overrides
(e.g. "Unavailable 12–1pm, Lunch break" and "Unavailable 3–5pm, Time Off" as two separate rows, each with
its own Remove), plus an "add another window" action, rather than a single-row form. See #11.

**The list screen shows everything, not one date's worth.** `list_availability_overrides(practitioner)` —
originally scoped to one date, matching the "Nothing set for this date" viewing-date filter shown on the
built screen — was widened, on request, to return **every** submitted override for the practitioner: past,
current, and future, in one table (newest `start_date` first). The date-scoped query and its viewing-date
filter UI were removed entirely, not just hidden — a practitioner reviewing their own history wants to see
everything they've declared, not filter it one day at a time.

**This is deliberately unrelated to the weekday-repeat correctness fix (§4).** That fix governs whether a
row actually **blocks or opens a booking** on a specific date — a completely different question from
whether this list **displays** the row at all. Removing the list's date-scoping does not touch, weaken, or
duplicate `applies_on_weekday` / `get_unavailability_for_date`, which remain exactly as they were and still
govern the two booking screens and the write-time guard.

**Table, not stacked cards.** The list renders as a proper `<table>` (Status · Dates · Time · Details ·
Remove), each row's Repeat pattern + Reason + Note collapsed into one **Details** column — a deliberate
simplification from showing all three as separate inline fragments.

## 3.5. Front Desk (and Admin) notification on declaration (ADR-062 decisions 12 + 13, 2026-09-14)

Found live: a practitioner blocked by §3's own conflict check had no path forward — core rejects the save,
names the conflicting appointments in its error text, and nothing happened after that. The practitioner
stayed stuck, the appointments stayed exactly as they were, nobody was told to act. Shipped, then corrected
the same day (decision 13) once checked against how My Work actually works — this section describes the
**final, shipped shape**; ADR-062 decision 12 is kept as a record of the first cut.

```
Unavailable, conflicts with appointments          Available, or Unavailable with nothing to reassign
        │                                                        │
        ▼                                                        ▼
find_unavailable_conflicts() — read-only,          set_availability_override() succeeds
same overlap math as core's own                    (core's own validate() has nothing to
validate_existing_appointments(),                   reject — no conflict is possible for
called BEFORE attempting the insert                 Available; a clean Unavailable simply
        │                                            has no conflicting appointment)
        ▼                                                        │
set_my_availability_override returns                             ▼
{"conflict": true, "conflicts": [...]}              create_front_desk_task(description)
at 200 — a business state, not an error               creates an unassigned ToDo (allocated_to=None,
        │                                              same shape as encounters.api's refund-task
        ▼                                              precedent) — dedup: exact description match
Frontend opens the REAL My Work task overlay         against a non-cancelled ToDo already there
(Sheet + CreateTodoForm, mirrored from                            │
inbox-tab.tsx) — pre-filled with the                              ▼
conflicting appointments (patient + [appt ID],       notify() → EB_Front Desk AND Admin, in-app alert
dd/mm/yyyy + 12h time), the practitioner's                        │
name + [ID], the reason, and a due date =            Both fire together — the notification's own
the declaration's start date. NEVER automatic.       "Open" action lands on My Work, so the ToDo
        │                                            must actually exist there to open onto.
        ▼ (only if the practitioner clicks Submit)
Existing useCreateTodo() → create_todo() flow —
a ToDo, never a Task. No bespoke backend
endpoint for this path (the earlier
create_availability_conflict_task was removed).
```

**Why the conflict case is a button, not automatic, while the other case is automatic — not an
inconsistency, a distinction that matters.** A conflict has something to review: which appointments, whose
patients, whether the reason given actually justifies creating work for Front Desk right now. A clean save
has nothing to review — there is no list to inspect, nothing to reconsider — so requiring a click there
would just be an extra step with no decision behind it. See ADR-062 alternatives 14-17 for the options this
was weighed against.

**`ToDo`, not `Task` — corrected same day.** My Work (`tasks/api.py::_fetch_todos`, `inbox-tab.tsx`) is
backed by core's `ToDo` doctype; `Task` is a Projects-module concept this app's task list never reads. The
first cut of this feature (ADR-062 decision 12) built against `Task` — corrected before release (decision
13) to `create_front_desk_task()` inserting a `ToDo` with `allocated_to=None`, the exact pattern
`encounters.api._create_refund_task_for_appointment` already established. Dedup changed to match: an exact
match on `ToDo.description` (there is no separate `subject` field), skipped when a non-cancelled row with
that description already exists — retrying an already-blocked or already-declared window creates nothing
new.

**The conflict overlay is the real one, not a copy.** The "Create task" button opens the actual
`CreateTodoForm` component (`components/narzim/inbox/todo-tab.tsx`), wrapped in a `Sheet` mirroring
`inbox-tab.tsx`'s own "New Task" panel chrome exactly — not a bespoke dialog. It is pre-filled
(`initialDescription`/`initialAssignTo`/`initialDueDate` props, added to `CreateTodoForm` for this) but
otherwise identical to opening "New Task" from My Work directly, including submitting through the same
`useCreateTodo()` hook. There is no backend endpoint specific to this path — the earlier
`create_availability_conflict_task` (and its BFF route) from decision 12 was removed once this was wired
up; conflict-path ToDo creation goes through the same `create_todo()` whitelisted method every other My
Work task uses.

**Automatic path: both a `ToDo` and a `notify()`, to Front Desk AND Admin.** For a clean save (Available, or
Unavailable with nothing to reassign), `create_front_desk_task()` fires unconditionally, and `notify()` is
called with `force_sync=True` targeting `_front_desk_users() + _admin_users()`. Both are needed together —
an interim version tried notify-only (no `ToDo`) and was corrected the same day, because the notification's
own "Open" action redirects to My Work, and there must be something there to open. Admin was added to the
recipient list for the same reason Front Desk is: whoever acts on the declaration needs to be told, and
Admin users are not guaranteed to also be Front Desk.

**Corrected 2026-09-15 — `create_front_desk_task()` now creates one ToDo per recipient, not one "owner."**
Until this fix, `notify()` already fanned out to the full `_front_desk_users() + _admin_users()` list above,
but `create_front_desk_task()` only ever inserted a *single* `ToDo`, assigned to `_front_desk_users()[0]`
sorted alphabetically by full name. In this app's actual user data that name was always `Administrator` —
a Frappe system account that gets every newly-created role (including `EB_Front Desk`) auto-granted to it,
and which sorts before every real staff name. So the notification fired for everyone, but the one place
with an actual actionable item ("Open" → My Work) only ever had something to show `Administrator`, never a
real Front Desk or Admin user. Found live investigating an unrelated report ("a practitioner was marked
unavailable but slots still show") — that report turned out to be correct behaviour, not a bug (the
declared window was a partial day, 9 AM-5 PM, not the full day). Fixed: `create_front_desk_task(description,
recipients, priority)` now takes the same recipient list `notify()` uses and inserts one `ToDo` per person
in it, with dedup checked per recipient (skip only someone who already has a non-cancelled ToDo with this
exact description) rather than a single global existence check. `Administrator` is not excluded from the
list — it still gets its own `ToDo` like everyone else holding the role — this fix only removes the
"pick just one" step that made it the *sole* recipient. See ADR-062 decision 14.

**No backdating.** Neither `set_availability_override()` nor `set_my_availability_override()` will accept a
`start_date` before today — checked at both layers (defense in depth), plus the date inputs on the frontend
form carry a `min` attribute and the form's own validation blocks submission before any request is sent.

**Cancel-guard: an Available override can't be pulled out from under a booking.** If a patient appointment
gets booked into an `Available` window a practitioner opened up, `cancel_availability_override()` now
refuses to remove that override until the appointment is reassigned, rescheduled, or cancelled first — it
re-runs `find_unavailable_conflicts()` against the override's own window and throws, naming the blocking
appointment(s), if any exist. Scoped to `Available` only — cancelling `Unavailable` is never blocked, since
there is nothing booked *into* time you declared yourself absent for.

**Two real, unrelated bugs found and fixed while building this.** (1) `notify()`'s normal deferred/Redis
delivery path silently delivers nothing whenever a document was written earlier in the same request —
reproduced deliberately, and confirmed present for other, pre-existing, unrelated records too. Fixed here
via a new `force_sync` parameter on `notify()` (`services/notifications.py`), used only at this call site.
(2) `api/v1/notifications/api.py` requested a nonexistent `description` column on core's `Notification Log`
(the real field is `email_content`) — this broke the entire notifications list page, for every user, for
every notification type. Neither bug is specific to this feature; both are recorded in ADR-062 decision 13.

## 4. The read path

**`Unavailable` — built, then corrected.** Both `appointments/api.py::get_available_slots` and
`patient_portal/api.py::get_my_available_slots` originally called core's own `get_practitioner_unavailability()`
directly and merged its rows in. That function is a pure `start_date<=date<=end_date` containment check — it
never reads the doctype's own `repeat`/weekday fields. Once the write side started accepting Repeat and
weekday ticks (§2, §3), this became a real bug, not a latent one: a "Weekly, Monday only" declaration was
silently treated as "every day in the range" by every caller.

**The fix — `services/availability.py`:**

- `applies_on_weekday(row, date)` — true unless `row.repeat == "Weekly"` and `date`'s weekday isn't one of
  the seven ticked fields. `Daily`/`Monthly`/`Never` have no extra distinguishing fields on the doctype (the
  weekday checkboxes `depends_on repeat=="Weekly"` only), so they still mean "every day in the range" — that
  is what the doctype can actually express, not a shortcut taken here.
- `get_unavailability_for_date(practitioner, date)` — a weekday-aware drop-in replacement for core's
  function, same field shape (`appointment_date`/`appointment_time` aliases, `duration`, `type`), now called
  at all three sites that used to call core's function directly: `get_available_slots`,
  `get_my_available_slots`, and `assert_bookable`'s self-declared-`Unavailable` check.
- The same filter was added to `_override_ranges` (the `Available`-direction read behind
  `generate_override_slots`, below) and to `list_availability_overrides` (the self-service list view), so
  "does this row apply to this date" agrees everywhere the question is asked — the list screen, both booking
  screens, and the write-time guard.

**`Available` — the one genuinely new piece of read-side logic this feature adds.** Nothing in this app has
ever generated bookable slots from anything but the weekly `Practitioner Schedule` template. A new shared
function, `services/availability.py::generate_override_slots(practitioner, date, ...)`, reads `Available`
rows for that practitioner/date (weekday-filtered per the fix above) and produces additional slots for that
window — called from both booking functions alongside their normal generation, so an `Available` override
works even on a day the practitioner has no schedule at all.

**Avoiding double-counted slots.** Before generating, the function first subtracts whatever the normal
weekly schedule already covers that weekday from the `Available` window, and generates slots only for
what's left. Worked example: a practitioner normally works Tuesday 9am–5pm and adds an `Available` override
for 3pm–7pm. The 3pm–5pm portion is already produced by the base-schedule generation, so it's skipped;
only 5pm–7pm — the genuinely new part — gets generated. On a day with no normal schedule at all, there's
nothing to subtract, so the full override window generates fresh.

**Slot duration — corrected 2026-09-10, was hardcoded.** Generated slots use `_default_slot_minutes()`
(`services/availability.py`): `Healthcare Settings.default_appointment_type`, resolved to that Appointment
Type's own `default_duration` — the same "how long is a normal visit here" field core's own booking flow
already reads, not a private guess. Falls back to a `_FALLBACK_SLOT_MINUTES = 20` constant only when that
chain is unset on a bare/misconfigured site — that fallback, not the resolution itself, is what matches
`scripts/seed/seed_practitioner_schedules.py`'s own seeded 20-minute default. Resolved fresh on every call
(not cached at import time), so a change to Healthcare Settings takes effect on the next request. A caller
may still pass an explicit `slot_minutes` to override this entirely (existing tests do, to exercise a
specific granularity) — core's doctype still carries no per-record duration/capacity field of its own to
read instead, which is why this lives here rather than on `Practitioner Availability` itself.

**Known, not fixed here:** the practitioner's own normal-schedule slots (from core's `Practitioner
Schedule` / `Healthcare Schedule Time Slot.duration`) can use a *different* duration than the resolved
clinic default above — e.g. a practitioner whose regular schedule is configured at 15 minutes will still
see their `Available`-override slots generated at whatever the clinic default resolves to (commonly 20),
producing two different granularities in the same day's grid. Cosmetic, not a booking-correctness issue
— every generated slot is still individually real and bookable.

**Corrected 2026-09-10, same day this was first written:** the obvious next idea — read the
practitioner's own normal-schedule duration instead, falling back to the clinic default only when no
schedule exists — is not a viable fix, not merely undecided. This function exists specifically so an
`Available` override works on a day the practitioner has **no** normal schedule at all (see above) —
the one case that needs a duration most is exactly the case with nothing to derive one from. A
practitioner can also carry more than one `Practitioner Schedule` at different durations, so even "read
the schedule" has no single well-defined answer when a schedule does exist.

**Built the same day instead: duration now follows the appointment type actually being booked, when one
is known.** `get_available_slots`/`get_my_available_slots` gained an optional `appointment_type`
parameter, passed through to a new `services/availability.py::_slot_minutes_for(appointment_type)`: that
type's own `default_duration` when it resolves to one, else falling through to `_default_slot_minutes()`
above unchanged. `generate_override_slots`'s resolution order is now explicit `slot_minutes` (unchanged)
→ `appointment_type`'s own duration → clinic-wide default. Checked against the actual frontend rather
than assumed: `new-appointment-dialog.tsx` already selects an Appointment Type (`visitTypeKey`) in Step 1,
before the Schedule step requests slots, and the reassign dialog already carries the original
appointment's `appointment_type` — both now pass it through. `patient_portal/api.py::
get_my_available_slots` accepts the same parameter, but no frontend caller in this repo supplies one yet
(that surface lives elsewhere, unverified) — a no-op until it does, never a regression.

**Still not the same as matching the practitioner's own schedule.** This makes the override duration
correct for *what's being booked*, not for *who normally works this schedule* — a 15-minute normal
schedule and a 20-minute-appointment-type override can still show different granularities in the same
day's grid. See `docs/KNOWN_ISSUES.md` for that narrower, still-open gap.

**A window that doesn't divide evenly into the resolved duration silently loses its last few minutes —
by design, not a bug.** `generate_override_slots`'s loop only appends a slot when a *full* `step` fits
before `covered`'s/the override's own end time:

```python
while cursor + step <= r_end:
    append {from: cursor, to: cursor + step}
    cursor += step
```

Example verified 2026-09-10: an override of 5:00 PM–11:59 PM at a 45-minute duration (`"QA Reschedule
Long"`) produces its last slot at 11:00 PM–11:45 PM; the final 14 minutes (11:45 PM–11:59 PM) can never
become a slot, because one starting there would run to 12:30 AM — past the declared 11:59 PM end. This
is the same mechanism reported earlier for a 20-minute duration (stopped at 11:20 PM, losing 19 minutes)
— it now surfaces at a different remainder because the duration itself is appointment-type-dependent
(decision 11), not because anything about the boundary logic changed.

**The real confusion this causes: each slot button is labeled by its start time only, not its range** —
so an "11:00 PM" button silently covering 45 minutes (until 11:45 PM) reads, at a glance, like the
grid simply stops offering evening/night times right after it, when it doesn't. Recorded as an open,
purely-frontend improvement in `docs/KNOWN_ISSUES.md` (show each slot's end time on its button) — not
built here.

## 5. Holiday list (read-only)

**Added 2026-09-09.** The same profile screen also shows the practitioner's company holiday calendar,
read-only — no add/edit/delete, matching §1's scope split above. Decision and rejected alternatives are
owned by ADR-062 decision 9 (this section, like §2-§4, owns only the mechanism).

```
GET get_my_holidays()
  providers/api.py  ← _session_practitioner(), same ownership pattern as every
                       other self-service endpoint on this screen
              │
              ▼
  get_practitioner_holidays(practitioner)
    services/providers.py
              │
              ▼
    Healthcare Practitioner.custom_company
              │  (the "home clinic" field dashboard.py/report.py already use)
              ▼
    Company.default_holiday_list
              │
              ▼
    Holiday List.holidays  →  [{date, description}, ...] sorted ascending
```

**Not Employee-based.** Core's `check_employee_wise_availability` (already called by §3's `assert_bookable`)
resolves the practitioner's Employee first, but this app has never linked one to a Healthcare Practitioner
(ADR-062 Alternative 4, verified). Going the same route here would return an empty list for every
practitioner — so this reads `custom_company` instead, the same field this app already uses everywhere else
it needs a practitioner's home clinic.

**A pre-existing gap this surfaced, not fixed here.** Because the Employee lookup above always comes back
empty, `assert_bookable`'s holiday/leave check has never actually blocked a booking on a holiday in this
app — it's a silent no-op, not a working guard with no test. See `docs/KNOWN_ISSUES.md` §"Holiday/leave
enforcement in assert_bookable is a silent no-op" and ADR-062 decision 9's Verification-table correction.
This section's read-only display does not depend on that guard working and does not fix it.

**Empty states are not errors.** No `custom_company` on the practitioner, or a company with no
`default_holiday_list` configured, both return `{"holiday_list": null, "holidays": []}` — an admin-setup
gap the frontend renders as "no holiday list configured," not a failure.

**Frontend:** `practitioner-holidays-card.tsx`, a plain read-only table (Date, Description) — no toggle, no
add/edit/delete controls, same card-header visual language as `practitioner-availability-card.tsx` (§2-§4)
but with nothing interactive in the body.

## 6. Build order

File-by-file checklist, backend first end-to-end, then frontend against a working backend. Mark each row
`Done` as it lands — this table is the single place build status lives for this feature (one fact, one
owner); do not track progress a second time anywhere else.

**Backend — `remedisys_healthcare_ai`**

| # | File | Work | Status |
|---|---|---|---|
| 1 | `services/providers.py` | `list_availability_overrides(practitioner)` — **no date param**, returns every submitted (docstatus=1) override for the practitioner, both types, past/current/future, newest `start_date` first; each row still carries its own `weekdays` summary. `set_availability_override(practitioner, availability_type, start_date, end_date, start_time, end_time, reason=None, repeat="Never", weekdays=None, note=None)` and `cancel_availability_override(practitioner, name)` — insert + submit / cancel the `Practitioner Availability` row via `ignore_permissions=True` (submit matters: `get_unavailability_for_date` filters `docstatus=1`, a Draft row is invisible). `note` is core's own free-text field, accepted for both types (unlike `reason`, which the doctype restricts to Unavailable) | **Done** |
| 2 | `api/v1/providers/api.py` | `list_my_availability_overrides()` — **date param removed**, `set_my_availability_override(availability_type, start_date, end_date, start_time, end_time, reason=None, repeat=None, weekdays=None, note=None)`, `cancel_my_availability_override(name)` — thin `_session_practitioner()`-checked wrappers around #1 | **Done** |
| 3 | `services/availability.py` *(new)* | `generate_override_slots(practitioner, date, covered_ranges, slot_minutes=None, appointment_type=None)` — subtracts caller-supplied normal-schedule coverage from each `Available` window, generates new slots for what's left, at a duration resolved via `_slot_minutes_for(appointment_type)`: that appointment type's own `default_duration` when known, else `_default_slot_minutes()` (Healthcare Settings' configured appointment duration, falling back to 20 min only if unset). `assert_bookable(practitioner, appointment_date, appointment_time, duration)` — write-time guard: holiday/leave, self-declared `Unavailable` overlap, and `Available`-window coverage for any time outside the normal schedule. `applies_on_weekday(row, date)` + `get_unavailability_for_date(practitioner, date)` — the weekday-repeat correctness fix (§4); `_override_ranges` also weekday-filtered | **Done** |
| 4 | `api/v1/appointments/api.py` | `assert_bookable` called from `_create_impl` (booking creation) and `reschedule_appointment`, before save. `generate_override_slots` called from `get_available_slots`, overlap-checked against existing bookings the same way base-schedule slots are. `get_available_slots`'s own `Unavailable` merge now calls `get_unavailability_for_date` instead of core's `get_practitioner_unavailability` directly (§4 fix). **Bug found and fixed while wiring this in:** the function originally returned an empty grid immediately whenever the practitioner had no normal schedule for that day — which would have silently hidden `Available` overrides on exactly the "day with no normal schedule" case (e.g. picking up an extra Saturday) this feature exists to support. Restructured so a missing normal schedule no longer short-circuits before override slots are considered; the empty-grid response is now the *last* thing checked, not the first | **Done** |
| 5 | `api/v1/patient_portal/api.py` | `book_my_appointment` already calls the shared `_create_impl` from #4, so booking creation was already covered — confirmed, no change needed there. `reschedule_my_appointment` saves standalone (not via `_create_impl`) and got its own `assert_bookable` call. `get_my_available_slots` got `generate_override_slots` wired in (same empty-schedule bug fixed as #4) and its `Unavailable` merge switched to `get_unavailability_for_date` | **Done** |
| 6 | `tests/providers/test_availability_override.py` *(new)* | Ownership rejection (guest, foreign practitioner), both types insert/submit/cancel correctly, core's overlap/conflict checks surface cleanly (Unavailable vs. existing appointment, Available vs. Available), list excludes cancelled rows, `list_availability_overrides` reports `weekdays` correctly, `note` round-trips for both types, invalid `repeat` rejected, a multi-day range persists distinct `start_date`/`end_date`. 17 tests. **Two tests removed** when the list's date-scoping was retired (their whole premise — probing the list per date — no longer applies to this function); replaced with a lighter persistence check. The weekday-repeat correctness fix itself stays fully covered, unweakened, in #7 — that's the code path (booking enforcement) it actually matters for | **Done** |
| 7 | `tests/appointments/test_availability_enforcement.py` *(new)* | Direct unit tests of `generate_override_slots` (empty/full/fully-covered/partial-overlap, the §4 worked example, **weekday-repeat regression**) and `assert_bookable` (holiday mock, self-declared Unavailable, inside/outside normal schedule, covered-by-Available, no-normal-schedule-at-all, **weekday-repeat regression through the actual guard**). Integration tests through both real booking surfaces: staff (`get_available_slots`, `_create_impl`, `reschedule_appointment`) and portal (`get_my_available_slots`, `book_my_appointment`, `reschedule_my_appointment`) — confirms `book_my_appointment` shares the exact same guard via `_create_impl`, not a duplicate. **Plus the "full day off" scenario** (`test_full_day_unavailable_blocks_every_normal_schedule_slot_and_booking`, added 2026-09-08): Unavailable, Start Date = End Date, `00:00:00`–`23:59:00` — the exact range the frontend's Add form produces when a practitioner marks a whole day off (the `<input type="time">` field caps at 23:59). Confirms the Default Schedule's real slot rows (09:00–21:00, 30-minute) all come back `available: false` / `blocked: true` (not just fewer slots), `assert_bookable` rejects morning/midday/evening times across the day, and the actual `_create_impl` booking path rejects a create attempt the same way. Verified green via `bench --site remedisis.localhost console` piped a throwaway runner script (`bench run-tests` is broken app-wide on this site — see the test file's own module docstring), deleted after the run. 19 tests | **Done** |
| 14 | `services/providers.py` + `api/v1/providers/api.py` | §5's `get_practitioner_holidays(practitioner)` + whitelisted `get_my_holidays()` wrapper — read-only, Company-resolved, no write path | **Done** |
| 15 | `tests/providers/test_holidays.py` *(new)* | Company-resolved happy path (holidays sorted ascending, wrapper's response shape) + no-`custom_company` empty-state. 2 tests. **Not yet run** — same `bench run-tests` breakage as #6/#7; written to be run the same `bench console` + throwaway-script way, not executed this session | **Written, unverified** |

**Frontend — `EB_Healthcare_Frontend`**

| # | File | Work | Status |
|---|---|---|---|
| 8 | `src/app/api/providers/me/availability/route.ts` *(new)* | BFF route: GET → `list_my_availability_overrides` (**no query param anymore** — was `?date=`), POST → `set_my_availability_override` (validates `start_date`/`end_date` instead of a single `date`), DELETE → `cancel_my_availability_override` (DELETE-with-JSON-body, matching this codebase's existing convention) | **Done** |
| 9 | ~~`src/hooks/use-my-availability.ts`~~ | **Plan deviation, evidence-based:** the sibling self-service cards already on this exact page (`PractitionerProfileCard`, `NotificationPrefsCard`, `PersonalInfoCard`) all do plain `fetch`/`useState` inline, not a react-query hook file — react-query hooks are the convention for *admin* resources (`use-admin-practitioner-schedules.ts`), not this page's self-service cards. Matched the page's own established pattern instead of forcing a mismatched one in; the fetch/mutate logic lives directly in #11 | **Done (folded into #11)** |
| 10 | `src/types/providers.ts` | `AvailabilityOverrideType`, `AvailabilityOverrideReason`, `AvailabilityRepeat`, `Weekday`, `AvailabilityOverride` (now carries `start_date`/`end_date`/`repeat`/`weekdays`/`note`) — already re-exported via the existing `@/types` barrel | **Done** |
| 11 | `src/components/providers/practitioner-availability-card.tsx` *(new)* | Self-contained card (no props needed — always the logged-in practitioner, no admin equivalent exists): **no viewing-date filter** — a **table** (Status · Start Date · End Date · Time · Pattern · Details · Remove) listing every declared override, past and future. `formatDMY()` renders every displayed date as dd/mm/yyyy; `formatTime12h()` renders every displayed time as 12-hour with AM/PM (both display-only — the underlying values stored/sent stay `YYYY-MM-DD`/24-hour `HH:MM` throughout, and the native `<input type="date"/"time">` fields in the form are unaffected). Start Date and End Date are separate columns, not one combined range. `patternFor()` shows the repeat type alone — "One day" for `Never`, "Daily"/"Monthly" as-is, "Weekly (Mon, Wed)" — with no date text duplicated into it. `detailsFor()` stays Reason + Note only. A `RequiredMark` (red `*`) marks every field the backend actually requires — start/end date, start/end time, and weekdays (only while Repeat = Weekly, matching the existing `pickAWeekday` validation) — matching real backend requiredness, not decoration. **The add form is now a modal `Dialog`** (`open={adding} onOpenChange={setAdding}`), not the earlier inline expanding block — matches this page's own existing `ChangePasswordDialog` convention exactly; the "+ Add" header button is always visible (no longer hidden while the form is open, since it no longer occupies the card's own layout). Form fields unchanged: type toggle, start/end date, start/end time, Repeat selector, weekday toggle-buttons (Weekly only), reason, and a free-text note textarea (both types, unlike reason). Surfaces the core conflict error and two client-side validations (end-before-start, no weekday ticked for Weekly) inline via `saveError` | **Done** |
| 12 | `src/app/(clinic)/profile/page.tsx` | Rendered as its own full-width card below the Personal Info / Practitioner Profile row, gated on `user.practitioner` (same gate as the profile card) — no `route-access.ts` change, `/profile` is already open to every authenticated role | **Done** |
| 13 | `messages/en.json`, `messages/es.json` | `profile.availability` namespace (grew from 21 through several rounds — range/Repeat/weekday, `note`/`notePlaceholder`, table headers, `pattern`, `viewTitle`; `dateRange` removed once Start/End Date became separate columns, `oneDay` re-added for the Pattern column's `Never` label), inserted as a sibling of `profile.practitioner`; both files validated to still parse as JSON after editing | **Done** |
| 16 | `src/app/api/providers/me/holidays/route.ts` *(new)* | BFF route: GET only → `get_my_holidays` — no POST/DELETE, matching the read-only scope (§1, §5) | **Done** |
| 17 | `src/types/providers.ts` | `PractitionerHoliday` (`date`, `description`), `PractitionerHolidays` (`holiday_list: string \| null`, `holidays: PractitionerHoliday[]`) | **Done** |
| 18 | `src/components/providers/practitioner-holidays-card.tsx` *(new)* | Read-only card: same header/icon visual language as `practitioner-availability-card.tsx` (§2-§4), a plain table (Date, Description), no toggle/add/edit/delete anywhere in the body. Renders a "no holiday list configured" empty state when `holiday_list` is `null`, not an error | **Done** |
| 19 | `src/app/(clinic)/profile/page.tsx` | Rendered alongside `PractitionerAvailabilityCard`, same `user.practitioner` gate | **Done** |
| 20 | `messages/en.json`, `messages/es.json` | New `profile.holidays` namespace | **Done** |
| 21 | ~~`src/app/api/providers/me/availability/conflict-task/route.ts`~~ | **Superseded same day (row #30):** built against the removed `create_availability_conflict_task` endpoint; deleted once the conflict button was wired to the real `CreateTodoForm`/`useCreateTodo()` flow instead | **Removed** |
| 22 | `src/types/providers.ts` | `AvailabilityConflictAppointment`, `AvailabilitySaveResult` (conflict branch gained `practitioner_name`) | **Done** |
| 23 | `src/components/providers/practitioner-availability-card.tsx` | Conflict state (`conflictInfo` — now including `practitionerId`/`practitionerName`), the inline conflict banner + scrollable appointment list (`max-h-32 overflow-y-auto`) | **Done, revised (row #30)** |
| 24 | `messages/en.json`, `messages/es.json` | New `profile.availability.conflictBanner`/`createTaskButton`/`conflictTask*`/`startDateInPast` keys | **Done** |
| 25 (backend) | `services/availability.py` | `find_unavailable_conflicts()` — also reused by the row #33 cancel-guard | **Done** |
| 26 (backend) | `services/providers.py` | `_front_desk_users()`, `create_front_desk_task()` — corrected to insert a `ToDo`, not a `Task` (row #30) | **Done, revised** |
| 27 (backend) | `services/notifications.py` | `EVENT_TYPES` gained `practitioner_unavailable_conflict` (declared, unused), `practitioner_availability_declared` | **Done** |
| 28 (backend) | `api/v1/providers/api.py` | `set_my_availability_override` returns `{"conflict": bool, ...}`; ~~new `create_availability_conflict_task`~~ removed same day (row #30) | **Done, revised** |
| 29 (backend) | `tests/providers/test_availability_override.py` | `TestAvailabilityNotifications` (renamed from `TestFrontDeskTaskOnAvailability`), 3 tests | **Done, revised** |
| 30 (backend + frontend) | `services/providers.py`, `api/v1/providers/api.py`, `practitioner-availability-card.tsx`, `todo-tab.tsx` | **Same-day correction (ADR-062 decision 13):** `create_front_desk_task()` switched from `Task` to `ToDo` (unassigned, `encounters.api`'s refund-task pattern); `create_availability_conflict_task` endpoint + its BFF route removed; the conflict button now opens the real `CreateTodoForm`/`Sheet` overlay (mirrored from `inbox-tab.tsx`), pre-filled via new `initialDescription`/`initialAssignTo`/`initialDueDate` props on `CreateTodoForm`, submitting through the existing `useCreateTodo()` hook | **Done** |
| 31 (backend) | `api/v1/providers/api.py` | Automatic path (Available / clean Unavailable) now creates a `ToDo` **and** calls `notify(force_sync=True)` targeting Front Desk + Admin, reversing an interim notify-only version | **Done** |
| 36 (backend) | `services/providers.py`, `api/v1/providers/api.py`, `tests/providers/test_availability_override.py` | **2026-09-15 correction:** `create_front_desk_task()` was creating only one `ToDo`, for one alphabetically-picked "owner" — which always resolved to the `Administrator` system account, never real staff. Changed to create one `ToDo` per recipient (the same Front Desk + Admin list `notify()` already used), deduped per recipient. Two tests renamed/rewritten to match | **Done, tests not yet run** |
| 32 (backend + frontend) | `services/providers.py`, `practitioner-availability-card.tsx` | No-backdating: server-side check in `set_availability_override()`/`set_my_availability_override()`; client-side `min` attribute on the Start/End Date inputs + `validationMessage()` check | **Done** |
| 33 (backend) | `services/providers.py`, `services/availability.py` | Cancel-guard: `cancel_availability_override()` refuses to remove an `Available` override while a `Patient Appointment` is booked into its window | **Done** |
| 34 (backend) | `services/notifications.py` | New `force_sync: bool` param on `notify()` — forces synchronous, in-process delivery instead of the default deferred Redis-queued path, fixing a reproduced (and pre-existing, unrelated) delivery failure | **Done** |
| 35 (backend) | `api/v1/notifications/api.py` | Unrelated pre-existing bug fixed in passing: `description` (nonexistent column) → `email_content` (the real `Notification Log` field), in `_serialize()` and `list_notifications()` | **Done** |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 5.1 | 2026-09-15 | Divyanshu (AI-assisted) | §3.5 gained a correction note: `create_front_desk_task()` was creating only one `ToDo` (for one alphabetically-picked "owner" — always `Administrator` in this app's real data, since it auto-holds every role and sorts first), even though `notify()` already fanned out to the full Front Desk + Admin list. Fixed to create one `ToDo` per recipient, matching who `notify()` already told. Found live while investigating an unrelated report that turned out to be correct behaviour (a partial-day availability window, not a bug). §6 gained row #36. See ADR-062 decision 14 |
| 5.0 | 2026-09-14 | Divyanshu (AI-assisted) | §3.5 rewritten (ADR-062 decision 13, same day as 4.0): corrected `Task` to `ToDo` throughout — My Work is backed by `ToDo`, `Task` is a Projects-module concept this app's list never reads; removed `create_availability_conflict_task` and its BFF route, replaced with the conflict button opening the real `CreateTodoForm`/`Sheet` overlay pre-filled; automatic path now creates a `ToDo` **and** `notify()`s Front Desk **and** Admin (an interim notify-only version was tried and reversed the same day, since the notification's "Open" action needs a `ToDo` on My Work to land on); added no-backdating (client + server) and a cancel-guard on `Available` overrides with a booked appointment; recorded two unrelated pre-existing bugs found and fixed (`notify()`'s deferred-delivery failure, `notifications/api.py`'s wrong column name). §6 rows #21, #23, #26, #28, #29 revised; rows #30-35 added |
| 4.0 | 2026-09-14 | Sarvesh-SocialAngel (AI-assisted) | Added §3.5 "Front Desk task on declaration" (ADR-062 decision 12) — a conflicting Unavailable declaration no longer dead-ends: `find_unavailable_conflicts()` pre-checks the same conflict core would find, and instead of the practitioner hitting a raw error, the frontend offers an explicit "Create task" button with the conflicting appointments shown inline; a clean Available or Unavailable save creates the Task automatically instead, since there is nothing to review. Both dedupe on an exact Task-subject match (core `Task` has no reference field). Found live via two screenshots while investigating NH-118; §6 gained rows #21-29 |
| 3.19 | 2026-09-10 | Divyanshu (AI-assisted) | §4 gained two notes from live testing with `"QA Reschedule Long"` (45-min duration): the loop's boundary condition can leave a window's last few minutes unbookable when it doesn't divide evenly by the resolved duration (by design — worked example: 5-11:59 PM at 45 min stops at 11:00-11:45 PM, same mechanism as the earlier 20-min case, different remainder); and the real confusion it causes — slot buttons show only a start time, not a range, making a covered slot look like a gap. The second is recorded as an open frontend improvement in `docs/KNOWN_ISSUES.md`, not built |
| 3.18 | 2026-09-10 | Divyanshu (AI-assisted) | §4 gained "Built the same day instead" — override-slot duration now prefers the booked appointment type's own `default_duration` (new optional `appointment_type` param, ADR-062 decision 11), checked against the real frontend rather than assumed infeasible: `new-appointment-dialog.tsx` and the reassign dialog already carried an Appointment Type in state before requesting slots. Wired through both; patient-portal caller unverified. §6 table row #3 updated. Narrows, does not close, the schedule-vs-override mismatch — still tracked in `docs/KNOWN_ISSUES.md` |
| 3.17 | 2026-09-10 | Divyanshu (AI-assisted) | Corrected §4's own "Known, not fixed here" note from 3.16, same day — it had floated "derive from the practitioner's own schedule" as an open follow-up, when that idea directly contradicts this section's own explanation of why `generate_override_slots` exists (to work on a day with no schedule at all). Replaced with the one option that doesn't need a schedule to exist: the override declaring its own explicit duration |
| 3.16 | 2026-09-10 | Divyanshu (AI-assisted) | §4's slot-duration paragraph corrected: `generate_override_slots` no longer takes its 20-minute grid from a private hardcoded constant — it now resolves `_default_slot_minutes()` (`services/availability.py`), reading `Healthcare Settings.default_appointment_type` → that Appointment Type's `default_duration`, with the old constant demoted to `_FALLBACK_SLOT_MINUTES`, used only when that chain is unset. Resolved per call, not cached at import time. Added a new "Known, not fixed here" note: a practitioner's own normal-schedule slot duration can still differ from the resolved clinic default, so the day's grid can show two granularities side by side — cosmetic, not a booking-correctness gap. §6 table row #3 updated to match |
| 3.15 | 2026-09-09 | Divyanshu (AI-assisted) | Added §5 "Holiday list (read-only)" — new `get_practitioner_holidays`/`get_my_holidays` (Company-resolved, not Employee-based) plus a new read-only frontend card on the same profile screen. §1's Scope table split the Holiday List row into "management" (still out of scope) vs. "viewing" (now in scope). Corrected the same silent-no-op finding as ADR-062 v1.7: `assert_bookable`'s holiday/leave check has never actually fired in this app. Old §5 "Build order" renumbered to §6, gained rows #14-#20 |
| 3.14 | 2026-09-08 | Divyanshu (AI-assisted) | Fixed the matching stale `Run:` block flagged (but left untouched) in 3.13 — `test_availability_override.py` (file #6) carried the identical wrong `bench --site marley.local run-tests --module ...` line. Same replacement as 3.13: real site (`remedisis.localhost`), the `bench console` + throwaway-runner workaround in place of broken `run-tests`. Comment-only; no test logic changed. Both this feature's test files' module docstrings are now accurate |
| 3.13 | 2026-09-08 | Divyanshu (AI-assisted) | Corrected a stale comment noticed while writing the 3.12 test: `test_availability_enforcement.py`'s module docstring told a reader to run `bench --site marley.local run-tests --module ...`, which is wrong on both counts — the real site is `remedisis.localhost`, and plain `run-tests` is broken app-wide on this bench (ERPNext's `BootStrapTestData` is non-idempotent under the `es` default language). Replaced with the actual working method used to run the 3.12 test: `bench --site remedisis.localhost console`, piped a throwaway `unittest` runner script. Comment-only; no test logic changed. `test_availability_override.py` (file #6) carries the same stale `marley.local run-tests` line and has not been touched — flagged, not fixed, pending a separate go-ahead |
| 3.12 | 2026-09-08 | Divyanshu (AI-assisted) | Requested: verify the "full day off" scenario end to end. Added `test_full_day_unavailable_blocks_every_normal_schedule_slot_and_booking` to `tests/appointments/test_availability_enforcement.py::TestStaffBookingEnforcement` — Unavailable, same start/end date, `00:00:00`–`23:59:00` (the exact range the Add form's `<input type="time">` fields produce for a whole-day-off entry). Confirms the Default Schedule's real 09:00–21:00 slot rows all come back blocked (not merely fewer of them), `assert_bookable` rejects morning/midday/evening times across the day, and `_create_impl` rejects an actual booking attempt. Ran via `bench --site remedisis.localhost console` with a throwaway runner script (per the documented `bench run-tests` workaround), deleted after: **1 test, OK**. No production code changed — this confirms existing behavior, it did not need a fix. 19 tests total in this file (was 18) |
| 3.11 | 2026-09-08 | Divyanshu (AI-assisted) | Reported: for a same-day range with only the time wrong (e.g. Start/End Date both 09/08/2026, Start Time 09:00 AM, End Time 05:00 AM), 3.8's combined message — "End date and time must be after the start date and time." — named the date too, even though the date was correct and only the time was the problem. Split `validationMessage()`'s single combined `combinedDateTime()` comparison back into two separate, order-sensitive checks: `endDate < startDate` → date-specific message (`endDateBeforeStart`, restored); `endDate === startDate && endTime <= startTime` → time-specific message (`endBeforeStart`, reworded back to "End time must be after start time."). A range spanning to a later end date is still always valid regardless of what the times say (unchanged from 3.8) — only the *messaging* changed, not which ranges are accepted. `combinedDateTime()` removed as dead code |
| 3.10 | 2026-09-08 | Divyanshu (AI-assisted) | Moved the 3.9 validation hint from just above the Save/Discard buttons (bottom of the form, after Note) to directly under the modal's title (top of the form, before Status) — seen immediately on opening or on the first invalid edit, not only after scrolling past every field. No new logic: still the one `clientValidationMessage` = `validationMessage()` computed live from current form state, rendered verbatim (whichever of `missingRequired`/`pickAWeekday`/`endBeforeStart` is currently failing) — generic by construction, since it was already a single function covering all three checks rather than one hardcoded string. The duplicate box at the bottom was removed, not kept as a second copy |
| 3.9 | 2026-09-08 | Divyanshu (AI-assisted) | Reported via screenshot: the disabled Save button gave no visible reason why (shown case — Start/End Date both 09/08/2026, Start Time 09:00 AM, End Time 05:00 AM — same-day range where end is before start, silently disabled with no explanation). Refactored 3.8's `mandatoryFieldsFilled()`/`isFormValid()` into one `validationMessage()` that returns the specific reason string (or `null` when valid) instead of a bare boolean, computed fresh on every render as `clientValidationMessage`. That message now renders live, in an amber inline hint box right above the Save/Discard buttons, the moment the form becomes invalid — not only after a failed Save click — and the same string is also set as the button's `title` tooltip. `handleAdd()` keeps a defensive re-check but can no longer actually surface its own error through normal use, since the button is disabled (`saving \|\| !!clientValidationMessage`) whenever a reason exists. No new i18n keys — reuses `missingRequired`/`pickAWeekday`/`endBeforeStart` from 3.8 |
| 3.8 | 2026-09-08 | Divyanshu (AI-assisted) | Requested stronger Add-form validation, frontend-only. Fixed a real bug in the process: the old checks compared `endDate < startDate` and `endTime <= startTime` as two independent conditions, which wrongly rejects a valid overnight/multi-day range (e.g. 2026-09-10 09:00 → 2026-09-12 08:00 spans midnight and is valid, but the old `endTime <= startTime` check alone would have blocked it). Replaced with a single `combinedDateTime(date, time)` comparison — `"YYYY-MM-DDTHH:MM"` strings sort the same lexicographically as chronologically — so the full start moment vs. end moment is compared, not date and time separately. Added `mandatoryFieldsFilled()`/`isFormValid()`, used both to block `handleAdd()` with a `missingRequired` error and to `disabled`-gate the Save button itself (`saving \|\| !isFormValid()`), so an incomplete or invalid form cannot be submitted at all rather than only erroring after the click. i18n: `endDateBeforeStart` removed as dead (its check no longer exists standalone), `endBeforeStart`'s text reworded to describe the combined check, new `missingRequired` key added — both locales validated to still parse as JSON |
| 3.7 | 2026-09-08 | Divyanshu (AI-assisted) | Requested clarification on the 3.6 modal change: a submitted row is for viewing only, never editing. Added a second, separate read-only "View Details" `Dialog` — opened by clicking a table row (delete button stops propagation so it still deletes directly) — showing Status/Start Date/End Date/Time/Pattern/Reason/Note with no inputs and no Save, just a `Close` button reusing the existing `common.close` key. The Add modal is unchanged and remains the only way to create an override. One new i18n leaf key, `viewTitle`, added to both locales; no backend, test, or wire-format changes |
| 3.6 | 2026-09-08 | Divyanshu (AI-assisted) | Two more requested UI refinements, frontend-only: (1) table times now render 12-hour with AM/PM via `formatTime12h` (storage/wire format and the form's own `<input type="time">` unaffected); (2) the "add" form moved from an inline expanding block into a modal `Dialog`, opened by the always-visible "+ Add" button — matches this page's existing `ChangePasswordDialog` pattern exactly rather than introducing a new one |
| 3.5 | 2026-09-08 | Divyanshu (AI-assisted) | Three requested UI refinements, frontend-only: (1) all displayed dates now render dd/mm/yyyy via `formatDMY` (storage/wire format unchanged); (2) Start Date and End Date split back into two separate table columns, so Pattern no longer needs to carry date text — reverted to repeat-type-only, "Never" reading as "One day"; (3) every backend-required field in the Add form (start/end date, start/end time, weekdays-when-Weekly) now carries a red-asterisk `RequiredMark`, matching actual requiredness rather than decoration |
| 3.4 | 2026-09-08 | Divyanshu (AI-assisted) | Pattern column revised, on request: shows the raw `repeat` field value (not the invented "One day"/"Continuous" substitutions from 3.3) plus the date range, self-contained in one cell — e.g. `"Weekly (Mon, Wed) · 2026-09-15 – 2026-09-29"` — alongside the still-separate Dates column. `oneDay`/`continuous` i18n keys removed as dead code once superseded (48 keys, was 50) |
| 3.3 | 2026-09-08 | Divyanshu (AI-assisted) | Split the table's combined "Details" column into a dedicated **Pattern** column (how the override applies within its range — "One day" / "Continuous" / "Daily" / "Monthly" / "Weekly (Mon, Wed)") and a narrower Details column (Reason + Note only). Frontend-only — no backend or test changes needed, since `start_date`/`end_date`/`repeat`/`weekdays` were already returned. i18n grew from 47 to 50 keys (`pattern`, `oneDay`, `continuous`) |
| 3.2 | 2026-09-08 | Divyanshu (AI-assisted) | Removed the "viewing date" filter entirely and widened `list_availability_overrides`/`list_my_availability_overrides` to drop their `date` parameter — the list now shows every declared override (past, current, future), not one date's worth. Explicitly unrelated to the weekday-repeat correctness fix (§4), which is untouched and still governs actual booking enforcement. List display switched from stacked cards to a real `<table>` (Status · Dates · Time · Details · Remove), with Repeat/Reason/Note collapsed into one Details column. Two tests removed (their premise — per-date list probing — no longer applies) and replaced with a lighter persistence check; 18 → 17 tests in file #6. i18n: `viewingDate` removed, `dateRange`/`time`/`details` added (45 → 47 keys) |
| 3.1 | 2026-09-08 | Divyanshu (AI-assisted) | Small follow-up: added core's own `note` field (free text, both types — unlike `reason`, which the doctype restricts to Unavailable). New `note` param on `set_availability_override`/`set_my_availability_override`, returned by `list_availability_overrides`; frontend gained a note textarea and list display; one new backend test (18 total, was 17); i18n namespace grew from 43 to 45 leaf keys per locale |
| 3.0 | 2026-09-08 | Divyanshu (AI-assisted) | Follow-up round, requested after the shipped screen was demoed: widened to a start/end date range plus core's own Repeat (Never/Daily/Weekly/Monthly) and weekday fields, matching a real screenshot of the built card. Surfaced and fixed a second, unplanned correctness gap in the process — core's `get_practitioner_unavailability()` never enforced its own Repeat/weekday fields, so "Weekly, Monday only" was silently treated as "every day in range" everywhere this app called it. Fix: new `applies_on_weekday`/`get_unavailability_for_date` in `services/availability.py`, swapped into all three read call sites plus the `Available`-direction read and the list view. Every backend function's signature changed (`date` → `start_date`/`end_date`, plus `repeat`/`weekdays`); both test files updated to the new signature and gained explicit weekday-repeat regression tests; frontend form gained start/end date, a Repeat selector and weekday toggle buttons; i18n namespace grew from 21 to 43 keys per locale. §1, §2, §3, §4 rewritten to describe the corrected mechanism; §5 checklist updated file by file; build status changed from "Proposed" to "Done" |
| 2.7 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #8-13 marked Done — full frontend built in `EB_Healthcare_Frontend`. One evidence-based plan deviation on #9: dropped the planned react-query hook file in favor of matching this specific page's own established plain-fetch convention (its other self-service cards all work this way; react-query is this codebase's convention for *admin* resources instead) — logic folded into #11. All 13 checklist items now Done; feature is fully built end to end, backend and frontend |
| 2.6 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #6 and #7 marked Done — 27 tests total across `services/providers.py`'s override CRUD, `services/availability.py`'s two functions, and both booking surfaces end to end. Two test-writing gotchas found and fixed before landing, both specific to this codebase's `handle_api_errors` convention: (1) a test driving a whitelisted wrapper down its error branch triggers `frappe.db.rollback()`, which can wipe uncommitted fixtures created earlier in the *same* test method — fixed by committing fixtures first, matching `test_reschedule_payment.py`'s and `test_portal_booking_e2e.py`'s existing precedent; (2) `reschedule_my_appointment` saves without `ignore_permissions=True`, so its test needed a real `EB_Patient`-permissioned Website User (second save for roles — Frappe strips roles assigned during a Website User's own insert), not the simpler System User fixture the other portal tests could use |
| 2.5 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #5 marked Done — found `book_my_appointment` already calls the shared `_create_impl` from #4, so it already had the guard; added `assert_bookable` to the separate `reschedule_my_appointment` save path and `generate_override_slots` to `get_my_available_slots`, with the same empty-schedule early-return bug fixed as in #4. Considered and declined a feature-flag gate on this work (discussed with the requester; kept unconditional, matching #4) |
| 2.4 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #3 and #4 marked Done — `services/availability.py` built; `assert_bookable` wired into booking creation and reschedule; `generate_override_slots` wired into `get_available_slots`. Records a bug caught during #4: the empty-schedule early-return would have hidden Available overrides on a day with no normal schedule at all — fixed before landing, not after |
| 2.3 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #2 marked Done — whitelisted `list_my_availability_overrides`/`set_my_availability_override`/`cancel_my_availability_override` built in `api/v1/providers/api.py`; #1 gained `list_availability_overrides`, the read function backing the first of these |
| 2.2 | 2026-09-08 | Divyanshu (AI-assisted) | Checklist #1 marked Done — `set_availability_override`/`cancel_availability_override` built in `services/providers.py`; parameter renamed `type` → `availability_type` (avoids shadowing the Python builtin) |
| 2.1 | 2026-09-08 | Divyanshu (AI-assisted) | Both open items resolved into the design: §3 gains the multi-window list UI note, §4 gains the subtraction-against-normal-schedule algorithm and the default-duration source; §5's #3/#7/#11 updated to match; Open items section removed (nothing outstanding) |
| 2.0 | 2026-09-08 | Divyanshu (AI-assisted) | Redesigned around ADR-062 v1.2: dropped named-schedule toggles for core's own type/time-range fields; widened to build both Available and Unavailable fully, including new slot-generation logic for Available; folded holiday/leave write-time enforcement into the same guard. §5 checklist rewritten accordingly |
| 1.2 | 2026-09-08 | Divyanshu (AI-assisted) | §5 replaced with the full 13-item file-by-file build checklist |
| 1.1 | 2026-09-08 | Divyanshu (AI-assisted) | Terminology fix: "shift" was never a system concept — replaced with `Practitioner Schedule` / "schedule" throughout |
| 1.0 | 2026-09-08 | Divyanshu (AI-assisted) | Initial version |
