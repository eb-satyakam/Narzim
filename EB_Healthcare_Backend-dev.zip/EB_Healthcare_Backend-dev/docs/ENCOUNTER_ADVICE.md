# Encounter Advice — How It Works

**Doc status:** living · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-28 by Divyanshu (AI-assisted) · **Version:** 1.0

**Status of the build: In progress.** See [§5](#5-build-order) for the per-file record.

**This document owns the mechanism.** The doctype-vs-field decision (why a new doctype, not
`Patient Encounter.education` or `Patient Education Resource`) and the "same PMR entry, not
separate rows" surfacing decision are owned by
[`adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md`](adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md);
this document does not restate them.

## 1. Scope

| In scope | Out of scope |
|---|---|
| A practitioner giving patient advice during a Guided Encounter — a checklist of suggested lines (AI-suggested or picked from common items) plus free-typed lines | Actually generating AI suggestions — this doctype stores whatever lines the frontend hands it, tagged with their `source`; producing the suggestions themselves is a separate, not-yet-scoped task |
| Multiple lines per one `Encounter Advice` record, each independently marked `AI` or `Manual`, and independently accepted/rejected | Real-time translation of stored advice into another language — this app has no store-once-render-in-any-language precedent (ADR-096's research); the practitioner is assumed to write in whatever language they're preparing this Rx in |
| Surfacing in the encounter's existing Patient Medical Record entry (ADR-096) | Printing on an actual Rx — no Rx/prescription print pipeline exists in this app yet; storing `source`/`accepted` per line is what a future print flow would read, not something this doctype produces itself |

## 2. Doctype: `Encounter Advice`

| Field | Type | Notes |
|---|---|---|
| `encounter` | Link → Patient Encounter | Required, **not** unique — mirrors `Encounter Canvas`; an encounter can have more than one advice record if ever needed |
| `patient` | Link → Patient | Read-only, denormalized from `encounter.patient` at creation |
| `practitioner` | Link → Healthcare Practitioner | Read-only, denormalized from `encounter.practitioner` at creation |
| `appointment` | Link → Patient Appointment | Read-only, denormalized from `encounter.appointment` at creation; blank when the source encounter has none |
| `lines` | Table → `Encounter Advice Item` | The actual advice — see below |

`Encounter Advice Item` (child table): `advice_text` (Small Text), `source` (Select: `AI` /
`Manual`), `accepted` (Check, default 1).

**Why a real child table, not a JSON blob like `Encounter Canvas.canvas_data`.** Canvas's payload is
opaque drawing data nothing on the backend ever needs to query into. Advice lines are the opposite:
the whole reason this doctype exists (ADR-096's rejected Option C, in the design conversation that
preceded this doc) is to make "was this line AI-suggested, and was it accepted?" answerable per
line, not buried in a merged string. A child table makes that a real, queryable column, not
something that would need parsing back out of JSON.

Same permission shape as `Encounter Canvas`: `EB_Practitioner` create/read/write, no delete;
`EB_Healthcare Admin` full CRUD. `track_changes: 1`.

## 3. API — `api/v1/encounter_advice/api.py`

Same authorization convention as `Encounter Canvas` throughout —
`require_permission("Patient Encounter", <perm>, doc=encounter)`, never a bare doctype-level check.

| Method | Purpose |
|---|---|
| `list_advice(encounter)` | Every advice record for one encounter |
| `get_advice(name)` | One record in full, including `lines`, for re-opening/editing |
| `save_advice(encounter, name=None, lines=[...])` | Create when `name` is omitted, else replace `lines` wholesale (matches `patients.api._update_patient_impl`'s guardians/relations convention — an array of plain row dicts replaces the full child table on every save) |
| `delete_advice(name)` | Admin-only — `EB_Practitioner` has no delete grant |

## 4. Surfacing — Patient Medical Record

Every `save_advice`/`delete_advice` call ends by calling
`services/encounter_summary_sync.py::sync_encounter_summary(encounter)` — the same shared helper
`Encounter Canvas` calls. See ADR-096 for the full mechanism (custom fields on `Patient Encounter`,
the `Patient History Settings` registration, and why a submitted encounter needs an explicit
`update_medical_record()` call rather than relying on a hook that never fires).

## 5. Build order

| # | Piece | Status |
|---|---|---|
| 1 | ADR-096 (surfacing decision) | ✅ Done |
| 2 | This doc | ✅ Done |
| 3 | `Encounter Advice` + `Encounter Advice Item` doctypes | ⏳ In progress |
| 4 | `api/v1/encounter_advice/api.py` | ⏳ In progress |
| 5 | Custom fields on `Patient Encounter` + Patient History Settings patch | ⏳ In progress |
| 6 | `services/encounter_summary_sync.py`, wired into Canvas and Advice | ⏳ In progress |
| 7 | Dashboard connections (`Patient`, `Patient Encounter`) for both doctypes | 🔲 Not started |
| 8 | Frontend | 🔲 Not started (separate task, per the Canvas precedent) |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
