# Remedisys — Current State

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.5
> ## This is the only document that states project status.
> Per `CLAUDE.md` §9 (one fact, one owner). Before this file existed, **eight documents totalling
> 5,663 lines** each asserted the phase status, last updated across **six different dates** — the
> oldest (`docs/planning/PHASES.md`) two months stale. A reader had no way to know which to believe,
> so whichever they opened first became "the current state".
>
> If you are about to write "Phase N is complete" in another document: **link here instead.**
> If this file is wrong, that is a bug — fix it here.

**Deployment:** Frappe Cloud (backend) · Vercel (frontend) · local dev `marley.local:8003`
— a migration of the backend to **AWS** (with Bedrock for AI) is decided but **deferred to a
later phase**; it needs an ADR superseding ADR-005. Analysis:
[`security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md` §14](security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md#14-migrating-from-frappe-cloud-to-aws--what-it-changes)
**Branches:** `dev` → `pre` → `main`. Never commit direct to `pre` or `main`.

---

## Phase status

| Phase | Scope | State |
|---|---|---|
| **0 — Auth foundation** | eb_frappe_jwt Bearer JWT (ADR-011), CI install/uninstall gate | ✅ **Complete** |
| **1 — Core clinical APIs** | patients · appointments · encounters · dashboard · providers | ✅ **Complete** |
| **2 — Clinical details** | vital signs · labs · immunizations (Mexico EPI) · clinical | ✅ **Complete** |
| **3 — Billing + insurance** | billing complete; **insurance partial** (4 methods) | 🟡 **Partial** |
| **4 — Operations + reporting** | notifications, tasks and inbox built — **and notification *delivery* rebuilt 2026-08-25: live over SSE, out-of-app push via FCM for patients, all 13 polling intervals removed** (see [`PUSH_NOTIFICATIONS.md`](PUSH_NOTIFICATIONS.md)); **reports not started** | 🟡 **Partial** |
| **5 — AI** | ambient capture, Encounter Copilot, lab extraction | ✅ **In production**, ahead of Phase 4 |

**The build order in the original plan was not followed.** AI shipped alongside Phases 1–3 rather
than after Phase 4. This is a fact about the project, not a proposal — see
[`docs/ai/DECISION_LOG.md`](ai/DECISION_LOG.md) for how it happened.

## What is live in production

| Component | Value |
|---|---|
| LLM | OpenAI `gpt-5-mini`, `reasoning_effort=low`, via the ADR-026 approved allowlist |
| ASR | Deepgram `nova-3`, `language=multi`, `diarize=true`; audio never reaches Frappe (ADR-009) |
| Audio retention | Off. `retain_audio = 0`, verified on every session on record |
| AI tool registry | 36 tools — 13 read, 23 write ([`services/ai_tools.py`](../remedisys_healthcare_ai/services/ai_tools.py)) |
| AI doctypes | 18 installed; 5 have zero rows (dead scaffolding) |
| Vector DB / RAG | **None**, deliberately. Retrieval is structured + keyword only |
| Jurisdiction | India + Mexico, pluggable via `ComplianceProfile` (ADR-018 multi-jurisdiction); default `mx` |

## Measured on `marley.local`, 2026-08-20

The last time anyone counted. Re-measure rather than trusting these if the date matters.

| Metric | Count |
|---|---|
| Patient Encounters | 144 (131 with SOAP content) |
| AI Encounter Sessions | 137 — **all in `Recording`; none has ever reached `Stopped`** |
| AI Transcript Segments | 13,631 |
| AI Prompt Log rows | 1,897 — 64 % of them the patient clinical summary |
| Immunizations / Patient Vaccines | **0 / 0** — the vaccine pipeline has never produced a record |
| AI SOAP Drafts | **0** — the subsystem is dead |

## Active work

**The encounter P0 queue** — see
[`docs/audit/practitioner/screens/03-encounter-deep-audit.md`](_archive/audit-screens/practitioner/03-encounter-deep-audit.md) §15
for the full plan and evidence.

| # | Item | State |
|---|---|---|
| P0-1 | Synthetic clinical-data layer in the patient chart | ✅ **Removed** 2026-08-20, verified in-browser |
| P0-2 | Consent bypass — recording auto-starts; `consent_obtained: true` hardcoded | ✅ **Fixed** 2026-08-26 on the V1 code path (`CopilotHost`'s mount-effect auto-start removed); verified by an exhaustive search finding exactly one remaining `copilot.start()` call site, reachable only from a consent click. The 144 existing rows carrying `consent_obtained=1` with no real consent are a separate, still-open question — see [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md) §5 |
| P0-3 | LLM authors drug strength into the permanent formulary | ⛔ Open |
| P0-4 | `_serialize_drug_rx` omits the dosing interval → silent erase on reopen | ⛔ Open (smallest fix on the list) |
| P0-5 | Adult vital thresholds applied to children; no respiratory-rate rule | ⛔ Open — **needs a clinician** to choose the reference source |
| P0-6 | Vitals NOTES field discards what is typed into it | ⛔ Open |
| P0-7 | Prescription rows silently dropped from every save | ⛔ Open |

**Target design** for the encounter: the 3-step flow behind
`NEXT_PUBLIC_FEATURE_ENCOUNTER_V2`, decided in
[ADR-054](adr/adr-054-three-step-encounter-flow-reusing-v1-components.md) and
documented in
[`docs/architecture/ENCOUNTER_V3.md`](architecture/ENCOUNTER_V3.md) (steps 2–3)
and
[`docs/architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md)
(step 1). This **supersedes** the single-screen, rebuild-the-fields
architecture proposed in
[`docs/architecture/ENCOUNTER_FROM_SCRATCH.md`](architecture/ENCOUNTER_FROM_SCRATCH.md)
(`draft`, 2026-08-20) — see that document's own header note.

## Decisions waiting on a person

Neither can be resolved from the code.

1. **Is the OpenAI data-processing agreement in place?**
   [`integrations/openai.py`](../remedisys_healthcare_ai/integrations/openai.py) lines 12–15 state the
   provider must stay off until it exists; `AI Settings.llm_provider` is `OpenAI`.
2. **What do the 137 `consent_obtained = 1` sessions represent** — dev/test traffic, or real
   consultations recorded without asking? Determines whether P0-2 is a hotfix or a disclosure.

Nine further open decisions (D1–D9) are listed in the encounter design document.

## Known unfinished, recorded so it is not mistaken for done

- Dashboard (`mission-control-client.tsx`) still synthesises content from `patHash`.
- Retention: **no purge job exists** — `scheduler_events` is commented out in `hooks.py`, and
  `AI Settings.transcript_retention_days` (2555) contradicts `ComplianceProfile` (90 mx / 30 in).
- Seven ADR numbers are permanently ambiguous by decision
  ([ADR-042](adr/adr-043-adr-identity-is-the-filename.md)); cite filenames, not numbers.
- Reports (Phase 4) not started; insurance (Phase 3) partial.

## Documents that used to assert status

These are now subordinate to this file. Where they still contain phase claims, this file wins.

`CLAUDE.md` §12 · `ROADMAP.md` · `README.md` · `docs/README.md` ·
`docs/planning/PLANNING.md` · `docs/planning/PHASES.md` ·
`docs/ai/CURRENT_SYSTEM_AUDIT.md` (`record` — a dated snapshot, correctly frozen) ·
`docs/ai/REMEDISYS_AI_MASTER_PLAN.md`

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.5 | 2026-09-25 | Satyakam (AI-assisted) | Links repointed: session transcripts and screen audits moved to `docs/_archive/` |
| 1.4 | 2026-09-03 | Ashutosh (AI-assisted) | Deployment line records that the backend move to **AWS (with Bedrock for AI) is decided but deferred to a later phase**, and needs an ADR superseding ADR-005. Pointer only — the analysis is owned by `security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md` §14, per one-fact-one-owner. Added because 36 living docs assert Frappe Cloud and a reader of the status file would otherwise not know a migration is coming |
| 1.3 | 2026-08-29 | Sarvesh-SocialAngel (AI-assisted) | Merged two same-version 1.2 edits made in parallel: Ashutosh's notification/push status update and the P0-2 consent correction |
| 1.2 | 2026-08-26 | Sarvesh-SocialAngel (AI-assisted) | P0-2 (consent bypass) marked fixed on the V1 path, with what remains open; target-design pointer corrected from a draft (`ENCOUNTER_FROM_SCRATCH.md`) to what was actually decided (ADR-054) and shipped |
| 1.1 | 2026-08-20 | Sarvesh-SocialAngel (AI-assisted) | ADR-042 renumbered to 043 after an upstream collision |
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Created as the single status source, replacing eight competing assertions |
