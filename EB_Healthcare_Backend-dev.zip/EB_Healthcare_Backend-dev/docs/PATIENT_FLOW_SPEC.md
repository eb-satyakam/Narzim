# Patient Flow Report — What We Are Building

**Doc status:** draft · **Created:** 2026-08-29 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-03 by Anant Sharma (AI-assisted) · **Version:** 5.1

> **Built 2026-08-29 — backend and frontend.** Backend verified against `remedisys.localhost`;
> frontend builds, lints and typechecks clean with both message catalogs in parity.
> §15 records what the data forced us to change, §16 what shipped.

> **Who this is for.** The backend and frontend developers building the report, and the
> clinic admin who will use it.
>
> **What it is.** A plan, written in plain words. It says what the page must show, what the
> data can and cannot answer, and what has to change in both repos.
>
> **What it is not.** Not the endpoint contract ([`API.md`](reports/API.md)) and not
> the user guide ([`REPORTS_GUIDE.md` (archived)](reports/archive/REPORTS_GUIDE.md)). Those get updated when this is built.

---

## 1. The short version

We are rebuilding the report now called **Daily Patient Flow**.

| | |
|---|---|
| **New name** | **Patient Flow** (everywhere — title, menu, breadcrumb, URL) |
| **New URL** | `/reports/patient-flow` |
| **Default filter** | **This Month** |
| **Who can open it** | Admin, Practitioner, Front Desk, Nurse |
| **Subtitle** | Real-time view of patient journeys, appointment performance, and clinic throughput |

The goal: a clinic admin opens the page and understands the clinic in **10 seconds**.

---

## 2. The one big change

Today the page mixes two different questions and gets both wrong.

- **"How many patients are waiting?"** — this is about **right now**.
- **"How many appointments did we complete?"** — this is about a **date range**.

You cannot answer "who is waiting right now" for a whole month. It means nothing.

Because the page opens on **This Month**, this matters even more: the very first thing the admin
sees is a month of history. Without a separate live strip there would be nowhere on the page that
answers "what is happening in the clinic at this moment".

**So we split the page into two parts:**

| Part | Follows the date filter? | What it answers |
|---|---|---|
| **Right Now** strip (top, pinned) | **No** — always live, stamped "as of 14:32" | Who is waiting, who is with a doctor |
| **Period** section (everything below) | **Yes** | What happened over the chosen days |

This is the most important rule in this document. Keep the two parts visually separate so nobody
reads a live number as a period number.

---

## 3. Page layout

```
Patient Flow                   [This Month ▾] [Clinic ▾] [↻]     as of 14:32
Real-time view of patient journeys, appointment performance, and clinic throughput

┌─ RIGHT NOW ────────────────────── ignores the date filter ─────────────┐
│  Waiting 6     In Consultation 4     Longest wait 41m     Rooms 4/5    │
└────────────────────────────────────────────────────────────────────────┘

┌─ NEEDS ATTENTION ──────────────────────────────────────────────────────┐
│  2 patients waiting over 30 min                                        │
│  5 appointments are past their time and still not marked               │
│  3 encounters not signed                                               │
│  1 patient checked out with an unpaid invoice                          │
└────────────────────────────────────────────────────────────────────────┘

── PERIOD: 1–29 Aug 2026 ────────────────────────────────────────────────
Appointments 82 · Patients 61 · New 14 · Returning 47 · Capacity 82/110
Completed 39 · Checked out 31 · Rescheduled 5 · Cancelled 4 · No-show 3 · Stale 5

[ Patient Flow Funnel ]          [ Appointment Outcomes ]
[ Hourly Patient Flow ]          [ New vs Returning ]
[ Waiting Time ]                 [ Appointment Types ]
[ Reschedule Analysis ]          [ No-Show Analysis ]
─────────────────────────────────────────────────────────────────────────
[ Billing — kept separate from the clinical numbers ]
```

Cards and charts only — no tables. Every card opens its own list, so the page needs no table of
its own (§14a).

---

## 4. Needs Attention

This is the only part of the page that tells the admin to **do something**. Everything else
just informs.

| Item | Meaning |
|---|---|
| Waiting too long | Checked in over 30 min ago, still no doctor |
| Past their time, unmarked | The slot has passed but nobody marked it done, cancelled, or no-show |
| Unsigned encounters | The doctor saw the patient but never signed the note |
| Checked out unpaid | The visit ended with money still owed |

Each line opens the list behind it.

**Where they come from.** "Waiting too long" is live, so it arrives on the Right Now endpoint.
The other three are about the chosen period, so they arrive on the period endpoint under
`attention`. The frontend shows them in one panel.

---

## 5. The cards

Every card is clickable and opens the matching list.

### Right Now (live)

| Card | Meaning |
|---|---|
| Waiting | Arrived, no doctor yet |
| In Consultation | With a doctor now |
| Longest wait | The person waiting the longest |
| Practitioners busy | Doctors currently with a patient, out of those working today. **Replaces "rooms occupied"** — see §15 |

### Period — volume

| Card | Meaning |
|---|---|
| Appointments | Every appointment in the range, any status |
| Patients | **Unique people**, not appointment rows |
| New patients | This was their **first ever** appointment |
| Returning patients | They had been before |
| Capacity used | Appointments booked vs slots available |

**New + Returning must equal Patients.** If they do not, the maths is wrong.

### Period — outcomes

| Card | Meaning |
|---|---|
| Completed | The consultation actually finished |
| Checked out | The visit was formally closed |
| Rescheduled | Moved to another date or time |
| Cancelled | Cancelled |
| No-show | The patient never came |
| Stale | Time has passed, still not marked — a data-quality warning |

Show a comparison with the previous same-length period **only when there is enough history**.
Never invent a percentage.

---

## 6. The charts

| Chart | What it shows | Rule to follow |
|---|---|---|
| **Patient Flow Funnel** | Appointments → Checked in → In consultation → Completed | **Cumulative.** "Checked in" means reached check-in *or went further*. Say this on the chart |
| **Appointment Outcomes** | Completed / No-show / Cancelled / Still scheduled | **Exclusive.** Every appointment counted once. Must add to 100% |
| **Hourly Patient Flow** | Volume by hour, toggle: Appointments / Arrived / Completed | Shows peak hours only if the data supports it |
| **New vs Returning** | Split of unique patients | Uses the corrected definition above |
| **Waiting Time** | Average, median, longest, over 15/30/60 min, by hour | **Must show coverage** (see §8) |
| **Appointment Types** | Types read from the database, top 8 + "view all" | Never hardcode the list |
| **Reschedule Analysis** | Total, rate, same-day vs future, old → new, what happened after, money impact | See §7 |
| **No-Show Analysis** | Total, rate, new vs returning patients, by day of week | — |
| **Billing** | Billed, collected, pending, paid vs unpaid visits | Kept in its own section. Never changes a patient count. Refunds sit with reschedules — see §15 |

---

## 7. Reschedules — use the data we already have

We store a full record of every reschedule: old and new date, time, doctor, department, type, fee,
invoice, and whether money was refunded or charged extra.

So the report can show:

- how many were moved, and how often
- moved to the same day vs a future date
- what happened afterwards — completed, cancelled, or still pending
- **the money impact** — refunds and extra charges

One appointment can be moved more than once. Count the **appointment** once, unless the chart is
explicitly about reschedule *events*.

---

## 8. Being honest about the numbers

Three rules. They matter more than any chart.

**1 · A dash means "not measured", never zero.**
If we cannot calculate something, show `—` and say why. A `0%` bar that really means "no data"
is a lie.

**2 · Always show the denominator.**
Not "average wait 18 minutes" but "average wait 18 minutes · measured on 20 of 112 visits".

**3 · Some numbers only exist going forward.**
Arrival time and consultation end time were added to the system partway through the project.
There is **no backfill**. Any date range before those fields existed will correctly show `—`.
Right now only about 1 in 5 visits has an arrival time recorded.

---

## 9. How we decide each status

This is the mapping the backend must use. It is not guesswork — each one comes from a real record.

```
Scheduled        appointment exists, nobody has arrived
Checked in       arrival time recorded, or status is "Checked In"
Waiting          arrived  AND  no encounter created yet
In consultation  encounter exists, still open, no end time
Completed        encounter marked Completed, or an end time is recorded
Checked out      appointment status is Checked Out or Closed
```

Separate from the flow — these are **outcomes**, not stages:

```
Cancelled     Rescheduled     No-show
```

Important: the system has **no "In Consultation" status**. We know a patient is with a doctor
because an encounter record exists. Do not look for a status that is not there.

---

## 10. Four things that are wrong today and must be fixed

| # | Problem | Why it matters |
|---|---|---|
| 1 | **New patients** counts people *registered* in the range, but **Patients** counts people who *had an appointment*. They are different groups | New + Returning does not add up to Patients. The patient-growth number the owner sees is wrong |
| 2 | The **In Consultation** card shows everyone who *ever* saw a doctor in the whole range, sitting next to **Checked In**, which shows *right now* | The cards read "2 waiting, 39 with a doctor" in a clinic with 4 rooms |
| 3 | **Waiting Now** does not exist at all. The Checked In card includes people already with a doctor | The waiting room always looks fuller than it is |
| 4 | **Still Scheduled** is a leftover subtraction, so forgotten old appointments hide inside it | Appointments dated 2099 have already been found this way |

---

## 11. What we are NOT building

Decided, so nobody re-opens it later.

| Not building | Reason |
|---|---|
| **Cancellation reasons** breakdown | **Dropped by decision (2026-08-29).** The reason is saved as free text inside appointment notes, with no fixed categories. Cancellations are still shown by day, doctor and department |
| A separate **Appointment Type** and **Visit Type** chart | They are the same field in the system. One chart only |
| **Patient satisfaction** | We collect no satisfaction data |
| Reminder **delivered / read** counts | Might be possible, unconfirmed. Check the live data before promising it |

---

## 12. What has to change

### Backend (this repo)

- Rewrite the report builder in [`appointments/report.py`](../remedisys_healthcare_ai/api/v1/appointments/report.py) — correct status mapping, correct new/returning, stale count, doctor and department blocks, reschedule analysis, capacity.
- Add a **live** endpoint for the Right Now strip. No date filter. Cheap and cached for ~30 seconds.
- Add a **paged detail** endpoint so every card can open its list. Reuse the existing pattern in [`dashboard/report.py`](../remedisys_healthcare_ai/api/v1/dashboard/report.py) instead of writing a new one.
- Reuse the existing invoice-to-doctor logic in [`billing/report.py`](../remedisys_healthcare_ai/api/v1/billing/report.py) for the billing block. Do not write a second version.
- Add tests for the status mapping and the new/returning maths.
- Keep the old endpoint name working for one release, so the two repos can be deployed separately.

### Frontend (`remedisys-ai-ehr`) — done

- ✅ Route renamed `/reports/daily-patient-flow` → `/reports/patient-flow`; landing-page link updated.
- ✅ Text keys renamed `dailyPatientFlow.*` → `patientFlow.*` in **both** catalogs — 170 keys each,
  parity checked. No hardcoded user-visible text.
- ✅ Right Now strip and Needs Attention panel, as separate components.
- ✅ **Every** card now opens its records. Was 5 of 12.
- ✅ Loading, empty, error and partial states, including a live strip that fails on its own without
  taking the page with it.
- ✅ Existing design system kept — same shell, cards, chart components, colour tokens.
- ✅ Default period stays **This Month**, inherited from the shell. No per-page override, and the
  other 14 reports are untouched.

### Speed

- One database read of appointments feeds every block on the page.
- Count with SQL grouping, not by looping in Python.
- The detail table is paged **on the server**. Never load everything into the browser.
- Add indexes for department and for the reschedule table.
- No repeated query per card.

---

## 13. Done means

- [ ] The report is called **Patient Flow** everywhere, in both languages
- [ ] This Month is the default; all date filters work
- [ ] Right Now is live and clearly separate from the period section
- [ ] Needs Attention shows real items and each one opens a list
- [ ] New + Returning equals Patients
- [ ] Waiting, In Consultation and Completed use the §9 mapping
- [ ] The funnel is cumulative and says so; outcomes add to 100%
- [ ] A reschedule counts one appointment once
- [ ] Waiting-time figures show their coverage
- [ ] Unmeasurable values show `—`, never `0`
- [ ] All cards clickable
- [ ] The detail table is paged from the server
- [ ] Billing is separate and does not change any patient count
- [ ] Loading, empty, error and partial states work
- [ ] No unlimited fetching, no repeated queries
- [ ] No Frappe or Marley core file changed
- [ ] Works on desktop and mobile

---

## 14. Decisions taken

| Question | Decision | Why |
|---|---|---|
| Endpoint rename | `get_patient_flow` is the new name. `get_daily_patient_flow` stays for **one release** as a thin projection of the same payload | Lets the two repos deploy on different days without the page breaking. It is a filter, not a second implementation, so the two cannot drift |
| Order of work | **Backend first**, frontend after | The frontend cannot be built against a contract that is still wrong |

---

## 14e. Second trim, and the last mismatch closed — 2026-08-31

### The page now

Three rows of exactly **four** cards, then the bar chart, then one chart pair, then types.

| Row | Cards |
|---|---|
| Patients and appointments | Appointments · New patients · Returning patients · Capacity used |
| *(unlabelled)* | Completed · Rescheduled · Cancelled · No show |
| *(unlabelled)* | Peak hour · Avg throughput · Average wait · Registered |

Removed: the **Patients** and **Longest wait** cards; the **New vs Returning**, **Waiting time**,
**Reschedule analysis** and **No-show by patient type** charts; the *Appointment outcomes* and
*Throughput and waiting* headings. The bar chart moved **above** the funnel/outcomes pair — it is the
only view of the day's shape, and the pair reads as detail on top of it.

Each row holding exactly four means every row fills the four-wide track and no card stretches to
cover a gap.

### Completed now opens the Encounters list — and finally agrees

This was the one card whose list never matched, flagged since §14c: 17 against 42.

The cause was the destination, not the number. `/appointments?status=Completed` means ERP status
`Closed`, which this clinic sets the moment an encounter is created — so it answered a different
question. The card counts consultations whose **note was submitted**, and that figure lives in the
Encounters list. Pointed there, with the Encounters screen gaining URL seeding (`status`, `preset`
or `from_date`/`to_date`, `practitioner`) the way Appointments and Patients already had.

**Verified: card 18, list 18.** Every card on the page now opens exactly the set it counted.

### Rescheduled is a real filter on the Appointments screen

It was a hidden query param that vanished as soon as the user touched anything. Now it is a chip in
the status dropdown, where people look for it.

It needed care, because **"Rescheduled" is not a status** — no appointment row carries it; it is
derived from `Appointment Reschedule History`. So it is split back out of the filter set: pushed to
the server as `rescheduled=1`, and excluded from the client-side `row.status` match, which would
otherwise have filtered every row away. Being chip-driven rather than URL-driven is what makes it
survive changing the date or the practitioner after arriving.

---

## 14d. Practitioner filter, 2026-08-29

A practitioner selector sits beside the period controls. Every figure, chart and card link on the
page narrows to that practitioner. Measured: 135 appointments clinic-wide → 56 for one doctor.

**Opt-in per report, not global.** `ReportShell` takes a `practitionerFilter` prop and only Patient
Flow sets it. Patient Volume, Average Visit Time and Utilization exist to compare practitioners
*against each other* and would be gutted by narrowing to one; My Performance takes no practitioner
at all.

**Practitioners do not get the control.** `report_practitioner_scope()` already confines a plain
`EB_Practitioner` to their own data with no setting that widens it, so a selector would be either
inert or an apparent leak of other doctors' numbers. `useIsScopedPractitioner()` mirrors that rule.

**The links carry it too** — and this was the part that nearly shipped broken. With the filter set,
`patientsSeen()` was still opening the whole clinic: a card reading 36 against a list of 92.
`list_patients` gained `visited_practitioner`, and every card was re-verified in both states:

| | Patients | New | Returning | Appointments | Rescheduled |
|---|---|---|---|---|---|
| All clinic | 92 = 92 | 71 = 71 | 21 = 21 | 135 = 135 | 30 = 30 |
| One practitioner | 36 = 36 | 17 = 17 | 19 = 19 | 56 = 56 | 6 = 6 |

**The scope lives in the URL now.** Period, custom range and practitioner are seeded from the query
string on mount and written back on every change, so the browser Back button restores them: a card
navigates to `/appointments` or `/patients`, and coming back returns to the report with its filters
intact. Held only in component state they reset to the defaults on every return — which is what the
filter appeared to "lose".

`router.replace`, not `push`: a filter change corrects where you already are. Pushing would make Back
walk through every period button pressed before the page was left at all.

The round-trip is a pure module — `src/lib/narzim/report-scope-url.ts` in the frontend repo — with
17 tests — because a round-trip that does not round-trip is a silent bug, and the
Appointments screen had shipped exactly that (an effect rebuilding its URL from a subset of what it
read, erasing the rest on mount).

**What the filter does NOT narrow:** whether a patient counts as new or returning stays clinic-wide.
"Have been here before" is a fact about the clinic, not about which doctor they saw — a patient on
their third visit is returning even if it is their first with this practitioner. Hence 17 new + 19
returning for a doctor whose own list holds 36 people.

---

## 14c. Two more corrections, 2026-08-29

### "Returning patients" read 0 while one patient had ten visits

**Was:** returning = had an appointment *before the window started*. At a clinic whose records begin
inside the window that reports **every** patient as new — live, New 92 / Returning 0, while Teena
Dubey had ten appointments that month and twenty other patients had two or more. The card says
"have been here before". Ten visits is not a new patient.

**Now:** count each patient's appointments up to the **end** of the window. Exactly one ever → new.
Two or more → returning. Still mutually exclusive, still sums to the distinct-patient count.
Bounded at the window end so a booking made for next month cannot retroactively turn this month's
first-timer into a returning patient.

Live result: **71 new + 21 returning = 92**, and all three reconcile against their lists.

### "Checked out" could only ever read 0 — removed

`Checked Out` has **never been set on this deployment — zero rows, at any date.** ERPNext moves an
appointment to `Closed` when an encounter is created and nothing moves it again, so there is no
checkout event distinct from the consultation being finished, which `Completed` already reports.
Of the 42 `Closed` appointments in August, 17 had a submitted encounter and **25 were patients still
with a doctor**.

No source, so no number — the same call as cancellation reasons. The KPI is gone from the payload
and the funnel stage with it.

### Cards navigate now, and carry the report's time scope

Cards open `/appointments` or `/patients` instead of a drawer. The drill-down sheet is deleted; the
backend `get_patient_flow_detail` is kept.

**The time scope travels with the link.** When the report is on a preset the destination also has —
Today, This Week, This Month — the link sends `?preset=<name>` and the destination opens with that
button lit, not with an equivalent-looking custom range. The three windows are defined identically
on both sides (`list-date-scope.ts` mirrors `resolve_report_window`). This Quarter, This Year and a
custom range have no counterpart, so those send explicit dates — which is also what carries a custom
range across.

| Report period | Link carries |
|---|---|
| Today · This Week · This Month | `?preset=today` / `week` / `month` |
| This Quarter · This Year · custom range | `?date_from=…&date_to=…` |

Every card verified against its destination on live August 2026 data:

| Card | Opens | card = list |
|---|---|---|
| Appointments | `/appointments` | 134 = 134 |
| Cancelled | `+status=Cancelled` | 4 = 4 |
| No show | `+status=No Show` | 67 = 67 |
| Peak hour | `+hour=9` | 22 = 22 |
| Rescheduled | `+rescheduled=1` | 30 = 30 |
| Patients | `/patients?visited_from&visited_to` | 92 = 92 |
| New patients | `+visit_cohort=new` | 71 = 71 |
| Returning patients | `+visit_cohort=returning` | 21 = 21 |
| Registered | `/patients?created_from&created_to` | 646 = 646 |
| **Completed** | `+status=Completed` | **17 vs 42 — the one that still differs** |

`Completed` on the Appointments screen means appointment status `Closed`; the card means *the
consultation note was submitted*. Closing it needs a new encounter-state filter on that screen —
not built, and not silently papered over.

#### A visit filter on the Patient directory

`/patients` could only filter on registration date, so the Patients / New / Returning cards opened
the whole directory — 646 rows behind a card reading 92. `list_patients` gained `visited_from`,
`visited_to` and `visit_cohort`.

The new/returning rule is **not reimplemented there**. Both it and Patient Flow call
`utils.report_repeat_patients`, so the card and the list it opens cannot drift — which is the entire
reason the link exists. The window filter is `utils.report_patients_seen_between`, shared the same way.

On the screen the incoming filter is its own **clearable chip**, deliberately not folded into the
date control beside it: that one filters on registration date, and quietly reusing it would make
"This Month" mean two different things on one screen.

#### Two other things had to be built

**A `rescheduled` filter on `list_appointments`.** None existed, so the card could only open the
whole window. It narrows `Appointment Reschedule History` by the date filter already built rather
than pulling the table's whole history into an `in` clause, and uses a sentinel for the empty case —
`in []` matches everything in Frappe, so "show me the rescheduled ones" would otherwise have returned
the entire window.

**A bug in the Appointments screen that erased every link that opened it.** Its URL-sync effect
rebuilt the URL from `q` / `status` / `practitioner` only. It runs on mount, so `date_from`,
`date_to` and `hour` were stripped straight back out — which is why Peak Hour landed on the whole
window. Anything the page navigates in with now has to be written back out.

---

## 14b. The status bug — found on screen, 2026-08-29

**The report disagreed with the dashboard's Live Queue, and the Live Queue was right.**

Right Now showed **In consultation 0** while the Live Queue showed **two patients in the
Practitioner Room**. Three of its four cards were wrong.

**Cause.** ERPNext Healthcare sets `Patient Appointment.status` to **"Closed" when an encounter is
created**. "Closed" therefore means *an encounter exists*, not *the visit finished*. The state
machine checked appointment status **before** the encounter, so every patient currently with a
doctor was reported as already checked out.

Proved on live rows:

```
HLC-APP-2026-00245  Renata      appt.status=Closed   encounter docstatus=0 (draft)      -> with the doctor
HLC-APP-2026-00239  anant resh  appt.status=Closed   encounter docstatus=0 (draft)      -> with the doctor
HLC-APP-2026-00243  Valeria     appt.status=Closed   encounter docstatus=1 (submitted)  -> finished
```

**Three fixes.**

| Was | Now |
|---|---|
| Appointment status checked before the encounter | **The encounter outranks the status.** Draft = with the practitioner, submitted = finished — the same split the Live Queue uses between Practitioner Room and Checkout |
| "Finished" read from encounter `status` / `custom_encounter_end` | **`docstatus` first.** That end-date field is prospective, so a submitted encounter without one would have sat in "in consultation" for ever |
| "Waiting" excluded status `Confirmed` | **Included.** That is what this clinic's Live Queue calls the Waiting Room |

**Verified after the fix** — the two screens now agree by construction:

```
waiting (3)          == waiting_room (0) + nursing_room (3)   True
in_consultation (2)  == practitioner_room (2)                 True
```

**A name collision fell out of it.** The new constant was called `_ARRIVED_STATUSES` — a name
check-in-rates already owns further down the same file, with different membership. The later
assignment silently won at import. A test caught it; had the order been reversed it would have
changed *check-in-rates* instead, with nothing watching. Renamed `_PF_PRESENT_STATUSES`.

**And the fix exposed a second mistake.** With the states correct, `checked_out` reads **0 for the
whole month**, and the funnel drew `134 → 63 → 42 → 17 → 0`. The builder that existed before this
rewrite had already documented why Checked Out must not be a funnel stage — this clinic never sets
that status — and the rewrite put it back anyway. The stage is removed again.
**The `Checked out` KPI card has the same problem and is still on the page: it can only ever read 0.**
It should go, or be redefined.

---

## 14a. Removed after review (2026-08-29)

Three blocks were built, looked at on screen, and taken back out.

| Removed | Where that information still lives |
|---|---|
| **Appointment list** — the 50-row table at the bottom | The **Appointments** card opens the same records, paged from the server. Nothing was lost, and the page stopped offering two different ways into one list |
| **Practitioner performance** table | Not replaced |
| **Department performance** table | Not replaced |
| **Right now** strip *(removed later the same day)* | Backend `get_patient_flow_live` kept and still correct — see §14b. Re-adding the strip is a two-line change |
| **Needs attention** panel *(same)* | `attention` is still returned in the period payload |
| **Billing** card *(same)* | `billing` still returned. Reschedule Analysis keeps the refund figure — that belongs with reschedules, the only place the system records it |
| **Stale** and **Median wait** cards *(same)* | Both still returned by the API; the page's key lists are exhaustive, so they simply are not rendered |
| **Card drill-down drawer** *(same)* | `get_patient_flow_detail` kept and still reconciles. Cards navigate to `/appointments` and `/patients` instead — see §14c |

The page is now cards and charts only. It reads as a dashboard rather than a dashboard with three
spreadsheets stapled underneath, and it lost ~120 lines and a horizontal scroll on mobile.

**The backend still computes and returns `by_practitioner`, `by_department`, `table` and
`table_total`.** Left in on purpose: the drill-down needs the same appointment fetch anyway, the
grouping is a pass over rows already in memory, and keeping the keys means a future chart needs no
backend change. If they should come out of the payload too, say so — it is a small change.

---

## 15. What the data forced us to change

Three things in this plan could not be built exactly as written. Recorded here rather than
quietly dropped.

| Planned | Built | Why |
|---|---|---|
| **Rooms occupied** (§5) | **Practitioners busy** | Healthcare Service Unit is not maintained as a room roster on this deployment, so "of 5 rooms" had no source. Doctors busy out of doctors working today answers the same operational question from data that exists |
| **Refunded** as a billing figure (§6) | **Reschedule adjustment**, inside Reschedule Analysis | Refunds are only ever recorded against a reschedule (`Appointment Reschedule History.delta_amount`). A standalone "refunded" figure on the billing card would have had nowhere to read from |
| Capacity as its own calculation | Reuses the **Utilization Rate** projection | The first version deduplicated shared schedule templates and undercounted clinic capacity **58x** — 2,139 against the 89,094 Utilization Rate reports for the same month. Both now read 89,094 and 0.1%. A schedule shared by ten doctors gives each of them those slots |

**One thing to expect on the current data.** This site has no appointment before 2026-08-06, so
every patient's first-ever visit is in August and the report correctly reads **New 86 · Returning 0**.
That is the definition working, not a bug. The New vs Returning card now says so in words when
returning is zero, so a correct result cannot read as a broken query.

---

## 16. What shipped

### The page, top to bottom

| Block | Follows the date filter? | Notes |
|---|---|---|
| **Patients and appointments** | Yes | Appointments · Patients · New · Returning · Capacity used |
| **Appointment outcomes** | Yes | Completed · Checked out · Rescheduled · Cancelled · No-show · Stale |
| **Throughput and waiting** | Yes | Peak hour · Avg throughput · Avg / median / longest wait · Registered |
| Funnel + Outcomes | Yes | Side by side. Funnel states on the card that it is cumulative |
| Hourly flow | Yes | One chart, three series, toggled — Appointments / Arrived / Completed |
| New vs Returning · Waiting time | Yes | Waiting time carries its coverage |
| Reschedule · No-show analysis | Yes | Reschedule shows when, what happened next, and the money |
| Appointment types | Yes | Read from the database, top 8 + a named "other" bucket |
| Billing | Yes | Its own card, fenced off |

### Two decisions the frontend forced

**Cards open a sheet, not a link.** Every other report deep-links into `/appointments`. That does not
work here for two reasons: `/appointments` has no filter for a derived state (there is no stored
status for "arrived but not yet seen", "past its time and unmarked", "finished but unsigned"), and
where it *can* express one it disagrees — it honours a clinic setting that reports never do, so a
practitioner's card reading 10 opened a list of 26. The drill-down sheet reads the report's own
detail endpoint, which derives rows from the same appointment set and scope the number uses.
Peak Hour keeps its existing `/appointments` link, because that one works.

**The hourly series toggle, rather than three bars per hour.** Arrived and Completed are *subsets*
of Appointments, not additions — stacking them would be arithmetically wrong, and overlaying three
bars across 24 hours is unreadable.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 5.1 | 2026-09-03 | Anant Sharma (AI-assisted) | Links repointed and relabelled after the reporting-docs rename and archive split; no change to the spec itself |
| 5.0 | 2026-08-31 | Anant Sharma (AI-assisted) | §14e: second trim — 4 cards per row exactly, bar chart first, four charts and two headings removed. Completed now opens the Encounters list and matches (18 = 18); Rescheduled is a real Appointments filter |
| 4.5 | 2026-08-31 | Anant Sharma (AI-assisted) | §14d: report scope (period, range, practitioner) persisted in the URL so Back restores it |
| 4.4 | 2026-08-29 | Anant Sharma (AI-assisted) | §14d: practitioner filter on Patient Flow, carried into every card link |
| 4.3 | 2026-08-29 | Anant Sharma (AI-assisted) | §14c: visit-window + new/returning filter added to the Patient directory, so the three patient cards open exactly what they count |
| 4.2 | 2026-08-29 | Anant Sharma (AI-assisted) | §14c: Peak hour and Rescheduled links made exact (new `rescheduled` filter; URL-erasure bug on the Appointments screen fixed); links now carry the report period as a preset |
| 4.1 | 2026-08-29 | Anant Sharma (AI-assisted) | §14c: returning-patient definition corrected; Checked out, Stale, Median wait and Billing removed; cards navigate instead of opening a drawer |
| 4.0 | 2026-08-29 | Anant Sharma (AI-assisted) | §14b: the Closed-status bug — the encounter now outranks appointment status, matching the Live Queue. Right Now and Needs Attention removed from the page |
| 3.1 | 2026-08-29 | Anant Sharma (AI-assisted) | Appointment list, practitioner performance and department performance removed from the page (§14a) |
| 3.0 | 2026-08-29 | Anant Sharma (AI-assisted) | Frontend built. §12 marked done; §16 records what shipped and the two decisions the frontend forced |
| 2.0 | 2026-08-29 | Anant Sharma (AI-assisted) | Backend built and verified. §14 decisions taken; §15 records the three substitutions the data forced |
| 1.1 | 2026-08-29 | Anant Sharma (AI-assisted) | Default period changed from Today to This Month; document owner corrected |
| 1.0 | 2026-08-29 | Anant Sharma (AI-assisted) | First version. Cancellation-reason breakdown dropped by decision |
