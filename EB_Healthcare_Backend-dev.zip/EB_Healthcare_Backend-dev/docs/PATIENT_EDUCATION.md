# Patient Education

**Doc status:** living · **Created:** 2026-09-09 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-10 by Anant Sharma (AI-assisted) · **Version:** 1.0

Practitioners can create patient-facing education content — manually, or with a Narzim
AI-generated first draft — that reaches the patient (Patient Portal) only after an
explicit approve-then-publish workflow. AI never auto-publishes; that is structural, not a
runtime check (see [Workflow](#workflow) and [AI generation](#ai-generation) below).

Branch: `feat/patient-education`. Full build narrative: [`WORK_LOG.md`](../WORK_LOG.md)
entry `2026-09-09 — Patient Education module`. Plan with the four-plus-approaches schema/
workflow comparison this repo's constitution (`CLAUDE.md` §10) requires:
`/Users/yadav/.claude/plans/async-squishing-meadow.md`.

---

## Why a new doctype, not the existing `Patient Encounter.education` field

`Patient Encounter.education` already exists as an unrelated free-text SOAP field (Desk
label "Review Details" — what the clinician told the patient during a specific visit). The
new doctype is `Patient Education Resource`, deliberately not `Patient Education`, so the
two are never confused in code, UI copy, or search.

Diagnosis/Condition are not standalone linkable records in this schema — diagnosis lives
as free text inside the encounter's SOAP data (ADR-019) — so `related_diagnosis` /
`related_condition` are plain-text snapshots taken at creation time, not Links.
`related_medication` **is** a real Link (`Medication Request`), since that doctype
genuinely exists and is server-validated to belong to the same patient/encounter
(`services/patient_education_validation.py::validate_medication_relationship`).

---

## File map

```
remedisys_healthcare_ai/
├── remedisys_healthcare_ai/doctype/patient_education_resource/
│   ├── patient_education_resource.json   ← schema, workflow field, permissions
│   └── patient_education_resource.py     ← validate() backstop only — see Workflow
├── services/
│   ├── patient_education.py              ← AI generation (Narzim AI drafts only)
│   └── patient_education_validation.py   ← all semantic validation, the workflow map
├── api/v1/
│   ├── patient_education/api.py          ← 12 whitelisted endpoints (clinician/EHR side)
│   ├── patients/api.py                   ← get_patient_education() thin delegate (Patient 360 tab)
│   ├── encounters/api.py                 ← get_encounter_education() thin delegate (Encounter section)
│   └── patient_portal/education.py       ← list_my_education_articles / get_my_education_article
├── remedisys_healthcare_ai/doctype/ai_settings/ai_settings.json  ← enable_patient_education flag
├── patches/v0/eb_docperm_spec.json       ← EB_Practitioner / EB_Nurse grants
└── llm/prompts/patient-education-v1.txt  ← the generation prompt (both LLM providers)

bruno/
├── patient_education/                    ← clinician/EHR-side requests (13 .bru files)
└── patient_portal/education/             ← patient-portal requests (2 .bru files)
```

---

## Workflow

```
Draft ──submit_for_approval──> Pending Approval ──approve_education──> Approved ──publish_education──> Published ──unpublish_education──> Archived
  ▲                                    │
  └──────────reject_education──────────┘ (Rejected can re-enter Draft or Pending Approval)
```

Allowed transitions (`services/patient_education_validation.py::_ALLOWED_TRANSITIONS`) —
anything not listed, including staying put, is rejected:

| From | May move to |
|---|---|
| `Draft` | `Pending Approval` |
| `Pending Approval` | `Approved`, `Rejected` |
| `Rejected` | `Draft`, `Pending Approval` |
| `Approved` | `Published` |
| `Published` | `Archived` |
| `Archived` | *(terminal)* |

`status`, `approved_by`, `approved_at`, and `portal_visible` are **never accepted as
request parameters on any endpoint** — always server-derived. Every transition writes via
`frappe.db.set_value` (not `doc.save()`), re-running the full semantic-validation gate
(`validate_for_approval` / `validate_for_publication`) immediately before the write, so it
always checks the record's *current* state, never what was true when it was created or
last saved. `patient_education_resource.py::validate()` is only the backstop against a
direct `frappe.get_doc(...).save()` from the Desk changing `status` outside this flow — it
re-runs `validate_workflow_transition` the same way.

---

## Doctype: `Patient Education Resource`

Single doctype, `track_changes: 1` (full native Version history — no separate audit-log
doctype). Key fields:

| Field | Type | Notes |
|---|---|---|
| `patient` | Link → Patient | required |
| `encounter` | Link → Patient Encounter | optional — set only when created from an Encounter |
| `title` / `category` / `content` | Data / Select / Text Editor | `category` ∈ the 9-value `CATEGORIES` tuple below |
| `source` | Select (`Manual` \| `Narzim AI`) | read-only, server-set only |
| `status` | Select | read-only, mutated only via the action endpoints |
| `created_by_practitioner` | Link → Healthcare Practitioner | server-derived from session, never a request param |
| `related_diagnosis` / `related_condition` | Small Text | plain-text snapshots, not Links (see above) |
| `related_medication` | Link → Medication Request | server-validated same-patient/encounter |
| `approved_by` / `approved_at` | Link / Datetime | set only by `approve_education` |
| `rejection_reason` | Small Text | set only by `reject_education` |
| `portal_visible` | Check | true only when `status = Published` |
| `patient_viewed` / `patient_viewed_at` | Check / Datetime | set by the portal's `get_my_education_article` on first open |
| `ai_prompt_log` | Link → AI Prompt Log | traceability for AI-generated drafts (Rule 10 — no prompt/response content duplicated here) |

`CATEGORIES` (`services/patient_education_validation.py`): Nutrition · Medication
Guidance · Post-Procedure Care · Chronic Disease Management · Preventive Care ·
Immunization · General Wellness · Discharge Instructions · Other.

---

## API — clinician / EHR side (`api/v1/patient_education/api.py`)

| Endpoint | Purpose |
|---|---|
| `create_manual_education` | Practitioner-authored Draft |
| `generate_ai_education` | Narzim-AI-authored Draft — refuses if `AI Settings.enable_patient_education` is off |
| `get_patient_education` | Patient 360 tab — all statuses, paginated (delegate in `patients/api.py`) |
| `get_encounter_education` | Encounter section — all statuses for one encounter (delegate in `encounters/api.py`) |
| `get_education_detail` | Single record |
| `update_draft_education` | Edit while `Draft`/`Rejected` only — has no `status` parameter, structurally |
| `delete_education` | Permanent delete — only while `Draft`/`Rejected`/`Archived` |
| `submit_for_approval` / `approve_education` / `reject_education` / `publish_education` / `unpublish_education` | The workflow transitions |
| `approve_and_publish_education` | Convenience wrapper — still runs both gates in order, never skips approval |

## API — Patient Portal side (`api/v1/patient_portal/education.py`)

Read-only, scoped to the calling patient by the query filter itself — **not** by DocPerm
(`EB_Patient` holds no grant on `Patient Education Resource` at all; see
`eb_docperm_spec.json`). Identity comes from `_session_patient()`
(`patient_portal/api.py`), reused exactly as every other portal endpoint does — never a
client-supplied patient id.

| Endpoint | Purpose |
|---|---|
| `list_my_education_articles` | `patient = <caller> AND status = Published AND portal_visible = 1` — summary shape |
| `get_my_education_article` | Full article; auto-marks `patient_viewed` on first open (no separate mark-viewed call) |

Reshapes the clinician-facing `content` HTML (only `<p>/<h4>/<ul>/<li>/<strong>` are ever
produced — see the prompt file and the manual-entry form) into the mobile/web portal's
pre-existing "article" contract: a plain-text narrative plus a separate `key_points` array
built from the `<li>` items.

> **Note:** `api/v1/patient_education/api.py`'s own module docstring still describes this
> portal exposure as "a documented API contract, not implemented here." That was accurate
> when written (2026-09-09); `patient_portal/education.py` was built afterward in the same
> branch and the docstring has not been updated yet — see [Known gaps](#known-gaps).

---

## AI generation

`services/patient_education.py::generate_education_draft()` is the **only** function that
may set `source = "Narzim AI"`, and every code path through it persists `status = "Draft"`
— there is no branch that can set anything else, so "AI never auto-publishes" is
structural rather than a convention someone could forget to follow.

- Context is bounded per Rule 5 / PHI-6 (minimum necessary): with an encounter, it reuses
  `services/ai.py::build_encounter_context(include_catalogs=False)`; without one (the
  Patient 360 entry point), `_patient_only_context()` sends only allergies, active
  medications, and the existing rolling clinical summary (capped at 2000 chars) — never a
  full chart read.
- Dispatches through the ADR-026 allowlist (`services/llm.py::get_llm_client()`).
  `generate_patient_education()` is implemented in both `integrations/anthropic.py` and
  `integrations/openai.py` with the same contract.
- Prompt: `llm/prompts/patient-education-v1.txt` — plain language, a fixed HTML tag
  allowlist, explicit "never invent a diagnosis/medication/dose not in the provided
  context," and a JSON-only response contract.
- Gated by `AI Settings.enable_patient_education` (default **OFF** — feature flags ship
  off in this app). When off, `generate_ai_education` refuses the request; manual creation
  is unaffected (Rule 7 — AI unavailability never blocks clinical work).
- Every call logs to `AI Prompt Log` (new `purpose` option `Patient Education Generation`)
  via `log_prompt_call` / `log_prompt_call_general`, linked back via `ai_prompt_log`.

---

## Validation (`services/patient_education_validation.py`)

Two tiers, deliberately not conflated:

- **Blocking** (always raises `frappe.ValidationError` / `PermissionError` /
  `DoesNotExistError`): patient exists and is active, encounter/medication belong to the
  same patient, title/content are non-empty, long enough, not placeholder text
  (`lorem ipsum`, `tbd`, `coming soon`, …), not a single character repeated, and every
  workflow transition is legal.
- **Advisory only** (`validate_content`'s return value, never raised): a deterministic —
  not LLM — keyword-overlap check between title/content and the selected category. A miss
  never blocks the request; the product spec explicitly requires that a legitimate
  multi-topic note not be rejected over a simple keyword mismatch (Rule 9: AI/heuristics
  are never the sole authority for a hard gate).

`resolve_acting_practitioner()` resolves the acting practitioner from
`frappe.session.user` via the new shared `utils.py::get_practitioner_for_user()` helper —
never from a client-supplied practitioner id. This replaced three copy-pasted one-liners
across `encounters/api.py` / `appointments/api.py` / `tasks/api.py`; those three existing
call sites were left untouched.

---

## Permissions

`patches/v0/eb_docperm_spec.json` (re-applied every `after_migrate` via
`rebuild_eb_role_permissions` — no separate dated patch was needed):

| Role | create | read | write | delete |
|---|---|---|---|---|
| `EB_Practitioner` | ✅ | ✅ | ✅ | — |
| `EB_Nurse` | — | ✅ | — | — |
| `EB_Front Desk` | — | — | — | — |
| `EB_Patient` | — | — | — | — |

`EB_Front Desk` is deliberately granted nothing — front desk has no operational need to
read clinical education content (PHI-6 minimum necessary), a deliberate deviation from the
Surgical History/Allergy doctypes' pattern of also granting Front Desk read.
`EB_Patient` is granted nothing at all; portal access is enforced entirely by the query
filter in `patient_portal/education.py` (see above), matching that module's existing
pattern for every other patient-facing endpoint.

---

## Known gaps

- **No committed test file.** `tests/` has no `patient_education/` directory. The 18
  end-to-end checks described in the 2026-09-09 `WORK_LOG.md` entry (cross-patient
  rejection, nurse-role create rejection, publish-without-approval rejection, the full
  happy path, illegal-transition rejection) were run ad hoc via `bench console`, not saved
  as pytest. This is auth/persistence/safety-adjacent code (Rule 6 — physician-in-control)
  and should get real coverage before this ships past `dev`.
- **`patient_education/api.py`'s module docstring is stale** — it still describes the
  Patient Portal exposure as unimplemented; `patient_portal/education.py` exists now (see
  the note above). Needs a one-line docstring fix.
- **EHR frontend (`EB_Healthcare_EHR`) — Patient 360 Education tab and Encounter Education
  section — not started.** Route-traced to classic `encounter-screen.tsx` (the `v3/`
  guided flow defaults off via `NEXT_PUBLIC_FEATURE_ENCOUNTER_V2`); verify which encounter
  UI is actually live in production before wiring the section there, since that env var can
  be flipped per deployment.
- **Patient Portal (`EB_Healthcare_PatientPortal`) list/detail UI — not started.** The
  backend contract above is fixed and implemented; only the mobile/web screens remain.
- Both frontend items live in separate repos not present in this bench checkout.

---

## Related documents

- [`WORK_LOG.md`](../WORK_LOG.md) — `2026-09-09 — Patient Education module` (full build
  narrative, files touched, verification performed)
- [`CHANGELOG.md`](../CHANGELOG.md) — `2026-09-09 · Patient Education module`
- `CLAUDE.md` §7 (custom doctypes), §9 (documentation hard rules this file follows)

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-10 | Anant Sharma (AI-assisted) | Initial version — backend architecture, workflow, API surface, permissions, and known gaps as of `feat/patient-education` |
