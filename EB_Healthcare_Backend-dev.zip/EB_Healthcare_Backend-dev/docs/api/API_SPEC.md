# Remedisys — API Specification

**Doc status:** living · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.2

**Version:** 1.2  
**Date:** 2026-06-10  
**Author:** Solution Architecture  
**Status:** Living document — updated from code + frontend contract audit

> **Last audit:** 2026-06-10. Cross-referenced against:
> - Backend: `api/v1/*/api.py` (line counts + function signatures)
> - Frontend: `Healthcare_next_app/docs/platform/API_CONTRACT_REPORT.md`
> - Auth: ADR-011 (eb_frappe_jwt — supersedes OAuth2)

> This document is the authoritative contract between the frontend (`Healthcare_next_app`)
> and the backend (`remedisys_healthcare_ai`). No API is implemented without a spec entry here.
> No spec entry is added without product approval.

---

## Personas

Every API is designed around a specific person doing a specific job. These are the five clinic personas this platform serves.

| ID | Persona | Name | Frappe Role | Frontend RoleId | What they care about |
|---|---|---|---|---|---|
| `P1` | **Front Desk** | Maria Salinas | `Front Desk` | `frontdesk` | Speed. Book fast, check in fast, collect payment fast. No wasted clicks. |
| `P2` | **Nurse** | Lourdes Méndez | `Nurse` | `nurse` | Accuracy. Correct vitals, right patient, right queue. |
| `P3` | **Practitioner** | Dr. Miguel Soto | `Practitioner` | `practitioner` | Context. Full patient history before walking in the room. |
| `P4` | **Admin** | Carlos Reyes | `Admin` / `System Manager` | `admin` | Visibility. See everything across all clinics, fix anything, no surprises. |
| `P5` | **Patient** | Mariana Reyes | `Patient` | `patient` | Convenience. Own records, own appointments, messages with the clinic. |

---

## Conventions

### Base path
All custom methods follow this pattern:
```
POST /api/method/remedisys_healthcare_ai.api.v1.<module>.api.<function_name>
```

### Authentication
Every request carries a Bearer token issued by Frappe OAuth2:
```
Authorization: Bearer <access_token>
```
The token is never sent from the browser directly. It lives in the NextAuth encrypted server-side session. The Next.js BFF injects it on every API route call.

### Standard success envelope
```json
{
  "message": {
    "data": [...],
    "total": 42,
    "page": 1,
    "page_size": 20
  }
}
```

### Standard error envelope
```json
{
  "exc_type": "PermissionError",
  "message": "Human-readable error message"
}
```

### HTTP status codes
| Code | Meaning |
|---|---|
| `200` | Success |
| `400` | Validation error — bad input |
| `401` | Not authenticated — token expired or missing |
| `403` | Permission denied — valid user, wrong role |
| `404` | Document not found |
| `500` | Unexpected server error |

### Pagination
All list endpoints accept `page` (default `1`) and `page_size` (default `20`, max `100`).

---

## Table of Contents

1. [Auth](#1-auth)
2. [Dashboard](#2-dashboard)
3. [Patients](#3-patients)
4. [Patient 360](#4-patient-360)
   - 4.1 Overview
   - 4.2 Timeline
   - 4.3 Vitals
   - 4.4 Encounters
   - 4.5 Lab Center
   - 4.6 Medications
   - 4.7 Immunizations
   - 4.8 Clinical History
   - 4.9 Documents
   - 4.10 Appointments (patient view)
   - 4.11 Tasks
   - 4.12 Referrals
   - 4.13 Billing (patient view)
   - 4.14 Insurance
   - 4.15 Messages
   - 4.16 Contact
5. [Appointments](#5-appointments)
6. [Encounters](#6-encounters)
7. [Labs](#7-labs)
8. [Medications Master](#8-medications-master)
9. [Billing](#9-billing)
10. [Admin](#10-admin)
11. [Inbox](#11-inbox)
12. [Notifications](#12-notifications)
13. [Providers](#13-providers)
14. [Reports](#14-reports)
15. [Custom Doctypes](#15-custom-doctypes)

---

---

# 1. Auth

> OAuth2 login/refresh/logout are Frappe built-ins — no custom code needed for those.
> Only one custom method exists in this domain and it is already built.

---

## 1.1 — Get Current User

> **User Story:** As **any clinic staff member (P1–P5)**, after I log in I want the system to know exactly who I am, what my role is, and which department I belong to — so the dashboard shows the right queue, the right actions, and the right data for my job.

**Screen:** Called immediately after OAuth2 token exchange. Not visible — runs in the NextAuth BFF before the session cookie is set.  
**Personas:** P1 Maria, P2 Lourdes, P3 Dr. Miguel, P4 Carlos, P5 Elena  
**Phase:** 0 — ✅ **Already built**  
**Module:** `api/v1/auth/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.auth.api.get_current_user
```

**Request parameters:** None. Uses `frappe.session.user` from the Bearer token.

**Response:**
```json
{
  "message": {
    "name": "dr.miguel@chavitos.mx",
    "full_name": "Dr. Miguel Soto",
    "email": "dr.miguel@chavitos.mx",
    "phone": "+52 999 123 4567",
    "user_image": "/files/dr-miguel.jpg",
    "roles": ["Practitioner", "System User"],
    "practitioner": {
      "name": "HP-0001",
      "practitioner_name": "Dr. Miguel Soto",
      "department": "Pediatric Surgery"
    }
  }
}
```

> `practitioner` is `null` for non-clinical staff (receptionists, admins).

**DocType mapping:**
| Response field | DocType | Field |
|---|---|---|
| `name`, `full_name`, `email`, `phone`, `user_image` | `User` | Standard fields |
| `roles[]` | `User Role` | child table of `User` |
| `practitioner.*` | `Healthcare Practitioner` | Linked via `Healthcare Practitioner.user` |

**Permissions:**
| Role | Access |
|---|---|
| Any authenticated user | ✅ Own record only |
| Guest | ❌ 401 |
| Disabled user | ❌ 403 |

**Error cases:**
| Condition | HTTP | `exc_type` |
|---|---|---|
| Token expired | 401 | `AuthenticationError` |
| User account disabled in Frappe | 403 | `ValidationError` |
| User is `Guest` | 401 | `AuthenticationError` |

---

## 1.2 — Auth Endpoints (eb_frappe_jwt — ADR-011)

> ⚠️ **ADR-011 supersedes OAuth2.** The original spec referenced `frappe.integrations.oauth2.*`. That is no longer used. Auth is now `eb_frappe_jwt` Bearer JWT. Implemented and verified 2026-06-05.

**Phase:** 0 — ✅ **Built and verified end-to-end**

| Action | Method | Endpoint | Body | Returns |
|---|---|---|---|---|
| **Login** | POST | `/api/method/eb_frappe_jwt.api.get_token` | `usr, pwd, device?` | `TokenPair` or `{requires_2fa:1, tmp_id}` |
| **2FA verify** | POST | `/api/method/eb_frappe_jwt.api.verify_otp` | `tmp_id, otp, device?` | `TokenPair` |
| **Refresh** | POST | `/api/method/eb_frappe_jwt.api.refresh_token` | `refresh_token, device?` | New `TokenPair` (single-use rotation) |
| **Logout** | POST | `/api/method/eb_frappe_jwt.api.revoke_token` | `refresh_token` | `{message: "logged out"}` |
| **Logout all** | POST | `/api/method/eb_frappe_jwt.api.revoke_all_tokens` | — | Revokes all sessions |

```
TokenPair: { access_token, refresh_token, token_type: "Bearer", expires_in, refresh_expires_in }
```

**2FA status:** Backend fully supports it. Frontend shows a message on `requires_2fa` but has no OTP entry UI — deferred per ADR-011. Do not build OTP UI until explicitly scheduled.

---

---

# 2. Dashboard

---

## 2.1 — Get Dashboard Data

> **User Story:** As **Maria (P1, Receptionist)**, when I arrive at the clinic at 7:45 AM I want to see today's full appointment list, how many patients are checked in, how many are waiting, and how much outstanding payment is due — so I can start the morning handover without opening five different screens.

> **User Story:** As **Lourdes (P2, Nurse)**, I want to see only the patients who are checked in and waiting for vitals — so I know exactly who to call next without scrolling through the whole list.

> **User Story:** As **Dr. Miguel (P3, Physician)**, I want to see only patients marked "Ready for Provider" in my queue — so I can start my first encounter the moment I arrive.

**Screen:** `/dashboard` — `DashboardClient` → `DashboardScreen`  
**Personas:** P1 Maria, P2 Lourdes, P3 Dr. Miguel  
**Phase:** 1  
**Module:** `api/v1/dashboard/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.dashboard.api.get_dashboard_data
```

**Request parameters:**
| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `date` | `string` (YYYY-MM-DD) | No | today | The calendar date to load |
| `location` | `string` | No | all | Filter by `Healthcare Service Unit` name |

**Response:**
```json
{
  "message": {
    "date": "2026-06-04",
    "kpis": {
      "total_today": 28,
      "confirmed": 12,
      "checked_in": 6,
      "in_room": 4,
      "completed": 3,
      "cancelled": 1,
      "no_show": 2,
      "outstanding_mxn": 4800
    },
    "queue": [
      {
        "appointment_id": "APP-0001",
        "patient_id": "PAT-0042",
        "patient_name": "Sofia Castillo",
        "age": 7,
        "appt_time": "08:00",
        "appt_type": "Consulta General",
        "status": "Checked-in",
        "practitioner_id": "HP-0001",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "location": "Consultorio 2",
        "vitals_recorded": false,
        "payment_status": "Unpaid",
        "amount_due_mxn": 650,
        "insurance": "IMSS",
        "risk_level": "routine",
        "wait_minutes": 14
      }
    ],
    "providers": [
      {
        "practitioner_id": "HP-0001",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "status": "available",
        "patients_seen_today": 3,
        "patients_waiting": 2
      }
    ]
  }
}
```

**DocType mapping:**
| Response field | DocType | Notes |
|---|---|---|
| `queue[]` | `Patient Appointment` | Filtered by `appointment_date = date` and `status != Cancelled` |
| `queue[].patient_name`, `age` | `Patient` | Joined via `patient` link |
| `queue[].practitioner_name` | `Healthcare Practitioner` | Joined via `practitioner` link |
| `kpis.outstanding_mxn` | `Sales Invoice` | Sum of `outstanding_amount` for today's patients |
| `providers[]` | `Healthcare Practitioner` | Aggregated from today's appointments |

**Permissions:**
| Role | Access |
|---|---|
| `Front Desk` | ✅ All appointments for their service unit |
| `Nurse` | ✅ Appointments with status `Checked-in` and above |
| `Practitioner` | ✅ Own appointments only |
| `System Manager` | ✅ All appointments, all locations |

**Error cases:**
| Condition | HTTP | Message |
|---|---|---|
| `date` is more than 30 days in the future | 400 | "Cannot load dashboard for a date more than 30 days ahead." |
| `location` does not exist | 400 | "Service unit not found." |

---

---

# 3. Patients

---

## 3.1 — List Patients

> **User Story:** As **Maria (P1, Receptionist)**, when a patient walks in I want to search by name, phone number, or date of birth and find their record in under 3 seconds — so I can check them in without creating a duplicate.

**Screen:** `/patients` — `PatientsClient`  
**Personas:** P1 Maria, P2 Lourdes, P3 Dr. Miguel, P4 Carlos  
**Phase:** 1 — ✅ **Built** (`api/v1/patients/api.py` — 1411 lines)  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.list_patients
```

**Request parameters:**
| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `search` | `string` | No | `""` | Free-text search: patient name, MRN, phone, email |
| `sex` | `string` | No | all | `"Male"` \| `"Female"` \| `"Other"` |
| `age_min` | `integer` | No | — | Minimum age in years |
| `age_max` | `integer` | No | — | Maximum age in years |
| `page` | `integer` | No | 1 | Page number |
| `page_size` | `integer` | No | 20 | Results per page (max 100) |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "name": "PAT-0042",
        "patient_name": "Sofia Castillo",
        "sex": "Female",
        "dob": "2019-03-14",
        "age_display": "7 years",
        "mobile": "+52 999 123 4567",
        "email": "sofia.castillo@email.com",
        "blood_group": "O+",
        "last_visit": "2026-05-20",
        "allergies": ["Penicillin"],
        "patient_image": "/files/sofia.jpg"
      }
    ],
    "total": 142,
    "page": 1,
    "page_size": 20
  }
}
```

**DocType mapping:** `Patient`

**Permissions:** All authenticated roles — `Front Desk`, `Nurse`, `Physician`, `System Manager`

---

## 3.2 — Get Patient

> **User Story:** As **Dr. Miguel (P3)**, before I walk into the room I want to see the patient's basic demographics, active allergies, and chronic conditions — so I know the critical context before saying hello.

**Screen:** Patient row click → opens Patient 360 header  
**Personas:** P1, P2, P3, P4  
**Phase:** 1 — ✅ **Built**  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.get_patient
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `patient_id` | `string` | Yes | Patient document name (e.g. `PAT-0042`) |

**Response:**
```json
{
  "message": {
    "name": "PAT-0042",
    "patient_name": "Sofia Castillo",
    "sex": "Female",
    "dob": "2019-03-14",
    "age_display": "7 years 2 months",
    "blood_group": "O+",
    "mobile": "+52 999 123 4567",
    "email": "sofia.castillo@email.com",
    "patient_image": "/files/sofia.jpg",
    "allergies": [
      { "allergy": "Penicillin", "reaction": "Anaphylaxis", "severity": "High" }
    ],
    "chronic_conditions": ["Type 1 Diabetes", "Asthma"],
    "guardian": {
      "name": "Ana Castillo",
      "relation": "Mother",
      "mobile": "+52 999 987 6543"
    },
    "address": "Calle 60 #125, Mérida, Yucatán, México"
  }
}
```

**DocType mapping:**
| Response field | DocType | Field |
|---|---|---|
| Patient fields | `Patient` | Standard |
| `allergies[]` | `Patient Allergy` (child of Patient) | |
| `chronic_conditions[]` | `Patient Medical Record` or `Diagnosis` | Filtered type |
| `guardian` | `Patient Relation` | Relation type = Guardian |

---

## 3.3 — Create Patient

> **User Story:** As **Maria (P1, Receptionist)**, when a new patient arrives I want to register them in under 2 minutes by entering their name, date of birth, sex, and phone number — so they can be seen today without waiting for a lengthy registration process.

**Screen:** `/patients` → "New Patient" sheet  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 1 — ✅ **Built**  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.create_patient
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `first_name` | `string` | Yes | |
| `last_name` | `string` | Yes | |
| `sex` | `string` | Yes | `"Male"` \| `"Female"` \| `"Other"` |
| `dob` | `string` | Yes | YYYY-MM-DD |
| `mobile` | `string` | Yes | E.164 format preferred |
| `email` | `string` | No | |
| `blood_group` | `string` | No | `"O+"`, `"A+"`, etc. |
| `guardian_name` | `string` | No | Required if patient is under 18 |
| `guardian_mobile` | `string` | No | |
| `address` | `string` | No | |

**Response:**
```json
{
  "message": {
    "name": "PAT-0043",
    "patient_name": "Carlos Mendoza López"
  }
}
```

**DocType mapping:** `Patient` — `insert()`

**Permissions:**
| Role | Access |
|---|---|
| `Front Desk` | ✅ |
| `Practitioner` | ✅ |
| `System Manager` | ✅ |
| `Nurse` | ❌ — nurses do not register patients |

**Error cases:**
| Condition | HTTP | Message |
|---|---|---|
| `first_name` or `last_name` missing | 400 | "Patient name is required." |
| `dob` in the future | 400 | "Date of birth cannot be in the future." |
| Patient under 18 with no guardian | 400 | "Guardian details are required for patients under 18." |

---

## 3.4 — Update Patient

> **User Story:** As **Maria (P1)**, when a patient tells me their phone number has changed I want to update it immediately during check-in — so appointment reminders reach them correctly.

**Screen:** Patient 360 → Contact tab → Edit  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 1  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.update_patient
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `mobile` | `string` | No | |
| `email` | `string` | No | |
| `address` | `string` | No | |
| `blood_group` | `string` | No | |
| `guardian_name` | `string` | No | |
| `guardian_mobile` | `string` | No | |

**Response:**
```json
{ "message": { "name": "PAT-0042", "updated": true } }
```

**DocType mapping:** `Patient` — `get_doc().save()`

---

---

# 4. Patient 360

> The Patient 360 is the richest screen in the platform. Each tab is an independent API call — they are loaded on demand when the user navigates to that tab, not all at once. This keeps the initial render fast.

---

## 4.1 — Patient Overview

> **User Story:** As **Dr. Miguel (P3)**, when I open a patient chart I want to immediately see their last visit, active orders, their care team, and any AI-generated summary — so I have full clinical context in under 5 seconds.

**Screen:** `/patients/[id]` → Overview tab  
**Personas:** P3 Dr. Miguel, P4 Carlos  
**Phase:** 1  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.get_patient_overview
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `patient_id` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "last_encounter": {
      "name": "ENC-0089",
      "date": "2026-05-20",
      "practitioner_name": "Dr. Miguel Soto",
      "chief_complaint": "Fiebre y dolor de garganta",
      "diagnosis": "Faringitis aguda",
      "soap_summary": "7-year-old female presented with 3-day fever..."
    },
    "open_orders": [
      {
        "type": "Lab Test",
        "name": "LT-0044",
        "description": "Biometría hemática completa",
        "status": "Pending",
        "ordered_date": "2026-05-20"
      }
    ],
    "care_team": [
      {
        "practitioner_id": "HP-0001",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "is_primary": true,
        "avatar": "/files/dr-miguel.jpg"
      }
    ],
    "next_appointment": {
      "appointment_id": "APP-0112",
      "date": "2026-06-10",
      "time": "10:00",
      "type": "Seguimiento"
    },
    "ai_summary": null
  }
}
```

> `ai_summary` is always `null` in Phase 1–4. Populated in Phase 5.

**DocType mapping:**
| Field | DocType |
|---|---|
| `last_encounter` | `Patient Encounter` — latest by date |
| `open_orders` | `Lab Test`, `Medication Request` — status not completed |
| `care_team` | `Healthcare Practitioner` — practitioners who have seen this patient |
| `next_appointment` | `Patient Appointment` — next upcoming |

---

## 4.2 — Patient Timeline

> **User Story:** As **Dr. Miguel (P3)**, I want to see a chronological feed of everything that has happened with this patient — every visit, every lab result, every vital sign — so I can understand their history at a glance without clicking through 10 different tabs.

**Screen:** Patient 360 → Timeline tab  
**Personas:** P3, P4  
**Phase:** 1  
**Module:** `api/v1/patients/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.get_patient_timeline
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `page` | `integer` | No | 1 |
| `page_size` | `integer` | No | 30 |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "date": "2026-05-20",
        "type": "encounter",
        "title": "Consulta — Faringitis aguda",
        "ref_id": "ENC-0089",
        "practitioner": "Dr. Miguel Soto",
        "icon": "stethoscope"
      },
      {
        "date": "2026-05-20",
        "type": "lab_result",
        "title": "BHC completa — resultado normal",
        "ref_id": "LT-0044",
        "icon": "flask"
      },
      {
        "date": "2026-05-18",
        "type": "vitals",
        "title": "Signos vitales registrados",
        "ref_id": "VS-0201",
        "icon": "activity"
      }
    ],
    "total": 87,
    "page": 1,
    "page_size": 30
  }
}
```

**DocType mapping:** Aggregation across `Patient Encounter`, `Lab Test`, `Vital Signs`, `Patient Medical Record`, `Patient Appointment` — all filtered by patient, ordered by date descending.

---

## 4.3 — List Vitals

> **User Story:** As **Lourdes (P2, Nurse)**, before I record today's vitals I want to see the patient's last three readings — so I can immediately spot an abnormal trend and flag it to the doctor before the encounter starts.

> **User Story:** As **Dr. Miguel (P3)**, for pediatric patients I need to see a WHO growth chart with weight and height percentile curves — so I can assess developmental progress and explain it to the parents visually.

**Screen:** Patient 360 → Vitals tab  
**Personas:** P2 Lourdes, P3 Dr. Miguel  
**Phase:** 2  
**Module:** `api/v1/clinical/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.list_vitals
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `limit` | `integer` | No | 10 |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "name": "VS-0201",
        "date": "2026-05-18",
        "weight_kg": 22.5,
        "height_cm": 118,
        "bmi": 16.2,
        "bp_systolic": 98,
        "bp_diastolic": 62,
        "pulse": 88,
        "temperature_c": 37.1,
        "spo2_pct": 98,
        "respiratory_rate": 20,
        "recorded_by": "Lourdes Méndez",
        "abnormal_flags": []
      }
    ],
    "growth_chart_data": {
      "applicable": true,
      "sex": "Female",
      "dob": "2019-03-14",
      "weight_series": [
        { "date": "2026-05-18", "weight_kg": 22.5, "percentile": 52 }
      ],
      "height_series": [
        { "date": "2026-05-18", "height_cm": 118, "percentile": 48 }
      ]
    }
  }
}
```

> `growth_chart_data.applicable` is `true` only for patients under 18. Percentile calculation uses WHO growth reference tables.

**DocType mapping:** `Vital Signs` filtered by patient, ordered by `signs_date` descending.

---

## 4.4 — Record Vitals

> **User Story:** As **Lourdes (P2, Nurse)**, after I take the patient's measurements I want to enter them in a single form and save — so the doctor can see them the moment they open the encounter without asking me separately.

**Screen:** Dashboard → Vitals Intake dialog, or Patient 360 → Vitals tab  
**Personas:** P2 Lourdes  
**Phase:** 2  
**Module:** `api/v1/clinical/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.record_vitals
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `encounter_id` | `string` | No | Links vitals to an encounter if open |
| `weight_kg` | `float` | No | |
| `height_cm` | `float` | No | |
| `bp_systolic` | `integer` | No | |
| `bp_diastolic` | `integer` | No | |
| `pulse` | `integer` | No | Beats per minute |
| `temperature_c` | `float` | No | Celsius |
| `spo2_pct` | `float` | No | Oxygen saturation % |
| `respiratory_rate` | `integer` | No | |

**Response:**
```json
{
  "message": {
    "name": "VS-0202",
    "abnormal_flags": [
      { "field": "pulse", "value": 112, "range": "60–100", "severity": "mild" }
    ]
  }
}
```

**DocType mapping:** `Vital Signs` — `insert()`  
**Permissions:** `Nurse`, `Physician`, `System Manager`

---

## 4.5 — List Encounters (Patient View)

> **User Story:** As **Dr. Miguel (P3)**, when reviewing a patient I want to see all their past encounters sorted newest first, with the diagnosis and my notes for each — so I don't repeat questions the patient has already answered.

**Screen:** Patient 360 → Clinical → Encounters tab  
**Personas:** P3 Dr. Miguel, P4 Carlos  
**Phase:** 1  
**Module:** `api/v1/encounters/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.encounters.api.list_encounters
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `page` | `integer` | No | 1 |
| `page_size` | `integer` | No | 10 |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "name": "ENC-0089",
        "date": "2026-05-20",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "chief_complaint": "Fiebre y dolor de garganta",
        "diagnoses": ["Faringitis aguda (J02.9)"],
        "status": "Completed",
        "has_prescription": true,
        "has_lab_orders": true
      }
    ],
    "total": 14,
    "page": 1,
    "page_size": 10
  }
}
```

**DocType mapping:** `Patient Encounter` + `Patient Encounter Diagnosis`

---

## 4.6 — List Prescriptions (Patient View)

> **User Story:** As **Dr. Miguel (P3)**, before prescribing I need to see all active medications this patient is currently taking — so I do not prescribe a drug that interacts with something they are already on.

**Screen:** Patient 360 → Clinical → Medications tab  
**Personas:** P3, P2 (view only)  
**Phase:** 2  
**Module:** `api/v1/prescriptions/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.prescriptions.api.list_prescriptions
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `status` | `string` | No | `"active"` | `"active"` \| `"all"` |

**Response:**
```json
{
  "message": {
    "active": [
      {
        "medication": "Amoxicilina",
        "dosage": "250 mg",
        "dosage_form": "Suspensión",
        "frequency": "Cada 8 horas",
        "duration": "7 días",
        "route": "Oral",
        "prescribed_by": "Dr. Miguel Soto",
        "prescribed_date": "2026-05-20",
        "encounter_id": "ENC-0089",
        "weight_based": true,
        "dose_per_kg": "40 mg/kg/día",
        "patient_weight_kg": 22.5
      }
    ],
    "history": []
  }
}
```

**DocType mapping:** `Drug Prescription` (child table of `Patient Encounter`) joined with `Medication`

---

## 4.7 — Immunization Record

> **User Story:** As **Lourdes (P2, Nurse)**, when a parent brings their child for a well-child check I want to immediately see the full vaccination history against the Mexico EPI schedule — so I can identify which vaccines are due or overdue and administer them today.

**Screen:** Patient 360 → Clinical → Immunizations tab (Grid, Timeline, Records views)  
**Personas:** P2 Lourdes, P3 Dr. Miguel  
**Phase:** 2 — **⚠️ Pending: verify `Nursing Task` coverage on `marley.local`**  
**Module:** `api/v1/clinical/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.get_immunization_record
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `patient_id` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "patient_dob": "2019-03-14",
    "patient_age_months": 87,
    "schedule": [
      {
        "vaccine": "BCG",
        "due_age": "Al nacer",
        "status": "given",
        "given_date": "2019-03-14",
        "batch_no": "BCG-2019-MX",
        "administered_by": "Enfermería"
      },
      {
        "vaccine": "MMR (Triple Viral)",
        "due_age": "12 meses",
        "status": "overdue",
        "given_date": null,
        "overdue_since": "2020-03-14"
      },
      {
        "vaccine": "VPH",
        "due_age": "9–14 años",
        "status": "upcoming",
        "given_date": null,
        "due_from": "2028-03-14"
      }
    ],
    "stats": {
      "administered": 8,
      "overdue": 1,
      "upcoming": 3,
      "total_in_schedule": 12
    }
  }
}
```

**DocType mapping:** `Nursing Task` or `Clinical Procedure` filtered by type = Immunization — **needs verification on `marley.local`**

---

## 4.8 — Clinical History

> **User Story:** As **Dr. Miguel (P3)**, when I open a patient chart I need to see documented allergies, chronic conditions, surgical history, family history, and birth/developmental history in one place — so I have complete medical context before starting the encounter.

**Screen:** Patient 360 → Clinical → History tab  
**Personas:** P3, P2 (view), P4  
**Phase:** 2  
**Module:** `api/v1/clinical/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.get_medical_history
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `patient_id` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "allergies": [
      { "allergy": "Penicillin", "reaction": "Anaphylaxis", "severity": "High" }
    ],
    "chronic_conditions": ["Type 1 Diabetes", "Asthma"],
    "surgical_history": [
      { "procedure": "Apendicectomía", "date": "2023-09-10", "hospital": "IMSS" }
    ],
    "family_history": [
      { "condition": "Diabetes tipo 2", "relation": "Abuela materna" }
    ],
    "birth_history": {
      "gestation_weeks": 39,
      "birth_weight_kg": 3.2,
      "delivery_type": "Cesárea",
      "apgar_score": 9
    },
    "developmental_milestones": {
      "walked_months": 13,
      "spoke_words_months": 14,
      "notes": "Desarrollo normal"
    }
  }
}
```

**DocType mapping:** `Patient` (birth/allergy fields) + `Patient Medical Record` (surgical, family history)

---

## 4.9 — Patient Documents

> **User Story:** As **Maria (P1, Receptionist)**, when a patient brings physical documents (insurance card, referral letter, prior lab reports) I want to scan and attach them to their chart — so the doctor can access them during the encounter without asking the patient to bring papers again.

**Screen:** Patient 360 → Clinical → Documents tab  
**Personas:** P1, P2, P3, P4  
**Phase:** 2  
**Module:** `api/v1/patients/api.py`

**Methods:**

**List documents:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.list_documents
```
Parameters: `patient_id`

**Upload document:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.upload_document
```
Parameters: `patient_id`, `file_name`, `file_data` (base64), `category` (`"Lab Report"` | `"Referral"` | `"Insurance"` | `"Consent"` | `"Other"`)

**Delete document:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.delete_document
```
Parameters: `file_id`

**DocType mapping:** Frappe standard `File` doctype — `attached_to_doctype = "Patient"`, `attached_to_name = patient_id`

---

## 4.10 — Patient Appointments (Patient View)

> **User Story:** As **Maria (P1)**, when a patient asks "when is my next appointment?" I want to pull up their full appointment history instantly — so I can answer without putting them on hold.

**Screen:** Patient 360 → Operations → Appointments tab  
**Personas:** P1, P3, P4  
**Phase:** 1  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.list_patient_appointments
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `status_filter` | `string` | No | `"all"` | `"upcoming"` \| `"completed"` \| `"cancelled"` \| `"all"` |
| `page` | `integer` | No | 1 |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "appointment_id": "APP-0112",
        "date": "2026-06-10",
        "time": "10:00",
        "status": "Open",
        "type": "Seguimiento",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "location": "Consultorio 2",
        "reason": "Revisión post-cirugía",
        "amount_mxn": 650,
        "payment_status": "Unpaid"
      }
    ],
    "total": 23
  }
}
```

**DocType mapping:** `Patient Appointment` filtered by `patient = patient_id`

---

## 4.11 — Clinical Tasks

> **User Story:** As **Dr. Miguel (P3)**, I want to create a follow-up task on a patient's chart — for example "Call mother in 3 days to check fever" — so nothing falls through the cracks between visits.

**Screen:** Patient 360 → Operations → Tasks tab  
**Personas:** P2 Lourdes, P3 Dr. Miguel, P4 Carlos  
**Phase:** 2  
**Module:** `api/v1/clinical/api.py`

**Methods:**

**List tasks:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.list_nursing_tasks
```
Parameters: `patient_id`, `status_filter` (`"open"` | `"completed"` | `"all"`)

**Create task:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.create_nursing_task
```
Parameters: `patient_id`, `task_name`, `description`, `due_date`, `priority` (`"High"` | `"Medium"` | `"Low"`), `assigned_to` (user)

**Complete task:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.complete_nursing_task
```
Parameters: `task_id`

**DocType mapping:** `Nursing Task` (standard Healthcare app ✅)

---

## 4.12 — Referrals

> **User Story:** As **Dr. Miguel (P3)**, when a patient needs to see a specialist I want to create a referral from within the chart — specifying the receiving doctor, the reason, and urgency — so the patient has a documented referral that the receiving clinic can verify.

**Screen:** Patient 360 → Operations → Referrals tab  
**Personas:** P3 Dr. Miguel, P4 Carlos  
**Phase:** 2 — **Requires custom `Patient Referral` doctype**  
**Module:** `api/v1/clinical/api.py`

**Methods:**

**List referrals:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.list_referrals
```

**Create referral:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.clinical.api.create_referral
```

**Request parameters (create):**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `department` | `string` | Yes | Link to `Medical Department` |
| `referred_to_practitioner` | `string` | No | Link to `Healthcare Practitioner` |
| `referral_type` | `string` | Yes | `"Internal"` \| `"External"` |
| `reason` | `string` | Yes | Clinical reason |
| `urgency` | `string` | Yes | `"Routine"` \| `"Urgent"` \| `"Emergency"` |
| `notes` | `string` | No | |

**DocType mapping:** `Patient Referral` — **custom doctype required** (see Section 15)

---

## 4.13 — Patient Billing (Patient View)

> **User Story:** As **Maria (P1, Receptionist)**, when a patient is checking out I want to pull up their outstanding invoices from within the chart — so I can collect payment without switching to a separate billing screen.

**Screen:** Patient 360 → Financial → Billing tab  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.list_patient_invoices
```

Parameters: `patient_id`, `status_filter` (`"unpaid"` | `"paid"` | `"all"`), `page`

**Response:**
```json
{
  "message": {
    "outstanding_total_mxn": 1300,
    "data": [
      {
        "invoice_id": "SINV-0089",
        "date": "2026-05-20",
        "encounter_id": "ENC-0089",
        "status": "Unpaid",
        "subtotal_mxn": 650,
        "iva_mxn": 104,
        "total_mxn": 754,
        "outstanding_mxn": 754,
        "line_items": [
          { "description": "Consulta Pediátrica", "qty": 1, "rate_mxn": 650 }
        ]
      }
    ]
  }
}
```

**DocType mapping:** `Sales Invoice` + `Sales Invoice Item` (ERPNext)

---

## 4.14 — Insurance Policies

> **User Story:** As **Maria (P1)**, before billing I want to see which insurance plans this patient has active — so I know whether to charge the patient directly or file a claim.

**Screen:** Patient 360 → Financial → Insurance tab  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 3  
**Module:** `api/v1/insurance/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.insurance.api.list_policies
```

Parameters: `patient_id`

**Response:**
```json
{
  "message": {
    "data": [
      {
        "policy_id": "PIP-0012",
        "payor": "IMSS",
        "policy_number": "IMSS-1234567890",
        "coverage_type": "Complete",
        "valid_from": "2026-01-01",
        "valid_till": "2026-12-31",
        "status": "Active",
        "co_pay_mxn": 0
      }
    ]
  }
}
```

**DocType mapping:** `Patient Insurance Policy` + `Insurance Payor` (Healthcare app ✅)

---

## 4.15 — Messages (Patient View)

> **User Story:** As **Dr. Miguel (P3)**, after an encounter I want to send a follow-up message to the patient's guardian — for example "Give the second dose at 8 PM" — so critical instructions are documented and not just verbal.

**Screen:** Patient 360 → Communication → Messages tab  
**Personas:** P1, P2, P3, P4  
**Phase:** 2  
**Module:** `api/v1/patients/api.py` (thin wrapper over Raven/clefincode_chat)

**Methods:**

**List messages:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.list_messages
```

**Send message:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.patients.api.send_message
```
Parameters: `patient_id`, `message_text`

**DocType mapping:** Raven `Message` or clefincode_chat — using the installed messaging app on `marley.local`. **Decision needed:** which chat app to use (Raven or clefincode_chat)?

---

## 4.16 — Contact Info

> **User Story:** As **Maria (P1)**, when a patient tells me their address has changed I want to update it in the chart in 30 seconds — so appointment reminder messages go to the right WhatsApp number.

**Screen:** Patient 360 → Operations → Contact tab  
**Personas:** P1, P4  
**Phase:** 1  
**Covered by:** `update_patient()` (Section 3.4) — no separate API needed.

---

---

# 5. Appointments

---

## 5.1 — Get Available Slots

> **User Story:** As **Maria (P1)**, when a patient asks for the next available slot with Dr. Miguel next Tuesday I want to see a real-time grid of open times — so I can offer choices without checking a paper schedule.

**Screen:** New Appointment dialog → Step 2  
**Personas:** P1 Maria  
**Phase:** 1 — ✅ **Built**  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.get_available_slots
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `practitioner_id` | `string` | Yes |
| `date` | `string` | Yes | YYYY-MM-DD |
| `appointment_type` | `string` | No |

**Response:**
```json
{
  "message": {
    "practitioner_name": "Dr. Miguel Soto",
    "date": "2026-06-10",
    "slots": [
      { "time": "08:00", "available": true },
      { "time": "08:30", "available": false, "reason": "Booked" },
      { "time": "09:00", "available": true }
    ]
  }
}
```

**DocType mapping:** `Practitioner Schedule` + `Healthcare Schedule Time Slot` + `Patient Appointment` (check existing bookings)

---

## 5.2 — Book Appointment

> **User Story:** As **Maria (P1)**, once a patient and I agree on a time I want to confirm the booking in a single click — and have a WhatsApp reminder automatically scheduled for the day before — so I never have to call patients manually to remind them.

**Screen:** New Appointment dialog → Step 3 → Confirm  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 1 — ✅ **Built** (`book_appointment`)  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.book_appointment
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `patient_id` | `string` | Yes | |
| `practitioner_id` | `string` | Yes | |
| `date` | `string` | Yes | YYYY-MM-DD |
| `time` | `string` | Yes | HH:MM (24h) |
| `appointment_type` | `string` | Yes | Link to `Appointment Type` |
| `department` | `string` | No | |
| `location` | `string` | No | `Healthcare Service Unit` |
| `reason` | `string` | No | |
| `payment_method` | `string` | No | `"Pay now"` \| `"Pay later"` |
| `insurance_policy_id` | `string` | No | |

**Response:**
```json
{
  "message": {
    "appointment_id": "APP-0113",
    "status": "Open",
    "date": "2026-06-10",
    "time": "09:00",
    "reminder_scheduled": true
  }
}
```

**DocType mapping:** `Patient Appointment` — `insert()`. Reminder triggered as Frappe background job.

**Error cases:**
| Condition | HTTP | Message |
|---|---|---|
| Slot already booked (race condition) | 400 | "This time slot was just booked. Please choose another." |
| Patient has fee validity | 200 | Normal — fee validity is handled by Healthcare app |

---

## 5.2.1 — Book Appointment for a New OR Existing Patient (atomic)

> **User Story:** As **Maria (P1)**, when a walk-in patient is not yet registered I want to enter their details and book in one confirm — and if the booking fails, I do NOT want a half-created patient left behind that I have to clean up.

**Screen:** New Appointment dialog → Step 1 "Add as new patient" path → Step 3 Confirm  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 1 — ✅ **Built** (`book_appointment_for_patient`)  
**Module:** `api/v1/appointments/api.py`

Use this endpoint **instead of** the two-call sequence `create_patient` → `book_appointment` whenever booking must also create the patient. It creates the Patient and the Patient Appointment in a **single transaction**: if the appointment insert fails, the just-created patient is rolled back — no orphan Patient. `create_patient` and `book_appointment` are unchanged and remain valid for their own flows.

> **Parameter naming:** this endpoint uses the **implemented** field names (`patient`, `appointment_date`, `appointment_time`, `practitioner`, …) — the same names as `create_appointment`/`book_appointment` in code — NOT the `patient_id`/`date`/`time` names shown in §5.2's older draft.

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.book_appointment_for_patient
```

**Patient source — supply EXACTLY ONE:**
| Parameter | Type | Description |
|---|---|---|
| `patient` | `string` | Existing Patient docname (the already-created patient). |
| `new_patient` | `object` | Patient fields to create. Mutually exclusive with `patient`. |

`new_patient` object:
| Field | Type | Required | Description |
|---|---|---|---|
| `first_name` | `string` | Yes | |
| `gender` | `string` | Yes | Link to `Gender` (e.g. `"Male"`, `"Female"`). Maps to core `sex`. |
| `last_name` | `string` | No | |
| `middle_name` | `string` | No | |
| `dob` | `string` | No | YYYY-MM-DD |
| `mobile` | `string` | No | |
| `email` | `string` | No | |
| `phone` | `string` | No | |
| `blood_group` | `string` | No | One of the 8 standard groups (e.g. `"O Positive"`). |
| `uid` | `string` | No | CURP. **Must be unique** — a duplicate rejects the whole booking (see errors). |
| `guardians` | `array` | No | `[{ guardian_name, relation, mobile, email, is_primary, address_line1, city, country, … }]` |

**Appointment parameters** (same as `book_appointment`):
| Parameter | Type | Required | Description |
|---|---|---|---|
| `appointment_date` | `string` | Yes | YYYY-MM-DD |
| `appointment_time` | `string` | Yes | HH:MM:SS |
| `appointment_type` | `string` | Yes | Link to `Appointment Type` |
| `practitioner` | `string` | No* | `Healthcare Practitioner` docname. *Required for the conflict guard to be meaningful. |
| `service_unit` | `string` | No | `Healthcare Service Unit`. `company` is derived from it when omitted. |
| `company` | `string` | No | Derived from `service_unit` if not supplied. |
| `department` | `string` | No | |
| `duration` | `number` | No | |
| `insurance_policy` / `insurance_payor` / `insurance_coverage` | `string` | No | |
| `billing_item` | `string` | No | |
| `notes` | `string` | No | |

**Payment parameters (invoicing — ADR-012):**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `payment_timing` | `string` | No (default `pay_later`) | `pay_later` → no invoice. `pay_now` → create Sales Invoice + settle in full (Payment Entry). `insurance` → create the (coverage-split) Sales Invoice, leaving the patient portion outstanding. Accepts `Pay Now` / `pay-now` / `paynow` too. |
| `mode_of_payment` | `string` | Required when `pay_now` | Link to `Mode of Payment` (e.g. `Cash`). |
| `discount_amount` / `discount_percentage` | `number` | No | Applied to the invoice. |
| `insurance_policy` | `string` | For a real coverage split | Pass it so core builds the coverage at booking; without it, `insurance` bills the patient in full and leaves it outstanding (`has_insurance: false`). |

**Response — success (standard envelope):** the booked appointment (same shape as `book_appointment`) plus `patient_created` and a **`payment`** object describing the invoicing outcome. `data.billing` is the appointment's at-booking invoice-due summary; **`data.payment` is authoritative for the invoice/payment this call produced.** When `new_patient` was used, `data.patient` is the newly created Patient docname.
```json
{
  "status": "success",
  "data": {
    "name": "HLC-APP-2026-00190",
    "status": "Confirmed",
    "patient": "HLC-PAT-2026-00077",
    "patient_name": "Juan Pérez",
    "appointment_date": "2026-06-23",
    "appointment_time": "10:30:00",
    "appointment_type": "General Consultation",
    "practitioner": "HLC-PRAC-2026-00001",
    "billing": { "status": "Unbilled", "outstanding": 0.0 },
    "patient_created": true,
    "payment": {
      "payment_timing": "pay_now",
      "invoiced": true,
      "invoice": "ACC-SINV-2026-00033",
      "sales_invoice": "ACC-SINV-2026-00033",
      "payment_entry": "ACC-PAY-2026-00011",
      "payment_status": "Paid",
      "outstanding": 0
    }
  }
}
```
HTTP **201** on success. `payment` shapes by timing:
- `pay_later` → `{ "payment_timing": "pay_later", "invoiced": false, "invoice": null }`
- `pay_now` → invoice + `payment_entry`, `payment_status: "Paid"`, `outstanding: 0`
- `insurance` → invoice created, `payment_status: "Unpaid"`, with `total` / `outstanding` / `patient_payable_amount` / `insurance_coverage_amount` / `has_insurance`

**Failure is ALL-OR-NOTHING.** If invoicing fails (or any other step), the whole call is rolled back — the patient (if new), the appointment, and the invoice/payment are all undone — and a standard **error** envelope is returned (NOT a 201 with a partial result). Nothing is persisted. (This overrides ADR-012's "keep the appointment booked Unpaid on billing failure" policy for this endpoint, per the 2026-06-16 decision.)

**Error cases** (standard error envelope; nothing is persisted — patient and appointment both roll back):
| Condition | HTTP | Code | Message |
|---|---|---|---|
| Both `patient` and `new_patient` supplied, or neither | 400 | VALIDATION_ERROR | "Provide either an existing 'patient' or a 'new_patient' object, not both." |
| `new_patient` not an object | 400 | VALIDATION_ERROR | "new_patient must be an object." |
| `new_patient.first_name` / `.gender` missing | 400 | VALIDATION_ERROR | "new_patient.first_name is required" / "new_patient.gender is required" |
| Unknown `gender` | 400 | VALIDATION_ERROR | "Unknown gender: {x}" |
| **Duplicate CURP** (`uid` already on another patient) | 409 | CONFLICT | "A patient with CURP {x} already exists: {name} ({id})" |
| Practitioner already booked at that date+time | 409 | CONFLICT | "Practitioner {p} is already booked at {t} on {d} …" |
| No permission to create Patient / Patient Appointment / Sales Invoice / Payment Entry | 403 | PERMISSION_ERROR | "You don't have permission…" |
| Appointment insert fails (e.g. slot overlap during insert) | 4xx/500 | — | Whole call rolled back — no orphan patient, no appointment. |
| Invoicing fails (pay_now/insurance — e.g. bad mode_of_payment, no receivable account) | 4xx/500 | — | **Whole call rolled back** — patient, appointment, AND invoice/payment all undone. |

**DocType mapping:** all in ONE deferred-commit transaction under a single savepoint (`booking_txn`): `Patient` — `insert()` (if new) → `Patient Appointment` — `insert()` (via `_create_impl(commit=False)`) → (pay_now) `Sales Invoice` + `Payment Entry`, or (insurance) `Sales Invoice` only, via `services.billing`. On full success, one `frappe.db.commit()`. On ANY exception, `rollback(save_point="booking_txn")` undoes everything and the error is raised.

**BFF wiring (frontend dev — required to activate):** point the new-patient branch of `POST /api/appointments` (in `Healthcare_next_app/src/app/api/appointments/route.ts`) at this method with a `new_patient` object, replacing the current `create_patient` → `book_appointment` two-call sequence. The existing-patient branch can keep calling `book_appointment` or switch to this method with `patient`.

---

## 5.3 — Check-in Patient

> **User Story:** As **Maria (P1)**, when a patient walks in I want to mark them as "Checked in" with one click — and have a 5-second undo in case I tapped the wrong row — so the nurse's queue updates instantly and I never create errors I can't fix.

**Screen:** Dashboard → appointment row → Check-in button  
**Personas:** P1 Maria  
**Phase:** 1 — ✅ **Built** (`check_in_patient`)  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.check_in_patient
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `appointment_id` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "appointment_id": "APP-0113",
    "status": "Checked-in",
    "checked_in_at": "2026-06-04T08:42:00"
  }
}
```

**DocType mapping:** `Patient Appointment` — `doc.status = "Checked-in"`, `doc.save()`

**Error cases:**
| Condition | HTTP | Message |
|---|---|---|
| Appointment already checked in | 400 | "Patient is already checked in." |
| Appointment is cancelled | 400 | "Cannot check in a cancelled appointment." |

---

## 5.4 — Cancel Appointment

> **User Story:** As **Maria (P1)**, when a patient calls to cancel I want to mark it cancelled with a reason — and have the slot become immediately available for walk-ins — so we don't lose revenue from unused slots.

**Screen:** Appointment row → Cancel action  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 1 — ✅ **Built** (`cancel_appointment`)  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.cancel_appointment
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `appointment_id` | `string` | Yes |
| `reason` | `string` | Yes |

---

## 5.5 — Reschedule Appointment

> **User Story:** As **Maria (P1)**, when a patient asks to move their appointment I want to pick a new time without cancelling and rebooking — so the patient's history stays clean and shows a reschedule, not a cancellation.

**Screen:** Appointment row → Reschedule action  
**Personas:** P1 Maria  
**Phase:** 1 — 🔲 **Not built** (`reschedule_appointment` missing — not in current `api/v1/appointments/api.py`)  
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.reschedule_appointment
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `appointment_id` | `string` | Yes |
| `new_date` | `string` | Yes |
| `new_time` | `string` | Yes |
| `reason` | `string` | No |

---

## 5.6 — List Appointments (Clinic View)

> **User Story:** As **Carlos (P4, Clinic Admin)**, at end of day I want to see all today's appointments — confirmed, checked-in, completed, no-shows — in one table I can export to CSV — so I can review clinic performance and share it with the medical director.

**Screen:** `/appointments` — list view and `/appointments/calendar` — calendar view  
**Personas:** P1, P2, P3, P4  
**Phase:** 1 — ✅ **Built** (`list_appointments`)  
**Module:** `api/v1/appointments/api.py`

> **Also built (not in original spec):** `update_status(appointment, status)` — used by dashboard status transitions. `get_appointment(appointment)` — single record fetch.  
> **Missing frontend route:** `PATCH /api/appointments` handler does not exist in the BFF — `useUpdateAppointmentStatus` hook will 404. Add PATCH handler to `Healthcare_next_app/src/app/api/appointments/route.ts`.

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.list_appointments
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `date_from` | `string` | No | today |
| `date_to` | `string` | No | today |
| `practitioner_id` | `string` | No | all |
| `department` | `string` | No | all |
| `status` | `string` | No | all |
| `page` | `integer` | No | 1 |
| `page_size` | `integer` | No | 50 |

---

## 5.6.1 — Get Single Appointment (with payment/invoice summary)

> **User Story:** As **Maria (P1, Front Desk)**, when I open an appointment's detail drawer on the dashboard I want to see the billed **amount** and whether it's been **invoiced/paid** — so I know what to collect without opening the billing screen.

**Screen:** Dashboard Live Queue → appointment detail drawer (PAYMENT block)
**Personas:** P1, P2, P3
**Phase:** 1 — ✅ **Built** (`get_appointment`)
**Module:** `api/v1/appointments/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.appointments.api.get_appointment
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `appointment` | `string` | Yes | — |

**Response — success (standard envelope):** the full appointment shape. The fields relevant to the drawer's PAYMENT block:

```json
{
  "status": "success",
  "data": {
    "name": "HLC-APP-2026-00008",
    "invoiced": true,
    "ref_sales_invoice": "ACC-SINV-2026-00013",
    "paid_amount": 1500.0,
    "billing": {
      "invoice": "ACC-SINV-2026-00013",
      "total": 1500.0,
      "paid": 1500.0,
      "outstanding": 0.0,
      "status": "Paid",
      "currency": "MXN"
    }
  }
}
```

**`data.billing` — authoritative payment/invoice summary for the drawer:**

| Field | Meaning | Render |
|---|---|---|
| `billing.total` | Invoice grand total | The **amount** (format with `billing.currency`, e.g. `$1,500.00 MXN`) |
| `billing.paid` | Amount collected | — |
| `billing.outstanding` | Unpaid balance | Show "due" only when `> 0` |
| `billing.status` | `Paid` / `Pending` / `Unbilled` | Payment badge |
| `billing.currency` | Invoice currency (may be `null` when Unbilled) | Amount formatting |
| `billing.invoice` | Sales Invoice docname (or `null`) | Optional "View invoice" link |

**Three states (`billing.status`):**
- `"Paid"` → green badge + amount (`outstanding == 0`).
- `"Pending"` → amount + `outstanding` due.
- `"Unbilled"` → **not invoiced yet**; `total == 0`, `currency == null`. Show "Not invoiced", not an amount.

**Notes for the frontend:**
- The **amount is NOT on the dashboard queue row** (`_queue_row` carries only `invoiced` and checkout-only `outstanding_mxn`). Fetch `get_appointment` when the drawer opens to read `billing`.
- **Permission fallback:** a role without Sales Invoice read access degrades to `billing.status = "Unbilled"` with zeros (no error) — render "Not invoiced".
- **i18n:** all labels (`Paid`, `Pending`, `Not invoiced`, `due`) and currency formatting go through the message catalogs — no hardcoded strings.

---

---

# 6. Encounters

---

## 6.1 — Create Encounter

> **User Story:** As **Dr. Miguel (P3)**, when I call a patient from the queue I want to open a new encounter for them in one tap — pre-filled with today's date, my name, and their department — so I can focus on the patient immediately rather than filling in form headers.

**Screen:** Dashboard → "Start Encounter" button  
**Personas:** P3 Dr. Miguel  
**Phase:** 1 — 🔲 **Not built** (`api/v1/encounters/api.py` is 0 bytes — highest priority gap)  
**Module:** `api/v1/encounters/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.encounters.api.create_encounter
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `patient_id` | `string` | Yes |
| `appointment_id` | `string` | No | Links to appointment that triggered the encounter |
| `practitioner_id` | `string` | Yes |
| `department` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "name": "ENC-0090",
    "status": "In Progress",
    "patient_name": "Sofia Castillo",
    "patient_age": "7 years",
    "practitioner_name": "Dr. Miguel Soto",
    "department": "Pediatric Surgery",
    "started_at": "2026-06-04T09:05:00"
  }
}
```

**DocType mapping:** `Patient Encounter` — `insert()`

---

## 6.2 — Get Encounter

> **User Story:** As **Dr. Miguel (P3)**, when I open an encounter I need to see all previously entered data — chief complaint, symptoms, diagnosis, prescriptions, and lab orders — so I can continue exactly where I left off if I was interrupted.

**Screen:** `/encounters/[id]` — Encounter screen  
**Personas:** P3  
**Phase:** 1  
**Module:** `api/v1/encounters/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.encounters.api.get_encounter
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `encounter_id` | `string` | Yes |

**Response:**
```json
{
  "message": {
    "name": "ENC-0090",
    "status": "In Progress",
    "patient_id": "PAT-0042",
    "patient_name": "Sofia Castillo",
    "patient_age": "7 years",
    "patient_weight_kg": 22.5,
    "allergies": ["Penicillin"],
    "chief_complaint": "Fiebre persistente",
    "symptoms": ["Fiebre", "Dolor de garganta"],
    "diagnoses": [
      { "icd_code": "J02.9", "description": "Faringitis aguda no especificada" }
    ],
    "exam_notes": "Faringe eritematosa, sin exudado...",
    "assessment": "Faringitis viral — probable origen viral",
    "plan": "Reposo, hidratación, antipiréticos",
    "prescriptions": [
      {
        "medication": "Paracetamol",
        "dosage": "250 mg",
        "frequency": "Cada 6 horas",
        "duration": "5 días",
        "route": "Oral",
        "weight_based": true,
        "dose_per_kg": "15 mg/kg/dosis"
      }
    ],
    "lab_orders": [
      { "template": "Biometría hemática", "status": "Ordered" }
    ],
    "follow_up_date": "2026-06-11",
    "follow_up_type": "Seguimiento"
  }
}
```

---

## 6.3 — Save Encounter Draft

> **User Story:** As **Dr. Miguel (P3)**, while in the middle of an encounter if I am called away urgently I want to save everything I have typed so far — so when I return nothing is lost and the patient does not have to repeat their history.

**Screen:** Encounter screen → auto-save / manual save  
**Personas:** P3  
**Phase:** 1  
**Module:** `api/v1/encounters/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.encounters.api.save_encounter_draft
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `encounter_id` | `string` | Yes | |
| `chief_complaint` | `string` | No | |
| `symptoms` | `string[]` | No | List of symptom names |
| `diagnoses` | `object[]` | No | `[{ icd_code, description }]` |
| `exam_notes` | `string` | No | |
| `assessment` | `string` | No | |
| `plan` | `string` | No | |
| `prescriptions` | `object[]` | No | See create_prescription below |
| `lab_orders` | `object[]` | No | See order_lab_test below |
| `follow_up_date` | `string` | No | YYYY-MM-DD |
| `follow_up_type` | `string` | No | |

**Response:**
```json
{ "message": { "name": "ENC-0090", "status": "In Progress", "saved_at": "2026-06-04T09:22:00" } }
```

**DocType mapping:** `Patient Encounter` — `doc.save()` (does not submit — stays as Draft/In Progress)

---

## 6.4 — Complete Encounter

> **User Story:** As **Dr. Miguel (P3)**, when I finish the clinical assessment and have reviewed all orders I want to mark the encounter as complete — which automatically notifies the front desk that this patient needs to check out and pay — so I do not have to call Maria separately.

**Screen:** Encounter screen → "Complete Encounter" footer button  
**Personas:** P3  
**Phase:** 1  
**Module:** `api/v1/encounters/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.encounters.api.complete_encounter
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `encounter_id` | `string` | Yes |

**Validation (service layer enforces):**
- Chief complaint must be present
- At least one diagnosis must be entered
- All mandatory fields complete

**Response:**
```json
{
  "message": {
    "name": "ENC-0090",
    "status": "Completed",
    "completed_at": "2026-06-04T09:45:00",
    "invoice_created": "SINV-0090",
    "billing_notification_sent": true
  }
}
```

**DocType mapping:** `Patient Encounter` — `doc.submit()`. Post-submit hook triggers invoice creation and billing notification.

**Error cases:**
| Condition | HTTP | Message |
|---|---|---|
| No chief complaint | 400 | "Chief complaint is required to complete the encounter." |
| No diagnosis | 400 | "At least one diagnosis is required." |
| Encounter already completed | 400 | "Encounter is already completed." |

---

---

# 7. Labs

---

## 7.1 — Order Lab Test

> **User Story:** As **Dr. Miguel (P3)**, from within an encounter I want to order a lab test from a pre-set panel (e.g. "Biometría hemática completa") with a single click — and have it automatically appear in the nurse's lab collection queue — so the patient does not have to come back with a separate paper form.

**Screen:** Encounter screen → Lab Orders section  
**Personas:** P3 Dr. Miguel  
**Phase:** 2  
**Module:** `api/v1/labs/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.labs.api.order_lab_test
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `encounter_id` | `string` | Yes |
| `patient_id` | `string` | Yes |
| `template_id` | `string` | Yes | Link to `Lab Test Template` |
| `notes` | `string` | No | Clinical notes for the lab technician |

**Response:**
```json
{
  "message": {
    "lab_test_id": "LT-0045",
    "template_name": "Biometría hemática completa",
    "status": "Ordered",
    "ordered_at": "2026-06-04T09:30:00"
  }
}
```

**DocType mapping:** `Lab Test` — `insert()` with status = `"Ordered"`

---

## 7.2 — List Lab Orders (Pending)

> **User Story:** As **Lourdes (P2, Nurse)**, at the start of my shift I want to see all lab orders that are pending sample collection — sorted by patient wait time — so I can collect them in the right order without missing anyone.

**Screen:** `/labs` → Pending Orders tab  
**Personas:** P2 Lourdes, P4 Carlos  
**Phase:** 2  
**Module:** `api/v1/labs/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.labs.api.list_lab_orders
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `status` | `string` | No | `"Ordered"` | `"Ordered"` \| `"Sample Collected"` \| `"All"` |
| `date_from` | `string` | No | today | |
| `page` | `integer` | No | 1 | |

---

## 7.3 — Collect Sample

> **User Story:** As **Lourdes (P2)**, when I draw blood from a patient I want to update the lab order status to "Sample Collected" immediately on my phone — so the doctor's screen shows it was collected and the lab queue shows it is on the way.

**Screen:** Labs → pending order → "Collect" button  
**Personas:** P2 Lourdes  
**Phase:** 2  
**Module:** `api/v1/labs/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.labs.api.collect_sample
```

Parameters: `lab_test_id`

**DocType mapping:** `Lab Test` — status → `"Sample Collected"` + `Sample Collection` record

---

## 7.4 — Record Lab Result

> **User Story:** As a **Lab Technician / Nurse (P2)**, when results come back from the analyzer I want to enter each result value against the reference range — and have abnormal results automatically flagged in red — so the doctor is notified immediately of critical values.

**Screen:** Labs → result entry  
**Personas:** P2 Lourdes  
**Phase:** 2  
**Module:** `api/v1/labs/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.labs.api.record_result
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `lab_test_id` | `string` | Yes |
| `results` | `object[]` | Yes | `[{ test_name, result_value, uom }]` |

**Response:**
```json
{
  "message": {
    "lab_test_id": "LT-0045",
    "status": "Completed",
    "has_abnormal": true,
    "abnormal_results": [
      { "test_name": "Hemoglobina", "value": "9.8", "uom": "g/dL", "range": "11.5–15.5", "flag": "LOW" }
    ],
    "practitioner_notified": true
  }
}
```

**DocType mapping:** `Normal Test Result` (child table of `Lab Test`)

---

## 7.5 — Mark Result Reviewed

> **User Story:** As **Dr. Miguel (P3)**, when I have reviewed an abnormal lab result and discussed it with the family I want to mark it as reviewed — so it disappears from my unreviewed list and is documented that I have seen it.

**Screen:** Patient 360 → Lab Center → result card → "Mark Reviewed"  
**Personas:** P3  
**Phase:** 2  
**Module:** `api/v1/labs/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.labs.api.mark_result_reviewed
```

Parameters: `lab_test_id`

---

---

# 8. Medications Master

---

## 8.1 — List Medications

> **User Story:** As **Dr. Miguel (P3)**, when I am prescribing I want to search the clinic's formulary by drug name or class and see standard dosages — so I prescribe from the approved list, not from memory.

**Screen:** Encounter screen → Prescription section → drug search  
**Personas:** P3 Dr. Miguel, P4 Carlos  
**Phase:** 2  
**Module:** `api/v1/medications/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.medications.api.list_medications
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `search` | `string` | No | `""` |
| `medication_class` | `string` | No | all |
| `page` | `integer` | No | 1 |
| `page_size` | `integer` | No | 20 |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "name": "MED-0012",
        "medication_name": "Amoxicilina",
        "generic_name": "Amoxicilina trihidrato",
        "medication_class": "Penicilinas",
        "dosage_forms": ["Suspensión 125mg/5ml", "Cápsula 500mg"],
        "standard_adult_dose": "500 mg cada 8 horas",
        "pediatric_dose_per_kg": "40 mg/kg/día dividido cada 8 horas",
        "max_dose_per_kg": "90 mg/kg/día",
        "contraindications": ["Alergia a penicilinas"]
      }
    ]
  }
}
```

**DocType mapping:** `Medication` + `Medication Class` + `Dosage Form` + `Dosage Strength`

---

---

# 9. Billing

---

## 9.1 — List Invoices

> **User Story:** As **Maria (P1, Receptionist)**, at the end of the day I want to see all invoices from today — paid and unpaid — sorted by amount due descending — so I can identify which patients still owe and call them before closing.

**Screen:** `/billing` — invoice list  
**Personas:** P1 Maria, P4 Carlos  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.list_invoices
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `date_from` | `string` | No | today |
| `date_to` | `string` | No | today |
| `status` | `string` | No | all | `"unpaid"` \| `"paid"` \| `"overdue"` \| `"all"` |
| `page` | `integer` | No | 1 |

---

## 9.2 — Get Invoice

> **User Story:** As **Maria (P1)**, when a patient questions their bill I want to pull up the full breakdown — every service, every charge, the IVA calculation — so I can explain it item by item and avoid disputes.

**Screen:** Billing → invoice row → detail view  
**Personas:** P1, P4  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.get_invoice
```

Parameters: `invoice_id`

---

## 9.3 — Record Payment

> **User Story:** As **Maria (P1)**, when a patient pays at the front desk I want to record the payment method (cash, card, transfer) and the amount — and have the system immediately mark the invoice as paid and send a WhatsApp receipt — so the patient leaves with proof of payment.

**Screen:** Dashboard → payment banner → "Collect Payment" dialog  
**Personas:** P1 Maria  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.record_payment
```

**Request parameters:**
| Parameter | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | `string` | Yes | |
| `amount_mxn` | `float` | Yes | Amount being paid |
| `payment_method` | `string` | Yes | `"Cash"` \| `"Card"` \| `"Transfer"` |
| `reference_number` | `string` | No | Card/transfer reference |

**Response:**
```json
{
  "message": {
    "payment_entry_id": "PE-0055",
    "invoice_status": "Paid",
    "receipt_sent_whatsapp": true,
    "change_mxn": 0
  }
}
```

**DocType mapping:** `Payment Entry` (ERPNext) — `insert()` + link to `Sales Invoice`

---

## 9.4 — Get AR Aging

> **User Story:** As **Carlos (P4, Clinic Admin)**, at the end of every week I want to see accounts receivable broken into aging buckets (0–7 days, 7–30 days, 30+ days) — so I can prioritise which patients to follow up with and avoid write-offs.

**Screen:** `/billing` → AR tab  
**Personas:** P4 Carlos, P5 Elena  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.get_ar_aging
```

Parameters: `location` (optional)

**Response:**
```json
{
  "message": {
    "buckets": {
      "current_0_7d": { "count": 12, "total_mxn": 7200 },
      "overdue_7_30d": { "count": 5, "total_mxn": 3800 },
      "overdue_30d_plus": { "count": 2, "total_mxn": 1400 }
    },
    "total_outstanding_mxn": 12400
  }
}
```

---

## 9.5 — Get Billing KPIs

> **User Story:** As **Carlos (P4)**, every morning I want to see yesterday's collections, this week's total, and the month-to-date revenue — so I know if the clinic is on track for its financial targets without opening a spreadsheet.

**Screen:** `/billing` → KPI strip  
**Personas:** P4, P5  
**Phase:** 3  
**Module:** `api/v1/billing/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.billing.api.get_billing_kpis
```

Parameters: `date_from`, `date_to`

---

---

# 10. Admin

---

## 10.1 — Get Admin Overview

> **User Story:** As **Elena (P5, Platform Admin)**, when I start my morning I want to see all three clinics side by side — patient volume, revenue, staff alerts, and outstanding AR for each — so I can identify which clinic needs my attention first without logging into each one separately.

**Screen:** `/admin` — multi-clinic overview  
**Personas:** P5 Elena, P4 Carlos  
**Phase:** 4  
**Module:** `api/v1/admin/api.py` *(new module — not in Phase 1)*

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.get_admin_overview
```

**Response:**
```json
{
  "message": {
    "clinics": [
      {
        "location": "Chavitos Clinic",
        "today_appointments": 28,
        "today_completed": 14,
        "today_revenue_mxn": 9100,
        "outstanding_mxn": 3200,
        "alerts": ["2 practitioners sick", "5 unconfirmed appointments"]
      }
    ]
  }
}
```

---

## 10.2 — List Staff

> **User Story:** As **Carlos (P4)**, when I need to see who is working at my clinic this month I want a clear list of all staff — name, role, status (active/inactive) — so I can identify gaps in coverage before they become a problem.

**Screen:** `/admin` → Staff tab  
**Personas:** P4, P5  
**Phase:** 4  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.list_staff
```

Parameters: `location`, `role_filter`, `status_filter`, `page`

**DocType mapping:** `User` + `User Role` + `Employee` (ERPNext)

---

## 10.3 — Invite Staff

> **User Story:** As **Carlos (P4)**, when I hire a new receptionist I want to send them an invitation email from within the system — assigning their role, clinic, and access level — so they can start working on day one without me needing to call IT.

**Screen:** `/admin` → Staff → "Invite" button  
**Personas:** P4, P5  
**Phase:** 4  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.invite_staff
```

Parameters: `email`, `role`, `location`, `first_name`, `last_name`

---

## 10.4 — Update User

> **User Story:** As **Carlos (P4)**, when a nurse changes branches or a front-desk worker is promoted to clinic admin I want to update their role and branch assignment without deleting and recreating their account — so they don't lose access history.

**Screen:** `/settings` → Users → edit pencil  
**Personas:** P4, P5  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_user
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Frappe User docname (email) |
| `role` | `string` | No | New Frappe role to assign |
| `branch` | `string` | No | Branch / location name |
| `enabled` | `int` | No | `1` = active, `0` = disabled |

**Implementation notes:**
- Remove the user's existing clinic role (Clinic Admin / Practitioner / Nurse / Frontdesk / Clinic Staff) and add the new one via `User Role` child table.
- All frontend users are `Website User` type — never set `user_type = "System User"`.
- `enabled = 0` → set `User.enabled = 0` (locks login without deleting the account).

**Response** (`set_response`):
```json
{
  "name": "ana@chavitos.health",
  "full_name": "Ana Méndez",
  "email": "ana@chavitos.health",
  "role": "Nurse",
  "branch": "Chavitos Clinic",
  "enabled": 1
}
```

---

## 10.5 — Create Service Unit

> **User Story:** As **Carlos (P4)**, when we open a new consultation room I want to add it as a service unit immediately so practitioners can start booking appointments there today — without waiting for IT.

**Screen:** `/settings` → Service Units → "Add Service Unit" popup  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_service_unit
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `service_unit_name` | `string` | Yes | Display name, e.g. "Consultation Room 1" |
| `service_unit_type` | `string` | No | e.g. "Consultation Room", "Lab", "Ward" |
| `allow_appointments` | `int` | No | `1` = yes (default `1`) |
| `company` | `string` | No | Link to Company — for multi-branch |

**Implementation notes:**
- Creates a `Healthcare Service Unit` DocType record with `is_group = 0`.
- `service_unit_type` is a link to `Healthcare Service Unit Type` — create that type if it doesn't exist, or validate the value exists first.
- All frontend users are Website Users — this method must be `@frappe.whitelist()` with explicit permission check: only `Clinic Admin` role may call it.

**Response** (`set_response`):
```json
{
  "name": "Consultation Room 1",
  "service_unit_name": "Consultation Room 1",
  "service_unit_type": "Consultation Room",
  "is_group": 0,
  "allow_appointments": 1
}
```

---

## 10.6 — Update Service Unit

> **User Story:** As **Carlos (P4)**, when a room changes its purpose (e.g. consultation → procedure) or we stop allowing appointments in it, I want to update that without deleting and recreating it — so appointment history is preserved.

**Screen:** `/settings` → Service Units → edit pencil  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_service_unit
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Frappe docname of the service unit |
| `service_unit_name` | `string` | No | Rename display label |
| `service_unit_type` | `string` | No | New type |
| `allow_appointments` | `int` | No | `1` or `0` |

**Response** (`set_response`): same shape as 10.5.

---

## 10.7 — Delete Service Unit

> **User Story:** As **Carlos (P4)**, when a service unit is permanently closed I want to remove it from the booking list so staff stop accidentally booking into it.

**Screen:** `/settings` → Service Units → delete button  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.delete_service_unit
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Frappe docname of the service unit |

**Implementation notes:**
- Prefer `allow_appointments = 0` (soft disable) if the unit has historical appointment records.
- Hard-delete only if the unit has zero linked appointments.
- Raise `frappe.ValidationError` if the unit is currently occupied (has a checked-in appointment today).

**Response** (`set_response`):
```json
{ "deleted": true, "name": "Consultation Room 1" }
```

---

## 10.8 — Create Company

> **User Story:** As **Carlos (P4)**, when we open a new clinic branch that has its own RFC/GST number I want to register it as a separate company in the system — so invoices, taxes, and accounting are correctly separated from day one.

**Screen:** `/settings` → Companies → "Add Company" popup  
**Personas:** P4, P5  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_company
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `company_name` | `string` | Yes | Legal entity name |
| `abbr` | `string` | Yes | Short code, max 10 chars, e.g. `CHAV` |
| `tax_id` | `string` | No | RFC / GSTIN |
| `country` | `string` | No | Default `"Mexico"` |
| `city` | `string` | No | |
| `phone_no` | `string` | No | |
| `email` | `string` | No | |
| `default_currency` | `string` | No | Default `"MXN"` |

**Implementation notes:**
- Creates a Frappe `Company` DocType record.
- `abbr` must be globally unique — validate before inserting and raise `frappe.ValidationError` with a clear message if it conflicts.
- Setting `default_currency` may require the currency to exist in the `Currency` DocType — validate.
- Only `Clinic Admin` role may call this.

**Response** (`set_response`):
```json
{
  "name": "Chavitos Clínica S.A. de C.V.",
  "company_name": "Chavitos Clínica S.A. de C.V.",
  "abbr": "CHAV",
  "country": "Mexico",
  "tax_id": "XAXX010101000",
  "city": "Mérida",
  "default_currency": "MXN"
}
```

---

## 10.9 — Update Company

> **User Story:** As **Carlos (P4)**, when a branch's phone number or RFC changes I want to update it in the system immediately — so invoices and contacts always have the correct legal details.

**Screen:** `/settings` → Companies → edit pencil  
**Personas:** P4, P5  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_company
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Frappe Company docname |
| `tax_id` | `string` | No | |
| `city` | `string` | No | |
| `phone_no` | `string` | No | |
| `email` | `string` | No | |
| `default_currency` | `string` | No | |

**Response** (`set_response`): same shape as 10.8.

---

## 10.10 — Departments (create / update / delete)

> **User Story:** As **Carlos (P4)**, I want to manage clinical departments so that practitioners and appointments can be assigned to the right specialty.

**Screen:** `/settings` → Departments  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

### 10.10.1 — create_department

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_department
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `department_name` | `string` | Yes | Display name |
| `parent_department` | `string` | No | Parent department name |

**Response** (`set_response`):
```json
{
  "name": "General Pediatrics",
  "department_name": "General Pediatrics",
  "is_group": 0,
  "disabled": 0,
  "parent_department": "Clinical"
}
```

### 10.10.2 — update_department

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_department
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Frappe Department docname |
| `department_name` | `string` | No | |
| `parent_department` | `string` | No | |

**Response** (`set_response`): same shape as create.

### 10.10.3 — delete_department

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.delete_department
```

**Request parameters:**

| Parameter | Type | Required |
|---|---|---|
| `name` | `string` | Yes |

**Response** (`set_response`): `{ "name": "<deleted-docname>" }`

---

## 10.11 — Appointment Types (create / update / delete)

> **User Story:** As **Carlos (P4)**, I want to create and edit appointment types so that front desk staff can book the right kind of visit.

**Screen:** `/settings` → Visit Types  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

> GET is already handled by `frappe.client.get_list` on `Appointment Type` — no custom method needed.

### 10.11.1 — create_appointment_type

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_appointment_type
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `name` | `string` | Yes | Appointment Type name (also the docname) |
| `default_duration` | `number` | No | Minutes, default 30 |
| `color` | `string` | No | Hex color string e.g. `#0098E4` |

**Response** (`set_response`):
```json
{ "name": "Consultation", "default_duration": 30, "color": "#0098E4" }
```

### 10.11.2 — update_appointment_type

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_appointment_type
```

**Request parameters:**

| Parameter | Type | Required |
|---|---|---|
| `name` | `string` | Yes |
| `default_duration` | `number` | No |
| `color` | `string` | No |

**Response** (`set_response`): same shape as create.

### 10.11.3 — delete_appointment_type

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.delete_appointment_type
```

**Request parameters:**

| Parameter | Type | Required |
|---|---|---|
| `name` | `string` | Yes |

**Response** (`set_response`): `{ "name": "<deleted-name>" }`

---

## 10.12 — Medications (create / update / delete)

> **User Story:** As **Carlos (P4)**, I want to maintain the clinic's drug formulary so that practitioners can prescribe from an approved medication list.

**Screen:** `/settings` → Medications  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

> GET is already handled by `frappe.client.get_list` on `Medication` — no custom method needed.

### 10.12.1 — create_medication

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_medication
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `item_name` | `string` | Yes | Display name |
| `dosage_form` | `string` | No | e.g. Tablet, Syrup, Injection |
| `strength` | `string` | No | e.g. 500 mg |
| `is_antibiotic` | `number` | No | 1 = yes, 0 = no |

**Response** (`set_response`):
```json
{
  "name": "Amoxicillin-001",
  "item_name": "Amoxicillin",
  "dosage_form": "Syrup",
  "strength": "250 mg/5 mL",
  "is_antibiotic": 1,
  "disabled": 0
}
```

### 10.12.2 — update_medication

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_medication
```

**Request parameters:** same as create plus required `name` (Frappe docname).

**Response** (`set_response`): same shape as create.

### 10.12.3 — delete_medication

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.delete_medication
```

**Request parameters:**

| Parameter | Type | Required |
|---|---|---|
| `name` | `string` | Yes |

**Response** (`set_response`): `{ "name": "<deleted-docname>" }`

---

## 10.13 — Insurance Providers (create / update / delete)

> **User Story:** As **Carlos (P4)**, I want to manage accepted insurance payers so that front desk can record correct coverage and copay at checkout.

**Screen:** `/settings` → Insurance  
**Personas:** P4  
**Phase:** 3 — 🔲 **Not built**  
**Module:** `api/v1/admin/api.py`

> GET is already handled by `frappe.client.get_list` on `Healthcare Insurance Company` — no custom method needed.

### 10.13.1 — create_insurance

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.create_insurance
```

**Request parameters:**

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `insurance_company_name` | `string` | Yes | Display name |
| `coverage_percentage` | `number` | No | 0–100 |
| `default_copay_amount` | `number` | No | MXN amount |
| `phone` | `string` | No | |

**Response** (`set_response`):
```json
{
  "name": "GNP-001",
  "insurance_company_name": "GNP Seguros",
  "coverage_percentage": 80,
  "default_copay_amount": 200,
  "phone": "+52 800 400 6900",
  "disabled": 0
}
```

### 10.13.2 — update_insurance

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.update_insurance
```

**Request parameters:** same as create plus required `name` (Frappe docname).

**Response** (`set_response`): same shape as create.

### 10.13.3 — delete_insurance

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.admin.api.delete_insurance
```

**Request parameters:**

| Parameter | Type | Required |
|---|---|---|
| `name` | `string` | Yes |

**Response** (`set_response`): `{ "name": "<deleted-docname>" }`

---

## Summary — Admin module build order

All methods live in `api/v1/admin/api.py` (new module). Build in this order:

| Priority | Method | Unblocks |
|---|---|---|
| 1 | `list_staff` | Settings → Users list populates |
| 2 | `invite_staff` | Admin can add new users |
| 3 | `update_user` | Admin can change roles / deactivate |
| 4 | `create_service_unit` | Settings → Service Units writes |
| 5 | `update_service_unit` | Edit service unit name/type |
| 6 | `delete_service_unit` | Remove unused service units |
| 7 | `create_company` | Settings → Companies writes |
| 8 | `update_company` | Edit company details |
| 9 | `create_department` / `update_department` / `delete_department` | Settings → Departments writes |
| 10 | `create_appointment_type` / `update_appointment_type` / `delete_appointment_type` | Settings → Visit Types writes |
| 11 | `create_medication` / `update_medication` / `delete_medication` | Settings → Medications writes |
| 12 | `create_insurance` / `update_insurance` / `delete_insurance` | Settings → Insurance writes |

**All methods must:**
- Be decorated `@frappe.whitelist()` — never `allow_guest=True`
- Gate on `Clinic Admin` role: `frappe.only_for("Clinic Admin")` or equivalent
- Use `set_response(data)` for single-record returns
- Use `set_list_response(data, pagination)` for list returns
- Raise `frappe.ValidationError` (not bare `Exception`) for business rule failures
- Never use `frappe.flags.ignore_permissions = True`

---

---

# 11. Inbox

---

## 11.1 — Get Work Items

> **User Story:** As **Dr. Miguel (P3)**, I want one single screen that shows everything waiting for my action today — lab results to review, prescriptions to renew, follow-ups overdue — sorted by urgency — so I never miss a time-sensitive clinical task.

> **User Story:** As **Maria (P1)**, I want my work inbox to show unconfirmed appointments, patients who haven't paid, and incoming messages — so I know exactly what to act on next without checking three separate screens.

**Screen:** `/inbox` — Work Inbox  
**Personas:** P1, P2, P3, P4 (role-filtered)  
**Phase:** 4  
**Module:** `api/v1/inbox/api.py` *(new module)*

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.inbox.api.get_work_items
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `role` | `string` | Yes | Frappe role or frontend RoleId |

**Response:**
```json
{
  "message": {
    "urgent": [
      {
        "type": "lab_result_abnormal",
        "title": "CBC abnormal — Hgb 9.8 g/dL",
        "patient_name": "Sofia Castillo",
        "ref_id": "LT-0044",
        "action_label": "Review result",
        "href": "/labs/LT-0044"
      }
    ],
    "normal": [
      {
        "type": "appointment_unconfirmed",
        "title": "5 appointments unconfirmed for tomorrow",
        "action_label": "Send reminders",
        "href": "/appointments"
      }
    ]
  }
}
```

**DocType mapping:** Aggregation across `Patient Appointment`, `Lab Test`, `Sales Invoice`, `Nursing Task` — filtered and prioritised by role.

---

---

# 12. Notifications

---

## 12.1 — List Notifications

> **User Story:** As **any staff member**, I want to see a notification bell badge that tells me something needs my attention — and when I click it, I want to see a concise list of recent alerts — so I stay informed without being distracted by constant pop-ups.

**Screen:** App Header → Notification bell  
**Personas:** P1, P2, P3, P4  
**Phase:** 4  
**Module:** `api/v1/notifications/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.notifications.api.list_notifications
```

**DocType mapping:** Frappe `Notification Log` (standard ✅) filtered by `for_user = current_user`

---

## 12.2 — Mark Notifications Read

**Screen:** Notification panel → "Mark all read"  
**Phase:** 4  
**Module:** `api/v1/notifications/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.notifications.api.mark_notifications_read
```

Parameters: `notification_ids[]` or `mark_all: true`

---

---

# 13. Providers

---

## 13.1 — List Providers

> **User Story:** As **Maria (P1)**, when I am booking an appointment and the patient says "I want the paediatric surgeon", I want to see all providers filtered by department and see which ones are available that day — so I book the right doctor the first time.

**Screen:** Appointments → provider picker, `/providers` directory  
**Personas:** P1, P4  
**Phase:** 1 — ✅ **Built** (`get_providers`, `get_service_units`)  
**Module:** `api/v1/providers/api.py`

> **Missing frontend route:** `GET /api/providers` BFF route does not exist — `useProviders` hook will 404. Add `Healthcare_next_app/src/app/api/providers/route.ts`.  
> **Also built (not in spec):** `get_service_units(company?)` — returns service units for appointment location picker. Frontend currently calls `frappe.client.get_list` directly for service units and practitioners — **this violates Rule: all data access through `api/v1/*`**. The backend methods exist; the frontend route handlers need to be updated to call them.

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.providers.api.list_providers
```

**Request parameters:**
| Parameter | Type | Required | Default |
|---|---|---|---|
| `department` | `string` | No | all |
| `location` | `string` | No | all |
| `available_on` | `string` | No | — | YYYY-MM-DD — filters by schedule |

**Response:**
```json
{
  "message": {
    "data": [
      {
        "name": "HP-0001",
        "practitioner_name": "Dr. Miguel Soto",
        "department": "Pediatric Surgery",
        "specialization": "Cirugía Pediátrica",
        "location": "Chavitos Clinic",
        "avatar": "/files/dr-miguel.jpg",
        "consultation_fee_mxn": 650,
        "available_today": true
      }
    ]
  }
}
```

**DocType mapping:** `Healthcare Practitioner` + `Medical Department` + `Practitioner Schedule`

---

## 13.2 — Get Provider

> **User Story:** As **Carlos (P4)**, when I onboard a new patient who asks "who specialises in cardiology at this clinic?", I want to pull up the full provider profile — specialisations, schedule, consultation fees — so I can give the patient accurate information.

**Screen:** `/providers/[id]` — provider profile  
**Personas:** P1, P4  
**Phase:** 1 — ✅ **Built** (`get_provider_detail`)  
**Module:** `api/v1/providers/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.providers.api.get_provider
```

Parameters: `provider_id`

---

---

# 14. Reports

---

## 14.1 — Operations Report

> **User Story:** As **Carlos (P4)**, every Monday I want to see last week's no-show rate, average wait time, and total patient volume — so I can identify trends and make staffing decisions before the next week starts.

**Screen:** `/reports` → Operations  
**Personas:** P4, P5  
**Phase:** 4  
**Module:** `api/v1/reports/api.py` *(new module)*

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.reports.api.get_operations_report
```

**Request parameters:**
| Parameter | Type | Required |
|---|---|---|
| `date_from` | `string` | Yes |
| `date_to` | `string` | Yes |
| `location` | `string` | No |

**Response:**
```json
{
  "message": {
    "total_appointments": 186,
    "completed": 164,
    "no_shows": 12,
    "cancellations": 10,
    "no_show_rate_pct": 6.5,
    "avg_wait_minutes": 18,
    "busiest_day": "Miércoles",
    "busiest_hour": "09:00–10:00"
  }
}
```

**DocType mapping:** `Patient Appointment` — aggregation queries

---

## 14.2 — Revenue Report

> **User Story:** As **Elena (P5)**, at end of month I want to see total collections, total outstanding, and revenue breakdown by clinic, practitioner, and service type — so I can report to the board and identify where revenue is leaking.

**Screen:** `/reports` → Revenue  
**Personas:** P4, P5  
**Phase:** 4  
**Module:** `api/v1/reports/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.reports.api.get_revenue_report
```

**DocType mapping:** `Sales Invoice` + `Payment Entry` (ERPNext) — aggregations

---

## 14.3 — Clinical Report

> **User Story:** As **Dr. Miguel (P3)**, at the end of the quarter I want to see which diagnoses I made most frequently and what the outcomes were — so I can identify whether certain conditions are being managed well at our clinic or need a protocol review.

**Screen:** `/reports` → Clinical  
**Personas:** P3, P4  
**Phase:** 4  
**Module:** `api/v1/reports/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.reports.api.get_clinical_report
```

**DocType mapping:** `Patient Encounter Diagnosis` + `Lab Test` — aggregations

---

## 14.4 — Patient Demographics

> **User Story:** As **Carlos (P4)**, I want to see the age and sex distribution of our patient population — so I can plan which specialties to add based on who is actually coming to our clinic.

**Screen:** `/reports` → Demographics  
**Personas:** P4, P5  
**Phase:** 4  
**Module:** `api/v1/reports/api.py`

**Method:**
```
POST /api/method/remedisys_healthcare_ai.api.v1.reports.api.get_patient_demographics
```

---

---

# 15. Custom Doctypes

---

## 15.1 — Patient Referral *(new — not in Healthcare app)*

**Why it is needed:** The Patient 360 Referrals tab shows referrals created by doctors. ERPNext Healthcare does not have a dedicated `Patient Referral` doctype. The closest available is `Service Request` (FHIR-based) but it does not have the UX fields needed (referring doctor, referred-to doctor, reason, urgency, follow-up date, internal vs external).

**Proposed doctype:** `Patient Referral`  
**App:** `remedisys_healthcare_ai`  
**Module:** `Remedisys Healthcare AI`

| Field | Type | Required | Description |
|---|---|---|---|
| `patient` | Link → Patient | Yes | |
| `referring_practitioner` | Link → Healthcare Practitioner | Yes | Auto-set from logged-in user |
| `referred_to_practitioner` | Link → Healthcare Practitioner | No | For internal referrals |
| `department` | Link → Medical Department | Yes | |
| `referral_type` | Select: Internal / External | Yes | |
| `reason` | Small Text | Yes | Clinical reason |
| `urgency` | Select: Routine / Urgent / Emergency | Yes | |
| `status` | Select: Pending / Accepted / Completed / Cancelled | Yes | Default: Pending |
| `notes` | Text | No | |
| `encounter` | Link → Patient Encounter | No | Encounter that generated the referral |
| `referral_date` | Date | Yes | Auto-set on creation |
| `follow_up_date` | Date | No | Expected response date |

**Permissions:**
| Role | Read | Write | Create |
|---|---|---|---|
| Practitioner | ✅ own | ✅ own | ✅ |
| System Manager | ✅ all | ✅ all | ✅ |
| Nurse | ✅ read | ❌ | ❌ |
| Healthcare Receptionist | ✅ read | ❌ | ❌ |

**APIs backed by this doctype:** Section 4.12 (list_referrals, create_referral)

---

## 15.2 — Immunization Verification *(pending)*

**Status:** ⚠️ Needs verification on `marley.local` before deciding.

The Healthcare app doctype list does not show dedicated immunization doctypes (e.g. `Immunization Record`, `Immunization Schedule`). On `marley.local`, we need to verify:

1. Is `Nursing Task` being used for immunization tracking?
2. Is `Clinical Procedure` being used for vaccination procedures?
3. Does the installed Healthcare version have immunization support not visible in the file listing?

**Decision point:** If no immunization doctype exists, we will either:
- **Option A:** Use `Nursing Task` with task type = Immunization (no new doctype)
- **Option B:** Create `Patient Immunization` doctype in `remedisys_healthcare_ai`

**This decision must be made before Phase 2 begins.**

---

---

## API Count Summary

> Last updated: 2026-06-10. Verified against actual backend file line counts and frontend contract audit.

| Domain | Spec Methods | Phase | Backend Status | Frontend BFF Status |
|---|---|---|---|---|
| Auth (eb_frappe_jwt) | 5 | 0 | ✅ Built (ADR-011) | ✅ Routes exist |
| Auth (get_current_user) | 1 | 0 | ✅ Built | ✅ `/api/auth/me` |
| Dashboard | 1 | 1 | 🔲 Not built (0 bytes) | ⚠️ Uses appointments list as workaround |
| Patients — core (list, get, create) | 3 | 1 | ✅ Built (1411 lines) | ✅ `/api/patients` |
| Patients — update | 1 | 1 | 🔲 Not built | 🔲 No route |
| Patient 360 — overview, timeline | 2 | 1 | 🔲 Not built | 🔲 No route |
| Patient 360 — vitals (list + record) | 2 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — encounters (patient view) | 1 | 1 | 🔲 Not built | 🔲 No route |
| Patient 360 — prescriptions | 1 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — immunizations | 1 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — medical history | 1 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — documents (list, upload, delete) | 3 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — appointments (patient view) | 1 | 1 | 🔲 Not built | 🔲 No route |
| Patient 360 — tasks (list, create, complete) | 3 | 2 | 🔲 Not built | 🔲 No route |
| Patient 360 — referrals (list, create) | 2 | 2 | 🔲 Not built (needs custom doctype) | 🔲 No route |
| Patient 360 — billing (patient view) | 1 | 3 | 🔲 Not built | 🔲 No route |
| Patient 360 — insurance policies | 1 | 3 | 🔲 Not built | 🔲 No route |
| Patient 360 — messages (list, send) | 2 | 2 | 🔲 Not built (messaging app undecided — D1) | 🔲 No route |
| Appointments — get_available_slots | 1 | 1 | ✅ Built | ✅ `/api/appointments/slots` |
| Appointments — book_appointment | 1 | 1 | ✅ Built | ✅ `/api/appointments` POST |
| Appointments — check_in_patient | 1 | 1 | ✅ Built | ✅ `/api/appointments` |
| Appointments — cancel_appointment | 1 | 1 | ✅ Built | ✅ `/api/appointments` |
| Appointments — update_status | 1 | 1 | ✅ Built | ❌ PATCH handler missing in BFF |
| Appointments — list_appointments + get | 2 | 1 | ✅ Built | ✅ `/api/appointments` GET |
| Appointments — reschedule | 1 | 1 | 🔲 Not built | 🔲 No route |
| Appointments — list_patient_appointments | 1 | 1 | 🔲 Not built | 🔲 No route |
| Encounters — create, get, save_draft, complete | 4 | 1 | 🔲 **Not built (0 bytes — critical gap)** | ⚠️ Routes exist, calls will 404 |
| Labs — order, list, collect, record, reviewed | 5 | 2 | 🔲 Not built (0 bytes) | ❌ No BFF route |
| Medications — list | 1 | 2 | 🔲 Not built | 🔲 No route |
| Billing — list_invoices, get, record_payment, ar_aging, kpis | 5 | 3 | 🔲 Not built (0 bytes) | ❌ No BFF route |
| Providers — list, get | 2 | 1 | ✅ Built (get_providers, get_provider_detail) | ❌ `/api/providers` route missing |
| Providers — get_service_units | 1 | 1 | ✅ Built | ⚠️ FE calls frappe.client.get_list directly (violation) |
| Providers — get_appointment_types | 1 | 1 | 🔲 Not built | ⚠️ FE calls frappe.client.get_list directly (violation) |
| Admin — overview, list_staff, invite | 3 | 4 | 🔲 Not built | 🔲 No route |
| Inbox — get_work_items | 1 | 4 | 🔲 Not built | 🔲 No route |
| Notifications — list, counts, mark_read, mark_all_read | 4 | 4 | ✅ Built | ✅ `/api/notifications` |
| Notifications — live stream (SSE) | 1 | 1 | ✅ Built | ✅ `/api/notifications/stream` |
| Patient portal — own notification feed | 4 | 4 | ✅ Built | ✅ `/api/notifications` (portal app) |
| Push — register/unregister device | 2 | 2 | ✅ Built | ✅ `/api/push` (portal app) |
| Reports — operations, revenue, clinical, demographics | 4 | 4 | 🔲 Not built | 🔲 No route |
| **Total** | **~70** | — | **~18 built, ~52 to build** | |

### Build Priority (Phase 1 remaining)

| Priority | Method | Backend | Frontend BFF |
|---|---|---|---|
| 🔴 P0 | `encounters` — all 4 methods | Build `encounters/api.py` | Routes exist — wire up |
| 🔴 P0 | `dashboard.get_dashboard_data` | Build `dashboard/api.py` | Wire up |
| 🟠 P1 | `appointments.update_status` PATCH | Already built | Add PATCH handler to `/api/appointments/route.ts` |
| 🟠 P1 | `providers` BFF route | Already built | Add `/api/providers/route.ts` |
| 🟠 P1 | `providers.get_appointment_types` | Build in `providers/api.py` | Fix `/api/healthcare/appointment-types/route.ts` to call our method |
| 🟠 P1 | Fix `frappe.client.get_list` violations | — | Update `/api/healthcare/service-units` + `/api/healthcare/practitioners` to call our methods |
| 🟡 P2 | `patients.update_patient` | Build in `patients/api.py` | Add to `/api/patients` |
| 🟡 P2 | `patients.get_patient_overview` + timeline | Build in `patients/api.py` | Add routes |
| 🟡 P2 | `appointments.list_patient_appointments` | Build in `appointments/api.py` | Add route |

---

## Open Decisions (Blocking)

| # | Decision | Impact | Owner | Status |
|---|---|---|---|---|
| D1 | **Messaging app** — Raven or clefincode_chat for Messages tab? | Patient 360 Messages API (§4.15) | Product | 🔲 Open |
| D2 | **Immunization doctype** — verify `Nursing Task` coverage on `remedisys.localhost` before Phase 2 | Immunization API (§4.7) | Backend lead | 🔲 Open |
| D3 | **Patient Referral** — approve creating `Patient Referral` custom doctype? | Referrals API (§4.12) | Backend lead | 🔲 Open |
| D4 | **Multi-role login** — Practitioner + Admin → which dashboard? Priority: Admin > Practitioner > Nurse > Front Desk > Patient | Auth middleware | Product | 🔲 Open |
| D5 | **Billing depth** — Phase 1: read-only invoice view only, or full payment collection? | Billing APIs (§9) | Product | 🔲 Open |
| D6 | **Contract ratification** — `list_patients` vs `get_patients`, `book_appointment` vs `create_appointment` etc. Two naming conventions coexist in the frontend (`lib/api/*` dead modules vs live BFF routes). **Ratify live BFF names** and delete dead `lib/api/*` modules. | All integration work | Both leads | 🔴 Must fix before Phase 1 integration |
| D7 | **`frappe.client.get_list` violations** — Frontend `/api/healthcare/service-units`, `/api/healthcare/practitioners`, `/api/healthcare/appointment-types` call Frappe built-ins directly, bypassing our permission layer. Backend methods exist for service-units and practitioners. Need `get_appointment_types` built. Frontend routes need updating. | Security + Rule compliance | Both leads | 🔴 Must fix |
| D8 | **`?id=` single-fetch broken** — `/api/appointments` and `/api/encounters` BFF route handlers ignore the `id` param and return the full list. `useAppointment(id)` / `useEncounter(id)` return a list, not a record. | Patient chart, encounter screen | Frontend | 🔴 Must fix |
| D9 | ~~**Role name mismatch**~~ — **Resolved.** `deriveFrontendRole` in `src/lib/auth/roles.ts:7` correctly maps Frappe role `"Practitioner"` → frontend `"practitioner"`. No mismatch exists. | — | — | ✅ Closed |

---

<!-- BEGIN GENERATED: endpoint index -->

# 16. Complete endpoint index (generated)

> **Superseded 2026-09-25.** This section was generated once, by hand, and never re-run; the
> table below is a snapshot of `dev` @ `6744129` (2026-08-19) and is kept only as a record.
> The current, regenerable index is [`ENDPOINT_INDEX.md`](ENDPOINT_INDEX.md) with one small
> table per module under [`endpoints/`](endpoints/README.md), produced by
> `scripts/gen_endpoint_index.py` and gated in CI with `--check`. Read those, not this.

> Every whitelisted method in `remedisys_healthcare_ai` — **485 endpoints**
> across 60 modules — with parameters, permission gate, frontend caller and Bruno
> coverage. Sections 1–15 above are the hand-written contract with request/response
> examples (they cover 59 of these methods in depth); this section is the
> exhaustive index, generated from source so it cannot drift silently.
>
> **Generated — do not hand-edit this section.** Everything between the
> `BEGIN/END GENERATED` markers is rewritten by the extractor. To change a
> description, change the method's docstring.

**Last generated:** 2026-08-19 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
**Generated from:** backend `dev` @ `6744129` · frontend `dev` @ `9f82b1b` ·
Bruno collection 232 requests · both patient-portal repos.

### Reading the tables

| Mark | Meaning |
|---|---|
| 🖥 | called by a frontend (BFF route shown) |
| 🧪 | has a Bruno request |
| 📘 | documented with examples in §1–15 |
| 🌐 | `allow_guest=True` — reachable without auth |
| `param?` | optional (has a default) |

The **Gate** column shows the `require_permission("<DocType>", "<ptype>")` call
found in the method body (278 of 485 have one). A blank Gate is not proof a
method is unguarded — it may delegate to a service — but it is where to look first.

### Coverage at a glance

| Module | Methods | 🖥 wired | 🧪 tested | 📘 spec'd |
|---|---|---|---|---|
| `api.v1.admin.catalog` | 73 | 54 | 10 | 9 |
| `api.v1.admin.demo_data` | 2 | 0 | 0 | 0 |
| `api.v1.admin.holiday_lists` | 5 | 1 | 0 | 0 |
| `api.v1.admin.lab_test_uoms` | 4 | 2 | 0 | 0 |
| `api.v1.admin.lab_unit_conversions` | 4 | 0 | 0 | 0 |
| `api.v1.admin.permissions` | 2 | 2 | 2 | 0 |
| `api.v1.admin.practitioners` | 11 | 5 | 5 | 0 |
| `api.v1.admin.settings` | 10 | 9 | 6 | 3 |
| `api.v1.admin.staff` | 4 | 4 | 3 | 3 |
| `api.v1.ai.api` | 18 | 17 | 0 | 0 |
| `api.v1.appointments.api` | 15 | 12 | 9 | 10 |
| `api.v1.appointments.report` | 4 | 4 | 0 | 0 |
| `api.v1.auth.api` | 5 | 5 | 4 | 1 |
| `api.v1.billing.api` | 21 | 19 | 6 | 1 |
| `api.v1.billing.report` | 3 | 3 | 0 | 0 |
| `api.v1.clinical.api` | 8 | 4 | 8 | 0 |
| `api.v1.clinical.report` | 1 | 1 | 0 | 0 |
| `api.v1.clinical_documents.api` | 8 | 8 | 0 | 2 |
| `api.v1.company.api` | 7 | 6 | 7 | 2 |
| `api.v1.dashboard.api` | 2 | 1 | 2 | 1 |
| `api.v1.dashboard.report` | 2 | 2 | 0 | 0 |
| `api.v1.documents.api` | 5 | 4 | 5 | 3 |
| `api.v1.encounters.api` | 22 | 21 | 7 | 5 |
| `api.v1.encounters.pdf` | 1 | 1 | 0 | 0 |
| `api.v1.encounters.report` | 3 | 3 | 0 | 0 |
| `api.v1.immunizations.api` | 22 | 18 | 22 | 0 |
| `api.v1.immunizations.report` | 1 | 1 | 0 | 0 |
| `api.v1.inbox.api` | 3 | 0 | 0 | 0 |
| `api.v1.insurance.api` | 4 | 4 | 4 | 0 |
| `api.v1.insurance.report` | 1 | 1 | 0 | 0 |
| `api.v1.labs.api` | 12 | 10 | 4 | 1 |
| `api.v1.messages.api` | 6 | 6 | 0 | 2 |
| `api.v1.narzim_assistant.api` | 5 | 4 | 0 | 1 |
| `api.v1.notes.api` | 9 | 8 | 5 | 0 |
| `api.v1.notifications.api` | 17 | 17 | 4 | 2 |
| `api.v1.nursing.api` | 14 | 8 | 12 | 2 |
| `api.v1.patient_portal.api` | 28 | 12 | 0 | 1 |
| `api.v1.patient_portal.chat` | 4 | 0 | 0 | 0 |
| `api.v1.patient_portal.portal_chat` | 4 | 4 | 0 | 0 |
| `api.v1.patients.api` | 17 | 14 | 11 | 5 |
| `api.v1.prescriptions.api` | 3 | 2 | 2 | 1 |
| `api.v1.procedures.api` | 12 | 3 | 10 | 0 |
| `api.v1.providers.api` | 7 | 5 | 4 | 4 |
| `api.v1.providers.report` | 2 | 2 | 0 | 0 |
| `api.v1.tasks.api` | 18 | 11 | 11 | 0 |
| `api.v1.vital_signs.api` | 6 | 5 | 5 | 0 |
| `api.ai.auth` | 1 | 0 | 0 | 0 |
| `api.ai.imaging_extraction` | 3 | 3 | 0 | 0 |
| `api.ai.lab_extraction` | 3 | 3 | 0 | 0 |
| `api.ai.lab_panel_extraction` | 11 | 11 | 0 | 0 |
| `api.ai.lab_result_summary` | 11 | 10 | 0 | 0 |
| `api.ai.patient_clinical_summary` | 2 | 2 | 0 | 0 |
| `api.ai.segments` | 2 | 2 | 0 | 0 |
| `api.ai.sessions` | 6 | 5 | 0 | 0 |
| `integrations.whatsapp.chat_api` | 6 | 0 | 0 | 0 |
| `integrations.whatsapp.notifications` | 1 | 0 | 0 | 0 |
| `integrations.whatsapp.webhook` | 1 | 0 | 0 | 0 |
| `overrides.pos_price_fix` | 1 | 0 | 0 | 0 |
| `overrides.sales_invoice_mixin` | 1 | 0 | 0 | 0 |
| `utils` | 1 | 0 | 0 | 0 |

---

## Endpoints by module

### `api.v1.admin.catalog`

`remedisys_healthcare_ai/api/v1/admin/catalog.py` — 73 endpoints

> Clinic catalog — appointment types, medications, insurance payors.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_appointment_type`**<br><sub>99</sub> | `name?`, `default_duration?`, `color?`, `allow_booking_for?`, `op_consulting_charge_item?`, `op_consulting_charge?` | Appointment Type · create | 🖥 `/api/healthcare/appointment-types` 🧪 📘 | Create an Appointment Type. |
| **`create_brand`**<br><sub>2150</sub> | `brand?`, `description?` | Brand · create | 🖥 `/api/admin/brands` | _no docstring_ |
| **`create_clinical_procedure_template`**<br><sub>1497</sub> | `template?`, `rate?`, `is_billable?`, `item_group?`, `description?`, `medical_department?`, `consume_stock?` | Clinical Procedure Template · create | — | _no docstring_ |
| **`create_complaint`**<br><sub>2850</sub> | `complaints?` | Complaint · create | 🖥 `/api/admin/symptoms` | _no docstring_ |
| **`create_diagnosis`**<br><sub>2967</sub> | `diagnosis?` | Diagnosis · create | 🖥 `/api/admin/diagnosis` | _no docstring_ |
| **`create_dosage_form`**<br><sub>2372</sub> | `dosage_form?` | Dosage Form · create | 🖥 `/api/admin/dosage-forms` | _no docstring_ |
| **`create_insurance`**<br><sub>890</sub> | `insurance_payor_name?`, `insurance_claim_credit_days?`, `website?`, `disabled?` | Insurance Payor · create | 🧪 📘 | _no docstring_ |
| **`create_item`**<br><sub>1908</sub> | `item_name?`, `item_group?`, `stock_uom?`, `item_type?`, `item_code?`, `description?`, `rate?`, `disabled?` … +1 more | Item · create | 🖥 `/api/admin/items` | _no docstring_ |
| **`create_item_tax_template`**<br><sub>1821</sub> | `title?`, `tax_rate?`, `company?` | Item · create | 🖥 `/api/admin/item-tax-templates` | Create a new Item Tax Template from the Add/Edit Item form's inline "create new" affordance. |
| **`create_lab_test_template`**<br><sub>1114</sub> | `lab_test_name?`, `department?`, `lab_test_group?`, `lab_test_template_type?`, `is_billable?`, `lab_test_rate?`, `lab_test_uom?`, `lab_test_normal_range?` … +8 more | Lab Test Template · create | — | _no docstring_ |
| **`create_manufacturer`**<br><sub>2206</sub> | `short_name?`, `full_name?` | Manufacturer · create | 🖥 `/api/admin/manufacturers` | _no docstring_ |
| **`create_medication`**<br><sub>554</sub> | `item_name?`, `dosage_form?`, `strength?`, `strength_uom?`, `medication_class?`, `default_prescription_dosage?`, `default_prescription_duration?`, `default_interval?` … +5 more | Medication · create | 🧪 📘 | _no docstring_ |
| **`create_medication_class`**<br><sub>2485</sub> | `medication_class?` | Medication Class · create | 🖥 `/api/admin/medication-classes` | _no docstring_ |
| **`create_payment_method`**<br><sub>3106</sub> | `mode_of_payment?`, `type?`, `enabled?` | Mode of Payment · create | 🖥 `/api/admin/payment-methods` | _no docstring_ |
| **`create_prescription_dosage`**<br><sub>2597</sub> | `dosage?` | Prescription Dosage · create | 🖥 `/api/admin/prescription-dosages` | _no docstring_ |
| **`create_prescription_duration`**<br><sub>2720</sub> | `number?`, `period?` | Prescription Duration · create | 🖥 `/api/admin/prescription-durations` | _no docstring_ |
| **`create_therapy_type`**<br><sub>1343</sub> | `therapy_type?`, `rate?`, `is_billable?`, `item_group?`, `description?`, `medical_department?`, `default_duration?` | Therapy Type · create | — | _no docstring_ |
| **`create_treatment_plan_template`**<br><sub>3430</sub> | `template_name?`, `medical_department?`, `description?`, `goal?`, `gender?`, `patient_age_from?`, `patient_age_to?`, `items?` … +2 more | Treatment Plan Template · create | 🖥 `/api/admin/treatment-plans` | _no docstring_ |
| **`delete_appointment_type`**<br><sub>227</sub> | `name?` | Appointment Type · delete | 🖥 `/api/healthcare/appointment-types` 🧪 📘 | _no docstring_ |
| **`delete_clinical_procedure_template`**<br><sub>1599</sub> | `name?` | Clinical Procedure Template · delete | — | _no docstring_ |
| **`delete_complaint`**<br><sub>2906</sub> | `name?` | Complaint · delete | 🖥 `/api/admin/symptoms` | _no docstring_ |
| **`delete_diagnosis`**<br><sub>3023</sub> | `name?` | Diagnosis · delete | 🖥 `/api/admin/diagnosis` | _no docstring_ |
| **`delete_dosage_form`**<br><sub>2428</sub> | `name?` | Dosage Form · delete | 🖥 `/api/admin/dosage-forms` | _no docstring_ |
| **`delete_insurance`**<br><sub>958</sub> | `name?` | Insurance Payor · delete | 🧪 📘 | _no docstring_ |
| **`delete_item`**<br><sub>2078</sub> | `name?` | Item · delete | 🖥 `/api/admin/items` | _no docstring_ |
| **`delete_lab_test_template`**<br><sub>1295</sub> | `name?` | Lab Test Template · delete | — | _no docstring_ |
| **`delete_manufacturer`**<br><sub>2329</sub> | `name?` | Manufacturer · delete | 🖥 `/api/admin/manufacturers` | _no docstring_ |
| **`delete_medication`**<br><sub>771</sub> | `name?` | Medication · delete | 🧪 📘 | _no docstring_ |
| **`delete_medication_class`**<br><sub>2539</sub> | `name?` | Medication Class · delete | 🖥 `/api/admin/medication-classes` | _no docstring_ |
| **`delete_payment_method`**<br><sub>3177</sub> | `name?` | Mode of Payment · delete | 🖥 `/api/admin/payment-methods` | _no docstring_ |
| **`delete_prescription_dosage`**<br><sub>2651</sub> | `name?` | Prescription Dosage · delete | 🖥 `/api/admin/prescription-dosages` | _no docstring_ |
| **`delete_prescription_duration`**<br><sub>2790</sub> | `name?` | Prescription Duration · delete | 🖥 `/api/admin/prescription-durations` | _no docstring_ |
| **`delete_therapy_type`**<br><sub>1449</sub> | `name?` | Therapy Type · delete | — | _no docstring_ |
| **`delete_treatment_plan_template`**<br><sub>3528</sub> | `name?` | Treatment Plan Template · delete | 🖥 `/api/admin/treatment-plans` | _no docstring_ |
| **`get_brand`**<br><sub>2234</sub> | `name?` | Brand · read | — | _no docstring_ |
| **`get_lab_test_template`**<br><sub>1101</sub> | `name?` | Lab Test Template · read | 🖥 `/api/admin/lab-tests/[name]` | Return a single Lab Test Template with its result-structure child tables. |
| **`get_manufacturer`**<br><sub>2285</sub> | `name?` | Manufacturer · read | — | _no docstring_ |
| **`get_medication`**<br><sub>538</sub> | `name?` | Medication · read | 🖥 `/api/admin/medications/[name]` | Return a single Medication with its child tables (combinations, items). |
| **`get_treatment_plan_template`**<br><sub>3395</sub> | `name?` | Treatment Plan Template · read | 🖥 `/api/admin/treatment-plans/[name]` | Return a single Treatment Plan Template with its items and drugs. |
| **`list_appointment_types`**<br><sub>54</sub> | — | Appointment Type · read | 🖥 `/api/healthcare/appointment-types` 🧪 | Return all Appointment Types ordered by name, with billing item if set. |
| **`list_brands`**<br><sub>2123</sub> | `query?`, `limit?` | Brand · read | 🖥 `/api/admin/brands` | Search the Brand master for the Medication linked-item editor's picker. |
| **`list_clinical_procedure_templates`**<br><sub>1483</sub> | — | Clinical Procedure Template · read | — | _no docstring_ |
| **`list_complaints`**<br><sub>2834</sub> | — | Complaint · read | 🖥 `/api/admin/symptoms` | _no docstring_ |
| **`list_diagnosis`**<br><sub>2951</sub> | — | Diagnosis · read | 🖥 `/api/admin/diagnosis` | _no docstring_ |
| **`list_dosage_forms`**<br><sub>2356</sub> | — | Dosage Form · read | 🖥 `/api/admin/dosage-forms` | _no docstring_ |
| **`list_genders`**<br><sub>3211</sub> | — | Gender · read | 🖥 `/api/admin/genders` | Return Gender master values (read-only) for metadata pickers. |
| **`list_item_tax_templates`**<br><sub>1780</sub> | — | Item · read | 🖥 `/api/admin/item-tax-templates` | List Item Tax Templates for the Add/Edit Item tax-template picker. |
| **`list_items`**<br><sub>1745</sub> | — | Item · read | 🖥 `/api/admin/items` | Return sellable Items for the Clinical Setup -> Items section. |
| **`list_manufacturers`**<br><sub>2179</sub> | `query?`, `limit?` | Manufacturer · read | 🖥 `/api/admin/manufacturers` | Search the Manufacturer master for the Medication linked-item editor's picker. |
| **`list_medication_classes`**<br><sub>2469</sub> | — | Medication Class · read | 🖥 `/api/admin/medication-classes` | _no docstring_ |
| **`list_payment_methods`**<br><sub>3085</sub> | — | Mode of Payment · read | 🖥 `/api/admin/payment-methods` | _no docstring_ |
| **`list_prescription_dosages`**<br><sub>2581</sub> | — | Prescription Dosage · read | 🖥 `/api/admin/prescription-dosages` | _no docstring_ |
| **`list_prescription_durations`**<br><sub>2707</sub> | — | Prescription Duration · read | 🖥 `/api/admin/prescription-durations` | _no docstring_ |
| **`list_therapy_types`**<br><sub>1329</sub> | — | Therapy Type · read | — | _no docstring_ |
| **`list_treatment_plan_templates`**<br><sub>3366</sub> | — | Treatment Plan Template · read | 🖥 `/api/admin/treatment-plans` | Return Treatment Plan Templates (metadata only; child tables omitted). |
| **`search_items`**<br><sub>789</sub> | `query?`, `item_group?`, `limit?` | Item · read | 🖥 `/api/items/search` | Search the Item master for the in-house pharmacy linked-item picker. |
| **`update_appointment_type`**<br><sub>166</sub> | `name?`, `default_duration?`, `color?`, `allow_booking_for?`, `op_consulting_charge_item?`, `op_consulting_charge?` | Appointment Type · write | 🖥 `/api/healthcare/appointment-types` 🧪 📘 | _no docstring_ |
| **`update_brand`**<br><sub>2247</sub> | `name?`, `brand?`, `description?` | Brand · write | 🖥 `/api/admin/brands` | _no docstring_ |
| **`update_clinical_procedure_template`**<br><sub>1543</sub> | `name?`, `template?`, `rate?`, `is_billable?`, `item_group?`, `description?`, `medical_department?`, `consume_stock?` … +1 more | Clinical Procedure Template · write | — | _no docstring_ |
| **`update_complaint`**<br><sub>2878</sub> | `name?`, `complaints?` | Complaint · write | 🖥 `/api/admin/symptoms` | _no docstring_ |
| **`update_diagnosis`**<br><sub>2995</sub> | `name?`, `diagnosis?` | Diagnosis · write | 🖥 `/api/admin/diagnosis` | _no docstring_ |
| **`update_dosage_form`**<br><sub>2400</sub> | `name?`, `dosage_form?` | Dosage Form · write | 🖥 `/api/admin/dosage-forms` | _no docstring_ |
| **`update_insurance`**<br><sub>923</sub> | `name?`, `insurance_payor_name?`, `insurance_claim_credit_days?`, `website?`, `disabled?` | Insurance Payor · write | 🧪 📘 | _no docstring_ |
| **`update_item`**<br><sub>2007</sub> | `name?`, `item_name?`, `item_group?`, `description?`, `rate?`, `disabled?`, `item_tax_template?` | Item · write | 🖥 `/api/admin/items` | _no docstring_ |
| **`update_lab_test_template`**<br><sub>1203</sub> | `name?`, `department?`, `lab_test_group?`, `lab_test_template_type?`, `is_billable?`, `lab_test_rate?`, `lab_test_uom?`, `lab_test_normal_range?` … +9 more | Lab Test Template · write | — | _no docstring_ |
| **`update_manufacturer`**<br><sub>2298</sub> | `name?`, `short_name?`, `full_name?` | Manufacturer · write | 🖥 `/api/admin/manufacturers` | _no docstring_ |
| **`update_medication`**<br><sub>671</sub> | `name?`, `item_name?`, `dosage_form?`, `strength?`, `strength_uom?`, `medication_class?`, `default_prescription_dosage?`, `default_prescription_duration?` … +7 more | Medication · write | 🧪 📘 | _no docstring_ |
| **`update_medication_class`**<br><sub>2511</sub> | `name?`, `medication_class?` | Medication Class · write | 🖥 `/api/admin/medication-classes` | _no docstring_ |
| **`update_payment_method`**<br><sub>3138</sub> | `name?`, `mode_of_payment?`, `type?`, `enabled?` | Mode of Payment · write | 🖥 `/api/admin/payment-methods` | _no docstring_ |
| **`update_prescription_dosage`**<br><sub>2623</sub> | `name?`, `dosage?` | Prescription Dosage · write | 🖥 `/api/admin/prescription-dosages` | _no docstring_ |
| **`update_prescription_duration`**<br><sub>2756</sub> | `name?`, `number?`, `period?` | Prescription Duration · write | 🖥 `/api/admin/prescription-durations` | _no docstring_ |
| **`update_therapy_type`**<br><sub>1392</sub> | `name?`, `therapy_type?`, `rate?`, `is_billable?`, `item_group?`, `description?`, `medical_department?`, `default_duration?` … +1 more | Therapy Type · write | — | _no docstring_ |
| **`update_treatment_plan_template`**<br><sub>3474</sub> | `name?`, `template_name?`, `medical_department?`, `description?`, `goal?`, `gender?`, `patient_age_from?`, `patient_age_to?` … +3 more | Treatment Plan Template · write | 🖥 `/api/admin/treatment-plans` | _no docstring_ |

### `api.v1.admin.demo_data`

`remedisys_healthcare_ai/api/v1/admin/demo_data.py` — 2 endpoints

> Full demo dataset generator for EB Clinic Settings' "Generate Test Data" button (Administrator only). One click generates a comprehensive, realistic demo dataset: - Bootstraps the "Chavitos Pediátrica" company (Mexican chart of accounts) if it doesn't exist yet — see `scripts/seed/create_mx_company.py` + `scripts/seed/setup_mx_clinic_accounts.py`. This also becomes the site's Global Default compan

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`delete_generated_data`**<br><sub>250</sub> | — | — | — | _no docstring_ |
| **`generate_test_data`**<br><sub>181</sub> | — | — | — | Idempotent and resumable: every sub-step checks before creating, so re-running after a partial failure continues rather than erroring on duplicates, and picks up the existing tr… |

### `api.v1.admin.holiday_lists`

`remedisys_healthcare_ai/api/v1/admin/holiday_lists.py` — 5 endpoints

> Holiday List CRUD — custom whitelisted layer, replaces `/api/resource/Holiday List`. ADR-021 (docs/adr/adr-021-master-data-crud-access.md) requires master/reference data to go through a whitelisted method, not raw `/api/resource/`. This is the first migrated doctype (see docs/planning/MASTER_CRUD_MIGRATION_PLAN.md) — scoped to Holiday List only rather than a generic cross-doctype dispatcher, since

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_holiday_list`**<br><sub>81</sub> | `holiday_list_name?`, `from_date?`, `to_date?`, `color?`, `weekly_off?`, `holidays?` | — | — | _no docstring_ |
| **`delete_holiday_list`**<br><sub>155</sub> | `name?` | — | — | _no docstring_ |
| **`get_holiday_list`**<br><sub>65</sub> | `name?` | — | 🖥 `/api/admin/holiday-list-detail` | Return a single Holiday List with its `holidays` child rows. |
| **`list_holiday_lists`**<br><sub>56</sub> | — | — | — | List Holiday Lists (flat fields only, no child rows). |
| **`update_holiday_list`**<br><sub>114</sub> | `name?`, `from_date?`, `to_date?`, `color?`, `weekly_off?`, `holidays?` | — | — | _no docstring_ |

### `api.v1.admin.lab_test_uoms`

`remedisys_healthcare_ai/api/v1/admin/lab_test_uoms.py` — 4 endpoints

> Lab Test UOM CRUD — custom whitelisted layer, replaces `/api/resource/Lab Test UOM`. Lab Test UOM is core Healthcare's unit-of-measure master for lab results (e.g. "mg/dL", "mmol/L") — picked by Lab Test Template's `lab_test_uom` field and, since it is also the Link target for Lab Unit Conversion's `from_unit`/ `to_unit` (see lab_unit_conversions.py), needs its own create/manage screen rather than

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_lab_test_uom`**<br><sub>40</sub> | `lab_test_uom?`, `uom_description?` | — | 🖥 `/api/labs/uoms` | _no docstring_ |
| **`delete_lab_test_uom`**<br><sub>85</sub> | `name?` | — | — | _no docstring_ |
| **`list_lab_test_uoms`**<br><sub>31</sub> | — | — | 🖥 `/api/labs/uoms` | List Lab Test UOMs (name/description master, no child rows). |
| **`update_lab_test_uom`**<br><sub>62</sub> | `name?`, `uom_description?` | — | — | _no docstring_ |

### `api.v1.admin.lab_unit_conversions`

`remedisys_healthcare_ai/api/v1/admin/lab_unit_conversions.py` — 4 endpoints

> Lab Unit Conversion CRUD — custom whitelisted layer. Lab Unit Conversion (ADR-020, gap G5) is the data-driven factor table services/lab_units.py::find_conversion reads to convert an AI-extracted lab value into an analyte's expected unit — deterministic and auditable (Rule 9; the LLM never does unit math). It previously had no admin exposure at all (Desk-only). `from_unit`/`to_unit` are Links to La

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_lab_unit_conversion`**<br><sub>50</sub> | `from_unit?`, `to_unit?`, `factor?`, `analyte?`, `offset?`, `bidirectional?`, `enabled?`, `source?` | — | — | _no docstring_ |
| **`delete_lab_unit_conversion`**<br><sub>136</sub> | `name?` | — | — | _no docstring_ |
| **`list_lab_unit_conversions`**<br><sub>41</sub> | — | — | — | List Lab Unit Conversion rows (flat fields, no child tables). |
| **`update_lab_unit_conversion`**<br><sub>89</sub> | `name?`, `from_unit?`, `to_unit?`, `factor?`, `analyte?`, `offset?`, `bidirectional?`, `enabled?` … +1 more | — | — | _no docstring_ |

### `api.v1.admin.permissions`

`remedisys_healthcare_ai/api/v1/admin/permissions.py` — 2 endpoints

> Role permission overrides — read and write the permission_overrides JSON blob.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_role_permissions`**<br><sub>22</sub> | `company?` | — | 🖥 `/api/admin/role-permissions` 🧪 | Return the stored role-permission overrides JSON blob for a company. |
| **`update_role_permissions`**<br><sub>35</sub> | `permission_overrides?`, `company?` | — | 🖥 `/api/admin/role-permissions` 🧪 | Replace the role-permission overrides blob for a company. |

### `api.v1.admin.practitioners`

`remedisys_healthcare_ai/api/v1/admin/practitioners.py` — 11 endpoints

> Admin — Healthcare Practitioner and Practitioner Schedule CRUD.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`admin_get_practitioner_profile`**<br><sub>449</sub> | `practitioner?` | Healthcare Practitioner · read | 🖥 `/api/admin/practitioners/[id]/profile` | Admin-facing read of an ARBITRARY practitioner's self-service profile (basic Healthcare Practitioner fields + Doctor Profile bio fields). |
| **`admin_update_practitioner_profile`**<br><sub>477</sub> | `practitioner?`, `about?`, `sub_specialty?`, `years_of_experience?`, `languages_spoken?`, `qualifications?`, `certifications?`, `work_experience?` | Healthcare Practitioner · write | 🖥 `/api/admin/practitioners/[id]/profile` | Admin-facing write of an ARBITRARY practitioner's Doctor Profile bio fields. |
| **`assign_schedule_to_practitioner`**<br><sub>700</sub> | `practitioner?`, `schedule?`, `service_unit?` | Healthcare Practitioner · write | 🖥 `/api/admin/practitioner-schedules/assign` | Append a schedule link to a practitioner without replacing existing links. |
| **`create_practitioner`**<br><sub>89</sub> | `first_name?`, `middle_name?`, `last_name?`, `email?`, `department?`, `gender?`, `practitioner_type?`, `mobile_phone?` … +4 more | Healthcare Practitioner · create | 🧪 | Create a Healthcare Practitioner. |
| **`create_practitioner_schedule`**<br><sub>667</sub> | `schedule_name?`, `time_slots?` | Practitioner Schedule · create | 🧪 | Create a Practitioner Schedule with optional time slot rows. |
| **`delete_practitioner`**<br><sub>529</sub> | `name?` | Healthcare Practitioner · delete | 🧪 | _no docstring_ |
| **`delete_practitioner_schedule`**<br><sub>753</sub> | `name?` | Practitioner Schedule · delete | 🧪 | _no docstring_ |
| **`get_practitioner_schedule`**<br><sub>617</sub> | `name?` | Practitioner Schedule · read | 🖥 `/api/admin/practitioner-schedules/detail` | Return a single Practitioner Schedule with its time slots. |
| **`lookup_practitioner_user`**<br><sub>48</sub> | `email?` | Healthcare Practitioner · read | — | Check if an email can be linked to a new practitioner. |
| **`update_practitioner`**<br><sub>246</sub> | `name?`, `first_name?`, `middle_name?`, `last_name?`, `email?`, `user_action?`, `status?`, `department?` … +8 more | Healthcare Practitioner · write | 🧪 | _no docstring_ |
| **`update_practitioner_schedule`**<br><sub>633</sub> | `name?`, `time_slots?`, `disabled?` | Practitioner Schedule · write | 🖥 `/api/admin/practitioner-schedules/detail` | Replace time slots on an existing Practitioner Schedule. |

### `api.v1.admin.settings`

`remedisys_healthcare_ai/api/v1/admin/settings.py` — 10 endpoints

> Clinic settings — company, department, service unit, clinic preferences, onboarding checklist.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_service_unit`**<br><sub>68</sub> | `service_unit_name?`, `company?`, `service_unit_type?`, `allow_appointments?`, `parent_healthcare_service_unit?`, `service_unit_capacity?`, `overlap_appointments?` | Healthcare Service Unit · create | 🖥 `/api/healthcare/service-units` 🧪 📘 | _no docstring_ |
| **`create_service_unit_type`**<br><sub>253</sub> | `service_unit_type?`, `allow_appointments?`, `overlap_appointments?`, `inpatient_occupancy?` | Healthcare Service Unit Type · create | 🖥 `/api/healthcare/service-unit-types` | _no docstring_ |
| **`delete_service_unit`**<br><sub>182</sub> | `name?` | Healthcare Service Unit · delete | 🖥 `/api/healthcare/service-units` 🧪 📘 | _no docstring_ |
| **`delete_service_unit_type`**<br><sub>352</sub> | `name?` | Healthcare Service Unit Type · delete | 🖥 `/api/healthcare/service-unit-types` | _no docstring_ |
| **`get_clinic_settings`**<br><sub>417</sub> | `company?` | — | 🖥 `/api/admin/clinic-settings` 🧪 | Return clinic settings for a company (defaults if not yet configured). |
| **`get_setup_checklist`**<br><sub>505</sub> | `company?` | Company · read | 🧪 | Return the clinic onboarding checklist. |
| **`list_service_unit_types`**<br><sub>227</sub> | — | Healthcare Service Unit Type · read | 🖥 `/api/healthcare/service-unit-types` | _no docstring_ |
| **`update_clinic_settings`**<br><sub>428</sub> | `company?`, `has_internal_pharmacy?`, `has_internal_lab?`, `has_internal_therapy?`, `has_internal_procedures?`, `appointment_reminder_timing?`, `no_show_alert_timing?`, `lab_result_notification?` … +9 more | — | 🖥 `/api/admin/clinic-settings` 🧪 | Patch one or more clinic settings fields for a company. |
| **`update_service_unit`**<br><sub>129</sub> | `name?`, `service_unit_name?`, `service_unit_type?`, `allow_appointments?`, `service_unit_capacity?`, `overlap_appointments?` | Healthcare Service Unit · write | 🖥 `/api/healthcare/service-units` 🧪 📘 | _no docstring_ |
| **`update_service_unit_type`**<br><sub>291</sub> | `name?`, `service_unit_type?`, `allow_appointments?`, `overlap_appointments?`, `inpatient_occupancy?`, `disabled?` | Healthcare Service Unit Type · write | 🖥 `/api/healthcare/service-unit-types` | _no docstring_ |

### `api.v1.admin.staff`

`remedisys_healthcare_ai/api/v1/admin/staff.py` — 4 endpoints

> Staff management — list, invite, update clinical users.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`invite_staff`**<br><sub>177</sub> | `email?`, `roles?`, `first_name?`, `last_name?`, `company?` | User · create | 🖥 `/api/admin/users` 🧪 📘 | Create a Website User, assign clinical roles, and send a branded welcome email. |
| **`list_staff`**<br><sub>58</sub> | `page?`, `page_size?`, `search?`, `role?`, `status?` | User · read | 🖥 `/api/admin/users` 🧪 📘 | Return all users carrying at least one clinical role. |
| **`resend_welcome_email`**<br><sub>320</sub> | `name?`, `company?` | User · write | 🖥 `/api/admin/users/resend` | Resend the branded set-password/welcome email to an existing staff user. |
| **`update_user`**<br><sub>241</sub> | `name?`, `roles?`, `enabled?`, `first_name?`, `last_name?` | User · write | 🖥 `/api/admin/users` 🧪 📘 | Patch a staff user: change roles, toggle enabled, update display name. |

### `api.v1.ai.api`

`remedisys_healthcare_ai/api/v1/ai/api.py` — 18 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`accept_soap_draft`**<br><sub>689</sub> | `draft_name` | — | 🖥 `/api/ai/soap-draft/accept` | Mark a SOAP draft as physician-accepted. |
| **`analyze_encounter`**<br><sub>1221</sub> | `encounter`, `transcript?`, `focus?`, `force?` | — | 🖥 `/api/ai/analyze` | Quick-action analysis (ADR-034): run the agent over the WHOLE encounter — the transcript plus the full stored Narzim conversation — and fill the draft with ClinicalSuggestions (… |
| **`analyze_lab`**<br><sub>1448</sub> | `encounter`, `lab_test` | — | 🖥 `/api/ai/analyze-lab` | Analyze one selected Lab Test and return a plain-language summary for the Narzim chat (read-only insight — Rule 6, no chart mutation). |
| **`ask_copilot`**<br><sub>753</sub> | `encounter`, `prompt`, `history?`, `transcript?`, `kind?`, `thread?`, `fingerprint?` | — | 🖥 `/api/ai/chat` | Agentic encounter assistant (ADR-030) — the "Ask Narzim AI anything about this encounter" box. |
| **`create_master`**<br><sub>221</sub> | `master_type`, `name` | — | 🖥 `/api/ai/create-master` | Create a clinical master record from an AI-proposed name, invoked when a physician confirms an is_new autopopulate suggestion ("Add to master?"). |
| **`discard_soap_draft`**<br><sub>703</sub> | `draft_name` | — | 🖥 `/api/ai/soap-draft/discard` | Mark a SOAP draft as discarded. No changes are applied to the encounter. |
| **`enhance_text`**<br><sub>441</sub> | `text` | — | 🖥 `/api/ai/enhance-text` | Rewrite free text (e.g. |
| **`generate_review_details`**<br><sub>1324</sub> | `encounter`, `transcript?` | — | 🖥 `/api/ai/review-details` | Generate the encounter's "Review Details" (the patient-facing visit summary — findings, diagnosis in plain language, medication/care instructions, red flags, follow-up) from the… |
| **`generate_soap_draft`**<br><sub>612</sub> | `encounter`, `transcript` | — | 🖥 `/api/ai/soap-draft` | Comprehensive, versioned SOAP draft generation — a deliberate end-of-session action distinct from generate_suggestions' incremental nudges. |
| **`generate_suggestions`**<br><sub>547</sub> | `encounter`, `transcript`, `focus?` | — | 🖥 `/api/ai/suggest` | Generate ClinicalSuggestion[] from a consultation transcript. |
| **`get_ai_flags`**<br><sub>401</sub> | — | — | 🖥 `/api/ai/flags` | Return AI feature flags. Fails closed — if AI Settings are missing all flags are off. |
| **`get_encounter_chat`**<br><sub>1117</sub> | `encounter`, `thread?` | — | 🖥 `/api/ai/encounter-chat` | Replay a persisted Narzim chat thread for an encounter (ADR-034). |
| **`get_encounter_threads`**<br><sub>1176</sub> | `encounter` | — | 🖥 `/api/ai/encounter-threads` | List the encounter's Narzim chat threads (ChatGPT-style history), newest activity first, each with a short preview + message count, so the physician can pick which past conversa… |
| **`list_encounter_labs`**<br><sub>1402</sub> | `encounter`, `page?`, `page_size?`, `search?` | — | 🖥 `/api/ai/encounter-labs` | List the encounter patient's Lab Tests for the Narzim "Labs" picker — newest first, paginated (5 at a time + "more"), optional name search. |
| **`mint_deepgram_token`**<br><sub>470</sub> | `encounter` | — | — | Return a short-lived Deepgram WSS URL + scoped token for the browser. |
| **`resegregate_transcript`**<br><sub>713</sub> | `encounter`, `transcript` | — | 🖥 `/api/ai/resegregate` | Rebuild a garbled transcript into a clean doctor/patient back-and-forth where automatic diarization failed — mislabeled turns AND single segments that mashed two speakers' words… |
| **`transcribe_audio`**<br><sub>481</sub> | `encounter`, `audio_b64` | — | 🖥 `/api/ai/transcribe` | Decode base64 audio, transcribe + diarize via Deepgram Nova-3 Medical. |
| **`upload_and_analyze_document`**<br><sub>1503</sub> | `encounter`, `prompt?`, `thread?` | — | 🖥 `/api/ai/analyze-document` | Attach → analyze (ChatGPT-style): the physician attaches a lab/clinical report (PDF or image) in the Narzim chat. |

### `api.v1.appointments.api`

`remedisys_healthcare_ai/api/v1/appointments/api.py` — 15 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`book_appointment`**<br><sub>1289</sub> | `patient?`, `company?`, `appointment_date?`, `appointment_time?`, `appointment_type?`, `appointment_for?`, `practitioner?`, `department?` … +24 more | — | 🖥 `/api/appointments` 🧪 📘 | Called by the Next.js route POST handler. |
| **`book_appointment_for_patient`**<br><sub>1497</sub> | `patient?`, `new_patient?`, `company?`, `appointment_date?`, `appointment_time?`, `appointment_type?`, `appointment_for?`, `practitioner?` … +28 more | — | 🖥 `/api/appointments/book` 🧪 📘 | Book an appointment for an EXISTING or a BRAND-NEW patient, atomically, and optionally invoice it in the same call. |
| **`book_appointment_with_payment`**<br><sub>1330</sub> | `mode_of_payment?`, `discount_amount?`, `discount_percentage?`, `**kwargs` | Patient Appointment · create | 🖥 `/api/appointments/create-with-payment` | Pay-Now booking: create the appointment, invoice it, settle in full. |
| **`cancel_appointment`**<br><sub>1747</sub> | `appointment?`, `reason?` | Patient Appointment · write | 🖥 `/api/appointments/[id]` `/api/appointments/cancel` 🧪 📘 | _no docstring_ |
| **`check_in_patient`**<br><sub>1773</sub> | `appointment?` | Patient Appointment · write | 🖥 `/api/appointments/[id]/check-in` `/api/appointments/check-in` 🧪 📘 | _no docstring_ |
| **`create_appointment`**<br><sub>1248</sub> | `patient?`, `company?`, `appointment_date?`, `appointment_time?`, `appointment_type?`, `appointment_for?`, `practitioner?`, `department?` … +24 more | — | 🧪 📘 | Called by the frontend appointments lib directly. |
| **`get_appointment`**<br><sub>1230</sub> | `appointment?` | Patient Appointment · read | 🖥 `/api/appointments` `/api/appointments/[id]` 🧪 📘 | _no docstring_ |
| **`get_appointments`**<br><sub>1202</sub> | `date?`, `practitioner?`, `patient?`, `status?`, `company?`, `limit?`, `offset?`, `sort?` … +4 more | — | — | Called by the frontend appointments lib directly. |
| **`get_available_slots`**<br><sub>986</sub> | `practitioner?`, `date?` | Healthcare Practitioner · read | 🖥 `/api/appointments/slots` 🧪 📘 | Return a practitioner's bookable time slots for a date. |
| **`get_reschedule_history`**<br><sub>2164</sub> | `appointment?` | Patient Appointment · read | — | Every reschedule-with-payment event for an appointment, oldest first — backs both the frontend's appointment-history timeline and its payment- history table (they're the same ro… |
| **`list_appointments`**<br><sub>1214</sub> | `date?`, `practitioner?`, `patient?`, `status?`, `company?`, `limit?`, `offset?`, `sort?` … +4 more | — | 🖥 `/api/appointments` 🧪 📘 | Called by the Next.js route GET handler. |
| **`reassign_appointment`**<br><sub>1844</sub> | `appointment?`, `practitioner?` | Patient Appointment · write | 🖥 `/api/appointments/[id]/reassign` | Reassign an appointment to a different practitioner (coverage workflow). |
| **`reschedule_appointment`**<br><sub>1804</sub> | `appointment?`, `appointment_date?`, `appointment_time?` | Patient Appointment · write | 🖥 `/api/appointments/[id]/reschedule` 📘 | Move an existing appointment to a new date/time (same practitioner). |
| **`reschedule_appointment_with_payment`**<br><sub>1972</sub> | `appointment?`, `new_practitioner?`, `new_appointment_date?`, `new_appointment_time?`, `new_appointment_type?`, `new_department?`, `new_service_unit?`, `fee_override?` … +2 more | Patient Appointment · write | 🖥 `/api/appointments/[id]/reschedule-with-payment` | Reschedule an appointment via the same drawer used to book one, and settle whatever fee difference the new doctor/date/time/type causes. |
| **`update_status`**<br><sub>1725</sub> | `appointment?`, `status?` | Patient Appointment · write | 🖥 `/api/appointments` `/api/appointments/[id]` 🧪 📘 | _no docstring_ |

### `api.v1.appointments.report`

`remedisys_healthcare_ai/api/v1/appointments/report.py` — 4 endpoints

> Operations reports owned by the appointments module — Phase 4, Screen 18. Frontend reports: operations/daily-patient-flow, operations/no-show-analysis, operations/queue-wait-times, operations/check-in-rates. queue-wait-times and check-in-rates both use Patient Appointment.custom_checked_in_at (stamped by the check-in API — a read-only system field). queue-wait-times measures arrival → seen (Encoun

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_check_in_rates`**<br><sub>416</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_daily_patient_flow`**<br><sub>127</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_no_show_analysis`**<br><sub>198</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_queue_wait_times`**<br><sub>326</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.auth.api`

`remedisys_healthcare_ai/api/v1/auth/api.py` — 5 endpoints

> Auth API — Remedisys-specific auth methods. Login, refresh, and logout are handled by the eb_frappe_jwt app (ADR-011): POST /api/method/eb_frappe_jwt.api.get_token — login, returns access + refresh POST /api/method/eb_frappe_jwt.api.refresh_token — rotate, returns a new pair POST /api/method/eb_frappe_jwt.api.revoke_token — logout (this device) POST /api/method/eb_frappe_jwt.api.revoke_all_tokens 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`change_password`**<br><sub>175</sub> | `current_password?`, `new_password?` | — | 🖥 `/api/auth/password` 🧪 | Change the logged-in user's password after verifying the current one. |
| **`get_current_user`**<br><sub>300</sub> | — | — | 🖥 `clinic:auth.ts` 🧪 📘 | Returns the logged-in user profile and roles. |
| **`request_password_reset`**<br><sub>248</sub> | `email?` | — | 🖥 `/api/auth/forgot-password` 🌐 | Public: email a reset link to an eligible portal user. |
| **`update_notification_prefs`**<br><sub>149</sub> | `prefs?` | — | 🖥 `/api/auth/notification-prefs` 🧪 | Save notification preferences for the logged-in user. |
| **`update_profile`**<br><sub>88</sub> | `full_name?`, `phone?`, `mobile_no?`, `user_image?`, `remove_user_image?`, `language?` | — | 🖥 `/api/auth/profile` 🧪 | Update the logged-in user's own profile fields. |

### `api.v1.billing.api`

`remedisys_healthcare_ai/api/v1/billing/api.py` — 21 endpoints

> Billing API — Phase 3. Endpoints: create_appointment_invoice — create the Sales Invoice for a Patient Appointment via the exact core Healthcare flow (works with or without insurance) list_patient_invoices — paginated Sales Invoice history for a patient list_all_invoices — paginated clinic-wide Sales Invoice list (patients only) list_draft_invoices — paginated clinic-wide draft (docstatus=0) Sales 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`collect_payment`**<br><sub>806</sub> | `invoice`, `amount`, `mode_of_payment`, `reference_no?`, `reference_date?` | Payment Entry · create | 🖥 `/api/billing/collect` 🧪 | Record a payment against a Sales Invoice via ERPNext Payment Entry. |
| **`create_appointment_invoice`**<br><sub>328</sub> | `appointment?`, `mode_of_payment?`, `paid_amount?`, `discount_percentage?`, `discount_amount?` | Sales Invoice · create | 🖥 `/api/billing/invoice` 🧪 | Create the Sales Invoice for an appointment using the core Healthcare flow. |
| **`create_credit_note`**<br><sub>862</sub> | `invoice`, `mode_of_payment?`, `items?` | Sales Invoice · create | 🖥 `/api/billing/refund` | Refund a patient Sales Invoice by creating a Credit Note. |
| **`create_invoice`**<br><sub>1248</sub> | `patient?`, `items?`, `taxes_and_charges?`, `discount_amount?`, `discount_percentage?`, `mode_of_payment?`, `paid_amount?`, `remarks?` | Sales Invoice · create | 🖥 `/api/billing/new-invoice` | Create an ad-hoc Sales Invoice from arbitrary line items + optional tax. |
| **`create_pos_invoice`**<br><sub>1206</sub> | `patient?`, `lines?`, `mode_of_payment?`, `paid_amount?`, `discount_amount?`, `discount_percentage?` | Sales Invoice · create | 🖥 `/api/billing/pos` | Create one consolidated Sales Invoice from selected billable lines, and optionally settle it (one visit → one bill → one payment). |
| **`create_sales_invoice`**<br><sub>1392</sub> | `patient?`, `service_refs?`, `items?`, `taxes_and_charges?`, `discount_amount?`, `discount_percentage?`, `mode_of_payment?`, `paid_amount?` … +7 more | Sales Invoice · create | 🖥 `/api/billing/create` | Unified Sales Invoice editor endpoint — mixes pulled healthcare-service lines (service_refs, cart-validated, invoiced write-back + insurance on submit) and ad-hoc item lines (it… |
| **`create_vaccination_invoice`**<br><sub>1157</sub> | `immunization_names?`, `mode_of_payment?`, `paid_amount?` | Sales Invoice · create | 🖥 `/api/billing/vaccination` | Create (and optionally settle) one Sales Invoice for the given vaccinations. |
| **`get_draft_invoice_detail`**<br><sub>627</sub> | `name?` | Sales Invoice · read | 🖥 `/api/billing/drafts/[name]` | Full editable detail of a single draft Sales Invoice. |
| **`get_patient_billables`**<br><sub>1190</sub> | `patient?` | Sales Invoice · create | 🖥 `/api/billing/pos` | Unified billing cart for a patient: every un-invoiced billable service (consultation, encounter, lab, procedure, …) plus vaccines, in one list. |
| **`get_patient_invoice`**<br><sub>712</sub> | `name` | Sales Invoice · read | 🖥 `/api/billing/invoice/[name]` 🧪 | Return a single Sales Invoice with its line items and taxes. |
| **`get_payment_methods`**<br><sub>60</sub> | — | Mode of Payment · read | 🖥 `/api/payment-methods` | List enabled ERPNext Modes of Payment for the booking payment dropdown. |
| **`get_refundable_items`**<br><sub>928</sub> | `invoice?` | Sales Invoice · read | 🖥 `/api/billing/refundable-items` | What's still refundable on a Sales Invoice, per line. |
| **`list_all_invoices`**<br><sub>445</sub> | `page?`, `page_size?`, `status?`, `date_from?`, `date_to?`, `search?`, `include_returns?` | Sales Invoice · read | 🧪 | Paginated clinic-wide Sales Invoice list, newest first. |
| **`list_billable_immunizations`**<br><sub>1142</sub> | `patient?` | Sales Invoice · create | 🖥 `/api/billing/vaccination` | List a patient's un-billed, billable immunizations (for the vaccination invoice picker). |
| **`list_draft_invoices`**<br><sub>559</sub> | `page?`, `page_size?` | Sales Invoice · read | 🖥 `/api/billing/drafts` | Paginated clinic-wide list of in-progress (docstatus=0) Sales Invoices, most recently modified first — backs the "Continue a draft" picker in the New Invoice sheet. |
| **`list_item_tax_templates`**<br><sub>1340</sub> | — | Sales Invoice · create | 🖥 `/api/billing/item-tax-templates` | List Item Tax Templates for the per-line tax picker on the invoice editor. |
| **`list_patient_invoices`**<br><sub>371</sub> | `patient`, `page?`, `page_size?`, `status?`, `include_returns?` | Sales Invoice · read | 🧪 📘 | Paginated Sales Invoice history for a patient, newest first. |
| **`list_payment_entries`**<br><sub>1032</sub> | `page?`, `page_size?`, `mode_of_payment?`, `date_from?`, `date_to?`, `search?` | Payment Entry · read | 🖥 `/api/billing/payments` 🧪 | Paginated clinic-wide list of incoming patient payments, newest first. |
| **`list_tax_templates`**<br><sub>1295</sub> | — | Sales Invoice · create | 🖥 `/api/billing/tax-templates` | List Sales Taxes and Charges Templates for the tax picker on the invoice editor. |
| **`search_billable_items`**<br><sub>1380</sub> | `query?`, `limit?` | Item · read | 🖥 `/api/billing/priced-items` | Item picker (with selling rate) for the Sales Invoice editor. |
| **`set_medication_billed_externally`**<br><sub>1477</sub> | `medication_request?`, `billed_externally?` | Sales Invoice · create | 🖥 `/api/billing/medication-external` | Mark (or unmark) a Medication Request as obtained outside the clinic so it drops off the billing cart without cancelling the prescription (ADR-024 companion). |

### `api.v1.billing.report`

`remedisys_healthcare_ai/api/v1/billing/report.py` — 3 endpoints

> Billing reports — Phase 4, Screen 18. Lives with the billing module (Frontend reports: financial/payment-methods, financial/outstanding-balances, financial/revenue-by-provider). Endpoints + aggregation are self-contained here; shared window/envelope primitives come from remedisys_healthcare_ai.utils. Backend returns raw values with stable keys — the frontend owns i18n labels and chart colors (Fron

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_outstanding_balances`**<br><sub>255</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Sales Invoice · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_payment_methods`**<br><sub>159</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Payment Entry · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_revenue_by_provider`**<br><sub>383</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Sales Invoice · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.clinical.api`

`remedisys_healthcare_ai/api/v1/clinical/api.py` — 8 endpoints

> Clinical API — Phase 2 (Patient 360 clinical tab). Conditions and allergies are stored on the existing ERPNext Patient doctype as comma-separated free-text — no new doctype (CLAUDE.md §7). This mirrors how patients.api already reads them (_split_allergies / get_patient_chart_overview): allergies -> Patient.allergies conditions -> Patient.medical_history Each endpoint manages a de-duplicated list o

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`add_allergy`**<br><sub>206</sub> | `patient?`, `allergy?` | — | 🖥 `/api/patients/[id]/allergies` 🧪 | Add an allergy (idempotent, case-insensitive). Returns the updated list. |
| **`add_condition`**<br><sub>238</sub> | `patient?`, `condition?` | — | 🖥 `/api/patients/[id]/conditions` 🧪 | Add a condition (idempotent, case-insensitive). Returns the updated list. |
| **`list_allergies`**<br><sub>199</sub> | `patient?` | — | 🧪 | Return the patient's allergy list. data = {patient, allergies: [str]}. |
| **`list_conditions`**<br><sub>231</sub> | `patient?` | — | 🧪 | Return the patient's condition list. data = {patient, conditions: [str]}. |
| **`remove_allergy`**<br><sub>222</sub> | `patient?`, `allergy?` | — | 🖥 `/api/patients/[id]/allergies` 🧪 | Remove an allergy (idempotent). Returns the updated list. |
| **`remove_condition`**<br><sub>254</sub> | `patient?`, `condition?` | — | 🖥 `/api/patients/[id]/conditions` 🧪 | Remove a condition (idempotent). Returns the updated list. |
| **`update_allergy`**<br><sub>213</sub> | `patient?`, `allergy?`, `new_value?` | — | 🧪 | Rename an existing allergy. 404 if the original is not present. |
| **`update_condition`**<br><sub>245</sub> | `patient?`, `condition?`, `new_value?` | — | 🧪 | Rename an existing condition. 404 if the original is not present. |

### `api.v1.clinical.report`

`remedisys_healthcare_ai/api/v1/clinical/report.py` — 1 endpoint

> Clinical reports owned by the clinical module — Phase 4, Screen 18. Frontend report: clinical/chronic-care-management. chronic_care derives the condition distribution + chronic-patient count from Patient.medical_history (semicolon/comma-separated condition names — real data). "Controlled vs uncontrolled", HbA1c trend, and review cadence have no structured source and are stubbed (docs/REPORTS_API.m

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_chronic_care`**<br><sub>127</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.clinical_documents.api`

`remedisys_healthcare_ai/api/v1/clinical_documents/api.py` — 8 endpoints

> Clinical Documents API — personal work documents (notes + image/PDF attachments). Thin whitelisted layer over services/clinical_documents.py. No business logic here: parse input, call the service, shape the standardised response. Every privacy rule (owner-or-shared visibility, 404 instead of 403) lives in the service module — this file never makes that decision itself. Endpoints: list_documents(se

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_document`**<br><sub>42</sub> | `title?`, `notes?`, `visibility?`, `shared_with?`, `share_with_team?`, `tags?` | — | 🖥 `/api/clinical-documents` | _no docstring_ |
| **`delete_attachment`**<br><sub>105</sub> | `id?`, `file_id?` | — | 🖥 `/api/clinical-documents/[id]/attachments` | _no docstring_ |
| **`delete_document`**<br><sub>83</sub> | `id?` | — | 🖥 `/api/clinical-documents/[id]` 📘 | _no docstring_ |
| **`get_document`**<br><sub>36</sub> | `id?` | — | 🖥 `/api/clinical-documents/[id]` | _no docstring_ |
| **`list_documents`**<br><sub>30</sub> | `search?` | — | 🖥 `/api/clinical-documents` 📘 | _no docstring_ |
| **`list_shareable_users`**<br><sub>112</sub> | — | — | 🖥 `/api/clinical-documents/shareable-users` | _no docstring_ |
| **`update_document`**<br><sub>61</sub> | `id?`, `title?`, `notes?`, `tags?`, `visibility?`, `shared_with?`, `share_with_team?`, `shared_access_level?` | — | 🖥 `/api/clinical-documents/[id]` | _no docstring_ |
| **`upload_attachment`**<br><sub>90</sub> | `id?` | — | 🖥 `/api/clinical-documents/[id]/attachments` | The file arrives as multipart form-data under the key "file"; id is a regular form field (mapped to this kwarg by Frappe). |

### `api.v1.company.api`

`remedisys_healthcare_ai/api/v1/company/api.py` — 7 endpoints

> Company API — all Company-related endpoints in one place. Method prefix: remedisys_healthcare_ai.api.v1.company.api.* get_companies paginated list of companies (switcher, booking, profile read) get_countries flat list of all Country names (for dropdowns) get_currencies flat list of {name, currency_name, symbol} (for dropdowns) create_company create a Company update_company patch a Company get_comp

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_company`**<br><sub>119</sub> | `company_name?`, `abbr?`, `default_currency?`, `country?`, `valuation_method?`, `tax_id?`, `phone_no?`, `email?` … +4 more | Company · create | 🧪 📘 | _no docstring_ |
| **`get_companies`**<br><sub>64</sub> | `page?`, `page_size?`, `search?` | Company · read | 🖥 `/api/admin/company-profile` `/api/companies` 🧪 | Return a paginated list of ERPNext Company records. |
| **`get_company_address`**<br><sub>242</sub> | `name?` | Company · read | 🖥 `/api/admin/company-address` 🧪 | Return the Office Address linked to the given Company, or null if none exists. |
| **`get_countries`**<br><sub>95</sub> | — | Company · read | 🖥 `/api/admin/countries` 🧪 | Return all Country names as a flat list, ordered alphabetically. |
| **`get_currencies`**<br><sub>104</sub> | — | Company · read | 🖥 `/api/admin/currencies` 🧪 | Return all enabled currencies as {name, currency_name, symbol}, ordered by name. |
| **`save_company_address`**<br><sub>269</sub> | `company_name?`, `address_line1?`, `address_line2?`, `city?`, `state?`, `pincode?`, `country?` | Company · write | 🖥 `/api/admin/company-address` 🧪 | Create or update the Office Address linked to the given Company. |
| **`update_company`**<br><sub>185</sub> | `name?`, `tax_id?`, `phone_no?`, `email?`, `default_currency?`, `country?`, `website?`, `date_of_establishment?` … +3 more | Company · write | 🖥 `/api/admin/company-profile` 🧪 📘 | Patch a company. company_name and abbr are not updatable (ERPNext restriction). |

### `api.v1.dashboard.api`

`remedisys_healthcare_ai/api/v1/dashboard/api.py` — 2 endpoints

> Dashboard API — Phase 1. get_dashboard_data — aggregated KPI snapshot for the Today tab. Returns: date — date this data covers queue_summary — appointment counts by status bucket revenue — pending and collected MXN from Sales Invoice practitioners — per-practitioner appointment counts for the day

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_command_center`**<br><sub>1019</sub> | `date?`, `date_from?`, `date_to?` | Patient Appointment · read | 🧪 | Multi-clinic admin rollup for the dashboard Command Centre tab. |
| **`get_dashboard_data`**<br><sub>198</sub> | `date?`, `practitioner?` | — | 🖥 `/api/dashboard` `clinic:dashboard.ts` 🧪 📘 | Return aggregated KPI data for the dashboard Today tab. |

### `api.v1.dashboard.report`

`remedisys_healthcare_ai/api/v1/dashboard/report.py` — 2 endpoints

> Reports landing-page overview — Phase 4, Screen 18. Frontend: the /reports index (KPI strip + weekly patient sparkline). Lives with the dashboard module since it is an aggregate snapshot, distinct from the operational Today dashboard in api.py. KPI strip is [appointments_period, checked_out_period, revenue_collected, outstanding_amount, no_show_rate_pct, avg_wait_min]. avg_wait_min briefly read as

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_my_performance`**<br><sub>332</sub> | — | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_reports_overview`**<br><sub>219</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.documents.api`

`remedisys_healthcare_ai/api/v1/documents/api.py` — 5 endpoints

> Patient Documents API — screen 13 (Documents tab). Thin whitelisted layer over services/documents.py. No business logic here: parse input, call the service, shape the standardised response. Storage and rules live in the service module. Uploaded documents are PMR rows flagged custom_is_uploaded_document=1; auto patient-history rows are never returned or mutated by these endpoints. Endpoints: list_c

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`delete_document`**<br><sub>74</sub> | `document_id?` | — | 🖥 `/api/patients/[id]/documents/[docId]` 🧪 📘 | Delete an uploaded document and its file blob. |
| **`get_download_url`**<br><sub>67</sub> | `document_id?` | — | 🧪 | Return the permission-checked (private) file URL for a document. |
| **`list_categories`**<br><sub>29</sub> | — | — | 🖥 `/api/documents/categories` 🧪 | Active document categories for the tab bar (ordered). |
| **`list_documents`**<br><sub>36</sub> | `patient?`, `category?`, `search?` | — | 🖥 `/api/patients/[id]/documents` 🧪 📘 | Uploaded documents for a patient, grouped client-side by category. |
| **`upload_document`**<br><sub>47</sub> | `patient?`, `category?` | — | 🖥 `/api/patients/[id]/documents` 🧪 📘 | Upload a file against a patient. |

### `api.v1.encounters.api`

`remedisys_healthcare_ai/api/v1/encounters/api.py` — 22 endpoints

> Patient Encounter API — Phase 1. SOAP persistence strategy: - Free-text fields without native ERPNext equivalents (chief_complaint, hpi, plan, education, notes, diagnosis-text) are stored as a JSON blob in encounter_comment. - Native ERPNext child tables are used for structured clinical data: diagnosis, drug_prescription, lab_test_prescription. Endpoints: list_encounters — paginated list (patient 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`book_follow_up`**<br><sub>2215</sub> | `encounter?`, `days_from_now?`, `appointment_type?`, `notes?`, `assigned_to?` | Patient Encounter · read | 🖥 `/api/encounters/[id]/followup` | Request a follow-up for this encounter, or update the one already requested — idempotent by encounter, same pattern as start_encounter/create_encounter elsewhere in this file (o… |
| **`cancel_encounter`**<br><sub>2063</sub> | `encounter?` | Patient Encounter · write | 🖥 `/api/encounters/[id]/cancel` 🧪 | Cancel a clinical note (Patient Encounter). |
| **`complete_encounter`**<br><sub>1864</sub> | `encounter?` | Patient Encounter · submit | 🖥 `/api/encounters/[id]/complete` 🧪 📘 | Validate and submit a Draft encounter (docstatus 0 → 1). |
| **`create_allergy`**<br><sub>1167</sub> | `allergy?` | — | 🖥 `/api/encounters/allergies` | Create an Allergy master record if it does not already exist. |
| **`create_complaint`**<br><sub>1257</sub> | `complaint?` | — | 🖥 `/api/encounters/complaints` | Create a Complaint master record if it does not already exist. |
| **`create_diagnosis`**<br><sub>1293</sub> | `diagnosis?` | — | 🖥 `/api/encounters/diagnoses` | Create a Diagnosis master record if it does not already exist. |
| **`create_encounter`**<br><sub>1010</sub> | `appointment?`, `patient?`, `practitioner?`, `medical_department?`, `company?`, `appointment_type?` | Patient Encounter · create | 🖥 `/api/encounters` 🧪 📘 | Create an Open / Draft Patient Encounter. |
| **`create_surgical_history`**<br><sub>1221</sub> | `surgery?` | — | 🖥 `/api/encounters/surgical-history` | Create a Surgical History master record if it does not already exist. |
| **`get_encounter`**<br><sub>871</sub> | `encounter?` | Patient Encounter · read | 🖥 `/api/encounters/[id]` 🧪 📘 | Return a single Patient Encounter by document name. |
| **`get_encounters`**<br><sub>850</sub> | `patient?`, `date?`, `practitioner?`, `status?`, `page?`, `page_size?` | — | — | Alias for list_encounters — called directly from encounters.ts. |
| **`get_follow_up`**<br><sub>2192</sub> | `encounter?` | Patient Encounter · read | 🖥 `/api/encounters/[id]/followup` | Return the follow-up task already requested for this encounter, or null if none. |
| **`get_treatment_plan_template`**<br><sub>1354</sub> | `template?` | Treatment Plan Template · read | 🖥 `/api/encounters/treatment-plans/[name]` | Return a Treatment Plan Template's orders so the encounter can auto-fill Medications / Investigations / Procedures / Therapies (doctor can then edit). |
| **`list_encounters`**<br><sub>757</sub> | `patient?`, `date?`, `practitioner?`, `status?`, `page?`, `page_size?` | Patient Encounter · read | 🖥 `/api/encounters` 🧪 📘 | Paginated encounter list. |
| **`list_follow_up_assignees`**<br><sub>2161</sub> | — | Patient Encounter · read | 🖥 `/api/encounters/followup-assignees` | Front Desk users a follow-up request can be assigned to — feeds the type-and-select assignee picker on the encounter's follow-up form. |
| **`save_draft`**<br><sub>1446</sub> | `encounter?`, `# SOAP text fields — all optional; omitted fields are preserved (merge semantics) chief_complaint?`, `hpi?`, `notes?`, `plan?`, `education?`, `diagnosis?`, `# Native Patient Encounter.physical_examination field (ADR-019) physical_examination?` … +8 more | Patient Encounter · write | 🖥 `/api/encounters/[id]` 🧪 📘 | Partial update of a Draft Patient Encounter. |
| **`search_allergies`**<br><sub>1151</sub> | `query?` | — | 🖥 `/api/encounters/allergies` | Return up to 15 Allergy names matching query (case-insensitive substring). |
| **`search_complaints`**<br><sub>1241</sub> | `query?` | — | 🖥 `/api/encounters/complaints` | Return up to 15 Complaint names matching query (case-insensitive substring). |
| **`search_diagnoses`**<br><sub>1277</sub> | `query?` | — | 🖥 `/api/encounters/diagnoses` | Return up to 15 Diagnosis names matching query (case-insensitive substring). |
| **`search_medications`**<br><sub>1187</sub> | `query?` | — | 🖥 `/api/encounters/medications-search` | Return up to 15 Medication generic names matching query (case-insensitive substring). |
| **`search_surgical_history`**<br><sub>1205</sub> | `query?` | — | 🖥 `/api/encounters/surgical-history` | Return up to 15 Surgical History names matching query (case-insensitive substring). |
| **`search_treatment_plan_templates`**<br><sub>1313</sub> | `query?`, `department?` | — | 🖥 `/api/encounters/treatment-plans` | Return up to 15 active Treatment Plan Templates matching query and optional department. |
| **`start_encounter`**<br><sub>940</sub> | `appointment` | Patient Encounter · create | 🖥 `/api/encounters/start` 🧪 | Create a new Open encounter from an existing Patient Appointment. |

### `api.v1.encounters.pdf`

`remedisys_healthcare_ai/api/v1/encounters/pdf.py` — 1 endpoint

> Encounter report email delivery. The frontend cannot send SMTP mail directly (BFF architecture — every outbound action goes through a whitelisted Frappe method). This emails the signed encounter (SOAP note) PDF to the patient or their guardian. The PDF itself is rendered by the frontend from the exact on-screen signed report (the same DOM used for "Download PDF" and the WhatsApp send) and passed h

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`email_encounter_report`**<br><sub>83</sub> | `encounter?`, `to_email?`, `file_data?`, `lang?` | Patient Encounter · read | 🖥 `/api/encounters/[id]/email-report` | Email the signed encounter report (SOAP note) as a PDF to the patient or their guardian. |

### `api.v1.encounters.report`

`remedisys_healthcare_ai/api/v1/encounters/report.py` — 3 endpoints

> Clinical reports owned by the encounters module — Phase 4, Screen 18. Frontend reports: clinical/diagnosis-trends, clinical/encounter-summaries. encounter-summaries is real except avg_duration_min (no end timestamp — stubbed). chronic-care is not here — it needs a chronic registry (docs/REPORTS_API.md §6).

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_avg_visit_time`**<br><sub>340</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Encounter · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_diagnosis_trends`**<br><sub>131</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Encounter · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_encounter_summaries`**<br><sub>231</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Encounter · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.immunizations.api`

`remedisys_healthcare_ai/api/v1/immunizations/api.py` — 22 endpoints

> Immunizations API — Phase 2 (clinical details). CRUD over the custom `Immunization` doctype (one administered vaccine dose per row). This app owns the doctype because ERPNext Healthcare has no immunization record. Each row links the Patient (and optionally the Appointment that triggered it) and the administering Practitioner. Backs the Patient Chart Immunizations tab. All access is permission-gate

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`apply_program`**<br><sub>1655</sub> | `patient?`, `program?` | — | 🖥 `/api/immunizations/apply-program` 🧪 | Assign every vaccine in a program to the patient (bulk enrolment). |
| **`assign_vaccine`**<br><sub>1373</sub> | `patient?`, `immunization_template?`, `assigned_by?`, `appointment?`, `encounter?`, `company?`, `notes?`, `should_bill?` | — | 🖥 `/api/immunizations/assign` 🧪 | Assign a vaccine (Immunization Template) to a patient. |
| **`create_immunization`**<br><sub>213</sub> | `patient?`, `vaccine?`, `date_administered?`, `immunization_template?`, `scheduled_dose_label?`, `administered_by?`, `administration_site?`, `lot_number?` … +9 more | — | 🖥 `/api/immunizations` 🧪 | Record an administered vaccine dose. |
| **`create_immunization_program`**<br><sub>1559</sub> | `program_name?`, `description?`, `gender?`, `patient_age_from?`, `patient_age_to?`, `is_default?`, `disabled?`, `schedules?` | — | 🖥 `/api/immunizations/programs` 🧪 | Define a program: a named bundle of vaccine schedules. |
| **`create_immunization_template`**<br><sub>686</sub> | `template_name?`, `short_name?`, `vaccine?`, `category?`, `color?`, `aliases?`, `schedule_source?`, `doses?` | — | 🖥 `/api/immunizations/templates` 🧪 | Define a vaccine and its scheduled doses. |
| **`delete_immunization`**<br><sub>474</sub> | `name?` | — | 🖥 `/api/immunizations` 🧪 | _no docstring_ |
| **`delete_immunization_program`**<br><sub>1641</sub> | `name?` | — | 🖥 `/api/immunizations/programs` 🧪 | _no docstring_ |
| **`delete_immunization_template`**<br><sub>765</sub> | `name?` | — | 🖥 `/api/immunizations/templates` 🧪 | _no docstring_ |
| **`get_immunization`**<br><sub>195</sub> | `name?` | — | 🖥 `/api/immunizations` 🧪 | _no docstring_ |
| **`get_immunization_program`**<br><sub>1547</sub> | `name?` | — | 🧪 | _no docstring_ |
| **`get_immunization_schedule`**<br><sub>995</sub> | `patient?` | — | 🖥 `/api/immunizations/schedule` 🧪 | Immunization chart for a patient. |
| **`get_immunization_template`**<br><sub>674</sub> | `name?` | — | 🧪 | _no docstring_ |
| **`list_assigned_vaccines`**<br><sub>1333</sub> | `patient?`, `include_stopped?` | — | 🧪 | Vaccines assigned to a patient (Active only, unless include_stopped). |
| **`list_immunization_programs`**<br><sub>1531</sub> | `search?`, `include_disabled?` | — | 🖥 `/api/immunizations/programs` 🧪 | Named immunization programs (bundles of vaccine schedules). |
| **`list_immunization_templates`**<br><sub>649</sub> | `category?`, `search?`, `include_disabled?` | — | 🖥 `/api/immunizations/templates` 🧪 | The full vaccination schedule (each vaccine with its scheduled doses). |
| **`list_immunizations`**<br><sub>162</sub> | `patient?`, `search?`, `page?`, `page_size?` | — | 🖥 `/api/immunizations` 🧪 | List immunizations, newest first. |
| **`list_pending_vaccines`**<br><sub>1023</sub> | `patient?` | — | 🖥 `/api/immunizations/pending` 🧪 | Vaccines assigned to the patient that still have a dose to give, each with its NEXT pending dose. |
| **`list_vaccines`**<br><sub>492</sub> | `search?` | — | 🖥 `/api/vaccines` 🧪 | Vaccine options for the form — Items in the Vaccine item group. |
| **`unassign_vaccine`**<br><sub>1461</sub> | `name?` | — | 🧪 | Stop a vaccine assignment (status -> Stopped). |
| **`update_immunization`**<br><sub>420</sub> | `name?`, `patient?`, `vaccine?`, `date_administered?`, `immunization_template?`, `scheduled_dose_label?`, `administered_by?`, `administration_site?` … +8 more | — | 🖥 `/api/immunizations` 🧪 | Patch an immunization. Only non-None fields are written. |
| **`update_immunization_program`**<br><sub>1595</sub> | `name?`, `program_name?`, `description?`, `gender?`, `patient_age_from?`, `patient_age_to?`, `is_default?`, `disabled?` … +1 more | — | 🖥 `/api/immunizations/programs` 🧪 | Patch a program. `schedules`, if given, REPLACES the existing list. |
| **`update_immunization_template`**<br><sub>724</sub> | `name?`, `short_name?`, `vaccine?`, `category?`, `color?`, `aliases?`, `schedule_source?`, `disabled?` … +1 more | — | 🖥 `/api/immunizations/templates` 🧪 | Patch a template. |

### `api.v1.immunizations.report`

`remedisys_healthcare_ai/api/v1/immunizations/report.py` — 1 endpoint

> Immunization report — Phase 4, Screen 18. Frontend report: clinical/immunization-rates. Source is the custom Immunization shot-log doctype. Vaccines administered + breakdown by vaccine are real; panel coverage (coverage_pct, overdue, due_this_period, coverage_status, coverage_by_age) needs per-patient schedule computation across the whole panel and is stubbed in v1 — see docs/REPORTS_API.md §6 (#7

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_immunization_rates`**<br><sub>73</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Immunization · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.inbox.api`

`remedisys_healthcare_ai/api/v1/inbox/api.py` — 3 endpoints

> Inbox API — Phase 4 (operational work feed). Role-filtered "what needs my attention today" aggregator, spec'd as FD-BH-4 (front desk), NU-BH-5 (nurse), PR-BH-1 (practitioner) in docs/audit/*/screens/BACKEND_HANDOFFS.md. One shared query style, three whitelisted entry points — each role sees a different slice of clinic operations, none of it duplicating the personal-assignment feed that tasks.get_m

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_frontdesk_worklist`**<br><sub>265</sub> | `date?` | Patient Appointment · read | — | Front desk operational work feed (FD-BH-4). |
| **`get_nurse_worklist`**<br><sub>471</sub> | `date?` | Patient Appointment · read | — | Nurse clinical work feed (NU-BH-5). |
| **`get_practitioner_worklist`**<br><sub>648</sub> | — | Patient Encounter · read | — | Physician clinical inbox / work feed (PR-BH-1). |

### `api.v1.insurance.api`

`remedisys_healthcare_ai/api/v1/insurance/api.py` — 4 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`delete_patient_insurance_policy`**<br><sub>148</sub> | `name?` | Patient Insurance Policy · delete | 🖥 `/api/insurance` 🧪 | Delete a Patient Insurance Policy. |
| **`get_patient_insurance_policies`**<br><sub>26</sub> | `patient?` | Patient Insurance Policy · read | 🖥 `/api/insurance` 🧪 | List all insurance policies for a patient (active + expired). |
| **`list_insurance_payors`**<br><sub>166</sub> | — | Insurance Payor · read | 🖥 `/api/insurance/payors` 🧪 | Return all active Insurance Payors and their eligible plans. |
| **`save_patient_insurance_policy`**<br><sub>71</sub> | `patient?`, `insurance_payor?`, `policy_number?`, `insurance_plan?`, `effective_date?`, `expiry_date?`, `name?` | Patient Insurance Policy · write | 🖥 `/api/insurance` 🧪 | Create or update a Patient Insurance Policy. |

### `api.v1.insurance.report`

`remedisys_healthcare_ai/api/v1/insurance/report.py` — 1 endpoint

> Insurance reports — Phase 4, Screen 18. Frontend report: financial/claims-status. Source is the healthcare Insurance Claim doctype (Patient Insurance Coverage is currently empty). status → outcome bucket: approved (Completed) / pending (Draft, Submitted) / rejected (Cancelled, Error). Backend returns raw values with stable keys (frontend owns i18n labels/colors).

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_claims_status`**<br><sub>99</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Insurance Claim · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.labs.api`

`remedisys_healthcare_ai/api/v1/labs/api.py` — 12 endpoints

> Labs API. Read / catalog (Phase 1/2): list_lab_test_templates — paginated Lab Test Template master (catalog) list_patient_lab_tests — paginated Lab Test records for a patient get_lab_test — single Lab Test record with result items (+ abnormal flags) create_lab_order — create a Lab Test order from a template Result entry — M1, Service-Request-anchored spine (see docs/AI_LAB_REPORT_EXTRACTION.md): l

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`attach_lab_report`**<br><sub>648</sub> | `lab_test` | Lab Test · write | 🖥 `/api/labs/attach` | Attach one or more report files to a Draft Lab Test for a physician to read manually — the fallback for when whoever creates the order cannot enter the numeric values (e.g. |
| **`create_lab_order`**<br><sub>474</sub> | `patient`, `template`, `practitioner?`, `company?` | Lab Test · create | 🖥 `/api/labs` 🧪 | Create a Lab Test order from a Lab Test Template. |
| **`create_lab_parameter`**<br><sub>73</sub> | `parameter_name?`, `default_uom?`, `abbreviations?` | Lab Test Template · write | 🖥 `/api/labs/create-parameter` | Create a canonical Lab Parameter from the create-test autocomplete (mirrors the 'create new UOM from the picker' affordance). |
| **`get_lab_test`**<br><sub>455</sub> | `name` | Lab Test · read | 🖥 `/api/labs` 🧪 | Full Lab Test record including result items (normal_test_items). |
| **`get_lab_trends`**<br><sub>734</sub> | `patient`, `analyte?` | Lab Test · read | — | Per-analyte time series of a patient's lab results, for trend charts. |
| **`list_lab_test_templates`**<br><sub>143</sub> | `search?`, `department?`, `template_type?`, `page?`, `page_size?` | Lab Test Template · read | 🖥 `/api/labs/templates` 🧪 | Return a paginated list of active Lab Test Templates. |
| **`list_patient_lab_tests`**<br><sub>381</sub> | `patient`, `page?`, `page_size?`, `status?`, `search?` | Lab Test · read | 🖥 `/api/labs` 🧪 | Paginated list of Lab Tests for a patient, newest first. |
| **`list_pending_lab_orders`**<br><sub>535</sub> | `patient?`, `page?`, `page_size?` | Service Request · read | — | Lab Test Service Requests awaiting results (the order worklist). |
| **`record_imaging_result`**<br><sub>714</sub> | `lab_test`, `transcribed_report` | Lab Test · write | 🖥 `/api/labs/imaging-result` | Manual entry for an Imaging-type Lab Test (ADR-019 gap G14b). |
| **`record_result`**<br><sub>616</sub> | `results`, `service_request?`, `lab_test?` | Lab Test · write | 🖥 `/api/labs/results` 📘 | Write result values onto a Draft Lab Test (does not finalize — Rule 6). |
| **`search_lab_parameters`**<br><sub>44</sub> | `query?`, `limit?` | Lab Parameter · read | 🖥 `/api/labs/search-parameters` | Autocomplete source for the Lab Test Template authoring screen (ADR-028): canonical Lab Parameters whose name OR abbreviations match the typed query, returning the default unit … |
| **`submit_lab_result`**<br><sub>700</sub> | `lab_test` | Lab Test · submit | 🖥 `/api/labs/submit` | Submit a Draft Lab Test — the physician finalizes the reading (Rule 6). |

### `api.v1.messages.api`

`remedisys_healthcare_ai/api/v1/messages/api.py` — 6 endpoints

> Team Chat API — internal staff-to-staff messaging (ADR-015). Backs the "Team" tab of the clinic chat widget. Patient/WhatsApp chat is a separate system (api/v1/notifications/api.py); this module never touches it. Doctypes: Chat Thread (+ Chat Thread Participant child) and Chat Message. Endpoints: list_threads — threads the current user belongs to, newest first get_thread — one thread header + full

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_thread`**<br><sub>197</sub> | `thread` | — | 🖥 `/api/messages/[id]` | Thread header + full message history. Stamps the caller's read cursor. |
| **`list_contacts`**<br><sub>357</sub> | `search?` | — | 🖥 `/api/messages/contacts` | Staff the current user can start a chat with (all enabled staff, minus self). |
| **`list_threads`**<br><sub>143</sub> | `page?`, `page_size?` | — | 🖥 `/api/messages` | Threads the current user belongs to, ordered by most recent activity. |
| **`mark_read`**<br><sub>342</sub> | `thread` | — | 🖥 `/api/messages/[id]/read` 📘 | Move the caller's read cursor to now (clears their unread badge). |
| **`send_message`**<br><sub>250</sub> | `thread`, `content` | — | 🖥 `/api/messages/[id]/messages` 📘 | Post a text message to a thread the caller belongs to. |
| **`start_thread`**<br><sub>292</sub> | `participants`, `title?`, `is_group?` | — | 🖥 `/api/messages` | Open a chat. |

### `api.v1.narzim_assistant.api`

`remedisys_healthcare_ai/api/v1/narzim_assistant/api.py` — 5 endpoints

> Narzim AI — general assistant API (sidebar feature, not the encounter copilot in api/v1/ai/api.py). Patient- and encounter-agnostic medication/clinical- knowledge Q&A, with optional PDF upload. See docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md for the full design. send_message — one turn of the assistant (text, optionally with a PDF attached as multipart form-data under "file") list_threads — this user's 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_thread`**<br><sub>73</sub> | `thread?` | AI Narzim Assistant Message · read | 🖥 `/api/ai/narzim-assistant/thread` | Replay one thread's messages. |
| **`get_usage_summary`**<br><sub>91</sub> | `from_date?`, `to_date?` | — | — | Admin-only: per-user token/cost breakdown for this assistant. |
| **`list_threads`**<br><sub>65</sub> | — | AI Narzim Assistant Message · read | 🖥 `/api/ai/narzim-assistant/threads` | This user's own conversation threads, newest activity first. |
| **`send_message`**<br><sub>42</sub> | `thread`, `message?` | AI Narzim Assistant Message · create | 🖥 `/api/ai/narzim-assistant/send` 📘 | One turn of the general Narzim AI assistant. |
| **`set_feedback`**<br><sub>82</sub> | `message`, `feedback?`, `note?` | AI Narzim Assistant Message · write | 🖥 `/api/ai/narzim-assistant/feedback` | Thumbs up/down (+ optional note) on one of this user's own assistant replies. |

### `api.v1.notes.api`

`remedisys_healthcare_ai/api/v1/notes/api.py` — 9 endpoints

> Notes API — Phase 1 (personal / clinic notes). CRUD over the Frappe core `Note` doctype (no custom doctype is introduced — same upgrade-safe choice as the ToDo/Task work queue). Backs the "My Work" screen's Shift Notes panel, replacing its sessionStorage-only scratchpad with persistent, owner-scoped notes. Scoping rule (mirrors get_my_tasks): - Normal users list only the notes they own. - "Admin" 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_note`**<br><sub>78</sub> | `title?`, `content?`, `public?` | Note · create | 🖥 `/api/my-work/notes` 🧪 | Create a Note. |
| **`delete_note`**<br><sub>207</sub> | `name?` | Note · delete | 🖥 `/api/my-work/notes` 🧪 | _no docstring_ |
| **`get_note`**<br><sub>109</sub> | `name?` | Note · read | 🧪 | _no docstring_ |
| **`list_note_shares`**<br><sub>264</sub> | `name?` | Note · read | 🖥 `/api/my-work/notes/shares` | Everyone this note is currently shared with — specific users, plus whether there's an "everyone on the team" grant. |
| **`list_notes`**<br><sub>121</sub> | `search?`, `public?`, `scope?`, `page?`, `page_size?` | Note · read | 🖥 `/api/my-work/notes` 🧪 | List notes. |
| **`list_shareable_users`**<br><sub>246</sub> | — | — | 🖥 `/api/my-work/notes/shareable-users` | Enabled users a note could be shared with — deliberately not gated on User-doctype read permission, which most clinic roles don't hold. |
| **`share_note`**<br><sub>280</sub> | `name?`, `user?`, `everyone?` | Note · write | 🖥 `/api/my-work/notes/shares` | Grant read access — to one specific person, or to everyone on the team (DocShare's own `everyone` flag; see get_shared's or_filters). |
| **`unshare_note`**<br><sub>307</sub> | `name?`, `user?`, `everyone?` | Note · write | 🖥 `/api/my-work/notes/shares` | Revoke a share — a specific person, or the "everyone" grant. |
| **`update_note`**<br><sub>174</sub> | `name?`, `title?`, `content?`, `public?` | Note · write | 🖥 `/api/my-work/notes` 🧪 | Patch a Note. |

### `api.v1.notifications.api`

`remedisys_healthcare_ai/api/v1/notifications/api.py` — 17 endpoints

> Notifications API — Frappe Notification Log + WhatsApp conversation inbox. Endpoints: list_notifications — paginated list for the logged-in user get_unread_count — fast unread badge count mark_read — mark one notification as read mark_all_read — mark all as read for the logged-in user get_whatsapp_conversations — WhatsApp staff inbox (conversation list) get_whatsapp_conversation — full thread for 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`assign_whatsapp_conversation`**<br><sub>896</sub> | `name`, `assignee` | — | 🖥 `/api/whatsapp/conversations/[id]/assign` | Assign a conversation to a staff member (admin + system manager only). |
| **`close_whatsapp_conversation`**<br><sub>426</sub> | `name` | — | 🖥 `/api/whatsapp/conversations/[id]/close` | Mark a WhatsApp conversation as Closed. |
| **`get_notification_counts`**<br><sub>139</sub> | — | — | 🖥 `/api/notifications` | Per-tab totals for the /notifications screen. |
| **`get_unread_count`**<br><sub>153</sub> | — | — | 🖥 `/api/notifications` 🧪 | Return the count of unread notifications for the current user. |
| **`get_whatsapp_availability`**<br><sub>266</sub> | — | — | 🖥 `/api/whatsapp/availability` | Whether WhatsApp messaging is available for the clinic. |
| **`get_whatsapp_conversation`**<br><sub>344</sub> | `name` | — | 🖥 `/api/whatsapp/conversations/[id]` | Return conversation header + full message thread. |
| **`get_whatsapp_conversations`**<br><sub>282</sub> | `page?`, `page_size?`, `status?`, `search?`, `patient?` | — | 🖥 `/api/whatsapp/conversations` | Paginated WhatsApp conversation list for the staff inbox. |
| **`list_notifications`**<br><sub>105</sub> | `page?`, `page_size?`, `unread_only?`, `document_type?` | — | 🖥 `/api/notifications` 🧪 📘 | Paginated Notification Log entries for the current user, newest first. |
| **`list_whatsapp_assignees`**<br><sub>857</sub> | — | — | 🖥 `/api/whatsapp/assignees` | Staff who can be assigned a WhatsApp conversation. |
| **`list_whatsapp_templates`**<br><sub>812</sub> | — | — | 🖥 `/api/whatsapp/templates` | Manual WhatsApp templates for the staff chat picker, sourced from the Remedisys WhatsApp Notification configs (trigger_type = Manual, enabled). |
| **`mark_all_read`**<br><sub>178</sub> | — | — | 🖥 `/api/notifications` 🧪 | Mark all unread Notification Log entries as read for the current user. |
| **`mark_read`**<br><sub>164</sub> | `name` | — | 🖥 `/api/notifications` 🧪 📘 | Mark a single Notification Log entry as read. |
| **`send_encounter_summary_whatsapp`**<br><sub>729</sub> | `encounter`, `file_data`, `notification?`, `filename?` | — | 🖥 `/api/whatsapp/encounters/[id]/send-summary` | Send a signed Patient Encounter to the patient over WhatsApp: an approved text template first (opens/extends the 24h window and notifies the patient), then a PDF as a follow-up … |
| **`send_whatsapp_media`**<br><sub>658</sub> | `name`, `file_data`, `mime_type`, `filename?`, `caption?` | — | 🖥 `/api/whatsapp/conversations/[id]/send-media` | Send a media attachment (image, document, video, audio) within the 24-hour window. |
| **`send_whatsapp_reply`**<br><sub>442</sub> | `name`, `message` | — | 🖥 `/api/whatsapp/conversations/[id]/reply` | Send a free-text reply within the 24-hour Meta session window. |
| **`send_whatsapp_template`**<br><sub>480</sub> | `name`, `template_name?`, `language?`, `variables?`, `notification?` | — | 🖥 `/api/whatsapp/conversations/[id]/send-template` | Send a pre-approved WhatsApp template (works regardless of 24h window). |
| **`start_whatsapp_conversation`**<br><sub>533</sub> | `patient?`, `phone?`, `message?`, `template_name?`, `language?`, `variables?`, `notification?` | — | 🖥 `/api/whatsapp/start` | Initiate a WhatsApp conversation from the clinic side (cold start). |

### `api.v1.nursing.api`

`remedisys_healthcare_ai/api/v1/nursing/api.py` — 14 endpoints

> Nursing Task API — an assigned nursing activity to be performed and tracked (monitor BP, administer medication, dressing change), per the Marley guide. Wraps the ERPNext Healthcare `Nursing Task` doctype (Rule 1 — never patch core). Standalone tasks (not generated from a checklist template) are created here. Lifecycle (ERPNext): Draft -> (submit) Requested -> work transitions (Received/Accepted/Re

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`assign_nursing_task`**<br><sub>456</sub> | `patient?`, `activity?`, `user?`, `notes?`, `requested_start_time?`, `company?`, `service_unit?`, `medical_department?` … +2 more | — | 🖥 `/api/nursing/tasks` | A doctor hands a single, named nurse a clinical task — create AND submit a Nursing Task in one transaction, so it lands in Requested and shows up on that nurse's worklist immedi… |
| **`cancel_nursing_task`**<br><sub>767</sub> | `name?` | — | 🧪 | Cancel a task: delete if still Draft, otherwise set Cancelled. |
| **`create_healthcare_activity`**<br><sub>184</sub> | `activity?`, `description?`, `role?`, `task_doctype?`, `activity_duration?` | Healthcare Activity · create | 🖥 `/api/admin/healthcare-activities` 🧪 | Create a Healthcare Activity (the master a Nursing Task picks from). |
| **`create_nursing_task`**<br><sub>390</sub> | `patient?`, `activity?`, `company?`, `service_unit?`, `medical_department?`, `user?`, `requested_start_time?`, `requested_end_time?` … +5 more | — | 🧪 📘 | Create a standalone Nursing Task (Draft). |
| **`delete_healthcare_activity`**<br><sub>274</sub> | `name?` | Healthcare Activity · delete | 🖥 `/api/admin/healthcare-activities` 🧪 | _no docstring_ |
| **`get_healthcare_activity`**<br><sub>224</sub> | `name?` | Healthcare Activity · read | 🧪 | _no docstring_ |
| **`get_nursing_task`**<br><sub>344</sub> | `name?` | — | 🧪 | _no docstring_ |
| **`list_healthcare_activities`**<br><sub>167</sub> | `search?` | Healthcare Activity · read | 🖥 `/api/admin/healthcare-activities` `/api/nursing/activities` 🧪 | Healthcare Activity master — the activity picker for a nursing task. |
| **`list_nurse_users`**<br><sub>356</sub> | `search?` | — | 🖥 `/api/nursing/nurses` | Enabled users holding EB_Nurse — the assignee pool for assign_nursing_task. |
| **`list_nursing_tasks`**<br><sub>300</sub> | `patient?`, `status?`, `user?`, `service_unit?`, `reference_doctype?`, `reference_name?`, `date_from?`, `date_to?` … +2 more | — | 🖥 `/api/nursing/tasks` 🧪 📘 | _no docstring_ |
| **`submit_nursing_task`**<br><sub>624</sub> | `name?` | — | 🧪 | Submit a Draft task (docstatus 0 -> 1); core sets status to Requested. |
| **`update_healthcare_activity`**<br><sub>236</sub> | `name?`, `description?`, `role?`, `task_doctype?`, `activity_duration?` | Healthcare Activity · write | 🖥 `/api/admin/healthcare-activities` 🧪 | Patch a Healthcare Activity. |
| **`update_nursing_task`**<br><sub>568</sub> | `name?`, `activity?`, `service_unit?`, `medical_department?`, `user?`, `requested_start_time?`, `requested_end_time?`, `duration?` … +4 more | — | 🧪 | Patch a DRAFT nursing task. Submitted tasks use the status endpoint. |
| **`update_nursing_task_status`**<br><sub>727</sub> | `name?`, `status?`, `task_document_name?`, `notes?` | — | 🖥 `/api/nursing/tasks/[name]/status` 🧪 | Move a submitted task through the work states (In Progress, On Hold, Completed, Failed, ...). |

### `api.v1.patient_portal.api`

`remedisys_healthcare_ai/api/v1/patient_portal/api.py` — 28 endpoints

> Patient Portal API — Phase 1 (self-service auth, home, appointments, health record). Every endpoint here is scoped to the CALLING PATIENT ONLY. `EB_Patient` has a coarse role grant on Patient Appointment (create/read/write), Patient Medical Record (create/read/write — uploaded documents, shared storage with the staff Documents tab), Patient itself (read/write), and read-only grants on Patient Enco

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`add_my_allergy`**<br><sub>860</sub> | `allergy?` | — | — | Add an allergy to the caller's own Patient.allergies (idempotent, add-only). |
| **`add_my_condition`**<br><sub>871</sub> | `condition?` | — | — | Add a condition to the caller's own Patient.medical_history (idempotent, add-only). |
| **`add_my_medication`**<br><sub>881</sub> | `medication?` | — | — | Add a medication to the caller's own Patient.medication (idempotent, add-only). |
| **`book_my_appointment`**<br><sub>610</sub> | `company?`, `practitioner?`, `appointment_date?`, `appointment_time?`, `appointment_type?`, `notes?`, `# Only "pay_later" is supported today — the patient portal has no # pay-now/online-payment flow yet (see appointments.api.book_appointment_for_patient # on the staff side, which already supports pay_now/insurance). Accepting # the param now`, `and rejecting anything else` … +1 more | — | 🖥 `/api/appointments` | _no docstring_ |
| **`cancel_my_appointment`**<br><sub>662</sub> | `appointment?`, `reason?` | — | 🖥 `/api/appointments/[id]` | _no docstring_ |
| **`get_my_account`**<br><sub>274</sub> | — | — | 🖥 `/api/auth/login` `/api/auth/me` | Profile + MRN for the logged-in patient (auth-context bootstrap). |
| **`get_my_appointment`**<br><sub>456</sub> | `appointment?` | — | — | _no docstring_ |
| **`get_my_available_slots`**<br><sub>469</sub> | `practitioner?`, `date?` | — | 🖥 `/api/appointments/slots` | Bookable slots for a practitioner/date — same computation as appointments.api.get_available_slots, but with per-slot patient identity (other patients' names) stripped: a patient… |
| **`get_my_clinical_summary`**<br><sub>823</sub> | — | — | — | The caller's own stored AI Patient Clinical Summary (ADR-029), for the portal Home page. |
| **`get_my_encounter`**<br><sub>1006</sub> | `encounter?` | — | 🖥 `/api/visits/[kind]/[id]` | _no docstring_ |
| **`get_my_health_record`**<br><sub>744</sub> | — | — | 🖥 `/api/health` | Aggregated allergies / conditions / medications / immunizations. |
| **`get_my_lab_result_summary`**<br><sub>937</sub> | `lab_test?` | Lab Test · read | — | The caller's own Lab Test's stored AI result-interpretation summary. |
| **`get_my_lab_test`**<br><sub>920</sub> | `name?` | — | 🖥 `/api/visits/[kind]/[id]` | _no docstring_ |
| **`get_my_next_follow_up`**<br><sub>1035</sub> | — | — | — | Soonest still-open follow-up request across all of the caller's encounters — feeds the portal Home page's "Next follow-up" card. |
| **`list_appointment_types`**<br><sub>415</sub> | — | — | — | Appointment Type is a real Link field on Patient Appointment — the booking wizard's "purpose of visit" step must offer these exact values, not arbitrary free text. |
| **`list_clinics`**<br><sub>330</sub> | — | — | — | Every clinic (Company) on the platform — the booking wizard's clinic step. |
| **`list_doctor_profiles`**<br><sub>397</sub> | `company?` | — | — | Active practitioners at a clinic with their full self-service Doctor Profile merged in — the Doctors directory's data source. |
| **`list_my_appointments`**<br><sub>430</sub> | `status?` | — | 🖥 `/api/appointments` | status is a portal TAB, not a raw doctype value — there is no single "Upcoming" status in Patient Appointment (see appointments.api's _STATUS_FE_TO_ERP): "upcoming" means anythi… |
| **`list_my_document_categories`**<br><sub>1080</sub> | — | — | — | _no docstring_ |
| **`list_my_documents`**<br><sub>1086</sub> | `category?`, `search?` | — | — | _no docstring_ |
| **`list_my_encounters`**<br><sub>966</sub> | `page?`, `page_size?` | — | 🖥 `/api/visits` | Signed (submitted) visit reports only — a draft encounter isn't a finalized report yet and shouldn't be shown to the patient. |
| **`list_my_lab_tests`**<br><sub>898</sub> | `page?`, `page_size?` | — | 🖥 `/api/visits` | _no docstring_ |
| **`list_my_vital_signs`**<br><sub>1122</sub> | `page?`, `page_size?` | — | — | _no docstring_ |
| **`list_practitioners`**<br><sub>345</sub> | `company?` | — | — | Active practitioners who hold a schedule at a company's service units — the booking wizard's practitioner step, scoped to the chosen clinic. |
| **`register`**<br><sub>121</sub> | `full_name?`, `sex?`, `dob?`, `mobile?`, `id_type?`, `id_number?`, `email?`, `password?` | — | 🖥 `/api/auth/register` 📘 🌐 | Self-service patient signup. |
| **`reschedule_my_appointment`**<br><sub>706</sub> | `appointment?`, `appointment_date?`, `appointment_time?` | — | 🖥 `/api/appointments/[id]` | _no docstring_ |
| **`update_my_account`**<br><sub>282</sub> | `full_name?`, `sex?`, `dob?`, `blood_group?`, `mobile?`, `email?` | — | — | Patient self-service edit of their own basic profile — the portal's Settings > Personal information card only (no address, no ID/MRN — those stay read-only on this surface). |
| **`upload_my_document`**<br><sub>1093</sub> | `category?` | — | — | Upload a file against the caller's own patient record. |

### `api.v1.patient_portal.chat`

`remedisys_healthcare_ai/api/v1/patient_portal/chat.py` — 4 endpoints

> Patient Portal API — Portal Chat (ADR-037; supersedes ADR-036). Portal Chat is fully independent of WhatsApp: every message here is a `Portal Message` linked to a `Portal Conversation`. Nothing in this module ever touches `WhatsApp Message`, `WhatsApp Conversation`, or any WhatsApp Business API credential — a portal reply is a plain database write, never a call to Meta. `EB_Patient` has a coarse r

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_my_chat_unread_count`**<br><sub>141</sub> | — | — | — | How many clinic messages the patient has not seen. |
| **`get_my_conversation`**<br><sub>103</sub> | — | — | — | Return the patient's own portal conversation with the clinic, if any. |
| **`list_my_chat_messages`**<br><sub>175</sub> | `page?`, `page_size?` | — | — | Paginated message history for the patient's own conversation, oldest first. |
| **`send_my_chat_message`**<br><sub>239</sub> | `message?` | — | — | Patient sends a message — recorded as a Portal Message under the patient's own identity. |

### `api.v1.patient_portal.portal_chat`

`remedisys_healthcare_ai/api/v1/patient_portal/portal_chat.py` — 4 endpoints

> Portal Chat API — staff-facing side (ADR-037). Independent of WhatsApp: this module only ever reads/writes `Portal Conversation` and `Portal Message`. No WhatsApp Business API call, no `WhatsApp Account` credential, appears anywhere in this file — a staff reply here is a plain database write, delivered to the patient the next time they open or refresh the Patient Portal chat screen, never pushed t

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_portal_conversation`**<br><sub>175</sub> | `conversation` | — | 🖥 `/api/portal-chat/conversations/[id]` | Full thread: conversation header + all Portal Messages, oldest first. |
| **`list_portal_conversations`**<br><sub>131</sub> | `status?`, `assigned_to?`, `patient?`, `page?`, `page_size?` | — | 🖥 `/api/portal-chat/conversations` | Staff inbox for Portal Chat — shared, not assignment-gated (same model as WhatsApp). |
| **`send_portal_message`**<br><sub>214</sub> | `conversation`, `content?` | — | 🖥 `/api/portal-chat/conversations/[id]/reply` | Staff reply — a plain Portal Message insert. |
| **`start_portal_conversation`**<br><sub>247</sub> | `patient`, `message?` | — | 🖥 `/api/portal-chat/start` | Initiate a Portal Chat conversation from the clinic side (cold start). |

### `api.v1.patients.api`

`remedisys_healthcare_ai/api/v1/patients/api.py` — 17 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`add_guardian`**<br><sub>1721</sub> | `patient`, `guardian_name`, `relation?`, `mobile?`, `email?`, `is_primary?`, `is_billable?`, `address_line1?` … +6 more | Patient · write | 🖥 `/api/patients/[id]/guardians` `/api/patients/guardian` 🧪 | Add a single guardian to an existing patient. |
| **`create_patient`**<br><sub>82</sub> | `# --- Demographics (required) --- first_name`, `gender`, `# --- Demographics (optional) --- last_name?`, `middle_name?`, `dob?`, `blood_group?`, `uid?`, `image?` … +31 more | — | 🖥 `/api/patients` 🧪 📘 | _no docstring_ |
| **`get_genders`**<br><sub>1964</sub> | — | — | 🖥 `/api/patients/genders` 🧪 🌐 | Return all Gender options in alphabetical order. |
| **`get_patient`**<br><sub>1282</sub> | `name` | Patient · read | 🖥 `/api/patients` 🧪 📘 | Full patient record for the Patient 360 chart header / demographics. |
| **`get_patient_chart_overview`**<br><sub>2091</sub> | `patient` | Patient · read | 🖥 `/api/patients` 🧪 | Patient Chart 360 — Overview tab. |
| **`get_patient_clinical_activity`**<br><sub>2555</sub> | `patient`, `limit?` | Patient · read | 🧪 | Patient Chart 360 — clinical activity feed for a patient. |
| **`get_patient_immunizations`**<br><sub>2433</sub> | `patient` | Patient · read | — | Patient Chart 360 — Immunizations tab. |
| **`get_patient_medications`**<br><sub>2274</sub> | `patient` | Patient · read | 🖥 `/api/patients/[id]/medications` 🧪 | Patient Chart 360 — Medications tab. |
| **`get_patient_visits`**<br><sub>2122</sub> | `patient`, `page?`, `page_size?` | Patient · read | 🖥 `/api/patients/[id]/visits` 🧪 | Patient Chart 360 — Visits tab. |
| **`get_patients`**<br><sub>1247</sub> | `page?`, `page_size?`, `search?`, `status?`, `gender?`, `filter_today?`, `filter_new?`, `filter_balance_due?` … +5 more | — | 📘 | Alias for list_patients — matches the frontend method name. |
| **`list_favorite_patients`**<br><sub>2623</sub> | — | Patient · read | 🖥 `/api/patients/favorites` | Return the Patient IDs the current user has favorited. |
| **`list_patients`**<br><sub>1007</sub> | `page?`, `page_size?`, `search?`, `status?`, `gender?`, `filter_today?`, `filter_new?`, `filter_balance_due?` … +5 more | Patient · read | 🖥 `/api/patients` 🧪 📘 | Paginated patient directory. |
| **`remove_guardian`**<br><sub>1774</sub> | `patient`, `contact` | Patient · write | 🖥 `/api/patients/[id]/guardians` `/api/patients/guardian` 🧪 | Remove a guardian Contact (and its linked Address) from a patient. |
| **`toggle_favorite_patient`**<br><sub>2603</sub> | `patient` | Patient · read | 🖥 `/api/patients/[id]/favorite` | Toggle the current user's favorite marker on a Patient record. |
| **`update_guardian`**<br><sub>1847</sub> | `patient`, `contact`, `guardian_name?`, `relation?`, `mobile?`, `email?`, `is_primary?`, `is_billable?` … +7 more | Patient · write | 🖥 `/api/patients/[id]/guardians` | Update a guardian Contact (and its linked Address) for a patient. |
| **`update_medication_status`**<br><sub>2354</sub> | `patient`, `drug_prescription`, `status`, `note?` | Patient · write | 🖥 `/api/patients/[id]/medications` | Stop, hold, or resume a medication from the Patient Chart 360 Medications tab. |
| **`update_patient`**<br><sub>1488</sub> | `name`, `first_name?`, `last_name?`, `middle_name?`, `gender?`, `dob?`, `blood_group?`, `uid?` … +28 more | — | 🖥 `/api/patients` `/api/patients/[id]` 🧪 📘 | Staff-facing patch of a patient — full field surface. |

### `api.v1.prescriptions.api`

`remedisys_healthcare_ai/api/v1/prescriptions/api.py` — 3 endpoints

> Prescriptions API — Phase 1/2. Endpoints: list_medications — paginated Medication master (catalog for encounter form) list_patient_prescriptions — paginated drug prescription history for a patient

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_item_preview`**<br><sub>235</sub> | `item_code?` | Item · read | 🖥 `/api/items/preview` | Lightweight Item preview for the encounter Drug Code link-hover card. |
| **`list_medications`**<br><sub>56</sub> | `search?`, `page?`, `page_size?` | Medication · read | 🖥 `/api/encounters/medications` 🧪 📘 | Return a paginated list of active Medications. |
| **`list_patient_prescriptions`**<br><sub>197</sub> | `patient`, `page?`, `page_size?` | Patient Encounter · read | 🧪 | Paginated drug prescription history for a patient. |

### `api.v1.procedures.api`

`remedisys_healthcare_ai/api/v1/procedures/api.py` — 12 endpoints

> Clinical Procedure API — record a medical procedure that was performed on a patient (wound dressing, suturing, sample collection, minor surgery, injection), per the Marley clinical guide. Wraps the ERPNext Healthcare `Clinical Procedure` doctype (Rule 1 — never patch core). Scope is the "record what was performed" model: pick a procedure template, who performed it, when, and the outcome. Inventory

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`cancel_clinical_procedure`**<br><sub>564</sub> | `name?` | — | 🧪 | Cancel a SUBMITTED procedure (docstatus 1 -> 2, status Cancelled). |
| **`complete_clinical_procedure`**<br><sub>532</sub> | `name?`, `outcome_notes?` | — | 🧪 | Mark the procedure Completed (core complete_procedure: sets actual end time, creates post-op Nursing Tasks from the template). |
| **`create_clinical_procedure`**<br><sub>347</sub> | `patient?`, `procedure_template?`, `practitioner?`, `medical_department?`, `service_unit?`, `company?`, `appointment?`, `start_date?` … +6 more | — | 🧪 | Create a Clinical Procedure (Draft). |
| **`get_clinical_procedure`**<br><sub>322</sub> | `name?` | — | 🧪 | _no docstring_ |
| **`get_procedure_template`**<br><sub>207</sub> | `template?` | Clinical Procedure Template · read | 🧪 | Template detail used to prefill the create form (department, billable, etc.). |
| **`list_clinical_procedures`**<br><sub>274</sub> | `patient?`, `practitioner?`, `status?`, `procedure_template?`, `date_from?`, `date_to?`, `company?`, `page?` … +1 more | — | 🧪 | _no docstring_ |
| **`list_items`**<br><sub>242</sub> | `search?`, `item_group?` | Item · read | 🖥 `/api/billing/items` 🧪 | Item master picker for procedure consumables (enabled items). |
| **`list_procedure_templates`**<br><sub>184</sub> | `search?`, `department?` | Clinical Procedure Template · read | 🖥 `/api/procedures/templates` 🧪 | Catalog of Clinical Procedure Templates for the procedure picker. |
| **`list_therapy_types`**<br><sub>593</sub> | `search?`, `department?` | Therapy Type · read | 🖥 `/api/therapies/types` | Catalog of Therapy Types for the rehabilitation/therapy picker. |
| **`start_clinical_procedure`**<br><sub>513</sub> | `name?` | — | — | Mark a submitted procedure In Progress (core start_procedure: sets actual start time and validates that mandatory Nursing Tasks are complete). |
| **`submit_clinical_procedure`**<br><sub>495</sub> | `name?` | — | 🧪 | Submit a Draft procedure (docstatus 0 -> 1, status Pending). |
| **`update_clinical_procedure`**<br><sub>451</sub> | `name?`, `practitioner?`, `medical_department?`, `service_unit?`, `start_date?`, `start_time?` | — | 🧪 | Patch a DRAFT clinical procedure. |

### `api.v1.providers.api`

`remedisys_healthcare_ai/api/v1/providers/api.py` — 7 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_departments`**<br><sub>104</sub> | — | Medical Department · read | — | List Medical Departments that belong to this clinic (show_in_portal = 1). |
| **`get_my_provider_profile`**<br><sub>182</sub> | — | — | 🖥 `/api/providers/me` | Fetch the logged-in practitioner's own full profile (basics + Doctor Profile). |
| **`get_provider`**<br><sub>73</sub> | `practitioner?` | Healthcare Practitioner · read | 🧪 📘 | Fetch a single Healthcare Practitioner with their schedule links. |
| **`get_provider_detail`**<br><sub>89</sub> | `name?` | Healthcare Practitioner · read | 🖥 `/api/healthcare/practitioners` `/api/providers` 🧪 📘 | Fetch a single Healthcare Practitioner by name. |
| **`get_providers`**<br><sub>22</sub> | `service_unit?`, `schedule?`, `department?`, `has_schedule?`, `page?`, `page_size?` | Healthcare Practitioner · read | 🖥 `/api/healthcare/practitioners` `/api/providers` 🧪 📘 | List active Healthcare Practitioners with optional filters. |
| **`get_service_units`**<br><sub>126</sub> | `company?` | Healthcare Service Unit · read | 🖥 `/api/providers/service-units` 🧪 📘 | List Healthcare Service Units optionally filtered by company. |
| **`update_my_provider_profile`**<br><sub>193</sub> | `about?`, `sub_specialty?`, `years_of_experience?`, `languages_spoken?`, `qualifications?`, `certifications?`, `work_experience?` | — | 🖥 `/api/providers/me` | Patch the logged-in practitioner's own Doctor Profile. |

### `api.v1.providers.report`

`remedisys_healthcare_ai/api/v1/providers/report.py` — 2 endpoints

> Provider-performance reports — Phase 4, Screen 18. Lives with the providers module. Frontend reports: providers/patient-volume, providers/utilization-rate. (average-visit-time lives with the encounters module; patient-satisfaction needs a feedback doctype — see docs/REPORTS_API.md §6.)

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_patient_volume`**<br><sub>115</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |
| **`get_utilization_rate`**<br><sub>321</sub> | `period?`, `date_from?`, `date_to?`, `practitioner?`, `department?`, `company?` | Patient Appointment · read | 🖥 `/api/reports/[report]` | _no docstring_ |

### `api.v1.tasks.api`

`remedisys_healthcare_ai/api/v1/tasks/api.py` — 18 endpoints

> Tasks API — Phase 1 (operational work queue). get_my_tasks — the logged-in user's pending work, aggregated across four CORE doctypes (no custom doctype is introduced) into one normalised feed. Every row carries exactly ONE `assigned_to` (single-assignee product rule — see ADR-041) and, where the doctype has a signal for it, one `assigned_by`: Task (ERPNext core) assigned via `_assign` (-> Users; f

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`add_todo_comment`**<br><sub>739</sub> | `name?`, `content?` | ToDo · read | 🖥 `/api/my-work/todos/comments` | Attributed to the real session user regardless of anything the caller passes; Frappe core's own add_comment trusts comment_email/comment_by verbatim, so we don't reuse it direct… |
| **`create_task`**<br><sub>931</sub> | `subject?`, `description?`, `priority?`, `status?`, `exp_start_date?`, `exp_end_date?`, `project?`, `department?` … +1 more | Task · create | 🧪 | Create a Task. |
| **`create_todo`**<br><sub>485</sub> | `description?`, `allocated_to?`, `date?`, `priority?`, `reference_type?`, `reference_name?`, `color?` | ToDo · create | 🖥 `/api/my-work/todos` `/api/patients/[id]/todos` 🧪 | Create a ToDo (reminder/assignment). |
| **`delete_task`**<br><sub>1054</sub> | `name?` | Task · delete | 🧪 | _no docstring_ |
| **`delete_todo`**<br><sub>658</sub> | `name?` | ToDo · delete | 🖥 `/api/my-work/todos` 🧪 | _no docstring_ |
| **`delete_todo_attachment`**<br><sub>860</sub> | `file_id?`, `todo_name?` | ToDo · read | 🖥 `/api/my-work/todos/attachments` | See update_todo_comment for why `todo_name` exists. |
| **`delete_todo_comment`**<br><sub>799</sub> | `name?`, `todo_name?` | ToDo · read | 🖥 `/api/my-work/todos/comments` | The comment's own author, or the task's creator/assignee/admin (moderation), may delete a comment. |
| **`get_my_tasks`**<br><sub>355</sub> | `task_type?`, `include_closed?` | ToDo · read | 🖥 `/api/my-work` 🧪 | Return the logged-in user's pending tasks across Task, ToDo, Nursing Task and Clinical Procedure. |
| **`get_task`**<br><sub>976</sub> | `name?` | Task · read | 🧪 | _no docstring_ |
| **`get_todo`**<br><sub>527</sub> | `name?` | ToDo · read | 🖥 `/api/my-work/todos` 🧪 | _no docstring_ |
| **`list_tasks`**<br><sub>988</sub> | `status?`, `priority?`, `project?`, `department?`, `page?`, `page_size?` | Task · read | 🧪 | _no docstring_ |
| **`list_todo_attachments`**<br><sub>824</sub> | `name?` | ToDo · read | — | _no docstring_ |
| **`list_todo_comments`**<br><sub>727</sub> | `name?` | ToDo · read | — | _no docstring_ |
| **`list_todos`**<br><sub>543</sub> | `allocated_to?`, `owner?`, `status?`, `priority?`, `reference_type?`, `reference_name?`, `page?`, `page_size?` | ToDo · read | 🖥 `/api/my-work/todos` `/api/patients/[id]/todos` 🧪 | _no docstring_ |
| **`update_task`**<br><sub>1013</sub> | `name?`, `subject?`, `description?`, `priority?`, `status?`, `exp_start_date?`, `exp_end_date?`, `project?` … +1 more | Task · write | 🧪 | Patch a Task. Only non-None fields are written; status changes the state. |
| **`update_todo`**<br><sub>582</sub> | `name?`, `description?`, `allocated_to?`, `date?`, `priority?`, `status?`, `reference_type?`, `reference_name?` … +1 more | ToDo · write | 🖥 `/api/my-work/todos` 🧪 | Patch a ToDo. |
| **`update_todo_comment`**<br><sub>770</sub> | `name?`, `content?`, `todo_name?` | ToDo · read | 🖥 `/api/my-work/todos/comments` | Only the comment's own author may edit it — matches Frappe core's own update_comment convention. |
| **`upload_todo_attachment`**<br><sub>836</sub> | `name?` | ToDo · read | 🖥 `/api/my-work/todos/attachments` | The file arrives as multipart form-data under the key "file"; `name` is a regular form field (mapped to this kwarg by Frappe). |

### `api.v1.vital_signs.api`

`remedisys_healthcare_ai/api/v1/vital_signs/api.py` — 6 endpoints

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`create_vital_signs`**<br><sub>281</sub> | `patient`, `signs_date?`, `signs_time?`, `# Vital Signs section temperature?`, `pulse?`, `respiratory_rate?`, `custom_oxygen_saturation?`, `bp_systolic?` … +12 more | Vital Signs · create | 🖥 `/api/vital-signs` 🧪 | Create a new Vital Signs record in Draft state. |
| **`get_vital_signs`**<br><sub>266</sub> | `name` | Vital Signs · read | 🧪 | Full Vital Signs record by document name. |
| **`get_vital_signs_template`**<br><sub>149</sub> | `department?` | — | 🖥 `/api/vital-signs/template` 🧪 | Return the Vital Signs Template for a department. |
| **`list_vital_signs`**<br><sub>235</sub> | `patient`, `page?`, `page_size?` | Vital Signs · read | 🖥 `/api/vital-signs` 🧪 | Paginated list of Vital Signs records for a patient, newest first. |
| **`submit_vital_signs`**<br><sub>587</sub> | `name` | Vital Signs · submit | 🖥 `/api/vital-signs/[id]/submit` 🧪 | Submit a Draft Vital Signs record (docstatus 0 → 1). |
| **`update_vital_signs`**<br><sub>423</sub> | `name`, `signs_date?`, `signs_time?`, `temperature?`, `pulse?`, `respiratory_rate?`, `custom_oxygen_saturation?`, `bp_systolic?` … +11 more | Vital Signs · write | 🖥 `/api/vital-signs/[id]` | Update a Draft Vital Signs record in place. |

### `api.ai.auth`

`remedisys_healthcare_ai/api/ai/auth.py` — 1 endpoint

> Authorization gate for the AI sidebar's realtime channel. A logged-in user can only receive events for a Patient Encounter if Frappe's permission system grants them read access on that encounter. The browser calls `subscribe_encounter_channel` first; on success it then subscribes to the returned channel via `frappe.realtime.subscribe(channel)`. Closes threat-model item S2 (a logged-in user subscri

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`subscribe_encounter_channel`**<br><sub>28</sub> | `encounter` | — | — | Authorize the current user to subscribe to an encounter's AI channel. |

### `api.ai.imaging_extraction`

`remedisys_healthcare_ai/api/ai/imaging_extraction.py` — 3 endpoints

> AI imaging-report transcription API (ADR-019 gap G14b) — whitelisted endpoints. upload_imaging_report — attach an uploaded report to an Imaging Lab Test and enqueue transcription extract_imaging_report — re-run transcription using the latest attached report get_imaging_extraction_status — latest transcription status (for the UI to poll) Mirrors api/ai/lab_extraction.py's shape, but for a fundament

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`extract_imaging_report`**<br><sub>97</sub> | `lab_test` | Lab Test · write | 🖥 `/api/labs/imaging-extract` | Re-run transcription for a Lab Test using its most recently attached report. |
| **`get_imaging_extraction_status`**<br><sub>122</sub> | `lab_test` | Lab Test · read | 🖥 `/api/labs/imaging-extraction-status` | Latest transcription status for a Lab Test (for the UI to poll). |
| **`upload_imaging_report`**<br><sub>65</sub> | `lab_test` | Lab Test · write | 🖥 `/api/labs/imaging-upload` | Attach an uploaded imaging report file and start AI transcription. |

### `api.ai.lab_extraction`

`remedisys_healthcare_ai/api/ai/lab_extraction.py` — 3 endpoints

> AI lab report extraction API (M5) — whitelisted endpoints. upload_lab_report — attach an uploaded report to the Lab Test (created from the Service Request if needed) and enqueue extraction extract_lab_report — re-run extraction for a Lab Test using its latest report get_extraction_status — latest extraction status for a Lab Test All gated on AI Settings.enable_lab_extraction (default OFF — flipped

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`extract_lab_report`**<br><sub>340</sub> | `lab_test` | Lab Test · write | 🖥 `/api/labs/extract` | Re-run extraction for a Lab Test using the exact file(s) from its most recent upload (see _latest_uploaded_file_names) — never just the single newest File row, which could silen… |
| **`get_extraction_status`**<br><sub>363</sub> | `lab_test` | Lab Test · read | 🖥 `/api/labs/extraction-status` | Latest extraction status for a Lab Test (for the UI to poll). |
| **`upload_lab_report`**<br><sub>282</sub> | `service_request?`, `lab_test?`, `acknowledge_warnings?` | Lab Test · write | 🖥 `/api/labs/upload` | Attach one or more uploaded report files and start AI extraction. |

### `api.ai.lab_panel_extraction`

`remedisys_healthcare_ai/api/ai/lab_panel_extraction.py` — 11 endpoints

> Multi-panel AI lab report extraction API (ADR-022) — whitelisted endpoints. upload_lab_report_package — attach an uploaded report to a Patient and enqueue multi-panel extraction get_panel_extraction_status — latest multi-panel extraction status + detected panels create_order_for_panel — explicit action: create a Lab Test (no Service Request — nothing to track) for a detected-but-unordered panel, t

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`add_analyte_to_template`**<br><sub>601</sub> | `template`, `analyte_name`, `normal_range?`, `uom?`, `lab_test?`, `result_value?` | Lab Test Template · write | 🖥 `/api/labs/panel-add-analyte` | Add a genuinely new analyte to an existing template (ADR-023 Decision 2). |
| **`create_imaging_order_from_narrative`**<br><sub>937</sub> | `extraction?`, `lab_test_name?`, `index?`, `practitioner?`, `company?`, `lab_test_code?`, `patient?`, `transcribed_report?` … +1 more | Patient · read | 🖥 `/api/labs/panel-create-imaging-order` | Explicit action: turn ONE narrative document from an extraction (is_narrative_report, see get_panel_extraction_status's narrative_reports array) into a Draft Imaging Lab Test, p… |
| **`create_order_for_panel`**<br><sub>297</sub> | `extraction`, `panel`, `practitioner?`, `company?`, `manual_values?` | Patient · read | 🖥 `/api/labs/panel-create-order` | Explicit action: create a Lab Test for a detected-but-unordered panel. |
| **`create_template_from_section`**<br><sub>724</sub> | `lab_test_name`, `template_type`, `analytes`, `lab_test_code?`, `allow_no_analytes?` | Lab Test Template · create | 🖥 `/api/labs/panel-create-template` | Create a brand-new template — from a detected report section that matched no existing template (ADR-023 Decision 2, AI flow), OR from the manual "create a new test" form when a … |
| **`finalize_section_order`**<br><sub>449</sub> | `extraction`, `template`, `values?`, `practitioner?`, `company?` | Patient · read | 🖥 `/api/labs/panel-finalize-section` | Create + submit a Lab Test for a template the physician just built from an unmatched report section (create_template_from_section), attaching the extraction's source report to it. |
| **`get_lab_extraction_availability`**<br><sub>124</sub> | — | — | 🖥 `/api/labs/ai-availability` | Whether AI lab extraction is available, for the frontend to decide between the AI upload flow and the manual-entry fallback (Rule 7 — AI unavailability must never block manual c… |
| **`get_panel_extraction_status`**<br><sub>223</sub> | `extraction` | Patient · read | 🖥 `/api/labs/panel-extraction-status` | Status + detected panels for a multi-panel extraction (for the UI to poll). |
| **`ignore_panel`**<br><sub>530</sub> | `extraction`, `panel` | Patient · read | 🖥 `/api/labs/panel-ignore` | Explicit action: dismiss a detected panel without creating an order. |
| **`map_unmapped_as_alias`**<br><sub>564</sub> | `parameter_name`, `canonical_analyte`, `source?` | Lab Test · write | 🖥 `/api/labs/panel-map-alias` | Resolve an unmapped report parameter as a synonym for an existing analyte (ADR-023 Decision 1). |
| **`search_analytes`**<br><sub>543</sub> | `query?` | Lab Test · read | 🖥 `/api/labs/panel-search-analytes` | Read-only lookup of known analyte labels (case-insensitive substring match), for the frontend's "map this unmapped parameter to an existing analyte" picker that feeds map_unmapp… |
| **`upload_lab_report_package`**<br><sub>174</sub> | `patient`, `acknowledge_warnings?` | Patient · read | 🖥 `/api/labs/panel-upload` | Attach one or more uploaded multi-panel report files and start extraction. |

### `api.ai.lab_result_summary`

`remedisys_healthcare_ai/api/ai/lab_result_summary.py` — 11 endpoints

> AI lab-result interpretation API — whitelisted endpoints. get_result_summary — the Lab Test's current AI result summary (for the UI to poll: status, narrative, per-analyte significance) retry_result_summary — explicitly re-run the summary (e.g. after a Failed run) — works regardless of docstatus, Draft or Submitted, unlike the automatic trigger get_patient_summary — patient-wide summary across eve

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`ask_lab_question`**<br><sub>621</sub> | `patient`, `question`, `history?` | Patient · read | 🖥 `/api/labs/chat` | Interactive patient Q&A — answer a clinician's MEDICAL question about THIS patient using only the patient's own record (see patient_clinical_summary.build_patient_chat_context). |
| **`ask_report_question`**<br><sub>424</sub> | `report_params?`, `question?`, `history?`, `extraction?`, `narrative_reports?` | Lab Test · read | 🖥 `/api/labs/report-chat` | Report-scoped Q&A on the extraction Review screen (ADR-033) — answer a clinician's question about THIS uploaded report only, using its extracted values and/or its transcribed na… |
| **`get_patient_summary`**<br><sub>216</sub> | `patient` | Lab Test · read | 🖥 `/api/labs/patient-summary` | Read the patient's STORED patient-wide lab summary (2026-07-22 — no longer generated at view time). |
| **`get_result_summary`**<br><sub>144</sub> | `lab_test` | Lab Test · read | 🖥 `/api/labs/result-summary` | The Lab Test's current AI result-interpretation summary (for the UI to poll). |
| **`list_patient_chat`**<br><sub>759</sub> | `patient`, `page?`, `page_size?` | Patient · read | 🖥 `/api/labs/chat/history` | Paginated stored chat thread for a patient, oldest-first — used to reload the conversation when the chat panel opens (ADR-030). |
| **`preview_patient_summary`**<br><sub>267</sub> | `patient`, `report_params?` | Lab Test · read | 🖥 `/api/labs/patient-summary/preview` | Synchronously compute (but do NOT persist) the patient-wide lab summary for the review dialog — the patient's saved labs analyzed together with the just-uploaded report (report_… |
| **`preview_report_summary`**<br><sub>294</sub> | `report_params?`, `extraction?`, `narrative_reports?` | Lab Test · read | 🖥 `/api/labs/report-summary` | At-a-glance summary of a SINGLE just-uploaded report, for the extraction review screen — every extracted value with its Normal/High/Low/Abnormal flag, each abnormal one explaine… |
| **`regenerate_patient_summary`**<br><sub>236</sub> | `patient`, `report_params?` | Lab Test · read | 🖥 `/api/labs/patient-summary/regenerate` | (Re)generate the patient-wide lab summary as a background job — returns at once with status Summarizing; the frontend polls get_patient_summary until it flips to Success/Failed/… |
| **`retry_result_summary`**<br><sub>193</sub> | `lab_test` | Lab Test · write | — | Explicitly re-run the AI result summary for a Lab Test, Draft or Submitted. |
| **`save_report_summary`**<br><sub>363</sub> | `lab_tests`, `summary`, `chat?` | Lab Test · write | 🖥 `/api/labs/save-report-summary` | Persist ONE report's summary + chat onto EACH Lab Test the report created, on Done (ADR-033). |
| **`set_patient_chat_feedback`**<br><sub>815</sub> | `message`, `feedback`, `note?` | Patient · read | 🖥 `/api/labs/chat/feedback` | Set thumbs up/down (and an optional note) on an assistant answer (ADR-030). |

### `api.ai.patient_clinical_summary`

`remedisys_healthcare_ai/api/ai/patient_clinical_summary.py` — 2 endpoints

> AI Patient Clinical Summary API (ADR-029) — whitelisted endpoints. get_patient_clinical_summary — the stored advisory summary for a patient (for the Summary tab to read); never triggers an LLM call generate_patient_clinical_summary — generate (synchronously) + persist a fresh summary, then return it Gated on AI Settings.enable_lab_extraction (the single AI-lab flag, ADR-028 — default OFF). Advisor

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`generate_patient_clinical_summary`**<br><sub>54</sub> | `patient`, `report_params?`, `persist?`, `background?`, `rebuild?` | Patient · read | 🖥 `/api/labs/clinical-summary/generate` | Generate (synchronously, on THIS call) the patient's clinical summary across labs, medications, immunizations, encounters and vitals, then return it. |
| **`get_patient_clinical_summary`**<br><sub>34</sub> | `patient` | Patient · read | 🖥 `/api/labs/clinical-summary` | Return the patient's stored advisory clinical summary (or NotGenerated). |

### `api.ai.segments`

`remedisys_healthcare_ai/api/ai/segments.py` — 2 endpoints

> Whitelisted API for `AI Transcript Segment` writes. Browser-side flow (per ADR-009): the browser receives finalized transcripts on its direct Deepgram WS and POSTs each one through ``append_segment``. The doctype controller is authoritative for append-only semantics and (session, sequence_number) uniqueness; this module is a thin permission + idempotency shim on top. Constitution references: - Rul

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`append_segment`**<br><sub>66</sub> | `session`, `sequence_number`, `speaker`, `text`, `start_ms`, `end_ms`, `confidence?`, `deepgram_segment_id?` … +2 more | — | 🖥 `/api/ai/session/segments` | Persist one finalized transcript segment and fan it out. |
| **`sync_transcript`**<br><sub>196</sub> | `session`, `segments` | — | 🖥 `/api/ai/session/sync-transcript` | Replace a session's transcript with a corrected set (physician "Fix speakers" / resegregate). |

### `api.ai.sessions`

`remedisys_healthcare_ai/api/ai/sessions.py` — 6 endpoints

> Whitelisted API for `AI Encounter Session` lifecycle. The browser uses these methods to create, start, refresh, and stop a recording session for a Patient Encounter. Per ADR-009 (Proposed, 2026-05-15), audio bytes go browser → Deepgram directly; this module never sees audio. Finalized transcript segments come back through `api/segments.py.append_segment` (slice 2). Constitution references: - Rule 

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_active_session`**<br><sub>83</sub> | `encounter` | — | 🖥 `/api/ai/session/active` | Return the caller's active (Draft/Recording) session for this encounter, with its persisted transcript, so a browser returning to the encounter page can resume the SAME recordin… |
| **`get_encounter_ai_record`**<br><sub>129</sub> | `encounter` | — | — | The consolidated AI record captured when this encounter was signed. |
| **`get_encounter_transcript`**<br><sub>205</sub> | `encounter` | — | 🖥 `/api/ai/encounter-transcript` | Every finalized transcript segment for this encounter, whoever's session captured it — the read-only archive shown on a signed/cancelled encounter. |
| **`refresh_deepgram_token`**<br><sub>301</sub> | `session` | — | 🖥 `/api/ai/session/refresh` | Mint a fresh Deepgram token for an in-flight `Recording` session. |
| **`start_session`**<br><sub>247</sub> | `encounter`, `consent_obtained?` | — | 🖥 `/api/ai/session` | Create or reattach a session and (optionally) start recording. |
| **`stop_session`**<br><sub>338</sub> | `session`, `close_reason?` | — | 🖥 `/api/ai/session/stop` | Terminate a `Recording` session. |

### `integrations.whatsapp.chat_api`

`remedisys_healthcare_ai/integrations/whatsapp/chat_api.py` — 6 endpoints

> WhatsApp chat layer — sits on top of frappe_whatsapp. frappe_whatsapp handles: Meta webhook, template sending, message storage. This module handles: conversation threading, 24h window, inbound routing, staff inbox API, and multi-tenant isolation by Company.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`assign_conversation`**<br><sub>369</sub> | `conversation`, `user` | — | — | Assign a conversation to a staff member. |
| **`close_conversation`**<br><sub>384</sub> | `conversation` | — | — | Mark conversation as Closed. |
| **`get_conversation`**<br><sub>256</sub> | `conversation` | — | — | Full thread: conversation header + all WhatsApp Messages ordered ASC. |
| **`list_conversations`**<br><sub>209</sub> | `status?`, `assigned_to?`, `limit?`, `offset?` | — | — | Staff inbox. |
| **`send_chat_message`**<br><sub>302</sub> | `conversation`, `body` | — | — | Send a free-form reply within the 24h Meta window. |
| **`send_template_message`**<br><sub>341</sub> | `conversation`, `template_name`, `variables` | — | — | Send a pre-approved template. |

### `integrations.whatsapp.notifications`

`remedisys_healthcare_ai/integrations/whatsapp/notifications.py` — 1 endpoint

> WhatsApp notification processor — wildcard doc_events hook. Fires on every doctype save. Exits in ~1ms for unmatched doctypes (indexed query returns empty immediately). Only proceeds when a matching enabled Remedisys WhatsApp Notification config exists. Never raises — any error per-config is caught, logged, and the document save continues unaffected.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_available_fields`**<br><sub>306</sub> | `doctype` | — | — | Return grouped field list for the Browse Fields dialog in Frappe Desk. |

### `integrations.whatsapp.webhook`

`remedisys_healthcare_ai/integrations/whatsapp/webhook.py` — 1 endpoint

> Meta WhatsApp webhook override. This module replaces ``frappe_whatsapp.utils.webhook.webhook`` via ``override_whitelisted_methods`` in hooks.py. We do NOT edit the upstream frappe_whatsapp app (Rule 1 — upgrade-safe): frappe_whatsapp is pulled from upstream and a local edit there would be lost on ``bench update`` and would conflict on ``git pull``. The ONLY behavioural change versus upstream is th

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`webhook`**<br><sub>40</sub> | — | — | 🌐 | Meta webhook. |

### `overrides.pos_price_fix`

`remedisys_healthcare_ai/overrides/pos_price_fix.py` — 1 endpoint

> Override for erpnext.stock.get_item_details.get_item_details. ERPNext POS has a timing bug: after get_item_details returns, the JS applies price_list_rate → rate via frappe.run_serially inside the frm.call callback — but that chain is not awaited before update_cart_html renders. Result: item cards always show MXN 0.00 for the first paint. Fix: for POS Invoice items, set rate = price_list_rate when

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`get_item_details`**<br><sub>19</sub> | `ctx`, `doc?`, `for_validate?`, `overwrite_warehouse?` | — | — | _no docstring_ |

### `overrides.sales_invoice_mixin`

`remedisys_healthcare_ai/overrides/sales_invoice_mixin.py` — 1 endpoint

> Diagnostic mixin for Sales Invoice process_item_selection. Logs intermediate values to identify why price_list_rate=0 in HTTP context.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`process_item_selection`**<br><sub>15</sub> | `item_idx` | — | — | _no docstring_ |

### `utils`

`remedisys_healthcare_ai/utils.py` — 1 endpoint

> Shared helpers used by every api/v1/*/api.py file. Do not add feature-specific logic here.

| Method | Params | Gate | Wired | Description |
|---|---|---|---|---|
| **`my_endpoint`**<br><sub>299</sub> | `...` | — | — | _no docstring_ |

<!-- END GENERATED: endpoint index -->

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-09-25 | Satyakam (AI-assisted) | §16 marked superseded by the generated `ENDPOINT_INDEX.md` |
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
