# Reschedule payment preview — frontend contract

**Doc status:** living · **Created:** 2026-08-19 by Anant Sharma · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

Status: shipped, both sides.
Backend: `preview_reschedule_payment` in `api/v1/appointments/api.py`.
Frontend (`remedisys-ai-ehr`): `hooks/use-reschedule-payment-preview.ts`,
`app/api/appointments/[id]/reschedule-payment-preview/route.ts`, and the
Payment + Review steps of `components/narzim/dashboard/new-appointment-dialog.tsx`.

This document stays as the contract between the two.

## Why this exists

The reschedule drawer's Payment step (step 3) computed the settlement itself,
from `get_appointment`'s invoice-level `billing` block minus the practitioner's
`op_consulting_charge`. That produced a number the backend then contradicted on
Continue, for two independent reasons:

1. `billing.total` / `billing.paid` are **invoice** totals. A Sales Invoice can
   cover several appointments (front-desk batch checkout), so those figures
   include other appointments' lines.
2. `op_consulting_charge` is **pre-tax**; `billing.paid` is tax-inclusive cash.
   Subtracting one from the other drops IVA entirely.

Observed live on `HLC-APP-2026-00106` (invoice `ACC-SINV-2026-00234`, shared
with `HLC-APP-2026-00100`):

| | Truth | Drawer showed | Backend would have done |
|---|---|---|---|
| Previous consultation fee | 580 | 2,900 | 2,900 |
| Already paid | 580 | 2,900 | 2,900 |
| New consultation fee | 2,320 | 2,000 | 2,320 |
| Settlement | collect 1,740 | **refund 900** | refund 580 |

The drawer offered a 900 MXN refund on a reschedule where the patient owed
1,740 MXN, and the copy said the refund settles immediately on confirm.

## The endpoint

`remedisys_healthcare_ai.api.v1.appointments.api.preview_reschedule_payment`

Permission: `Patient Appointment` **read** (the settling call needs write).
Writes nothing — no history row, no invoice, no payment.

### Request

| Param | Required | Notes |
|---|---|---|
| `appointment` | yes | |
| `new_practitioner` | no | defaults to the current one |
| `new_appointment_type` | no | defaults to the current one |
| `new_appointment_date` | no | accepted for payload parity, unused — fee does not depend on it |
| `new_appointment_time` | no | same |
| `fee_override` | no | front-desk negotiated rate, pre-tax |

Signature parity is deliberate: send the drawer's single payload to the preview
on every field change, and the same payload to the settling endpoint on
Continue.

### Response

```json
{
  "appointment": "HLC-APP-2026-00106",
  "old": {
    "practitioner": "HLC-PRAC-2026-00009",
    "practitioner_name": "Adrián López Vázquez",
    "appointment_type": "General Consultation",
    "invoice": "ACC-SINV-2026-00234",
    "fee": 580.0,
    "fee_incl_tax": 580.0,
    "tax_rate": null,
    "paid": 580.0
  },
  "new": {
    "practitioner": "HLC-PRAC-2026-00008",
    "practitioner_name": "Silvia Cantón Rendón",
    "appointment_type": "Emergency",
    "fee": 2000.0,
    "tax_rate": 16.0,
    "tax_amount": 320.0,
    "fee_incl_tax": 2320.0
  },
  "adjustment": { "type": "Additional Payment", "amount": 1740.0 },
  "currency": "MXN"
}
```

`adjustment.type` is one of `Additional Payment` | `Refund` | `None`.
`adjustment.amount` is a magnitude — the direction is in `type`.

`old.tax_rate` is `null` when the appointment was already invoiced: `old.fee`
is then this appointment's real share of that invoice, tax already included,
and there is no single rate to attribute to it. When the appointment was never
invoiced, `old.fee` is the pre-tax booking fee and `old.tax_rate` is populated.

## Rules for the drawer

1. **Render the response verbatim. Compute nothing.** No subtraction, no tax
   maths, no fallback to `op_consulting_charge`. Any arithmetic in the frontend
   reintroduces the divergence this endpoint exists to remove.
2. **Show the tax line.** The current three-row layout hides it:

   ```
   Previous consultation fee            580 MXN   ← old.fee_incl_tax
   Already paid                         580 MXN   ← old.paid
   New consultation fee               2,000 MXN   ← new.fee
   IVA (16%)                            320 MXN   ← new.tax_amount
   New total                          2,320 MXN   ← new.fee_incl_tax
   ─────────────────────────────────────────────
   Amount to collect                  1,740 MXN   ← adjustment.amount
   ```

   Omit the IVA and total rows only when `new.tax_rate` is 0 or null.
3. **The summary band is directional.** `Additional Payment` → "Amount to
   collect", collect-styling. `Refund` → "Refund amount". `None` → "No payment
   needed", and hide the band's amount.
4. **The immediacy copy belongs to the refund case only.** "This refund is
   settled immediately once you confirm" must not render for
   `Additional Payment` or `None`.
5. **Re-fetch on every input change** that alters practitioner, appointment
   type, or `fee_override`. Debounce; do not cache across changes.
6. **Both strings are catalog entries** (`es-MX` + `en-US`), including the
   IVA label — the tax name is jurisdiction-specific and comes from
   `new.tax_rate`, not hardcoded.
7. **Reconcile on confirm.** `reschedule_appointment_with_payment` now returns
   `new.tax_rate`, `new.tax_amount` and `new.fee_incl_tax` alongside the
   existing `new.fee`. If the confirmed `adjustment.amount` differs from what
   was previewed (someone changed a rate mid-drawer), show the settled figure
   rather than the stale preview.

## Backend changes behind this

- `services/billing.py::appointment_invoice_share` — an appointment's own share
  of a possibly-shared invoice, prorated on `net_amount`, tax-inclusive.
- `services/billing.py::consultation_fee_with_tax` — one place that converts a
  pre-tax `op_consulting_charge` into a tax-inclusive total. Used by both the
  preview and the settlement.
- `services/billing.py::total_paid_for_appointment` — now measures prior
  adjustments from their own documents rather than the never-updated
  `adjustment_status` flag.
- `api/v1/appointments/api.py::_reschedule_quote` — the shared calculation.
  `preview_reschedule_payment` and `reschedule_appointment_with_payment` both
  call it, which is what makes them structurally unable to disagree.

Regression tests: `tests/appointments/test_reschedule_payment.py`, the
`shared-invoice attribution`, `preview parity` and `collected pay_later delta`
sections.


---

## Addendum — refunds that span more than one invoice (2026-08-19)

Once the preview reported the *correct* amount owed back, a second bug became
reachable: `Row # 1: Rate cannot be greater than the rate used in Sales Invoice
ACC-SINV-2026-00386`.

An appointment's money sits on its original invoice **plus one delta invoice
per prior fee increase**. `total_paid_for_appointment` aggregated all of them;
`_create_reschedule_refund` could only reverse the appointment's
`ref_sales_invoice`. On `HLC-APP-2026-00123` that meant 2,320 paid, 1,740 owed
back, and only 580 reachable — core rejected the oversized return.

Fixed by deriving both from one place:

- `services/billing.py::_appointment_funding` — the single definition of where
  an appointment's money sits. `total_paid_for_appointment` is now the sum of
  its sources.
- `appointment_refund_sources` — the same list, capped per source at BOTH
  remaining cash and remaining returnable **quantity** (`_returnable_value`).
  The value-sized return consumes a whole line's quantity, so an invoice can
  hold cash it can no longer credit-note back.
- `_allocate_reschedule_refund` — draws newest-source-first, one Credit Note
  per invoice touched, each `return_against` the invoice the money came in on.
- `_SETTLEMENT_TOLERANCE` (0.05) — below this a fee difference is rounding, not
  money. Chasing a one-centavo residue onto a second invoice would cost that
  invoice its entire returnable quantity.

Two further bugs were found and fixed on the way:

- The tax back-out read the row's **item tax template rate** rather than the tax
  the invoice actually applied. An Item Tax Template only modulates a
  header-level tax row, and core Healthcare's `create_sales_invoice` never sets
  one — so a POS-booked refund of 402 paid out 347. Now derived from the
  invoice's own realised multiplier and corrected against the draft total.
- `Appointment Reschedule History.refund_credit_note` is a single Link. A
  multi-invoice refund produces several, so refunds are now recorded in the
  `refund_breakdown` child table (`Appointment Reschedule Refund`); the old
  field still holds the primary. Backfilled by
  `patches/v0/backfill_reschedule_refund_breakdown_20260819.py`.

### Response addition

`reschedule_appointment_with_payment` now returns, alongside the existing
`adjustment.credit_note`:

```json
"adjustment": {
  "type": "Refund", "amount": 1740.0,
  "credit_note": "ACC-SINV-2026-00391",
  "refunds": [
    { "invoice": "ACC-SINV-2026-00387", "credit_note": "ACC-SINV-2026-00391",
      "payment_entry": "ACC-PAY-2026-00162", "amount": 1740.0 }
  ]
}
```

The drawer should show every row in `refunds`, not just `credit_note` — a
refund drawn from two invoices produces two documents the patient may be asked
about.

### Still open — frontend labelling

`old.fee_incl_tax` is scoped to the ORIGINAL invoice while `old.paid` covers the
whole chain, so the Payment step can read "Previous consultation fee 580 /
Already paid 2,320". Both are correct; side by side they read as an error.
Recommended: relabel to `Total charged so far` / `Already paid`, both
chain-scoped, so the settlement visibly follows from the rows above it.


---

## Addendum — R-1 / R-2: pay-later double billing (2026-08-19)

**R-1.** An appointment with no invoice yet is billed the FULL new fee by a
reschedule (there is nothing to top up). That invoice was left unlinked, so the
appointment stayed `invoiced=0` / `ref_sales_invoice=None` and the ordinary
collect-payment path raised a SECOND invoice for the same consultation.
Reproduced live: **870 + 500 = 1,370 for one 870 visit.**

**R-2.** `Patient Appointment.paid_amount` — the appointment's stamped FEE,
despite the name — was never updated by a reschedule. Core's
`get_appointment_item` bills `paid_amount or practitioner_charge`, so the
second invoice above charged the OLD 500. It also feeds `_billing_for`'s
unbilled fallback, so the appointments list showed the wrong amount due.

Both fixed in `reschedule_appointment_with_payment`, in one write:

```python
appointment_updates = {"paid_amount": flt(new_fee)}
if not old_invoice and adjustment.get("invoice"):
    appointment_updates["invoiced"] = 1
    appointment_updates["ref_sales_invoice"] = adjustment["invoice"]
frappe.db.set_value("Patient Appointment", appointment, appointment_updates)
```

The link is written through the DB layer rather than by adding
`reference_dt`/`reference_dn` to the delta invoice's line: core's own
`on_submit` would then throw "already invoiced" on any later top-up, and would
repoint `ref_sales_invoice` at each new delta in turn
(`healthcare/utils.py::set_invoiced`). Only applied when there was no prior
invoice — when there was, the delta is a genuine top-up and `ref_sales_invoice`
must keep pointing at the original.

`_appointment_funding` now skips the original invoice if a prior history row
already contributed it as an `additional_invoice`, since after this change the
two can be the same document.

### Visible change for front desk

A pay-later appointment that is rescheduled now becomes **invoiced with an
outstanding balance**, where before it stayed unbilled until checkout. The
appointments list shows it as `Pending` rather than `Unbilled`, and the
checkout screen collects against the existing invoice instead of offering to
create one. This is the correct state — the charge really was raised at
reschedule time — but it is a change in what the operator sees.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
