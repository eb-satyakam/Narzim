# Frappe Drive — Frontend Integration Guide

**Doc status:** living · **Created:** 2026-08-18 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-18 by Divyanshu (AI-assisted) · **Version:** 1.1

> How to drive the installed `drive` app from the Next.js frontend
> (`Healthcare_next_app`) through the BFF, what works, and what is broken.
>
> **Every endpoint, response shape and failure mode in this document was
> executed against the live site** (`remedisys.localhost`, Frappe v16.31.0,
> `drive` 0.3.0) on 2026-08-18. Where something is unverified it says so.

**Status:** Installed on dev, integration not built.
**Owner:** Backend.
**Created:** 2026-08-18 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
**Last updated:** 2026-09-18 — Divyanshu (AI-assisted) · corrected the branch trap, the
archival claim, and the storage model (§0.1, §1)

> ## ⚠️ READ THIS BEFORE `bench get-app` — 2026-09-18
>
> **`bench get-app https://github.com/frappe/drive` installs the WRONG BRANCH.** It defaults to
> `develop`, and `develop` has restructured: it has **no `Drive File` doctype at all** and stores
> everything in core `File`. `services/drive.py` targets `Drive File`, so on `develop` the entire
> Narzim Drive integration cannot work.
>
> ```bash
> bench get-app --branch main https://github.com/frappe/drive     # ← the branch this repo needs
> bench --site <site> install-app drive
> ```
>
> **Both branches report `__version__ = "0.3.0"`.** The version string cannot tell them apart, which
> is why "drive 0.3.0" appears throughout this document and still did not prevent the mistake.
> **Record the commit:** `main` = `0bd11d8` (2026-06-16).
>
> Three more things that cost a session on 2026-09-18:
>
> - **`main` needs OpenCV** (`opencv-python-headless`) and `ffmpeg`; `develop` does not. If you
>   switch branches *after* installing, re-run the dependency install or `install-app` dies with
>   `No module named 'cv2'`.
> - **A failed `install-app` leaves partial state** — the `Module Def` and any doctypes created
>   before the crash. The retry then fails with `Duplicate entry 'Drive'` until they are removed.
> - **`developer_mode = 1` makes `frappe.delete_doc("DocType", …)` delete the app's SOURCE FILES**,
>   not just the database rows. Cleaning up a failed install this way silently removed three
>   directories from `apps/drive`; `git status` in that app showed it and `git checkout --` restored
>   them. Check `git status` in `apps/drive` after any doctype cleanup.
<sub>Editing this file? Update **Last updated** with your name and date.</sub>

---

## 0. Read this before writing code

Four decisions are still open. They do not block local development, but Drive
must not reach production until they are settled:

1. **AGPL-3.0.** Drive is AGPL-3.0. ADR-030 disallowed Frappe_Assistant_Core
   for PHI flows partly on this basis. A written legal position on the
   network-use clause for multi-tenant commercial SaaS is required.
2. **ADR missing.** The constitution requires an ADR per architectural
   decision. Adopting Drive supersedes part of ADR-010 (§3 below) and needs its
   own ADR.
3. **~~Source is archived.~~ CORRECTED 2026-09-18 — it is not.** `github.com/frappe/drive` is
   actively developed: `develop` had commits as recent as **2026-09-16**. What is true is that
   **`main` has not moved since 2026-06-16**, which is what "archived" was inferred from. The
   practical consequence is unchanged and now sharper: the branch we depend on (`main`) is
   effectively frozen while upstream work continues on `develop` in a direction that **removes the
   `Drive File` doctype entirely**. A future upgrade is a migration, not a pull. Bugs we find in
   `main` — including §8 — we carry.
4. **PHI boundary.** Drive's permission model knows nothing about `Patient`,
   the `EB_*` roles, LFPDPPP/DPDPA minimization, or NOM-024 retention. The
   standing recommendation is Drive for **non-PHI staff files only**; patient
   documents stay on `Patient Medical Record` (`services/documents.py`) and
   staff clinical notes on `Clinical Document`
   (see `docs/CLINICAL_DOCUMENT_DRIVE.md`).

### ~~The one setting that must not change~~ — DOES NOT EXIST ON `main`

```
Drive Disk Settings.use_drive_for_files = 0     ← develop ONLY
```

**Corrected 2026-09-18: this field does not exist on `main`**, the branch this repo uses. Reading
it there raises *"Field use_drive_for_files does not exist on Drive Disk Settings"*. It is a
`develop` feature, and on `develop` it is genuinely load-bearing — at `1` Drive takes over `File`
handling for the **entire site**, routing patient attachments through Drive's permission model.

On `main` the PHI boundary is structural instead: Drive stores its own rows in `Drive File` and
never touches core `File`, so patient attachments are unaffected by construction rather than by a
setting. **If this repo ever moves to `develop`, this flag becomes critical again.**

---

## 1. How Drive stores things (and why your PHI files are unaffected)

⚠️ **CORRECTED 2026-09-18. This paragraph described `develop`, not the branch we use.**

On **`main`** (what `services/drive.py` targets) Drive **does** introduce its own file doctype:
**`Drive File`**, carrying `team`, `parent_entity`, `path`, `title`, `mime_type`, `document`,
`is_active`, `is_group` and `file_size`. A folder is a `Drive File` with `is_group=1`. Core `File`
is untouched, which is why PHI attachments are unaffected.

On **`develop`** the original paragraph is accurate — Drive dropped `Drive File` and moved to core
`File` (`override_doctype_class = {"File": "drive.overrides.file.File"}`), renaming
`parent_entity` → `folder` and `title` → `file_name`. That restructure is the reason
`services/drive.py` cannot run on `develop` at all.

Drive also installs a site-wide permission override on core `File`:

```python
# drive/hooks.py
has_permission = {"File": "drive.api.permissions.user_has_permission"}
```

That sounds alarming; it is not, because of the first branch of that function:

```python
# drive/api/permissions.py
if is_site_file(doc):                       # is_site_file == "has no team"
    return ff_has_permission(doc, ptype, user)   # stock Frappe behaviour
```

**Files with no `team` — every file our app has ever created — keep exactly the
stock Frappe permission path.** Only team-owned files go through Drive's
own model. Verified after install: all existing app endpoints still return 200
and no existing file changed behaviour.

The 12 doctypes Drive adds: `Drive Team`, `Drive Team Member`,
`Drive Permission`, `Drive Token`, `Drive User Invitation`, `Drive Favourite`,
`Drive Notification`, `Drive Entity Log`, `Drive Entity Activity Log`,
`Drive Settings`, `Drive Disk Settings`, `Account Request`.

---

## 2. Prerequisites

### 2.1 The `Drive User` role is mandatory

Drive ships its own role. `Drive User` holds create/read/write on `Drive Team`;
none of the `EB_*` roles do. Without it, `create_team` fails with
`PermissionError` (verified — `admin@narzim.com` failed until the role was
granted).

Any staff user who should use Drive needs `Drive User` **in addition to** their
`EB_*` role. Decide deliberately who gets it — it is the Drive access switch.

### 2.2 Every file lives in a team

There is no "just upload a file" call. Uploads target a folder, and every
folder belongs to a `Drive Team`. So the frontend's first job is resolving a
team:

```
get_teams  →  empty?  →  create_team  →  get_root_folder(team)  →  upload into it
```

A user with no team sees an empty drive, not an error (`get_teams` returns
`[]`/`{}`, verified).

---

## 3. Auth — Bearer JWT works, keep it in the BFF

**Verified:** Drive's whitelisted methods work with an `eb_frappe_jwt` Bearer
token. They read `frappe.session.user`, which the JWT `auth_hooks` set, exactly
like our own endpoints.

```
POST /api/method/drive.api.permissions.get_teams
Authorization: Bearer <access_token>          → 200 {"message": [...]}
```

So Drive fits the ADR-011 + ADR-010 pattern with no new credential: browser →
Next.js route handler → Frappe with the server-side token. **The browser must
never call Drive directly, and the `/drive` SPA must not be linked from the
clinic UI** — it is served by Frappe and talks to Frappe directly, which is the
BFF violation ADR-010 forbids. Treat Drive as an API, not as a UI we adopt.

### 3.1 Use `frappeFetchDirect`, not `frappeFetchSet`

Our helpers `frappeFetchSet` / `frappeFetchList` unwrap **our** envelope
(`{status, data}` from `set_response`). Drive returns raw Frappe
`{"message": ...}`, so those helpers will throw. Use the exported raw helper
and unwrap `message` yourself:

```ts
// src/lib/api/drive.ts  (new)
import { frappeFetchDirect } from "@/lib/api/client"

export async function driveCall<T>(
  method: string,
  token: string,
  body?: Record<string, unknown>,
): Promise<T> {
  // frappeFetchDirect defaults to POST — which is what we want, see §7.
  const raw = await frappeFetchDirect<{ message: T }>(method, { token, body })
  return raw.message
}
```

### 3.2 BFF route handler, following the existing pattern

```ts
// src/app/api/drive/teams/route.ts
import { getAccessToken } from "@/lib/auth/cookies"
import { frappeErrResponse } from "@/lib/api/client"
import { withFrappeDebug } from "@/lib/api/frappe-debug"
import { driveCall } from "@/lib/api/drive"

// GET /api/drive/teams → teams this user can see
export const GET = withFrappeDebug(async () => {
  const token = await getAccessToken()
  if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 })
  try {
    const teams = await driveCall<Record<string, unknown>>(
      "drive.api.permissions.get_teams", token, { details: 1 },
    )
    return Response.json({ data: teams })
  } catch (err) {
    return frappeErrResponse(err)
  }
})
```

---

## 4. Endpoint reference

`✅` = executed successfully against the live site. `⚠️` = executed, failed —
see §8. Unmarked = present in 0.3.0, not exercised yet.

### Files and folders — `drive.api.files.*`

| Method | Args | Notes |
|---|---|---|
| ✅ `get_root_folder` | `team` | `{name, file_url}` — the folder to upload into |
| ✅ `upload_file` | multipart, see §5 | returns the created `File` doc |
| ⚠️ `create_folder` | `team`, `file_name`, `parent?` | **broken in 0.3.0**, §8 |
| ✅ `create_auth_token` | `entity_name` | cookieless download token, §6 |
| ✅ `get_file_content` | `entity_name`, `trigger_download?`, `token?` | `allow_guest`; the download |
| `stream_file_content` | `entity_name` | ranged streaming (video/audio) |
| `download_folder` | `entities` | zip |
| `rename` | `entity_name`, `new_title` | |
| `move` | `entity_names[]`, `new_parent?`, `team?` | |
| `remove_or_restore` | `entity_names` | trash / untrash |
| `delete_entities` | `entity_names[]?`, `clear_all?` | permanent |
| `set_favourite` | `entities[]?`, `clear_all?` | |
| `search` | `query` | |
| `get_thumbnail` | `entity_name` | |
| `update_access` | `entity_name`, `method`, `**kwargs` | sharing |
| `create_link` | `team`, `file_name`, `link`, `parent?` | bookmark entity |
| `does_entity_exist` | `name?`, `folder?`, `team?` | |
| `get_new_title` | `title`, `parent_name`, `folder?` | de-dupe helper |
| `track_visit` | `entity_name` | feeds `recents` |
| `get_docs_attached_to` | `file_name` | |

### Listings — `drive.api.list.*`

All take `team`, plus `order_by`, `ascending`, `file_kinds`, `search`.

| Method | Notes |
|---|---|
| ✅ `files` | folder contents; also `entity_name` (folder), `start`, `limit` |
| `shared` | `shared_type`: `"with"` \| `"by"` |
| `favourites` · `recents` · `trash` | |
| `get_attachments` | `doctype`, `docname` — surfaces a doc's attachments as virtual nodes |

Verified row shape from `list.files`:

```json
{ "name": "7cc4227f39", "file_name": "handbook.txt", "folder": "86eae6bbf0",
  "file_size": 29, "file_type": "Text", "is_folder": 0, "team": "59ompncat4",
  "owner": "admin@narzim.com", "owner_full_name": "Super Admin",
  "child_count": 0, "share_count": 0, "kind": "native", "type": "admin",
  "read": 1, "write": 1, "share": 1, "comment": 1, "upload": 1 }
```

Note the per-row permission booleans — render actions off these, never off role
guesses. `file_url` comes back `null` in listings by design; fetch content via
§6, never by constructing a `/private/files/...` URL.

### Teams, users, settings — `drive.api.product.*`

| Method | Notes |
|---|---|
| ✅ `create_team` | `user`, `team_name?`, `personal?` — needs `Drive User` (§2.1) |
| ✅ `get_teams` | `user?`, `details?`, `exclude_personal?` |
| `edit_team` · `leave_team` · `get_team_users` · `remove_user` | |
| `invite_users` | `emails`, `team?`, `as_guest?` |
| `set_user_access` | `team`, `user`, `access_level` |
| `get_my_invites` · `get_team_invites` · `accept_invite` · `reject_invite` | |
| `get_settings` · `set_settings` · `disk_settings` | |
| `is_site_admin` · `signup_disabled` · `oauth_providers` | |
| `signup` · `send_otp` · `verify_otp` | **do not expose** — Drive's own account flow, bypasses our auth |

### Permissions / storage / activity / notifications

`drive.api.permissions.*`: ✅ `get_teams`, `get_user_access`, `is_admin`,
`get_entity_with_permissions`, `get_shared_with_list`, `get_public_teams`.
`drive.api.storage.*`: `storage_breakdown(team, owned_only)`,
`storage_bar_data(team?, entity_name?)`.
`drive.api.activity.get_entity_activity_log(entity_name)`.
`drive.api.notifications.*`: `get_notifications`, `get_unread_count`,
`mark_as_read`.

---

## 5. Upload contract

`upload_file` takes a **multipart** body and supports chunking. Query/form args:
`team` (required), `total_file_size`, `uuid` (upload session id), `parent`
(folder — defaults to the team root), `file_modified` (epoch ms), `embed`.

Chunked uploads add `chunk_index`, `total_chunk_count`, `chunk_byte_offset`.
Every chunk request returns **empty** until the final chunk, which returns the
created `File` doc. The frontend must treat "no body" as "keep going", not as
failure.

Verified single-shot upload:

```
POST /api/method/drive.api.files.upload_file
Authorization: Bearer <token>
multipart: file=@handbook.txt, team=59ompncat4, total_file_size=29, uuid=<id>

→ 200 {"message": {"name": "7cc4227f39", "file_name": "handbook.txt",
        "is_private": 1, "file_size": 29, "team": "59ompncat4",
        "folder": "86eae6bbf0", "file_type": "Text", ...}}
```

The BFF route must forward the multipart stream rather than re-encode JSON —
read the incoming `FormData` and pass it straight through, and stream large
files instead of buffering them in the route handler.

There is a **server-side validation hook** we should use rather than trusting
the client:

```python
# hooks.py in remedisys_healthcare_ai
validate_drive_upload = ["remedisys_healthcare_ai.<module>.check_drive_upload"]
```

Called with `file`, `team`, `parent`, `embed`; return anything other than
`None`/`True` to reject with that message. This is the right place to enforce
mime/size policy and to keep clinical documents out of Drive.

Storage quota is enforced on upload (`storage_bar_data`) and fails with
"You're out of storage!" — surface that as a real error state.

---

## 6. Download — two routes, pick per use case

**A. Proxy through the BFF (default).** Call `get_file_content` with the
server-side Bearer token and stream the response back. Keeps the browser away
from Frappe and keeps the file behind our session. Verified: returns the file
body with `200`.

**B. Short-lived token (only when the browser must fetch directly** — e.g. an
`<img>`/preview or an external viewer that cannot carry our cookie).

```
POST drive.api.files.create_auth_token {entity_name}   → token
GET  drive.api.files.get_file_content?entity_name=…&token=…   (no auth header)
```

Verified working. **Two caveats, both verified:**

- `create_auth_token` **must be POST.** Over GET the token row is rolled back
  (§7) and the download then 403s. This cost real debugging time.
- **The token is not actually single-use.** The code deletes it after use, but
  `get_file_content` is served over GET, so the delete is rolled back too — the
  token row survives (confirmed still present in `Drive Token` after a
  successful download) and the same URL works repeatedly until its 5-minute
  expiry. Treat the token as a **5-minute bearer capability for that one file**,
  never put it in a shareable link, a log, or a page the patient can see.

---

## 7. The GET/POST rule (bit us twice)

Frappe does not commit database writes on `GET` requests. Any Drive method that
writes — `create_auth_token`, `create_team`, `create_folder`, `rename`, `move`,
`set_favourite`, `remove_or_restore`, `track_visit` — **must** be called with
`POST`, or it appears to succeed and silently rolls back.

`frappeFetchDirect` defaults to `POST`, so following §3.1 gets this right by
default. Do not "optimise" a read-looking call into a GET without checking
whether it writes.

---

## 8. Known broken in 0.3.0 — `create_folder`

Creating a folder fails on this deployment:

```
FileNotFoundError: [Errno 2] No such file or directory:
  '/private/files/Clinic Staff Files (admin@narzim.com)/Policies'
```

Root cause, confirmed in source. `drive/api/files.py::create_folder` passes the
parent's **`file_url`** as a filesystem path:

```python
"parent_path": Path(parent_doc.file_url or "")     # "/private/files/…" — absolute
```

`FileManager.get_disk_path` uses that value raw when `parent_path` is present,
while every other path in the module goes through `storage_key()`, whose own
comment states why:

```python
def storage_key(file_url):
    # file_url -> backend storage key, always relative so `base / key` can't
    # reset to an absolute path (Path("a") / "/b" == Path("/b")).
    return file_url.lstrip("/")
```

`create_folder` then does `(self.site_folder / path).mkdir()`. Because `path`
is absolute, pathlib discards `site_folder` and it tries to mkdir at the
filesystem root. **Uploads are unaffected** — they take the `storage_key()`
branch, which is why §5 works and §8 does not.

The fix is one line — wrap the value in `storage_key()`:

```python
"parent_path": Path(storage_key(parent_doc.file_url or "")),
```

But it is a patch to a third-party app whose upstream is archived, so we own it
forever unless we move to `frappe/suite`. **Do not patch `apps/drive` in place**
(Rule 1 reasoning applies: it would be silently lost on any re-clone). Either
carry it as a tracked fork, or verify whether `frappe/suite` already fixed it
and migrate. Until then, the frontend cannot offer "New folder" — build against
the team root only.

---

## 9. Suggested BFF surface

Mirror the existing naming so the frontend stays consistent:

| Route | Drive method |
|---|---|
| `GET /api/drive/teams` | `permissions.get_teams` |
| `POST /api/drive/teams` | `product.create_team` |
| `GET /api/drive/files?team=&folder=` | `list.files` |
| `GET /api/drive/shared?team=` | `list.shared` |
| `GET /api/drive/trash?team=` | `list.trash` |
| `POST /api/drive/upload` | `files.upload_file` (multipart passthrough) |
| `GET /api/drive/files/[id]/content` | `files.get_file_content` (stream) |
| `POST /api/drive/files/[id]/rename` | `files.rename` |
| `POST /api/drive/files/[id]/trash` | `files.remove_or_restore` |
| `POST /api/drive/files/move` | `files.move` |
| `GET /api/drive/storage?team=` | `storage.storage_bar_data` |

Per frontend rule 10, every user-visible string goes through the message
catalogs — including Drive's error text, which is English-only at source and
must be mapped, not passed through.

---

## 10. Verification log (2026-08-18)

Executed against `remedisys.localhost`, `drive` 0.3.0, Frappe 16.31.0, auth via
`eb_frappe_jwt` Bearer token:

| Step | Result |
|---|---|
| `permissions.get_teams` with Bearer JWT | ✅ 200 |
| `product.create_team` without `Drive User` role | ❌ PermissionError (expected) |
| `product.create_team` with `Drive User` role | ✅ team `59ompncat4` |
| `files.get_root_folder` | ✅ folder `86eae6bbf0` |
| `files.create_folder` | ❌ FileNotFoundError (§8) |
| `files.upload_file` (single shot, 29 B) | ✅ file `7cc4227f39`, `is_private=1` |
| `list.files` | ✅ 1 row, shape as §4 |
| `create_auth_token` over GET → download | ❌ 403 (token rolled back, §7) |
| `create_auth_token` over POST → download | ✅ 200, correct body |
| same token reused | ⚠️ 200 again — not single-use (§6) |
| all app endpoints re-checked after install | ✅ 200 (front desk, nurse, doctor) |

Test artifacts left on dev: team `59ompncat4` ("Clinic Staff Files"), file
`7cc4227f39` (`handbook.txt`), and the `Drive User` role granted to
`admin@narzim.com`. All are safe to delete.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-18 | Divyanshu (AI-assisted) | Four corrections found while installing Drive on a second bench: `bench get-app` installs `develop` not `main` and both report 0.3.0; §1's storage model described `develop`; `use_drive_for_files` does not exist on `main`; the repo is not archived (only `main` is frozen). Added the install-trap warning and the provenance header this file never had |
| 1.0 | 2026-08-18 | Sarvesh-SocialAngel (AI-assisted) | Initial guide, verified against a live site |
