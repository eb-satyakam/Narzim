# Narzim GPT (PR #493) — frontend API contract

**Doc status:** living · **Created:** 2026-09-21 by Divyanshu (AI-assisted) · **Updated:** 2026-09-21 by Divyanshu (AI-assisted) · **Version:** 1.0

**Who this is for:** the frontend engineer binding
[PR #493](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_EHR/pull/493) to the real
backend. Every endpoint the Narzim GPT screens need, with its exact route, payload, response JSON,
validation limits, and error shape. Nothing here is aspirational — every signature and every field
name was read out of the shipped code on `feature/narzim-gpt`, not from a plan.

**Scope:** the 23 Narzim methods (15 of them new in PR #493), plus the endpoints the PR reuses from
elsewhere — patient and visit pickers, the My Library file surface, and mic dictation. **28
endpoints total.**

### This document vs. the inventory

[`docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md`](../ai/NARZIM_GPT_BACKEND_INVENTORY.md) answers a
different question — *"does a backend API exist yet, and what must we still build?"* — and remains
the build record for the PR, with the per-item ADR reasoning behind each decision. **This document
owns the calling contract.** When the two disagree about a route, a payload or a response, **this
one is correct**: it was verified against the code on 2026-09-21, after the backend was finished.

⚠️ **The inventory contains six statements that will break a bind.** They are listed in §7 with the
correct values. Read that section first if you have already started from the inventory.

---

## 0. Before you bind anything

Five conventions. Getting any of them wrong produces a failure that looks like a backend bug and
is not one.

### 0.1 There are no REST resources — the route is a Python path

Frappe whitelisted methods only. `/api/resource/` is banned repo-wide (`CLAUDE.md` §3), so there is
no `/narzim/threads/:id`. The URL is the dotted module path of the function:

```
POST https://<site>/api/method/remedisys_healthcare_ai.api.v1.<module>.<file>.<function>
```

Everything is `POST`, including reads. The one exception is `drive.api.download`, which is a `GET`
because it streams a file.

⚠️ **The two Narzim files are different routes.** Chat lives in `...narzim_assistant.api.<fn>`;
templates live in `...narzim_assistant.templates.<fn>`. The inventory doc spells the
template routes with `.api.` — that is a 404. See §7.1.

### 0.2 Auth

```
Authorization: Bearer <jwt>
```

eb_frappe_jwt (ADR-011). The Next.js BFF holds the token server-side and the browser never sees it
(ADR-010/011) — so every call below is made from a route handler, not from a component.

### 0.3 Content type — JSON and multipart both work

Send `application/json` with a normal nested body for everything **except** a call that attaches a
file. `send_message` and `send_message_stream` accept `multipart/form-data` when a file rides along.

The composer's five structured inputs (`context`, `sources`, `urls`, `template_id`,
`library_doc_ids`) are accepted **either way**, verified in
`services/narzim_turn_inputs.py::_as_json`:

| You send | How to encode `context` |
|---|---|
| `application/json` | a real object — `"context": {"patient": "MRN-..."}` |
| `multipart/form-data` | a **JSON string** in a form field — `context={"patient":"MRN-..."}` |

Multipart has no types and cannot nest, which is why the string form exists. A dict or list is
passed straight through, so you do **not** have to double-encode on the JSON path.

### 0.4 Three response envelopes — this is the one that will bite you

Verified in `remedisys_healthcare_ai/utils.py`.

**(a) Single object** — `set_response`. Used by `patients`, `encounters`, `drive`, `documents`:

```json
{ "status": "success", "data": { "...": "..." } }
```

**(b) Paginated list** — `set_list_response`. Used by `list_patients`, `list_encounters`:

```json
{ "status": "success",
  "data": [ { "...": "..." } ],
  "pagination": { "total": 137, "page": 1, "page_size": 10 } }
```

⚠️ **`data` IS the array and `pagination` is its SIBLING, not nested inside it.** `utils.py:404`
documents this as `{"items": [...]}` and `utils.py:412` actually writes
`frappe.response["data"] = items`. **The code is right and that docstring is wrong** — read
`res.data`, never `res.data.items`.

**(c) Raw return** — **every `narzim_assistant` and `ai` method on this page**:

```json
{ "message": { "...": "..." } }
```

Deliberate, and stated in `api/v1/narzim_assistant/api.py`'s own docstring: these are
*"deliberately bare-whitelisted-method style (no `handle_api_errors` envelope), matching
`api/v1/ai/api.py`"*. Frappe wraps a plain returned dict in `message` itself.

**So: chat is `res.message.<field>`; the pickers and the library are `res.data`.** PR #493's mock
returns one flat shape for all three — the BFF must normalise per module, or the picker and the
chat will break in different ways on the day the mock is switched off.

### 0.5 Errors

A bare whitelisted method that calls `frappe.throw` returns a non-2xx with this body:

```json
{
  "exception": "frappe.exceptions.ValidationError",
  "_server_messages": "[\"{\\\"message\\\": \\\"At most 5 links can be attached to one message.\\\"}\"]"
}
```

`_server_messages` is a **JSON string containing a JSON array of JSON strings** — it is
double-encoded, so `JSON.parse` it twice to reach the human text. Map the exception class to a
status:

| Exception | HTTP | When |
|---|---|---|
| `frappe.exceptions.ValidationError` | 417 (Frappe's default) | bad input — limits, malformed JSON, unknown category |
| `frappe.exceptions.PermissionError` | 403 | the PHI guard fired, or the row belongs to someone else |
| `frappe.exceptions.AuthenticationError` | 401 | no/expired token |
| `frappe.exceptions.DoesNotExistError` | 404 | unknown id, **or an id you may not see** (deliberately identical — see §6.3) |

**Rule 7 applies to your error handling too.** An AI failure must never block clinical work: a
provider outage comes back as a normal `200` with an apologetic `reply` and a logged `Failed` row,
not as an exception. Do not build a retry storm around a 200.

### 0.6 What is off by default — check before you file a bug

| Thing | Controlled by | Default |
|---|---|---|
| Markdown replies | `AI Settings.narzim_reply_markdown` | **OFF** → `reply_format` is always `"plain"` |
| Clinical Web source | active `ComplianceProfile.retrieval_providers` | **off unless a provider is approved for that site** |
| My Library source | Frappe Drive installed **and** a clinic team configured | off if either is missing |
| Scope gate | `AI Settings.narzim_scope_mode` | `Enforce` · `Warn` · `Off` |

`list_sources` (§2.10) computes the middle two live. **Draw the Sources bar from that call — never
hardcode the toggles.** A toggle you offer that the server then refuses is worse than one visibly
greyed out.

---

## 1. Endpoint index

All 28. `narzim_assistant.api` and `narzim_assistant.templates` use envelope **(c)**; the rest use
**(a)** or **(b)**.

### Chat — `remedisys_healthcare_ai.api.v1.narzim_assistant.api.<fn>`

| # | Method | What it does | §|
|---|---|---|---|
| 1 | `send_message` | one turn, blocking | [2.1](#21-send_message) |
| 2 | `send_message_stream` | the same turn as SSE | [2.2](#22-send_message_stream) |
| 3 | `get_thread` | replay one conversation | [2.3](#23-get_thread) |
| 4 | `list_threads` | the sidebar | [2.4](#24-list_threads) |
| 5 | `hide_thread` | remove one conversation | [2.5](#25-hide_thread--hide_all_threads) |
| 6 | `hide_all_threads` | clear history | [2.5](#25-hide_thread--hide_all_threads) |
| 7 | `set_feedback` | 👍 / 👎 on a reply | [2.6](#26-set_feedback) |
| 8 | `get_suggestions` | empty-state prompt cards | [2.7](#27-get_suggestions) |
| 9 | `get_usage_summary` | admin-only token/cost | [2.8](#28-get_usage_summary) |
| 10 | `list_sources` | which sources this site offers | [2.10](#210-list_sources) |

### Templates — `remedisys_healthcare_ai.api.v1.narzim_assistant.templates.<fn>`

| # | Method | What it does | § |
|---|---|---|---|
| 11 | `list_templates` | template library list | [3.1](#31-list_templates) |
| 12 | `get_template` | one template + parsed sections | [3.2](#32-get_template) |
| 13 | `create_template` | create, optionally by duplicating | [3.3](#33-create_template) |
| 14 | `update_template` | partial update of your own | [3.4](#34-update_template) |
| 15 | `delete_template` | delete your own | [3.5](#35-delete_template) |
| 16 | `preview_sections` | parse an outline without saving | [3.6](#36-preview_sections) |
| 17 | `apply_template` | fill a template into a chat turn | [3.7](#37-apply_template) |
| 18 | `generate_template_example` | fictional worked example | [3.8](#38-generate_template_example) |
| 19 | `start_template_edit_session` | open the editor | [3.9](#39-start_template_edit_session) |
| 20 | `edit_template_chat` | change the outline, by hand or by asking | [3.10](#310-edit_template_chat) |
| 21 | `save_template_session` | write the outline back | [3.11](#311-save_template_session) |
| 22 | `generate_template` | build a blank template from past visits | [3.12](#312-generate_template) |
| 23 | `suggest_templates` | which template fits this conversation | [3.13](#313-suggest_templates) |

### Supporting — reused from other modules

| # | Method | What it does | § |
|---|---|---|---|
| 24 | `patients.api.list_patients` | "Link patient" picker | [4.1](#41-list_patients--link-patient) |
| 25 | `encounters.api.list_encounters` | "Link visit" picker | [4.2](#42-list_encounters--link-visit) |
| 26 | `drive.api.list_entries` | browse My Library | [4.3](#43-my-library--driveapi) |
| 27 | `drive.api.upload` / `trash` | add / remove library files | [4.3](#43-my-library--driveapi) |
| 28 | `ai.api.transcribe_audio` | mic dictation | [4.4](#44-transcribe_audio--mic-dictation) |

---

## 2. Chat — `api/v1/narzim_assistant/api.py`

### 2.1 `send_message`

One turn, blocking. Use this as the fallback path; use §2.2 for live typing.

```
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.send_message
Authorization: Bearer {{access_token}}
Content-Type: application/json   (or multipart/form-data when attaching a file)
```

**Payload**

| Field | Type | Required | Notes |
|---|---|---|---|
| `thread` | string | ✅ | client-generated conversation id. A new chat mints a new uuid (ChatGPT style) |
| `message` | string | — | required unless a file is attached |
| `file` | multipart file | — | see accepted types below |
| `context` | object / JSON string | — | `{"patient": "MRN-...", "encounter": "HLC-ENC-..."}` |
| `sources` | array / JSON string | — | subset of `["clinical_web", "library"]` |
| `urls` | array / JSON string | — | pasted pages, **max 5** |
| `template_id` | string | — | e.g. `"TMPL-00004"` |
| `library_doc_ids` | array / JSON string | — | pinned My Library files, **max 20** |

Sending none of the five optional inputs behaves exactly as if they did not exist.

**Accepted uploads** (`services/narzim_assistant.py::_extract_document`): PDF, Excel
(`.xlsx`/`.xls`), CSV, text (`.txt`), Word (`.docx`/`.doc`), PowerPoint (`.pptx`), and images
(PNG/JPEG/WEBP/GIF). Anything else is a `ValidationError`. An image with no readable text is sent
to the vision model; a file from which no text can be extracted **and** which is not a decodable
image is refused, because personal details cannot be masked before the content reaches the
provider.

**200 OK**

```json
{
  "message": {
    "reply": "## Assessment\n\nLikely viral upper respiratory infection [1].\n\n## Plan\n\n- Supportive care\n",
    "reply_format": "markdown",
    "sources_used": ["clinical_web"],
    "template_used": "TMPL-00004",
    "references": [
      {
        "index": 1,
        "kind": "guideline",
        "title": "Bright Futures / AAP periodicity schedule",
        "url": "https://www.aap.org/en/practice-management/bright-futures/",
        "snippet": "Annual well-child visits are recommended from age 3…",
        "publisher": "American Academy of Pediatrics",
        "published_date": "2026-01-01"
      }
    ],
    "message_name": "AINAM-2026-00124",
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "model": "gpt-5-mini",
    "tokens_in": 4210,
    "tokens_out": 830,
    "cost_usd": 0.011,
    "refused": false
  }
}
```

**Every one of those 12 fields is always present**, including on a refusal and on a plain reply
with no retrieval — so you never have to treat "absent" as a third case. `sources_used`,
`references` and `template_used` are empty/`null` when nothing was retrieved or applied.

- `reply_format` — `"plain"` | `"markdown"`. Always `"plain"` while
  `AI Settings.narzim_reply_markdown` is off (§0.6), and always `"plain"` on a refusal, because the
  refusal is a fixed constant string.
- `sources_used` — only sources that **actually returned text**. A citation is never emitted
  without a retrieve.
- `references[]` — full shape in §5.2. Optional fields are **omitted, not null**.
- `refused` — `true` when the scope gate or the vision guard refused the turn. The reply is still a
  normal 200 with readable text; `model` is `""` and all token counts are `0`, because no answering
  call was made.

**403** — the PHI guard fired (the message named a patient in free text rather than linking one):

```json
{
  "exception": "frappe.exceptions.PermissionError",
  "_server_messages": "[\"Narzim GPT cannot see patient records…\"]"
}
```

> **Why that is a 403 and not a silent strip:** identity must arrive as a linked id, never as free
> text (ADR-075). The `context` chip is the supported way to talk about a patient; typing the name
> into the message is not, and is refused rather than quietly redacted so the clinician knows the
> question was not answered the way they meant it.

### 2.2 `send_message_stream`

Identical contract, permissions and file handling to §2.1 — only the delivery differs.

```
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.narzim_assistant.api.send_message_stream
Authorization: Bearer {{access_token}}
Accept: text/event-stream
```

**200 OK** — `text/event-stream`. Three frame types:

```
data: {"type":"delta","text":"For "}
data: {"type":"delta","text":"an 18 kg "}
data: {"type":"done","reply":"For an 18 kg child…","message_name":"AINAM-2026-00123","thread":"a1b2…","reply_format":"plain","model":"gpt-5-mini","tokens_in":1234,"tokens_out":567,"cost_usd":0.003,"references":[],"sources_used":[],"truncated":false,"refused":false}
```

⚠️ **The incremental frame is `"delta"`, not `"token"`.** The inventory doc says
`{"type":"token"}` — no such frame is ever emitted (§7.2).

| Frame | Fields | Meaning |
|---|---|---|
| `delta` | `text` | append to the bubble |
| `done` | `reply`, `message_name`, `thread`, `reply_format`, `model`, `tokens_in`, `tokens_out`, `cost_usd`, `references`, `sources_used`, `truncated`, `refused` | final metadata; `reply` is the complete text, so you can replace rather than trust your concatenation |
| `error` | `message` | generation failed **after** the stream began |

- `truncated: true` means the token budget cut the answer off mid-sentence. Say so in the UI rather
  than leaving the clinician to wonder.
- **Errors before the first byte are real HTTP errors, not frames.** The generator is primed before
  the `Response` is built, so a missing thread, an unsupported file, a bad linked id or a provider
  401/429 still raises inside the normal request cycle and you get a proper status code. Only a
  failure *after* text has started flowing arrives as an `error` frame — by then the 200 is already
  sent. Handle both paths.
- A client disconnect is handled server-side: whatever text had arrived is persisted, so the turn
  is not lost from the thread.
- The response sets `X-Accel-Buffering: no`. If you proxy it, **do not re-buffer** — nginx's default
  would collect the whole stream and deliver it as one block, which works locally and is silently
  broken in production.

### 2.3 `get_thread`

```
POST …narzim_assistant.api.get_thread
{ "thread": "a1b2c3-4d5e-6f70-8901-234567890abc" }
```

Send `{"thread": ""}` or `{}` to get the user's **most recent** thread — so reopening the assistant
continues the last conversation instead of starting blank.

**200 OK**

```json
{
  "message": {
    "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
    "messages": [
      {
        "id": "AINAM-2026-00122",
        "role": "user",
        "content": "dosing in an 18 kg child",
        "reply_format": "plain",
        "context": { "patient": "MRN-2026-0001433", "encounter": "HLC-ENC-2026-00008" },
        "sources_requested": ["clinical_web"],
        "urls": [],
        "library_doc_ids": [],
        "template_requested": "TMPL-00004",
        "sources_used": [],
        "template_used": null,
        "references": [],
        "model": null,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost_usd": 0.0,
        "attached_file": null,
        "feedback": "",
        "feedback_note": ""
      },
      {
        "id": "AINAM-2026-00123",
        "role": "assistant",
        "content": "For an 18 kg child…",
        "reply_format": "markdown",
        "context": null,
        "sources_requested": [],
        "urls": [],
        "library_doc_ids": [],
        "template_requested": null,
        "sources_used": ["clinical_web"],
        "template_used": "TMPL-00004",
        "references": [ { "index": 1, "kind": "literature", "title": "…", "pmid": "39123456" } ],
        "model": "gpt-5-mini",
        "tokens_in": 1234,
        "tokens_out": 567,
        "cost_usd": 0.003,
        "attached_file": null,
        "feedback": "Up",
        "feedback_note": ""
      }
    ]
  }
}
```

Oldest first. Per-message notes:

- **`context` is `null` when nothing was linked** — not `{}`. Test truthiness.
- `reply_format` is **per message**, so a thread spanning the markdown flag being switched on still
  renders its older replies as plain text.
- The user turn carries what was **requested** (`sources_requested`, `urls`, `library_doc_ids`,
  `template_requested`); the assistant turn carries what was **used** (`sources_used`,
  `template_used`, `references`). Replay both — a refresh that silently drops the chips reads as if
  they were never attached, and the clinician cannot tell that the next question will be answered
  with less context than the last.
- `references` is **always an array, never absent**, so a reply that predates citations and a reply
  with none look identical to your renderer.

### 2.4 `list_threads`

```
POST …narzim_assistant.api.list_threads
{}
```

**200 OK** — ⚠️ the array is **nested under `threads`**, not returned bare. The inventory shows
`{"message": [...]}` (§7.3).

```json
{
  "message": {
    "threads": [
      {
        "thread": "a1b2c3-4d5e-6f70-8901-234567890abc",
        "preview": "Amoxicillin dosing in a toddler",
        "count": 12,
        "last": "2026-09-17 14:02:11"
      }
    ]
  }
}
```

Newest activity first, this user's own threads only. `preview` is the auto-generated thread title
when one exists, falling back to the first 80 characters of the first user message, falling back to
`"…"` — so it is never empty.

### 2.5 `hide_thread` / `hide_all_threads`

```
POST …narzim_assistant.api.hide_thread        { "thread": "a1b2c3-…" }
POST …narzim_assistant.api.hide_all_threads   {}
```

```json
{ "message": { "thread": "a1b2c3-…", "hidden": 14 } }
{ "message": { "hidden": 132 } }
```

`hidden` is the number of rows filtered out of the read paths.

> **These are NOT deletes, and the UI must not say "delete".** The rows are retained and only
> excluded from the read paths — this is a `write` permission, not `delete`, which is why every
> clinical role can do it while `delete` stays `0` for all of them. `content` is free text a human
> typed, so destroying it would destroy the record of what was asked.

### 2.6 `set_feedback`

```
POST …narzim_assistant.api.set_feedback
{ "message": "AINAM-2026-00123", "feedback": "Up", "note": "clear and correct" }
```

⚠️ **There is no `thread` argument.** The first field is literally called `message` and takes the
**message id** (`AINAM-…`), not the message text. `feedback` is `"Up"` | `"Down"` | `""` (clears).

**200 OK** — ⚠️ not `{"ok": true}`, which is what the inventory claims (§7.4):

```json
{ "message": { "message": "AINAM-2026-00123", "feedback": "Up", "feedback_note": "clear and correct" } }
```

The echo is the stored state — render from it rather than from optimistic local state, so a cleared
vote and a failed write look different.

### 2.7 `get_suggestions`

```
POST …narzim_assistant.api.get_suggestions
{}
```

```json
{
  "message": {
    "suggestions": [
      { "title": "Pediatric dosing", "prompt": "What is the weight-based pediatric dose of amoxicillin?" },
      { "title": "Red flags", "prompt": "What are the red flags in a child with a fever lasting more than three days?" },
      { "title": "Differential", "prompt": "What is the differential diagnosis for a persistent cough in a four-year-old?" },
      { "title": "Note structure", "prompt": "Give me a SOAP note structure for a well-child visit." }
    ]
  }
}
```

Starter cards for an empty chat. `title` is the card face; `prompt` is what you send as
`send_message.message`. A client that wants a single string uses `prompt`.

> **Worth the round trip even though you could hardcode cards** — it does three things the browser
> cannot: picks the set matching the user's **role** (server-side truth), returns it in the user's
> **language** through the app's own catalogue (`CLAUDE.md` §13 rule 10 forbids hardcoded
> user-visible strings), and names a medication **this clinic actually stocks**. Deterministic — no
> model call, so it is instant and free. It never raises for lack of content: an empty formulary or
> an unknown role yields the practitioner set rather than an empty state inside an empty state.

### 2.8 `get_usage_summary`

```
POST …narzim_assistant.api.get_usage_summary
{ "from_date": "2026-09-01", "to_date": "2026-09-30" }
```

Both dates optional. **Admin only** — anyone else gets a 403.

```json
{
  "message": {
    "usage": [
      { "user": "doctor@clinic.mx", "message_count": 214, "tokens_used": 483920, "cost_usd": 1.94 }
    ]
  }
}
```

Visibility only. There is no enforcement behind it — do not build a "quota exceeded" state.

### 2.9 Scope refusals — not an endpoint, a response you must render

When `AI Settings.narzim_scope_mode` is `Enforce` and the classifier judges a question outside
clinical scope, `send_message` returns a normal **200** with `refused: true`, a fixed refusal
string as `reply`, `reply_format: "plain"`, `model: ""` and zero tokens. The streaming path emits
the same text as a single `delta` followed by a `done` frame with `refused: true`.

Both the question and the refusal are persisted and replayed by `get_thread` (ADR-034): a thread
that silently dropped the question it refused would read as if the user never asked anything, and
the refusal rate could not be audited afterwards. **Render a refused turn as a normal assistant
message with a distinct treatment — not as an error toast.**

### 2.10 `list_sources`

```
POST …narzim_assistant.api.list_sources
{}
```

```json
{
  "message": {
    "sources": [
      {
        "type": "clinical_web",
        "enabled": false,
        "label": "Clinical Web",
        "description": "PubMed, WHO, CDC, AAP, and clinical practice guidelines",
        "reason": "No literature provider has been approved for this clinic yet."
      },
      {
        "type": "library",
        "enabled": true,
        "label": "My Library",
        "description": "Your files and URLs",
        "reason": ""
      }
    ]
  }
}
```

**Draw one toggle per entry and grey out the disabled ones.** `label` and `description` are already
localised — do not hardcode them.

> **`enabled` is computed live, never hardcoded.** Clinical Web is on only when the active
> `ComplianceProfile` names an approved retrieval provider (PHI-1); My Library is on only when
> Frappe Drive is installed **and** has a clinic team. A toggle that is offered and then fails is
> worse than one that is visibly unavailable, which is why this endpoint exists at all.

`reason` explains a greyed toggle — show it as a tooltip. A greyed control with no explanation
sends the clinician to support. It is `""` when the source is enabled.

**URL pasting is deliberately not a fourth entry.** It is gated separately and rides on
`send_message.urls`.

---

## 3. Templates — `api/v1/narzim_assistant/templates.py`

⚠️ **Route file is `.templates.`, not `.api.`** for all 13.

`AI Chat Template` fields: `title`, `description`, `category`, **`body_markdown` (canonical)**,
`is_default`, `is_system`, `version`, `duplicate_from`, `owner`.

`category` ∈ `"general"` | `"encounter"` | `"document"` | `"analysis"`. Anything else is a
`ValidationError` naming the allowed set.

**Permissions:** System Manager everything · Practitioner full CRUD on their own rows plus read on
system rows · Nurse / Front Desk read own + system. An `is_system` row can be **read and duplicated
by anyone, written by nobody** — edit or delete it and you get a refusal telling you to duplicate
first.

### 3.1 `list_templates`

```
POST …narzim_assistant.templates.list_templates
{ "category": "", "page": 1, "page_size": 50 }
```

`category` empty means all. `page_size` is capped at **200**.

```json
{
  "message": {
    "templates": [
      {
        "id": "TMPL-00004",
        "name": "Pediatric SOAP Note",
        "description": "Standard paediatric consultation note",
        "category": "encounter",
        "is_default": true,
        "is_system": true,
        "version": 1,
        "updated_at": "2026-09-17 14:02:11",
        "can_edit": false
      }
    ],
    "total": 12,
    "page": 1,
    "page_size": 50
  }
}
```

⚠️ The array is under `templates` with `total`/`page`/`page_size` as siblings — **not** a bare
array, and **not** envelope (b)'s `pagination` object. the inventory shows a bare array (§7.3).

- `id` is the opaque row name (`TMPL-00004`); `name` is the human title. Split deliberately, matching
  the rest of the codebase's list convention (in `patients.api`, `mrn` is the id and `name` is the
  label). **Show `name`, send `id`.**
- **`can_edit` is server-computed** — grey out edit/delete from it rather than re-deriving
  "not system and mine", which drifts. The server stays authoritative either way.
- Ordered system-first, then most recently changed, so a new user sees the curated set before
  anything they have made.

### 3.2 `get_template`

```
POST …narzim_assistant.templates.get_template
{ "template_id": "TMPL-00004" }
```

The §3.1 row **plus**:

```json
{
  "message": {
    "id": "TMPL-00004",
    "name": "Pediatric SOAP Note",
    "description": "Standard paediatric consultation note",
    "category": "encounter",
    "is_default": true,
    "is_system": true,
    "version": 1,
    "updated_at": "2026-09-17 14:02:11",
    "can_edit": false,
    "body_markdown": "## Subjective\n\n- [Reason for visit] (State the primary reason…)\n",
    "sections": [
      { "heading": "Subjective", "level": 2, "slot_count": 4 },
      { "heading": "Plan", "level": 2, "slot_count": 2 }
    ],
    "duplicate_from": null
  }
}
```

### 3.3 `create_template`

```
POST …narzim_assistant.templates.create_template
{
  "name": "My SOAP",
  "description": "",
  "category": "general",
  "body_markdown": "## Subjective\n\n- [Reason for visit] (State the primary reason…)\n",
  "duplicate_from": "TMPL-00004"
}
```

`name` is required. Returns the **full `get_template` shape** for the new row.

`duplicate_from` is how a clinician gets an editable copy of a system template: it records the
provenance, and the copy is owned by whoever asked. Its body is used **only when you did not supply
one**, so "duplicate and immediately edit" is a single call. `is_system` can never be set from a
request — otherwise a client could mint a row nobody, including its author, may edit or delete.

### 3.4 `update_template`

```
POST …narzim_assistant.templates.update_template
{ "template_id": "TMPL-00007", "body_markdown": "## Subjective\n…" }
```

**Partial** — every field is optional and only what you send is touched, so the editor can save a
structure change without resending metadata it never showed. Fields: `name`, `description`,
`category`, `body_markdown`, `is_default`. Returns the full `get_template` shape.

`version` bumps **only when `body_markdown` actually changes**.

### 3.5 `delete_template`

```
POST …narzim_assistant.templates.delete_template
{ "template_id": "TMPL-00007" }
```

```json
{ "message": { "deleted": "TMPL-00007" } }
```

Own rows only; a system row is refused with "duplicate it first".

### 3.6 `preview_sections`

```
POST …narzim_assistant.templates.preview_sections
{ "body_markdown": "## Subjective\n\n- [Reason for visit] (…)" }
```

```json
{ "message": { "sections": [ { "heading": "Subjective", "level": 2, "slot_count": 1 } ] } }
```

Parses an outline **without saving it** — a pure function of its input that touches no row and
needs no template to exist. Use it to drive the Structure tab as the clinician types; the
alternative (saving to read back `sections`) would version-bump the template dozens of times per
edit. Safe to debounce and call freely.

### 3.7 `apply_template`

```
POST …narzim_assistant.templates.apply_template
{
  "template_id": "TMPL-00004",
  "thread": "a1b2c3-…",
  "context": { "patient": "MRN-2026-0001433", "encounter": "HLC-ENC-2026-00008" },
  "sources": ["clinical_web"]
}
```

Fills the template into the chat thread as a **draft turn**.

```json
{
  "message": {
    "reply": "## Subjective\n\n- Fever for three days…",
    "reply_format": "markdown",
    "sources_used": [],
    "template_used": "TMPL-00004",
    "message_name": "AINAM-2026-00131",
    "user_message_name": "AINAM-2026-00130",
    "thread": "a1b2c3-…",
    "model": "gpt-5-mini",
    "tokens_in": 3120,
    "tokens_out": 640,
    "cost_usd": 0.008,
    "filled": true,
    "tools_used": ["get_patient_summary", "get_vitals"],
    "refused": false
  }
}
```

- **`filled`** distinguishes "nothing to fill from yet" from "filled, and every slot legitimately
  came back blank" — the two are indistinguishable from the text alone, and they need different
  empty states.
- `user_message_name` is returned here and not by `send_message`, because this path creates the user
  turn on the clinician's behalf and you may need to reference it.
- When `context` names a patient, the fill reads that chart through the **read-only** tool set. With
  no patient, it has only the conversation to work from.
- **It never writes the encounter.** This produces a draft in a chat thread; putting it into the
  record is a separate, physician-driven action (Rule 6).

### 3.8 `generate_template_example`

```
POST …narzim_assistant.templates.generate_template_example
{ "body_markdown": "## Subjective\n\n- [Reason for visit] (…)", "context": null }
```

```json
{
  "message": {
    "example_markdown": "## Subjective\n\n- Fever for three days, no rash…",
    "model": "gpt-5-mini",
    "prompt_version": "narzim-template-example-v1",
    "tokens_in": 410,
    "tokens_out": 220,
    "cost_usd": 0.001,
    "context_used": false
  }
}
```

An entirely **fictional** worked example, for the editor's Example tab. Takes the body from the
request rather than a template id, because the point is to preview what the clinician is typing
right now — unsaved, and possibly never saved.

> ⚠️ **`context` is accepted and deliberately ignored; `context_used` is always `false`.** An
> example is rendered into an editor preview and cached in an edit session, so real patient data
> there would be PHI sitting outside every retention and erasure path that covers a thread (PHI-4).
> The flag is returned rather than the parameter dropped silently, because a client that sent it is
> entitled to know it had no effect. **Never persist `example_markdown`** — a filled example is
> synthetic PHI, and Save writes structure only.

### 3.9 `start_template_edit_session`

```
POST …narzim_assistant.templates.start_template_edit_session
{ "template_id": "TMPL-00004" }
```

```json
{
  "message": {
    "session_id": "ATES-2026-00007",
    "template_id": "TMPL-00004",
    "title": "Pediatric SOAP Note",
    "structure_markdown": "## Subjective\n\n- [Reason for visit] (…)\n",
    "version": 1,
    "is_copy": true
  }
}
```

The working outline lives on the server between calls, because Save sends `{session_id, name}` and
no markdown. Session TTL is **24 hours**, purged daily.

**`is_copy: true` means the source is a system template**, so Save will create the clinician's own
copy rather than write the original. Read-access is enough to open a session — that is the point:
open a system template, edit freely, Save makes it yours. **Show "Save as a copy" from this flag,
before any work is invested, not after.**

### 3.10 `edit_template_chat`

```
POST …narzim_assistant.templates.edit_template_chat
{
  "session_id": "ATES-2026-00007",
  "message": "Add a follow-up slot under Plan",
  "structure_markdown": "## Subjective\n…"
}
```

Two controls over one outline, and they may arrive together:

| Field | Effect |
|---|---|
| `structure_markdown` | what the canvas currently holds. Stored as-is. **No model call** — a manual edit is not a question |
| `message` | a plain-language request, applied to the outline *after* the manual edit above |

Sending **neither is an error**, not a no-op — it means the client thinks it asked for something.

```json
{
  "message": {
    "session_id": "ATES-2026-00007",
    "template_id": "TMPL-00004",
    "title": "Pediatric SOAP Note",
    "structure_markdown": "## Subjective\n…\n\n## Plan\n\n- [Follow-up] (…)",
    "version": 1,
    "is_copy": true,
    "model": "gpt-5-mini",
    "prompt_version": "narzim-template-edit-v1",
    "tokens_in": 380,
    "tokens_out": 190,
    "cost_usd": 0.001,
    "generated": true,
    "context_used": false
  }
}
```

`generated` is `false` for a hand edit — **do not show an "AI changed this" affordance over the
clinician's own typing**. `context` is accepted and not used here either (§3.8's reasoning: a
template is copied between clinicians and can be published clinic-wide).

**A 404 here means the session expired** — the message to show is "this editing session has
expired, open the template again". Expired and never-existed return the same error deliberately, so
the endpoint cannot be used to confirm which ids exist.

### 3.11 `save_template_session`

```
POST …narzim_assistant.templates.save_template_session
{ "session_id": "ATES-2026-00007", "name": "My paediatric SOAP" }
```

```json
{
  "message": {
    "session_id": "ATES-2026-00007",
    "saved": true,
    "template": { "id": "TMPL-00019", "name": "My paediatric SOAP", "...": "full get_template shape" }
  }
}
```

**Structure only** — a filled example is never persisted, and cannot be, because the session never
held one.

Two destinations, decided by `is_copy` from §3.9:

| Source | What Save does | `name` |
|---|---|---|
| system template | creates a new row the clinician owns | **required** — a copy that silently takes its parent's title is indistinguishable from it in the list |
| their own template | updates in place, bumping `version` only if the structure changed | optional |

Read `template.id` from the response — **on the copy path it is a new id**, and the editor must
rebind to it.

### 3.12 `generate_template`

```
POST …narzim_assistant.templates.generate_template
{
  "encounter_ids": ["HLC-ENC-2026-00008", "HLC-ENC-2026-00011"],
  "name": "",
  "category": "encounter"
}
```

At least 1, **at most 5** visit ids (array or JSON string).

```json
{
  "message": {
    "id": null,
    "name": "",
    "body_markdown": "## Subjective\n\n- [Chief complaint] (…)\n\n## Plan\n…",
    "category": "encounter",
    "sections_used": [
      { "section": "Subjective", "encounters": 5 },
      { "section": "Plan", "encounters": 4 }
    ],
    "encounters_read": 5,
    "worded_by_model": true,
    "model": "gpt-5-mini",
    "prompt_version": "narzim-template-generate-v1",
    "tokens_in": 240,
    "tokens_out": 310,
    "cost_usd": 0.001
  }
}
```

**`id` is `null` — the template is NOT saved.** The clinician reviews it and saves it through
`create_template`, so an unwanted suggestion costs nothing to discard.

- `worded_by_model: false` means the provider failed or returned something that was not a template,
  and you got the deterministic fallback. Say "wording is basic because the assistant was
  unavailable" rather than silently offering a worse result.
- `sections_used` is the evidence for the suggestion — show it, so the clinician can see *why* these
  sections were chosen.

> **Nothing from a patient's record reaches the model.** The visits are read locally only to count
> **which sections** this clinician uses; the model receives only those section names, from a fixed
> vocabulary. The output is a blank form, and clinical content is not needed to produce one
> (PHI-6). "PHI stripped" would be the wrong description — there is nothing to strip, because
> nothing patient-derived is sent.

### 3.13 `suggest_templates`

```
POST …narzim_assistant.templates.suggest_templates
{ "thread": "a1b2c3-…", "message": "write up this vaccination visit" }
```

```json
{
  "message": {
    "suggestions": [
      {
        "id": "TMPL-00009",
        "name": "Immunization visit",
        "description": "",
        "category": "encounter",
        "is_system": false,
        "score": 2,
        "matched_on": ["vaccination", "visit"]
      }
    ],
    "offer_to_save": false,
    "save_candidate": null,
    "considered_turns": 6,
    "context_used": false
  }
}
```

Max 5 suggestions, from the last 6 turns of the thread. **Deterministic — no model call**, so it is
instant and free and safe to call on every turn.

- `matched_on` is why each suggestion appeared. **Show it** — a suggestion a clinician cannot
  explain is one they cannot sensibly reject.
- `offer_to_save` is `true` only when the clinician has effectively hand-built a structure in the
  thread **and** no existing template already covers it. `save_candidate` is the text to prefill the
  "save as template" dialog. **This endpoint writes nothing** — the clinician still creates it via
  `create_template`.

### 3.14 `body_markdown` — the slot language

```markdown
## Subjective

- [Reason for visit or chief complaint] (State the primary reason for the consultation. Only
  include if explicitly mentioned in the transcript or clinical note; otherwise leave blank.)
- [Vital signs] (Include temperature, pulse, blood pressure, oxygen saturation…)
```

`[slot]` is a value to fill; `(parenthetical)` is an instruction to the model. Fill rules, which
the editor's help text should reflect: replace a `[slot]` only with a value actually available;
**never print the parentheses**; if nothing was said, leave the bullet blank — do **not** write "not
mentioned"; never invent patient details.

Legacy system rows may still use `{{placeholders}}` with `<!-- AI instructions -->`. Accept both on
read; persist the `[slot] (instruction)` form after an edit.

**A template body may not name a patient.** It is refused at save time as well as at fill time,
because a template is a shared object that gets copied between clinicians.

---

## 4. Supporting endpoints

These are **not** Narzim methods — they use envelope **(a)** or **(b)** (`res.data`), not
`res.message`.

### 4.1 `list_patients` — "Link patient"

```
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.patients.api.list_patients
{ "search": "renata", "page": 1, "page_size": 10 }
```

Envelope **(b)**:

```json
{
  "status": "success",
  "data": [
    {
      "mrn": "MRN-2026-0001433",
      "name": "Renata Martínez Cruz",
      "gender": "Female",
      "dob": "12-03-1981",
      "age": "45 Yrs 06 months 05 days",
      "status": "Active",
      "mobile": "+52 55 1234 5678",
      "email": "renata@example.com",
      "image": null,
      "lastVisit": "2026-09-17",
      "primaryPractitioner": "HLC-PRAC-2026-00045"
    }
  ],
  "pagination": { "total": 137, "page": 1, "page_size": 10 }
}
```

➡️ **Send `data[i].mrn` as `send_message.context.patient`.**

`search` substring-matches MRN, patient name, mobile, email, or a linked guardian's name. 21 other
filters exist and are irrelevant to the picker. **Do not build a `search_patients` endpoint** — this
one already is it.

### 4.2 `list_encounters` — "Link visit"

```
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.encounters.api.list_encounters
{ "patient": "MRN-2026-0001433", "page": 1, "page_size": 10, "exclude_cancelled": 1 }
```

```json
{
  "status": "success",
  "data": [
    {
      "name": "HLC-ENC-2026-00008",
      "patient": "MRN-2026-0001433",
      "patient_name": "Renata Martínez Cruz",
      "practitioner": "HLC-PRAC-2026-00045",
      "practitioner_name": "Anant Sharma",
      "encounter_date": "2026-09-17",
      "encounter_time": "14:45:00",
      "medical_department": "General Physician",
      "status": "Open",
      "docstatus": 0
    }
  ],
  "pagination": { "total": 3, "page": 1, "page_size": 10 }
}
```

➡️ **Send `data[i].name` as `send_message.context.encounter`.**

Filters: `patient`, `date`, `from_date`/`to_date`, `practitioner`, `status`, `status_in`,
`exclude_cancelled`, `page`, `page_size`. `date` and the range are mutually exclusive — `date` wins.
Scope the picker to the patient just linked.

> **Always send the id, never the display name.** ADR-075 and the PHI guard both depend on identity
> arriving as a structured id; a patient named in free text is refused (§2.1's 403).

### 4.3 My Library — `drive.api.*`

⚠️ **PR #493 points at `clinical_documents.api`. That module does not exist** —
`api/v1/clinical_documents/` holds only `__pycache__`. My Library is Frappe Drive:

```
POST …drive.api.list_entries   { "parent": null, "search": "", "flat": 0 }
POST …drive.api.upload         multipart: file=<the document>, parent=<folder id, optional>
POST …drive.api.trash          { "id": "<entry id>" }
POST …drive.api.get_entry      { "id": "<entry id>" }
GET  …drive.api.download       { "id": "<entry id>" }
POST …drive.api.summarize_entry { "id": "<entry id>", "lang": "es" }
POST …drive.api.ask_entry      { "id": "<entry id>", "question": "what was the HbA1c?", "lang": "es" }
```

Envelope **(a)** — read `res.data`.

- `list_entries` returns **one level** by default (`parent: null` is the team root), which is what a
  folder-navigating UI wants. `flat: 1` returns every entry in the team regardless of depth, each
  still carrying its `parent` — use it to show counts or filter across everything without N round
  trips.
- **`summarize_entry` and `ask_entry` already do document Q&A**, citing the pages used. Check them
  before writing new library-search code; the overlap with what the PR wants "My Library" to do is
  real. Pass `lang` — the portal keeps the locale in a cookie and never writes it to
  `User.language`, so without it a Spanish reader asking about an English PDF is answered in
  English.
- ⚠️ **Upload allowlist** (`services/drive.py`) is `jpg jpeg png gif webp bmp tiff svg pdf xlsx xls
  csv` — **no `.docx`, no `.txt`.** A `.docx` upload is rejected today. Note this is *narrower* than
  what `send_message`'s own attachment path accepts (§2.1).
- ➡️ Pin a file on a turn by sending its entry id in `send_message.library_doc_ids` (max 20).
- **`api/v1/documents/api.py` is a different thing** — Patient Medical Record rows, i.e. the
  patient's chart files, not the doctor's personal library. Use it for the optional "patient files
  as extra context", never for My Library.

### 4.4 `transcribe_audio` — mic dictation

```
POST {{base_url}}/api/method/remedisys_healthcare_ai.api.v1.ai.api.transcribe_audio
{ "audio_b64": "GkXfo59ChoEBQveBAULyg..." }
```

`encounter` is **optional** — the Narzim composer and the template editor dictate into a text field
that belongs to no visit. Passing one (`{"encounter": "HLC-ENC-2026-00008", "audio_b64": "..."}`)
is unchanged in every respect. Both shapes return the identical payload:

```json
{
  "message": {
    "segments": [
      { "speaker": "doctor", "text": "How long has the fever lasted?", "start": 0.0, "end": 2.4, "confidence": 0.98 }
    ],
    "transcript": "Doctor: How long has the fever lasted?\nPatient: About three days."
  }
}
```

`audio_b64` is base64 of webm/opus from `MediaRecorder`. Missing it is a `ValidationError`
("audio_b64 is required."); undecodable base64 is "Invalid audio_b64 — base64 decode failed."

**Audio is never stored** — processed in memory and discarded immediately after the provider
responds (`audio_retention_days = 0`). Deepgram usage is audited on both paths, so billed usage is
never unaccounted.

> ⚠️ **A frontend one-liner still blocks this, and it is yours to change.**
> `EB_Healthcare_Frontend/src/app/api/ai/transcribe/route.ts:19` rejects the request before it
> reaches Frappe:
> ```ts
> if (!body?.encounter || !body?.audioB64) {
>   return Response.json({ error: "encounter and audioB64 are required" }, { status: 400 })
> }
> ```
> It must become `if (!body?.audioB64)`, and `TranscribeBody.encounter` must become optional
> (`encounter?: string`). The backend accepts either shape today, so this change is safe to make at
> any time and breaks nothing that currently works.

---

## 5. Shared object shapes

### 5.1 `context` — the linked patient / visit chip

```json
{ "patient": "MRN-2026-0001433", "encounter": "HLC-ENC-2026-00008" }
```

Both keys optional; either may appear alone. Accepted by `send_message`, `send_message_stream` and
`apply_template`; accepted-but-ignored by `generate_template_example`, `edit_template_chat` and
`suggest_templates` (each reports `context_used: false`).

**Every id is re-authorised against the session user on every turn**, because the picker runs in the
browser and the id arrives as a plain string. An id the user may not see is refused as *unknown*,
not *forbidden* (§6.3).

### 5.2 `references[]` — a citation

```json
{
  "index": 1,
  "kind": "literature",
  "title": "Amoxicillin dosing in paediatric community-acquired pneumonia",
  "url": "https://pubmed.ncbi.nlm.nih.gov/39123456/",
  "snippet": "High-dose amoxicillin remains first-line…",
  "publisher": "Pediatrics",
  "published_date": "2026-01-01",
  "authors": "García R, Solano M",
  "pmid": "39123456",
  "doi": "10.1542/peds.2026.0001",
  "library_doc": "abc123def"
}
```

| Field | Always present | Notes |
|---|---|---|
| `index` | ✅ | matches the `[n]` marker in the reply text; the array is sorted by it |
| `kind` | ✅ | `"library"` \| `"literature"` \| `"guideline"` \| `"url"` |
| `title` | ✅ | may be `""` |
| everything else | — | **omitted entirely when empty, never `null`** |

That last row matters: the optional fields are absent rather than null, so check presence, not
nullness. `library_doc` is the Drive entry id — link it back to the file in My Library.

`references` is **always an array** on `send_message`, on the `done` frame, and on every message in
`get_thread`. Never absent, so "no citations" and "this reply predates citations" look identical to
your renderer.

### 5.3 Message ids

| Prefix | Doctype | Example |
|---|---|---|
| `AINAM-` | `AI Narzim Assistant Message` | `AINAM-2026-00123` |
| `TMPL-` | `AI Chat Template` | `TMPL-00004` |
| `ATES-` | `AI Template Edit Session` | `ATES-2026-00007` |
| `MRN-` | `Patient` | `MRN-2026-0001433` |
| `HLC-ENC-` | `Patient Encounter` | `HLC-ENC-2026-00008` |

`thread` is **not** a doctype id — it is a client-generated uuid you mint for a new chat.

---

## 6. Limits, validation and error messages

### 6.1 Hard limits — enforce these client-side too, so the user finds out before the round trip

| Input | Limit | Message when exceeded |
|---|---|---|
| `urls` | **5** per message | "At most 5 links can be attached to one message." |
| `library_doc_ids` | **20** per message | "At most 20 library documents can be pinned to one message." |
| `template_id` | 140 chars | "template_id is too long." |
| `encounter_ids` (`generate_template`) | 1–**5** | "Choose at most 5 visits." / "Choose at least one visit…" |
| `page_size` (`list_templates`) | 200 | silently clamped |
| `suggest_templates` | 5 suggestions, 6 turns read | — |

### 6.2 URL rules — the SSRF guard

A pasted URL is fetched **by our server**, so it is screened before acceptance:

| Rejected | Message |
|---|---|
| non-`http(s)` scheme | "Only http(s) links are allowed: {url}" |
| no host | "That link has no host: {url}" |
| `localhost`, `*.localhost` | "That link points at this server: {url}" |
| literal private / loopback / link-local / reserved / multicast IP | "That link points at a private address: {url}" |

A public hostname that resolves to a private address is re-checked at fetch time — so a URL can pass
this validation and still fail later. Surface that later failure rather than assuming acceptance
means success.

### 6.3 Unknown vs forbidden — deliberately indistinguishable

An id you may not see returns **the same error as one that does not exist**, for linked patients,
linked visits, pinned library files and edit sessions. For a document titled after a patient, a 403
is itself a disclosure. **Do not write UI copy that distinguishes them** ("you don't have access to
this file") — say "not found" and mean it.

### 6.4 Validation messages worth mapping

| Input | Message |
|---|---|
| any of the five, malformed | "{field} is not valid JSON." / "{field} must be JSON." |
| `sources` not an array | "sources must be a JSON array." |
| unknown source value | names the allowed set |
| unknown `category` | "Unknown category: {x}. Allowed: general, encounter, document, analysis" |
| `edit_template_chat` with neither input | "Send the edited outline, a change to make, or both." |
| expired session | "This editing session has expired. Open the template again." |
| Drive missing | "My Library is not available on this site." |
| empty upload | "The uploaded file is empty." |
| unsupported upload | "Unsupported file type. Supported: PDF, Excel (.xlsx/.xls), CSV, text (.txt), Word (.docx/.doc), PowerPoint (.pptx), and images (PNG/JPEG/WEBP/GIF)." |
| unreadable upload | "Could not read any text from this {kind} file…" |

All are already localised server-side — **render the server's message rather than substituting your
own string**, or the `es-MX` user gets an English one (`CLAUDE.md` §13 rule 10).

---

## 7. Six errors in the inventory doc — read this if you started from it

[`NARZIM_GPT_BACKEND_INVENTORY.md`](../ai/NARZIM_GPT_BACKEND_INVENTORY.md) v3.12 was written while
the backend was still being built, and six of its statements no longer match the shipped code. They
are listed here rather than fixed there, because that document is the build record and its payload
examples are evidence of what was planned at the time. **For anything below, this document is
authoritative.**

| # | The inventory says | Actually |
|---|---|---|
| 7.1 | Template routes are `…narzim_assistant.api.<fn>` | **`…narzim_assistant.templates.<fn>`.** The `.api.` spelling 404s. Templates moved into their own module after that text was written |
| 7.2 | SSE frames are `{"type":"token","text":…}` | **`{"type":"delta","text":…}`.** No `token` frame is ever emitted |
| 7.3 | `list_threads` → `{"message":[…]}`; `list_templates` → `{"message":[…]}` | Both are **nested objects**: `{"message":{"threads":[…]}}` and `{"message":{"templates":[…],"total":n,"page":n,"page_size":n}}` |
| 7.4 | `set_feedback` → `{"ok": true}` | Returns the **stored state**: `{"message":…,"feedback":…,"feedback_note":…}` |
| 7.5 | `send_message` accepts **PDF only** | Accepts PDF, Excel, CSV, txt, Word, PowerPoint and images. Note this differs from the *Drive upload* allowlist (§4.3), which is narrower and still lacks `.docx`/`.txt` |
| 7.6 | `generate_template_example` → `{"example_markdown": …}` | Also returns `model`, `prompt_version`, `tokens_in`, `tokens_out`, `cost_usd`, `context_used` |

Also now stated where it matters, having been absent before: `can_edit` on template rows,
`reason` on sources, `filled` / `tools_used` on `apply_template`, `truncated` on the `done` frame,
and the fact that optional `references[]` fields are **omitted rather than null**.

---

## 8. Binding order — the shortest path to a working screen

1. **`list_sources`** first. It decides what the Sources bar may even offer, and both toggles are off
   on a fresh site (§0.6) — bind it before you conclude the toggles are broken.
2. **`get_suggestions` → `send_message` → `get_thread` → `list_threads`.** That is a complete, useful
   chat with no optional inputs at all.
3. **Add the five composer inputs** (§2.1). Sending none of them is exactly today's behaviour, so
   add them one at a time.
4. **Swap in `send_message_stream`** once the blocking path works. Keep `send_message` — it is the
   real fallback, and the two are at full parity including retrieval and citations.
5. **Pickers** (§4.1, §4.2) → the `context` chip.
6. **Templates**: list → get → apply. Then the editor session (§3.9–3.11), which is the most stateful
   piece and the one worth doing last.
7. **Mic** (§4.4) — and remember the BFF one-liner is yours.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-21 | Divyanshu (AI-assisted) | Initial version. All 28 endpoints for PR #493 with route, payload, response JSON, limits and errors, verified against `feature/narzim-gpt`. Supersedes the inventory doc's payload examples for calling purposes (§7) |
