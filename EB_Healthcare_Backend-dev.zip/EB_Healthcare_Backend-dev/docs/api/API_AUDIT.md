# API audit — coverage, security, contract and hygiene

**Doc status:** record · **Created:** 2026-09-03 by Invincible · **Updated:** 2026-09-03 by Invincible · **Version:** 1.0

> One audit for the backend API surface. Produced by scripted analysis over all
> **485 whitelisted methods**, the 232-request Bruno collection and all three
> frontends (clinic app + both patient-portal repos), then **hand-verified**.
>
> Verification matters here: twelve automated checks produced roughly five false
> positives for every real finding. §9 lists every false positive with the reason
> it is not a bug, so nobody re-raises them.

**Status:** Audit only — no code changed.
**Owner:** Backend.
**Created:** 2026-08-19 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
**Last updated:** 2026-08-19 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
<sub>Editing this file? Update **Last updated** with your name and date.</sub>

**Verified against:** backend `dev` @ `6744129` · frontend `dev` @ `9f82b1b`.
**Companions:** [`API_SPEC.md`](API_SPEC.md) — the contract; §16 is the generated
index of all 485 endpoints · [`DRIVE_FRONTEND_INTEGRATION.md`](DRIVE_FRONTEND_INTEGRATION.md)
— how-to for the installed Drive app.

---

## 1. Findings

| # | Finding | Severity | Scale |
|---|---|---|---|
| **F1** | ~~WhatsApp webhook accepts **unauthenticated** POSTs~~ — **RESOLVED 2026-08-31.** Residual: an unconfigured `WHATSAPP_APP_SECRET` warns instead of rejecting | ~~P0~~ → **P2 residual** | 1 endpoint |
| **F2** | LLM clinical output (SOAP, suggestions, transcript) written to the Frappe **Error Log** — Rule 10 | **P0 compliance** | **11 sites** |
| **F3** | Two frontend routes call backend methods that **do not exist** | **P0 correctness** | 2 routes |
| **F4** | Two response-envelope styles; the spec documents only one | **P1 contract** | 43 endpoints |
| **F5** | Eight modules have **zero** contract tests — incl. all AI and all portal | **P1 coverage** | 123 methods |
| **F6** | Every invoice-creating method is untested at request level | **P1 coverage** | 18 of 24 in `billing` |
| **F7** | 126 methods have no frontend caller — incl. the whole `procedures` lifecycle | **P1 dead surface** | 126 methods |
| **F8** | Duplicate BFF routes for the same backend method | P2 | 2 pairs |
| **F9** | BFF routes with no frontend consumer | P2 | 11 of 239 |
| **F10** | Patch files that exist but are not registered in `patches.txt` — they never run | P2 | **4 files** (+2 disabled on purpose) |
| **F11** | Unauthenticated (`allow_guest`) endpoints with no test | P2 | 2 of 4 |
| **F12** | Unbounded queries in whitelisted endpoints | P3 | 22 (mostly scope-bounded) |
| **F13** | Two API modules have no test directory | P3 | `company`, `messages` |

### Coverage headlines

| Metric | Count |
|---|---|
| Whitelisted methods | **485** |
| Called by at least one frontend | 359 |
| **No frontend caller** | **126** |
| Covered by a Bruno request | 168 |
| **No Bruno request** | **317 (65%)** |
| **Neither frontend nor Bruno** | **76** |
| `allow_guest=True` | 4 |

Two-thirds of the API has no executable contract test, and the modules with *zero*
coverage are the newest and most sensitive: AI, patient portal, messaging,
clinical documents.

---

## 2. F1 — Unauthenticated WhatsApp webhook `RESOLVED 2026-08-31`

> **RESOLVED upstream on 2026-08-31**, after this audit was written.
> `_verify_meta_signature()` (`integrations/whatsapp/webhook.py:71`) now checks Meta's
> `X-Hub-Signature-256` HMAC-SHA256 over the raw body, compared with
> `hmac.compare_digest`; a missing, malformed or mismatched signature is a 403 and
> nothing is persisted. Covered by `tests/security/test_whatsapp_webhook_signature.py`.
>
> **The residual, deliberately:** when `WHATSAPP_APP_SECRET` is unset the request is
> accepted with a warning rather than rejected, so a site with no secret configured is
> still unauthenticated. That is a documented go-live gate (`REQUIREMENTS_FOR_HIPAA_AND_SOC2.md`
> gap #4), not an oversight — rejecting would take inbound patient messaging down.

The original finding, kept as the record of what was fixed: the endpoint is
`@frappe.whitelist(allow_guest=True)`; the **GET** branch verified
`hub.verify_token`, and the **POST** branch verified nothing:

```
grep -rn "X-Hub-Signature|hub_signature|hmac"  remedisys_healthcare_ai/**/*.py  →  0 matches
```

Meta signs every delivery with `X-Hub-Signature-256` (HMAC-SHA256 of the raw body
using the app secret). Nothing checks it. The chain for an unauthenticated POST:

1. `webhook.py:65` — inserts a `WhatsApp Notification Log` with the attacker's raw
   JSON, `ignore_permissions=True`, **before any validation**.
2. `webhook.py:~105` — inserts a `WhatsApp Message` (`type: "Incoming"`) with
   attacker-controlled `from`, `message`, `profile_name`, `message_id`.
3. `hooks.py:282` — `after_insert` fires
   `integrations/whatsapp/chat_api.py:42 on_whatsapp_message_created`.
4. `chat_api.py:73-77` — `_find_patient(from, company)` →
   `_find_or_create_conversation(patient=…)`.

**Impact.** Anyone who knows or guesses a patient's phone number can post
arbitrary messages into that patient's clinical conversation, where staff read
them as coming from the patient. The same endpoint allows unauthenticated
unbounded document creation (log spam / storage exhaustion) and lets an attacker
create conversations for arbitrary numbers.

The `phone_number_id` → `whatsapp_account` lookup is **not** a control: the value
comes from the attacker's own payload.

**Fix.** Verify `X-Hub-Signature-256` against the account's app secret over the
**raw** body before the first `insert()`. Reject on mismatch, log IDs only. Then
rate-limit per IP, and move the notification-log write to after verification.

> The handler mirrors upstream `frappe_whatsapp`, but the file lives in our app, so
> the fix is ours. It has no Bruno request and no frontend caller — nothing would
> have caught it.

---

## 3. F2 — LLM clinical output is written to the Error Log `P0`

Rule 10: *"transcript text, SOAP content, patient names, DOBs, MRNs never appear
in logs"*; prompt logs store *"hashes and token counts, not raw content"*. **Eleven**
sites log the model's raw response on a JSON parse failure (re-counted against
`0dbb481` on 2026-09-03 — the first pass reported five and missed the
`note extract` / `note gaps` / `considerations` paths on both providers):

| Site | What is logged |
|---|---|
| `integrations/openai.py:1631` | `last_content_text[:500]` — raw **clinical suggestions** |
| `integrations/openai.py:1778` | `content_text[:500]` — raw **SOAP draft** |
| `integrations/openai.py:1862` | `content_text[:500]` — raw **note extract** |
| `integrations/openai.py:2195` | `content_text[:500]` — raw **note gaps** |
| `integrations/openai.py:2261` | `content_text[:500]` — raw **considerations** |
| `integrations/anthropic.py:1638` | `last_content_text[:500]` — raw **clinical suggestions** |
| `integrations/anthropic.py:1778` | `content_text[:500]` — raw **SOAP draft** |
| `integrations/anthropic.py:1833` | `content_text[:500]` — raw **note extract** |
| `integrations/anthropic.py:1880` | `content_text[:500]` — raw **note gaps** |
| `integrations/anthropic.py:1922` | `content_text[:500]` — raw **considerations** |
| `services/ai.py:964` | `str(content_text)[:500]` — **transcript re-segregation** |

```python
# integrations/openai.py:1118
except json.JSONDecodeError:
    if attempt == 0:
        continue
    frappe.log_error(last_content_text[:500], "AI Copilot — suggestions JSON parse error")
```

These land in the `Error Log` doctype: readable in Desk by any System Manager, not
PHI-scrubbed, included in site backups. A SOAP draft for a real encounter is
clinical content about an identifiable patient; the only thing limiting exposure is
a 500-character slice.

**Fix.** Log the failure *shape* — model, prompt version, response length, parse
error offset, and a **hash** of the payload. If raw text is genuinely needed, gate
it behind a per-environment debug flag with consent, the pattern `AI Prompt Log`
already uses.

---

## 4. F3 — Two frontend routes call methods that do not exist `P0`

Both 404 the moment the feature is used. Confirmed by searching the whole backend
for the name and for near-matches:

| Frontend route | Calls | Reality |
|---|---|---|
| `app/api/ai/autopopulate/route.ts` | `api.v1.ai.api.autopopulate_encounter` | **Not defined.** The `ai` module's 18 methods include `generate_suggestions`, `analyze_encounter`, `generate_soap_draft` — nothing `autopopulate_*`. Most likely renamed and the route never followed. |
| portal repo | `api.v1.patient_portal.api.add_self_reported_item` / `remove_self_reported_item` | **Not defined.** The portal API has `add_my_allergy`, `add_my_condition`, `add_my_medication` — the generic endpoints were split per type and the caller was left behind. |

Neither module has a single Bruno request (F5), which is why nothing caught them.

---

## 5. F4–F7 — Contract and coverage `P1`

### F4 · Two response envelopes, one documented convention

`API_SPEC.md §Conventions` documents one success envelope from
`utils.set_response()`:

```json
{ "status": "success", "data": { ... } }
```

**43 methods do not use it.** They `return` a value, so Frappe wraps it as
`{"message": …}`. The whole of `api/ai/*` (`sessions.py`, `auth.py`, `segments.py`,
`realtime.py`) plus `overrides/sales_invoice_mixin.py:15` and
`overrides/pos_price_fix.py:19`.

Not a runtime bug — a contract split that **already leaked into the frontend**,
which carries two client helpers to cope: `frappeFetchSet`/`frappeFetchList`
(unwrap `data`) and `frappeFetchDirect` (unwrap `message`). Pick wrong and it
throws; nothing tells you which family an endpoint belongs to except its source.

Options, in preference order: (1) migrate the 43 to `set_response` and update the
frontend; (2) flag every raw-envelope endpoint in `API_SPEC.md` §16 and say which
helper to use; (3) leave it undocumented — the status quo, which keeps costing
debugging time.

### F5 · Eight modules with zero contract tests

| Module | Methods | What it does |
|---|---|---|
| `api.ai` | 39 | live AI session / transcript / segment surface |
| `patient_portal` | 36 | everything the patient-facing app calls |
| `ai` (v1) | 18 | Copilot: SOAP drafts, suggestions, document analysis |
| `clinical_documents` | 8 | Narzim Drive — sharing + permissions |
| `integrations.whatsapp` | 8 | inbound/outbound patient messaging (F1) |
| `messages` | 6 | staff/patient threads |
| `narzim_assistant` | 5 | assistant threads |
| `inbox` | 3 | the three role worklists |

`clinical_documents` is the sharpest case: it implements owner-only sharing,
View-vs-Edit gating and deliberate **404-not-403** privacy
(`docs/CLINICAL_DOCUMENT_DRIVE.md §5`). A 617-line unit test landed 2026-08-18 —
good — but there is still no request-level proof a non-owner gets 404 over HTTP.

`inbox` is notable: all three worklists have neither a frontend caller nor a test,
despite ADR-041 landing 2026-08-18 to rework My Work.

### F6 · The money and clinical core is partly untested

| Module | Methods | Untested |
|---|---|---|
| `encounters` | 26 | **19** — incl. `create_diagnosis`, `create_allergy`, `create_complaint`, `book_follow_up` |
| `billing` | 24 | **18** — incl. `create_sales_invoice`, `create_pos_invoice`, `create_credit_note`, `create_vaccination_invoice` |
| `admin` | 115 | 89 |
| `notifications` | 17 | 13 |

Every invoice-creating method in the app is untested at request level — and
`billing` is where the ADR-decided behaviour lives (partial collection,
`min(paid_amount, outstanding)`, coverage splits), precisely the logic that
regresses silently.

### F7 · 126 methods have no frontend caller

Some are legitimately backend-only (report builders, scheduler targets). The ones
that look like real gaps:

| Module | Unused by any frontend |
|---|---|
| `procedures` (12) | **9** — the entire lifecycle: `create_`, `submit_`, `start_`, `complete_`, `cancel_`, `update_`, `get_`, `list_clinical_procedures`, `get_procedure_template`. Only the template picker is wired. |
| `nursing` (14) | **6** — `create_nursing_task`, `submit_`, `update_`, `cancel_`, `get_nursing_task`, `get_healthcare_activity` |
| `integrations.whatsapp` (8) | **8** — `list_conversations`, `get_conversation`, `send_chat_message`, `send_template_message`, `assign_conversation`, `close_conversation` … |
| `patient_portal` (36) | 20 — `add_my_allergy`, `add_my_condition`, `get_my_clinical_summary`, `get_my_lab_result_summary` … |
| `admin` (115) | 38 — 26 of them with no test either (`create_clinical_procedure_template`, `create_lab_test_template`, `create_therapy_type` + delete/update siblings) |
| `tasks` (18) | 7 |

The `procedures`/`nursing` figures confirm the dormancy found separately by E2E on
2026-08-18: a procedure ordered on an encounter creates only a `Service Request`,
and no code path anywhere creates a `Clinical Procedure` document. The
`patient_portal` figure is after scanning **both** portal repos.

---

## 6. F8–F11 — Hygiene `P2`

### F8 · Duplicate BFF routes for one method

| Backend method | Routes | Used by the UI |
|---|---|---|
| `cancel_appointment` | `/api/appointments/cancel` · `/api/appointments/[id]` | the `[id]` one |
| `check_in_patient` | `/api/appointments/check-in` · `/api/appointments/[id]/check-in` | the `[id]` one |

Both must be kept in step while they both exist, and a fix to one silently misses
the other.

### F9 · 11 of 239 BFF routes have no consumer

```
/api/admin/diagnosis          /api/admin/dosage-forms       /api/admin/healthcare-activities
/api/admin/medication-classes /api/admin/payment-methods    /api/admin/symptoms
/api/ai/soap-draft/discard    /api/ai/transcribe            /api/appointments/cancel
/api/appointments/check-in    /api/patients/guardian
```

Two are F8's duplicates. The six `admin/*` masters look superseded by the generic
`app/api/admin/[resource]/route.ts`, which builds `${BASE}.list_${resource}`
dynamically — confirm with the settings owner, then delete. `/api/ai/transcribe`
and `/api/ai/soap-draft/discard` are live-feature routes with no caller, which
pairs suspiciously with F3's dead `autopopulate` call.

Dead routes are not inert here: each is an authenticated proxy to a backend method,
reachable whether or not the UI uses it.

### F10 · Four patch files are not registered — they never run

```
patches/v0/reapply_eb_role_permissions_20260629b.py   …629c.py   …629d.py
patches/v0/reapply_eb_role_permissions_20260706b.py
```

Two further files are absent from the run but **deliberately so** — corrected
2026-09-03, the first pass counted them as defects:

```
patches/v0/seed_cardiology_medications.py        ← removed from the migrate run
patches/v0/seed_cardiology_treatment_plans.py       2026-06-22, comment in patches.txt
```

They create records with Link/Dynamic-Link refs that do not exist on a fresh site,
so they threw `LinkValidationError` and aborted `bench migrate`. `patches.txt`
carries the reason inline. Not a finding; listed so nobody "fixes" it by
re-registering them.

Every entry *in* `patches.txt` has a file (that direction is clean). The risk is the
reverse: four `reapply_eb_role_permissions_*` variants suggest an iterated
permission fix where it is now unclear which is authoritative — and a
role-permission patch written but never registered may mean a site is missing
permissions someone believes were applied.

### F11 · Unauthenticated endpoints with no test

| Method | Bruno | Note |
|---|---|---|
| `auth.api.request_password_reset` (`auth/api.py:248`) | **none** | needs tests for rate limiting and for not leaking whether an email exists |
| `patient_portal.api.register` (`patient_portal/api.py:121`) | **none** | public patient self-registration, creates records from the open internet |
| `patients.api.get_genders` | ✅ | harmless static list |
| `integrations.whatsapp.webhook.webhook` | **none** | F1 |

Three of the four unauthenticated paths have no executable test.

---

## 7. F12–F13 — Lower priority `P3`

**F12 · Unbounded queries (22 endpoints).** `limit_page_length=0` means "no limit".
Precisely: most are **not** a risk — `list_patients:1123` plucks only the caller's
own favourite patient *names*; `list_my_appointments` is one patient's own. Small
masters (`list_genders`, `list_payment_methods`, `list_dosage_forms`,
`list_complaints`, `list_diagnosis`, `list_items`, `list_treatment_plan_templates`)
grow slowly but are user-facing pickers and should be search-limited. The one that
genuinely needs pagination is `messages/api.py:143 list_threads`, which grows with
clinic size.

**F13 · No test directory** for `api/v1/company` and `api/v1/messages`. `messages`
also has zero Bruno requests, so it has no coverage of any kind — and it handles
staff/patient threads.

---

## 8. What came back clean

These usually fail in a codebase this size, and here they did not:

**No SQL injection.** 60 `frappe.db.sql()` sites. Four interpolate f-strings —
`patients/api.py:686`, `admin/staff.py:114`, `admin/staff.py:135`,
`services/narzim_assistant.py:444` — and in every case the interpolated value is a
**code-built condition fragment** (`" AND ".join(conditions)`, `where_sql`) while
user input is parameter-bound (`%(patients)s`, `%s` + params tuple). Verified that
`conditions`/`where` are assembled from string literals only.

**No `ignore_permissions=True` in any whitelisted endpoint touching a PHI
doctype.** 406 occurrences app-wide — all in patches, seeds, services and hook
handlers running in system context; zero on the authenticated API surface.

**No envelope-overwrite bugs.** `set_response()` warns that a whitelisted method
must not also `return` a value. Six looked like they did; in all six the returns
belong to **nested helper functions** (`get_patient_visits`,
`get_my_available_slots`, `get_available_slots`, `get_setup_checklist`,
`get_patient_invoice`, `create_sales_invoice`). Verified by AST, excluding nested
scopes.

**All `hooks.py` targets resolve.** 26 looked unresolved; every one is a
commented-out line from the stock Frappe template.

---

## 9. False positives this audit produced

| Check | Raw hits | Real | Why the rest are not bugs |
|---|---|---|---|
| Method missing (frontend → backend) | 27 | **2** | `api.py` **re-exports** resolve 17 (`admin/api.py:7-141` imports from ten siblings, so `admin.api.list_staff` is callable while the `def` is in `admin/staff.py`); 8 were bare module prefixes (`const METHOD = "…"`) or dynamic fragments (`${BASE}.create_${resource}`) |
| No frontend caller | 271 | **126** | same alias resolution — 145 methods reach the frontend via `api.py` |
| Envelope overwrite | 6 | **0** | returns are in nested helpers |
| Endpoint with no response call | 15 | **0** | delegate to a shared `_list(...)`/`_impl(...)` that sets the response |
| Unresolved `hooks.py` target | 26 | **0** | commented-out template boilerplate |
| Raw SQL interpolation | 4 | **0** | only code-built fragments; user values parameter-bound |
| `ignore_permissions=True` | 406 | **0 on the API surface** | system-context code |
| PHI-in-log grep | 12 | **5** | the other 7 log static strings or a `title=` label only |
| Whitelisted stub `utils.my_endpoint` | 1 | **0** | it is a `@frappe.whitelist()` line **inside a docstring** (`utils.py:295-301`) |
| Broken `patches.txt` entry | 0 | 0 | — |

**Rule of thumb:** grep-level checks over a Frappe app produce ~5 false positives
per real finding. Anything script-reported should be AST- or context-verified
before it becomes a ticket — which is why the CI checks proposed below are narrow
and deterministic rather than heuristic.

---

## 10. Recommendations, in order

1. **Verify the WhatsApp webhook signature** (F1) `P0`. Nothing else here is
   reachable from the open internet.
2. **Stop logging LLM payloads** (F2) `P0`. Eleven call sites → hash + length +
   model + prompt version.
3. **Fix the two dead frontend calls** (F3) `P0`. Repoint `autopopulate` at the
   real method (confirm with the AI owner) and reconcile the portal's
   self-reported-item calls.
4. **Add a CI method-resolution check** `P0`, cheap and permanent: extract every
   `remedisys_healthcare_ai.*` string from both frontends and assert each resolves
   against the installed app, handling `api.py` aliases. This bug class then cannot
   ship again.
5. **Decide the envelope question** (F4) `P1` — migrate or document; either way the
   flag belongs in `API_SPEC.md` §16.
6. **Bruno coverage for the guest endpoints** (F11) `P1` — a `guest/` folder:
   `request_password_reset` (rate limited, enumeration-safe),
   `patient_portal.register`, and the webhook **rejecting an unsigned POST**. Run in
   CI.
7. **Bruno coverage for money and clinical writes** (F6) `P1` — the 18 `billing`
   methods first, then the 19 in `encounters`. Assert the ADR-decided numbers
   (coverage split, partial collection), not just HTTP 200.
8. **Resolve the patch backlog** (F10) `P2` — confirm which
   `reapply_eb_role_permissions_*` is authoritative and whether any site is missing
   permissions. Add a CI check that `patches/` and `patches.txt` agree.
9. **Decide the fate of the dormant surface** (F7) `P1` — `procedures` (9),
   `nursing` (6), `whatsapp` (8), 20 portal methods, 26 admin masters. Each is
   either wired to a frontend, covered by a test as a deliberate API-only
   capability, or deleted. Whitelisted + unreachable + untested is the worst of the
   three in a PHI system.
10. **Delete the duplicate and dead routes** (F8, F9) `P2`; **cap the pickers and
    paginate `list_threads`** (F12) `P3`; **add `tests/company/` and
    `tests/messages/`** (F13) `P3`.

---

## 11. Reproducing this

Two scripts produced everything above; both are ~70 lines, take no arguments, and
read only source:

| Script | Produces |
|---|---|
| method × frontend × Bruno join | the coverage numbers, F3, F5–F7, F11, and §16 of `API_SPEC.md` |
| multi-check AST/grep pass | F2, F4, F8–F10, F12–F13 and the clean results in §8 |

Both are worth promoting into `tests/ci/` as the two checks in §10.4 and §10.8 —
that is the only way findings like F3 and F10 stay fixed.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Invincible | Initial version (header backfilled from git history) |
