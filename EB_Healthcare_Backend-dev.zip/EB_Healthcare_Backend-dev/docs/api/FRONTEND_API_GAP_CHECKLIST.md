# Frontend API Gap — Build Checklist

**Doc status:** living · **Created:** 2026-06-12 by Anant Sharma · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

> **How this was produced:** by reading the actual Next.js screen code in
> `EB_Healthcare_Frontend` page-by-page (not the README/ROADMAP, which are stale)
> and tracing each screen's data flow: screen → hook → `lib/api` → BFF route → backend
> method, OR → mock data. Anything still on mock is listed here as an API to build.
>
> **Conventions every method below must follow** (from the existing codebase):
> - Path: `remedisys_healthcare_ai.api.v1.<module>.api.<function>`
> - Decorate with `@frappe.whitelist()` and `@handle_api_errors`
> - Call `require_permission("<Doctype>", "<perm>")` **first**
> - List responses: `set_list_response(200, items, total, page, page_size)` → `{data, pagination}`
> - Single responses: `set_response(200, data={...})` → `{data}`
> - No `/api/resource/` — custom whitelisted methods only
> - No PHI in logs (IDs only)
>
> **Legend:** ☐ to build · ⚠️ needs a decision before building · ✅ already exists (do NOT rebuild)

---

## Excluded from the build list — backend EXISTS, only frontend wiring is missing
Do not build these. Hand to the frontend team to connect.

- ✅ `encounters.api.create_encounter` / `save_draft` / `complete_encounter` — `/encounters/new` is a "coming soon" stub
- ✅ `appointments.api.cancel_appointment` / `check_in_patient` — reschedule/cancel are state-only in the UI
- ✅ `appointments.api.book_appointment_for_patient` — atomic new-patient booking (creates Patient + Appointment in one transaction; rolls the patient back if booking fails). **Frontend wiring:** repoint the new-patient branch of `POST /api/appointments` from the two-call `create_patient` → `book_appointment` sequence to this method with a `new_patient` object. Contract: API_SPEC.md §5.2.1; Bruno: `bruno/appointments/book-appointment-for-patient.bru`
- ✅ `labs.api.create_lab_order` — order button not wired
- ✅ `patients.api.get_patient_immunizations` — exists (read); immunizations tab still renders mock

---

## TIER 1 — Billing ✅ DONE (2026-06-12)
Module: `api/v1/billing/api.py` · Doctypes: `Sales Invoice`, `Payment Entry`
Tests: `tests/billing/test_billing.py` (envelope/contract/pagination/permission). Smoke-tested against
`remedisis.localhost`: invoices return real data; payments correctly scope out non-patient receipts.

- ✅ **`list_all_invoices`** — clinic-wide invoice list, scoped to `patient is set`
  - Inputs: `status?`, `search?`, `date_from?`, `date_to?`, `include_returns=false`, `page=1`, `page_size=20`
  - Output (list): each row `{ name, patient, patient_name, status, posting_date, due_date, grand_total, outstanding_amount, paid_amount, currency, company, remarks, practitioner, practitioner_name, is_return, docstatus }`
  - `practitioner`/`practitioner_name` resolved: header `ref_practitioner` first, else the line-item-referenced Patient Appointment (batched). Same enrichment applied to `list_patient_invoices`.
  - Perm: `require_permission("Sales Invoice", "read")`
- ✅ **`list_payment_entries`** — patient payments received list (Receive/Customer, scoped to patient customers)
  - Inputs: `mode_of_payment?`, `search?`, `date_from?`, `date_to?`, `page=1`, `page_size=20`
  - Output (list): each row `{ name, party, party_name, mrn, paid_amount, mode_of_payment, posting_date, reference_no, invoices[], status, docstatus }`
  - Perm: `require_permission("Payment Entry", "read")`

---

## TIER 2 — Reports (new module `api/v1/reports/api.py`; all 16 screens are mock)
Shared response contract for every report: `{ kpis: [{label, value, sub}], charts: {<named series>}, table: [...] }`
Common inputs: `date_from`, `date_to`, plus the optional filter noted. Read-only; perm against the source doctype.

**Clinical**
- ☐ `get_chronic_care` — filter `service_unit?` — KPIs (chronic patients, well-controlled %, due for review, escalations); charts: condition_distribution, controlled_vs_uncontrolled, hba1c_trend; table: patients due for review
- ☐ `get_diagnosis_trends` — filter `provider?` — top diagnoses by ICD code, by category, trend arrows
- ☐ `get_encounter_summaries` — filter `provider?` — encounter types, by-provider counts, 30-day trend, recent encounters
- ☐ `get_immunization_rates` — filter `age_group?` — coverage status, vaccines administered, coverage by age, overdue list

**Financial**
- ☐ `get_claims_status` — filter `insurer?` — claims by status/insurer, approval-rate trend, claim details
- ☐ `get_outstanding_balances` — filter `provider?` — aging buckets (0-7/8-14/15-30/>30), by amount range, pending invoices
- ☐ `get_payment_methods` — payment split (cash/card/transfer/IMSS), method volume, recent transactions
- ☐ `get_revenue_by_provider` — revenue per provider, revenue share, visits + avg/visit

**Operations**
- ☐ `get_check_in_rates` — on-time/early/late/no-show %, by day of week, weekly trend
- ☐ `get_daily_patient_flow` — input `date` — hourly volume, visit types, appointment list
- ☐ `get_no_show_analysis` — reasons, by day of week, monthly rate trend, today's no-shows
- ☐ `get_queue_wait_times` — input `date` — wait by hour, distribution brackets, wait by provider

**Provider**
- ☐ `get_average_visit_time` — filter `provider?`, `visit_type?` — by provider, by visit type, duration distribution
- ☐ `get_patient_satisfaction` — filter `provider?` — rating distribution, by provider, NPS trend, feedback
- ☐ `get_patient_volume` — filter `provider?` — by provider, volume share, weekly trend
- ☐ `get_utilization_rate` — filter `provider?` — utilization tiers, by provider (available/booked/%), weekly trend

> Note: build as 16 functions OR one dispatcher `get_report(report_type, **filters)`. The frontend
> calls them per-screen, so 16 thin functions sharing helpers is the cleaner match.

---

## TIER 3 — Patient 360 clinical tabs
Module: `api/v1/clinical/api.py` (currently empty) unless noted. All scoped by `patient`.

**Conditions / Allergies** — ✅ DONE (2026-06-12) · `api/v1/clinical/api.py` · **No new doctype** — stored on
existing Patient fields (`allergies`, `medical_history`) as comma-separated lists, consistent with
`patients.api._split_allergies` / `get_patient_chart_overview`. Tests: `tests/clinical/test_clinical.py`.
Full CRUD smoke-tested against a live patient (add/dedup/update/remove/conditions), original data restored.
- ✅ `list_allergies(patient)` → `data = {patient, allergies: [str]}`
- ✅ `add_allergy(patient, allergy)` — idempotent, case-insensitive
- ✅ `update_allergy(patient, allergy, new_value)` — 404 if original missing
- ✅ `remove_allergy(patient, allergy)` — idempotent, case-insensitive
- ✅ `list_conditions` / `add_condition` / `update_condition` / `remove_condition` — same, on `medical_history`
- **Constraint:** plain text fields hold names only. Per-item `severity` / `detail` / `comments` from the
  mock are NOT persisted — they'd require a child table/doctype (out of scope per §7). Single place to
  swap the backing store later if needed: `_read_items` / `_write_items` in `clinical/api.py`.
- ☐ `list_problems(patient)` (problem list view) — NOT built; decide if it's distinct from conditions.

**Documents** — ⏸️ PARKED (2026-06-12) — revisit later. Doctype: Frappe `File` (attach to Patient).
Frontend tab is fully mock (SEED_DOCS, upload not wired), so the contract is soft. Open decision before
building: where `category` lives (custom Select field+migrate / native tags / derive from
`attached_to_doctype`). `File` is the right primary store (not `Patient Medical Record`, which is the
auto-generated clinical timeline). type/size/date/owner all derive from native File fields.
- ☐ `list_documents(patient, category?)` → `[{id, name, category, type, date, size, added_by, tags[]}]`
- ☐ `upload_document(patient, category, file, tags?)`
- ☐ `delete_document(id)`

**Immunizations (write)** — Doctype: ERPNext `Immunization` (read already exists)
- ☐ `create_immunization(patient, name, date, lot, dose, site, by, note?)`
- ☐ `update_immunization(id, ...)`
- ☐ `delete_immunization(id)`

**Lab results detail** — Doctype: `Lab Test`
- ☐ `get_lab_result_detail(name)` → results array `[{test_name, result, uom, normal_low, normal_high, flag}]` (if not already covered by existing `get_lab_test`)

---

## TIER 4 — Insurance (module `api/v1/insurance/api.py` is empty)
Doctypes: confirm — ERPNext Healthcare has limited claims support; may need custom.

- ☐ `list_patient_policies(patient)` → `[{id, insurer, policy_no, coverage_pct, copay, valid_to}]`
- ☐ `add_policy(patient, insurer, policy_no, ...)`
- ☐ `update_policy(id, ...)`
- ☐ `list_claims(patient?)` → `[{id, patient, insurer, amount, status, submitted_on}]`
- ☐ `create_claim(patient, invoice, insurer, amount)`
- ☐ `submit_claim(id)`
- ☐ `get_claim_status(id)`

---

## TIER 5 — Operational screens (all mock today)

**Inbox** (`/inbox`) — new module `api/v1/inbox/api.py`
- ☐ `get_inbox(role)` → `[{id, type, priority, title, patient_name?, patient_id?, context, time_ago, action_label}]`
  - `type`: lab-result | rx-renewal | referral-reply | unsigned-note | follow-up | no-show | payment | consent | insurance | message | vitals-queue | rooming | confirmation
  - `priority`: critical | review | todo | info
- ☐ `mark_done(item_id)`

**Activity feed** (`/activity`) — likely reads existing docs (no new doctype)
- ☐ `get_activity(date_from, date_to)` → `[{type, patient_id, patient_name, practitioner?, at, detail}]`
  - types: booked | checked-in | payment | rescheduled | cancelled | noshow | new-patient | vitals | encounter

**Cash / Shift** (`/cash`) — ⚠️ needs new doctypes (see decisions below)
- ⚠️ `open_shift(opening_float, from_transfer_id?)` → ShiftSession
- ⚠️ `close_shift(shift_id, actual_cash)` → ShiftSession + variance
- ⚠️ `get_active_shift()` / `list_today_shifts()`
- ⚠️ `create_transfer(from_shift_id, to_staff_id?, amount)` → DrawerTransfer
- ⚠️ `accept_transfer(id)` / `decline_transfer(id)` / `list_pending_transfers()`
  - ShiftSession: `{id, staff_id, staff_name, opened_at, opening_float, cash_collected, card_collected, transfer_collected, status, closed_at?, actual_cash?}`

---

## TIER 6 — Tasks, Referrals, Messages

**Tasks (per-patient)** (`patient-chart/tasks-tab`) — ⚠️ doctype decision (operational `get_my_tasks` exists separately)
- ⚠️ `list_patient_tasks(patient)` → `[{id, title, description?, status, priority, category, assignee, due_date?, created_date, tags[]}]`
- ⚠️ `create_task(patient, title, priority, category, assignee, due_date?, description?)`
- ⚠️ `update_task(id, ...)`
- ⚠️ `delete_task(id)`

**Referrals** (`patient-chart/referrals-tab`) — ⚠️ no ERPNext-native home → new doctype
- ⚠️ `list_referrals(patient, direction?)` → `[{id, direction, specialty, specialist?, reason, priority, status, referred_by, referred_date, appointment_date?, notes?}]`
- ⚠️ `create_referral(patient, specialty, reason, priority, referred_by, ...)`
- ⚠️ `update_referral(id, status?, appointment_date?, reply_notes?)`

**Messages** (`/inbox` threads + `patient-chart/messages-tab`) — ⚠️ custom or ERPNext `Communication`
- ⚠️ `list_threads(patient?, category?, unread_only?)` → `[{id, subject, category, participants[], last_at, unread, priority}]`
- ⚠️ `get_thread(id)` → thread + messages `[{from, text, time}]`
- ⚠️ `create_thread(patient?, subject, category, initial_message)`
- ⚠️ `reply(thread_id, content)`
- ⚠️ `mark_read(thread_id)`

---

## TIER 7 — Confirm scope/shape before building

- ⚠️ **Medications formulary** (`/medications`) — frontend shape `{brandName, genericName, category, presentations[], routes[], standardDose, status, controlled, notes}` is **richer than ERPNext `Medication`**. Decide: extend Medication with custom fields, or new doctype. Then build `list_formulary` + CRUD.
- ⚠️ **Prescriptions** (`/prescriptions`) — screen is a "coming soon" stub. Build `list / get / create` only once the screen exists.
- ⚠️ **Providers schedule/availability/stats** (`/providers`) — list is wired; availability %, weekly schedule, and today/wait stats are hash-based mocks. Needs a real schedule/stats method.

---

## Appointments list — server-side filter params (frontend request, 2026-07-09)

**Method:** `remedisys_healthcare_ai.api.v1.appointments.api.list_appointments` (`_list_impl`)
**Current params:** `date`, `practitioner`, `patient`, `status`, `company`, `limit`, `offset`, `sort`.

The Appointments **List** (`appointments-client.tsx`) and **Calendar** (`calendar/calendar-client.tsx`)
already push **status** and **practitioner** server-side. Three more filters are **client-side only**
today — filtered in-memory on the fetched window — because `list_appointments` has no param for them.
Add these so every filter is server-side (frontend then drops the in-memory `.filter(...)` fallbacks).
This also removes the current "a filter only matches the already-loaded page under pagination" caveat.

1. ☐ **`search`** (str, optional) — partial, case-insensitive match across `patient_name` and
   `patient` (MRN/id). The existing `patient` param is exact-id only. Suggest an OR filter: `like`
   on `patient_name` + prefix/`like` on the patient id. *Frontend today:* `appointments-client.tsx`
   `filtered` useMemo, search branch (`patient.includes(q) || mrn.includes(q)`).

2. ☐ **`date_from` + `date_to`** (str `YYYY-MM-DD`, optional, **inclusive**) — range query on
   `appointment_date`, replacing the exact-`date`-only limitation. Keep the single `date` param working
   (fast path), or treat `date_from == date_to` as one day. *Needed for* List "This week"/"All dates"
   and Calendar Week/Month, which currently fetch a `limit:500` window and filter client-side by day —
   so periods beyond that window silently render empty (the known calendar caveat). *Frontend today:*
   List `filtered` (week/custom branches) + `apiParams` `limit:500` fallback; Calendar `periodAppointments`
   + `apiParams`.

3. ☐ **`billing_status`** (str, optional) — one of `Unbilled` / `Pending` / `Paid`, resolved per
   appointment from `ref_sales_invoice` + invoice `outstanding_amount` (mirror `_billing_for` / `_fmt`'s
   `billing.status`): `Unbilled` = no `ref_sales_invoice`; `Pending` = invoiced & outstanding > 0;
   `Paid` = invoiced & outstanding == 0. **Most expensive** — needs an invoice join/batch lookup in the
   list query (`_list_impl` already builds an `inv_map` batch for enrichment; filter against it).
   *Frontend today:* List `filtered` billing branch + the "All billing" dropdown; the Invoiced column
   renders Paid / Invoiced / Not-invoiced badges from `billing.status`.

**On delivery:** frontend sends these in `apiParams` and deletes the three in-memory filter passes.
Response envelope unchanged (`set_list_response` → `{data, pagination}`).

---

## Cross-cutting decisions needed (block several items above)

1. **New-doctype items vs. the "no new doctypes in Phases 1-4" rule.** Cash shifts, drawer transfers, referrals, message threads, per-patient tasks, and sticky notes have no ERPNext-native table. Building them means new custom doctypes — which contradicts CLAUDE.md §7. **Decide per item: in scope (write an ADR superseding §7) or keep frontend-local.**
2. **Admin `/api/resource/` deviation.** 13 admin resources (diagnosis, departments, lab-tests, medications, practitioners, price-lists, etc.) currently use Frappe's generic `/api/resource/<Doctype>` via `standardCrud: true`, bypassing the custom service layer — against the "custom whitelisted methods only" rule. Custom methods already exist for some (medications/departments). **Decide: migrate the BFF to the custom methods, or formally accept the deviation.**
3. **Dashboard shape gap — ✅ FIXED (2026-06-12)** in `dashboard/api.py`. Verified against `remedisis.localhost`:
   - ✅ `vital_room` — appts with a non-cancelled Vital Signs record (verified: HLC-APP-00004 routes here)
   - ✅ `practitioner_room` — appts with a Draft (docstatus 0) Patient Encounter (verified on 2026-06-11)
   - ✅ `checkout` — appts with a submitted/Completed encounter (verified: 2 on 2026-06-04)
   - ✅ `mobile` added to `_queue_row` (batched Patient phone lookup)
   - ✅ `status` now RAW ERP status (dropped the `_STATUS_ERP_TO_FE` mapping in the queue serializer)
   Rooms are mutually exclusive by most-advanced clinical artifact. `waiting_room` now means
   "checked-in, not yet progressed" — so `longest_waiting`/`practitioner_delays` (derived from it) reflect
   only patients genuinely waiting. Backend extras `practitioners`/`practitioner_delays` remain (unused by
   frontend, harmless). **Frontend follow-up:** add `?? []` to `dash.vital_room` (mission-control-client.tsx:601)
   for defensiveness, even though the backend now always sends it.

4. **Practitioner-only appointment visibility — config default (ADR-018).** The frontend
   Appointments **List** and **Calendar** views now lock a practitioner-only user (holds
   `EB_Practitioner` and no admin/front-desk/nurse role) to their own appointments: the
   practitioner filter is forced to the logged-in doctor's linked Healthcare Practitioner id
   (`useAuth().user.practitioner.name`) and rendered disabled so it can't be changed
   (`appointments-client.tsx`, `calendar/calendar-client.tsx`).
   - **This is a UX guard only.** It works because `_list_impl` honours a caller-supplied
     `practitioner` filter even when scope is `_SCOPE_ALL`. A practitioner who calls
     `list_appointments` directly (no filter) still receives **all** appointments, because
     `_practitioner_read_scope` defaults `practitioners_see_all_appointments` to **True/ON**
     when the EB Clinic Settings flag is unset or the company can't be resolved.
   - **Backend request / decision:** for hard server-side enforcement of "a doctor sees only
     their own appointments," set `practitioners_see_all_appointments = OFF` on **EB Clinic
     Settings** per company (then `_practitioner_read_scope` returns the practitioner's own id
     and overrides any caller filter). Decide whether OFF should be the **shipped default** for
     single-doctor / privacy-sensitive clinics, or stay opt-in per clinic. Also confirm the
     `_SCOPE_NONE` behavior (practitioner with no linked Healthcare Practitioner record → empty
     list) is the intended fail-closed result. See
     `docs/adr/adr-018-practitioner-appointment-visibility-and-coverage.md`.

---

## Suggested build order
1. Tier 1 billing (2 methods) — unblocks a live page
2. Dashboard shape check (decision #3) — cheap, possibly a real gap
3. Tier 3 clinical tabs (conditions/allergies, documents, immunization-write)
4. Tier 2 reports (16)
5. Tier 4 insurance
6. Tier 5 inbox/activity
7. Resolve decisions #1/#2, then Tier 6 + cash + Tier 7

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-12 | Sarvesh | Initial version (header backfilled from git history) |
