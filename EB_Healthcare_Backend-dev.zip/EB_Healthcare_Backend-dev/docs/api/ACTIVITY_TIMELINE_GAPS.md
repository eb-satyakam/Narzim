# Activity timeline — API gaps

**Doc status:** living · **Created:** 2026-08-17 by Sarvesh-SocialAngel · **Updated:** 2026-08-17 by Sarvesh-SocialAngel · **Version:** 1.0

| | |
|---|---|
| **Raised** | 2026-08-17, by the frontend |
| **Requested by** | Patient 360 → **Activity** tab (`Healthcare_next_app`) |
| **Frontend doc** | `Healthcare_next_app/docs/activity/ACTIVITY_TIMELINE.md` |
| **Blocking?** | **No.** The feature is built and works against today's API. |
| **Status** | **Resolved 2026-08-17** — see *Resolution* below. Three of the eight claims were wrong. |

---

## Resolution (2026-08-17)

Every item below was verified against the implementation before any code was
written. That reduced eight requested gaps to **three** real backend changes, and
disproved three claims in this document — including two of my own.

| # | Claim | Verdict | Outcome |
|---|---|---|---|
| 1 | Documents return a login email | Correct | **Fixed** — `added_by_name`, one deduped `User` query per page |
| 2 | Lab `result_date` has no time-of-day | **Wrong as a backend gap** | `_LAB_LIST_FIELDS` + `_serialize_lab_row` already return `result_date`, `submitted_date` (Datetime) and `creation`; `services/labs.py:603` already defines the precedence. Frontend work, not backend. |
| 3 | Immunization `date_administered` has no time | Correct | **Fixed** — `creation` exposed for ordering, explicitly not an administration time |
| 4 | Report identity for the lab AI summary | Out of scope | ADR-033 rejected exactly this as "Alternative 1". Changing it requires superseding that ADR, not adding a field. `AI Lab Panel Extraction Panel`'s parent is `AI Prompt Log` — an audit record, not a clinical contract — so it cannot serve as identity either. |
| 5 | `education` absent from `list_encounters` | Correct, and correct as designed | **No change.** ~1.5 KB × 200 rows ≈ 300 KB per chart load for text usually never read. |
| 6 | No totals on the lab history | — | **No change.** Unbounded by design in the BFF; fine at current volumes. |
| 7 | Lists silently cap at 200 | **Wrong about the cause** | Both endpoints already return a real `total` (`encounters/api.py:841`, `appointments/api.py:675`). The actual defect is that `list_encounters` clamps `page_size = min(100, …)` (line 777), so the frontend's `page_size: 200` silently receives 100. A frontend correction. |
| 8 | No merged activity endpoint | Not requested | **Not implemented.** |

One further gap surfaced during the fix and was closed with it: `list_documents`
also ordered by `communication_date desc, creation desc` without returning
`creation`, so same-day uploads were unorderable client-side too.

**Schema changes: none.** No doctype JSON, custom field, patch or fixture.
`list_documents` costs one extra query per page (constant in row count, zero on an
empty page); `list_immunizations` costs none — `creation` is another column on a
query that already sorted by it.

Tests: `tests/documents/test_documents_added_by.py`,
`tests/immunizations/test_immunization_creation_field.py`.

### Corrections to the text below

The sections that follow are the original request, kept verbatim as the record of
what was asked. Two of its assertions do not survive contact with the code:

- **§1 cites `api/v1/immunizations/api.py:45` (`administered_by_name`) as the
  precedent** for a bulk User lookup. It is not — that is a `fetch_from` on a
  **Healthcare Practitioner** link. The real precedent, and what was followed, is
  `services/providers.py::_user_image_fallback`.
- **§2 presents the lab timestamp as a backend gap.** It was already served. See
  row 2 above.

Patient 360 gained an **Activity** tab: one chronological feed of every clinical
action on a patient — encounters, appointments, vitals, labs, uploaded documents,
immunizations. It consumes only existing per-patient endpoints; **no backend code
was changed** to build it (frontend CLAUDE.md §13.2).

Each item below is either a gap that forces the frontend into a workaround, or a
defect a user can see today. Ordered by user impact.

---

## Summary

| # | Gap | Where | User-visible? | Effort |
|---|---|---|---|---|
| 1 | Document uploader returned as a login email | `services/documents.py:149` | **Yes** | Small |
| 2 | Lab `result_date` has no time-of-day | Lab Test | **Yes** | Small (a) / Schema (b) |
| 3 | Immunization `date_administered` has no time | Immunization | **Yes** | Small (a) / Schema (b) |
| 4 | Lab AI summary is report-scoped but served per-test | ADR-033 | Fixed FE-side | Medium |
| 5 | `education` absent from `list_encounters` | `api/v1/encounters/api.py:47` | No | **Probably leave as-is** |
| 6 | No totals / pagination on the patient lab history | `/api/labs` | Not yet | Medium |
| 7 | Appointment & encounter lists silently cap at 200 | both list endpoints | Not yet | Small |

---

## 1. Documents return the uploader's login email, not their name 🔴

`remedisys_healthcare_ai/services/documents.py:149`

```python
"added_by": r.get("owner"),
```

`owner` is the Frappe User docname — in this deployment, the login email. The
Activity feed therefore renders an uploader as `dr.arielcmjose@g…` (truncated),
directly beside encounter and appointment rows that correctly read
`Dr Ariel Castillo`. It also breaks the avatar, whose initials are derived from
the actor's name.

**Ask:** return `added_by_name` alongside `added_by`, resolved from
`User.full_name`, bulk-resolved per page.

Precedent already in this app:

- `api/v1/immunizations/api.py:45` returns **both** `administered_by` and
  `administered_by_name`.
- `list_encounters` returns `practitioner_name` next to `practitioner`.
- `services/providers.py::_user_image_fallback` is the existing bulk
  `user_id -> User.<field>` lookup pattern for exactly this shape.

```python
# services/documents.py, in the list serializer
"added_by":      r.get("owner"),
"added_by_name": user_full_names.get(r.get("owner")),   # bulk-resolved per page
```

**No coordinated deploy needed.** The frontend already prefers `added_by_name`
when present and falls back to today's behaviour when absent.

**Frontend has a partial workaround in place**, and it is explicitly a stopgap: it
maps the email through `Provider.user -> practitioner_name`, which recovers a real
name *only when the uploader is a practitioner*. Front-desk and admin uploaders
still cannot be resolved client-side; those fall back to the email's local part.

---

## 2 & 3. Lab results and immunizations carry no time-of-day 🔴

- `Lab Test.result_date` — Date, no time.
- `Immunization.date_administered` — Date, no time.
  `api/v1/immunizations/api.py:175` already compensates with
  `order_by="date_administered desc, creation desc"` — i.e. it *already* falls
  back to `creation` as a tiebreaker precisely because the date has no time.

Reproduced on `MRN-2026-0000158`: nine labs resulted on 2026-08-17 render with an
**empty time column** and in **no defined order** among themselves, while
encounters, appointments and vitals on the same feed show real clock times.

The frontend deliberately shows nothing rather than defaulting to midnight — a
fabricated `12:00 AM` on a clinical record is worse than a blank.

**Ask — either:**

**(a) No schema change.** Also return `creation` (Lab Test already does) and/or
`modified`, and state which the frontend should treat as "when this was recorded".

> ⚠️ This needs an explicit decision, not a guess: `creation` is when the **order
> was raised**, not when the **result came back**. Labelling it as a result time
> would be clinically misleading. If (a) is chosen, say so and the frontend will
> use it for *ordering only*, leaving the time column blank.

**(b) Correct.** Add a `result_datetime` on Lab Test, captured at result entry,
and an administered time on Immunization.

**Recommendation: (a) now for ordering, (b) when the schema is next touched.**

---

## 4. Lab AI summary is report-scoped but exposed per-test

Per **ADR-033**, the summary returned for a Lab Test *is the shared report
summary*. Every test extracted from one upload returns byte-identical `narrative`
and `flags`.

This surfaced as a visible bug: a patient with one multi-panel upload showed the
same ~1,500-character interpretation and the same three flags repeated on **nine**
consecutive lab cards.

**Already fixed on the frontend** — grouped by `LabTest.source_file_url` and
rendered once per report, labelled "AI Interpretation (whole report)".

**The remaining gap:** `source_file_url` is documented as *"most recently attached
report file"*. That is a plausible grouping key, not a guaranteed one — if a
test's attachment is later replaced, two tests from one report drift apart and the
interpretation renders twice. The failure is benign, but the grouping is an
inference rather than identity.

**Ask:** expose the report identity — a `report` / `panel_extraction` link on Lab
Test, or a way to fetch `get_result_summary` once per report.

---

## 5. `education` is not in `list_encounters` — probably correct, recorded deliberately

`api/v1/encounters/api.py::_LIST_FIELDS` (lines 47–63) omits `education`; only
`get_encounter` returns it.

The feed shows **Review Details** (the patient-facing explanation) on completed
encounters, so it lazily fetches the full encounter when that row is expanded.

**This is likely the right design and may need no change.** `education` runs
~1.5 KB in real records; adding it to a 200-row list response would add ~300 KB to
every Patient 360 load for text that is usually never read.

Recorded so the choice is deliberate. **Only worth revisiting** if a view needs
review-details text for many encounters at once — and even then, prefer a boolean
(`has_education`) over the body, so the UI can show or hide the affordance without
paying for the text.

---

## 6 & 7. Unbounded lab history; silent 200-row truncation

- `/api/labs` returns the patient's **entire** lab history with no page size (the
  BFF route pages through everything by design). Fine at current volumes;
  unbounded over years.
- The feed requests `appointments limit: 200` and `encounters page_size: 200`.
  Past 200 the oldest events are **silently dropped** — the user is not told the
  feed is incomplete.

**Ask:** confirm whether these list endpoints return a true total.
`list_encounters` appears to, and `useAppointmentsWithTotal` exists on the
frontend. Given a total, the frontend can show "showing N of M" and offer "load
older" instead of truncating in silence.

---

## Not requested: a merged activity endpoint

Opening the tab issues seven parallel requests (appointments, encounters, vitals,
labs, documents, immunizations, providers). All are react-query cached and shared
with the rest of the chart, so most are warm in practice. **This is not currently
a performance problem and needs no action.**

Noted only because a single endpoint is what would unlock proper cursor pagination
across the merged feed (6/7) and a stable server-side intra-day sort (2/3). Worth
revisiting only if the feed grows a "load more" requirement.

---

## What the frontend does when each lands

| Gap | Frontend change |
|---|---|
| 1 | Prefer `added_by_name` — **already coded**, zero-change |
| 2/3 | Use the supplied timestamp for ordering (and the time column, if it is a true result time) |
| 4 | Group on real report identity instead of `source_file_url` |
| 6/7 | "showing N of M" + load-older control |

Every one of these degrades gracefully: the feed keeps working with today's
payloads when a field is absent.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-17 | Sarvesh | Initial version (header backfilled from git history) |
