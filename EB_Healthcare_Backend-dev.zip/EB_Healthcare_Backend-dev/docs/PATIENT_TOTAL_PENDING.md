# Patient Total Pending Balance — Mechanism

**Doc status:** living · **Created:** 2026-09-16 by Ashutosh (AI-assisted) · **Updated:** 2026-09-16 by Ashutosh (AI-assisted) · **Version:** 1.1

## 1. Scope

How the Command Center appointment drawer's PAYMENT tile computes the patient's real total pending balance — every already-invoiced-but-unpaid Sales Invoice plus everything still unbilled, tax-inclusive — and the pre-existing `create_pos_invoice` tax bug this work found and fixed along the way. See [ADR-071](adr/adr-071-patient-total-pending-and-item-tax-fix.md) for the decision and rejected alternatives; this document is the mechanism, layer by layer.

## 2. Why this needed to change

Reported live: the drawer showed "Unpaid MXN 1,000" for an appointment, computed as `row.expected_amount_mxn` (that one appointment's own consultation fee) plus a client-side tax guess. A patient can owe money from other visits entirely — other unpaid invoices, other unbilled labs/meds/procedures — none of which this figure ever included. Reported and re-stated across two sessions: show the real total, not one appointment's slice.

## 3. The shape of the fix

1. `services/billing.py::get_patient_total_pending(patient)` — new function, two halves summed:
   - **Already invoiced:** `SUM(outstanding_amount)` across every submitted, non-return Sales Invoice for the patient.
   - **Not yet invoiced:** every line `get_patient_billables(patient)` currently returns, priced through a real (never-saved) draft Sales Invoice, so the number is exactly what checkout would charge — not a guess.
2. `create_pos_invoice`'s invoice-building code extracted into a shared `_build_pos_invoice_doc(...)` helper — both the real invoice path and the preview build the identical draft, so they can never quietly disagree.
3. **A real, pre-existing, live bug found and fixed while building this**: `_build_pos_invoice_doc` never carried each line's `item_tax_template` onto the Sales Invoice row it builds, so every service billed through the consolidated POS checkout (`create_pos_invoice`) invoiced at zero tax regardless of what its Item master specified — while the separate manual "New Sales Invoice" editor (`create_invoice`) charged the correct amount for the identical item. Fixed by copying `item_tax_template` onto each row after `set_healthcare_services()`/the Immunization append runs.
4. New whitelisted endpoint `api/v1/billing/api.py::get_patient_total_pending`, gated `require_permission("Sales Invoice", "read")` (not `"create"` — see §6).
5. Frontend: `usePatientTotalPending` hook, `/api/billing/total-pending` BFF route, and `mission-control-client.tsx`'s PAYMENT tile rewritten to show the total instead of the appointment-scoped estimate.

## 4. Why a real draft invoice, not a tax-rate formula

A naive approach — sum each line's `rate * qty`, then add `rate * item_tax_template's nominal %` — was rejected before being tried. This codebase already has a documented, live incident from exactly that assumption: `services/billing.py::_create_reschedule_refund`'s own comment records that an Item Tax Template only ever becomes real charged tax once it's promoted to a header Sales Taxes and Charges row — assuming otherwise cost a real 55-peso shortfall on a refund (`ACC-SINV-2026-00579`). Building the exact draft `create_pos_invoice` would submit, and reading its computed `grand_total` before discarding it, sidesteps that risk entirely: the number is never an approximation of the real invoice calculation, it IS that calculation.

This is also *how* the item-tax bug below was found: a formula-based estimate would have silently agreed with whatever number it was told to compute. Building the real draft surfaced the actual discrepancy between what checkout was really about to charge and what the item's own tax configuration said it should.

## 5. The item-tax bug, precisely

Verified live against patient Isha Iyer (MRN-2026-0001437), a real patient with real pending data — not test/scratch:

- Her "Consulatation fee" item carries a real Item Tax Template (`Mexico Tax - N`, IVA 16%).
- Billing that line through `create_pos_invoice` (the consolidated checkout `set_healthcare_services` path) produced exactly 500 MXN — zero tax.
- Billing the identical item through the separate manual invoice editor (`create_invoice`, `/billing/invoices/new`) produced 580 MXN — the correct, tax-inclusive amount.

Root cause, traced into the actual code:

- `set_healthcare_services` (`apps/healthcare/healthcare/healthcare/custom_doctype/sales_invoice.py` — third-party Healthcare app, never patched directly per Constitution Rule 1) calls core's `get_item_details()` per item, which DOES resolve the item's tax template — then the mixin copies only a fixed allowlist of fields onto the invoice row (`rate`, `income_account`, `reference_dt`/`dn`, `description`, `discount_percentage`, `insurance_*`). `item_tax_template` was never one of them.
- The Immunization-line append (`_build_pos_invoice_doc`, this app's own code, not core's) had the identical omission — it never set `item_tax_template` either.
- Even with `item_tax_template` set on a row, `calculate_taxes_and_totals()` alone does **not** turn it into a header tax row — that promotion happens in `accounts_controller.py::set_taxes_and_charges()` → `append_taxes_from_item_tax_template()`, gated by `Accounts Settings.add_taxes_from_item_tax_template` (confirmed **enabled** on this site). That method normally runs as part of `.validate()`, which a real `.save()` (as `create_pos_invoice` does) always triggers — so the ONE fix needed for the real invoice path was carrying `item_tax_template` onto the row; `.save()`'s own validate chain does the rest automatically.
- The preview function (`get_patient_total_pending`) deliberately never calls `.save()`/`.validate()` (nothing may be persisted), so it has to call `draft.set_taxes_and_charges()` explicitly, before `draft.calculate_taxes_and_totals()`, to get the same result a real save would produce.

**Fix, in `_build_pos_invoice_doc`:**

```python
# Healthcare-service rows (via the third-party mixin):
for row, s in zip(si.items, healthcare):
    if s.get("item_tax_template"):
        row.item_tax_template = s["item_tax_template"]

# Immunization rows (this app's own append):
si.append("items", {
    ...,
    "item_tax_template": s.get("item_tax_template"),
})
```

**And in `get_patient_total_pending`, before reading the total:**

```python
draft.set_taxes_and_charges()      # promotes item_tax_template -> header tax row
draft.calculate_taxes_and_totals()  # in-memory only — draft is never saved
```

## 6. Why `require_permission("Sales Invoice", "read")`, not `"create"`

`get_patient_billables` (the existing cart endpoint) requires `"create"` on Sales Invoice, since it backs an actual checkout flow. `get_patient_total_pending` only needs `"read"` — checked directly against this site's DocPerm table before shipping: `EB_Nurse` has `read: 1, create: 0`. Requiring `"create"` here would have blocked nurses from seeing a number they could already see (the old client-side estimate had no such gate) — a real access regression this check caught before it happened.

## 7. What did NOT change

- No historical Sales Invoice was recomputed, corrected, or credit-noted. This fixes the code path going forward only. Whether previously under-charged tax needs remediation (a compliance/CFDI question) is a separate, unmade decision.
- `create_invoice` (the manual editor) was not touched — it already carried tax correctly; it was the reference this work verified against, not a component of the fix.
- No new dedup/guard was added anywhere in this work — that is the unrelated, still-open "same-day duplicate dose" discussion from the immunization work earlier the same day (see WORK_LOG).

## 7a. Which figure the drawer actually shows

The backend computes and returns all three figures every time — `invoiced_outstanding_mxn`, `unbilled_total_mxn`, `total_pending_mxn`. The Command Center drawer's PAYMENT tile was shipped first showing the combined `total_pending_mxn`, verified live, and shown to the person who asked for it. They then asked, explicitly, to narrow it to `unbilled_total_mxn` only — confirmed after being shown the concrete tradeoff (a patient with a real, already-invoiced, unpaid balance but nothing new to bill now reads as "settled" on this one tile; that balance still exists on its invoice and in the full billing tab). This is a frontend-only change — `mission-control-client.tsx` reads a different field off the same, unchanged endpoint. If a future screen needs the combined figure, or this tile is ever widened back out, the data is already there.

## 8. Testing

Live, read-only verification only (no automated test added this pass — a reasonable follow-up would be a test asserting `create_pos_invoice`'s real, submitted invoice charges the same total as `get_patient_total_pending` previews for the same cart):

- Confirmed `total_pending_mxn` exactly reconciles against real data for two different patients: Ananya Kapoor (0 pending — cart genuinely empty, separately confirmed why: her only unbilled items are gated behind a disabled Item master, `VAC-APLICACION`, unrelated to this fix) and Isha Iyer (1,138 invoiced-outstanding + 1,580 unbilled = 2,718 total, matching the manual editor's per-item total exactly).
- Confirmed, via `.validate()` on a throwaway draft (never inserted/saved), that a REAL invoice created through `create_pos_invoice` after this fix charges the same corrected total — not just the preview function.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-16 | Ashutosh (AI-assisted) | §7a added: the drawer now shows `unbilled_total_mxn` only, not the combined `total_pending_mxn` — narrowed on request after the combined figure shipped and was shown live |
| 1.0 | 2026-09-16 | Ashutosh (AI-assisted) | Initial version |
