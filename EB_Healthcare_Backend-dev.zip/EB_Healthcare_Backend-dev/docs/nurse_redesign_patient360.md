# Nurse — Patient 360 redesign

**Doc status:** living · **Created:** 2026-09-29 by Ashutosh (AI-assisted) · **Updated:** 2026-09-29 by Ashutosh (AI-assisted) · **Version:** 1.1

Rebuilding the Patient 360 chart for the **Nurse** role against the Narzim
design. Companion to
[`frontdesk_redesign_patient360.md`](frontdesk_redesign_patient360.md), which
covers the front-desk view and the shared groundwork — design tokens, the
`.nz-design` scoping, the Tailwind traps and the shared card components. Read
that one first; this document only records what is specific to nurse.

**Scope:** the nurse view. Doctor and admin are untouched.

---

## 1. Where the design lives

| | |
|---|---|
| File | `Patients.dc.html`, the `role === 'nurse'` config (around line 561) |
| Purpose line | *"What you need before the doctor: today's visit, tasks, allergies and vitals."* |
| Read via | `DesignSync(get_file)` for the source, plus the live canvas with `roleFrontdesk` / `roleDoctor` **off** |

Switching the other roles off is not optional. In a multi-role render the tabs
after the divider belong to the user's *other* roles, so the only way to see
what a nurse alone gets is to turn the rest off. Two findings came from doing
exactly that, and neither is visible in the source config:

**The `rail` is dead config.** Every role defines one — admin (549), nurse (566),
doctor (579) — and **no role renders it**. There is no `ch.rail` anywhere in the
markup, and the rendered nurse view has no side rail. Do not build it.

**`VITALS TREND` is not in `cfg.cards`.** It comes from a separate `tables` key
that the card config does not mention:

```js
nurse   tables: { overview: ['vit'], visits: ['enc','lab','vit'] }
doctor  tables: { overview: ['enc'], results: ['lab','vit'] }
```

So a nurse's Overview is four cards **plus** a vitals-trend table, and the
History tab is tables only with no cards at all (`cards.visits: []`). Reading
`cfg.cards` alone misses the table entirely. Front desk has no `tables` key,
which is why that view has none.

---

## 2. What the design specifies

```
‹ ⬤ Roberto Castillo B+ 38y3m·M [Nursing task]        [Log immunization] [Record vitals]

● Allergy·Ibuprofen ● Waiting 14 min ● Temp 38.4°C at desk ● Asthma·inhaler PRN ● Flu vaccine due Nov
                          "What you need before the doctor: today's visit, tasks, allergies and vitals."

● TEMP AT DESK   ● LAST VITALS          ● ALLERGIES        ● TASKS
  38.4 °C          10 Sep                 Ibuprofen          4 open
  febrile·recheck  09:05 · Paola Ruiz     rash · 2021        1 due now

Overview · Medications · Immunizations · History · Messages

[Today's visit] [Nursing tasks] [Allergies] [Safety & contact]
VITALS TREND                                            [+ Record vitals]
```

---

## 3. What was built

### 3.1 Per-role tab order

The design orders tabs per role, and a nurse's order is its own: Medications and
Immunizations lead, Messages comes last. `TAB_ORDER` in `patient-screen.tsx`
became `TAB_ORDER_BY_ROLE` with a `DEFAULT_TAB_ORDER` fallback, so nurse gets its
own list. A key missing from a list still sorts to the end rather than
disappearing.

```
design, nurse   Overview · Medications · Immunizations · History · Messages
ours            Overview · Medications · Immunizations · Timeline ·
                WhatsApp Chat · Portal Chat · Lab Test · Appointments ·
                Documents · Family
```

The design's five lead; our extras follow rather than being hidden (decided
2026-09-29). `Timeline` takes the `History` slot: the design's nurse "History" is
its tables view, which this app keeps on Summary.

### 3.2 `chart-band.tsx` — the shared band

The chips + KPI band existed but was bound to one role. Extracted to a
presentational component the nurse band renders, rather than growing a second
copy — that duplication is what produced the profile-gap bug recorded in the
companion doc.

**The tone → colour rule is the design's `K()` helper, verbatim:**

```js
fg  = tone && tone !== 'ok' && tone !== 'none' ? T[tone][1] : var(--ink-900)
dot = T[tone || 'none'][3]
```

`crit` red · `warn` amber · `teal` teal · **`ok` and `none` stay ink**. A settled
balance and a clean allergy record are black with a green *dot* — good news gets
the dot, not the ink. Only a value needing action is coloured.

Three things were wrong before this was read properly:

| | Was | Design |
|---|---|---|
| value colour | an invented `valueTone` opt-in flag | deterministic from the tone |
| `ok` border | `--ok-border` | **`--ok-bg`** — a green chip has no darker rim |
| `none` dot | `--ink-200` | **`--ink-300`** |

**Tile clickability is also from `K()`** — a tile is a control only when `go` is
passed, and the nurse config passes it on **none** of the four. So no nurse tile
navigates, and none carries the design's `˅`.

### 3.3 `nurse-band.tsx`

Four KPIs and the chips, all from data that already exists.

| Tile | Source | Tone |
|---|---|---|
| Temp at desk / Last temp | `list_vital_signs` → `temperature` | `crit` at ≥ 38 °C |
| Last vitals | `signs_date` + `signs_time` | `warn` when the patient is in **today** and the reading is not |
| Allergies | `patient.allergies` | `crit` when any |
| Tasks | `list_nursing_tasks` | `crit` when open **and** the patient is here now, else `warn` |

Two tone rules only visible by reading `K()` properly, both implemented:

- **Last vitals turns amber when the patient is in today.** A reading from a
  previous visit is stale the moment someone is sitting in front of you, and
  amber is how the nurse is told to take a fresh set.
- **Tasks go crit, not warn, when the patient is here now.** Open work on an
  absent patient is a reminder; on one who is waiting, it is a queue holding up
  the doctor.

The label switches **"Last temp" → "Temp at desk"** when the reading is today's,
as the design does.

### 3.4 `nurse-overview.tsx`

The design's four cards, rendered **above** the existing clinical blocks:

| Card | Contents |
|---|---|
| Today's visit | When · With (practitioner · service unit) · Reason · Temp |
| Nursing tasks | one row per open task, status as the badge |
| Allergies | one row per allergy |
| Safety & contact | Blood group · Weight · Mobile · Emergency contact |

Hidden entirely when there is nothing to show — a card saying "no visit" tells a
nurse nothing they did not already know.

### 3.5 `vitals-trend.tsx`

The design's `ch.tVit` table: parameters down, readings across, newest first,
with `+ Record vitals` in the header.

```
grid      minmax(160px,1.4fr) repeat(N, minmax(72px,1fr)) · gap 10
head row  9px 18px · --ink-5 · "Parameter" 600 10px .07em uppercase --ink-350
data row  10px 18px · border-bottom 1px --ink-25 · tabular-nums
cell      plain 500 12.5px --ink-500 · latest 700 13px · abnormal badged --warn-bg
```

Three cell states, and they are the point: an out-of-range value is badged, the
most recent in-range one is bold, older ones recede — so the eye lands on *what
is wrong*, then *what is now*.

**Every reading, not four.** The design shows four because its demo patient has
four; its own markup is `overflow-x:auto` around a `min-width:520px` inner div,
i.e. built to scroll. The table now renders every reading the hook fetched and
scrolls when they do not fit.

The inner width is **computed**, not left at the design's flat 520px:

```
min-width = max(520, 160 + readings × 82)     // 160 label + (72 column + 10 gap)
```

`minmax(72px,1fr)` only guarantees a 72px *floor*. With enough columns the
browser squeezes them to the container instead of overflowing, and the scroll
never engages — the grid has to be told how wide it really is.

**The Parameter column sticks**, which the design does not do. It does not need
to at four columns; at twenty, scrolling right would leave a wall of numbers with
no row labels. A departure, and a deliberate one.

Both behaviours verified in the browser rather than assumed:

```
7 readings    min-width  734px · scrollWidth 1406 = clientWidth 1406 → no scroll
20 readings   min-width 1800px · scrollWidth 1800 > clientWidth 1406 → scrolls
sticky        scrolled 394px   · label left 113 == scroller left 113 → held
```

**Abnormal is a clinical claim**, so every threshold is the app's own, taken from
the field-help catalogue the nursing screen already shows — BP ≥ 140/90, pulse
< 50 or > 110, temp ≥ 38, SpO₂ < 94, BMI ≥ 30. Weight has no threshold in that
guidance, so it is never flagged rather than guessed at. A parameter never
recorded is omitted, not rendered as a row of dashes.

### 3.6 Header actions

- **`Book appointment` is hidden for nurse.** It was ungated. Booking is a
  desk/clinical-owner job — the same role set `AppHeader`'s own `BOOKING_ROLES`
  uses, which never included nurse.
- **`Record vitals` is always shown for a nurse.** Deliberately not gated on a
  checked-in appointment the way the breadcrumb copy is: recording vitals is the
  normal reason a nurse opens this chart, not an exception. No capability check
  either — `roles.ts` grants `recordVitals: true` to nurse unconditionally.

### 3.7 Three blocks removed from the nurse Overview

Requested 2026-09-29, and it is also exactly what the design's nurse Overview
contains and nothing more:

- Clinical summary (`PatientClinicalSummaryCard`)
- Last encounter summary (`PatientSummaryCard`)
- Patient history (`HistoryTab`) and the growth/vitals block (`VitalsTab`)

**Not withheld** — a nurse is a clinical role and can open all three from their
own tabs. They are off *this view* because it answers one question, and three
long read-only blocks push that answer off the screen.

`ClinicalNotesCard` was **not** removed: it was not in the list. The design has
no equivalent, so it is a candidate if the tab still feels long.

---

## 4. Backend — nothing new was needed

Two modules were already there and are worth knowing about:

| | |
|---|---|
| `api/v1/nursing/api.py` | **1,241 lines** — `list_nursing_tasks(patient, status)`, `create_nursing_task`, `assign_nursing_task`, healthcare activities. Hook: `use-nursing.ts` |
| `api/v1/tasks/api.py` | 1,206 lines, including `_fetch_nursing_tasks` |

The Nursing tasks card needed **no backend work at all**.

### Four values have no backing field

Every field name on `Patient Appointment` and `Vital Signs` was checked for
`arriv` / `check_in` / `prior` / `urgen` / `triage` / `fall` / `risk` / `nurse` /
`recorded`:

| Design value | Verified absent |
|---|---|
| `Arrived 10:31 · waiting 14 min` | no arrival timestamp on Patient Appointment |
| `Priority: Routine` | no priority / urgency / triage field |
| `Fall risk: Low` | no such field on any doctype |
| `09:05 · Paola Ruiz` | `signs_time` exists; there is **no recorded-by** on Vital Signs |

All four are **omitted, not dashed** (decided 2026-09-29). A permanently blank
clinical row reads as a loading failure, and a fabricated fall risk is worse than
either. The time half of the last one *is* shown, because `signs_time` is real —
only the name is dropped.

`Arrived / waiting` is the one a nurse would actually use, if any of these are
ever worth adding.

---

## 5. Bugs found and fixed

| Symptom | Cause |
|---|---|
| **Tasks tile opened the Record-vitals modal** | Straight miswire — `onClick: onRecordVitals` on the Tasks tile. Tasks are not vitals, and a tile opening an unrelated modal is worse than one that does nothing |
| **Values rendered black** | An invented `valueTone` opt-in instead of the design's deterministic rule |
| **`NKDA` printed for an empty allergies field** | See below — a clinical-accuracy problem, not a wording one |
| **Vitals older than the fourth reading were unreachable** | The trend was capped at `columns = 4`, and the nurse Overview no longer renders the Vitals tab — so this table is a nurse's ONLY view of vitals. Everything older was hidden with nothing on screen to say it existed. A cap justified as "avoiding a scroll" on a table the design had already built to scroll |

### `NKDA` was clinically wrong

Copied from the design (`al.length ? al.join(', ') : 'NKDA'`). NKDA means *No
Known **Drug** Allergies* — a cleared drug history. This app's field is
`Patient.allergies`, free text labelled simply **"Allergies"**, so it covers food
and environmental too, and an empty one means *nothing was written down*, which
is not the same as *asked and ruled out*.

A nurse reading `NKDA` would take it as a cleared history. That is asserting in
the UI something the data does not support — §9.9 **PHI-5**.

The two languages also disagreed: English printed the initialism while Spanish
printed `Sin alergias conocidas`, which silently widened the claim from *drug*
allergies to *all* allergies.

```
now   en   None recorded  ·  "No allergies recorded. Confirm with the patient at every visit."
      es   Sin registrar  ·  "Sin alergias registradas. Confírmelo con el paciente en cada visita."
```

The long form carries the app's own existing guidance from the nursing
field-help. The reasoning is in `nurse-band.tsx` so nobody restores `NKDA` from
the design later.

**This is the "don't copy the design blindly" check working.** It was caught
because someone asked what the letters meant.

### A data problem, flagged not fixed

Vitals records are storing **`0`** rather than null for unmeasured values, so
SpO₂ renders as critically low and BMI as flagged when the truth is *not
measured*. The display is faithful to the record; the record is wrong. Two
possible fixes — guard the display for values where zero is physiologically
impossible, or stop the write path storing `0` for a blank field. The second is
the real one. **Neither is done.**

---

## 6. NOT DONE

### 6.1 History tab

`tables: { visits: ['enc','lab','vit'] }` — encounters, labs and vitals tables,
no cards. The vitals table is built (`vitals-trend.tsx`); the encounters and labs
tables are not.

### 6.2 Messages

```js
msgs: [C('WhatsApp & SMS with ' + first, 'thread', thread, { wide: true, act: [...], compose }),
       C('Activity', 'rows', activity, { wide: true })]
```

Same gap as front desk, plus an Activity card the front-desk config does not
have. See the front-desk doc §7.1 — that view's Messages card carries the
*"Clinical messages are routed to the doctor"* notice, which is a PHI boundary
stated in the UI, not decoration.

### 6.3 Other

- **`Log immunization`** — the design's secondary nurse action. Ours lives in the
  breadcrumb as "Add immunization", not in the patient header.
- **The chips the design shows that we cannot** — `Waiting 14 min`,
  `Flu vaccine due Nov`. The first has no backing field (§4); the second needs
  the immunization schedule read per patient, which exists but is not wired here.
- **`ClinicalNotesCard`** still renders on the nurse Overview.
- **Colours are unverified against real alert data.** No patient in the database
  has an allergy, and the only febrile reading appeared mid-session. The `crit`
  path was confirmed by a **runtime-only** `window.fetch` override in the browser
  — nothing written — which rendered `38.4 °C` as `rgb(140,43,33)` = `--crit-fg`
  with an `--crit-solid` dot. The `warn` path has never been seen on screen.

---

## 7. Files touched

**New**

```
src/components/narzim/patient-chart/chart-band.tsx      shared chips + KPI band
src/components/narzim/patient-chart/nurse-band.tsx      the nurse's four KPIs
src/components/narzim/patient-chart/nurse-overview.tsx  the nurse's four cards
src/components/narzim/patient-chart/vitals-trend.tsx    the design's tVit table
```

**Changed**

```
src/components/narzim/patient-chart/patient-screen.tsx      TAB_ORDER_BY_ROLE
src/components/narzim/patient-chart/overview-tab.tsx        nurse branch, three blocks hidden
src/components/narzim/patient-chart/reception-band.tsx      migrated onto ChartBand (shared extraction)
src/components/narzim/patient-chart/reception-model.ts      fmtShortDate, ReceptionAppt widened
src/app/(clinic)/patients/[id]/patient-chart-client.tsx     nurse band, header actions
messages/en.json · messages/es.json                         chart.nurse, chart.vitalsTrend
```

No backend change was required for the nurse view.

**Verification:** `tsc` clean · 630 tests / 36 files passing · no new lint errors
· en/es key parity. The band, tab order, cards and vitals trend were each
confirmed in the browser against a live nurse session (`nurse@gmail.com`), with
the tone rule checked by reading `getComputedStyle` rather than by eye.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-29 | Ashutosh (AI-assisted) | Vitals trend shows every reading and scrolls horizontally, with a computed inner width and a sticky Parameter column. Records the four-column cap as a defect: it hid vitals a nurse had no other way to reach |
| 1.0 | 2026-09-29 | Ashutosh (AI-assisted) | Initial record of the nurse Patient 360 redesign: the band, cards, vitals trend and tab order; the design's tone and clickability rules; the NKDA correction; and what remains |
