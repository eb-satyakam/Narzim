# Patient Documents — Design & Build Plan

**Doc status:** living · **Created:** 2026-06-19 by Anant Sharma · **Updated:** 2026-06-19 by Sarvesh-SocialAngel · **Version:** 1.0

> **Screen 13 — Documents.** Surfaced as the **Documents sub-tab under the Clinical
> section** of the Patient Chart (`documents-tab.tsx`, mounted at
> `patient-screen.tsx:611`). This document is the authoritative design and build
> plan for storing uploaded patient documents (lab reports, x-rays, referrals,
> prescriptions, consents, and other files) against a patient.

**Status:** Planned (not yet built).
**Owner:** Backend.
**Last updated:** 2026-06-19.

---

## 1. Goal

Let staff upload arbitrary clinical files **against a patient** — lab report PDFs,
x-ray images, referral letters, signed consents, etc. — categorize them, and
list / preview / download / delete them from the patient chart Documents tab.

The existing frontend `documents-tab.tsx` is a **demo shell**: `docs` initializes
to an empty array, upload is stubbed, and the action buttons have no handlers.
There is currently **no backend** for it (no `api/v1/documents`, no service, no
file/attachment handling anywhere in the app). This plan builds that backend.

---

## 2. Storage model — reuse `Patient Medical Record`

Documents are stored as rows in the **core ERPNext Healthcare `Patient Medical
Record` (PMR)** doctype — one row per uploaded file. We do **not** create a new
storage doctype.

Why PMR:
- It is keyed to `patient` and ships an `attach` field literally labeled
  "Attach Medical Record".
- Reusing a core healthcare doctype keeps us **upgrade-safe (Rule 1)** — we only
  add custom fields, never modify core.
- The constitution prefers reusing core healthcare doctypes over inventing new
  ones for clinical data.

PMR fields used:

| PMR field | Use |
|---|---|
| `patient` (Link) | the patient the document belongs to |
| `attach` (Attach) | the uploaded file (one file per record) |
| `subject` (Text Editor) | document display name / filename |
| `communication_date` | document date |
| `user` / `owner` | who uploaded it |
| `reference_doctype` / `reference_name` | set to **`File` / the uploaded File's name** — links the record to exactly what was uploaded |

---

## 3. The discriminator problem (and the fix)

PMR is **also** the engine behind the patient history/timeline. ERPNext Healthcare
**auto-creates** a PMR row whenever a clinical document is submitted (Encounter,
Vital Signs, Lab Test, Prescription, Discharge Summary…). Verified in
`healthcare/.../patient_history_settings.py::create_medical_record()` — it sets
`patient`, `subject`, `status`, `communication_date`, `reference_doctype`,
`reference_name`, `reference_owner`, and **never sets `attach`**.

So if the Documents tab naively queried all PMR rows for a patient, it would
return every history entry too.

### Fix: an explicit upload flag

Add a custom field `custom_is_uploaded_document` (Check, **read-only**, default
`0`) to PMR. Only our upload service sets it to `1`. Auto-created history rows
take the default `0` and are therefore **completely untouched** — existing
Healthcare behavior is unchanged.

The Documents tab lists only rows where `custom_is_uploaded_document = 1`.

**Why a flag and not `attach IS NOT NULL`:** the `attach`-empty behavior of
auto-rows is a Healthcare *implementation detail*, not a contract. A future
version could auto-attach files to history rows and silently pollute the
Documents tab. An explicit flag that only our code sets does not depend on
Healthcare internals — we own the signal.

> **Known limitation:** the native Frappe **Desk** patient-history feed
> (`patient_history.py::get_feed`) does not know about our flag. In its
> *unfiltered* mode it returns all PMR rows for a patient, including uploads.
> When the doctype filter is active, uploads are excluded (their
> `reference_doctype` is `File`, which is not a configured patient-history
> document type). This only affects the admin-facing Desk screen; the
> clinical UX is Next.js and builds its own history off our API, where we
> control the filter. Low stakes, documented so no one is surprised.

| Source | `custom_is_uploaded_document` | In Documents tab? |
|---|---|---|
| Encounter / Vitals / Lab auto-history | `0` (default) | No |
| Manual upload (lab report, x-ray) | `1` (set by service) | Yes |

---

## 4. Categories — `Document Category` master doctype

The tab bar categories (from the design): **Lab Reports, Imaging, Referrals,
Prescriptions, Consents, Other** (`All` is a filter, not a stored category).

These are modeled as a **master doctype** (not a `Select`) because:
1. Each category carries **presentation metadata** (color, icon) — the frontend
   `CATEGORY_CFG` already proves this.
2. Clinics may add their own categories at runtime without a code deploy.

> If categories were ever locked to exactly these six forever and clinics could
> never change them, a plain `Select` + catalog translations would be the lighter
> correct choice. The master is justified by configurability + per-category
> metadata.

### Doctype: `Document Category` (lives in `remedisys_healthcare_ai` app)

| Field | Type | Notes |
|---|---|---|
| `code` | Data | **unique, stable, lowercase** — i18n key + program reference (e.g. `lab_reports`) |
| `category_name` | Data | admin/fallback display label |
| `color` | Data | hex, e.g. `#0098E4` |
| `icon` | Data | lucide icon name, e.g. `FileText` |
| `sort_order` | Int | tab order |
| `is_active` | Check | hide without deleting |
| `is_standard` | Check | protects the 6 built-ins from deletion/rename |

The document's category becomes `custom_document_category` → **Link → Document
Category** on PMR.

### Standard seed rows

| code | category_name | color | icon | sort |
|---|---|---|---|---|
| `lab_reports` | Lab Reports | `#0098E4` | FileText | 1 |
| `imaging` | Imaging | `#8B5CF6` | FileImage | 2 |
| `referrals` | Referrals | `#10B981` | FileType | 3 |
| `prescriptions` | Prescriptions | `#F59E0B` | FileCode | 4 |
| `consents` | Consents | `#64748B` | FileText | 5 |
| `other` | Other | `#94A3B8` | File | 6 |

Seeded via an **idempotent patch** (registered in `patches.txt`) so the rows
exist before any document links to them, and re-running migrate never duplicates
them. All seeded with `is_standard = 1`.

---

## 5. Internationalization (es-MX / en-US)

Master-doctype values live in the **database as data** — the frontend message
catalogs never see them. Storing a user-visible English label in the master
would silently break bilingual UX (Rule 10).

**Mechanism — stable `code` + catalog translation:**

```
Document Category row:  code = "lab_reports"   (never shown to users)

messages/en.json:  "documentCategory.lab_reports": "Lab Reports"
messages/es.json:  "documentCategory.lab_reports": "Resultados de Laboratorio"

Frontend render:   t(`documentCategory.${cat.code}`)
```

- **Standard categories** translate cleanly in both languages via their `code`.
- **Clinic-custom categories** have no catalog entry → frontend falls back to the
  typed `category_name`. Acceptable: it is clinic-authored data, not a system
  string.

The `code` also serves as the stable program reference, so renaming a display
label never breaks code that checks `code === "consents"`.

---

## 6. End-to-end flow

```
User uploads chest_xray.pdf, picks category "Imaging"
        │
        ▼  (api/v1/documents → services/documents.py)
1. require_permission("Patient", "write")
2. save_file(content, is_private=1)          → creates a PRIVATE Frappe File
3. new Patient Medical Record:
     patient                     = "HLC-PAT-0001"
     subject                     = "chest_xray.pdf"
     attach                      = <private File url>
     custom_is_uploaded_document = 1            ← upload flag (the discriminator)
     custom_document_category    = "imaging"    ← Link → Document Category
     reference_doctype           = "File"       ← links the record to the
     reference_name              = <File name>      uploaded File doc
        │
        ▼  Documents tab list
   list_documents(patient):
     WHERE patient = X AND custom_is_uploaded_document = 1
     grouped by custom_document_category
     label resolved on frontend from category.code
```

---

## 7. Files to create / modify

### Backend

```
remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/document_category/
  ├── document_category.json          # new master doctype
  ├── document_category.py            # block edit/delete of is_standard rows
  └── test_document_category.py

remedisys_healthcare_ai/remedisys_healthcare_ai/fixtures/custom_field.json
  # append 2 entries (hand-edit — NO bench export-fixtures):
  #   Patient Medical Record.custom_is_uploaded_document (Check, read_only, default 0)
  #   Patient Medical Record.custom_document_category    (Link → Document Category)

remedisys_healthcare_ai/patches/v1/seed_document_categories.py   # idempotent seed
remedisys_healthcare_ai/patches.txt                              # register patch

remedisys_healthcare_ai/services/documents.py
remedisys_healthcare_ai/api/v1/documents/api.py
remedisys_healthcare_ai/tests/documents/test_documents.py
```

Plus **Custom DocPerm** grants so Nurse / Front Desk can read+write PMR for
uploads (watch the orphan `rmd_` DocPerm gotcha on core healthcare doctypes —
hand-grant and verify).

### Frontend (separate repo — requires its own explicit go-ahead; read-only by default)

```
src/app/api/patients/[id]/documents/route.ts        # BFF list + upload
src/app/api/patients/[id]/documents/[docId]/route.ts # BFF download + delete
src/components/narzim/patient-chart/documents-tab.tsx # wire real data
  - replace useState<Doc[]>([]) with a fetch
  - replace hardcoded CATEGORY_CFG with list_categories()
  - resolve labels via t(`documentCategory.${code}`)
  - wire upload / preview / download / delete
```

---

## 8. API surface (`api/v1/documents/api.py`)

All methods call `require_permission(...)` first. All logs carry IDs only
(`patient_id`, `document_id`) — never filenames or content (Rule 10).

```python
list_documents(patient, category=None, search=None, page=1)
    # filters PMR: patient=X, custom_is_uploaded_document=1
    # -> [{id, name, category, type, size, date, added_by, file_url, reference_name}]

upload_document(patient, file, category)
    # require_permission("Patient", "write")
    # save_file(is_private=1) -> create PMR row (flag=1, category, attach)

get_download_url(document_id)   # permission-checked; never a public /files/ URL

delete_document(document_id)    # delete File blob + PMR row (cascade)

list_categories()               # [{code, color, icon, sort_order}] for the tab bar
```

---

## 9. Risks & mitigations

| Risk | Mitigation |
|---|---|
| **PHI exposure via public file URLs** | `is_private=1`; download only via permission-checked endpoint; test that raw `/private/files/...` is rejected when logged out |
| **Orphaned file blobs on delete** | delete cascade (File + PMR row); covered by a test |
| **Native Desk history leakage** | documented (§3); Desk is not the clinical UI; frontend controls its own filter |
| **Broken Link integrity** | seed runs before any reference; idempotent + patch-ordered |
| **Permission gaps (Nurse/Front Desk 403)** | Custom DocPerm grants, verified per role |
| **Large imaging files** | enforce a max size server-side (frontend says 25 MB); mind Frappe Cloud upload limits |
| **i18n regression** | `code`-based translation; never store English label as the display string |

---

## 10. Build sequence (milestones)

1. **`Document Category` doctype + idempotent seed patch** → migrate → confirm 6
   rows, `is_standard=1`.
2. **Two custom fields on PMR** via fixtures → migrate → confirm on a PMR form.
3. **`services/documents.py` + `api/v1/documents/api.py`** → upload / list /
   download / delete / categories, all permission-gated, files private.
4. **Tests** (`tests/documents/`):
   - upload sets flag + category and creates a private File
   - list excludes auto-history rows
   - delete cascades to the File blob
   - download blocked without permission
   - non-physician roles gated correctly
5. **Custom DocPerm** for Nurse / Front Desk → re-run role tests.
6. **(Separate, on explicit go-ahead) Frontend wiring** — BFF route +
   `documents-tab.tsx`.

Backend (1–5) is self-contained and testable without the frontend.

---

## 11. Compliance checklist (Mexico — LFPDPPP / NOM-024)

- [ ] All uploaded files stored `is_private=1`
- [ ] Downloads served only through a permission-checked endpoint
- [ ] No filenames / PHI in logs — IDs only
- [ ] Delete removes the underlying File blob (no residual PHI on disk)
- [ ] Role-scoped access (Physician / Nurse / Front Desk per clinic policy)
- [ ] `track_changes` on PMR retains an audit trail of document rows

---

## 12. Open decision

**Clinic-configurable categories (master) vs. the fixed six (`Select`).**
This plan assumes the **master** (configurable + metadata-driven). If categories
are locked forever, switch `custom_document_category` to a `Select` with stable
values and drop the `Document Category` doctype + seed patch. Everything else in
this plan is unaffected.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-19 | Sarvesh | Initial version (header backfilled from git history) |
