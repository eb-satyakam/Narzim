# Doctor — Patient 360 redesign

**Doc status:** living · **Created:** 2026-09-29 by Ashutosh (AI-assisted) · **Updated:** 2026-09-29 by Ashutosh (AI-assisted) · **Version:** 1.0

Rebuilding the Patient 360 chart for the **Practitioner / Doctor** role against
the Narzim design. Third in the series, after
[`frontdesk_redesign_patient360.md`](frontdesk_redesign_patient360.md) and
[`nurse_redesign_patient360.md`](nurse_redesign_patient360.md).

Read the front-desk document first — it owns the shared groundwork (design
tokens, `.nz-design` scoping, the Tailwind v4 traps, the shared card
components). Read the nurse one second — it owns `chart-band.tsx`,
`vitals-trend.tsx` and the `tables`-vs-`cards` discovery, all of which this view
reuses unchanged. **This document records only what is specific to the doctor.**

**Scope:** the practitioner view. Front desk and nurse are untouched by this
work; admin remains untouched by all three.

---

## 1. Where the design lives

| | |
|---|---|
| File | `Patients.dc.html`, the `else` branch of `_ch`'s role switch — the doctor config (around line 574) |
| Purpose line | *"The clinical picture: summary, problems, medications, results and care gaps."* |
| Read via | `DesignSync(get_file)` for the source, plus the live canvas with `roleFrontdesk` / `roleNurse` **off** |

The nurse document explains why switching the other roles off is not optional.
Two things specific to the doctor config are worth stating here:

**`rail` is dead config, confirmed again.** The doctor defines one at line 579
(Clinical / Care team / Visits groups). As with admin and nurse, there is no
`ch.rail` anywhere in the markup and nothing renders. Do not build it.

**The doctor's tables are different from the nurse's.**

```js
doctor  tables: { overview: ['enc'], results: ['lab','vit'] }
```

So the design's doctor Overview is its cards **plus a past-encounters table**,
and Results is two tables with no cards. Neither table is built yet — see §7.

---

## 2. What the design specifies

```
‹ ⬤ Roberto Castillo B+ 38y3m·M [Clinical task]   [Order labs] [New prescription] [Continue encounter]

● Allergy·Ibuprofen ● BP above target ● Eye exam overdue ● Pending·CBC, Dengue NS1
                    "The clinical picture: summary, problems, medications, results and care gaps."

● HBA1C          ● BLOOD PRESSURE     ● EGFR              ● CARE GAPS
  7.8 %            138/88               92                  4
  ↓0.6·target<7    above target × 3     mL/min · normal     1 overdue

Overview · Problems & meds · Results · Care plan · Messages · Documents

[✦ Clinical summary                                                              wide, ai ]
[Active problems  All →] [Current medications  New Rx →] [Care gaps  Care plan →]
PAST ENCOUNTERS (tables.overview = ['enc'])
```

Source, verbatim:

```js
kpis: [K('HbA1c','7.8 %','↓ 0.6 · target < 7','warn'),
       K('Blood pressure','138/88','above target × 3','warn'),
       K('eGFR','92','mL/min · normal','ok'),
       K('Care gaps','4','1 overdue','crit')],
cards: { overview: [C('✦ Clinical summary','ai',summary,{wide:true,sub:'AI · from 12 visits · review before relying on it'}),
                    C('Active problems','rows',problems,{act:['All',tabTo('problems')]}),
                    C('Current medications','rows',meds,{act:['New Rx',go('Prescriptions.dc.html')]}),
                    C('Care gaps','rows',gaps,{sub:'Diabetes care bundle',act:['Care plan',tabTo('care')]})], … }
```

**No doctor KPI passes `go`.** `K(k, v, sub, tone, go)` only makes a tile a
control when the fifth argument is present, and the doctor config never supplies
it. So — as for the nurse, unlike front desk — **not one tile is clickable**, and
none renders the chevron. Verified in the browser: zero `svg` in every tile.

---

## 3. What was built

### 3.1 Per-role tab order

`patient-screen.tsx` → `TAB_ORDER_BY_ROLE.practitioner`:

```
summary · conditions · medications · orders · vitals · messages · portalMessages · documents
         └─ "Problems & meds" ─┘   └─ "Results" ─┘   └── "Messages" ──┘
· encounters · history · immunizations · appointments · activity · billing · family · tasks · referrals
  └────────────────────── ours, after the design's ──────────────────────┘
```

**Two of the design's six tabs map onto pairs of ours, and are left as pairs.**
"Problems & meds" is one tab there and `conditions` + `medications` here;
"Results" is one tab there and `orders` + `vitals` here. Merging them means
fusing four working tab bodies into two — a rebuild, not a reorder — and the
instruction was that the design's *order* leads. Each pair keeps the design's
position, in the design's reading order.

**Care plan is absent, not last.** See §5.

A key missing from the list sorts to the end rather than disappearing, so
`conditions` and `vitals` — neither of which currently renders as a tab for a
practitioner — cost nothing by being named.

### 3.2 `doctor-band.tsx`

Renders through the shared `ChartBand` (nurse doc §3.2), so every measurement,
the `T` tone table and the value-colour rule are inherited, not restated.

**Chips**

| Chip | Source | Tone |
|---|---|---|
| `Allergy · <name>`, one per allergy (max 3) | `patient.allergies` | `crit` |
| `No allergies recorded` when empty | — | `none`, **not** the design's `ok` |
| `BP above target` | latest Vital Signs vs 140/90 | `warn` |
| `Pending · <tests>` | Lab Tests with `docstatus === 0` | `teal` |
| active problems (max 2) | `patient.activeConditions` | `none` |

The empty-allergy chip is grey rather than the design's green for the same
reason the nurse band says "None recorded" instead of "NKDA": green asserts a
*cleared* allergy history, and an empty `Patient.allergies` only means nothing
was written down.

**Tiles** — lab · blood pressure · lab, the design's order.

### 3.3 The lab tiles are not HbA1c and eGFR

The design names those two because its demo patient is a diabetic adult.
**Neither analyte exists anywhere on this site.** Verified by grouping
`Normal Test Result` across all 101 submitted Lab Tests:

```
   65   52  Test Analyte One
   26   26  Test Analyte Two
    5    5  Colesterol HDL / Creatinina / Colesterol LDL / Glicemia basal /
            Triglicéridos / Colesterol total / Nitrógeno ureico (BUN) / Colesterol VLDL
```

Hardcoding the design's two labels would put two permanently empty tiles in
front of every doctor, for all 528 patients — the failure `nurse-overview.tsx`
already documents, where a blank clinical row reads as a loading failure.

**Decision (taken with the user, 2026-09-29): the tile SHAPE is the design's,
the ANALYTE is the patient's own** — out of range first, then most recently
resulted. A patient with no labs gets no lab tile rather than a dash.

Live on `MRN-2026-0000001`:

```
● COLESTEROL TOTAL   ● BLOOD PRESSURE            ● GLICEMIA BASAL
  196 mg/dL            120/89                      89 mg/dL
  target < 200         3 of last 5 above target    target 70–100
```

**The sub-line reproduces both of the design's shapes**, chosen by what the data
supports:

| Design | When | Ours |
|---|---|---|
| `↓ 0.6 · target < 7` | ≥2 numeric points **and** a parsed range | `↑/↓ <delta> · target < X` |
| `mL/min · normal` | otherwise | `<unit> · <flag>` |

Both halves come from the backend. `get_lab_trends` returns `normal_low` /
`normal_high` per analyte and a per-point `flag`, so **"above target" here is
the server's judgement against the analyte's own reference range** — not a
threshold invented in the frontend. The blood-pressure thresholds *are* app
constants (140/90, from the app's own field help, the same pair
`vitals-trend.tsx` flags against) and are commented as such.

**The BP sub-line states its window.** The design prints a bare
`above target × 3`. That count has no denominator, and on `MRN-2026-0000001` the
*latest* reading is in target while three of the previous five were not — so a
bare "× 3" beside "120/89" invites exactly the wrong reading. Ours says
`3 of last 5 above target`. Eight characters longer, unambiguous.

### 3.4 `doctor-overview.tsx`

Two cards, through the shared `NzCard` / `NzRow`:

| Card | Source | Action | Badge |
|---|---|---|---|
| Active problems | `patient.activeConditions` | **none** — see §6 | none — see below |
| Current medications | `usePatientMedications`, active only | `All →` Medications tab | `rx_status` |

The medications badge is mapped through `rxStatusToDisplay`, **exported from
`medications-tab.tsx` and imported here rather than copied**. A second copy of
that mapping is how the tab and the card would come to disagree about whether a
drug is on hold.

**The problem rows carry no badge.** The design ends each with a control state —
`Above target`, `Monitoring`, `Controlled`. No such field exists:
`activeConditions` carries `diagnosis`, `code` and `last_seen` and nothing more.
Calling a diabetic "Controlled" because the record is silent is precisely the
clinical claim PHI-5 forbids.

**The sub-line says "last seen", not "since".** The design writes
`E11.9 · since 2021`. We have `last_seen`, which is when the condition was last
*recorded* — not its onset. "Since" would turn a recent note into an onset date.

### 3.5 Overview order (revised the same day, on request)

The first version put the two cards **above** the AI summary, which inverted the
design: `cards.overview` opens with the wide `ai` card — the whole record in a
paragraph — and only then narrows to problems and medications.

Final order for a practitioner:

```
Clinical summary   (ai, wide)
Clinical notes     (ours — a clinician's words above a model's)
Active problems · Current medications
Vitals trend
```

**Three blocks were removed from this tab**, by request:

| Removed | Still reachable at |
|---|---|
| Last encounter summary | Encounters tab |
| Patient history box | History tab |
| The vitals *table* (`VitalsTab`) | replaced by `VitalsTrend` |

All three removals are gated on `role === "practitioner"`, so no other role's
Overview moved. Nothing is removed from the app — only from this tab.

**Vitals is now literally the nurse's component.** `VitalsTrend`, unchanged, with
`onRecordVitals` passed through (a practitioner has `recordVitals: true` in
`roles.ts`). One table, one set of thresholds, one definition of "abnormal", for
both roles — rather than two views of the same numbers that can drift apart.

### 3.6 `patient-clinical-summary-card.tsx` reshelled onto the design's `ai` card

`C(title, 'ai', …)` is **not a second card implementation** — it is the ordinary
card shell with two substitutions:

```js
bg: type === 'ai' ? 'var(--teal-50)'  : 'var(--surface-card)'
bd: type === 'ai' ? 'var(--teal-200)' : 'var(--border-subtle)'
```

So `NzCard` gained a `tone="ai"` prop rather than a sibling component. Verified
live with `getComputedStyle`:

```
bg      rgb(243,249,248)   --teal-50
border  rgb(207,230,225)   --teal-200
title   14px / 700 / --ink-900
sub     11.5px / 400 / --ink-400
body    13.5px / 500 / lh 21.6px (1.6) / --ink-900
```

**The sub-line does not say "from 12 visits."** Nothing counts the encounters
that fed the summary, so the number would be decoration presented as provenance.
Ours reads `AI · review before relying on it` — the design's own caveat, minus
the count.

**The amber disclaimer bar was removed** (2026-09-29, on request): it is not in
the design. See §6 for where Rule 6's marking now lives — this is the one
paragraph of this document a future reader must not skip.

### 3.7 `/api/labs/trends` — the endpoint that had no frontend

`get_lab_trends(patient, analyte)` has been in `services/labs.py:658` since the
labs module was built and is whitelisted at `api/v1/labs/api.py:1121`. **Nothing
on the frontend ever called it** — no route, no type, no hook — so the one
endpoint that returns a per-analyte series *with* its reference range and a
per-point flag was unreachable from the browser.

Added: `src/app/api/labs/trends/route.ts`, the `LabTrendPoint` /
`LabTrendAnalyte` / `LabTrends` types, and `useLabTrends(patient, analyte)` with
`silent403` and an empty fallback — labs are a clinical read, and a role without
permission must degrade to "no trend" rather than fire a global toast on a chart
it is otherwise allowed to open.

**`points` arrive oldest first** (the backend sorts ascending), so the latest
reading is the *last* element. Getting that backwards would show a patient's
first ever result as their current one.

### 3.8 `chart-band.tsx` — the KPI label now truncates

A departure from the design, and a necessary one. The design's labels are short
fixed strings ("HbA1c", "Balance"); ours can be whatever the lab named the
analyte, and `Nitrógeno ureico (BUN)` is 22 characters in a ~122px track. Left
to wrap, it pushes **every tile in the row** taller, because the band is a grid
with shared rows. The full text stays reachable as the `title` attribute.

### 3.9 Header actions — already correct

| Design | Ours | |
|---|---|---|
| Order labs | Lab Test | ✅ |
| New prescription | — | ❌ see §5 |
| Start / Continue encounter | Start encounter | ✅ |

This app's extra actions (Add immunization, Upload Docs, Book appointment,
Tasks) are kept, not hidden — §13.3.

---

## 4. Backend — nothing new was needed

No backend change was made for the doctor view. Everything the band and the
cards read was already exposed:

| Shown | Endpoint |
|---|---|
| Lab trends, ranges, flags | `labs.get_lab_trends` — **existed, was unreachable** |
| Blood pressure history | `vital_signs` list |
| Pending lab orders | `labs.list_patient_lab_tests` (`docstatus === 0`) |
| Active problems | `get_patient` → `activeConditions` |
| Current medications | `get_patient_medications` |
| Allergies | `get_patient` → `allergies` |
| Clinical summary | ADR-029 stored summary |

This is the second time in this series that a "missing backend" turned out to be
an exposure gap rather than a schema gap — the first was `Patient.creation` and
the insurance coverage split (front-desk doc §4). **Check the service layer
before reporting a gap.**

---

## 5. NOT BUILT, and why

### Care gaps — skipped entirely, by decision

The fourth KPI tile (`Care gaps · 4 · 1 overdue`, `crit`), the
`Eye exam overdue` flag, the Care gaps Overview card, and **the whole Care plan
tab**.

Nothing in the backend models a care gap: there is no care-plan doctype, no
bundle definition, no "due by" anywhere. The `4` in the design is a demo
constant. Inventing it would be a clinical claim the record cannot support
(PHI-5), and deriving it from something like "no HbA1c in 6 months" would be
inventing a screening protocol this clinic has never agreed to.

**The purpose line was shortened to match** — *"The clinical picture: summary,
problems, medications and results."* The band must not advertise something it
does not show.

### `High risk · renal dosing`

No backing field on any doctype. Dropped.

### `New Rx`

This app has no standalone prescribing screen — prescriptions are written inside
an encounter, and `prescriptions/api.py` is an unused Phase 2 stub (CLAUDE.md
§6). A button labelled New Rx that opened nothing is worse than none.

### The problem card's `All →` action

Not a data gap — a *destination* gap. The Conditions tab is switched off in
`patient-screen.tsx`, behind a commented-out entry with a `re-enable` TODO. The
first version shipped an `All →` pointing at `?tab=conditions`, which navigates
nowhere. **Restore the action the day that tab comes back.**

---

## 6. Where Rule 6's marking lives now

The clinical summary card shows an **AI-suggested differential**, so CLAUDE.md
Rule 6 requires it to be marked as AI and as unverified. It used to carry an
amber `AI-generated from the patient's record — not a verified diagnosis` bar;
that bar is not in the design and was removed on request.

**The marking did not go with it.** It now rests entirely on the two things the
design itself uses:

| | |
|---|---|
| the **teal tint** | `tone="ai"` — the design's own signal for a card a model wrote, against the white cards beside it |
| the **sub-line** | `AI · review before relying on it` — the design's own caveat |

**Both are load-bearing.** Dropping either leaves an AI differential presented
exactly like a clinician's note, which is the specific thing Rule 6 exists to
prevent. This is written into the component's header comment as well, so it
survives someone reading the code without this document.

---

## 7. NOT DONE — the doctor view is not finished

### 7.1 The design's tables

```js
tables: { overview: ['enc'], results: ['lab','vit'] }
```

Neither is built. `overview: ['enc']` is the past-encounters strip; `results`
is the Results tab's lab and vitals tables. The nurse's `vitals-trend.tsx`
already implements `tVit` and can be reused for the `vit` half.

### 7.2 Problems & meds tab cards

`C('Active problems')`, `C('Allergies')`, `C('Current medications')`,
`C('Past medications')`, `C('Family history')`. Our `medications` tab exists and
works; the design's five-card layout is not built.

### 7.3 Messages and Documents tab cards

`msgs` has the design's `sub: 'Your replies are signed and saved to the chart'`
— which must be checked against what the app actually does before it is shown
(PHI-5). `docs` is one wide rows card with an Upload action.

### 7.4 Carried over from the other roles

Front desk's Messages / Documents / Timeline tabs and the nurse's History-tab
tables are still outstanding. The **admin role is untouched**.

---

## 8. Data problems found, not fixed

Both are live defects in seeded or recorded data, surfaced by this work and
flagged rather than patched. Neither is a frontend bug.

**`Drug Prescription.drug_name` holds the raw code.** `DRUG-PARACETAMOL` rather
than a display name, on the seeded prescriptions. The Medications tab has been
showing this all along; the Overview card simply made it more visible.

**Implausible vital signs on `MRN-2026-0000001`.** `777/777 mmHg`,
`SpO₂ 0`, `Temperature 44 °C`, and systolic-below-diastolic entries. These are
now on the doctor's main screen because the Vitals trend moved onto Overview.
Related to the known backend issue where vitals store `0` instead of null. The
AI clinical summary independently calls them out — *"vitals contain implausible
entries … suggesting data-entry error"*.

**Formatting fixed in passing:** `strength` is a Frappe float, so every whole
dose arrived as `500.0` and concatenated to `500.0Milligram`. Now `500 Milligram`.
The UOM word is deliberately **not** abbreviated to `mg` — mapping units is a
clinical decision, and getting it wrong on a paediatric dose is not cosmetic.

---

## 9. Bugs found and fixed during this work

**A missing message key is invisible to `tsc`.** `clinicalSummaryAiSub` was used
in the component before it existed in `messages/*.json`. Typecheck, lint and all
630 tests passed; only the browser console said
`IntlError: MISSING_MESSAGE`. **Third time in this series** that a design-sync
defect has been caught only by reading the live page — after the empty
`box-shadow` and the swapped tab labels.

**`?tab=conditions` navigated nowhere.** See §5.

**`skin rash` printed twice.** `activeConditions` is populated from free-text
complaints as well as coded ones, so `code === diagnosis` and the row printed
the words in both the title and the sub-line. Same class of defect as the
invoice number appearing twice in the front-desk billing card.

---

## 10. Files touched

**New**

```
src/components/narzim/patient-chart/doctor-band.tsx      the doctor's chips + KPIs
src/components/narzim/patient-chart/doctor-overview.tsx  Active problems, Current medications
src/app/api/labs/trends/route.ts                         BFF proxy to get_lab_trends
```

**Changed**

```
src/components/narzim/patient-chart/chart-band.tsx                 KPI label truncates
src/components/narzim/patient-chart/nz-card.tsx                    tone="ai"
src/components/narzim/patient-chart/patient-clinical-summary-card.tsx  reshelled onto NzCard
src/components/narzim/patient-chart/patient-screen.tsx             TAB_ORDER_BY_ROLE.practitioner
src/components/narzim/patient-chart/overview-tab.tsx               doctor branch, three blocks removed
src/components/narzim/patient-chart/medications-tab.tsx            rxStatusToDisplay exported
src/types/labs.ts                                                  LabTrend* types
src/hooks/use-labs.ts                                              useLabTrends
src/app/(clinic)/patients/[id]/patient-chart-client.tsx            DoctorBand
messages/en.json · messages/es.json                                chart.doctor, clinicalSummaryAiSub
```

No backend change was required for the doctor view.

**Verification:** `tsc` clean · 630 tests / 36 files passing · no new lint errors
· en/es key parity · browser console clean after reload. The band, Overview
order, cards, tab strip and the `ai` card shell were each confirmed in the
browser against a live `EB_Practitioner` session, with every measurement read
from `getComputedStyle` rather than judged by eye — the discipline that caught
the empty `box-shadow` in the front-desk pass and the missing message key in
this one.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-29 | Ashutosh (AI-assisted) | Initial record of the doctor Patient 360 redesign: the band, the patient's-own-analyte decision, the Overview order and its three removals, the `ai` card shell, the lab-trends endpoint that had no frontend, why care gaps are skipped, and where Rule 6's marking lives after the amber bar was removed |
