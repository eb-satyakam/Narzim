# Demo Data Generator

**Doc status:** living · **Created:** 2026-07-18 by Anant Sharma · **Updated:** 2026-07-18 by Sarvesh-SocialAngel · **Version:** 1.0

Full rewrite of EB Clinic Settings' "Generate Test Data" button — from a
small per-click incremental generator into a one-shot, tracked, reversible
demo dataset generator. Administrator only.

## What it does

One click of **Generate Test Data** on `EB Clinic Settings → Chavitos
Pediátrica`:

1. **Bootstraps infrastructure** (idempotent, never deleted):
   - Creates the **Chavitos Pediátrica** company (Mexican chart of accounts)
     if missing, via `scripts/seed/create_mx_company.py` +
     `scripts/seed/setup_mx_clinic_accounts.py`. Sets it as the site's
     Global Default company.
   - Fills in the company's legal/contact/address profile (RFC/tax ID,
     phone, email, website, establishment date, address in Mérida,
     Yucatán) if still blank.
   - Ensures the Diagnosis catalog (32 ICD-10 entries) and the 7 Appointment
     Types exist.

2. **Users**:
   - Super admin `admin@narzim.com` (role `EB_Healthcare Admin`)
   - `nurse@narzim.com` (`EB_Nurse`), `frontdesk@narzim.com` (`EB_Front Desk`)
   - 10 Healthcare Practitioners with real logins (unlike the old generator,
     which deliberately created practitioners with no login), each with
     gender, a 500 MXN OPD consulting charge, and assigned to a shared
     **Morning Shift** schedule (Mon–Sat, 08:00–14:00, 30-minute slots).
   - **All passwords: `Admin@123`.**

3. **Catalog**: 50 Medications, 15+ Medication Classes, 10 Brands, 10
   Manufacturers, 10 Lab Test Templates, the Mexico CENSIA vaccine catalog
   (11 vaccines), and an expanded Item Group / Item set (12 each).

4. **Clinical ops**: 6 Treatment Plan Templates, 18 Clinical Procedure
   Templates, 10 Therapy Types, 10 Nursing Activities (Healthcare Activity),
   and one Immunization Program ("Cartilla Nacional de Vacunación") bundling
   7 of the core vaccine doses.

5. **40 Patients** across the real visit pipeline — built from the existing
   whitelisted API layer (`patients`, `appointments`, `vital_signs`,
   `encounters`, `services.billing`), exactly as the frontend would drive it:

   | Stage | Count | State |
   |---|---|---|
   | Open | 5 | Appointment left at its default status |
   | Waiting room | 5 | Appointment status `Confirmed` |
   | Nursing room | 10 | Checked in + Draft Vital Signs |
   | Practitioner room | 10 | + Draft Patient Encounter (docstatus 0) |
   | Checked out | 10 | + submitted encounter + diagnosis + billing |

   The 10 checked-out patients split **3 pay-later / 3 invoiced-unpaid / 4
   invoiced-and-paid**, so billing/AR-aging screens have all three states to
   show. Appointments always use *today's* date.

## Undo — "Delete Generated Data"

Every record created above (except the infra in step 1) is tracked — as it's
created, immediately, per record — into `EB Clinic Settings.demo_data_log`
(a JSON array of `[doctype, name]` pairs) for the Chavitos Pediátrica
company, and `demo_data_status` flips to `"Generated"`. The Actions button
then becomes **Delete Generated Data**, which:

- Deletes every tracked record in **reverse creation order**.
- **Cancels submitted documents first** (Sales Invoice, Payment Entry,
  Patient Encounter) — Frappe blocks deleting a submitted doc outright.
- Is **resilient to partial failure**: anything that fails to delete stays
  in the log (not silently dropped), so clicking the button again retries
  only what's left. `demo_data_status` only clears once the log is empty.
- Never touches shared infrastructure — the company, its chart of accounts,
  Medical Departments, UOMs, Dosage Forms, the Diagnosis catalog, or your
  own manually-created records.

## Idempotency / resumability

`generate_test_data` can be called again after a partial failure (or to
resume) without erroring on duplicates — every phase checks for an existing
record first and reuses it (re-applying gender/charge/password if it was a
stale reuse) rather than failing. The tracker also reloads whatever was
already logged, so progress isn't lost across retries.

## Known gotchas (things that bit us building this)

- **Healthcare core auto-creates an Item on `after_insert`** for both
  `Therapy Type` and `Clinical Procedure Template`, *regardless of
  `is_billable`*. Both must be tracked (the Item too), or a later delete +
  regenerate collides on the orphaned Item's primary key.
- **`Medication`'s `format:` autoname doesn't render `{strength}`** in this
  install (verified empirically) — the real uniqueness key is
  `(dosage_form, generic_name, strength_uom)`, not the full 4-field spec.
  `create_medications` dedupes on the 3-field key and skips ~8 colliding
  entries in the curated 100-item list.
- **Appointments are stamped with the date they're created on** — demo data
  generated on a previous day won't show up in "today's" Live Queue
  dashboard. Regenerate to refresh the date.
- Individual record creates in this app appear to commit independently of
  the caller's outer transaction — a plain `frappe.db.rollback()` (used by
  `handle_api_errors` on any exception) does **not** reliably undo earlier
  successful steps. Tracking + committing per-record (not per-phase) is what
  makes the undo log accurate even when a later step fails.

## Files

- `remedisys_healthcare_ai/api/v1/admin/demo_data.py` — orchestrator:
  `generate_test_data`, `delete_generated_data`, infra bootstrap, company
  profile fill, incremental progress saving.
- `demo_data_helpers.py` — `Tracker`, `call_or_raise`, `cancel_and_delete`.
- `demo_data_users.py` — front-office + practitioner users, schedule.
- `demo_data_catalog.py` — medications/classes/brands/manufacturers/lab
  templates/vaccines/items.
- `demo_data_clinical.py` — treatment plans/procedures/therapy types/nursing
  activities/immunization program.
- `demo_data_patients.py` — the 40-patient visit pipeline.
- `scripts/seed/seed_demo_patients.py` — curated list of 40 patient
  demographics.
- `remedisys_healthcare_ai/remedisys_healthcare_ai/doctype/eb_clinic_settings/`
  — `eb_clinic_settings.json` (adds `demo_data_status` + `demo_data_log`
  fields), `eb_clinic_settings.js` (button toggle).

## Demo credentials

| User | Password | Role |
|---|---|---|
| `admin@narzim.com` | `Admin@123` | EB_Healthcare Admin |
| `nurse@narzim.com` | `Admin@123` | EB_Nurse |
| `frontdesk@narzim.com` | `Admin@123` | EB_Front Desk |
| `luis@narzim.com`, `moises@narzim.com`, ... (10 practitioners) | `Admin@123` | EB_Practitioner |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-18 | Sarvesh | Initial version (header backfilled from git history) |
