# OPD Backend Flow — Appointment → Vitals → Encounter → Sales Invoice → Payment

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

> **What this is.** A doctype/field-level trace of how our system ("Marley" / Remedisys) actually runs the OPD visit **in the backend**, end to end, and where the chain is **weak or missing**. Companion to `FRONTDESK_CHARTER_AND_GAPS.md` (which covers the frontend). This one is about the *data model and server logic*, not the UI.
>
> Grounded in a code read on **2026-07-09** of `remedisys_healthcare_ai/api/v1/*` + `services/billing.py` and the ERPNext **Healthcare core** (`apps/healthcare`). Line references are to those files.
>
> **Design principle confirmed:** our app never forks core. It *composes* core ERPNext Healthcare doctypes (Patient Appointment, Patient Encounter, Vital Signs, Sales Invoice, Payment Entry) and patches around core side-effects it cannot edit. This is Rule 1 (upgrade-safe) holding up in practice.

---

## 1. The doctypes in play

| Step | Doctype | Owner | Submittable? |
|---|---|---|---|
| Book | **Patient Appointment** | Healthcare core | no (status-driven) |
| Vitals | **Vital Signs** | Healthcare core | yes (0→1) |
| Encounter | **Patient Encounter** | Healthcare core | yes (0→1) |
| Bill | **Sales Invoice** (+ Sales Invoice Item) | ERPNext core | yes (0→1) |
| Pay | **Payment Entry** | ERPNext core | yes (0→1) |
| Insure | **Patient Insurance Policy / Coverage**, **Insurance Payor** | Healthcare core | — |
| Refund | **Sales Invoice** (`is_return=1`) | ERPNext core | yes |

The single join that ties the money side to the clinical side is **`Patient.customer`** (Link → Customer). Everything financial hangs off the patient's Customer record.

---

## 2. The end-to-end chain (as it actually runs)

```
 ┌──────────────────────────────────────────────────────────────────────────────┐
 │ CLINICAL CHAIN                                                                 │
 │                                                                                │
 │  book_appointment_for_patient                                                  │
 │        │  creates                                                              │
 │        ▼                                                                       │
 │  Patient Appointment  ──status──►  Open / Scheduled  (set by CORE, not us)     │
 │        │  check_in_patient → status="Checked In" + custom_checked_in_at        │
 │        │                                                                       │
 │        │  (nurse) create_vital_signs                                           │
 │        │        ▼                                                              │
 │        │   Vital Signs  ── .appointment ──► [PA]   ── .patient ──► [Pt]        │
 │        │        (encounter link filled LATER, by date-match heuristic)         │
 │        │                                                                       │
 │        ▼  start_encounter(appointment)                                         │
 │  Patient Encounter  ── .appointment ──► [PA]  (draft, docstatus=0)             │
 │        │   carries patient, practitioner, medical_department(=PA.department)   │
 │        │   _link_vitals_to_encounter  ← backfills Vital Signs.encounter        │
 │        │   complete_encounter → status="Completed", doc.submit() → docstatus=1 │
 │        │        (also auto-submits draft Vital Signs for this encounter)       │
 └────────┼───────────────────────────────────────────────────────────────────────┘
          │  becomes billable once submitted / appointment invoiced=0
 ┌────────▼───────────────────────────────────────────────────────────────────────┐
 │ MONEY CHAIN                                                                    │
 │                                                                                │
 │  get_patient_billables  ── scans invoiced=0 sources ──►                        │
 │     Appointment consult fee · submitted Encounter · Lab Test · Procedure ·     │
 │     Immunization (checked against real Sales Invoice Item rows)                │
 │        │  create_pos_invoice / create_appointment_invoice / create_vaccination │
 │        ▼                                                                       │
 │  Sales Invoice  .customer=Patient.customer  .items[].reference_dt/dn ◄─back─┐  │
 │        │   CORE on_submit → set_invoiced() writes source.invoiced=1 ─────────┘  │
 │        │   (+ insurance Journal Entry: payor receivable ↔ patient debit_to)    │
 │        ▼  collect_payment                                                      │
 │  Payment Entry  party=Customer  references→SI  allocated_amount                │
 │        │   outstanding_amount ↓   status: Unpaid → Partly Paid → Paid          │
 │        ▼                                                                       │
 │  REFUND: make_return_doc → Credit Note (full-invoice only, strips ref_dt/dn)   │
 └────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Step by step (what the backend does, precisely)

### 3.1 Book — `Patient Appointment`
- `book_appointment_for_patient` wraps optional patient-creation + appointment + invoice in **one savepoint (`booking_txn`)** — all-or-nothing (appointments/api.py L1304).
- Required: `patient`, `appointment_date`, `appointment_time`, `appointment_type`. `company` auto-derived from `service_unit` if omitted (core requires it).
- **Initial status is set by core, not us:** today → **`Open`**, future → **`Scheduled`**, past → **`No Show`** (core `set_status`).
- A **pre-insert conflict guard** (`_practitioner_conflict`) blocks cross-service-unit double-booking and capacity overflow → HTTP 409.
- Our custom fields on the appointment: `custom_checked_in_at`, `custom_patient_confirmed`, `custom_patient_email` (all read-only).

### 3.2 Check-in
- `check_in_patient` only from `Open`/`Scheduled`/`Confirmed`; writes `{status:"Checked In", custom_checked_in_at: now}` via **`frappe.db.set_value`** (a direct DB write, not `doc.save()`).
- Status vocabulary is translated FE↔ERP: FE "Completed" ↔ ERP "Closed"; FE "Ready for Provider"/"Checked-in" both → ERP "Checked In".
- Role gate `_ROLE_ALLOWED_STATUSES`: `EB_Front Desk` may set Scheduled/Open/Confirmed/Checked In/Checked Out/Cancelled/No Show; admins bypass.

### 3.3 Vitals — `Vital Signs`
- `create_vital_signs` makes a **draft** Vital Signs. **Only `patient` is required**; `encounter` and `appointment` are both optional.
- Intended intake flow: nurse records vitals **before** the encounter exists, linking by `appointment` only.
- BMI = `weight / height²` (height in **metres**); BP = `"{sys}/{dia} mmHg"`. Recomputed on every update.
- Idempotent per appointment (returns existing draft rather than duplicating).

### 3.4 Encounter — `Patient Encounter`
- `start_encounter(appointment)` creates a **draft** encounter linked via `Patient Encounter.appointment`; carries `patient`, `practitioner` (from the **appointment**, per ADR-018 — not the caller), `medical_department` (= appointment's `department`), `company`.
- Idempotent: one non-cancelled encounter per appointment (enforced by query, **not a DB unique constraint**).
- `_link_vitals_to_encounter` backfills `Vital Signs.encounter` by matching **patient + same day**.
- `complete_encounter`: requires a chief complaint + caller is the assigned practitioner/admin → sets `status="Completed"`, stamps `custom_encounter_end`, **submits** (docstatus 0→1), and auto-submits any draft Vital Signs for that encounter.
- **Core side-effect we fight:** core `PatientEncounter.on_update` closes the appointment (`status="Closed"`) on **every** save — even a draft. We can't edit core, so `_restore_appointment_status_if_draft` re-restores the prior status after each draft write. All four write sites call it.

### 3.5 What becomes billable — `get_patient_billables`
Delegates to core `get_healthcare_services_to_invoice`, then appends immunizations. A source is billable when:

| Source | "un-billed" test | rate from |
|---|---|---|
| Appointment consult | `invoiced=0`, not Cancelled | `paid_amount` **or** `practitioner_charge` |
| Encounter | `invoiced=0`, submitted, **only if no appointment** | practitioner charge |
| Lab Test | `invoiced=0`, submitted, no service_request | Lab Test Template item (if `is_billable`) |
| Clinical Procedure | `invoiced=0` (+ separate `consumption_invoiced`) | template item |
| Immunization | **no submitted `Sales Invoice Item` referencing it** | `Item Price` (selling) for the vaccine Item |

Consultation fee is skipped if a **Fee Validity** (free follow-up) exists. Consultation charge precedence: a pre-entered `paid_amount` **overrides** the practitioner's configured rate.

### 3.6 Invoice — three paths
- **A. Appointment invoice** (`create_appointment_invoice`) → core `create_sales_invoice`. Persists `mode_of_payment`+`paid_amount` onto the appointment first; if both present, sets `is_pos=1` and appends a POS `payments` row. Insurance branch builds the SI via `set_healthcare_services`.
- **B. Vaccination invoice** — one line per shot (`item_code=vaccine`, `reference_dt="Immunization"`). No discount support.
- **C. POS consolidated checkout** (`create_pos_invoice`) — **server re-runs `get_patient_billables` and matches by `(reference_type, reference_name)`**; any line not currently billable is rejected. Rates/accounts always from the server cart, never the client (anti-tamper). Invoice-level discount on grand total.
- Patient→Customer via `Patient.customer`; `_ensure_patient_customer` repairs a missing/dangling link lazily.

### 3.7 Write-back & double-bill guard
- Back-reference lives on **`Sales Invoice Item.reference_dt/reference_dn`**.
- The wrapper does **not** flip source flags. Core `Sales Invoice.on_submit → manage_invoice_submit_cancel → set_invoiced()` writes `source.invoiced=1` and, for appointments, `ref_sales_invoice` + cascades to derived Encounter/Procedure.
- `validate_invoiced_on_submit` **throws "already invoiced"** — the real DB-level double-bill guard. Concurrent checkouts fail *safely* (second submit throws) rather than double-billing.

### 3.8 Payment — `Payment Entry`
- `collect_payment`/`settle_invoice` use core `get_payment_entry("Sales Invoice", invoice)`, then set `mode_of_payment`, `paid_amount`, `received_amount`, `references[].allocated_amount`.
- **Partial payment** allowed (`amount ≤ outstanding`); leaves positive `outstanding_amount`.
- Status transition (`Unpaid → Partly Paid → Paid`) is driven by **core** off `outstanding_amount` — the wrapper never sets it manually.
- POS-embedded payments settle at invoice submit (no separate Payment Entry).

### 3.9 Insurance split — **real, core-driven**
- Coverage created at booking (`Patient Appointment.after_insert → make_insurance_coverage` → **Patient Insurance Coverage**).
- Read into the invoice only when coverage is Approved/Partly-Invoiced, not expired, company matches.
- Per-line `insurance_coverage_amount = amount × coverage% / 100`; header `patient_payable_amount = outstanding − total_insurance_coverage`.
- At SI submit, a **Journal Entry** moves the covered portion from the patient's `debit_to` to the **Insurance Payor's receivable** (payor's own Customer party).

### 3.10 Refund — `Credit Note`
- **Full-invoice only** via `make_return_doc` (`is_return=1`, `return_against`, negative lines). No partial/line refund.
- Only on **fully-paid** invoices (`outstanding==0`); blocked on unpaid/partly-paid.
- Strips `reference_dt/dn` on return lines so core doesn't throw — **consequence: the original source stays `invoiced=1`, so a refunded service is NOT reopened for re-billing.**
- Cash out: POS → negated payment refunds itself; non-POS → a "Pay" Payment Entry with negative allocation. Wrapped in a savepoint with rollback.

---

## 4. Gap map — weak & missing links in the backend chain

Severity = clinical/financial correctness risk × frequency.

| # | Gap | Where | Severity | Detail |
|---|---|---|---|---|
| **B1** | **Vitals→Encounter link is a same-day heuristic, not guaranteed** | encounters `_link_vitals_to_encounter` | **High** | Vitals are created before the encounter and linked later by matching **patient + same date**. For a **walk-in encounter with no appointment**, the appointment-scoping guard is skipped, so a patient with **two same-day visits** can have vitals cross-linked to the **wrong encounter**. Clinical-data-integrity risk. |
| **B2** | **No cash-drawer / POS shift persistence** | billing (no POS Profile/Opening/Closing Entry) | **High** | Invoices set `is_pos=1` but there is no POS Opening/Closing Entry, no drawer balance, no per-cashier till. Reconciliation is only "query Payment Entry by mode+date". No shift open/close/handover/variance. (Matches frontend G1 — the FE fakes this in localStorage.) |
| **B3** | **No void / cancel of a submitted Sales Invoice or Payment Entry** | billing/api.py | **Medium-High** | A mistaken bill can only be corrected by a **full Credit Note**, which itself requires the invoice to be **fully paid first**. No graceful correction of an unpaid mistake. |
| **B4** | **Refund is full-invoice only; doesn't reopen the source** | `create_credit_note` | Medium | No partial/line refund. After a refund the appointment/lab stays `invoiced=1`, so the service can't be re-billed without manually clearing the flag. |
| **B5** | **Encounter can exist with no appointment ("floating")** | `create_encounter(appointment=None)` | Medium | Loses the appointment back-link and weakens vitals-linking (feeds B1). Also changes which billable path applies (encounter billed directly only when it has no appointment). |
| **B6** | **Vitals can attach to nothing but a patient** | `create_vital_signs` | Medium | `encounter` and `appointment` both optional — a bare-patient vitals row only ever joins a visit via the B1 heuristic. |
| **B7** | **Status writes bypass validation + audit log** | check_in/update_status/cancel/reassign | Medium | These use `frappe.db.set_value`, skipping core validation and the change-log. Deliberate (e.g. `practitioner` is `set_only_once`), but the only trace of a check-in/reassign is the custom timestamp — thin for a clinical audit trail. |
| **B8** | **`company` resolution is inconsistent across invoice paths** | billing | Medium | Appointment path uses `Patient Appointment.company`; vaccination/POS paths use the **user/global default company**. In a multi-clinic setup, vaccine/POS revenue can post against the wrong company vs. the clinical event. |
| **B9** | **Immunization `invoiced` write-back is fragile** | core `set_invoiced` | Low-Med | Core tries to write `Immunization.invoiced` on submit; that field may not exist in this deploy (Immunization is custom here). Billing is still *safe* (the guard is the Sales-Invoice-Item existence check), but the write-back can error. |
| **B10** | **Insurance JE granularity + no coverage cancel** (core TODO) | core `post_transfer_journal_entry…` | Low-Med | One Journal Entry per covered line (not per payor); coverage can't be cancelled once invoiced; posting needs `Insurance Payor.receivable_account`+party configured or it throws at submit. |
| **B11** | **POS checkout read-then-submit not transactionally locked** | `create_pos_invoice` | Low | Concurrent checkouts of the same patient fail *safely* (second submit throws `already invoiced`) but with an ugly error rather than a graceful 409. |

**Headline:** the **money spine is sound** — patient→customer join, server-side anti-tamper cart, core-enforced double-bill guard, real insurance split via Journal Entry, partial payments, atomic booking. The genuinely worrying items are **B1 (vitals mis-linking → clinical safety)** and **B2 (no real cash/shift accounting → financial control)**. The rest are correctness/robustness edges.

---

## 5. What needs an ADR before fixing

- **B2 Cash-drawer / shift** — adopt ERPNext **POS Profile + POS Opening/Closing Entry**, or new custom shift doctypes. New persistent entities → ADR (already flagged in CLAUDE.md §12 and frontend gap G1). Decide POS-Entry-vs-custom before building.
- **B3 Void policy** — decide void-vs-credit-note and who may void. Decision note.
- **B1 Vitals linking** — arguably a fix, not an ADR, but the rule ("vitals must bind to an encounter/appointment, never bare patient + date") is worth recording.

## 6. Suggested fix order (for discussion — not committed)

1. **B1 vitals mis-link** — tighten `_link_vitals_to_encounter` to require appointment scoping (or refuse cross-linking when >1 same-day encounter). Clinical safety first; small code change.
2. **B2 cash/shift** — ADR → POS Opening/Closing Entry + `api/v1/cash` → replace FE localStorage. Biggest financial-control win.
3. **B3/B4 void + partial refund** — add invoice void + line/partial credit note.
4. **B7 audit** / **B8 company** / **B5–B6 link hardening** — robustness pass.

---

*Companion doc: `FRONTDESK_CHARTER_AND_GAPS.md` (frontend role charter + FE gap register G1–G11). Backend gaps here are prefixed **B**; where they map to a frontend gap it's noted inline.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
