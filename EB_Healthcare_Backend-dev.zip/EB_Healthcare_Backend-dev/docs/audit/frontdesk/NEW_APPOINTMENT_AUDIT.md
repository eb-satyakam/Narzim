# New Appointment — flow audit

**Doc status:** record · **Created:** 2026-09-03 by Invincible · **Updated:** 2026-09-03 by Invincible · **Version:** 1.0

> One document for the whole booking flow. Each finding is told **once**, at two
> levels: a **user story with a worked example** (readable by anyone), then the
> **code evidence** (`file:line`) underneath it. No separate "technical" and
> "plain-language" versions to keep in sync.
>
> **Companion, not replacement:** [`screens/07-appointment-booking.md`](../../_archive/audit-screens/frontdesk/07-appointment-booking.md)
> stays the canonical screen inventory and decision sheet (rows BK1–BK4). This is
> the deep pass behind it — submitters, component reuse, accessibility, dead code,
> configuration. §4 lists the four claims in `07` that this pass found stale.

**Status:** Audit only — nothing built, no code changed.
**Verified against:** frontend `dev` @ `9f82b1b`, backend `dev` @ `6744129`, live
site `remedisys.localhost` (Frappe 16.31.0, currency MXN). Every line number and
every figure below was read at that commit / on that site.
**Owner:** Backend.
**Created:** 2026-08-18 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com` (merged the same day from two earlier drafts: a technical audit and a user-story doc)
**Last updated:** 2026-08-18 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
<sub>Editing this file? Update **Last updated** with your name and date.</sub>

---

## How to read this

**The people.** Mapped to the real dev accounts, so any scenario is reproducible.

| Persona | Role | Dev account | Cares about |
|---|---|---|---|
| **Gaurav**, front desk | `EB_Front Desk` | `frontdesk@narzim.com` | Speed — a parent is at the counter or on the phone, with a queue behind them |
| **Roma**, nurse | `EB_Nurse` | `nurse@narzim.com` | The visit exists, is checked in, carries the right reason |
| **Dr. Demo**, physician | `EB_Practitioner` | `doctor@narzim.com` | Right patient, right slot, complete history |
| **Lucía**, clinic manager | `EB_Healthcare Admin` | `admin@narzim.com` | Money collected correctly, claims payable, reports that reconcile |

**Each finding has:** the user story · a concrete scenario · what happens today
(with evidence) · what should happen · Given/When/Then acceptance criteria.

**Priorities.** `P0` money or safety is wrong today · `P1` staff or patients hurt
by inconsistency · `P2` quality and speed.

**Patients in examples are fictional.** No real patient data appears here
(Rule 10).

---

## 1. The flow as it exists

`src/components/narzim/dashboard/new-appointment-dialog.tsx` — **2,538 lines**,
one file, four steps (`STEPS` at `:115`):

| Step | i18n key | Fields |
|---|---|---|
| 1 Patient | `newAppt.stepPatient` | patient search **or** inline new patient (names, gender, DOB, phone+country, email, guardians, photo); appointment type (8 buttons); reason for visit |
| 2 Schedule | `newAppt.stepSchedule` | date (calendar popover), department, practitioner, service unit, slot grid (single + multi-practitioner) |
| 3 Payment | `newAppt.stepPayment` | timing (pay now / pay later / ~~insurance~~), fee override, discount (amount or %), mode of payment, insurance panel *(unreachable — F1)* |
| 4 Confirm | `newAppt.stepConfirm` | summary rows + change-diff (`ChangeDiff`, `:2517`) |

It is not only a booking form. It also contains inline **patient registration**,
**guardian create/update/remove**, **photo upload**, and a **fee/discount
calculator** — four responsibilities in one component, which is why it is 2.5k
lines.

**Three screens render it**, and each maps the result to the API itself:

| Renderer | Line |
|---|---|
| `app/(clinic)/patients/[id]/patient-chart-client.tsx` | `:851` |
| `components/narzim/dashboard/reschedule-dialog.tsx` | `:91` |
| `components/app-shell/command-palette.tsx` | `:209` |

### What already works — keep it

**As** Gaurav, **I want** to book a returning patient and take payment at the
desk, **so that** the visit and its invoice exist before the family sits down.

Sra. Martínez phones about her daughter Sofía. Gaurav opens **+ New
Appointment**, types "Sofía", picks her, chooses **General Consultation**
(20 min), writes "Tos desde el lunes, sin fiebre", picks tomorrow 11:00 with
Dra. Roma Garcia, chooses **Pay now → Cash**, confirms.

This works, and it is **atomic**: one backend call creates appointment + Sales
Invoice + Payment Entry, or none of them. Slots are real availability, not
free-text. A new patient is created in the same transaction and rolled back if
booking fails. The four-step shape and the atomic call are the strongest parts of
this flow — everything below is about the edges.

---

## 2. Findings

### F1 · Insurance: the clinic bills the family for the insurer's share `P0`

**As** Lucía, **I want** an insured visit to bill the insurer for its share and
leave only the copay on the family, **so that** we get paid by the insurer and
don't chase parents for money they don't owe.

**Scenario — the money.** Dra. Roma Garcia's fee is **1,000 MXN** (real value on
this site). Sofía's policy covers 80%:

| | Should be | Today |
|---|---|---|
| Insurer (claim) | 800 MXN | **0 — no claim exists** |
| Family pays | 200 MXN copay | **1,000 MXN** |

**What happens today — two failures stacked.**

1. **Gaurav cannot choose insurance at all.** The option is commented out:
   ```ts
   // new-appointment-dialog.tsx:2127
   // { key: "insurance", title: t("insurance"), hint: t("insuranceHint"), icon: "🏥" },
   ```
   He sees only *Pay now* and *Pay later*. Everything behind that option is live,
   translated, maintained — and unreachable:

   | Dead branch | Line |
   |---|---|
   | `isInsuranceTiming` | `:597` |
   | insurance panel (provider / policy no. / copay / coverage breakdown) | `:2164-2200` |
   | copay-vs-total switch in the price block | `:2206-2212` |
   | insurance rows in the Confirm summary | `:2387-2389` |

2. **If it were switched on tomorrow, the data would still be discarded.** Both
   submitters collapse the entire capture to one field:
   ```ts
   payload.payViaInsurance ? { payment_timing: "insurance" as const } : …
   // command-palette.tsx:131 · patient-chart-client.tsx:447
   ```
   Dropped: `insuranceProvider`, `policyNumber`, `copay`, and
   `insuranceCoverage` — which the UI **displays to staff** as "Coverage by
   provider: $800". The payload type even declares `insurance_policy?: string`
   (`lib/api/appointments.ts:107`); nothing ever sets it.

**Why it is a revenue bug.** `book_appointment_for_patient` is explicit that the
split happens only when the policy is passed:

> `"insurance"` — book and create the Sales Invoice. When the appointment carries
> insurance coverage (**pass `insurance_policy` so core builds the coverage at
> booking**), the invoice is coverage-split and the patient portion (copay) is
> left OUTSTANDING for collection at checkout.

No `insurance_policy` → no coverage row → the **full 1,000 MXN is billed to the
family**, while Gaurav has just told the parent the insurer covers 800.

**Third problem — the insurer list ignores both sources of truth.** The panel
hardcodes nine insurers (`:2176`): IMSS · ISSSTE · AXA Seguros · GNP Seguros ·
MAPFRE · Seguros Monterrey · Metlife · Zurich · Other. Meanwhile:

| Hook | Real source | Used by |
|---|---|---|
| `useInsurancePayors` | `Insurance Payor` master | `settings/insurance/insurance-form.tsx` |
| `usePatientInsurance` | the patient's own policies | `insurance-tab`, `command-panel`, `overview-frontdesk`, `patient-chart-client` |

Neither is used in booking, so staff **retype a policy number the system already
holds**. For an insured visit the correct interaction is *select the existing
policy*, with "add new" as the exception. (See F3b — the real payor list has one
row, which gates this fix.)

**What should happen.** Gaurav picks **Insurance**, selects Sofía's existing
policy, confirms the copay, books. Invoice is coverage-split: 800 to the insurer,
200 outstanding from the family, collected at checkout.

```gherkin
Given Sofía has an active insurance policy on file
  And Dra. Roma Garcia's consultation fee is 1,000 MXN
When Gaurav books an appointment and chooses "Insurance"
Then he can select Sofía's existing policy without retyping the number
  And the created Sales Invoice carries a coverage row for the insurer
  And only the copay is left outstanding
  And the coverage amount shown on screen equals the amount saved on the invoice
```

---

### F2 · Lucía's booking numbers are wrong — two submitters, one tracker `P0`

**As** Lucía, **I want** to trust the booking report, **so that** I can staff the
clinic and judge whether a change helped.

**Scenario.** Lucía reads that the clinic booked 40 appointments last week, 15%
new patients. The real numbers are higher and the new-patient share differs — she
cannot see it.

**What happens today.** The dialog does not submit; it emits a `NewApptPayload`
(`:56-80`) and each host maps it. Two hosts hold a **verbatim copy** of the same
~45-line mapper, comments included:

- `command-palette.tsx:112-156`
- `patient-chart-client.tsx:440-472`

| | command-palette | patient-chart |
|---|---|---|
| company | `company` | `activeCompany` |
| existing patient | `payload.existingId!` | `payload.existingId ?? patient?.name!` |
| `track("appointment.booked")` | ✅ `:158` | ❌ **absent** |
| after success | toast / paid-state handling | success flag + `router.push` |

Every booking started **from a patient chart is invisible** to the funnel. The
tracking call even carries this comment:

```ts
// Booking funnel. Instrumented at the real call site: this is the only
// booking path in the app — it calls appointmentsApi.book() directly rather
// than through a hook.
```

That is false — `patient-chart-client.tsx:458` calls `book()` too — and it
actively steers the next engineer away from the bug. Any conclusion drawn from
`appointment.booked` (conversion, days-ahead, new-vs-returning, `duration_ms`) is
biased.

**What should happen.** One `useBookAppointment()` mutation owning the mapper
*and* the `track()` call; all three hosts consume it. Analytics cannot drift from
call sites it does not live in.

```gherkin
Given Gaurav books an appointment from the patient chart
When the booking succeeds
Then an "appointment.booked" event is recorded
  And its fields match a booking made from the global + New Appointment button
```

---

### F3 · Two configuration traps that will make the fixes look broken `P1`

Not code bugs — data gaps that gate the P0 work.

**F3a — four of five practitioners have no fee.** The wizard prefills from
`Healthcare Practitioner.op_consulting_charge`. Live values:

| Practitioner | Fee |
|---|---|
| Roma Garcia | 1,000 MXN |
| Demo Doctor | **0** |
| José Remedios Cortés Cárdenas | **0** |
| Maggie Raudez | **0** |
| Ileana Puga Heredia | **0** |

So **Pay now** against four of five practitioners silently creates a **0 MXN
invoice** unless Gaurav notices and types the fee himself, every time.

```gherkin
Given a practitioner has no consultation fee configured
When Gaurav chooses "Pay now"
Then the flow warns him that no fee is set
  And it does not silently create a 0 MXN invoice
```

**F3b — the real insurer list has one row, and it is not an insurer.** The
`Insurance Payor` master on this site contains exactly one entry: **"Apoolo"**.
The UI's nine hardcoded Mexican insurers exist nowhere in the database. So
"wire the real payor list" (F1) will show Gaurav a single option called *Apoolo*
— correct behaviour that reads as a regression. **Payors must be seeded as part
of the insurance fix, not after it.**

```gherkin
Given the clinic accepts IMSS and three private insurers
When Gaurav opens the insurer list during booking
Then he sees exactly the payors configured for this clinic
  And each one can be used to create a claimable coverage split
```

---

### F4 · Rescheduling looks different depending on where you click `P1`

**As** Gaurav, **I want** rescheduling to work the same way everywhere, **so
that** I don't relearn the screen mid-call.

**Scenario.** A parent asks to move Thursday's visit. From Sofía's chart
**overview** Gaurav clicks Reschedule and gets one dialog. Ten minutes later,
from the **Appointments tab of the same chart**, he gets a different one —
different layout, different slot grid.

| File | Size | Slot source | Used by |
|---|---|---|---|
| `narzim/appointments/reschedule-dialog.tsx` | 12 KB | own `useAvailableSlots` | `appointments-client`, **`patient-chart/overview-frontdesk`** |
| `narzim/dashboard/reschedule-dialog.tsx` | 4.7 KB | wraps `NewAppointmentDialog` | **`patient-chart/appointments-tab`** |

**What should happen.** One reschedule experience everywhere. Keep the wrapper —
it inherits the real slot grid — and repoint the other two consumers.

```gherkin
Given an appointment shown in the chart overview and in the chart appointments tab
When Gaurav clicks Reschedule from either place
Then the same dialog opens with the same slot grid and the same fields
```

---

### F5 · The flow cannot be used without sight, and is slow by keyboard `P1`

**As** a front-desk employee who uses a screen reader, **I want** to book an
appointment, **so that** I can do my job.

```
aria-* or role= attributes in new-appointment-dialog.tsx (2,538 lines):  0
```

| Control | Missing | Consequence |
|---|---|---|
| Patient search | `role="combobox"`, `aria-expanded`, `aria-activedescendant` | results never announced; no keyboard contract |
| Appointment type (8 buttons) | `role="radiogroup"`/`radio`, `aria-checked` | read as 8 unrelated buttons; no arrow keys |
| Payment timing cards | same | same |
| Slot grid | `aria-selected`, `aria-live` | can't tell which slot is chosen, or that slots reloaded |
| Every field | `aria-invalid`, `aria-describedby` | validation errors are visual only |
| Step transitions | `aria-live`, focus move | step change silent; focus stays put |
| Required fields | `aria-required` (only a visual `*`) | requiredness is colour/glyph-only |

This is the flow that generates revenue, it cannot be operated without sight, and
it is the fastest thing here to fail a WCAG 2.1 AA procurement review. Sighted
keyboard users pay too: no arrow-key movement in the busiest grids in the clinic.

```gherkin
Given Gaurav uses only a keyboard
When he books an appointment
Then he can complete every step without a mouse
  And arrow keys move between visit types and between time slots
Given a screen reader user opens the wizard
Then the current step, the selected visit type, the selected slot and any
     validation error are all announced
```

---

### F6 · The same field behaves differently on different screens `P2`

**As** Gaurav, **I want** one field to behave the same way everywhere, **so that**
I make fewer mistakes on a child's birthday.

**Scenario.** On **Register Patient**, DOB is three dropdowns — day, month, year —
most-recent years first (right for a pediatric clinic), day list clamped to the
month so 31 February is impossible. On **New Appointment** the same field is a
calendar popover: reaching a 4-year-old's birthday means clicking back through 48
months.

**The underlying pattern: your data layer is shared, your field layer is not.**
That is good news — this is an extraction job, not a re-architecture.

Shared hooks (correct today): `usePatientSearch` 8 consumers · `usePractitioners`
6 · `usePaymentMethods` 5 · `useGenders` 5 · `useAppointmentTypes` 4.
Shared **components**: `src/components/shared/` holds exactly **two** files.

| Field | Implementations | Where | Canonical choice |
|---|---|---|---|
| **Patient search** | **8 hand-rolled UIs on one shared hook** | booking drawer; `billing/new-invoice-sheet.tsx:171` (raw `<input>`+dropdown); `inbox/assign-nursing-task-form.tsx:99` (`Command`); `messages/new-chat-dialog.tsx:92`; `messages/new-portal-chat-dialog`; `patient-chart/family-tab`; `command-palette`; `billing/invoices/new` | new `PatientField` — highest-value extraction in the app |
| **Date of birth** | **2 components** | `DobCalendarPopover` (booking `:51`, used `:1261`) · `DobSelectFields` (`register-patient-dialog.tsx:830`) | **`DobSelectFields`** — the considered one (pediatric year order, per-month day clamping) |
| **Phone + country** | **3** | drawer inline (`COUNTRIES` `:25`, `lib/phone` `:27-33`); `register-patient-dialog` inline; shared `PhoneCountrySelect` | **`PhoneCountrySelect`** — whose own header says it was extracted *from this drawer* "so any other phone-number field gets the same readable list"; the drawer was never migrated, so the screen that motivated the fix still has the defect |
| **Field label** | redeclared locally in drawer `:136` **and** registration `:203` | — | `components/ui/field.tsx` + `label.tsx` (exist, unused by both) |
| **Guardian block** | **1, shared** ✅ | `GuardianFieldset` from `patient-chart/contact-tab` | already right — the model to copy |
| **Slot picker** | **2** | drawer; `appointments/reschedule-dialog` | one `SlotPicker` |
| **Money / fee / discount** | duplicated logic | drawer; `billing/new-invoice-sheet`; `collect-payment-dialog` | `MoneyField` + `DiscountField` |
| **Payment method** | 5 call sites, own select each | drawer (+ hardcoded fallback); billing ×3; collect-payment | `PaymentMethodField` |
| **Appointment type** | drawer; also needed on chart + encounter | — | `AppointmentTypeField` |
| **Insurance** | drawer (hardcoded) vs `insurance-tab` (real payors) | — | `InsuranceFields` |

**Why it compounds.** Each duplicate is an independent set of decisions about
keyboard handling, loading state, empty state, error copy, i18n keys and now
accessibility. Eight patient pickers mean eight chances to get "no results"
wrong, and eight places to fix when adding `aria-` semantics.

```gherkin
Given any screen that asks for a date of birth
When it renders
Then it uses the shared DobField component
  And entering a 4-year-old's birthday takes the same interactions everywhere
```

---

### F7 · "Walk-in" is offered but not implemented `P1`

**As** Gaurav, **I want** to register a family who just walked in without picking
a future slot, **so that** they join today's queue immediately.

**Scenario.** A mother arrives at 09:20 with a feverish toddler, no appointment.
Gaurav chooses **Walk-in** — one of the eight visit types, 30-minute default
duration, seeded by the backend (`patches/v0/seed_walkin_appointment_type_20260731.py`)
for exactly this purpose.

**What happens today.** The wizard treats it like any scheduled visit: date,
practitioner and a **slot from the grid** are all still required.
`grep -i "walk.?in"` in the 2,538-line dialog → **0 matches**. So he picks
whatever slot is near now, and the appointment time is fiction — which then flows
into wait-time and punctuality reports.

**What should happen.** Walk-in skips slot selection and books for **now**,
asking at most for the practitioner on duty.

```gherkin
Given a family arrives at 09:20 with no appointment
When Gaurav selects the "Walk-in" visit type
Then the wizard does not ask him to choose a time slot
  And the appointment is created for the current time
  And it appears in today's queue and dashboard immediately
  And wait-time reports show the real arrival time, not an invented slot
```

---

### F8 · The same child gets two charts `P1`

**As** Dr. Demo, **I want** one chart per child, **so that** I see the full
history — allergies, vaccines, growth — at the visit.

**Scenario.** Sofía's father phones Monday; Gaurav books her, creating the patient
inline. Thursday her mother walks in, spells the surname differently, and a
colleague books again from the chart screen. Two charts for one child. Dr. Demo
opens one, sees no immunizations, re-orders a vaccine she already had.

**What happens today.** The inline new-patient path creates the record with no
similarity check, though the backend ships `overrides/patient_duplicate_check.py`.
Booking is the most likely place in the product to create a duplicate (parent
phones, then walks in). Mirrors `03-patient-registration.md` R3.

**What should happen.** A warning before creation: *"2 possible matches — Sofía
Ramírez (4 y, 55‑5599‑0000), Sofia Ramirez (4 y, …). Use existing or create new?"*

```gherkin
Given a patient already exists with a similar name and date of birth
When Gaurav fills the inline new-patient form and continues
Then he is shown the possible matches before the record is created
  And he can select an existing patient instead
  And creating a duplicate requires an explicit confirmation
```

---

### F9 · Fields the backend accepts and the UI never offers `P2`

**As** Lucía, **I want** to know which referral sources bring us patients, **so
that** I can decide where to spend.

`book_appointment_for_patient` accepts, and the flow never sends:

| Param | Why it matters |
|---|---|
| `referring_practitioner` | referral attribution — **0 matches** in the drawer |
| `source` | how the family found the clinic — marketing/referral reporting |
| `insurance_payor`, `insurance_coverage` | see F1 |
| `add_video_conferencing` | telehealth |
| `procedure_template`, `therapy_type`, `therapy_plan`, `service_request` | procedure/therapy-driven bookings |
| `patient_age`, `patient_sex` | denormalised fields core keeps on the appointment |
| `billing_item`, `inpatient_record` | billing override; admitted patients |

Wired correctly today: `department` (`useAdminDepartments`), `duration`, `notes`,
`service_unit`, `paid_amount`, `discount_amount`. Note `discount_percentage` is
declared in the payload type but **never sent** — the % input is converted
client-side (`07` BK4, still true).

---

### F10 · Step 1 wastes the screen and hides the road ahead `P2`

**As** Gaurav, **I want** to see how long the flow is and what I have chosen, **so
that** I move fast and check myself before confirming.

**Scenario.** Step 1 shows three fields in roughly the top 15% of the sheet, the
eight-button type grid carrying most of the visual weight, a large empty area
below. The step indicator shows *Patient* then three bare numbers — the labels
*Schedule*, *Payment*, *Confirm* exist in `messages/en.json` but are not
displayed. Gaurav commits to a four-step flow able to see one of them.

**What should happen.** Show all four labels with a running summary of choices,
and use step 1's empty space for what the system already knows once a patient is
picked: age, outstanding balance, active insurance, last visit.

```gherkin
Given Gaurav opens New Appointment
Then all four step names are visible
When he selects an existing patient
Then step 1 shows that patient's age, outstanding balance and active insurance
```

---

## 3. Recommendations, in the order I would do them

**1. Transmit insurance** `F1` `P0` — small, revenue. Un-comment the option,
replace the hardcoded list with `useInsurancePayors`, let staff **select an
existing policy** via `usePatientInsurance`, pass `insurance_policy` in the
mapper. **Seed the payors first** (`F3b`) or it will look like a regression.
*Done when:* an insured booking produces a coverage-split invoice with only the
copay outstanding, verified on `remedisys.localhost` — not just in the UI.

**2. One booking pipeline** `F2` `P0` — `buildBookingPayload(draft)` +
`useBookAppointment()` with `track()` inside; all three hosts consume it. Delete
the duplicated mappers and the false comment.

**3. Delete one reschedule dialog** `F4` `P1` — keep the wrapper, repoint
`appointments-client` and `overview-frontdesk`.

**4. Build `src/components/fields/`** `F6` `P1`, incremental, in value order:
`PatientField` (8 call sites) → `PhoneField` → `DobField` → `SlotPicker` →
`PaymentMethodField` → `MoneyField`/`DiscountField` → `AppointmentTypeField` →
`InsuranceFields`. Each owns label, validation copy, loading/empty state,
keyboard behaviour, **a11y semantics** and its own i18n keys. Migrate the booking
drawer first — worst offender, highest traffic.

**5. Accessibility inside that extraction, not after** `F5` `P1` — radiogroup on
the type and timing grids, combobox on patient search, `aria-live` on slot load
and step change, `aria-invalid`/`aria-describedby` on every field, focus moved to
each step's heading. In the field kit it is fixed once for every screen.

**6. Flow polish** `F7` `F8` `F9` `F10` `P2` — walk-in path, duplicate guard,
visible step labels with chosen values, `referring_practitioner` + `source`, and
a real server-conflict state when a slot is taken mid-booking (the atomic backend
already rejects it; the UI should recover in place, not toast and lose the draft).

**7. Structural, once the kit exists** — split the 2,538-line drawer:
`useBookingDraft` reducer + one component per step + inline registration lifted
into a reusable `PatientQuickCreate` shared with `register-patient-dialog`.
Enforce with an ESLint boundary banning raw `<input>`/`<select>` for these data
types outside `components/fields/`, or the duplication returns.

---

## 4. Corrections to `screens/07-appointment-booking.md`

`07` is broadly right and predates this pass; four claims are now stale. Recorded
here rather than edited in, because `07` has uncommitted work in `stash@{0}`.

| `07` claim | Current reality |
|---|---|
| "All three dialogs' strings 🟡 **HARDCODED ENGLISH** … largely not `useTranslations`" | **No longer true** for the booking drawer: 140 `t("…")` calls across 4 `useTranslations` namespaces. The i18n sweep landed. |
| Line refs `dialog:766` (insurance option), `:810` (insurer list), `:59` (`generateMrn`), `:277` (payment fallback) | File grew to 2,538 lines: option `:2127`, insurer list `:2176`, `generateMrn` `:126`, fallback moved. |
| `command-palette:116` as *the* submitter | There are **two** submitters (F2); the palette one is `:112-156`. |
| Reschedule "🟢 REAL … same practitioner" (implies one implementation) | **Two** reschedule dialogs (F4), both live. |

Re-confirmed as still accurate: BK1 (insurance broken), BK2 (no edit path), BK3
(mock payor list), BK4 (`discount_percentage` never sent), MRN preview is
display-only (`generateMrn` `:126`), duplicate guard missing.

---

## 5. Decisions someone must make before building

1. **Copay** — informational only, or must it drive the invoice split? If the
   latter, `book_appointment_for_patient` needs a copay parameter; today the split
   is derived by core from the policy's coverage.
2. **Walk-in** — book at `now()`, or auto-assign the next free slot? Decides
   whether walk-ins appear on the calendar.
3. **Fees** — configure `op_consulting_charge` per practitioner, or make the fee a
   required entry at booking time? (`F3a`)
4. **Payors** — who seeds the real insurer list, and does each need a coverage
   percentage? (`F3b`)
5. **Editing** — which fields may be corrected after booking, before invoicing:
   visit type, reason, fee, service unit? (`07` BK2)
6. **`discount_percentage`** — forward it, or formally accept amount-only and drop
   it from the payload type?

---

## 6. Tester's checklist

On `remedisys.localhost` as `frontdesk@narzim.com` (password in the team vault):

| # | Check | Finding |
|---|---|---|
| 1 | Insurance is selectable; an insured booking creates a coverage-split invoice with only the copay outstanding | F1 |
| 2 | The insurer list matches the site's `Insurance Payor` records | F1, F3b |
| 3 | The patient's existing policy can be selected without retyping the number | F1 |
| 4 | Booking from the patient chart records `appointment.booked` | F2 |
| 5 | "Pay now" against a practitioner with no fee warns instead of invoicing 0 MXN | F3a |
| 6 | Reschedule from chart overview and chart appointments tab open the same dialog | F4 |
| 7 | Whole flow completable by keyboard only; steps, slots and errors announced | F5 |
| 8 | DOB, phone and patient search look and behave identically on booking and registration | F6 |
| 9 | Walk-in books for now, with no slot grid | F7 |
| 10 | A near-duplicate patient triggers a warning before creation | F8 |
| 11 | All four step labels visible; selected patient's age/balance/insurance shown on step 1 | F10 |

---

## 7. Evidence log

| Claim | Evidence |
|---|---|
| 4 steps | `new-appointment-dialog.tsx:115` |
| 2,538 lines, 4 responsibilities | `wc -l`; guardian/photo/registration imports `:38-52` |
| 3 renderers | `patient-chart-client.tsx:851`, `dashboard/reschedule-dialog.tsx:91`, `command-palette.tsx:209` |
| 2 copied mappers | `command-palette.tsx:112-156`, `patient-chart-client.tsx:440-472` |
| analytics only in palette | `command-palette.tsx:158` + comment |
| insurance option commented out | `:2127` |
| insurance dead branches | `:597`, `:2164-2200`, `:2206-2212`, `:2387-2389` |
| insurance dropped on submit | `command-palette.tsx:131`, `patient-chart-client.tsx:447` |
| `insurance_policy` declared, unused | `lib/api/appointments.ts:107` |
| hardcoded insurer list | `:2176` |
| real payor/policy hooks unused in booking | `hooks/use-patient-insurance.ts` consumers |
| practitioner fees | `Healthcare Practitioner.op_consulting_charge` on the live site |
| `Insurance Payor` = 1 row ("Apoolo") | live site query |
| 0 aria/role | `grep -cE "aria-|role=" new-appointment-dialog.tsx` → 0 |
| 8 patient-picker UIs | `grep -rl usePatientSearch src` |
| 2 DOB components | `:51`/`:1261` vs `register-patient-dialog.tsx:830` |
| 3 phone implementations | `grep -rl phone-country-select` → 2 files; drawer imports `COUNTRIES` `:25`, `lib/phone` `:27-33` |
| 2 reschedule dialogs | `ls -l` + consumer grep |
| walk-in unhandled | `grep -i "walk.?in"` → 0 |
| Walk-in type exists, 30 min | `Appointment Type` on the live site |
| i18n adopted (`07` stale) | 140 × `t("`, 4 × `useTranslations` |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Invincible | Initial version (header backfilled from git history) |
