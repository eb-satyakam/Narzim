# Front Desk — Role Charter, Workflows & Frontend Gap Analysis

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

> **Scope of this document.** Two things in one file:
> 1. **What the Front Desk *should* perform** — the role charter, written as user stories with concrete pediatric-clinic (Mexico) examples. This is the reference for "done".
> 2. **Where the frontend stands against that charter** — each workflow marked **REAL** (wired to the live `remedisys_healthcare_ai` backend), **MOCK** (UI exists, no backend / fake data), or **MISSING** (not built), with the exact gap.
>
> Grounded in a code read of both `EB_Healthcare_Backend` (`api/v1/*`) and `Healthcare_next_app` on **2026-07-09**. This is analysis, not a build order — nothing here is a committed scope until we agree on it.
>
> **Companion:** `OPD_BACKEND_FLOW_AND_GAPS.md` traces the same visit at the **backend doctype level** (appointment → vitals → encounter → sales invoice → payment) and lists backend gaps **B1–B11**. Read it for the data-model view; this doc is the role/UI view.

---

## 1. Who the Front Desk is

**Persona — "Recepción".** The first and last person a family sees. In a pediatric clinic in Mexico the patient is a child; the person she talks to, bills, and reminds is almost always the **guardian** (madre/padre/tutor). She runs the waiting room, the money, and the schedule. She is *not* clinical — she never touches vitals, diagnoses, or prescriptions.

**Her three jobs, in priority order:**
1. **Get the right patient in front of the right provider on time** (schedule + check-in + queue).
2. **Collect the money correctly and account for it** (checkout + billing + cash).
3. **Keep families informed** (confirmations, reminders, follow-ups).

**Role mapping in the system:** Frappe role `EB_Front Desk` → frontend role `frontdesk`. Capabilities granted today (`lib/narzim/roles.ts`): `newAppt, collectPayment, confirm, checkIn, rescheduleCancel, reassign, noShow, invoices`. Clinical capabilities (`startEncounter`, `canEditEncounterDraft`, `markReady`) are correctly **denied**.

---

## 2. The Front Desk day (the end-to-end loop)

```
        MORNING                     THROUGHOUT THE DAY                       EVENING
  ┌──────────────┐        ┌────────────────────────────────────┐      ┌──────────────┐
  │ Open shift   │        │  Walk-in / phone → register/find    │      │ Reconcile    │
  │ + cash float │───────▶│  Book / confirm / reschedule appt   │─────▶│ cash drawer  │
  │ Review today │        │  Arrival → check-in → queue         │      │ Close shift  │
  └──────────────┘        │  Encounter done → CHECKOUT          │      │ Handover     │
                          │  Consolidate charges → invoice      │      │ Day report   │
                          │  Collect payment → receipt          │      └──────────────┘
                          │  Book follow-up                     │
                          │  Send reminders                     │
                          └────────────────────────────────────┘
```

Each stage is expanded below. **The loop is only as strong as its weakest stage** — today the weak stages are the two bookends (shift/cash open and close) and insurance.

---

## 3. Workflows — what she should do, and where we stand

Legend: 🟢 **REAL** (wired end-to-end) · 🟡 **MOCK** (UI only / fake data) · 🔴 **MISSING** (not built) · 🟠 **BUILT-BUT-HIDDEN** (code exists, disabled in UI)

---

### 3.1 Patient reception & registration

**User story.**
> *As Front Desk, I want to register a new child with their guardian, contact, and insurance in one form, so that the family is on file before they reach the provider and I can bill them.*

**Example.** Sra. López walks in with her 3-year-old, Mateo, first visit. Recepción creates Mateo's record, sets Sra. López as **primary guardian** with her mobile, adds the family address, and (if insured) captures the GNP policy number.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Register patient (full form: demographics, guardians, contact, allergies, history) | `patients.create_patient` | `register-patient-dialog.tsx` → `useCreatePatient` | 🟢 REAL |
| Find existing patient (name / MRN / mobile / phone / email) | `patients.list_patients(search=…)` | `patients-client.tsx` → `usePatients` | 🟢 REAL |
| Add / edit / remove guardian | `add_guardian` / `update_guardian` / `remove_guardian` | Patient chart | 🟢 REAL |
| Update demographics | `patients.update_patient` | Patient chart | 🟢 REAL |
| Quick typeahead search (for booking/checkout dialogs) | *folded into `list_patients`* | booking dialog search | 🟢 REAL (no dedicated typeahead endpoint, but works) |

**Gap:** none blocking. Cosmetic: per-row message count is hardcoded `0` on the patient list.

---

### 3.2 Appointment booking

**User story.**
> *As Front Desk, I want to book an appointment into a real open slot for the right provider and visit type, and optionally take payment now, so the schedule reflects reality and pre-paid visits are settled up front.*

**Example.** Sra. López wants Mateo seen Thursday by Dra. Ramírez for a *Consulta de control*. Recepción picks Thursday, sees Dra. Ramírez's **real free slots**, books 10:30, and takes the ₱600 consulta as **pay-now** (cash) — one atomic action that creates the appointment, the invoice, and the payment.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| See real available slots | `appointments.get_available_slots` | `useAvailableSlots` in booking dialog | 🟢 REAL |
| Book (existing or brand-new patient, atomic) | `book_appointment_for_patient` | `new-appointment-dialog.tsx` + command palette | 🟢 REAL |
| Book with payment now (invoice + settle atomically) | `book_appointment_with_payment` / `payment_timing="pay_now"` | booking dialog pay-now path | 🟢 REAL |
| Fee override + discount at booking | params on booking | booking dialog | 🟢 REAL |
| Book from calendar grid (click a slot) | — | calendar is **display-only** | 🔴 MISSING |

**Gap.** The **calendar** (`calendar/calendar-client.tsx`) renders real appointments but is **read-only**: no click-to-book, no drag-to-reschedule, no click-through to the appointment or patient. Booking today only starts from the global "+ New Appointment" header button or ⌘K. For a front desk that lives in the calendar, this is a real friction point (see gap G4).

---

### 3.3 Confirm / reschedule / cancel / reassign

**User story.**
> *As Front Desk, when a family calls to move or cancel, or when I need to cover a provider's absence, I want to change the appointment safely without double-booking.*

**Example.** Dra. Ramírez calls in sick Thursday. Recepción needs to **reassign** her Thursday patients to Dr. Núñez. Today she can reschedule/cancel each, but the one-click *reassign provider* action is hidden.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Confirm (Open/Scheduled → Confirmed) | `update_status` | `useUpdateAppointmentStatus` | 🟢 REAL |
| Reschedule (new date/time, same provider) | `reschedule_appointment` | `useRescheduleAppointment` | 🟢 REAL |
| Cancel (with reason) | `cancel_appointment` | `useCancelAppointment` | 🟢 REAL |
| Mark No-Show | `update_status(No Show)` | queue / status controls | 🟢 REAL |
| **Reassign provider (coverage)** | `reassign_appointment` | hook + `ReassignDialog` exist | 🟠 **BUILT-BUT-HIDDEN** — menu item commented out in `appointments-client.tsx` (~L357–367, "temporarily disabled per request") |

**Gap.** Reassign is trivially re-enableable — the hook, route, dialog, and capability all exist; only the menu entry is commented out. Confirm with the team *why* it was disabled before flipping it back on (G5).

---

### 3.4 Arrival → check-in → queue

**User story.**
> *As Front Desk, when a family arrives I want to check them in so the clinical team knows they're here and the patient enters the room queue.*

**Example.** Sra. López and Mateo arrive at 10:20. Recepción taps **Check-in** on the "arriving soon" card; Mateo moves into the **waiting room** queue and the nurse sees him.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Check-in (stamps arrival time) | `check_in_patient` | `useCheckInPatient` — dashboard queue + chart | 🟢 REAL |
| Live room queue (arriving / waiting / nursing / provider / checkout) | `dashboard.get_dashboard_data` | `mission-control-client.tsx` | 🟢 REAL |
| Move patient between rooms | queue mutations | queue actions | 🟢 REAL |
| Today's KPIs (scheduled, waiting, revenue, longest wait) | `get_dashboard_data` | dashboard KPI row | 🟢 REAL |

**Gap:** none in the core loop. Missing niceties: no **eligibility/insurance verification at check-in** and no **co-pay prompt at check-in** (see G2). No walk-in "add to queue without a slot" express path (minor — a walk-in is booked as a same-day appointment today).

---

### 3.5 Checkout & billing (the money loop)

This is the heart of the role. Broken into its parts.

#### 3.5a Consolidated checkout (visit → one bill)

**User story.**
> *As Front Desk, after the visit I want every un-billed charge (consulta, vaccine, lab, procedure) gathered into ONE invoice so the family pays once and I issue one receipt.*

**Example.** Mateo's visit produced: consulta ₱600 + vacuna hexavalente ₱950 + aplicación ₱150. At checkout Recepción sees all three, ticks them, generates **one** invoice for ₱1,700, takes the card payment, and hands over the receipt.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Gather all un-invoiced billables | `billing.get_patient_billables` | `usePatientBillables` in `checkout-dialog.tsx` | 🟢 REAL |
| Create ONE consolidated invoice + optional payment | `billing.create_pos_invoice` | `useCreatePosInvoice` | 🟢 REAL |
| Checkout from dashboard "checkout" queue room | dashboard + collect | `collect-payment-dialog.tsx` | 🟢 REAL |

**Gap:** functionally complete. Minor: checkout's payment-method picker is a hardcoded 3-option list (Cash/Card/Transfer) instead of pulling `billing.get_payment_methods` (the *collect* dialogs do it correctly).

#### 3.5b Invoices & pending / outstanding

**User story.**
> *As Front Desk, I want to see all invoices — especially the unpaid ones — with balances, so I can chase outstanding money and answer "how much do we owe?".*

**Example.** A family returns; Recepción searches their name in Billing, sees a ₱400 balance from last visit still **Pending**, and collects it before today's visit.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Clinic-wide invoice list + filters (All/Pending/Paid/Refunded), search, date range, CSV | `billing.list_all_invoices` | Billing hub Invoices tab | 🟢 REAL |
| Per-patient invoice history | `billing.list_patient_invoices` | chart Billing tab | 🟢 REAL |
| Outstanding KPI + balance-due patient filter | `list_all_invoices` / `list_patients(filter_balance_due)` | Billing KPIs + patient list | 🟢 REAL |
| View single invoice (lines + taxes) | `billing.get_patient_invoice` | invoice detail / print modal | 🟢 REAL |

**Gap:** none for viewing. See G6 for the *create-invoice-outside-a-visit* gap.

#### 3.5c Create a Sales Invoice (ad-hoc)

**User story.**
> *As Front Desk, I sometimes need to raise an invoice that isn't tied to today's checkout (e.g. a certificate, a missed charge, a product), so I can bill anything the clinic sells.*

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Create invoice for an appointment | `billing.create_appointment_invoice` | `CreateInvoiceDialog` (appointment path) | 🟢 REAL |
| Consolidated POS invoice | `billing.create_pos_invoice` | checkout dialog | 🟢 REAL |
| Vaccination-only invoice | `billing.create_vaccination_invoice` | (via billables) | 🟢 REAL |
| **"New Invoice" button on the Billing hub** | *backend supports it* | **no button on Billing page**; chart Billing-tab New-Invoice button is **commented out** (`billing-tab.tsx` ~L239, "hidden until wired") | 🟠 **BUILT-BUT-HIDDEN** |

**Gap.** There is no *entry point* to raise an invoice outside the appointment/checkout flows even though the backend can. Front desk cannot bill an ad-hoc/miscellaneous item today (G6).

#### 3.5d Collect payment / partial / refund / receipt

**User story.**
> *As Front Desk, I want to take full or partial payment in the family's chosen method, refund when needed, and always produce a receipt.*

**Example.** A family can only pay ₱1,000 of ₱1,700 today. Recepción takes ₱1,000 (partial), the invoice shows ₱700 still outstanding, and she prints the invoice.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Collect payment (full or **partial**) | `billing.collect_payment` (any amount ≤ outstanding) | `CollectInvoicePaymentDialog` → `useCollectPayment` | 🟢 REAL |
| Payment method dropdown (real ERPNext modes) | `billing.get_payment_methods` | `usePaymentMethods` | 🟢 REAL |
| Refund (full-invoice credit note, returns cash) | `billing.create_credit_note` | `RefundButton` → `useCreateCreditNote` | 🟢 REAL |
| List incoming payments (filter method/date, search) | `billing.list_payment_entries` | Payments tab | 🟢 REAL |
| Invoice PDF / print | — (client jsPDF) | `InvoicePrintModal` | 🟢 REAL |
| **Dedicated payment receipt** (separate from invoice PDF) | 🔴 no endpoint | invoice PDF stands in | 🔴 MISSING |
| **Void / cancel a submitted invoice** | 🔴 no endpoint (only credit note) | — | 🔴 MISSING |
| **Partial / line-item credit note** | 🔴 credit note is full-invoice only | — | 🔴 MISSING |

**Gaps:** no true **receipt** document (G7); no **void/cancel invoice** (G8) — a mistaken submitted invoice can only be reversed by a full credit note, which is noisier than a void; no **partial refund** (G8).

---

### 3.6 Cash drawer & shift management — **the biggest gap**

**User story.**
> *As Front Desk, I want to open my shift with a cash float, have every cash payment I take roll up against my drawer, and at end of day count the drawer, see the expected-vs-actual variance, and hand over — so the clinic's cash is accountable and I'm not personally liable for a black box.*

**Example.** Recepción opens with ₱1,000 float. Through the day she takes ₱4,300 cash across visits. At close the drawer should hold ₱5,300; she counts ₱5,250 → **₱50 short**, recorded and explained. Tomorrow's shift starts clean.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Open shift + opening float | 🔴 **no `/api/cash` route, no doctype** | `open-shift-dialog.tsx` writes **localStorage**, fake `setTimeout` | 🟡 **MOCK** |
| Roll cash payments into the drawer | 🔴 none | computed **client-side** from localStorage | 🟡 MOCK |
| Drawer transfers (petty cash out) | 🔴 none | `transfer-drawer-dialog.tsx` → localStorage | 🟡 MOCK |
| Close shift, expected-vs-actual variance | 🔴 none | `close-shift-dialog.tsx` → localStorage | 🟡 MOCK |
| Shift identity / who's on the terminal | 🔴 none | `session.ts` mock PIN session in `sessionStorage` | 🟡 MOCK |

**Impact (spelled out because this is serious):** shift open/close, float, drawer transfers, and cash variance are **not persisted, not multi-user, not auditable**, and **not reconciled against real Payment Entries**. If two people use the app, or the browser cache is cleared, the cash record is gone. For a clinic handling real pesos this is the **#1 operational and compliance risk** in the front-desk surface (G1). It also needs an **ADR** (new custom doctypes) before it can be built — see §5.

---

### 3.7 Insurance at the desk

**User story.**
> *As Front Desk, I want to record a family's insurance, split a bill between insurer and patient co-pay, and see the insurance side of billing, so insured families are billed correctly.*

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| Record / edit / delete patient policy | `insurance.save_patient_insurance_policy` / `delete_…` | — | 🔴 MISSING (no UI) |
| List policies / payors | `get_patient_insurance_policies` / `list_insurance_payors` | — | 🔴 MISSING (no UI) |
| Insurance split on invoice | handled in `create_appointment_invoice` | booking has an insurance pay-timing option **partly commented out** | 🟠 partial |
| Billing → **Insurance tab** | *backend exists* | hardcoded empty "coming soon" state | 🟡 MOCK |

**Gap.** The backend for policies + payors exists, but there is **no frontend** to manage a patient's insurance and the Billing Insurance tab is a placeholder (G3). Note: insurance *claims* (`create_claim` / `submit_claim`) are **not built on the backend at all** — that's a Phase-3 backend gap, out of front-desk scope for now.

---

### 3.8 Communication — reminders, confirmations, follow-up

**User story.**
> *As Front Desk, I want to remind families of tomorrow's appointments and confirm bookings over WhatsApp, and set the follow-up the doctor asked for, so no-shows drop and continuity holds.*

**Example.** Dra. Ramírez wants Mateo back in 2 weeks. Recepción books the follow-up ToDo assigned to herself. The evening before, she wants to WhatsApp all of tomorrow's families a reminder.

| Capability | Backend | Frontend | Status |
|---|---|---|---|
| In-app notifications (list, unread, mark read) | `notifications.*` | notifications (bell hidden via `false &&`) | 🟠 built, UI hidden |
| WhatsApp inbox (reply, template, media, start conversation) | `notifications.get_whatsapp_conversations` … | messaging surface | 🟢 REAL (per backend; FE wiring for FD to verify) |
| Book follow-up (ToDo assigned to front desk) | `encounters.book_follow_up` / `get_follow_up` | follow-up UI | 🟢 REAL |
| **Automated appointment reminder** ("remind for appointment X" / scheduled) | 🔴 no reminder endpoint (only manual generic WhatsApp; appt has a `reminded` flag nothing sets) | — | 🔴 MISSING |

**Gap.** Reminders are **manual and generic** — there is no "send reminder for this appointment" action and no scheduled/automated reminder. The `reminded` flag on the appointment is never set by anything (G9).

---

## 4. Gap register (prioritized)

Priority = operational/compliance risk × how often the desk hits it.

| # | Gap | Layer | Severity | Why it matters |
|---|---|---|---|---|
| **G1** | **Cash drawer / shift is fully mock** (localStorage, no backend, mock session) | FE **+ backend + ADR** | **Critical** | Real money, not persisted/auditable/multi-user; #1 risk. Needs new doctypes → ADR first. |
| **G2** | No eligibility check / co-pay prompt at check-in | FE + backend | High | Insured families should be verified & co-pay taken at arrival, not after. |
| **G3** | Insurance management UI missing; Billing Insurance tab is a placeholder | FE (backend for policies exists; claims don't) | High | Insured billing is a black hole in the UI despite backend support for policies. |
| **G4** | Calendar is read-only (no book / drag-reschedule / click-through) | FE only | Medium-High | The desk's most natural surface can't act. Backend already supports every action. |
| **G5** | Reassign provider disabled in UI | FE only (1-line) | Medium | Coverage for provider absence is a common desk task; fully built, just hidden. |
| **G6** | No entry point to create an ad-hoc invoice (Billing hub + chart button commented out) | FE only | Medium | Can't bill miscellaneous/off-visit items though backend can. |
| **G7** | No dedicated payment receipt (invoice PDF stands in) | FE + maybe backend | Medium | Families expect a payment receipt, especially for partial payments. |
| **G8** | No void/cancel of submitted invoice; no partial/line-item refund | backend + FE | Medium | Mistaken invoice can only be reversed by full credit note — noisy and error-prone. |
| **G9** | No automated / per-appointment reminders (manual generic WhatsApp only) | backend + FE | Medium | Reminders drive down no-shows; today it's fully manual. |
| G10 | Notifications bell hidden (`false &&`), stale mock-data comments, hardcoded `0` message counts | FE cosmetic | Low | Polish; logic already exists. |
| G11 | Checkout payment-methods hardcoded instead of `get_payment_methods` | FE cosmetic | Low | Inconsistent with collect dialogs; drifts from real ERPNext modes. |

**Encouraging headline:** the *core* front-desk loop — **register → book (with payment) → check-in → queue → checkout/consolidated-invoice → collect (full/partial) → refund → invoices/payments lists** — is **real and wired end-to-end** to the backend. The gaps cluster at the **edges of the day (open/close cash), insurance, and the calendar's interactivity**, plus a few things built-but-hidden that are near-free to switch on.

---

## 4A. Are we aligned with the core (ERPNext Healthcare) flow? — Frontend verdict

The frontend is a **thin client over the BFF → our `api/v1` → core**. So it can only be as aligned with core as our API is (see `CORE_HEALTHCARE_FLOW_AND_MARLEY_MAP.md`), and then it **adds its own misalignments** wherever it stops calling the API and starts **faking or hiding** data.

Legend: ✅ aligned · 🟡 cosmetic/deliberate · 🟠 under-uses or diverges from core · 🔴 not aligned

| Front-desk surface | Aligned with core? | Why |
|---|---|---|
| Booking (slots, create, pay-now) | ✅ **Aligned** | Real `Patient Appointment` via our API → core validation. (Slots ride our *port* of core logic — behaves like core today, drift risk on upgrade.) |
| Checkout / consolidated invoice | ✅ **Aligned** | Uses `get_patient_billables` → core `get_healthcare_services_to_invoice`. Mirrors core billable discovery. |
| Invoices / payments / partial / refund | ✅ **Aligned** | Thin client over core Sales Invoice / Payment Entry. |
| Appointment status vocabulary | 🟡 **Cosmetic** | FE "Completed"↔ERP "Closed", "Ready for Provider"→"Checked In". Harmless mapping. |
| Check-in **queue** | 🟠 **Diverged** | The queue shown is our dashboard's room model — it does **not** reflect core's native `position_in_queue` (the API never sets it, it writes status via `db.set_value`). FE queue is a Marley construct. |
| Calendar | 🟠 **Under-uses core** | Read-only; core supports book/reschedule from a slot but the FE doesn't expose it. |
| Patient 360 history / activity | 🔴 **Not aligned** | Shows a hand-rolled subset feed, **not** core's auto-maintained `Patient Medical Record` timeline. New data types won't appear unless the FE is manually extended. |
| Insurance tab | 🔴 **Not aligned** | Hardcoded "coming soon" placeholder. Core has the full Policy → Coverage → **Claim** model; the FE surfaces none of it (G3). |
| **Cash drawer / shift** | 🔴 **Worst misalignment** | Entirely browser `localStorage` + mock PIN session — **no backend at all**. Core even has POS Opening/Closing Entry that could back it. The FE invents its own reality (G1). |
| Reassign provider / "New Invoice" | 🟠 **Hidden** | Built and core-capable, but commented out in the UI (G5/G6). |

**Bottom line (frontend):** aligned on the **transactional loop** (because our API is), and misaligned **exactly where it stops talking to core and starts faking or hiding**. In one line — *the frontend is honest where it talks to core, and misleading where it doesn't* — the **cash drawer** being the glaring case (it looks like it's tracking money; it isn't). Ranked FE misalignments: **cash (🔴 fiction) > insurance placeholder (🔴) > history feed ≠ core timeline (🔴) > under-exposed calendar/queue/hidden actions (🟠)**.

---

## 5. What needs an ADR before it can be built

Per CLAUDE.md §12, new custom doctypes require an ADR. These gaps introduce new persistent entities:

- **G1 Cash/Shift management** — new doctypes (Shift Session, Cash Transaction / Drawer Transfer, opening/closing balance). This is explicitly called out in CLAUDE.md §12 as "requires ADR before building". **Do this first for cash** — do not let the frontend keep pretending localStorage is a backend.
- **G8 Invoice void + partial refund** — likely no new doctype (uses ERPNext core), but a decision on *void-vs-credit-note* policy belongs in an ADR/decision note.
- **G9 Automated reminders** — background job + template policy; decision note on scheduling and opt-out (LFPDPPP/DPDPA consent).

The others (G2 partial, G3 UI-over-existing-backend, G4, G5, G6, G7, G10, G11) are mostly **frontend** work against endpoints that already exist, except where noted.

---

## 6. Out of scope for Front Desk (explicit handoffs)

So we don't accidentally scope-creep the role:

- **Clinical authoring** — vitals, encounter notes, diagnoses, prescriptions, marking a patient "ready" → Nurse / Doctor. Correctly denied in capabilities.
- **Insurance claim submission/adjudication** — backend not built (`insurance` claims are stubbed); this is a later Phase-3 backend task, not a desk UI gap yet.
- **Reports** — only if `can_view_reports` is granted; the Reports module itself is Phase 4.
- **Clinic settings / staff admin** — Clinic Admin / Platform Admin.

---

## 7. Suggested build order (for discussion — not committed)

1. **Free wins first (FE-only, endpoints exist):** G5 re-enable reassign, G6 wire the New-Invoice button, G11 use real payment methods in checkout, G10 unhide notifications. → makes the desk feel complete in ~a day.
2. **Insurance UI (G3):** build the policy management + Billing Insurance tab over the *existing* insurance endpoints.
3. **Calendar interactivity (G4):** click-to-book + click-through (drag-reschedule can follow).
4. **Cash/Shift (G1) — the big one:** write the ADR, add doctypes + `api/v1/cash`, then replace the localStorage layer. This is the highest-value but heaviest item.
5. **Check-in eligibility + co-pay (G2), receipts (G7), void/partial-refund (G8), reminders (G9).**

---

## Appendix — backend correctness note (for the backend dev, not a FE gap)

`billing.collect_payment` runs `require_permission("Payment Entry", "create")` and then `pe.save(ignore_permissions=True)`. The explicit gate runs first so it's not exploitable, but the `ignore_permissions=True` after a permission check is contradictory and worth tidying so intent is unambiguous.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
