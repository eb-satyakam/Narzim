# Native ERPNext Healthcare — Default Core Flow & How Marley Uses It

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

> **What this is.** A deep map of the **default ERPNext Healthcare core** process model (the engine we build on), plus the important part: **what Marley/Remedisys uses, ignores, reimplements, or diverges from** — and the risk each divergence carries.
>
> Grounded in a code read of `apps/healthcare/healthcare/` + our `remedisys_healthcare_ai/api/v1/*`, and a **live query of `Healthcare Settings` on `remedisys.localhost`** on **2026-07-09**. Companion to `OPD_BACKEND_FLOW_AND_GAPS.md` (our app's chain) and `FRONTDESK_CHARTER_AND_GAPS.md` (the frontend).
>
> **Why it matters:** core has a lot of automation that fires whether or not our API asks for it (doc_events, `after_insert`, scheduler jobs, the `Sales Invoice`/`Payment Entry`/`*` hooks). Knowing what's on, what we lean on, and what we bypass is the difference between building *with* the engine and fighting it (Rule 1 upgrade-safety).

---

## 0. The single most important fact: which MODE our site runs in

Core behavior is governed by a handful of `Healthcare Settings` flags. Here is the **live** configuration and what each implies:

| Flag | Live value | What it means for us |
|---|---|---|
| `show_payment_popup` | **0 (OFF)** | Core does **NOT** auto-create a Sales Invoice on appointment. **We own invoicing** via `billing/api.py`. **Consequence:** the *other* branch is live — core auto-creates **Fee Validity** and **appointment Insurance Coverage** in `after_insert`/`on_update`. |
| `enable_free_follow_ups` | **0 (OFF)** | Free-follow-up engine dormant. `manage_fee_validity` short-circuits. No hidden free-visit accounting. |
| `link_customer_to_patient` | **1 (ON)** | Core auto-creates the `Customer` on `Patient.on_update`. Our `_ensure_patient_customer` is a **backstop**, not the primary path. |
| `process_service_request_only_if_paid` | **0 (OFF)** | Lab Test / Procedure / Therapy Session can be spawned from a Service Request **without** an invoice. No billing-first gate. |
| `collect_registration_fee` | **0 (OFF)** | No "patient Disabled until registration paid" gate. Patients are usable immediately. |
| `automatically_generate_billable` | **0 (OFF)** | No daily inpatient bed-charge accrual (we don't do inpatient anyway). |
| `create_lab_test_on_si_submit` | **0 (OFF)** | Lab Tests are not auto-created when an invoice is submitted. |

**Read this as:** we run core in **"manual invoicing, no fee-validity, customer-autolink on"** mode. Our billing API is the source of truth for money; core's automatic-invoicing brain is switched off. That is a coherent choice — but it means two core subsystems (**Fee Validity**, **appointment-level Insurance Coverage**) are still quietly active on every appointment save, and we should either use them deliberately or confirm they're inert.

---

## 1. The default core process model (canonical, out-of-the-box)

Core is a **v14+ order-management design**. The important structural truth: **submitting an encounter does not create Lab Tests or Procedures directly** — it creates an *order layer* (`Service Request` / `Medication Request`), and the execution docs are spawned from those later.

```
SETUP (masters)
  Healthcare Settings ── Medical Department ── Service Unit Type ─► Service Unit (rooms)
  Practitioner ── Practitioner Schedule (weekly time_slots) ── bound via Practitioner Service Unit Schedule
  Appointment Type (default_duration, allow_booking_for, charges)

SCHEDULING
  Patient Appointment
    • get_availability_data() → slots (schedule × room capacity/overlap × holidays/leave × unavailability)
    • validate(): overlap/capacity/per-day/inpatient-unit/unavailability → set_status → position_in_queue
    • status: today→Open, future→Scheduled, past→No Show; Confirmed/Checked In/Checked Out/Closed/Cancelled manual
    • after_insert(): payment popup? / insurance coverage / calendar Event / confirmation SMS
    • CHECK-IN = manual status "Checked In" → set_position_in_queue()  (native queue)

CLINICAL
  Patient Appointment --make_encounter()--> Patient Encounter (draft)
    child rows: symptoms · diagnosis(→codification) · drug_prescription · lab_test_prescription
                · procedure_prescription · therapies
    on_submit ──► create_therapy_plan()   → Therapy Plan
              ──► make_service_request()  → Service Request  (per lab/procedure/therapy)
              ──► make_medication_request → Medication Request (per drug)
              ──► status=Completed, appointment=Closed, timeline entry

  Service Request --(later, whitelisted, gated by process_service_request_only_if_paid)-->
       make_lab_test()          → Lab Test  (order→sample→result→approve)
       make_clinical_procedure()→ Clinical Procedure (start→consume stock→complete)
       make_observation()       → Sample Collection + Observation + Diagnostic Report
       make_therapy_session()   → Therapy Session (increments Therapy Plan)
  Each spawn → Nursing Tasks from the template's checklist.

BILLING (core "Invoice Healthcare Services")
  get_healthcare_services_to_invoice() scans invoiced=0 / billing_status=Pending sources
    → Sales Invoice (items carry reference_dt/dn + insurance_* fields)
    → on_submit: set_invoiced() writes back; post_transfer_journal_entry (insurance split)
  Payment Entry ── partial/full ── status Unpaid→Partly Paid→Paid

INSURANCE (fully native)
  Patient Insurance Policy (needs active Insurance Payor Contract)
    → Patient Insurance Coverage (eligibility rule → coverage% → patient_payable vs coverage_amount)
    → invoice split → Journal Entry moves covered amount to payor's receivable
    → Insurance Claim aggregates coverages → payor Payment Entry closes them

INPATIENT (fully native, unused by us)
  admission order → Inpatient Record → admit → Inpatient Occupancy (bed → Occupied)
    → daily bed billables → discharge (blocks on unbilled) → Discharge Summary

RECORDS
  Global doc_events["*"] on_submit → Patient Medical Record timeline entry
    (Encounter, Lab Test, Clinical Procedure, Therapy Session, Vital Signs, Observation …)

SCHEDULER (fires automatically, no API needed)
  every-cycle: send_appointment_reminder (sets `reminded`)
  daily: update_appointment_status (past Open → No Show) · fee_validity status · inpatient billables
```

---

## 2. What Marley USES / IGNORES / REIMPLEMENTS / DIVERGES

This is the crux. Legend: ✅ **uses core as-is** · ♻️ **reimplements over core** · 🚫 **ignores core capability** · ⚠️ **diverges / fights core**

| Core subsystem | Marley | Notes & risk |
|---|---|---|
| **Masters** (Practitioner, Schedule, Service Unit, Appointment Type) | ✅ uses | We read/compose them. `providers`/scheduling APIs sit on top. Fine. |
| **Slot generation** (`get_availability_data`) | ♻️ reimplements | `appointments.get_available_slots` **ports** core slot logic rather than calling it. Risk: **logic drift** — if core's overlap/capacity rules change on upgrade, our port won't. Worth a note to re-sync on Healthcare upgrades. |
| **Appointment create** | ✅ uses core doctype | We insert `Patient Appointment` and let core `validate()`/`set_status()` run. Good — status, overlap, datetime all core. |
| **Status writes / check-in** | ⚠️ diverges | We use `frappe.db.set_value` (not `doc.save()`) for status + `custom_checked_in_at`. **Bypasses core `validate()` AND `set_position_in_queue()`** → the native queue (`position_in_queue`, `appointment_based_on_check_in`) is **not populated**; our dashboard queue is our own logic. Also skips the change-log (audit thinness — see backend gap B7). |
| **Fee Validity** (free follow-up) | 🚫 off / unused | `enable_free_follow_ups=0`. Engine dormant. If pediatrics ever wants "control visit free within N days," this is **native and free** — we'd just flip the flag rather than build it. |
| **Auto-invoicing** (`show_payment_popup`) | ⚠️ deliberately off, reimplemented | We own invoicing in `billing/api.py` (consolidated POS checkout, pay-now booking). Coherent, but means we **re-solve** what core's popup does. |
| **Billable discovery** | ✅ uses core | `get_patient_billables` → core `get_healthcare_services_to_invoice` (+ our immunization append). Good — billing discovery stays core-aware, including Service Request `billing_status`. |
| **Invoice write-back / double-bill guard** | ✅ uses core | We rely on core `Sales Invoice.on_submit → set_invoiced` + `validate_invoiced_on_submit`. Sound. |
| **Encounter → order layer** (Service/Medication Request) | ✅ uses core (implicitly) | `complete_encounter` → `doc.submit()` fires core `on_submit`, which **auto-spawns Service Requests + Medication Requests + Therapy Plan**. We get the order layer for free. |
| **Labs** | ♻️ hybrid | `create_lab_order` creates a **Lab Test directly** from template (bypassing Service Request), but `list_pending_lab_orders`/`record_result` are **Service-Request-anchored** (they read the SRs encounter-submit spawned, and create the Lab Test from the SR if needed). Two creation paths coexist — worth confirming they don't produce duplicate/orphan Lab Tests for the same order. |
| **Clinical Procedure / Therapy / Observation / Diagnostic Report** | 🚫 largely unused | Not surfaced in our API. Fine for pediatric OPD, but these are rich native flows (stock-consuming procedures, therapy plans, structured observations) we could adopt instead of building. |
| **Nursing Tasks** | 🚫 read-only-ish | We *display* Nursing Tasks in `get_patient_clinical_activity` but don't drive the checklist workflow. Native generates them from templates on procedure/lab/therapy creation. |
| **Patient → Customer** | ✅ core (backstopped) | `link_customer_to_patient=1` → core creates the Customer; our `_ensure_patient_customer` only repairs gaps. No divergence, mild redundancy. |
| **Patient Medical Record timeline** | 🚫 ignored / reimplemented | Core auto-populates a unified timeline via the `*` hook. Our `get_patient_clinical_activity` **does not read it** — it hand-queries Clinical Procedure + Nursing Task + Encounter/Clinical Notes. Risk: our feed is a **partial, hand-maintained subset**; new doctypes won't appear automatically the way they do in the native timeline. Adopting `Patient Medical Record` would give a complete, auto-maintained history. |
| **Insurance** (Policy/Coverage/Payor/Claim + JE split) | ♻️ partial — uses coverage, ignores claims | We use core policy + coverage + the invoice split JE (real, working). But `insurance/api.py` exposes **only policy CRUD + payor list** — **no `Insurance Claim`** (aggregate coverages → bill payor → reconcile payor payment). The whole **payor-billing back-end of the revenue cycle is native and unused.** Biggest untapped core capability. |
| **Inpatient** (Record/Occupancy/bed billing/discharge) | 🚫 unused | No inpatient API. Correct for an OPD pediatric product; note it exists if scope ever expands. |
| **Registration fee gate** | 🚫 off | `collect_registration_fee=0`; we create patients Active. Fine. |
| **Scheduler: appointment reminders** | ⚠️ gap | Core has `send_appointment_reminder` (sets `reminded`) driven by `Healthcare Settings` reminder fields. It appears **not configured** (frontend gap G9: reminders are manual). This native job could power reminders with config, not code. |
| **Scheduler: daily No-Show** | ✅ core | `update_appointment_status` flips past Open appointments to No Show daily. We inherit it. |

---

## 3. The divergences that carry real risk

Ranked. These are where "we reimplemented / ignored core" could bite.

1. **Native check-in queue is bypassed (⚠️).** Because status is written via `frappe.db.set_value`, core never runs `set_position_in_queue()`. If we ever want a true ordered queue (position numbers, check-in-based ordering), we're building it ourselves — core already has `position_in_queue` + `appointment_based_on_check_in`. **Decision needed:** adopt native queue vs. keep our dashboard-derived one.

2. **Patient Medical Record timeline ignored (🚫).** We maintain a partial activity feed by hand. The native timeline is complete and auto-updated. As we add doctypes (immunizations, vitals, labs), our feed needs manual extension while the native one would already have them. **Recommend:** back the Patient 360 "activity/history" on `Patient Medical Record`.

3. **Insurance claims unused (♻️/🚫).** We split invoices with insurers correctly but have **no way to bill the payor and reconcile their payment** — the native `Insurance Claim` flow does exactly this and is fully built. For an India/Mexico product with real payors this is a **major revenue-cycle gap hiding in plain sight** (it's built in core, just not surfaced). Ties to frontend G3 (insurance UI is a placeholder).

4. **Slot logic is a port, not a call (♻️).** `get_available_slots` duplicates core's availability algorithm. On any Healthcare upgrade that changes overlap/capacity semantics, our copy silently drifts. **Recommend:** either call core `get_availability_data` or add a CI check that flags core changes to that function.

5. **Labs dual creation path (♻️).** Direct Lab Test creation + Service-Request-anchored creation coexist. Confirm one order can't yield two Lab Tests (once direct, once from the SR). Low probability, worth a targeted test.

6. **Fee Validity & appointment Insurance Coverage fire silently (⚠️).** With `show_payment_popup=0`, core's `after_insert`/`on_update` run `make_insurance_coverage` (when a policy is attached) and the fee-validity branch. Free-follow-ups are off so validity is inert, but **insurance coverage IS being auto-created on insured appointments** — make sure that's intended and not double-creating against our own insurance handling.

---

## 4. What core gives us for free that we're NOT using (opportunity list)

- **Insurance Claim** revenue cycle (payor billing + reconciliation) — built, unused. *(highest value)*
- **Patient Medical Record** unified auto-timeline — built, ignored.
- **Fee Validity** free-follow-up windows — built, off. Pediatric "control visit free within N days" is one flag.
- **Native check-in queue** (`position_in_queue`) — built, bypassed.
- **Appointment reminders** scheduler — built, unconfigured (frontend G9).
- **Nursing Task** checklists, **Clinical Procedure** stock consumption, **Therapy Plan** sessions, **Observation/Diagnostic Report** structured results — built, unused (adopt if scope grows).
- **Inpatient** admission→discharge→bed-billing — built, unused (out of current scope).

---

## 5. Recommendation (for discussion — not committed)

We are, on balance, **composing core well** on the money spine (billing discovery, write-back, insurance split, order layer via encounter submit). The concerning pattern is a handful of places where we **hand-rolled a subset of something core already does completely** — check-in queue, the activity timeline, and (by omission) insurance claims.

Suggested next decisions:
1. **Insurance claims** — decide whether to surface the native `Insurance Claim` flow (backend + the placeholder frontend G3). Highest untapped value.
2. **Patient 360 history** — repoint the activity feed at `Patient Medical Record` so it's complete and self-maintaining.
3. **Check-in queue** — pick one: adopt native `position_in_queue` or formally own it in our dashboard (and document that core's queue is intentionally unused).
4. **Slot-logic drift guard** — CI check or switch to calling core.
5. Confirm the **silent insurance-coverage auto-creation** on insured appointments is intended.

None of this is urgent breakage — it's "build with the engine, not beside it." I have **not changed any code**; this is analysis.

---

*Companions: `OPD_BACKEND_FLOW_AND_GAPS.md` (our app chain, gaps B1–B11) · `FRONTDESK_CHARTER_AND_GAPS.md` (front-desk role, gaps G1–G11).*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
