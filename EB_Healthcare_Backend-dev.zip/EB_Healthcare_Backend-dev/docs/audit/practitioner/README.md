# Practitioner (Doctor) Role Audit — `EB_Practitioner` (index + charter)

**Doc status:** living · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.1
**Frontend:** `Healthcare_next_app` · **Backend:** `EB_Healthcare_Backend` (Frappe v16 / ERPNext Healthcare)
**Role under audit:** Practitioner / Physician (`EB_Practitioner` → frontend `practitioner`) — **the signer.** The clinical decision-maker who owns the encounter, diagnoses, prescribes, and finalizes.
**Started:** 2026-07-09 · **Method:** deep-dive backend first, then one screen per turn — same as the front-desk and nurse audits.

> ## ★ Guiding principle — the physician is in control, and what they sign must be real
> The doctor is the clinical authority (CLAUDE.md Rule 6): AI suggests, the nurse preps, but **the physician reviews, decides, and signs.** Everything they act on must be **real data** — a fabricated allergy, a mock medication list, or an AI "risk" they can't distinguish from truth is a **patient-safety** defect, ranked above everything cosmetic. The physician's two unique powers — **sign the encounter** and **prescribe** — must be backed end-to-end, not mocked.

## Who the Practitioner is
**Persona — "Doctor / Médico."** Sees the patient in the practitioner room, reviews intake (vitals/labs/history the nurse prepped), documents the encounter (SOAP), orders labs/procedures/therapies, **prescribes**, **signs** the note (which spawns the order layer), finalizes lab readings, and can collect the visit payment from the chart. The apex clinical role — full chart access, full authoring, sign authority.

**Three jobs:**
1. **Decide & document** — review intake, author the encounter, diagnose.
2. **Order & prescribe** — labs/procedures/therapies + medications (physician-only route).
3. **Finalize** — sign the encounter (order-layer spawn), finalize lab results.

## Practitioner capability & gating baseline (verified 2026-07-09)
- **Frontend role:** `EB_Practitioner` → `RoleId "practitioner"` (`roles.ts`).
- **Capabilities (`mergeCapabilities`):** `startEncounter · collectPayment` = **true**; `newAppt · confirm · checkIn · markReady · canEditEncounterDraft · rescheduleCancel · reassign · noShow · invoices` = **false**.
  - `startEncounter=true` + `canEditEncounterDraft=false`: the doctor **owns/signs** the encounter (not the nurse's "draft-only" path). `canSign = practitioner || admin` (encounters/[id]/page.tsx).
  - `collectPayment=true`: **the doctor can create/collect the visit invoice from the chart** — unusual for a physician; flag for review.
- **Action defaults (`permissions-store.practitioner`):** `vitals · startencounter · readycheckout · sendbacktonurse` = true; `checkin · reschedule · cancel · noshow · movetoroom · collectpayment` = false.
- **Routes (`route-access.ts`):** `/encounters`, `/labs`, **`/medications` (practitioner + admin only)** — the physician-exclusive route; plus shared dashboard/patients/appointments/inbox. No billing/cash/settings nav.
- **Chart (`chart-permissions.ts`):** `sections:{}`, `subtabs:{}` → **full access to every tab**; overview flags **`showRiskBanner: true`, `showAiInsights: true`** — the fabricated AI surfaces are **deliberately ON for the doctor** (the C1/C5 concern lands hardest here).
- **Server authority:** the physician-only gates — `complete_encounter` (`_require_assigned_practitioner_or_admin`), `submit_lab_result` (`Lab Test submit`) — are what make this role the signer.

## Screen inventory & status
Ordered by the physician's flow.

| # | Area | Screen | File | Status |
|---|---|---|---|---|
| 1 | Home | Dashboard — practitioner room / my patients | [screens/01-dashboard.md](../../_archive/audit-screens/practitioner/01-dashboard.md) | ✅ **audited** — "what a doctor sees first"; PD1–PD5 |
| 2 | Patients | Patient Chart 360 (full clinical + AI surfaces) | 02-patient-chart.md | ⬜ pending |
| 3 | Clinical | Encounter authoring + **sign** (SOAP, dx, orders) | [screens/03-encounter.md](../../_archive/audit-screens/practitioner/03-encounter.md) | ✅ **audited** — sign gated OK; PE1 (fake AI) · PE2 (vitals) |
| 3b | Clinical | **Encounter — full forensic code audit (2026-08-20)** | [screens/03-encounter-deep-audit.md](../../_archive/audit-screens/practitioner/03-encounter-deep-audit.md) | ✅ **audited** — supersedes row 3's findings. Fabricated clinical data, consent bypass, Rx interval loss, pediatric thresholds. Target design: the 3-step flow, [ADR-050](../../adr/adr-054-three-step-encounter-flow-reusing-v1-components.md) — see [`ENCOUNTER_V3.md`](../../architecture/ENCOUNTER_V3.md) and [`ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md`](../../architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md). The consent-bypass finding here is fixed as of 2026-08-26 (see `STATUS.md` P0-2) |
| 4 | Clinical | Prescriptions / Medications (physician-only route) | [screens/04-medications.md](../../_archive/audit-screens/practitioner/04-medications.md) | ✅ **audited** — PM1 (`/medications` mock) · PM2 (Rx placeholder) |
| 5 | Clinical | Labs — review + **finalize** results | [screens/05-labs.md](../../_archive/audit-screens/practitioner/05-labs.md) | ✅ **audited** — PL1 (results-to-review) |
| 6 | Clinical | Orders (labs/procedures/therapies from encounter) | [screens/06-orders.md](../../_archive/audit-screens/practitioner/06-orders.md) | ✅ **audited** — PO1 (order tracking) |
| 7 | Patients | Patient list / my panel | [screens/07-patients.md](../../_archive/audit-screens/practitioner/07-patients.md) | ✅ **audited** — PP1 (my panel filter) |
| 8 | Work | My Work — unsigned notes / results to review | [screens/08-my-work.md](../../_archive/audit-screens/practitioner/08-my-work.md) | ✅ **audited** — PW1 (clinical inbox) |
| 9 | Comms | Notifications / Messages | [screens/09-notifications.md](../../_archive/audit-screens/practitioner/09-notifications.md) | ✅ **audited** — PN1 (notif hidden) |

**✅ ALL 9 PRACTITIONER SCREENS AUDITED (2026-07-09).** Decision sheet + hand-offs: [screens/DECISION_SHEET.md](../../_archive/audit-screens/practitioner/DECISION_SHEET.md) · [screens/BACKEND_HANDOFFS.md](../../_archive/audit-screens/practitioner/BACKEND_HANDOFFS.md). Headline: the **sign + finalize authority is correctly the physician's and well-gated**, but the *support surfaces are fake or missing* — **PR1 fabricated AI ON for the doctor (critical)**, **PR2 `/medications` fully mock**, **PD2/PW1 no clinical inbox**. The doctor doesn't need more screens — the ones they have must show true data and never lose an un-signed note or abnormal result.

## Cross-screen findings (P-series; reuse FD/NU where shared)
- **PR1 — Fake AI surfaces ON for the doctor (SAFETY):** `chart-permissions.practitioner.overview` sets `showRiskBanner:true` + `showAiInsights:true` — the `patHash`-fabricated "High Readmission Risk" + AI insights render for the clinical decision-maker. Worst possible audience for fake clinical data; also a "no AI before Phase 5" violation (shared C1/C5).
- **PR2 — `/medications` is fully mock:** the physician-only medications screen renders `MEDICINE_MASTER` (hardcoded array, **0 API calls**) — not `list_medications`. A doctor's drug reference/formulary is fake.
- **PR3 — `/prescriptions` is a "coming soon" placeholder** — prescribing exists only inside the encounter (drug_prescription child table); there's no standalone prescription management.
- **PR4 — `collectPayment=true` for the physician** — doctor can invoice/collect from the chart; confirm this is intended (role-bleed vs. deliberate small-clinic flow).
- (Reuse **NL1**: labs finalize — confirm the physician *does* hold `Lab Test submit` and nurse/FD don't; **NV1** vitals binding affects what the doctor signs.)

## Related docs (backend already deep-traced — build on, don't re-trace)
- **`../frontdesk/OPD_BACKEND_FLOW_AND_GAPS.md`** — OPD chain: encounter submit → Service/Medication Request spawn, labs, vitals binding (B1).
- **`../frontdesk/CORE_HEALTHCARE_FLOW_AND_MARLEY_MAP.md`** — native encounter→order-layer, Patient Medical Record, uses/ignores map.
- **`../nurse/`** — the handoff partner (nurse preps the draft the doctor signs; ADR-022).
- ADR-019 (encounter native binding), ADR-022 (nurse draft vs physician sign), Rule 6 (physician-in-control).

## Decision sheet & backend hand-offs
`screens/DECISION_SHEET.md` + `screens/BACKEND_HANDOFFS.md` (PR-BH-*) added once screens are audited.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-25 | Satyakam (AI-assisted) | Links repointed: session transcripts and screen audits moved to `docs/_archive/` |
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |

<!-- BEGIN GENERATED INDEX -->

_0 document(s) in this directory. Generated by `scripts/gen_doc_indexes.py` — do not edit by hand._

<!-- END GENERATED INDEX -->
