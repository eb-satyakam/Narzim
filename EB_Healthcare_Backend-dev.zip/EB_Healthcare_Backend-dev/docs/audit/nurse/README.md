# Nurse Role Audit — `EB_Nurse` (index + charter)

**Doc status:** living · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-09-25 by Satyakam (AI-assisted) · **Version:** 1.1
**Frontend:** `Healthcare_next_app` · **Backend:** `EB_Healthcare_Backend` (Frappe v16 / ERPNext Healthcare)
**Role under audit:** Nurse (`EB_Nurse` → frontend `nurse`) — the clinical intake role that runs the Nursing Room.
**Started:** 2026-07-09 · **Method:** deep-dive the backend flow first, then one screen per turn with REAL/MOCK/MISSING wiring — same method as the front-desk audit (`../frontdesk/screens/README.md`).

> ## ★ Guiding principle — safe clinical intake, physician-in-control
> The nurse captures the clinical facts that the visit turns on — **vitals, labs, immunizations** — and preps the encounter, but **never signs it**. Every value she records must be persisted to the right clinical record and **bound to the correct encounter/patient** (no same-day cross-linking), and every clinical decision stays with the physician (CLAUDE.md Rule 6). "Mock / fabricated / mis-bound clinical data" is not an acceptable end state — it is a **patient-safety** gap, ranked above cosmetic ones.

## Who the Nurse is
**Persona — "Enfermera / RN."** She owns the **Nursing Room**: greets the checked-in patient, records vitals, draws labs / records results, administers immunizations on the Mexico EPI schedule, drafts the clinical note, and **marks the patient ready for the provider**. She is clinical but **not the signer** — the physician owns diagnosis, prescription, and the signed encounter.

**Three jobs:**
1. **Capture accurate clinical intake** — vitals (with BMI/BP), labs, immunizations — bound to the right visit.
2. **Advance the clinical queue** — check-in → nursing room → mark ready for provider.
3. **Prep the encounter** — open/save a draft the physician completes and signs.

## Nurse capability & gating baseline (verified 2026-07-09)
- **Frontend role:** `EB_Nurse` → `RoleId "nurse"` (`src/lib/narzim/roles.ts`).
- **Capabilities (`mergeCapabilities`):** `checkIn · markReady · canEditEncounterDraft` = **true**; `newAppt · collectPayment · confirm · startEncounter · rescheduleCancel · reassign · noShow · invoices` = **false**.
  - **ADR-022:** nurse may open + save an encounter **draft** (`canEditEncounterDraft`) but **cannot sign/submit** (`startEncounter=false`; `complete_encounter` requires the assigned practitioner).
  - **ADR-020:** nurse administers/records vaccines (nurse-administration handoff).
- **Routes (`route-access.ts`):** nurse-allowed clinical routes `/encounters`, `/labs`; shared `dashboard`, `patients`, `appointments`, `inbox`. **`billing` + `cash` are NOT in nurse nav** (revenue is front-desk/admin). Reports only with `can_view_reports`.
- **Nav (`buildNav`):** Dashboard · My Work · Patients · Appointments (+ clinical routes). **No Billing, no Cash, no Settings.**
- **Chart (`chart-permissions.ts`):** nurse **hides `financial` section + `summary` subtab** → lands on Appointments; sees clinical tabs (Vitals, Lab Test, Medications, Immunizations, History, Documents) and gets the **`overview-nurse`** overview.
- **Server authority:** `require_permission()` per doctype; nurse has Patient Appointment write (status), Patient Encounter create (draft), Vital Signs / Lab Test / Immunization write. The physician-only gate on `complete_encounter` is the safety boundary.

## Screen inventory & status
Ordered by the nurse's clinical flow.

| # | Area | Screen | File | Status |
|---|---|---|---|---|
| 1 | Home | Dashboard — Nursing Room queue | [screens/01-dashboard.md](../../_archive/audit-screens/nurse/01-dashboard.md) | ✅ **audited** — ND1–ND5 |
| 2 | Patients | Patient List (nurse lens) | [screens/02-patients-list.md](../../_archive/audit-screens/nurse/02-patients-list.md) | ✅ **audited** — NP1 (age), no create |
| 3 | Patients | Patient Chart 360 (nurse overview + clinical tabs) | [screens/03-patient-chart.md](../../_archive/audit-screens/nurse/03-patient-chart.md) | ✅ **audited** — NC1 (record-vitals stub) · NC2 (AI banner) |
| 4 | Clinical | Vitals entry (BMI/BP, encounter binding) | [screens/04-vitals.md](../../_archive/audit-screens/nurse/04-vitals.md) | ✅ **audited** — NV1 (safety) · NV2 (fake growth curves) |
| 5 | Clinical | Lab collection / results | [screens/05-labs.md](../../_archive/audit-screens/nurse/05-labs.md) | ✅ **audited** — NL1 (finalize-perm) · NL2 (dual path) |
| 6 | Clinical | Immunizations (administration, Mexico EPI) | [screens/06-immunizations.md](../../_archive/audit-screens/nurse/06-immunizations.md) | ✅ **audited** — NI1 (allergy check) · NI2 (lot/expiry) |
| 7 | Clinical | Encounter draft (open/save, no sign — ADR-022) | [screens/07-encounter-draft.md](../../_archive/audit-screens/nurse/07-encounter-draft.md) | ✅ **audited** — sign gate double-enforced; NE1 draft scope |
| 8 | Appointments | Appointments (nurse: check-in / mark ready) | [screens/08-appointments.md](../../_archive/audit-screens/nurse/08-appointments.md) | ✅ **audited** — NA1 (list check-in) |
| 9 | Work | My Work / Nursing tasks | [screens/09-my-work.md](../../_archive/audit-screens/nurse/09-my-work.md) | ✅ **audited** — NW1 (clinical worklist) |
| 10 | Comms | Notifications / Messages (shared) | [screens/10-notifications.md](../../_archive/audit-screens/nurse/10-notifications.md) | ✅ **audited** — NN1 (notif hidden) |
| 11 | Clinical | Nursing Tasks & Healthcare Activities (workflow) | [screens/11-nursing-tasks.md](../../_archive/audit-screens/nurse/11-nursing-tasks.md) | ✅ **audited** — NT1 ✅ built · NT2 gated · NT3/NT4 |

**✅ ALL 11 NURSE SCREENS AUDITED** (screens 1–10: 2026-07-09; screen 11 added + refreshed 2026-07-10). Headline: the **safety gates that exist are well-built** (encounter sign double-enforced, labs record≠finalize, immunization handoff) — but the real risks are clinical: **NV1 vitals mis-binding (critical)**, **NV2 fake growth curves**, **NL1 confirm labs-finalize permission**, **NE1 scope nurse draft authoring**, and the missing **nurse clinical worklist (NW1)**.

> **Refresh note (2026-07-10):** the **nursing-task workflow UI (NT1)** and **Healthcare Activity screen (NT2)** — both flagged as absent when screen 11 was first written — have since been **built** (frontend branches `feat/nursing-worklist` `6c22a9a` + Nursing Activities settings `a53af13`, not yet on `main`). The dedicated `/nursing` worklist now drives Start/Complete against `update_nursing_task_status`, which **partially closes NW1** (real *assigned-task* worklist exists; the *proactive clinical due-item* feed — vitals-pending / vaccines-due / labs-to-draw — is still missing). See screen 11 and the DECISION_SHEET for the reconciled status.

## Cross-screen findings (recurring patterns — N-series, reuse FD-series where shared)
_Logged as they recur. Patient-safety items rank above cosmetic._
- **NU1 — Vitals mis-binding (SAFETY):** vitals bind to an encounter by a **same-patient/same-day heuristic** (`_link_vitals_to_encounter`), risking cross-link on a patient with two same-day visits / walk-ins (backend gap **B1** from the front-desk OPD trace). Highest-priority clinical-integrity item.
- **NU2 — Labs dual creation path:** direct Lab Test create vs Service-Request-anchored (`create_lab_order` vs `record_result`) can duplicate/orphan (labs audit; FD OPD trace).
- **NU3 — Physician-in-control boundary:** verify nowhere lets a nurse sign/finalize (ADR-022) — the safety gate.
- (Reuse FD1 fabricated-`patHash`, FD2 built-but-commented, FD4 placeholder demographics, FD6 hardcoded i18n as they appear on shared screens.)

## Related docs (the backend flow is already deep-traced — read alongside)
- **`../frontdesk/OPD_BACKEND_FLOW_AND_GAPS.md`** — the OPD backend chain incl. vitals binding (B1), labs, immunization billing, encounter draft/submit. **The nurse audit builds on this, not a re-trace.**
- **`../frontdesk/CORE_HEALTHCARE_FLOW_AND_MARLEY_MAP.md`** — native core clinical flow (encounter → Service/Medication Request order layer, Nursing Tasks, Patient Medical Record) + uses/ignores/reimplements.
- ADR-019 (encounter native binding), ADR-020 (vaccine nurse-administration handoff), ADR-022 (nurse encounter draft write), ADR-017 (queue-derived handoff state).

## Decision sheet & backend hand-offs
- **[screens/DECISION_SHEET.md](../../_archive/audit-screens/nurse/DECISION_SHEET.md)** — every gap tiered with recommendations; includes the deep answer to *"do we need more nurse options?"* (mostly no — fix & complete, don't widen).
- **[screens/BACKEND_HANDOFFS.md](../../_archive/audit-screens/nurse/BACKEND_HANDOFFS.md)** — `NU-BH-1…8`, verified against the backend. **NU-BH-3 is a CONFIRMED bug** (nurse + front desk both hold `Lab Test submit` → Rule 6 unenforced).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.1 | 2026-09-25 | Satyakam (AI-assisted) | Links repointed: session transcripts and screen audits moved to `docs/_archive/` |
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |

<!-- BEGIN GENERATED INDEX -->

_1 document(s) in this directory. Generated by `scripts/gen_doc_indexes.py` — do not edit by hand._

| Document | Status | Updated | Title |
|---|---|---|---|
| [`PLAN_NURSE_PROCEDURE_BILLING.md`](PLAN_NURSE_PROCEDURE_BILLING.md) | record | 2026-07-10 | Plan — Nurse "Record Procedure Done → Bill" (dressing, injection, nebulizat… |

<!-- END GENERATED INDEX -->
