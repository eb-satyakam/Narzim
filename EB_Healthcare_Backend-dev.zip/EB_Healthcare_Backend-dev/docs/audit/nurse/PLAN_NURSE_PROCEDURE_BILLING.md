# Plan — Nurse "Record Procedure Done → Bill" (dressing, injection, nebulization)

**Doc status:** record · **Created:** 2026-07-10 by Invincible · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** Draft for sign-off · **Date:** 2026-07-10 · **Area:** Clinical + Billing (Phase 3/4)
**Companion ADR:** [adr-024-nurse-initiated-billable-procedure.md](../../adr/adr-024-nurse-initiated-billable-procedure.md)
**Origin:** nurse-workflow question — "a nurse does a dressing in-house; how does front desk learn it must be billed?"

> **Answer in one line:** the billing cart *is* the handoff. The nurse records the procedure and marks it done; a completed, billable Clinical Procedure auto-appears in front desk's cart. No chat/note. Today this is blocked by two walls (below).

## 1. Context
- **Phase:** 3/4 (Billing + Operations). **Exit gate:** a nurse-performed billable service reaches front desk's cart with no manual message.
- Verified live 2026-07-10 (`remedisys.localhost`).

## 2. What already exists — do NOT rebuild
- **Backend lifecycle:** `create` / `submit` / `start` / `complete` / `cancel` `_clinical_procedure` in `api/v1/procedures/api.py` — full and working.
- **Nurse permission:** `EB_Nurse` has read/write/create/submit on `Clinical Procedure` (verified in Custom DocPerm).
- **Standalone supported:** `create_clinical_procedure` requires only **patient + procedure_template**; `appointment`/`encounter` are optional → a walk-in dressing with no doctor visit is allowed.
- **Cart auto-pickup:** native `get_clinical_procedures_to_invoice` bills any Clinical Procedure with `docstatus=1`, `invoiced=0`, and template `is_billable=1`; already wired into `get_patient_billables`.

## 3. The two walls (verified)
| # | Wall | Evidence | Fix |
|---|---|---|---|
| W1 | **The whole "record/complete a procedure" lifecycle is unreachable from the app** — the only procedure BFF route is `list_procedure_templates`. No create/submit/complete route or UI exists (for anyone, not just the nurse). The doctor's encounter only *orders* procedures; My Work only *displays* them read-only; the nursing worklist has zero procedure handling. | `find src/app/api -ipath "*procedure*"` → templates only; grep for `create_/complete_clinical_procedure` across `src/` → none | New BFF routes + a nurse "Record procedure" action |
| W2 | **Every Clinical Procedure Template is `is_billable = 0`** (incl. the existing "Wound Dressing") — so even a completed procedure never reaches the cart. | live query of `Clinical Procedure Template` | Mark nurse-performable chargeable templates `is_billable=1` + priced Item, via seed/patch |

## 4. What to build
**A. Config (data/patch)** — mark the nurse-performable billable templates `is_billable=1` with a priced Item. Delivered as a repeatable seed/patch, not manual clicks. **Template list + prices: TO BE SUPPLIED (decision D4).**

**B. Backend (thin)** — one convenience wrapper `record_procedure_done(patient, procedure_template, notes?, ...)` = create → submit → complete in a single call (reuses existing functions; no new lifecycle logic). Idempotency guard against double-tap.

**C. Frontend** — BFF routes (`record_procedure_done`, `list_clinical_procedures`); a "Record Procedure" action (template picker + notes) on the nurse's surface (D1); a confirmation ("Wound Dressing recorded — sent to billing").

## 5. Decisions (see ADR-024 for the locked values)
| # | Question | Recommended (ADR default) |
|---|---|---|
| D1 | Where does the nurse trigger it? | **Nursing worklist (`/nursing`)** "＋ Record procedure" |
| D2 | One-step or multi-step? | **One-step** `record_procedure_done` (create+submit+complete) |
| D3 | Walk-in (no appointment) allowed? | **Yes** — front desk bills from the cart |
| D4 | Which templates billable + prices? | **TO BE SUPPLIED** (clinical) |
| D5 | Scope guard (Rule 6) | **Allow-list** nurse-performable procedures only |
| D6 | Reuse "billed externally" opt-out here? | **Later** (same pattern, separate slice) |

## 6. Risks
- **Double-billing** — double-tap creates two procedures → idempotency guard + visible/removable in cart.
- **`complete_procedure()` side effect** — core creates post-op Nursing Tasks from the template; keep nurse templates side-effect-light.
- **`is_billable` is global** — marking a template billable makes it chargeable everywhere (correct for a chargeable procedure; confirm none should be free).
- **Standalone customer link** — a walk-in must still resolve patient→customer at invoice time.
- **Rule 6 (physician-in-control)** — restrict the nurse picker to nurse-performable procedures; she must not order physician-gated procedures. (Precedent: ADR-020 vaccine nurse-administration.)

## 7. Rollout
1. ADR-024 + D1–D6 locked (D4 supplied).
2. Config seed (templates billable + priced).
3. Backend wrapper `record_procedure_done` + test.
4. BFF routes.
5. Nurse UI on the D1 surface + confirmation.
6. Live end-to-end verify: nurse records dressing → appears in front desk cart → billed.

## 8. Relationship to the "medication bought outside" gap
Different problem, same billing surface:
- **This plan:** *start* billing something a nurse performed (create the billable).
- **Medication opt-out (separate):** *stop* billing a prescribed drug the patient obtained elsewhere (`custom_billed_externally`, default 0). Not gated on `has_internal_pharmacy` — see [ADR-016] and the medication discussion.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-10 | Sarvesh | Initial version (header backfilled from git history) |
