# Help & Support — customer-experience audit: what a clinic user cannot do

**Doc status:** record · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

> A dated snapshot of the Help & Support request flow as shipped on
> `feat/helpdesk-integration` (`16002f7`), audited from the **clinic user's** point of view: what a
> doctor, nurse or front-desk person wants to *do* and cannot.
>
> **Companion, not a replacement.** The engineering audit
> [`2026-08-24-help-support-form-audit.md`](2026-08-24-help-support-form-audit.md) owns severity,
> effort and implementation findings. Where a gap appears in both, this document cites its ID
> (`A1`, `B1`, …) rather than restating it. Everything marked **NEW** is a customer-facing gap that
> audit did not capture, because it was written from the code outward instead of from the user inward.

---

## 1. The one-sentence verdict

**The form lets a clinician send a message. It does not let them report a problem.**

Everything the shipped form asks for — subject, description, a file — is what *support* needs to open
a record. Almost nothing it offers is what a *clinician* needs to feel heard, to convey urgency, or
to find out what happened next. Nine of the twelve things a clinic user would reach for are simply
not there.

| Journey stage | Options the user has | Options a clinic user expects |
|---|---|---|
| Before filing | none | search help, see known issues |
| While filing | 3 (subject, description, file) | ~10 |
| At submit | ticket number | reference, expected response, what happens next |
| After filing | **nothing** | see it, chase it, add to it, close it |

---

## 2. What already works, from the user's side

Worth stating, because the list below is long.

- **It is in the product.** No second login, no separate portal, no email address to remember.
- **It opens on the screen where the problem happened** — the drawer is reachable from every clinic
  page.
- **The language is human.** "What happened?" and "What you were doing, what you expected, and what
  happened instead" ask for the right thing without jargon.
- **It is honest about patient data.** The PHI warning appears exactly where the risk is taken.
- **It is bilingual**, `en` and `es-MX` in parity — for a Mexican clinic that is not a nicety.
- **It confirms.** A ticket number is shown, so the user knows something was created.

---

## 3. Stage 1 — Before filing

### C1 · NEW · Cannot search for an answer first
The drawer already shows route-specific help above the "Contact support" link, but there is **no
search**, and the app's `/guide` page is not reachable from here. A user who could have self-served in
ten seconds files a ticket instead.

**Why it matters commercially:** every deflected ticket is support cost you do not pay. This is the
single cheapest lever in the whole flow.

### C2 · NEW · Cannot see whether it is already a known issue
If the lab list is down for everyone, forty staff file forty tickets and none of them learn that it is
known and being worked on.

---

## 4. Stage 2 — While filing

### C3 · Cannot say how urgent it is
*Engineering audit `A1`.* From the user's side the feeling is specific: **"I am telling you my clinic
is stopped and the form does not care."** Every ticket leaves at the same priority.

### C4 · Cannot say what kind of problem it is
*Engineering audit `A3`.* A user cannot distinguish "this is broken", "I do not know how to do this",
"this is wrong data", "I want to suggest something". Those need different people and different
response times, and the form flattens them into one.

### C5 · NEW · Cannot say who it affects
"Only me on this laptop" and "every nurse in the clinic since this morning" are the same ticket today.
Blast radius is the second thing any triager asks, after severity.

### C6 · NEW · Cannot flag patient-safety impact — **healthcare-specific**
There is no way to say *"this is affecting patient care right now"*. A prescription that will not save
during a paediatric consult is not the same class of problem as a misaligned button, and in a clinical
product that distinction deserves to be first-class rather than buried in prose.

**Why this is the most important NEW gap:** it is the one where the cost of getting triage wrong is
measured in patients, not minutes. It also gives the clinic something auditable to point at.

### C7 · NEW · Cannot say when it started or how often
"Since the update this morning" and "it happens every third save" are the two facts that make a bug
reproducible. Nothing asks, so most users will not think to say.

### C8 · Cannot paste a screenshot
*Engineering audit `B1`.* From the user's side: the keyboard shortcut they already use puts the image
on the clipboard, and the form cannot take it. They must save a file, find it, and browse — or give
up, which is what most people do.

### C9 · NEW · Cannot record the screen
A layout that breaks, a dropdown that closes, a spinner that never stops — a still image cannot show
any of them. A short screen recording is the difference between "cannot reproduce" and a fix.

### C10 · NEW · Cannot record a voice note
Explicitly descoped from the slice, and listed here because from the user's side it is a **missing
option, not a missing feature**: mid-clinic, a doctor can say in fifteen seconds what they will not
stop to type. The backend already accepts the audio formats; only the recorder is absent.

### C11 · NEW · Cannot annotate or redact a screenshot
Two needs in one control. **Annotate:** circle the thing that is wrong, so the agent looks at the
right corner. **Redact:** black out the patient's name before sending — today the only options are
"send the chart as-is" or "do not send evidence at all", which is a poor choice to hand a clinician
who has just been warned about PHI.

### C12 · NEW · Cannot ask to be called back
No phone number, no "call me" option, no preferred-contact choice. For an urgent clinical problem the
fastest channel is a phone, and the form pushes everything into text.

### C13 · NEW · Cannot file on behalf of a colleague
Front desk routinely reports what a doctor is experiencing. The ticket will be attributed to the
person who typed it, so support replies to the wrong human.

---

## 5. Stage 3 — At submit

### C14 · NEW · Does not say when anyone will respond
An SLA **is** attached to every ticket (`response_by` is set — verified on ticket `0006`), and the
user is never shown it. The one question every person asks after clicking Send — *"when will someone
look at this?"* — is answered by data we already have and do not display.

### C15 · NEW · Does not say what happens next
No "support will reply here", no "you will get a notification", no "we may call you". The user is left
to guess whether anything will happen at all.

### C16 · NEW · No reference the user can quote
A number appears on screen and is gone when the drawer closes. Nothing is emailed, nothing is stored
in the app, so a user phoning to chase cannot say which request they mean.

---

## 6. Stage 4 — After filing

**This entire stage does not exist.** *Engineering audit `C1` records the gap; the user-facing
consequences are worth spelling out.*

### C17 · Cannot see their own requests
No list, no status, no history. A clinician cannot answer "did I already report this?".

### C18 · NEW · Cannot see or send a reply
Helpdesk agents reply on the ticket. Those replies land where no clinician is looking, and the user
has no way to answer a question the agent asks — which is how tickets stall and get closed unresolved.

### C19 · NEW · Cannot add information later
"It just happened again, here is another screenshot" requires filing a **second ticket** today.

### C20 · NEW · Cannot reopen, close or rate
`HD Ticket` carries a `feedback` field Helpdesk uses for satisfaction. The user can neither say "this
is fixed, thank you" nor "this was closed and it is still broken".

### C21 · NEW · Is not notified of anything
The app already has `/notifications` and `/inbox` for staff. Support uses neither, so the loop is
closed only by the user going to look — and there is nowhere to look.

---

## 7. Cross-cutting

### C22 · NEW · Nothing is designed for mid-consult use
The realistic moment of use is a doctor with a patient in the room. Today's flow is: open menu →
Help → read → Contact support → type a subject → type a description → find a file → send. Nobody does
that with a patient waiting; they phone a colleague instead, and the problem never gets recorded.

### C23 · NEW · The draft is lost if anything interrupts
*Engineering audit `B6`.* In clinic terms: the patient asks a question, the drawer closes, the report
is gone. Interruption is the normal case here, not the exception.

### C24 · NEW · No indication that Spanish is understood
An `es-MX` user writes Spanish into a form whose UI is Spanish. Nothing tells them whether support
reads Spanish, and nothing tags the ticket's language for routing.

---

## 8. What a redesign should reuse rather than build

The app already owns most of the surfaces these gaps need. A redesign that adds new ones would be
duplicating.

| Need | Existing surface |
|---|---|
| Search before filing (C1) | the help drawer's route-keyed content + the `/guide` page |
| My requests (C17) | `/inbox` — already the staff work list |
| Replies and notifications (C18, C21) | `/notifications`, and the Portal Chat pattern (ADR-037) already does staff↔patient threads |
| Priority, type, feedback, SLA (C3, C4, C14, C20) | **native `HD Ticket` fields** — nothing to build backend-side, they are simply not exposed |
| Voice note (C10) | the backend already accepts `webm`/`m4a`/`ogg`/`wav` |

**Six of the twenty-four gaps need no new backend at all** — they are native Helpdesk fields the form
does not surface.

---

## 9. The customer's priority order

Deliberately different from the engineering audit's, which sequenced by risk and effort. This
sequences by what a clinic user would notice first.

| Rank | Gap | Why it is first |
|---|---|---|
| 1 | **C6 patient safety** + C3 urgency | The only gaps whose cost is clinical, not operational |
| 2 | **C17–C21 the whole after-filing stage** | Without it users stop trusting the channel, and then stop using it |
| 3 | **C8 paste** + C9 screen recording + C11 redact | Determines whether usable evidence ever arrives |
| 4 | **C14–C16 expectations at submit** | Cheap, and it is the difference between confidence and doubt |
| 5 | **C1–C2 deflection** | Lowest cost per ticket avoided |
| 6 | C10 voice, C12 call-back, C22 speed | The mid-consult reality, and the hardest to design well |
| 7 | C5, C7, C13, C23, C24 | Real, and safe to do later |

---

## 10. Deliberate non-conclusions

- **No design is proposed here.** This audit says what is missing, not what to build. Four
  alternative designs are owed separately, per `CLAUDE.md` §10.
- **No code was changed.**
- **Two decisions still gate the after-filing stage** — the integration plan's §12 decision 1 (ticket
  read scope) and decision 3 (structured context) — because "my requests" is exactly the read-scope
  question in user-facing clothes.
- **Not validated with real users.** Every gap here is reasoned from the clinical workflow this repo
  documents, not from observing a clinician. That is the next cheapest thing worth doing, and it may
  reorder §9.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Audited the support flow from the clinic user's point of view: 24 gaps across four journey stages, 18 of them not captured by the engineering audit, prioritised by what a user notices first |
