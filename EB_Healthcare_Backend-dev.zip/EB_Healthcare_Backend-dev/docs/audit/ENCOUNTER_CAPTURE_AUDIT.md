# Audit — the encounter capture screen, A to Z

**Doc status:** living · **Created:** 2026-09-02 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-02 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 2.2

**This is the only audit document for this screen.** Measured on `marley.local`
on 2026-09-02, half by querying the database and half by reading the code. Every
number came from a real row or a real call.

**`living`, not `record`, and that was a deliberate change (v2.0).** It began as
a `record` — a frozen dated snapshot. It became a gap TRACKER the moment fixes
started landing against it, and `CLAUDE.md` §9 is explicit that a `record` is
never corrected. So the status changed rather than the rule being bent. The
obligation that comes with `living` is real: **when a gap below stops being true,
this document is wrong and fixing it is a bug, not housekeeping.**

Measurements keep their date. A number recorded on 2026-09-02 stays as it was
measured; only the gap's STATUS moves.

---

## 1. One page

```
Review the note
   │
   ├─ 1. resegregate-v1   who said which line     ~9s   rewrites transcript rows
   ├─ 2. soap-v1          write the note         ~17s   NEW draft row every press
   └─ 3. soap-gaps-v1     said but not written   ~12s   writes nothing
                                                  ────
                                                  ~39s
```

**Three LLM calls, serial.** A fourth step, `extract_transcript_vitals`, runs
alongside and uses **no model at all** — plain rules. Two more calls run later at
Fill Encounter.

**The screen mostly works.** Eight gaps below. Three could affect a patient; the
rest are cost, observability and one latent risk.

---

## 2. What happens, step by step

### Step 1 — Capture

```
consent asked → session created → Deepgram socket opens → mic streams
                                                              │
                                       words come back ───────┘
                                               │
                              every 20s the new lines are saved
```

| Table | When | By |
| --- | --- | --- |
| `AI Encounter Session` | Start, Stop | `api/ai/sessions.py` |
| `AI Transcript Segment` | live, plus every 20s | `api/ai/segments.py` |

Audio is never stored. Text only.

### Step 2 — One press of "Review the note"

**Call 1 · `resegregate-v1` · ~9s.** Deepgram often labels every line `doctor`,
including the patient's words. This decides who really spoke each line, then
`sync_transcript` updates rows, creates new ones and deletes extras — the rebuild
re-splits turns, so the count changes. It skips itself when the transcript has
not changed (`real-provider.ts:1474`), so a second press is free.

**Call 2 · `soap-v1` · ~17s.** Writes the whole note. Saves a **new**
`AI SOAP Draft` row, version + 1, so regenerations can be compared.

**Call 3 · `soap-gaps-v1` · ~12s.** Compares the finished note against the
transcript and produces the "Said in the consultation, not in this section"
cards. Writes nothing but a log row.

### Where the data lands

| Table | Written by | New row or update |
| --- | --- | --- |
| `AI Transcript Segment` | call 1 | updated · created · **deleted** |
| `AI SOAP Draft` | call 2 | **new row every press** |
| `AI Prompt Log` | calls 1, 2, 3 | three rows |
| `Patient Encounter.encounter_comment` | autosave | updated |
| `Vital Signs` | vitals fill | existing draft row updated |

### Step 3 — Fill Encounter

```
note-extract-v1   reads YOUR reviewed note → symptoms, diagnoses, rx, labs   ~9s
considerations    Lane B ideas, shown apart, written only if you press Add
```

`note-extract-v1` reads **the reviewed note, never the transcript**. Deliberate:
the transcript can contain standard-of-care ideas nobody chose, and those must
never become billable orders.

---

## 3. What is running correctly

An audit that lists only faults gives a false picture.

| Thing | Evidence |
| --- | --- |
| The three calls succeed | 113 `soap-v1`, 89 `soap-gaps-v1`, 101 `resegregate-v1`; failures in single digits |
| Nothing reaches the record unasked | `find_note_gaps` and `generate_considerations` make **zero** DB writes |
| Draft versioning is honest | 5 calls → 5 rows → version 5, verified |
| Deepgram config is correct | a real server-side socket returned **HTTP 101** with our exact params and token |
| Consent is enforced server-side | `start_session` keeps the session in `Draft` without it — PHI-2 holds |
| The drop path saves before sealing | it flushes, *then* closes the session — the ordering is right |
| Audio is never stored | text rows only |
| A repeat press is free | the resegregate skip and the note fingerprint both hold |

---

## 4. The gaps

### G1 · Recording died after about ten seconds — **FIXED 2026-09-02**

**WHAT.** "Transcription stopped — connection closed" appears within about
twelve seconds, with little or nothing captured.

**EVIDENCE.**

```
AIES-2026-00257   12s   0 segments   system_close
AIES-2026-00253    7s   0 segments   error
AIES-2026-00249   13s   0 segments   error
```

Deepgram closes a socket that has had no audio for ~10s, so the timing fits.

**NOT THE CONFIG**, checked first against the real service: `nova-3`, `multi`,
key present, ttl 3900s, **HTTP 101 accepted**. The fault is browser-side.

**USER STORY.** Dr. Bracamontes presses Start, greets the patient, the parent
begins the history → **the screen shows** the orange banner and "Ready to record"
→ **the database holds** one line or none → **consequence:** he writes the whole
note by hand and only learns the recording died when the note comes back empty.

**ROOT CAUSE — FOUND IN DEEPGRAM'S OWN DOCS, not in the console.** I spent most
of this session treating the close code as the missing evidence. It was not
needed. The behaviour is documented:

> "If no audio data **or** `KeepAlive` messages are sent within a 10-second
> window, the connection will close with a `NET-0001` error."
> "Send a `KeepAlive` message every **3-5 seconds**."
> — [Deepgram · Keep Alive](https://developers.deepgram.com/docs/keep-alive)

`NET-0001` arrives as close code **1011**. Deaths at 7s, 12s and 13s are that
cutoff, not a network fault.

**WHAT WE WERE MISSING — four things.**

1. **KeepAlive ran only while PAUSED.** `_startKeepAlive()` was called from
   `pause()` and nowhere else, because a recording session was assumed to be
   kept alive by its own audio. Deepgram accepts audio **or** KeepAlive, and we
   relied on exactly one of them. Three windows have no audio and none was
   covered: socket-open to the recorder's first chunk; every chunk dropped while
   the socket is not `OPEN` (what `audioChunksDropped` counts, including
   mid-rotation); and a throttled background tab.
2. **The interval was 8000ms** against a hard 10s cutoff — two seconds of
   margin. Now 3000ms.
3. **No `Finalize`** — see G2.
4. **No `CloseStream`** — the socket was slammed shut, discarding whatever
   Deepgram still held.

**FIXED** on `fix/drop-path-tells-the-truth`: KeepAlive for the whole socket
lifetime at 3s, re-armed at all three points where `this.ws` is assigned, plus
`Finalize` and `CloseStream`.

**REJECTED — "send silent audio"**, which the docs also offer for the
open-to-speech window. KeepAlive is the documented alternative and is strictly
safer: injecting synthetic silence into a clinical ASR stream invites
transcribed noise in a patient's record.

**ALSO REJECTED — the auto-reconnect I proposed earlier the same day.** It would
have treated a symptom, and a blind reconnect into a no-audio condition loops
for ever — connect, idle 10s, drop, reconnect — burning provider minutes while
the UI claims to be recording.

---

### G2 · The banner promised a save the code never checked — **FIXED 2026-09-02**

**WHAT.** The drop banner says *"Everything transcribed so far is saved."* Two
independent reasons that is false.

**Only finished lines are ever sent.**

```
real-provider.ts:1752   if (!this.sessionId || this.finalSegments.length === 0)
```

A line still being spoken is an *interim*. Interims are shown in the panel and
never enter `finalSegments`, so they were never candidates for saving.

**And the save result is discarded.** `_persistTranscript` returns
`{attempted, confirmed, failed, sealed}`. The **Stop button** path reads it and
raises a dialog on failure (`use-copilot.ts:523`). The **drop** path awaits the
same call and ignores its return value, then shows the banner regardless.

**WHY IT MATTERS.** `CLAUDE.md` PHI-5 — never say in the UI what the code does
not do. A clinician told the transcript is safe does not re-dictate.

**USER STORY.** He greets the patient, the parent starts talking → **the screen
shows** the banner, the line still visible, and "Everything transcribed so far is
saved" → **the database holds zero rows** → **consequence:** he trusts it and
the opening of the consultation is gone.

**EXAMPLE.**

```
screen      "Good morning! How are you feeling"
            no closing punctuation, and punctuate=true -- an interim
database    AIES-2026-00257   12s   0 segments
banner      "Everything transcribed so far is saved."
```

**FIXED**, in the frontend repo (`fix/drop-path-tells-the-truth`).

The fix mirrors `stop()`, which was already right: it has gated on `confirmed`
all along. The drop path now does the same — **seal on success, stay open on
failure** — and emits the outcome. `retryTranscriptPersist()`,
`finalizeUnconfirmedStop()` and the Stop-time dialog already existed and were
already wired; this path simply never used them, so the recovery surface is
reused rather than a second near-identical one invented.

```
banner   "Everything transcribed so far is saved"
      →  "Finished lines were saved; anything still being spoken was not."
```

Counts and the Retry now live in the outcome dialog, which is where a claim about
persistence belongs.

**Interim lines are marked "Not saved yet"** in the transcript, because no banner
can fix that half — the text is unsaved *before* any failure happens. Added
through the message catalogs (en + es), not hardcoded (§13.10).

**Marked, not persisted, deliberately.** Interim ASR is unconfirmed and gets
materially revised, so writing it as transcript text would put words in a
clinical record that were never said that way. Making a false promise true by
lowering the truth is not a fix.

**THE OBJECTION THAT HAD TO CLEAR FIRST.** Sealing unconditionally was itself a
deliberate fix — sessions stuck in `Recording` for ever were one of the two
causes of the 141 orphan sessions on record. Verified before changing it:
`AI Settings.enable_orphan_sweep = 1`, `sweep_orphan_sessions` on a 15-minute
cron, scheduler unpaused. **If that sweep is ever turned off, this gate must go
back to unconditional** — the code comment says so too.

Two tests pin it, and they were checked the right way round: reverting the seal
gate makes the "does NOT seal" test fail; restoring it passes.

---

### G3 · A line arriving one moment late was dropped where no human looks — **FIXED 2026-09-02**

**WHAT.** The backend refuses any write once the session leaves `Recording`:

```
segments.py:119   if session_row.status != "Recording":
                      logger.info("segment_dropped_sealed ...")
                      return {"status": "sealed"}
```

The refusal is **correct** — a sealed session must stay immutable. The problem is
the reporting: a logger line in a server file, not in `Error Log`, so it cannot
be queried, and on the drop path nobody looks.

**WHY IT MATTERS.** This is the only code path that silently discards clinical
speech. It should be the loudest thing in the system.

**USER STORY.** The socket dies at 00:12. The 20-second autosave fires at 00:20,
after sealing → **the server drops every line and logs one info line** → **the
clinician sees** G2's banner → **consequence:** loss with no record anyone finds.

**FIXED** by G2's change, as predicted. The `sealed` count was already returned
by the backend and already carried in the outcome object — G2 was what threw it
away. It now reaches the physician in the outcome dialog, with a retry, instead
of a logger line in a file.

The backend refusal itself is unchanged and was never the defect. A sealed
session must stay immutable; only the reporting was wrong.

---

### G4 · A session on screen with no database row

**WHAT.** `HLC-ENC-2026-00141` showed twelve seconds elapsed and one transcribed
turn. The database has no session row for it that day.

**EVIDENCE.**

```
sessions for HLC-ENC-2026-00141:
AIES-2026-00128   Stopped   backfilled   08-12   940s   65 segs
```

Nothing from 09-02, and no session of any kind was created after 12:11.

**WHY IT MATTERS.** A recording with no session row has no consent record, no
duration and no audit trail. For a clinical system that is worse than no
recording.

**UNVERIFIED** — whether `start_session` was never called, failed silently, or
the UI ran on a hydrated session. The error log shows no failure, which is itself
odd: a rejected call normally appears as `API 4xx · …`.

---

### G5 · The cost ledger is wrong in both directions — **HALF FIXED 2026-09-02**

**WHAT.** `AI Prompt Log.cost_estimate_usd` does not match what the calls cost.

**EVIDENCE**, recomputed from the logged tokens at gpt-5-mini rates
($0.25 in / $2.00 out per Mtok):

```
prompt          calls   recorded    true      error
soap-gaps-v1       89   $0.0000   $0.2756    records ZERO
v2 (pt summary)  1926  $38.0919   $4.7558    ~8x too high
v3                354   $9.2965   $1.1531    ~8x too high
v9                 41   $6.5986   $0.7638    ~8.6x too high
v6                 66   $1.0063   $0.0974    ~10x too high
soap-v1           113   $0.4796   $0.5767    about right
ask-copilot-v2    340   $9.5183   $9.8937    about right
```

**TWO CAUSES.** `find_note_gaps` builds its return value without a `cost_usd`
key, so `result.get("cost_usd", 0.0)` writes zero every time — tokens log
correctly, which is exactly why it stays invisible. Separately, the 8–10x
over-reports are the old pricing-fallback bug at `openai.py:1490`: a dated model
id never matched `_COST_PER_MTOK` and fell back to full `gpt-5` pricing, 60x the
input rate. Fixed by prefix matching; **the historical rows were never
recomputed.**

**USER STORY.** A clinic admin opens the AI cost report to decide whether the
copilot is affordable per visit → **the screen shows** about $65 → **the truth
is** about $18, with one whole feature reporting nothing → **consequence:** the
feature is killed for a cost it does not have, or a budget is set on a number
nobody can reconcile against the provider invoice.

**FIXED — the zero.** `find_note_gaps` in `integrations/openai.py` now returns
`cost_usd`. It was the ONLY sibling in that file missing it, and OpenAI is the
live provider, which is why it bit; the Anthropic adapter already had it.
Verified on a live call:

```
before   cost_usd 0.0      (on all 89 logged calls)
after    cost_usd 0.00257
```

**STILL OPEN — the historical rows.** The 8–10x over-reports from the old
pricing fallback are untouched. Correcting them means recomputing
`cost_estimate_usd` on ~2,400 existing rows, which is a data migration on the
audit trail and deserves its own patch and its own review. Recorded here rather
than done quietly.

So the ledger is **right from today forward and still wrong looking backward.**
Anyone reading totals must know which.

---

### G6 · Provider latency was measured on one path only — **FIXED 2026-09-02**

**WHAT IT WAS.**

```
purpose               calls   rows with cached_tokens
Copilot Chat             48   48      88% cached, avg 34,760 tokens
Copilot SOAP Draft      108    0
Copilot Suggestions      83    0
Copilot Transcribe        6    0
```

`AI Prompt Log` has had `reasoning_tokens` and `cached_tokens` columns all along.
The adapters already computed them, via a helper called `usage_detail()` — and
exactly **one** caller used it, the agent loop. That is the whole reason
`ask-copilot-v2` was the only path with numbers. It was never a missing
capability, only an unconnected one.

**FIXED.** Five adapter returns now carry the detail and seven `log_prompt_call`
sites pass it through.

**AND IT IMMEDIATELY ANSWERED ITS OWN OPEN QUESTION.** The audit said "not a
claim that caching is absent — a claim that it is unmeasured". Measured, on a
live `find_note_gaps` call:

```
input 3,895 tokens · cached 2,816  →  72% of the prompt was cached
reasoning_tokens 832
```

Two things follow. The prompt **is** being cached, so cost was being
over-estimated on these paths as well as under-recorded. And `reasoning_tokens
832` is direct evidence for the hidden thinking phase that explains why a
streamed `soap-v1` produces nothing for its first ~10 seconds — a gap that had
only been inferred until now.

---

### G7 · A delete resting on a rule nothing enforces — **FIXED 2026-09-02**

```
segments.py   keep = len(clean)
              filters={"sequence_number": (">=", keep)}   →   delete_doc(...)
```

Only correct if numbering is dense and **zero**-based. Verified it holds today:

```
AIES-2026-00258   10 rows   min 0   max 9    distinct 10
AIES-2026-00251   13 rows   min 0   max 12   distinct 13
```

**Nothing is being lost.** But nothing validates it at the delete site. A client
numbering from 1 would write rows 1..N, set `keep = N`, then permanently delete
row N — the last line of every corrected transcript — while reporting
`deleted: 1`, which looks like the intended cleanup.

**FIXED.** `sync_transcript` now checks the numbering where it is relied on and
**refuses** a payload that is not `0..len-1`, with a warning naming the session,
count, min and max.

Refuse rather than silently do something clever: deleting the wrong row costs the
end of a consultation, and refusing costs a retry. Verified the only caller
already satisfies it — `segs.map((seg, i) => ({ sequence_number: i }))`,
renumbered per session — so nothing changes today. That check was done BEFORE
adding a throw to a write path, because a validation that rejects real traffic is
worse than the fragility it replaces.

---

### G8 · `plan` and `education` are always last

Position as a share of output bytes (`AI SOAP Draft` AISD-2026-00112):
chiefComplaint 9%, hpi 24%, physicalExamination 46%, **plan 100%**.

Any future progressive display must never present a partly-filled note as ready
to sign. The Plan is the part that reaches the pharmacy.

---

## 5. Fixed on 2026-09-02, with server-side proof

*"Could not verify the transcript's speaker labels"* appeared over a perfectly
good transcript. Two `generateSoap` passes ran at once because the guard was
React state, which a caller resuming after an `await` reads stale. Both wrote the
same transcript rows and one lost the race.

```
12:08:46  resegregate-v1  Success
12:08:47  resegregate-v1  Success        ← two passes
12:08:47  TimestampMismatchError: AITS-2026-15796 has been modified
          after you have opened it
```

Fixed with a ref mutex and by sharing the in-flight rebuild rather than returning
a failure code. **A concurrency guard cannot be React state.**

---

### G9 · Timestamps restart at zero after a socket rotation — **OPEN**

**WHAT.** Deepgram's reconnection guidance is explicit:

> "When reconnecting, timestamps reset to 00:00:00 on the new connection…
> maintain a starting timestamp to offset all returned timestamps."
> — [Deepgram · Recovering From Connection Errors](https://developers.deepgram.com/docs/recovering-from-connection-errors-and-timeouts-when-live-streaming-audio)

We keep no offset. `grep` for `tOffset|timeOffset|baseTime|offsetMs` across the
provider returns nothing, and results are stored raw:

```
real-provider.ts   tStart: r3(msg.start)
                   tStart: msg.start
```

**WHY IT MATTERS.** `_rotateSocket()` runs on every long consultation — it fires
shortly before the Deepgram token's TTL elapses. After it, every turn's
`tStart` restarts from 0. Transcript rows are ordered by `sequence_number`, not
by time, so the visible order survives; what breaks is anything that reads the
timings.

**USER STORY.** A consultation runs past the token TTL, so the socket rotates →
**the screen shows** the turns in the right order, because ordering uses
`sequence_number` → **the database holds** a second run of timings starting again
at 0 → **consequence:** the per-session elapsed clock reads as though time went
backwards mid-visit, the same defect the "New recording session" divider was
added to explain, and any later work that reasons about when something was said
is silently wrong.

**NOT YET FIXED, and not bundled into the drop fix.** It is a data-correctness
change to how timings are recorded, not a connection fix, and it deserves its
own change and its own test. Recorded here rather than done quietly at the end
of an unrelated commit.

---

## 6. Priority

| # | Gap | Severity | Status | Blocked on |
| --- | --- | --- | --- | --- |
| G1 | Recording died at ~10s | **clinical** | **fixed** | — |
| G2 | Banner promised an unchecked save | **clinical + honesty** | **fixed** | — |
| G3 | Sealed drops invisible to humans | **clinical** | **fixed** | — |
| G4 | Session on screen, absent from the database | **audit** | **open** | reproduction |
| G5 | Cost ledger wrong both ways | governance | **half fixed** | a backfill patch |
| G6 | Provider latency unmeasured | observability | **fixed** | — |
| G7 | Index-based delete, unenforced rule | latent | **fixed** | — |
| G8 | `plan` and `education` last | design constraint | open by design | nothing — just respect it |
| G9 | Timestamps restart at 0 after a rotation | **data correctness** | **open** | nothing — needs its own change |

### The order they were done in, and why

**First, the safe three.** Not "least dangerous gap" — least dangerous **FIX**.
G5, G6 and G7 are backend-only, change nothing a clinician sees, and touch no
clinical logic:

```
G6   pass two numbers that were already being computed
G5   add one key to one return
G7   add a check that today's only caller already satisfies
```

**Then the honest pair.** G2 and G3 were the more valuable ones all along, but
they change what a clinician reads when a recording fails, so they needed a
wording decision and a rejected-alternatives pass before a patch — see G2 for
the two options that lose and why.

**Five gaps closed, one of them half.** Six remain open in some form:

| Still open | What it needs |
| --- | --- |
| G4 | a reproduction |
| G5 (second half) | a backfill patch over ~2,400 audit rows |
| G9 | a timestamp offset kept across rotations |
| G8 | nothing — a constraint to respect, not a defect |

**Six of nine closed, one half.** No clinical gap is open.

### The lesson from G1, worth more than the fix

I spent most of a session calling G1 "blocked on one line from the browser
console", and proposed an auto-reconnect to work around it. Reading the
provider's own documentation settled the root cause in minutes and showed the
reconnect would have been actively harmful. **Read the vendor's docs before
inferring a vendor's behaviour from your own code.**

### What did NOT change, across all five fixes

No prompt, no clinical rule, no schema, and no change to what the model
produces. The only user-visible change is the drop banner's wording and the
"Not saved yet" marker — both of which exist to stop the screen asserting
something the code had not checked.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 2.2 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | **G1 fixed** — root cause found in Deepgram's docs, not the console: KeepAlive ran only while paused, at 8s against a documented 10s cutoff, with no `Finalize` or `CloseStream`. New **G9** recorded: timestamps restart at 0 after a socket rotation and no offset is kept |
| 2.1 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | G2 and G3 fixed — the drop path now seals only on a confirmed save, reuses the Stop-time retry dialog, tells the truth in the banner, and marks interim lines "Not saved yet". Five gaps closed today; G1 is now the only one a patient could feel |
| 2.0 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | G6 and G7 fixed, G5 half fixed. `Doc status` changed `record` → `living`: it is now a tracker, and a `record` may never be corrected. G6's own open question answered by its fix — the prompt is **72% cached**, and `reasoning_tokens 832` is the first direct evidence of the hidden thinking phase |
| 1.0 | 2026-09-02 | Sarvesh-SocialAngel (AI-assisted) | Initial audit — one document covering the capture screen, the three calls behind "Review the note", and eight gaps. Consolidates two working drafts written the same day |
