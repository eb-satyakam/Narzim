# Appointment Flow — Fix Log

> **Link note (2026-08-20):** frontend references in this document were relative paths into
> `remedisys-ai-ehr`, a repo since renamed. A cross-repo relative link cannot resolve from here, so
> they are now plain code references. The frontend repo is `EB_Healthcare_Frontend`
> (working copy `Healthcare_next_app`).

**Doc status:** record · **Created:** 2026-08-19 by Anant Sharma · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-08-19
**Companion to:** `docs/audit/APPOINTMENT_FLOW_UI_GAPS.md` (the audit that preceded this)
**Scope:** the New Appointment drawer (booking) — 6 reported UI defects plus 3 requested
changes (cheque/reference capture on Pay-Now; Husband/Wife relations; one reschedule flow
across all four entry points).

> **Note on the local site name:** `CLAUDE.md` §5 says `marley-bench → marley.local:8003`.
> The actual bench site is **`remedisys.localhost`** (`sites/remedisys.localhost`), which is
> what the commands below use. The constitution is stale on this point.

**Repos touched:**

| Repo | Files | Net |
|---|---|---|
| `remedisys-ai-ehr` (frontend) | 6 | +214 / −143 |
| `EB_Healthcare_Backend` | 2 | +28 / −2 |

**Verification (all changes, both repos):**

- `tsc --noEmit` clean across `src/` — one pre-existing error remains in
  `e2e/encounter-submit.spec.ts:237`, untouched by this work
- `eslint` **identical to the HEAD baseline** on every changed file — 21 findings
  before, 21 after, no new ones (all pre-existing `set-state-in-effect` /
  `no-unused-vars` / `exhaustive-deps`)
- `npm run i18n:check` — 5,821 keys, en ↔ es aligned
- `npm test` — 70/70 pass
- Backend: `ast.parse` clean. `ruff` is **not installed in this environment**, so the
  Python lint gate in §9 of `CLAUDE.md` has NOT been run — do that before merge.
- **Not exercised against a live site.** No booking was made on `marley.local`, so the
  runtime behaviour of items 4, 5 and 7 is verified by reading, not by observation.
  See "Before merge" at the bottom.

---

## 1 — Enter did nothing when no patient matched

**Reported:** typing a name with no match, then pressing Enter, had no effect.

**Cause:** `handleSearchKeyDown`'s Enter branch only acted when `searchResults[activeIdx]`
existed. With an empty result set it fell through and returned, so the one action the
dropdown was offering — "Add *<query>* as a new patient" — was mouse-only.

**Fix** (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 540):
Enter now falls through to `startNewPatient()`, gated on the same two conditions that make
that row appear — `query.trim().length >= 2` and `!searchLoading`. The loading guard
matters: mid-flight, a real match may still arrive, and Enter must not create a duplicate
patient a half-second before the search would have found the existing one.

---

## 2 — An invalid date of birth was silently discarded

**Reported:** DOB accepted a wrong format with no error, and Continue stayed enabled.

**Cause:** the field's `onChange` only commits `npDob` once all 8 digits parse to a real,
non-future calendar date. A partial entry (`12/03/20`) or an impossible one (`31/02/2020`,
which ISO parsing rejects) left `npDob` empty — correctly, but in **silence**. `patientOk`
never consulted DOB, so Continue stayed live and the patient was created with no date of
birth at all. For a pediatric clinic that also silently disables weight-based dosing and
the age-appropriate immunization schedule downstream.

> **Corrected 2026-08-19 (same day, after testing on `localhost:3000`).** The first
> version of this fix shipped ONE boolean and ONE message, and got the diagnosis wrong:
> entering `12/11/2026` — a complete date, but in the future — reported *"Enter a complete
> date of birth as DD/MM/YYYY."* The date was complete. Root cause: validity was derived
> from `!!npDob`, and because the input only commits `npDob` for a date that passes every
> check, **the reason it was empty had already been discarded** by the time validation ran.
> Now `classifyDob(display)` reads the typed digits and returns which of three ways it
> failed, each with its own message. Note the year clamp in the input
> (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 1232) only rejects years *past* the current one, so a future month/day inside
> the current year always reaches validation — which is exactly the reported case.

**Fix:**
- `classifyDob` (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 150) → `"incomplete" | "impossible" | "future" | null`, each mapped
  to its own message (`dobIncomplete` / `dobImpossible` / `dobFuture`). The single
  `dobInvalid` key is gone.
- Future check compares against **the start of tomorrow**, not `now` — `parsed` is
  midnight, so `parsed > new Date()` would have rejected a newborn born earlier today for
  most of the working day.
- Components are round-tripped after parsing, so `31/02/2020` is reported as impossible
  rather than silently rolling into March.
- `npDobValid` (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 612) — anything typed must resolve to a committed `npDob`
- red border + `aria-invalid` + inline `dobInvalid` message (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 1276)
- added to `patientOk` **and** to the existing-patient Save gate, so editing a real
  patient's DOB is held to the same rule

**Verified** by running the classifier over 11 cases including the reported input:
blank → valid; `1` and `12/03/20` → incomplete; `31/02/2020`, `30/02/2024`, `31/04/2020`
→ impossible; `12/11/2026` and tomorrow → future; today, `01/01/1990` and the `29/02/2024`
leap day → valid. All 11 pass.

DOB stays **optional** — blank is still valid. Only a *partial* entry is an error.

---

## 3 — New-patient draft lived in browser storage

**Reported:** new-patient data is kept in local storage; keep it in state and drop it
afterwards.

**Removed entirely** (~120 lines): `PENDING_PATIENT_KEY`, the version/TTL/per-user
envelope, `readPendingPatientDraft`, `writePendingPatientDraft`,
`clearPendingPatientDraft`, the sync effect, the success-clear effect, and the
clear-on-abandon call. Every `np*` field now seeds from its own empty value.

**Why this is sufficient:** every caller mounts the dialog conditionally
(`{newApptOpen && <NewAppointmentDialog …>}` — `command-palette.tsx:208`,
`patient-chart-client.tsx:850`), so closing it unmounts the component and the draft goes
with it. That is exactly the requested "in state, gone afterwards".

**One addition beyond the ask:** `purgeLegacyPendingPatientDraft`
(`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 171, run once at mount, `src/components/narzim/dashboard/new-appointment-dialog.tsx` line 845) evicts both old keys. Deleting the write path
stops new writes but cannot reach a value an **earlier build already wrote** — a patient
name, DOB and phone sitting in `localStorage` on a shared front-desk terminal. Without the
purge that data persists indefinitely on machines that ran the old build.

> **This reverses in-progress uncommitted work.** The working tree already held a migration
> of this draft from `localStorage` to hardened `sessionStorage` (version stamp, 30-min TTL,
> per-user check). The instruction was to drop storage, so the storage path went entirely
> rather than keeping two mechanisms. The **email-validation work from that same session was
> left intact** — `src/lib/email.ts` and `npEmailValid` are untouched, and the new DOB gate
> deliberately follows their pattern.

---

## 4 — "TIME SLOT" sat above UNIT instead of above the slot grid

**Reported:** on the Schedule step, "Time slot" shows before "Morning", not before "Unit".

**Cause:** the heading was the first child of the whole block, so the reading order was
`TIME SLOT → UNIT → MORNING` — labelling the room chips as though they were the time slots.

**Fix:** the unit filter (a filter *on* the grid) now comes first, and the heading moved
down to the thing it names (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 1821). It still leads the empty/loading states
(`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 1773) — those render no unit filter, so there is nothing there to confuse it with.

---

## 5 — Gap under the "Book with" bar

**Reported:** after picking a practitioner and a slot, a gap appears at the bottom around
"Book with".

**Cause, since it explains the exact artefact in the screenshot:** the bar was
`sticky bottom-0` **inside** the scrolling body, and that body carries `py-5`. A sticky
element rests against the *padding* box, not the scrollport, so the bar settled 20px above
the true bottom — the strip where 8:20/8:40 PM showed through underneath it, while the
EVENING heading scrolled behind it.

**Fix** (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 2431): hoisted out of the scroll container into a real
`shrink-0` band between the scroll body and the Back/Continue footer. No padding to leak
through, nothing can hide behind it, and the grid scrolls above it.

This is also the correct behaviour rather than only the correct layout: when a slot has
more than one free practitioner, the pick is **required** before Continue enables, so it
must not be something the user can scroll past.

**Bonus:** `needsPractPick` and the band now share one `bookWithOptions` memo
(`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 819) — previously each re-derived "who can take this slot" independently, so the
Continue gate and the panel could in principle disagree about whether a pick was owed.

---

## 6 — Percent discount accepted more than 100%

**Reported:** cap the percentage at 100.

**Cause:** the *math* already clamped (`Math.min(discInput, 100)`), but the **field kept
displaying whatever was typed**. Entering 150 showed a 150% discount while the invoice
used 100% — a number on screen that did not match what would be charged.

**Fix** (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 2078): clamped as typed (`max={100}` when the mode is percent, plus an
`onChange` clamp), and clamped **again on the Flat → % switch** — 500 is a legitimate flat
discount but not a legitimate percentage, so it is capped on the way across rather than
left displaying 500%.

---

## 7 — Cheque / reference number on Pay-Now (new feature)

**Requested:** choosing Pay now → Cheque should open a field for the cheque number, and
that should land on the Payment Entry like it does in billing.

**What already existed** — this shaped the fix into a pass-through rather than new work:

- `settle_invoice` and `api.v1.billing.collect_payment` **already accepted**
  `reference_no` / `reference_date`
- three billing screens **already had the field** (`billing-client.tsx`,
  `new-invoice-client.tsx`, `collect-payment-dialog.tsx`)

**The one broken link:** `invoice_and_settle` — the booking Pay-Now path — never took the
parameters. So a cheque collected at booking always landed with the **invoice id** as its
Payment Entry reference, and the real cheque number existed only on paper.

**Backend** (28 lines, no new accounting logic):

| File | Change |
|---|---|
| `services/billing.py:509` | `invoice_and_settle` takes `reference_no` / `reference_date` |
| `services/billing.py:592` | forwards both to `settle_invoice` |
| `api/v1/appointments/api.py:1332,1380` | `book_appointment_with_payment` accepts + forwards |
| `api/v1/appointments/api.py:1513,1652` | `book_appointment_for_patient` accepts + forwards |

Named `reference_no` / `reference_date` to match `collect_payment` and the ERPNext Payment
Entry fields the frontend already sends elsewhere. Both are documented in
`book_appointment_for_patient`'s docstring as **distinct from** the adjacent
`reference_doctype` / `reference_docname`, which are the appointment's own core link
fields — a genuine confusion risk in that signature.

**Frontend:**
- `showReferenceField` (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 923) uses the **same derivation as all three billing
  screens**: `!isWaiverMethod && selectedMethodType !== "Cash"`, read off the Mode of
  Payment's own `type`. So it follows the clinic's configured modes rather than a hardcoded
  "Cheque" string — and correctly appears for Card, Bank and wire too, not only cheques.
- field rendered under the Pay-Now method select (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 2164)
- `referenceNo` added to `NewApptPayload` (`src/components/narzim/dashboard/new-appointment-dialog.tsx` line 889) → both booking call sites →
  `reference_no`; typed on `appointmentsApi.book` and `CreateWithPaymentPayload`
- no BFF change needed — `api/appointments/book` and `create-with-payment` pass the body
  verbatim

**Required for a Bank-type tender** (`referenceRequired`, dialog `:925`) — Continue is
disabled until it is filled (`paymentOk`, `:928`, wired into `stepValid` step 2).

> **This reverses my first call, correctly.** I originally shipped it optional, reasoning
> that ERPNext demands a reference only for a Bank-type account and that
> `apply_mode_account_and_reference` already substitutes the invoice id there — so a blank
> field could not fail the booking. Challenged on why Continue stayed enabled for a Cheque
> with no number, that reasoning does not survive: **the fallback is exactly the problem.**
> Substituting the invoice id means nothing errors, and the Payment Entry carries an invoice
> id where the cheque number should be — so the payment cannot be reconciled against the
> bank statement. "It does not fail the collection" was true and irrelevant.

The gate is **narrower than `showReferenceField`** on purpose:

| Mode of Payment `type` | Field shown | Blocks Continue |
|---|---|---|
| `Cash` | no | no |
| `Bank` — Cheque, Bank Draft, Wire Transfer, Credit Card | yes | **yes** |
| `General` / `Phone` | yes | no |

`Bank` is precisely where core's own `validate_transaction_reference` would have thrown, so
the drawer now demands a reference exactly where ERPNext does and no further. A mode
configured as General or Phone still offers the field — a reference can be useful — without
blocking, because core would not have demanded one either. Verified against the site's real
config: `Cash` is type `Cash`; `Cheque`, `Bank Draft`, `Wire Transfer` and `Credit Card` are
all type `Bank`.

Pay-later and insurance are not gated: the former has nothing to reference yet, the latter
leaves the copay outstanding for checkout to collect.

> **Known divergence, not fixed here:** the three billing screens
> (`billing-client.tsx`, `new-invoice-client.tsx`, `collect-payment-dialog.tsx`) still treat
> the reference as optional for every mode, so a cheque collected at **checkout** can still
> land with the invoice id as its reference. Same `referenceRequired` rule would apply;
> out of scope for this drawer-focused pass.

---

## 8 — Husband / Wife added to the guardian & contact relation picker

**Requested:** add Husband and Wife to the relation dropdown.

**Why this is not a one-line change.** The Contact `relation` field is a **Select**
Custom Field, and Frappe's own `_validate_selects` rejects any value outside the stored
`options`. A frontend-only addition would render the two new choices and then fail on
save. Four places have to agree, and the repo already carries two prior patches proving
this (`add_guardian_relation_option_20260703`, `add_sibling_relation_option_20260716`):

| Layer | File | Change |
|---|---|---|
| Picker | `contact-tab.tsx:36` | `CONTACT_RELATIONS_MINOR` += Husband, Wife (before Other) |
| Labels | `messages/{en,es}.json` | `chart.contact.relations` += Husband/Wife · Esposo/Esposa |
| API allowlist | `api/v1/patients/api.py:1547` | `_GUARDIAN_RELATIONS` += Husband, Wife |
| Select options | `fixtures/custom_field.json` | Contact-relation **and** Address-relation |
| Existing sites | `patches/v0/add_spouse_relation_options_20260819.py` | new patch + `patches.txt` entry |

The fixture alone is not enough — fixtures only create fields that do not yet exist, so a
new option never reaches a site that already has the field. Hence the patch, which sets the
full list idempotently rather than appending.

Kept as the two literal terms rather than a single "Spouse", both because that is what was
asked for and because the rest of the list is already gendered (Father/Mother,
Stepfather/Stepmother). Note `CONTACT_RELATIONS_ADULT` (`contact-tab.tsx:37`) separately
offers "Spouse" and "Partner" — that list is for a non-guardian contact on an adult patient
and was left alone.

> **Worth knowing:** the picker offers `Guardian` and `Sibling`, which reached the stored
> Select options only via those two earlier patches — a site that has not run them cannot
> save either. Any future relation must repeat all five rows above.

**Confirmed in practice.** Booking with relation "Husband" before the patch ran failed at
submit with Frappe's own Select validation:

```
Patient Relation cannot be "Husband". It should be one of "", "Father", "Mother",
"Guardian", "Legal Guardian", "Grandparent", "Stepfather", "Stepmother", "Uncle",
"Aunt", "Sibling", "Other"
```

That option list is the pre-patch value stored on the site — exactly why the fixture edit
alone is insufficient. **The patch has since been run on the local dev site** and both
fields read back with `…Sibling\nHusband\nWife\nOther`:

```
bench --site remedisys.localhost execute \
  remedisys_healthcare_ai.patches.v0.add_spouse_relation_options_20260819.execute
```

Run per site (or let `bench migrate` pick it up from `patches.txt`) before the picker's two
new options are usable there.

> **Two pre-existing inconsistencies found while doing this, NOT touched:**
> - `patientsPage.editSheet.contacts.relations` (`messages/en.json:3202`) is a separate,
>   older map — `Father, Mother, Legal Guardian, Grandparent, Stepfather, Stepmother, Uncle,
>   Aunt, Other`. It has never had Guardian or Sibling, and does not have Husband/Wife now.
> - `remedisys_healthcare_ai/remedisys_healthcare_ai/fixtures/custom_field.json` (58 lines)
>   is a **stale duplicate** of the live 10,386-line `remedisys_healthcare_ai/fixtures/custom_field.json`
>   and still carries the pre-2026-07 option list. Frappe reads the live one; the duplicate
>   is a trap for the next person editing "the fixture". Worth deleting separately.

---

## 9 — One reschedule flow everywhere (closes the audit's 🔴 G-01)

> Full reschedule-flow status, including the 5 gaps still open and the suggested
> order to close them: `docs/audit/APPOINTMENT_RESCHEDULE_STATUS.md`.

**Requested:** the Appointments list, then "everywhere we reschedule the appointment flow is
same".

Two dialogs existed, and which screen you started from decided whether money moved:

| Screen | Before | After |
|---|---|---|
| Appointments list | `reschedule_appointment` | `..._with_payment` |
| Patient chart → Overview card | `reschedule_appointment` | `..._with_payment` |
| Mission Control | `..._with_payment` | unchanged |
| Patient chart → Appointments tab | `..._with_payment` | unchanged |

`components/narzim/appointments/reschedule-dialog.tsx` is **deleted**; all four sites now
import `components/narzim/dashboard/reschedule-dialog.tsx`.

**What the two non-settling screens were actually doing.** Worse than the audit recorded:
that dialog also let the operator change the **practitioner**, committing it through a
separate `reassign_appointment` call before `onConfirm` fired the date/time move. So from
the Appointments list you could move a paid appointment to a differently-priced doctor and
the system collected nothing, refunded nothing, and wrote no history row — and the two
writes were **not atomic**: a failure after the reassign left the appointment with a new
doctor and its old slot, with no rollback and no message describing that state.

Every reschedule now goes through one path that: previews the settlement server-side
(`preview_reschedule_payment`, so the figure shown and the figure charged come from one
function), collects or refunds the difference, writes an `Appointment Reschedule History`
row, is idempotent on retry, and changes practitioner + date + time + type in a single
transaction. It carries 24 tests (`tests/appointments/test_reschedule_payment.py`); the path
just retired had none.

**Cleanup this made possible, all verified unreferenced first:**
- `useRescheduleAppointment` deleted from `hooks/use-appointments.ts` — a live export
  pointing at the non-settling endpoint is exactly how a screen gets wired back to it.
- `appointmentsApi.reschedule` kept (the endpoint is a legitimate simple API) but annotated
  with why the UI must not use it.
- `toReschedulable` / `handleReschedule` and 3 orphaned imports removed from
  `overview-frontdesk.tsx`; its `rescheduleFor` state is now just an id, since the dialog
  fetches the appointment itself.
- 4 orphaned i18n keys dropped from both catalogs (`appointmentsPage.toast.rescheduled`,
  `.rescheduleFailed`, `overviewFrontdesk.rescheduledToast`, `.rescheduleError`) — the
  shared dialog raises its own `dashboard.reschedule.done/failed`.

**Still open from the reschedule audit** (not part of this ask):

| # | Gap |
|---|---|
| R-2 | Neither reschedule path runs `_practitioner_conflict`, so a reschedule can double-book a practitioner **across service units** where a fresh booking returns 409. Core's `validate_overlaps` is scoped to one service unit. A fix must exclude the appointment being moved. |
| R-3 | `get_reschedule_history` still has no BFF route or consumer, though its docstring claims it backs a frontend timeline and payment-history table. |
| R-4 | `new_service_unit`, `new_department`, `fee_override` are accepted by the endpoint and the BFF route but absent from `ReschedulePaymentPayload`. `new_service_unit` matters most: the drawer resolves a service unit per slot and discards it in reschedule mode, so a move to another room leaves the appointment on the old one — which is also how R-2 goes unnoticed. |
| R-5 | No server-side past-date guard on either path (core has none either); both UIs block it client-side only. |
| R-6 | A `Checked In` appointment can still be rescheduled. Product decision. |

---

## Also added

`newAppt` i18n keys, en + es: `dobIncomplete`, `dobImpossible`, `dobFuture`,
`referenceNo`, `referenceNoPlaceholder`, `referenceNoRequired`
(reference wording matched to the existing billing keys). `emailInvalid` came from the
pre-existing uncommitted work.

> **Caught during the work:** the first attempt inserted `dobInvalid` into the wrong
> namespace — `messages/en.json` has **five** `emailInvalid` keys across different
> namespaces, and a naive first-match search landed on line 122 instead of the `newAppt`
> block at 749. Any future key insertion into these catalogs must resolve the namespace
> block first, not the key name. `npm run i18n:check` does not catch this (parity holds
> either way) — only the missing string at runtime would.

---

## Not covered

| Item | Why |
|---|---|
| Reference no. on a **reschedule** fee difference | `adjust_payment_for_reschedule` has its own `settle_invoice` call (`services/billing.py:2638`) still passing no reference. Same three-line shape as item 7; out of the reported scope. |
| The 16 gaps in `APPOINTMENT_FLOW_UI_GAPS.md` | Untouched. The four 🔴 items there — split reschedule settlement, no-show unreachable, Mission Control check-in not stamping `custom_checked_in_at`, arrival time not returned — are all still open. |
| `ruff` on the two Python files | Not installed in this environment. |

## Before merge

1. Run `ruff` + `mypy` on the two backend files (§9 of `CLAUDE.md`).
2. One real booking on `marley.local`: Pay now → a Bank/Cheque mode → confirm the typed
   number lands in `Payment Entry.reference_no` (not the invoice id).
3. Re-test DOB with all three failures: `12/03/20` (incomplete), `31/02/2020`
   (impossible), `12/11/2026` (future) — each must show its own message.
4. Eyeball the Schedule step for items 4 and 5 — particularly the "Book with" band with
   6+ practitioners, where it wraps to two rows and the band grows taller.
5. Confirm a Cash Pay-Now booking still shows **no** reference field and still settles, and
   that Cheque with an empty reference now keeps Continue disabled.
6. ~~Run the spouse-relation patch, then save a guardian with relation **Wife**.~~
   ✅ Done on `remedisys.localhost` — both Custom Fields verified. Still required on every
   other site (staging, production) before the two new options work there.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
