# Frappe Helpdesk — what the vendored app does on our behalf

**Doc status:** record · **Created:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-25 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.2

> A dated snapshot of what `helpdesk` v1.29.0 writes, copies, schedules and sends **without
> Remedisys asking it to**, audited on `marley.local` against the installed source.
>
> **Why this audit exists.** Two audits examined our own code and neither found the defect that
> mattered: every support ticket linked to the reporter's patient record, MRN and all. It surfaced
> only when someone asked where a field was stored and we read the actual row — because the field
> belonged to Helpdesk, not to us. This is the pass over everything else in that category.
>
> Related: [integration plan](../planning/2026-08-24-helpdesk-integration-plan.md) ·
> [design spec](../architecture/2026-08-24-help-support-ux-system-design.md) ·
> [known issues](../KNOWN_ISSUES.md)

---

## 1. Verdict

**Nothing found is exploitable today. Four things are one configuration change away from being
serious, and two of those switches are already half-flipped.**

| | Count | Meaning |
|---|---|---|
| **LIVE** | 3 | Happening now on this site — **L1 resolved 2026-08-25** |
| **LATENT** | 5 | Off today; a single toggle or hosting default turns it on |
| **CONTAINED** | 3 | Looked dangerous, verified blocked |

The pattern worth internalising: **the risk in a vendored app is rarely its code — it is its
defaults.** Every LATENT finding below is a checkbox someone could tick in the Desk without
touching a repository, on an app we do not own, in a database holding patient records.

---

## 2. LIVE — happening now

### L1 · Agent replies leave the estate by email

> **RESOLVED the same day, 2026-08-25.** Helpdesk's own switches are now set by
> `patches/v0/disable_helpdesk_outgoing_email_20260825` — `skip_email_workflow = 1`,
> `enable_reply_email_via_agent = 0`, `enable_reply_email_to_agent = 0`. The site's shared outgoing
> account is untouched, because Remedisys sends staff and patient-portal invitations through it.
> Verified: an agent reply added **0 rows to the Email Queue** and the clinician still saw it in
> their thread. This annotation is added to a `record` document only because the finding was closed
> within a day of being written; the finding itself stands as evidence of what was true.

`skip_email_workflow = 0` and an enabled default outgoing account (`no-reply@narzim.com`) mean an
agent reply is delivered as email to the reporter's address — a personal Gmail, in the case observed.
A reply can quote whatever the clinician pasted.

### L2 · SLA status is rewritten on our tickets hourly
`scheduler_events.hourly_long → update_sla_status_in_ticket`. Helpdesk writes to `HD Ticket` rows on a
schedule, with no involvement from us. Benign in itself; recorded because **any assumption that a
ticket only changes when someone acts on it is false.**

### L3 · A network fetch runs on every migrate and every scheduler tick
`after_migrate` and `scheduler_events.all` both call `helpdesk.search.download_corpus`, which
downloads NLTK corpora (`averaged_perceptron_tagger_eng`, `punkt_tab`, `brown`) when absent.

Outbound internet access during **deploy**, on a healthcare site. It is idempotent and cached, so it
is a first-run cost — but a deploy that assumes an air-gapped or egress-filtered host will hang or
fail here, and the failure will look like a slow migration rather than a blocked download.

---

## 3. LATENT — one switch away

### N1 · Ticket content is copied out of the database into a search index
**The finding with the longest tail.** Helpdesk indexes, per `search_sqlite.py`:

| Doctype | Fields indexed |
|---|---|
| `HD Ticket` | `subject`, `description` |
| `HD Ticket Comment` | `content` |
| `Communication` (filtered to HD Ticket) | `content` |

That is **every word of every support request and every reply**, duplicated into
`helpdesk_search.db` in the site directory — plus a second, Redis-backed index in `search.py`
(`build_index_in_background`, wired to `after_migrate`).

Not yet built on `marley.local` (the file does not exist), which is the only reason this is LATENT.

**Why it matters beyond "another copy":** a clinician pasting a chart excerpt into a support request
puts that text in a file that a database backup may not include, a database restore will not
rebuild consistently, and **a deleted ticket may not purge** — `search_sqlite.py` has no `on_trash`
handling, unlike the Redis implementation which does have `remove_document`. Retention and erasure
for these copies is undefined.

### N2 · Enabling one ERPNext toggle mirrors 307 patient-derived records into Helpdesk
`doc_events` binds Helpdesk to ERPNext **`Customer`** — `after_insert`, `on_update`, `before_rename`,
`after_rename`, `on_trash` — and `after_insert` creates an `HD Customer` for every ERPNext Customer.

```
should_sync()        = 0     (ERPNext HD Settings.enabled)
ERPNext Customers    = 307
HD Customer records  = 0
```

Ticking that box creates 307 HD Customers from records that, on this site, are patient-derived.
**And it is not only a data-copy problem:** `customer` is the field that widens ticket visibility
(`get_customer_criteria`: `customer IN get_customers(user)`), so populating it is also the thing our
per-user isolation (D4/D5) depends on *not* happening.

### N3 · Telemetry is already switched on at the site level
```
System Settings.enable_telemetry = 1
conf.pulse_api_key               = absent   →  is_enabled() = False
```
Nothing sends today **only** because the API key is missing. On a managed host that key is a platform
concern, not ours — if Frappe Cloud provides it, event capture begins with no change on our side.
Helpdesk calls `capture_event("ticket_created")` on every ticket. The payload is an event name, not
content, so this is a posture finding rather than a PHI one — but it should be a decision, not a
default.

### N4 · Auto-close will silently rewrite ticket status
`scheduler_events.daily → close_tickets_after_n_days`, gated by `auto_close_tickets = 0` with
`auto_close_after_days = 14` already configured. Enabling it closes inactive tickets on a timer —
including, on the current design, a request whose clinician is simply waiting.

### N5 · Two Assignment Rules are enabled with empty teams
*Already recorded in the design spec's D3.* `Product Experts - Support Rotation` and
`Billing - Support Rotation` are **enabled**; their teams have no members, so nothing assigns. Adding
one user to either team begins auto-assigning to an individual, violating the locked
no-assignment decision — and no test can catch it, because it is Desk configuration.

---

## 4. CONTAINED — looked dangerous, verified blocked

Recorded because "73 ungated endpoints" is alarming until it is measured, and measuring it is what
distinguishes a finding from a scare.

**73 whitelisted methods carry no `@agent_only` / `@agent_manager_only` decorator**, so they are
reachable in principle by any authenticated user — including our staff, who hold `HD Customer`.
Frappe's doctype permission layer still applies inside them. Probed as a real staff user
(`e2e_support@remedisys.test`, `EB_` roles + `HD Customer`):

```
HD Ticket perms for HD Customer:  read 1 · write 1 · create 1 · delete 0

delete_ticket (someone else's)    blocked  PermissionError
delete_ticket (own)               blocked  PermissionError
knowledge_base.create_category    blocked  PermissionError
data_import.bulk_insert           blocked  RuntimeError
search.build_index                blocked  ResponseError
knowledge_base.get_categories     ALLOWED  (reading the knowledge base — intended)
```

**C1 · Ticket deletion is not reachable by staff** — `delete = 0` on the DocPerm, in both directions.
**C2 · Bulk insert and index rebuild are not reachable by staff.**
**C3 · Knowledge-base reads are open to staff**, which is the intended behaviour for a help surface.

The general lesson: *decorator-ungated is not the same as reachable.* The permission layer held on
every probe. It is still worth knowing the surface exists, because a future Helpdesk release could
add a method whose own guard is the only thing standing in the way.

---

## 5. The switches that decide all of this

Everything above reduces to a small number of settings that live in the Desk, not in a repository.
Current values on `marley.local`:

| Setting | Value | What it governs |
|---|---|---|
| `skip_email_workflow` | `0` | replies go out as email (**L1**) |
| `enable_reply_email_to_agent` | `1` | a clinician's reply emails the assigned agents — inert only while tickets are unassigned (D3) |
| `auto_set_customer_from_contact` | `1` | would populate `customer` from a contact; inert now that we detach both |
| `auto_close_tickets` | `0` | **N4** |
| `send_acknowledgement_email` | `0` | no auto-reply on creation |
| `instantly_send_email` | `0` | — |
| `enable_email_ticket_feedback` | `0` | no satisfaction emails |
| `ERPNext HD Settings.enabled` | `0` | **N2** |
| `System Settings.enable_telemetry` | `1` | **N3** |
| Assignment Rules | 2 enabled, 0 members | **N5** |

**None of these are in version control.** A data reset, a restore, or someone exploring the Desk
changes behaviour with no diff, no review and no test. That, rather than any single finding, is the
thing worth designing around.

---

## 6. What this audit did not cover

- **The Helpdesk frontend** (`desk/`) — only the Python surface was read.
- **Helpdesk's own portal** at `/helpdesk` for non-agents — we do not route clinicians there, but it
  remains reachable and was not probed.
- **The other 68 ungated methods** — six were probed, chosen for looking most destructive.
- **Upgrade behaviour** — what a future `helpdesk` version changes in any of the above.
- **`HD Ticket` field-level permissions** (`permlevel`), which were not examined.

---

## 7. Recommended actions

Ordered by cost-to-benefit, none taken.

| # | Action | Addresses | Cost |
|---|---|---|---|
| 1 | **Decide the email question**: disable outgoing for Helpdesk and rely on in-app notification, or accept email under a processor agreement | L1, and `enable_reply_email_to_agent` | a decision + one setting |
| 2 | ~~Record the Helpdesk settings as a checked artefact~~ — **DONE 2026-08-25.** `scripts/helpdesk_settings_spec.json` declares 11 field values and 3 rules; `scripts/check_helpdesk_settings.py` reports drift and, with `strict=1`, fails. See below | N2–N5 | done |
| 3 | **Decide the search-index retention story** before the index is ever built, since building it is what makes the copies exist | N1 | a decision |
| 4 | **Disable or deliberately empty the two Assignment Rules** before go-live | N5 | one setting |
| 5 | Confirm whether the deploy host permits the NLTK download, or pre-seed the corpora | L3 | a check |

**Action 2 is the one that generalises.** Every LATENT finding here is a setting nobody reviewed,
and the only durable fix is to make those settings visible where changes are reviewed.

### How to run the check

```bash
bench --site <site> execute \
    remedisys_healthcare_ai.scripts.check_helpdesk_settings.execute
# add --kwargs "{'strict': 1}" to fail on drift, e.g. as a deploy step
```

`FAIL` = an `enforced` value drifted (a patch sets it; something undid it).
`WARN` = a `review` value differs — a decision waiting to be made, not an error.
`SKIP` = the doctype or field is absent (an app not installed, or a vendored rename), reported rather
than silently passing.

**It only reads.** Nothing writes a setting or repairs anything: `enforced` items are set by their own
patch, and quietly reverting a deliberate admin change from inside a checker would be the same class
of surprise this exists to surface.

Two things it proved on its first real runs. On `marley.local` it reports **13 ok · 1 to review** —
the review being `enable_telemetry = 1`, which is audit N3 turned from a paragraph nobody re-reads
into something a machine raises. On `test.marley.local` it reports **3 drifted**, correctly: the email
patch has never run there. A checker that only ever says "ok" would have said "ok" to both.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.2 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Recommended action 2 done — the settings are now a declared spec with a checker, and the doc records how to run it |
| 1.1 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Annotated L1 as resolved — Helpdesk's outgoing email is disabled by patch |
| 1.0 | 2026-08-25 | Sarvesh-SocialAngel (AI-assisted) | Audited the vendored Helpdesk surface: 3 live, 5 latent and 3 contained findings, with the settings table that governs them |
