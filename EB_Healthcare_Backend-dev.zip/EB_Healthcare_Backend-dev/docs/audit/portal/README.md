# Patient Portal — audit

**Doc status:** record · **Created:** 2026-09-03 by Gaurav · **Updated:** 2026-09-03 by Gaurav · **Version:** 1.0

<!-- INDEX: manual -->
<!-- This README is the audit document itself, not a generated directory index.
     scripts/gen_doc_indexes.py treats every directory README as its index and,
     finding no BEGIN/END markers here, would append a generated file list under
     the revision history (gen_doc_indexes.py:109 appends; it does not overwrite).
     The marker above makes the generator skip this file (see its line 16). -->

**Status:** ✅ audited 2026-09-03 — PP1–PP16 logged, all decisions pending · **Area:** Patient-facing · **Repo:** `Healthcare_Patient_Portal`
**Audited against:** backend `dev` @ `9913ea2` · portal working tree as of 2026-08-20 (no VCS — see PP3).
**Professional lens:** the patient portal is the only surface a *patient* touches unsupervised. It carries their identity, their record and their consent — so the two questions that matter are "is this really their data?" and "can they exercise their rights over it?". This repo answers neither, because it is not connected to anything.

> **Headline: `Healthcare_Patient_Portal` is a design prototype, not the patient portal.**
> 3,341 lines, 11 screens, zero backend calls. The working portal is a different
> repo — see PP2 before planning any work here.

---

## 1. What this repo is

| | |
|---|---|
| Package name | `narzim-patient-portal` v0.1.0 |
| Stack | Next.js 14.2.35 App Router · next-intl 4 · Tailwind · Radix · zod · zustand |
| Size | 3,341 lines (2,006 in `app/`, 11 pages) |
| Backend calls | **zero** — no `fetch`, no `axios`, no `frappeFetch`, no `/api/` route |
| Tests | **zero** |
| Middleware | **none** (`middleware.ts` does not exist) |
| Version control | **none** — not a git repository |
| README | unmodified `create-next-app` boilerplate |

Every screen renders `lib/portal/data.ts` (140 lines) or `lib/sampleData.ts`
(348 lines) — hardcoded fixtures including a fictional patient with a
CURP, an NSS and an MRN.

## 2. REAL vs MOCK vs MISSING (the headline)

| Screen | Lines | State | Evidence |
|---|---|---|---|
| `/portal/login` | 109 | 🟡 **INERT** | `<form action="#" method="POST">`, no submit handler, no auth call (PP4) |
| `/portal/activate-account` | 128 | 🟡 **MOCK** | static markup; links to `/portal/login` |
| `/portal/home` | 189 | 🟡 **MOCK** | `lib/portal/data` |
| `/portal/health` | 222 | 🟡 **MOCK** | `lib/portal/data` |
| `/portal/appointments` | 97 | 🟡 **MOCK** | `lib/portal/data` |
| `/portal/appointments/schedule` | 349 | 🟡 **MOCK** | booking wizard over fixtures; nothing is submitted |
| `/portal/chat` | 132 | 🟡 **MOCK** | `lib/portal/data`; backend chat exists and is unused (PP13) |
| `/portal/settings` | 187 | 🟡 **MOCK** | `lib/portal/data` |
| `/portal/access` | 176 | 🟡 **MOCK** | device/session revoke + OTP are `useState` only |
| `/portal/telemedicine/[room]` | 227 | 🔴 **NO BACKEND EXISTS** | zero telemedicine methods anywhere in the backend (PP12) |
| `/portal` (index) | 5 | — | redirect shim |

There is no 🟢 REAL row. That is the finding.

## 3. Gaps

| # | Gap | Class | Sev | Recommendation |
|---|---|---|---|---|
| **PP1** | **Zero backend integration.** No network call of any kind in 3,341 lines. All 11 screens render hardcoded fixtures. | Mock | **Critical** | Decide this repo's purpose (PP2) before writing a line of integration code. |
| **PP2** | **Three repos claim to be the patient portal**, and the other two are the ones actually wired: `EB_Healthcare_PatientPortal` (14 files reference the portal API, git-tracked, last commit 2026-07-07) and `Healthcare-super-app` (10 files, last commit 2026-06-15). This repo references it in **0**. | Ambiguity | **Critical** | Name the authoritative portal repo in `docs/README.md` and archive or clearly label the others. Same defect class as D1/D6 in `DOCS_AUDIT.md`: a reader cannot tell which artifact is real. |
| **PP3** | **Not a git repository.** No history, no remote, no branch, no review trail. Losing the directory loses the work. | Process | **High** | `git init` + push, or delete it. An untracked 3,341-line codebase on one laptop is not a state to leave things in. |
| **PP4** | **Login is inert and nothing is protected.** `<form action="#">` with no handler; no `middleware.ts`, so `/portal/home`, `/portal/health` and every other route render for an unauthenticated visitor. | Auth | **High** | Harmless while the data is fake, fatal the moment it isn't. Route protection must land in the same change as the first real API call, not after. |
| **PP5** | **6 of 11 internal links 404**: `/`, `/contact`, `/legal/terms`, `/legal/privacy`, `/legal/cookies`, `/portal/reset-password`. | Dead link | **High** | The three legal routes are the serious ones — see PP7. |
| **PP6** | **`ComplianceBadge` is built to assert six regulatory claims** — COFEPRIS, NOM-024, NOM-004, CFDI, LFPDPPP, ISO 27001. It is currently **never imported**, so nothing renders today. | False claim (latent) | **High** | ISO 27001 and COFEPRIS are things an organisation either holds or does not. Delete the variants that are not held before this component is ever mounted. Mirrors front-desk L1/L2 (`screens/00-login.md`). |
| **PP7** | **ARCO rights are typed but not implemented.** `lib/consent.ts` defines `ArcoRequest`, `PatientConsent`, `AuditLogEntry` and a `getArcoDueDate()` that computes the 20-business-day deadline citing *LFPDPPP Art. 24*; `messages/en/patient.json` carries a translated `arco` namespace. **No screen submits an ARCO request.** | Compliance | **High** | Under LFPDPPP a data subject's access/rectification/cancellation/opposition rights are not optional. Either build the flow or remove the scaffolding that implies it exists. |
| **PP8** | **Cookie consent is never collected.** `CookieBanner.tsx` is the only consumer of `consent.ts`, and `CookieBanner` is imported by no file — so the banner never mounts and `saveCookieConsent()` is never called. | Compliance | Med-High | Decide whether the portal needs a banner at all; if yes, mount it, if no, delete `consent.ts`'s cookie half. |
| **PP9** | **i18n is fully wired and almost entirely unused.** `NextIntlClientProvider` is mounted in `app/layout.tsx`, 6 namespaces and **375 keys** exist — and the 11 screens make **2 `t()` calls between them**. Every visible string is hardcoded English. | i18n | **High** | Bilingual is a product requirement (CLAUDE.md §13.10). This is the whole-portal version of front-desk FD6. |
| **PP10** | **Spanish is missing exactly where it is legally required.** `legal.json`: 74 keys in `en`, **13** in `es-MX` — 69 untranslated. `developers.json`: 42 vs 17. | i18n / compliance | **High** | The *aviso de privacidad* is a legal document for a Mexican deployment; English-only does not discharge it. |
| **PP11** | **Default locale is `"en"`** (`lib/i18n.ts:6`) for a product whose default jurisdiction is Mexico. | i18n | Med | ADR-018 makes `mx` the default profile with `es-MX` primary. Flip the fallback, or drive it from `ComplianceProfile.primary_language`. |
| **PP12** | **The telemedicine screen has no backend to connect to.** 227 lines behind a `/telemedicine/[room]` dynamic route; there is not one telemedicine, video-room or meeting method in the entire backend. | Missing | Med | Either a product commitment nobody has recorded, or a mockup that should be deleted. Needs an owner's answer, not an engineer's guess. |
| **PP13** | **28 built backend methods have no consumer here.** See §4. | Dead surface | Med | The backend is ahead of the frontend, not behind it. |
| **PP14** | **6 of 7 shared components are never imported** — `ComplianceBadge`, `CookieBanner`, `LanguageToggle`, `LegalPageLayout`, `StepCard`, `TestimonialCard`. Only `Button` is used, by one file. | Dead code | Low-Med | Suggests the repo was cut down from a larger marketing site. Supports the PP2 reading. |
| **PP15** | **Zero tests**, no test tooling in `package.json`. | Coverage | Med | Defer until PP2 is answered — testing a fixture renderer proves nothing. |
| **PP16** | **Two Next configs**: `next.config.js` (real, applies the next-intl plugin) and an empty `next.config.mjs`. **Verified not a live bug** — Next 14.2.35's `CONFIG_FILES` lists `next.config.js` first, so it wins and the `.mjs` is ignored. | Cleanup | Low | Delete `next.config.mjs`. It is a trap: editing it has no effect, silently. |

## 4. The 28 unused backend methods

`api/v1/patient_portal/api.py` (1,164 lines, 1,644 lines of tests) exposes a
complete portal surface. This frontend calls none of it.

| Portal screen that would use it | Backend methods available |
|---|---|
| Login / activation | `register` *(`allow_guest`)*, `get_my_account`, `update_my_account` |
| Home | `get_my_clinical_summary`, `get_my_next_follow_up` |
| Health record | `get_my_health_record`, `list_my_vital_signs`, `list_my_encounters`, `get_my_encounter`, `list_my_lab_tests`, `get_my_lab_test`, `get_my_lab_result_summary` |
| Health record — patient-reported | `add_my_allergy`, `add_my_condition`, `add_my_medication` |
| Appointments | `list_my_appointments`, `get_my_appointment`, `book_my_appointment`, `cancel_my_appointment`, `reschedule_my_appointment`, `get_my_available_slots`, `list_appointment_types` |
| Clinic / doctor pickers | `list_clinics`, `list_practitioners`, `list_doctor_profiles` |
| Documents | `list_my_documents`, `list_my_document_categories`, `upload_my_document` |
| Chat | *(separate module)* `messages.api`: `list_threads`, `get_thread`, `send_message`, `start_thread`, `mark_read`, `list_contacts` — see ADR-036, ADR-037 |
| Telemedicine | **none exist** (PP12) |

## 5. Permissions

Nothing to audit on this side: there is no auth, no session, no role check and no
middleware. The backend's portal scoping is real and tested
(`tests/patient_portal/test_portal_scoping_guardrails.py`, `test_multirole_authorization.py`)
— but no client here exercises it.

One backend item worth a separate look, out of scope for this pass:
`register()` is `@frappe.whitelist(allow_guest=True)`, i.e. unauthenticated
self-signup that creates records. The code defends it by analogy to core Frappe's
website signup. On a PHI surface under LFPDPPP/DPDPA that analogy deserves testing
rather than assuming.

## 6. Open questions for product owner

1. **PP2 — which repo is the patient portal?** Nothing else here can be planned until this is answered. Three candidates, two of them wired, this one not.
2. **PP12 — is telemedicine a committed feature?** There is a built screen and no backend. Either it needs an ADR and a backend, or the screen should go.
3. **PP6 — which of the six compliance claims does the organisation actually hold?** COFEPRIS, NOM-024, NOM-004, CFDI, LFPDPPP, ISO 27001. Each unheld one must be deleted from the component.
4. **PP7 — who owns the ARCO request flow?** It is a legal obligation with a 20-business-day clock, currently represented only by a TypeScript interface.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Gaurav | Initial audit — PP1–PP16 against backend `dev` @ `9913ea2` |
