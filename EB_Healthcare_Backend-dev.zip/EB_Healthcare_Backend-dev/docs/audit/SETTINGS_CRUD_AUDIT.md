# Settings Masters — E2E CRUD Audit (Frontend ↔ Backend)

**Doc status:** record · **Created:** 2026-07-07 by Invincible · **Updated:** 2026-07-07 by Sarvesh-SocialAngel · **Version:** 1.0

**Role audited:** `EB_Healthcare Admin` (user `admin@narzim.com`)
**Repos:** `Healthcare_next_app` (Next.js BFF + hooks) ↔ `EB_Healthcare_Backend` (Frappe whitelisted API)
**Date:** 2026-07-06
**Method:** static cross-repo read of `settings-nav.ts`, `src/hooks/use-admin-*`, `src/app/api/admin/**`, `src/lib/api/*` on the FE; `api/v1/admin/*` + sibling modules on the BE. No live runtime CRUD exercised (see "How to complete" at end).
**Scope:** the Settings masters an admin can open + edit. Verifies each master's CRUD is (a) wired on the FE, (b) backed by a real method, (c) routed through the permission-checked whitelisted layer vs Frappe's built-in `/api/resource/`.

---

## 0. Executive summary

- **The OPD/settings CRUD is real** — nearly every master has working list/create/update/delete against the backend. This is not mock data.
- **The one systemic gap is the `/api/resource/` bypass (audit finding C-4).** A subset of masters read and/or write directly through Frappe's built-in `/api/resource/`, bypassing the `require_permission()` + error-envelope service layer that CLAUDE.md §3/§11 mandate. For those, **the ONLY access control is the `EB_Healthcare Admin` DocType role permissions** — so correctness of that role's perms is load-bearing.
- **5 masters have NO custom backend method at all** (100% `/api/resource/`): **Medical Department, Patient Care Type, Item Group, Price List, Tax Category** (+ Lab Test Sample / Sample Collection / generic UOM as pickers).
- **ADR-021 is stale:** it prescribes a generic `master_crud.py` with a server-side field allowlist — **that file was never built.** The code instead hand-wrote bespoke per-doctype methods. ADR-021 should be updated or superseded to match reality.

---

## 1. CRUD matrix (FE wiring ↔ BE method ↔ data path)

Legend — **WL** = whitelisted `/api/method` (compliant); **RES** = Frappe `/api/resource/` (C-4 violation). CRUD = ops present end-to-end.

| Master | FE CRUD | List path | Write path | Backend methods | Delete guard | Notes |
|---|---|---|---|---|---|---|
| **Brands** | C R U — | WL | WL | get/create/update, **no delete** | n/a | Delete intentionally omitted (permanent ref data; edit/rename). ✅ consistent FE+BE |
| **Manufacturers** | C R U D | WL | WL | full CRUD | ⚠ raw (unguarded delete) | needs `EB_Healthcare Admin` DocPerm delete grant (plan §28) |
| **Dosage Forms** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean |
| **Medication Classes** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean |
| **Prescription Dosages** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean |
| **Prescription Durations** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean |
| **Complaints** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean (now MasterTable) |
| **Diagnosis** | C R U D | WL | WL | full CRUD | ✅ LinkExists | clean; update = rename |
| **Therapy Types** | C R U D | **RES** | WL | list/create/update/delete | ⚠ raw delete | list read bypasses; writes WL |
| **Clinical Procedures** | C R U D | **RES** | WL | list/create/update/delete | ⚠ raw delete | list read bypasses; writes WL |
| **Treatment Plan Templates** | C R U D | WL | WL | full CRUD (+child rows) | ✅ LinkExists | clean; rich builder |
| **Item Groups** | C R U D | **RES** | **RES** | **none** | Frappe default | 100% bypass; `standardCrud` writes raw |
| **Lab Test Templates** | C R U D | **RES** | WL | create/update/delete (+child) | ⚠ raw delete | list read bypasses |
| **Lab Test Units** | C R U D | WL | WL | full CRUD | — | ADR-021-clean |
| **Unit Conversions** | C R U D | WL | WL | full CRUD | — | ADR-021-clean |
| **Medications** | C R U D | **RES** | WL | create/update/delete (+child, core routing) | ⚠ raw delete | list read bypasses; **cap 500** |
| **Payment Methods** | C R U D | WL | WL | full CRUD | ✅ LinkExists | `accounts` child not managed |
| **Insurance Payors** | C R U D | **RES** | WL | create/update/delete | ⚠ raw delete | list read bypasses; writes handle claim-account children |
| **Price Lists** | C R U D | **RES** | **RES** | **none** | Frappe default | 100% bypass; `standardCrud` |
| **Tax Categories** | C R U D | **RES** | **RES** | **none** | Frappe default | 100% bypass; `standardCrud` |
| **Items** | C R U D | WL | WL | full CRUD (+Item Price) | ⚠ raw delete | clean path |
| **Medical Departments** | C R U D | **RES** | **RES** | **none** | Frappe default | 100% bypass; `standardCrud`; portal_image editable raw |
| **Practitioners** | C R U D | **RES** | WL | create/update/delete + schedule CRUD | — | list via providers; rich detail |
| **Company** | C R U — | **RES** | WL | get/create/update, no delete | n/a | `noDelete` (expected) |
| **Facilities / Service Units** | C R U D | (providers module) | WL | service-unit create/update/delete | — | outside admin layer |
| **Appointment Types** | C R U D | (healthcare module) | WL | full CRUD (+service Item) | ⚠ raw delete | outside admin layer |
| **Vaccine Schedules / Immunization Programs** | C R U D | (immunization module) | WL | full CRUD + assign | — | outside admin layer |
| **Holiday Lists** | C R U D | WL | WL | full CRUD | — | ADR-021 pilot |
| **Users** | C R U — | WL | WL | list_staff/invite/update, no delete | n/a | deactivate via update |
| **Role Permissions** | R U | WL | WL | get/update | n/a | single config doc |

---

## 2. Gaps & findings

### G-1 — `/api/resource/` bypass, no backend method at all `[CRITICAL — = audit C-4]`
**Medical Departments, Patient Care Type, Item Groups, Price Lists, Tax Categories** (+ Lab Test Sample / Sample Collection / UOM pickers) have **zero custom backend methods** — every op is raw `/api/resource/`. The BFF only checks `requiredFields` presence; it does **not** whitelist writable fields, so the client can set any writable field on these doctypes. Access control rests entirely on the `EB_Healthcare Admin` DocType perms being correct.
**Fix:** either build whitelisted CRUD (bespoke or the ADR-021 generic `master_crud`), or write an ADR that formally accepts a low-risk exception. Not "silent."

### G-2 — `/api/resource/` read bypass on otherwise-compliant masters `[HIGH]`
**Therapy Types, Clinical Procedures, Lab Test Templates, Medications, Insurance Payors, Practitioners, Company** write through whitelisted methods but **list through `/api/resource/`**. The `listMethod` flag (ADR-021) is the migration lever; only Holiday Lists / Lab Test UOM / Unit Conversions have adopted it.
**Fix:** add `list_*` whitelisted methods + `listMethod` in the BFF registry.

### G-3 — Hardcoded list caps silently truncate `[HIGH]`
Medications **500**, Lab Tests **300**, Therapy Types/Clinical Procedures/Item Groups/UOM **500**. The generic `[resource]` GET returns `data ?? []` with **no total/pagination**, so the FE cannot even detect truncation. A real pharmacy catalog >500 loses rows from lists **and prescribing pickers** with no "more" affordance. **Medications is highest risk.**
**Fix:** bump caps + return a total, or paginate; at minimum surface a "showing first N" state.

### G-4 — Unguarded deletes `[MEDIUM]`
`delete_manufacturer`, `delete_medication`, `delete_insurance`, `delete_lab_test_template`, `delete_therapy_type`, `delete_clinical_procedure_template`, `delete_appointment_type` use raw `frappe.delete_doc` (no `LinkExistsError` guard) — deleting one in use surfaces a raw Frappe error and risks orphaning refs. The one-field masters (dosage-form, class, dosage, duration, complaint, diagnosis, payment) ARE guarded.
**Fix:** add LinkExists guards to the unguarded set for a clean "in use, cannot delete" message.

### G-5 — Rename-on-edit for one-field masters `[LOW — verify]`
Diagnosis / Complaint / Dosage Form: the doc `name` IS the value, so "edit" renames the primary key. Cascade to linking documents depends on backend rename behavior the FE can't see. **Verify** rename cascades (or is blocked when referenced).

### G-6 — ADR-021 vs reality `[process]`
ADR-021 (status **Proposed**) prescribes a generic `master_crud.py` with field allowlist — **never built**. Code follows the ADR's rejected alternative (bespoke methods) + the 3-col plan which *accepts* `/api/resource/` for a few low-risk masters. **Two documents prescribe different mechanisms.**
**Fix:** update/supersede ADR-021 to match the shipped approach and explicitly rule on the 5 no-method masters.

---

## 3. Decisions for discussion

1. **G-1 (5 no-method masters):** build whitelisted CRUD, or ADR-accept the exception? (These are low-PHI reference data, but Medical Department + Price List touch clinical routing + money.)
2. **G-3 (caps):** bump-and-total now (cheap), or proper server pagination? Medications especially.
3. **G-4:** add LinkExists guards to the 7 unguarded deletes? (low effort, better UX + safety)
4. **G-6:** who owns updating ADR-021?

---

## How to complete this audit (runtime verification)
This pass is static. To close it E2E, log in as `admin@narzim.com` and exercise one create/edit/delete per master, confirming: (a) the write persists, (b) delete-in-use returns a clean error not a 500, (c) the `EB_Healthcare Admin` role actually permits the op on `/api/resource/` masters. Highest-value runtime checks: Medical Department / Item Group / Price List / Tax Category writes (G-1 perms), and Medications list past 500 (G-3).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-07 | Sarvesh | Initial version (header backfilled from git history) |
