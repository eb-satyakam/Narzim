# Settings → Practitioners

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — PR1→ADR-021, PR2/PR3/PR4 FE-TODO, PR6→BH-9, PR5 inert (single-clinic), PR7 skipped (verified inert) · **Section:** Scheduling & Staff · **Screen 7/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Healthcare Practitioner`** (healthcare app) — the most substantial settings screen: a 3-column master/detail with **user-account provisioning** (an optional login email creates a Website User + `EB_Practitioner` role + set-password email), a **full availability-schedules child-table editor**, and **status→login sync** (disabling a practitioner disables their `User.enabled`). Permissions are clean (admin full CRUD; others read-only — fourth P1 counter-case), and the create/update/delete + detail read all go through **custom whitelisted methods**. Two things stand out: the **list read alone uses generic `/api/resource/`** (the one ADR-021 hole), and a **list-load error is silently rendered as an empty "No practitioners." state**. There's **no hard delete in the UI** (deactivation is via status = Disabled) — a deliberate, correct choice for a doctype with clinical history. The charge-item pickers are proper **searchable comboboxes** (contrast Appointment Types AT3). Familiar gaps: **hardcoded strings** (P6), **thin validation** (notably no email-format check even though it provisions a login), and an **orphaned `custom_company` field**.

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Healthcare Practitioner`** | **generic `/api/resource/Healthcare Practitioner`** via `frappeRestList` (`admin/[resource]/route.ts:222`, `client.ts:214`) — **ADR-021 hole (PR1)** |
| Detail (read) | `Healthcare Practitioner` | custom `providers.api.get_provider_detail` (`api/healthcare/practitioners/route.ts:14`; hook calls `/api/providers`) ✅ |
| Create | `Healthcare Practitioner` | custom `admin.api.create_practitioner` (`api/v1/admin/practitioners.py:88`) ✅ |
| Update | `Healthcare Practitioner` | custom `admin.api.update_practitioner` (`practitioners.py:245`) ✅ |
| Delete | `Healthcare Practitioner` | custom `admin.api.delete_practitioner` (`practitioners.py:448`) — **exists but not wired to UI** |
| Schedules | `Practitioner Schedule` + `Practitioner Service Unit Schedule` (child) | custom create/update/assign/delete schedule endpoints (`practitioners.py:536+`) |

- **Frontend:** 3-column master/detail under `/settings/practitioners`: list `practitioners-list.tsx`, profile `practitioner-profile.tsx`, form `practitioner-form.tsx`. Hooks `use-admin-practitioners.ts` (generic `createAdminResource("practitioners")`) + hand-written `useGetPractitionerDetail` (GET `/api/providers?id=`). Nav `settings-nav.ts:48` (**Scheduling & Staff**).
- **ADR-021 / Rule 11:** **PARTIAL** — writes + detail read are custom whitelisted ✅; **only the list GET uses `/api/resource/`** ❌ (**PR1**). Note the existing `get_providers` custom list can't be reused as-is (it's Active-only; settings must show Disabled too).

## 2. Permissions — clean (fourth P1 counter-case)
DocPerm spec `patches/v0/eb_docperm_spec.json:1069`:
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ✅ |
| EB_Front Desk / EB_Practitioner / EB_Nurse | ✅ | — | — | — |

Admin full CRUD; create/edit UI correctly permission-backed. **No P1 mismatch.**

## 3. Field parity + control types
Backend key fields: `first_name` (Data, **reqd**), `middle_name`, `last_name`, `practitioner_name` (auto, read-only), `gender` (Link→Gender), `status` (Select Active/Disabled, **reqd**, default Active), `mobile_phone` (Data), `practitioner_type` (Select Internal/External), `department` (Link→Medical Department), `designation` (Link, read-only, `fetch_from` employee), `user_id` (Link→User), `op_consulting_charge_item`/`op_consulting_charge` (Link→Item / Currency), `inpatient_visit_charge_item`/`inpatient_visit_charge`, `image` (Attach Image, hidden), `show_in_portal` (Check), `practitioner_schedules` (child), **`custom_company` (Link→Company, "Clinic")**, `hospital` (Data, legacy).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| First / Middle / Last Name | `first_name`/`middle_name`/`last_name` | Data | text | ✅ | both | first_name yes |
| Login Email | → provisions `user_id` | Link→User | email input (create/link) | ✅ | both; read-only display once linked | no |
| Department | `department` | Link→Medical Department | `<select>` (portal depts) | ✅ | both | no |
| Mobile Phone | `mobile_phone` | Data | dial-code + tel (`PhonePicker`) | ✅ | both | no |
| Gender | `gender` | Link→Gender | `<select>` (4 fixed) | ⚠️ Link-as-fixed-enum (minor) | both | no |
| Type | `practitioner_type` | Select | `<select>` Internal/External | ✅ | both | no |
| Status | `status` | Select | `<select>` Active/Disabled | ✅ | edit-only | yes (defaults Active) |
| OPD / Inpatient Charge Item | `*_charge_item` | Link→Item | **searchable `ChargeItemPicker`** | ✅ (good — contrast AT3) | both | no |
| OPD / Inpatient Charge | `*_charge` | Currency | number | ✅ | both | no |
| Availability Schedules | `practitioner_schedules` | Table | **full row editor** (schedule + service unit) | ✅ (good — like HL) | edit-only | no |

**Not surfaced:**
- **`custom_company` ("Clinic")** — our own custom field (added for the Command Centre dashboard to group practitioners by clinic); neither the create/update API nor the UI reads/writes it → **always empty, dashboard grouping can't work** (**PR5**, P10 inert field).
- **`image`** (practitioner photo) — fetched by the list GET but no upload control or display in the form (**PR6**); contrast MD5's "surface every field" principle.
- **`show_in_portal`** — controls patient-portal visibility; hidden (**PR7**).
- `designation` (read-only fetched), `hospital` (legacy Data) — low value, skip.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| PR1 | **List read via generic `/api/resource/Healthcare Practitioner`** (`route.ts:222`, `client.ts:214`) — the only non-custom data path (writes + detail are clean). | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021.** Migrate the list read to a whitelisted admin `list_practitioners` (must include Disabled, unlike Active-only `get_providers`) under ADR-021's `master_crud` — no separate per-screen decision. |
| PR2 | **List-load error rendered as empty state** — `useAdminPractitioners` error is ignored (`data=[]`), so a backend/network failure shows "No practitioners." as if the clinic simply has none. | Error UX (**P11**) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card (like the other screens' amber `loadError`). First instance of P11; sweep other list screens. |
| PR3 | **Fully hardcoded strings — no `useTranslations`** (form/list/profile). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.practitioners` catalog (en + es-MX). |
| PR4 | **Thin validation** — only `first_name` on create; **no email-format check** even though the email provisions a login User; no phone/number guards. | Validation | **Medium** | ✅ **DECIDED: frontend fix** — validate email format especially (bad email → broken/duplicate login account server-side), plus name-on-edit + numeric guards. |
| PR5 | **`custom_company` ("Clinic") orphaned** — field exists for Command Centre dashboard grouping but is never populated (API + UI both ignore it). | Inert field (P10) | Low–Med | ✅ **DECIDED: accept inert for now.** Single-clinic → grouping is moot. Revisit (populate + surface) with the multi-clinic clinic selector (cf. SU2). Command Centre clinic-grouping is knowingly inert until then. |
| PR6 | **Practitioner `image` not surfaced** — no upload/display; useful for portal/booking cards. | Missing field (P8) | Low | ✅ **DECIDED: surface a photo upload** (reuse `/api/admin/upload-image` from MD5, per the "surface every field" principle). Needs backend to accept `image` on create/update → **BH-9**. Frontend TODO. |
| PR7 | **`show_in_portal` not surfaced** — can't control which practitioners appear in patient-portal booking. | Inert field (P10) | — | ✅ **DECIDED: SKIP — verified inert.** Patient Portal repo has 0 refs; the provider list filters by `status` only; nothing filters practitioners by `show_in_portal` (only `seed_practitioners.py` sets it; the field is meaningful for Medical Departments, not practitioners). Same class as Appointment Types `allow_booking_for`. |
| — | **No hard delete in UI** | Design | (n/a) | ✅ **DELIBERATE — keep.** Deactivation via status = Disabled (soft) is correct; hard-deleting a practitioner with encounters/appointments would fail or orphan. Backend DELETE exists but intentionally unwired. No swallowed-delete issue here. |
| — | **ADR-021 writes + detail read; user provisioning; status→login sync; charge comboboxes; schedules editor** | — | — | ✅ Solid. Documented in §0/§3, no finding. |

## 5. Resolved decisions (2026-07-04)
1. **PR7 — RESOLVED: skip (verified inert).** Confirmed `show_in_portal` is not consumed anywhere for practitioners (portal 0 refs; provider list filters `status` only). Same as `allow_booking_for` — don't surface a dead toggle.
2. **PR6 — RESOLVED: surface a photo upload** (reuse MD5's `/api/admin/upload-image`); needs `image` accepted on create/update → **BH-9**. Low priority.
3. **PR5 — RESOLVED: accept inert.** `custom_company` grouping is moot single-clinic; revisit with the multi-clinic clinic selector (cf. SU2).
4. **PR1 — RESOLVED under ADR-021** (list read → whitelisted `list_practitioners` incl Disabled).
5. **PR2 + PR3 + PR4 — RESOLVED: frontend fixes** (distinct list-error card; `settings.practitioners` en+es; validation incl email format).

## 6. Follow-up
- Backend: **BH-9** (see [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md)) — `create/update_practitioner` accept `image`. List read migrates under ADR-021.
- Frontend TODO (separate change): PR2 (error card), PR3 (i18n), PR4 (validation), PR6 (photo upload once BH-9 lands).

## 7. Notable backend behaviors (documented, not gaps)
- **User provisioning:** create/update with a Login Email creates a Website User + `EB_Practitioner` role + set-password email, or links an existing one. User link is not changeable from the UI (Frappe desk only) — deliberate.
- **Status→login sync:** setting status = Disabled sets `User.enabled = 0` (`practitioners.py:438`) — disabling a practitioner disables their login.
- **No hard delete (deliberate):** deactivation is via status; hard delete cascades to Contact/Address (`on_trash`) and would fail if referenced by encounters/appointments.
- **Naming quirk:** JSON declares `naming_series HLC-PRAC-.YYYY.-` but the controller `autoname` names the record by full name (`practitioner_name`). Factual note.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
