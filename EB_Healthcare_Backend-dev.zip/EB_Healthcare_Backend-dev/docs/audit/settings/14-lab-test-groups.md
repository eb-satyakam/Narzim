# Settings → Lab Test Groups (Item Group)

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — IG1→BH-11 (P1 perm grant); IG2→ADR-021; IG4 rename applied (FE); IG3 accept; IG5 folds into LT5 · **Section:** Clinical Data · **Screen 14/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes (except the label rename requested by the owner).

## 0. Headline
"Lab Test Groups" is **not a distinct doctype** — it's the **Groups tab of screen 13** (`/settings/labs?tab=groups`) managing ERPNext **`Item Group`**, which is what the Lab Test Template's `lab_test_group` field links to (the field is mislabeled "Item Group" in core). It's **create + delete only** (no edit, by design). Two real findings: a **P1 permission mismatch** — the UI offers create + delete, but the DocPerm spec grants `EB_Healthcare Admin` only **`read`** on Item Group (IG1) — and **ADR-021**: CRUD goes through generic **`/api/resource/Item Group`** (`standardCrud`), not a custom method (IG2). Error handling on this tab is good (profile error card + delete toast). Per the owner's instruction, the misleading **"Lab Test Groups" label is renamed to "Item Groups"** on the frontend (IG4).

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List / Create / Delete | **`Item Group`** (erpnext core) | **generic `/api/resource/Item Group`** via `standardCrud` (`admin/[resource]/route.ts:73-81`) — **ADR-021 hole (IG2)**; `frappeMethod: "item_group"` is dead config (no such custom method) |
| Update | — | none (create+delete only, by design) |

- **Frontend:** Groups tab of `settings/labs/` — `labs-list.tsx` (list + inline delete), `group-form.tsx` (create), `group-profile.tsx` (delete). Hooks `use-admin-item-groups.ts` (`createAdminResource("item-groups")` → useList/useCreate/useDelete). Nav `settings-nav.ts:60` (`lab-test-groups` → `/settings/labs?tab=groups`).
- **No custom backend method** for Item Group (grep: none in `catalog.py`/anywhere) and **no dedicated BFF route** — it falls through to the generic `[resource]` catch-all with `standardCrud: true`.
- **ADR-021 / Rule 11:** ❌ **VIOLATION** — CRUD via `/api/resource/Item Group`. Same class as MD1/HL7; resolves under ADR-021 `master_crud`.

## 2. Permissions — P1 mismatch
DocPerm spec (`Item Group`): **`EB_Healthcare Admin`** = **`read` only** (no write/create/delete); no other EB role listed.
- **IG1 (P1):** the UI offers **Create** (`group-form.tsx`) and **Delete** (`group-profile.tsx`), but the admin role has **read-only** server-side. Via `/api/resource/`, Frappe enforces native `has_permission` → **create/delete 403** for a user whose only relevant role is `EB_Healthcare Admin` (works only if the user also holds System Manager). Classic P1 (create-capable UI + create-denied role, first seen Company G1).

## 3. Field parity + control types
Backend `Item Group` (create path uses): `item_group_name` (Data, reqd), `parent_item_group` (hardcoded "All Item Groups"), `is_group` (0). Only leaf groups shown (`filters: is_group=0`).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Group Name → **Item Group Name** | `item_group_name` | Data | text | ✅ | create-only (no edit) | yes |

Parent/is_group set implicitly (leaf under "All Item Groups"). No other fields surfaced (correct — this is a category label).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| IG1 | **P1: create+delete UI vs read-only DocPerm.** Admin can't actually create/delete Item Groups server-side (403) unless also System Manager. | Permission (P1) | **High** | ✅ **DECIDED → BH-11:** grant `create` + `delete` on `Item Group` to `EB_Healthcare Admin` via a DocPerm patch (never hand-edit). Product wants admins to manage lab-test categories. Delete-in-use fails safely (LinkExistsError / has-children). |
| IG2 | **ADR-021 violation — CRUD via `/api/resource/Item Group`** (`standardCrud`); `frappeMethod: "item_group"` dead. | Architecture (Rule 11) | **Medium** | ✅ **DECIDED: resolves under ADR-021** `master_crud`. Same as MD1/HL7. |
| IG3 | **No edit (create+delete only)** — can't rename an Item Group. | Missing CRUD | Low | ✅ **DECIDED: accept.** Renaming a referenced Item Group is risky/rare; delete+recreate suffices. |
| IG4 | **Misleading label "Lab Test Groups" / "Groups"** — it's ERPNext Item Group, not a lab doctype. | Clarity / naming | **Medium** | ✅ **DONE (frontend, owner-requested): renamed to "Item Groups".** Nav entry, tab, and group form/profile labels updated. (Note: "Item Group" is ERPNext terminology; a clinical label like "Lab Test Category" would read clearer, but the owner chose "Item Group" for backend alignment.) Strings still hardcoded pending LT5 i18n. |
| IG5 | **Hardcoded strings** (shared labs components). | i18n (P6) | **Medium** | ✅ **DECIDED: folds into LT5** (`settings.labTests` catalog covers these components). |
| — | **Delete-error toast + profile error card handled correctly** (`group-profile.tsx`) | — | — | ✅ No finding (P5 counter-case). |

## 5. Follow-up
- Backend: **BH-11** — DocPerm patch granting `Item Group` create+delete to `EB_Healthcare Admin` (resolves IG1). IG2 folds into ADR-021.
- Frontend: **IG4 rename applied this session** (see commit in `Healthcare_next_app`). i18n (IG5) folds into LT5.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
