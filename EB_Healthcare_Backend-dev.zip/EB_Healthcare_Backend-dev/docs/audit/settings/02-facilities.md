# Settings → Facilities

**Doc status:** record · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-02 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed (F4 parked → screen 13) · **Section:** Clinic · **Screen 2/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only, no backend changes.

## 0. Headline — what this screen actually is
"Facilities" is **not** `Healthcare Service Unit`, `Warehouse`, or `Branch`. It is **4 boolean toggles** on the custom per-company DocType **`EB Clinic Settings`**, marking whether the clinic does Pharmacy / Lab / Therapy / Procedures **in-house** vs. **external referral**. The real `Healthcare Service Unit` lives on the separate **"Service Units"** screen (screen 4). Do not conflate them.

These 4 flags are **functional, not cosmetic** — they drive encounter order-routing (`encounter-screen.tsx:136` `useClinicFacilities(company)`): an in-house order stays internal, otherwise it's routed as an external referral.

## 1. Doctype mapping
| Section | DocType | API method(s) |
|---|---|---|
| Facilities toggles | **`EB Clinic Settings`** (custom, per-company; `autoname: field:company`) | `get_clinic_settings` read · `update_clinic_settings` write (auto-creates the row) |
| Clinic selector | `Company` | `get_companies` |

- **BFF:** `/api/admin/clinic-settings` (GET/PATCH) → `admin.api.get_clinic_settings` / `update_clinic_settings`. Company list via `/api/companies`.
- **Frontend:** `src/components/settings/facilities-section.tsx`; hooks `useClinicSettings` / `useUpdateClinicSettings`; route `/settings/facilities`.
- **Architecture:** custom whitelisted methods only — **no `/api/resource/`** (compliant). ✅
- **Shared doctype:** `EB Clinic Settings` backs **5 screens** — Facilities, Notifications, Access & Security, Appearance, Role Permissions. Each screen edits its own field subset via the same GET/PATCH. (Relevant when we reach those screens.)

## 2. Permissions (DocPerm spec + doctype JSON agree)
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ❌ |
| EB_Front Desk / EB_Nurse / EB_Practitioner | ✅ | ❌ | ❌ | ❌ |

- Screen needs read + write → admin has both. **No UI-offered-but-denied mismatch** (unlike Company G1). ✅
- Clinical roles have **read** (needed because `useClinicFacilities` drives encounter order-routing for all clinical roles) but no write. `/settings` is admin-gated at the route level, so they can't reach this screen anyway.

## 3. Field-by-field parity + control types — clean 1:1
| Frontend field | Backend field | fieldtype | UI control | Correct control? | Editable | Req |
|---|---|---|---|---|---|---|
| Clinic | `company` | Link→Company | `<select>` from `get_companies` | ✅ (dropdown, not free text) | yes | yes (BE) |
| Pharmacy | `has_internal_pharmacy` | Check | toggle switch | ✅ | yes | no |
| Lab / Diagnostics | `has_internal_lab` | Check | toggle switch | ✅ | yes | no |
| Therapy / Rehabilitation | `has_internal_therapy` | Check | toggle switch | ✅ | yes | no |
| Procedure Room | `has_internal_procedures` | Check | toggle switch | ✅ | yes | no |

- **Backend fields not surfaced (Facilities scope):** none — all 4 flags present. (The other 13 `EB Clinic Settings` fields belong to Notifications/Access/Appearance/Role-Perms screens — out of scope here, not a defect.)
- **UI fields with no backend mapping:** none.
- **Link/Select as free text:** none (`company` is a proper dropdown).
- **Required not enforced:** none — Save disabled until a company is selected (auto-selects first company on load).

## 4. CRUD / validation / states
- **CRUD:** Create (implicit, auto-created on first save) · Read · Update. **No delete** — correct; this is a per-company config row, not a list entity.
- **Validation:** `company` required + unique (guaranteed by `autoname: field:company`); bool coercion via `_truthy`. Appropriate for boolean data.
- **Loading:** ✅ spinner. **Empty:** if no companies, select is empty and Save disabled — but no explicit "no clinics" message. **Error:** ⚠️ **no error UI** — see F1.

## 5. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| F1 | **Save failure is silently swallowed** — `useUpdateClinicSettings` has no `onError`; a failed PATCH (403/network) shows no message, button just leaves pending. `useCompanies` also swallows 403 → `[]`. | Error UX | **High** | ✅ **DECIDED: fix now (frontend).** Add `onError` → toast + keep form dirty for retry. Sweep all settings mutations for the same gap (P5). |
| F2 | **All UI strings hardcoded English** — "Facilities", "In-house", "External referral", "Save changes", etc. No message-catalog use. Violates CLAUDE.md §13.10 (bilingual). Likely systemic across settings screens. | i18n | Medium | ✅ **DECIDED: batch fix.** Log per screen; fix in one dedicated i18n pass across all settings screens at the end (one consistent catalog change, not scattered edits). Tracked as pattern P6. |
| F3 | No explicit "no clinics configured" empty state. | Empty state | Low | ✅ **DECIDED: fix now (frontend)**, alongside F1. |
| F4 (Q) | **Completeness check:** the 4 flags map 1:1 to the 4 encounter order types (drug/lab/procedure/therapy). Is there an orderable type not covered — e.g. **Imaging/Radiology** — that would need a 5th `has_internal_imaging` flag? | Missing field? | Medium | ⏸️ **PARKED — carry to screen 13 (Lab Test Templates).** ERPNext has no native imaging order type (imaging = Lab Test template or Clinical Procedure). Risk: clinics often do bloodwork in-house but refer out X-ray/ultrasound — if imaging is bucketed under Lab, `has_internal_lab` would wrongly keep it in-house. Resolve when auditing how imaging templates are categorized; likely a per-template routing override rather than a 5th global flag. |

## 6. Open questions for product owner
1. **F1:** confirm we add proper save error handling (toast/inline) — this is the one real defect here.
2. **F4:** does the clinic ever order **imaging/radiology** as a distinct type (separate from lab tests)? If yes, Facilities is missing an in-house/referral flag for it.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
