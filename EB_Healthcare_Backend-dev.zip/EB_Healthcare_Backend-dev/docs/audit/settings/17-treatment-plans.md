# Settings → Treatment Plans

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — TP1/TP2/TP3/TP4 FE-TODO; TP5 skip; renamed "Treatment Plan Templates" (FE, owner-requested). No backend hand-off. · **Section:** Clinical Data · **Screen 17/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Treatment Plan Template`** (healthcare) — the richest Clinical Data master: parent demographics (department, gender, age range, description, goal) plus **two child tables** — **`items`** (Treatment Plan Template Item: a Therapy/Procedure/Lab-Test template + qty + instructions) and **`drugs`** (Drug Prescription: medication + dosing). The screen is **well-built**: full CRUD, both child-table editors, ADR-021-clean (dedicated custom routes), the **list handles `isError` correctly** (P11 counter-case), and **DocPerm grants `EB_Healthcare Admin` full CRUD (no P1** — the sweep's second clean master after Diagnosis). Field parity with the custom API is good. The nits: **swallowed delete + no confirm dialog** (TP1), **hardcoded strings** (TP2), **thin validation** (TP3, incl. a backend age-range check not mirrored client-side), and **plain `<select>`s** where searchable comboboxes would help long template/medication lists (TP4). One structural oddity: this screen lives under **`/admin/treatment-plans`**, not `/settings/…` like its Clinical Data siblings. Open call: the nav label is **"Treatment Plans"** vs the doctype **"Treatment Plan Template"**.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Treatment Plan Template`** | custom `admin.api.list_treatment_plan_templates` (`catalog.py:3031`) ✅ |
| Detail (read) | `Treatment Plan Template` | custom `admin.api.get_treatment_plan_template` (`treatment-plans/[name]/route.ts:19`) ✅ |
| Create | `Treatment Plan Template` (+ items, drugs) | custom `admin.api.create_treatment_plan_template` (`catalog.py:3095`) ✅ |
| Update | children **replaced** when supplied | custom `admin.api.update_treatment_plan_template` (`catalog.py:3139`) ✅ |
| Delete | `Treatment Plan Template` | custom `admin.api.delete_treatment_plan_template` (`catalog.py:3193`) — savepoint + `LinkExistsError` → friendly "in use, disable instead" ✅ |

- **Frontend:** `src/components/treatment-plans/treatment-plan-form.tsx` (`TreatmentPlanFormView` + `ServiceItemsEditor` + `MedicationsEditor`); list `src/app/(clinic)/admin/treatment-plans/page.tsx`. Hooks `use-admin-treatment-plans.ts` (`createAdminResource("treatment-plans")` + hand-written detail + genders). Nav `settings-nav.ts:63` (**Clinical Data**, label "Treatment Plans", route `/admin/treatment-plans`).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — dedicated custom routes for all ops; never `/api/resource/`.

## 2. Permissions — clean (P1 counter-case)
DocPerm spec `eb_docperm_spec.json:3763`: **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Practitioner` full CRUD; `EB_Nurse` read-only. **No P1 mismatch** for the admin. (Second clean master in the sweep, after Diagnosis; contrast 14/15 where admin was read-only.)

## 3. Field parity + control types
Backend create API accepts: `template_name` (reqd, unique), `medical_department`, `gender`, `patient_age_from/to`, `description`, `goal`, `items[]`, `drugs[]`, `disabled`. The form surfaces **all of them** — good parity.

| Frontend field | Backend | control | Correct? |
|---|---|---|---|
| Template name | `template_name` (Data, reqd, unique) | text | ✅ |
| Medical department / Gender | `medical_department` / `gender` (Link) | `<select>` | ✅ |
| Age from / Age to | `patient_age_from/to` (Int) | number | ✅ (see TP3 — no client range check) |
| Description / Goal | Small Text | textarea | ✅ |
| Disabled | `disabled` (Check) | checkbox | ✅ |
| **Service Items** | `items` → Treatment Plan Template Item | child editor: Type (`<select>` Therapy/Procedure/Lab Test — matches API's `_TPT_ITEM_TYPES`) + Template (`<select>` by type) + qty + instructions | ✅ (type restriction correctly mirrors backend) |
| **Medications** | `drugs` → Drug Prescription | child editor: Medication `<select>` (auto-fills dosing) + drug_name/dosage/interval/uom/period/comment | ✅ |

**Not surfaced (P8, TP5):** inpatient config (`is_inpatient`, `healthcare_service_unit_type`, `expected_length_of_stay`, counselling), and the `practitioners`/`complaints`/`diagnosis` MultiSelects — **none accepted by the custom API either**, so the UI is aligned with the API surface. Low value for OPD.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| TP1 | **Delete error swallowed + no confirm dialog** — `del.mutateAsync(p.name).catch(() => null)` fires directly on click (`page.tsx:41`). Backend returns a friendly "in use, disable instead" on `LinkExistsError`, but the swallow hides it. | Error UX (P5) + destructive-action safety | **Medium** | ✅ **DECIDED: frontend fix** — add a confirm dialog and surface the delete error (toast), so the "disable instead" message shows. |
| TP2 | **Fully hardcoded strings — no `useTranslations`** (page + form). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.treatmentPlans` catalog (en + es-MX). |
| TP3 | **Thin validation** — only `template_name`; **no `age_from ≤ age_to`** (backend `validate_age` 400s otherwise); child rows filtered but not validated; numeric no guards. | Validation | **Medium** | ✅ **DECIDED: frontend fix** — add age-range check (mirror backend) + basic child-row validation. |
| TP4 | **Plain `<select>`s for item Template + Medication** — long lists (many lab tests/procedures/therapies/medications) would benefit from searchable comboboxes (the Medications screen already has the pattern). | Control / UX | Low | ✅ **DECIDED: adopt searchable comboboxes** (reuse Medications-screen pattern), **low priority** — batch with the FE polish pass. |
| TP5 | **Inpatient config + practitioners/complaints/diagnosis MultiSelects not surfaced** — also not in the custom API. | Missing fields (P8) | Low | ✅ **DECIDED: skip** (aligned with API; OPD scope). |
| — | **ADR-021 clean; admin full CRUD (no P1); list handles isError; good field parity; friendly delete error** | — | — | ✅ Strong screen. |

## 5. Resolved — naming
**RENAMED to "Treatment Plan Templates"** (owner-requested, matches the backend doctype). Applied on the frontend: nav entry, page/`AppHeader` titles, form titles + back-link, empty/error copy, add-button label. Strings hardcoded pending TP2 i18n. (Structural note retained: this screen lives at `/admin/treatment-plans`, not `/settings/…` like its siblings — works, just inconsistent; no route change proposed.)

## 6. Follow-up
- **No backend hand-off** (admin full CRUD, ADR-021 clean, API accepts all surfaced fields).
- Frontend TODO: TP1 (confirm + delete error), TP2 (i18n), TP3 (validation), TP4 (comboboxes, low).
- Naming (§5) pending owner decision.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
