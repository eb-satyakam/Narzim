# Settings → Medical Departments

**Doc status:** record · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-03 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — MD2/MD3/MD5 done, MD4 decided (show all), MD1 resolved under ADR-021 · **Section:** Clinic · **Screen 3/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only, no backend changes.

## 0. Headline
Maps to ERPNext Healthcare **`Medical Department`**. It **is** a full CRUD list screen (list + create + edit + delete). **Two real problems:** (1) it does all CRUD through Frappe's **forbidden `/api/resource/` endpoints** (Rule 11 / §3 violation), and (2) the delete error is silently swallowed. Permissions are correct (admin genuinely has full CRUD — no Company-G1-style mismatch).

## 1. Doctype mapping
| Section | DocType | API path |
|---|---|---|
| Departments list + CRUD | **`Medical Department`** (Healthcare core; `autoname: field:department`, `unique`) | **`/api/resource/Medical Department`** ← generic Frappe REST, not a custom method |
| Care-type dropdown | `Patient Care Type` | `usePatientCareTypes()` |

- **Frontend:** `src/components/settings/departments-section.tsx`; hooks `use-admin-departments.ts` → `createAdminResource("departments")`; nav `settings-nav.ts:39`; route `/settings/departments`.
- **BFF:** generic `src/app/api/admin/[resource]/route.ts`, resource key `departments`, configured **`standardCrud: true`** → routes to `frappeRestList/Insert/Update/Delete` = `/api/resource/Medical Department`.
- A legitimate custom read method exists — `providers.api.get_departments` (`providers/api.py:98`, filters `show_in_portal=1`, returns `{name}`) — but it is the **picker used elsewhere, NOT wired to this screen**. There are **no** `create/update/delete_department` custom methods anywhere in `api/v1`.

## 2. Permissions (DocPerm spec + doctype JSON agree) — clean
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ✅ |
| EB_Front Desk / EB_Nurse / EB_Practitioner | ✅ | ❌ | ❌ | ❌ |

Admin genuinely has full CRUD; `/api/resource/` calls pass Frappe DocPerm. **No P1 mismatch.** (Contrast Company G1.)

## 3. Field-by-field parity + control types
| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Medical department name | `department` | Data (unique, reqd) | text input | ✅ | create only (disabled on edit) | ✅ enforced both sides |
| Patient care type | `patient_care_type` | Link→Patient Care Type | `<select>` populated | ✅ (Link-as-dropdown, no free-text bug) | yes | no |
| Show in patient portal | `show_in_portal` | Check | checkbox | ✅ | yes | no |
| Portal image | `portal_image` | Attach Image | image upload + thumbnail | ✅ (added MD5) | yes | no |

- **Backend fields not surfaced:** `portal_image` (Attach Image) — no upload control (F5, low; portal out of scope).
- **UI fields with no backend mapping:** none.
- **Link/Select as free text:** none — `patient_care_type` is a proper dropdown. ✅
- **Required not enforced:** none — `department` enforced client (`:63`) + server (`route.ts` `requiredFields`). Name correctly locked on edit (autoname = primary key).

## 4. CRUD / validation / states
- **CRUD:** Create ✅ · Read ✅ · Update ✅ · Delete ✅ (confirm dialog). Full CRUD present.
- **Validation:** `department` reqd + unique (duplicate → Frappe DuplicateEntryError, surfaced). Delete-in-use relies on Frappe LinkExistsError — but see F2, that error is swallowed.
- **States:** loading spinner ✅, list error panel ✅, empty state ✅. Create/update failures **are** surfaced (try/catch → `submitError`). **Delete failure is NOT** (F2).

## 5. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| MD1 | **`/api/resource/Medical Department` used for all CRUD** via `standardCrud:true`; no custom `api/v1` method backs the screen. Violates CLAUDE.md §3/§11 ("never use `/api/resource/`; all data access through the permission-checked service layer"). Same class as Company C-4. | **Architecture (Rule 11)** | **High** | ✅ **RESOLVED under ADR-021.** ADR chose a generic whitelisted `master_crud` method for all master-data screens (not `/api/resource/`, not per-doctype methods). Medical Departments migrates with the other `standardCrud` screens (HL7, Company C-4) under that one migration — no separate per-screen decision. |
| MD2 | **Delete error swallowed** — `deleteDepartment.mutateAsync(...).catch(() => null)` (`:78`). A blocked delete (department in use → LinkExistsError) closes the dialog as if it succeeded; row reappears with no message. | Error UX (P5) | **High** | ✅ **DONE (frontend).** try/catch → inline error in the confirm dialog, dialog stays open. Verified live. |
| MD3 | **All strings hardcoded English** — headers, columns, dialog copy, error strings. §13.10 bilingual violation (P6). | i18n | Medium | ✅ **DONE (frontend).** All strings → `settings.departments` catalog (en + es-MX), incl. `t.rich` delete warning. Verified live. |
| MD4 | **List shows ALL Medical Departments** incl. ~25 ERPNext system defaults. | UX / data noise | Medium | ✅ **DECIDED: show all** (no filter) — current behavior, no change. Live data confirmed no field cleanly distinguishes system-default from clinic-created, so a filter would be unreliable anyway. |
| MD5 | `portal_image` (Attach Image) not surfaced — while `show_in_portal` (Check) was. | Missing field / consistency | Medium | ✅ **DONE (frontend) — full doctype-field parity.** Added `portal_image` upload to the create/edit dialog via a new generic `/api/admin/upload-image` BFF route (Frappe `upload_file`, no doctype attach → works create + edit). Threaded through type/input/BFF list fields. Verified: upload renders thumbnail end-to-end. **Principle adopted: surface every field the backend doctype has.** |

## 6. Resolved
1. **MD1** — RESOLVED under **ADR-021**: generic whitelisted `master_crud` method replaces `/api/resource/` across all master-data screens (Medical Departments, Holiday Lists HL7, Company C-4). One migration, no per-screen work.
2. **MD4** — DECIDED: **show all** departments (no system-default filter). Live data has no field that cleanly distinguishes ERPNext defaults from clinic-created, so a filter would be unreliable.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
