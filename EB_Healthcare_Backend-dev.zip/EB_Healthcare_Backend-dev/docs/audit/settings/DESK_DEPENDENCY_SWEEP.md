# Desk-Dependency Sweep — "manage everything from the frontend"

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-04 · **Principle:** true multi-tenant SaaS — a tenant (clinic admin) must manage **everything** from the Next.js frontend; the Frappe desk is an internal/superadmin escape hatch only. This sweep enumerates every surface that currently **forces a tenant into the desk** (or is a non-functional placeholder), across 5 areas: nav/screens, config singletons, pricing/tax/accounting, templates/branding, operational/platform.

## 0. Headline
The **master-data layer is in good shape** — all 19 audited masters + Items, Payment Methods, Insurance, Immunization templates/programs are real frontend CRUD. The desk-dependencies cluster in **config, integrations/messaging, financial setup, and platform admin**. Also corrects two earlier assumptions (see §4).

## 1. What IS fully tenant-managed (frontend, no desk) ✅
Master data: screens 1–19 (Company, Facilities, Depts, Service Units, Holiday Lists, Appointment Types, Practitioners, Schedules, Medications, Brands, Manufacturers, Dosage Forms, Lab Test Templates, Item Groups, Complaints, Diagnosis, Treatment Plan Templates, Therapy Types, Clinical Procedure Templates) · **Items** · **Payment Methods** · **Insurance** (Payor + Policy) · **Immunization templates + programs** · **Price List + Tax Category** (via generic REST) · **Users** (invite/role/enable-disable) · **EB Clinic Settings** (facility flags, notification cadence, access/security, appearance fields) · per-user notification channel prefs · company branding (logo/name/address → printed slips) · role-permission *UI-visibility overlay*.

## 2. Desk-dependency gap register
Verdict: **GAP** = tenant can't do it from frontend (desk-only / placeholder / unwired). Disposition → hand-off or fix.

### A. Config singletons the app depends on
| Surface | State | Tenant impact | Disposition |
|---|---|---|---|
| **Healthcare Settings** (core) | desk-only; read internally (invoicing, MRN naming, `op_consulting_charge_item`) | can't configure billing automation | **BH-13** |
| **Selling Settings** (`selling_price_list`) | desk-only; read by catalog/billing | can't set the default price list that drives pricing | **BH-16** |
| **Stock Settings** (`default_warehouse`) | seed-script-only | can't set default warehouse (pharmacy stock) | **BH-16** |
| **Email Account / SMTP** (core) | desk-only | email delivery not configurable | **BH-14** |
| **WhatsApp Settings + WhatsApp Account** (frappe_whatsapp) | desk-only; core dependency for all WhatsApp | can't connect/configure WhatsApp | **BH-14** |
| **AI Settings** (custom) | desk-only; read across integrations | LLM/ASR/flags — **Phase 5**, defer | note (Phase 5) |

### B. Integrations & messaging
| Surface | State | Tenant impact | Disposition |
|---|---|---|---|
| **Integrations screen** (WhatsApp/Email/SMS/Google Cal) | **static placeholder** (`connected:false`, no wiring) | can't connect any channel | **BH-14** |
| **WhatsApp template content** (`WhatsApp Templates`, SysMgr-only) | desk-only | can't author templates | **BH-19** |
| **WhatsApp reminder rules** (`Remedisys WhatsApp Notification`) | desk-only (no FE; send-only in app) | can't add/edit reminder configs | **BH-19** |
| **Email templates** (`Email Template`) | desk-only, unsurfaced | can't customize email content | **BH-19** |
| **Event alert rules** (core `Notification`, fixtures) | desk-only | can't edit event-driven alerts | **BH-19** |
| **Reminder scheduling** (`scheduler_events` commented out) | timing preference storable but **nothing runs it** | **Phase-4 reminders don't fire on schedule** | **BH-17** |

### C. Financial setup
| Surface | State | Tenant impact | Disposition |
|---|---|---|---|
| **Price List / Tax Category** | **managed but via generic `/api/resource`** (`standardCrud`), no custom guard | works; ADR-021 violation | ADR-021 `master_crud` |
| **Sales Taxes and Charges Template** | desk-only | **actual tax rates** on invoices not configurable | **BH-15** |
| **Item Tax Template** | desk-only | per-item tax rates not configurable | **BH-15** |
| **Item Price (bulk / price-list lines)** | no surface (only per-item `rate`) | can't view/bulk-edit a price list's rates | **BH-15** |
| **Chart of Accounts / Account** | desk-only; CoA locked at company create (`COA_SELECTABLE=false`) | can't choose CoA or manage ledgers | **BH-3** (existing) |
| **Fiscal Year** | desk-only | can't set/roll fiscal year | **BH-15** |
| **Currency** | read-only (can pick, can't add / set FX) | can't add a currency or exchange rate | **BH-15** |
| **Cost Center** | desk-only (seed only) | can't manage cost centers | **BH-15** (low) |

### D. Platform / operational
| Surface | State | Tenant impact | Disposition |
|---|---|---|---|
| **Real RBAC** (Frappe DocType permissions) | desk-only; the `role-permissions` screen only edits an app **UI-visibility overlay** (JSON on EB Clinic Settings), not actual record permissions | can't change who can read/write which records | **BH-18** (or explicit "superadmin-only" decision) |
| **User deletion** | only deactivate (`enabled=0`); no `delete_user` | can't remove a user | **BH-18** (minor) |
| **Data import / export / bulk** | none (API + UI) | can't import patients/masters or export data | **BH-20** |
| **Audit log / activity** | `/activity` page is **mock data**; no API | no real audit/activity visibility | **BH-20** |
| **Backups / site config** | superadmin/bench only | — | **Accept** (correctly superadmin) |

### E. Dead / mock UI (frontend bugs — not backend)
| Surface | State | Disposition |
|---|---|---|
| **Appearance** nav entry | routes to `/settings/appearance` but not in `VALID_SECTIONS` + no folder → **404** | **Fix (FE):** build the screen or remove the entry |
| **Subscription & Billing** | mock (`MOCK_INVOICES`, disabled buttons) | **Decide:** wire to real SaaS billing, or hide until built (may be vendor-managed) |
| **Orphan doctype** `remedisys_clinic_settings` | empty (only `__pycache__`), superseded by `EB Clinic Settings` | **Cleanup (BE):** remove |

### F. Not a desk-dependency (noted for completeness)
- **Print layout / letterhead / terms** — Frappe Print Formats are **unused**; patient documents are **hardcoded in React** (`encounter-report.tsx`). Not desk-configurable *or* frontend-configurable → layout changes need code. (Company logo/name/address *do* flow in and are editable.)

## 3. Consolidated hand-offs (added by this sweep)
Existing: BH-1…4, 6–15. This sweep adds:
- **BH-16** — Selling Settings + Stock Settings tenant config (`selling_price_list`, `default_warehouse`) via whitelisted get/update + a "Billing/Inventory defaults" screen.
- **BH-17** — Reminder scheduling: wire `scheduler_events`/notification schedules so the stored `appointment_reminder_timing`/`payment_reminder_timing` actually fire (Phase-4), + surface status in UI.
- **BH-18** — Real permission/user administration: manage Frappe DocType permissions + user deletion from the UI (or a conscious decision to keep RBAC superadmin-only).
- **BH-19** — Messaging content authoring: WhatsApp templates + `Remedisys WhatsApp Notification` rules + email templates + event `Notification` rules, via API + a "Notifications/Templates" screen.
- **BH-20** — Data import/export + real audit-log/activity feed.
- **BH-15 revised** — financial setup bundle: Sales Taxes & Charges Template + Item Tax Template CRUD, Fiscal Year, Currency add, Cost Center, bulk Item-Price editor; and migrate Price List/Tax Category off `/api/resource` to custom methods (ADR-021).
- **Frontend fixes (no BH):** Appearance dead nav (build or remove); Subscription mock (wire or hide); **BE cleanup:** drop orphan `remedisys_clinic_settings`.

## 4. Corrections to earlier opportunistic findings
- **G-C was wrong.** Price List and Tax Category are **managed** (generic REST CRUD), not "read-only/stub, no backend create." The real financial gaps are tax-rate templates, CoA/Account, Fiscal Year, Currency-add, Cost Center, and bulk Item Price — re-scoped into BH-15 above. G-C in `GAPS_SETTINGS_COVERAGE.md` is corrected accordingly.
- **Items / Payment Methods / Insurance** are **real CRUD screens** (the `/admin/*` variants are redirects) — not un-audited gaps. **Vaccine Schedules / Immunization Programs** are **full CRUD**, not out of scope.

## 5. Priority read (for the true-SaaS roadmap)
1. **Quick FE bugs:** Appearance 404, Subscription mock, orphan doctype — cheap, do first.
2. **Phase-4 blockers:** BH-14 (connect WhatsApp/email), BH-17 (reminders actually fire), BH-19 (author reminder/notification content). Reminders are the headline SaaS feature and are currently unwired end-to-end.
3. **Billing setup (Phase-3):** BH-13 (Healthcare Settings), BH-16 (Selling/Stock defaults), BH-15 (tax templates + CoA via BH-3).
4. **Platform admin:** BH-18 (RBAC/user delete), BH-20 (import/export, audit).
5. **Deferred:** AI Settings (Phase 5).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
