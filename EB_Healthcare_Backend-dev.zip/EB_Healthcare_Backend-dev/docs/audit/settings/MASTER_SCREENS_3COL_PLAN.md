# Settings Master Screens — 3-Column Standardization + Full CRUD

**Doc status:** record · **Created:** 2026-07-06 by Invincible · **Updated:** 2026-07-06 by Sarvesh-SocialAngel · **Version:** 1.0

**Goal (owner directive, 2026-07-06):** every settings **master** screen uses the same **3-column** layout (settings-nav · record list · record detail/edit), every master has **view + edit + delete** (not just create/list), and **consolidated masters are split into their own standalone screens** (no grouping under a parent dropdown). Backend CRUD is built where missing.

## Target pattern (the reference)
The 3-column pattern already used by **Practitioners, Lab Test Templates, Complaints, Diagnosis, Items, Insurance, Medications**:
- **Col 1:** settings sidebar (`SettingsSidebar`)
- **Col 2:** record list (`w-72` aside) — search + add + rows
- **Col 3:** routed detail/profile + edit form (`/settings/<x>`, `/settings/<x>/new`, `/settings/<x>/[id]`, `/settings/<x>/[id]/edit`)

## Current state (survey 2026-07-06)
| Pattern | Screens |
|---|---|
| ✅ **3-column (target)** | Practitioners · Lab Test Templates · Complaints · Diagnosis · Items · Insurance · Medications |
| ❌ **List + modal** (convert) | Medical Departments · Service Units · Holiday Lists · Appointment Types · Payment Methods · Immunization Templates · Immunization Programs · Therapy Types · Clinical Procedures · Price Lists · Tax Categories |
| ❌ **Flat table, no view/edit** (convert + needs backend) | **Brands · Manufacturers** |
| ❌ **Consolidated tab → make standalone** | Dosage Forms · Medication Classes · Prescription Dosages · Prescription Durations (under Medications) · Item Groups (under Labs) |
| ✅ **Single-doc form (leave as-is, not a list master)** | Company · Facilities |

## Backend CRUD gaps (what to build)
Confirmed by method survey — only two masters are genuinely missing write methods:
| Doctype | Has | Built |
|---|---|---|
| **Brand** | list, create | **get, update** — **NO delete** (owner decision: brands are permanent reference data; corrections via edit/rename. ERPNext would allow delete but it's intentionally not exposed) |
| **Manufacturer** | list, create | **get, update, delete** (deletable in ERPNext — Stock Manager; blocked when referenced by Items) + DocPerm delete grant for `EB_Healthcare Admin` |
Everything else has full CRUD (Dosage Form, Med Class, Rx Dosage/Duration, Therapy, Clinical Procedure, Complaint, Diagnosis, Item, Mode of Payment, Insurance) or works via generic REST which already supports update/delete (Item Group, Price List, Tax Category). Optional (ADR-021 cleanliness): custom `list_medications` / `list_lab_test_templates` / `list_item_groups` to drop the last `/api/resource` reads — separate from this refactor.

Also DocPerm: Brand already has admin delete; **Manufacturer needs a delete grant** (was BH-10) — fold into the perms patch.

## Phased plan
**Phase 0 — Backend CRUD (this branch: `fix/brand-manufacturer-crud`)**
- Add `get_brand`/`update_brand`/`delete_brand` + `get_manufacturer`/`update_manufacturer`/`delete_manufacturer` to `catalog.py`, register in `admin/api.py`.
- DocPerm patch: grant Manufacturer `delete` to `EB_Healthcare Admin`.
- Verify via bench.

**Phase 1 — Split consolidated masters into standalone 3-col screens (FE-only; backend CRUD already exists)**
- Dosage Forms, Medication Classes, Prescription Dosages, Prescription Durations → own `/settings/<x>` 3-col screens (stop using the Medications dropdown/`SubMasterPanel`).
- Item Groups → own `/settings/item-groups` 3-col screen (stop being a Labs tab).

**Phase 2 — Convert "flat table / list+modal" masters to 3-column**
- Brands, Manufacturers (needs Phase 0), Payment Methods, Therapy Types, Clinical Procedures, Price Lists, Tax Categories, Medical Departments, Service Units, Holiday Lists, Appointment Types, Immunization Templates, Immunization Programs.
- Each: add `list` (col2) + `profile` (col3 view) + `form` (col3 edit) + routes, matching the reference pattern.

**Approach:** build a **reusable 3-col scaffold** (generic list/profile/form parametrized by resource) so simple one-field masters (Brands, Dosage Forms, Complaints-like) are config, not bespoke — avoids 15× hand-written rewrites and keeps them identical. Rich masters (Treatment Plans, Lab Tests, Medications) keep their bespoke detail panes.

## Branching
One branch per screen (or per small group), per the team's convention. Backend gap = `fix/brand-manufacturer-crud`. FE screen conversions = `feat/3col-<screen>` (or grouped `feat/3col-consolidated-masters` for the sub-master split).

## Notes / reversed prior decisions
This supersedes earlier audit dispositions that accepted less: BR1 (Brands create+read only), DF1 (Dosage Forms no edit UI), and the "consolidated tab" acceptance for sub-masters. Owner now wants full 3-col + view/edit + standalone for all.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-06 | Sarvesh | Initial version (header backfilled from git history) |
