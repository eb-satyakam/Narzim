# Settings → Price Lists & Tax Categories

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — PT1 P1 (Price List create+delete) & PT2 P1 (Tax Category delete) → **BH-23**; PT3 ADR-021 → BH-15; PT4 swallowed delete + PT5 i18n FE-TODO. List-error handled. · **Section:** Billing · **Screen 23** (post-completeness-check) · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit.

## 0. Headline
One tabbed screen at `/admin/price-lists` managing two ERPNext core doctypes: **`Price List`** (named selling/buying price lists) and **`Tax Category`**. Both tabs are list + inline dialog with full CRUD, but via generic **`/api/resource`** (`standardCrud`, no custom methods) — an **ADR-021 violation** (PT3). **Two P1 permission gaps:** the UI offers create+delete, but `EB_Healthcare Admin` has **Price List = read/write only** (no create, no delete) and **Tax Category = read/write/create** (no delete). Combined with **swallowed delete errors** (`.catch(() => null)`), those denials fail silently. List-load error *is* handled (P11 counter-case). This is the **financial-setup surface** flagged in the desk-dependency sweep (G-C/BH-15) — note Tax Category carries **no tax rates** (those live in Sales Taxes and Charges Template, still desk-only).

## 1. Doctype mapping
| Tab | DocType | API |
|---|---|---|
| Price Lists | **`Price List`** (erpnext) | **generic `/api/resource/Price List`** via `standardCrud` (`[resource]/route.ts:171`) — ADR-021 hole |
| Tax Categories | **`Tax Category`** (erpnext) | **generic `/api/resource/Tax Category`** via `standardCrud` (`[resource]/route.ts:209`) — ADR-021 hole |

- **Frontend:** `src/app/(clinic)/admin/price-lists/page.tsx` (`PriceListsTab` + `TaxCategoriesTab`). Hooks `use-admin-price-lists.ts` + `use-admin-tax-categories.ts` (both `createAdminResource`, `standardCrud`). Nav `settings-nav.ts:76-77` — **both `price-lists` and `tax-categories` nav keys point to the same `/admin/price-lists` route** (tab toggle).
- **No custom backend methods** for either (grep: none).
- **ADR-021 / Rule 11:** ❌ **VIOLATION** (both) — CRUD via `/api/resource/`.

## 2. Permissions — two P1 mismatches
DocPerm spec:
| DocType | EB_Healthcare Admin | UI offers | Gap |
|---|---|---|---|
| **Price List** | read, write (**no create, no delete**) | create + edit + delete | **create AND delete 403** (PT1) |
| **Tax Category** | read, write, create (**no delete**) | create + edit + delete | **delete 403** (PT2) |
(`EB_Finance` has read/write/create on both; neither role has delete on either.)

## 3. Field parity + control types
**Price List:** `name` (reqd), `currency` (Data/Link), `selling` (Check), `buying` (Check), `enabled` (Check) — all surfaced (name text, currency text w/ default placeholder, three toggles). ✅
**Tax Category:** `name` (reqd), `title` — surfaced (name + title text). ✅
Both are thin masters; field parity is fine. (Price List `currency` is a free-text input vs a `Link`→Currency in ERPNext — minor control nit, low; Currency isn't creatable from the UI anyway per Sweep §C.)

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| PT1 | **P1: Price List create+delete UI vs admin read/write-only.** Both 403. | Permission (P1) | **High** | ✅ **DECIDED → BH-23:** grant `create`+`delete` on `Price List` to `EB_Healthcare Admin`. |
| PT2 | **P1: Tax Category delete UI vs admin no-delete.** Delete 403s. | Permission (P1) | **High** | ✅ **DECIDED → BH-23:** grant `delete` on `Tax Category` to `EB_Healthcare Admin`. |
| PT3 | **ADR-021 violation** — both CRUD via `/api/resource/`. | Architecture | **Medium** | ✅ **DECIDED: resolves under BH-15** (financial-setup bundle migrates Price List + Tax Category to custom methods). |
| PT4 | **Delete errors swallowed** — `.catch(() => null)` on both tabs (`page.tsx:69`, tax tab). Compounds PT1/PT2 — the 403s show nothing. | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — surface delete errors (inline/toast). |
| PT5 | **Hardcoded strings** (both tabs). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** (P6 pass). |
| — | **List-error handled (P11 counter-case); create-error inline; field parity good** | — | — | ✅ |

## 5. Scope note (from the sweep, G-C)
Managing Price List headers + Tax Categories from the UI is **not** the whole financial-setup story — the actual **tax rates** (`Sales Taxes and Charges Template`, `Item Tax Template`), **Fiscal Year**, **Currency add**, **Cost Center**, and **bulk Item-Price editing** remain desk-only. All bundled in **BH-15**. This screen covers only the two thin masters.

## 6. Follow-up
- Backend: **BH-23** — DocPerm patch: `Price List` create+delete + `Tax Category` delete for `EB_Healthcare Admin` (fold into the master-doctype DocPerm sweep with BH-11/12/21/22). **BH-15** migrates both off `/api/resource` + adds the rest of financial setup.
- Frontend: PT4 (surface delete errors), PT5 (i18n via P6).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
