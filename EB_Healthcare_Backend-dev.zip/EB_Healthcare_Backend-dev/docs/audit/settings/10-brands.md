# Settings → Brands

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — BR1→BH-10 (add delete, skip rename); BR2 FE-TODO (i18n); BR3 skip. ADR-021 clean. · **Section:** Clinical Data · **Screen 10/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to ERPNext core **`Brand`** (`erpnext/setup`) — commercial brands assigned to a medication's pharmacy items (`Item.brand`). **Correction to the screen-9 note:** Brands *is* a standalone screen (`[section]/page.tsx:45` → `<BrandsSection />`, and it's in `VALID_SECTIONS`) — the nav entry is **not** dead; clicking it works. This is a **small, clean** screen: a Brand/Description table + inline add form. It's **ADR-021-clean** (custom `list_brands`/`create_brand`, explicit "never `/api/resource/`") and — notably — **handles the list-error state correctly** (amber card, not the P11 empty-state trap). The one real gap: it is **Create + Read only** — no update or delete, on **both** frontend and backend, so brands can't be renamed/edited or removed once added. That's *aligned with the backend surface* (marley `catalog.py` exposes only `list_brands` + `create_brand`), so it is not a frontend workaround — it's a coordinated backend+frontend capability gap.

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Brand`** (erpnext core) | custom `admin.api.list_brands` (`brands/route.ts:13`; `catalog.py:1899`) ✅ |
| Create | `Brand` | custom `admin.api.create_brand` (`brands/route.ts:26`; `catalog.py:1926`) ✅ |
| Update | — | **none** (no `update_brand`) |
| Delete | — | **none** (no `delete_brand`) |

- **Frontend:** `src/components/settings/brands-section.tsx` (standalone; table + inline add). Hooks `use-admin-brands.ts` (`createAdminResource("brands")` → `useList` + `useCreate` **only**). Nav `settings-nav.ts:56` (**Clinical Data**; href derived → `/settings/brands`). Also used as an inline searchable combobox (with inline-create) inside the Medication `linked_items` editor.
- **ADR-021 / Rule 11:** ✅ **CLEAN** — GET + POST both go through custom whitelisted methods; the BFF explicitly avoids `/api/resource/`.

## 2. Permissions
DocPerm spec `eb_docperm_spec.json` (Brand): **`EB_Healthcare Admin`** read/write/create/**delete** = 1; `EB_Nurse` + `EB_Practitioner` read-only.
- **Inverse capability gap (not P1):** admin *has* `write` + `delete` permission server-side, but **no API method exposes update/delete** — so those granted perms are currently unusable. (This is the mirror of P1: perm-allowed-but-no-capability, rather than UI-offered-but-perm-denied.)

## 3. Field parity + control types
Backend `Brand` fields: `brand` (Data, **reqd**), `description` (Text), `brand_defaults` (Table→Item Default), `image` (Attach Image).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Brand Name | `brand` | Data | text | ✅ | create-only (no edit exists) | yes |
| Description | `description` | Text | text input | ✅ (Text→input; single-line adequate) | create-only | no |

**Not surfaced (P8):** `brand_defaults` (per-company accounting defaults — irrelevant to a name master, skip), `image` (brand logo — low value, skip).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| BR1 | **Create + Read only — no Update, no Delete** (FE and BE). Can't rename/edit or remove a brand (fix a typo, delete a duplicate/unused). Backend `catalog.py` exposes only `list_brands`/`create_brand`. | Missing CRUD (backend+frontend) | **Medium** | ✅ **DECIDED: add delete → BH-10.** Backend `delete_brand` (safely blocked by LinkExistsError if in use) + FE delete affordance. **Rename skipped** (renaming a referenced Brand is risky/rare). Create+Read accepted otherwise. |
| BR2 | **Fully hardcoded strings — no `useTranslations`** (`brands-section.tsx`: title/sub :37-38, labels :58/62, errors, buttons). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.brands` catalog (en + es-MX). |
| BR3 | **`image` / `brand_defaults` not surfaced.** | Missing fields (P8) | Low | ✅ **DECIDED: skip** (logo low-value; brand_defaults is accounting). |
| — | **ADR-021 clean; correct list-error handling (P11 counter-case); create error surfaced** | — | — | ✅ No finding. Cleanest small master so far. |

## 5. Resolved decisions (2026-07-04)
1. **BR1 — RESOLVED: add delete (BH-10), skip rename.** Backend `delete_brand` + FE delete affordance; delete-in-use blocked by LinkExistsError. Rename declined (risky/rare on referenced Brands). Create+Read accepted.
2. **BR2 — RESOLVED: frontend i18n** (`settings.brands` en+es).
3. **BR3 — RESOLVED: skip** (`image`, `brand_defaults`).

## 6. Follow-up
- Backend: **BH-10** — add `delete_brand`. Frontend then adds the delete affordance.
- Frontend TODO: BR2 (i18n).
- **Screen 11 (Manufacturers)** is the same shape (`catalog.py` exposes only `list_manufacturers`/`create_manufacturer`) → apply the same decision (add `delete_manufacturer`, skip rename, i18n). Will fold into BH-10 / a sibling item at screen 11.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
