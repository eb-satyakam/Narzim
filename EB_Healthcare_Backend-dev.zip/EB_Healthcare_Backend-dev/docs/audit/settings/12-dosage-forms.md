# Settings → Dosage Forms

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — DF1 accept (no edit UI, low value); DF2/DF3/DF4 fold into screen-9 FE fixes (shared components). ADR-021 clean. · **Section:** Clinical Data · **Screen 12/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Dosage Form`** (healthcare) — a one-field master (`dosage_form`, the record name). **Not a standalone screen:** it's a **tab** of Medications (`/settings/medications?tab=dosage-forms`) whose UI is shared with three other sub-masters — **Medication Classes, Prescription Dosages, Prescription Durations** — via two generic components: `SubMasterPanel` (create) + `SubMasterRows` (list + inline delete). **Full CRUD exists end-to-end** (backend `list/create/update/delete_dosage_form`, all four BFF verbs, all four hooks) and is **ADR-021-clean** (custom methods, "not `/api/resource/`"). Permissions clean. The gaps are: **no edit/rename UI** (the fully-built `update` capability is unused — DF1), and the shared-component issues already logged on screen 9 — **swallowed delete** (MED3) and **list-error-as-empty** (MED2) — plus hardcoded strings (P6).

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Dosage Form`** (healthcare) | custom `admin.api.list_dosage_forms` (`dosage-forms/route.ts:16`; `catalog.py:2023`) ✅ |
| Create | `Dosage Form` | custom `admin.api.create_dosage_form` (`route.ts:30`; `catalog.py:2039`) ✅ |
| Update | `Dosage Form` | custom `admin.api.update_dosage_form` (`route.ts:44`; `catalog.py:2067`) ✅ **(wired backend→BFF→hook, no UI)** |
| Delete | `Dosage Form` | custom `admin.api.delete_dosage_form` (`route.ts:58`; `catalog.py:2095`) ✅ |

- **Frontend:** create via `sub-master-panel.tsx` (rendered from `settings/medications/page.tsx:15` when a sub-master tab is active); list + inline delete via `SubMasterRows` in `medications-list.tsx`. Hooks `use-admin-dosage-forms.ts` (`createAdminResource("dosage-forms")` → list/create/**update**/delete — update hook exists but unused). Nav `settings-nav.ts:58` → `/settings/medications?tab=dosage-forms`.
- **ADR-021 / Rule 11:** ✅ **CLEAN** — all four verbs go through custom whitelisted methods.
- **Shared surface:** the same `SubMasterPanel`/`SubMasterRows` also drive **Medication Classes**, **Prescription Dosages**, **Prescription Durations** (not separate screens in the 18-list; managed here incidentally). Findings below apply to all four.

## 2. Permissions — clean
DocPerm spec (Dosage Form): **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Nurse` + `EB_Practitioner` read-only. **No P1 mismatch.**

## 3. Field parity + control types
Backend `Dosage Form`: single field `dosage_form` (Data, **reqd**; `autoname: field:dosage_form`).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Dosage Form (value) | `dosage_form` | Data | text | ✅ | create-only (no edit UI) | yes |

Full field parity (one field). Nothing unsurfaced.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| DF1 | **No edit/rename UI** — `update_dosage_form` + PATCH route + `useUpdateDosageForm` all exist but nothing calls them; `SubMasterRows` offers only delete. | Unused capability | Low | ✅ **DECIDED: accept (skip edit UI).** Low value for a one-field master (delete + recreate suffices; renaming a referenced Dosage Form is risky). The built `update` capability stays available for future use. |
| DF2 | **Delete error swallowed** — `SubMasterRows` `.catch(() => null)` (`medications-list.tsx:146-161`). | Error UX (P5) | **Medium** | ✅ **DECIDED: fix — folds into MED3** (same component; one fix covers all four sub-masters). |
| DF3 | **List-error rendered as empty** — `SubMasterRows` `?? []` (P11). | Error UX (P11) | **Medium** | ✅ **DECIDED: fix — folds into MED2** (same component). |
| DF4 | **Hardcoded strings** — `SubMasterPanel` META titles/subs + `SubMasterRows` labels (P6). | i18n (P6) | **Medium** | ✅ **DECIDED: fix — folds into MED4** (`settings.medications` catalog, sub-master keys). |
| — | **ADR-021 clean (full CRUD custom); create error surfaced; perms clean** | — | — | ✅ No finding. |

## 5. Resolved decisions (2026-07-04)
1. **DF1 — accept.** No edit affordance; delete+recreate is enough for a one-field master. `update_dosage_form` remains available but unused.
2. **DF2/DF3/DF4 — fold into the screen-9 Medications frontend fixes** (MED3 swallowed delete, MED2 list-error, MED4 i18n) — the components are shared, so one set of fixes closes all four sub-masters (Dosage Forms, Classes, Dosages, Durations).

## 6. Follow-up
- **No backend hand-off** (backend already has full CRUD).
- Frontend TODO: covered by MED2/MED3/MED4 (shared `SubMasterRows`/`SubMasterPanel`). No Dosage-Form-specific frontend work.
- **Note:** Medication Classes / Prescription Dosages / Prescription Durations are managed by the same components and inherit these decisions (not separately enumerated in the 18-screen list).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
