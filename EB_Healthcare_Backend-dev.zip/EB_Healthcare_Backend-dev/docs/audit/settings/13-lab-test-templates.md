# Settings → Lab Test Templates

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — LT1→ADR-021; LT2/LT3/LT5/LT6/LT7 FE-TODO; LT4 remove dead plumbing. No backend hand-off. · **Section:** Clinical Data · **Screen 13/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Lab Test Template`** (healthcare) — a **polymorphic master** with 6 "Result Format" types (Single / Compound / Descriptive / Grouped / Imaging / No Result), three type-specific child tables, and **auto-creation of an ERPNext Item + Item Price**. The **form is rich and well-built** (3-column master/detail, type-conditional sections, full child-table editors for Compound components / Descriptive particulars / Grouped member-tests). Writes + detail read are **custom whitelisted** (ADR-021-clean); the **list read uses `/api/resource/`** (LT1, no `list_lab_test_templates` method). Permissions clean. Notable quirks: **`sample`/`sample_qty`/`sample_details` are plumbed through the form state but never rendered or sent (dead fields, LT4)**; **delete error is swallowed** (LT3, inconsistent with the Groups tab which toasts); **list-error-as-empty** (P11, LT2); thin validation (LT6). **Structural:** the sibling "Lab Test Groups" nav entry (screen 14) is a **tab of this screen** managing ERPNext **Item Group** (create+delete, no edit) — and the mandatory "Group" field is actually `lab_test_group` → **Item Group** (mislabeled in core), not a distinct "Lab Test Group" doctype.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Lab Test Template`** | **generic `/api/resource/Lab Test Template`** via `frappeRestList` (`admin/[resource]/route.ts:231`) — **ADR-021 hole (LT1)** |
| Detail (read) | `Lab Test Template` | custom `admin.api.get_lab_test_template` (`lab-tests/[name]/route.ts:6`) ✅ |
| Create | `Lab Test Template` (+ 3 child tables) | custom `admin.api.create_lab_test_template` (`catalog.py:1066`) ✅ |
| Update | `Lab Test Template` (children replaced) | custom `admin.api.update_lab_test_template` (`catalog.py:1155`) ✅ |
| Delete | `Lab Test Template` | custom `admin.api.delete_lab_test_template` (`catalog.py:1247`) — cascades to linked Item (`on_trash`), can fail if Item referenced ✅/⚠️ |

- **Frontend:** `settings/labs/` 3-col master/detail — `labs-list.tsx`, `lab-test-form.tsx` (6-type polymorphic), `lab-test-profile.tsx`, plus `group-form.tsx`/`group-profile.tsx` for the Groups tab. Hooks `use-admin-lab-tests.ts` (`createAdminResource("lab-tests")`) + hand-written `useLabTestDetail`. Nav `settings-nav.ts:59` (standalone) + `:60` `lab-test-groups` → Groups tab.
- **ADR-021 / Rule 11:** **PARTIAL** — create/update/delete + detail custom ✅; **list GET uses `/api/resource/`** ❌ (**LT1**).

## 2. Permissions — clean
DocPerm spec `eb_docperm_spec.json:1797` (Lab Test Template): **`EB_Healthcare Admin`** full read/write/create/delete; `EB_Nurse` + `EB_Practitioner` read-only. **No P1 mismatch.**

## 3. Field parity + control types
Backend mandatory: `lab_test_name` (Data, unique, locked after insert), `lab_test_group` (Link→**Item Group**), `department` (Link→Medical Department). Type driver: `lab_test_template_type` (Select, 6). Type-specific children: `normal_test_templates` (Compound), `descriptive_test_templates` (Descriptive), `lab_test_groups` (Grouped). Billing: `is_billable` (default 1), `lab_test_rate` (Currency, required when billable & not linking existing item & not Grouped).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Test name | `lab_test_name` | Data (unique) | text | ✅ | create-only (locked on edit) | yes |
| Department | `department` | Link→Medical Department | `<select>` | ✅ | both | yes |
| Group | `lab_test_group` | Link→**Item Group** | `<select>` (item-groups) | ✅ (correctly targets Item Group) | both | yes |
| Test type | `lab_test_template_type` | Select | `<select>` (6 types) | ✅ | both | — |
| Result UOM / Normal range (Single) | `lab_test_uom` / `lab_test_normal_range` | Link→Lab Test UOM / Long Text | `<select>` / **free-text** | ✅ (range is free-text by design) | both | no |
| Components (Compound) | `normal_test_templates` | Table | full row editor (name/UOM/range) | ✅ | both | no |
| Particulars + sensitivity (Descriptive) | `descriptive_test_templates` / `sensitivity` | Table / Check | row editor + checkbox | ✅ | both | no |
| Member tests (Grouped) | `lab_test_groups` | Table | row editor (Add Test / Add New Line) | ✅ | both | no |
| Imaging description | `lab_test_description` | Text Editor | textarea | ✅ | both | no |
| Billable / Rate | `is_billable` / `lab_test_rate` | Check / Currency | checkbox / number (gated: internal lab & !Grouped) | ✅ | both | rate reqd if billable |

**Dead/unsurfaced fields:** `sample` (Link→Lab Test Sample), `sample_qty`, `sample_details` — **present in form state + `CreateLabTestInput` but never rendered or added to the save payload** (LT4). Also not surfaced: `secondary_uom`/`conversion_factor`, `result_legend`, `worksheet_instructions`, `staff_role`, `patient_care_type`, `codification_table` (advanced/rare — skip). All pickers are plain `<select>` (no searchable combobox) — acceptable for small preloaded lists.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| LT1 | **List read via generic `/api/resource/Lab Test Template`** (`route.ts:231`) — no `list_lab_test_templates` method (peers like Therapy Type ship one). | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021.** Same as PR1/PS1/MED1. |
| LT2 | **List-error rendered as empty** — `labs-list.tsx:36-37` ignores `isError` (both Lab Tests + Groups tabs) → failure shows "No lab tests." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card (both tabs). |
| LT3 | **Delete error swallowed** — `lab-test-profile.tsx:42-49` empty `catch`, no `del.error` render (comment claims "surfaced by the mutation" but nothing renders it). Inconsistent with `group-profile.tsx` which toasts. | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — surface the delete error (toast), matching the Groups tab. Delete cascades to the Item and can legitimately fail → error must be visible. |
| LT4 | **`sample` / `sample_qty` / `sample_details` are dead fields** — plumbed through form state + `CreateLabTestInput` but never rendered or sent (`handleSave` omits them). Can't set sample type/qty/collection details, though `create_lab_test_template` accepts + validates `sample`. | Missing field / dead code (P8) | **Medium** | ✅ **DECIDED: remove the dead plumbing.** Labs external/minimal; surfacing would need a Lab Test Sample options list for marginal value. Strip `sample*` from form state + `CreateLabTestInput` (FE cleanup). Revisit if internal-lab sample tracking is adopted. |
| LT5 | **Fully hardcoded strings — no `useTranslations`** (all labs components). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.labTests` catalog (en + es-MX). |
| LT6 | **Thin validation** — 3 required guards only. **No rate-required-when-billable** (billable + empty rate → backend 400 "Standard Selling Rate should be greater than zero"); no min<max (ranges are free-text by design); no non-empty check for Compound/Grouped/Descriptive children. | Validation | **Medium** | ✅ **DECIDED: frontend fix** — require rate when billable; warn on empty child tables for Compound/Grouped/Descriptive. |
| LT7 | **No enable/disable toggle** — `disabled` is read-only in the profile; the only removal path is hard delete (which cascades to the Item and can fail if referenced). | UX / safety | Low–Med | ✅ **DECIDED: add a disable toggle** (safer than delete for a referenced test); `update_lab_test_template` already accepts `disabled`. Frontend only. |
| — | **Rich polymorphic form; writes+detail ADR-021 clean; perms clean; Groups tab toasts delete** | — | — | ✅ Strong screen overall. |

## 5. Structural note — screen 14 (Lab Test Groups)
The `lab-test-groups` nav entry (`settings-nav.ts:60`) deep-links to the **Groups tab of this screen** (`/settings/labs?tab=groups`). "Groups" here = ERPNext **`Item Group`** (the `lab_test_group` field target), managed by `group-form.tsx`/`group-profile.tsx` — **create + delete only, no edit**. So **screen 14 is a tab of screen 13**, and will be a short cross-referenced audit (Item Group as the lab-test category).

## 6. Resolved decisions (2026-07-04)
1. **LT4 — remove dead plumbing.** Labs external/minimal; strip `sample`/`sample_qty`/`sample_details` from form state + `CreateLabTestInput`. Revisit if internal-lab sample tracking is adopted (backend already accepts `sample`).
2. **LT7 — add disable toggle** (backend supports `disabled`); safer than delete-only.
3. **LT1 → ADR-021**; **LT2/LT3/LT5/LT6 → frontend fixes** (list-error card; surface delete error; i18n; rate-when-billable + empty-child validation).

## 7. Follow-up
- **No backend hand-off** (create/update/delete + detail already custom; `disabled` already accepted).
- Frontend TODO: LT2 (error card), LT3 (delete toast), LT4 (remove dead sample fields), LT5 (i18n), LT6 (validation), LT7 (disable toggle). LT1 folds under ADR-021 list migration.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
