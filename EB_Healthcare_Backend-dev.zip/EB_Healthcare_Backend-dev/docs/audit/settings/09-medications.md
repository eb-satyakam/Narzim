# Settings → Medications

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — MED1→ADR-021; MED2/3/4/5 FE-TODO; MED6 skip; MED7 accept+document; MED8 trivial BE cleanup. No formal hand-off. · **Section:** Clinical Data · **Screen 9/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Medication`** (healthcare app) — by far the richest master: composed naming (`{dosage_form} {generic_name} {strength}{strength_uom}`), a `combinations` child (multi-ingredient), and a `linked_items` child that **auto-creates ERPNext `Item` + `Item Price`** records. The **form is the best-built in the audit**: every Link is a **searchable combobox or select** (Item, Brand, Manufacturer, ingredient medications, class, dosage form, UOM), with **inline master creation** for Brand/Manufacturer — no Link-as-free-text (P9) anywhere. Writes + detail read are **custom whitelisted** (ADR-021-clean); only the **list read uses `/api/resource/`** (MED1). Permissions clean (admin full CRUD; nurse/practitioner read-only). Familiar gaps: **list-error-as-empty** (P11, MED2), **swallowed sub-master deletes** (P5, MED3), **hardcoded strings** (P6). Plus a data-hygiene note: **deleting a Medication leaves its auto-created Item/Item Price orphaned** (MED7). **Structural finding for screens 10–12:** Brands & Manufacturers are **routeless nav entries** managed only inline here, and Dosage Forms is a **tab** of this screen — they have no standalone screens.

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Medication`** | **generic `/api/resource/Medication`** via `frappeRestList` (`admin/[resource]/route.ts:231`) — **ADR-021 hole (MED1)** |
| Detail (read) | `Medication` | custom `admin.api.get_medication` (`medications/[name]/route.ts:8`) ✅ |
| Create | `Medication` (+ combinations, linked_items) | custom `admin.api.create_medication` (`catalog.py:528`) ✅ |
| Update | `Medication` (children full-replace) | custom `admin.api.update_medication` (`catalog.py:632`) ✅ |
| Delete | `Medication` | custom `admin.api.delete_medication` (`catalog.py:732`) — hard delete, **no Item cleanup** ✅/⚠️ |
| Ingredients | `Medication Ingredient` (child `combinations`) | via create/update ✅ |
| Pharmacy items | `Medication Linked Item` (child `linked_items`) | routed to core Item via `_route_linked_items_to_core` ✅ |

- **Frontend:** `medications-list.tsx` (tabbed: Medications / Dosage Forms / Classes / Dosages / Durations), `medication-profile.tsx`, `medication-form.tsx` (769 lines) with `CombinationsEditor` + `LinkedItemsEditor`. Hooks `use-admin-medications.ts` (`createAdminResource("medications")`) + `use-medication-detail.ts`. Nav `settings-nav.ts:55` (**Clinical Data**).
- **ADR-021 / Rule 11:** **PARTIAL** — create/update/delete + detail custom ✅; **list GET uses `/api/resource/`** ❌ (**MED1**). Note there is **no `list_medications`** custom method — the list deliberately uses generic REST.

## 2. Permissions — clean (sixth P1 counter-case)
DocPerm spec `eb_docperm_spec.json:2067` (Medication) + `:2135` (Medication Class): **`EB_Healthcare Admin`** full read/write/create/delete; `EB_Nurse` + `EB_Practitioner` read-only. **No P1 mismatch.**

## 3. Field parity + control types
Backend mandatory: `generic_name` (Data), `medication_class` (Link), `strength` (Float), `strength_uom` (Link→UOM), `dosage_form` (Link). Children: `combinations`→Medication Ingredient; `linked_items`→Medication Linked Item (item/item_code/item_group/stock_uom/brand/manufacturer/is_billable/rate).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Req |
|---|---|---|---|---|---|
| Generic name | `generic_name` (via `item_name`) | Data | text | ✅ | yes |
| Medication class | `medication_class` | Link→Medication Class | `<select>` | ✅ | yes |
| Dosage form | `dosage_form` | Link→Dosage Form | `<select>` | ✅ | yes |
| Strength | `strength` | Float | number | ✅ | yes |
| Strength UOM | `strength_uom` | Link→UOM | `<select>` | ✅ | yes |
| Default dosage / duration | `default_prescription_*` | Link | `<select>` | ✅ | optional (UI) |
| Interval / Interval UOM | `default_interval`/`_uom` | Int / Select | number / `<select>` | ✅ | optional |
| Combination + ingredients | `is_combination` / `combinations` | Check / Table | checkbox + **searchable MedicationPicker** rows | ✅ (good) | — |
| Pharmacy items | `linked_items` | Table | **full editor**: Item search, **Brand/Manufacturer searchable comboboxes w/ inline create**, rate, billable | ✅ (best in audit) | — |

**Not surfaced (P8, MED6):** `national_drug_code` (Mexico drug coding?), `reference_url`, `staff_role` (Link→Role), `codification_table` (medical codes), head-level `price_list`. All low-value for now.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| MED1 | **List read via generic `/api/resource/Medication`** (`route.ts:231`) — no `list_medications` custom method. | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021** (whitelisted list). Same as PR1/PS1. |
| MED2 | **List-load error rendered as empty** — `medications-list.tsx:93-131` checks `isLoading` only, `?? []` → a failed load shows "No medications." (also all 4 sub-master tabs). | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card (list + all sub-master tabs). |
| MED3 | **Sub-master deletes swallowed** — `delDosageForm/delClass/delDosage/delDuration.mutateAsync(n).catch(() => null)` (`medications-list.tsx:146-161`). Failed delete (in-use master) silently no-ops. | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — surface delete errors (toast). Full treatment of these sub-masters at screens 10/12. |
| MED4 | **Fully hardcoded strings — no `useTranslations`** (list/profile/form). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.medications` catalog (en + es-MX). |
| MED5 | **Thin validation** — presence-only; no numeric guard on `strength`/`interval`/`rate` beyond browser `type=number`. | Validation | Low | ✅ **DECIDED: frontend fix** — numeric guards (batch with MED2–MED4). |
| MED6 | **Fields not surfaced** — `national_drug_code`, `reference_url`, `staff_role`, `codification_table`, head `price_list`. | Missing fields (P8) | Low | ✅ **DECIDED: skip.** NDC is a US concept; Mexico uses other coding and OPD prescribes by generic + brand. No reporting requirement in scope. Revisit if a dispensing/pharmacy-reporting need appears. |
| MED7 | **Delete leaves orphaned ERPNext Item/Item Price** — `delete_medication` hard-deletes the Medication but not the Item/Item Price it auto-created (`catalog.py:732`; no cleanup). | Data hygiene (backend) | Low–Med | ✅ **DECIDED: accept + document.** Auto-deleting Items is unsafe — they may be referenced by past invoices. Behavior documented; no cleanup. Revisit only if orphan volume becomes a problem. |
| MED8 | **`is_antibiotic` dead key** in `_fmt_medication` (`catalog.py:482`) — `hasattr`-guarded, field doesn't exist → always `false`. | Cleanup (backend) | Low | ✅ **DECIDED: drop the dead key.** Trivial serializer cleanup for whoever next touches `catalog.py`; no formal hand-off. |
| — | **Rich form: searchable comboboxes everywhere + inline master creation + child editors; delete toasts** | — | — | ✅ Best-built form in the audit. No finding. |

## 5. Structural finding — screens 10 (Brands), 11 (Manufacturers), 12 (Dosage Forms)
The Clinical Data nav lists Brands, Manufacturers, Dosage Forms as entries, but:
- **Brands** (`settings-nav.ts:56`) & **Manufacturers** (`:57`) have **no `route`** → not wired to a page. They exist only as **inline searchable comboboxes with inline-create** inside the Medication `linked_items` editor.
- **Dosage Forms** (`:58`) routes to `/settings/medications?tab=dosage-forms` — a **tab** of this screen, **delete-only** (no create/edit UI; dosage forms are otherwise only picked in the med form `<select>`).

Implication for the audit plan: screens 10–12 likely have **no standalone screen to audit** — the finding will be "managed inline / routeless nav entry."

> **CORRECTION (from screen 10):** Brands **does** have a standalone screen (`[section]/page.tsx:45` → `<BrandsSection />`, in `VALID_SECTIONS`); the nav href is derived from the key, so the entry is not dead. Manufacturers (11) is the same. Only **Dosage Forms** is a tab. See [10-brands.md](10-brands.md).

## 6. Resolved decisions (2026-07-04)
1. **MED6 — SKIP.** No NDC/other unsurfaced fields — not needed for a Mexico OPD product; revisit only on a dispensing/reporting requirement.
2. **MED7 — ACCEPT + DOCUMENT.** Orphaned Item/Item Price on delete is tolerated (Items may be invoice-referenced; auto-delete unsafe). No cleanup.
3. **MED8 — DROP dead key** (trivial `catalog.py` cleanup; no formal hand-off).
4. **MED1 → ADR-021**; **MED2/MED3/MED4/MED5 → frontend fixes** (list-error card, sub-master delete toasts, i18n, numeric guards).
5. **Screens 10/11/12 model — CONFIRMED inline/tab.** Brands & Manufacturers managed inline from Medications (no standalone screens); Dosage Forms as a tab. Screens 10–12 will be audited as short cross-referenced notes. **Decision on the routeless Brands/Manufacturers nav entries deferred to screen 10** (verify click behavior first; leaning toward minimal standalone list screens reusing the sub-master row pattern, rather than dead nav entries). Dosage Forms (12) needs a **create affordance** (currently delete-only) — to confirm at screen 12.

## 7. Notable backend behaviors (documented, not gaps)
- **Item auto-creation:** saving a Medication with `linked_items` creates/updates ERPNext `Item` + `Item Price` (stock item when pharmacy enabled). The custom API inserts with empty `linked_items` first, then routes rows through core's duplicate-safe path.
- **item_code uniqueness:** a linked `item_code` reused across Medications throws server-side (`medication.py` validate).
- **Composed naming:** the record name is `{dosage_form} {generic_name} {strength}{strength_uom}`; there is no rename affordance in the UI (name is immutable in practice).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
