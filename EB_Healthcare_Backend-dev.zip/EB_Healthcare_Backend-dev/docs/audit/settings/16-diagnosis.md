# Settings → Diagnosis

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — DG1/DG2 FE-TODO; DG3 skip. ADR-021 clean; perms clean (no P1); no rename needed. No backend hand-off. · **Section:** Clinical Data · **Screen 16/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Diagnosis`** (healthcare) — a one-field master (`diagnosis`, the record name). Structurally identical to Complaints (screen 15) but **cleaner on the two things that bit that screen**: the nav label **already matches the backend doctype** ("Diagnosis" — no rename), and the **DocPerm grants `EB_Healthcare Admin` full CRUD** — so **no P1 mismatch** (the DocPerm sweep's first clean master). ADR-021-clean (dedicated `/api/admin/diagnosis` route → custom methods), profile handles error + delete correctly. Only the familiar frontend nits remain: **list-error-as-empty** (P11) and **hardcoded strings** (P6).

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Diagnosis`** (healthcare) | custom `admin.api.list_diagnosis` (`catalog.py:2618`) ✅ |
| Create | `Diagnosis` | custom `admin.api.create_diagnosis` (`catalog.py:2634`) ✅ |
| Update (= rename) | `Diagnosis` | custom `admin.api.update_diagnosis` (`catalog.py:2662`) ✅ |
| Delete | `Diagnosis` | custom `admin.api.delete_diagnosis` (`catalog.py:2690`) ✅ |

- **Frontend:** `settings/diagnosis/` 3-col — `diagnosis-list.tsx`, `diagnosis-form.tsx`, `diagnosis-profile.tsx`. Hooks `use-admin-diagnosis.ts` (`createAdminResource("diagnosis")` → full CRUD). Dedicated BFF route `src/app/api/admin/diagnosis` (custom methods). Nav `settings-nav.ts:62`, label "Diagnosis" (**already matches backend — no rename**).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — all four ops via custom whitelisted methods; kept out of the `standardCrud` catch-all by design.

## 2. Permissions — clean (P1 counter-case)
DocPerm spec (`Diagnosis`): **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Nurse` read/write/create; `EB_Practitioner` read/create; `EB_Front Desk` read. **No P1 mismatch** — admin has the full CRUD the UI offers. (Contrast screens 14/15, where admin was read-only.)

## 3. Field parity + control types
Backend `Diagnosis`: `diagnosis` (Data, **reqd**, autoname), `estimated_duration` (Duration), `codification_table` (Table→Codification Table).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Diagnosis Name | `diagnosis` | Data | text | ✅ | create + edit (= rename) | yes |

**Not surfaced (P8, DG3):** `estimated_duration`, `codification_table` — neither rendered nor accepted by `create_diagnosis`/`update_diagnosis` (single-field API). Low value for a clinic diagnosis master.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| DG1 | **List-error rendered as empty** — `diagnosis-list.tsx:25` destructures `{ data: diagnoses = [], isLoading }`, ignores `isError` → failure shows "No diagnoses." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card. |
| DG2 | **Hardcoded strings — no `useTranslations`** (all diagnosis components). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.diagnosis` catalog (en + es-MX). |
| DG3 | **`estimated_duration` / `codification_table` not surfaced** — also not accepted by the single-field API. | Missing fields (P8) | Low | ✅ **DECIDED: skip** (low value; API is single-field by design). |
| — | **ADR-021 clean; admin full CRUD (no P1); profile error card + delete toast; nav name matches backend** | — | — | ✅ Cleanest master in the Clinical Data section. |

## 5. Follow-up
- **No backend hand-off**, **no rename** (name already matches; perms already full).
- Frontend TODO: DG1 (list-error card), DG2 (i18n). Both fold naturally into the shared list-error (P11) + i18n (P6) sweeps.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
