# Settings → Vaccine Schedules & Immunization Programs

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — cleanest surface in the audit: custom app-owned doctypes, row-level perms, no P1, no ADR-021 issue, list-error handled, real validation, delete not swallowed. Only IM1 (i18n) → P6. · **Section:** Clinical Data · **Screen 24** (post-completeness-check, final) · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit.

## 0. Headline
Two screens over **custom, app-owned doctypes** — **`Immunization Template`** ("Vaccine Schedules": a vaccine + dose ladder) and **`Immunization Program`** (a bundle of templates with age/gender targeting, e.g. the Mexico EPI schedule). This is the **best-engineered surface in the whole audit**: a dedicated `api/v1/immunizations/api.py` with **row-level permission checks** (`require_permission(dt, perm, doc=name)`), explicit "no `/api/resource/` use", full CRUD, rich child-table editors (dose ladder / program schedules), and clean error/validation handling on both screens. **No P1, no ADR-021 violation, no swallowed deletes.** The only gap is the systemic one — **hardcoded strings** (IM1). Effectively a reference implementation for the rest of the app.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| Templates list/get/create/update/delete | **`Immunization Template`** (custom) + child `doses` | custom `immunizations.api.{list,get,create,update,delete}_immunization_template` ✅ |
| Programs list/get/create/update/delete | **`Immunization Program`** (custom) + child `schedules` (`Immunization Program Item`) | custom `immunizations.api.{list,get,create,update,delete}_immunization_program` (+ `apply_program`) ✅ |

- **Frontend:** `immunization-templates-section.tsx` (nav "Vaccine Schedules") + `immunization-programs-section.tsx` (nav "Immunization Programs"). Hooks `use-immunizations.ts` (`useAdminImmunizationTemplates`/`Programs` + CRUD). Dedicated BFF routes `api/immunizations/templates` + `api/immunizations/programs`. Nav `settings-nav.ts:66-67` (**Clinical Data**).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — dedicated custom whitelisted methods; the module header explicitly states "no /api/resource use." **Best practice.**

## 2. Permissions — clean (row-level; no P1)
Custom doctypes carry their permissions in the doctype JSON (authoritative for app-owned doctypes):
| DocType | EB_Healthcare Admin | others |
|---|---|---|
| **Immunization Template** | read/write/create/delete ✅ | Nurse/Practitioner/Front Desk = read |
| **Immunization Program** | read/write/create/delete ✅ | Nurse/Practitioner/Front Desk = read |
Admin has full CRUD the UI offers → **no P1.** The API additionally enforces **row-level** checks (`doc=name`) — stronger than the doctype-level checks elsewhere in the app. (Related `Immunization` + `Patient Vaccine` doctypes are in the DocPerm spec with broad clinical CRUD — those are the patient-facing records, not these masters.)

## 3. Field parity + control types
**Immunization Template:** `template_name` (name), `short_name`, `vaccine` (Link), `category`, `disabled`, `aliases`, `doses` (child ladder). Surfaced with a full **dose-ladder editor**. ✅
**Immunization Program:** `program_name` (name), `description`, `is_default`, `disabled`, `patient_age_from`/`to`, `gender`, `schedules` (child → `Immunization Program Item`). Surfaced with a full **schedule editor** + age/gender targeting. ✅
Rich child-table editing on both — parity is strong; no P8 concern.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| IM1 | **Hardcoded strings — no `useTranslations`** (both sections; 0 uses). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → catalog (folds into the P6 pass). |
| — | **Custom app-owned doctypes; row-level perms; no `/api/resource/`; admin full CRUD (no P1); list-error handled; real validation (name/dose required); delete not swallowed** | — | — | ✅ **Reference implementation.** No finding. |

## 5. Follow-up
- **No backend hand-off. No P1. No ADR-021 issue.** Only IM1 (i18n) via the P6 pass.
- **Recommend using `api/v1/immunizations/api.py` as the pattern** for the ADR-021 `master_crud` migration (MD1/HL7/PR1/PS1/MED1/LT1/IG2/TH1/CP1/insurance) and for future master screens — it's the cleanest example of custom whitelisted CRUD with row-level permission enforcement in the codebase.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
