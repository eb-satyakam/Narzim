# Settings coverage gaps (not screens — missing configuration surfaces)

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

Found by the master-data completeness check (2026-07-04). These are **not** master-data screens; they are **global/config surfaces the frontend does not manage**, configurable only via the Frappe desk / seed today.

> **Guiding principle (see [README.md](README.md)):** true multi-tenant SaaS — a tenant must manage **everything** from the frontend; the desk is never part of their workflow. So "desk-managed" here is **not acceptable** — each gap below is a hand-off to close, not a documented limitation.

---

## G-A — `Healthcare Settings` (ERPNext core global config) — no frontend screen

**Doctype:** `Healthcare Settings` (Single, ERPNext core). **Frontend:** none — zero references in `src/`.

- **What it controls:** `op_consulting_charge_item` (default consulting charge item for auto-invoicing), automatic invoice creation on appointment/encounter, registration fee + validity, free-follow-up validity (`valid_days` / `max_visits`), valuation method, inpatient settings.
- **How the app uses it (read-only):**
  - `services/billing.py` reads it to decide invoice automation + fee validity.
  - `api/v1/admin/settings.py:453` — onboarding checklist flag `healthcare_settings_configured` (checks `op_consulting_charge_item` is set).
- **Permissions:** DocPerm grants `EB_Healthcare Admin` **read + write** — but **no API method writes it** and no UI exists → the write grant is unused (inverse capability gap, cf. Brands/Manufacturers).
- **Distinct from `EB Clinic Settings`:** the app's own per-company singleton (`get_clinic_settings`/`update_clinic_settings`) backs Company/Facilities/Notifications/Access/Appearance/Role-Permissions. `Healthcare Settings` is a *separate* ERPNext-core singleton and is **not** surfaced.
- **Impact:** an admin setting up billing cannot pick the default consulting charge item or toggle auto-invoicing from the UI — must use the desk or a seed script, even though the onboarding checklist tracks it as a setup step.
- **Decision → BH-13.** Expose the **full admin-relevant `Healthcare Settings`** via whitelisted get/update + a settings screen. (Under the full-SaaS mandate, "rest stays desk-managed" is not acceptable — surface every field a tenant would reasonably configure; only truly internal/superadmin fields may remain out.)

---

## G-B — Integrations / messaging channels (Email, WhatsApp, SMS) — placeholder only

**Frontend:** `src/components/settings/integrations-section.tsx` (60 lines) is a **static placeholder** — a hardcoded list of four integrations (Google Calendar, WhatsApp Business, SMS/Twilio, Email/SMTP), **all `connected: false`**, and the "Connect" button only toggles a local `clicked` state (`setClicked`). **No config form, no API, no BFF route.**

- **Email (SMTP):** not configurable on the frontend → Frappe `Email Account` / site config (desk only).
- **WhatsApp:** *messaging* works (`use-whatsapp.ts`, `/api/whatsapp/conversations`), but the **account/credentials** are the `WhatsApp Account` doctype (frappe_whatsapp app) — **desk only**, no UI or custom API to manage.
- **SMS/Twilio:** not wired at all.
- **Google Calendar:** OAuth via desk, not wired here.
- **Note:** the "Notifications" settings screen is event *preferences* (which events notify), stored on `EB Clinic Settings` — **not** channel credentials.
- **Impact (Phase 4):** WhatsApp appointment reminders are on the roadmap, but an admin cannot **connect/configure** the channel that drives them from the UI.
- **Decision → BH-14.** Backend `get`/`update` for the messaging-channel config (at minimum WhatsApp Account + email/SMTP), and wire the Integrations screen to real config, replacing the placeholder.

---

---

## G-C — Financial setup (tax rates, CoA, fiscal year, currency) — desk-only

> **Correction (desk-dependency sweep, 2026-07-04):** the original G-C claim ("Price Lists & Tax Categories are read-only/stub, no backend create") was **wrong**. Price List and Tax Category **are managed** from the UI — via Frappe generic REST (`standardCrud:true`), gated only by raw DocPerm (an ADR-021 violation, not a missing-CRUD gap). The genuine financial desk-dependencies are the rate/ledger surfaces below. See [DESK_DEPENDENCY_SWEEP.md](DESK_DEPENDENCY_SWEEP.md) §C.

Desk-only financial setup a tenant cannot configure from the frontend:
- **Sales Taxes and Charges Template** + **Item Tax Template** — the actual **tax rates** on invoices (Tax Category alone carries no rates).
- **Chart of Accounts / Account** — CoA locked to ERPNext default at company create (`COA_SELECTABLE=false`); no `Account` CRUD → **BH-3** (existing).
- **Fiscal Year**, **Currency** (read-only — can't add / set FX), **Cost Center** — desk-only.
- **Item Price (bulk / price-list line rates)** — no surface; per-item `rate` only.
- **Price List / Tax Category** — managed, but move off `/api/resource` to custom methods (ADR-021).

**Decision → BH-15 (revised).** Bundle the above as tenant financial setup; sequence with Phase-3 billing.

---

## Next step — desk-dependency sweep

The three gaps above were found opportunistically. To **guarantee** the "everything from the frontend" principle, a **systematic sweep** is needed: enumerate every surface that currently forces a tenant into the Frappe desk — config singletons, print formats / letterhead / branding, email + notification templates, WhatsApp message templates, taxes & pricing, fiscal/currency setup, data import/export & backups, scheduled-job/reminder config, and any master with read-only or placeholder UI. Output: one consolidated gap list → hand-offs. **Not yet run.**

---

_These gaps are additional to the master-data audit (screens 1–19). See [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md) BH-13 / BH-14 / BH-15. All are frontend + backend coordinated work (new API + new/rewired screen). Under the guiding principle they are **required**, not optional — sequencing follows product phase (billing setup, Phase-4 messaging), but none is "accepted as desk-managed."_

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
