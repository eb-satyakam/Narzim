# P6 — Frontend i18n Pass: Scope & Phased Plan

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Repo:** `Healthcare_next_app` (frontend). **Date:** 2026-07-04.
**Origin:** P6 ("hardcoded UI strings") — the most recurring finding across the settings audit (screens 1–19) and confirmed system-wide by the locale-switch investigation: switching language barely changes the UI because most components render English literals instead of catalog keys.

## 0. Current state (measured)
- **Infra is healthy.** `next-intl`, cookie-based locale (`NARZIM_LOCALE`), now correctly synced to `User.language` on login / profile-save / stale-session auto-resync. **2,614 catalog keys, en ↔ es at 100% parity** (0 missing either side). Rich namespaces already exist: `sidebar`, `settings`, `dashboard`, `patientChart`, `encounter`, `billing`, `common`, …
- **Coverage ≈ 32%** — 99 of 307 `.tsx` use next-intl. The rest render hardcoded English.
- **The `%` overstates truth**: a file counts as "i18n" if it imports `useTranslations`, but may still hardcode most strings (e.g. `app-sidebar.tsx` imports a translator yet the nav labels are literal `"Dashboard"`, `"Patients"`, …).

### Coverage by area (tsx: total / using next-intl)
| Area | Files | i18n | ~% | Debt |
|---|---|---|---|---|
| `components/app-shell` (sidebar, header, nav) | 5 | 4 | 80% | **nav labels hardcoded despite translator — high visibility** |
| `components/settings` | 44 | 6 | **13%** | **largest single block** (the audited screens) |
| `app/(clinic)` (pages/routes) | 111 | 22 | **19%** | page shells, reports, billing/cash pages |
| `narzim/patient-chart` | 35 | 23 | 65% | fill the remaining third |
| `narzim/dashboard` | 20 | 12 | 60% | fill remaining |
| `narzim/cash` | 5 | 4 | 80% | small |
| `narzim/encounter` / `clinic` | 4 | 4 | 100% | done |
| `narzim/inbox` / `admin` | 5 | 3 | ~60% | small |
| `components/{medications,treatment-plans,shared,help}` | 4 | 0 | 0% | back settings screens |
| `components/ui` (shadcn primitives) | 32 | 0 | 0% | mostly no user strings — spot-check only |

## 1. Guiding decisions
- **Bilingual `es` + `en` only** (ADR-007 / ADR-018) — no other locales (see [15-symptoms.md] language decision). Every string gets both.
- **Every user-visible string goes through the catalog** — no literals in JSX text, labels, placeholders, titles, toasts, aria-labels, option labels.
- **en/es parity is invariant** — enforced in CI (below), never let it drift.
- **Reuse existing namespaces/keys** where present (`sidebar.*`, `settings.*`, `common.*`) before adding new ones.

## 2. Phased plan (ordered by visible-impact ÷ effort)
| Phase | Scope | Why first / notes | Rough size |
|---|---|---|---|
| **P6.0 — App shell** | `app-shell` sidebar nav labels + role labels, header, `mobile-nav`, org switcher | Shows on **every** screen → biggest visible win per hour; `sidebar` namespace already exists (mostly wiring, little new translation) | ~5 files, S |
| **P6.1 — Settings** | all 44 `components/settings/*` + the 4 backing `components/{medications,treatment-plans,shared,help}` | Largest block; directly closes the P6 finding on screens 1–19; `settings` namespace exists | ~48 files, **L** |
| **P6.2 — App pages** | `app/(clinic)/*` route components (reports, billing, cash, profile, activity, etc.) | High traffic; many are thin shells (cheap), a few are large | ~90 files w/ strings, **L** |
| **P6.3 — Clinical remainder** | untranslated third of `patient-chart`, `dashboard`, `inbox`, `admin` | Core clinical polish | ~25 files, M |
| **P6.4 — Sweep & primitives** | audit `components/ui` for stray user strings; catch stragglers | Mostly no-op; ensures completeness | 32 files, S |

## 3. Cross-cutting workstream (do alongside P6.0 — prevents regrowth)
- **Lint guardrail:** add an ESLint rule that flags hardcoded JSX text / string props in `src/components` + `src/app` (e.g. `eslint-plugin-i18next` `no-literal-string`, or `react/jsx-no-literals` scoped). **Without this the debt regrows** — every new screen re-introduces literals (as this audit repeatedly found).
- **CI parity check:** a small script asserting `messages/en.json` and `messages/es.json` have identical key sets (they do today — keep it that way). Fail the build on drift.
- **Option-label pattern:** standardize how `<select>`/combobox option labels are translated (recurring gap) — a shared helper or a documented convention.

## 4. Method (per component)
1. Extract every user-visible literal → keys under the correct namespace (reuse existing where possible).
2. Add the key to **both** `en.json` and `es.json`.
3. Replace with `useTranslations("<ns>")` (client) / `getTranslations` (server) + `t("key")`.
4. Verify render in both locales (flip `NARZIM_LOCALE` / the Profile picker).

## 5. Effort & sequencing
- ~120–150 components carry real user strings (excluding `ui/` primitives and no-string shells).
- Recommended order: **P6.0 first** (one short PR, immediate visible payoff on every screen) → **cross-cutting guardrail** (lock the gains) → then **P6.1 settings** (largest, ties off the audit) → **P6.2 pages** → **P6.3 clinical remainder** → **P6.4 sweep**.
- Each phase is independently shippable; keep en/es parity green throughout.

## 5b. Deferred (backlog) — dynamic multi-language support (beyond es/en)
**Status: deferred — keep in list.** Product is bilingual today (ADR-007/018). Making the frontend genuinely support *many* languages (up to Frappe's ~80) is a **content** problem, not a code switch: our ~2,600 next-intl keys would need translating per language (~208k strings), and Frappe's own translations do **not** cover our custom app keys.
When picked up, the design is:
1. **Dynamic supported-locale list = backend Frappe `Language` list ∩ catalogs that exist** (`messages/<code>.json`) — auto-grows as catalogs are added; never offers a language the UI can't render. Needs a small backend `list_languages` endpoint (hand-off — add as BH when scheduled).
2. **English fallback** in `getRequestConfig` so partial catalogs degrade gracefully.
3. Make `locales`/`isLocale`/`localeMeta` **derived** from the available set (not the fixed pair).
4. **Translation pipeline** to produce catalogs — AI/MT first pass (reuse the Anthropic/OpenAI integrations) **with human review** (clinical/patient-safety terms), or a TMS (Crowdin/Lokalise/Tolgee). Never hand-maintain N JSON files; enforce en-parity in CI.
5. Ship only the market languages actually needed (es, en, later hi / en-IN per ADR-018) — adding one becomes "run the pipeline + review."

## 6. Definition of done
- Switching language (Profile picker / `LocaleSwitcher`) flips **all** user-visible copy across app shell, settings, pages, and clinical screens.
- No hardcoded user-visible strings remain in `src/components` / `src/app` (lint-enforced).
- `en.json`/`es.json` key sets identical (CI-enforced).

_This plan is the consolidation of the per-screen **P6** decisions in the settings audit. The locale *plumbing* (cookie sync, `User.language`, variant normalization, auto-resync) is complete and verified; this pass supplies the missing translations that make the switch visible._

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
