# Settings & Setup Audit — Healthcare Admin (index)

**Doc status:** living · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Frontend:** `Healthcare_next_app` · **Backend:** `EB_Healthcare_Backend` (Frappe v16 / ERPNext Healthcare)
**Role under audit:** Healthcare Admin (`EB_Healthcare Admin`) — everything must be doable via the frontend only; **no backend changes**.
**Started:** 2026-07-02 · **Method:** one screen per turn, discussed with the product owner before finalizing each section. One markdown file per screen (linked below).

> ## ★ Guiding principle — full frontend self-service (true SaaS, zero desk dependency)
> This is a **multi-tenant SaaS**. A tenant (clinic admin/owner) must be able to manage **every** feature — master data, settings, billing automation, taxes, pricing, integrations, templates, users/roles — **entirely from the Next.js frontend**. The Frappe **desk is an internal / superadmin escape hatch, never part of a tenant's workflow.**
> **Consequence for this audit:** "configured via desk / seed" or "read-only master" is **not an acceptable end state** — it is a gap to close (backend whitelisted API + a frontend screen). Every desk-only or placeholder surface below is tracked as a hand-off, not accepted.

## Scope & method (applied to every screen)
1. **Exact doctype mapping** — which backend DocType(s) the screen reads/writes, and the whitelisted API method(s).
2. **Field-by-field parity** — Frontend field ↔ Backend field, presence on each side, editable/required, mismatches (down to checkboxes).
3. **CRUD completeness** — Create / Read / Update / Delete from the UI.
4. **Role permissions** — frontend route gate vs backend `require_permission()`; can Healthcare Admin actually perform each action server-side (per the DocPerm spec)?
5. **Validation & constraints** — required, formats (RFC/email/phone), uniqueness, disabled-after-create, mandatory backend fields missing from UI.
6. **Control-type correctness** — each field's UI control must match its backend fieldtype: `Link`→searchable dropdown (from the linked doctype), `Select`→fixed dropdown, `Date`→date picker, `Check`→checkbox, `Data(Email/Phone/URL)`→validated text, `Int/Float/Currency`→number, `Text`→textarea, `Attach`→file upload. A **Link/Select rendered as free text = referential-integrity bug** (highest-priority control mismatch).
7. **Empty / loading / error states.**
8. **Gaps & decisions** — ranked; decisions logged inline once agreed.

## Admin role permission baseline (reused across all screens)
- **Frontend role:** Frappe role **`EB_Healthcare Admin`** → frontend `RoleId` `"admin"` (`src/lib/auth/roles.ts:4`), highest priority. Frappe's native **`System Manager` is NOT mapped** — a System-Manager-only user gets no frontend role.
- **Route gate:** `/settings`, `/admin`, `/reports` are `admin`-only (`src/lib/auth/route-access.ts:19`), enforced in `src/proxy.ts:25`. This is a **UX guard, not the security boundary** — real enforcement is Frappe per-doctype permission on every BFF data call.
- **Server-side authority:** `require_permission(doctype, perm)` = `frappe.has_permission` (`utils.py:39`). The true baseline is the **DocPerm spec** `patches/v0/eb_docperm_spec.json` (applied via `patches.txt`), NOT role literals in code.
- **Reusable caution:** "create-capable UI + create-denied role" is a likely recurring mismatch across master-data screens — check DocPerm create/delete for each doctype.

## Screen inventory & status
| # | Section | Screen | File | Status |
|---|---|---|---|---|
| 1 | Clinic | Company | [01-company.md](01-company.md) | ✅ **closed** — G1–G7 decided |
| 2 | Clinic | Facilities | [02-facilities.md](02-facilities.md) | ✅ **closed** — F1/F3 fix, F2 batch, F4 parked→#13 |
| 3 | Clinic | Medical Departments | [03-medical-departments.md](03-medical-departments.md) | ✅ **closed** — MD2/3/5 done, MD4 show-all, MD1→ADR-021 |
| 4 | Clinic | Service Units | [04-service-units.md](04-service-units.md) | ✅ **closed** — SU3→BH-8, SU1/6/7 FE-TODO, SU5→ADR-021, SU2 keep (single-clinic), SU4 skip |
| 5 | Clinic | Holiday Lists | [05-holiday-lists.md](05-holiday-lists.md) | ✅ **closed** — HL1–4 done, HL5→BH-6 |
| 6 | Scheduling & Staff | Appointment Types | [06-appointment-types.md](06-appointment-types.md) | ✅ **closed** — ADR-021 clean; AT2/AT5→BH-7, AT1/AT3/AT4/AT5/AT6 FE-TODO, AT2 UI deferred |
| 7 | Scheduling & Staff | Practitioners | [07-practitioners.md](07-practitioners.md) | ✅ **closed** — PR1→ADR-021, PR2/3/4 FE-TODO, PR6→BH-9, PR5 inert, PR7 skip |
| 8 | Scheduling & Staff | Practitioner Schedules | [08-practitioner-schedules.md](08-practitioner-schedules.md) | ✅ **closed** — PS1→ADR-021, PS2/3/4/5/6 FE-TODO, PS7 skip (no BE hand-off) |
| 9 | Clinical Data | Medications | [09-medications.md](09-medications.md) | ✅ **closed** — MED1→ADR-021, MED2/3/4/5 FE-TODO, MED6 skip, MED7 accept, MED8 cleanup |
| 10 | Clinical Data | Brands | [10-brands.md](10-brands.md) | ✅ **closed** — BR1→BH-10 (add delete), BR2 i18n, BR3 skip; ADR-021 clean |
| 11 | Clinical Data | Manufacturers | [11-manufacturers.md](11-manufacturers.md) | ✅ **closed** — MF1→BH-10 (delete + DocPerm grant), MF2 i18n, MF3 skip; ADR-021 clean |
| 12 | Clinical Data | Dosage Forms | [12-dosage-forms.md](12-dosage-forms.md) | ✅ **closed** — tab; DF1 accept (no edit UI), DF2/3/4 fold into MED2/3/4; ADR-021 clean |
| 13 | Clinical Data | Lab Test Templates | [13-lab-test-templates.md](13-lab-test-templates.md) | ✅ **closed** — LT1→ADR-021, LT2/3/5/6/7 FE-TODO, LT4 remove dead fields; no BE hand-off |
| 14 | Clinical Data | Lab Test Groups (Item Group) | [14-lab-test-groups.md](14-lab-test-groups.md) | ✅ **closed** — IG1 P1→BH-11, IG2→ADR-021, IG4 renamed "Item Groups" (FE), IG3 accept |
| 15 | Clinical Data | Symptoms → Complaints | [15-symptoms.md](15-symptoms.md) | ✅ **closed** — SY1 P1→BH-12, SY2 FE, SY3 renamed "Complaints", SY4 i18n; ADR-021 clean |
| 16 | Clinical Data | Diagnosis | [16-diagnosis.md](16-diagnosis.md) | ✅ **closed** — clean: no P1, ADR-021 clean, no rename; DG1/DG2 FE-TODO, DG3 skip |
| 17 | Clinical Data | Treatment Plan Templates | [17-treatment-plans.md](17-treatment-plans.md) | ✅ **closed** — no P1, ADR-021 clean; TP1–TP4 FE-TODO, TP5 skip; renamed to match backend |
| 18 | Clinical Data | Therapy Types | [18-therapy-types.md](18-therapy-types.md) | ✅ **closed** — no P1, no rename; TH1→ADR-021, TH2/3/4/5 FE-TODO, TH6 skip |
| 19 | Clinical Data | Clinical Procedure Templates | [19-clinical-procedures.md](19-clinical-procedures.md) | ✅ **closed** — added via completeness check; no P1; CP1→ADR-021, CP2/3/4/5 FE-TODO, renamed to match backend |

_Completeness check (2026-07-04): every backend master with CRUD maps to a frontend screen — none missing. The 18-screen inventory omitted **Clinical Procedures** (screen 19). Additional functional surfaces being audited post-sweep: **20 Payment Methods** ✅ ([20-payment-methods.md](20-payment-methods.md)) · **21 Insurance** ✅ ([21-insurance.md](21-insurance.md) — create likely broken, IN1). **22 Items** ✅ ([22-items.md](22-items.md)). **23 Price Lists / Tax Categories** ✅ ([23-price-lists-tax-categories.md](23-price-lists-tax-categories.md)) · **24 Vaccine Schedules / Immunization Programs** ✅ ([24-immunization.md](24-immunization.md) — cleanest surface: custom doctypes, row-level perms, no P1). **★ All functional surfaces now audited — nothing left to audit.**_

_**Gaps re-classified under the guiding principle (were "out of scope"):** **Price Lists** and **Tax Categories** have **no backend `create`** (read-only/stub) — under "manage everything from the frontend" these need write CRUD (API + screen), tracked as **G-C**. **Vaccine Schedules** / **Immunization Programs** (immunization module) still warrant their own audit. A **desk-dependency sweep** (below) is the systematic way to guarantee nothing forces a tenant into the desk._

_Settings coverage gaps (config surfaces the frontend does not manage) — see [GAPS_SETTINGS_COVERAGE.md](GAPS_SETTINGS_COVERAGE.md): **G-A** Healthcare Settings → BH-13; **G-B** Integrations/messaging placeholder → BH-14; **G-C** financial setup (tax rates, CoA, fiscal year, currency) → BH-15._

**★ Full desk-dependency sweep (2026-07-04): [DESK_DEPENDENCY_SWEEP.md](DESK_DEPENDENCY_SWEEP.md).** Systematic 5-area sweep of everything that forces a tenant into the desk. Master data is fully managed; desk-dependencies cluster in config (BH-13/16), integrations+messaging (BH-14/17/19), financial setup (BH-15, BH-3), and platform admin (BH-18/20). Also fixes: **Appearance** nav 404, **Subscription** mock, orphan `remedisys_clinic_settings`. Corrects earlier G-C (Price List/Tax Category are managed via generic REST, not stubs) and confirms Items/Payment Methods/Insurance/Immunization are real CRUD._

**✅ AUDIT COMPLETE — 19 screens closed (2026-07-04)** + 2 settings-coverage gaps logged (G-A, G-B). Backend hand-offs consolidated in [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md) (BH-1…4, 6, 7, 8, 9, 10, 11, 12, 13, 14). Recurring frontend fixes to batch: **P5** (swallowed delete errors), **P6** (i18n — bilingual catalogs), **P11** (list-error-rendered-as-empty), and the **ADR-021 `master_crud`** list-read migration (screens using `/api/resource/`: MD1, HL7, PR1, PS1, MED1, LT1, IG2, TH1).

## Cross-screen findings (recurring patterns)
_Logged here as they recur across screens (e.g. the create-denied-but-UI-offered pattern, hidden-but-writable fields, cosmetic validation)._
- **P1 — Create/UI vs perm mismatch:** UI offers create for roles with `create:0` (first seen: Company G1).
- **P2 — Hidden-but-writable core fields:** ERPNext-mandatory fields hidden in UI (first seen: Company `default_currency`, `valuation_method`).
- **P3 — Cosmetic validation:** `type=email`/`url` never fires because saves are button clicks, not `<form>` submits (first seen: Company G4).
- **P4 — Create-only / permanent fields hidden:** ERPNext fields that can only be set at creation and never changed after (first seen: Company `abbr`, `chart_of_accounts`) — must be surfaced *at create* or lost forever.
- **P5 — Silent save failures:** settings mutations lack `onError`; failed PATCH/403 shows no message (first seen: Facilities F1). Check every settings screen's mutation error handling.
- **P6 — Hardcoded UI strings (i18n §13.10):** settings screens use English literals instead of message-catalog keys (first seen: Facilities F2). **Confirmed systemic** — only ~32% of components use next-intl; switching language barely changes the UI. Scoped, phased remediation plan: **[I18N_P6_PLAN.md](I18N_P6_PLAN.md)** (infra healthy + en/es at 100% parity; debt concentrated in settings 13% / app pages 19% / shell nav; start with app-shell + a lint guardrail).
- **P7 — `EB Clinic Settings` is shared across 5 screens** (Facilities, Notifications, Access & Security, Appearance, Role Permissions) via one GET/PATCH; each screen edits its own field subset.
- **P9 — `Link`/`Dynamic Link` field rendered as free text** (method §6, highest-priority control class = referential-integrity bug): user types a value that must match an existing record by name (first seen: Appointment Types AT3 — billing item `Link`→`Item` as a plain input). Check every master-data screen for Link fields shown as text instead of a searchable dropdown.
- **P10 — Inert/dead field:** backend stores + validates a field nothing consumes downstream; surfacing it in the UI would ship a setting with no effect (first seen: Appointment Types AT2 — `allow_booking_for`, unused by booking UI or API). Before adding UI for a backend field, confirm something actually reads it.
- **P11 — List-load error rendered as empty state:** a failed list query is swallowed to `data=[]`, so a backend/network error shows the "nothing here yet" empty message instead of an error (first seen: Practitioners PR2 — `useAdminPractitioners` error ignored). Sweep every list screen for error handling distinct from empty.
- **Positive — ADR-021-clean reference:** Appointment Types (screen 6) is the first master-data screen already using custom `api/v1/admin` CRUD instead of `/api/resource/`. Use `api/v1/admin/catalog.py` as the migration template for MD1/HL7 and other `standardCrud` screens. Practitioners (screen 7) is clean for writes + detail read; only its list read uses `/api/resource/`.

## Backend hand-offs
Items that can't be done frontend-only are consolidated in [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md) (BH-1…). Nothing implemented yet — spec only.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |

<!-- BEGIN GENERATED INDEX -->

_29 document(s) in this directory. Generated by `scripts/gen_doc_indexes.py` — do not edit by hand._

| Document | Status | Updated | Title |
|---|---|---|---|
| [`01-company.md`](01-company.md) | record | 2026-07-02 | Settings → Company |
| [`02-facilities.md`](02-facilities.md) | record | 2026-07-02 | Settings → Facilities |
| [`03-medical-departments.md`](03-medical-departments.md) | record | 2026-07-03 | Settings → Medical Departments |
| [`04-service-units.md`](04-service-units.md) | record | 2026-07-04 | Settings → Service Units |
| [`05-holiday-lists.md`](05-holiday-lists.md) | record | 2026-07-06 | Settings → Holiday Lists |
| [`06-appointment-types.md`](06-appointment-types.md) | record | 2026-07-03 | Settings → Appointment Types |
| [`07-practitioners.md`](07-practitioners.md) | record | 2026-07-04 | Settings → Practitioners |
| [`08-practitioner-schedules.md`](08-practitioner-schedules.md) | record | 2026-07-04 | Settings → Practitioner Schedules |
| [`09-medications.md`](09-medications.md) | record | 2026-07-04 | Settings → Medications |
| [`10-brands.md`](10-brands.md) | record | 2026-07-04 | Settings → Brands |
| [`11-manufacturers.md`](11-manufacturers.md) | record | 2026-07-04 | Settings → Manufacturers |
| [`12-dosage-forms.md`](12-dosage-forms.md) | record | 2026-07-04 | Settings → Dosage Forms |
| [`13-lab-test-templates.md`](13-lab-test-templates.md) | record | 2026-07-04 | Settings → Lab Test Templates |
| [`14-lab-test-groups.md`](14-lab-test-groups.md) | record | 2026-07-04 | Settings → Lab Test Groups (Item Group) |
| [`15-symptoms.md`](15-symptoms.md) | record | 2026-07-04 | Settings → Symptoms → **Complaints** |
| [`16-diagnosis.md`](16-diagnosis.md) | record | 2026-07-04 | Settings → Diagnosis |
| [`17-treatment-plans.md`](17-treatment-plans.md) | record | 2026-07-04 | Settings → Treatment Plans |
| [`18-therapy-types.md`](18-therapy-types.md) | record | 2026-07-04 | Settings → Therapy Types |
| [`19-clinical-procedures.md`](19-clinical-procedures.md) | record | 2026-07-04 | Settings → Clinical Procedures → **Clinical Procedure Templates** |
| [`20-payment-methods.md`](20-payment-methods.md) | record | 2026-07-04 | Settings → Payment Methods |
| [`21-insurance.md`](21-insurance.md) | record | 2026-07-04 | Settings → Insurance (Insurance Payor) |
| [`22-items.md`](22-items.md) | record | 2026-07-04 | Settings → Items |
| [`23-price-lists-tax-categories.md`](23-price-lists-tax-categories.md) | record | 2026-07-04 | Settings → Price Lists & Tax Categories |
| [`24-immunization.md`](24-immunization.md) | record | 2026-07-04 | Settings → Vaccine Schedules & Immunization Programs |
| [`BACKEND_HANDOFFS.md`](BACKEND_HANDOFFS.md) | record | 2026-07-05 | Backend hand-offs from the Settings audit |
| [`DESK_DEPENDENCY_SWEEP.md`](DESK_DEPENDENCY_SWEEP.md) | record | 2026-07-04 | Desk-Dependency Sweep — "manage everything from the frontend" |
| [`GAPS_SETTINGS_COVERAGE.md`](GAPS_SETTINGS_COVERAGE.md) | record | 2026-07-04 | Settings coverage gaps (not screens — missing configuration surfaces) |
| [`I18N_P6_PLAN.md`](I18N_P6_PLAN.md) | record | 2026-07-04 | P6 — Frontend i18n Pass: Scope & Phased Plan |
| [`MASTER_SCREENS_3COL_PLAN.md`](MASTER_SCREENS_3COL_PLAN.md) | record | 2026-07-06 | Settings Master Screens — 3-Column Standardization + Full CRUD |

<!-- END GENERATED INDEX -->
