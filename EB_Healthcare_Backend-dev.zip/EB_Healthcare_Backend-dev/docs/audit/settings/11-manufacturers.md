# Settings → Manufacturers

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — MF1→BH-10 (add delete + DocPerm grant); MF2 i18n; MF3 skip. ADR-021 clean. · **Section:** Clinical Data · **Screen 11/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to ERPNext core **`Manufacturer`** (`erpnext/stock`) — pharmaceutical manufacturers assigned to a medication's pharmacy items. **Near-identical to Brands (screen 10):** standalone screen (`[section]/page.tsx:46` → `<ManufacturersSection />`), Name/Full-Name table + inline add, **ADR-021-clean** (custom `list_manufacturers`/`create_manufacturer`, explicit "not `/api/resource/`"), **correct error handling** (amber card, not the P11 trap). Same core gap: **Create + Read only** — no update/delete, FE and BE aligned. **One difference from Brands:** the Manufacturer DocPerm grants admin `read/write/create` but **NOT `delete`** — so enabling delete needs a DocPerm patch *in addition to* the API method.

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Manufacturer`** (erpnext core) | custom `admin.api.list_manufacturers` (`manufacturers/route.ts:17`; `catalog.py:1955`) ✅ |
| Create | `Manufacturer` | custom `admin.api.create_manufacturer` (`manufacturers/route.ts:31`; `catalog.py:1982`) ✅ |
| Update | — | **none** |
| Delete | — | **none** |

- **Frontend:** `src/components/settings/manufacturers-section.tsx` (standalone; table + inline add). Hooks `use-admin-manufacturers.ts` (`createAdminResource("manufacturers")` → `useList` + `useCreate` only). Nav `settings-nav.ts:57` (**Clinical Data**). Also an inline searchable combobox (inline-create) in the Medication `linked_items` editor.
- **ADR-021 / Rule 11:** ✅ **CLEAN** — GET + POST via custom whitelisted methods; BFF explicitly avoids `/api/resource/`.

## 2. Permissions
DocPerm spec (Manufacturer): **`EB_Healthcare Admin`** read/write/create = 1, **delete = 0**; `EB_Front Desk` / `EB_Nurse` / `EB_Practitioner` read-only.
- **Differs from Brand:** Brand grants admin `delete=1`; Manufacturer does **not**. Enabling delete (MF1) therefore requires both a new `delete_manufacturer` method **and** a DocPerm patch granting `delete` to `EB_Healthcare Admin`.
- **Inverse capability gap (not P1):** admin has `write` but no `update_manufacturer` API — granted perm unusable, same as Brands.

## 3. Field parity + control types
Backend `Manufacturer` fields: `short_name` (Data, **reqd**), `full_name` (Data), `website` (Data), `country` (Link→Country), `logo` (Attach Image), `notes` (Small Text), `address_html`/`contact_html` (HTML).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Name | `short_name` | Data | text | ✅ | create-only (no edit exists) | yes |
| Full Name | `full_name` | Data | text | ✅ | create-only | no |

**Not surfaced (P8):** `website`, `country`, `logo`, `notes`, address/contact HTML — all low-value for a medication-tagging lookup. Skip.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| MF1 | **Create + Read only — no Update/Delete** (FE and BE aligned; `catalog.py` exposes only `list_manufacturers`/`create_manufacturer`). Can't remove a typo/duplicate. | Missing CRUD (backend+frontend) | **Medium** | ✅ **DECIDED: add delete → BH-10** (same as Brands BR1). **Also requires a DocPerm patch** granting `delete` to `EB_Healthcare Admin` (Manufacturer currently lacks it). Rename skipped; Create+Read accepted. Delete-in-use fails safely (LinkExistsError). |
| MF2 | **Fully hardcoded strings — no `useTranslations`** (`manufacturers-section.tsx`: title/sub :37-38, labels :57/61, errors, buttons). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.manufacturers` catalog (en + es-MX). |
| MF3 | **`website`/`country`/`logo`/`notes` not surfaced.** | Missing fields (P8) | Low | ✅ **DECIDED: skip** (low-value for a medication-tagging lookup). |
| — | **ADR-021 clean; correct list-error handling (P11 counter-case); create error surfaced** | — | — | ✅ No finding. |

## 5. Resolved decisions (2026-07-04)
1. **MF1 — add `delete_manufacturer` (BH-10)** + DocPerm patch granting admin `delete`; FE delete affordance. Rename skipped; Create+Read accepted.
2. **MF2 — frontend i18n** (`settings.manufacturers` en+es).
3. **MF3 — skip** extra fields.

## 6. Follow-up
- Backend: **BH-10** (extended) — `delete_manufacturer` **+ DocPerm `delete` grant** for `EB_Healthcare Admin` (via patch, never hand-edit).
- Frontend TODO: MF2 (i18n), delete affordance once BH-10 lands.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
