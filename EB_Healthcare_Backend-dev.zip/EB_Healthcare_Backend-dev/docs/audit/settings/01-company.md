# Settings → Company

**Doc status:** record · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-02 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ audited — decisions pending · **Section:** Clinic · **Screen 1/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only, no backend changes.

## 1. Doctype mapping — one screen → two core doctypes
| Section | DocType | API method(s) |
|---|---|---|
| Header + Legal + Contact | **`Company`** (ERPNext core — *no custom fields; all native*) | `get_companies` read · `update_company` write · `create_company` create |
| Address block | **`Address`** (Frappe core, type "Office", Dynamic-Link → Company) | `get_company_address` read · `save_company_address` write |
| Logo | `Company.company_logo` | separate `/api/admin/upload-logo`, then `update_company` |

**BFF routes:** `/api/admin/company-profile` (GET `get_companies` p1/s1 → `data[0]`; PATCH `update_company`) · `/api/admin/company-address` (GET/POST) · `/api/companies` (switcher list).
**Frontend:** `src/components/settings/companies-section.tsx` — renders `CompanyProfile` when a company exists, else `CreateCompanyForm`. Hooks: `use-company-profile.ts`, `useCountries`.

## 2. Permissions (DocPerm spec `patches/v0/eb_docperm_spec.json`) — the headline
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | **❌** | **❌** |
| EB_Nurse / EB_Practitioner / EB_Front Desk | ✅ | ❌ | ❌ | ❌ |
| System Manager / Accounts Manager (core) | ✅ | ✅ | ✅ | ✅ |

- **Update/Save works** for Healthcare Admin (write granted). ✅
- **Create Company → 403** for a pure Healthcare Admin (`create:0`). `CreateCompanyForm` renders but submit fails unless the user also holds System Manager/Accounts Manager. **Frontend/backend mismatch (G1).**
- **All clinical roles have `read` on Company** — broader exposure than the admin-only `/settings` gate implies.

## 3. Field-by-field parity
All rendered fields map to real backend fields; **no orphan UI fields**. All Legal/Contact fields are **native `Company` columns** (not app custom fields).

| Frontend field | Backend field | DocType | Editable | Req (BE) | Notes |
|---|---|---|---|---|---|
| Company name (header) | `company_name` | Company | 🔒 read-only | yes | update API omits it (`api.py:198`) |
| Abbreviation (badge) | `abbr` | Company | 🔒 read-only | yes | `set_only_once` at core |
| RFC / Tax ID | `tax_id` | Company | ✅ | no | no RFC format validation anywhere |
| Country (Legal) | `country` | Company | ✅ | yes | required at doctype; UI doesn't enforce |
| Date of establishment | `date_of_establishment` | Company | ✅ | no | |
| Date of incorporation | `date_of_incorporation` | Company | ✅ | no | |
| Default holiday list | `default_holiday_list` | Company | ✅ | no | |
| Street / address line 1 | `address_line1` | **Address** | ✅ | no | |
| Address line 2 | `address_line2` | **Address** | ✅ | no | |
| City | `city` | **Address** | ✅ | no | |
| State / province | `state` | **Address** | ✅ | no | |
| Postal code | `pincode` | **Address** | ✅ | no | backend field name is `pincode` |
| Country (Address) | `country` | **Address** | ✅ | no | second, independent Country field |
| Phone (+"+52") | `phone_no` | Company | ✅ | no | stored as `"+52-<num>"`; no format check |
| Email | `email` | Company | ✅ | no | `type=email` cosmetic (no `<form>` submit) |
| Website | `website` | Company | ✅ | no | `type=url` cosmetic |
| Logo | `company_logo` | Company | ✅ | no | separate `/api/admin/upload-logo` |

**Backend fields NOT surfaced:** `default_currency` (writable via `update_company`, forced `"MXN"` on create, never shown → G2), `valuation_method` (create-only, FIFO, ERPNext-mandatory), `chart_of_accounts` (create-only, not in API → G7).

### 3.1 Control-type correctness (backend fieldtype → UI control)
| Field | Backend fieldtype | UI control | Correct? |
|---|---|---|---|
| country (Legal & Address) | Link→Country | `CountrySelect` dropdown | ✅ |
| default_holiday_list | Link→Holiday List | `<select>` from `useAdminHolidayLists` | ✅ |
| date_of_establishment / incorporation | Date | native date picker | ✅ |
| company_logo | Attach Image | `AvatarUpload` | ✅ |
| tax_id / email / phone_no / website | Data | text input | ⚠️ correct control, but validation is cosmetic (G4) |
| default_currency | Link→Currency | *hidden* → must be dropdown from `useCurrencies` | ➕ add (G2) |
| chart_of_accounts | Select | *absent* → must be `Select` at create | ➕ add (G7) |

Field-type discipline on this screen is otherwise sound (no Link/Select rendered as free text).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| G1 | Create-company UI offered to a role with `create:0` → 403. | Perm mismatch | **High** | ✅ **DECIDED: allow.** Healthcare Admin may create a company/clinic. → **Backend hand-off:** grant `create` on Company to `EB_Healthcare Admin` in `eb_docperm_spec.json` (NOT frontend-only). Keep `delete` OFF. **Architect caveats:** ERPNext Company create auto-provisions COA/warehouses/cost-centers (heavy — prefer a guided onboarding wizard over the raw form); `abbr` is `set_only_once` (permanent — validate hard at create). |
| G2 | `default_currency` hidden but writable (forced MXN); `valuation_method` hidden. | Missing field | Medium | ✅ **DECIDED: Option B.** Currency = a **Currency-linked dropdown** (fed by `useCurrencies`, never hardcoded), **editable iff backend allows**, else read-only with reason. **Backend hand-off:** add computed `currency_change_allowed = not check_if_transactions_exist()` to the company-profile response (ERPNext blocks currency change once submitted Sales/Purchase docs exist — `company.py:320,143`). At create, default currency by jurisdiction/compliance profile (`mx`→MXN, `in`→INR). `valuation_method` stays hidden (FIFO). |
| G7 | **Chart of Accounts not selectable at create.** `create_company` has no `chart_of_accounts` arg; create form omits it; ERPNext silently uses the country's standard CoA. CoA is **create-only / permanent** (builds the account tree; cannot change after). | Missing field (create-only) | Medium | ✅ **DECIDED (Option 1): create-form only.** Scaffolded as a disabled `Select` in `CreateCompanyForm` (`COA_SELECTABLE` flag), defaulting to country standard. **Deliberately NOT shown in the profile/edit view** — CoA is create-only/permanent; showing it in edit would misleadingly imply it's changeable. Visible once the create/onboarding flow is enabled (BH-1) and BH-3 lands: (a) `create_company` accepts `chart_of_accounts`; (b) endpoint listing CoA templates per country (ERPNext `get_charts_for_country`). |
| G3 | Two independent "Country" fields (`Company.country` vs `Address.country`) can diverge; no sync/validation. | UX + integrity | Medium | ✅ **DECIDED: sync-with-warning.** Default Address country from Company country; keep editable; warn if they diverge. Frontend-only. |
| G4 | No real validation on profile view — free-text RFC (no Mexican RFC check; matters for CFDI), cosmetic email/url types, free-text phone. | Validation | **High** | ✅ **DECIDED: add client validation.** RFC regex per jurisdiction (MX `^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3}$`; skip/relax for India), real email + URL checks, phone digit-count. Frontend-only. |
| G5 | Two-doctype save non-atomic — `update_company` + `save_company_address` are separate calls; partial-save risk, no rollback. (*fix touches backend*) | Integrity | Medium | ✅ **DECIDED: frontend mitigation now** — save sequentially; on address failure show clear "company saved, address failed — retry" state (no silent half-save). Combined transactional endpoint logged as backend nice-to-have (hand-off, low priority). |
| G6 | Logo upload is a separate step from Save — minor orphan-on-failure risk. | Minor | Low | ✅ **DECIDED: accept**, with tightening — persist the logo URL only on a successful Save. Frontend-only. |

## 5. CRUD / states
- **CRUD from this screen:** Read + Update only (correct for "edit my clinic"). Company Create/Delete are not this screen's job (multi-clinic create is a separate admin flow — and blocked for the admin role, G1).
- **Empty/loading/error states:** create-form shows when `company === null`; profile does `window.location.reload()` on save. _Detailed loading/error handling to confirm from `companies-section.tsx` render paths._

## 6. Open questions for product owner
1. **G1:** Is multi-clinic creation *supposed* to be a Healthcare Admin capability (→ backend perm grant or a System-Manager-only flow), or should the create form be hidden for this role?
2. **G2:** Should currency be shown & editable here, or is MXN a deliberate lock we make explicit (read-only display)?

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
