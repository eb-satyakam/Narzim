# Settings → Symptoms → **Complaints**

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — SY1 P1→BH-12; SY2→FE fix; SY3 renamed "Complaints" (FE, owner-requested); SY4 i18n. ADR-021 clean. · **Section:** Clinical Data · **Screen 15/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit; label rename applied per owner.

## 0. Headline
Maps to core **`Complaint`** (healthcare) — a **one-field master** (`complaints`, which is also the record name). The frontend called it **"Symptoms"**; per the owner's instruction it is **renamed to "Complaints" to match the backend doctype** (SY3). Standalone 3-column screen with **full CRUD** (edit = rename, since the field is the name). It's **ADR-021-clean** (own `/api/admin/symptoms` route → custom `list/create/update/delete_complaint`, no `/api/resource/`), and the profile handles errors + delete correctly (P5 counter-case). But it has the **same P1 permission mismatch as screen 14, worse**: the UI offers create/edit/delete while the DocPerm spec grants `EB_Healthcare Admin` only **`read`** on Complaint — so every write 403s for the admin (SY1). Oddly, `EB_Practitioner` has `create` but the admin does not.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Complaint`** (healthcare) | custom `admin.api.list_complaints` (`catalog.py:2501`) ✅ |
| Create | `Complaint` | custom `admin.api.create_complaint` (`catalog.py:2517`) ✅ |
| Update (= rename) | `Complaint` | custom `admin.api.update_complaint` (`catalog.py:2545`) ✅ |
| Delete | `Complaint` | custom `admin.api.delete_complaint` (`catalog.py:2573`) ✅ |

- **Frontend:** `settings/symptoms/` 3-col — `symptoms-list.tsx`, `symptom-form.tsx`, `symptom-profile.tsx`. Hooks `use-admin-symptoms.ts` (`createAdminResource("symptoms")` → full CRUD). Dedicated BFF route `src/app/api/admin/symptoms` (custom methods). Nav `settings-nav.ts:61` (**Clinical Data**, own route `/settings/symptoms`).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — all four ops via custom whitelisted methods; explicitly kept out of the `standardCrud` catch-all (comment in `[resource]/route.ts:187-190`).

## 2. Permissions — P1 mismatch (worse than IG1)
DocPerm spec (`Complaint`): **`EB_Healthcare Admin`** = **`read` only**; `EB_Nurse` = read; **`EB_Practitioner`** = read + **`create`**.
- **SY1 (P1):** the UI offers **Create + Edit + Delete**, but the admin role is **read-only** → `create_complaint`/`update_complaint`/`delete_complaint` all raise `PermissionError` for an `EB_Healthcare Admin` (unless the user also holds System Manager). Worse than screen 14 (which at least had read). Inconsistency: `EB_Practitioner` can create complaints but the admin can't.

## 3. Field parity + control types
Backend `Complaint`: single field `complaints` (Data, **reqd**; `autoname: field:complaints`).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Symptom Name → **Complaint** | `complaints` | Data | text | ✅ | create + edit (edit = rename) | yes |

Full parity (one field). Edit is a genuine rename (name == the field).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| SY1 | **P1: full CRUD UI vs admin read-only DocPerm on `Complaint`.** Create/edit/delete 403 for `EB_Healthcare Admin`; `EB_Practitioner` inconsistently has create. | Permission (P1) | **High** | ✅ **DECIDED → BH-12:** grant `create`+`write`+`delete` on `Complaint` to `EB_Healthcare Admin` via a DocPerm patch. (Review the `EB_Practitioner` create grant for consistency while at it.) |
| SY2 | **List-error rendered as empty** — `symptoms-list.tsx:25` destructures `{ data: symptoms = [], isLoading }`, ignores `isError` → failure shows "No symptoms/complaints." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card. |
| SY3 | **Misleading label "Symptoms" — the doctype is `Complaint`.** | Clarity / naming | **Medium** | ✅ **DONE (frontend, owner-requested): renamed to "Complaints".** Nav, list, form, profile labels updated. "Complaint" (chief complaint) is standard clinical terminology, so this reads cleanly. Strings hardcoded pending SY4 i18n. |
| SY4 | **Hardcoded strings — no `useTranslations`** (all symptoms components). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.complaints` catalog (en + es-MX). |
| — | **ADR-021 clean; profile error card + delete toast handled correctly** | — | — | ✅ No finding (P5 counter-case). |

## 5. Recurring sub-pattern (P1 on master doctypes)
Screens 14 (Item Group) and 15 (Complaint) both show **admin read-only DocPerm under a full-CRUD (or create/delete) UI**. Worth a **sweep of the remaining Clinical Data master doctypes' DocPerm** (Diagnosis, Treatment Plan, Therapy Type) for the same gap — several master doctypes may have been granted read-only to `EB_Healthcare Admin` by oversight. Flagged for screens 16–18.

## 6. Follow-up
- Backend: **BH-12** — DocPerm patch granting `Complaint` create+write+delete to `EB_Healthcare Admin` (resolves SY1).
- Frontend: **SY3 rename applied this session** (`Healthcare_next_app`). SY2 (error card) + SY4 (i18n) are frontend TODO.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
