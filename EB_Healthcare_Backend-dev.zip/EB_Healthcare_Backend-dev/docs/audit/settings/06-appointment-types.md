# Settings → Appointment Types

**Doc status:** record · **Created:** 2026-07-03 by Invincible · **Updated:** 2026-07-03 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — decisions logged. AT2/AT5→BH-7 (backend); AT1/AT3/AT4/AT5/AT6→frontend TODO; AT2 UI Select deferred (field inert); AT7 keep. · **Section:** Scheduling & Staff · **Screen 6/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Appointment Type`** (healthcare app). This is the **first master-data screen that is already ADR-021 clean** — it goes through custom `api/v1/admin/catalog.py` whitelisted methods, **not** `/api/resource/` (contrast MD1, HL7). Permissions are clean too (admin full CRUD, front-desk read-only) — a second P1 counter-case after Holiday Lists. The problems are elsewhere: a **mandatory backend field (`allow_booking_for`) is entirely absent from the UI** and the backend API that would set it is **buggy** (validates against a value that isn't even a valid option); the **billing item is a `Link`→`Item` rendered as a free-text box** (referential-integrity control mismatch, the highest-priority control class); the create/edit forms are **asymmetric** (billing only settable after a second save); the familiar **swallowed-delete-error** (P5) and **fully-hardcoded strings** (P6, worse than prior screens — zero `useTranslations`).

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List | **`Appointment Type`** (healthcare app) | `list_appointment_types` (`api/v1/admin/catalog.py:51`) |
| Create | `Appointment Type` | `create_appointment_type` (`catalog.py:96`) |
| Update | `Appointment Type` | `update_appointment_type` (`catalog.py:140`) |
| Delete | `Appointment Type` | `delete_appointment_type` (`catalog.py:201`) |
| Billing rows | `Appointment Type Service Item` (child `items`) | first row read/written by the API |
| Medical codes | `Codification Table` (child `codification_table`) | **not touched** |

- **Frontend:** `src/components/settings/visit-types-section.tsx` (component `VisitTypesSection`, nav key `visit-types`, UI label "Appointment Types"); hand-written hooks in `use-healthcare.ts` (`useAppointmentTypes` :133, create :143, update :167, delete :186); nav `settings-nav.ts:47` (**Scheduling & Staff** group).
- **BFF:** `src/app/api/healthcare/appointment-types/route.ts` → `frappeFetchSet` to `remedisys_healthcare_ai.api.v1.admin.api.{list,create,update,delete}_appointment_type` (GET :11, POST :30, PATCH :47, DELETE :64).
- **ADR-021 / Rule 11:** ✅ **COMPLIANT.** Real custom whitelisted CRUD; no `/api/resource/`. **No AT-finding here** — this is the reference example the other master-data screens should migrate toward.

## 2. Permissions — clean (second P1 counter-case)
DocPerm spec `patches/v0/eb_docperm_spec.json:147-192`:
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ✅ |
| **EB_Front Desk** | ✅ | — | — | — |

Admin has full CRUD; create/delete UI is correctly permission-backed. **No P1 mismatch.** (The doctype JSON's own `permissions` list `Healthcare Administrator` + `Physician`, but per README the DocPerm spec patch is the authoritative baseline.)

## 3. Field parity + control types
Backend `Appointment Type` fields (`appointment_type.json`): `appointment_type` (Data, **reqd**, unique), `default_duration` (Int), `color` (Color), `price_list` (Link→Price List), `items` (Table→Appointment Type Service Item), **`allow_booking_for` (Select `Practitioner\nDepartment\nService Unit`, reqd, default Practitioner)**, `codification_table` (Table→Codification Table).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Appointment type name | `appointment_type` | Data (unique) | text | ✅ | create-only (locked on edit) | yes |
| Duration (min) | `default_duration` | Int | number (min5 step5) | ✅ | yes | no |
| Color | `color` | Color | fixed-palette swatches | ⚠️ constrained (see AT7) | yes | no |
| Billing item (service item name) | `items[0].op_consulting_charge_item` | **Link→Item** | **plain text input** | ❌ **Link-as-free-text (AT3)** | **edit-only** | no |
| Consulting charge (MXN) | `items[0].op_consulting_charge` | Currency | number | ✅ | **edit-only** | no |

**Not surfaced (P8):**
- **`allow_booking_for`** — Select, **mandatory**, hard-defaults to `Practitioner` server-side; admin can never choose Department/Service Unit from the UI (**AT2**).
- `price_list` (Link→Price List) — not surfaced.
- Full `items` child table — only the **first** service-item's charge-item/charge is read/written; multiple service items, `inpatient_visit_charge_item`/`inpatient_visit_charge`, and `dt`/`dn` are invisible (**AT5**).
- `codification_table` (ICD/medical codes) — not surfaced.

**Create vs edit asymmetry:** create sends only `{name, default_duration, color}` (`visit-types-section.tsx:66`); the create API doesn't even accept billing (`create_appointment_type` signature has no charge params). Billing item + charge are edit-only → a new type must be **saved twice** before it can bill (**AT5**).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| AT1 | **Delete error swallowed** — `deleteVisitType.mutateAsync(...).catch(() => null)` then dialog closes unconditionally (`visit-types-section.tsx:74-78`). A blocked delete (type referenced by existing appointments) closes as if it succeeded, no message. | Error UX (P5) | **High** | ✅ **DECIDED: frontend fix** (try/catch → inline error, keep dialog open) — same as MD2/HL1. Not yet implemented. |
| AT2 | **`allow_booking_for` (reqd Select) absent from UI + backend API bug.** DocType options are `Practitioner/Department/Service Unit`; the custom API validates against `{"Practitioner","Medical Department"}` (`catalog.py:117,171-175`) — "Medical Department" isn't a valid option, and "Department"/"Service Unit" are **silently coerced to Practitioner** on create or **rejected 400** on update. Field is mandatory, hidden, and hard-defaulted. | Missing mandatory field (P2) + **backend correctness** | **High** | ✅ **DECIDED: fix backend, defer UI.** Evidence: `allow_booking_for` is **inert** — booking UI (`new-appointment-dialog.tsx`, always practitioner-driven) and booking API (`appointments/api.py:_create_impl`, never reads it) ignore it. → **BH-7** fixes the validation set (real options, no silent coercion). **UI Select deferred** until non-practitioner booking is a real feature (avoids a dead setting). |
| AT3 | **Billing item is `Link`→`Item` rendered as a free-text input** (`visit-types-section.tsx:158-165`). Typing a name that must exactly match an existing `Item` = referential-integrity risk (method §6, highest-priority control class). | Control mismatch | **High** | ✅ **DECIDED: searchable Item combobox**, filtered to service items (`/api/admin/items` exists). Depends on BH-7 (create accepts billing) so it's settable at create, not just edit. Frontend TODO. |
| AT4 | **Fully hardcoded English strings — no `useTranslations` at all** (title/sub :84, table headers :110, dialog titles :138/:204, field labels, validation msg :65, buttons). Worse than prior screens (zero i18n, not partial). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → new `settings.appointmentTypes` catalog (en + es-MX). Not yet implemented. |
| AT5 | **Create/edit asymmetry + partial billing model.** Create can't set billing (double-save required); only `items[0]` surfaced; `price_list`, inpatient charges, full `items` table, `codification_table` all hidden. | Missing fields (P4) + product scope | **Medium** | ✅ **DECIDED: keep single OP charge, make it settable at create.** Full `items` table / inpatient charges / `price_list` / `codification_table` **deferred (YAGNI for OPD)**. "Settable at create" → **BH-7** (create API accepts `op_consulting_charge_item`/`op_consulting_charge`). |
| AT6 | **Thin client validation** — only name-required on create (`:65`); no edit validation, no duplicate-name pre-check, duration/charge rely on HTML `min`/`step` only. | Validation | Low | ✅ **DECIDED: frontend fix** (name required on edit too, numeric guards). Duplicate name is caught server-side (unique) + surfaced via `submitError`, so no client pre-check needed. |
| AT7 | **Color restricted to a fixed palette** (`APPT_TYPE_COLORS`, `:11`) vs backend arbitrary `Color`. | Control (minor) | Low | ✅ **DECIDED: keep palette** for visual consistency (same as elsewhere). No change. |
| — | **ADR-021 / Rule 11** | Architecture | (n/a) | ✅ **COMPLIANT** — custom whitelisted CRUD, no `/api/resource/`. No finding. |

## 5. Resolved decisions (2026-07-03)
1. **AT2 — RESOLVED: fix backend, defer UI.** Verified `allow_booking_for` is inert (booking is practitioner-only end-to-end). Backend validation fix → **BH-7**. UI Select deferred until non-practitioner booking is a real product feature — declined to ship a setting nothing consumes. *(Reverses an initial "add the Select" lean, on the strength of the inert-field evidence.)*
2. **AT5 — RESOLVED: single OP charge, settable at create.** Full `items` table / inpatient charges / `price_list` / `codification_table` deferred as YAGNI for an outpatient pediatric product. Create-path billing → **BH-7**.
3. **AT3 — RESOLVED: searchable Item combobox filtered to service items.** Exact item-group filter to be confirmed at implementation time against `/api/admin/items`.
4. **AT1 + AT4 — RESOLVED: standard frontend fixes** (surface delete errors; move all strings to `settings.appointmentTypes` en + es-MX), same as MD/HL.

## 6. Follow-up
- Backend: **BH-7** (see [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md)) — fix `allow_booking_for` validation + accept billing on create.
- Frontend TODO (separate change): AT1, AT3, AT4, AT5 (create-billing UI once BH-7 lands), AT6.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-03 | Sarvesh | Initial version (header backfilled from git history) |
