# Settings → Therapy Types

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — TH1→ADR-021; TH2/TH3/TH4/TH5 FE-TODO; TH6 skip. No P1, no rename, no backend hand-off. · **Section:** Clinical Data · **Screen 18/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Therapy Type`** (healthcare) — a billable master that **auto-creates an ERPNext Item** (item_code/item_name default to the therapy name). Single-page **list + modal form** (not the 3-column pattern). **Admin has full CRUD (no P1** — third clean master in the sweep, with Diagnosis + Treatment Plans), the **list handles `isError`** (P11 counter-case), writes go through **custom methods** (ADR-021-clean), and the **nav label already matches the backend** ("Therapy Types" → doctype "Therapy Type" — no rename). Three real gaps: the **list read uses `/api/resource` even though a custom `list_therapy_types` already exists** (TH1), the familiar **swallowed delete + no confirm** (TH2), and — the notable one — **`medical_department` and `default_duration` are accepted by the create/update API but are missing from the form** (TH3), so two supported fields can't be set.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Therapy Type`** | **generic `/api/resource/Therapy Type`** via `frappeRestList` (`[resource]/route.ts` GET) — **ADR-021 hole (TH1)**, despite a custom `list_therapy_types` (`catalog.py:1283`) existing and unused |
| Create | `Therapy Type` (+ auto Item) | custom `admin.api.create_therapy_type` (`catalog.py:1297`) ✅ |
| Update | `Therapy Type` | custom `admin.api.update_therapy_type` (`catalog.py:1346`) ✅ |
| Delete | `Therapy Type` | custom `admin.api.delete_therapy_type` (`catalog.py:1403`) ✅ |

- **Frontend:** `src/app/(clinic)/admin/therapy-types/page.tsx` (`TherapyTypesContent` — list + `Dialog` form). Hooks `use-admin-therapy-types.ts` (`createAdminResource("therapy-types")` → full CRUD). Generic `[resource]` config (`route.ts:191`, `frappeMethod: "therapy_type"`, **no `standardCrud`** → create/update/delete custom, list generic). Nav `settings-nav.ts:64` (**Clinical Data**, route `/admin/therapy-types`).
- **ADR-021 / Rule 11:** **PARTIAL** — create/update/delete custom ✅; **list GET via `/api/resource/`** ❌ (**TH1**). Cheapest fix in the audit since `list_therapy_types` is already written.

## 2. Permissions — clean (P1 counter-case)
DocPerm spec (`Therapy Type`): **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Nurse` + `EB_Practitioner` read-only. **No P1 mismatch.**

## 3. Field parity + control types
Backend create/update API accepts: `therapy_type` (reqd, name), `rate`, `is_billable` (default True), `item_group` (default "Services"), `description`, `medical_department`, `default_duration`. (Doctype also has `exercises`, `therapy_for`, `healthcare_service_unit`, `staff_role`, `codification_table` etc. — **not** in the API.)

| Frontend field | Backend | control | Correct? | Editable |
|---|---|---|---|---|
| Therapy Type Name | `therapy_type` (Data, reqd) | text | ✅ | create + edit (= rename) |
| Rate | `rate` (Currency) | number | ✅ | both |
| Description | `description` | textarea | ✅ | both — **but not prefilled on edit** (list omits it; no detail fetch) |
| Is Billable | `is_billable` (Check) | checkbox | ✅ | both |

**Accepted by API but NOT surfaced (P8, TH3):** `medical_department` (Link — which department offers the therapy) and `default_duration` (Int — default session length). Both are pure frontend adds (API already supports them). `item_group` defaults to "Services" server-side (fine to leave implicit). Doctype-only extras (`exercises`, `therapy_for`, service unit, staff role) are not in the API — skip (TH6).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| TH1 | **List read via `/api/resource/Therapy Type`** despite an existing unused `list_therapy_types`. | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021** (point the list at the custom `list_therapy_types` — trivial, method exists). |
| TH2 | **Delete error swallowed + no confirm** — `del.mutateAsync(item.name).catch(() => null)` (`page.tsx:136`), fires on click. | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — confirm dialog + surface delete error. |
| TH3 | **`medical_department` + `default_duration` accepted by API but not in the form**; `description` not prefilled on edit. | Missing fields (P8) | **Medium** | ✅ **DECIDED: frontend fix** — add department + default-duration inputs (API already accepts them); prefill description on edit (add to list fields or fetch detail). |
| TH4 | **Fully hardcoded strings — no `useTranslations`.** | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.therapyTypes` catalog (en + es-MX). |
| TH5 | **Thin validation** — only name; no rate guard; billable + empty rate may 400 server-side (auto-Item rate check). | Validation | Low–Med | ✅ **DECIDED: frontend fix** — require rate when billable (mirror the auto-Item rule). |
| TH6 | **`exercises`/`therapy_for`/service unit/staff role not surfaced** — also not in the API. | Missing fields (P8) | Low | ✅ **DECIDED: skip** (aligned with API; advanced/rare for OPD). |
| — | **Admin full CRUD (no P1); list handles isError; writes custom; name matches backend** | — | — | ✅ Clean master. |

## 5. Follow-up
- **No backend hand-off** (API already accepts department/duration; `list_therapy_types` already exists; admin already full CRUD).
- **No rename** — nav label already matches the backend doctype.
- Frontend TODO: TH1 (list → custom method / ADR-021), TH2 (confirm + delete error), TH3 (surface department + duration, prefill description), TH4 (i18n), TH5 (rate-when-billable).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
