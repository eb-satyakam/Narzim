# Settings → Holiday Lists

**Doc status:** record · **Created:** 2026-07-02 by Invincible · **Updated:** 2026-07-06 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — HL1–HL4 done, HL5→BH-6, HL6/HL7 skipped · **Section:** Clinic · **Screen 5/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only, no backend changes.

## 0. Headline
Maps to core **`Holiday List`** (parent) + **`Holiday`** child table. This is one of the **best-built** settings screens: it has a **full child-row editor** (add/edit/remove individual holiday dates + a bulk "generate weekly-off" button) and clean permissions. The gaps are the familiar ones — `/api/resource/` (ADR-021), swallowed delete error, hardcoded strings (with one twist: **English weekday names get written into the DB**), and thin client-side validation. Plus one genuine product opportunity for Mexico: local-holiday auto-import is unused.

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List + create/update/delete | **`Holiday List`** (core) | **`/api/resource/Holiday List`** via `standardCrud:true` (`[resource]/route.ts:55-63`) |
| Edit prefill (with child rows) | `Holiday List` | `/api/admin/holiday-list-detail` → `frappeRestGet` = `/api/resource/Holiday List/<name>` |
| Holiday rows | `Holiday` (child table `holidays`) | written inline via the standardCrud insert/update |

- **Frontend:** `src/components/settings/holiday-lists-section.tsx`; hooks `use-admin-holiday-lists.ts` (generic `createAdminResource`); nav `settings-nav.ts:41`.
- **ADR-021 / Rule 11:** **VIOLATION** — all CRUD via `/api/resource/`; no custom `create/update/delete_holiday_list` method exists (`frappeMethod: "holiday_list"` is dead config). Same class as Medical Departments MD1. Resolves under ADR-021's `master_crud` migration.

## 2. Permissions — clean (P1 counter-case)
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ✅ |
| (core HR Manager / HR User only otherwise) | — | — | — | — |

Admin has full CRUD; create UI is correctly permission-backed. **No P1 mismatch.**

## 3. Field parity + child table
**Parent fields:**
| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| List Name | `holiday_list_name` | Data | text | ✅ | create-only (locked on edit) | yes |
| Weekly Off | `weekly_off` | Select | `<select>` 7 days | ✅ | yes | no |
| From Date | `from_date` | Date | date picker | ✅ | yes | **yes (not enforced UI)** |
| To Date | `to_date` | Date | date picker | ✅ | yes | **yes (not enforced UI)** |
| Colour | `color` | Color | color picker | ✅ | yes | no |
| Holidays count | `total_holidays` | Int (read-only) | display | ✅ | — | — |

**Child `holidays` table — FULLY MANAGEABLE ✅** (the key question): add rows, edit date/description/half-day inline, remove rows; bulk "generate all {weekday}s in range". Written on save as `Holiday` rows.
| Child field | Backend | fieldtype | UI control | Correct? | Req |
|---|---|---|---|---|---|
| Date | `holiday_date` | Date | date picker | ✅ | yes (not enforced UI) |
| Description | `description` | **Text Editor (rich, reqd)** | plain text, **allows blank** | ⚠️ | yes (blank → server 400) |
| Half Day | `is_half_day` | Check | checkbox | ✅ | no |
| (row) Weekly Off | `weekly_off` | Check | **no toggle** (only generator sets it) | ⚠️ | no |

**Not surfaced (P8 assessment):** parent `is_half_day`; `country` + `subdivision` (drive local-holiday auto-import); server actions `get_local_holidays` and `clear_table`. Weekly-off generate is **client-reimplemented**, not the server `get_weekly_off_dates`.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| HL1 | **Delete error swallowed** — no feedback on delete-in-use. | Error UX (P5) | **High** | ✅ **DONE (frontend).** Failures surfaced inline; confirm dialog stays open. Verified. |
| HL2 | **Hardcoded strings + English weekday names written to DB.** | i18n + data | **High** | ✅ **DONE (frontend).** All strings → `settings.holidayLists` (en + es-MX). Weekday dropdown shows localized labels over canonical enum values (Sunday..Saturday still SENT). Generated rows persist neutral **"Weekly Off"** description (per decision) — no more English weekday leak. |
| HL3 | **Thin client validation.** | Validation | Medium | ✅ **DONE (frontend).** Validates name, from/to dates, date range (to ≥ from), and each row (date + description) before save. |
| HL4 | **Weekly-off generator timezone bug** — shifted dates in TZs behind UTC (Mexico). | Correctness | Medium | ✅ **DONE (frontend).** Parse + format dates in LOCAL time consistently (`parseLocalDate`/`formatLocalDate`); getDay() now matches the emitted date. |
| HL5 | **Local-holiday auto-import unused** — one-click Mexican/Indian public holidays via `country`/`subdivision` + server `get_local_holidays`. | Missing capability | Product decision | 🔧 **BACKEND HAND-OFF (BH-6, medium).** Expose `get_local_holidays` (+ optionally `get_weekly_off_dates`, `clear_table`) as whitelisted endpoints; frontend adds a country picker + "Import public holidays" button. Wanted for MX+IN (ADR-018); not blocking (manual entry + weekly-off generate work today). |
| HL6 | Row-level `weekly_off` flag has no per-row toggle. | Minor | Low | ✅ **DECIDED: skip.** Generator sets it; per-row toggle adds little. |
| HL7 | `/api/resource/` CRUD (ADR-021 / Rule 11). | Architecture | (ADR-021) | ✅ **Resolves under ADR-021 `master_crud` migration** — no separate decision. |

## 5. Open questions for product owner
1. **HL5 (the interesting one):** do you want **one-click import of Mexican public holidays** (and India, per ADR-018) via `country`/`subdivision`? It's a real time-saver, but the server action isn't API-exposed → **backend hand-off**. Worth it, or is manual entry / weekly-off generate enough for a clinic?
2. **HL2 data-leak:** for generated weekly-off rows, what should the stored `description` be — the localized weekday ("Domingo"), a fixed neutral value ("Weekly Off"), or the day name in a canonical language? (Affects what's persisted, not just display.)

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-02 | Sarvesh | Initial version (header backfilled from git history) |
