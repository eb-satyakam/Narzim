# Settings → Service Units

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — SU3→BH-8; SU1/SU6/SU7 FE-TODO; SU5→ADR-021 read; SU2 keep auto-default (single-clinic); SU4 skipped · **Section:** Clinic · **Screen 4/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Healthcare Service Unit`** (healthcare app) — a **tree doctype** (nested-set: `lft`/`rgt`/`parent`/`is_group`), though the screen treats it as a flat list of consultation rooms. **Writes are ADR-021-clean** (custom `create/update/delete_service_unit` in `api/v1/admin/settings.py`), but the **read path is not** — the BFF `GET` calls generic `frappe.client.get_list` directly, bypassing the service layer. Permissions are clean (admin full CRUD; all other roles read-only — third P1 counter-case). The real problems: the **mandatory `company` (Link) is hidden and silently auto-defaulted to the first Company** (breaks multi-clinic); **capacity + overlap are edit-only on both sides** (create can't set them → double-save); plus the familiar **swallowed delete error** (P5) and **fully hardcoded strings** (P6).

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Healthcare Service Unit`** (healthcare app) | **generic `frappe.client.get_list`** in BFF (`service-units/route.ts:29`), filters `is_group=0` + `allow_appointments=1`. **No custom list method.** |
| Create | `Healthcare Service Unit` | `create_service_unit` (`api/v1/admin/settings.py:68`) |
| Update | `Healthcare Service Unit` | `update_service_unit` (`settings.py:119`) |
| Delete | `Healthcare Service Unit` | `delete_service_unit` (`settings.py:167`) — hard `frappe.delete_doc` |

- **Frontend:** `src/components/settings/service-units-section.tsx` (`ServiceUnitsSection`); hooks `use-healthcare.ts` (`useAdminServiceUnits` :57, create :67, update :88, delete :107 — hand-written, not `standardCrud`); BFF `src/app/api/healthcare/service-units/route.ts`; nav `settings-nav.ts:40` (**Clinic** group).
- **BFF write proxying:** POST→`...admin.api.create_service_unit` (:85), PATCH→`update_service_unit` (:102), DELETE→`delete_service_unit` (:119). BFF resolves `company` to the first Company when absent (`route.ts:70-79`) and forces `allow_appointments=1` (:82).
- **ADR-021 / Rule 11:** **PARTIAL** — writes use custom whitelisted methods ✅; **read uses `frappe.client.get_list`** (generic, service-layer-bypassing) ❌ (**SU5**).

## 2. Permissions — clean (third P1 counter-case)
DocPerm spec `patches/v0/eb_docperm_spec.json:1159`:
| Role | read | write | create | delete |
|---|---|---|---|---|
| **EB_Healthcare Admin** | ✅ | ✅ | ✅ | ✅ |
| EB_Front Desk / EB_Practitioner / EB_Nurse | ✅ | — | — | — |

Admin has full CRUD; create/delete UI correctly permission-backed. **No P1 mismatch.**

## 3. Field parity + control types
Backend `Healthcare Service Unit` fields: `healthcare_service_unit_name` (Data, **reqd**), `parent_healthcare_service_unit` (Link→self, tree), `is_group` (Check), `service_unit_type` (Link→Healthcare Service Unit Type), `allow_appointments` (Check, ro, `fetch_from` type), `overlap_appointments` (Check, ro), `inpatient_occupancy` (Check, ro), `occupancy_status` (Select ro, runtime), `warehouse` (Link→Warehouse), **`company` (Link→Company, reqd)**, `service_unit_capacity` (Int), `address_html`/`contact_html` (HTML).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Name | `healthcare_service_unit_name` | Data | text | ✅ | create-only (locked on edit) | yes |
| Capacity (patients) | `service_unit_capacity` | Int | number (min1) | ✅ | **edit-only** | no |
| Allow overlap | `overlap_appointments` | Check | `<select>` Yes/No | ✅ | **edit-only** | no |

**Not surfaced (P8):**
- **`company`** — Link, **mandatory**; hidden and **auto-defaulted server-side to the first Company** (`route.ts:70-79`). No clinic selector → every service unit silently attaches to Company #1 (**SU2**).
- **`service_unit_type`** — Link classification (also drives `allow_appointments` via `fetch_from`); the API accepts it but the UI never sends it (**SU4**).
- `warehouse`, tree `parent`/`is_group`, `inpatient_occupancy`, `occupancy_status` — inventory / hierarchy / inpatient / runtime; reasonably out of scope for an OPD room list.

**Create vs edit asymmetry:** the create form has Capacity + Allow-overlap inputs, but `handleSave` create branch sends only `{service_unit_name, allow_appointments:1}` (`service-units-section.tsx:65-68`) — and `create_service_unit` has **no capacity/overlap params** (`settings.py:68-74`). So both values are silently dropped at create; a new room must be **saved then edited** to set them (**SU3**).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| SU1 | **Delete error swallowed** — `handleDelete` try/catch with empty catch ("swallow — mirrors prior `.catch(() => null)`"), `service-units-section.tsx:23-32`. A blocked delete (unit referenced by appointments) shows no message. | Error UX (P5) | **High** | ✅ **DECIDED: frontend fix** (inline error, keep dialog open) — same as MD2/HL1/AT1. Not yet implemented. |
| SU2 | **Mandatory `company` hidden + auto-defaulted to first Company** (`route.ts:70-79`). No clinic selector; multi-clinic setups silently misfile every unit under Company #1. | Missing mandatory field (P8) + correctness | Low (single-clinic) | ✅ **DECIDED: keep auto-default.** Deployment is **single-clinic for now** → auto-defaulting to the only Company is correct behavior, no selector needed. **Revisit if/when multi-clinic** (then: frontend clinic selector shown when >1 Company; the create API already accepts `company`). |
| SU3 | **Create/edit asymmetry** — capacity + overlap are edit-only; `create_service_unit` doesn't accept them, so the create dialog's inputs are dropped → double-save. | Missing fields (P4) | **Medium** | ✅ **DECIDED: fix.** Backend `create_service_unit` accepts `service_unit_capacity`/`overlap_appointments` (**BH-8**) + frontend sends them on create. |
| SU4 | **`service_unit_type` not surfaced** — classification Link ignored (also drives `allow_appointments`). | Missing field (P8) | Low | ✅ **DECIDED: skip.** Keep the screen a flat OPD room list; no room-type classification (YAGNI). No change. |
| SU5 | **Read path uses generic `frappe.client.get_list`** (`route.ts:29`), bypassing the service layer — unlike the (clean) custom write methods. | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021.** The list read migrates to a whitelisted method with the other master-data screens under ADR-021's `master_crud` (or a dedicated `list_service_units` mirroring `list_appointment_types`) — no separate per-screen decision. |
| SU6 | **Fully hardcoded English strings — no `useTranslations`** (title/sub :80, table headers :108, dialog titles :135, field labels, validation :64, buttons). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.serviceUnits` catalog (en + es-MX). Not yet implemented. |
| SU7 | **Thin client validation** — name-required on create only (`:64`); capacity/overlap rely on HTML attrs; no name check on edit. | Validation | Low | ✅ **DECIDED: frontend fix** (name required on edit too, numeric guards). |
| — | **ADR-021 writes** | Architecture | (n/a) | ✅ Writes are custom whitelisted methods (create/update/delete) — clean. Only the read (SU5) is not. |

## 5. Resolved decisions (2026-07-04)
1. **SU2 — RESOLVED: keep auto-default.** Deployment is single-clinic for now, so defaulting to the only Company is correct. Flagged to revisit (add a clinic selector) if/when a deployment becomes multi-clinic.
2. **SU3 — RESOLVED: fix.** Capacity + overlap settable at create → **BH-8** (backend create args) + frontend.
3. **SU4 — RESOLVED: skip.** Flat OPD room list; `service_unit_type` not surfaced.
4. **SU1 + SU6 + SU7 — RESOLVED: standard frontend fixes** (surface delete error; `settings.serviceUnits` en+es catalog; validation on edit). Note: an earlier local branch prototyped the SU1 delete-error + a company selector; that work was reverted and is not on `dev`.
5. **SU5 — RESOLVED under ADR-021** (`master_crud` read migration).

## 6. Follow-up
- Backend: **BH-8** (see [BACKEND_HANDOFFS.md](BACKEND_HANDOFFS.md)) — `create_service_unit` accepts capacity/overlap. Read path migrates under ADR-021.
- Frontend TODO (separate change): SU1, SU3 (send capacity/overlap at create once BH-8 lands), SU6, SU7.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
