# Settings → Practitioner Schedules

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — PS1→ADR-021; PS2/PS3/PS4/PS5/PS6 FE-TODO; PS7 skip. No backend hand-off. · **Section:** Scheduling & Staff · **Screen 8/18** · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to core **`Practitioner Schedule`** (parent) + **`Healthcare Schedule Time Slot`** (child `time_slots`). Sibling of screen 7 — same 3-column shell, toggled by `?tab=schedules`. This is a **well-built** screen: full time-slot editor (add / inline-edit / remove + a "Generate Slots" helper that splits a window into fixed-duration slots), custom whitelisted CRUD, clean permissions (5th P1 counter-case), and — notably — the **first screen with correct delete-error UX out of the box** (friendly "still assigned to practitioners" toast, not swallowed). The gaps are mostly mechanical: the **list read uses generic `/api/resource/`** (PS1, same as PR1), **list/edit load errors are masked** (PS2/PS3 — and PS3 risks silently wiping slots on save), **thin validation** (no `from < to`, no overlap, empty slot-list allowed — client *and* server), **hardcoded strings** (P6), plus some **dead assignment plumbing** (PS6).

## 1. Doctype mapping
| Section | DocType | API |
|---|---|---|
| List (read) | **`Practitioner Schedule`** | **generic `/api/resource/Practitioner Schedule`** via `frappeRestList` (`admin/[resource]/route.ts:231`) — **ADR-021 hole (PS1)** |
| Detail (read) | `Practitioner Schedule` | custom `admin.api.get_practitioner_schedule` (`detail/route.ts:13`) ✅ |
| Create | `Practitioner Schedule` | custom `admin.api.create_practitioner_schedule` (`practitioners.py:584`) ✅ |
| Update | `Practitioner Schedule` (+ `time_slots` full replace) | custom `admin.api.update_practitioner_schedule` (`detail/route.ts:31`; `practitioners.py:550`) ✅ |
| Delete | `Practitioner Schedule` | custom `admin.api.delete_practitioner_schedule` (`practitioners.py:670`) — hard delete (LinkExistsError if assigned) ✅ |
| Assign to practitioner | writes `Healthcare Practitioner.practitioner_schedules` | `assign_schedule_to_practitioner` (`practitioners.py:617`) — **exists but done on screen 7, not here (dead here)** |

- **Frontend:** `schedule-form.tsx` (+ nested `SlotEditor`), `schedule-profile.tsx`, shared left-rail `practitioners-list.tsx`; hooks `use-admin-practitioner-schedules.ts` (`createAdminResource` for list/create/delete + hand-written get/update/assign); nav `settings-nav.ts:49` (**Scheduling & Staff**, `/settings/practitioners?tab=schedules`).
- **ADR-021 / Rule 11:** **PARTIAL** — create/update/delete + detail read custom ✅; **only the list GET uses `/api/resource/`** ❌ (**PS1**).

## 2. Permissions — clean (fifth P1 counter-case)
DocPerm spec `patches/v0/eb_docperm_spec.json` (`Practitioner Schedule`): single role **`EB_Healthcare Admin`** = read/write/create/delete ✅ (+ print/email/report/export/share/select). Child `Healthcare Schedule Time Slot` has no own entry — inherits parent perms (correct for `istable`). **No P1 mismatch.**

## 3. Field parity + control types
Parent: `schedule_name` (Data, **reqd**, unique = record name), `time_slots` (Table child), `disabled` (Check), `allow_video_conferencing` (Check, **inert** — no controller logic, no API support). Child `Healthcare Schedule Time Slot`: `day` (Select weekday, **reqd**), `from_time` (Time, **reqd**), `to_time` (Time, **reqd**), `maximum_appointments` (Int), `duration` (Float, **read-only**). **No `service_unit` on the slot** (service unit is bound on the practitioner-schedule link, not the slot).

| Frontend field | Backend field | fieldtype | UI control | Correct? | Editable | Req |
|---|---|---|---|---|---|---|
| Schedule Name | `schedule_name` | Data (unique) | text | ✅ | create-only (immutable on edit) | yes |
| Schedule Status | `disabled` | Check | `<select>` Active/Disabled | ✅ | edit-only | — |
| (slot) Day | `day` | Select | `<select>` weekday | ✅ | both | yes |
| (slot) From / To | `from_time`/`to_time` | Time | `<input type=time>` | ✅ | both | yes |
| (slot) Max | `maximum_appointments` | Int | number (min1) | ✅ | both | no |
| (slot) Duration | `duration` | Float (ro) | **computed display** (`calcDuration`) | ✅ (matches backend ro; not persisted) | — | — |

**Full slot editor** ✅ — add / generate / inline-edit / remove; whole `time_slots` array replaced on save (matches backend replace semantics). **Not surfaced:** `allow_video_conferencing` (inert here; telemedicine out of scope — skip, P10).

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| PS1 | **List read via generic `/api/resource/Practitioner Schedule`** (`route.ts:231`) — only non-custom path. | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021** (whitelisted list). Same as PR1. |
| PS2 | **List-load error rendered as empty** — shared `practitioners-list.tsx:38` ignores `isError` → a failed load shows "No schedules." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card. Fixed together with PR2 (same component). |
| PS3 | **Edit detail-load error → blank form → save wipes slots.** `schedule-form.tsx:160-169` doesn't check `detailQuery.isError`; on failure `d` is null → form mounts empty, and saving PATCHes the real record with an **empty `time_slots`** (full replace) → **silent slot data loss.** | Correctness / data loss | **Medium-High** | ✅ **DECIDED: fix (frontend).** Block the edit form with an error state when detail load fails; never submit an empty `time_slots` replace derived from a failed load. |
| PS4 | **Thin validation — client *and* server.** Only `schedule_name` required (create). No `from < to`, no overlap, empty `time_slots` allowed; the controller also doesn't enforce `from<to`/overlap (`abs()` diff). Reversed/overlapping/empty schedules can be saved. | Validation | **Medium** | ✅ **DECIDED: client-side validation** (`from<to`, non-empty, overlap warning). **No server-side hardening** — low risk (admin-entered, no direct API consumers). |
| PS5 | **Fully hardcoded strings — no `useTranslations`** (`schedule-form.tsx`, `schedule-profile.tsx`, `shared.tsx` day names). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.practitionerSchedules` catalog (en + es-MX). |
| PS6 | **Dead assignment plumbing** — `useAssignScheduleToPractitioner` hook + `/api/admin/practitioner-schedules/assign` BFF route + backend `assign_schedule_to_practitioner` all exist but are unused; real assignment happens via the practitioner update payload (screen 7). Two mechanisms, one dead. | Cleanup / dead code | Low | ✅ **DECIDED: remove the dead frontend parts** (unused hook + `/assign` BFF route). Backend `assign_schedule_to_practitioner` left in place (harmless, no cost). |
| PS7 | **`allow_video_conferencing` not surfaced** — Check on parent, no API/controller support here. | Inert field (P10) | Low | ✅ **DECIDED: skip** (telemedicine out of scope; inert on this doctype). |
| — | **Delete-error UX done right** (`schedule-profile.tsx:31-46` — friendly linked-schedule toast, not swallowed) | — | — | ✅ First screen correct out of the box. No finding (counter-case to P5). |

## 5. Resolved decisions (2026-07-04)
1. **PS3 — RESOLVED: fix.** Edit form shows an error state on failed detail load; never submits an empty `time_slots` replace derived from a failed load (prevents silent slot wipe). Frontend.
2. **PS4 — RESOLVED: client-side validation only** (`from<to`, non-empty, overlap warning). No backend hardening — low risk (admin-entered, no direct API consumers).
3. **PS6 — RESOLVED: remove dead frontend plumbing** (unused hook + `/assign` BFF route). Backend endpoint left in place.
4. **PS1 — RESOLVED under ADR-021** (list read → whitelisted). **PS2 + PS5 — frontend fixes** (error card shared with PR2; `settings.practitionerSchedules` en+es). **PS7 — skip** (inert).

## 6. Follow-up
- **No backend hand-off.** All items are frontend (PS2, PS3, PS4, PS5, PS6) or fold under ADR-021 (PS1).
- Frontend TODO (separate change): PS2 (list-error card, w/ PR2), PS3 (edit-load guard), PS4 (slot validation), PS5 (i18n), PS6 (remove dead hook + `/assign` route).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
