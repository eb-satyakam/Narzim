# Settings → Clinical Procedures → **Clinical Procedure Templates**

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — CP1→ADR-021; CP2/CP3/CP4/CP5 FE-TODO; CP6 renamed (FE); consumables skip. No P1, no backend hand-off. · **Section:** Clinical Data · **Screen 19** (added post-completeness-check) · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit; label rename applied.

## 0. Headline
Maps to core **`Clinical Procedure Template`** (healthcare) — a billable master that **auto-creates an ERPNext Item + Item Price** (item_code = template name). **Not in the original 18-screen inventory** — surfaced by the master-data completeness check; it's a direct clinical peer of Lab Test Templates (13) and Therapy Types (18) and feeds Treatment Plan items (17). Structurally a **twin of Therapy Types**: single-page list + modal form. **Admin has full CRUD (no P1** — 4th clean master with Diagnosis/Treatment Plans/Therapy Types), the **list handles `isError`** (P11 counter-case), and writes are **custom** (ADR-021-clean). Gaps mirror Therapy Types: **list uses `/api/resource` despite an existing unused `list_clinical_procedure_templates`** (CP1), **swallowed delete + no confirm** (CP2), **`item_group` + `medical_department` accepted by the API but not surfaced** (CP3 — notably `item_group`, so every procedure silently defaults to the "Services" group), hardcoded strings (CP4). Renamed **"Clinical Procedures" → "Clinical Procedure Templates"** to match the backend (CP6), consistent with screen 17.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List (read) | **`Clinical Procedure Template`** | **generic `/api/resource/`** via `frappeRestList` (`[resource]/route.ts` GET) — **ADR-021 hole (CP1)**, despite an existing unused `list_clinical_procedure_templates` (`catalog.py:1435`) |
| Detail | — | **no `get_` endpoint**; edit prefills from the list row (which omits `description`) |
| Create | `Clinical Procedure Template` (+ auto Item) | custom `admin.api.create_clinical_procedure_template` (`catalog.py:1449`) ✅ |
| Update | `Clinical Procedure Template` | custom `admin.api.update_clinical_procedure_template` (`catalog.py:1495`) ✅ |
| Delete | `Clinical Procedure Template` | custom `admin.api.delete_clinical_procedure_template` (`catalog.py:1551`) ✅ |

- **Frontend:** `src/app/(clinic)/admin/clinical-procedures/page.tsx` (`ClinicalProceduresContent` — list + `Dialog`). Hooks `use-admin-clinical-procedures.ts` (`createAdminResource("clinical-procedures")`). Generic `[resource]` config (`route.ts:199`, `frappeMethod: "clinical_procedure_template"`, **no `standardCrud`**). Nav `settings-nav.ts:65` (**Clinical Data**, route `/admin/clinical-procedures`).
- **ADR-021 / Rule 11:** **PARTIAL** — create/update/delete custom ✅; **list GET via `/api/resource/`** ❌ (**CP1**), same cheap-fix situation as Therapy Types (custom list exists).

## 2. Permissions — clean (P1 counter-case)
DocPerm spec `eb_docperm_spec.json:347`: **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Nurse` + `EB_Practitioner` read-only. **No P1 mismatch.**

## 3. Field parity + control types
Backend create/update API accepts: `template` (reqd, name), `rate`, `is_billable` (default True), `item_group` (default "Services"), `description` (defaults to template name if blank), `medical_department`, `consume_stock`. Doctype also has `items` (consumables child), `sample*`, `codification_table`, checklists, `default_duration` — **not** in the API.

| Frontend field | Backend | control | Correct? | Editable |
|---|---|---|---|---|
| Template Name | `template` (Data, reqd, unique) | text | ✅ | create + edit (= rename) |
| Rate | `rate` (Float) | number | ✅ | both |
| Description | `description` | textarea | ✅ | both — **not prefilled on edit** (no `get_` endpoint; list omits it) |
| Is Billable | `is_billable` (Check) | checkbox | ✅ | both |

**Accepted by API but NOT surfaced (P8, CP3):** `medical_department` (Link) and **`item_group`** (Link — defaults server-side to "Services", so **all procedures land in one group**, can't be categorized). `consume_stock` also in the input type but unsurfaced. **Doctype-only (not in API — skip, CP-consumables):** `items` consumables child, `sample*` collection, `codification_table`, checklists, `default_duration`.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| CP1 | **List read via `/api/resource/`** despite an existing unused `list_clinical_procedure_templates`. | Architecture (Rule 11 / §3) | **Medium** | ✅ **DECIDED: resolves under ADR-021** (point list at the custom method — trivial, exists). Same as TH1. |
| CP2 | **Delete error swallowed + no confirm** — `del.mutateAsync(item.name).catch(() => null)` (`page.tsx:136`). | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — confirm dialog + surface delete error. |
| CP3 | **`item_group` + `medical_department` accepted by API but not surfaced** (item_group silently defaults to "Services" → no categorization); `description` not prefilled on edit. | Missing fields (P8) | **Medium** | ✅ **DECIDED: frontend fix** — surface item_group + medical_department (API already accepts); prefill description on edit (add to list fields or add a `get_` endpoint). |
| CP4 | **Fully hardcoded strings — no `useTranslations`.** | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → `settings.clinicalProcedures` catalog (en + es-MX). |
| CP5 | **Thin validation** — only template; billable + empty rate may 400 (auto-Item rate rule). | Validation | Low–Med | ✅ **DECIDED: frontend fix** — require rate when billable. |
| CP6 | **Naming: "Clinical Procedures" vs doctype "Clinical Procedure Template".** | Clarity / naming | **Medium** | ✅ **DONE (frontend): renamed to "Clinical Procedure Templates"** (matches backend; consistent with screen 17). Nav, headers, dialog, empty/error copy updated. Hardcoded pending CP4 i18n. |
| — | **consumables / sample / codification not surfaced** — also not in the API. | Missing (P8) | Low | ✅ **DECIDED: skip** (advanced; API doesn't accept). |
| — | **Admin full CRUD (no P1); list handles isError; writes custom** | — | — | ✅ Clean master. |

## 5. Follow-up
- **No backend hand-off** (API accepts item_group/department; custom list exists; admin full CRUD). Auto-Item creation needs a selling Price List configured (shared behavior with Lab Test/Therapy/Medication).
- **Rename applied** ("Clinical Procedure Templates"). Frontend TODO: CP1 (list→custom/ADR-021), CP2 (confirm+delete error), CP3 (surface item_group+department, prefill description), CP4 (i18n), CP5 (rate-when-billable).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
