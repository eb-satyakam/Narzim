# Settings → Insurance (Insurance Payor)

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — **IN1 FIXED** (create was broken; backend methods rewired to real doctype contract + FE dropped standardCrud; CRUD verified via bench), IN2 resolved, **IN5 FIXED** (list-error card); IN3 i18n → P6; IN4 skip. Perms clean (no P1). Renamed → "Insurance Payors" (FE). · **Section:** Billing · **Screen 21** (post-completeness-check) · [index](README.md)

> **UPDATE (2026-07-04) — IN1/IN5 implemented, not just decided.** Turned out the custom `create_insurance`/`update_insurance`/`_fmt_insurance` were on a **stale schema** (`insurance_company_name`/coverage/copay/phone) that matched neither the doctype nor the frontend — so routing to them would *also* have failed. Fix spanned both repos: **backend** (`fix/insurance-payor-crud`, `05b6955`) rewrote the three functions to the real fields (`insurance_payor_name`/`insurance_claim_credit_days`/`website`/`disabled`, keeping `ignore_mandatory` for the reqd claims-account tables); **frontend** (`fix/insurance-payor-crud`) dropped `standardCrud` so writes use the custom methods, + added the IN5 list-error card. Verified via bench: create/update/delete all succeed with the FE payload keys. **This means IN1 DID need a backend change** (the audit's original "no backend hand-off" was wrong — the methods existed but were broken).
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit.

## 0. Headline
Maps to core **`Insurance Payor`** (healthcare) — the insurer master (the per-patient policies live on the patient chart, not here). Standalone 3-column master/detail. **Permissions are clean** — `EB_Healthcare Admin` has full CRUD (no P1). Profile handles errors + delete correctly. **But the create path is almost certainly broken:** the screen uses generic **`/api/resource`** (`standardCrud`), and `Insurance Payor` has **two REQUIRED child account tables** (`claims_receivable_accounts`, `rejected_claims_expense_accounts`) the form never provides → generic create throws `MandatoryError`. A custom `create_insurance_payor` exists that handles this (`ignore_mandatory`), **but the frontend bypasses it** (standardCrud). Fixing that (route to the custom methods) resolves both the broken create **and** the ADR-021 violation.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List / Create / Update / Delete | **`Insurance Payor`** | **generic `/api/resource/Insurance Payor`** via `standardCrud` (`admin/[resource]/route.ts:~70`) — **ADR-021 hole (IN2)**; `frappeMethod: "insurance"` dead |
| (available, unused) | `Insurance Payor` | custom `admin.api.create/update/delete_insurance_payor` (`catalog.py:861/889/914`) — **handle the reqd account tables** but not called by the FE |

- **Frontend:** `settings/insurance/` 3-col — `insurance-list.tsx`, `insurance-form.tsx`, `insurance-profile.tsx`. Hooks `use-admin-insurance.ts` (`createAdminResource("insurance")` → full CRUD, `standardCrud`). Nav `settings-nav.ts:75` (**Billing**).
- **ADR-021 / Rule 11:** ❌ **VIOLATION** — CRUD via `/api/resource/` despite existing custom methods.

## 2. Permissions — clean (no P1)
DocPerm spec (`Insurance Payor`): **`EB_Healthcare Admin`** read/write/create/delete = 1; `EB_Finance` read/write/create; `EB_Front Desk`/`EB_Practitioner`/`EB_Nurse` read. **No P1 mismatch.**

## 3. Field parity + control types
Backend `Insurance Payor`: `insurance_payor_name` (Data, **reqd**, name), `customer` (Link), `website` (Data), **`claims_receivable_accounts` (Table, reqd)**, **`rejected_claims_expense_accounts` (Table, reqd)**, `image`, `disabled` (Check), `insurance_claim_credit_days` (Int), `code_system` (Link).

| Frontend field | Backend | control | Correct? | Req |
|---|---|---|---|---|
| Payer Name | `insurance_payor_name` | text | ✅ | yes |
| Claim Credit Days | `insurance_claim_credit_days` | number | ✅ | no |
| Website | `website` | text | ✅ | no |

**Not surfaced:** the two **required** account tables, `customer`, `image`, `code_system`, `disabled`. The account tables are the crux of IN1 — the custom `create_insurance_payor` sets `ignore_mandatory` to get past them; generic REST doesn't. (Surfacing GL account mapping in the UI is out of scope — server-side defaulting via the custom method is the right call.)

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| IN1 | **Create likely broken** — `standardCrud` generic REST + two reqd account child tables the form omits → `MandatoryError`. Custom `create_insurance_payor` (sets `ignore_mandatory`) exists but is bypassed. | Correctness (create) | **High** | ✅ **DECIDED: FE/BFF fix** — flip the `insurance` `[resource]` config **off `standardCrud`** so create/update/delete route to the existing custom `*_insurance_payor` methods. Fixes create **and** ADR-021 in one change. **No backend hand-off** (methods exist). *Verify by attempting to create a payor before/after.* |
| IN2 | **ADR-021 violation** — CRUD via `/api/resource/Insurance Payor`. | Architecture | **Medium** | ✅ **RESOLVED by IN1** (custom methods are the fix). |
| IN3 | **Hardcoded strings — no `useTranslations`** (form/list/profile). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** (P6 pass). |
| IN5 | **List-error rendered as empty** — `insurance-list.tsx:25` ignores `isError` → failure shows "No insurers." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card. |
| IN4 | **Account tables / customer / image / code_system not surfaced.** | Missing fields (P8) | Low | ✅ **DECIDED: skip** (accounts server-defaulted via the custom method; rest advanced). |
| — | **Perms clean (no P1); profile error card + delete toast handled** | — | — | ✅ |

## 5. Follow-up
- **No backend hand-off** — the custom `*_insurance_payor` methods already exist and handle the reqd tables; the fix is a **frontend/BFF config change** (drop `standardCrud` for `insurance` → use the custom methods), which resolves IN1 + IN2.
- Frontend: IN1 (route to custom methods), IN5 (list-error card), IN3 (i18n via P6).
- **Naming — RENAMED (owner-requested): "Insurance" → "Insurance Payors"** to match the backend doctype `Insurance Payor`; also fixed the "Payer" → "Payor" spelling (field is `insurance_payor_name`). Applied on the frontend (nav, screen/back-link titles, form labels + validation, list/profile copy). Consistent with the backend-matching renames on screens 14/15/17/19.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
