# Settings → Payment Methods

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — PM1 P1→BH-21; PM2/PM3 FE-TODO; PM4 skip; name kept. ADR-021 clean. · **Section:** Billing · **Screen 20** (post-completeness-check) · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit, no backend changes.

## 0. Headline
Maps to ERPNext core **`Mode of Payment`** (`erpnext/accounts`) — the accepted payment modes for billing/checkout. Small screen: list + inline dialog (Name / Type / Active). **ADR-021-clean** (dedicated custom `/api/admin/payment-methods` route, explicit "no `/api/resource/`"), and the **list handles `isError`** (P11 counter-case). One real defect: a **P1 permission mismatch** — the UI offers **delete**, but the DocPerm grants `EB_Healthcare Admin` only `read/write/create` (no `delete`), so deleting 403s — and that failure is **swallowed** (`.catch(() => null)`), so it's silent.

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List / Create / Update / Delete | **`Mode of Payment`** (erpnext) | custom `admin.api.{list,create,update,delete}_mode_of_payment` (`catalog.py:2749+`) — dedicated BFF route `api/admin/payment-methods` ✅ |

- **Frontend:** `src/components/settings/payment-methods-section.tsx` (list + inline dialog). Hooks `use-admin-payment-methods.ts` (`createAdminResource("payment-methods")` → full CRUD). Nav `settings-nav.ts:74` (**Billing**).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — all ops via custom whitelisted methods.

## 2. Permissions — P1 mismatch (delete)
DocPerm spec (`Mode of Payment`): **`EB_Healthcare Admin`** read/write/**create** = 1, **delete = 0**; `EB_Finance` read/write/create; `EB_Front Desk` read.
- **PM1 (P1):** the UI offers **Delete** (`payment-methods-section.tsx:57`, `:104`), but admin has **no `delete`** → `delete_mode_of_payment` 403s for `EB_Healthcare Admin` (works only if also System Manager). Same class as Item Group (BH-11) / Complaint (BH-12).

## 3. Field parity + control types
Backend `Mode of Payment`: `mode_of_payment` (Data, **reqd**, name), `type` (Select: Cash/Bank/General/Phone), `accounts` (Table→Mode of Payment Account, per-company GL mapping), `enabled` (Check).

| Frontend field | Backend | control | Correct? | Req |
|---|---|---|---|---|
| Method Name | `mode_of_payment` | text | ✅ | yes |
| Type | `type` | `<select>` (Cash/Bank/General/Phone) | ✅ | no |
| Active | `enabled` | checkbox/select | ✅ | no |

**Not surfaced (P8, PM4):** `accounts` — per-company default GL account for the mode (drives where payments post). Not exposed; relies on ERPNext defaults. Low-value for the UI; note only.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| PM1 | **P1: delete UI vs admin read/write/create-only DocPerm.** Delete 403s for `EB_Healthcare Admin`. | Permission (P1) | **High** | ✅ **DECIDED → BH-21:** grant `delete` on `Mode of Payment` to `EB_Healthcare Admin` (and `EB_Finance`) via a DocPerm patch. Delete-in-use fails safely (LinkExistsError). |
| PM2 | **Delete error swallowed** — `deletePaymentMethod.mutateAsync(m.name).catch(() => null)` (`:57`). Compounds PM1 — the 403 shows nothing. | Error UX (P5) | **Medium** | ✅ **DECIDED: frontend fix** — surface delete errors (inline/toast). |
| PM3 | **Hardcoded strings — no `useTranslations`** (title/sub, labels, empty, validation). | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** → catalog (folds into P6 pass). |
| PM4 | **`accounts` (GL mapping) not surfaced.** | Missing field (P8) | Low | ✅ **DECIDED: skip** (ERPNext defaults; low UI value). |
| — | **Naming:** nav "Payment Methods" vs doctype "Mode of Payment" | Clarity | — | ✅ **KEEP "Payment Methods"** — clearer than the ERPNext term "Mode of Payment"; the field literally is the payment method. (Contrast the backend-matching renames on screens 14/15/17/19 where the backend name was clearer or equal.) |
| — | **ADR-021 clean; list error handled (P11 counter-case); create error inline** | — | — | ✅ |

## 5. Follow-up
- Backend: **BH-21** — DocPerm patch granting `Mode of Payment` `delete` to `EB_Healthcare Admin` + `EB_Finance`.
- Frontend: PM2 (surface delete error), PM3 (i18n — via P6 pass).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
