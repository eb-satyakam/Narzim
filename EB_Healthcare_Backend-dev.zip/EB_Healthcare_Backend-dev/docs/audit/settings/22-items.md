# Settings → Items

**Doc status:** record · **Created:** 2026-07-04 by Invincible · **Updated:** 2026-07-04 by Sarvesh-SocialAngel · **Version:** 1.0

**Status:** ✅ closed — IT1 P1→BH-22; IT2 P11 FE; IT3 i18n. ADR-021 clean; delete-error handled (P5 counter-case); no rename. · **Section:** Clinical Data | Billing | Items · **Screen 22** (post-completeness-check) · [index](README.md)
**Role:** `EB_Healthcare Admin` (frontend `admin`) · frontend-only audit.

## 0. Headline
Maps to ERPNext core **`Item`** — the service/billing items behind consultations, labs, procedures, therapies (the ones auto-created by those masters can also be managed here directly). Standalone 3-column master/detail. **ADR-021-clean** (dedicated custom `/api/admin/items` route, "never `/api/resource/`"). Error handling is good — profile shows a load-error card and **surfaces delete errors via toast (not swallowed)**, and there's a numeric-rate validation check. The form exposes a sensible **service-item subset** of the (huge) Item doctype. One real defect: a **P1 permission mismatch** — the UI offers delete, but `EB_Healthcare Admin` has only `read/write/create` on `Item` (no `delete`).

## 1. Doctype mapping
| Op | DocType | API |
|---|---|---|
| List / Create / Update / Delete | **`Item`** (erpnext) | custom `admin.api.{list,create,update,delete}_item` (`catalog.py:1671+`) — dedicated BFF route `api/admin/items` ✅ |

- **Frontend:** `settings/items/` 3-col — `items-list.tsx`, `item-form.tsx`, `item-profile.tsx`. Hooks `use-admin-items.ts` (`createAdminResource("items")` → full CRUD). Nav `settings-nav.ts:68` (**Clinical Data**, `/settings/items`).
- **ADR-021 / Rule 11:** ✅ **CLEAN** — all ops via custom whitelisted methods.

## 2. Permissions — P1 mismatch (delete)
DocPerm spec (`Item`): **`EB_Healthcare Admin`** read/write/**create** = 1, **delete = 0**; `EB_Front Desk`/`EB_Nurse`/`EB_Practitioner` read.
- **IT1 (P1):** the UI offers **Delete** (`item-profile.tsx`), but admin has **no `delete`** → `delete_item` 403s for `EB_Healthcare Admin`. Same class as BH-11 / BH-12 / BH-21. (Note: Items are heavily referenced by invoices/stock, so even with the perm, delete-in-use will usually fail with `LinkExistsError` — which the profile toast already surfaces. Granting delete just lets *unused* items be removed.)

## 3. Field parity + control types
Backend create/update accepts a service-item subset: `item_name` (reqd), `item_group` (Link, reqd), `stock_uom` (Link→UOM, reqd), `item_type`/service flag, `rate`, `description`, `disabled`.

| Frontend field | Backend | control | Correct? | Req |
|---|---|---|---|---|
| Item Name | `item_name` | text | ✅ | yes |
| Item Code | `item_code` | text | ✅ | create-only |
| Item Group | `item_group` | `<select>` | ✅ | yes |
| Unit (UOM) | `stock_uom` | `<select>` (uoms) | ✅ | yes |
| Type | Service/Stock | `<select>` | ✅ | — |
| Rate | `rate` | number (NaN-checked) | ✅ | no |
| Description / Disabled | `description` / `disabled` | textarea / checkbox | ✅ | no |

`Item` has 100+ fields (accounting/inventory/manufacturing); surfacing only the service-item subset is **correct** for a clinic — no P8 concern.

## 4. Gaps & decisions
| # | Finding | Type | Priority | Decision |
|---|---|---|---|---|
| IT1 | **P1: delete UI vs admin read/write/create-only DocPerm** on `Item`. Delete 403s for `EB_Healthcare Admin`. | Permission (P1) | **High** | ✅ **DECIDED → BH-22:** grant `delete` on `Item` to `EB_Healthcare Admin` via a DocPerm patch. Delete-in-use fails safely (LinkExistsError, already surfaced by the toast). |
| IT2 | **List-error rendered as empty** — `items-list.tsx:26` ignores `isError` → failure shows "No items." | Error UX (P11) | **Medium** | ✅ **DECIDED: frontend fix** — distinct error card. |
| IT3 | **Hardcoded strings — no `useTranslations`.** | i18n (P6) | **Medium** | ✅ **DECIDED: frontend fix** (P6 pass). |
| — | **ADR-021 clean; profile error card + delete toast (P5 counter-case); numeric-rate validation; appropriate field subset; name matches** | — | — | ✅ |

## 5. Follow-up
- Backend: **BH-22** — grant `Item` `delete` to `EB_Healthcare Admin` (DocPerm patch).
- Frontend: IT2 (list-error card), IT3 (i18n via P6).

_Recurring: **four** master doctypes now have the admin-missing-a-CRUD-perm P1 — Item Group (BH-11), Complaint (BH-12), Mode of Payment (BH-21), Item (BH-22). Recommend the backend dev do **one DocPerm sweep** granting `EB_Healthcare Admin` full CRUD on all managed master doctypes rather than per-screen patches._

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-04 | Sarvesh | Initial version (header backfilled from git history) |
