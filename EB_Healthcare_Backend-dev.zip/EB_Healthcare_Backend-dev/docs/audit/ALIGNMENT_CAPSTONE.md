# Cross-Role Alignment Capstone — are we aligned with the ERPNext Healthcare core default flow?

**Doc status:** record · **Created:** 2026-07-09 by Invincible · **Updated:** 2026-07-09 by Sarvesh-SocialAngel · **Version:** 1.0

**Scope:** synthesizes the three role audits (Front Desk · Nurse · Practitioner) + the core-flow trace into one verdict: **for each step of the native ERPNext Healthcare default flow, are we aligned, diverged, or showing fake data — and which role touches it.**
**Grounded in:** code reads of `remedisys_healthcare_ai/api/v1/*` + `apps/healthcare/` core + a live `Healthcare Settings` check, 2026-07-09.
**Companions:** `frontdesk/` · `nurse/` · `practitioner/` audits · `frontdesk/CORE_HEALTHCARE_FLOW_AND_MARLEY_MAP.md` · `frontdesk/OPD_BACKEND_FLOW_AND_GAPS.md`.

> **One-line verdict:** *The engine runs the core flow correctly — the clinical + money spine composes ERPNext Healthcare properly and Rule 1 (upgrade-safe) holds. The misalignments are not flow-shape problems: they are (a) fabricated UI data on top of real pipes, (b) permission over-grants against the flow's own safety model, (c) a few reimplemented read-layers that drift from core, and (d) one vitals-binding correctness bug.*

---

## 1. The native core flow, step by step — aligned / diverged / fake

Legend: 🟢 aligned (composes core) · 🟠 diverged / reimplemented / under-uses core · 🔴 fake or broken on top of the real flow · role = who drives that step.

| # | Core default-flow step | Status | Role(s) | What we do vs core |
|---|---|---|---|---|
| 1 | **Book appointment** (Patient Appointment, status/overlap/validate) | 🟢 | Front Desk | Insert real doc; core `validate()`/`set_status()` run. Atomic book→invoice→pay savepoint (ADR-012). |
| 2 | **Slot generation** (`get_availability_data`) | 🟠 | Front Desk | We **ported** core's algorithm instead of calling it → upgrade-drift risk. |
| 3 | **Check-in → queue** (native `position_in_queue`) | 🟠 | Front Desk / Nurse | Status via `db.set_value` bypasses `set_position_in_queue()`; our dashboard queue is a Marley construct, not core's. |
| 4 | **Vitals capture** (Vital Signs, BMI/BP) | 🟢 | Nurse | Real create/submit; BMI/BP mirror core `vital_signs.js`. |
| 4b | **Vitals → encounter binding** | 🔴 | Nurse → Doctor | **Heuristic (same patient+day), not a guaranteed core link** → walk-in / two-same-day-visit **cross-bind** (NV1/B1). The doctor signs whatever it bound. |
| 5 | **Encounter draft** (nurse prep, ADR-022) | 🟢 | Nurse | `save_draft` gated to docstatus=0; nurse can author, not sign. |
| 6 | **Sign / complete encounter** (docstatus 0→1) | 🟢 | Doctor | Double-gated (FE `canSign` + BE `_require_assigned_practitioner_or_admin`). The heart of the flow — well-built. |
| 7 | **Sign spawns order layer** (Service + Medication Request + Therapy Plan) | 🟢 | Doctor (auto) | Native core `on_submit` (ADR-019) — we get the order layer for free. |
| 8 | **Prescribe** (drug_prescription → Medication Request) | 🟢 | Doctor | Real *inside* the encounter. **But** the standalone `/medications` screen is 🔴 mock (`MEDICINE_MASTER`, 0 API calls) and `/prescriptions` is a placeholder. |
| 9 | **Labs: order → result → finalize** | 🟢 flow / 🔴 perm | Nurse (record) · Doctor (finalize) | Lifecycle composes core; `record_result` ≠ `submit_lab_result`. **Perm bug:** `EB_Nurse` + `EB_Front Desk` also hold `Lab Test submit` — non-physicians can finalize (NL1/NU-BH-3). |
| 9b | **Labs dual creation path** | 🟠 | Nurse | Direct `create_lab_order` vs SR-anchored → possible duplicate/orphan Lab Test. |
| 10 | **Immunization → billable** | 🟢 | Nurse (record) · FD (bill) | Custom Immunization doctype + `reference_dt` billing link; ADR-020 handoff. Clean role split. |
| 11 | **Billable discovery** (`get_healthcare_services_to_invoice`) | 🟢 | Front Desk | Calls core; stays in sync with core billing rules. |
| 12 | **Invoice + write-back + double-bill guard** | 🟢 | Front Desk | Core `set_invoiced` on submit is the guard. **Gap:** no arbitrary-line/tax **invoice editor** (create-with-tax/add-remove-lines missing both FE + BE). |
| 13 | **Payment** (partial/full, status) | 🟢 | Front Desk | Core `get_payment_entry`; core drives status. |
| 14 | **Insurance coverage → split → payor JE** | 🟢 | Front Desk | Real, core-driven. **But** insurance *booking* path is dead (policy never sent) and policy UI hidden. |
| 15 | **Insurance Claim** (bill payor → reconcile) | 🟠 | — | Fully built in core, **entirely unused** — the largest untapped core capability. |
| 16 | **Patient Medical Record timeline** | 🟠 | all | Core auto-populates via `*` hook; our history feed is a hand-rolled subset that ignores it. |
| 17 | **POS session / cash reconciliation** | 🔴 | Front Desk | Invoices are `is_pos=1` but **no POS Profile/Opening/Closing Entry**; cash drawer is localStorage mock (CD1). ADR-023 proposes the fix. |
| 18 | **Scheduler: appointment reminders** | 🟠 | Front Desk | Native `send_appointment_reminder` exists, unconfigured — reminders are manual. |
| 19 | **Scheduler: daily No-Show** | 🟢 | (auto) | Core `update_appointment_status` inherited. |

**Tally:** 🟢 aligned = 11 steps (the whole transactional spine) · 🟠 diverged/under-used = 6 · 🔴 fake/broken on top = 3 (vitals binding, labs perm, cash) + the fake-AI overlay (below).

---

## 2. The four misalignment *classes* (none is "the flow is wrong")

**A. Fabricated UI on a real flow.** The pipe underneath is core-correct; the UI paints fake cues on top.
- `patHash` **AI risk banner + insights** — and `chart-permissions` turns them **ON for the physician** (PR1) — the worst audience; also a "no AI before Phase 5" violation.
- **`/medications`** mock formulary (PR2). **Cash drawer** localStorage (CD1). Dashboard placeholder demographics.

**B. Permission over-grants against the flow's safety model.** Core *intends* physician-only finalize; the DocPerm spec grants it too widely.
- `EB_Nurse` **and** `EB_Front Desk` hold `Lab Test submit` (NL1/NU-BH-3, **confirmed in `eb_docperm_spec.json`**) → Rule 6 bypassable.
- Physician `collectPayment=true` (PR4) — money role-bleed into the clinical role.

**C. Reimplemented instead of composed (drift risk, not breakage).**
- Check-in queue (ignores `position_in_queue`), Patient history (ignores `Patient Medical Record`), slot logic (ports vs calls), Insurance Claim (unused). "Not using all of core," upgrade-drift on slots.

**D. One data-binding correctness bug.**
- **Vitals→encounter** same-day heuristic (NV1/B1) — the single spot where composing the core flow has a real hole; it propagates to the signed note.

---

## 3. Alignment scorecard by role

| Role | Flow alignment | Where it's real | Where it diverges / fakes |
|---|---|---|---|
| **Front Desk** | High on the money spine | book→checkout→invoice→pay→refund, insurance split, billable discovery | cash mock (CD1), no invoice editor, insurance booking dead, `Lab Test submit` over-grant, reminders manual |
| **Nurse** | High on intake; safety gates well-built | vitals/BMI, immunization+handoff, encounter draft (can't sign) | **vitals mis-bind (NV1)**, fake growth curves, labs dual-path, **confirmed lab-finalize over-grant** |
| **Practitioner** | High on the apex acts | **sign** + **finalize** correctly gated, prescribe-in-encounter, order-layer spawn | **fake AI ON for doctor (PR1)**, `/medications` mock, no clinical inbox, `collectPayment` bleed |

---

## 4. The highest-leverage fixes (cut across all three roles)

Ranked by reach × risk. Each closes gaps in *multiple* role audits:

1. **Flip the fabricated AI/risk surfaces off** (PR1/C1/C5) — FE-only, closes a Critical safety + phase violation on the doctor, nurse, and front-desk charts at once.
2. **Fix the `Lab Test submit` over-grant** (NL1/NU-BH-3) — one DocPerm patch; restores Rule 6 (removes it from nurse + front desk).
3. **Fix vitals→encounter binding** (NV1/NU-BH-1) — the one flow-composition correctness bug; protects what the doctor signs.
4. **Build the role-filtered work-feed** (FD-BH-4 = NU-BH-5 = PR-BH-1) — **one backend, three role views**: front-desk worklist, nurse clinical worklist, physician clinical inbox. Highest value-per-build in the whole program.
5. **Cash/shift on native POS** (ADR-023) — replaces the localStorage mock; aligns step 17 with core.
6. **Sales Invoice editor + real `/medications`** — make the two mock/missing billing+formulary surfaces real (FD-BH-2, PR-BH-2).

---

## 5. Bottom line
- **Are we aligned with the core default flow? Yes — where it counts.** The clinical and money spine (steps 1, 4–7, 10–14) composes ERPNext Healthcare correctly, and the physician's sign+finalize authority — the core of the flow — is well-built and upgrade-safe.
- **The problems are not flow-shape.** They are fabricated UI (A), permission over-grants (B), reimplemented read-layers (C), and one binding bug (D).
- **Six fixes** (§4) close the large majority of the ~90 gaps across the three role audits, because the same root causes recur across roles.

*Capstone over the three role audits. No product code changed by this document.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-09 | Sarvesh | Initial version (header backfilled from git history) |
