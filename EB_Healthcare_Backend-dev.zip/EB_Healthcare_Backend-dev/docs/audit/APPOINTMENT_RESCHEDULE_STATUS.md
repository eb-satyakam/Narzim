# Appointment Reschedule — Fixed Today, and What's Left

**Doc status:** record · **Created:** 2026-08-19 by Anant Sharma · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-08-19
**Scope:** the reschedule flow only — every UI entry point, both backend endpoints, the
settlement path, and the audit trail. Booking is covered in
`docs/audit/APPOINTMENT_FLOW_FIXES.md`; the wider screen-by-screen audit is
`docs/audit/APPOINTMENT_FLOW_UI_GAPS.md`.

**Headline:** the flow-consistency defect is **fixed** — one reschedule path now serves all
four entry points. **5 gaps remain** (1 blocking, 3 functional, 1 product decision), plus
2 items closed without code.

| | Count |
|---|---|
| Fixed today | 1 (the 🔴 one) + 1 regression I introduced and then fixed |
| Closed without code change | 2 |
| **Still open** | **5** — 1 🔴, 3 🟠, 1 🟡 |

---

## 1. The flow as it now stands

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'noteBkgColor': '#1e3a5f', 'noteTextColor': '#93c5fd'}}}%%
flowchart LR
    A[Appointments list] --> D
    B[Chart → Overview card] --> D
    C[Mission Control] --> D
    E[Chart → Appointments tab] --> D
    D[dashboard/reschedule-dialog.tsx<br/>the ONE dialog] --> P[preview_reschedule_payment<br/>dry run, writes nothing]
    P --> R[reschedule_appointment_with_payment]
    R --> S[adjust_payment_for_reschedule<br/>collect · refund · nothing]
    R --> H[Appointment Reschedule History row]
    H -.->|NO route, NO consumer| X[( R-3 )]

    style X fill:#7f1d1d,stroke:#dc2626
```

All four entry points import the same dialog:

| Screen | File |
|---|---|
| Appointments list | `app/(clinic)/appointments/appointments-client.tsx:39` |
| Chart → Overview card | `components/narzim/patient-chart/overview-frontdesk.tsx:17` |
| Chart → Appointments tab | `components/narzim/patient-chart/appointments-tab.tsx:20` |
| Mission Control | `components/narzim/dashboard/mission-control-client.tsx:38` |

---

## 2. Fixed today

### ✅ R-1 / G-01 — one reschedule flow everywhere

Two dialogs existed, and **which screen you started from decided whether money moved**:

| Screen | Before | After |
|---|---|---|
| Appointments list | `reschedule_appointment` — date/time only | `..._with_payment` |
| Chart → Overview card | `reschedule_appointment` — date/time only | `..._with_payment` |
| Mission Control | `..._with_payment` | unchanged |
| Chart → Appointments tab | `..._with_payment` | unchanged |

`components/narzim/appointments/reschedule-dialog.tsx` is **deleted**.

**The defect was worse than the original audit recorded.** That dialog also let the operator
change the **practitioner**, committing it through a *separate* `reassign_appointment` call
before `onConfirm` fired the date/time move. Consequences:

1. From the Appointments list you could move a **paid** appointment to a differently-priced
   doctor and the system collected nothing, refunded nothing, and wrote no history row.
2. The two writes were **not atomic** — a failure after the reassign left the appointment
   with a new doctor and its old slot, with no rollback and no message describing that state.

Every reschedule now: previews the settlement server-side (so the figure shown and the figure
charged come from one function), collects or refunds the difference, writes an
`Appointment Reschedule History` row, is **idempotent on retry**, and changes practitioner +
date + time + type in a **single transaction**. It carries 24 tests
(`tests/appointments/test_reschedule_payment.py`); the path just retired had none.

**Cleanup this enabled** — each verified unreferenced before removal:

- `useRescheduleAppointment` deleted from `hooks/use-appointments.ts`. A live export pointing
  at the non-settling endpoint is exactly how a screen gets wired back to it.
- `appointmentsApi.reschedule` **kept** — the endpoint is a legitimate simple API — but
  annotated with why no screen may use it.
- `toReschedulable`, `handleReschedule` and 3 orphaned imports removed from
  `overview-frontdesk.tsx`; its `rescheduleFor` state is now just an id, since the dialog
  fetches the appointment itself.
- 4 orphaned i18n keys dropped from both catalogs (`appointmentsPage.toast.rescheduled`,
  `.rescheduleFailed`, `overviewFrontdesk.rescheduledToast`, `.rescheduleError`) — the shared
  dialog raises its own `dashboard.reschedule.done/failed`.

### ✅ A regression I introduced, and fixed

The reschedule drawer reuses the booking drawer, so it inherited the **"Book with" band**
change made earlier the same day. I hoisted that band out of the scrolling body to stop it
overlapping the slot grid, but gave it `shrink-0` and **no height cap**. `shrink-0` never
yields space, so as the practitioner list grew the band consumed the whole sheet and the
scrolling body — department, practitioner toggle, date, the entire slot grid — collapsed to
zero height, with nothing left to scroll back to.

Now capped at `max-h-[26vh]` with `overflow-y-auto` **inside** the band, plus a bare count
next to the label so a long list reads as "many are free" rather than as a broken panel.

> **What made it visible:** the dev site holds **306 Healthcare Practitioners, 294 of them
> named `QA %`** — leaked by `test_reschedule_payment.py`, whose `tearDown` deletes
> practitioners inside a blanket `except Exception: pass`. That swallow is correct for
> invoices and payment entries (GL retention legitimately blocks deleting a cancelled
> accounting doc) but wrong for practitioners, which are not accounting documents and leak on
> any failure. 24 tests × 3 practitioners × every run compounds, and they pollute every
> practitioner dropdown in the app. **Not cleaned up** — deleting 294 records belonging to
> another session's test runs is not a call to make unilaterally.

---

## 3. Closed without a code change

| Item | Why it's closed |
|---|---|
| **R-7** — no tests on the plain reschedule path | Resolved by removal, not by testing. No screen calls `reschedule_appointment` any more, so the untested path is no longer reachable from the product. The endpoint stays for API callers. |
| **R-8** — refunds are always immediate, never store credit | Deliberate and documented in the endpoint's own docstring (mirrors the manual refund flow, which has no store-credit option either). Recorded here so it stays a decision rather than resurfacing as a surprise: a reschedule to a cheaper doctor always cuts a Credit Note plus refund Payment Entry, even when the patient returns next week. |

---

## 4. Still open — 5

### 🔴 R-2 — a reschedule can double-book a practitioner across rooms

`_practitioner_conflict` is called by **all four booking entry points**
(`appointments/api.py:1261, 1302, 1353, 1602`) and by **neither reschedule path**. Its own
docstring states why it exists:

> ERPNext's own overlap check is scoped to a single service unit, so this guard catches the
> practitioner being double-booked across locations.

Core's `validate_overlaps` still runs on `doc.save()`, so a **same-room** clash is caught. A
**cross-room** one is not. Concretely: Dr. Raj already has 10:00 in Room 1. Booking a second
patient at 10:00 in Room 2 is refused with a 409. Booking it at 15:00 and then *rescheduling*
it to 10:00 succeeds silently.

**Fix:** call the same guard on both reschedule paths — **excluding the appointment being
moved**, or a no-op reschedule to its own current slot would report a conflict with itself.
Pairs with R-4 (a room to check against).

### 🟠 R-3 — the audit trail is unreachable

`get_reschedule_history` (`appointments/api.py:2332`) has **no BFF route and no consumer**.
Its own docstring claims it "backs both the frontend's appointment-history timeline and its
payment-history table" — neither exists. The only frontend trace is the unused
`history: string` on `RescheduleWithPaymentResult`.

Every settled reschedule now writes a rich row: old/new fee, adjustment type and status,
delta, additional invoice, payment entry, credit note, and a `refund_breakdown` child table
for refunds spanning several invoices. **None of it is visible in the product.** "Why was
this moved three times and who paid the difference?" is answerable in the database and
nowhere else — the wrong side of the line for a NOM-024 traceability claim.

**Fix:** `GET /api/appointments/[id]/reschedule-history` + a timeline section in the chart's
Appointments tab.

### 🟠 R-4 — three parameters the frontend never sends

`reschedule_appointment_with_payment` accepts `new_service_unit`, `new_department` and
`fee_override`; the BFF route forwards all three; `ReschedulePaymentPayload`
(`new-appointment-dialog.tsx:111`) has fields for none of them.

`new_service_unit` is the consequential one: the drawer's slot picker resolves a service unit
per slot (`slotServiceUnit`), and reschedule mode **discards it** — so a move to a slot in
another room leaves the appointment pointed at the old room. That is also *how R-2 goes
unnoticed*: you think you moved the patient to Room 2, and the record still says Room 1.

`fee_override` means front desk can negotiate a rate when booking but not when rescheduling.

### 🟠 R-5 — no server-side past-date guard

Neither reschedule path validates the target date, and core has no past-date validation
either (verified — nothing). Both UIs block it client-side only (`min={today}`, and past
slots disabled), so this is reachable via the API. Booking has the identical hole (B-3 in the
booking audit), so one shared validator fixes both.

### 🟡 R-6 — a `Checked In` appointment can be rescheduled

Both paths block only `Cancelled` / `Closed` / `Checked Out`. `No Show` being reschedulable
is probably correct (rebooking a no-show). `Checked In` means the patient is **physically in
the clinic** — moving that appointment to next week leaves the queue holding a checked-in
patient with a future date. Needs a product decision, not obviously a bug.

---

## 5. Suggested order

| Order | Items | Why together |
|---|---|---|
| 1 | **R-2 + R-4** | One PR. Sending `new_service_unit` gives the conflict guard a room to check against; without it the guard is half-blind. Highest-value: R-2 is the only 🔴 left. |
| 2 | **R-3** | Pure addition — one route, one timeline component. Unlocks history rows the flow already writes. |
| 3 | **R-5** | Share one past-date validator with booking's B-3. |
| 4 | **R-6** | Decide, then implement or record the decision. |

---

## 6. Verification of today's changes

- `tsc --noEmit` clean across `src/` — one pre-existing error remains in
  `e2e/encounter-submit.spec.ts:237`, untouched
- `eslint` **at baseline on every changed file**: `overview-frontdesk` 0, `use-appointments`
  0, `lib/api/appointments` 0, `appointments-client` 12 = baseline 12, `new-appointment-dialog`
  11 = baseline 11. No new findings.
- `npm run i18n:check` — 5,826 keys, en ↔ es aligned
- `npm test` — 70/70
- Backend untouched by the consolidation (frontend-only change)

**Not exercised in a browser.** Worth one real reschedule from the **Appointments list** to a
differently-priced doctor — confirming the settlement figure appears and an invoice or credit
note results. That screen has never run this dialog before today.

## 7. Note on the preview endpoint

`preview_reschedule_payment`, `hooks/use-reschedule-payment-preview.ts`, the
`reschedule-payment-preview` route and `docs/api/RESCHEDULE_PAYMENT_PREVIEW_SPEC.md` landed
in the working tree today from **another** session, not from this work. They are the reason
the settling path can be trusted: per that spec, the drawer previously computed settlement
from invoice-level totals against a pre-tax fee and **offered a 900 MXN refund on a
reschedule where the patient owed 1,740 MXN**. Recorded here because §2 depends on that
endpoint being sound, and because `tests/appointments/test_reschedule_payment.py` and
`services/billing.py` are still being edited by that session — coordinate before touching
either.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
