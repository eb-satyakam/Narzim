# Appointment Flow — UI Gap Audit

**Doc status:** record · **Created:** 2026-08-19 by Anant Sharma · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-08-19
**Scope:** the appointment lifecycle end to end — booking, confirmation, check-in,
reschedule, reassign, cancel, no-show, billing settlement — across the clinical
frontend (`remedisys-ai-ehr`, Next.js App Router) audited against
`remedisys_healthcare_ai/api/v1/appointments/api.py` (2,184 lines).

**Method:** enumerated every whitelisted method in the backend `appointments`
module, every BFF route under `src/app/api/appointments/**`, every client method
in `src/lib/api/appointments.ts`, every hook in `src/hooks/use-appointments.ts`,
and every screen/dialog that consumes them. Findings are grounded in code with
`file:line` references, not in docs or assumptions.

> **Status update — 2026-08-19, later the same day.** Seven defects in the **New
> Appointment drawer** were reported separately and have since been fixed; see
> `docs/audit/APPOINTMENT_FLOW_FIXES.md`. Two of them overlap this audit:
> **G-05** (the insurance path) is now half-resolved — `insurance_policy` is still not
> sent, so that gap stands, but the drawer now threads a Payment Entry `reference_no`
> through the Pay-Now path, which is the same class of "backend accepts it, UI never
> sent it" defect. **G-11**'s missing-field table gains a resolved row: `reference_no`
> is now wired at both booking call sites.
>
> **G-01 is now FIXED** (fix log §9): all four reschedule entry points use the settling
> flow and the non-settling dialog is deleted. The other three 🔴 items — **G-02**
> (no-show unreachable), **G-03** (Mission Control check-in not stamping
> `custom_checked_in_at`), **G-04** (arrival time not returned) — are **still open**,
> as is a separate set of reschedule gaps recorded in fix log §9: cross-service-unit
> double-booking on reschedule, unreachable reschedule history, three unsent
> parameters, and no server-side past-date guard.

**Verdict:** the backend appointment module is materially more capable than the
UI exposes. Nothing is *missing* from the backend for the core flow. The gaps are
all on the UI side and fall into three classes: **capabilities built and then
disabled**, **the same action wired to two different backends depending on which
screen you start from**, and **data the backend records that no screen can read**.

**Legend:** 🔴 blocking / data-integrity · 🟠 functional gap · 🟡 consistency / debt

---

## 1. The flow as it actually exists today

```mermaid
%%{init: {'theme': 'dark', 'themeVariables': {'primaryColor': '#1e293b', 'primaryTextColor': '#e2e8f0', 'primaryBorderColor': '#3b82f6', 'lineColor': '#475569', 'actorBkg': '#1e293b', 'actorBorder': '#3b82f6', 'actorTextColor': '#e2e8f0', 'signalColor': '#3b82f6', 'signalTextColor': '#cbd5e1', 'noteBkgColor': '#1e3a5f', 'noteTextColor': '#93c5fd'}}}%%
flowchart TD
    A[Book Appointment drawer<br/>new-appointment-dialog.tsx] -->|book_appointment_for_patient| B[Open / Scheduled]
    B -->|Mission Control only<br/>update_status| C[Confirmed]
    C -->|Mission Control: update_status ⚠️<br/>Patient chart: check_in_patient ✅| D[Checked In]
    D --> E[Nursing room → vitals]
    E --> F[Practitioner room → draft Encounter]
    F --> G[Closed / Checked Out]
    G --> H[Checkout → invoice + payment]

    B -.->|Appointments list<br/>reschedule_appointment<br/>NO fee settlement| B
    B -.->|Mission Control / chart tab<br/>reschedule_appointment_with_payment<br/>fee settled + history row| B
    B -.->|cancel_appointment| I[Cancelled]
    B -.->|NO UI ANYWHERE| J[No Show]

    style J fill:#7f1d1d,stroke:#dc2626
    style C fill:#1e3a5f
```

### Entry points that can create an appointment

| Entry point | File | Backend method |
|---|---|---|
| Command palette / global "New appointment" | `src/components/app-shell/command-palette.tsx:141` | `book_appointment_for_patient` |
| Patient chart → Book | `src/app/(clinic)/patients/[id]/patient-chart-client.tsx:458` | `book_appointment_for_patient` |
| Follow-up auto-book on encounter sign | `e2e/followup-autobook-on-sign.spec.ts` (covered) | `book_appointment_for_patient` |

All three share the drawer (`new-appointment-dialog.tsx`, 2,540 lines) but each
re-implements the payload mapping independently — see gap **G-11**.

---

## 2. Backend surface vs. UI coverage

| Backend method | BFF route | Client method | Reachable in UI |
|---|---|---|---|
| `get_available_slots` | `api/appointments/slots` | `useAvailableSlots` / `useMultiPractitionerSlots` | ✅ |
| `list_appointments` / `get_appointments` | `api/appointments` | `appointmentsApi.list` | ✅ |
| `get_appointment` | `api/appointments/[id]` | `appointmentsApi.get` | ✅ |
| `book_appointment_for_patient` | `api/appointments/book` | `appointmentsApi.book` | ✅ |
| `book_appointment_with_payment` | `api/appointments/create-with-payment` | `appointmentsApi.createWithPayment` | ⚠️ client method exists, **no caller** |
| `book_appointment` | `POST api/appointments` | `appointmentsApi.create` | ⚠️ client method exists, **no caller** |
| `create_appointment` | — | — | ❌ no route |
| `update_status` | `PATCH api/appointments/[id]` | `useUpdateAppointmentStatus` | ✅ (Mission Control, chart tab) |
| `check_in_patient` | `api/appointments/[id]/check-in` | `useCheckInPatient` | ⚠️ chart tab + lab center only |
| `cancel_appointment` | `DELETE api/appointments/[id]` | `useCancelAppointment` | ✅ |
| `reschedule_appointment` | `api/appointments/[id]/reschedule` | `useRescheduleAppointment` | ✅ (list + chart overview) |
| `reschedule_appointment_with_payment` | `api/appointments/[id]/reschedule-with-payment` | `useRescheduleWithPayment` | ✅ (Mission Control + chart tab) |
| `reassign_appointment` | `api/appointments/[id]/reassign` | `useReassignAppointment` | ⚠️ **commented out** in the list menu |
| `get_reschedule_history` | ❌ **none** | ❌ **none** | ❌ **unreachable** |
| `report_practitioner_scope` | ❌ none | — | ❌ (diagnostic; acceptable) |

---

## 3. Gaps

### 🔴 G-01 — Rescheduling settles money on two screens and not on the other two

The same user-facing action ("move this appointment") is wired to two different
backend endpoints depending on where the user starts, and the two have different
financial consequences.

| Screen | Dialog | Endpoint | Fee difference settled | Reschedule History row |
|---|---|---|---|---|
| Appointments list | `components/narzim/appointments/reschedule-dialog.tsx` | `reschedule_appointment` | ❌ no | ❌ no |
| Patient chart → Overview card | same dialog | `reschedule_appointment` | ❌ no | ❌ no |
| Mission Control | `components/narzim/dashboard/reschedule-dialog.tsx` | `reschedule_appointment_with_payment` | ✅ yes | ✅ yes |
| Patient chart → Appointments tab | same dashboard dialog | `reschedule_appointment_with_payment` | ✅ yes | ✅ yes |

Evidence: `src/app/(clinic)/appointments/appointments-client.tsx:28` and
`src/components/narzim/patient-chart/overview-frontdesk.tsx:15` import the
non-settling dialog; `src/components/narzim/patient-chart/appointments-tab.tsx:20`
and `src/components/narzim/dashboard/mission-control-client.tsx:38` import the
settling one.

**Consequence:** moving a paid 800 MXN consultation to a 1,200 MXN slot from the
Appointments list leaves 400 MXN uncollected and no audit row explaining the move.
The same action from Mission Control raises the additional-payment invoice. Which
screen the front desk happened to use determines whether the clinic gets paid.

**Fix:** delete `components/narzim/appointments/reschedule-dialog.tsx` and point
all four call sites at the settling dialog. `reschedule_appointment` stays
available for the no-fee-change path but should not be the default any screen
reaches by accident.

---

### 🔴 G-02 — "No Show" cannot be set from anywhere in the UI

`No Show` is a real `Patient Appointment` status, is in the backend's role matrix
(`_ROLE_ALLOWED_STATUSES` grants it to `EB_Front Desk`,
`api/v1/appointments/api.py:130`), is excluded from slot-blocking, is a filter
option (`src/types/appointments.ts:92`), is a KPI on the calendar
(`calendar/calendar-client.tsx:197`), and has a whole report page
(`src/app/(clinic)/reports/operations/no-show-analysis/page.tsx`).

No screen writes it. A repo-wide search for a mutation setting `No Show` returns
nothing — only display styles, filters and read-only report consumers.

**Consequence:** the No-Show Analysis report is structurally empty. Appointments
that never happened stay `Confirmed` forever, inflating the queue and corrupting
punctuality and utilisation reporting.

**Fix:** add "Mark as no-show" to the Appointments list row menu and to the
Mission Control *arriving_soon* / *waiting_room* cards, gated on
`appointment_datetime < now`.

---

### 🔴 G-03 — Mission Control check-in does not stamp the arrival timestamp

`check_in_patient` (`api.py:1773`) is the only code path that writes
`custom_checked_in_at`, the field that `api/v1/appointments/report.py` uses for
**queue-wait-times** and **check-in-rates**.

Mission Control — the front desk's primary queue screen — checks patients in with
`updateStatus.mutate({ id, status: "Checked-in" })`
(`mission-control-client.tsx:1507`), which routes to `update_status` and writes
only `status`. `useCheckInPatient` exists but is called only from the patient
chart Appointments tab and the lab center.

**Consequence:** the majority of real check-ins carry no arrival time, so both
wait-time reports silently measure a biased subset. `report.py:225` filters on
`custom_checked_in_at: ["is", "set"]` — the missing rows disappear rather than
error.

**Fix:** Mission Control's check-in action must call `useCheckInPatient`.
Separately, make `update_status` stamp `custom_checked_in_at` when the target
status is `Checked In` and the field is empty, so no future caller can bypass it.

---

### 🔴 G-04 — Arrival time is never returned to the frontend at all

Even where `custom_checked_in_at` *is* written, `_fmt` (`api.py:455-580`) does not
include it in the appointment payload, and it is absent from
`src/types/appointments.ts`.

**Consequence:** no screen can show "waiting 18 min" from real data. Mission
Control's `wait_minutes` comes from the dashboard endpoint's own derivation, and
the Appointments list has no wait column at all.

**Fix:** add `checked_in_at` to `_APPT_FIELDS` + `_fmt` and to the `Appointment`
type. One-line backend change; unblocks a live wait-time column.

---

### 🟠 G-05 — The insurance booking path is built and commented out

`book_appointment_for_patient` fully supports `payment_timing="insurance"`:
coverage-split invoice, patient copay left outstanding for checkout
(`api.py:1495-1530`).

In the drawer, the insurance option in the payment-timing picker is commented out:

```
// { key: "insurance", title: t("insurance"), hint: t("insuranceHint"), icon: "🏥" },
```
`src/components/narzim/dashboard/new-appointment-dialog.tsx:2129`

Roughly 80 lines of insurance UI below it (provider select, policy number, copay
input, coverage calculation, summary rows at :2166, :2193, :2389) are unreachable,
along with the `payViaInsurance` / `insuranceProvider` / `policyNumber` / `copay`
fields on `NewApptPayload` and the `payment_timing: "insurance"` branch in both
call sites (`command-palette.tsx:133`, `patient-chart-client.tsx:448`).

**Also broken if re-enabled:** neither call site sends `insurance_policy`. The
backend needs that docname to have core build the coverage at booking — without
it, `payment_timing="insurance"` produces a normal full-amount invoice with no
coverage split, i.e. the patient is billed the whole fee. The dialog collects the
insurer as **free text**, not as a `Patient Insurance Policy` link.

**Fix:** before un-commenting, replace the free-text insurer field with a
`Patient Insurance Policy` picker fed from `api/v1/insurance` and pass
`insurance_policy` through both call sites. Un-commenting alone would ship a
mis-billing bug.

---

### 🟠 G-06 — Reassign provider is built end to end and disabled in the UI

Backend `reassign_appointment` (`api.py:1844`), BFF route, `useReassignAppointment`,
`mergeCapabilities(roles).reassign` gate, and a complete `ReassignDialog`
(`appointments-client.tsx:264-345`) all exist. The menu entry is commented out:

```
{/* Reassign provider — temporarily disabled per request
```
`src/app/(clinic)/appointments/appointments-client.tsx:400`

Reassignment survives only as a side effect inside the non-settling reschedule
dialog (`components/narzim/appointments/reschedule-dialog.tsx:59-90`), where a
changed practitioner is committed by a **separate** `reassign` call before
`onConfirm` fires the reschedule — two non-atomic writes. If the second fails the
appointment is left reassigned but not moved, with no rollback and no single
toast that describes the resulting state.

**Fix:** decide whether coverage reassignment is a product feature. If yes,
restore the menu entry and drop the two-write path in favour of
`reschedule_appointment_with_payment`, which takes `new_practitioner` atomically.
If no, delete the dialog, the hook, the BFF route and the capability flag rather
than leaving four layers of dead code.

---

### 🟠 G-07 — Reschedule history is unreachable

`get_reschedule_history` (`api.py:2164`) returns the full audit trail of every
move, and `reschedule_appointment_with_payment` writes a history row per move.
There is no BFF route, no client method, and no consumer — the only frontend trace
is the unused `history: string` field on `RescheduleWithPaymentResult`
(`src/types/appointments.ts`).

**Consequence:** "why was this moved three times and who pays the difference?" is
answerable in the database and nowhere in the product. For a NOM-024 traceability
claim this is the wrong side of the line.

**Fix:** add `GET /api/appointments/[id]/reschedule-history` and render it as a
timeline section in the appointment detail / chart Appointments tab.

---

### 🟠 G-08 — Multi-select filters silently filter only the first 200 rows

The Appointments list pushes a filter server-side only when exactly one value is
selected:

```
// server-side only when exactly 1 is checked (efficient path); 0 or 2+ means
// fetch all and filter client-side — no backend changes required.
```
`src/app/(clinic)/appointments/appointments-client.tsx:488`

But every `apiParams` branch hard-caps `limit: 200` (`:507-514`). "Fetch all" is
in fact "fetch 200". Selecting two statuses, two practitioners, or two billing
states filters a truncated window and presents the result as complete.

Applies to `statusFilterSet`, `practFilterSet` and `billingFilterSet`.

**Fix:** the backend already accepts `["in", [...]]` semantics internally —
extend `status` / `practitioner` / `billing_status` in `_list_impl` to accept a
comma-separated list and push all multi-selects server-side. Until then, surface
"showing first 200 of N" instead of an unqualified count.

---

### 🟠 G-09 — `service_unit` is sent to the slots endpoint and silently ignored

`get_available_slots(practitioner, date)` (`api.py:986`) takes **no**
`service_unit` parameter. `frappe.call` filters kwargs against the function
signature, so the argument is dropped without error.

The frontend believes otherwise. The BFF route conditionally forwards it and
documents behaviour the backend does not have:

```
// service_unit is optional: when omitted, the backend returns availability
// across all of the practitioner's schedules for the day.
```
`src/app/api/appointments/slots/route.ts:14-15`

`useMultiPractitionerSlots` also includes `serviceUnit` in the React Query key
(`src/hooks/use-healthcare.ts:315`), so distinct rooms produce distinct cache
entries holding identical data.

Worse, slots are **deduped by `from_time`, first service unit wins**
(`api.py:1172-1181`). A practitioner with two concurrent service units loses the
second one entirely, so a room-specific booking UI cannot be built on this
endpoint as written.

**Fix:** either add a real `service_unit` filter to `get_available_slots` and
group rather than dedupe, or delete the parameter from the BFF route, the hook
cache key and the `requireServiceUnit` option (`use-healthcare.ts:346`) and stop
documenting a filter that does not exist.

---

### 🟠 G-10 — The Appointments list row menu offers only two of six lifecycle actions

`ActionMenu` (`appointments-client.tsx:349-423`) offers **Reschedule** and
**Cancel**. Missing: Confirm, Check in, Mark no-show, Reassign (G-06). All exist
in the backend and three of them are reachable from Mission Control only.

**Consequence:** a front desk working the list — the natural screen for tomorrow's
schedule — cannot confirm or check in without navigating to another screen. The
`actionsDisabled` guard also blanks the whole menu for `Cancelled` and
`Completed` appointments, so "Rebook" (which the chart tab does offer,
`appointments-tab.tsx:65`) is unavailable exactly where a cancelled row is most
visible.

---

### 🟡 G-11 — The booking payload is mapped three times, and drops eight fields

`command-palette.tsx:100-155` and `patient-chart-client.tsx:422-473` contain
near-identical 50-line payload mappings, each carrying the same comment claiming
it "mirrors dashboard-client.tsx" — a file that no longer holds that logic.

Fields `book_appointment_for_patient` accepts that no mapping sends:

| Field | Effect of omission |
|---|---|
| `insurance_policy` | insurance timing mis-bills (G-05) |
| ~~`reference_no` / `reference_date`~~ | ✅ **Fixed 2026-08-19** — Pay-Now cheque/bank reference now reaches the Payment Entry instead of defaulting to the invoice id. See `APPOINTMENT_FLOW_FIXES.md` §7. |
| `duration` | every appointment takes the type default; the drawer has no duration control at all |
| `department` | appointment carries no department; department-scoped reports lose rows |
| `referring_practitioner` | referral attribution impossible |
| `source` | no acquisition-channel reporting |
| `add_video_conferencing` | telemedicine bookings cannot be made |
| `discount_percentage` | drawer's `%` discount toggle (`:2105`) is converted to an amount client-side; the percentage is never persisted |
| `discount_amount` on insurance timing | only sent for `pay_now` (`command-palette.tsx:137`) |

**Fix:** extract one `buildBookingPayload(payload, company)` in
`src/lib/api/appointments.ts` and have all entry points call it. Decide per field
above whether to wire it or to remove it from the drawer.

---

### 🟡 G-12 — Three broken/dead BFF routes

| Route | Problem |
|---|---|
| `api/appointments/cancel/route.ts` | validates and forwards `{ name }`; backend expects `appointment` → guaranteed 400. **No callers.** |
| `api/appointments/check-in/route.ts` | same `{ name }` vs `appointment` mismatch → guaranteed 400. **No callers.** |
| `GET api/appointments?id=` (`route.ts:30-36`) | calls `get_appointment` with `{ name: id }`; backend expects `appointment` → guaranteed 400. **No callers.** |

Superseded by the `[id]/` routes, which pass the correct parameter name. Three
endpoints that would fail on first use if anyone believed them.

**Fix:** delete all three.

---

### 🟡 G-13 — Status filter list omits two live statuses

`APPOINTMENT_STATUS_FILTER_OPTIONS` (`src/types/appointments.ts:88-95`) offers
Confirmed, Checked-in, Checked-out, Completed, No Show, Cancelled. The backend
surfaces `Open` and `Scheduled` as distinct values on purpose — `_STATUS_ERP_TO_FE`
(`api.py:89-101`) stopped collapsing them into "Confirmed" specifically so the UI
could show the true lifecycle stage. Neither is filterable; a freshly booked
appointment is findable only under "All statuses".

`billing_status` has the mirror problem: `_billing_for` can return `Refunded`
(`api.py:420`) but `_list_impl` accepts only `Unbilled | Pending | Paid`
(`api.py:648-670`), so refunded appointments are unfilterable.

---

### 🟡 G-14 — Legacy and canonical status names coexist in the type system

`AppointmentStatus` carries both `"Checked In"` and `"Checked-in"`, both
`"Checked Out"` and `"Checked-out"`, plus `Ready for Provider`, `In Procedure`,
`Completed`, `Rescheduled` and a display-only `Practitioner Room`
(`src/types/appointments.ts:1-30`). Consumers defensively list both spellings —
`appointments-tab.tsx:46-53` enumerates five variants across three arrays.

The backend translates in both directions (`_STATUS_FE_TO_ERP` /
`_STATUS_ERP_TO_FE`), so only the frontend names reach the UI. The duplication is
pure risk: a new `STATUS_STYLE` map or filter that covers one spelling and not the
other fails silently on a subset of rows.

**Fix:** normalise on the frontend names the backend actually emits (`Open`,
`Scheduled`, `Confirmed`, `Checked-in`, `Checked-out`, `Completed`, `No Show`,
`Cancelled`), keep `Practitioner Room` explicitly marked derived, delete the rest.

---

### 🟡 G-15 — Slot tooltips expose other patients' names under a practitioner-read gate

`get_available_slots` requires only `Healthcare Practitioner: read`
(`api.py:1015`) but returns `patient_name` per booked slot
(`api.py:1160-1168`). Any role that can read practitioners sees who else is
booked, without needing `Patient: read`.

This is acceptable for front desk. It is the same leak `docs/KNOWN_ISSUES.md:37-46`
already flags as blocking for the patient-portal wrapper. Documenting it here so
the staff-app case is a recorded decision rather than an oversight — and so the
eventual shared helper strips identity by caller role, not by endpoint.

---

### 🟡 G-16 — ~40 lines of hardcoded demo queue data remain in Mission Control

`USE_DEMO_QUEUE = false` (`mission-control-client.tsx:538`) but `DEMO_DASH`
(`:540-570`) — 14 fully-populated appointments with names, phone numbers and
chief complaints — still ships in the client bundle and is still branched on at
`:2290`. The project already has a proper dev-only mechanism
(`FRAPPE_DEMO_MODE`, `api/appointments/route.ts:16-25`).

**Fix:** delete `DEMO_DASH`/`USE_DEMO_QUEUE`; use `FRAPPE_DEMO_MODE` if a demo
queue is still wanted.

---

## 4. Priority

| # | Gap | Class | Effort |
|---|---|---|---|
| 1 | ~~**G-01** one reschedule dialog, fee always settled~~ ✅ **FIXED 2026-08-19** — all four entry points use the settling flow; the non-settling dialog is deleted. See `APPOINTMENT_FLOW_FIXES.md` §9. | 🔴 revenue + audit | done |
| 2 | **G-03** Mission Control uses `check_in_patient` | 🔴 report integrity | S — 1 call site |
| 3 | **G-02** No-show action in list + queue | 🔴 unblocks a shipped report | M |
| 4 | **G-04** return `checked_in_at` | 🔴 unblocks wait times | S — backend only |
| 5 | **G-12** delete 3 broken routes | 🟡 | S |
| 6 | **G-08** push multi-selects server-side | 🟠 silent wrong results | M — backend + client |
| 7 | **G-10** complete the row action menu | 🟠 | M |
| 8 | **G-09** resolve the `service_unit` contract | 🟠 | M — needs a product call |
| 9 | **G-05** insurance path + `insurance_policy` picker | 🟠 | L — depends on Phase 3 insurance |
| 10 | **G-07** reschedule history route + timeline | 🟠 | M |
| 11 | **G-06** decide reassign: restore or delete | 🟠 | S either way |
| 12 | **G-11** single `buildBookingPayload` | 🟡 | M |
| 13 | **G-13 / G-14** status + billing filter cleanup | 🟡 | M |
| 14 | **G-16** delete demo queue data | 🟡 | S |
| 15 | **G-15** record the slot-tooltip decision | 🟡 | S — doc only |

Items 1–5 are a single focused PR and remove every revenue and reporting
correctness defect in the flow.

## 5. Not gaps

Recorded so they are not re-raised:

- **Waitlist, recurring appointments, appointment reminders as an in-flow action.**
  Not in the backend either. `Patient Appointment.reminded` is a core field the
  backend surfaces (`api.py:_fmt`) but nothing sets; the reminder settings under
  `components/settings/preferences-section.tsx:35` configure notification
  preferences, not appointment-level sends. Product decision, not a UI gap.
- **Calendar drag-and-drop reschedule.** Never specified; the calendar
  (`calendar/calendar-client.tsx`) is read + navigate with day/week/month views.
- **Free-text search.** The `apiParams` comment at `:499` claims the backend only
  supports exact patient-id match. Stale — `_list_impl:613-637` does partial
  case-insensitive search on patient name and MRN, and the client does send
  `search`. Comment should be corrected; behaviour is fine.
- **`create_appointment` has no BFF route.** Correct: `book_appointment_for_patient`
  supersedes it and is atomic. Consider deprecating `create_appointment` and
  `book_appointment` rather than routing them.

---

**Follow-up:** `docs/audit/APPOINTMENT_RESCHEDULE_STATUS.md` is the reschedule flow's own
status sheet — what was fixed 2026-08-19 and the 5 gaps still open.

**Follow-up:** `docs/audit/APPOINTMENT_FLOW_FIXES.md` records the seven New Appointment
drawer fixes landed after this audit, and what they deliberately left alone.

**Evidence base:** backend `remedisys_healthcare_ai/api/v1/appointments/api.py`,
`report.py`; frontend `remedisys-ai-ehr` @ `e99b417` —
`src/app/(clinic)/appointments/**`, `src/app/api/appointments/**`,
`src/lib/api/appointments.ts`, `src/hooks/use-appointments.ts`,
`src/types/appointments.ts`, `src/components/narzim/{appointments,dashboard,patient-chart}/**`,
`src/components/app-shell/command-palette.tsx`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
