# OPD Frontend + Architecture Alignment Audit

**Doc status:** record · **Created:** 2026-07-07 by Invincible · **Updated:** 2026-07-07 by Sarvesh-SocialAngel · **Version:** 1.0

**App audited:** `Healthcare_next_app` (Next.js App Router) against `EB_Healthcare_Backend` (Frappe v16)
**Date:** 2026-07-02
**Author:** Architecture audit (read-only; no code changed)
**Baseline:** Roadmap-calibrated — findings are judged against the committed phase plan, not an Epic/Athena end-state. Items deliberately deferred by the roadmap are listed separately as *tracked deferrals*, not launch gaps.
**Scope of this pass:** the OPD spine — booking → reception/queue → patient 360 → consultation/encounter → billing — plus backend/architecture alignment and cross-cutting concerns. Deeper per-screen button-level sweeps and the full 15-section enterprise wishlist are follow-ups.

> **Reading note for stakeholders.** The prompt that commissioned this audit assumed "the product has serious hidden gaps" and to "challenge everything." I did. The honest headline is: **the OPD spine is real and wired to the backend — this is not a demo-ware frontend.** Booking, check-in, the derived-state queue (ADR-020), the patient chart, the encounter SOAP/Rx/lab flow, and billing collect/refund/POS all call real whitelisted backend methods. The serious findings are concentrated in five places, not spread across everything. Treating intentional Phase-4/5 deferrals as launch blockers would be noise; I have quarantined them.

---

## 0. Executive summary

| Metric | Count |
|---|---|
| Total findings (this pass) | 21 |
| **Critical** (launch-blocking / safety / financial-integrity / compliance) | 5 |
| High | 7 |
| Medium | 6 |
| Low | 3 |
| Constitution (CLAUDE.md) violations | 3 |
| Backend/frontend mismatches | 4 |
| Tracked deferrals (planned — NOT counted as gaps) | 6 |

### The 5 Critical findings (detail below)
1. **C-1 — Cash drawer / shift management has no backend.** The frontend has a full cash-drawer + PIN shift-handoff UI (`cash/`, `(auth)/pin`) but the backend exposes **no cash/shift/reconciliation endpoints**. Money movement with no server-side source of truth is a financial-control failure. `[VERIFY]`
2. **C-2 — Canned clinical data ("Acute bronchitis") ships in the production encounter screen.** An AI-autofill *demo simulation* writes hardcoded vitals (`37.8 / 112`) and a diagnosis into the live encounter form. This is a patient-safety and Rule-6 (physician-in-control) hazard even as a demo.
3. **C-3 — Referrals tab silently discards data.** The patient-chart Referrals tab holds referrals in React local state with no API and no persistence. A clinician "creates a referral," it looks saved, and it is gone on refresh. Data-integrity + clinical-continuity risk.
4. **C-4 — `/api/resource/` usage violates the architecture constitution.** All 14 `/api/admin/*` master-data routes hit Frappe's built-in `/api/resource/<DocType>`, bypassing the permission-checked whitelisted service layer that CLAUDE.md §3/§11 mandate.
5. **C-5 — No amend workflow for signed encounters.** A submitted (signed) Patient Encounter can only be *cancelled*, not amended. Correcting a signed clinical note by cancel-and-recreate breaks the medico-legal audit chain (NOM-024-SSA3 / CIE-10 record integrity).

---

## 1. Cross-cutting / architecture findings

### C-4 — `/api/resource/` bypass in admin master-data routes `[CRITICAL — constitution violation]`
- **Backend alignment problem.** `src/lib/api/client.ts` exposes `frappeRestList/Get/Insert/Update/Delete` against Frappe's built-in `/api/resource/<DocType>`. Used by all 14 `/api/admin/*` routes (brands, diagnosis, items, manufacturers, medications, symptoms, treatment-plans, `[resource]`, …). CLAUDE.md §3 (locked assumption "Custom whitelisted methods only — Never use Frappe's built-in `/api/resource/`") and §11 ("all data access goes through `api/v1/<module>/api.py`") forbid this.
- **Why it matters:** these routes skip the `require_permission()` + `@handle_api_errors` envelope layer. Permission enforcement then relies entirely on Frappe's DocType-level role permissions being correct for every master DocType — which is exactly the surface a `feature/fix-role-permission-gaps` branch exists to patch. It also means the error contract, PHI-scrubbing, and audit conventions of the service layer are not applied to master-data writes.
- **Suggested fix:** wrap admin master-data CRUD behind whitelisted methods in `api/v1/admin/api.py` (a stub already exists, 138 lines). Frontend `frappeRest*` should be deleted from the client once migrated. If a deliberate exception is wanted for low-risk masters, it needs its own ADR that supersedes the §3 lock — not a silent client comment asserting REST is "officially supported."
- **Priority: Critical.**

### H-1 — Appointment status vocabulary drift (phantom + hyphenated statuses) `[HIGH — backend mismatch]`
- The backend emits exactly: `Scheduled, Open, Confirmed, Checked In, Checked Out, Closed, Cancelled, No Show` (translated to FE names `Confirmed / Checked-in / Checked-out / Completed / Cancelled / No Show`). The frontend `AppointmentStatus` union still carries **legacy values** the backend never emits: `Checked-in` (hyphen vs `Checked In`), `Ready for Provider`, `In Procedure`, `Completed`, `Rescheduled`.
- `Ready for Provider` is the **phantom status ADR-020 was written to kill** — it is only an input alias collapsing to `Checked In`; it is never emitted. `waiting` / `in-consultation` are **derived rooms, not statuses**.
- **Risk:** action-menu transitions or filters keyed off phantom/hyphenated values are dead code that will silently no-op or mis-filter the queue. Multiple parallel status vocabularies (`AppointmentStatus`, `VisitStatus`, my-work status) increase drift risk.
- **Suggested fix:** collapse to the single canonical backend set; delete legacy union members once action menus are migrated (the code comment already flags this as pending). Add a shared enum sourced from one place.
- **Priority: High.**

### H-2 — Frontend is ahead of backend on Physical Exam + Vaccinations (feature exists, UI disabled) `[HIGH — backend mismatch, inverted]`
- The frontend disables **Review of Systems, Physical Exam, and Vaccinations** in the encounter screen (local state, `TODO(backend)`, per `docs/BACKEND_PENDING.md`). But the backend `save_draft` **already accepts** `physical_examination` (stashed in the `encounter_comment` blob per ADR-019) and `vaccines` (materialized into native Immunization records on `complete_encounter`, atomically, per ADR-019).
- **This is a mismatch in the *other* direction:** working backend capability is dark in the UI. Physical Exam and Vaccinations appear buildable now. Review of Systems has no confirmed backend field — that one is a genuine pending item.
- **Suggested fix:** reconcile `docs/BACKEND_PENDING.md` against the actual `save_draft` contract; enable Physical Exam + Vaccinations, confirm ROS storage before enabling it.
- **Priority: High.**

### M-1 — Hardcoded user-visible strings despite next-intl `[MEDIUM — constitution §13.10]`
- next-intl v4 is set up with `en.json` / `es.json` (2,903 lines each), yet production components still contain English literals ("Loading encounter…", "Encounter not found", "Back to encounters", referral specialty labels). §13.10 says hardcoded user-visible strings are a bug.
- **Suggested fix:** sweep clinical screens for literals; a lint rule (`eslint-plugin-formatjs`/`no-literal-string`) would prevent regression.
- **Priority: Medium.**

### M-2 — Documentation vs. implementation drift `[MEDIUM — governance/compliance]`
- CLAUDE.md §5 and ADR-010 still say **NextAuth (v5/v4)**; the real implementation is **custom eb_frappe_jwt Bearer JWT via BFF** (ADR-011). The CLAUDE.md repo-layout section lists insurance/prescriptions/notifications/documents as empty stubs — they are **built**. The frontend also relies on `docs/BACKEND_PENDING.md` which is now partly wrong (see H-2).
- **Why it matters for an audit:** ADRs and CLAUDE.md are the declared source of truth. If they lag reality, every downstream decision (and this audit) risks being calibrated to fiction. For a compliance posture (NOM-024 requires accurate system documentation), stale architecture docs are a finding, not a nit.
- **Suggested fix:** refresh CLAUDE.md §5/§6, supersede ADR-010's auth clause explicitly, reconcile `BACKEND_PENDING.md`.
- **Priority: Medium.**

### L-1 — List envelope key: `data` vs `items` `[LOW — verify]`
- `set_list_response()` writes the array under `data` while its docstring says `items` (utils.py). The frontend `frappeFetchList` reportedly reads `data`, so this is currently harmless — but the docstring is a trap for the next integrator.
- **Priority: Low** (fix docstring; add a contract test).

### L-2 — Route-access is a UX guard, not a security boundary `[LOW — confirm posture]`
- `src/lib/auth/route-access.ts` is explicitly a client-side UX gate; the real boundary is Frappe permissions. This is the correct BFF posture **only if** every whitelisted method enforces `require_permission()` and every `/api/resource/` master (see C-4) has correct DocType perms. The existence of `feature/fix-role-permission-gaps` suggests this was not fully true recently — worth a permission-matrix regression test before launch.
- **Priority: Low → escalates to High if C-4 is not fixed.**

---

## 2. Module: Appointment Booking

### Existing flow
Search/calendar → doctor + slot (`get_available_slots`) → atomic patient+appointment booking (`book_appointment_for_patient`), with pay-now / pay-later / insurance paths (`book_appointment_with_payment`, ADR-012). Reschedule, cancel, reassign-practitioner (front-desk coverage, ADR-018), check-in all wired to real backend writes. **Real data, not mock.**

### Missing features / gaps
- **Waitlist** — absent (tracked deferral).
- **Walk-in / emergency booking as a distinct fast-path** — not confirmed; walk-in appears to route through the same create flow. Emergency priority is not modeled.
- **Refund-on-cancel wiring** — backend `create_credit_note` exists; confirm the cancel UI actually offers/triggers refund when the appointment was pre-paid, rather than leaving an orphaned paid invoice. `[VERIFY]`

### Business-logic problems
- **Double-booking / slot-lock concurrency** `[HIGH]` — booking is described as atomic and the envelope supports `409 CONFLICT`, but the concurrency guarantee (row lock vs. optimistic re-check) should be proven under two simultaneous bookings of the last slot. A slot double-book is a real-world OPD incident. `[VERIFY with a concurrency test]`
- **`Rescheduled` is never emitted** — reschedule maps back to `Scheduled`, so a rescheduled appointment is indistinguishable from a fresh one in history. Loses operational signal (no-show/reschedule analytics).

### Backend alignment
- Buffer-between-appointments and practitioner holiday/leave handling live in `get_available_slots` — confirm the frontend surfaces "no slots / on leave" states rather than an empty grid. `[VERIFY]`

### Priority: High (concurrency + refund-on-cancel verification).

---

## 3. Module: Reception Desk / Queue (ADR-020 derived state)

### Existing flow
`dashboard` + `queue` driven by `useDashboard`/`useAppointments`. Queue stages **derived from real clinical artifacts** — `arriving_soon` (ERP Open), `waiting_room` (Confirmed, no encounter), `nursing_room` (Checked In, vitals), `practitioner_room` (draft encounter exists), `checkout` (submitted encounter + outstanding). This is a genuinely good design and matches ADR-020. Check-in is wired.

### Missing features (operational)
- **Estimated wait time** — not modeled.
- **Emergency priority / queue reorder / skip / recall patient** — not present. Real OPD desks need manual reorder and recall.
- **No-show handling in UI** — backend derives a `no_show` set; confirm the queue exposes marking/undoing no-show. `[VERIFY]`
- **Token / turn number** — check-in exists, but a printed/displayed token number for patients is not confirmed. `[VERIFY]`

### UX problems
- **M-3 — Fake queue counts during load** `[MEDIUM — data integrity]`: `queue-client.tsx` renders a hardcoded fallback object (`waiting_room: 5, nursing_room: 8, …`) before real data resolves. Staff briefly see fabricated counts. Replace with a skeleton/zero state.

### Enterprise
- **Real-time updates** — queue appears to poll via React Query. At clinic scale that is fine; for a busy multi-provider floor, Frappe SocketIO push would reduce staleness. Confirm refetch interval. `[VERIFY]`

### Priority: Medium (spine works; operational controls + fake-count are the gaps).

---

## 4. Module: Patient 360 / Chart

### Existing flow
`patients/[id]` with tabs: overview, clinical, history, visits, vitals, insurance, documents, contact, referrals. Most tabs call real hooks (`usePatientInsurance`, visits, documents, allergies/conditions). Backend serves these via ~10 discrete endpoints across patients/clinical/labs/billing/documents/notifications.

### Critical / high findings
- **C-3 — Referrals tab silently discards data** `[CRITICAL — data integrity]`: `referrals-tab.tsx` stores referrals in `React.useState([])` with a hardcoded `SPECIALTIES` list — no API, no persistence. The backend referrals DocType is unbuilt (needs an ADR per backend §12.4). A tab that *looks* functional but loses clinical referral data is worse than an absent tab. **Fix:** hide/disable the tab behind a feature flag until the backend exists, or ship the backend. Do not present an interactive form that persists nothing.

### Missing / not-yet-real
- **Financial tab** is composed from billing endpoints (invoices, billables) — no wallet / advance-payment ledger (advance payment unsupported backend-side).
- **Insurance claims history** — not present (claims lifecycle unbuilt; policies only). Tracked deferral.
- **Communication history** (SMS/email/WhatsApp) — notifications module + WhatsApp conversations exist; confirm the chart tab surfaces them. `[VERIFY]`

### Enterprise / scalability
- **H-3 — No aggregate Patient-360 endpoint** `[HIGH — scalability]`: the chart fans out to ~10 sequential/parallel calls. At enterprise volume and on mobile networks this is a latency and N+1-shaped waterfall. Consider a single `get_patient_360(patient)` aggregator (or a documented parallel-fetch contract with per-tab lazy loading).

### Priority: Critical (C-3), then High (aggregation).

---

## 5. Module: Doctor Consultation / Encounter

### Existing flow
`encounters/[id]` → `encounter-screen.tsx`. Persists chief complaint, HPI, plan, education, diagnoses (text + `diagnoses` child table), Rx (`drug_prescription`), labs/imaging (`lab_test_prescription`), procedures, therapies via `save_draft` / `sign()` (→ `complete_encounter` submit). Loading / not-found / error states present. Draft merge semantics are well-designed (text merge, child-table replace). **Real for the built subset.**

### Critical findings
- **C-2 — Canned clinical data in production** `[CRITICAL — safety / Rule 6]`: an AI-autofill *demo* (~L430–445) writes hardcoded vitals `37.8/112`, diagnosis "Acute bronchitis, unspecified", and a canned plan into the live form. Even as a demo this violates Rule 6 (AI never auto-applies clinical content) and is a real "wrong data saved to a real patient" hazard. **Fix:** remove or hard-gate behind an off-by-default dev flag; it must not exist in a production build. AI belongs in Phase 5 behind the suggestion→review→approve pipeline.
- **C-5 — No amend workflow for signed encounters** `[CRITICAL — compliance]`: `complete_encounter` submits (docstatus 1); the only backward path is `cancel_encounter` (cancel/delete). There is **no amend** endpoint. A signed clinical note must be correctable via an audited amendment, not cancel-and-rewrite, to preserve the medico-legal record (NOM-024-SSA3). **Fix:** add an amend path (Frappe supports amended-from) that preserves the original and links the correction.

### Missing features
- **H-4 — No structured ICD/CIE-10 coding** `[HIGH — compliance/billing]`: diagnoses are stored as native `Diagnosis` docnames or free text; no ICD-10/CIE-10 code field is surfaced. Mexico clinical + billing records generally need CIE-10 coding, and downstream insurance claims cannot be built without coded diagnoses. Confirm whether the `Diagnosis` DocType carries a CIE-10 code and surface it.
- **Follow-up scheduling** — no dedicated follow-up field in `save_draft`; "schedule follow-up from the encounter" is not wired. Common OPD action.
- **Allergy banner during prescribing** `[HIGH — safety, non-AI]`: allergies are stored (`Patient.allergies`, clinical CRUD) and the chart shows them, but prescribing in the encounter should surface an **allergy alert** at the point of drug order. This does *not* require AI — it's a lookup against recorded allergies. Full drug-interaction checking is a Phase-5 deferral, but a basic recorded-allergy warning is table stakes and should be discussed for launch.
- **Templates / voice notes** — templates exist (`search_treatment_plan_templates`); voice notes are Phase-5.

### Backend alignment
- See H-2 — Physical Exam + Vaccinations are backend-ready but UI-disabled.

### Priority: Critical (C-2, C-5), then High (ICD, allergy alert).

---

## 6. Module: Billing / Payments / Cash

### Existing flow
`billing/` + `cash/`. Backend `billing/api.py` (843 lines) delegates to ERPNext core: appointment/vaccination/POS invoices, `collect_payment` (supports **partial** payment ≤ outstanding), `create_credit_note` (full refund), payment-method list, invoice/payment reads. Invoice, collect, refund, POS all wired to real methods. **Real data.**

### Critical findings
- **C-1 — Cash drawer / shift management has no backend** `[CRITICAL — financial control]`: the frontend has `cash/` (shift/drawer) and `(auth)/pin` with `openShift` / `DrawerTransfer` / `StaffMember`, but the **backend exposes no cash/shift/reconciliation endpoints** (backend §12.4 lists "Cash/Shift management" as *requiring an ADR before building* — i.e. unbuilt). If the cash-drawer UI is operating on client/local state, then shift open/close, drawer counts, and daily reconciliation have **no server-side source of truth** — a direct financial-control and audit failure. **Fix / VERIFY first:** confirm whether `cash/` calls any backend method. If it does not, it must be disabled until the backend (Cash Session / Shift / Drawer Reconciliation doctypes) is designed via ADR. Cash handling without server reconciliation cannot go to production.

### Missing features
- **Split payment** (multiple modes on one settlement) — `collect_payment` takes a single `mode_of_payment`. Common at a front desk (part cash, part card).
- **Partial refund** — `create_credit_note` is a full return only; no partial/line-level refund.
- **Advance payment** — not supported backend-side.
- **Insurance claim adjudication billing** — not present (claims unbuilt; tracked deferral).

### Compliance
- **H-5 — Mexican CFDI / SAT electronic invoicing not present** `[HIGH — MX compliance]`: invoices are ERPNext Sales Invoices with no CFDI (SAT) e-invoicing / RFC / tax-stamp integration surfaced. In Mexico, a billable clinical invoice generally requires CFDI. This is a compliance and go-to-market blocker for the MX jurisdiction and must be on the pre-production discussion list. (IVA/tax logic likewise unconfirmed.)

### Priority: Critical (C-1), then High (CFDI), then Medium (split/partial/advance).

---

## 7. Patient Registration (spot-check — feeds compliance)

Not the focus of this pass, but relevant to compliance findings:
- `create_patient` supports demographics, guardians (add/remove/update), genders. **Confirm:** duplicate-patient detection (phone/name/DOB), consent capture (LFPDPPP/DPDPA privacy consent + clinical consent), government ID, emergency contact, MRN/UHID naming series. `[VERIFY]` — consent capture in particular is a **compliance requirement** in both active jurisdictions (ADR-018: MX + India). If registration does not capture and store consent, that is a High/Critical compliance finding to confirm in the next pass.

---

## 8. Tracked deferrals — planned, NOT counted as launch gaps

These are absent by roadmap decision. Listed so they are not "discovered" as surprises later, but they are **not** flaws against current scope:

1. **Insurance claims lifecycle** (create/submit/status) — Phase 3 remaining; policies-only today.
2. **AI scribe / SOAP / safety validators / drug-interaction** — Phase 5 (locked). *Caveat: the recorded-allergy banner (H-4 area) is arguably non-AI and worth pulling forward.*
3. **WhatsApp reminders / notification automation** — Phase 4 (module built, automation triggers pending).
4. **Reports** — 16 frontend report screens exist but several backend `report.py` methods are partial/stub with explicit `partial`/`stub_fields` flags; screens will render empty/error until wired. Frontend is ahead of backend here — acceptable, but should show honest "not yet available" states, not errors.
5. **Referrals, Cash/Shift, Tasks, Messages threading** — flagged in backend §12.4 as needing an ADR before building. (Note: the *frontend already ships UI* for referrals — C-3 — and cash — C-1 — ahead of these ADRs, which is why they became Critical findings rather than clean deferrals.)
6. **SpO2 vital** — backend vitals set has no oxygen-saturation field; add when the vitals template is next revised.

---

## 9. Product gaps we must discuss before production

Ordered by what I would not let ship without a decision:

1. **Cash handling (C-1).** Do we disable the cash-drawer UI for launch, or fast-track a Cash Session / Shift / Reconciliation backend via ADR? There is no safe middle — money movement needs a server ledger.
2. **Canned clinical demo data in the encounter (C-2).** Remove entirely for production, or gate behind an off-by-default flag? My recommendation: remove; reintroduce only inside the Phase-5 suggestion→review→approve pipeline.
3. **Signed-note amendment (C-5) and CIE-10 coding (H-4).** These are medico-legal/compliance table stakes for a Mexican EHR. Are we comfortable launching without an audited amend path and coded diagnoses? I am not.
4. **CFDI / SAT e-invoicing (H-5).** Can we legally bill in Mexico without CFDI? This likely gates revenue in the target market and needs counsel input (already flagged as "COFEPRIS/counsel TBD" in CLAUDE.md §3).
5. **Referrals persistence (C-3).** Ship the backend, or hide the tab. Not "leave it as local state."
6. **`/api/resource/` bypass (C-4).** Do we migrate admin master-data behind whitelisted methods, or write an ADR that formally carves out an exception? A silent bypass is the worst option.
7. **Point-of-prescribe allergy alert (H-4 area).** Non-AI safety win — do we pull it into launch scope?
8. **Consent capture at registration** (compliance, §7) — confirm it exists; if not, it is likely a launch blocker in both jurisdictions.
9. **Status-vocabulary cleanup (H-1)** — schedule the removal of phantom/hyphenated statuses before more action menus are built on top of them.
10. **Doc/reality reconciliation (M-2)** — refresh CLAUDE.md/ADRs so future decisions aren't calibrated to stale assumptions.

---

## 10. Method, confidence, and what this pass did NOT cover

- **Method:** two parallel deep reads — backend whitelisted API surface (`api/v1/*`, `services/*`, ADR-020) and the `Healthcare_next_app` route tree, auth, API client, and OPD screens — synthesized here. Read-only; no code executed against live data.
- **`[VERIFY]` markers** flag claims I inferred from structure but did not exercise at runtime. Highest-value verifications: C-1 (does `cash/` call the backend?), booking concurrency (double-book the last slot), refund-on-cancel wiring, consent capture at registration.
- **Not covered in this focused pass** (candidates for the next round): full page-by-page button-level sweep (§13 of the brief), patient discovery/search UX, lab order full lifecycle states, immunization screen, notifications/messages UX depth, multi-clinic/multi-company switching at scale, and a real load/scalability model. The prompt's "10,000 clinics / franchise" enterprise-scale question is a separate architecture exercise, not a frontend audit finding.

---

*End of first-pass audit. No code was modified. Recommend triaging §9 with product + clinical + compliance stakeholders before scheduling fixes.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-07 | Sarvesh | Initial version (header backfilled from git history) |
