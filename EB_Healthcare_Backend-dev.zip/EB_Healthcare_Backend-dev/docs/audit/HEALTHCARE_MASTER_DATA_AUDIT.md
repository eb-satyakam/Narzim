# Marley Health — Healthcare Admin Master Data Audit (Outpatient Module)

**Doc status:** living · **Created:** 2026-06-26 by Invincible · **Updated:** 2026-06-26 by Sarvesh-SocialAngel · **Version:** 1.0

**Question:** Can a hospital admin fully configure and operate the entire outpatient module from master data alone, for go-live tomorrow?

**Short answer: No — not yet.** The *doctype foundation* is strong (ERPNext Healthcare ships almost every master the outpatient module needs, and the admin API exposes most of them). But several **go-live-critical catalogs are empty**, a few **existing doctypes have no admin UI**, and **radiology has no model at all**. Specifics below.

**Method:** Audited the live `remedisys.localhost` site — counted records in every healthcare master doctype, checked which master doctypes are *installed*, and cross-referenced the admin catalog API + admin BFF routes to determine what an admin can actually configure from the frontend. Grounded in the database, not assumptions.

**Date:** 2026-06-25 · **Site audited:** `remedisys.localhost` (dev)

> Distinction used throughout:
> **EXISTS** = doctype installed · **POPULATED** = has records · **CONFIGURABLE** = admin can manage it from the Next.js frontend.

---

## SECTION 1 — Existing master records (installed + populated)

| Master | Doctype | Records | Admin-configurable (frontend)? |
|---|---|---|---|
| Company / Org | Company | 1 | ✅ company-profile |
| Medical Department / Specialty | Medical Department | 39 (14 clinic + 25 ERPNext default) | Partial (seeded; `show_in_portal` filters the 14) |
| Practitioner | Healthcare Practitioner | 22 | ✅ practitioners |
| Practitioner Schedule | Practitioner Schedule | 1 (shared "Standard Clinic Hours") | ✅ practitioner-schedules |
| Appointment Type | Appointment Type | 7 (billing items + fees set) | ✅ appointment-types |
| Patient | Patient | 11 | ✅ patients |
| Patient Care Type | Patient Care Type | 3 | ✅ via `[resource]` |
| Medication Class | Medication Class | 32 | ✅ medication-classes |
| Antibiotic | Antibiotic | 166 | ❌ no UI |
| Prescription Dosage | Prescription Dosage | 12 | ✅ prescription-dosages |
| Prescription Duration | Prescription Duration | 26 | ✅ prescription-durations |
| Complaint / Symptom | Complaint | 48 | ✅ symptoms |
| Item (services) | Item | 7 | ✅ items |
| Item Group | Item Group | 8 | — |
| Price List | Price List | 2 (Standard Selling/Buying) | ✅ price-lists |
| Item Price | Item Price | 7 (consultation only) | ✅ price-lists |
| Mode of Payment | Mode of Payment | 5 | ✅ payment-methods |
| Currency | Currency | 9 enabled | — (ERPNext core) |
| Role (EB_) | Role | 6 | ✅ role-permissions |

---

## SECTION 2 — Missing master records

### 2a. Critical empty catalogs (doctype EXISTS, zero records — go-live blockers)

| Master | Doctype | Records | Impact |
|---|---|---|---|
| **Diagnosis / ICD catalog** | Diagnosis | **0** | Doctors cannot code diagnoses; no ICD-10. Encounter completion requires a diagnosis. **P0** |
| **Lab Test catalog** | Lab Test Template | **0** | No lab tests orderable at all. **P0** |
| **Clinical Procedure catalog** | Clinical Procedure Template | **0** | No procedures orderable/billable. **P0** |
| **Medication / drug catalog** | Medication | **0** on this site | No prescribable drugs. (CLAUDE.md claims a 100-med seed — **not run on this site**; confirm before go-live.) **P0** |
| **Holiday List** | Holiday List | **0** | `get_available_slots` checks holidays/leave; with none set, holiday handling is undefined and clinic closures can't be modeled. **P0** |
| **Service Unit Type** | Healthcare Service Unit Type | **0** | No room/unit typing (consultation room, sample room, etc.). **P1** |
| **Service Units** | Healthcare Service Unit | 1 | Only one unit — no rooms/floors/wards modeled. **P1** |
| **Tax template** | Sales Taxes and Charges Template | **0** | No tax on invoices (may be intended for MX, but unconfigured). **P1** |
| **Pricing (lab/procedure/pharmacy)** | Item Price | 7 (consultation only) | Only consultation is priced; nothing else can be billed. **P0 once catalogs exist** |

### 2b. Masters with NO doctype in the install (must be modeled or scoped out)

| Requested master | Status | Note |
|---|---|---|
| **Radiology / Imaging** (Modality, X-Ray/CT/MRI/US, contrast, DICOM, PACS, reporting templates) | **Does not exist** | ERPNext Healthcare ships no radiology module. Model as Clinical Procedure Templates, or descope outpatient radiology, or new ADR. **P1/P2** |
| Branch / Floor / Ward (explicit) | Partial | Modeled via Healthcare Service Unit tree (is_group) + Inpatient — no dedicated Branch master. OK for single-site outpatient. |
| Insurance Plan / Package / Coverage Plan | Partial | `Insurance Payor` + `Patient Insurance Policy` + `Patient Insurance Coverage` exist; no `Healthcare Insurance Coverage Plan` package master. **P2** |
| Corporate client / Employer master | Missing | Modeled via ERPNext Customer; no healthcare-specific corporate contract master. **P2** |
| Referral source / Referral doctor master | Partial | Appointment carries `referring_practitioner`/`source`; no standalone referral master. **P2** |
| Consent template master | Missing | No consent doctype. Required for LFPDPPP/NOM-024. **P1** |
| Drug interaction / contraindication / allergy-interaction rules | Missing | Not in ERPNext Healthcare. These are the Phase-5 AI safety validators — descoped pre-AI. **P2 (P0 when prescribing controlled drugs)** |

---

## SECTION 3 — Incomplete healthcare configuration

- **`Healthcare Settings`** exists but `op_consulting_charge_item` / `inpatient_visit_charge_item` are **NULL** — no global fallback billing item. Invoicing currently works only because Appointment Types now carry per-type charges (recently fixed). Set the global fallback. **P1**
- **Medical Department** has 39 records — 25 are ERPNext defaults (Cardiology, ENT, etc.) mixed with the 14 real clinic departments; only the 14 are flagged `show_in_portal`. Clean up or rely on the flag consistently. **P2**
- **Only one Practitioner Schedule** ("Standard Clinic Hours") shared by all 22 practitioners — no per-practitioner hours, leave calendar, or telemedicine availability. Acceptable for launch, not for real operations. **P1**
- **No telemedicine availability / consultation-type config** on practitioners. **P2**
- **Practitioner credentials** (license number, medical council registration, qualifications) — fields exist on the doctype but are unseeded/unsurfaced in the admin UI. Compliance-relevant. **P1**

---

## SECTION 4 — Medication master gaps

| Item | Status |
|---|---|
| Medication catalog | **EMPTY on this site** (0) — P0; run/verify the 100-med seed |
| Medication Class | ✅ 32 |
| Antibiotic | ✅ 166 seeded — but **no admin UI** to manage |
| Dosage Form | EXISTS, configurable (dosage-forms) — verify populated |
| Dosage Strength | Doctype exists; not surfaced |
| Prescription Dosage / Duration | ✅ 12 / 26, configurable |
| Route of administration / Frequency | Modeled within Dosage/Drug Prescription; no standalone master UI |
| Controlled-drug / OTC / pregnancy / pediatric-dosage rules | **Missing** — not in ERPNext; pediatric weight-based dosing is a roadmap feature, not a master |
| Drug interaction / substitution / refill rules | **Missing** — Phase-5 AI validators (descoped pre-AI) |
| Prescription instruction templates | Partial via Treatment Plan / Drug Prescription comments |

**Verdict:** drug *catalog is empty* (P0). Safety-rule masters are intentionally deferred to the AI phase, but **controlled-substance categorization should not wait** if controlled drugs will be prescribed.

---

## SECTION 5 — Lab master gaps

| Item | Status |
|---|---|
| Lab Test Template | **EMPTY (0)** — P0, no orderable tests |
| Lab Test Group/Panel Template | Doctype exists (Lab Test Group Template); empty; **no admin UI** |
| Lab Test UOM | Doctype exists; **no admin UI** |
| Specimen / Sample Collection | Doctypes exist; **no admin config UI**, no collection workflow |
| Reference range (age/gender-based) | Modeled inside `Normal Test Template` items; **no admin UI to author them** |
| Lab Test Category | No dedicated doctype — uses Department + Group |
| Sample container / rejection reasons / barcode / QC / TAT / repeat rules | **Missing** — not modeled |
| Result approval workflow | Not configured |
| External lab / machine (LIS) integration | **Missing** |

**Verdict:** lab is **catalog-empty and admin-blind** — an admin cannot build the lab test menu from the frontend today. **P0/P1.**

---

## SECTION 6 — Radiology master gaps

**Entire domain absent.** No Modality, no imaging procedure master, no contrast/preparation rules, no DICOM/PACS config, no reporting templates, no radiation-safety checklist — and **no underlying doctype**.

Options: (a) model imaging as Clinical Procedure Templates for outpatient X-ray/US ordering+billing only; (b) descope radiology from outpatient go-live; (c) ADR for a radiology module. **P1 decision, P2 build.**

---

## SECTION 7 — Billing master gaps

| Item | Status |
|---|---|
| Service / consultation fee master | ✅ Appointment Types carry per-type fees; **Healthcare Settings fallback NULL** (P1) |
| Procedure / Lab / Radiology / Pharmacy price lists | **Missing** — Item Price has consultation only (P0 once catalogs exist) |
| Price List | ✅ Standard Selling/Buying |
| Mode of Payment | ✅ 5 |
| Tax template | **EMPTY (0)** — P1 |
| Insurance Payor / Policy / Coverage | ✅ doctypes exist + admin/insurance UI |
| Insurance package / coverage-plan master | **Missing** (P2) |
| Discount rules / corporate pricing / co-pay / credit billing | **Missing** — would use ERPNext Pricing Rules (not surfaced in admin UI) (P2) |
| Refund rules | Via ERPNext core (not surfaced) |
| Invoice series | ERPNext naming series (default) — verify branded series (P2) |
| Payment gateway | **Not configured** (P2 — cash/card only at launch) |

---

## SECTION 8 — Clinical master gaps

| Item | Status |
|---|---|
| Diagnosis catalog | **EMPTY (0)** — P0 |
| ICD code master | Infrastructure EXISTS (`Code System`, `Code Value`, `Medical Code`, `Codification Table`) but **unpopulated + no admin UI** — P1 |
| Clinical Procedure Template | **EMPTY (0)** — P0 |
| Procedure category | Modeled via Item Group / department |
| SOAP / clinical-note templates | Treatment Plan templates exist (6 seeded per CLAUDE.md); no standalone note-template master |
| Allergy master / severity | Allergy captured as free-text + `Patient Allergy`; no severity master (P2) |
| Chronic disease / disease category | Via Diagnosis + `Patient Medical Record` conditions; no separate category master (P2) |
| Vaccination / Immunization schedule | ✅ EXISTS + API (Mexico EPI); verify templates/programs seeded |
| Symptom master | ✅ Complaint (48) |
| Body system / Body Part | `Body Part` exists; **no admin UI** (P2) |
| Patient Assessment Template | EXISTS; not surfaced (P2) |
| Follow-up template | **Missing** (P2) |

---

## SECTION 9 — Security configuration gaps

| Item | Status |
|---|---|
| Role master (EB_) | ✅ 6 roles, `desk_access=0`, rebuilt from `eb_docperm_spec.json` |
| Role permissions (per-doctype) | ✅ configurable (role-permissions UI); recently hardened (Medical Department, Mode of Payment, Customer added) |
| User / staff management | ✅ users, invite-staff |
| Department / Branch-scoped permissions | **Missing** — permissions are role-level, not branch/department-scoped (P2; matters for multi-site) |
| Approval workflows (prescription/billing) | **Missing** — no Frappe Workflow defined (P2) |
| Audit log | `track_changes` on custom doctypes; ERPNext Version/Activity log core; PHI-in-logs rules pending (P1 for compliance) |
| Session timeout / password policy | ERPNext core defaults — **not explicitly configured** (P1) |
| 2FA | Backend-ready (eb_frappe_jwt `verify_otp`), frontend deferred (P2) |
| API permission config | ✅ all access via whitelisted permission-checked methods |

---

## SECTION 10 — Priority matrix

| Priority | Item | Type |
|---|---|---|
| **P0** | Seed/verify **Diagnosis (ICD)** catalog | Empty catalog |
| **P0** | Seed **Lab Test Template** catalog + **admin UI to author tests** | Empty + no UI |
| **P0** | Seed **Clinical Procedure Template** catalog + **admin CRUD UI** | Empty + no UI |
| **P0** | Run/verify **Medication** seed (0 on this site) | Empty catalog |
| **P0** | Create **Holiday List** + assign to schedules | Scheduling blocker |
| **P0** | **Item Prices** for labs/procedures/pharmacy (once catalogs exist) | Billing blocker |
| **P1** | Set `Healthcare Settings` global consulting charge item (fallback) | Incomplete config |
| **P1** | **Service Unit Type** + real **Service Units** (rooms) + admin UI | Missing config |
| **P1** | **Consent template** master (LFPDPPP/NOM-024) | Missing, compliance |
| **P1** | Practitioner **credentials** (license/council/qualifications) surfaced | Compliance |
| **P1** | **Tax template** (or explicit zero-tax decision) | Billing |
| **P1** | **ICD Code System** populate + admin UI (or confirm Diagnosis-only) | Clinical coding |
| **P1** | Radiology **decision** (procedure-template model vs descope vs ADR) | Scope |
| **P1** | Session timeout / password policy / PHI-log scrubbing | Security/compliance |
| **P2** | Per-practitioner schedules, leave, telemedicine availability | Ops depth |
| **P2** | Antibiotic / Dosage Strength / Body Part / Patient Assessment admin UIs | Admin reach |
| **P2** | Insurance package master, discount/co-pay/corporate pricing (Pricing Rules) | Billing depth |
| **P2** | Branch/department-scoped permissions, approval workflows | Multi-site/governance |
| **P2** | Lab depth: panels, specimen config, reference-range UI, QC, TAT, LIS | Lab maturity |
| **P3** | Drug interaction/contraindication/substitution (Phase-5 AI validators) | Deferred |
| **P3** | PACS/DICOM, payment gateway, external lab integration | Future |

---

## Final answers

1. **Can hospital admin configure outpatient system completely?** **No.** The doctype foundation and admin API cover most of the outpatient module, but **Diagnosis, Lab Test Templates, Clinical Procedure Templates, Medications, and Holiday List are empty**, several existing doctypes (Clinical Procedure Template, Lab panels/specimens, Antibiotic, ICD codes, Service Unit Type) have **no admin UI**, and **radiology has no model**. A clinic cannot go live on master data alone today.
2. **Which master records already exist?** Section 1 — departments, practitioners, schedules, appointment types, patients, medication classes, antibiotics, prescription dosages/durations, complaints, items, price lists, payment methods, roles.
3. **Which master records are missing?** Section 2 — empty: Diagnosis, Lab Test Template, Clinical Procedure Template, Medication, Holiday List, Service Unit Type, Tax; absent doctypes: Radiology, Consent template, Insurance package, Corporate/Referral masters.
4. **Which medication masters are missing?** Section 4 — the **drug catalog itself is empty** (P0); controlled-substance categorization and interaction/substitution/refill rules are unmodeled (deferred to AI phase).
5. **Which laboratory masters are missing?** Section 5 — **Lab Test Template catalog empty + no admin authoring UI**; panels, specimens, reference-range UI, QC, TAT, LIS all missing.
6. **Which billing masters are missing?** Section 7 — non-consultation **Item Prices**, **Tax template**, Healthcare Settings fallback item, insurance packages, discount/co-pay/corporate pricing, payment gateway.
7. **Which security masters are missing?** Section 9 — branch/department-scoped permissions, approval workflows, explicit session/password policy, PHI-log scrubbing; 2FA frontend deferred.
8. **What must be built before go-live?** All **P0**: seed Diagnosis/Lab/Procedure/Medication catalogs, build admin UIs for Lab Test Templates and Clinical Procedure Templates, create a Holiday List, and price every billable item. Then P1 (rooms, consent, credentials, tax, security policy, radiology decision).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-26 | Sarvesh | Initial version (header backfilled from git history) |
