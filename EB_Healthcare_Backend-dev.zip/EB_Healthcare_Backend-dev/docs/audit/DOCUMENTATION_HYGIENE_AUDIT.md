# Documentation Hygiene Audit — Both Repos

**Doc status:** record · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

**Scope:** every `.md` file in `remedisys_healthcare_ai` (246) and `Healthcare_next_app` (79) —
**325 files, 67,543 lines, 3.77 MB**. Inventoried mechanically (content hash, H1, git created/updated
date, commit count, outbound link graph), then the suspicious clusters were read.

**Verdict up front:** the documentation is voluminous and often excellent in isolation, and
**structurally unmanaged**. 48 % of it is unreachable, the decision record has nine numbering
collisions and three phantom entries that production code cites, and three separate documents each
claim to be the single source of truth for permissions.

---

## 1. The five findings that matter

| # | Finding | Severity |
|---|---|---|
| **D1** | **9 ADR number collisions.** One number, two different decisions — while CLAUDE.md and production code cite those numbers as if unique | **Critical** |
| **D2** | **3 ADRs are cited by production code and CLAUDE.md and do not exist** — including ADR-009, the browser→Deepgram-direct audio decision | **Critical** |
| **D3** | **Two ADR directories** with opposite naming conventions and colliding numbers | High |
| **D4** | **Three documents claim to be the source of truth for permissions**, two of them byte-identical across a repo boundary | High |
| **D5** | **157 of 325 documents (48 %) are orphaned** — nothing links to them, including every ADR | High |

---

## 2. D1 — ADR number collisions

`docs/adr/` holds **43 files covering 36 numbers**. Seven numbers are used twice inside that
directory, and two more collide with the second ADR directory (§4). The citation counts show these
are not dormant:

| Number | The two decisions sharing it | Files citing "ADR-NNN" |
|---|---|---|
| **ADR-018** | `multi-jurisdiction-compliance` · `practitioner-appointment-visibility-and-coverage` | **61** — incl. `CLAUDE.md`, `README.md`, `ROADMAP.md` |
| **ADR-020** | `vaccine-nurse-administration-handoff` · `queue-derived-handoff-state` | **39** |
| **ADR-026** | `llm-provider-allowlist` · `vaccine-two-part-billing-at-administration` | **30** — incl. `CLAUDE.md` |
| **ADR-030** | `llm-curated-tool-access` · `ai-patient-chat-persistence` | **30** — incl. `CLAUDE.md` |
| **ADR-028** | `narzim-central-ai-platform` · `lab-parameter-master` | **26** |
| **ADR-038** | `encounter-signing-assigned-practitioner-only` · `narrative-documents-with-embedded-values` | **13** |
| **ADR-027** | `ai-copilot-credit-metering` · `architecture-gap-remediation-roadmap` | **11** |

### Why this is not cosmetic

`CLAUDE.md` §9 states the rule: *"ADR in `/docs/adr/`. Use the template. **Number sequentially.**"*
It is violated seven times in its own directory, and the constitution itself is one of the ambiguous
citers:

- **CLAUDE.md's amendment block** cites *"ADR-018 (2026-06-30): Jurisdiction is now India + Mexico"*.
  A reader who opens `docs/adr/` and picks the other `adr-018-*` file reads about practitioner
  appointment visibility instead.
- **CLAUDE.md** cites *"ADR-026: LLM is no longer locked to a single vendor"*, while
  `encounter-screen.tsx`'s `buildSaveDraftPayload` comment cites *"ADR-026 (revised): per-order
  billing opt-in for the vaccine PRODUCT"*. **The constitution and the production code reference two
  different documents by the same number.**
- **CLAUDE.md** cites *"ADR-030: Rule 4 refined — curated LLM tool-calling"*, while
  `adr-034-encounter-chat-persistence.md` cites ADR-030 meaning chat persistence.
- **ADR-039 and `encounters/[id]/page.tsx`** both cite *"ADR-038's restriction"* — and there are
  two ADR-038s.

In a clinical system the ADR set is the record of *why* a safety-relevant decision was made. An
ambiguous citation is an unresolvable audit trail.

**Fix:** renumber the later of each pair to the next free number (042+), leave a one-line stub at the
old filename pointing to the new one, and update the citing files. Then enforce it (§7).

---

## 3. D2 — ADRs that are cited and do not exist

| Number | Cited by | What is missing |
|---|---|---|
| **ADR-008** | 7 files incl. `ROADMAP.md`, `api/ai/segments.py`, `adr-010`, `SYSTEM_DESIGN_FRONTEND.md` | The AI sidebar / overlay decision. `api/ai/sessions.py`'s docstring: *"ADR-008 — sidebar is a floating overlay; the channel name comes from `api.auth.REALTIME_CHANNEL_PREFIX`"* |
| **ADR-009** | **14 files incl. `CLAUDE.md`, `ROADMAP.md`, `api/ai/sessions.py`** | **The browser→Deepgram-direct audio decision.** `sessions.py` module docstring: *"Per ADR-009 (Proposed, 2026-05-15), audio bytes go browser → Deepgram directly; this module never sees audio."* This is the privacy architecture of the entire ambient-documentation feature |
| **ADR-040** | 7 files incl. `services/billing.py`, `WORK_LOG.md`, two frontend clients | A billing decision |

ADR-009 is the sharpest case. The claim "audio never reaches Frappe" is the foundation of the
LFPDPPP position for ambient recording. It is asserted in the constitution, asserted in a module
docstring, and **the document that decided it has never existed**. The decision may well be right;
it is simply unrecorded.

**Fix:** write the three missing ADRs from the evidence that already exists in the code and in
`CLAUDE.md`, or replace every citation with the real source. Do not leave a dangling reference to a
privacy decision.

---

## 4. D3 — Two ADR directories

| Directory | Files | Convention | Created |
|---|---|---|---|
| `docs/adr/` | 43 | `adr-NNN-slug.md` (lowercase) | 2026-05 onward |
| `remedisys_healthcare_ai/docs/adr/` | 4 | `ADR-NNN-slug.md` (uppercase) | all 2026-06-29 |

The nested directory holds `ADR-001-eb-role-naming`, `ADR-002-website-user-only`,
`ADR-003-bff-pattern`, `ADR-004-no-core-docperm` — and **two of those numbers already mean something
else** in the canonical directory:

| Number | `docs/adr/` | `remedisys_healthcare_ai/docs/adr/` |
|---|---|---|
| **003** | `no-core-modification` | `bff-pattern` |
| **004** | `frappe-v16-lock` | `no-core-docperm` |

ADR-001 and ADR-002 exist **only** in the nested directory, and are cited from the canonical one
(`adr-005`, `adr-007`) and from a migration patch (`patches/v0/fix_customer_role_desk_access_20260716.py`).
So a reader following a citation from `docs/adr/` has to know about a second directory that no index
mentions.

**Fix:** one ADR directory. Move the four, renumber 003/004 to free numbers, keep stubs.

---

## 5. D4 — Three sources of truth for permissions

| File | Lines | Self-description | git updated |
|---|---|---|---|
| `backend: docs/architecture/ROLES_AND_PERMISSIONS.md` | 405 | *"**Single source of truth** for roles, API access, and master data setup"* | 2026-06-20 |
| `frontend: docs/platform/ROLES_AND_PERMISSIONS.md` | 405 | **byte-identical copy** of the above, same claim | 2026-06-10 |
| `frontend: docs/architecture/ROLE_PERMISSIONS.md` | 272 | *"**Source of truth** for who can do what on the Frappe backend"* | 2026-06-22 |

Two problems, both live:

1. **A duplicated file across a repo boundary.** Content matches today; the git dates already differ
   by ten days. `CLAUDE.md` §9 makes exactly this argument for `WORK_LOG.md` — *"even work done in
   the frontend repo gets logged here, not in a second copy there… two logs drift apart"* — and then
   the permission model is kept in two copies anyway. Permissions are security-critical; a drifted
   copy is how a role gets granted twice or revoked once.
2. **Two documents in the same repo both claiming source-of-truth status on the same subject**, with
   different content, different names and different scopes. A reader cannot tell which one to trust,
   and the newer one (`ROLE_PERMISSIONS.md`, 2026-06-22) is the smaller.

Note also that `docs/security/EB_ROLE_AUTHORIZATION.md` (493 lines, 2026-08-19) and
`EB_ROLE_AUTHORIZATION_AUDIT.md` (1,733 lines) are newer than all three and orphaned — so the most
current permission analysis is the least discoverable.

**Fix:** the backend document is canonical. Delete the frontend copy and replace it with a one-line
pointer (the frontend `CLAUDE.md` already uses this pattern for `WORK_LOG.md`). Merge
`ROLE_PERMISSIONS.md`'s matrix into the canonical document as a generated section, or mark it
explicitly as "generated snapshot, not authoritative".

### The same pattern, four more times

| Subject | Competing documents |
|---|---|
| System design | `backend docs/architecture/SYSTEM_DESIGN.md` (505L) · `frontend docs/SYSTEM_DESIGN_FRONTEND.md` (225L) · `frontend docs/ai/SYSTEM_DESIGN.md` (259L) · `frontend docs/architecture/ARCHITECTURE.md` (279L) |
| Phases | `backend docs/planning/PHASES.md` (210L) · `frontend docs/delivery/PHASES.md` (357L) — **the copy is 70 % larger than the original** |
| Workflows | `backend docs/flows/WORKFLOWS.md` (301L) · `frontend docs/product/WORKFLOWS.md` (355L) |
| Contributing | `backend CONTRIBUTING.md` (208L) · `frontend CONTRIBUTING.md` (454L) |

`PHASES.md` is the worst of these: two divergent plans for the same delivery, and the larger one is
in the repo that `CLAUDE.md` says is not where planning lives.

---

## 6. D5 — Half the documentation is unreachable

| Repo | Orphaned | Total | Share |
|---|---|---|---|
| backend | 113 | 246 | 46 % |
| frontend | 44 | 79 | 56 % |
| **both** | **157** | **325** | **48 %** |

"Orphaned" = no other `.md` file links to it (root-level `README`/`CLAUDE`/`CONTRIBUTING`/`WORK_LOG`/
`ROADMAP` excluded).

**Every single ADR is orphaned**, because `docs/adr/` has **no index**. Forty-three architectural
decisions with no table of contents, in a directory whose numbering is ambiguous.

Largest orphans, all substantial and all invisible:

| Lines | Updated | File |
|---|---|---|
| 1,733 | 2026-08-19 | `docs/security/EB_ROLE_AUTHORIZATION_AUDIT.md` |
| 1,070 | 2026-06-24 | `docs/qa/FRONT_DESK_QA.md` |
| 1,036 | 2026-06-22 | `docs/WHATSAPP_INTEGRATION.md` |
| 984 | 2026-06-10 | `frontend docs/platform/API_PHASE_PLAN.md` |
| 586 | 2026-06-24 | `docs/qa/FRONT_DESK_FEATURES.md` |
| 523 | 2026-08-12 | `docs/REPORTS_API.md` |
| 494 | 2026-08-19 | `docs/audit/APPOINTMENT_FLOW_UI_GAPS.md` |
| 493 | 2026-08-19 | `docs/security/EB_ROLE_AUTHORIZATION.md` |

Three of the top eight were written **yesterday** and are already unreachable.

**Fix:** every directory under `docs/` gets a `README.md` index, and `docs/README.md` links to each.
An index entry is cheap; a 1,733-line audit nobody can find is not.

---

## 7. Other confirmed defects

### 7.1 Broken internal links (3)

| Source | Dead target |
|---|---|
| `frontend README.md` (×2) | `./docs/delivery/SESSION_RECOVERY.md` |
| `frontend docs/AUTH.md` | `./AUTH_FLOW.md` |

### 7.2 Self-reported dates that disagree with git (7 real, excluding today's uncommitted edits)

| File | Claims | git says | Drift |
|---|---|---|---|
| `docs/architecture/SYSTEM_DESIGN.md` | 2026-06-19 | 2026-07-16 | **27 days** |
| `docs/flows/IMMUNIZATION_PROCESS.md` | 2026-06-18 | 2026-07-03 | 15 days |
| `docs/architecture/ROLES_AND_PERMISSIONS.md` | 2026-06-10 | 2026-06-20 | 10 days |
| `docs/WHATSAPP_INTEGRATION.md` | 2026-06-20 | 2026-06-22 | 2 days |
| `docs/flows/WORKFLOWS.md`, `docs/planning/PHASES.md`, `docs/planning/PLANNING.md` | — | — | 1 day each |

A hand-maintained "Last updated" line is unreliable by construction. This is precisely what the new
provenance-header rule addresses — and why `--fix` derives dates from `git log` rather than guessing.

### 7.3 Fifteen documents still assert that AI is deferred

Contradicted by production (AI shipped ~2026-07-23; the encounter audit measured 137 AI sessions,
13,631 transcript segments, 1,897 prompt-log rows):

`CLAUDE.md` · `ROADMAP.md` · `docs/ai/REMEDISYS_AI_ARCHITECTURE_EXPLAINED.md` ·
`docs/ai/DECISION_LOG.md` · `docs/ai/CURRENT_SYSTEM_AUDIT.md` ·
`docs/adr/adr-026-llm-provider-allowlist.md` · `docs/audit/ALIGNMENT_CAPSTONE.md` ·
`docs/audit/practitioner/README.md` · `docs/audit/practitioner/screens/03-encounter.md` ·
`docs/audit/practitioner/screens/04-medications.md` ·
`docs/audit/practitioner/screens/DECISION_SHEET.md` ·
`docs/audit/nurse/screens/07-encounter-draft.md` · `docs/audit/nurse/screens/DECISION_SHEET.md` ·
`docs/audit/frontdesk/screens/04-patient-chart.md` ·
`docs/audit/frontdesk/screens/FE_BUILD_PLAN.md`

Several are *historical records* and should keep their stale text (an audit dated July should read as
July). The distinction the corpus does not currently make is **living document vs point-in-time
record**. Living documents must be corrected; records must be dated and frozen. The provenance header
plus an explicit `Status:` field solves this.

### 7.4 Generated artefacts committed as documentation

`frontend playwright-report/data/f210e9d83a7a35d26f70064a2a968395e001e43e.md` (167 lines) — a test
artefact in the doc corpus. `playwright-report/` should be gitignored.

---

## 8. Enforcement

Two checkers, both intended as CI gates. A rule nothing checks is not a rule — the encounter audit
found `enable_safety_validators`, a setting that gates nothing, and the same failure mode applies to
documentation standards.

| Script | Checks |
|---|---|
| `scripts/check_md_headers.py` | Every `.md` has an H1, a `**Created:/Updated:/Version:**` provenance line, and a `## Revision history` section. `--fix --author <name>` backfills using real `git log` dates. `--report` for a non-failing inventory |
| `scripts/check_adr_numbering.py` | No duplicate ADR numbers · no ADR cited in code or docs without a file · exactly one ADR directory · an index exists and lists every ADR |

Current state: `check_md_headers.py --report` → **241 of 246 backend files non-compliant** (the rule
is new; five files were brought into compliance today). `check_adr_numbering.py` → **9 collisions,
3 phantom ADRs, 2 directories, no index**.

---

## 9. Recommended actions, in order

| # | Action | Why first |
|---|---|---|
| **A1** | Renumber the 9 colliding ADRs; add stubs at the old paths; fix the citing files | An ambiguous decision record is an unresolvable audit trail |
| **A2** | Write ADR-008, ADR-009, ADR-040 — or remove the citations | ADR-009 is the privacy foundation of ambient recording and does not exist |
| **A3** | Consolidate to one ADR directory; add `docs/adr/README.md` as an index | 43 orphaned decisions |
| **A4** | Delete `frontend docs/platform/ROLES_AND_PERMISSIONS.md`; replace with a pointer. Reconcile `ROLE_PERMISSIONS.md` | Two drifting copies of a security-critical model |
| **A5** | Pick one owner per duplicated subject (system design, phases, workflows, contributing); the loser becomes a pointer | Four architecture documents is zero architecture documents |
| **A6** | Add a `README.md` index to every `docs/` subdirectory | 48 % orphan rate |
| **A7** | Backfill provenance headers: `check_md_headers.py --fix --author "<name>"` per repo, then review the diff | Makes the new rule real |
| **A8** | Add a `Status:` field distinguishing **living** from **record** documents; correct the living ones, freeze the records | Resolves the 15 stale AI claims without falsifying history |
| **A9** | Fix the 3 broken links; gitignore `playwright-report/` | Cheap |
| **A10** | Wire both checkers into CI | Otherwise this audit is itself a document nobody enforces |

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial audit — 325 files inventoried; ADR governance, duplication, orphan and staleness findings |
