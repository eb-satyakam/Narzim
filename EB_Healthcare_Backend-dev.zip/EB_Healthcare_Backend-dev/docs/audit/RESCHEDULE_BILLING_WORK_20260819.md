# Reschedule & billing — work log, 2026-08-19

**Doc status:** record · **Created:** 2026-08-19 by Anant Sharma · **Updated:** 2026-08-19 by Sarvesh-SocialAngel · **Version:** 1.0

Single session. Started from one screenshot ("this refund looks wrong"), ended
with nine defects fixed across the reschedule and billing paths, and ten gaps
documented.

Scope: `remedisys_healthcare_ai` (backend) and `remedisys-ai-ehr` (frontend).
Nothing committed in either repo.

Patient names omitted throughout; appointment and invoice IDs are the dev-site
records used as evidence.

---

## 1. What started it

The reschedule drawer offered a **900 MXN refund** on an appointment where the
patient actually owed **1,740 MXN**. Three different numbers were in play:

| | Correct | Drawer showed | Backend would have done |
|---|---|---|---|
| Previous consultation fee | 580 | 2,900 | 2,900 |
| Already paid | 580 | 2,900 | 2,900 |
| New consultation fee | 2,320 | 2,000 | 2,320 |
| **Settlement** | **collect 1,740** | **refund 900** | **refund 580** |

Two independent causes, both since fixed (§2.1, §2.2).

---

## 2. Defects fixed

### 2.1 Shared invoices attributed whole to each appointment 🔴

`ACC-SINV-2026-00234` covers **two** appointments (500 + 2,000 + IVA = 2,900).
Core Healthcare stamps that one invoice onto every referenced appointment's
`ref_sales_invoice` (`healthcare/utils.py::set_invoiced`), so both reported
2,900 as their own charge.

Could invert a fee **increase** into a refund.

**Fix** — `services/billing.py::appointment_invoice_share`: an appointment's
share of an invoice, prorated on line `net_amount`, tax-inclusive. Collapses to
today's behaviour on a 1:1 invoice.

```
HLC-APP-2026-00106  billed 580.0   paid 580.0
HLC-APP-2026-00100  billed 2320.0  paid 2320.0
                    ── reconstitutes 2900 exactly ──
```

### 2.2 Pre-tax and tax-inclusive figures compared directly 🔴

The drawer showed the raw `op_consulting_charge` (pre-tax) next to
tax-inclusive cash and subtracted them. IVA at 16% vanished.

**Fix** — `services/billing.py::consultation_fee_with_tax`: one place that
converts. Both the preview and the settlement read it.

### 2.3 No preview endpoint — the drawer did its own arithmetic 🔴

Step 3 of the reschedule drawer computed the settlement client-side from
`get_appointment`'s invoice-level billing block. It disagreed with what
Continue then charged.

**Fix** — `preview_reschedule_payment`, sharing `_reschedule_quote` with
`reschedule_appointment_with_payment`. Structurally unable to diverge.
Contract: `docs/api/RESCHEDULE_PAYMENT_PREVIEW_SPEC.md`.

### 2.4 Collected pay-later deltas were invisible 🟠

`total_paid_for_appointment` counted prior adjustments only when
`adjustment_status` was `Paid`/`Refunded`. Nothing in the app ever writes that
field after insert — grep found exactly one writer, at creation. A delta
invoice collected through the billing screen stayed `Pending` forever and its
money never counted, so the next reschedule billed for it again.

**Fix** — measure prior adjustments from their own documents, never the flag.

### 2.5 Refunds could not span invoices 🔴

An appointment's money sits on its original invoice **plus one delta invoice
per prior fee increase**. `total_paid_for_appointment` aggregated all of them;
`_create_reschedule_refund` could only reverse `ref_sales_invoice`. Result on
`HLC-APP-2026-00123`: 2,320 paid, 1,740 owed back, only 580 reachable — core
rejected the oversized return with *"Rate cannot be greater than the rate used
in Sales Invoice …"* and the reschedule aborted.

**Fix** — `_appointment_funding` is now the single definition of where an
appointment's money sits; `total_paid_for_appointment` is the sum of its
sources and `appointment_refund_sources` is the same list capped per source.
`_allocate_reschedule_refund` draws newest-source-first, one Credit Note per
invoice touched.

### 2.6 POS-booked refunds paid out short 🔴

The tax back-out read the row's **Item Tax Template** rate. A template only
modulates a header-level tax row, and core's `create_sales_invoice` never sets
one — so `ACC-SINV-2026-00579` had `item_tax_template = "Mexico Tax - CPMX"`,
empty header taxes, `grand_total == net_total == 750`. Dividing by 1.16 paid
**347 against an intended 402** while the history row recorded the full 402. A
silent 55-peso shortfall on every POS-booked refund.

**Fix** — derive from the invoice's own realised multiplier, then correct
against the draft total. Exact for any tax configuration.

### 2.7 A one-centavo residue could brick an invoice 🟠

The value-sized return takes a whole line at `qty=-1`, so a partial-value
refund consumes that line's entire returnable quantity. A 1-cent rounding
residue spilled onto a second invoice burned its full refundability.

**Fix** — `_returnable_value` caps each source by quantity as well as cash, and
`_SETTLEMENT_TOLERANCE = 0.05` stops the allocator chasing sub-coin residue.
Five centavos is below the smallest coin in circulation and above per-document
rounding.

### 2.8 Pay-later double billing 🔴

Reproduced live: pay-later booking (500 stamped, no invoice) → reschedule to a
750 doctor → front desk collects normally:

```
reschedule → Additional Payment 870, invoice ACC-SINV-2026-00700, Pending
AFTER:  invoiced=0   ref_sales_invoice=None   paid_amount=500
collect → SECOND invoice ACC-SINV-2026-00701 total=500
>>> 870 + 500 = 1,370 billed for one 870 visit
```

Also: `Patient Appointment.paid_amount` — the stamped **fee**, despite the name
— was never updated by a reschedule, so the second invoice charged the stale
500. Core bills `paid_amount or practitioner_charge`.

**Fix, two parts:**
- `paid_amount` now follows the new practitioner on every reschedule.
- **A reschedule no longer invoices a never-invoiced appointment at all.** The
  fee simply changes and checkout bills it through the normal cart. This
  removes the double-billing risk at its source rather than guarding it, and
  restores the checkout cart (see §2.9). An appointment that *is* invoiced but
  unpaid still gets its delta settled — that invoice was cut at the old fee.

### 2.9 The checkout cart was empty after a pay-later reschedule 🟠

`get_patient_billables` returns only **unbilled** services. Once the reschedule
had invoiced the consultation there was nothing left to put in the cart, so
"Pay now" opened a blank New Sales Invoice on a patient who owed 2,320.

Fixed by §2.8 — no invoice is raised, so the cart populates at the new rate:

```
1. pay-later booking (fee 500):  invoiced=0  ref=None  paid_amount=500
2. reschedule to the 750 doctor: adjustment {"type": "None"}, no invoice
                                 invoiced=0  ref=None  paid_amount=750
3. cart: General Consultation  qty 1  rate 750.0
4. invoices raised: 0
```

### 2.10 Appointment billing ignored delta invoices 🔴

`_billing_for` read only `ref_sales_invoice`. On `HLC-APP-2026-00173` that
meant a green **✓ Paid — MXN 580** badge over an unpaid 1,740 delta invoice,
while the patient's Billing tab correctly showed 1,740 outstanding. Two screens,
two answers.

**Fix** — `_billing_context` / `_billing_for` now aggregate the whole chain,
apply the appointment's share of a shared invoice, and filter `docstatus: 1`
(a cancelled invoice used to report a phantom receivable). Batched: three
queries per page, not per row.

```
HLC-APP-2026-00173  total 2320  paid 580  outstanding 1740  Pending
```

The **dashboard** had its own copy of this logic keyed on `ref_sales_invoice`;
it now calls the shared helper, and its KPIs sum per-appointment figures so a
shared invoice contributes each appointment's share exactly once.

### 2.11 Stale reschedule drawer reassigned patients silently 🔴

`invalidateAll` invalidated `["appointments"]` but not the **singular**
`["appointment", id]` key that the reschedule drawer reads — the two don't
prefix-match. The drawer seeded its practitioner picker from that stale cache
at mount, so reopening it offered the doctor from *before* the last reschedule.
Changing only the time and pressing Continue **silently moved the patient back
to the previous doctor and billed the difference**.

Observed on `HLC-APP-2026-00173`: `Moisés → Adrián`, then 16 minutes later
`Adrián → Moisés` with a 1,740 charge nobody intended.

**Fix** — invalidate the singular key; gate the drawer on `isFetching` not just
`isLoading`; key `NewAppointmentDialog` on the appointment's identity so its
`useState` initialisers re-run.

### 2.12 Pay now dead ends and navigation

- Patient-mode Pay now showed only the unbilled cart; with the cart legitimately
  empty it opened a blank invoice. Now falls through to the single outstanding
  invoice — **no new UI**, it renders the page's existing `outstandingInvoices`
  section. Covers both routes in (the sheet's prescope and the
  `?patient=…&prefill=1` deep link the dashboard button actually uses).
- The invoice-resolution effect was a one-shot latched on `patient`, so late or
  corrected data was never consulted. Replaced with a pure derivation.
- Discard left `?prefill=1` in the URL, so a refresh silently re-opened a
  drawer the user had discarded. Params are now cleared, and a Pay now started
  from the dashboard returns there (`from=dashboard` + `router.back()`).

---

## 3. Schema

**New child doctype `Appointment Reschedule Refund`** — `source_invoice`,
`credit_note`, `payment_entry`, `amount`. A refund spanning two invoices
produces two Credit Notes; `Appointment Reschedule History.refund_credit_note`
is a single Link and now holds the primary only, with
`refund_breakdown` carrying the full set.

Backfill: `patches/v0/backfill_reschedule_refund_breakdown_20260819.py`,
idempotent. `bench migrate` ran clean.

---

## 4. Deliberate decisions

| Decision | Why |
|---|---|
| `_SETTLEMENT_TOLERANCE = 0.05` | Below the smallest MXN coin, above per-document rounding. Chasing a centavo across invoices destroys refundability. |
| Reschedule does not invoice an uninvoiced appointment | Matches what "pay later" means, keeps the checkout cart working, removes double billing at source. |
| Delta invoices carry no `reference_dt`/`reference_dn` | Core's `validate_invoiced_on_submit` would throw, and `set_invoiced` would repoint `ref_sales_invoice` at each new delta — breaking refund allocation. |
| Refund allocation is newest-source-first | Reversing the most recent change is what a reschedule-back is. Oldest-first would refund the base consultation and leave a later upgrade standing. |
| `_billing_for` keeps invoice-level keys, adds `invoices[]` | Non-breaking for existing consumers. |

---

## 5. Still open

| | Gap | Severity |
|---|---|---|
| **G-a** | A waived (Government) appointment is billed the **full fee** on reschedule. `_apply_waiver` zeroes the invoice, so `total_paid` reads 0 and the delta comes out as the whole new fee. Verified: waived invoice `grand_total=0` → reschedule → Additional Payment 870. | 🔴 |
| **R-3** | Cancelling an appointment doesn't sweep delta invoices — `cancel_unpaid_invoice_for_appointment` reads only `ref_sales_invoice`. Two live `Pending` rows on the dev site. | 🔴 |
| **G-c** | Insurance is ignored by the delta invoice path — the patient is billed 100% of the difference with no payor split. Code-verified, not reproduced (no insured appointments on this site). | 🟠 |
| **R-4** | A date-only reschedule is allowed after the encounter exists. The practitioner-change path blocks it; a pure date/time move doesn't. 2 such appointments on this site. | 🟠 |
| **R-5** | No past-date validation anywhere — core's `validate()` doesn't check it and neither endpoint adds one. | 🟠 |
| **R-6** | No row lock. The idempotency check reads the newest history row without `for update`, so two concurrent confirms can both settle. | 🟠 |
| **R-7** | The patient portal's `reschedule_my_appointment` writes date/time directly — no history row, no fee settlement, no encounter or past-date guard. | 🟡 |
| **R-8** | Delta invoices have no queryable appointment link — only free-text `remarks`. Traceable via `Appointment Reschedule History`, not from the invoice. | 🟡 |
| **R-9** | Rescheduling notifies nobody. Booking sends a WhatsApp reminder; moving the appointment tells the patient nothing. | 🟡 |
| **G-07** | Reschedule history is unreachable — no BFF route, no UI. We now write a richer audit trail nobody can read. | 🟠 |

Also noted, outside this flow:
- `test_auth::test_practitioner_user_returns_practitioner_data` sets
  `"user": …` on Healthcare Practitioner; the real field is **`user_id`**
  (see `admin/staff.py::_ensure_practitioner_profile`). Self-contained fixture
  bug, unrelated to this work.
- Six reschedule tests assume a tax-free site while this one applies IVA 16%.
  Their fixtures need a pass; failures are identical with and without all of
  the above.
- Pay now still can't handle a patient with **several** outstanding invoices —
  needs a list UI and a product decision.

---

## 6. Files changed

### Backend — `remedisys_healthcare_ai`

```
 api/v1/appointments/api.py                              419 +++++---
 api/v1/dashboard/api.py                                 147 +++----
 services/billing.py                                     484 ++++++---
 tests/appointments/test_reschedule_payment.py           423 +++++++
 tests/dashboard/test_dashboard.py                       144 +++----
 .../appointment_reschedule_history.json                   9 +
 6 files changed, 1358 insertions(+), 268 deletions(-)
```

New:
- `remedisys_healthcare_ai/doctype/appointment_reschedule_refund/`
- `patches/v0/backfill_reschedule_refund_breakdown_20260819.py`
- `docs/api/RESCHEDULE_PAYMENT_PREVIEW_SPEC.md`

Key additions in `services/billing.py`: `appointment_invoice_share`,
`consultation_fee_with_tax`, `_appointment_funding`, `appointment_refund_sources`,
`_returnable_value`, `_allocate_reschedule_refund`, `_credit_note_refunded_cash`,
`_SETTLEMENT_TOLERANCE`.

In `api/v1/appointments/api.py`: `_billing_context`, `_reschedule_quote`,
`preview_reschedule_payment`, `_new_fee_tax_breakdown`.

### Frontend — `remedisys-ai-ehr`

```
 messages/en.json                                     21 +-
 messages/es.json                                     21 +-
 app/(clinic)/billing/billing-client.tsx              23 +-
 components/narzim/dashboard/mission-control-client.tsx  5 +-
 components/narzim/dashboard/new-appointment-dialog.tsx 553 +++++-----
 components/narzim/dashboard/reschedule-dialog.tsx    23 +-
 hooks/use-appointments.ts                            16 +-
 lib/api/appointments.ts                              30 +-
 types/appointments.ts                                34 +
```

New: `hooks/use-reschedule-payment-preview.ts`,
`app/api/appointments/[id]/reschedule-payment-preview/route.ts`.

**`app/(clinic)/billing/invoices/new/new-invoice-client.tsx` is identical to
dev** — an earlier attempt added line-item UI to `OutstandingInvoiceRow`; it was
reverted in full at the request of the repo owner. No design changes anywhere:
the frontend diff contains no markup or styling lines.

---

## 7. Test status

| Suite | Result |
|---|---|
| `tests/appointments/test_reschedule_payment` | **22 / 22 pass** (14 new cases) |
| `tests/dashboard/test_dashboard` | 36 ran, 0 failures (13 rewritten for `_attach_billing`) |
| `tests/billing/test_billing` | 5 ran, 0 failures |
| `tests/auth/test_auth` | 6 ran, 1 pre-existing failure |
| Frontend `vitest` | 70 passed |
| Frontend `tsc --noEmit` | clean (one pre-existing error in `e2e/encounter-submit.spec.ts`) |
| Frontend `eslint` | no new errors in any touched file; two files improved by one warning |

Seven older reschedule tests fail identically **with and without** every change
above — verified by stashing the source and re-running. Their fixtures assume a
tax-free site.

### Harness note

`bench run-tests` cannot start on this site for **any** module — `before_tests`
dies on a pre-existing `Fiscal Year 2026-2027` overlap. All backend results
above were produced by driving the `FrappeTestCase` classes directly in a bench
console. Worth fixing before relying on CI here.

---

## 8. Data left to reconcile on the dev site

- `HLC-APP-2026-00100` — orphan `Pending` history row `9j4s8l0sd4`, delta 2,000,
  whose invoice `ACC-SINV-2026-00204` is unpaid and now correctly shows as
  outstanding.
- `HLC-APP-2026-00173` — 1,740 outstanding from the unintended
  stale-picker reassignment (§2.11). Rescheduling back to the original
  practitioner will now compute a correct 1,740 refund drawn from
  `ACC-SINV-2026-00387`.
- No audit yet of how many other appointments share an invoice.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-19 | Sarvesh | Initial version (header backfilled from git history) |
