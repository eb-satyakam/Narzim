# Help & Support request form — production-readiness audit

**Doc status:** record · **Created:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-08-24 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 1.0

> A dated snapshot of the Help & Support ticket form as shipped on
> `feat/helpdesk-integration` (backend `fa55676`, frontend `24a7de0`), audited against three
> references: **Frappe Helpdesk's own customer portal form**, **this codebase's own conventions**,
> and what a production in-app support widget is expected to do. It is `record` status — frozen
> evidence of 2026-08-24, not a living spec. The design it audits is in
> [`../planning/2026-08-24-helpdesk-integration-plan.md`](../planning/2026-08-24-helpdesk-integration-plan.md).

---

## 1. Verdict

**The integration is sound. The form is a thin slice, and it shows.** It creates a real
`HD Ticket` with attachments, correct attribution, SLA and permission gating — that part is
verified and right. What is missing is almost everything that makes a support request *actionable
for the agent* and *followable by the clinician*.

| Severity | Count | Meaning |
|---|---|---|
| **P0** | 8 | Ship-blocking for a clinic. A support desk with these gaps generates more work than it resolves |
| **P1** | 12 | Materially degrades the request or the agent's ability to act |
| **P2** | 5 | Polish |

The single most consequential finding is **A2**: a ticket arrives with no idea which screen the
clinician was on. Every ticket therefore starts with a round trip that the browser already knew the
answer to.

**This audit recommends no code changes yet.** Findings are sequenced in §9 for a decision.

---

## 2. Method

- Read the shipped implementation: `api/v1/support/api.py`, `services/support.py`,
  `src/components/help/support-request-form.tsx`, `help-drawer.tsx`,
  `src/app/api/support/{tickets,availability}/route.ts`.
- Compared field-for-field against Helpdesk's own portal form,
  `apps/helpdesk/desk/src/pages/ticket/TicketNew.vue` — which is template-driven and **does** expose
  `priority`, ticket type and a rich editor with inline media.
- Compared against this repo's own conventions: analytics on comparable flows
  (`encounter.signed`, `prescription.created`), `CLAUDE.md` §13 i18n and UX rules, Rule 10.
- Exercised the live form in a browser (ticket `0006`) and the route directly (tickets `0004`,
  `0005`, `0007`).

**Not covered:** load/perf, penetration testing, and the Helpdesk agent-side experience.

---

## 3. What is already right

Stated first because a findings list alone misrepresents the state.

| | |
|---|---|
| Native `HD Ticket`, no custom doctype, nothing to synchronise | verified end to end |
| Permission checked **before** any file is written | a user without the role writes nothing |
| Attachments stored private (`is_private = 1`) | a support screenshot is a PHI screenshot |
| Description HTML-escaped | `<script>alert(1)</script>` stored inert |
| Attachment keeps the sender's filename | fixed after being found live |
| Availability gating | the form is not offered to someone who cannot send it |
| `en` + `es-MX` parity, no hardcoded strings | `CLAUDE.md` §13.10 |
| PHI warning in the form | states the risk where the risk is taken |

---

## 4. Findings — A. Ticket quality (what support receives)

### A1 · P0 · No priority
`HD Ticket.priority` exists and Helpdesk's own portal exposes it; ours does not, so **every ticket
is created `Medium`** by SLA default. A clinician cannot say "this is blocking me right now".

**USER STORY.** Dr. Bracamontes cannot sign any encounter — the whole clinic is stalled → she files
a ticket → **the system shows** it as Medium, indistinguishable from "the avatar is the wrong
colour" → **the queue actually contains** both at the same priority → **consequence:** an agent
triages by arrival order and a clinic sits blocked for hours.

**Effort:** small — one Select, one backend parameter.

### A2 · P0 · No EHR context whatsoever
The plan's §8 zero-customization interim — a context block appended to the description — **was not
implemented**. The ticket carries subject, body and files, and nothing else.

**WHY it matters most:** the drawer already calls `usePathname()`. The browser knows the route, the
encounter id, the app build and the user agent. Not sending them means the agent's first action on
every ticket is to ask a question the client could have answered for free.

**EXAMPLE — ticket `0006` as the agent sees it:**
```
subject     : E2E — prescription drawer will not save
description : Clicked Save in the Rx drawer. Nothing happened & no error
attachments : bug-screenshot.png
--- and nothing about: which screen · which encounter · which browser · which build
```

**Effort:** small for the description block; the structured version needs Custom Fields (plan §8).

### A3 · P1 · No ticket type or category
Every ticket is `Unspecified` (the default set on 2026-08-24). Triage has nothing to sort or route
by, and Helpdesk's Assignment Rules have nothing to key on.

### A4 · P1 · No console or network error capture
Production widgets attach the last N console errors and failed requests. We attach none, so a
JavaScript exception that the clinician never saw is invisible to support.

### A5 · P2 · No browser/device or app-version string
Subsumed by A2, listed separately because it is the cheapest half of it and answers "is this user on
a stale build?".

---

## 5. Findings — B. Interaction

### B1 · P0 · Cannot paste a screenshot
The overwhelmingly common way to capture a bug on macOS and Windows is a keyboard shortcut that puts
the image **on the clipboard**. Our form has a file picker only, so the user must save to disk, find
the file, and browse to it — three steps that did not need to exist. No `paste` handler exists.

**USER STORY.** A nurse presses Cmd+Shift+4, drags a box round the error, opens the form, presses
Cmd+V → **nothing happens** → she gives up on the screenshot and describes it in words → the agent
cannot reproduce it.

**Effort:** small — one `onPaste` on the form.

### B2 · P1 · No drag-and-drop onto the drop zone
The zone is styled as a drop target (dashed border) but only responds to a click. It looks like it
accepts a drop and does not.

### B3 · P1 · No thumbnail or preview
An attachment renders as a filename chip. The user cannot confirm they attached the right screenshot
— and with a screenshot of a patient chart, "the right one" matters for PHI, not just for accuracy.

### B4 · P1 · No client-side size guard, no size shown
The server-side ceiling is 10 MB per file (`max_file_size` unset). The client sends anything, so an
oversized file is a failed upload after the wait, surfaced as a generic error.

### B5 · P1 · No upload progress
`fetch` with no progress reporting; the only feedback is a button spinner. On clinic wifi an 8 MB PDF
looks indistinguishable from a hang.

### B6 · P1 · The draft is destroyed silently
Closing the drawer resets the view to help (by design, so stale input is not reopened) — but there is
**no confirmation and no persistence**. Escape, a mis-click outside, or the close X discards a
half-written report with a screenshot attached.

### B7 · P1 · Subject truncates silently at 140 characters
`maxLength={140}` with no counter and no message. A clinician typing a long sentence simply stops
being able to type, mid-word.

### B8 · P2 · 360 px drawer is cramped
Subject, a 5-row textarea, an attachment list and a PHI notice inside 360 px. Helpdesk's own portal
gives the same form a full page.

### B9 · P2 · No autofocus on Subject
The user must click before typing, every time.

---

## 6. Findings — C. After submit

### C1 · P0 · The clinician cannot follow their own ticket
On success the form shows *"Your ticket is 0006"* — a number, with **no link, no status, and no
list**. There is no "My requests" view. The user cannot see whether anyone replied, cannot add
information, and cannot reopen.

**WHY this is P0:** it is the difference between a support desk and a suggestion box. A clinician who
cannot see progress files again, or stops filing.

### C2 · P1 · No notification when support replies
Helpdesk can email, but our staff are Website Users inside the EHR and the app has its own
notification surface. A reply currently lands where nobody is looking.

### C3 · P2 · No "file another request"
The success state's only action is back-to-help.

---

## 7. Findings — D. Accessibility and robustness

### D1 · P1 · State changes are not announced
The error line has `role="alert"`, which is right. The **success** state is not announced and focus
is not moved, so a screen-reader user is told nothing after submitting.

### D2 · P1 · No focus management across the view switch
Switching help → form → sent moves nothing. Focus stays wherever it was.

### D3 · P2 · Attachment list is not a labelled group
Remove buttons carry `aria-label`; the list itself has no accessible name or count.

---

## 8. Findings — E/F/G. Contract, observability, tests

### E1 · P0 · No rate limit on ticket creation
`create_support_ticket` has no throttle. A retry loop, a stuck client, or one frustrated user can
create unbounded tickets, each with up to five 10 MB files. Nothing in the path — BFF or backend —
bounds it.

**Effort:** small — Frappe's own rate-limit decorator or a per-user count check.

### E2 · P1 · No description length cap
A pasted stack trace or log becomes an unbounded Text Editor value. The subject is capped; the body
is not.

### E3 · P1 · No source marker on the ticket
`via_customer_portal` is set by Helpdesk for both our route and its own portal, so **you cannot tell
an EHR-filed ticket from any other** in reporting. A tag or a field would answer "how many requests
come from inside the product?".

### E4 · P2 · Upstream error text reaches the UI in dev
By design in `frappeErrResponse` (dev shows the real message, prod is generic). Correct, but worth a
deliberate confirmation for this endpoint since the message is rendered verbatim to a clinician.

### F1 · P1 · No analytics event
Comparable flows emit `auth.logged_in`, `encounter.signed`, `prescription.created`. Support emits
nothing, so **adoption and failure rate are unmeasurable** — including how often the form 403s or
errors, which is exactly what we would want to know in week one.

### G1 · P0 · No frontend test for the component
The repo has 168 vitest tests; **none** touch this form. Subject validation, the file cap, the
disabled-submit rule, the error path and the success state are all unguarded against regression.

### G2 · P1 · No committed e2e spec
The Playwright flow that verified this lives in a scratchpad, not in `e2e/`. It cannot be committed
as-is: every existing spec hardcodes a password, and two of them name users that do not exist on this
site — see G3.

### G3 · P0 · The backend suite cannot currently run on `marley.local`
Not caused by this feature, and it blocks verification of everything above.
`erpnext/tests/utils.py:2989` runs `BootStrapTestData()` **at import time**; its
`make_records` skip-check compares `currency`, and this site's `Standard Buying` price list is
**MXN** where ERPNext's test data expects USD — so it tries to insert a row that already exists and
dies on the primary key. Proven independent of this work: `tests.billing.test_billing`, untouched,
fails identically. `--skip-before-tests` does not help, because the trigger is an import side effect.
Vendored ERPNext code, so per `RULES.md` it must not be edited.

---

## 9. Recommended sequencing

Grouped so each block is independently shippable. Effort is rough developer-days.

| Block | Findings | Effort | Why this order |
|---|---|---|---|
| **1. Make tickets actionable** | A1 priority · A2 context block · A3 type | ~1.0 | Highest value per hour, no new UI patterns, and it stops the round-trip on every ticket |
| **2. Make capture natural** | B1 paste · B2 drop · B3 thumbnails · B7 counter · B4 size guard | ~1.0 | B1 alone changes whether screenshots get attached at all |
| **3. Close the loop** | C1 my-requests list · C2 notification | ~2.0 | Turns it from a suggestion box into a desk. Needs plan §12 decision 1 first, since the list is exactly the read-scope question |
| **4. Guard it** | E1 rate limit · E2 body cap · E3 source marker · G1 component tests | ~1.0 | Do before real users, not after |
| **5. Trust the pipeline** | G3 harness · G2 e2e spec · F1 analytics | ~1.0 | G3 blocks verifying anything else; it is environmental and can run in parallel |
| **6. Polish** | B5 progress · B6 draft · B8 width · B9 autofocus · D1–D3 · A4 · A5 | ~1.5 | After the above |

**Decisions required before block 3:** plan §12 decision 1 (ticket read scope) and decision 3
(description block vs Custom Fields — A2 can ship either way, but A3's filterability cannot).

---

## 10. What this audit deliberately does not claim

- **No load, security-penetration or agent-side review was done.**
- **Findings are not bugs in the agreed slice.** Voice note, EHR context and a my-requests list were
  explicitly out of scope; A2, A4 and C1 are recorded here because the *product* needs them, not
  because the slice failed to deliver them.
- **Nothing above was fixed.** No code changed for this audit.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-08-24 | Sarvesh-SocialAngel (AI-assisted) | Audited the shipped Help & Support form against Helpdesk's own portal, repo conventions and production expectations: 8 P0, 12 P1, 5 P2, sequenced into six blocks |
