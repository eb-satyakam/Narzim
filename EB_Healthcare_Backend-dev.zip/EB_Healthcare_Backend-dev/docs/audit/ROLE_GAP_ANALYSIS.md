# Role-by-Role Gap Analysis — Front Desk · Nurse · Practitioner · Clinic Admin

**Doc status:** record · **Created:** 2026-07-18 by Anant Sharma · **Updated:** 2026-07-18 by Sarvesh-SocialAngel · **Version:** 1.0

**Date:** 2026-07-16
**Method:** each role was re-tested against the *current* code in this repo (`git log`, DocPerm fixtures, `api/v1/*` handlers) and cross-checked against the prior audit corpus (`docs/audit/{frontdesk,nurse,practitioner,settings}/`, `docs/qa/*.md`, `docs/audit/ALIGNMENT_CAPSTONE.md`). Frontend (`Healthcare_next_app` / `remedisys-web`) is a separate repo **not present in this environment** — all UI/frontend findings below are carried from the prior audits and are labeled as such, not re-verified this session.
**Status legend:** `CONFIRMED` = re-checked in today's code · `NO-LONGER-TRUE` = fixed since the audit was written · `STALE/UNVERIFIED` = not re-checked this pass, treat prior audit as the source · `NEW` = introduced since the last audit, not yet covered by any audit doc.

---

## 0. Cross-role patterns (read this first)

The same four root causes recur in every role below — fixing them once closes gaps across all four:

1. **DocPerm over-grants vs. the flow's own safety model.** `patches/v0/eb_docperm_spec.json` grants `Lab Test submit` to `EB_Front Desk`, `EB_Nurse`, **and** `EB_Practitioner` alike — any of the first two can finalize a lab result, not just the physician. Also `EB_Front Desk` holds `read`/`export` on `Patient Encounter`, `Vital Signs`, and `EB Clinic Settings` — PHI exposure to a non-clinical role. This is one fixture file; fixing it closes confirmed Rule 6 (physician-in-control) and PHI-exposure findings for Front Desk, Nurse, and Practitioner simultaneously.
2. **Fabricated AI/risk UI shown pre-Phase-5.** A `patHash`-driven "High Readmission Risk" banner and AI insights render on the live Patient Chart for Front Desk and Practitioner (worst possible audience — a physician trusting a fake risk score). This is a direct violation of CLAUDE.md's Phase-5 lock. Frontend-only, not re-verified this session, but was Critical-severity in the last audit pass.
3. **Reimplemented-vs-composed drift.** Check-in queue, slot generation, and patient history timeline are hand-rolled instead of calling ERPNext Healthcare's native equivalents (`position_in_queue`, core slot algorithm, `Patient Medical Record`). Not breakage today, but upgrade-drift risk against Rule 1.
4. **Money/config surfaces still desk-only or mocked**, cutting across Front Desk and Clinic Admin: cash drawer/shift has no backend at all (ADR-023 still `Proposed`), `Healthcare Settings` has no whitelisted API, tax/fiscal setup is desk-only, and the frontend Integrations panel is a static placeholder.

The repo is moving: since the audits were written (early-to-mid July), the **Sales Invoice editor and outstanding-balance-on-patient-row gaps have already been closed** (see Front Desk §1), and a **new admin-only demo-data generator** was added today with a live bug (see Clinic Admin §4). Both are called out below.

---

## 1. Front Desk

### Can do (backend verified real, not mock)
- Register/search patients, manage guardians — `patients/api.py`.
- Book appointments atomically with real slot data, pay-now/pay-later/insurance — `appointments/api.py::book_appointment_for_patient`.
- Check in, cancel, no-show, reschedule — `appointments/api.py`.
- **Consolidated checkout** from server-discovered billables — `billing/api.py::create_pos_invoice`.
- **Ad-hoc invoice editor with tax templates** (`create_invoice`, `create_sales_invoice`, `list_tax_templates`, `search_billable_items`) — **NEW-LOOKS-FIXED**: this was reported missing (FD-BH-2) in the 2026-07-09 audit; it now exists in code.
- Collect partial payment, issue full-invoice credit note, list invoices/payments.
- Outstanding balance now returned per patient row (`list_patients` → `balanceDue`) — closes former gap FD-BH-9.
- Insurance policy CRUD (backend) and payor lookup — `insurance/api.py`.

### Backend/code gaps
| Gap | Status |
|---|---|
| `Lab Test` create/write/**submit** granted to `EB_Front Desk` | CONFIRMED — a receptionist can finalize a lab result |
| `Patient Encounter` read/export granted to `EB_Front Desk` | CONFIRMED — SOAP/diagnosis PHI exposed to non-clinical role |
| `Vital Signs` read/export granted to `EB_Front Desk` | CONFIRMED |
| No cash-drawer/shift backend (`api/v1/cash`, POS Opening/Closing Entry) | CONFIRMED — ADR-023 still "Proposed," real money untracked |
| No invoice void / payment reversal (only full-invoice credit note) | CONFIRMED |
| No Insurance Claim workflow (`list_claims`/`create_claim`/`submit_claim`) | CONFIRMED — largest untapped ERPNext core capability |
| No duplicate-patient check (only an email-availability check exists) | CONFIRMED |
| Sales Invoice editor (FD-BH-2) | **NO-LONGER-TRUE** — built since audit |
| Outstanding balance on patient list (FD-BH-9) | **NO-LONGER-TRUE** — built since audit |

### UI/Frontend gaps (per prior audit, not re-verified)
- Cash drawer is `localStorage` only, no real session identity.
- Calendar is read-only — no click-to-book / drag-to-reschedule.
- "Reassign provider" action exists but is commented out.
- "New Invoice" entry point commented out on the Billing hub — now that the backend exists, this is pure wiring work.
- Insurance CRUD UI hidden despite backend support.
- No payment-receipt document (invoice PDF stands in).
- Reminders are manual only (no automated per-appointment scheduling).
- Notifications bell hard-disabled; no Messages nav entry.
- Payment-method picker and currency symbol hardcoded instead of driven by config.
- Fabricated "High Readmission Risk" AI banner rendered on the live Patient Chart (see §0.2).

### Top fixes
1. Tighten `EB_Front Desk` DocPerms — remove Lab Test submit/write, remove Encounter/Vital Signs read. One fixture change, closes 3 confirmed PHI/safety findings.
2. Build the cash-drawer/shift backend (ADR-023) — the only remaining *Critical* severity gap; real money is unaudited.
3. Wire the frontend to the invoice-editor endpoints that already exist server-side — fastest remaining high-value win.

---

## 2. Nurse

### Can do (backend verified real, not mock)
- Record vitals with server-computed BMI/BP classification, linkable to an encounter — `vital_signs/api.py`.
- Record immunizations against the Mexico EPI schedule (given/due/overdue) — `immunizations/api.py`.
- Order labs and record (draft) results — `labs/api.py`.
- Author an encounter **draft** (docstatus=0) via `save_draft` — cannot sign it.
- Full Clinical Procedure lifecycle (create/submit/start/complete) — backend built, frontend trigger UI missing.
- Read allergies, conditions, vitals history, immunization schedule.

### Backend/code gaps
| Gap | Status |
|---|---|
| Vitals→encounter binding is a same-patient/same-day heuristic, not a true FK | CONFIRMED (core claim) — **but the audit's "no ambiguity guard" claim is now false**: linking is appointment-aware and skips when genuinely ambiguous. Residual risk remains for walk-ins with no appointment. |
| `Lab Test submit` granted to `EB_Nurse` (and Front Desk) | CONFIRMED — nurse can finalize a lab result, bypassing Rule 6 |
| Encounter sign gate blocks nurse correctly (`_require_assigned_practitioner_or_admin`) | CONFIRMED working as intended |
| `save_draft` has no section scoping — nurse can write diagnosis/Rx fields in the draft, not just intake fields | CONFIRMED |
| Immunization capture stores `lot_number` only — no `expiry_date` or `manufacturer` field exists at all | CONFIRMED — worse than "missing," these fields don't exist |
| No allergy check before recording immunization (`list_allergies` exists but is never called from the immunization flow) | CONFIRMED |
| Growth-curve percentiles, labs dual-creation path, nurse work-feed | STALE/UNVERIFIED this pass |

### UI/Frontend gaps (per prior audit, not re-verified)
- "Record vitals" CTA on the chart is a toast stub in some entry points.
- Fabricated AI risk banner may render for nurse too.
- No proactive clinical worklist (vitals-pending / vaccines-due / labs-to-draw) beyond assigned tasks — though a `/nursing` task UI (start/complete) was built 2026-07-10.
- Notifications panel hidden for nurse; fake growth-chart percentile bands rendered as if real.
- No procedure-recording UI at all — blocks the nurse-initiated billing handoff (ADR-024) even though the backend supports it.
- Hardcoded (non-i18n) strings on several nurse screens.

### Top fixes
1. Remove `Lab Test submit` from `EB_Nurse` (and `EB_Front Desk`) — same fixture fix as Front Desk §1.
2. Add an allergy/contraindication check before immunization administration — cheap, `list_allergies` already exists.
3. Scope `save_draft` server-side to intake fields only, and add `expiry_date`/`manufacturer` to immunization capture (recall traceability).

---

## 3. Practitioner (Doctor)

### Can do (backend verified real, not mock)
- Own and **sign** encounters — `complete_encounter` does a real `doc.submit()` on native `Patient Encounter`, double-gated by `_require_assigned_practitioner_or_admin`.
- Signing correctly spawns the order layer (Medication Request / Service Request / Therapy Plan) via **native ERPNext core `on_submit`** — Remedisys only tags channel afterward, confirming ADR-019 (composed, not reimplemented).
- Prescribe inside the encounter via the `drug_prescription` child table, validated against Item/Dosage Form/Medication/Prescription Duration masters.
- Order labs, record and **finalize** results (`submit_lab_result`) — though finalize is over-granted to other roles too (see §0.1).
- **`prescriptions/api.py` is fully built** (`list_medications`, `list_patient_prescriptions`, `get_item_preview`) — **CLAUDE.md's repo-layout table is stale here**, still labeling it a "Phase 2 stub." The audit was right that it exists.
- Weight-based dosing, follow-up booking, treatment-plan-template autofill.

### Backend/code gaps
| Gap | Status |
|---|---|
| `Lab Test submit` shared across Front Desk/Nurse/Practitioner (not physician-exclusive) | CONFIRMED |
| No standalone prescription-*create* endpoint — prescribing is encounter-only | CONFIRMED (matches audit, intentional per design) |
| `collectPayment=true` capability flag reported for practitioner (PR4) | **Backend already blocks this** — no `EB_Practitioner` row on Sales Invoice/Payment Entry DocPerms, and `billing/api.py` explicitly comments "blocked by design." If the frontend flag is really true, it's a dead button, not a privilege escalation — downgrade this finding's severity. |
| No `get_practitioner_worklist` / clinical-inbox endpoint | CONFIRMED — only a generic `get_my_tasks` (ToDo aggregation) exists |
| Amend-after-sign path for a submitted encounter | STALE/UNVERIFIED — only `cancel_encounter` (1→2) was found; no correction/amend flow located but search wasn't exhaustive |
| "My panel" scoping on `list_encounters` | CONFIRMED working (practitioners see only their own); equivalent scope on `list_patients` not verified |

### UI/Frontend gaps (per prior audit, not re-verified)
- Fabricated AI risk banner + AI insights explicitly **turned on for the practitioner** in `chart-permissions` — worst-audience Phase-5 violation, Critical severity in the prior audit.
- `/medications` screen renders a hardcoded `MEDICINE_MASTER` array with **zero API calls**, ignoring the real `list_medications` endpoint confirmed to exist.
- `/prescriptions` is a "coming soon" placeholder despite the backend being fully built.
- No physician clinical inbox in the UI (matches the confirmed backend gap above).
- Notifications bell/panel hidden for practitioner.
- No pediatric weight-based dosing UI (backend supports it).

### Top fixes
1. Fix the `Lab Test submit` over-grant (same fixture change as §1/§2) — restores Rule 6.
2. Build `get_practitioner_worklist` (unsigned encounters + abnormal labs awaiting finalize + order progress) — highest-value missing backend surface; `get_my_tasks` is a partial base.
3. Flip the fabricated AI banner off for the practitioner, and wire `/medications` + `/prescriptions` to the already-real backend endpoints — cheap, high-trust wins.

---

## 4. Clinic Admin (Healthcare Admin)

### Can do (backend verified real, not mock)
Full CRUD via custom whitelisted methods (never `/api/resource/`) for: Companies, Service Units + Types, Appointment Types, Medications/Classes/Brands/Manufacturers/Dosage Forms, Items (with `Item Price` sync), Treatment Plan Templates, Prescription Dosages/Durations, Complaints, Diagnosis, Payment Methods, Lab Test Templates, Therapy Types, Clinical Procedure Templates, Insurance, Practitioners + Schedules, Holiday Lists, Lab Test UOMs/conversions, Staff/Users, Role-permission UI overlay, EB Clinic Settings.

**NEW today (2026-07-16):** `generate_test_data` / `delete_generated_data` (`api/v1/admin/demo_data.py`) — one-click demo dataset (company bootstrap, users, 50 meds/vaccines/items, 35-patient visit pipeline), with teardown tracked via `EB Clinic Settings.demo_data_log`. This is an **`Administrator`-only desk shortcut**, not a Clinic Admin (`EB_Healthcare Admin`) capability — it doesn't fulfill ADR-014's self-serve onboarding wizard, it's an internal seeding tool.

### Backend/code gaps
| Gap | Status |
|---|---|
| `Healthcare Settings` (ERPNext core singleton) has no whitelisted get/update API | CONFIRMED — no frontend path to set `op_consulting_charge_item`, auto-invoicing, registration fee |
| Messaging/Integrations config (WhatsApp/Email/SMS) has no backend whitelisted method | CONFIRMED — matches the frontend placeholder |
| ADR-021 (master-data CRUD access) violation: Price List / Tax Category managed via generic REST + raw DocPerm, not custom methods | CONFIRMED — no `master_crud.py` exists; ADR-021 itself still `Status: Proposed` |
| Financial setup (Sales Taxes and Charges Template, Item Tax Template, Fiscal Year, Currency add, Cost Center, bulk Item-Price editor) | CONFIRMED desk-only; `_upsert_item_price` only partially mitigates (single price list, per-item) |
| Reminder scheduling unwired | CONFIRMED — `hooks.py` still has `scheduler_events` fully commented out; a Phase-4 headline feature with zero execution path |
| Cash Drawer/Shift backend | CONFIRMED absent — no `api/v1/cash/`; ADR-023 decided (native POS Opening/Closing Entry) but not implemented |
| Real DocType-permission admin UI (vs. the JSON overlay) | CONFIRMED absent |
| **NEW bug:** `eb_clinic_settings.js` desk script calls `generate_test_data(args={company:...})` and expects response keys the current Python no longer returns (current signature takes no args, returns different keys) | **NEW** — will raise a `TypeError`, surfaced as a 500 through `handle_api_errors`. Low blast radius (Administrator-only button) but should be fixed to match today's rewrite. |
| Symptoms/Complaints admin CRUD (prior audit's C4) | Likely **NO-LONGER-TRUE** — `list_complaints`/`create_complaint` etc. now exist in `__all__`, but the DocPerm grant wasn't independently re-verified |

### UI/Frontend gaps (per prior audit, not re-verified)
- Integrations screen is a static placeholder — "Connect" is a no-op.
- Real RBAC screen only edits a JSON UI-visibility overlay, not actual Frappe DocType permissions.
- `/activity` audit-log page is mock data; no data import/export UI.
- Master-data screens are mid-migration from "list+modal" to a target 3-column layout (several settings screens still pending).
- Recurring bugs across settings screens: silently swallowed save errors, hardcoded English strings (i18n violation of CLAUDE.md §13.10), Link fields rendered as free text, list-load errors shown as empty state instead of an error.
- Cash Drawer/Shift screen is `localStorage` mock (no backend to swap to yet, per ADR-023).

### Top fixes
1. Wire `scheduler_events` in `hooks.py` so reminder timings actually fire — currently dead despite the UI implying it works.
2. Build `master_crud.py` (finish ADR-021) with whitelisted CRUD for tax templates, Fiscal Year, Cost Center — closes the last known constitutional (Rule "custom whitelisted methods only") violation.
3. Fix the `demo_data.py` / `eb_clinic_settings.js` signature mismatch (quick), and decide in ADR-014 whether `generate_test_data` is the intended interim seeding path or should be superseded by a real self-serve onboarding wizard.

---

## 5. Where to go next

Ranked by reach × effort across all four roles:

1. **One DocPerm fixture fix** (`patches/v0/eb_docperm_spec.json`): remove `Lab Test submit` from Front Desk + Nurse, remove `Patient Encounter`/`Vital Signs`/`EB Clinic Settings` read from Front Desk. Closes confirmed Rule 6 and PHI findings for 3 of 4 roles at once.
2. **Frontend-only AI/mock cleanup** (not re-verified this session, but was Critical in the last audit): turn off the fabricated risk banner for Front Desk + Practitioner, wire `/medications` and `/prescriptions` to the real backend endpoints that already exist.
3. **Cash Drawer/Shift backend** (ADR-023) — the one remaining gap that's both Critical-severity and touches two roles (Front Desk operationally, Clinic Admin for reconciliation).
4. **Clinic Admin financial/config backend** (ADR-021 `master_crud.py`, `Healthcare Settings` API, scheduler wiring) — unblocks self-service setup that today forces a Frappe-desk detour, violating the multi-tenant SaaS principle.
5. **Practitioner clinical inbox** (`get_practitioner_worklist`) — highest-value missing read surface for the role that carries the most clinical liability.

---

*Synthesized from live code (2026-07-16) + `docs/audit/{frontdesk,nurse,practitioner,settings}/`, `docs/qa/*.md`, and `docs/audit/ALIGNMENT_CAPSTONE.md`. Frontend claims are carried from those audits and were not re-verified this session — the Next.js repo is not present in this environment. Re-run this analysis once the frontend repo is available, or after the fixture/backend fixes above land, to confirm closure.*

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-07-18 | Sarvesh | Initial version (header backfilled from git history) |
