# Documentation audit — duplication, ambiguity and staleness

**Doc status:** record · **Created:** 2026-09-03 by Invincible · **Updated:** 2026-09-03 by Invincible · **Version:** 1.0

> A structural pass over all **179 markdown files** in `docs/`: what duplicates
> what, where a reader cannot tell which document is authoritative, and which
> status headers contradict the code.
>
> **This file is itself temporary.** It exists to drive the six actions in §9.
> When they are done, delete it — otherwise it becomes the thirteenth "what's
> broken" document, which is the main problem it describes.

**Status:** Audit only — no docs were rewritten or deleted.
**Owner:** Backend.
**Created:** 2026-08-19 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
**Last updated:** 2026-08-19 — Claude Code (Opus 5) · session run by `groupmonks@gmail.com`
<sub>Editing this file? Update **Last updated** with your name and date.</sub>

**Method:** link-graph + title + status extraction over every `.md`, cross-checked
against the code that cites them (backend `dev` @ `6744129`).

---

## 1. Findings

| # | Finding | Impact | Scale |
|---|---|---|---|
| **D1** | **Seven ADR numbers are used twice** — 14 files competing for 7 numbers | **Highest.** Code cites these numbers 9–15 times each; a reader has a 50/50 chance of opening the wrong decision | 14 files |
| **D2** | 15 ADRs marked **Proposed** that the code already implements | ADR status is not trustworthy, so nobody uses it | 15 of 43 |
| **D3** | **Twelve** documents whose job is "list what's broken", in five locations | No single answer to "where is the backlog?" | 12 docs |
| **D4** | No ADR index; **56 documents** nothing links to | Discovery is by `find`, not by reading | 56 orphans |
| **D5** | Status headers that contradict the code | A doc says "not built" for shipped features | **1 confirmed** (was 2; one fixed upstream) |
| **D6** | Three docs with "document/drive" in the name, for three different features | Known-confusing — one doc's header exists purely to disambiguate itself from another | 3 docs |
| **D7** | 85 audit files across 4 role folders, overlapping `qa/` (7 docs) | Two parallel QA/audit vocabularies | 92 docs |
| **D8** | **`API_SPEC.md` documents 41 endpoints that are not callable** — and misses 426 that are | The contract is wrong in both directions | 41 phantom / 426 absent |
| **D9** | `FRONTEND_CONTRACT.md` (24) and `ROLES_AND_PERMISSIONS.md` (10) assign contracts and **role permissions** to endpoints that do not exist | Security doc grants rights on phantom methods | 34 |
| **D10** | 9 documented endpoint paths are **wrong but the method exists elsewhere** | Silent 404 for anyone following the doc | 9 |
| **D11** | `CLAUDE.md` §6 repo map calls three built modules "stub / not started" | The constitution understates what exists | 3 modules |
| **D12** | 129 filenames cited across 54 docs exist in **neither repo** — incl. 4 in `docs/README.md` and 4 in `CLAUDE.md` | Dead ends from the two most-read documents | 129 refs |
| — | **Clean:** zero broken markdown links · zero duplicate H1 titles · **zero copy-pasted paragraphs** | — | — |

---

## 2. D1 — Seven ADR numbers are used twice `Highest`

The constitution says: *"ADR in `/docs/adr/`. Use the template. **Number
sequentially.** Never edit a merged ADR — supersede it."* Numbering has collided
seven times:

| Number | Two competing documents | Status |
|---|---|---|
| **ADR-018** | `multi-jurisdiction-compliance` — pluggable compliance, India + Mexico | Accepted |
| | `practitioner-appointment-visibility-and-coverage` | Accepted |
| **ADR-020** | `queue-derived-handoff-state` — derived room state | Accepted |
| | `vaccine-nurse-administration-handoff` — doctor → nurse | Proposed |
| **ADR-026** | `llm-provider-allowlist` — LLM not single-vendor | Accepted |
| | `vaccine-two-part-billing-at-administration` | Proposed |
| **ADR-027** | `ai-copilot-credit-metering` | Proposed |
| | `architecture-gap-remediation-roadmap` | Proposed |
| **ADR-028** | `lab-parameter-master` | Proposed |
| | `narzim-central-ai-platform` — Marley becomes a thin AI client | Proposed |
| **ADR-030** | `ai-patient-chat-persistence` | Accepted |
| | `llm-curated-tool-access` — refines Rule 4 | Accepted |
| **ADR-038** | `encounter-signing-assigned-practitioner-only` | Accepted |
| | `narrative-documents-with-embedded-values` | Proposed |

**Why this is the worst finding.** These numbers are load-bearing in code and in
the constitution:

| Number | Cited in | Also cited in `CLAUDE.md` |
|---|---|---|
| ADR-028 | **15 code files** | — |
| ADR-020 | **14 code files** | — |
| ADR-018 | 11 code files | 4× |
| ADR-030 | 10 code files | 1× |
| ADR-026 | 9 code files | 6× |
| ADR-038 | 2 code files | — |
| ADR-027 | 1 code file | — |

A developer reading `# ADR-028: canonical parameter` in `lab_template_sync.py`
cannot tell from the number whether the governing decision is *"Canonical Lab
Parameter Master"* or *"Narzim — a separate, centrally-owned platform; Marley
Health becomes a thin AI client."* Those two decisions are not remotely related,
and one of them is an architectural pivot.

The pairs are also semantically adjacent enough to mislead: ADR-020
`queue-derived-handoff-state` and ADR-020 `vaccine-nurse-administration-handoff`
are **both about handoff**. ADR-026 `llm-provider-allowlist` and ADR-026
`vaccine-two-part-billing` are both cited in the AI/billing area.

**Fix.** Do not renumber merged ADRs — the constitution forbids editing them, and
renumbering would break every existing citation. Instead:

1. Add **`docs/adr/README.md`**: one row per number, both documents where a number
   collides, and which is canonical for that number.
2. Adopt full-slug citation in code and docs going forward:
   `ADR-028-lab-parameter-master`, not `ADR-028`.
3. Add a CI check that a new `adr-NNN-*.md` cannot reuse an existing number.
4. Sweep the ~60 existing ambiguous code citations to full slugs — mechanical, and
   the only way old comments stop misleading.

---

## 3. D2 — 15 ADRs say "Proposed" but the code implements them

Status distribution across 43 ADRs: **24 Accepted · 17 Proposed · 1 Superseded**
(plus one file whose Status line is the unedited template
`Proposed | Accepted | Superseded | Deprecated`, and one with a prose status).

These are marked **Proposed** while the code already cites and implements them:

| ADR | Code files citing it |
|---|---|
| `adr-019-encounter-native-binding` | **15** |
| `adr-028-lab-parameter-master` | **15** |
| `adr-020-vaccine-nurse-administration-handoff` | **14** |
| `adr-026-vaccine-two-part-billing-at-administration` | 9 |
| `adr-024-nurse-initiated-billable-procedure` | 7 |
| `adr-025-encounter-opt-in-billing-and-two-part-vaccine` | 7 |
| `adr-021-master-data-crud-access` | 6 |
| `adr-037-portal-chat-separate-thread` | 5 |
| `adr-017-frontdesk-pos-consolidated-billing` | 4 |
| `adr-023-cash-drawer-shift-reconciliation` | 3 |
| `adr-038-narrative-documents-with-embedded-values` | 2 |
| `adr-012` · `adr-027` (both) · `adr-028-narzim-central-ai-platform` | 1 each |

ADR-020's vaccine handoff is **provably live** — an E2E run on 2026-08-18 created
`HLC-NUR-2026-00001` through exactly the mechanism that ADR describes. It still
says Proposed.

**Consequence:** "Proposed" carries no information. A reader cannot use status to
tell a decision under discussion from one shipped months ago, so they must read
the code anyway — which is what an ADR exists to prevent.

**Fix.** One sweep: for each of the 15, set `Accepted` with the date it shipped
(git log on the citing code gives it). Then treat status as a gate in review: an
ADR cannot stay Proposed once its code merges.

---

## 4. D3 — Twelve "what's broken" documents in five locations

| Document | Lines | Last touched |
|---|---|---|
| `KNOWN_ISSUES.md` | 57 | 2026-07-29 |
| `FRONTEND_FEATURE_AUDIT.md` | 169 | 2026-07-07 |
| `qa/GAP_BACKLOG.md` | 133 | 2026-07-17 |
| `audit/ROLE_GAP_ANALYSIS.md` | 184 | 2026-07-18 |
| `audit/OPD_FRONTEND_AUDIT.md` | 227 | 2026-07-07 |
| `audit/SETTINGS_CRUD_AUDIT.md` | 96 | 2026-07-07 |
| `audit/ALIGNMENT_CAPSTONE.md` | 89 | 2026-07-10 |
| `audit/frontdesk/FRONTDESK_CHARTER_AND_GAPS.md` | 331 | 2026-07-09 |
| `audit/frontdesk/OPD_BACKEND_FLOW_AND_GAPS.md` | 181 | 2026-07-09 |
| `api/FRONTEND_API_GAP_CHECKLIST.md` | 265 | 2026-07-09 |
| `api/ACTIVITY_TIMELINE_GAPS.md` | 233 | 2026-08-18 |
| `api/API_AUDIT.md` | 402 | 2026-08-19 |

Ten of the twelve have not been touched since July. There is no stated
relationship between any of them, so "is this still true?" has to be answered per
document, by reading code. That is the single biggest source of wasted time in this
tree — and the last two are mine, which is how the pattern keeps growing.

**Fix.** One live backlog — `KNOWN_ISSUES.md` is the natural home, already
top-level and short. Everything else becomes either (a) a ticket referenced from
it, or (b) a dated point-in-time audit moved to `docs/audit/archive/` with an
explicit "superseded by" line. An audit is a **snapshot**; a backlog is **living**.
Mixing the two is why ten documents rotted.

---

## 5. D4 — No ADR index, and 56 documents nothing links to

`docs/adr/` holds 43 ADRs plus a template and **has no README**. 32 of the ADRs are
linked from nowhere — including `adr-041` (accepted 2026-08-18) and both halves of
five of the seven colliding numbers.

Also unlinked: **all seven** `qa/` documents, four top-level `audit/*` documents,
three `flows/*`, `ai/README.md`, `grafana/README.md`, and four top-level docs
(`DEMO_DATA_GENERATOR.md`, `FRONTEND_FEATURE_AUDIT.md`, `REPORTS_API.md`,
`WHATSAPP_INTEGRATION.md`).

`docs/README.md` is described as the master navigation, but indexes only a subset.
So the practical way to find anything here is `find`/`grep` — which means readers
find *a* document on a topic, not necessarily *the* one.

**Fix.** `adr/README.md` (§2), plus complete `docs/README.md`, plus a CI check that
every `.md` is reachable from an index. Cheap, and it makes orphans impossible to
add silently.

---

## 6. D5 — Status headers that contradict the code

| Document | Says | Reality |
|---|---|---|
| `PATIENT_DOCUMENTS.md` (2026-06-25) | **"Status: Planned (not yet built)"** and *"There is currently **no backend** for it (no `api/v1/documents`, no service…)"* | **Built.** `api/v1/documents/api.py` exists (5 endpoints), `services/documents.py` is 343 lines, and `tests/documents/test_documents_added_by.py` landed 2026-08-18 |
| ~~`AI_MULTI_PANEL_LAB_EXTRACTION.md`~~ | ~~"Design approved pending final go-ahead"~~ | **FIXED upstream 2026-08-31** — the doc now opens "Status: BUILT AND LIVE" (v1.3). Kept as a record of what was corrected |

A doc that says a shipped feature is unbuilt is worse than no doc: it sends someone
to build it twice. `screens/07-appointment-booking.md` had the same problem — four
claims stale, now recorded in `audit/frontdesk/NEW_APPOINTMENT_AUDIT.md §4`.

---

## 7. D6 — Three "document/drive" docs for three different features

| Document | Actual subject |
|---|---|
| `CLINICAL_DOCUMENT_DRIVE.md` | **Narzim Drive** — staff personal documents, custom `Clinical Document` doctype |
| `PATIENT_DOCUMENTS.md` | **Patient chart Documents tab** — files against a patient, on `Patient Medical Record` |
| `api/DRIVE_FRONTEND_INTEGRATION.md` | **`frappe/drive`** — the third-party app installed 2026-08-18 |

This confusion is already documented *inside* the tree: `CLINICAL_DOCUMENT_DRIVE.md`
opens with a warning block that exists purely to distinguish itself from
`PATIENT_DOCUMENTS.md`, calling it *"a known point of confusion between the two
features."* Then I added a third with "DRIVE" in the name.

**Fix.** Rename to the feature, not the metaphor — e.g. `STAFF_DOCUMENT_DRIVE.md`,
`PATIENT_CHART_FILES.md`, `FRAPPE_DRIVE_APP.md` — and keep the disambiguation block
in each.

---

## 8. D7 — 92 audit/QA documents, two vocabularies

`docs/audit/` holds **85** files: `settings/` 30, `frontdesk/screens/` 20,
`nurse/screens/` 13, `practitioner/screens/` 11, plus 4 top-level and role-level
docs. Alongside it, `docs/qa/` holds 7 — including `FRONT_DESK_QA.md` and
`FRONT_DESK_FEATURES.md`, which cover the same role as the 20 files in
`audit/frontdesk/`.

The per-screen audits are genuinely valuable and well-structured (I used them, and
they were mostly accurate). The problem is that "audit" and "qa" are two names for
overlapping work, in two trees, with no cross-links — and none of the `qa/` files
are indexed anywhere.

**Fix.** Pick one tree. `audit/<role>/screens/` is the stronger structure; fold
`qa/` into it or make `qa/` explicitly about *test plans* (`E2E_TEST_PLAN.md` genuinely
is) and move the role/feature inventories under `audit/`.

---


## 8b. Second pass — reference accuracy

The first pass looked at *structure* (duplication, staleness, orphans). This pass
checked whether documents' **claims resolve**: do the files and API methods they
cite exist? Method: extract every `` `path.ext` `` and every
`remedisys_healthcare_ai.api.*` string from all 179 docs (plus `CLAUDE.md` and
`ROADMAP.md`), resolve against both repos and against the 485 real whitelisted
methods, applying `api.py` re-export aliases.

### D8 · `API_SPEC.md` is wrong in both directions

| | |
|---|---|
| Endpoints it documents that are **not callable** | **41** |
| Real endpoints it does not mention | **426** of 485 |

It documents an entire `v1.reports.api.*` namespace (`get_clinical_report`,
`get_operations_report`, `get_revenue_report`, `get_patient_demographics`) that has
never existed. Reports **were** built — 17 endpoints — but as `<module>/report.py`
(`billing.report.get_revenue_by_provider`, `appointments.report.get_no_show_analysis`
…), a namespace the spec never learned. Also phantom: `billing.api.list_invoices`,
`billing.api.get_invoice`, `billing.api.record_payment`, `billing.api.get_ar_aging`,
`billing.api.get_billing_kpis`, `dashboard.api.get_dashboard_stats`,
`encounters.api.update_encounter`, `labs.api.order_lab_test`,
`clinical.api.record_vitals`, and 26 `admin.api.*` CRUD methods.

### D9 · Two architecture docs contract against phantom endpoints

`architecture/FRONTEND_CONTRACT.md` (24 non-callable) and
`architecture/ROLES_AND_PERMISSIONS.md` (10) — the latter is the security
reference, assigning role permissions to methods such as
`admin.api.create_staff_user`, `admin.api.disable_staff_user` and
`admin.api.delete_company` that do not exist. A reader auditing "who can disable a
user?" gets an answer about a method that was never written.

`qa/FRONT_DESK_QA.md` adds 8 more.

### D10 · Nine paths documented in the wrong module

The method exists — the documented path 404s:

| Documented | Actually |
|---|---|
| `patients.api.upload_document` | `documents.api.upload_document` |
| `patients.api.list_documents` / `delete_document` | `clinical_documents.api.*` |
| `patients.api.send_message` | `messages.api.send_message` |
| `clinical.api.create_nursing_task` / `list_nursing_tasks` | `nursing.api.*` |
| `medications.api.list_medications` | `prescriptions.api.list_medications` |
| `admin.settings.create_practitioner_schedule` | `admin.practitioners.*` |
| `providers.api.list_practitioners` | `patient_portal.api.list_practitioners` |

### D11 · `CLAUDE.md` §6 understates three built modules

| Repo map says | Reality |
|---|---|
| `insurance/api.py` — "🔲 Phase 3 stub (empty — not started)" | **4 endpoints, fully frontend-wired** |
| `notifications/api.py` — "🔲 Phase 4 stub (empty — not started)" | **17 endpoints** |
| `prescriptions/api.py` — "🔲 Phase 2 stub (unused)" | 3 endpoints, 2 wired |

§12 also lists reports as work "to build — 16 endpoints"; 17 exist (D8). The
constitution is the first document a new engineer reads, and it tells them to build
things that are already there.

### D12 · 129 dead file references, including from the two most-read docs

`docs/README.md` names four documents that no longer exist
(`ENCOUNTER_COPILOT_AGENT_DESIGN.md`, `ENCOUNTER_COPILOT_AGENT_PLAN.md`,
`ENCOUNTER_FILL_FORM_AUDIT.md`, `copilot-revised-plan.md`) — as prose rather than
links, which is why the link-graph check reported zero broken links. `CLAUDE.md`
cites four missing paths, including `docs/planning/AUTH_INTEGRATION_PLAN.md`, which
the ADR-011 amendment presents as authoritative for the auth flow.

**Not all 129 are bugs, and the distinction matters:** an **ADR** citing a file
deleted later is correct — it is a point-in-time record. A **plan** naming files it
intends to create is also fine. The ones that matter are dead references in
*living* documents: `docs/README.md`, `CLAUDE.md`,
`ai/NARZIM_AI_ENCOUNTER_SYSTEM.md` (7), `flows/*`, `architecture/*`.

*(My own `DOCS_AUDIT.md` shows 3 "missing" files — those are the new filenames I
propose in D6. A future version of this check should ignore proposed names.)*

### What this pass found clean

**Zero copy-pasted paragraphs.** No identical block over 240 characters appears in
two documents — so the duplication in this tree is conceptual (many docs on one
topic), never literal. That is the easier kind to fix.

## 9. Actions

Ordered by how much confusion each removes per hour spent:

1. **`docs/adr/README.md`** with the collision table from §2, marking the canonical
   ADR per number. Unblocks everything else about ADRs. *(D1, D4)*
2. **Status sweep of the 15 Proposed-but-shipped ADRs** → Accepted + ship date.
   *(D2)*
3. **Fix the two false statuses** in `PATIENT_DOCUMENTS.md` and
   `AI_MULTI_PANEL_LAB_EXTRACTION.md`. *(D5)*
4. **Nominate `KNOWN_ISSUES.md` as the single live backlog**; move the ten stale
   audits to `docs/audit/archive/` with "superseded by" lines. *(D3)*
5. **Complete `docs/README.md`** so all 179 files are reachable; add the CI orphan
   check and the ADR-number-uniqueness check. *(D4, D1)*
6. **Rename the three document/drive docs**; decide `audit/` vs `qa/`. *(D6, D7)*
7. **Correct `API_SPEC.md`** — delete the 41 phantom endpoints, fix the 9 wrong
   paths, and document the real `<module>/report.py` namespace. §16 already lists
   all 485 real endpoints, so the gap is now visible in one file. *(D8, D10)*
8. **Fix `ROLES_AND_PERMISSIONS.md` and `FRONTEND_CONTRACT.md`** — 34 phantom
   endpoints, in a security doc and a contract doc. *(D9)*
9. **Update `CLAUDE.md` §6/§12** for `insurance`, `notifications`, `prescriptions`
   and reports. *(D11)*
10. **Add a CI doc-reference check** — assert every `` `file.ext` `` and every
    `remedisys_healthcare_ai.api.*` string in a *living* doc resolves. This is the
    same check proposed for the frontend in `api/API_AUDIT.md §10.4`; one script
    covers both. *(D8–D12)*

Then delete this file.

### Two conventions worth writing into `CONTRIBUTING.md`

- **Cite ADRs by full slug**, never bare number.
- **Every doc declares its kind in the header**: *living reference* (kept current),
  *point-in-time audit* (carries "verified against commit X", archived when
  superseded), or *ticket* (deleted when closed). Ten of the twelve gap documents
  rotted because nothing said which kind they were.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-03 | Invincible | Initial version (header backfilled from git history) |
