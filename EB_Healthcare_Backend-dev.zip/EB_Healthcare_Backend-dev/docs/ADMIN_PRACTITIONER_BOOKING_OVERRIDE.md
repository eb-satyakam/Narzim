# Admin-Practitioner Booking Override — Mechanism

**Doc status:** living · **Created:** 2026-09-14 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-09-15 by Divyanshu (AI-assisted) · **Version:** 2.0

> **2026-09-15 correction:** §3-§4 below originally described the mechanism
> ADR-065 chose (withhold `practitioner`, patch it in via `frappe.db.set_value`
> after insert). That mechanism did not work — it broke booking outright for
> any normal Appointment Type, with the symptom `"Please enter Practitioner"`.
> This revision rewrites §3-§4 to describe the corrected mechanism
> (`ignore_permissions=True`, `practitioner` never withheld) per ADR-069, which
> supersedes ADR-065's implementation. §2 below is expanded with a "why the
> first version broke" postmortem. Nothing in §1 (scope) or §5 (what does NOT
> change) is affected.

## 1. Scope

How `book_appointment` (and every endpoint that shares `_create_impl`) lets a
doctor who is *also* an admin book an appointment naming a different
practitioner, without loosening anything for a plain doctor. See ADR-069 (and
its superseded predecessor ADR-065) for the decision and rejected
alternatives; this document is the mechanism, layer by layer.

## 2. Why it broke

Every `EB_Practitioner` user carries a Frappe **User Permission**:
`Healthcare Practitioner = <their own practitioner record>`. This restricts
which values of that Link field their session may reference, in *any*
doctype, anywhere — it is what stops Dr. Sheru from naming Dr. Sandhu as
`practitioner` on a new appointment, and vice versa. It is enforced inside
`doc.insert()`/`doc.save()` by Frappe core itself, independent of our own
application code, and it has no concept of "this user also holds an admin
role."

Our own app-level check, `_enforce_practitioner_self_booking()`
(`api/v1/appointments/api.py:336`), already exempts admin roles — an admin's
`practitioner` argument sails through that function unchanged. The bug was
never there. It was one layer further in: `_create_impl` always called
`doc.insert(ignore_permissions=False)`, so Frappe's core check ran anyway and
rejected the value the app layer had just approved.

## 2a. Why the FIRST fix (ADR-065, 2026-09-14) also broke

The original fix reused `reassign_appointment`'s pattern for a *write*
(ADR-018) and applied it to a *create*: keep the restricted `practitioner`
value out of `doc_data` so `doc.insert()` never evaluates it against the User
Permission, then patch it in afterward via `frappe.db.set_value()`.

That assumed the User Permission was the *only* thing checking `practitioner`
at insert time. It is not. `Patient Appointment`'s own controller
(`apps/healthcare/healthcare/healthcare/doctype/patient_appointment/patient_appointment.py:237-247`,
`validate_based_on_appointments_for`) runs on every `validate()`:

```python
def validate_based_on_appointments_for(self):
    if self.appointment_for:
        appointment_for_field = frappe.scrub(self.appointment_for)   # "practitioner"
        if not self.get(appointment_for_field):
            frappe.throw(_("Please enter {}").format(frappe.bold(self.appointment_for)),
                         frappe.MandatoryError)
```

`appointment_for` is `fetch_from: appointment_type.allow_booking_for`, and
every standard clinical Appointment Type resolves this to `"Practitioner"`.
So the sequence at insert was: `appointment_for` fetched to `"Practitioner"` →
this check runs → `self.practitioner` is empty (withheld on purpose) →
`frappe.throw("Please enter Practitioner", MandatoryError)` → `doc.insert()`
never returns → the post-insert `frappe.db.set_value()` patch this whole
mechanism depended on never runs. Reported live 2026-09-15 booking Anant
Sharma with a different practitioner; root-caused the same day. See ADR-069.

**Reused mechanism, different doctype shape.** `reassign_appointment`'s
version of this pattern is correct *for a write*: `Patient
Appointment.practitioner` is `set_only_once`, so an *existing* document being
saved has no equivalent mandatory-value gate to trip — the field is already
populated from whenever it was first created. A *create* has no such
guarantee; `validate_based_on_appointments_for` exists precisely to make sure
one gets set. Copying the write-path pattern onto the create path carried
over the bypass but not the reason it was safe there.

## 3. The shape of the fix (corrected, 2026-09-15 / ADR-069)

1. Detect the narrow population this applies to (unchanged —
   `_resolve_admin_target_practitioner()`, §4.1 below).
2. **Keep `practitioner` in `doc_data` at all times.** Never withhold it.
3. Pass `ignore_permissions=True` to `doc.insert()` for this branch — the same
   parameter this function already threads through for the patient-portal's
   pre-authorized path (`skip_staff_authorization`), extended to cover this
   case too.
4. Nothing to patch afterward: `practitioner_name`, `title`, and `department`
   are all derived normally during the insert, because `practitioner` was
   present the whole time.
5. Log the override — IDs only (unchanged).

## 4. Layer by layer

### 4.1 The gate — `_resolve_admin_target_practitioner()`

`api/v1/appointments/api.py`, next to `_enforce_practitioner_self_booking()`.
A pure function of session state and its two arguments — no DB writes, easy
to unit-test in isolation:

```python
def _resolve_admin_target_practitioner(practitioner, skip_staff_authorization):
    if not practitioner or skip_staff_authorization:
        return None
    roles = set(frappe.get_roles(frappe.session.user))
    if "EB_Practitioner" not in roles or not (roles & _ADMIN_ROLES):
        return None
    own = _practitioner_for_user(frappe.session.user)
    if own and practitioner != own:
        return practitioner
    return None
```

Returns the target practitioner **only** when all of these hold: a
practitioner was actually named; this is not the patient-portal path; the
caller holds `EB_Practitioner`; the caller **also** holds an admin role
(`_ADMIN_ROLES = {"EB_Healthcare Admin", "System Manager", "Administrator"}`);
and the named practitioner differs from the caller's own. Every other caller
— a plain practitioner, a non-practitioner Front Desk/Admin user (who holds no
restrictive User Permission to begin with), the portal — gets `None`, and
`_create_impl` behaves exactly as before this change.

### 4.2 The value stays in the insert (corrected)

`_create_impl` builds `doc_data` from an `optional` dict that includes
`practitioner` whenever it is not `None`. As of ADR-069, there is no longer
any code here that removes it — `admin_target_practitioner` being truthy
changes only how `doc.insert()` is called (§4.3), never what `doc_data`
contains. The local variable `practitioner` (and now `doc_data["practitioner"]`)
holds the target value throughout, including for `assert_bookable()` (the
ADR-062 holiday/leave/availability guard), which validates the *target*
doctor's calendar, not the caller's own.

### 4.3 The insert itself (corrected)

```python
doc.insert(ignore_permissions=skip_staff_authorization or bool(admin_target_practitioner))
```

`ignore_permissions=True` for this branch does two things in one call:

1. Skips the doctype-level `create` permission check inside `insert()` —
   already redundant, since `require_permission("Patient Appointment",
   "create")` ran explicitly earlier in the same function for every
   non-portal caller.
2. Skips Frappe's Link-field User Permission check on `practitioner` inside
   `_validate_links()` — the actual thing ADR-065 needed bypassed.

Because `practitioner` is present in `doc_data` (§4.2), core's own
`validate_based_on_appointments_for()` (§2a above) sees a populated value and
never throws. Every field this doctype does NOT restrict for this caller
(everything except `practitioner`) behaves exactly as an unrestricted insert
always did — `ignore_permissions=True` doesn't add any new grant beyond what
`require_permission()` already established, it just also lifts the one
Link-field restriction this ADR exists to route around.

### 4.4 No deferred write needed

There is nothing left to patch after `doc.insert()`. `practitioner_name`
(`fetch_from=practitioner.practitioner_name`) and `department`
(`fetch_from=practitioner.department`, `fetch_if_empty`) are both derived
normally during the insert, exactly as they would be for any other
practitioner-booked appointment, because `practitioner` was present the whole
time. `title` is set by the doctype's own `validate()` the same way. The
former §4.4 (`frappe.db.set_value` + `doc.reload()`) and §4.5 (department
backfill via `_ensure_appointment_department`) sections are deleted — not
replaced, removed. `_ensure_appointment_department()` itself is untouched and
still used by `reassign_appointment` (ADR-018), where it remains correct: that
function performs a *write* on an existing document (`practitioner` is
`set_only_once`, already populated from creation), not a *create*, so it has
no equivalent to `validate_based_on_appointments_for()` to satisfy.

### 4.5 The audit line

```python
frappe.logger("remedisys").info(
    f"appointment.admin_booked_for_other_practitioner name={doc.name} "
    f"practitioner={admin_target_practitioner} by={frappe.session.user}"
)
```

Appointment name, target practitioner, acting user — IDs only. No patient
name, no clinical content. Same shape as `reassign_appointment`'s own log
line, so any tooling built to watch one covers both.

## 5. What does NOT change

- A plain `EB_Practitioner` naming a colleague still gets the pre-existing
  `"You can only book appointments for yourself."` — `_enforce_practitioner_self_booking`
  intercepts this before `_create_impl` is even reached; `_resolve_admin_target_practitioner`
  is never consulted for this caller.
- A non-practitioner Front Desk/Admin user booking any doctor for any patient
  already worked before this change (no User Permission row exists for them)
  and is untouched.
- The patient portal (`book_my_appointment` → `skip_staff_authorization=True`)
  is excluded explicitly and was never affected.
- `book_appointment_with_payment` and `book_appointment_for_patient` both
  funnel through the same `_create_impl`, so they inherit this fix with no
  code change of their own.

## 6. Failure modes

- **Target practitioner has no `department`.** The `fetch_from` simply yields
  nothing at insert time — the field is left blank, the same behavior a plain
  self-booking would show for a practitioner with no department. Not a new
  failure mode, and (post-ADR-069) no longer routed through
  `_ensure_appointment_department` for this branch at all — that guard is
  only reached via `reassign_appointment`/`reschedule_appointment_with_payment`
  now, which is a *write*, not this *create* path.
- **`assert_bookable` rejects the target's slot** (holiday, leave, outside
  schedule). Raised before `doc.insert()` runs at all — no half-written
  appointment, nothing to roll back.
- **The insert itself fails for any other reason** (a genuine validation
  error, a DB error). Since ADR-069, `practitioner` was never split across
  two writes — there is exactly one write (the insert), so there is no
  partial-success state to reason about: it either fully succeeds or nothing
  is persisted. This is strictly simpler than the pre-ADR-069 failure surface,
  which had a documented partial-success window between `doc.insert()`
  succeeding and the (now-deleted) post-insert `db.set_value` running.

## 7. Testing

`tests/appointments/test_appointments.py::TestResolveAdminTargetPractitioner`
— six cases against the pure helper, no site fixtures needed (mocks
`frappe.get_roles` and `_practitioner_for_user` directly, matching this
file's existing `TestStatusRoleGate` style):

1. Admin practitioner naming a colleague → flagged.
2. Admin practitioner naming themselves → not flagged.
3. Plain practitioner (no admin role) → never flagged.
4. Non-practitioner admin/front-desk → never flagged.
5. Portal path (`skip_staff_authorization=True`) → never flagged.
6. No practitioner named (department-only booking) → never flagged.

The end-to-end write path (`doc.insert()` → `db.set_value` → department
backfill → log line) is exercised manually per ADR-065 §Verification; an
integration test against real Patient/Practitioner fixtures is a reasonable
follow-up once `bench run-tests` is unblocked site-wide (currently broken for
every module — see `docs/KNOWN_ISSUES.md`).

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-09-14 | Sarvesh-SocialAngel (AI-assisted) | Initial version |
