# Encounters Screen — What We Are Building

**Doc status:** draft · **Created:** 2026-08-29 by Anant Sharma (AI-assisted) · **Updated:** 2026-09-04 by Anant Sharma (AI-assisted) · **Version:** 3.5

> **Built 2026-08-31 — frontend, plus one backend addition.** Laid out as a **table** matching the
> Patients directory (§4.3), not the card list v1.0–v2.0 described. `list_encounters` gained
> `from_date`/`to_date`, **verified against 42 live encounters on `remedisys.localhost`** (§10.4) —
> gap 1 in §6 is closed. Lints, typechecks and tests clean; catalogs in parity. The **frontend has
> still not been opened in a browser.** §10 records what shipped.

> **Who this is for.** The frontend developer who will build the screen, the backend developer
> who owns `api/v1/encounters/api.py`, and the doctor and clinic admin who will use it.
>
> **What it is.** A plan in plain words. It says what the Encounters list must show, what the
> current API can and cannot answer, and exactly what happens when a row is clicked.
>
> **What it is not.** Not the endpoint contract ([`api/API_SPEC.md`](api/API_SPEC.md)), and not a
> spec for the encounter *form* — the 6,630-line `encounter-screen.tsx` is out of scope and is
> not being changed.

---

## 1. The short version

**The Encounters page already exists.** This is not a new build. All three routes are live in
`remedisys-ai-ehr`:

| Route | File | Size |
|---|---|---|
| List | `src/app/(clinic)/encounters/encounters-client.tsx` | 380 lines |
| Detail | `src/app/(clinic)/encounters/[id]/page.tsx` → `EncounterScreen` | 99 + **6,630** lines |
| New | `src/app/(clinic)/encounters/new/page.tsx` | 103 lines |

The **detail screen is the most developed screen in the product**. The **list page is the weak
part**, and it is what this document specifies.

Measured against the two screens it is meant to resemble:

| Page | Lines | Row menu | Server pagination | Server search |
|---|---|---|---|---|
| Patients | 1,530 | yes | yes | yes |
| Appointments | 1,333 | yes (Cancel / Reassign / Refund) | yes | yes |
| **Encounters** | **380** | **none** | **no** | **no** |

| | |
|---|---|
| **URL** | `/encounters` (unchanged — no second route) |
| **Default filter** | **This Week**, all statuses — for every role (§4.4a) |
| **Who can open it** | Practitioner, Nurse, Clinic Staff, Admin — **not Front Desk** (`route-access.ts:37`) |
| **Repo** | `remedisys-ai-ehr` (frontend) — plus optional additions to `list_encounters` here |

The goal: a doctor opens the page and immediately sees **what they still owe**; an admin opens it
and immediately sees **what is unfinished and unbilled**.

---

## 2. What is broken today

Seven defects, all verified against the current file. Ordered by consequence.

### 2.1 The status badge hides unsigned notes — the one with clinical weight

`encounters-client.tsx:62-67`:

```tsx
function normaliseStatus(s: string): EncStatus {
  if (s === "Completed") return "Completed";
  if (s === "Cancelled") return "Cancelled";
  return "Today";          // "Open" and "Ordered" both land here
}
```

**WHAT.** Anything not Completed or Cancelled is badged **"Today"**, whatever its date.

**WHY it matters.** An unsigned note is unattested, unbilled, and an incomplete record for
NOM-024 purposes. The page paints a three-week-old unsigned draft in the same teal as a patient
currently in the room, so the most important thing on the screen is invisible. Nothing else in
the product surfaces it either.

**HOW it happens.** The function reads only `status` and ignores both `docstatus` (the real
submit state) and `encounter_date`. All three are already in the API response.

**WHEN.** Present since the file was written; `docstatus` has been in `_LIST_FIELDS` throughout.

> **USER STORY.** On 3 August Dr. Ruiz is pulled to an emergency mid-encounter and never signs
> the note. On 29 August she opens Encounters → **the system shows** it badged "Today", same teal
> as her live queue → she reads it as current and scrolls past → **the database actually
> contains** `docstatus=0, status="Open", encounter_date="2026-08-03"` → **consequence:** 26 days
> unsigned, the visit is never invoiced, and no screen in the product will ever raise it.

### 2.2 The "Start" and "New" buttons do nothing

`encounters-client.tsx:333`:

```tsx
<button onClick={e => { e.stopPropagation(); }}>Start</button>
```

The handler does nothing except stop the click bubbling — so it also **removes** the row's own
navigation. Aiming for the button is worse than missing it. "New" (line 228) has no `onClick`
at all, although `/encounters/new` exists.

> **USER STORY.** Dr. Bracamontes taps **Start** on Ana Reyes → **the system shows** nothing: no
> spinner, no error → he taps twice more, assumes the app is frozen, reloads → **the database
> still contains** the same untouched Draft → **consequence:** he stops using the list page and
> navigates via the patient chart instead, which is why this has not been reported.

### 2.3 Rows past 100 cannot be reached

Lines 113-119 hardcode `page_size: 100` and never send `page`. "Load More" only reveals more of
the 100 rows already in the browser.

> **EXAMPLE.** `list_encounters` accepts `page` and clamps `page_size` to 100
> (`page_size = min(100, max(1, int(page_size)))`, `api/v1/encounters/api.py:797`). With 3,000
> encounters the KPI tile reads **3,000**, the footer reads **100**, and encounter 101 is
> unreachable by any interaction on the page.

### 2.4 Search silently misses older records

Line 141 filters the **client array**, not the server. Typing a patient name from six months ago
returns "No encounters match this filter" even though the record exists. To the user that is
indistinguishable from data loss.

### 2.5 Six useful fields are fetched and thrown away

`_LIST_FIELDS` (`api/v1/encounters/api.py:47`) already returns all of these. The list renders
none of them:

| Field | Who needs it |
|---|---|
| `encounter_time` | doctor — ordering within a day; two visits on one date are otherwise identical |
| `invoiced` | admin — revenue leak detection *(fetched; deliberately not displayed, see §4.3)* |
| `medical_department` | admin — filtering and scanning |
| `appointment_type` | both — follow-up vs new |
| `docstatus` | both — the true signed/draft state (see 2.1) |
| `encounter_done_by_name` | admin — ADR-039, who actually *signed*, which differs from the assigned practitioner when a colleague covers |

### 2.6 Nine hardcoded English strings

`"All"`, `"Today"`, `"Completed"`, `"Cancelled"`, `"Total"`, `"New"`, `"Start"`,
`"No encounters match this filter"`. This is a bilingual `es-MX` + `en-US` product and the rest
of the file correctly uses `t()`. Per CLAUDE.md §13.10 this is a bug, not a style preference.

### 2.7 Five API calls per page load, and a private pagination copy

Lines 121-128 fire four extra `useEncounters({page_size: 1})` calls purely to read
`pagination.total` for the KPI tiles.

Separately: `src/lib/narzim/pagination.ts` was created to de-duplicate pagination and its own
header comment names `encounters-client` as one of the four screens it replaced — but encounters
still carries its own `PAGE_SIZES = [20, 50, 100]` and its own footer, where the shared component
offers `[10, 20, 50, 100]`. The de-duplication did not land here.

---

## 3. Thinking as a doctor, then as an admin

The two roles want opposite things from the same table. This is why one flat list serves neither.

| | **Doctor** | **Admin / Front desk** |
|---|---|---|
| The question in their head | *"What do I still owe?"* | *"Is the clinic's work finished and billed?"* |
| Time direction | forward — today, now | backward — yesterday, last month |
| Scope | own encounters only — the backend already forces this (`api/v1/encounters/api.py:832`) | all providers |
| First priority | **unsigned drafts** — personal liability | **unsigned drafts** — compliance |
| Second priority | today's queue | **completed but uninvoiced** — revenue |
| The failure they fear | "I forgot to sign a note" | "we treated someone and never billed them" |

They converge on one thing — **unsigned drafts** — which today has no representation anywhere in
the product. That is why it becomes the default filter and the leftmost tile for both roles.

---

## 4. What the page shows

### 4.1 Header controls

Left to right in `AppHeader`: **Encounter date** label · `ListDateFilter` (Today / This Week /
This Month + calendar) · search · **New** (practitioners only). Per-column filters do **not** sit
here — see §4.2.

The date control is the **same `ListDateFilter`** the Patients and Appointments lists render, so
"This Month" means the same days on all three — its preset windows deliberately match
`resolve_report_window()` in `utils.py`. "Tomorrow" is not offered and future dates are disabled:
an encounter records a visit that has happened, so a future window could only return nothing.

**The KPI tiles from v1.0–v2.0 are gone.** The reference layout has none, and the date presets now
own the "Today" question the tiles were answering. Their message keys were deleted rather than
left orphaned.

### 4.2 Where each filter lives

Filter placement copies Patients and Appointments exactly, because those two already agree with
each other and a third arrangement would make the same control mean a different thing per screen:

| Filter | Lives in | Precedent |
|---|---|---|
| Encounter date | **App header** — `ListDateFilter` | Patients (`registeredLabel`), Appointments |
| Search | **App header** | both |
| New | **App header**, right-most | Patients' `Register Patient` |
| **Status** | **`STATUS` column header**, dropdown | Appointments' status popover |
| **Practitioner** | **`PRACTITIONER` column header**, dropdown | Patients' `PRIMARY PRACTITIONER` popover |

A filtering column header turns **amber with a count badge**, so an active filter is visible
without opening anything, and the rows dim while a panel is open — both lifted from Patients.

Below the header sits the **active-filter chip strip**, again as on Patients: one removable chip
per live filter plus **Clear all**. It renders only when something is actually filtering.

**Status values.** `Unsigned` · `Completed` · `Cancelled` · **`All except cancelled`**. The last
exists because the Encounter Summaries report scopes its Encounters figure with `docstatus < 2`,
and no single `status` value says that — it would need three of the four. It is backed by
`exclude_cancelled` on `list_encounters` (§7.1).

**Status is multi-select, honoured by the server (v3.5).** Up to v3.4 it was single-select,
because `list_encounters` accepted one `status` and a multi-select could then only be honoured by
filtering the rows already loaded — the same page-scoped lie the old search told. Appointments
does exactly that (`statusFilterSet.size === 1 ? … : undefined`, then a client-side pass) and it
was not copied here. `status_in` (§7.2) removes the constraint: the whole selection goes out as
one query, so the rows, the total and the page number all come from the same result and every row
is real. The panel stays open while ticking, and the chip strip renders one removable chip per
selected status.

**`All except cancelled` stays mutually exclusive with the other three.** It is not a peer: it
filters on `docstatus < 2`, not on `status`, and no set of `status` values reproduces it —
`docstatus` is authoritative and `status` is only a tiebreak (§4.4), so the two can disagree on a
row. Ticking it clears the peers; ticking a peer clears it. On `remedisys.localhost` today
`status_in=Open,Ordered,Completed` and `docstatus < 2` both return 47, which is the same
coincidence §4.2 already warns about and not a property anyone maintains.

**The practitioner filter remains single-select** — no equivalent backend parameter exists, and
none has been asked for.

**The practitioner column has no filter for a practitioner user** — the backend force-scopes them
to their own encounters (`api.py:832`), so the control could only ever be a no-op.

### 4.3 The table

Same shape as the Patients directory, deliberately: dark `#006067` header row, uppercase column
labels, `odd:bg-white even:bg-[#F9F9F9]` zebra striping, sticky header, and the shared
`TablePagination` footer. Three screens that answer "show me all the X" should not each invent
their own layout. Below `md` it collapses to a card list, the same breakpoint Patients uses.

| # | Column | Contents |
|---|---|---|
| 1 | **Patient** | avatar · name · MRN |
| 2 | **Encounter** | encounter no. · appointment no. |
| 3 | **Status** | badge, with age for unsigned |
| 4 | **Date / Time** | `Aug 29, 2026` · `09:40` |
| 5 | **Practitioner** | initials chip in the practitioner's stable colour · name · *signed by* when different |
| 6 | **Department** | `medical_department` |
| 7 | **Reason** | chief complaint, truncated with a title tooltip |
| 8 | — | `Continue` (drafts, practitioners only) · `[⋮]` menu |

Columns 3 and 5 carry their own filter dropdowns — see §4.2.

Columns 4–6 are fields the previous version fetched and discarded.

**No billing state in this table.** A `Not invoiced` flag shipped in the Status column earlier on
2026-08-31 and was **removed the same day by request**. Two reasons it was right to go: the
column is called Status and was carrying two unrelated kinds of status — clinical (is the note
signed?) and financial (has it been billed?) — and mixing them makes a doctor's work queue read
as a billing report. `invoiced` is still on every row of the API response, so a dedicated Billing
column or an "Uninvoiced" filter can be added later without a backend change; it is simply not
shown today.

**No sort affordances.** The Patients table offers them because `list_patients` takes `sort_by` /
`sort_dir`; `list_encounters` takes neither and always orders `encounter_date desc,
encounter_time desc`. A caret that silently sorted only the 20 rows on screen would be the same
class of lie as the old search — see gap 6 in §6.

**Status is derived from `docstatus` first, `status` only as tiebreak**, because a Draft can carry
`status = "Ordered"` and only `docstatus` says whether anyone has attested:

| Condition | Badge | Colour |
|---|---|---|
| `docstatus === 2` or `status === "Cancelled"` | Cancelled | rose |
| `docstatus === 1` or `status === "Completed"` | Completed | emerald |
| draft, `encounter_date` is today | In progress | teal |
| draft, `encounter_date` is older | **Unsigned · Nd** | **amber** |

The `· Nd` age counter is the whole fix for 2.1 — the difference between "in progress" and
"forgotten".

### 4.4a Defaults, and the trap in them

**The screen opens on This Week, all statuses**, for every role. This Week matches the
Appointments list, which also opens on the current week rather than on everything ever recorded.
The URL always wins: a report card arriving with `?preset=month` or an explicit range keeps its
own period, because a default that overrode an incoming link would show the wrong period under
the figure the reader just clicked.

**Why the status default is no longer Unsigned.** Up to v3.3 a practitioner landed on `Unsigned`.
That was right while the date scope defaulted to *all dates*. It stops being right the moment the
date defaults to This Week, because the two compose into **"unsigned, this week"** — and measured
on 2026-08-31, a **Monday**:

| | |
|---|---|
| This Week (Mon 31 Aug – Sun 6 Sep) | **1** encounter, **0** unsigned |
| Unsigned, all time | **25**, oldest **25 days** old |

So the composed default rendered an **empty list** while every unsigned note in the clinic sat
just outside the window — defeating defect 2.1, which this screen exists to fix. Landing on
"this week, everything" is at least coherent with the date chip the reader can see.

**The cost, stated plainly.** Unsigned notes are no longer the landing view. They are two actions
away: Status → Unsigned, then remove the date chip. On a Monday the default view is thin by
nature — 1 row on 2026-08-31 — and fills as the week runs.

**If unsigned-first matters more than This Week**, the fix is to default the date scope to *all
dates* again, or to have choosing `Unsigned` clear the date scope automatically on the grounds
that "what have I not signed?" is an all-time liability question rather than a period one. Both
are one-line changes; neither is made here, because This Week was asked for explicitly.

## 4.4 Row action menu `[⋮]`

The pattern Appointments already has (`ActionMenu`) and Encounters lacks. **Navigation only:**

- Open note / View signed report
- Open patient chart
- Open appointment (only when the encounter has one)

**Cancel is deliberately not offered here.** Cancelling is a destructive clinical action gated by
ADR-038 to the assigned practitioner, and it already lives inside the encounter screen where the
full note is visible. Offering it from a list row means acting against a three-line summary.

---

## 5. What happens after a click

This already works and is **not** being changed. Clicking a row routes to `/encounters/[id]`,
which renders `EncounterScreen` in one of three states derived from `docstatus`:

| Encounter state | `docstatus` | What the screen shows | Who can act |
|---|---|---|---|
| **Draft / in progress** | 0 | Full editable note — SOAP, vitals, diagnosis, prescriptions, labs, AI copilot sidebar. `Save draft` + `Sign`. | **Sign:** any practitioner (ADR-039). **Cancel:** assigned practitioner only (ADR-038). **Nurse:** save only, no Sign (ADR-022). |
| **Signed / completed** | 1 | Same layout, read-only — the signed report. Shows `encounter_done_by_name`, i.e. who actually attested. | nobody edits; print / book follow-up |
| **Cancelled** | 2 | Cancelled banner, read-only | nobody |

The real gap is that a click is the **only** thing a row can do — there is no route to the
patient chart or the appointment, and not enough on the row to decide whether opening is worth
it. The `[⋮]` menu and the richer row close that.

### Why row-click stays a full-page jump

| Approach | Pros | Cons |
|---|---|---|
| **A. Full-page jump (chosen)** | zero new code; the screen is already excellent; deep-linkable | full load + back-navigation per row when triaging |
| B. Side peek drawer, "Open full note" inside | triage without losing list position | a second tap on the way to signing |
| C. Inline expand (accordion) | no navigation at all | a real encounter does not fit in a row |
| D. Split pane — list left, note right | fastest for working a queue | breaks on tablets, which is what staff use here |

**A is chosen.** **B** solves a problem the improved row already solves: once the row carries
status, age, department and practitioner, a summary drawer adds nothing that justifies a second
tap. **C** is unusable for the content — SOAP, vitals, prescriptions and a copilot compressed
into a row is a worse editor, and users would open the full page anyway. **D** fails the
deployment reality: `encounter-screen.tsx` has no half-width layout, so it would require a
responsive rewrite of the largest component in the codebase to serve one desktop case.

---

## 6. What the backend cannot do today

Four gaps. **None are assumed** — the screen in §4 is buildable without them, with the stated
losses.

| # | Gap | Blocks | If not built |
|---|---|---|---|
| 1 | ~~No `from_date` / `to_date`~~ — **BUILT 2026-08-31**, verified on live data (§10.4) | — | — |
| 2 | No `search` / `q` parameter | server-side search (defect 2.4) | search stays scoped to the loaded page — **and must say so in the UI** rather than silently returning nothing |
| 3 | `invoiced` returned but not filterable | an "Uninvoiced" filter | moot today — billing state is not shown at all (§4.3) |
| 4 | No counts endpoint | one request for all tiles | 5 `page_size: 1` queries, one per tile |

A sixth: **no `sort_by` / `sort_dir`.** `list_encounters` always orders `encounter_date desc,
encounter_time desc`, so the table ships without sort affordances (§4.3).

~~A fifth, smaller one: `status` takes a single value, but "unsigned" means `Open` **or**
`Ordered`, so the count needs two queries and an "Unsigned" list page needs a merge.~~
**CLOSED 2026-09-04** by `status_in` (§7.2). The list merge is deleted; the count tiles still
issue their own queries, which is gap 4, not this one.

Gaps 1 and 2 are each a small additive change to an existing function and are backwards
compatible (both optional). **They are the backend owner's call and are not being made here.**

---

## 6a. Report drill-through — Encounter Summaries

`/reports/encounter-summaries` gained a **practitioner filter** (the shell's opt-in
`practitionerFilter`; earned because the report already breaks down by provider), and two of its
four KPI cards now open this list:

| Card | Opens | Definition matched |
|---|---|---|
| **Encounters** | `/encounters?preset=month&status=active` | `docstatus < 2` |
| **Unsigned Notes** | `/encounters?preset=month&status=unsigned` | `docstatus = 0` |

The other two cards — Avg Duration and Prescriptions — get no link: a ratio and a count with no
matching filtered list, and a link resolving to the wrong set is worse than none.

The Encounters card previously pointed at `/appointments?status=Completed`, a stand-in chosen only
because this list ignored URL parameters. It counted *appointments* under a card counting
*encounters*.

**Why `active` and not "no filter":** the list's unfiltered view includes cancelled encounters and
the report's figure does not. They agree today only because the database holds **zero** cancelled
encounters — luck, not equivalence.

**Verified on live data**, 2026-08-01..31, card figure against the list the card opens:

| Scope | Encounters | Unsigned |
|---|---|---|
| whole clinic | 43 = 43 | 25 = 25 |
| Adrián López Vázquez | 16 = 16 | 10 = 10 |
| Luis Vera Avilés | 6 = 6 | 2 = 2 |
| Moisés Casares Montalvo | 3 = 3 | 2 = 2 |

The practitioner rows matter most: `useReportLinks` folds the chosen practitioner into the link, so
a card showing one doctor's number opens that doctor's rows rather than the clinic's.

### 7.1 `exclude_cancelled`

Truthy drops `docstatus = 2`. The coercion treats the **strings** `"0"` and `"false"` as off —
both are truthy in Python, so a caller turning the flag off would otherwise have turned it on.
Proven by capturing the filter dict reaching `frappe.get_list` across all 8 input forms, because a
count-based test cannot distinguish on from off while no cancelled encounter exists.

### 7.2 `status_in`

Added 2026-09-04 for the multi-select Status filter (§4.2). A comma-separated subset of the same
four values `status` accepts. Whitespace around entries is stripped and duplicates dropped; a
single surviving value is sent as a plain equality rather than `IN (…)`, so the common one-status
case keeps the query plan it has always had, and an all-empty value (`","`) falls through to no
status filter rather than emitting `status IN ()`, which MariaDB rejects.

`status` wins when both arrive — the same precedence rule, for the same reason, as `date` beating
`from_date`/`to_date`: it is the older, narrower parameter every existing caller already sends.
Any unrecognised entry is a **400 `VALIDATION_ERROR`**, deliberately, so a typo cannot read as
"this clinic saw nobody".

Verified against 47 live encounters on `remedisys.localhost` (§10.5).

---

## 7. Deliberately out of scope

- **No new doctype, no schema change, no migration.**
- **No change to `EncounterScreen`** (6,630 lines) — it works.
- **No change to the ADR-038 / ADR-039 / ADR-022 permission logic.** The screen reuses the
  `canSign` / `canCancel` derivation already in `[id]/page.tsx`.
- **No second route.** The page is rebuilt at `/encounters`; a parallel list page would drift
  from this one exactly as duplicated docs have before.

---

## 8. Build checklist

**Frontend — `remedisys-ai-ehr`, `src/app/(clinic)/encounters/encounters-client.tsx`** — done 2026-08-31

- [x] **Restore the sidebar entry** (`app-shell/app-sidebar.tsx`) — see §10.1; this was not in v1.0 of this document
- [x] **Lay it out as a table** matching the Patients directory (§4.3) — this was not in v1.0/v2.0 either
- [x] **Put every filter where Patients/Appointments put it** (§4.2) — date + search in the app header, status and practitioner in their column headers, active-filter chip strip below

- [x] Derive status from `docstatus` + `status` + `encounter_date`; add the amber Unsigned badge with age (§4.3) — fixes 2.1
- [x] Wire "New" → `/encounters/new`; replace the dead "Start" with "Continue" → `/encounters/[id]` — fixes 2.2
- [x] Send `page` and `page_size`; drive the footer from `pagination.total` — fixes 2.3
- [x] Migrate onto `TablePagination` + `@/lib/narzim/pagination`; delete the private `PAGE_SIZES` — fixes 2.7
- [x] Show a visible notice while searching that the scope is the current page — makes 2.4 honest
- [x] Render `encounter_time`, `medical_department`, `encounter_done_by_name` — fixes 2.5 (`invoiced` deliberately excluded, §4.3)
- [x] Make the KPI tiles clickable filters; role-aware fourth tile (§4.1)
- [x] Add the `[⋮]` row menu, navigation only (§4.4)
- [x] Move all strings into `messages/en.json` + `messages/es.json` under `encounters` — fixes 2.6
- [x] Default filter: Unsigned for practitioners, Today for admin / front desk
- [x] `pnpm lint` · `pnpm typecheck` · both catalogs in parity

**Backend — this repo, only if §6 is approved**

- [x] `from_date` / `to_date` on `list_encounters` (gap 1) — built and verified 2026-08-31
- [ ] `search` on `list_encounters` (gap 2)
- [x] `status_in` on `list_encounters` (gap 5) — built and verified 2026-09-04
- [ ] `get_encounter_counts()` method (gap 4)
- [ ] Patch entry not required — no schema change

---

## 9. Tradeoffs

**Chosen:** rebuild the existing list in place, frontend-only, against today's API; state the
search limitation in the UI instead of hiding it.

**Rejected:** *building the backend filters first* — the seven defects in §2 are all fixable
without them, and three of them (the dead buttons, the misleading badge, unreachable rows) are
live today; blocking those on a backend change delays the fixes that matter most. *Adding a
second "new" page* — two encounter lists would drift. *Adding Cancel to the row menu* — an
unrequested destructive surface acting on a three-line summary.

**The cost of the choice:** search still misses older records until gap 2 is built, and admins
get a single-day picker rather than a range. Both are now visible to the user rather than silent,
which is the part that was actually causing harm.

---

## 10. What shipped, 2026-08-31

Frontend only. `encounters-client.tsx` went 380 → 749 lines; `app-sidebar.tsx` gained a nav entry
and an icon import; `messages/en.json` and `messages/es.json` gained 31 keys each.

Verified: **0 eslint errors, 0 type errors, 204 unit tests pass, 6,097 keys en ↔ es aligned.**
**Not yet run against live data.**

### 10.1 The thing this document got wrong

Version 1.0 said the page's problem was that it was thin. That was a symptom. The cause was one
commented-out line, `app-sidebar.tsx:342`:

```tsx
// Encounters accessible from Patient 360 → Clinical tab
// ...(isClinical ? [{ key: "encounters", label: "Encounters", … href: "/encounters" }] : []),
```

**The screen had no way in.** And the stated reason inverts what the list is for: reaching it
through Patient 360 requires already knowing *which patient* — but "what have I not signed?" and
"what did the clinic not finish?" are exactly the questions asked when you do not yet know the
patient. A list nobody can reach is a list nobody reports bugs against, which is why a button
whose whole handler was `e => { e.stopPropagation(); }` survived.

The nav entry is restored under the role gate copied verbatim from `lib/auth/route-access.ts:37`
— `nurse`, `practitioner`, `clinic_staff`, `admin`. **Front Desk is deliberately excluded**,
because route-access does not grant it `/encounters`; a nav link a role cannot follow is worse
than no link. §4.1's "admin lens" therefore means admin **or clinic_staff**, not front desk as
v1.0 stated.

### 10.2 Two decisions the build forced

**`react-hooks/set-state-in-effect` fires on both obvious page-number patterns.** Resetting the
page on a filter change, and clamping an out-of-range page, were each written as an effect and
each rejected by lint. The reset moved into the filter handlers — the new page number is already
known at the moment the filter changes, so no effect is needed to discover it. The clamp is now
applied **where the value is read**, not written back to state. Feeding the clamp into the query
params instead would have been actively wrong: `serverTotal` is 0 while a request is in flight,
so every fetch would have snapped the reader back to page 1.

**~~The Unsigned view needs two queries and a bounded merge.~~ Resolved 2026-09-04.** A draft is
`Open` *or* `Ordered`, and `status` took one value, so the list fetched `Ordered` separately and
merged it **only into page 1** — combining two independently paginated server queries under one
page number is not sound. The seam was not cosmetic: an `Ordered` draft that fell past page 1 was
invisible in the one view built to find unsigned notes. `status_in` (§7.2) makes it one query and
the merge is deleted. The count tiles still issue their own queries (gap 4).

### 10.4 The table rewrite, and the backend change it required

The card layout of v1.0–v2.0 was replaced with a table matching the Patients directory. That
change is what forced the backend addition: the shared `ListDateFilter` emits an inclusive
`[from, to]` window for every preset, and `list_encounters` accepted only an exact `date`. Adding
`from_date` / `to_date` was therefore not optional scope creep — the requested layout does not
function without it.

The addition is small and backwards compatible (both params optional, `date` still wins when
both are sent). Threaded through three layers: `list_encounters` + its `get_encounters` alias,
the BFF route's explicit param whitelist, and `EncounterListParams`.

**Verified against 42 live encounters on `remedisys.localhost`**, spanning 2026-08-06 → 2026-08-29:

| Check | Result |
|---|---|
| exact `date` still correct (regression) | api 3 = db 3 |
| full range == unfiltered total | 42 = 42 |
| `from_date` alone | api 9 = db 9 |
| `to_date` alone | api 34 = db 34 |
| two ranges partition the set | 34 + 8 = 42 |
| `date` beats range (documented precedence) | 3 = 3 |
| inverted range rejected | HTTP 400 `VALIDATION_ERROR` |
| every returned row inside the window | 9 rows, 0 outside |
| all 8 fields the table renders present | all present |

An inverted range returns a **400**, not an exception: `@handle_api_errors` maps `ValidationError`
to a 400 response by design. It is rejected rather than returned empty because an empty list is
indistinguishable from "this clinic saw nobody", which is a far worse thing to show a doctor.

### 10.5 Multi-select status, and the page-2 bug it fixed, 2026-09-04

Reported as "there is except one filter at a time, accept multiple filter". The popover already
rendered checkboxes, so it *promised* multi-select while the handler replaced the selection —
`changeFilter(filter === k ? "all" : k)`. Fixing the handler alone would have been the page-scoped
lie §4.2 rejects, so the backend gained `status_in` (§7.2) first.

Fixing it also closed a live correctness bug that had nothing to do with the request. "Unsigned"
is two backend statuses, and the old code merged the second one into **page 1 only**:

```ts
const mergeOrdered = filter === "unsigned" && page === 1;   // deleted
```

**USER STORY.** Dr. Bracamontes filters Status → Unsigned over three months to clear his backlog
→ **the system shows** page 1 with `Open` and `Ordered` drafts merged, and a total that counts
only `Open` → he clicks page 2 → the request sent is `status="Open"` alone, so **the database
contains** `Ordered` drafts in that window that **the response never includes** → **consequence:**
unsigned notes are invisible in the one screen built to find them. Unattested, unbilled, and an
incomplete record under NOM-024.

**EXAMPLE.** Verified on `remedisys.localhost`, 47 encounters (26 `Open` / 0 `Ordered` /
21 `Completed` / 0 `Cancelled`), calling `list_encounters` directly:

```
status_in=Open,Ordered              -> 26 rows, total=26
status_in=Open,Ordered,Completed    -> 47 rows, total=47
status_in=Completed,Cancelled       -> 21 rows, total=21
status_in=" Open , Ordered "        -> 26 rows, total=26     (whitespace)
status_in=Open,Open                 -> 26 rows, total=26     (duplicates)
status_in=","                       -> 47 rows, total=47     (no filter, not IN ())
status_in=Bogus                     -> 400 VALIDATION_ERROR
status=Completed & status_in=Open   -> 21 rows, total=21     (status wins)
```

Row count equals `total` in every case, which is the property the old merge could not hold. The
`Ordered` bucket is empty on this site, so the merge path could not have been caught by a count
test here — it was found by reading the workaround's own comment, which had named `status__in` as
the fix since 2026-08-31.

Frontend: `pnpm lint`, `tsc --noEmit` and 357 tests clean; catalogs in parity; no new strings.

### 10.3 Still true after the build

Gaps 2–6 remain open. In particular **search still only looks at the loaded page** — it now says so in the UI and also matches the practitioner name, but until gap 2 exists
a patient from six months ago is not findable by typing their name.

---

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.5 | 2026-09-04 | Anant Sharma (AI-assisted) | Status filter is multi-select, backed by a new `status_in` on `list_encounters` (§7.2). Deletes the page-1-only `Ordered` merge, which hid unsigned drafts past page 1 (§10.5). `All except cancelled` stays mutually exclusive — it is a `docstatus` lens, not a peer. Gap 5 closed |
| 3.4 | 2026-08-31 | Anant Sharma (AI-assisted) | §4.4a: date scope now defaults to This Week by request. Status default relaxed from Unsigned to none — measured, the two composed into an empty landing list while 25 unsigned notes sat outside the window |
| 3.3 | 2026-08-31 | Anant Sharma (AI-assisted) | §6a: Encounter Summaries drill-through — practitioner filter on the report, Encounters and Unsigned Notes cards now open this list on matching definitions. `exclude_cancelled` added to `list_encounters` (§7.1); `All except cancelled` added to the Status filter |
| 3.2 | 2026-08-31 | Anant Sharma (AI-assisted) | `Not invoiced` flag removed from the Status column by request — the column was carrying clinical and financial state at once. `invoiced` still fetched, simply not displayed |
| 3.1 | 2026-08-31 | Anant Sharma (AI-assisted) | §4.2 rewritten: filters relocated to match Patients/Appointments — status and practitioner into column-header dropdowns, active-filter chip strip below the header, standalone filter strip removed. Records why status stays single-select where Appointments went multi |
| 3.0 | 2026-08-31 | Anant Sharma (AI-assisted) | Rebuilt as a table matching the Patients directory; KPI tiles dropped. Backend gained `from_date`/`to_date`, verified on live data — gap 1 closed, sort added as gap 6 |
| 2.0 | 2026-08-31 | Anant Sharma (AI-assisted) | Built, frontend only. §10 added: the sidebar entry was commented out — the real cause of the rot — plus the two patterns lint rejected. §4.1 admin lens corrected to admin/clinic_staff; Front Desk has no route access |
| 1.0 | 2026-08-29 | Anant Sharma (AI-assisted) | First version. Records that the page already exists; specifies the list rebuild, the doctor/admin split, click behaviour, and the four backend gaps |
