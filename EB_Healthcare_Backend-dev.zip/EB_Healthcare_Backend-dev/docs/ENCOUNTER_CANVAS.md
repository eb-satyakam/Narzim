# Encounter Canvas — How It Works

**Doc status:** living · **Created:** 2026-09-28 by Divyanshu (AI-assisted) · **Updated:** 2026-09-28 by Divyanshu (AI-assisted) · **Version:** 1.4

**Status of the build: In progress.** See [§6](#6-build-order) for the per-file record.

**This document owns the mechanism.** The storage-format decision (`canvas_data` — raw HTML — is
the only artifact stored; there is no separate rendered file) and its rejected alternatives are
owned by [`adr/adr-097-encounter-canvas-html-only-no-rendered-file.md`](adr/adr-097-encounter-canvas-html-only-no-rendered-file.md)
(supersedes [`adr/adr-095-...`](adr/adr-095-encounter-canvas-storage-format.md), which originally
stored both `canvas_data` and a rendered PNG); this document does not restate that reasoning.

## 1. Scope

| In scope | Out of scope |
|---|---|
| A practitioner sketching a diagram (pen, marker, line, arrow, rectangle, circle, text, eraser) during a Guided Encounter | The "Continue to Pad" step in the product mockup — no Prescription Pad exists anywhere in this codebase; the button is hidden until that is separately scoped |
| Multiple canvases per one `Patient Encounter` | Editing a canvas from the Classic encounter view (guided-view only for this iteration) |
| Saving a canvas so it can be **reopened and edited again**, not just exported once | Real-time collaborative drawing (two users on one canvas at once) |
| Flagging a canvas `attach_to_rx` for a future prescription flow to pick up | Actually attaching to or printing a prescription — no Rx print flow exists yet; the flag is stored inert |
| Printing a canvas as a flattened image | — |

## 2. Why a new doctype, not an existing one

- **Not `Clinical Document`** — deleted 2026-09-09 for a real permission hole (any EB_-role user could
  read any patient's private attachments through it). See `patches/v0/drop_clinical_document_20260909.py`.
- **Not Narzim Drive** — `services/drive.py`'s `move_to_patient()` is deliberately copy-then-trash,
  with its own separate permission authority, so Drive's model never leaks into patient-chart
  permissions. A record that must be governed by one `Patient Encounter`'s own permissions belongs
  under its own doctype, not Drive's.
- **A new doctype, `Encounter Canvas`**, links directly to `Patient Encounter` and carries its own
  DocPerm block in its own JSON (this is our own doctype, not core — no `eb_docperm_spec.json` /
  Custom DocPerm indirection needed, unlike `Practitioner Availability` or `Holiday List`, which are
  core Healthcare/Frappe doctypes we cannot edit directly).

## 3. Doctype: `Encounter Canvas`

| Field | Type | Notes |
|---|---|---|
| `encounter` | Link → Patient Encounter | Required, **not** unique — this is what allows multiple canvases per encounter |
| `patient` | Link → Patient | Read-only, denormalized from `encounter.patient` at creation — never caller-supplied, so a client can only say which encounter a canvas belongs to, never claim a different patient for it. Lets a canvas be listed/filtered by patient without joining through Patient Encounter |
| `practitioner` | Link → Healthcare Practitioner | Read-only, denormalized from `encounter.practitioner` at creation, same reasoning as `patient` |
| `appointment` | Link → Patient Appointment | Read-only, denormalized from `encounter.appointment` at creation. Blank whenever the source encounter's own `appointment` is blank (e.g. a walk-in) |
| `title` | Data | Optional label, shown in the multi-canvas list since there can be several per encounter |
| `canvas_data` | Code (HTML) | The only artifact stored — raw HTML, rendered verbatim wherever a picture is needed (the PMR summary today). Opaque to the backend; owned by the frontend editor. See ADR-097 (supersedes ADR-095, which also stored a rendered `image` PNG file — removed). **Not `Long Text`** — found live, 2026-09-28: Frappe's own save-time HTML sanitizer runs unconditionally on any `Long Text`/`Text` field containing `<`/`>`, and silently stripped every SVG shape attribute out of a value containing literal markup. `Code` is unconditionally exempt (`base_document.py::_sanitize_content()`'s own docstring) — which is also why rendering it anywhere requires a script-disabled sandbox (§4) |
| `attach_to_rx` | Check | Inert until a prescription/Rx print flow exists (none does today) |
| `print_mode` | Select (`Full page` / `Compact`) | Matches the mockup's "Print: full page" control |

`track_changes: 1` per CLAUDE.md §7. Own permissions block: `EB_Practitioner` gets
create/read/write (no delete — a saved clinical sketch is not casually removable, consistent with
this app's audit-trail expectations elsewhere); `EB_Healthcare Admin` gets full CRUD.

## 4. API — `api/v1/encounter_canvas/api.py`

All whitelisted, all permission-checked against the specific `encounter` via
`require_permission("Patient Encounter", <perm>, doc=encounter)` — never a bare doctype-level check,
since a canvas is only ever read/written in the context of one encounter the caller must already be
allowed to touch.

| Method | Purpose |
|---|---|
| `list_canvases(encounter)` | Every canvas for one encounter — `title`, `attach_to_rx`, `print_mode`, `modified`; **not** `canvas_data` (kept out of the list payload; only fetched when a specific canvas is opened for editing) |
| `get_canvas(name)` | One canvas in full, including `canvas_data` (returned verbatim, no parsing), for re-opening in the editor |
| `save_canvas(encounter, name=None, title=None, canvas_data=None, attach_to_rx=0, print_mode=None)` | Creates when `name` is omitted, else updates. Stores `canvas_data` verbatim — no JSON parse/re-encode, no `image_base64`/rendered-file parameter (removed by ADR-097) |
| `delete_canvas(name)` | Admin-only (permission check enforces this — `EB_Practitioner` has no `delete` grant) |

Every `save_canvas`/`delete_canvas` call ends by calling
`services/encounter_summary_sync.py::sync_encounter_summary(encounter)`, shared with
`Encounter Advice` — see [ADR-096](adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md)
for why: the canvas's existence needs to surface inside the encounter's *existing* Patient Medical
Record entry, not as a separate row, and that requires updating a custom field on `Patient Encounter`
itself every time a canvas changes. **How that field renders a picture** (embedding `canvas_data`
verbatim in a sandboxed iframe, not parsing or rasterizing it) is owned by
[ADR-097](adr/adr-097-encounter-canvas-html-only-no-rendered-file.md).

## 5. Frontend

- New component (internal name **not** `Canvas` — `v3/canvas-chrome.tsx` already means the guided
  view's single-page layout shell; the sketch tool is `encounter-sketch-panel.tsx` or similar,
  labelled "Canvas" in the UI only).
- Drawing surface is real DOM/SVG (strokes as SVG paths, shapes as elements, text as HTML), not the
  native `<canvas>` element — so it serializes to a self-contained HTML document that `canvas_data`
  stores directly (ADR-097). There is no PNG export/upload step (`html2canvas-pro` is not needed for
  this field) — anything that needs a picture renders `canvas_data` itself.
- New step slots into `v3/steps.tsx` alongside `CaptureStep` / `ReviewSoapStep`.
- "Continue to Pad" is hidden/disabled — see §1.

## 6. Build order

| # | Piece | Status |
|---|---|---|
| 1 | ADR-095 (storage format decision) — superseded by ADR-097 | ✅ Done |
| 2 | This doc | ✅ Done |
| 3 | `Encounter Canvas` doctype (JSON + controller) | ✅ Done |
| 4 | `api/v1/encounter_canvas/api.py` | ✅ Done |
| 5 | ADR-096 + `services/encounter_summary_sync.py` retrofit (PMR surfacing) | ✅ Done |
| 6 | ADR-097 — `image` removed, `canvas_data` rendered verbatim via sandboxed iframe | ✅ Done |
| 7 | Frontend sketch component + guided-view step wiring | 🔲 Not started |
| 8 | `CHANGELOG.md` / `WORK_LOG.md` entries | 🔲 Not started |

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.4 | 2026-09-28 | Divyanshu (AI-assisted) | ADR-097: `image` (rendered PNG) removed entirely — `canvas_data` (HTML) is the only stored artifact, rendered verbatim in a sandboxed iframe rather than parsed/rasterized. `save_canvas()` no longer JSON-encodes `canvas_data` or accepts `image_base64` |
| 1.3 | 2026-09-28 | Divyanshu (AI-assisted) | `canvas_data` fieldtype corrected from `Long Text` to `Code` — Frappe's own save-time HTML sanitizer was silently stripping SVG attributes from any value containing `<`/`>`; `Code` is unconditionally exempt |
| 1.2 | 2026-09-28 | Divyanshu (AI-assisted) | Retrofit: save/delete now call `sync_encounter_summary()` so the canvas surfaces in the encounter's existing Patient Medical Record entry (ADR-096) |
| 1.1 | 2026-09-28 | Divyanshu (AI-assisted) | Added denormalized `patient`/`practitioner`/`appointment` fields, read-only, populated from the encounter at creation |
| 1.0 | 2026-09-28 | Divyanshu (AI-assisted) | Initial version |
