# Remedisys — Complete Product Roadmap

**Doc status:** living · **Created:** 2026-06-04 by Sarvesh-SocialAngel · **Updated:** 2026-08-13 by Sarvesh-SocialAngel · **Version:** 1.0

> **This is the master product plan.** It covers every screen, every
> user-facing feature, and every AI capability — designed together, built
> in phases by screen cluster.
>
> **Companion docs:**
> - `CLAUDE.md` — engineering rules, AI architecture, non-negotiables
> - `docs/architecture/SYSTEM_DESIGN.md` — backend (Frappe) component map
> - `docs/flows/WORKFLOWS.md` — backend end-to-end request flows
> - `docs/planning/PHASES.md` — backend build phases
> - `docs/adr/` — all architectural decisions
> - `Healthcare_next_app/docs/SYSTEM_DESIGN_FRONTEND.md` — frontend architecture (Next.js, BFF, RBAC) — lives in frontend repo
> - `Healthcare_next_app/docs/AUTHENTICATION.md` — full auth sequence diagrams — lives in frontend repo
>
> **⚠️ STATUS CORRECTION — 2026-08-13. This document's AI plan was overtaken by reality.**
>
> The line below used to read *"Zero AI in this phase — do not build them now."* **That is no
> longer true and has not been true for months.** AI capture shipped 2026-05-15; the Encounter
> Copilot went live around 2026-07-23 and is in production today: OpenAI `gpt-5-mini`, Deepgram
> `nova-3`, a 36-tool agent, 18 AI doctypes, `api/v1/ai/api.py` at 1,778 lines.
>
> **Consequences for reading this document:**
> - The **screen designs and clinical requirements below remain valid and useful.**
> - The **phase ordering, "do not build AI yet" instructions, and eval gates were not
>   followed.** Do not plan AI work from them.
> - Note this file's phase numbers differ from `README.md`/`CLAUDE.md` (here Phase 3 =
>   "Encounter + Core AI", Phase 5 = "Operations + Suggestions"). Two numbering schemes exist.
> - **For anything AI, use [`docs/ai/`](./docs/ai/):**
>   [`REMEDISYS_AI_MASTER_PLAN.md`](./docs/ai/REMEDISYS_AI_MASTER_PLAN.md) is the authoritative
>   plan; [`CURRENT_SYSTEM_AUDIT.md`](./docs/ai/CURRENT_SYSTEM_AUDIT.md) is what is actually
>   true, with `file:line` evidence; [`DECISION_LOG.md`](./docs/ai/DECISION_LOG.md) records how
>   the divergence happened and who made each change.
>
> **Original (now historical) phase note:** Connect all Next.js screens to Frappe backend.
> Every screen functional with real data. Zero AI in this phase.

---

## Users and Roles

| Role | Frappe Role | What they do |
|---|---|---|
| **Front Desk** | Healthcare Receptionist | Appointments, patient registration, billing, check-in |
| **Nurse** | Nurse | Vitals, lab collection, immunization, patient prep |
| **Doctor** | Physician | Encounters, diagnosis, prescriptions, full patient chart |
| **Admin** | System Manager | All screens + user/provider/department management |

---

## Screen Index

| # | Screen | Roles | Phase | AI? |
|---|---|---|---|---|
| 01 | Login | All | 1 | — |
| 02 | Dashboard | All (role-specific) | 1 | — |
| 03 | Patient List | All | 1 | — |
| 04 | Patient Registration | Front Desk, Admin | 1 | — |
| 05 | Appointments — Calendar | Front Desk, Doctor (view), Admin | 2 | — |
| 06 | Appointments — Book / Edit | Front Desk, Admin | 2 | — |
| 07 | Patient Chart | Doctor, Nurse (partial), Admin | 2 | ✓ summary |
| 08 | Patient Encounter | Doctor, Admin | 3 | ✓ core AI screen |
| 09 | Vitals Entry | Nurse, Doctor (view) | 3 | ✓ anomaly alert |
| 10 | Lab Orders + Results | Doctor (order), Nurse (collect), Admin | 3 | ✓ suggestions |
| 11 | Prescriptions | Doctor, Admin | 3 | ✓ safety check |
| 12 | Immunization | Nurse, Doctor, Admin | 4 | — |
| 13 | Documents | All (role-scoped) | 4 | — |
| 14 | Billing + Invoices | Front Desk, Admin | 4 | — |
| 15 | Insurance Claims | Front Desk, Admin | 4 | — |
| 16 | Messages | All | 5 | — |
| 17 | Notifications | All | 5 | — |
| 18 | Reports | All (role-filtered) | 5 | — |
| 19 | Global Search | All | 5 | — |
| 20 | Providers | Admin (CRUD), others (view) | 6 | — |
| 21 | Departments | Admin (CRUD), others (view) | 6 | — |
| 22 | Settings | Admin | 6 | — |
| 23 | Admin Panel | Admin | 6 | — |

---

## Complete Screen Designs

---

### 01 — Login

**Roles:** All.
**Frappe:** `POST /api/method/login`.

**Functionality:**
- Email + password form (es-MX labels default, en-US toggle)
- "Forgot password" link → Frappe reset email flow
- On success: role detected → redirect to role default route
- On failure: clear error message (wrong credentials / account locked)
- Session persists until explicit logout or 8-hour inactivity

**RBAC routing on success:**
```
Front Desk  →  /desk/appointments
Nurse       →  /nurse/patients
Doctor      →  /doctor/encounters
Admin       →  /admin/settings
```

**AI:** none.

---

### 02 — Dashboard

**Roles:** All. Each role sees a different dashboard.
**Frappe:** `Patient Appointment`, `Patient Encounter`, `Vital Signs`.

#### Front Desk Dashboard
- Today's appointment list (time, patient name, practitioner, status)
- Check-in queue (arrived but not seen)
- Quick "Book Appointment" button
- Today's billing summary (invoices created, pending payments)

#### Nurse Dashboard
- Patients in clinic today waiting for vitals
- Pending lab sample collections
- Due immunizations (patients scheduled today with pending shots)

#### Doctor Dashboard
- Today's scheduled encounters (time, patient, complaint)
- Pending lab results to review
- Encounters in Draft status (started, not submitted)
- AI sessions in progress (recording / Stopped / SOAP ready)

#### Admin Dashboard
- Clinic-wide stats: appointments today, encounters submitted, invoices raised
- Pending user access requests
- System health (AI Settings, Deepgram status, last background job run)

**AI:** Doctor dashboard shows AI session status cards (Recording / SOAP ready / Failed).

---

### 03 — Patient List

**Roles:** All (same list, different action buttons).
**Frappe:** `Patient`.

**Functionality:**
- Paginated table: Name, DOB, Sex, Blood Group, Phone, Status, Last Visit
- Search by name, phone, MRN
- Filter by: Status (Active / Inactive), Sex, Blood Group, Age range
- Sort by: Name, Last Visit, Registration Date
- Row click → Patient Chart
- "New Patient" button (Front Desk, Admin only)
- Export to CSV (Admin only)

**AI:** none.

---

### 04 — Patient Registration

**Roles:** Front Desk, Admin.
**Frappe:** `Patient` (create/edit).

**Functionality:**

*Mandatory fields:*
- First name, paternal surname, maternal surname (es-MX name pattern)
- Date of birth
- Sex
- CURP (Mexican national ID — optional but recommended)
- Phone number
- Email

*Optional fields:*
- Blood group, Rh factor
- Emergency contact (name, phone, relationship)
- Preferred language (es-MX / en-US — used for consent text)
- Insurance provider + policy number
- Address

*Actions:*
- Save as Draft (incomplete registration)
- Save and Check In (immediately adds to today's queue)
- Duplicate detection: warn if same name + DOB already exists
- Print registration summary

**AI:** none.

---

### 05 — Appointments — Calendar View

**Roles:** Front Desk (full), Doctor (view own), Admin (all).
**Frappe:** `Patient Appointment`, `Healthcare Practitioner Schedule`.

**Functionality:**
- Calendar with Day / Week / Month views (default: Day)
- Slots colored by status: Scheduled (blue), Arrived (green), Completed (grey), Cancelled (red)
- Provider filter: show one or all providers
- Department filter
- Click empty slot → open "Book Appointment" form
- Click existing appointment → open appointment detail popover:
  - Patient name, complaint, status
  - Actions: Check In / Cancel / Reschedule / View Patient Chart
- Drag-and-drop reschedule (Day view only)
- Today's walk-in queue: separate panel showing arrived patients without appointment

**AI:** none.

---

### 06 — Book / Edit Appointment

**Roles:** Front Desk, Admin.
**Frappe:** `Patient Appointment` (create/edit), `Healthcare Practitioner Schedule` (read).

**Functionality:**
- Patient search (typeahead by name or MRN)
- "New Patient" shortcut if not found
- Practitioner select
- Department select (auto-filters practitioners)
- Date picker → live slot availability from Frappe schedule
- Appointment type (New Visit / Follow-up / Procedure / Teleconsult)
- Chief complaint (free text, brief)
- Duration override
- Notes for front desk
- Appointment confirmation: send SMS / email (via Frappe Communication)
- Edit mode: all fields editable; cancellation requires a reason

**AI:** none.

---

### 07 — Patient Chart

**Roles:** Doctor (full), Nurse (partial: no prescriptions or encounter editing), Front Desk (demographics + appointments only), Admin (full).
**Frappe:** `Patient` + all linked doctypes.

**Layout:**
```
Left panel (fixed):                Right panel (tabbed content):
  - Patient photo                    Tabs:
  - Name, age, sex, blood group        Overview
  - CURP / MRN                         Encounters
  - Phone, email                        Vitals
  - Allergies (red badges)              Labs
  - Active problems (tags)              Prescriptions
  - Insurance                           Immunization
  - "New Encounter" button              Documents
                                        Billing
```

#### Overview tab
- Active medications list (from latest encounter prescriptions)
- Allergy list with severity
- Problem list (diagnoses from past encounters, ICD codes)
- Last 3 vitals readings (trend mini-chart)
- Upcoming appointments

#### Encounters tab
- Timeline of all past Patient Encounters
- Each row: date, practitioner, chief complaint, status (Draft/Submitted)
- Click → open read-only encounter summary
- "New Encounter" button (Doctor only)

#### Vitals tab
- Table of all Vital Signs records (date, BP, pulse, temp, weight, SpO2)
- Trend line charts: BP over time, weight over time
- "Add Vitals" button (Nurse, Doctor)

#### Labs tab
- List of all Lab Tests: date, panel name, status (Ordered/Sample Collected/Result Available)
- Expand row → view individual test results with reference ranges
- Abnormal results highlighted in red
- "Order Lab" button (Doctor)

#### Prescriptions tab
- Medication history: drug name, dosage, frequency, prescribed date, encounter
- Active vs past medications grouped
- Allergy conflict flag if prescribed drug matches an allergy

#### Immunization tab
- Vaccination record: vaccine, date, dose, administered by
- Overdue vaccines highlighted (based on standard schedule)
- "Add Immunization" button (Nurse, Doctor)

#### Documents tab
- Uploaded files: type (Lab Report / Referral / Consent / Other), date, uploaded by
- Preview PDF inline
- Upload button (all roles except view-only)

#### Billing tab
- All invoices for this patient: date, amount, status (Paid/Unpaid)
- Click → open invoice detail

**AI:** AI context summary card in Overview tab (Phase AI-2):
- "Patient context last updated: [date]"
- Structured summary: active meds, allergies, recent diagnoses
- Link to `AI Encounter Context Snapshot` used to generate it
- Never narrative — always structured fields (see ai-ux-design-risks.md §3)

---

### 08 — Patient Encounter ← CORE AI SCREEN

**Roles:** Doctor (full CRUD), Admin (full), Nurse (view only after submission).
**Frappe:** `Patient Encounter`, `Drug Prescription`, `Lab Prescription`.

This is the central product screen. It has the deepest manual functionality
and is the primary surface for every AI feature.

#### Manual functionality (complete)

**Header bar (always visible):**
- Patient name + age + sex (link → Patient Chart)
- Encounter date + time
- Practitioner name
- Status badge: Draft / In Progress / Submitted
- "Save Draft" button (auto-saves every 2 minutes)
- "Submit Encounter" button (requires all mandatory fields)
- "Print Encounter" button

**Section 1 — Chief Complaint**
- Free text, max 500 chars
- Onset picker: today / X days ago / X weeks ago
- Severity: 1–10 slider

**Section 2 — History of Present Illness**
- Free text editor (rich text: bold, italic, bullet list)
- Structured fields:
  - Duration
  - Character of complaint (aching / sharp / burning / pressure / other)
  - Location (body diagram click — optional)
  - Aggravating factors
  - Relieving factors
  - Associated symptoms (checklist: nausea, vomiting, fever, dizziness, etc.)

**Section 3 — Review of Systems**
- System-by-system checklist (Cardiovascular, Respiratory, GI, Neuro, MSK, etc.)
- "All negative" shortcut
- Free text notes per system

**Section 4 — Physical Examination**
- General appearance
- Per-system structured fields: Heart, Lungs, Abdomen, Neuro, Skin
- Free text for each system
- "Normal exam" shortcut populates normal findings

**Section 5 — Assessment / Diagnosis**
- Primary diagnosis: ICD-10 / CIE-10 code search (from Frappe's `Diagnosis` doctype)
- Additional diagnoses: add up to 5
- Clinical impression (free text)
- Chronic vs acute toggle per diagnosis

**Section 6 — Plan**
- Free text plan
- Ordered actions checklist: Labs ordered / Imaging ordered / Referral made / Follow-up scheduled

**Section 7 — Prescriptions**
- Add medication: drug search from formulary (Frappe `Medication` doctype)
- Per prescription: dosage, frequency, duration, route, special instructions
- Allergy conflict alert: if drug matches patient's Allergy list, red banner appears
- Drug interaction alert: if two prescribed drugs interact (Phase AI-3 validator)
- Print prescription (separate print format)

**Section 8 — Lab Orders**
- Add lab test from panel list (Frappe `Lab Test Template`)
- Urgency: Routine / Urgent / STAT
- Clinical indication (pre-filled from diagnosis)
- Order prints to lab printer on save

**Section 9 — Follow-up**
- Follow-up in: X days / weeks / months
- Preferred practitioner (defaults to current)
- Notes for scheduling

#### AI functionality (same screen, same phase)

**AI Sidebar / Overlay** (ADR-008: FAB → popover → fullscreen):

```
States visible via FAB status dot:
  ● grey      = AI available, not started
  ● amber pulse = Recording / Reconnecting
  ● green     = Stopped (transcript saved)
  ● orange    = SOAP draft ready
  ● red       = AI error / unavailable
```

**Recording flow:**
- FAB click → popover opens
- Consent checkbox (text in patient's preferred language — LFPDPPP Art. 17)
- "Start Recording" → browser opens WSS direct to Deepgram (ADR-009)
  - Token minted by Frappe backend (`start_session`)
  - Audio: Opus 250ms chunks, browser-direct to Deepgram
- Live transcript panel: finalized utterances appear in real time
  - Speaker label: Doctor / Patient / Unknown
  - Interim transcripts shown muted; finals appear solid
  - Scrolls to latest; manual scroll pauses auto-scroll
- "Stop Recording" → drain 1.5s → session marked Stopped
- Idle timeout: 5 min no audio → auto-close with alert

**SOAP Draft generation (post-recording):**
- "Generate SOAP" button in sidebar (appears after Stop)
- Frappe RQ background job:
  1. Load all `AI Transcript Segment` rows for session
  2. LLM call 1: transcript cleanup (prompt `transcript_cleanup_v1.es-MX.txt`)
  3. LLM call 2: SOAP generation, schema-locked JSON (prompt `soap_v1.es-MX.txt`)
  4. Pydantic validation; single retry on schema failure
  5. Persist `AI SOAP Draft`
  6. `frappe.publish_realtime` → sidebar receives `soap.ready`
- Each LLM call → `AI Prompt Log` row (hash + tokens, not raw content)

**SOAP draft panel:**
- Four collapsible sections: Subjective / Objective / Assessment / Plan
- Each section: AI-generated text + "Accept" / "Edit" / "Reject" controls
- Confidence badge per section
- Validation state badge: Unvalidated / Validated Pass / Validated Warn / Validated Block
- "Regenerate section" button (section-level; triggers a new LLM call)
- "Regenerate all" button
- "Insert into Encounter" → copies accepted section text into the corresponding
  manual form field (physician in control — REST PUT as logged-in user, Rule 6)
- AI's contribution tracked in `AI Recommendation Log` (not in Frappe audit log)

**Safety validators (run automatically before SOAP is marked Validated):**
- Allergy conflict: SOAP plan vs patient allergies
- Drug interaction: prescribed drugs vs each other (licensed drug DB)
- Vitals anomaly: flagged vitals not addressed in plan
- Missing data: mandatory fields empty (e.g., diagnosis missing)
- Red flags: keyword + classifier scan on transcript
  (chest pain, stroke FAST, suicidal ideation, critical vitals)
  → red banner in sidebar; physician must click "Acknowledged" to dismiss
  → acknowledgment logged in `AI Recommendation Log`

**AI Suggestions (Phase 5 only — feature-flagged OFF until eval gate passed):**
- ICD / CIE-10 suggestions (Week 1)
- Lab suggestions (Week 2)
- Differential diagnosis (Week 3)
- Medication suggestions — highest risk; full validator pipeline required (Week 4)

Each suggestion:
- Confidence score (always visible)
- Validation state (always visible)
- Source: transcript segment IDs + context snapshot ID
- Accept / Edit / Reject buttons (mandatory; no implicit acceptance)
- Logged to `AI Recommendation Log`

**AI failure modes (Rule 7 — AI failure must not break encounter):**
- Deepgram down → sidebar shows "AI transcription unavailable"; Encounter form unaffected
- Anthropic down → SOAP generation fails gracefully; physician writes manually
- RQ job fails → `soap.failed` event → sidebar shows "Generation failed — try again"
- JS error in sidebar → wrapped in try/catch; form save not blocked

---

### 09 — Vitals Entry

**Roles:** Nurse (CRUD), Doctor (view + override), Admin.
**Frappe:** `Vital Signs`.

**Functionality:**
- Link to Patient + Encounter (Encounter field optional — can record outside an encounter)
- Fields: Pulse rate, BP (systolic/diastolic), Temperature (°C), Respiratory rate,
  SpO2, Weight (kg), Height (cm), BMI (auto-calculated), Head circumference (paediatric)
- Normal range indicators: values outside range highlighted immediately
- "Quick vitals" shortcut: only BP + pulse + temp (for fast triage)
- History: last 5 readings shown alongside for comparison
- Submit → saved to `Vital Signs` doctype + links to encounter if provided

**AI:** Vitals anomaly validator (Phase AI-3):
- When vitals are saved, checks for patterns requiring clinical attention
- Examples: BP > 180/120 → alert "Hypertensive urgency — confirm with doctor"
- Alert shown in sidebar on the Encounter screen (not a blocker — physician acknowledges)
- Logged to `AI Recommendation Log`

---

### 10 — Lab Orders + Results

**Roles:** Doctor (order + view results), Nurse (collect sample + update status), Admin.
**Frappe:** `Lab Test`, `Lab Test Template`, `Lab Test Result`.

#### Doctor view
**Order side:**
- Select patient + link to encounter
- Search lab test templates (panel name, e.g. "CBC", "Metabolic Panel", "Lipid Panel")
- Add multiple panels in one order
- Urgency: Routine / Urgent / STAT
- Clinical indication
- Print lab requisition

**Results side (when results available):**
- Test name, result value, unit, reference range
- Abnormal results highlighted (red = critical, amber = borderline)
- Trend: if same test ordered before, mini-chart shows trend
- Download / print PDF of result

#### Nurse view
- List of pending sample collections for today
- Click row → mark "Sample Collected" + timestamp + collector name
- Reject sample: reason + notify ordering doctor

**AI — Lab suggestions (Phase AI-4, feature-flagged):**
- After SOAP generation, AI may suggest labs based on assessment
- Shown as suggestion cards in sidebar with confidence score
- Doctor accepts → lab added to order list
- Never auto-ordered
- Source: transcript + context snapshot (never raw lab PDF — see ai-ux-design-risks.md §3)

---

### 11 — Prescriptions

**Roles:** Doctor (CRUD), Admin (view).
**Frappe:** `Drug Prescription` (child of `Patient Encounter`), `Medication`.

**Functionality (within Encounter form — Section 7 described above, and standalone view):**
- Prescription history list for a patient (all encounters)
- Active prescriptions vs completed
- Print current prescription (formatted for pharmacy)
- Repeat prescription: copy a past prescription into a new draft

**AI — Safety checks (Phase AI-3):**
- Allergy conflict badge on every drug (green = clear, red = conflict)
- Drug-drug interaction alert if two or more prescriptions interact
- Contraindication alert: e.g., Metformin + eGFR < 30 → red alert
- All checks run against licensed drug database (not LLM) per Rule 4
- LLM is explicitly forbidden from making drug safety decisions

**AI — Medication suggestions (Phase AI-5, feature-flagged, highest risk):**
- Suggested only after: Phase AI-3 validators are live + 100-case eval passed
- Suggestion shown as card: drug + dose + confidence + validation state
- Accept / Edit / Reject (mandatory)
- Confidence and validation state always visible, never collapsed
- Logged to `AI Recommendation Log`

---

### 12 — Immunization

**Roles:** Nurse (CRUD), Doctor (view + approve), Admin.
**Frappe:** `Immunization`.

**Functionality:**
- Patient immunization record: vaccine name, date, dose number, lot number, administered by, site
- Upcoming vaccines: based on patient age + standard vaccination schedule
  (Mexico's Cartilla Nacional de Vacunación)
- Overdue vaccines: highlighted in red
- Add new immunization record
- Print immunization certificate

**AI:** none.

---

### 13 — Documents

**Roles:** All (role-scoped upload/view).
**Frappe:** `Patient Medical Record`.

**Functionality:**
- Upload: drag-and-drop or file picker (PDF, images, DOCX)
- Document types: Lab Report / Referral Letter / Consent Form / X-Ray / Other
- Link to patient + optionally to encounter
- View PDF inline (no download required)
- Search by type, date range, keywords in filename
- Delete (Doctor + Admin only; confirmation required)

**AI:** none.
(Lab reports are NEVER fed to the LLM — see ai-ux-design-risks.md §3. Documents
are displayed as-is; any structured data lives in the Lab Test doctype.)

---

### 14 — Billing + Invoices

**Roles:** Front Desk (CRUD), Doctor (view), Admin (full).
**Frappe:** `Patient Invoice`, `Fee Validity`.

**Functionality:**
- Invoice list: patient, date, amount, status (Draft / Submitted / Paid / Cancelled)
- New invoice: link to patient + appointment; add service items from price list
- Payment recording: cash / card / transfer; generate receipt
- Outstanding balance per patient
- Daily collection summary
- Print invoice (formatted)

**AI:** none.

---

### 15 — Insurance Claims

**Roles:** Front Desk, Admin.
**Frappe:** `Healthcare Insurance Claim`.

**Functionality:**
- Claims list: patient, insurer, amount claimed, status
- New claim: link to invoice + patient + policy
- Attach supporting documents (lab results, encounter summary)
- Claim status tracking: Submitted / In Review / Approved / Rejected
- Rejection reason + resubmission flow

**AI:** none.

---

### 16 — Messages

**Roles:** All.
**Frappe:** `Communication`.

**Functionality:**
- Inbox: messages received
- Compose: to (user search), subject, body, attach file
- Reply thread view
- Message types: Internal (between staff) / External (to patient email/SMS)
- Read / Unread status
- Search by sender, patient name, keyword

**AI:** none.

---

### 17 — Notifications

**Roles:** All.
**Frappe:** `Notification Log`.

**Functionality:**
- Bell icon in header with unread count badge
- Dropdown: latest 10 notifications (timestamp, subject, brief text)
- Click → navigate to relevant record
- Full notification list page: filter by type (System / Reminder / AI / Billing)
- Mark all read
- AI notifications: "SOAP draft ready for encounter #123", "Red flag detected", "Recording auto-closed"

**AI:** AI events (soap.ready, red_flag, session.stopped) create notification rows.

---

### 18 — Reports

**Roles:** All (role-filtered content).
**Frappe:** Frappe Report framework + custom queries.

#### Front Desk Reports
- Daily appointments (count by status, practitioner)
- Daily collections (cash / card / insurance)
- Patient registration summary (new patients per week/month)

#### Nurse Reports
- Vitals completion rate (% of patients with vitals recorded)
- Lab sample collection turnaround

#### Doctor Reports
- My encounters this month (count, avg duration)
- Patient load by diagnosis (top 10 ICD codes)
- Lab result review pending

#### Admin Reports (all of the above plus)
- Clinic-wide revenue
- Practitioner utilization
- AI cost report: tokens/encounter, $/encounter, $/physician/day
- AI quality report: SOAP acceptance rate, edit distance, regeneration rate
- Data export: any doctype to CSV

**AI:** AI cost + quality metrics appear in Admin Reports (Phase AI-6).

---

### 19 — Global Search

**Roles:** All.
**Frappe:** `frappe.utils.global_search.search`.

**Functionality:**
- Keyboard shortcut: Cmd/Ctrl + K
- Search across: Patient (name, MRN, phone), Appointments, Encounters, Lab Tests
- Result grouped by type with icons
- Click result → navigate directly
- Recent searches stored in localStorage (no PHI sent to analytics — Rule 10)

**AI:** none.

---

### 20 — Providers

**Roles:** Admin (CRUD), all others (view).
**Frappe:** `Healthcare Practitioner`.

**Functionality:**
- Provider list: name, specialisation, department, phone, status
- Provider detail: qualifications, schedule, consultation fee, linked user account
- Add / edit provider
- Assign provider to department
- View provider's encounters and appointments count

**AI:** none.

---

### 21 — Departments

**Roles:** Admin (CRUD), all others (view).
**Frappe:** `Medical Department`.

**Functionality:**
- Department list: name, head, room/location
- Add / edit department
- Practitioners per department
- Appointment slots per department (link to practitioner schedules)

**AI:** none.

---

### 22 — Settings

**Roles:** Admin only.
**Frappe:** `Healthcare Settings` (Single), `AI Settings` (Single).

#### Healthcare Settings
- Default currency, appointment duration
- Inpatient vs outpatient configuration
- SMS / email notification templates

#### AI Settings
- Deepgram: language (`es-MX` / `en-US`), model, diarize toggle
- Max session minutes (bounds Deepgram token TTL)
- Feature flags (one toggle per AI capability — all OFF by default):
  - `enable_transcription`
  - `enable_soap_generation`
  - `enable_safety_validators`
  - `enable_icd_suggestions`
  - `enable_lab_suggestions`
  - `enable_differential_diagnosis`
  - `enable_medication_suggestions`
- Per-clinic retention overrides (transcript TTL, SOAP draft TTL)
- Debug mode: raw prompt logging (7-day hard ceiling — see retention policy)
- Cost budget: daily token budget per clinic; alert at 80%; auto-disable suggestions at 100%

**AI:** AI Settings is the control plane for all AI feature flags.

---

### 23 — Admin Panel

**Roles:** Admin only.
**Frappe:** `User`, `Role`, Frappe permission APIs.

**Functionality:**
- User list: name, email, role(s), status (Active / Inactive)
- Add user: create Frappe User, assign Healthcare role, link to Practitioner if Doctor
- Edit user: change role, reset password, activate/deactivate
- Role permissions overview: what each role can do (read-only view of Frappe permissions)
- Audit log view: recent actions by user (Frappe built-in `Activity Log`)
- Frappe Cloud backups: link to FC dashboard (external)

**AI:** none.

---

## Build Phases

Each phase delivers complete, shippable functionality for the screens in scope.
Manual and AI features in the same screen ship in the same phase.

---

### Phase 1 — Foundation

**Scope:** Auth, RBAC, layouts, Frappe client infrastructure.
**Screens:** 01 Login, 02 Dashboard (shells), 03 Patient List.

Deliverables:
- `remedisys-web` repo created (Next.js 14+, shadcn/ui, Tailwind, TanStack Query)
- `lib/frappe/client.ts` — `frappeFetch` BFF wrapper
- `lib/auth.ts` — NextAuth Frappe credentials provider
- `middleware.ts` — session guard + role routing
- Role-specific layouts (desk / nurse / doctor / admin) with nav sidebar
- Login page (bilingual labels)
- Patient list (table, search, filter) for all roles
- Role-based dashboards (placeholder stats while data layer builds)
- Frappe Cloud `allow_cors` configured

Exit gate: all 3 roles log in, land on correct layout, see patient list, log out.

---

### Phase 2 — Patient + Appointment

**Scope:** Core operational flow for Front Desk.
**Screens:** 04 Patient Registration, 05 Appointment Calendar, 06 Book Appointment, 07 Patient Chart (basic).

Deliverables:
- New Patient form with CURP + bilingual labels
- Appointment calendar (day/week/month, provider filter)
- Book/edit appointment with live slot availability
- Patient Chart: demographics + Overview tab + Encounters tab (read-only list)

Exit gate: front-desk user registers a patient, books an appointment, views the patient chart.

---

### Phase 3 — Encounter + Core AI

**Scope:** The central clinical screen — complete: manual SOAP + full AI sidebar.
**Screens:** 08 Patient Encounter (complete), 09 Vitals Entry, 10 Lab Orders + Results, 11 Prescriptions.

This is the largest phase. Manual and AI are built together.

Deliverables:
- Complete encounter form (Sections 1–9 as described in screen 08)
- AI sidebar: FAB → popover → fullscreen (ADR-008 design in React)
- Recording: consent UI, start/stop, live transcript panel (ADR-009 browser-direct Deepgram)
- AI transcription with Deepgram (es-MX + en-US)
- SOAP draft generation (Frappe RQ background job + Anthropic)
- SOAP draft panel: Accept / Edit / Reject per section
- Insert into Encounter as logged-in physician
- Safety validators: allergy conflict + drug interaction + vitals anomaly + red flags
- Vitals entry form + anomaly alerts
- Lab order form + results view
- Prescriptions within encounter + allergy conflict badges
- All AI events via Frappe SocketIO → Next.js via socket.io-client

Exit gate: doctor opens encounter, records 10-min session, reviews AI SOAP draft, edits one section, inserts into encounter, adds prescription, orders lab, submits encounter. AI failure does not block form submit.

---

### Phase 4 — Clinical Depth

**Scope:** Remaining clinical screens.
**Screens:** 12 Immunization, 13 Documents, 14 Billing, 15 Insurance Claims.

Deliverables:
- Full Patient Chart tabs: Vitals, Labs, Prescriptions, Immunization, Documents, Billing
- Immunization record with Mexico vaccination schedule
- Document upload + inline PDF viewer
- Billing: invoices, payments, receipts
- Insurance claims workflow

Exit gate: nurse can complete a patient visit (vitals → lab collection → immunization). Doctor can view complete patient chart. Front desk can create and mark-paid an invoice.

---

### Phase 5 — Operations + Suggestions

**Scope:** Shared operational screens + AI suggestions (feature-flagged).
**Screens:** 16 Messages, 17 Notifications, 18 Reports, 19 Search.
**AI:** ICD / CIE-10 suggestions, Lab suggestions, Differential diagnosis, Medication suggestions — each gated on its own 100-case eval.

Deliverables:
- Internal + patient-facing messaging
- Notification bell + full notification list
- Role-filtered reports (clinical + financial)
- Global search (Cmd+K)
- AI suggestion panels in Encounter sidebar (each feature-flagged OFF; enabled per clinic after eval)
- AI cost + quality dashboard in Admin Reports

Exit gate: all roles can send messages, see notifications, run their reports, search. At least one AI suggestion type passes its 100-case eval and is enabled in staging.

---

### Phase 6 — Admin + Hardening

**Scope:** Admin screens + system hardening.
**Screens:** 20 Providers, 21 Departments, 22 Settings, 23 Admin Panel.

Deliverables:
- Provider + department management
- Full AI Settings control panel with all feature flags
- User management with role assignment
- Retention jobs: scheduled purge of expired AI data
- Chaos drills: kill Deepgram / Anthropic mid-encounter; Encounter form must continue
- Load test: 50 concurrent encounters
- Eval harness: 50–100 de-identified encounter golden dataset + LLM judge
- Per-clinic feature flag overrides

Exit gate: chaos drills pass for all Rule 7 scenarios. Load test passes. At least one pilot clinic configured with feature flags tuned to their eval scores.

---

### Phase 7 — Pilot

| Week | Mode |
|---|---|
| 1 | Shadow — AI generates, physician does not see. Data collection only. |
| 2 | Visible-but-non-binding — physician can view SOAP draft, not auto-inserted. |
| 3–4 | Full pilot — weekly review: acceptance rate, edit distance, complaints, latency, cost. |

Exit to GA: acceptance rate ≥ 70%; zero safety incidents; physician NPS ≥ 30.

---

## Key Cross-Cutting Rules (summary — full text in CLAUDE.md)

| Rule | What it means for screen design |
|---|---|
| Rule 1 — Upgrade-Safe | No Frappe core edits. All data via REST API. |
| Rule 2 — Uninstall-Safe | Removing `remedisys_healthcare_ai` must not break any screen. |
| Rule 4 — No direct DB from LLM | LLM sees structured fields from tool functions, not raw DB dumps. |
| Rule 5 — No full history dump | 4000-token context budget, structured retrieval first. |
| Rule 6 — Physician in Control | AI never writes to a record without an explicit physician action. |
| Rule 7 — AI failure must not break healthcare | Encounter form works with AI completely down. |
| Rule 10 — No PHI in logs | No patient names, MRNs, or clinical content in logs or Sentry. |

**Anti-patterns to never implement** (full detail in `docs/ai-ux-design-risks.md`).
**⚠️ Four of these seven were subsequently implemented.** Status verified 2026-08-13 — recorded
here rather than quietly deleted, because each was a deliberate reversal that deserves review:

| # | Anti-pattern | Status |
|---|---|---|
| 1 | Free-text "ask the AI" input | ❌ **IMPLEMENTED** — `NarzimAIChatBar.tsx`. It is the headline feature. The stated risk was unbounded scope; the mitigation actually shipped is a prompt-level scope restriction (`ask-copilot-v2.txt:8`), not a structural one |
| 2 | Search-as-you-type for AI suggestions | ✅ Not implemented — suggestions fire at recording stop, not per keystroke |
| 3 | AI-narrated lab report summaries | ❌ **IMPLEMENTED** — `get_lab_analysis` tool + `analyze_lab` endpoint + the patient-portal lab assistant |
| 4 | Phase-ordering violations (skipping eval gates) | ❌ **VIOLATED** — AI shipped before Phase 4; no eval gate exists. This is why the master plan makes an evaluation suite a P1 item |
| 5 | "+ New session" redundancy | ✅ Not implemented |
| 6 | Bilingual consent in wrong language | ✅ Language resolves from `User.language` → `ComplianceProfile`. ⚠️ But the **consent gate itself was removed** 2026-07-25 (`183c783`, "for seamless navigation") |
| 7 | Autocomplete in clinical record fields | ✅ Not implemented |

These are not presented as mistakes — several may have been the right call. They are presented
as **decisions that were made without being written down**. See
[`docs/ai/DECISION_LOG.md`](./docs/ai/DECISION_LOG.md).

---

## Compliance (Mexico — and now India)

**⚠️ Scope widened 2026-06-30 by ADR-018:** jurisdiction is **India + Mexico**, pluggable via
`ComplianceProfile` (`mx` = LFPDPPP + NOM-024-SSA3-2010; `in` = DPDPA 2023 + ABDM). The table
below covers Mexico only — **the India column has not been written.** That is an open gap, not
an omission from this edit.

| Requirement | Claimed | Verified status 2026-08-13 |
|---|---|---|
| LFPDPPP Art. 8 — express consent for sensitive data | Recording consent checkbox before any audio | 🔴 **The consent gate was removed** 2026-07-25 (`183c783` — "removing consent gate… for seamless navigation"). The commit message calls it a dev-only bypass; **verify what is live in production before relying on this row** |
| LFPDPPP Art. 17 — privacy notice in comprehensible language | Consent text bound to `Patient.language` | ⚠️ Depends on the row above |
| LFPDPPP Art. 19 — security duty | BFF pattern; Frappe never exposed to browser | ✅ Holds — but the credential is **Bearer JWT (ADR-011)**, not "SID in encrypted session" as written |
| LFPDPPP Art. 20 — breach notification | PHI scrubber on Sentry; IDs-only logs; BAA per vendor | ⚠️ Logs verified IDs-only (Rule 10 holds in `log_prompt_call`). Sentry scrubber and vendor BAAs **not verified in this audit** |
| NOM-024-SSA3-2010 §6.2 — record integrity | AI never auto-writes; physician approval required | 🔴 **Not true for 5 tools.** `add_allergy`, `add_patient_medication`, `add_medical_history`, `add_surgical_history`, `set_patient_summary` write to the permanent `Patient` record with no approval (`encounter-screen.tsx:3217-3263`). Encounter-level fields **do** honour it |
| NOM-024-SSA3-2010 §7 — traceability | Every AI action linked to `AI Prompt Log` + `AI Recommendation Log` | ⚠️ `AI Prompt Log` exists and logs every call. **`AI Recommendation Log` does not exist** — no such doctype. And tool **arguments and results are never stored**, so *why* the AI recommended something cannot be reconstructed (audit §13.1) |
| COFEPRIS — SaMD classification | To be confirmed with counsel before Phase 5 (suggestions) | 🔴 **Phase 5 has arrived and shipped.** Suggestions are live in production. This confirmation is now overdue, not pending |
| Audio retention | OFF by default; never stored server-side (ADR-009) | ✅ Verified — audio streams browser→Deepgram directly and never reaches Frappe |

> **Read the two 🔴 record-integrity rows together with `docs/ai/REMEDISYS_AI_MASTER_PLAN.md`
> §13 P0** — items 1–3 there exist specifically to close them. They are the top of the roadmap
> for that reason.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-04 | Sarvesh | Initial version (header backfilled from git history) |
