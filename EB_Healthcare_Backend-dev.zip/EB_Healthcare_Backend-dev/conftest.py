"""
Pytest conftest for remedisys_healthcare_ai tests.
Initializes a Frappe site connection without ERPNext test bootstrap.
"""
import os

import frappe
import pytest

# The bench layout frappe assumes, resolved once at import.
BENCH_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SITES_PATH = os.path.join(BENCH_PATH, "sites")

# chdir at IMPORT time, not inside the fixture. frappe builds both of its log
# paths relative to the cwd — os.path.join("..", "logs", f) for bench-level logs
# and os.path.join(site, "logs", f) for site-level — and expects that cwd to be
# <bench>/sites, which is what `bench` itself does. Doing it in a fixture is too
# late: importing a test module can pull in a dependency that configures a logger
# during collection (cssutils, via ERPNext's premailer), which then tried to open
# <cwd>/../logs/cssutils.log and killed collection for 15 modules before any
# fixture had run. conftest.py is imported before collection, so this is the
# earliest hook that covers both phases.
os.chdir(SITES_PATH)


def pytest_addoption(parser):
    parser.addoption("--site", action="store", default="marley.local")


@pytest.fixture(scope="session", autouse=True)
def frappe_site(request):
    site = request.config.getoption("--site")
    # cwd is already SITES_PATH (set at import — see the note above); frappe.init's
    # own sites_path was never the problem, only the cwd the loggers resolve against.
    frappe.init(site=site, sites_path=SITES_PATH)
    frappe.connect()
    frappe.set_user("Administrator")
    yield
    frappe.destroy()
