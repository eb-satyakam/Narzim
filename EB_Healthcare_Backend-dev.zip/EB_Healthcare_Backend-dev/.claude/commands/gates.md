---
description: Run every documentation gate (headers, links, indexes, endpoint index, ADR numbering, version bumps)
allowed-tools: Bash(python3:*)
---
Documentation gates — the same set `.github/workflows/docs-gates.yml` runs on every PR. Fix every FAIL before committing; a WARN on a `record` document means you edited a frozen snapshot — confirm that was intended.

!`python3 scripts/check_md_headers.py 2>&1 | tail -3`
!`python3 scripts/check_md_links.py 2>&1 | tail -2`
!`python3 scripts/gen_doc_indexes.py --check 2>&1 | tail -3`
!`python3 scripts/gen_endpoint_index.py --check 2>&1 | tail -3`
!`python3 scripts/check_adr_numbering.py 2>&1 | tail -4`
!`python3 scripts/check_version_bump.py --staged 2>&1 | tail -6`
