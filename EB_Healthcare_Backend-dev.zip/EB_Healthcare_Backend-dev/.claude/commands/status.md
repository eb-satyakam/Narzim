---
description: Print the current project state (docs/STATUS.md, the only owner of status)
allowed-tools: Bash(cat:*)
---
The only document that states project status. Do not restate it elsewhere; link to it.

!`cat docs/STATUS.md`
