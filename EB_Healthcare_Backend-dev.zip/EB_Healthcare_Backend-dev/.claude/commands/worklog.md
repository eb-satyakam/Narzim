---
description: List the latest WORK_LOG.md and CHANGELOG.md headings without reading the files — /worklog 30
argument-hint: [number of entries, default 20]
allowed-tools: Bash(grep:*), Bash(head:*)
---
Latest work-log entries (grep the heading, then read that range with an offset; never the whole file):

!`grep -n "^## 20" WORK_LOG.md | head -${ARGUMENTS:-20}`

Latest changelog groups:

!`grep -n "^### 20" CHANGELOG.md | head -${ARGUMENTS:-20}`

Older months live in `docs/worklog/` and `docs/changelog/` as frozen records.
