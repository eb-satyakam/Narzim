---
description: Show a backend module's brief and its generated endpoint table — /module encounters
argument-hint: <module name under api/v1, e.g. encounters | patients | ai>
allowed-tools: Bash(cat:*), Bash(ls:*), Bash(test:*)
---
Module: **$ARGUMENTS**

## Brief (hand-written, code-cited; absent means nobody has written one yet — use the encounters one as the template)

!`test -f remedisys_healthcare_ai/api/v1/$ARGUMENTS/CLAUDE.md && cat remedisys_healthcare_ai/api/v1/$ARGUMENTS/CLAUDE.md || echo "(no brief yet at remedisys_healthcare_ai/api/v1/$ARGUMENTS/CLAUDE.md)"`

## Endpoints (generated from the AST — regenerate with scripts/gen_endpoint_index.py)

!`test -f docs/api/endpoints/$ARGUMENTS.md && cat docs/api/endpoints/$ARGUMENTS.md || (echo "(no such module; known modules:)"; ls docs/api/endpoints | sed 's/\.md$//' | tr '\n' ' ')`

## Files

!`ls -la remedisys_healthcare_ai/api/v1/$ARGUMENTS 2>/dev/null; ls remedisys_healthcare_ai/tests/$ARGUMENTS 2>/dev/null`
