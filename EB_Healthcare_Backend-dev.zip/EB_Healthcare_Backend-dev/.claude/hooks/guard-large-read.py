#!/usr/bin/env python3
"""PreToolUse hook: refuse a whole-file Read of anything over 100 KB.

Why: CLAUDE.md §8. A session that opens WORK_LOG.md (≈1 MB) or API_SPEC.md (≈240 KB) whole
spends its context on the wrong thing and then reasons from a truncated view. The fix is
always the same — grep for the heading or symbol, then read a range — so say so.

Exit 2 blocks the call and feeds stderr back to the model. Anything else lets it through.
Reads with an offset or limit pass; so do files under the threshold.
"""
import json
import os
import sys

LIMIT = 100 * 1024

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(0)
inp = payload.get("tool_input") or {}
path = inp.get("file_path") or ""
if not path or inp.get("offset") is not None or inp.get("limit") is not None:
    sys.exit(0)
try:
    size = os.path.getsize(path)
except OSError:
    sys.exit(0)
if size <= LIMIT:
    sys.exit(0)
name = os.path.basename(path)
sys.stderr.write(
    f"Refused: {name} is {size // 1024} KB. Do not read it whole (CLAUDE.md §8).\n"
    f"  grep -n '^## ' '{path}' | head        # find the section\n"
    f"  then Read with offset/limit, or grep -n '<symbol>' for the lines you need.\n"
    "  Endpoints: docs/api/ENDPOINT_INDEX.md → docs/api/endpoints/<module>.md\n"
    "  Logs: /worklog lists headings; CHANGELOG.md and WORK_LOG.md are grep-only.\n"
)
sys.exit(2)
