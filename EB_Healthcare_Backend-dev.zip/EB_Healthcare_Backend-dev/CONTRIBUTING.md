# Contributing Guide — EB Healthcare Backend

**Doc status:** living · **Created:** 2026-06-04 by Sarvesh-SocialAngel · **Updated:** 2026-07-10 by Sarvesh-SocialAngel · **Version:** 1.0

## Branch Structure

```
main   ← Production (live users)
 └── pre   ← Staging (testers + admins)
      └── dev   ← Integration (all developers merge here)
           └── feature/*   ← Individual developer work
```

| Branch | Who | Purpose |
|--------|-----|---------|
| `main` | Deploy only | Production — stable, live environment |
| `pre` | Testers, Admins | Staging — final QA before production |
| `dev` | All developers | Integration — all features merge here first |
| `feature/*` | Individual devs | Isolated feature development |

---

## Developer Workflow

### 1. Start a new feature

Always branch off `dev`, never off `main` or `pre`.

```bash
git checkout dev
git pull origin dev
git checkout -b feature/your-feature-name
```

Feature branch naming:

```
feature/patient-dashboard
feature/appointment-booking
feature/invoice-module
fix/login-redirect
chore/update-dependencies
```

### 2. Work and commit

```bash
git add .
git commit -m "feat: add patient dashboard"
git push -u origin feature/your-feature-name
```

Use [Conventional Commits](https://www.conventionalcommits.org/):

| Prefix | Use for |
|--------|---------|
| `feat:` | New feature |
| `fix:` | Bug fix |
| `chore:` | Tooling, dependencies |
| `docs:` | Documentation only |
| `refactor:` | Code restructure, no feature change |
| `style:` | Formatting, no logic change |
| `test:` | Adding or fixing tests |

### 3. Open a Pull Request

- PR target: `feature/* → dev`
- Developers can **open PRs only** — cannot merge their own or others' PRs
- A **Maintainer or Admin** reviews, approves, and merges all PRs
- Delete the feature branch after merge

---

## Promotion Flow

```
feature/*  →  PR  →  dev     (developer review)
dev        →  PR  →  pre     (QA / tester review)
pre        →  PR  →  main    (production release)
```

Never merge directly into `pre` or `main` — always go through PRs.

---

## Branch Protection Rules

| Branch | Rules |
|--------|-------|
| `main` | Require PR, 1 Maintainer/Admin approval, dismiss stale reviews, no force push, restrict push to Maintainer/Admin only |
| `pre` | Require PR, 1 Maintainer/Admin approval, no force push, restrict push to Maintainer/Admin only |
| `dev` | No direct push restrictions, PR required to merge |

---

## Maintainer Responsibilities

Maintainers (users with **Maintain** role) are responsible for:

- **Reviewing and approving PRs** — review code, request changes, and approve when ready
- **Merging PRs** — merge approved PRs into `dev`, `pre`, or `main`
- **Resolving conflicts** — if a PR has merge conflicts, the maintainer can:
  1. Pull the feature branch locally and rebase/merge manually, or
  2. Guide the developer to resolve and re-push

### Conflict Resolution (Maintainer)

When a PR has conflicts that need maintainer intervention:

```bash
# Fetch the feature branch
git fetch origin
git checkout feature/branch-name

# Rebase onto the target branch (e.g. dev)
git rebase origin/dev

# Resolve conflicts in editor, then:
git add .
git rebase --continue

# Push the resolved branch
git push --force-with-lease origin feature/branch-name
```

### Conflict Resolution (Developer — preferred)

Developers should resolve their own conflicts before requesting review:

```bash
git fetch origin
git rebase origin/dev
# resolve conflicts
git add .
git rebase --continue
git push --force-with-lease origin feature/your-feature-name
```

### GitHub Role Permissions

| Action | Developer | Maintainer | Admin |
|--------|-----------|------------|-------|
| Push to `feature/*` branches | ✅ | ✅ | ✅ |
| Push directly to `dev` | ✅ | ✅ | ✅ |
| Push directly to `pre` / `main` | ❌ | ✅ | ✅ |
| Open PRs | ✅ | ✅ | ✅ |
| Approve PRs | ✅ | ✅ | ✅ |
| Merge PRs (own or others) | ❌ | ✅ | ✅ |
| Resolve conflicts | ❌ | ✅ | ✅ |
| Manage repo settings | ❌ | ✅ | ✅ |
| Manage branch protection | ❌ | ❌ | ✅ |

---

## Keeping Your Branch Up to Date

Before pushing, rebase on the latest `dev` to avoid conflicts:

```bash
git fetch origin
git rebase origin/dev
```

If you have conflicts, resolve them, then:

```bash
git add .
git rebase --continue
git push --force-with-lease origin feature/your-feature-name
```

---

## Local Setup

```bash
git clone https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend.git
cd marley-bench/apps/remedisys_healthcare_ai
bench install-app remedisys_healthcare_ai
bench start
```

See `README.md` for full environment variable details.

---

## Code Standards

- Follow Frappe framework conventions
- Use Python type hints
- Run `bench run-tests` before opening a PR

## EB_ Role Permissions (permissions-as-code)

EB_ role doctype permissions are declared in
`remedisys_healthcare_ai/patches/v0/eb_docperm_spec.json` — the single source of
truth. `rebuild_eb_role_permissions.execute()` reconciles them from the spec on
**every `after_install` and `after_migrate`** (wired in `hooks.py`), so they are
**reset-safe**: a data reset that wipes Custom DocPerm is repaired on the next
migrate.

- **To change a permission:** edit `eb_docperm_spec.json` and commit. The next
  migrate applies it. **Do NOT add new `reapply_eb_role_permissions_*` patches** —
  the after_migrate hook already applies the spec.
- **Do NOT ship EB_ perms as a Custom DocPerm fixture.** Any Custom DocPerm on a
  doctype overrides its standard perms entirely, so an EB_-only fixture strips
  every core/Healthcare role on import. The spec+rebuild layers EB_ rows on top
  of the shipped defaults instead.
- **Editing EB_ perms in the Desk UI won't persist** — the next migrate reverts
  to the spec. Change the spec, not the DB.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-04 | Sarvesh | Initial version (header backfilled from git history) |
