# Mobile auth (future)

**Doc status:** living · **Created:** 2026-06-05 by Sarvesh-SocialAngel · **Updated:** 2026-06-05 by Sarvesh-SocialAngel · **Version:** 1.0

Mobile uses the **same eb_frappe_jwt endpoints** as web — there is no separate
OAuth2/PKCE flow (ADR-011 retired OAuth2):

- Login: `POST /api/method/eb_frappe_jwt.api.get_token` `{ usr, pwd, device }`
- Refresh: `POST /api/method/eb_frappe_jwt.api.refresh_token` `{ refresh_token }`
- Logout: `POST /api/method/eb_frappe_jwt.api.revoke_token` `{ refresh_token }`

The only difference from web is storage: keep the refresh token in the device
**Keychain (iOS) / Keystore (Android)** — never in plain storage. The access
token stays in memory. Refresh tokens are single-use; store the rotated one.

The web requests in `../web/` apply verbatim; duplicate them here with mobile
device labels when the mobile client work begins.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | 2026-06-05 | Sarvesh | Initial version (header backfilled from git history) |
