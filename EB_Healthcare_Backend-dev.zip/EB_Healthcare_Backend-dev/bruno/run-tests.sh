#!/usr/bin/env bash
# Run the Bruno auth test suite against the local environment.
#
# Usage:
#   cd bruno/
#   bash run-tests.sh            # runs auth/web suite
#   bash run-tests.sh --bail     # stop on first failure
#   bash run-tests.sh auth/web/login.bru   # single request

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Load .env secrets (password, otp, ...)
ENV_FILE=".env"
if [ ! -f "$ENV_FILE" ]; then
  echo "ERROR: $SCRIPT_DIR/.env not found."
  echo "  Copy .env.example → .env and fill in the values."
  exit 1
fi

# Build --env-var flags from .env (compatible with bash 3 on macOS)
ENV_VAR_FLAGS=()
while IFS='=' read -r key value; do
  [[ "$key" =~ ^[[:space:]]*# ]] && continue
  [[ -z "$key" ]] && continue
  ENV_VAR_FLAGS+=("--env-var" "${key}=${value}")
done < "$ENV_FILE"

TARGET="${1:-auth/web}"
shift 2>/dev/null || true

echo "── Bruno auth tests (env: local, target: $TARGET) ──"
bru run "$TARGET" --env local "${ENV_VAR_FLAGS[@]}" "$@"
