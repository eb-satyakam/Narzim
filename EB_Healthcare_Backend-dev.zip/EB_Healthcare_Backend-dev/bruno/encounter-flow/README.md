# Encounter flow (v9): test it step by step

**Doc status:** living · **Created:** 2026-09-30 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Sarvesh-SocialAngel (AI-assisted) · **Version:** 3.0

This folder runs the v9 encounter flow against the backend. There is one
request per step, in the same order the screen does it. It calls Frappe
directly with a Bearer token. The Next.js BFF is not in the path.

**Local bench only.** Never point it at production.

---

## 1. Before you start (one time)

| # | Do this | Why |
|---|---|---|
| 1 | Run `bench start` in **your own terminal** | The API must be up on `http://127.0.0.1:8003` (site `marley.local`) |
| 2 | Check that `sites/marley.local/site_config.json` has `deepgram_api_key` and `openai_api_key` | Step 07 needs Deepgram. Steps 16, 17, 19, 21 and 25 need the AI key |
| 3 | Open Bruno → open the collection `apps/remedisys_healthcare_ai/bruno` | This folder is inside it |
| 4 | Pick the **`local`** environment. Set `email` (a **practitioner** user), the secret `password`, and `appointment_id` | The user must have EB_Practitioner. The appointment must have **no signed encounter** |
| 5 | Open the console: **View → Toggle Developer Tools → Console** | Every step prints what it sent and what came back |

Cost: steps 16, 17, 19, 21 and 25 call the LLM. A full run is about 5 AI calls.

---

## 2. How to run

**Option A: step by step (best for learning).**
Click `01`, then Send. Read the **Console** block and the **Tests** tab. Then
go to `02`, and so on. Each step saves values the next one needs, so keep the order.

**Option B: the whole folder.**
Right-click `encounter-flow` → **Run**. Bruno runs 01 → 28 and shows
pass/fail for each step.

**Option C: from the terminal.**
```
cd apps/remedisys_healthcare_ai/bruno
bru run encounter-flow --env local --env-var appointment_id=HLC-APP-2026-XXXXX
```
Set `password` as a secret in the Bruno `local` environment first. Don't pass
it with `--env-var`, because it would stay in your shell history.

---

## 3. How to read what happened

Every step prints one block in the Console:

```
==================== 21 Analyze 3 · SOAP draft (first time) ====================
STATUS  : 200 | 8421 ms
SENT    : {"encounter":"HLC-ENC-2026-00007","transcript":"Doctor: Good morning...","current_draft":"","enable_ai_proposed_assessment":1}
KEY     : { "draft_name": "AISD-0107", "version": 1, "targets": ["chiefComplaint","hpi","physicalExamination","assessment","plan","diagnoses","orders.rx"] }
VAR SET : flow_hpi = "34-year-old woman with 3 days of fever..."
```

| Line | Means |
|---|---|
| `STATUS` | HTTP code and time taken. 200/201 = OK. 417 = validation error. 403 = no permission |
| `SENT` | The body that was sent. Passwords and tokens show as `***` |
| `KEY` | The important part of the response, not the whole thing |
| `ERROR` | Shown instead of `KEY` when the call failed. It holds the server's message |
| `VAR SET` | A value saved for a later step |

More places to look:

| Where | What |
|---|---|
| **Timeline** tab | The exact raw request and response |
| **Tests** tab | Pass/fail for the step |
| **Docs** tab | What the step does, and an example response |
| Desk → **AI Prompt Log** | Real tokens in/out, cached tokens, round trips, tools used, cost for each AI call |
| Desk → **AI SOAP Draft** | Each draft: version, model, raw AI reply |
| Desk → **AI Encounter Session** / **AI Transcript Segment** | Consent, status, saved lines |
| Desk → **AI Encounter Chat Message** | What Ask AI saved (steps 16–17) |
| Desk → **Patient Encounter** → `encounter_comment` | Where the SOAP text is stored (steps 23 and 26) |

---

## 4. The sequence

### A. Login and open

| # | Step | Method | What to check |
|---|---|---|---|
| 01 | Login | `eb_frappe_jwt.api.get_token` | 200. The token is saved |
| 02 | Open encounter | `encounters.create_encounter` | `docstatus 0`. `chief_complaint` is **empty** (not copied from the appointment) |

### B. Screen load (what v9 calls when the page opens)

| # | Step | Method | What to check |
|---|---|---|---|
| 03 | Old scribe session? | `sessions.get_active_session` | `name: null` on a fresh encounter |
| 04 | Advice list | `encounter_advice.list_advice` | `[]` |

### C. Consent and recording

| # | Step | Method | What to check |
|---|---|---|---|
| 05 | **NEGATIVE:** start recording before consent | `sessions.start_session` | **Must fail** (417, "Consent must be recorded…"). This is the PHI-2 check |
| 06 | Patient agreed | `sessions.record_consent` | `consent_method: asked_and_agreed` |
| 07 | Mic starts | `sessions.start_session` | `status: Recording`. A Deepgram token is made |
| 08–13 | 6 transcript lines (stand in for Deepgram) | `segments.append_segment` | `persisted`. `duplicate` is OK on a re-run |
| 14 | Vitals (38.4 °C, HR 96…) | `vital_signs.create_vital_signs` | 201. The SOAP's Objective will use these |

### D. Ask AI

| # | Step | Method | What to check |
|---|---|---|---|
| 15 | Build the transcript text | `sessions.get_encounter_transcript` | `count: 6`. `flow_transcript` is saved |
| 16 | Upload lab photo ⚠️ AI | `ai.upload_and_analyze_document` | The reply lists Hb 11.2, WBC 13,500… The file appears in the patient's Documents |
| 17 | Ask a question ⚠️ AI + tools | `ai.ask_copilot` | A reply, plus `actions` (e.g. an Rx card). **Nothing is written to the encounter** |
| 18 | Read the chat | `ai.get_encounter_chat` | 4+ messages. The upload turn is shown as `[file]` |

### E. Analyze (first time)

| # | Step | Method | What to check |
|---|---|---|---|
| 19 | Speaker check ⚠️ AI | `ai.resegregate_transcript` | Doctor / Patient labels are correct |
| 20 | Save the fixed labels | `segments.sync_transcript` | `status: synced` |
| 21 | **SOAP draft** ⚠️ AI | `ai.generate_soap_draft` | See the checklist below |
| 22 | Mark delivered | `ai.accept_soap_draft` | `Accepted` |
| 23 | Pad autosave | `encounters.save_draft` | The five text parts are saved |
| 24 | Read the encounter back | `encounters.get_encounter` | The text is there. Symptoms, diagnoses and Rx are **still empty** |

**Checklist for step 21's SOAP** (open Desk → AI SOAP Draft → the new row, or the step's Timeline):
- [ ] **CC** comes from the transcript ("fever and sore throat, 3 days").
- [ ] **Objective** has T 38.4 °C, HR 96 (step 14) **and** the CBC values with the lab name and date (step 16).
- [ ] The CBC values are **copied exactly**, with no "high/low" wording.
- [ ] **Assessment** is "acute pharyngitis" (the doctor said it). There is no "AI-proposed" marker, because the doctor stated one.
- [ ] **Plan** has paracetamol 500 mg every 8 h for 3 days, and fluids.
- [ ] The penicillin allergy is not ignored.
- [ ] The language matches your user language.

### F. Regenerate (second Analyze)

| # | Step | Method | What to check |
|---|---|---|---|
| 25 | Regenerate, with a new line ("ibuprofen…") ⚠️ AI | `ai.generate_soap_draft` + `current_draft` | `version 2+`. The Plan **now has ibuprofen** and **still has paracetamol** |
| 26 | Pad autosave | `encounters.save_draft` | Saved |

### G. End

| # | Step | Method | What to check |
|---|---|---|---|
| 27 | End session | `sessions.stop_session` | `Stopped` |
| 28 | **NEGATIVE:** line after stop | `segments.append_segment` | `sealed`. The line is **not** saved |

---

## 5. Test ideas (change one thing, run again)

| Try | Expect |
|---|---|
| Skip step 14 (vitals) | Objective has no vital signs. The AI must not invent any |
| Skip step 16 (lab) | Objective has no lab values |
| Delete line 6 (the doctor's plan) | Assessment / Plan come back with an **"AI-proposed"** marker (v9 only) |
| Change line 4 to "no allergies" | The allergy is no longer mentioned from the transcript. The patient's saved allergy still shows in the context |
| Send step 21 twice | Version goes up (2, 3…). Each run is a new AI SOAP Draft row |
| Log in as a nurse (no EB_Practitioner) | Steps 19 and 21 still work: they only check **read** permission on the encounter. Ask AI (17) offers no write tools if the user has no **write** permission. Worth knowing: a SOAP draft is not practitioner-only |
| Use an appointment whose encounter is signed | Step 02 returns `docstatus 1`, and steps 23 and 26 fail with "Only Draft encounters…" |

---

## 6. When something fails

| Symptom | Cause | Fix |
|---|---|---|
| Step 01 → 401 | Wrong email/password | Check the env |
| Any step → 403 | The user is not a practitioner, or has no permission | Use an EB_Practitioner user |
| Step 05 → **200** (should fail) | An older session of yours already has consent | Run step 27, or use a new appointment |
| Step 07 → "AI transcription unavailable (DEEPGRAM_NOT_CONFIGURED)" | No `deepgram_api_key` | Add it to site_config |
| Steps 08–13 → `sealed` | The session is not Recording (step 07 failed or already stopped) | Fix step 07, then run 06 → 07 again |
| Step 21 → `draft_name: null` | Empty transcript | Check step 15 `count` |
| Step 19 → error / empty | The AI call failed, or the transcript is very long | Check the Error Log. Try again |
| Step 23 → 400 | The encounter is not a draft, or a field is invalid | See `ERROR` in the Console |
| Step 25 test "ibuprofen" fails | The model did not merge the new line | A real finding: check the soap-regenerate prompt |

---

## 7. Not covered here

- **Deepgram audio.** Bruno cannot stream audio, so lines are added by hand (08–13).
- **Copy to Rx Pad and Ask AI → Rx:** see §9 (`rx-scenarios/`). Advice and follow-up extracted by Copy are recorded there but not applied.
- **Sign** (`complete_encounter`). See `../encounters/complete-encounter.bru`.
- **The two suggestion calls** that the app runs on End session (`/api/ai/suggest`).
- **Deepgram token refresh** (`refresh_deepgram_token`). The app does this about once, near expiry.

## 8. Run again

- Lines 08–13 return `duplicate` on the same session. That is fine.
- After step 27 the session is closed. A new run makes a new session at step 06.
- Test file: `fixtures/sample-cbc.png` (synthetic data, not a real patient).

## 9. Rx Pad scenarios (`rx-scenarios/`)

The main flow stops at the SOAP text. `rx-scenarios/` goes on: Copy to Rx Pad, Ask AI adding a
medication, Clear, Copy again, duplicates and strength conflicts, each checked after a save and a
reload, and each correlated with Langfuse.

### 9.1 How Copy to Rx Pad is reproduced

In v9, Copy to Rx Pad is not one endpoint. The browser builds the note and an "already documented"
summary, calls `extract_note_structured`, resolves catalog masters (`create_master`,
`create_complaint`, `create_diagnosis`, lab templates), merges into the Pad with a dose-conflict
guard and an exact-name duplicate rule, posts a system note per conflict, then autosaves with
`save_draft`. Bruno calls the **same backend methods** and runs the **same browser rules** from one
file, `rx-scenarios/lib/rxpad.js`. Every function there names the frontend code it copies
(`v9/data/scribe-apply.ts`, `copilot/field-mapping.ts`, `copilot/apply-suggestion.ts`,
`shared/logic.ts`, `v9/encounter-v9-route.tsx`, `v9/panel/live-scribe-panel.tsx`). **If that
frontend code changes, `rxpad.js` must change with it.**

An Ask AI card tap goes through the same merge (`applyAskAiAction` → `onCopyStructuredToPad`), so
it uses the same file.

### 9.2 Run it

Needs the main flow's transcript (steps 01–15 once), `bench start`, and Langfuse running. In the
git-ignored `folder.bru`, next to `email`/`password`/`appointment_id`, set `site` (e.g.
`marley.local`), `langfuse_host` and the two `langfuse_*_key` values from `~/langfuse/.env`.

```bash
cd apps/remedisys_healthcare_ai/bruno
bru run encounter-flow/rx-scenarios -r --env local      # s0 → s8 in one run
```

Run the whole folder in one go: scenarios share runtime variables (token, encounter, SOAP state),
which Bruno keeps only for one run. About 15 model calls and 4 minutes.

Each step prints `REQUEST`, `STATUS`, `ENCOUNTER`, `LANGFUSE SESSION` and a `RESULT` with the Rx
Pad after the step. Ask AI steps are followed by a Langfuse step that reads the trace and the
`tool.add_medication` input and output.

### 9.3 Scenarios and what they found (run of 2026-10-01, `marley.local`)

Test labels: **PASS** = expected to pass today · **REGRESSION** = must stay true; a failure is a
bug · **CURRENT LIMITATION** = asserts today's behaviour on purpose · **PRODUCT DECISION** = the
behaviour needs a decision; the test records today's · **INFO** = recorded only.

| # | Scenario | Result | What happened |
|---|---|---|---|
| s0 | Setup: login, encounter, transcript, Analyze, SOAP text | ✅ all PASS | SOAP draft proposes `Paracetamol · TID · 3 Day · 500 mg` |
| s1 | SOAP → Copy to Rx Pad → save → reload | ❌ **1 PASS test fails** (`500 mg`) | Paracetamol is added once (the SOAP item and the extracted item are de-duplicated by name), TID, 3 Day. But `create_master("medication", "Paracetamol")` resolves to an existing master **`Tablet paracetamol 0Milligram`** (`DRUG-PARACETAMOL-6`, strength 0), and the merge takes the master's strength over the AI's 500. **The saved prescription says 0 mg.** |
| s2 | Ask AI adds a new medication (Pad empty) | ✅ all PASS | `add_medication` → `added_to_draft`; card → `Tablet Paracetamol 500Milligram`, `1-1-1`, `2 Day`, 500 mg; persists after reload. The AI named the drug "Paracetamol Tablet 500mg", which resolves to the 500 mg master |
| s3 | Pad has Paracetamol 500 mg · 1-1-1 · 3 Day; Ask AI "2 days" | ✅ PASS (records behaviour) · **PRODUCT DECISION** | `add_medication` returns **`dose_conflict: true`** although the strength is the same (500 vs 500): only the duration differs. No card; the existing 3-day row is kept. Ask AI cannot change a duration, and calls the change a dose conflict |
| s4 | Clear → Copy again | ✅ all PASS | Paracetamol comes back from the SOAP text (the SOAP draft's own items are already used). Same 0 mg master as s1. Clear empties the chief complaint; the next save rebuilds it from the symptoms (`Fever, Sore throat, Cough`), not the original sentence |
| s5 | Ask AI adds Cetirizine → Clear → Copy | ✅ all PASS · **CURRENT LIMITATION** | Cetirizine (`added_to_draft`, new master created) is on the Pad before Clear; after Clear + Copy only Paracetamol returns. Copy rebuilds from the SOAP text, so Ask AI additions are lost |
| s6 | Copy twice | ❌ **1 REGRESSION fails** | Same page (no reload): still one row ✅. **After a reload, Copy adds a second Paracetamol** (`DRUG-PARACETAMOL-6` 0 mg + `DRUG-PARACETAMOL-7` 500 mg). Cause: after a reload the Pad's `drug_name` is the Item code; the extraction is told "medications: DRUG-PARACETAMOL-6", proposes "Paracetamol 500 mg", and the browser's exact-name rule cannot match an Item code to a drug name |
| s7 | Pad has Paracetamol 400 mg (reloaded); SOAP says 500 mg | ❌ **2 REGRESSION fail** | 400 mg is kept ✅, but **no conflict is detected and a 500 mg row is added**: two paracetamol strengths on one prescription, no system note. The browser guard compares `rxCompareKey("DRUG-PARACETAMOL-8")` with `rxCompareKey("paracetamol 500 mg")`, which never match |
| s8 | Langfuse correlation | ✅ INFO | 86 traces in the session `enc-cbc23692267ebcfe`, in order (Copy = `extract_note_structured` + `create_master` traces, Ask AI = `ask_copilot` → `tool.add_medication` …) |

**Totals:** 100 tests, 96 passed, 4 failed (s1 ×1, s6 ×1, s7 ×2). All 66 scenario requests
returned HTTP 200.

### 9.4 What the failures mean

1. **Wrong strength on the prescription** (s1, s4, s5, s6). A medicine named without its strength
   resolves to a 0 mg master and the merge overwrites the AI's strength with the master's. Look at
   `apply-suggestion.ts` (`strength: info.strength != null ? String(info.strength) : …`) and at how
   `Tablet paracetamol 0Milligram` was created (`create_master` → `_create_medication_master`).
2. **Duplicates and missed conflicts after a reload** (s6, s7). After a save the Pad holds the Item
   code as `drug_name`. The backend compares drugs by Item (`_rx_match_existing`); the browser
   compares names as text (`field-mapping.ts` `rx`, `scribe-apply.ts` `rxCompareKey`). Same rule,
   two implementations, and the browser's does not survive a reload.
3. **Ask AI cannot change a duration** (s3), and labels a same-strength change `dose_conflict`.
   Whether Ask AI should replace, update or ask is a product decision (plan doc 13, steps 12–14).
4. **Clear + Copy forgets Ask AI medicines** (s5). Expected from the code; whether that is right is
   a product decision.

Side effects of a run on the local site: medication masters `Tablet Paracetamol 400Milligram`
(`DRUG-PARACETAMOL-8`) and `Tablet Cetirizine 10Milligram` (`DRUG-CETIRIZINE`) were created through
`create_master`, as the screen would create them. Each run adds one SOAP draft version and system
notes to the encounter's Ask AI threads `bruno-rx-s2`, `bruno-rx-s3`, `bruno-rx-s5`.

## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 3.0 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | §9: `rx-scenarios/` (Copy to Rx Pad, Ask AI → Rx, Clear + Copy, duplicates, strength conflict, Langfuse correlation) with the results of the first run |
| 2.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | 28 steps after a deep check against the code: vitals, sync_transcript, advice list, Regenerate, two negative tests, Deepgram prerequisite, developer log, test guide |
| 1.0 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | First version, 21 steps |
