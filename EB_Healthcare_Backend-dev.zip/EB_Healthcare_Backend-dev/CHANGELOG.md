# Changelog

**Doc status:** living · **Created:** 2026-08-20 by Sarvesh-SocialAngel (AI-assisted) · **Updated:** 2026-10-01 by Divyanshu (AI-assisted) · **Version:** 9.41

All notable changes to Remedisys — backend (`remedisys_healthcare_ai`) and frontend
(`EB_Healthcare_Frontend`). Format: [Keep a Changelog](https://keepachangelog.com). Newest first.

**Scope of this file:** *what* changed, one reader-facing line each, every line carrying its own
**date · repo · author**. Not *why* or *how* — that is `WORK_LOG.md`. Not what is still broken — that
is `docs/KNOWN_ISSUES.md`. See `CLAUDE.md` §9 for the boundary and the entry format.

**Reading an entry:** `**date** · repo · author — what changed. (link to the reasoning)`

> **Rolling window:** this file holds only groups dated in the **current month**. Older groups
> are rolled verbatim into `docs/changelog/YYYY-MM.md` (status `record`) on the first working day
> of the month — see [`docs/changelog/README.md`](docs/changelog/README.md). A dated group is never
> deleted; it is moved.

---

## [Unreleased] — on `dev`, not yet promoted to `pre`

### 2026-10-01 · Checkout lists every bill still owing, not only unbilled visits (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `fix/checkout-shows-part-paid-bills` (from `dev`)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md)

#### Changed
- **2026-10-01** · `frontend` · Divyanshu (AI-assisted) — Billing's Checkout list also shows every bill that still owes money (Unpaid, Partly Paid, Overdue; any patient, any date), one row per bill, with Collect payment for that bill. Before, a billed visit left the list once billed, so a part-paid bill could only be collected from the Invoices tab. The unbilled row shows only the unbilled amount, and the tab badge counts the same list.

### 2026-10-01 · The billing cart runs as the clerk, not as Administrator (backend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `fix/billing-cart-without-admin-switch` (stacked on `fix/billing-refund-preview-from-server`)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-122](docs/adr/adr-122-billing-cart-runs-as-the-clerk.md) · [design note](docs/flows/BILLING_CART_PERMISSIONS.md)

#### Security
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — building a billing cart switched the whole request to Administrator for ten clinical scans. Each scan now runs as the logged-in user. Administrator is borrowed only for a doctype the user cannot read (Therapy Plan, Therapy Session, Observation), only when the patient has such a record, and the elevated read is logged with the real user. The queue board's unbilled probe no longer switches user at all.

#### Fixed
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — the user switch emptied the request's parameters (`frappe.form_dict`) and replaced its session id for whatever ran after the cart; they are now restored.

### 2026-10-01 · The Refund dialog shows the amount the server will pay (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `fix/billing-refund-preview-from-server` (stacked on `fix/billing-rounding-residue`); frontend `fix/refund-dialog-server-preview` (stacked on `fix/billing-confirm-disabled-while-saving`)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-121](docs/adr/adr-121-the-refund-figure-comes-from-the-server.md) · [design note](docs/flows/BILLING_REFUND_PREVIEW.md)

#### Added
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — `billing.preview_credit_note`: what a full or partial refund would pay back, built by the refund's own code and never saved.

#### Changed
- **2026-10-01** · `frontend` · Divyanshu (AI-assisted) — the billing page's Refund dialog shows the server's figures (total, tax, discount, rounding, cash back, waiver) instead of working them out in the browser. Confirm waits for the figure. Before, the screen and the receipt could differ by a peso.

### 2026-10-01 · A bill a few centavos short refunds as offered; no 0.01 "waiver reversals" (backend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `fix/billing-rounding-residue` (stacked on `fix/billing-concurrent-money-moves`)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-119](docs/adr/adr-119-a-rounding-residue-is-not-a-debt-or-a-waiver.md) · [design note](docs/flows/BILLING_ROUNDING_RESIDUE.md)

#### Fixed
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — a bill still owing 0.05 or less was offered for refund and then refused ("only fully paid invoices"), which rolled the whole appointment refund back. It now refunds the cash paid and withdraws the residue, so the bill ends at 0.
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — a rounding gap of 0.05 or less between a Credit Note and the cash paid back is no longer booked as a reversed waiver on a bill that was never waived.

### 2026-10-01 · Two refunds or payments at once on one bill: the second is refused (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `fix/billing-concurrent-money-moves`; frontend `fix/billing-confirm-disabled-while-saving` (both stacked on the ADR-117 branches)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-118](docs/adr/adr-118-lock-the-bill-before-moving-money.md) · [design note](docs/flows/BILLING_CONCURRENT_MONEY_MOVES.md)

#### Fixed
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — two refunds, two payments or two reschedules at once on the same bill could both go through. The one that comes second now gets 409 "was just changed by someone else. Refresh and try again", and nothing is written. Before, on this server, it ended in a 500 database error.
- **2026-10-01** · `frontend` · Divyanshu (AI-assisted) — the Collect and Refund dialogs' Confirm button is disabled while the request is in flight.

### 2026-10-01 · A reschedule or cancel of a bill that is not fully paid no longer bills twice (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `fix/reschedule-partly-paid-balance`; frontend `fix/refund-dialog-balance-withdrawn`
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-117](docs/adr/adr-117-replace-the-line-when-the-invoice-has-a-balance.md) · [design note](docs/flows/RESCHEDULE_PARTLY_PAID_BALANCE.md)

#### Added
- **2026-10-01** · `backend` + `frontend` · Divyanshu (AI-assisted) — the refund plan and the invoice preview report `balance_withdrawn`, the unpaid balance a Credit Note cancelled. The Refund dialog shows it as "Unpaid balance withdrawn" and the invoice preview as "Withdrawn by credit note".

#### Fixed
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — moving a part-paid appointment to a dearer doctor raised a second invoice and left the old one's unpaid balance owing. 1,000 billed, 500 paid, moved to 2,320 owed 1,820 and was billed 2,320. One invoice now owes 1,820.
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — a part-paid appointment can be cancelled and refunded. The Refund dialog said "partly paid" and refunded nothing; it now pays back what was paid and withdraws the rest.
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — a cheaper reschedule of a part-paid appointment replaces its line instead of using the line up at a reduced rate.
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — an appointment paid on a replacement invoice read "Refunded"; it reads "Paid".
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — an invoice whose balance was withdrawn read "Write-off" for it.

### 2026-10-01 · Bruno + Langfuse: run and trace the v9 encounter flow (backend tooling)

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend
**Branch:** `feat/langfuse-encounter-tracing`
**Related:** [`bruno/encounter-flow/README.md`](bruno/encounter-flow/README.md) · [ADR-120](docs/adr/adr-120-langfuse-encounter-tracing.md) · [`LANGFUSE_LOCAL_TRACING.md`](docs/grafana/LANGFUSE_LOCAL_TRACING.md) · [WORK_LOG — 2026-10-01](WORK_LOG.md)

#### Added
- **2026-10-01** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `bruno/encounter-flow/`: 28 requests that run the v9 encounter flow in screen order (login → consent → transcript → vitals → Ask AI → Analyze → Regenerate → stop), with two negative checks (no recording before consent, no line after stop), a per-step console log with secrets masked, and a test guide. Local bench only; `folder.bru` is git-ignored because Bruno stores folder secrets there.

- **2026-10-01** · `backend` · Sarvesh-SocialAngel (AI-assisted) — dev-only Langfuse tracing (ADR-120): every `remedisys_healthcare_ai.*` request gets a trace with its input, output and status (errors marked), traces of one encounter share an opaque `enc-…` session, background jobs are traced, and each model call names every prompt it was built from. `session_for(encounter)` gives the session id. No effect outside developer sites.

- **2026-10-01** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `bruno/encounter-flow/rx-scenarios/`: 9 scenarios (66 requests, 100 tests) for Copy to Rx Pad, Ask AI → Rx, Clear + Copy again, duplicate Copy and strength conflict, each verified after save and reload and correlated with Langfuse. The browser's merge rules run from one mirror, `lib/rxpad.js`. No application change.

#### Fixed
- **2026-10-01** · `backend` · Sarvesh-SocialAngel (AI-assisted) — local Langfuse traces of Bearer-token requests showed user "Guest"; a `set_session()` made after the trace opened was silently ignored (SDK v4 has no `update_trace()`).

### 2026-10-01 · A deploy now configures WhatsApp end to end (backend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/deployment-backend`
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [Deploy guide](docs/deploy_whatsapp.md)

#### Changed
- **2026-10-01** · `backend` · Ashutosh (AI-assisted) — setting up WhatsApp on an environment is now the account keys, a deploy, and ticking Enabled. `after_migrate` syncs the approved templates from Meta, repairs their header images and points the 8 notification configs at the v3/v4 templates, in that order; each step is idempotent, skipped on a site with no Active account, and cannot fail a deploy.

#### Fixed
- **2026-10-01** · `backend` · Ashutosh (AI-assisted) — dev's notifications had been stuck on the v1/v2 template names since the account was repointed at another WABA: the one-shot mapping patch ran before any v3/v4 template existed, skipped all eight, and — having not raised — was recorded in Patch Log and never ran again. Pre and production were waiting on the same trap.
### 2026-10-01 · Refunds today counts cash paid out (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `fix/refunds-today-cash-out`; frontend working tree (uncommitted)
**Related:** [WORK_LOG — 2026-10-01](WORK_LOG.md) · [ADR-116](docs/adr/adr-116-refunds-today-counts-cash-paid-out.md)

#### Added
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — `list_all_invoices` returns `refunded_cash_total`, the cash paid out through the matching credit notes (new `billing.refunded_cash_total`).

#### Fixed
- **2026-10-01** · `backend` · Divyanshu (AI-assisted) — the invoice preview's Visit block read "—" for a reschedule's replacement, additional-payment and credit-note invoices; it now resolves the appointment from Appointment Reschedule History, including a credit note that refunds one (via the invoice it reverses).
- **2026-10-01** · `backend` + `frontend` · Divyanshu (AI-assisted) — Billing's "Refunds today" showed credit-note face value (2,320) although 1,740 left the till; it now shows cash paid out.
- **2026-10-01** · `frontend` · Divyanshu (AI-assisted) — a cancelled appointment whose replacement invoice still holds money read "Refund Issued" beside a live Refund button; it now reads "Refund due".

### 2026-09-30 · Financial Report: charts removed, money figures stop overlapping and repeating the currency (frontend)

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend
**Branch:** `feat/reports-design`, not yet merged to `dev`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Fixed
- **2026-09-30** · `frontend` · Anant Sharma (AI-assisted) — On every report screen, a headline figure too wide
  for its card no longer paints over the figure next to it. Financial Report / Today showed
  "116,643 MXN152,671 MXN" as one run of digits. The figure now scales down to fit its own card
  instead, and is never wrapped or cut short — a card with room still renders at the full size.

#### Changed
- **2026-09-30** · `frontend` · Anant Sharma (AI-assisted) — Financial Report's five money figures read
  "116,643" rather than "116,643 MXN". Each of those cards names the currency once, underneath —
  Refunded, Outstanding and Waived say it now too, where before only two cards did.

- **2026-09-30** · `frontend` · Anant Sharma (AI-assisted) — Revenue by Provider and Outstanding Balances
  read their money figures the same way — "385,863" with the currency named once underneath,
  instead of "385,863 MXN" overlapping the card beside it.

#### Removed
- **2026-09-30** · `frontend` · Anant Sharma (AI-assisted) — All five charts are gone from the Financial
  Report: Collection Trend, Payment Split, Method Volume, Billing Outcome and Refunds by Method.
  The page is now the KPI cards, the basis note, the insights row and the transactions ledger.
  The endpoint still returns the chart data, so the report drawer is unaffected.

### 2026-09-30 · One "refund everything" action for a cancelled appointment (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend and frontend `feat/appointment-line-owns-its-money`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [Design note §12](docs/flows/RESCHEDULE_CANCEL_REFUND_LINES.md) · [ADR-114](docs/adr/adr-114-appointment-line-owns-its-money.md)

#### Added
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — `get_appointment_refund_plan` (read-only) and `refund_cancelled_appointment`: a cancelled appointment is refunded across every invoice that holds its money (original, reschedule extra, replacement), all together or not at all. Front Desk and Admin only.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — the Appointments screen's Refund opens one dialog listing each invoice with cash back and waiver reversed, and refunds them together; the button stays until nothing is left to refund.

#### Fixed
- **2026-09-30** · `backend` + `frontend` · Divyanshu (AI-assisted) — an appointment with no invoice yet showed the pre-tax fee (2,000); the row now shows what it will invoice for (2,320) via a new `billing.estimated_total`.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — the Appointments row showed the appointment's fee (2,000) instead of what was billed (2,320, tax and reschedule extra included); it now shows the billed total.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — after a dearer pay-now reschedule then cancel, the old Refund dialog covered one invoice and the button vanished, leaving the rest of the patient's money with the clinic.

### 2026-09-30 · Only front desk and admin move money; reassign settles the fee (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend and frontend `feat/appointment-line-owns-its-money`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [ADR-115](docs/adr/adr-115-billing-without-permission-bypass.md)

#### Security
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — payments, refunds, invoices and reschedule
  settlements now run on the user's own permissions; only front desk and administrators can move
  money, and other roles are told so before anything changes.

#### Fixed
- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — reassigning an appointment to a
  doctor with a different fee now refunds or collects the difference; the Appointments screen shows
  it before you confirm.

- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — after a cheaper reschedule, the
  new invoice and its credit note no longer show a false write-off; the preview shows the credit
  moved between them ("Credit from …" / "Applied to …").
- **2026-09-30** · `frontend` · `backend` · Divyanshu (AI-assisted) — a credit note's preview is headed
  "Credit Note", shows "Settled", marks cash going back as a refund, and its printed remark says how
  much was refunded and where the rest went.

- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — a refund now goes back through the payment
  method the money came in by (cash from the till, a bank draft from the bank, split when it came in
  both ways) instead of always leaving the bank account with no method recorded; credit-note
  remarks show the currency code instead of "$".

- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — front desk can again settle an invoice through a
  Government waiver (and reverse it on a refund); it was refused with a permission error. A database
  deadlock during a reschedule now reports its real error instead of "savepoint does not exist".

- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — the invoice list shows the payment
  method of a replacement invoice (the tender its money came in by) instead of "—".

- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — refunding an invoice that was part paid and part
  waived now shows how much goes back in cash and how much is a waiver reversed (no money), instead of one total; the
  payment method reads the same ("Cash + Government") on the list and in the invoice preview.

- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — an appointment whose invoice was refunded in full no longer shows a
  leftover paid amount when part of the invoice had been waived (it showed 354.84 instead of 0).

- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — cancelling a visit that was already paid and then moved to a
  dearer doctor with "pay later" now cancels the unpaid extra invoice (it stayed open for a visit that no longer existed)
  and lets the original payment be refunded (the Refund button was hidden because the visit read "Pending").

#### Changed
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — an invoice settled entirely by a Government waiver
  offers "Reverse waiver" instead of "Refund"; its dialog says no money was collected and nothing is paid back.
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — when a practitioner cancels a visit with an
  unpaid invoice, the charge stays and front desk gets a task to remove it.

### 2026-09-30 · Reschedule and cancel touch only the appointment's own invoice line (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend and frontend `feat/appointment-line-owns-its-money`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [ADR-114](docs/adr/adr-114-appointment-line-owns-its-money.md)

#### Fixed
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — after an appointment moves to a cheaper slot,
  cancelling it now refunds the fee the patient kept; before, it said "Nothing left to refund".
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — a cheaper reschedule no longer uses up a
  vaccine's or another appointment's line on the same invoice.
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — cancelling an unpaid appointment removes
  only its own charge; other items and appointments on the same invoice stay owed.

#### Changed
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — a cheaper reschedule bills the new fee on a
  replacement invoice paid from the earlier payment, and pays back only the difference in cash.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — refunding a cancelled appointment opens on
  the invoice that holds its money, with only its own line ticked.

### 2026-09-30 · Narzim GPT: the gaps found in review (backend + frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend, frontend
**Branch:** `feat/narzim-gpt-experience` in both repos
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a conversation is titled by its first turn
  with a topic; "hi" and "testing" no longer name it "Initial Greeting and Assistance" for good.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — "make it bold", "shorter", "as a table" and
  their Spanish forms are answered; the scope gate had refused them as writing tasks (B15).
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the chat's library listed a backend method
  that no longer exists and could not upload; it is Drive now, and any file, note or upload can be
  ticked as a source.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the greeting never addresses an honorific
  ("Dr.") as a first name; a note's legacy `/documents/[id]` URL opens the Documents editor; no
  booking button on the AI page.

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `list_encounters(search=…)`: a visit by the
  patient's or practitioner's name, its id or its type, looked up through the Patient and
  Practitioner records because the encounter's own name columns are null on a real site.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `recent_patients`: the patients this
  clinician saw most recently, for the composer's picker before anything is typed.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `set_default_sources` and `defaults` on
  `list_sources`: the composer's source switches start where the user last left them.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — Link a patient shows recent patients on
  opening; Link a visit searches the whole record from two characters.

### 2026-09-30 · Follow-up suggestions read as the clinician's own request (backend + frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend, frontend
**Branch:** `feat/narzim-gpt-experience` in both repos
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [`prompts/README.md`](prompts/README.md)

#### Fixed
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — clicking a follow-up such as "Do you want me
  to list the two draft visits?" sent that sentence back. It now sends the request it implies ("List
  the two draft visits"), in English and Spanish, and the button shows exactly what it will send.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — a follow-up that needs the clinician to act
  first (link a visit, attach a file, choose) is shown as text, not as a button.

#### Changed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — prompts `narzim-assistant-v7`/`-v8` and
  `narzim-assistant-context-v7`/`-v8` replace v5/v6: one added rule, that a follow-up is written as
  the clinician would type it, never as an offer, never needing them to act first. Older log rows
  keep their versions.

### 2026-09-30 · Narzim GPT: task lists, recent visits, dictation cue, template type help (frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** frontend
**Branch:** frontend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Added
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — a task pill on the empty chat opens a list
  of that kind of task in the composer's place; a row puts its opening in the composer, nothing is
  sent for the clinician.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — "Listening…" beside the microphone while
  dictation is on, in the chat and the template editor.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the Templates page and the editor's type
  menu say what Encounter, Document and Analysis are for, and that the type groups templates
  without changing how one is filled.

#### Fixed
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — Link a visit lists the newest visits as
  soon as it opens, and narrows them as you type; it showed nothing until two characters were typed.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the template editor's help panel slides
  open and closed instead of appearing and vanishing.

#### Changed
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — more room between Rename, Add to
  favourites and Remove in a conversation's menu.

### 2026-09-30 · Narzim GPT start screen: a greeting, the composer, and the tasks below it (frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** frontend
**Branch:** frontend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Changed
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the empty chat shows a greeting with the
  clinician's first name, the composer, and five task pills (Look up, Work up, Treat, Prepare,
  Write) that open the shortcut library on that tab; the four generic question cards are gone.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — linked patient, visit, template, file and
  page chips sit inside the composer box.

#### Added
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the conversation history column can be
  hidden and shown; the choice is remembered in the browser.

### 2026-09-30 · Full payment collected in one go; refunds show and carry the exact discount (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend and frontend `fix/billing-rounding-and-refund-discount`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Fixed
- **2026-09-30** · `backend` · Divyanshu (AI-assisted) — a partial refund of an invoice with a flat
  discount now gets only the refunded lines' share of that discount, instead of the whole discount
  on every partial Credit Note.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — the refund dialog's "Total to refund"
  subtracts the invoice discount and charges tax on the discounted amount, so selecting every line
  matches the invoice total instead of the pre-discount price.
- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — collecting the full amount while
  creating an invoice now settles ERPNext's rounded total in one payment, so rounding no longer
  leaves a few centavos (e.g. 0.05) outstanding.

- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — Refund no longer shows on an
  invoice with nothing left to refund (e.g. one whose reschedule refund already returned every unit).

#### Changed
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — an invoice whose earlier refund returned
  every item for less than its total now reads "Partial · fee adjusted" and shows a greyed-out
  Refund button explaining that nothing is left to refund.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — Refund from the invoice preview (patient
  chart and billing) opens the same item-picker refund dialog as the billing list.
- **2026-09-30** · `backend` · `frontend` · Divyanshu (AI-assisted) — the new sales invoice screen's
  tax and total now equal what is saved, it shows the subtotal, the rounding and the rounded
  total that is collected, and each line's Amount is before tax, as on the printed invoice.
- **2026-09-30** · `frontend` · Divyanshu (AI-assisted) — the refund dialog lists each line as the
  invoice does (unit price × qty, the line's discount, tax %, amount) and totals the base, item
  discounts, the invoice discount, rounding, and the rounded amount that is actually paid back.

### 2026-09-29 · Reports v3: custom date range back on every report, Patient Flow throughput row out

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend
**Branch:** `feat/reports-design`, not yet merged to `dev`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [design plan §10](docs/reports/18-reports-v3-redesign.md)

#### Added
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Every report page and the Reports landing page can be
  scoped to a custom day or date range again, chosen from a fifth segment inside the same
  Today / 7 / 30 / 90 control. Future dates are not selectable.
  ([why](docs/reports/18-reports-v3-redesign.md))

#### Changed
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — The "Suggested next step" card on every Operations report
  now says "Open the list view" and shows every appointment in the period, instead of promising a
  calendar and opening the appointments list.
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Check-in Rates' funnel stage reads "Seen by practitioner"
  rather than "Seen by doctor", matching the word the rest of the product uses for that role.
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — The Reports landing page's Brief now states the window it
  is actually showing: picking a custom range captions it with those dates rather than the preset
  that is no longer in force.

- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Every report page now shows its filters on the title's
  own row, the way the Reports landing page does, instead of dropping them to a line of their own.

#### Removed
- **2026-09-29** · `backend` + `frontend` · Anant Sharma (AI-assisted) — "Ask Orin", the question box on the Reports
  screens, is removed entirely — the button, the panel, the endpoint, the prompt and its tests.
- **2026-09-29** · `backend` · Anant Sharma (AI-assisted) — The AI findings on the Reports screens do not appear: the
  backend that writes them was lost from the working tree before it was ever committed and cannot be
  recovered. The panel renders nothing rather than an error, and every figure, chart, table and
  export on every report is unaffected. ([what was lost](docs/KNOWN_ISSUES.md))
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Patient Volume no longer shows its three charts (visits
  by provider, share by provider, weekly visits). The design gives this report one chart — visits per
  day split new vs returning — which the backend does not compute, so the page shows its figures,
  findings and provider table with no chart rather than one the design does not have.
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Patient Flow no longer shows the Patient flow funnel,
  Appointment outcomes or Appointment types charts. The page keeps its hourly chart, Breakdown table
  and KPI figures; the backend still returns all three datasets.
- **2026-09-29** · `frontend` · Anant Sharma (AI-assisted) — Patient Flow no longer shows the throughput row's two
  cards, "Peak hour" and "Registered". Both figures are still computed and returned, and the
  Breakdown table still marks its peak row from `peak_hour`.

### 2026-09-28 · Reports v3 redesign (backend + frontend)

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend
**Branch:** `feat/reports-design` (both repos), not yet merged to `dev`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-111](docs/adr/adr-111-reports-v3-chart-parity.md) · [ADR-112](docs/adr/adr-112-check-in-and-claims-funnels.md) · [ADR-113](docs/adr/adr-113-rolling-day-count-report-periods.md) · [design plan](docs/reports/18-reports-v3-redesign.md)

#### Security
- **2026-09-28** · `backend` · Anant Sharma (AI-assisted) — The reports overview no longer returns clinic revenue and
  outstanding balances to nurses: it is gated to Front Desk and Practitioner (Admin by bypass),
  closing G-42. ([why](docs/reports/G-42-ROLE-GATE.md))
- **2026-09-28** · `frontend` · Anant Sharma (AI-assisted) — Report Export writes aggregate figures only; a table that
  names patients is left out of the file, which says where to export it from instead.
  ([why](docs/reports/18-reports-v3-redesign.md))

#### Added
- **2026-09-28** · `frontend` · Anant Sharma (AI-assisted) — New Reports landing page: the Brief (headline figures with
  change vs the previous period), Pinned reports, and every report grouped by
  Operations / Clinical / Financial / Practitioner with search. The Brief's AI findings and the
  pinned list stay empty until their backend is rebuilt ([what was lost](docs/KNOWN_ISSUES.md)).
- **2026-09-28** · `frontend` · Anant Sharma (AI-assisted) — Every report page gets the Reports v3 header (back link and
  category, period switch, doctor filter, Export).
- **2026-09-28** · `backend` + `frontend` · Anant Sharma (AI-assisted) — Patient Flow gets a heat-map toggle (arrivals by
  weekday and hour) and Payment Methods gets a "by mode" toggle on its trend chart; both are an
  additional view next to the existing chart, which stays the default.
  ([why it's additive, not a chart-type replacement](docs/reports/18-reports-v3-redesign.md))

#### Changed
- **2026-09-28** · `frontend` · Anant Sharma (AI-assisted) — All 17 reports are listed again, including Diagnosis Trends,
  Chronic Care, Outstanding Balances, Claims Status and Utilization Rate; the reasons they were
  hidden still hold. ([register](docs/reports/HIDDEN_REPORTS.md))
- **2026-09-28** · `frontend` · Anant Sharma (AI-assisted) — Report headline figures are larger, with their change shown
  underneath as "▲ 12% vs last month"; rate changes on the Brief are shown in points.
### 2026-09-30 · A failed reply no longer leaves a duplicate or orphan question (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — when a reply fails, the question no longer
  stays in the conversation on its own, and sending it again no longer shows it twice (B2).

### 2026-09-30 · Answers agree with the record: signed vitals, pending labs, long citations, tool names (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a signed visit's vital signs are read; they
  were reported as absent because only draft vital signs were looked at.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a citation whose title is longer than its
  field no longer loses the whole reply; the title is shortened, or the citation dropped, and the
  answer is kept.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — the AI Prompt Log records which chart tools
  a Narzim GPT answer used.

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — lab tests that are ordered and not yet
  resulted are reported as pending, so "no results" and "nothing ordered" no longer read the same.

### 2026-09-30 · No citations on record questions; follow-up questions after every answer (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-110](docs/adr/adr-110-literature-search-only-for-knowledge-questions.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — with Clinical Web on and a chart linked, a
  question about the record ("summarise the transcript", "what did we discuss") no longer searches
  the literature or attaches citations.

#### Changed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — every answer ends with up to three
  follow-up questions the assistant can answer; the chat shows them as buttons.

### 2026-09-30 · A document from a template is filled from the chart, with no placeholder left (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-109](docs/adr/adr-109-document-turn-reads-the-chart-first.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — with a template attached and a patient
  linked, "generate" returns the document filled from the chart, not the template's placeholders.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a streamed answer that could not be saved
  now says so.

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a reply written from a template lists the
  fields the record did not answer.

### 2026-09-30 · Narzim GPT: medications on the linked visit, attached templates, rename and favourites (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-107](docs/adr/adr-107-narzim-thread-rename-and-favourites.md) · [adr-108](docs/adr/adr-108-linked-visit-medications-and-attached-template.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — with a signed visit linked, Narzim GPT no
  longer reports "no current medications documented" when the prescriptions are on that visit.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — with a template attached, a short request
  such as "generate explainer" writes the document from the chart instead of being declined.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — answers no longer end with "feel free to
  ask" and similar closing offers.

#### Changed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a medication answer reports prescriptions
  and medication orders both, with each order's status (active, on-hold, stopped, completed).

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `rename_thread` and `set_thread_favourite`;
  the conversation list reports which conversations are favourites.

### 2026-09-30 · Live dictation in the Narzim GPT composers (backend + frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend, frontend
**Branch:** `feat/narzim-gpt-experience` in both repos
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-106](docs/adr/adr-106-live-dictation-token-for-composers.md)

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `mint_dictation_token` issues a 10-minute
  Deepgram token for dictating into a text box, with no encounter.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — in the Narzim GPT chat and the template
  editor, dictated words appear as they are spoken.

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — dictation follows the clinician's own
  language, so English dictated on a Spanish-language site is no longer transcribed as Spanish.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — a blocked microphone, a missing microphone,
  a lost connection and silence each show their own message.

#### Security
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the chat composer no longer uploads
  dictated audio through the server, and the template editor no longer sends it to the browser
  vendor's speech service. Both stream to Deepgram directly.

### 2026-09-30 · Template studio: drafts, delete, instant examples, printed labels (backend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend
**Branch:** backend `feat/narzim-gpt-experience`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-105](docs/adr/adr-105-template-studio-drafts-delete-and-example-cache.md) · [design](docs/ai/NARZIM_TEMPLATE_STUDIO_FIXES.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a template that had been opened in the
  editor can now be deleted.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a new template no longer fails to save with
  "'Heading' will get truncated, as max characters allowed is 140".
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — new templates print a label in front of each
  form value, in the example and in the real note.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — the example no longer invents a record
  number; an identifier slot shows the word "example".

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `draft_template_outline` writes a first
  outline without creating a template.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — the editor's chat reply says whether the
  request changed the outline, and which sections were added or removed.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — saving from the editor can set the
  template's type and description.

#### Changed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — an example is written once per structure and
  kept in the cache for 7 days; `regenerate` asks for a fresh one.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — Apply template writes a repeating block once
  per item found in the sources, and omits it when there are none.

### 2026-09-30 · Narzim GPT answers a question about the chart in front of you (backend + frontend)

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend, frontend
**Branch:** `feat/narzim-gpt-experience` in both repos
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [adr-050](docs/adr/adr-050-narzim-assistant-domain-scope-gate.md) · [`prompts/README.md`](prompts/README.md)

#### Fixed
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — with a patient, visit, template or clinical
  document attached, Narzim GPT no longer refuses a question for being vaguely phrased. "Summarise
  this session" and "brief me" are answered from the chart; an explicit non-clinical request is
  still refused.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a turn with only a patient linked answers at
  patient level instead of declining because no visit is linked.
- **2026-09-30** · `frontend` · Satyakam (AI-assisted) — the starter cards on an empty chat follow
  the linked patient; the BFF route no longer drops the linked context.

#### Added
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — a broad question on a linked chart gets a
  briefing, then up to three follow-up questions drawn from what the record actually contained.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — Langfuse traces carry the conversation, the
  clinician and the prompt version on every generation.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — `AI Settings.narzim_scope_prompt_v1` rolls
  the domain gate back to the previous classifier prompt without a deploy.
- **2026-09-30** · `backend` · Satyakam (AI-assisted) — Spanish for the Narzim GPT starter cards.
### 2026-09-30 · v9 Rx print shows Advice lines and an attached Canvas drawing (ADR-104)

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `docs/adr-104-rx-print-canvas-svg-rendering`, frontend `feat/v9-rx-print-advice-canvas`
**Related:** [WORK_LOG — 2026-09-30](WORK_LOG.md) · [ADR-104](docs/adr/adr-104-rx-print-canvas-svg-rendering.md)

#### Added
- **2026-09-30** · `backend` · Sarvesh-SocialAngel (AI-assisted) — recorded ADR-104: the v9 Rx
  print/PDF pipeline renders an attached Canvas drawing by extracting its SVG and loading it as
  a plain `<img>`, never an iframe — the safe pattern ADR-097 already named for exactly this
  situation. No backend code changed; `attach_to_rx`, `print_mode`, `canvas_data` and the Advice
  endpoints already existed.
- **2026-09-30** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — `encounter-report.tsx` gains
  two new report sections, Advice and an attached Canvas drawing, in both Rx print surfaces
  (`SignedReportOverlay`, the post-sign preview, and `EncounterReportModal`, reprinting any past
  encounter). `canvas-serialize.ts` gains `canvasDataToImgSrc()`, the SVG-extraction helper ADR-104
  specifies. Only a canvas with `attach_to_rx = true` prints; `print_mode` (Full page/Compact) is
  read for the first time since it was added.

### 2026-09-29 · Medications tab shows submitted encounters only (backend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** backend `fix/medications-submitted-encounters-only`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Fixed
- **2026-09-29** · `backend` · Divyanshu (AI-assisted) — the patient chart's Medications tab no
  longer lists medicines from an encounter that is still a draft or was cancelled; only submitted
  encounters count as prescribed.

### 2026-09-29 · Checkout badge, refund totals sign, Uncollected today-only (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend, frontend
**Branch:** backend `docs/agentic-dev-restructure`, frontend `dev` (both uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [adr-099](docs/adr/adr-099-dashboard-revenue-kpis-clinic-wide.md)

#### Changed
- **2026-09-29** · `backend` · Divyanshu (AI-assisted) — the Billing header's "Uncollected" figure
  now covers invoices posted today only, like "Collected today" and "Refunds". The all-time
  outstanding total is still shown on the Invoices tab.

#### Fixed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — after collecting a payment, the Billing
  invoice list and the header figures update straight away instead of only after a page reload. The
  header figures are labelled "Uncollected today" and "Refunds today".
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Billing now has one refund filter, "Refund
  Issued", covering the refunded invoices in the list; the separate "Refunded" filter for credit
  notes was removed from the filter row. The summary shows just "Billed (MXN)" and "Outstanding
  (MXN)" amounts.
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — the Invoices summary is now three small
  figures (invoices, billed, outstanding) on the filter row, and the selected status filters are no
  longer repeated as removable tags underneath. A new "Refund Issued" filter lists invoices that
  have been refunded, so the status filters now add up to "All".
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Billing search no longer loses the search
  box while results load; previous results stay on screen with a small spinner. An unsubmitted draft
  credit note is no longer counted as a refund. The invoice summary text is shown in full, moving to
  a second line when the toolbar is full.
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — with only the "Refunded" filter selected,
  the summary now shows the number of refunds and the amount refunded, without an outstanding figure.
  The Invoices toolbar no longer shows a scrollbar, and its filter pills no longer wrap.
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — the Checkout tab count no longer stays stuck
  on an old number while you are on another tab. Refund totals under the "Refunded" filter show as a
  plain amount, without a minus sign.

### 2026-09-29 · Refunded totals fixed; multi-select pills; search minimum length (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Fixed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — the "Refunded" filter showed 0.00 MXN for
  both totals even with real refunds selected; it now shows the correct amounts. Status filters can
  now be combined instead of only one at a time. Search no longer queries the server for a single
  typed character.

### 2026-09-29 · Invoice list totals fixed; Unpaid pill restored (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend
**Branch:** backend `docs/agentic-dev-restructure` · frontend `dev` (both uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-102](docs/adr/adr-102-invoice-list-exact-totals.md)

#### Fixed
- **2026-09-29** · `backend` + `frontend` · Divyanshu (AI-assisted) — the Invoices tab's own
  "billed"/"outstanding" totals could undercount once a clinic passed 100 invoices (this site has
  240); they now come from an exact server-side total instead of summing only the invoices already
  loaded on screen.
  - **2026-09-29** update — that fix had shipped on the backend but never reached the browser (a
    silent gap in the Next.js layer); it does now. A second bug in the same total (return invoices
    were counted when they shouldn't be) is also fixed.
  - **2026-09-29** update — the Invoices tab now loads every matching invoice instead of only the
    newest 100, so the "All" count, status filters (an Overdue invoice was reading as 0), and other
    filters are no longer silently incomplete once a clinic passes 100 invoices.

#### Added
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — "Unpaid" is back as a quick filter; a real
  Unpaid invoice now exists on the site.

### 2026-09-29 · Checkout unbilled-only; Unpaid/Partly-Paid filter fixed (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Fixed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Checkout no longer lists a visit that's
  already been invoiced and paid. The "Unpaid" filter no longer also matches "Partly Paid" invoices
  (this site had 0 truly Unpaid invoices; the filter was always showing Partly Paid ones instead).

#### Added
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — "Overdue" is now its own quick filter on
  the Invoices tab, alongside Paid/Unpaid/Partly Paid/Refunded.
  - **2026-09-29** update — Checkout shows one row per patient instead of one per unbilled visit;
    they showed the same total twice.

### 2026-09-29 · Checkout: default selection, no Outstanding list, no Paid badge (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Changed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Checkout now selects the first patient in
  queue by default instead of landing empty. The queue no longer shows a "Paid" badge for an
  already-settled patient.

#### Removed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Checkout no longer shows a clinic-wide
  outstanding-invoices list when nobody is selected (added earlier the same day, reversed by request).
  - **2026-09-29** update — the "Unpaid" quick filter is removed from the Invoices tab.

#### Fixed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — unchecking "Collect payment now" in the
  New Invoice sheet now actually hides the payment method and amount fields (they'd stayed visible
  since the sheet's footer was rebuilt earlier today). The Checkout tab's badge count now matches
  what the tab actually shows, instead of counting every completed visit including already-billed
  ones.

### 2026-09-29 · New sales invoice sheet wording fixes (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Changed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — the New sales invoice sheet's title is
  sentence case, the patient card shows a "Change" link instead of an icon only, and an empty
  unbilled cart reads "Nothing unbilled" instead of "—".
  - **2026-09-29** update — each line item shows how much its own discount took off, in currency,
    not just the percentage. The sheet's bottom bar is now one row (totals, payment) instead of two
    side-by-side cards, with no "Save as draft" button. The drawer is wider and the item list has
    more room before it scrolls on its own.
  - **2026-09-29** update — removed the Ctrl+Enter shortcut added above.

### 2026-09-29 · Printed invoice matches the design (backend + frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend
**Branch:** backend `docs/agentic-dev-restructure` · frontend `dev` (both uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-101](docs/adr/adr-101-invoice-detail-print-fields.md)

#### Added
- **2026-09-29** · `backend` · Divyanshu (AI-assisted) — The invoice detail now includes the issue
  time, each item's category and source, the patient's phone, the visit(s) billed, who issued the
  invoice, and who took each payment and when.

#### Changed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — The invoice view and print follow the
  design's invoice page: summary strip, billed-to / visit / from, items grouped by category,
  payments received, and a balance-due box.

#### Fixed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Invoice dates could print one day early in
  Mexico, and months printed in English on the Spanish screen.
  - **2026-09-29** update — checked against a real printed invoice: amounts no longer wrap across
    two lines, a long payment reference no longer gets cut off, and the tax-ID label ("RFC") no
    longer appears on a non-Mexican company's invoice.

### 2026-09-29 · Checkout walk-in + outstanding invoices; invoice view redesigned (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-098](docs/adr/adr-098-billing-screen-restyle-presentation-layer-only.md)

#### Added
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Checkout has a "Walk-in bill (pharmacy,
  lab only)" button that opens the new-invoice sheet.
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — With no patient selected, Checkout lists
  every outstanding and overdue invoice, oldest due first, each with View and Collect.

#### Changed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — The invoice view (and the printed invoice,
  which is the same page) now uses the new-invoice sheet's card layout. Every field, refund, collect
  and credit-note link is unchanged; the invoice date is labelled "Date" instead of "Payment Date".

### 2026-09-29 · Invoices table collapsed to 7 columns (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-100](docs/adr/adr-100-invoice-list-item-summary-field.md)

#### Changed
- **2026-09-29** · `frontend` · Divyanshu (AI-assisted) — Billing's Invoices table now matches the
  Narzim mock's 7 columns (Invoice/Patient/Items/Method/Amount/Status/Actions). Provider, Paid,
  Balance and Due are no longer shown by default (still in code, not deleted); MRN moved to a
  secondary line under the patient's name instead of its own column.
  - **2026-09-29** update — MRN removed from the table entirely (the mock shows name only), and the
    table header changed from a solid teal bar to the mock's light neutral style, on Billing only.
  - **2026-09-29** update — each invoice row now shows Refund (when refundable) and View, styled to
    the mock. Collect moved off the row; it is in the invoice sheet that View opens.
  - **2026-09-29** update — Collect is back on the row for unpaid invoices, next to Refund and View.
  - **2026-09-29** update — the Status pill is left-aligned in its column and no longer runs into
    the row's buttons.
  - **2026-09-29** update — long item lists wrap instead of being cut off, and "+N more" is
    translated.
  - **2026-09-29** update — KPI chips widen to fit their amount instead of cutting it off.

### 2026-09-29 · Invoice list rows carry an item summary (backend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `docs/agentic-dev-restructure`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-100](docs/adr/adr-100-invoice-list-item-summary-field.md)

#### Added
- **2026-09-29** · `backend` · Divyanshu (AI-assisted) — `list_all_invoices` and
  `list_patient_invoices` now return `items_summary`, a short string of what each invoice was for
  (e.g. "Consulatation fee, Consulatation fee"), batched from the invoice's own line items — no new
  endpoint, additive field only.
  - **2026-09-29** update — repeated items now collapse with a count ("Consulatation fee ×2"), and
    how many further items were left out comes back as `items_more_count` rather than English text
    in the summary, so the frontend shows it in the user's language. Feeds the Narzim-restyled Billing screen's Items column
  (`EB_Healthcare_Frontend/docs/architecture/BILLING_NARZIM_RESTYLE.md`), which previously had no
  data source for it.

### 2026-09-29 · Dashboard revenue KPIs are now clinic-wide (backend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `docs/agentic-dev-restructure`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [ADR-099](docs/adr/adr-099-dashboard-revenue-kpis-clinic-wide.md)

#### Fixed
- **2026-09-29** · `backend` · Divyanshu (AI-assisted) — The dashboard's "collected today" and
  "uncollected" figures were computed only from today's scheduled appointments, so they read 0.00 MXN
  whenever no appointment happened to be booked for today — even with real, current outstanding debt
  on the books. Now computed directly from Sales Invoice, clinic-wide, matching what the labels
  actually claim.
  - **2026-09-29** update — "collected today" now includes payments taken through a Payment Entry
    (it was counting only POS payments, so a paid non-POS invoice showed as 0), and the figures now
    respect the user's permissions.

### 2026-09-29 · Three encounter gaps found and fixed: cancel-with-orders, order status in Patient History, Advice/Canvas read permission

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repo:** backend
**Branch:** `feature/v9-service-request-active-status`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Fixed
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — cancelling a signed encounter
  that still has an active Medication Request, or a submitted Vital Signs row, no longer fails.
  Both are now cancelled before the encounter itself, not after — the order the check requires.
  - **2026-09-29** update — also fixed: an On-Hold or Completed Medication Request/Service
    Request is reset to Active before either cancel call, since core itself refuses to cancel
    one in either state. And: a cancelled Service Request's status was staying stuck at whatever
    it was (core's own `ServiceRequest.on_cancel` never sets it to Revoked) — 6 already on this
    site, now corrected by a one-time data patch.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `list_advice`/`get_advice` and
  `list_canvases`/`get_canvas` now check real permission on Encounter Advice/Encounter Canvas
  themselves, not only on the parent encounter — closing a gap where Front Desk, or a portal
  patient, could read either regardless of their own (nonexistent) grant on those doctypes.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — saving a Canvas without
  re-sending `attach_to_rx` no longer silently turns it back off.

#### Added
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Service Request and Medication
  Request are now registered in Patient History Settings (ADR-103): an order, and every later
  Continue/Hold/Revoke/Stop, now reaches the patient's Medical Record timeline. Going forward
  only — existing orders don't gain a retroactive entry.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Encounter Advice and Encounter
  Canvas are now governed centrally in `eb_docperm_spec.json`, visible to a permission audit for
  the first time. No access changes — same grants they already had.

### 2026-09-29 · Fix: a real Active Service Request never showed as Active in v9 Overview

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repo:** backend
**Branch:** `feature/v9-service-request-active-status`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Fixed
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — lab/procedure/therapy rows now
  carry their real, linked Service Request id and live status (`_attach_service_request_status`,
  mirrors the 2026-09-26 Medication Request fix). Added the matching `set_service_request_status`
  method (Continue/Hold/Stop) the frontend already called but that did not exist. Granted
  EB_Practitioner/EB_Nurse write on Service Request (`eb_docperm_spec.json`), the same permission
  gap the medication fix closed for Medication Request.
  - **2026-09-29** update — also added `list_active_orders(patient)`: every Active / On Hold
    Service Request and Medication Request for the patient, across all encounters (same source as
    core's Desk "Encounter Details" tab). v9 Overview's "Active now" column now reads it.
  - **2026-09-29** update — status actions now match core Desk's own menu exactly: Service Request
    Active → On Hold / Revoke, On Hold or Revoked → Active; Medication Request Active → On Hold / Stop /
    Cancel, On Hold or Stopped → Active. Enforced server-side (`_SR_STATUS_TRANSITIONS`,
    `_MED_STATUS_TRANSITIONS`); the Service Request action is now `revoke` (was `stop`).

### 2026-09-29 · v9 Advice connected: Copy to Rx Pad fills it from the SOAP, Ask AI can read and change it

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend
**Branch:** `feature/v9-advice-connect` (backend), `feat/v9-advice-canvas-connect` (frontend)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Added
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `extract_note_structured`'s v9-only
  `allow_full_order_details` mode gains an `advice` target: patient-instruction lines from the SOAP's
  Plan (rest, fluids, wound care, when to return, medication-timing advice) are extracted alongside
  the existing orders, deduplicated and capped.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — v9-only opt-in `enable_advice_tools`
  on `ask_copilot`: offers `add_advice`/`remove_advice` and includes the encounter's current Advice
  lines in `get_encounter_state`. Classic/v3 never send this flag.
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 Advice section is connected to
  the real `Encounter Advice` record (backend PR #460): presets and free text autosave; presets save
  in the Rx language chosen in Configure Pad. Copy to Rx Pad and an applied Ask AI advice suggestion
  both add their own lines, shown as removable "AI" rows.
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 Canvas is connected to the real
  `Encounter Canvas` record: Save, a saved-sketch list with reopen-and-edit, and Attach to Rx now work.
  A drawing is saved as an SVG (display/print) plus its stroke list as JSON (reopen), always rendered
  in a sandboxed iframe. Print size matches the backend's two options (Full page / Compact).

#### Changed
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Configure Pad's Rx language choice
  is now shared (localStorage) so AdviceSection can read it, instead of staying local to the drawer.

### 2026-09-29 · v9 Scribe: editable SOAP, AI-proposed Assessment/Plan and orders, Copy to Rx Pad fills from the SOAP

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend
**Branch:** `feature/v9-soap-draft-editing` (backend), `feat/encounter-v9-design` (frontend)
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Added
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Regenerate merges new transcript into the doctor's current SOAP
  instead of starting over (`generate_soap_draft(current_draft=...)`, `soap-regenerate-v1.txt`).
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — v9-only opt-in: the AI may propose an Assessment and Plan when the
  doctor stated neither, marked `[AI proposed — not stated by the clinician]`, low confidence.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — v9-only opt-in: the AI may propose Labs, Procedures, Therapies,
  Vaccines and a complete Rx from the documented clinical picture, each marked as proposed.
  - **2026-09-29** update — removed. The orders flag, its two addendum prompts and its tests are
    gone. The AI now writes the full order specifics into the proposed Plan text instead.
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — v9-only opt-in on `extract_note_structured`
  (`allow_full_order_details`): reads full Rx dosing, therapies and vaccines from the SOAP, checked
  against the site's dosage and period masters (`note-extract-v2-full-order-details-addendum.txt`).
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 Ask AI tab is real: reads the Draft SOAP, adds to one section
  on a tap, keeps chat history, and shows Rx dose conflicts as system messages.
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 SOAP view: SOAP/Transcript sub-tabs, four editable boxes,
  Regenerate with Undo, and AI-proposed orders as single cards with their own "Add to Rx Pad".
  - **2026-09-29** update — the AI-proposed order cards are removed. The Draft SOAP is the single
    source.

#### Changed
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 "Copy to Rx Pad" now also reads the SOAP text with v3's Fill
  Encounter extraction, creates or selects masters, and fills Rx, labs, procedures, diagnoses and
  follow-up. AI-proposed cards are never swept in by the bulk button.
  - **2026-09-29** update — Copy to Rx Pad now reads the current SOAP (with the doctor's edits) and
    fills Rx with full dosing, labs, procedures, therapies, vaccines, diagnoses and follow-up.
- **2026-09-29** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — v9 Analyze is visible during live recording; recording keeps
  running in the background.

#### Fixed
- **2026-09-29** · `backend` · Sarvesh-SocialAngel (AI-assisted) — An attached lab's inline "Interpretation: ..." line no longer
  reaches the Objective section.

### 2026-09-29 · Multi-role users on the Patient 360 (frontend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Added
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A **Nursing Tasks** tab. The nurse's Nursing
  tasks card now has an "All →" that opens it, so a patient with eighty tasks has a full list to go
  to rather than only the six that fit on the card.

#### Fixed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The "All →" links on the Overview cards, and
  the front-desk tiles that jump to Appointments, Billing or Documents, now work every time. They
  changed the address bar rather than the chart, so whether anything happened depended on where you
  had last been — clicking the same one twice, or after moving tabs yourself, did nothing.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The Nursing Tasks tab shows the patient's
  nursing tasks. It was opening a different list entirely — personal to-do reminders — so it read
  "No tasks" for a patient the chart said had 80. It is now a plain list of every nursing task with
  its status, and nothing else: no filters and no Add, since tasks are created and advanced on the
  Nursing screen where the room and queue context exists.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Nursing tasks are labelled with the
  patient's name instead of their MRN: "Nina Martinez - Administer Vaccine", not
  "MRN-2026-0000001 - Administer Vaccine".
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A patient with a long list — 80 open nursing
  tasks, say — no longer stretches their card down the page and leaves the cards beside it floating
  in empty space. List cards now stop at about six rows and scroll, and each shows how many items it
  holds next to its title so nothing is hidden without saying so.

#### Removed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The green "Nursing task" / "Desk task" pill
  beside the patient's name is gone. It named the role you were already logged in as and said
  nothing about the patient; in the design it is a menu for switching which role's layout you open
  the chart in, and this app has no such switch.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The temperature no longer appears twice on a
  nurse's Overview. It was on the Temp at desk tile and repeated as a row inside the Today's visit
  card just below; the card now shows when the visit is and who it is with.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The row of coloured pills above the summary
  tiles is gone, along with the sentence describing the view. Once the tiles and cards started
  showing every role's information, the pills were repeating what was already on screen a few
  centimetres below — the temperature, the balance, how complete the record is.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — **Allergies are the exception and still
  appear**, for front desk and for administrators. Those are the two roles with no allergy list
  anywhere else on the chart, and reception seeing them is a deliberate safety decision — they are
  the people handing over samples and booking procedures.

#### Changed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The Overview cards are merged the same way
  as the tiles. Where two roles show overlapping cards — the front desk's Contact and the nurse's
  Safety & contact — they become one card carrying every field from both, with the repeated ones
  shown once. A nurse on the front desk keeps the patient's email and address as well as their
  blood group and weight.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Where two roles show the same thing two
  different ways — the front desk's list of what is missing from a record, and the administrator's
  completeness bar — you get the version built for the role you are mainly acting as, not both.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Someone who holds more than one role now
  sees every role's summary tiles in one band, scrolling sideways if they cannot all fit. A nurse who
  is also on the front desk gets the temperature AND the balance at a glance, instead of only the
  tiles belonging to whichever role the system ranked higher.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Where two roles report the same figure under
  different names — the balance, and how complete the record is — it is shown once, worded the way
  the role you are mainly acting as words it. The same amount will not appear twice under two
  labels.

#### Fixed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A nurse who is also on the front desk can
  reach Billing again. The chart decided which tabs to show from one role only — the
  highest-ranked — so anyone whose *other* role was the one that needed a tab simply lost it, while
  the header still offered them "Check out". Tabs are now shown when any role the person holds
  allows them.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A doctor who is also an administrator now
  opens a patient chart on the clinical view rather than the record-quality one. Being an
  administrator was treated as outranking being a clinician, which is right for most of the app and
  wrong for the chart: someone opening a patient's record is usually there to treat them.

---

### 2026-09-29 · The Record-vitals dialog (frontend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Changed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The Record-vitals dialog is rebuilt to the
  Narzim design: each measurement is its own card with the value set large and its unit beside it,
  and a reading outside the normal range tints the whole card amber as it is typed. Shown on the
  patient chart, the appointments list and mid-encounter — the same dialog in all three.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The dialog is now titled with the patient's
  name where the screen knows it, so a nurse recording vitals can see at a glance whose chart they
  are in.

#### Fixed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Abnormal readings are now flagged when
  recording vitals from the patient chart. The check needs the patient's age to know which range
  applies, and the chart had never given it one — so a dangerously high blood pressure typed there
  was never marked, while the same value typed during an encounter was.

---

### 2026-09-29 · The administrator's Patient 360 (frontend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md) · [admin redesign](docs/admin_redesign_patient360.md)

#### Added
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — An administrator opening a patient chart now
  sees a record-quality band above the tabs: how complete the record is, what the patient has been
  billed over their lifetime, what they still owe, and which messaging consents are on file.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The admin Overview leads with a Record
  integrity checklist, the consents on file, and the account totals.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — SMS and Email consents can now be read, not
  just WhatsApp. The backend has always answered for any channel; the frontend never asked for the
  other two.

#### Changed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The admin's chart tabs are reordered to the
  design's reading order, with this app's extra tabs following rather than being removed.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — An administrator now reads the same vitals
  table a nurse and a doctor do. The last encounter summary, the patient history box and the growth
  chart are no longer on their Overview; all remain on their own tabs.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The patient history box is back on the nurse
  and doctor Overview, with its inline edit. It had been removed as a side-effect of replacing the
  vitals table it shared a row with, which was never the intent.

#### Security
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Three things the design shows an
  administrator are deliberately not built, because nothing behind them can be substantiated: who
  has opened this chart (the access rows are recorded but no endpoint reads them), whether the
  record has duplicates, and consents this clinic does not operate. The band's description line was
  shortened to match what it shows.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Record completeness is counted from the same
  list the front desk fills in, so an administrator auditing record quality and a receptionist
  correcting it can never be shown two different numbers.

---

### 2026-09-29 · The practitioner's Patient 360 (frontend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-29](WORK_LOG.md)

#### Added
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A doctor opening a patient chart now sees a
  clinical band above the tabs: their allergies, any blood pressure above target, which labs are
  still pending, and their active problems, with the patient's two most relevant lab results and
  their latest blood pressure as tiles.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The doctor's Overview leads with Active
  problems and Current medications, so the two questions asked before every consultation are
  answered before any scrolling.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — Lab trends reach the browser for the first
  time. `get_lab_trends` has been in the backend since the labs module was built; nothing on the
  frontend ever called it, so no route, type or hook existed.

#### Changed
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The doctor's Overview is reordered to read
  top to bottom the way a consultation does: the clinical summary first, then clinical notes, then
  active problems and current medications, then the vitals trend. Last encounter summary and the
  patient history box are no longer on this tab — both are still on their own tabs, and every other
  role's Overview is unchanged.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A doctor now reads the same vitals table a
  nurse does, from the same component, so the two roles cannot come to disagree about which reading
  is abnormal.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The clinical summary card is now tinted
  teal, the design's marker for a card a model wrote. Its problem statement, suggested differential
  and "not a verified diagnosis" warning are unchanged.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The doctor's chart tabs are reordered to the
  design's reading order — problems and medications, then results, then messages, then documents —
  with this app's extra tabs following rather than being removed.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A long KPI label now shortens with an
  ellipsis instead of making every tile in the band taller. Analyte names are as long as the lab
  chose to make them; the design's own labels were all short enough never to need this.

#### Security
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — The design's "Care gaps" tile, its
  "Eye exam overdue" flag and its Care plan tab are deliberately not built: nothing in the backend
  models a care plan, a care bundle or a due date, and a number on that tile would be an invented
  clinical claim (PHI-5). The band's own description line was shortened to match what it shows.
- **2026-09-29** · `frontend` · Ashutosh (AI-assisted) — A patient with no allergies recorded is
  shown in grey as "No allergies recorded", not in green as the design's "No known allergies":
  nothing written down is not the same as asked and ruled out.

---

### 2026-09-28 · Billing screen restyle + Checkout tab (frontend)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend (+ backend ADR)
**Branch:** frontend `dev` (uncommitted)
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-098](docs/adr/adr-098-billing-screen-restyle-presentation-layer-only.md)

#### Added
- **2026-09-28** · `frontend` · Divyanshu (AI-assisted) — Billing has a **Checkout** tab: today's
  patients ready for checkout, what each owes, and a Collect payment action (front desk and admin
  only). Invoices remains the default view.
- **2026-09-28** · `frontend` · Divyanshu (AI-assisted) — Billing header shows Collected, Outstanding
  and Refunds for the invoices in view.
- **2026-09-28** · `frontend` · Divyanshu (AI-assisted) — Invoice list has one-click status filters
  (All/Paid/Unpaid/Overdue/Refunded) with counts, a count-and-billed summary, the posting date under
  each invoice number, and a Clear filters button when a filtered list comes back empty.

#### Changed
- **2026-09-28** · `frontend` · Divyanshu (AI-assisted) — Restyled to the Narzim design: status pills,
  invoice-editor line-item header, the discard-invoice dialog (Discard now reads as destructive), and
  the print dialog's primary button.
- **2026-09-28** · `frontend` · Divyanshu (AI-assisted) — The dashboard's Pay now logic moved into a
  shared component also used by the Checkout tab. No behaviour change.

### 2026-09-28 · Canvas rendering rebuilt: no more rendered-file field, canvas_data renders verbatim in a sandboxed frame

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-097](docs/adr/adr-097-encounter-canvas-html-only-no-rendered-file.md) (supersedes [ADR-095](docs/adr/adr-095-encounter-canvas-storage-format.md))

#### Fixed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — A styled drawing (strokes colored via a
  CSS class defined outside the `<svg>` element) rendered as a solid black shape in the encounter's
  Medical Record entry, because the prior fix's regex-based extraction discarded the `<style>`
  block that gave the drawing its intended stroke-only look.

#### Changed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `Encounter Canvas.image` (the rendered-PNG
  Attach field) is removed. `canvas_data` (raw HTML) is now the only stored artifact, and it
  renders verbatim — unparsed, unsliced — wherever a picture is needed, instead of a separately
  uploaded file. **BREAKING**: `save_canvas()` no longer accepts `image_base64`; `get_canvas()` /
  `list_canvases()` no longer return an `image` field. Migration:
  `patches/v0/drop_encounter_canvas_image_field_20260928.py`.

#### Security
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `canvas_data`'s fieldtype is
  unconditionally exempt from Frappe's save-time HTML sanitizer, so a `<script>` tag placed in it
  is never stripped. Rendering it now goes through a `sandbox=""` iframe specifically to disable
  script execution — verified with a new test that a planted `<script>` tag survives the save
  unstripped and that the sandbox attribute is present wherever `canvas_data` renders.

### 2026-09-28 · A canvas with no rendered image yet still shows a picture in the encounter's Medical Record entry

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-096](docs/adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md)

#### Added
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — A canvas whose `canvas_data` contains
  literal SVG markup, but has no rendered PNG yet (no frontend exists to produce one today), now
  renders that SVG directly as its thumbnail in the encounter's Medical Record entry, instead of
  falling all the way back to plain text.

### 2026-09-28 · Fix: canvas sketches could be silently corrupted on save

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-095](docs/adr/adr-095-encounter-canvas-storage-format.md)

#### Security
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `canvas_data` (a canvas's editable
  drawing data) could be silently corrupted on save: Frappe's own HTML sanitizer strips markup-
  like content from `Long Text` fields unconditionally, and would have done the same to real,
  correctly-encoded data the moment a canvas annotation contained a `<` or `>` (e.g. `"BP < 90"`).
  Fieldtype corrected to `Code`, which is exempt. Not just a display bug — this was silent data
  loss of a clinical drawing.

### 2026-09-28 · Fix: multiple canvases on one encounter ran together into one garbled string

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Fixed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — A second (or third) canvas on the same
  encounter with no image rendered as illegible, run-together text (`"ENCVS-2026-00002image"`) in
  the encounter's Medical Record entry — no separator existed between entries. Each canvas now
  renders on its own line.

### 2026-09-28 · Canvas thumbnail is now self-contained, not a link to the file

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-096](docs/adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md)

#### Changed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — The canvas thumbnail in the encounter's
  Medical Record entry now embeds the actual image bytes directly (a self-contained `data:` URI)
  instead of linking to the file — rendering it no longer depends on the file still existing at
  that path. `custom_canvas_summary` widened to `Long Text` to hold the embedded data.

### 2026-09-28 · Canvas Summary shows the actual sketch, not just its name

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-096](docs/adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md)

#### Added
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `Canvas Summary` in the encounter's
  Medical Record entry now shows an actual clickable thumbnail of each sketch, not just its name.

#### Security
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — Found and closed a real HTML-injection
  surface while verifying the above: nothing downstream escapes the Canvas/Advice summary text,
  so an unescaped practitioner-typed value (a title, an advice line) could have rendered as live
  markup in the Medical Record entry. Confirmed Frappe's own `Document` save layer already
  sanitizes this on every save, so no additional escaping was added on top of it — a first
  attempt to add one was itself a bug (double-encoding an already-sanitized value).

### 2026-09-28 · Canvas/Advice Summary fields grouped under their own section on Patient Encounter

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Changed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `Canvas Summary`/`Advice Summary` on the
  Patient Encounter Desk form now sit side by side under their own "Encounter Content" section,
  instead of stacked under unrelated fields. Cosmetic only.

### 2026-09-28 · Fix: Desk-created Canvas/Advice records never showed in the encounter's Medical Record

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Fixed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — A canvas or advice record created
  directly in Desk (the only way to use either feature before the frontend exists) never
  refreshed the encounter's Medical Record entry — the resync only ran from this app's own API,
  which a Desk save never goes through. Moved to `on_update`/`after_delete` hooks on both
  doctypes so every write path resyncs, not just one.

### 2026-09-28 · Encounter Advice, and Canvas/Advice now show inside the encounter's own Medical Record entry

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-096](docs/adr/adr-096-encounter-canvas-advice-surface-via-patient-history-fields.md) · [docs/ENCOUNTER_ADVICE.md](docs/ENCOUNTER_ADVICE.md)

#### Added
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — New `Encounter Advice` doctype
  (per-line `source: AI | Manual` + `accepted`) and `api/v1/encounter_advice/api.py`, backing
  patient-advice checklists/free text during a Guided Encounter.
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `Encounter Canvas` and `Encounter Advice`
  now surface inside the encounter's *existing* Patient Medical Record entry (verified live: the
  same row's `subject` gains "Canvas Summary"/"Advice Summary" sections, no duplicate row ever
  created) instead of creating separate timeline rows — two new `Patient Encounter` custom fields,
  a `Patient History Settings` registration, and a shared `encounter_summary_sync.py` helper.
  Both doctypes also now show as Connections on the `Patient` and `Patient Encounter` Desk forms.

#### Fixed
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — The new Connections crashed Desk's own
  "Connections" count sidebar (`Unknown column 'order_group' in 'WHERE'`) on any Patient or
  Patient Encounter — a shared default fieldname left behind by core Healthcare's own dashboard
  setup was silently wrong for both new doctypes. Fixed with explicit `non_standard_fieldnames`
  entries instead of relying on that default.

### 2026-09-28 · Encounter Canvas backend — sketch tool storage for the Guided Encounter view

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend
**Branch:** `feature/encounter-canvas`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md) · [ADR-095](docs/adr/adr-095-encounter-canvas-storage-format.md) · [docs/ENCOUNTER_CANVAS.md](docs/ENCOUNTER_CANVAS.md)

#### Added
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — New `Encounter Canvas` doctype and
  `api/v1/encounter_canvas/api.py` (`list_canvases`/`get_canvas`/`save_canvas`/`delete_canvas`),
  backing a sketch/diagram tool for the Guided Encounter view. One encounter can hold several
  canvases; each stores both editable stroke data and a rendered PNG derived from it (ADR-095).
  Frontend drawing surface not built yet — this is the storage layer only.

#### Security
- **2026-09-28** · `backend` · Divyanshu (AI-assisted) — `Encounter Canvas` is not built on
  `Clinical Document` (deleted 2026-09-09 for a real permission hole — see that date's entry
  below) or on Narzim Drive's separate permission model; every read/write is authorized against
  the specific `Patient Encounter` the canvas belongs to, and `EB_Practitioner` has no delete
  grant on the doctype itself.

### 2026-09-28 · Two fields the Patient 360 front-desk chart needs (backend)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Added
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The patient payload now returns `creation`,
  the date the record was first made. Nothing new is stored — Frappe sets it on every doctype — it
  simply was never serialised, which is why the chart header could not show "Patient since 2021"
  and the Patients list derived a year from the MRN string instead of reading one.
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — New endpoint `get_patient_insurance_coverage`
  returns what the insurer pays and what the patient pays. `Patient Insurance Policy` carries only
  the payor and the policy number; the percentages live on `Patient Insurance Coverage`, which an
  appointment links to but nothing read — so the coverage split never reached the browser. Unblocks
  the front-desk chart's Coverage, Est. co-pay, At checkout and Pre-auth rows.

#### Security
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The coverage endpoint returns the money split
  and deliberately NOT `code_value` / `item_eligibility` / `template_dt`: a receptionist collecting a
  co-pay needs the amount, not the coded clinical reason the insurer priced it that way (PHI-6,
  minimum necessary). It is permission-checked against `Patient Insurance Coverage` and writes a PHI
  read audit, the same as the policy endpoint beside it.

---


### 2026-09-26 · Real status changes for past medications (backend)

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-26](WORK_LOG.md)

#### Fixed
- **2026-09-26** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A prescribed medication's real,
  signed `Medication Request` and its live status (Active/On Hold/Stopped/…) were silently dropped
  by the encounter read API — the write side has linked them since submission was built, the read
  side never returned the link. Same class of bug as the 2026-08-20 dosing-frequency loss.

#### Added
- **2026-09-26** · `backend` · Sarvesh-SocialAngel (AI-assisted) — New endpoint to Continue/Hold/Stop
  a past encounter's medication for real, backed by its actual `Medication Request` document —
  permission-checked, and restricted to the three real actions (no raw status accepted from a
  client). No EB_ role could write to `Medication Request` at all before this; the docperm patch
  fix travels in the same commit as the endpoint that needs it.

#### Security
- **2026-09-26** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Granted `Medication Request`
  write access to EB_Practitioner/EB_Healthcare Admin/EB_Nurse (read-only for EB_Front Desk/
  EB_Patient), via the doc-driven `eb_docperm_spec.json` patch mechanism, matching `Patient
  Encounter`'s existing per-role shape — not an `ignore_permissions` bypass.

---

### 2026-09-26 · Export appears once you tick rows

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-26](WORK_LOG.md)

#### Changed
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **The Export button now appears once you
  select rows**, on all four lists, instead of always sitting in the toolbar. Once it is open the
  dialog still offers "everything matching the current filters", so a full export is a tick away.
  Import on the Patients list is unaffected — it has nothing to do with which rows are selected.

---

### 2026-09-26 · Fields and Export sit in the same place on all four lists

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-26](WORK_LOG.md)

#### Fixed
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **The Fields and Export buttons now sit
  to the right of the search box on every list.** On Encounters and Billing they had ended up on the
  left of it, so the toolbar read differently depending on which list you were on.

---

### 2026-09-26 · Encounters can be ticked, and Yes/No columns read as Yes/No

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-26](WORK_LOG.md)

#### Added
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **The encounters list now has row
  checkboxes**, like the other three. Ticked encounters can be exported on their own, and a selection
  survives paging so it can be gathered across pages.

#### Fixed
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **A yes/no column added through Fields
  now reads "Yes" instead of "1".** Fields like Invoiced or In print were showing the 1 and 0 they are
  stored as. False shows as empty, so the column reads as a list of the rows where the thing is true.

---

### 2026-09-26 · Every list has an Export button

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `fix/practitioner-department-required`, frontend `dev`
**Related:** [WORK_LOG 2026-09-26](WORK_LOG.md)

#### Added
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **Encounters can now be exported**, to
  Excel or CSV, with a choice of columns. It was the one list with no export at all.
- **2026-09-26** · `backend` · Anant Sharma (AI-assisted) — New `export_encounters` and
  `export_invoices`.

#### Changed
- **2026-09-26** · `frontend` · Anant Sharma (AI-assisted) — **Export is a plain button on every
  list now**, instead of being tucked inside a "Data" menu on two of them. On Patients, Import sits
  beside it as its own button. On Billing the button is always there rather than appearing only once
  rows are ticked.

#### Security
- **2026-09-26** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **The billing export now
  runs on the server and is recorded.** It used to be built in the browser: no limit on how much it
  would take, no permission check, and **nothing written to the Access Log**, so invoices could leave
  the system with no record that anyone had taken them. It also exported a stale set of rows after a
  filter change. All four exports now log who exported what, when, and under which filters — never
  the rows themselves.

---

### 2026-09-25 · List columns no longer squash when you add one

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-25](WORK_LOG.md)

#### Fixed
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — **Adding a column no longer squeezes the
  others.** Patient names, ages and phone numbers were being broken across three and four lines to
  make room; now every column keeps the width its content needs and the list scrolls sideways instead.
  Applies to all four lists.
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — A column you add is capped at a readable
  width and shows its full value on hover, so picking a long free-text field cannot stretch the table
  off the screen.

---

### 2026-09-25 · All four clinical lists now let you choose and order their columns

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `fix/practitioner-department-required`, frontend `dev`
**Related:** [ADR-094](docs/adr/adr-094-user-selectable-list-columns.md) · [WORK_LOG 2026-09-25](WORK_LOG.md)

#### Added
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — **The encounters list gets the same
  Fields button** as Patients, Appointments and Billing: add any encounter field as a column and drag
  the columns into the order you want. Patient and MRN stay first. That completes all four lists.
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — New `get_encounter_list_fields`, and
  `list_encounters` now accepts a `fields` list.

#### Security
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — As on the other three, the encounters
  column list only ever offers fields the signed-in user is allowed to read, and a column name the
  server does not recognise is ignored rather than queried.

---

### 2026-09-25 · The billing list gets the same column picker

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `fix/practitioner-department-required`, frontend `dev`
**Related:** [ADR-094](docs/adr/adr-094-user-selectable-list-columns.md) · [WORK_LOG 2026-09-25](WORK_LOG.md)

#### Added
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — **The billing list now has the same
  Fields button** as Patients and Appointments: add any invoice field as a column and drag the columns
  into the order you want. Patient and MRN stay first, Actions stays last.
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — New `get_invoice_list_fields`, and
  `list_all_invoices` now accepts a `fields` list.

#### Changed
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — **The invoice columns are sized a little
  differently.** They used to be locked to fixed proportions, which left no room for a column you add;
  they now size to their content like the other lists, and the table widens as you add columns.

#### Security
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — As on the other lists, the billing column
  list only ever offers fields the signed-in user is allowed to read, and a column name the server does
  not recognise is ignored rather than queried.

---

### 2026-09-25 · The appointments list gets the same column picker

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `fix/practitioner-department-required`, frontend `dev`
**Related:** [ADR-094](docs/adr/adr-094-user-selectable-list-columns.md) · [WORK_LOG 2026-09-25](WORK_LOG.md)

#### Added
- **2026-09-25** · `frontend` · Anant Sharma (AI-assisted) — **The appointments list now has the same
  Fields button as the Patients list**: add any Patient Appointment field as a column, and drag the
  columns into the order you want. Patient and MRN stay first, as they do on Patients.
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — New `get_appointment_list_fields`, and
  `list_appointments` now accepts a `fields` list.

#### Changed
- **2026-09-25** · `backend` + `frontend` · Anant Sharma (AI-assisted) — The picker is now **one**
  implementation serving both lists rather than two copies, so the two screens cannot drift apart.
  Nothing changes for anyone using the Patients list.
  - **2026-09-25** update — fixed the Patients toolbar button showing
    `patientsPage.fieldPicker.open` instead of "Fields" after that move.

#### Security
- **2026-09-25** · `backend` · Anant Sharma (AI-assisted) — As on Patients, the appointments column
  list only ever offers fields the signed-in user is allowed to read, and a column name the server
  does not recognise is ignored rather than queried.

---

### 2026-09-24 · Reorder the columns on the Patients list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [ADR-094](docs/adr/adr-094-user-selectable-list-columns.md) · [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Columns on the Patients list can now be
  dragged into whatever order you want**, built-in ones included — Patient Age, Gender, Mobile, Email,
  Last / Next visit and Primary practitioner. Patient and MRN stay first. Every row also has up and
  down buttons, so the order can be changed from the keyboard.

#### Changed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — The Fields dialog now has two sections:
  the current columns in order, and the list of fields to add. An existing column choice is carried
  over; nothing needs setting up again.

---

### 2026-09-24 · Choose which columns the Patients list shows

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `fix/practitioner-department-required`, frontend `dev`
**Related:** [ADR-094](docs/adr/adr-094-user-selectable-list-columns.md) · [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **A "Fields" button on the Patients list
  lets you add any Patient field as a column** — marital status, occupation, blood group and the rest —
  the way Frappe's own list view does. The choice is remembered in your browser.
  - **2026-09-24** update — the fields the list already shows (Patient, Patient Age, Gender, Mobile,
    Email) now appear ticked and marked "In list" instead of looking available, and can no longer be
    added a second time. The dialog was also rendering half its intended width, which made every
    label wrap; it is now correctly sized, scrolls within the window instead of running off the
    bottom, and has a search box.
  - **2026-09-24** update — adding a column now widens the table and lets the list scroll sideways,
    instead of squeezing the columns already on screen to make room.
  - **2026-09-24** update — fixed a second, permanently empty "Gender" column appearing beside the
    real one for anyone who had chosen Gender before it became a built-in column. A column choice that
    is no longer available — now built in, or removed from the doctype — is dropped instead of drawn
    empty, and no longer stops the Patients list loading at all.
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — New `get_patient_list_fields`, and
  `list_patients` now accepts a `fields` list.
  ([why](docs/adr/adr-094-user-selectable-list-columns.md))

#### Security
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — The column list only ever offers fields the
  signed-in user is allowed to read: anything restricted by `permlevel` is filtered out, and a column
  name the server does not recognise is refused rather than queried.

---

### 2026-09-24 · The four clinical lists now look like one product

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Changed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Patients, Appointments, Encounters and
  Billing now share one table design**: the same header, the same row striping, the same hover and the
  same row height. The Appointments list in particular had no striping at all and taller, tighter-packed
  rows, so it read as a different screen from the other three.

---

### 2026-09-24 · Wide list tables can be scrolled sideways again

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **The Patients, Appointments, Encounters
  and Billing lists now scroll sideways**, so columns that sat past the right-hand edge of a narrow
  window can be reached. They were clipped with no scrollbar and no way to get to them. Column
  headers still stay pinned while scrolling down.
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — A sideways swipe on a trackpad no longer
  navigates the browser back out of a list.

---

### 2026-09-24 · A note you are writing can no longer be lost by a stray click

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Closing the note editor with unsaved
  text now asks first**, offering Keep editing, Discard, or Save note. Clicking outside the editor —
  or pressing Escape — used to discard everything typed, with no warning and no way back.
  - **2026-09-24** update — the note editor also no longer overlaps its own text with the formatting
    toolbar when scrolled, and opens centred on screen.

---

### 2026-09-24 · Notes open in the middle of the screen

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Changed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Writing a note now opens a centred
  window instead of a narrow panel down the right-hand side**, with room to write. Everything it could
  do before, it still does.

---

### 2026-09-24 · Renaming a file keeps its file type

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Renaming a document can no longer
  change or delete its file type.** The extension now sits beside the name box as a fixed label
  instead of being part of the text you edit. Removing it used to stop the file previewing and hide it
  from type filters.

---

### 2026-09-24 · Filter Documents by file type

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **A Type filter on Documents** — folders,
  notes, PDFs, images, spreadsheets, Word documents, audio or other files. It works alongside the
  All / Private / Shared / Favourites / Trash tabs rather than replacing them, so you can ask for
  shared PDFs, or starred notes.

---

### 2026-09-24 · The New menu names what it creates

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Changed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — On Documents, the **New** menu now reads
  **Note · File · Folder** instead of "New Note / New Upload / New Folder" — the button already says
  New, and "File" names what you get rather than how it gets there.

---

### 2026-09-24 · Favourites in Narzim Drive

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **A Favourites tab on Documents, beside
  Shared.** Star a file or a folder from the star beside its three-dot menu, or from the menu itself,
  and it is listed there no matter which folder it lives in. Opening a starred folder takes you to it.
  - **2026-09-24** update — folders can now be starred from the folder card and its menu, in both grid
    and list views; previously only files could be.
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — Favourites are **per person**: yours are
  not visible to colleagues, and starring a document shared with you grants nobody anything.

#### Security
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — A document can only be starred if the
  person may already open it, and the Favourites list re-checks access on every entry — so a document
  that stops being shared with you stops appearing, even though your star remains.

---

### 2026-09-24 · Deleted documents preview again, and show the right document

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — **Documents in Trash show their preview
  again, and can be opened and downloaded.** Deleting a document moves its file aside for safe
  keeping, and the screen was still looking for it in its old place.

#### Security
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — **A deleted document could display a
  different document's contents under its own name**, when a document with the same name still
  existed in the same folder. It now always resolves to its own file.

---

### 2026-09-24 · A document that cannot be previewed looks the same whatever its type

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **An image that cannot be loaded now
  shows the same placeholder every other file type shows**, instead of the browser's broken-image
  symbol with the stored filename beside it. Visible on Trash, where several documents no longer have
  their file.
  - **2026-09-24** update — "no longer have their file" was wrong. The files were always intact; a
    deleted document's file is moved aside and the screen was looking in the old place. Fixed below.

---

### 2026-09-24 · Notes show their text on the Documents grid

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — **A note now shows its opening lines on
  the Documents grid.** Every note looked like a blank page, so a written note and an empty one were
  indistinguishable without opening each in turn.

#### Security
- **2026-09-24** · `backend` · Anant Sharma (AI-assisted) — The note excerpt is cut short on the
  server, so a list of notes no longer needs to send their full contents to the browser to show a few
  words of each. Excerpts are read only for notes the viewer may already open.

---

### 2026-09-24 · PDF previews return to the Documents grid

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md)

#### Fixed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **PDFs on the Documents screen show
  their first page again.** Every PDF was showing a grey tile with a broken-document icon, which read
  as a failed upload and prompted people to upload the same file repeatedly; the files themselves
  were always intact. Previews now fill the tile the way image previews do.

#### Security
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — The fix keeps clickjacking protection on
  every Drive file route rather than relaxing it, and keeps file downloads on the audited endpoint, so
  access to a patient document is still recorded.

---

### 2026-09-24 · Patient import hidden until it can take a real file

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-24](WORK_LOG.md) · [ADR-080](docs/adr/adr-080-patient-import-session-and-llm-column-mapping.md)

#### Changed
- **2026-09-24** · `frontend` · Anant Sharma (AI-assisted) — **Import patients** is hidden from the
  patient list for now. It only accepted a file using our own template, so a list handed to reception
  by the clinic — with its own Spanish column headings — was rejected outright. The step that reads
  any heading is built and tested but not yet on screen. Exporting is unaffected.

---

### 2026-09-23 · Groundwork for importing a 1000-row patient list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-23](WORK_LOG.md) · [ADR-080](docs/adr/adr-080-patient-import-session-and-llm-column-mapping.md)

#### Added
- **2026-09-23** · `backend` · Anant Sharma (AI-assisted) — A bulk import now survives being
  interrupted. Its progress — the uploaded rows, the column choices, and every skip-or-create
  decision — is stored, so closing the tab or losing the session no longer means starting the file
  again. Finished imports are deleted after seven days.
- **2026-09-23** · `backend` · Anant Sharma (AI-assisted) — Front desk can now import patients. It
  was the only staff role that could not, despite being the role handed the list.

#### Fixed
- **2026-09-23** · `backend` · Anant Sharma (AI-assisted) — **Permission changes made for the import
  and export features were being undone on every deployment.** They had been applied directly instead
  of through the app's role-permission specification, which is reconciled on each migration. Front
  desk would silently have lost the ability to export patients and appointments. Now recorded in the
  specification and verified to survive a migration.

---

### 2026-09-22 · Patient list gains bulk export and bulk import

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/practitioner-department-required`
**Related:** [WORK_LOG 2026-09-22](WORK_LOG.md) · [design + flows](docs/export-import/PATIENT_IMPORT_EXPORT.md)

#### Added
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — The patient list has a **Data** menu next
  to Register patient, holding Export and Import.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Patients can be **exported** to Excel or
  CSV. The file contains the patients matching the filters currently on screen, or the whole
  directory, and the confirm button states which and how many before anything downloads.
  ([how it works](docs/export-import/PATIENT_IMPORT_EXPORT.md))
  - **2026-09-22** update — patients can now also be **ticked individually**. Every row has a
    checkbox, the header checkbox selects the current page, ticks are kept while paging through the
    directory, and a bar above the list shows how many are selected. Export then offers a third
    choice: the selected patients, the current filters, or everyone.
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — The patient list has row checkboxes on
  both the desktop table and the mobile card list, so a tablet at the front desk can select patients
  the same way.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Patients can also be imported from a
  **Google Sheets link**, not only an uploaded file — the same three steps and the same row-by-row
  review. ([how it works](docs/export-import/PATIENT_IMPORT_EXPORT.md))

- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — The **appointments** list now has row
  checkboxes and a **Data** menu, and appointments can be exported to Excel or CSV — either the ones
  ticked, or everything in the current view. There is no appointment import: an appointment is a
  commitment to a slot, and creating them from a file would bypass the conflict, capacity and
  availability checks booking enforces.
  ([how it works](docs/export-import/APPOINTMENT_EXPORT.md))
  - **2026-09-22** update — selection on the appointments list now matches the patients list exactly:
    a checkbox on every row on desktop **and on every card on mobile**, and the "N selected" strip
    sits under the header on both screens. The first pass added checkboxes only to the desktop table,
    so a front-desk tablet — which renders the card list — had no way to select anything.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Appointment exports offer four column
  sets — schedule, clinical, billing and everything — and are recorded in Frappe's Access Log like
  every other export.

#### Fixed
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — **PDF documents show a real preview
  again in Narzim Drive.** Every PDF card showed a grey "cannot display" box while images previewed
  normally. The file proxy was discarding the range headers Chrome's PDF viewer depends on and
  relabelling partial responses as whole ones, so the viewer received a reply whose stated length did
  not match its contents. ([mechanism](docs/narzim-drive/NARZIM_DRIVE.md))
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — Document thumbnails are no longer
  re-downloaded on every render. The proxy was passing through a "never store this" instruction meant
  for API replies, so simply scrolling the Documents screen refetched roughly 400 KB per PDF card each
  time. Files are now reusable by that browser for five minutes and still kept out of any shared cache.
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — **Trash now shows the same previews as
  the Documents grid.** Deleted items all rendered as an identical file icon, so a deleted lab report
  and a deleted note looked the same — at the one moment the only decision is whether to restore.

- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — **Dates in an imported file are no longer
  guessed.** The import now asks how the file writes dates (DD/MM/YYYY, MM/DD/YYYY or YYYY-MM-DD) and
  parses only that way. Previously the date was inferred per value, so in a clinic writing
  day-first every date whose day was 12 or lower was read as month-first and stored silently wrong —
  `06/07/2002` became 7 June instead of 6 July. A date of birth sets the age that drives dosing and
  the immunization schedule. Two-digit years and dates of birth in the future are now refused.
  ([why](docs/export-import/PATIENT_IMPORT_EXPORT.md))
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Import no longer rejects a row because a
  value was typed in lower case. `male`, `M`, `Masculino`, `o+` and similar are understood and stored
  in the system's own spelling; a genuinely unknown value is still refused and lists what is accepted.
  - **2026-09-22** update — extended to every column with a fixed list, after a Spanish spreadsheet
    was rejected on all 10 of its rows. `Soltero`/`Casada`/`Viudo`, `Activo`/`Inactivo` and
    `Padre`/`Madre`/`Tía`/`Esposo` are now understood, with or without accents. `Cónyuge` and `Hija`
    are deliberately **not** guessed — the first does not say Husband or Wife, and there is no
    Daughter relation — so each says exactly what to write instead.
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — The import review shows each date as it
  will actually be saved, so a wrong format choice is visible before anything is written.

- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — The import review no longer flags a row as
  a possible duplicate just because it shares one word of a name with an existing patient. Sharing a
  surname is now a quiet note; a matching national ID, or a matching name and date of birth, is still
  raised for attention. On a ten-row Spanish sheet this went from six warnings to one — the one that
  was real.
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — A possible-duplicate line now names the
  patient it matched (it previously read "Possible duplicate of —" with the record missing) and says
  what matched in plain words — "part of the name", "date of birth" — instead of an internal field
  name.

#### Security
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — **MIGRATION**
  `patches.v0.grant_appointment_export_perm_20260922` gives Front Desk permission to export
  appointments; it was the only staff role that could not export the screen it works on all day.
  Appointment exports honour the same practitioner visibility rule as the list itself, so a doctor
  restricted to their own schedule exports only that.
- **2026-09-22** · `frontend` · Anant Sharma (AI-assisted) — The Google Sheets field states, beside
  the input, that a sheet can only be read while it is shared with "anyone with the link", that this
  makes the patient details in it readable by anyone holding that link, and that sharing should be
  turned off again afterwards — or the sheet downloaded and uploaded instead.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — The sheet URL is pinned to
  `https://docs.google.com/spreadsheets/` before the server fetches anything, so the field cannot be
  used to make the server request an arbitrary address.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Patients can be **imported** from a
  spreadsheet in three steps: download a template, upload the filled file, review every row, then
  confirm. Nothing is written until the final button; the review lists missing required values,
  invalid entries with the values that are accepted, and probable duplicates — both against existing
  patients and between two rows of the same file.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — The import template is generated from the
  registration API itself and carries a second sheet listing the values each column accepts, so the
  format cannot drift from what the system will take.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — An exported file can be edited and
  imported back: the export's "Import template" column set is the importer's own column contract.

#### Security
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Every patient export is recorded in
  Frappe's **Access Log** — who, when, how many rows, which columns and which filters, and never any
  patient data. Patient exports now appear in the same log as every other export in the system.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Who may bulk export or import is governed
  by Frappe's native Patient export/import permissions, changeable in the Role Permissions Manager.
  **MIGRATION** `patches.v0.grant_patient_import_export_perms_20260922` grants import to
  EB_Healthcare Admin and export to EB_Front Desk; before it nobody held import at all. Nurses hold
  neither.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Exported spreadsheet cells that begin
  `=`, `+`, `-` or `@` are neutralised, so patient-entered text cannot execute as a formula when a
  clinic administrator opens the file.
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — Re-submitting an import cannot create the
  patients twice; a repeated confirmation returns the first result instead of writing again.

#### Changed
- **2026-09-22** · `backend` · Anant Sharma (AI-assisted) — The patient list's filter resolution moved
  into one shared function, so the export covers exactly the set the list would show rather than a
  second implementation of the same filters.

---
### 2026-09-25 · A patient message reaches 12 people instead of 38

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend
**Branches:** `feat/noti-func-backend` · `feat/noti-enhancement-frontend`
**Related:** [WORK_LOG — 2026-09-25](WORK_LOG.md) ·
[`notifications_patient_coordinator.md`](docs/planning/notifications_patient_coordinator.md)

#### Added
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — A **Patient Coordinator** role. It is
  additive — a nurse, doctor or receptionist can hold it alongside their own role — and whoever holds
  it receives every inbound patient message and hands each one to the clinician who should answer.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — A **⋯ menu** on patient-message notifications
  with **Assign to…**, opening a searchable staff picker. Assigning notifies that one person.
- **2026-09-25** · `backend` + `frontend` · Ashutosh (AI-assisted) — Portal conversations can now be
  assigned at all. WhatsApp has had this for months; the portal had the field and no way to set it.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — An **Unassigned** filter on Patient Messages,
  so the overnight backlog is visible rather than merely waiting.

#### Changed
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — **A patient message no longer notifies every
  clinician.** It went to all 38 holders of five roles, carrying the patient's name and what they
  wrote; it now goes to the triage desk, and a clinician is told when a conversation is assigned to
  them by name. **Nothing was hidden** — every conversation is still readable by every staff member.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — The **Assign** button appears in the patient
  chart, and the assign dialog is a searchable picker rather than a free-text box where a typo routed
  a patient's conversation to the wrong clinician.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — `/messages` is called **Patient Messages**
  (it showed "WhatsApp Messages" while listing portal chats) and is back in the sidebar. It had no
  nav entry at all, so the only way in was clicking a notification.
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — An assignment notification opens the patient's
  **chart**, not the shared inbox, so the clinician does not have to find the conversation again.

#### Security
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — Fewer people see each patient's words. 14
  practitioners and 15 nurses stopped receiving messages about patients they are not treating
  ("minimum necessary", CLAUDE.md §9.9 PHI-6).

### 2026-09-25 · A developer can see every prompt, reply and tool call of an AI request

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend · **Branch:** working tree (uncommitted)
**Related:** [WORK_LOG 2026-09-25](WORK_LOG.md) · [`docs/grafana/LANGFUSE_LOCAL_TRACING.md`](docs/grafana/LANGFUSE_LOCAL_TRACING.md)

#### Added
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — Dev-only Langfuse tracing (`integrations/langfuse_trace.py`): one trace per AI request with full provider input/output, usage and every curated tool call's arguments and result. Off unless `site_config.json` has `developer_mode`, `langfuse_enabled` and keys; `langfuse` is not a declared dependency.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `docs/grafana/LANGFUSE_LOCAL_TRACING.md`: gate, span map, runbook, and the rules that keep it off production.

### 2026-09-25 · The repository explains itself to an agent without 17k tokens of preamble

**Author(s):** Satyakam (AI-assisted) · **Repos:** backend · **Branch:** `docs/agentic-dev-restructure`
**Related:** [WORK_LOG 2026-09-25](WORK_LOG.md) · [`CLAUDE.md`](CLAUDE.md) 4.0 · [`docs/api/ENDPOINT_INDEX.md`](docs/api/ENDPOINT_INDEX.md)

#### Changed
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `CLAUDE.md` is rules only (BE-1…BE-10, PHI-1…PHI-8 with citable IDs) and 282 lines instead of 1,102. The repo map, roadmap, current-state and frontend sections moved to their owners; a crosswalk maps v3.x section citations.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `WORK_LOG.md` and `CHANGELOG.md` hold only the current month; August is frozen under `docs/worklog/` and `docs/changelog/`.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `docs/README.md` is a task router, not a catalogue.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — 68 session transcripts and 47 per-screen audits moved under `docs/_archive/` with every link repointed; the runtime prompts stay in `prompts/`.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `docs/api/API_SPEC.md` §16 marked superseded by the generated index.

#### Added
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `scripts/gen_endpoint_index.py` generates `docs/api/ENDPOINT_INDEX.md` and one table per module from the AST (method, file:line, params, response shape, gates); `--check` gates it.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — Code-cited module briefs at `api/v1/{encounters,patients,ai}/CLAUDE.md`, auto-loaded only when working in that folder.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `.claude/` slash commands `/status`, `/module`, `/worklog`, `/gates`, and a hook that refuses whole-file reads over 100 KB.
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — `.github/workflows/docs-gates.yml` runs the six documentation gates on every PR.

#### Fixed
- **2026-09-25** · `backend` · Satyakam (AI-assisted) — Twelve duplicated provenance lines in `WORK_LOG.md` and two duplicated `[Unreleased]` headings in `CHANGELOG.md`, left by merges; the header gate now rejects a second provenance line. Six files that had failed the header gate on `dev` backfilled.

### 2026-09-24 · Notification settings actually do something now

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend + patient portal
**Branches:** `feat/noti-func-backend` · `feat/noti-enhancement-frontend` · `feat/enhance-pp-noti`
**Related:** [WORK_LOG — 2026-09-24](WORK_LOG.md) ·
[`docs/planning/Configurable_Notifications.md`](docs/planning/Configurable_Notifications.md)

#### Added
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — **Appointment reminders, no-show alerts and
  lab-result notifications now send.** The three dropdowns in Settings → Notifications had saved
  faithfully and been read by nothing; there was no scheduler at all. A job runs every five minutes
  and raises them through the existing `notify()` chokepoint, so the bell, the live update and push
  all work without a second delivery path.
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — A no-show tells **both** the front desk and
  the patient, in different words and at different times: staff at the chosen delay, the patient
  15 minutes later so someone merely parking the car is not accused of missing their appointment.
- **2026-09-24** · `frontend` · Ashutosh (AI-assisted) — **View details** on an appointment
  notification opens the appointment in a side sheet, with the patient's age, date of birth, sex,
  blood group, email and phone. It used to navigate to the Appointments list filtered to one row.
- **2026-09-24** · `frontend` · Ashutosh (AI-assisted) — **Reschedule** opens the reschedule drawer
  in place instead of routing through the Appointments list to get there.

#### Changed
- **2026-09-24** · `portal` + `frontend` · Ashutosh (AI-assisted) — Appointment messages are written
  to a patient rather than at them — "See you soon 👋", "We missed you today" — and dates read
  **DD-MM-YYYY** everywhere, in both apps. Long messages wrap instead of being cut off mid-sentence.
- **2026-09-24** · `frontend` · Ashutosh (AI-assisted) — **Payment reminders** removed from Settings →
  Notifications. It was never implemented and is not being built: it is a billing concern, and "At
  checkout" is not a reminder. The stored field is left in place.

#### Fixed
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — Choosing most values in Settings →
  Notifications **failed to save**. The dropdowns and the stored field had never agreed on their
  options — per field they overlapped on one or two — so anything else was rejected. Existing values
  are migrated.
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — Two unread notifications about the same
  appointment no longer overwrite each other. "Confirmed" and "cancelled" were treated as the same
  row because the de-duplication key ignored which event it was.
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — A to-do's notification no longer shows raw
  HTML in the bell. Existing ones are repaired.
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — Six notification types could never have sent
  a push, because they were missing from the routing table. All 21 are now routed.

#### Security
- **2026-09-24** · `backend` · Ashutosh (AI-assisted) — To-dos created before today are back-filled
  with who assigned them. Frappe grants read access on "you were allocated it **or** you assigned
  it", so a practitioner who assigned a task could lose sight of it without a blanket-access role.
  49 of 53 rows were affected.

### 2026-09-23 · NOM-024-SSA3-2012 cited across living documents

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [COMPLIANCE_MULTI_JURISDICTION.md §4.2](docs/security/COMPLIANCE_MULTI_JURISDICTION.md)

#### Fixed
- **2026-09-23** · `backend` · Nishant — Every living document now cites the Mexican healthcare
  standard as NOM-024-SSA3-2012, the revision in force, instead of the superseded 2010 one: the
  constitution's locked Jurisdiction row and role description, the HIPAA readiness gap analysis,
  both architecture overviews, planning, known issues, push notifications, lab-report extraction,
  and four reports, plus three code comments in the Drive guard and Drive service.
  ([compliance plan](docs/security/COMPLIANCE_MULTI_JURISDICTION.md))
- **2026-09-23** · `backend` · Nishant — The constitution's ADR-018 amendment keeps what ADR-018
  decided and adds a dated correction, and its ADR-007 line stays as history. ADRs, records and
  drafts are unchanged, as their rules require.

---

### 2026-09-23 · Compliance plan and ADR-007: stale facts corrected

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [COMPLIANCE_MULTI_JURISDICTION.md](docs/security/COMPLIANCE_MULTI_JURISDICTION.md) · [ADR-007](docs/adr/adr-007-jurisdiction-mexico.md)

#### Fixed
- **2026-09-23** · `backend` · Nishant — The compliance plan no longer says the scheduler is
  commented out. It is active (a 15-minute sweep, a weekly PHI access review, a daily consent
  job), but no retention purge is registered, so retention is still unimplemented. Stage 2.1 is
  marked done, with the purge in 2.2 as the remaining half.
  ([compliance plan](docs/security/COMPLIANCE_MULTI_JURISDICTION.md))
- **2026-09-23** · `backend` · Nishant — The compliance plan's Mexico heading names
  NOM-024-SSA3-2012, matching the revision its body already verified.
- **2026-09-23** · `backend` · Nishant — ADR-007 now records that ADR-018 superseded it, which
  ADR-018 already declared, and points to NOM-024-SSA3-2012. Its decision text is unchanged: a
  merged ADR is superseded, never edited. ([ADR-007](docs/adr/adr-007-jurisdiction-mexico.md))

---

### 2026-09-23 · Platform V2: architecture documents describe only the target

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [01-system-map.md](docs/platform/01-system-map.md) · [06-transition-runbook.md Gates](docs/platform/06-transition-runbook.md#gates)

#### Changed
- **2026-09-23** · `backend` · Nishant — The platform documents 01 to 05 now describe only the
  target, by the test "still true the day after Frappe is retired". The BFF leaves both flow
  diagrams, the authorization layers and the deployment view: web reaches the core with a
  core-issued session cookie, the frontend is static SPAs, and the core runs three services.
  ([system map](docs/platform/01-system-map.md#where-authorization-happens))
  - **2026-09-23** update — The folder README follows the same rule: its shape diagram shows three
    services and a static SPA, it counts twelve invariants, and BFF and ownership map are glossed
    as transition-only terms. ([README](docs/platform/README.md))
- **2026-09-23** · `backend` · Nishant — Transition content moved to the runbook: the Gates table,
  the rules for identity while Frappe and the core coexist, the route-move rule behind the
  ownership map, and the build-time PostHog detail. What stays behind is the destination rule,
  such as stable internal identifiers. ([runbook](docs/platform/06-transition-runbook.md#gates))
- **2026-09-23** · `backend` · Nishant — Present-state passages in 02, 03 and 04 ("the state
  today", the unwired materiality gate, the rolling summary, the prefix-matching allergy check)
  become target statements that point to the runbook phase fixing them. This also removes the
  stale claim that the scheduler is disabled.
  ([invariants](docs/platform/02-invariants.md#where-the-gaps-are-tracked))

---

### 2026-09-23 · Platform V2: the transition runbook, made visual and completed

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [06-transition-runbook.md](docs/platform/06-transition-runbook.md)

#### Changed
- **2026-09-23** · `backend` · Nishant — The transition runbook is restructured for engineers to
  follow at a glance: one journey diagram, the same card for every phase (a diagram, entry, exit
  and undo, then one-line steps tagged IaC, release or data), reasoning folded into collapsible
  blocks, and a grid of all 42 components against the 14 phases. 28 diagrams in all.
  ([runbook](docs/platform/06-transition-runbook.md))

#### Added
- **2026-09-23** · `backend` · Nishant — The target state with nothing left of Frappe, and a table
  of what replaces each Frappe capability: doctypes, ERPNext, identity, permissions, RQ, the
  scheduler, SocketIO, files and Drive, email, WhatsApp, Desk, fixtures and patches, audit logs.
  ([Phase 13](docs/platform/06-transition-runbook.md#phase-13--retire-frappe))
- **2026-09-23** · `backend` · Nishant — What moves from Frappe Cloud and Vercel and how: code
  rebuilt from GitHub pinned to Frappe Cloud's commits, configuration copied (including the bench
  environment), data by backup and restore, and the RDS settings Frappe needs.
  ([Part I](docs/platform/06-transition-runbook.md#9-part-i--relocate))
- **2026-09-23** · `backend` · Nishant — An observability track from foundation to retirement,
  and a CI/CD track: infrastructure and application pipelines, digest promotion, canary cell with
  a soak, and a deploy freeze or dual deploy from the first rehearsal to the last cutover, since
  Frappe Cloud and Vercel auto-deploy from GitHub today.
  ([observability](docs/platform/06-transition-runbook.md#12-observability-through-the-phases),
  [CI/CD](docs/platform/06-transition-runbook.md#delivery-pipelines-cicd))

---

### 2026-09-23 · Platform V2: files, EFS now and S3 later

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [06-transition-runbook.md Phase 2](docs/platform/06-transition-runbook.md#phase-2--build-the-legacy-stack-in-each-cell) · [Phase 11](docs/platform/06-transition-runbook.md#phase-11--capability-migration)

#### Changed
- **2026-09-23** · `backend` · Nishant — The transition runbook explains why files stay on EFS
  during the move (a shared filesystem Frappe already expects, where S3 would change behaviour
  mid-move) and adds a lifecycle policy moving idle files to EFS Infrequent Access.
  ([Phase 2](docs/platform/06-transition-runbook.md#phase-2--build-the-legacy-stack-in-each-cell))
- **2026-09-23** · `backend` · Nishant — The later move to S3 is specified from the code: writes
  already go through Frappe's `write_file` hook, one direct disk read in lab extraction changes
  first, existing files are copied and every stored `file_url` rewritten, private files move to
  signed URLs, and Drive is pointed at S3.
  ([Phase 11](docs/platform/06-transition-runbook.md#phase-11--capability-migration))

---

### 2026-09-23 · Platform V2: the transition runbook

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [06-transition-runbook.md](docs/platform/06-transition-runbook.md)

#### Added
- **2026-09-23** · `backend` · Nishant — A transition runbook from Frappe Cloud to the target
  architecture: three parts (relocate, harden, migrate) in thirteen phases, each with entry
  conditions, steps and exit evidence. It includes the architecture at each state, the route of
  all 42 components, the Terraform modules each phase adds or removes, and API versioning from
  contract fixtures to `/api/v1/`. ([runbook](docs/platform/06-transition-runbook.md))
- **2026-09-23** · `backend` · Nishant — The relocation covers what a code audit found missing:
  site naming inside the cell, the patient portal, the four Frappe apps outside `required_apps`,
  the nginx frontend, the scheduler flag carried in the backup, queue draining, CloudFront and WAF
  limits, admin access and the full site-config inventory, with 18 verification checks.
  ([Part I](docs/platform/06-transition-runbook.md#9-part-i--relocate))

#### Changed
- **2026-09-23** · `backend` · Nishant — Identity now leaves Frappe first, with `/api/auth/*` the
  first domain NestJS serves, and NestJS becomes the API facade after the move rather than at G4.
  The SPA follows the last `/api/*` path moving, uses Vite, React and TanStack Router, and has a
  bundle-size budget in CI. ([system map](docs/platform/01-system-map.md#sequencing))
- **2026-09-23** · `backend` · Nishant — The shared account is in `us-west-2`, out of `us-east-1`,
  and Terraform state is one bucket per region so one region's outage cannot block another cell.
  ([deployment](docs/platform/05-deployment.md#infrastructure-and-delivery))

#### Security
- **2026-09-23** · `backend` · Nishant — The runbook schedules, with evidence, the AI tool-dispatch
  check that lets a caller without encounter write permission trigger write tools, and makes it
  the first item of the hardening phase.
  ([Phase 6](docs/platform/06-transition-runbook.md#phase-6--harden-the-relocated-stack))

---

### 2026-09-23 · Platform V2: browser telemetry and per-cell providers

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [05-deployment.md The browser](docs/platform/05-deployment.md#the-browser-errors-replay-and-product-events) · [External providers per cell](docs/platform/05-deployment.md#external-providers-per-cell)

#### Added
- **2026-09-23** · `backend` · Nishant — Frontend errors, performance, session replay and product
  events go to CloudWatch RUM in each cell, replacing PostHog. Funnels are Logs Insights or Athena
  queries over those events. ([deployment](docs/platform/05-deployment.md#the-browser-errors-replay-and-product-events))
- **2026-09-23** · `backend` · Nishant — Four rules for using a different external vendor per cell,
  and a vendor residency check: no SaaS vendor hosts in Mexico, so LogRocket self-hosted is named
  as the upgrade path. ([deployment](docs/platform/05-deployment.md#external-providers-per-cell))

#### Security
- **2026-09-23** · `backend` · Nishant — Session replay is masked by enforcement, not by setting:
  RUM masks every text node and input and cannot be overridden. Before it is enabled, clinical
  screens are audited for patient data in attributes, each site gets its own app monitor so
  viewing a replay is tenant-scoped, and the browser sends RUM data through the BFF so no AWS
  credential reaches it. ([deployment](docs/platform/05-deployment.md#the-browser-errors-replay-and-product-events))

---

### 2026-09-23 · Platform V2: telemetry stays in the cell

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [05-deployment.md Where it runs](docs/platform/05-deployment.md#where-it-runs) · [02-invariants.md §08](docs/platform/02-invariants.md#08--observability)

#### Security
- **2026-09-23** · `backend` · Nishant — Telemetry egress is decided: traces and logs, which
  resolve to patients, never leave their cell (X-Ray and CloudWatch in the cell's region).
  Metrics carry only allowlisted labels, with no tenant, patient or encounter, and one shared
  Grafana reads them in place through a role that cannot read logs or traces. The OpenTelemetry
  collector in each cell enforces the allowlists and strips exemplars.
  ([deployment](docs/platform/05-deployment.md#where-it-runs))
- **2026-09-23** · `backend` · Nishant — Trace and log retention is set per cell from its
  compliance profile and never exceeds that profile's shortest erasure deadline, so expiry
  completes erasure. Disputes are answered from the command ledger, provenance and access audit,
  not from traces. The trace backend row of the PHI inventory is now answered.
  ([inventory](docs/platform/02-invariants.md#the-phi-inventory))

---

### 2026-09-23 · Platform V2: Terraform and the delivery pipeline

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [05-deployment.md Infrastructure and delivery](docs/platform/05-deployment.md#infrastructure-and-delivery)

#### Added
- **2026-09-23** · `backend` · Nishant — The platform deployment doc now names Terraform as the
  infrastructure tool and defines how it is delivered: an AWS account per prod cell, one cell
  module with a Terraform root per cell, S3 state with no PHI, plan and apply roles assumed by
  GitHub Actions through OIDC with no stored keys, canary-first applies with approval, and nightly
  drift detection. Application deploys promote one image per commit through the cells and never
  run Terraform. ([deployment](docs/platform/05-deployment.md#infrastructure-and-delivery))

#### Security
- **2026-09-23** · `backend` · Nishant — Non-prod is declared PHI-free: rehearsals that need a real
  backup run in the prod cell's own account. The Frappe scheduler deploys with the old task stopped
  before the new one starts, so retention and purge jobs never run twice during a release.
  ([deployment](docs/platform/05-deployment.md#infrastructure-and-delivery))

---

### 2026-09-23 · Platform V2: API contract invariant and the post-transition frontend

**Author(s):** Nishant · **Repos:** backend · **Branch:** `docs/platform-v2-architecture`
**Related:** [02-invariants.md §12](docs/platform/02-invariants.md#12--contract) · [01-system-map.md Sequencing](docs/platform/01-system-map.md#sequencing)

#### Added
- **2026-09-23** · `backend` · Nishant — Platform invariant 12, Contract: one OpenAPI
  contract generated from the core's schemas, `/api/v1/` path versioning with a CI gate on breaking
  changes, a support window per consumer (web, mobile, partners), and patch-with-expected-version
  rules for clinical writes. ([invariant](docs/platform/02-invariants.md#12--contract))

#### Changed
- **2026-09-23** · `backend` · Nishant — The platform deployment doc now treats the Next.js BFF as
  a transition service. After Frappe is retired (G4), the destination is a Vite + React SPA served
  from S3, with the BFF's session and response-shaping role moved into the NestJS core: three
  services instead of four. ([sequencing](docs/platform/01-system-map.md#sequencing))

---

### 2026-09-24 · Review screen for report prompts in the lab upload (ADR-092 part 3, switched off)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-092](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `frontend` · Divyanshu (AI-assisted) — When report review is switched on, the lab
  upload shows a stepper (Upload → Review → Extracting → Results), lets the user pick the test before
  uploading, and shows a review step: each report's prompt and template, editable, with "save for
  future reports of this test", before anything is extracted.
- **2026-09-24** · `frontend` · Divyanshu (AI-assisted) — The uploader's note can now be written on the
  first screen of the AI upload, where it was previously unreachable.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — The lab AI availability check reports whether
  report review is switched on.
- **2026-09-24** · `backend + frontend` · Divyanshu (AI-assisted) — On the review screen, a clinician can
  ask the AI to change a prompt and template in plain words ("also capture the method"); the change
  appears for checking, with Undo. Only the prompt text is sent, never the report, and nothing is
  saved unless the clinician chooses "Save & extract". ([ADR-092 §3.2.1](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md))
  - **2026-09-24** update — the test picker is multi-select, lists the Lab Test Templates, and sits
    under the practitioner; the review step shows only the prompt and a preview of the output layout,
    and says it is preparing — not extracting — while the prompts are drafted.
  - **2026-09-24** update — "Select Test" now uses the same compact control as the practitioner
    selector. Fixed: the lab upload drawer could not scroll, so on a tall first screen the upload
    option was cut off and a file could not be chosen.
  - **2026-09-24** update — the review's Cancel, Extract without saving and Save & extract buttons sit
    in the bottom bar beside Back; Save & extract saves all the prompts in the review, replacing the
    per-test checkbox.
  - **2026-09-24** update — picking a test on the review screen loads that test's saved prompt; the
    AI's guess of an image's study is labelled "unconfirmed" instead of shown as the heading.
  - **2026-09-24** update — the review now shows only a preview of each test's output; changes are
    asked of the AI in one input fixed at the bottom (the same input as Narzim GPT). The prompt text,
    summary guidance, manual template editing, the note box and Cancel upload were removed from it.
  - **2026-09-24** update — each test keeps a "Rebuild preview" action; the unused cancel-upload
    action was deleted from backend and frontend.
  - **2026-09-24** update — with no test picked, the AI now first looks through the saved prompts and
    uses one that fits (marked "suggested" when judged from a picture), and drafts one when none
    fits — so every report, images included, gets a preview.
  - **2026-09-24** update — lab uploads can run on their own background worker (queue `lab_upload`),
    so a slow summary job no longer makes an upload wait. **MIGRATION:** declare the queue in
    `common_site_config.json` and run a worker for it (ADR-092 §3.2.5); without it uploads use the
    shared queue as before.

#### Fixed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — A lab upload whose background job never ran no
  longer shows "processing" forever: it is marked failed with a message to upload again.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — A study the clinician states for an image the
  AI could not identify is now passed to the extraction; it was being dropped.

---

### 2026-09-24 · Lab uploads can stop for prompt review before extraction (ADR-092 part 2a, switched off)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-092](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — New AI Settings switch "Review report
  prompts before extraction" (off). When on, an upload identifies each report and its tests, proposes
  the approved prompt for each test or drafts one, and waits for a clinician to approve before
  extracting. The user may pick the test first or just upload. Off until the review screen exists.
  **MIGRATION:** `bench migrate`.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Approve, rebuild-template and cancel
  actions for a review; an unreviewed upload is cancelled after 7 days.

#### Changed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Lab uploads now run ahead of background
  summary jobs, so an upload no longer waits behind them.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — When the AI re-reads a file it skipped, it
  now uses the uploader's note too.

#### Fixed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Editing or deleting a Lab Test Template now
  refreshes the AI's clinical vocabulary; a duplicate setting had silently switched that off.

---

### 2026-09-24 · Report prompts can be stored per test (ADR-092 part 1)

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-092](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Added
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — New record type "AI Report Prompt": the
  stored instructions for reading one kind of report, linked to the tests it serves, with its
  approved template, who approved it, and how it was drafted. An approved version can no longer be
  edited or deleted; a change becomes a new version. Not used by the upload flow yet.
  **MIGRATION:** `bench migrate` (new doctypes and a new Lab Test field).
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Lab Test has a new read-only field, "AI
  Report Prompt", for the prompt version a result was extracted with. Empty until part 2.

#### Changed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Each lab upload now records which version of
  the template-selection prompt it ran, and a hash of its text.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — The Anthropic adapter now records cached and
  cache-write tokens as the OpenAI adapter does. Costs are unchanged today, since no caching is used.

---

### 2026-09-24 · AI lab review requires submit permission to finalise a result

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Security
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Finalising a detected panel or a new section
  on the AI lab review screen now requires permission to submit Lab Tests, the same as submitting a
  result by hand. Before, permission to edit was enough. The check runs before anything is created.

---

### 2026-09-24 · Test files and superseded prompt versions removed; report-prompt design proposed

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-092](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md) · [Known issues](docs/KNOWN_ISSUES.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Removed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Removed, at the owner's request, the prompt
  files `multi_panel_extraction_v16`–`v20` (superseded by `v21`, the only version in use) and six lab
  test files (`test_body_site_gate`, `test_call_cost_estimate`, `test_image_findings_graded`,
  `test_image_only_no_template`, `test_image_review_systematic`, `test_report_reasoning_tokens`); two
  edited test files were restored to their committed state. Earlier entries below that name them are
  left as written.

#### Security
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — The image-reading safety rules (body-site
  gate, Clear/Possible grading, no organ from a template) now have no automated test. Real uploads
  logged as prompt `v19` and `v20` can no longer be matched to their prompt text from the repo.

#### Added
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Proposed design for storing report prompts,
  linking them to Lab Test Templates, and reviewing the template before extraction. Not built.
  ([ADR-092](docs/adr/adr-092-report-prompts-reviewed-before-extraction.md))
  - **2026-09-24** update — revised to approach B: the clinician-approved template itself is stored,
    linked to the Lab Test Template and reused unchanged; the prompt that drafted it is recorded as
    its origin. Still not built.
  - **2026-09-24** update — added: unit conversion where the AI proposes a missing conversion rule, a
    clinician approves it once and code converts; a stepper upload flow; small fixes in the same
    build. Still not built.
  - **2026-09-24** update — ADR-092 accepted, with expiry, roles, Stage 1 model and storage decided;
    Anthropic usage fields added to the build. Implementation not started.
  - **2026-09-24** update — ADR-092 v3.0 restated to the owner's requirement: a report prompt is stored
    per test in a new `AI Report Prompt` doctype, the template is generated from it (once per prompt
    version), a prompt is created when none exists, the user can pick a test first or upload directly,
    add a note, and approves prompt and template on the same screen. Not built.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Recorded five verified lab-flow issues in
  [`docs/KNOWN_ISSUES.md`](docs/KNOWN_ISSUES.md) (submit permission on the AI path, Draft reuse, unused
  aliases, unreachable uploader note, duplicate `hooks.py` key). None fixed.
  - **2026-09-24** update — the Draft reuse entry was withdrawn: reusing an open Draft Lab Test is
    intended (it is the pending order the report fills), so four issues remain.

---

### 2026-09-24 · Images read systematically by a stronger model, and short plain-language summaries

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-091](docs/adr/adr-091-images-reviewed-systematically-by-a-stronger-model.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Changed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Uploads that contain an image (X-ray,
  ultrasound, scan, tracing, photo) are now read by a separate, stronger model — new AI Settings
  field "OpenAI Image Model", default `gpt-5.5`. Text reports stay on the normal model.
  **MIGRATION:** patch `v0.set_openai_image_model_20260924`.
  ([why](docs/adr/adr-091-images-reviewed-systematically-by-a-stronger-model.md))
  - **2026-09-24** update — each provider now has its own image model, shown only when that
    provider is selected: "OpenAI Image Model" (default `gpt-5.5`) and "Anthropic Image Model"
    (blank = use Anthropic Model, until a Claude model is measured on images).
  - **2026-09-24** update — prompt `multi_panel_extraction_v21`: the findings list carries findings
    only, an uncertain exact location is marked indeterminate rather than guessed, and nothing
    the view cannot show (a direction, a depth) is stated. OpenAI Image Model set back to
    `gpt-5.5` after it had been changed to `gpt-5` in the settings form.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — The AI now checks every part of an image
  in turn and lists each finding separately instead of stopping at the first; images are sent at
  full resolution. Prompts `multi_panel_extraction_v19` and `v20`.
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Report summaries are shorter (at most 5
  lines, or 3-5 sentences with lab values) and in simple words, and carry every image finding at
  its Clear/Possible grading. Prompts `report_narrative_summary_v3`, `lab_report_summary_v5`.

#### Security
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — The previous image model wrote "no
  fracture seen" on an X-ray with three displaced fractures in 3 of 4 runs; the new one found them
  in 4 of 4. Tested on two images only — AI image findings still must not be relied on to find or
  exclude an abnormality. ([evidence](docs/adr/adr-091-images-reviewed-systematically-by-a-stronger-model.md))

---

### 2026-09-24 · AI image observations name what is clearly visible and grade every finding

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-090](docs/adr/adr-090-image-observations-graded-not-restricted.md) · [WORK_LOG — 2026-09-24](WORK_LOG.md)

#### Changed
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — AI image observations now name the
  anatomy when it is clearly recognisable, actively look for abnormalities, and mark every
  finding "Clear:" or "Possible:". A finding the AI did not grade is shown as "Possible:".
  Prompt: `multi_panel_extraction_v18`. ([why](docs/adr/adr-090-image-observations-graded-not-restricted.md))

#### Security
- **2026-09-24** · `backend` · Divyanshu (AI-assisted) — Measured: the AI still misses a
  displaced hand fracture in most runs, and can write "no fracture identified". AI image
  observations must not be relied on to find or exclude an abnormality.
  ([evidence](docs/adr/adr-090-image-observations-graded-not-restricted.md))

---

### 2026-09-23 · AI costs priced for the model that ran, and a rate-limit message that reaches the clinician

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [WORK_LOG — 2026-09-23](WORK_LOG.md)

#### Fixed
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — AI cost estimates for lab extraction,
  lab and report summaries, imaging extraction and patient clinical summaries are now priced for
  the model that ran the call. They were priced at Claude Sonnet rates regardless, overstating
  every OpenAI call about tenfold. Rows written before this date are unchanged.
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A lab-report upload's log row now counts
  every AI call the upload made — template selection, extraction and any per-file retry — with
  the number of calls in `round_trips`. Only the extraction call was counted before.
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — When the AI service is rate-limited or
  times out, the lab chat now says so ("The AI service is rate-limited right now…") instead of
  the generic "Could not get an answer."
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — Six lab tests that had been failing
  since the behaviour they tested was deliberately changed now test the current behaviour.

---

### 2026-09-23 · A body site is recorded only when printed words name it

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-089](docs/adr/adr-089-body-site-needs-printed-evidence.md) · [WORK_LOG — 2026-09-23](WORK_LOG.md)

#### Security
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A report's body site is now kept only
  when words printed on the document name it. A site the AI read from a picture alone is shown
  as an unconfirmed suggestion and the site is recorded as "not identified", so the review
  screen and the report summary no longer state an organ nobody identified.
  ([why](docs/adr/adr-089-body-site-needs-printed-evidence.md))

#### Changed
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — AI image descriptions no longer name an
  organ that is not printed on the image. A description that still does is marked as
  unconfirmed. Prompt: `multi_panel_extraction_v17`.
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — The lab review API now also returns how
  each report's site was identified and, when it was not printed, the AI's unconfirmed
  suggestion (`identified_from`, `suggested_body_site`, `suggestion_evidence`,
  `names_unconfirmed_site`). Additive; existing fields are unchanged.

#### Fixed
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — AI Prompt Log now records the model's
  hidden reasoning tokens and cached tokens for lab extraction and report summaries; they
  always read 0 before.

---

### 2026-09-23 · An ultrasound is described from what it shows, not from the template it was matched to

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-088](docs/adr/adr-088-images-read-from-what-they-show.md) · [WORK_LOG — 2026-09-23](WORK_LOG.md)

#### Fixed
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — An uploaded scan or photo with no
  report text is no longer matched to a report template by how it looks. An unlabelled
  ultrasound had been matched to the clinic's renal ultrasound template and then described as a
  kidney, with "cortical thinning", when nothing in the image identified the organ. It is now
  described from what is visible, and the organ is reported as "not identified" when the image
  does not show it. ([why](docs/adr/adr-088-images-read-from-what-they-show.md))
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — AI image observations no longer use
  words that judge tissue ("thinning", "debris", "mass") unless the report itself prints them.

#### Changed
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A report-type template is now a
  suggestion the document overrides, not an instruction that wins over the reading rules.
  Reports with printed text still get their template.
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A new template is never written from an
  unlabelled image. Prompts: `report_template_select_v2`, `multi_panel_extraction_v16`.

---

### 2026-09-22 · Reports are read with a template for their own kind, and the library writes itself

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feature/lab-two-stage-extraction`
**Related:** [ADR-080](docs/adr/adr-080-report-type-templates-for-lab-extraction.md) · [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Added
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — An uploaded report is now read using a
  template written for its own kind of study — a paediatric blood count, an ENT audiometry, an
  orthopaedic MRI, a nephrology panel — instead of the single generic instruction set that was
  used for every report from every specialty.
  ([why](docs/adr/adr-080-report-type-templates-for-lab-extraction.md))
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — When a kind of report arrives that the
  clinic has no template for, one is written and saved automatically, so every later report of
  that kind is recognised without anyone writing anything. The physician reviewing that
  extraction is told on screen that a template was created.
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — Whoever uploads a report can attach a
  short note, such as "ENT referral, right ear only". It helps the assistant recognise what the
  document is; it can never change a value read off the report.

#### Removed
- **2026-09-23** · `backend` + `frontend` · Divyanshu (AI-assisted) — The report summary now shows
  what the assistant saw in the report's images by default, whenever the report contains any,
  rather than only when the written summary happened to mention them.

- **2026-09-23** · `backend` + `frontend` · Divyanshu (AI-assisted) — What the assistant sees in a
  report's images now appears in the report itself, under its own heading, as well as in the
  summary. Each image gets its own sub-heading and a short list of what stands out, with a line
  stating plainly that it is a description of what is visible and not a diagnosis.
  ([why](docs/adr/adr-085-image-observations-on-every-document.md))
- **2026-09-23** · `frontend` · Divyanshu (AI-assisted) — Fixed the image-observation panel, which
  had been showing nothing at all since the observations moved to document level.

- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A transcribed report no longer carries
  the parts of the page that are not the report: the letterhead repeated on every page, the page
  numbers, and the label printed down the margin one letter per line. Verified that every
  threshold, both tables and all six recommendations survived the change.

- **2026-09-23** · `frontend` · Divyanshu (AI-assisted) — Fixed a crash on reports that measure
  both sides of the body, and two silent faults behind it: dragging one eye's measurement to
  another section moved the other eye's as well, and removing one removed both. A row is now
  identified by its measurement AND its side.

- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A report now keeps its own shape. A
  five-page audiology report was arriving as one wall of text — every page header repeated, a
  printed sidebar spelled out one letter per line, and the hearing-threshold table flattened into
  prose. Its sections and its results table are preserved now.
  ([why](docs/adr/adr-087-keep-the-models-structured-transcription.md))

- **2026-09-23** · `backend` + `frontend` · Divyanshu (AI-assisted) — A device measurement report
  is no longer treated as a blood test with missing information. An eye-biometry printout was
  reporting "no tests detected" and "45 results could not be checked because no reference range
  was given" — but a measurement like axial length has no normal range and never did, so nothing
  was missing. Its values are now shown as measurements.
  ([why](docs/adr/adr-086-measurement-reports-are-not-lab-panels.md))
- **2026-09-23** · `backend` · Divyanshu (AI-assisted) — A device's own precision figure (such as
  "SD 3 µm") is recorded as precision instead of being filed as a reference range. It describes how
  steady the instrument was, not what a healthy value looks like.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Pictures inside a report are now looked
  at even when the report is mostly tables. An eye-biometry printout carries scans, corneal maps
  and photographs beside its measurements; none of them were being read, so the assistant could
  only guess how many images a report held by counting blocks of numbers.
  ([why](docs/adr/adr-085-image-observations-on-every-document.md))
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Asking a question about a report now gets
  an answer that takes the pictures into account. "How many images are in this report?" is answered
  from the images themselves, and a coloured line drawn on a scan can be explained from the
  report's own annotation instead of "I cannot determine that from these data".
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — Measurements from a report covering both
  sides of the body are grouped and labelled by side, so two rows both reading "AL" can be told
  apart at a glance.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Warnings printed on a report by the
  machine that produced it are now captured and put at the top of the summary. An eye-biometry
  upload was summarised as "no results flagged as abnormal" while the device itself was saying the
  left-eye measurement was inconsistent and should be re-checked, and that some values had been
  typed in by hand. ([why](docs/adr/adr-084-report-printed-warnings.md))

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — A report that measures both sides of the
  body — both eyes, both ears, both kidneys — no longer loses one of them. An eye-biometry upload
  was reading 36 measurements and showing 18: every left-eye value was being discarded as a
  duplicate of the right, because the two are printed with the same name, in the same section, in
  the same unit. ([why](docs/adr/adr-083-per-parameter-side.md))
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Which side a measurement belongs to is
  worked out by the assistant from the report's own notation, in any language and any specialty,
  rather than from a fixed list in our code. The list it replaced knew the abbreviation for "both
  eyes" but not the one for "both ears".

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — The report summary now uses what the
  assistant saw in the image. An ultrasound whose record already held a full description of a
  septated kidney lesion was still being summarised as "if images were acquired, they are not
  described here" — the description existed and was simply never passed to the summary. It is
  passed now, carrying a label saying it was observed from the image and not stated by the report.

- **2026-09-22** · `backend` + `frontend` · Divyanshu (AI-assisted) — A report that is a picture
  rather than a page of text — an ultrasound still, an X-ray, a clinical photograph — is now
  described instead of coming back blank. An uploaded renal ultrasound previously reached the
  review screen reading "No tests detected" and "Nothing left to resolve", which looked exactly
  like a report that had been read and contained nothing.
  ([why](docs/adr/adr-082-ai-image-observations.md))
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — What the assistant sees in an image is
  shown in its own panel, headed "Observed by AI from the image" and carrying the line "A
  description of what is visible, not a diagnosis." It is never mixed into the text of what the
  report itself says, so a clinician can always tell the two apart.
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — The duplicate-upload warning no longer
  says only "same lab and date". It fires for an identical file too, and now says so.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Which part of the body a report covers,
  and which side, are now recorded as their own fields rather than buried in a paragraph. The same
  two fields carry left-versus-right for an eye, an ear, a limb, a kidney or a lung, so a side that
  could not be determined is now visibly blank instead of quietly missing.
  ([why](docs/adr/adr-081-report-subject-and-template-driven-summaries.md))
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — Each kind of report can now say what its
  own summary must always mention, instead of every report on the system being summarised by one
  identical set of instructions. An eye scan's summary now states which eye, its scan quality and
  what the report does not contain.
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — A summary is now told the facts already
  established from the page — such as which side was examined — rather than working them out again
  from text that does not contain the marks they came from. An eye scan of the left eye was being
  summarised as covering both eyes.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — A report summary no longer says "no
  imaging findings" when the report does contain images. That phrasing could be read as "the study
  was not done"; it now states separately what the report holds and what it lacks — for example
  "images are present, but no written interpretation or quantitative measurements are provided".

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — A report whose meaning is carried by the
  page rather than by its text is now shown to the assistant **as a picture**. On an eye scan the
  header prints an empty circle beside the eye that was not scanned and a filled one beside the eye
  that was; neither circle exists in the file's hidden text, so the eye was read correctly only
  about two times in three. Measured after the change: three times in three.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — An imaging report whose page is mostly a
  picture is now actually looked at. A Carl Zeiss OCT scan was being stored as the 514 characters
  of field labels printed beside the image, so its summary truthfully said the images "are not
  provided here". The text beside an image is no longer mistaken for the report.

- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — The local OCR double-check was removed
  from lab extraction. It never read values out of a report — it only proved a file had already
  been read so a second AI call could be skipped — so what is extracted is unchanged, and
  re-checking a file now always costs a call.

---

### 2026-09-22 · Prescribing now checks against the patient's own recorded allergies

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend ·
**Branch:** `feat/check-prescription-allergies`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md) · [prompt archive](docs/_archive/prompts/2026-09-22-check-prescription-allergies.md)

#### Added
- **2026-09-22** · `backend` · Sarvesh-SocialAngel (AI-assisted) — New whitelisted method
  `check_prescription_allergies(encounter, drugs)` compares each drug on an encounter against
  `Patient.allergies` (the same field Patient 360's allergy list reads) and returns any matches by
  name, generic name, or medication class. String-matching only — no cross-reactivity claim.
  Frontend (`Healthcare_next_app`) already calls this; no frontend change needed.

---
### 2026-09-22 · To-Do detail panel stops flattening what you wrote

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md) · [`docs/flows/TODO.md`](docs/flows/TODO.md)

#### Fixed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — Opening a to-do in the side panel and saving
  no longer strips its formatting. The panel flattened the description to plain text on load and wrote
  that back on save, so changing the priority silently destroyed the bold, italics and lists in the
  description. The panel now keeps and edits rich text, like the full-page view always has.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The Reference picker lists patients as soon
  as it opens. It previously read "No patients found" before anything had been searched for — a
  statement about the clinic that had never been checked. Same fix covers the Appointment and
  Encounter tabs, which both start from choosing a patient.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The to-do side panel's subtitle says **To-Do**
  rather than "Task", matching the create drawer.

#### Changed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The "Related to" field is now labelled
  **Reference**, the same word the Desk form uses.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The description editor in the side panel is
  no longer 420px tall. A one-line to-do pushed Priority, Due date and Assignee below the fold.

### 2026-09-22 · A to-do now records who assigned it

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `Fix/enhance-my-work-back`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Fixed
- **2026-09-22** · `backend` · Ashutosh (AI-assisted) — A to-do created from the app now records
  **Assigned By**. It was left blank, and Frappe grants read access on "you were allocated it **or**
  you assigned it" — so a practitioner who assigned a task to a nurse could lose sight of it if they
  no longer held a role with blanket ToDo access. The assignment comment in the audit trail was also
  being written without a name.

### 2026-09-22 · A to-do can be linked to a patient, appointment or encounter

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Added
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — A **Related to** field on the To-Do form,
  linking the to-do to a Patient, an Appointment or an Encounter. Pick the patient first, then the
  record — an appointment id is not something anyone can search for. The backend has always accepted
  this; no frontend ever sent it, so the only linked to-dos were the ones backend flows created.

#### Notes
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The Desk form's **Color** field is
  deliberately not offered. Nothing in Frappe renders it — not the list view, not the calendar — so
  the picker would write a value no screen ever shows. **Status**, **Role** and **Assigned By** are
  likewise absent because the create endpoint does not take them: a new to-do is always Open, and
  the creator is the assigner.

### 2026-09-22 · To-Do descriptions can be formatted

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Added
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The To-Do description box has a formatting
  toolbar — bold, italic, underline, strikethrough, numbered / bulleted / checklist, link, and clear
  formatting. The field always stored rich text and the to-do detail view already displayed it that
  way; only the create form could not produce it.

### 2026-09-22 · The Create drawer calls a To-Do a To-Do

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Changed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The Create drawer on My Work says **To-Do**
  where it said "Task": the title, the kind tab and the submit button. What it creates is a `ToDo`,
  which the row badge has always called "To-Do", while Frappe has a separate `Task` doctype that this
  form does not touch. The drawer's subtitle also said "Task" on the Nursing Task tab; it now names
  whichever record is being created.

### 2026-09-22 · Period filter no longer hides open encounters

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Fixed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — Choosing a period on My Work emptied the
  Encounters tab, even with an encounter dated today. An open encounter has no due date — it has an
  encounter date — and the filter only looked at the due date. It now matches on the row's own date,
  falling back to the encounter date, so "Today" finds today's encounter.

### 2026-09-22 · My Work gets the Reports period selector

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Added
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — My Work has the same period selector the
  Reports screens use — **All dates · Today · This Week · This Month · This Quarter · This Year**,
  with the calendar picker beside it for a custom range. A period covers the whole calendar span, so
  "This Week" includes a task due on Friday; the periods resolve to the same days the Reports
  backend uses, verified against `resolve_report_window()` for nine cases including the Sunday and
  leap-year edges. **All dates** stays the default, because a list opening on This Month would hide
  work that went overdue in August.

### 2026-09-22 · The STATUS filter lists only statuses that exist

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Fixed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The STATUS filter on My Work offers only the
  statuses the rows on that tab actually have: **Open / Done** for To-Do, the nursing workflow states
  for Nursing, **Open / Completed / Cancelled** for Encounters. It previously also offered "Overdue"
  and "Today", which are facts about the due date rather than statuses and are already covered by the
  DUE DATE filter next to it, and listed them on tabs whose doctype cannot produce them.

### 2026-09-22 · My Work gets a row of its height back

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Changed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — "New Task" moved to the page header beside
  Register Patient and is now called **Create**, since the drawer it opens offers both a personal
  task and a nursing task. The To-Do / Nursing / Encounters tabs move up into the freed row, so the
  screen has one toolbar row instead of two and the table starts higher.

### 2026-09-22 · My Work is one list; status is a filter, not a tab

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Changed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — My Work shows every task in one list. The
  **Unread** and **Completed** tabs split rows on exactly what the STATUS column already prints on
  each row, so the screen carried two controls for one idea and the tab quietly overrode the filter.
  Unfinished work sorts to the top, so the list still opens on what is outstanding.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The STATUS filter always offers All / Open /
  Overdue / Due today / Done, with the nursing workflow states listed beneath when nursing rows are
  present. It previously replaced that whole set with the nursing states whenever a nursing task was
  on the page, which left no way at all to ask for finished work.

#### Removed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The Unread / Completed tab bar. "New Task"
  and bulk-complete are no longer hidden while looking at finished work.

### 2026-09-22 · My Work separates its three kinds of row, and each one tells the truth

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Added
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — My Work splits into **To-Do**, **Nursing**
  and **Encounters** sub-tabs under both Unread and Completed, each with its own count. The three
  kinds of row were interleaved in one list, and because a ToDo has only Open and Closed as statuses
  there was nothing on screen to tell them apart.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — A date filter on My Work: a single day or a
  date range, filtering on the due date. Only the presets Today / This week / Overdue existed, so
  "what was due last Tuesday" could not be asked. Uses the same control as Patients, Appointments,
  Encounters, Billing and Reports.

#### Fixed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — A task you assign to yourself now shows your
  name in the USER column instead of a dash.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The STATUS column showed a due date
  ("Today") where a status belonged; it now shows Open or Closed.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — Nursing rows are filtered by the statuses
  nursing tasks actually have (Requested, Accepted, In Progress, Completed and the rest, only those
  present on screen), not by the generic Open / Overdue / Due today set that never matched them.
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — An unfinished encounter is labelled
  **Encounter**, not "Clinical Note". It is a `Patient Encounter` left open, never a clinical note,
  and the badge sent anyone looking for a note to the wrong screen.

#### Removed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The PRIORITY column is hidden under the
  Nursing sub-tab. `Nursing Task` has no priority field at all, so the column was permanently empty.

### 2026-09-22 · Clinical notes live in one place; the personal notes panel leaves My Work

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend · **Branch:** `Fix/enhance-my-work-task`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Changed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The patient Tasks popup lists tasks only.
  Clinical notes were also shown there, which since they gained their own card on the Summary tab
  and a row on the Activity feed meant the same note appeared in three places — and a full note
  rendered as a sticky card crowded the tasks out of view. Notes are still created from that
  popup's Create button; it simply no longer lists them back.

#### Removed
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — The personal notes panel ("My Notes" /
  "Shared") no longer occupies the right third of My Work; the task table now spans the full width.
  **Nothing was deleted:** this is the Clinical Documents feature, which is separate from patient
  Clinical Notes despite the similar name. Every note written there is still stored and still
  reachable from the Documents screen — only this one surface is gone.

### 2026-09-22 · `bench migrate` unblocked — the `drive` app was on the wrong branch

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend (bench environment) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md) · [docs/narzim-drive/DRIVE_MIGRATION_PLAN.md](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md)

#### Fixed
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — `bench migrate` was failing on a missing
  `Drive File` table. This bench's `apps/drive` was checked out on `develop`, not the `main` branch
  already documented as the pin in `DRIVE_MIGRATION_PLAN.md` — re-pointed to `main@0bd11d8` to match,
  which brought in `Drive File` and 8 other doctypes the Narzim Drive feature depends on. No new
  doctype schema was invented; this was an environment drift against an already-recorded decision.
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — `repair_drive_home_folders_20260917`, which
  had been silently failing (and then silently skipped), now actually runs: it repaired all 6 Drive
  Teams on this site that had no home folder.

### 2026-09-22 · The waived money is now called what it is, and its filter is visible

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend · **Branch:** `fix/financial-reports-gaps`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md)

#### Changed
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — The Waived card on Payment Methods is now
  named after the scheme the money was written off under — **Government (Waived)** — so it no longer
  reads as unrelated to the Government card beside it, which reports the same invoices from the
  other side. The scheme name is read from the data, so renaming the scheme renames the card.

#### Fixed
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — **Opening Billing from a waived card now
  shows a filter you can see and remove.** The list was correctly narrowed to the invoices the card
  counted, but nothing on screen said so and nothing could undo it — changing any other filter left
  the list stuck on those invoices, with the only way back being to edit the address bar.
  - **2026-09-22** update — the list was **not** correctly narrowed, as the line above claimed.
    Reported from the live screen: the drill-down showed Cash invoices and unpaid ones. The filter
    was being discarded in the app's own API route before it ever reached the server, so a card
    reading 12 invoices opened all 81 in the window. Fixed, and the parameters are now declared in
    the type that describes that request so the next one cannot go missing the same way.
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — The Government (Waived) card no longer
  shows a percentage. It read 22.5% beside a Government card reading 23.2% **for the same money** —
  both correct, measured against different totals, and together they read as a fault. The share of
  written-off work is still on the page, in the Billing Outcome chart, where the three outcomes add
  up to 100% and the basis is stated.
- **2026-09-22** · `frontend` · Divyanshu (AI-assisted) — A doctor who only sees their own figures
  no longer opens the **whole clinic's** written-off invoices when they click a waived card. Every
  other card on the page already carried the doctor across; this one did not.

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/financial-reports-gaps`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md) · [GAPS](docs/reports/GAPS.md) G-63

#### Fixed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — **When a patient is refunded, the money now
  comes off the doctor whose appointment it was.** Refunds were never deducted from anyone, and the
  page said they could not be traced — they always could. Where one bill covered several doctors,
  each doctor's share of the refund matches their share of that bill.
  ([gap](docs/reports/GAPS.md))
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Revenue by Provider now shows a **Net**
  column — what each doctor earned after refunds — and says how much of the refunded money was
  traced and how much was not, instead of claiming none of it could be.

#### Security
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — A doctor's earnings were overstated on the
  report used to compare doctors: Sarvesh Sandhu read 13,252 MXN against a true net of 11,252, 15%
  high. Recorded here because the figure is compensation-adjacent.

---

### 2026-09-21 · The financial set stays at two reports — a decision, recorded

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend + backend (docs) · **Branch:** `fix/financial-reports-gaps`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md) · [HIDDEN_REPORTS](docs/reports/HIDDEN_REPORTS.md) §2 · [GAPS](docs/reports/GAPS.md) G-29

#### Changed
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Outstanding Balances was added to the
  Reports page earlier today and has been **taken back off it** at the product owner's direction.
  The Reports page lists the two financial reports it listed before: Revenue by Provider and
  Financial Report. Nothing was deleted — the page, its endpoint and its translations all remain.
  ([why](docs/reports/HIDDEN_REPORTS.md))
  - **2026-09-21** update — the three documents that recommended un-hiding it now record the
    decision instead, so the change is not simply re-applied by whoever reads them next.

---

### 2026-09-21 · The receivables list stops hiding rows

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/financial-reports-gaps`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md) · [GAPS](docs/reports/GAPS.md) G-27

#### Fixed
- **2026-09-21** · `backend` + `frontend` · Divyanshu (AI-assisted) — Outstanding Balances now lets
  you page through every unpaid invoice. It previously showed the 50 largest and there was no way to
  reach the rest, so on a busy month the smaller debts were never chased.
  ([gap](docs/reports/GAPS.md))
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — The Claims Status approval chart no longer
  says "Monthly" when it is showing weeks, and its dates read as "7 Sep – 13 Sep" rather than
  "2026-09-07".

---

### 2026-09-21 · The AI clinical summary reads like a chart review, not a database dump

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `fix/clinical-sum-backend`
**Related:** [WORK_LOG 2026-09-21](WORK_LOG.md) · ADR-029

#### Added
- **2026-09-22** · `frontend` · Ashutosh (AI-assisted) — Clinical notes are visible in the patient
  chart. A "New note" button and the patient's notes now sit at the top of the Summary tab, above
  the AI clinical summary, and each note also appears on the Activity timeline with its own filter
  chip. Long notes show one line with a "Read more" control. Notes could be written before this but
  were never shown back anywhere.

#### Fixed
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — A patient's clinical summary no longer
  reports corrections to registration data as clinical findings. Editing a date of birth had been
  producing "unresolved demographic/identity discrepancy" at the top of the summary, and it stayed
  there permanently — the summary is written incrementally and had no way to retract a statement
  once made. Existing summaries correct themselves the next time they regenerate.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Implausible values (a weight that moves
  30 kg in a week, a blood pressure of 777/777) are now called out as probable entry errors instead
  of being worked up as clinical findings. The summary had been raising malignancy, sepsis and
  eating disorders from mis-keyed numbers.

#### Changed
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — The summary now opens with the patient and
  leads with what is clinically significant, rather than walking the record category by category.
  Appointment cancellations and no-shows are limited to one clause where they affect clinical
  interpretation, instead of being itemised.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — It is written in the register a clinician
  uses — a one-line patient descriptor, values inline with units, a differential that reads as
  reasoning with the test that would discriminate. The Spanish is written as a Mexican clinician
  writes it (TA, FC, FR, IMC) rather than translated from the English.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — A misfiled entry is read for what it
  clinically is: asthma sitting in the allergy list is now reported as a likely condition to
  clarify, not as an allergy.

### 2026-09-21 · Front desk hears about portal bookings and reschedules; notification event key reaches the EHR

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `fix/minor-changes`
**Related:** [WORK_LOG 2026-09-21](WORK_LOG.md)

#### Added
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — The front desk is now notified when a patient
  books an appointment from the patient portal. Previously a portal booking told nobody at the
  clinic: the notification the booking raises is addressed to the patient, and is deliberately
  suppressed when the patient is the one who acted, so a slot could fill overnight and first be
  noticed when the patient arrived.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — The front desk is now notified when a patient
  reschedules from the portal, and the notification names the slot that was vacated as well as the
  new one, so the freed time can be re-offered.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — The staff notifications API now returns each
  notification's event key and render parameters, which the patient portal API has always returned.
  The EHR notifications screen can now tell one kind of notification from another without
  pattern-matching the subject line — which could never work reliably, because the subject is
  written in the language of whoever triggered it.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Two new notification tabs are available to
  the EHR: "Patient messages" (portal and WhatsApp together) and "Appointments", each with a count
  that is computed from the same definition as the list it labels.

- **2026-09-21** · `frontend` · Ashutosh (AI-assisted) — The staff Notifications screen was
  redesigned: notifications are grouped under Today and Earlier, each carries an icon and a status
  colour for what actually happened, and appointment rows offer the next action directly — View
  details, and either Reschedule or Rebook patient. New tabs for Patient messages and Appointments,
  and a sort control (newest, oldest, unread first).
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Appointment notifications now name the
  patient they are about, so the front desk can see who cancelled without opening the record.
  Staff notifications only — a patient's own notification does not repeat their name back to them.
  Existing notifications were backfilled.
- **2026-09-21** · `frontend` · Ashutosh (AI-assisted) — A notification about an appointment now
  opens that appointment. The appointments list accepts one appointment by name, so "View details"
  shows the row it refers to rather than an unfiltered list.

- **2026-09-21** · `frontend` · Ashutosh (AI-assisted) — The front desk can reach the Patient
  Appointment QR and the Patient Registration Form from the Dashboard. Both lived in Settings, which
  only admins can open, so the people who print and hand out these two things could not get to
  either. They now open in a drawer over the dashboard, so the queue stays visible.

- **2026-09-21** · `frontend` · Ashutosh (AI-assisted) — A doctor can add a vaccine to the
  immunization schedule card from the patient's chart. "Add vaccine" is the last row of the card and
  lists the vaccines that are not shown by default. **Adding one shows it on every patient's card,
  not only the patient on screen.**
  - **2026-09-21** update — the picker's note explaining that clinic-wide scope was removed on
    request, so the effect is no longer stated anywhere in the interface.

#### Security
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — **PERMISSION CHANGE.** EB_Practitioner now
  has `write` on Immunization Template, so a doctor can change which vaccines appear on schedule
  cards. `create` and `delete` were deliberately NOT granted — authoring or removing a vaccine
  schedule stays with EB_Healthcare Admin. EB_Nurse and EB_Front Desk are unchanged (read-only).
  Applied through `eb_docperm_spec.json`, which the `after_migrate` hook reconciles.

#### Fixed
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Notifications in the staff EHR show what
  they actually say. Every one displayed "Open the record to read this notification." — an email
  placeholder — instead of its own text, because the list read the wrong column. A patient's
  WhatsApp message now reads as the message they sent. 109 of 110 existing notifications were
  affected; they display correctly now with no migration. The patient portal was never affected.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Front-desk appointment notifications linked
  to a page that does not exist. Every one raised since 2026-09-11 pointed at `/appointments/<id>`,
  a route the EHR has never had, so opening one showed a 404.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Healthcare Admins now receive the same
  patient-initiated appointment notifications as the front desk. Previously only EB_Front Desk did,
  so an admin watching their own notifications saw nothing when a patient cancelled.
- **2026-09-21** · `frontend` · Ashutosh (AI-assisted) — A cancellation notification no longer
  offers "Reschedule", which cannot succeed on a cancelled appointment and failed only after the
  user had picked a new slot. It offers "Rebook patient" instead, opening the booking drawer with
  the patient already filled in.
- **2026-09-21** · `backend` · Ashutosh (AI-assisted) — Removed 3,135 junk notifications from
  `mysite.localhost` left behind by test runs between 2026-09-11 and 2026-09-16, plus 111 orphaned
  appointment-cancellation rows pointing at appointments that no longer exist. Local site data only;
  no code change.
### 2026-09-21 · Moving an appointment to a doctor in another department no longer fails

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `fix/appointment-department-set-only-once`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md)

#### Fixed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — Reassigning an appointment to a
  practitioner in a different department no longer fails with "Value cannot be changed for
  Department". Reassignment within the same department was unaffected, which is why this looked
  intermittent.

#### Changed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — `Patient Appointment.department` is no
  longer `set_only_once`. Cross-department reassignment is a supported workflow here, so core's
  constraint was wrong for this product. Shipped as a Property Setter fixture rather than set by
  hand, so every site behaves the same — unpinned doctype metadata is why dev and a local bench
  disagreed on this in the first place.
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — The Property Setter fixture filter now
  covers `Patient Appointment` and `WhatsApp Account`, not `Patient` alone. The WhatsApp token
  setter was already in the fixture file but outside the filter, so the next `export-fixtures`
  would have dropped it.
### 2026-09-21 · The money reports now say what the database actually says

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** backend `feature/narzim-gpt`, frontend `dev`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md) · [GAPS](docs/reports/GAPS.md) G-04, G-57 – G-62 · [verification](docs/reports/FINANCIAL_REPORTS_VERIFICATION_2026-09-20.md)

#### Fixed
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Revenue by Provider now tells you when
  money was refunded. It had stopped saying so in August, so the page and Payment Methods appeared
  to disagree by 6,480 MXN with no explanation. ([gap](docs/reports/GAPS.md))
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Payment Methods now lists the individual
  payments and refunds behind its totals, so a receptionist can check a single payment without
  leaving the report.
- **2026-09-21** · `backend` + `frontend` · Divyanshu (AI-assisted) — Outstanding Balances no longer
  claims part of the list is hidden when it is showing everything; it now says "showing X of Y"
  only when rows were genuinely cut.
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Outstanding Balances now states the date
  its balance was measured on, so a figure taken today is not read as a whole month's activity.
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Claims Status no longer draws a 0%
  approval rate for a period in which no claims were filed. "We filed none" and "all of ours were
  denied" now look different.
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Claims Status no longer offers a doctor
  filter that broke the page; insurance claims do not record a doctor, so the control is gone.
- **2026-09-21** · `frontend` · Divyanshu (AI-assisted) — Claims Status cards now show the amount
  of money in each state, not only how many claims are in it.

#### Changed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — Outstanding Balances reports how many
  invoices matched, not just how many it returned. (**Additive** — no existing field removed.)

---

### 2026-09-20 · The four money reports were checked against the database, number by number

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend (docs) · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-20](WORK_LOG.md) · [verification record](docs/reports/FINANCIAL_REPORTS_VERIFICATION_2026-09-20.md) · [GAPS](docs/reports/GAPS.md) G-57 – G-62

#### Added
- **2026-09-20** · `backend` · Divyanshu (AI-assisted) — Every figure on the four financial reports
  (Revenue by Provider, Payment Methods, Outstanding Balances, Claims Status) was compared against
  what the database actually holds, and the result written down as a dated record.
  ([evidence](docs/reports/FINANCIAL_REPORTS_VERIFICATION_2026-09-20.md))
- **2026-09-20** · `backend` · Divyanshu (AI-assisted) — Six previously unrecorded defects in those
  reports are now on the register as G-57 – G-62. ([register](docs/reports/GAPS.md))

#### Changed
- **2026-09-20** · `backend` · Divyanshu (AI-assisted) — The gap register's own totals disagreed
  with each other over one already-fixed item; the two counts now match.
  ([register](docs/reports/GAPS.md))
- **2026-09-20** · `backend` · Divyanshu (AI-assisted) — G-27 previously said Outstanding Balances
  warns you when its list is cut short. It does warn — with the wrong number — so the wording was
  corrected and the disclosure defect split out as G-57. ([register](docs/reports/GAPS.md))

**No code changed.** These reports have not been altered; this records what they currently do.

---

### 2026-09-21 · A patient could read "Due" on the queue card and "Paid" in the drawer at the same time

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `fix/queue-card-nonbillable-work-shows-due`
**Related:** [WORK_LOG — 2026-09-21](WORK_LOG.md) · follows the 2026-09-17 queue payment state work below

#### Fixed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — The Clinical Command Center no longer shows
  an amber "Due" chip on a patient who owes nothing. A lab report uploaded from outside the clinic
  is deliberately not chargeable, and the board was counting it as work still to be billed — so the
  card said "Due" while the drawer for the same appointment said "Paid". Because such a record can
  never be invoiced, that "Due" would never have cleared on its own.
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — The same miscount is closed for encounters
  billed through their appointment, drugs whose item is disabled or already fully invoiced, orders
  and procedures billed through a Service Request, and therapy sessions billed through their plan.

#### Changed
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — The board and the appointment drawer now
  decide "is this chargeable" through the same shared code, so the two can no longer drift apart.
- **2026-09-21** · `backend` · Divyanshu (AI-assisted) — The board's query-cost test now asserts the
  property it is named for (cost does not grow with the number of patients) instead of an absolute
  ceiling that had never passed.

---

### 2026-09-18 · Audit-logging documentation corrected against code

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs only) · **Branch:** `docs/audit-logging-corrections`
**Related:** [WORK_LOG 2026-09-18](WORK_LOG.md) · [docs/security/AUDIT_LOGGING_PLAN.md](docs/security/AUDIT_LOGGING_PLAN.md)

#### Added
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — A plain-language guide to the five
  things the system tracks — logins, chart reads, exports, record changes and patient messages —
  written for someone who has never worked with audit logs.
  ([docs/security/LOGS_AND_TRACKING_EXPLAINED.md](docs/security/LOGS_AND_TRACKING_EXPLAINED.md))
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — A work plan for the remaining audit-logging
  gaps: eight open items in priority order, each with its evidence, its acceptance test and the
  reason it sits where it does.
  ([docs/security/AUDIT_LOGGING_PLAN.md](docs/security/AUDIT_LOGGING_PLAN.md))

#### Fixed
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — The audit-logging reference no longer
  tells readers that log retention was declined. It was reversed four days after that decision was
  written, and the document had said otherwise for eighteen days while the newer compliance
  assessment said the opposite.
  ([docs/security/AUDIT_LOGGING.md](docs/security/AUDIT_LOGGING.md) §11.1)
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — The record of how patient-chart reads are
  logged now describes the permission chokepoint that covers every read endpoint, instead of the
  thirteen hand-placed call sites it replaced in September.
  ([docs/security/AUDIT_LOGGING.md](docs/security/AUDIT_LOGGING.md) §8.5)
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — The audit-logging summary no longer
  presents four solved problems as live failures. Failed logins going untraced, every 4xx being
  discarded, 46 endpoints going unaudited and chart reads not being recorded were all fixed in
  August, but the document's opening table — the part most people read and quote — still listed them
  in red. It now marks what is built, what is a standing rule, and what is genuinely open.
  ([docs/security/AUDIT_LOGGING.md](docs/security/AUDIT_LOGGING.md) §3)
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — The open-questions and follow-up sections
  of the same document are reconciled: the question of what log retention is actually set to is
  answered, and four of five outstanding obligations are marked done. The one still open — no
  decision record exists for either logging decision — is now tracked in the plan.
  ([docs/security/AUDIT_LOGGING.md](docs/security/AUDIT_LOGGING.md) §12-13)

#### Security
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — Recorded that the six-year retention patch
  had an unintended side effect: the logs of who read which patient chart, and of which documents
  left the system, went from being kept forever to being deleted after six years. Nothing is lost
  before about 2032 and six years satisfies every jurisdiction we operate in, but the change was
  made while believing it extended retention, and it now needs a deliberate decision either way.
  ([docs/security/AUDIT_LOGGING.md](docs/security/AUDIT_LOGGING.md) §11.1 · plan item O7)
- **2026-09-18** · `backend` · Anant Sharma (AI-assisted) — Confirmed still open and raised to the top
  of the plan: a patient's email address is written to the application log file when an encounter
  report is emailed, which Rule 10 forbids.
  ([docs/security/AUDIT_LOGGING_PLAN.md](docs/security/AUDIT_LOGGING_PLAN.md) item O5)
### 2026-09-18 · A fresh chat now suggests things worth asking — the backend for PR #493 is complete

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.25

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Opening a new Narzim chat now offers
  starter questions chosen for **your role** — a doctor, a nurse and a front-desk colleague each see
  a different set — in your own language, and one of them names a medicine this clinic actually
  stocks. ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Fixed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A starter card could name a nonsense entry
  from the medicine list, asking "the pediatric dose of C?". Entries that are not plausible medicine
  names are now skipped.

---

### 2026-09-18 · Narzim remembers what it read, and shows you the same thing tomorrow

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [ADR-079](docs/adr/adr-079-ai-source-cache-stored-for-reproducibility.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.24

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Asking a follow-up about a link you already
  shared no longer re-downloads it, so the answer comes back faster.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Reopening a conversation now shows the
  **same source text the assistant actually read**, even if the website has since been changed or
  taken down. ([why](docs/adr/adr-079-ai-source-cache-stored-for-reproducibility.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Saved copies are deleted automatically after
  30 days, by a job that ships with the feature rather than being promised for later.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A saved copy is never shared between staff:
  what one clinician opened is not served to anyone else.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A saved copy can never be used to get around
  a refusal: a link this clinic may not open, or one carrying a patient's details, is still refused
  even if it was read successfully before.

---

### 2026-09-18 · The record of who receives patient data is now enforced, not just written down

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [ADR-078](docs/adr/adr-078-phi1-enforced-at-the-provider-chokepoints.md)

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — If the AI provider configured for a clinic
  is not the one named in its compliance record, AI now stops instead of sending patient data
  anyway. Previously only the registration-form scanner checked this; the encounter assistant, note
  generation, lab reading and Narzim did not.
  ([why](docs/adr/adr-078-phi1-enforced-at-the-provider-chokepoints.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — The same check now covers voice capture,
  which nothing had ever checked: the clinic's compliance record names an audio provider, and until
  today no code read that field at all.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Changing the AI provider in Settings to one
  the compliance record does not name is refused **at the moment of saving**, with a message naming
  both values, so the mistake surfaces to the administrator making it rather than to a clinician
  losing AI mid-consultation days later.

---

### 2026-09-18 · Literature search and pasted links are switched on

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [ADR-077](docs/adr/adr-077-clinical-web-outbound-retrieval.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.23

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Narzim can now search published medical
  literature and read a link you paste, and cite both alongside your own files. Available in both
  Mexico and India.
  ([why](docs/adr/adr-077-clinical-web-outbound-retrieval.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A link whose address itself contains a
  patient's name or record number is refused before anything is sent, because the address reaches
  the far end before any page comes back. You are told why, and can open it yourself.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — What is sent to the literature search never
  contains a patient's name, record number, email or phone number; only the clinical question.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Only one literature provider is approved,
  by name. Anything else is still refused, and adding one is a reviewed change rather than a setting.

---

### 2026-09-18 · A typed-out reply now shows its sources too

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.22

#### Fixed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — When Narzim types its answer out word by
  word, it now actually reads the files you attached and shows them underneath. Until today that
  only worked for the other kind of reply, so the same question could be answered from your protocol
  or without it depending on which one you got — with nothing on screen to tell you which.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Stopping a reply half way now keeps a record
  of which sources the part you already read came from.

#### Changed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A question Narzim is going to decline no
  longer opens your files or searches anything first.

---

### 2026-09-18 · Literature search and pasted links — built, and switched off

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.21 · [ADR-076](docs/adr/adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md) (Proposed)

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Narzim can search published medical
  literature and read a link you paste, and cite both in the same numbered list as your own files.
  **Neither is switched on anywhere**: both refuse until a clinic's compliance profile names who is
  allowed to receive the request. ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A pasted link can no longer be used to make
  the server read something on the clinic's own network: every address behind the name is checked,
  and re-checked at every redirect, before anything is downloaded.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A literature search is checked a second time,
  immediately before it is sent, so a patient's name, email or phone number cannot reach a search
  provider even if a future change adds another way to build the query.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A link or a search that fails now says so.
  Neither is allowed to look like "there is nothing to find", which would be a clinical claim made by
  a network error.

---

### 2026-09-18 · Narzim can answer from your own files, and show you which one

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.20

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Attach one of your own library files to a
  question and Narzim answers from it, with a numbered source under the answer that points back at
  the file. **The first working citation** — the sources list under a reply has never had anything to
  show until now.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Nothing leaves the clinic: your files are
  already stored here, and their text is masked for personal details in exactly the same way as a
  file you drag into the chat.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — If one of the files you attached cannot be
  read, you are told — rather than quietly getting an answer from the others and believing all of
  them were used.

---

### 2026-09-18 · The Sources bar knows what it can actually offer

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.19

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — The Sources bar can now ask which sources
  this clinic actually has, and each one says whether it is available **and why not** when it is not
  — so a switched-off source explains itself instead of silently failing when you use it.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Literature search reports itself as
  unavailable until a provider has been formally approved for the clinic, so it cannot be switched on
  by accident.

---

### 2026-09-18 · Somewhere for answer sources to live

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.18

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Groundwork for the numbered sources under an
  answer. Every reply now carries a sources list, and a conversation reloads with the same sources it
  had. The list is empty for now — nothing looks anything up yet — but everything that will fill it
  now has somewhere to put it.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A source can only be recorded by the code
  that actually fetched it. The AI is never asked to produce one, so it cannot invent a reference —
  a made-up source in a clinical tool is worse than none, because it looks checked.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A source that points at one of your own files
  must say which file, or it is refused; otherwise the citation could not be opened and verified.

---

### 2026-09-18 · Pinning one of your own files to a question works again

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.17

#### Fixed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Attaching one of your own library files to a
  Narzim question was refused every time with "Unknown library document". It now works. The check was
  looking for your file in the wrong place — the old storage system Narzim Drive has moved off.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A file you are not allowed to see now gives
  exactly the same answer as a file that does not exist, so nobody can learn that a document exists
  by attaching its id. Permission is checked through Narzim Drive's own sharing rules rather than a
  generic check that does not understand them.

#### Changed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — On a site without Narzim Drive installed,
  ordinary messages still work; only attaching a library file is unavailable, and it says so.

---

### 2026-09-18 · The compliance record can name who may receive a search

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.16 · [ADR-076](docs/adr/adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md)

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — The clinic's compliance record can now name
  which research providers may receive a search, and whether the server may open a link somebody
  pastes. Both markets ship with **nothing approved**, so neither is available until someone records
  a decision.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Searching or opening a link now refuses
  outright unless the compliance record names that provider, with a message saying what has to happen
  first. Previously the record had nowhere to name a research provider at all, so this could not have
  been checked even in principle.

#### Deprecated
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — [ADR-076](docs/adr/adr-076-jurisdiction-profiles-central-table-over-hipaa-baseline.md)
  proposes replacing one-file-per-country with a single table over a HIPAA baseline, so opening in a
  new country needs no code change. **Proposed, not accepted** — it supersedes ADR-018 and needs that
  author's agreement.

---

### 2026-09-18 · Groundwork for medical literature search

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.15

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Groundwork for looking things up in medical
  literature: the check that decides what a search may contain before it ever leaves the clinic.
  Nothing searches anything yet — this is the safety gate the search will have to pass.

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — A search can never contain a patient's name,
  their record number, their email address or their phone number — checked against your own patient
  records, so it is exact rather than a guess. Clinical numbers such as a weight or an age do travel,
  because they make the search better and identify nobody.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — The check runs again immediately before
  anything would be sent, so a future change cannot accidentally go around it. If the patient list
  cannot be read, no search happens at all rather than an unprotected one.

---

### 2026-09-18 · Narzim suggests the right template

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.14

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — As you type, Narzim now suggests which of
  your templates fits what you are working on, and tells you which words matched so you can see why.
  It works in Spanish and English, and ignores accents — "vacunacion" finds "Vacunación".
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — When Narzim produces something already shaped
  like a note and you have no template for it, it offers to save it as one. Nothing is saved unless
  you choose to.

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Suggesting a template sends nothing anywhere.
  The matching happens entirely inside the system, so your conversation is not transmitted just to
  sort a list.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

---

### 2026-09-18 · Build a template from your past visits

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.13

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Pick up to five of your past visits and the
  system builds you a blank note template from the sections you actually use. It comes back as a
  suggestion you review and save yourself — nothing is saved on your behalf — and it shows you which
  visits each section came from, so you can check the reasoning.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — If the assistant is unavailable, the template
  is still produced, with plainer wording, and you are told that is why.

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Building a template from past visits sends
  **no patient information anywhere.** The visits are read inside the system to count which sections
  you use; only those section names — from a fixed list written in the code — are sent to the
  assistant. No complaint, medicine, name or record number leaves.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Every visit you select is permission-checked
  before anything about it is read.

---

### 2026-09-18 · The template editor

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-18](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.12

#### Added
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — You can now open a note template in the
  editor, change it either by typing or by asking in plain language ("add a follow-up slot under
  Plan"), and save it. Your work is kept on the server while you edit, so closing the tab or a
  restart does not lose it.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Opening one of the built-in templates now
  works properly: you can edit it freely and Save creates your own named copy, leaving the original
  untouched. The editor tells you it will be a copy before you start.

#### Fixed
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — The test suite had been leaving a stray
  template behind on every run since the templates work began; 7 had accumulated on the dev site.
  Cleaned up and the cause fixed.

#### Security
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — An editing session holds only the outline
  being written — never a patient, a visit, or a filled-in example — so it cannot become an
  unexpected place patient data lives. The editor ignores any patient sent to it and says so.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Saving from the editor goes through the same
  checks as saving anywhere else, so an outline naming a patient is refused there too.
- **2026-09-18** · `backend` · Divyanshu (AI-assisted) — Abandoned editing sessions are now deleted
  automatically after 24 hours by a daily job, rather than the 24 hours being only a claim.

---

### 2026-09-17 · Templates that fill themselves in

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.11

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Apply one of your note templates to a
  Narzim conversation and it comes back filled in from what was said, and from the linked patient's
  record when you have linked one. It is a draft in the chat for you to read and edit — nothing is
  written to the visit.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The template editor can now show a worked
  example of the outline you are writing, so you can see what it looks like filled before saving it.
  The example is entirely made up and is never saved.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Picking a template in the message box now
  actually shapes the reply, and the conversation records which template was used.

#### Changed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A reply built from a template is now
  displayed as formatted text rather than raw markdown, so your own headings do not come back as
  literal `##`.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Applying a template to an empty conversation
  with no patient linked returns the blank structure immediately instead of asking the AI to fill
  something it has no information for.

#### Fixed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Narzim could answer in an unexpected
  language when a message gave no clue which one to use: the patient-aware path never told the model
  the clinic's default.

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A template chosen for a message is now
  permission-checked before its content is used, so another clinician's private template cannot be
  reached through the message box.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A template whose text names a patient is
  refused before it is sent anywhere, the same way a typed message already was.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The template editor's example preview is
  never generated from a real patient's record, even if the request asks for one.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A template can no longer be **saved** with a
  patient's name or ID in its text — previously it was only stopped from being sent to the AI, so it
  could still sit in the template library, be copied, and be published to the whole clinic. You are
  asked to use a slot such as `[Patient name]` instead.
  ([why](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

---

### 2026-09-17 · Narzim can now answer about a patient you link

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [ADR-075](docs/adr/adr-075-narzim-gpt-patient-aware-context.md) · [inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.10

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Link a patient to a Narzim conversation and
  it can now answer from that patient's record — allergies, current medications, labs, previous
  visits — instead of from general knowledge. It reads the chart; it can never change it. Link a
  visit as well and it can also see that visit.

#### Changed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The message shown when you name a patient
  without linking one now tells you to link them, instead of saying Narzim has no access to patient
  records — which is no longer true.

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Naming a patient *other* than the one you
  linked is still refused before anything is sent or saved, and the refusal never repeats what it
  matched. A visit or appointment number counts as naming its patient. A patient number that matches
  nobody is refused rather than let through.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Narzim is given read-only access to the
  chart and no ability to write to it, and only for the patient you linked. Whether you may see that
  patient is re-checked on the server on every message.

---

### 2026-09-17 · Note templates you can create, edit and keep

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [Narzim GPT backend inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.9

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Clinicians can now keep their own note
  structures — a SOAP outline, a referral skeleton — and list, create, edit and delete them. The
  templates shipped with the product are available to everyone to start from.

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A template shipped with the product cannot
  be changed or deleted by anyone, including an administrator; to alter one you duplicate it first,
  and your copy records what it came from. Enforced in two places so a change made directly in the
  admin desk is refused too.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A clinician sees only their own templates
  plus the ones shipped with the product. Another clinician's private template is not visible, and
  not reachable by opening it directly either.

---

### 2026-09-17 · Narzim remembers what you attached to a question

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [Narzim GPT backend inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.8

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A question can now carry a linked patient or
  visit, source toggles, pasted links, a chosen note template and pinned library files. These are
  saved with the question and come back when the conversation is reopened, instead of being
  discarded. They are recorded now and start doing something as the search and template features
  land.

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A linked patient, visit or library file is
  re-checked against the signed-in user on the server every time, so sending an id the user is not
  allowed to see is refused rather than attached.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A pasted link is checked before it is
  stored: only `http(s)`, and never an address on the server's own network. Our server is what
  fetches these pages later, so an unchecked link would let it be used to reach internal systems.

---

### 2026-09-17 · Narzim can format its answers, once a screen can show them

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [Narzim GPT backend inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.6

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The Narzim assistant can now answer with
  headings, lists and tables instead of one block of prose, and every reply says which of the two it
  is so the chat knows whether to lay it out or print it as-is. **Off until switched on** in
  AI Settings → *Narzim Assistant Replies in Markdown*; leave it off until the chat screen can
  actually render formatting, or clinicians see the raw `##` and `**` characters.

#### Changed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Replies now remember the format they were
  written in. A conversation that was going on before the setting was switched on keeps showing its
  older answers as plain text instead of re-interpreting them.

---

### 2026-09-17 · The dictation mic works outside a patient visit

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `feature/narzim-gpt`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md) · [Narzim GPT backend inventory](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md) §3.4 item 6

#### Added
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Speech-to-text can now be used where there
  is no patient visit open, such as the Narzim GPT chat box and the note-template editor. Previously
  it refused unless it was given an encounter, so the mic was a dead button on those screens.
  ([what needs it](docs/ai/NARZIM_GPT_BACKEND_INVENTORY.md))

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Dictation that happens outside a visit is
  still recorded in the AI usage log, so transcription billed to the clinic is never unaccounted
  for. Audio continues to be discarded immediately and is never stored, on both paths.

### 2026-09-17 · Review fixes on the queue payment state hotfix

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `hotfix/queue-payment-state`
**Related:** [prompts/2026-09-17-queue-payment-state-hotfix-review-fixes.md](docs/_archive/prompts/2026-09-17-queue-payment-state-hotfix-review-fixes.md)

#### Changed
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Loading the Clinical Command
  Center costs a fixed number of database queries again, whatever the size of the board. It had
  become one full billing calculation per patient, including an unsaved draft Sales Invoice each,
  over the whole day's appointment list, on a screen that refreshes every 30 seconds. The card shows
  a chip and never an amount, so the board now asks for the payment state and leaves the exact
  figure to the appointment drawer, which is unchanged.
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The "All appointments" list no
  longer triggers any billing lookup. It renders no payment state.

#### Fixed
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A patient's balance, and the
  invoice a "Pay Now" settles, are now scoped to the current company. On this site Narzim and
  Remedisys share one Customer per patient, so a card at one clinic could show, and collect
  against, the other clinic's invoice.
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — "Partly paid" now means money was
  actually received. It is read from submitted Payment Entries instead of inferred from a fall in
  the invoice's outstanding amount, which a write-off or a credit note also causes. A part-waived
  Government invoice was reporting cash the till never took.
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A billing lookup failure on the
  dashboard is logged once per request, with its real traceback, and the write is deferred. It was
  one Error Log row per failing patient per refresh, with the stack trace discarded, which turned a
  read-only screen into a steady writer.
- **2026-09-17** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — "Pay Now" reads the invoice's
  current balance before offering to collect, instead of trusting the board's snapshot, which can be
  30 seconds old. If someone else has settled it in the meantime, the front desk gets the new-invoice
  sheet rather than a rejected payment.
- **2026-09-17** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The collect dialog shows the
  invoice's own currency, and says how many other invoices still owe. A payment settles one invoice,
  and collecting once could otherwise read as "this patient is clear".

#### Security
- **2026-09-17** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A patient's billing position is
  returned only to staff roles, and the invoice id and amount only to front desk and admin. The
  dashboard endpoint is gated on read access to Patient Appointment, which `EB_Patient` also holds,
  so a portal account was in scope to receive other patients' invoice ids and balances.

### 2026-09-17 · Booking an appointment as "Pay now · Government" works again

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `main`
**Related:** [WORK_LOG 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — Booking an appointment with payment timing
  **Pay now · Government** no longer fails with "Insufficient Permission for POS Profile". A waived
  government appointment is not a cash sale, so its invoice is no longer marked as a point-of-sale
  invoice — which is what was sending it looking for a POS terminal the clinical user is not allowed
  to read. The invoice still nets to zero and the appointment still shows Government as its payment
  method. Only ERPNext 16.35+ sites (dev) were affected; 16.26 (local) never performed the check.

#### Changed
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — A waived government invoice is no longer
  attached to a POS Profile. On sites that have one configured, consultation waivers were being
  booked against the `Pharmacy Counter` till, which would have corrupted future shift reconciliation
  ([ADR-023](docs/adr/adr-023-cash-drawer-shift-reconciliation.md)).

---

### 2026-09-17 · A queue card can no longer show "Paid" over money the drawer is asking front desk to collect

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `main`
**Related:** [WORK_LOG 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `frontend` · Divyanshu (AI-assisted) — A patient card on the Clinical Command
  Center now shows the same payment state as that appointment's own detail drawer. A card could show
  a green "Paid" while the drawer for the same appointment showed "Unpaid MXN 1,580" and a Pay now
  button, because the card only looked at that one consultation's invoice and the drawer looks at
  everything still unbilled for the patient.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The dashboard queue now returns
  `patient_unbilled_total_mxn` on every room's rows, so the board and the drawer read one number
  instead of two. Computed once per distinct patient per board rather than once per card.
  - **2026-09-17** update — extended to the patient's FULL pending position
    (`patient_total_pending_mxn`), because unbilled-only went back to reading "Paid" as soon as the
    work was invoiced and part-collected.
- **2026-09-17** · `frontend` · Divyanshu (AI-assisted) — A part-paid balance now shows as
  **Partly paid** with the amount still owed, on both the queue card and the appointment drawer,
  instead of a green "Paid". Previously an invoice with 1,000 of 1,580 collected showed as settled
  on the dashboard while the patient's Billing tab showed 580 MXN to collect.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — `get_patient_total_pending` also reports
  how much has already been collected against invoices that still owe (`invoiced_paid_mxn`,
  `invoiced_partially_paid`), so "Partly paid" and "Unpaid" can be told apart.
- **2026-09-17** · `frontend` · Divyanshu (AI-assisted) — Pressing **Pay Now** on a patient who owes
  on an already-issued invoice now opens the same Record Payment dialog as the Billing tab's Collect
  button, against that invoice. It previously opened an empty "new invoice" sheet whenever the
  balance was not on the appointment's own invoice, leaving no way to take the money from the
  dashboard.
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — `get_patient_total_pending` resolves which
  invoice a collect action should settle (`collect_invoice`, `collect_outstanding_mxn`,
  `outstanding_invoice_count`), newest owing first.
- **2026-09-17** · `frontend` · Divyanshu (AI-assisted) — A queue card no longer shows two
  contradictory payment chips at once. The duplicate chip in the card header is removed; the payment
  state is stated once, next to the visit type.
- **2026-09-17** · `frontend` · Divyanshu (AI-assisted) — An appointment that has never been invoiced
  now reads "Payment pending" instead of "Paid". Having nothing left to collect is not the same as
  having been paid, and the card was announcing a payment that never happened.

#### Security
- **2026-09-17** · `backend` · Divyanshu (AI-assisted) — The new batched billing lookup is
  read-only by construction: it computes only for patients whose Customer link already exists, so
  loading a dashboard can never create a Customer or write to a Patient record as a side effect.

### 2026-09-17 · Owner profile photos in Narzim Drive

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend (`EB_Healthcare_EHR`) ·
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `both` · Anant Sharma (AI-assisted) — The Owner column now shows the person's
  profile photo instead of their initials, in both the file and folder lists. Initials remain as
  the fallback for someone with no photo set.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The Share dialog shows profile photos
  too. The backend had been sending them all along and the dialog discarded them.

---

### 2026-09-17 · Folder names capped at 30, and the folder list obeys the tab

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend (`EB_Healthcare_EHR`) ·
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Changed
- **2026-09-17** · `both` · Anant Sharma (AI-assisted) — A folder name may now be at most **30**
  characters, down from 140. Files and notes are unchanged — an uploaded file is named after the
  file it came from, and those are routinely longer.

#### Fixed
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The Private and Shared tabs now filter
  folders as well as files. Private folders were listed under Shared, above a "No results.".
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The folder list view shows the owner
  and the date modified in their own columns; the document count had been sitting under "Owner"
  and the date column was empty.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The "Your Folders" heading is hidden
  when a tab has no folders, instead of heading an empty space.

---

### 2026-09-17 · Narzim Drive: shared folders, printing, paste, trash and folder lists

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend (`EB_Healthcare_EHR`) ·
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `backend` · Anant Sharma (AI-assisted) — Sharing a folder now actually shares it.
  The folder and every file inside it appear for the person it was shared with; previously neither
  did, so folder sharing appeared to do nothing.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Cmd/Ctrl+A works inside a note again.
  The documents screen was capturing it and selecting every file instead, so the note's own text
  could never be selected. Ctrl+A on the file list now selects what is on screen rather than every
  document in the drive.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Copy and paste of a file creates one
  copy, not two. It used to leave an empty note beside the copied file.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The Print button works, and is now
  offered for images as well as PDFs. It previously did nothing at all.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The grid/list toggle works in Trash.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Searching now finds folders, not just
  documents; folders follow the grid/list toggle; and a drive with many folders shows a first
  screenful with "Show all N folders" instead of pushing the file list off the page.
- **2026-09-17** · `both` · Anant Sharma (AI-assisted) — A folder or document name longer than 140
  characters is refused with "name is too long" as it is typed, instead of failing as a raw
  database error.

#### Removed
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — "Move to Patient" no longer appears in
  the selection bar when only notes are selected; a mixed selection files its files and leaves the
  notes alone.

---

### 2026-09-17 · Uploads and notes now land in the folder you have open

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend (`EB_Healthcare_EHR`) ·
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Files uploaded while a folder was open
  went to the top level of the drive instead of into that folder. Drag-and-drop, paste and the
  upload button all now file into the open folder.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — A new note written while a folder was
  open is now created in that folder, instead of at the top level.

---

### 2026-09-17 · Narzim Drive notes: the Share button works, and dead actions are gone

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend (`EB_Healthcare_EHR`) ·
**Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — The link box in a Drive note is no
  longer cut off by the edge of the panel. Its "Enter link:" label and the first characters of the
  URL were hidden whenever the cursor sat near the left of a line.
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Share on an open note now opens the
  share dialog. It previously did nothing at all when pressed.

#### Removed
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — "Move to Patient" is no longer offered
  for notes, in the note panel or the three-dot menu. A note has no stored file, so the server
  refused every one of them; the action could only ever end in "Notes cannot be moved to a patient."

#### Security
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Whether you own a document is now
  decided in one place, and requires both an owner and a signed-in user to be known. The previous
  comparison treated "owner unknown" and "not signed in yet" as a match, which could show Delete and
  Rename on a document nobody had been confirmed to own.

---

### 2026-09-17 · A Drive team with no root folder no longer blocks every upload

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend ·
**Branch:** `fix/drive-home-folder-usability`
**Related:** [WORK_LOG — 2026-09-17](WORK_LOG.md)

#### Fixed
- **2026-09-17** · `backend` · Anant Sharma (AI-assisted) — Seven users on dev could not upload any
  document at all. Narzim Drive now skips a Drive team that has lost its root folder instead of
  handing it to Drive and failing with "This team doesn't exist", and a migration rebuilds the
  missing folders so each user is back on their own drive rather than the shared clinic one.
- **2026-09-17** · `backend` · Anant Sharma (AI-assisted) — One broken team no longer makes the
  clinic team ambiguous. Previously a single unusable team put the Documents screen into
  "Several clinic Drive Teams exist" rather than picking the one that worked.
- **2026-09-17** · `backend` · Anant Sharma (AI-assisted) — Saving a clinical user now repairs
  their drive when its root folder is missing, instead of skipping them because a team row exists.
  Without this an affected user stayed broken through every future save, indefinitely.

---

### 2026-09-16 · Document uploads tell the truth, and the list refreshes by itself

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend (`EB_Healthcare_EHR`) ·
**Branch:** `fix/drive-upload-feedback-and-cache`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md)

#### Fixed
- **2026-09-16** · `frontend` · Anant Sharma (AI-assisted) — The upload panel on the Documents
  screen no longer reports failed uploads as successful. Seven uploads that all returned HTTP 400
  were announced as "7 uploads complete"; it now counts successes and reports failures when there
  are any.
- **2026-09-16** · `frontend` · Anant Sharma (AI-assisted) — A document now appears in the list as
  soon as it is uploaded or moved to a patient, instead of only after a manual page reload. The
  mutation hooks were refreshing a cache key the Documents screen does not read.

#### Added
- **2026-09-17** · `frontend` · Anant Sharma (AI-assisted) — Narzim Drive is back in the sidebar.
  The entry was hidden on 2026-09-16 because uploads were failing; with the three defects behind
  that fixed, the `/documents` entry is restored to exactly its pre-hide state.

---

### 2026-09-16 · Narzim Drive finds the clinic team by itself instead of failing every upload

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend ·
**Branch:** `fix/drive-clinic-team-resolution`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md)

#### Fixed
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Document uploads work again on a site
  that was never hand-configured with a shared Drive team. The clinic team is now derived
  automatically when exactly one non-personal team exists, so the `remedisys_drive_team` setting is
  an override for the ambiguous case rather than a requirement the feature shipped without
  performing.
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — A `remedisys_drive_team` value naming a
  team that does not exist on this site (an id copied between environments) no longer takes
  Documents down for the whole clinic: it falls back to the derived team and logs a warning, and
  where nothing is derivable the error now names the setting at fault and the candidate ids instead
  of Drive's internal "This team (…) doesn't exist".

#### Added
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — **MIGRATION** `AI Settings → Narzim
  Drive → Clinic Drive Team`, so an administrator can set the team in the UI rather than in
  `site_config.json`; it takes precedence over the site-config pin. Patch
  `ensure_clinic_drive_team_20260916` creates the clinic team when the site has none and corrects a
  missing or stale pin. It moves no documents.

---

### 2026-09-16 · Encounter follow-up banner is a light tint again, not a solid fill

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** frontend ·
**Branch:** `fix/encounter-followup-banner-color`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md)

#### Fixed
- **2026-09-16** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The "Sent to Front Desk"
  follow-up banner on the Encounter note screen renders as a light tint again instead of a solid
  green fill. A color-token refactor (2026-09-11) had mapped its palest-tint background to the
  saturated `--success` token at the wrong opacity.

---

### 2026-09-16 · A doctor now sees why an encounter failed to load, not just "not found" (NH-135 follow-up)

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** frontend ·
**Branch:** `fix/nh135-encounter-error-messages`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) · [Backend PR #414](https://github.com/eBasics-Services-P-Limited/EB_Healthcare_Backend/pull/414)

#### Fixed
- **2026-09-16** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The encounter screen now shows a
  distinct message for "you don't have permission", "this encounter doesn't exist", and "something
  went wrong" — previously all three showed the same "Encounter not found", which is why the real
  NH-135 permission bug (fixed separately, see the linked backend PR) took far longer to diagnose
  than it should have.

---

### 2026-09-16 · Narzim Drive: a personal drive per user, trash management, bulk upload and a storage meter

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `feat/narzim-drive-per-user`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) · [NARZIM_DRIVE.md](docs/narzim-drive/NARZIM_DRIVE.md)

#### Added
- **2026-09-16** · `backend`+`frontend` · Anant Sharma (AI-assisted) — Every clinical user now gets
  their own drive, created with their account, and what they upload goes into it.
  ([how it works](docs/narzim-drive/NARZIM_DRIVE.md))
- **2026-09-16** · `backend`+`frontend` · Anant Sharma (AI-assisted) — **Trash** is visible in the
  EHR at last: deleted documents can be found, sorted, searched, restored, deleted one at a time,
  selected in bulk, or emptied. Previously deleting was one-way through the product.
- **2026-09-16** · `frontend` · Anant Sharma (AI-assisted) — Several files can be uploaded at once,
  by picker, drag-and-drop or paste; three upload at a time so a bulk import cannot swamp the server.
- **2026-09-16** · `frontend` · Anant Sharma (AI-assisted) — The Documents footer shows how much
  storage you have used, amber at 80% and red at 90%.

#### Changed
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Documents lists now span a user's own
  drive, the clinic's shared drive and anything shared with them, so a document is visible whichever
  way it arrived. Nothing was migrated; older documents stay in the clinic drive.

#### Fixed
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Deleting a user no longer breaks
  Documents for every subsequently created user. One membership row left pointing at a deleted
  account blocked provisioning for everyone.
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Creating a document from Frappe Drive's
  own UI no longer fails with a name collision once users have their own drives.

#### Security
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Frappe Drive's own interface is now
  restricted to Desk users; patient-portal and clinical Website User accounts are refused outright.
  ⚠️ Reads through that interface are still unlogged and bypass per-document privacy — see
  [NARZIM_DRIVE.md §6](docs/narzim-drive/NARZIM_DRIVE.md).
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — Permanently deleting a document now
  writes an audit row naming who did it. Frappe Drive records nothing.
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — A user can only restore or permanently
  delete documents they own; trash is visible team-wide but not actionable across owners.

#### Deprecated
- **2026-09-16** · `backend` · Anant Sharma (AI-assisted) — **MIGRATION**: `remedisys_drive_team` in
  `site_config.json` is now **mandatory** on every site. With a drive per user several teams always
  exist, and without the key every Documents request fails. Set it to the team whose `personal = 0`
  **before** creating any user on that site, then `bench --site <site> clear-cache`.

---

### 2026-09-16 · A doctor can now read a signed encounter that another practitioner signed (NH-135)

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend ·
**Branch:** `fix/nh135-encounter-signed-read-permission`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md)

#### Security
- **2026-09-16** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **Fixed a data-access bug where a
  signed Patient Encounter became unreadable to every doctor except the one who signed it**, and
  vanished from the patient's chart list entirely instead of showing an error. `custom_encounter_done_by`
  was missing its permission exemption since the field was added (2026-08-07); verified live that 69 of
  167 signed encounters on the dev bench were affected before this fix.

### 2026-09-16 · "Pay Now" no longer silently does nothing; reschedule delta invoices now show a practitioner

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) ·
[ADR-074](docs/adr/adr-074-pay-now-dead-end-and-missing-practitioner-on-delta-invoices.md)

#### Fixed
- **2026-09-16** · `frontend` · Ashutosh (AI-assisted) — **"Pay Now" on the Command Center drawer no
  longer does nothing when the current visit is already fully paid but the patient has other unbilled
  items** — it now opens checkout for the patient's actual unbilled balance, the same way the Patient
  Chart's own "Pay now" button already does.
- **2026-09-16** · `backend` · Ashutosh (AI-assisted) — Reschedule/reassign delta invoices now show
  the practitioner in the Patient 360 Billing tab, previously blank for these rows.

---

### 2026-09-16 · A credit-noted invoice now links to its own Credit Note, in the Patient 360 Billing tab

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) ·
[ADR-073 Addendum](docs/adr/adr-073-billing-cache-invalidation-and-paid-amount-display.md)

#### Fixed
- **2026-09-16** · `backend` + `frontend` · Ashutosh (AI-assisted) — **Opening an invoice marked
  "Credit Note Issued" from the Patient 360 Billing tab (or an appointment card) now links directly to
  the Credit Note itself** — previously the badge was correct but there was no way to actually view the
  document it named, in either of those two screens (the clinic-wide Revenue/Billing hub already had
  this working).

---

### 2026-09-16 · Billing/payment screens now refresh immediately after a payment, and show what was actually paid

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) ·
[ADR-073](docs/adr/adr-073-billing-cache-invalidation-and-paid-amount-display.md)

#### Fixed
- **2026-09-16** · `frontend` · Ashutosh (AI-assisted) — **The Patient 360 Billing tab and the Command
  Center drawer's PAYMENT tile now refresh immediately after a reassignment, a collected payment, or a
  checkout** — previously each could keep showing pre-payment numbers (a real Credit Note, or a
  just-settled balance, invisible) until something unrelated happened to trigger a refetch.
- **2026-09-16** · `frontend` · Ashutosh (AI-assisted) — The "New Sales Invoice" success screen now
  shows the amount actually paid, not just the total and (if partial) what's still owed.

---

### 2026-09-16 · Reassignment fee increases were undercharging tax; Patient 360 now shows every invoice for an appointment

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) ·
[ADR-072](docs/adr/adr-072-reschedule-delta-invoice-tax-fix-and-invoice-trail-visibility.md) ·
[RESCHEDULE_DELTA_INVOICE_FIX.md](docs/RESCHEDULE_DELTA_INVOICE_FIX.md)

#### Security
- **2026-09-16** · `backend` · Ashutosh (AI-assisted) — **Fixed a real billing-tax bug: reassigning an
  appointment to a higher-fee practitioner was silently undercharging the tax portion of the
  difference.** Verified live: a reassignment meant to collect 1,320 MXN more only collected 1,137.93.
  Going forward only — no historical invoice was recomputed or corrected.

#### Fixed
- **2026-09-16** · `frontend` · Ashutosh (AI-assisted) — **The Patient Chart's appointment card now
  shows every invoice tied to an appointment, not just the original** — a reassignment that raised the
  fee creates its own additional invoice, which was previously visible only in the clinic-wide
  Revenue/Billing hub.

---

### 2026-09-16 · New Sales Invoice's cart lines now show who performed each service and when

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md)

#### Added
- **2026-09-16** · `backend` + `frontend` · Ashutosh (AI-assisted) — **Each cart line in the "New
  Sales Invoice" editor now shows the practitioner who performed/ordered it, and the visit it came
  from** — a booked appointment's date, or a direct/walk-in encounter's own date (clickable through to
  the encounter).

---

### 2026-09-16 · Command Center shows a patient's total pending balance — and a real checkout tax bug is fixed

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-16](WORK_LOG.md) ·
[ADR-071](docs/adr/adr-071-patient-total-pending-and-item-tax-fix.md) ·
[PATIENT_TOTAL_PENDING.md](docs/PATIENT_TOTAL_PENDING.md)

#### Fixed
- **2026-09-16** · `backend` + `frontend` · Ashutosh (AI-assisted) — **The Command Center appointment
  drawer's PAYMENT amount now shows everything still unbilled for the patient across every visit**,
  tax-inclusive, instead of only the current appointment's own fee.
  - **2026-09-16** update — shipped first showing invoiced-outstanding + unbilled combined
    (verified live at MXN 2,718 for a real patient); narrowed on request to show the unbilled amount
    only (MXN 1,580) — an already-invoiced-but-unpaid balance is deliberately not reflected on this
    tile going forward (still visible on the invoice itself and the full billing tab). The backend
    still computes and returns both figures.

#### Security
- **2026-09-16** · `backend` · Ashutosh (AI-assisted) — **Fixed a real billing-tax bug in the
  consolidated checkout endpoint (`create_pos_invoice`): items with a configured tax rate were being
  invoiced at zero tax** when billed through that path, while the same item billed through the manual
  invoice editor charged correctly. Verified live on a real patient invoice before and after. Going
  forward only — no historical invoice was recomputed or corrected.

---

### 2026-09-15 · Clicking a Yearly vaccine's "Next dose" dot no longer fails with a server error

**Author(s):** Ashutosh (AI-assisted) · **Repos:** frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-15](WORK_LOG.md)

#### Fixed
- **2026-09-15** · `frontend` · Ashutosh (AI-assisted) — **Clicking a Yearly vaccine's "Next dose" dot
  (e.g. Td, Influenza) on the Schedule Card or Timeline no longer throws
  `"scheduled_dose_label Next dose is not a dose in template ..."`.** The dot's label was a
  display-only synthetic string, never a real dose on the template, and was being sent to the server
  as if it were one; it is now omitted the same way the "Add immunization" dropdown already handled
  this case. Pre-existing bug, surfaced by today's chart fix making every round's dots directly
  clickable.

---

### 2026-09-15 · Immunization chart now shows every concurrent open round of a vaccine, not just one

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `bug/fix_appointment_booking-issue`
**Related:** [WORK_LOG — 2026-09-15](WORK_LOG.md) ·
[ADR-070 Addendum](docs/adr/adr-070-concurrent-open-vaccine-rounds.md) ·
[IMMUNIZATION_CONCURRENT_ROUNDS.md §5](docs/IMMUNIZATION_CONCURRENT_ROUNDS.md)

#### Fixed
- **2026-09-15** · `backend` · Ashutosh (AI-assisted) — **A patient with two or more concurrent open
  rounds of the same vaccine now has every round reflected on the Immunization chart and the "Add
  immunization" picker**, not just one. Verified live: a patient with 6 Active vaccine assignments
  (2 rounds each of 3 vaccines) was previously shown only 3 on the chart — one round per vaccine, the
  other silently invisible.
- **2026-09-15** · `frontend` · Ashutosh (AI-assisted) — The Schedule Card and Timeline views now show a
  "Round N of M" badge next to a vaccine's name whenever the patient has more than one open round of it,
  so two rows for the same vaccine read as two distinct rounds rather than an unexplained duplicate.
  - **2026-09-15** update — badge removed on request ("keep the design as it is but show the list of
    all vaccine which is assigned to that, do not change the design"). The row markup is unchanged from
    before this entry; only the underlying data fix (every round now returned and rendered) stands.
- **2026-09-15** · `frontend` · Ashutosh (AI-assisted) — The "Add immunization" dialog's round-picker
  ("Which assignment?") now numbers each option ("Round 1 of 2", "Round 2 of 2") instead of showing
  only an assignment date — two rounds opened the same day previously rendered as two identical,
  unpickable-apart options.
- **2026-09-15** · `frontend` · Ashutosh (AI-assisted) — **Clicking a dose's dot on the Schedule Card or
  Timeline no longer asks which round it belongs to** — every dot already belongs to one specific round
  (when the vaccine has 2+ concurrent open rounds), so the dialog now identifies it automatically
  instead of showing the "Which assignment?" picker.
- **2026-09-15** · `backend` + `frontend` · Ashutosh (AI-assisted) — **The "Add immunization" dropdown
  itself now lists every open round of a vaccine as its own entry** (e.g. "Influenza (Overdue) — Round 1
  of 2" and "...Round 2 of 2" as two separate, directly-pickable options), instead of one deduplicated
  entry that still needed a second "which round?" step afterward. Picking an entry now identifies the
  round directly, for the generic "Add immunization" button as well as for a dot click — the manual
  round-picker remains only as a fallback for the (now unreachable in normal use) case where the round
  genuinely can't be inferred.

---

### 2026-09-15 · Re-assigning a vaccine while the prior course is still open no longer merges the two orders

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend ·
**Branch:** `feature/create_notification_on_mark_avilable-and_unavilable`
**Related:** [WORK_LOG — 2026-09-15](WORK_LOG.md) ·
[ADR-070](docs/adr/adr-070-concurrent-open-vaccine-rounds.md) ·
[IMMUNIZATION_CONCURRENT_ROUNDS.md](docs/IMMUNIZATION_CONCURRENT_ROUNDS.md)

#### Fixed
- **2026-09-15** · `backend` · Ashutosh (AI-assisted) — **Assigning a vaccine while the patient's
  existing course of that same vaccine is still open now opens a separate round**, instead of
  silently merging into the open one. A dose recorded later against either round is now always
  attributed correctly; recording one with no way to tell which round it belongs to (more than one
  open round, no round specified) is refused with a clear error instead of guessing.
- **2026-09-15** · `frontend` · Ashutosh (AI-assisted) — The "Add immunization" dialog now asks which
  open round a dose belongs to whenever a patient has more than one open round of the same vaccine —
  previously there was no way to specify this at all.

#### Security
- **2026-09-15** · `backend` · Ashutosh (AI-assisted) — A worklist dose recorded from a nurse's task
  now uses the exact round that task was created for, instead of re-resolving "the" active round for
  the vaccine from scratch — closes a case where a dose could silently attach to the wrong course once
  a patient had two open rounds of the same vaccine, permanently miscounting both.

---

### 2026-09-15 · Admin-practitioner booking no longer fails with "Please enter Practitioner"

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend ·
**Branch:** `feature/create_notification_on_mark_avilable-and_unavilable`
**Related:** [WORK_LOG — 2026-09-15](WORK_LOG.md) ·
[ADR-069](docs/adr/adr-069-admin-practitioner-booking-fixed-via-ignore-permissions.md) (supersedes
[ADR-065](docs/adr/adr-065-admin-practitioner-booking-user-permission-bypass.md)'s implementation)

#### Security
- **2026-09-15** · `backend` · Divyanshu (AI-assisted) — **Booking an appointment for a colleague, as a
  practitioner who also holds an admin role, works again.** ADR-065's fix for this (2026-09-14) withheld
  the `practitioner` value from the write to dodge a Frappe permission check, which broke booking outright
  — core's own mandatory-field check rejected the empty value before the workaround ever got to restore
  it, surfacing as `"Please enter Practitioner"`. The permission bypass this exists for now happens via
  `ignore_permissions=True` on the same insert instead, so the value is never missing.

#### Fixed
- **2026-09-15** · `backend` · Divyanshu (AI-assisted) — Same fix as above, from the booking operator's
  side: a Front Desk/Admin-role doctor naming a different practitioner on a new appointment no longer
  gets a `"Please enter Practitioner"` error. `book_appointment`, `book_appointment_with_payment`, and
  `book_appointment_for_patient` all share the fixed code path.

---

### 2026-09-15 · Availability-declaration notifications now reach every Front Desk and Admin user

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend ·
**Branch:** `feature/create_notification_on_mark_avilable-and_unavilable`
**Related:** [WORK_LOG — 2026-09-15](WORK_LOG.md) · [ADR-062](docs/adr/adr-062-practitioner-self-service-availability.md)

#### Fixed
- **2026-09-15** · `backend` · Divyanshu (AI-assisted) — **A practitioner marking themselves Available or
  Unavailable now notifies every enabled Front Desk and Admin user, not just one.** The task/notification
  used to go to a single person chosen alphabetically by name, which in practice always landed on the
  `Administrator` system account — real Front Desk staff never saw it. Every Front Desk and Admin user now
  gets their own task.

---

### 2026-09-14 · Immunizations is view-only for Front Desk

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Security
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — **Front Desk can no longer record, edit or
  delete a vaccination.** The "Add immunization" button is hidden for that role, clicking a dose on the
  Schedule Card or Timeline no longer opens the Add-immunization dialog, and the Records list drops its
  edit and delete actions. Reception keeps the full schedule card, the Administered / Overdue / Due now /
  Upcoming counters and Print Card, and the tab now carries a "solo lectura" badge and a view-only
  notice. Administering a vaccine is a clinical act, and the backend already refuses the write for
  `EB_Front Desk` — the UI was offering an action that would have been rejected.

#### Changed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The Patient 360 read-only badge and notice
  are translated instead of hardcoded English. They had never rendered for a real user before today, so
  nobody had hit the missing `es-MX` strings.

---

### 2026-09-14 · Encounters: the dead "Open appointment" row action is removed

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Removed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — **"Open appointment" is gone from the
  Encounters row menu.** It always landed on an empty Appointments list: it passed the appointment in a
  `?highlight=` parameter that no screen has ever read, so the list fell back to showing the current
  week, and an encounter's appointment is almost never in the current week. The menu keeps "Open note" /
  "View signed report" and "Open patient chart". An appointment is still reachable from the Appointments
  list by setting its date range.

---

### 2026-09-14 · Register a patient straight from the Dashboard

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Added
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The Dashboard now carries the same
  **Register patient** button as the Patients screen, with the same two routes (Scan form / Manually)
  and the same duplicate-match check. Registering no longer requires navigating to Patients first.

#### Changed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The "Register patient" prompt shown on an
  empty patient list now offers the scanner as well as the manual form, instead of the manual form only.

---

### 2026-09-14 · Only a document's owner can change who it is shared with

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Security
- **2026-09-14** · `backend` · Anant Sharma (AI-assisted) — **A person a document was shared with can no
  longer share it onward.** Narzim Drive's Share button is only offered to the owner, and one of the two
  sharing endpoints already enforced that — but `drive.share` did not, and it is reachable directly. A
  recipient could add other staff, or open a document to the whole team, without the owner knowing.
  Both endpoints now require the same owner-level permission. Sharing at the point of creating or
  editing your own document is unchanged.
- **2026-09-14** · `backend` · Anant Sharma (AI-assisted) — Added tests covering the above: a recipient
  cannot re-share, cannot widen to the team, and an owner still can.

---

### 2026-09-14 · Narzim Drive: a file inside a folder can be moved back out again

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Fixed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — In Narzim Drive, "Move to" now offers
  **All Documents** alongside the folders, so a file filed into a folder can be moved back to the top
  level. Previously the menu listed folders only, and there was no way out of a folder at all. The same
  option was added to the bulk "Move to folder" dialog.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — "Move to" no longer offers the folder the
  file is already in, which did nothing when chosen.

---

### 2026-09-14 · Patients header: fewer buttons, each one saying what it is doing

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Changed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — On the Patients screen, "Register patient"
  and "Scan form" are now one button. "Register patient" opens a short menu offering **Scan form** or
  **Manually**; both lead to the same registration drawer, as they always did.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The four date buttons (Today, This Week,
  This Month, Custom range) are now one button that names the filter currently in force and opens those
  same four choices. Only the Patients screen changes; Appointments, Encounters, Billing and the report
  pages keep the button row.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The List / Report toggle is now one button
  naming the view you are on, with both choices in a menu.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — Removed the standalone "Registered" caption
  beside the date filter.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The date filter button now sits beside the
  view button, after the search box, so the two controls that decide what you are looking at are
  together.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The same date filter button now replaces the
  four preset buttons on Appointments, Encounters and Billing, so all four list screens carry the same
  control. On Appointments it also sits beside the view button, and the List / Report toggle there
  became a single button naming the view you are on, as on Patients.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — Removed the standalone "Encounter date"
  caption on the Encounters header, as with "Registered" on Patients.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — On Encounters and Billing the date filter
  button moved to the right of the search box, so it sits beside the action buttons rather than leading
  the header. All four list screens now put it in the same place.

---

### 2026-09-14 · Report cards now open the list filtered by the practitioner they counted

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/ui-fixes`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md)

#### Fixed
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — On the Patients and Appointments screens,
  picking a healthcare practitioner in the report panel and then clicking one of its cards opened the
  whole clinic's list instead of that practitioner's. The figures were right; only the list behind them
  ignored the practitioner. Clicking "Total Patients 42" for one doctor now opens 42 rows, not all 660.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — On Patients, filtering the list by the
  Primary Practitioner column and then opening the report made every figure read zero. The column holds
  a practitioner's display name and the report needed their record id, so nothing matched.
- **2026-09-14** · `frontend` · Anant Sharma (AI-assisted) — The "seen in period" chip on the Patients
  list now names the practitioner it is filtering by, instead of showing only a date range while the
  rows behind it were one doctor's.

---

### 2026-09-14 · A blocked "mark myself unavailable" no longer dead-ends — Front Desk gets a task instead

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md) · [ADR-062 decision 12](docs/adr/adr-062-practitioner-self-service-availability.md) · Jira NH-123

#### Added
- **2026-09-14** · `backend` + `frontend` · Sarvesh-SocialAngel (AI-assisted) — When a doctor tries to mark
  themselves unavailable over a time that already has patients booked, the screen now shows exactly which
  appointments conflict and offers a "Create task" button — clicking it puts a task in Front Desk's list,
  with the doctor's stated reason, so someone actually goes and reassigns those patients. Previously this
  just showed an error and nothing else happened.
- **2026-09-14** · `backend` · Sarvesh-SocialAngel (AI-assisted) — When a doctor successfully declares new
  available time, or marks themselves unavailable with nothing to reassign, Front Desk now gets a task
  automatically — no button needed, since there's nothing to review first. Saving the identical declaration
  twice does not create a second task.
  - **2026-09-14** update (Divyanshu, AI-assisted) — Corrected the same day: what's created is now a
    proper **My Work task** (a `ToDo`, unassigned and claimable), not the internal "Task" record the first
    version used, which nobody's task list actually reads. The "Create task" button (conflict case) now
    opens the real My Work task-creation panel, pre-filled with the conflicting appointments, the doctor's
    name and ID, the reason, and a due date — not a separate lookalike. The automatic case (no conflict)
    now **also notifies Admin**, not Front Desk alone, and the notification's "Open" link goes to a real
    task waiting in My Work rather than nowhere.
  - **2026-09-14** update (Divyanshu, AI-assisted) — Added: a practitioner can no longer mark himself
    Available or Unavailable for a date that has already passed (checked both on the form and on save).
    Added: if a practitioner opens up Available time and a patient gets booked into it, he can no longer
    delete that declaration until the appointment is reassigned, rescheduled, or cancelled.

#### Fixed
- **2026-09-14** · `backend` · Divyanshu (AI-assisted) — Some in-app notifications (including the ones
  above) were silently not arriving, with no visible error — traced to a delivery-timing issue that only
  showed up when a save happened right before the notification; fixed for this feature's notifications.
- **2026-09-14** · `backend` · Divyanshu (AI-assisted) — The Notifications page was failing to load at all,
  for every user, with "Could not load notifications" — an unrelated pre-existing bug (a query asking for a
  database column that was never there) found and fixed while checking the above.

---

### 2026-09-14 · A doctor who is also an admin can now book an appointment for another practitioner

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-14](WORK_LOG.md) · [ADR-065](docs/adr/adr-065-admin-practitioner-booking-user-permission-bypass.md) · Jira NH-118

#### Fixed
- **2026-09-14** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Booking a Patient Appointment and
  naming a different doctor as the practitioner no longer fails with a permission error for a user who
  holds both a practitioner role and an admin role. The app's own booking logic already intended to
  allow this; a separate, framework-level restriction (the same one that correctly stops a plain doctor
  from naming a colleague) was rejecting it regardless of the admin role. A plain doctor's booking
  behavior is unchanged.

#### Security
- **2026-09-14** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The fix reuses the same restricted
  write pattern already used for reassigning an existing appointment's doctor (ADR-018), rather than
  waiving every permission check on the booking — the bypass is scoped to the one field it concerns,
  and every such override now writes one log line (appointment, target practitioner, acting user — no
  patient data) so it can be reconstructed later.
  ([why not a blanket bypass](docs/adr/adr-065-admin-practitioner-booking-user-permission-bypass.md))

---

### 2026-09-22 · Claude now asks before changing code or git state, and writes a doc + ADR before non-trivial work

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-22](WORK_LOG.md) · [ADR-065](docs/adr/adr-065-permission-before-changes-and-docs-before-work.md) · [docs/planning/CLAUDE_PERMISSION_POLICY.md](docs/planning/CLAUDE_PERMISSION_POLICY.md)

#### Added
- **2026-09-22** · `backend` · Divyanshu (AI-assisted) — `CLAUDE.md` §10 gained a new hard rule: no
  code, config, or git-state change lands without an explicit go-ahead on a stated plan (once per
  task, not once per step), and any non-trivial task gets a markdown doc and an ADR written before
  implementation starts, not after.

### 2026-09-12 · The encounter assistant now looks up allergies and current medications instead of recalling them

**Author(s):** Gaurav (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-030](docs/adr/adr-030-llm-curated-tool-access.md)

#### Added
- **2026-09-12** · `backend` · Gaurav (AI-assisted) — Asked whether a drug is safe for a patient, or
  what they are already taking, the encounter assistant now reads the chart and the patient's earlier
  signed visits rather than answering from what the model already had in front of it. Each medication
  it reports names the visit it was prescribed at, so a clinician can check the answer against the
  record instead of taking it on trust.
- **2026-09-12** · `backend` · Gaurav (AI-assisted) — When nothing is recorded, the assistant is now
  required to say that nothing is recorded. An empty allergy field is not the same statement as "no
  known allergies" — a chart nobody has filled in looks identical to a chart with nothing to report,
  and only one of the two is safe to prescribe against.
- **2026-09-12** · `backend` · Gaurav (AI-assisted) — 16 tests covering both lookups, including that
  an unsigned draft prescription is never reported as something the patient is taking, that the
  current visit's own draft is not read back as history, and that the reads stay bounded.

#### Security
- **2026-09-12** · `backend` · Gaurav (AI-assisted) — Both lookups run through the permission-checked
  path, so they can only return visits the person asking is already allowed to open. An earlier draft
  of this work queried the prescriptions table directly, which would have returned rows for every
  patient on the site regardless of who was asking; that approach was dropped before it was committed.
- **2026-09-12** · `backend` · Gaurav (AI-assisted) — The lookups were added to the assistant's existing
  curated tool set rather than by installing a second one. The alternative considered — exposing them
  through Frappe Assistant Core — would have put an AGPL-3.0 dependency in a path carrying patient data
  and split the audit trail across two logs, so "who asked what about which patient" would have needed
  two queries to answer. ([why the curated set is the only tool surface](docs/adr/adr-030-llm-curated-tool-access.md))

---

### 2026-09-12 · Command Center's insight panel rebranded as "Nova Insights"

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3w](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Changed
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — The Command Center's operations summary
  panel now shows a "Nova Insights" badge instead of a generic alert icon, matching the AI persona
  branding already used on the AI Workforce screens.

---

### 2026-09-12 · Fixed: the operations summary could show a practitioner the whole clinic's data instead of just their own

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3v](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Security
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The operations summary now determines
  whose appointments to count from the same server-verified permission check the patient board
  already uses, instead of trusting a role claim supplied by the request. Previously, a practitioner
  whose own board correctly showed only their own patients could still be shown a summary describing
  the entire clinic's numbers.

---

### 2026-09-12 · Fixed a stuck-"Refreshing" bug; the summary generates on click only again

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend + backend (docstring only) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3u](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Fixed
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — Traced a "stuck on Refreshing…" report to
  its real cause: the project folder syncing with OneDrive was causing the dev server to rebuild
  itself unprompted, occasionally stranding an in-flight request. A separate, unrelated issue
  (duplicate dev-server processes) was found and fixed along the way.

#### Changed
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — The operations summary now generates only
  when the user clicks Refresh, reverting the automatic page-load fetch added earlier — reduces
  exposure to the OneDrive-related issue above until the environment problem itself is resolved.

---

### 2026-09-12 · Real loading feedback while the operations summary generates; Nurse gets the practitioner filter

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend + backend (prompt text only) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3t](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — The Command Center's operations summary
  now shows "Generating today's insights…" while it loads, instead of a stale, no-longer-accurate
  placeholder that gave no sense anything was happening.
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — Nurse now gets the same "filter by
  practitioner" dropdown Front Desk and Admin already had.

#### Changed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The operations summary now spends fewer
  words stating the underlying number and more on the recommendation — the fact justifies the
  action, the action is what matters.

---

### 2026-09-12 · Command Center's operations summary now appears automatically on page load

**Author(s):** Divyanshu (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3s](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `frontend` · Divyanshu (AI-assisted) — The Command Center's operations summary
  now generates automatically the first time the page loads, instead of waiting for the user to
  click Refresh. Every update after that still requires a manual click, unchanged.

---

### 2026-09-12 · Shorter, denser summary for accounts holding several roles at once

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3r](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Changed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — For an account holding several roles at
  once (e.g. Admin + Nurse + Front Desk), the summary now merges facts about the same room into one
  clause and avoids repeating a staffing recommendation twice, instead of reading as a long chain of
  separate sentences. Wording only — every underlying fact and number is unchanged.

---

### 2026-09-12 · Pace suggestions now project an actual finish time, not just minutes-per-patient

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3q](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — Admin/Nurse/Front Desk's pace suggestions
  now also state a projected clock-time finish and how many minutes later than planned that is
  (e.g. "projected to finish around 9:27 PM, 3hr later than planned"), alongside the existing
  minutes-per-remaining-patient figure. A deliberately smaller scope than a reference design shared
  for this change — no severity/urgency label was added, only the planning-relevant number.

---

### 2026-09-12 · Fixed: a smaller room could silently suppress the busiest room's own slowdown suggestion

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3p](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Fixed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The "busiest room is also running slow"
  suggestion (shipped earlier the same day) required that room to also be the single worst-ratio
  room on the whole board — so a much smaller room with a more extreme ratio could silently
  suppress a real, clearly elevated signal on the room actually affecting the most patients. Now
  checks the busiest room's own numbers directly; the suggestion also states the actual live-vs-
  historical comparison, not just a bare recommendation.

---

### 2026-09-12 · "Busiest and slower than usual" room now suggests reviewing staffing

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3o](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — For Admin, when a room is both the busiest
  on the board and running slower than its own historical average at the same time, the summary now
  suggests reviewing staffing or coverage for that room — a real decision, not a restated count.
  Never fires from a plain patient count alone.

---

### 2026-09-12 · A room running slower than usual now tells staff what to actually do about it

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3n](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — When a room is running slower than its own
  historical average, the summary now also says whether the next stage of the visit is free right
  now or occupied too — a real next step ("this may need attention at that stage's own capacity"),
  not just a restated duration.

#### Fixed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — That same "room running slow" fact was
  previously dropped from the summary entirely whenever any other fact was also true (the normal
  case on a busy board) — it only ever appeared as a last-resort fallback. It is now covered
  whenever it's true, same as every other fact.

---

### 2026-09-12 · Checkout no longer flagged as "overdue" in the queue-tips summary

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3m](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Changed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — Admin's "most overdue" and "N appointments
  delayed, review staffing" facts no longer count Checkout — a Checkout appointment's long wait is
  structural (the patient has already been fully seen), not a real delay, so it no longer prompts a
  staffing review it doesn't need. Checkout's real signal, pending payment, was already covered by
  the existing `payment_pending_count` fact and is unchanged.

---

### 2026-09-12 · Nurse's "vitals not recorded" summary now says who's waited longest, not just how many

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3l](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The queue-tips summary's "N patients in
  Nursing Room still need vitals" fact now also states the longest current wait among them, so a
  Nurse has a "see this one first" signal instead of just a repeated count. Never names a patient.

#### Security
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — Documented a live-confirmed data-integrity
  issue found while building the above (`docs/KNOWN_ISSUES.md`): abandoned Queue Stage Log rows are
  never closed, so a stale prior-day row can be misread as an hours-long wait by code that doesn't
  independently re-apply the existing today-only date filter. `regenerate_queue_tips` itself already
  applies that filter and is unaffected; this is a recorded gap, not a new defect shipped here.

---

### 2026-09-12 · Queue-tips summary now warns Admin, Nurse, and Front Desk when today's pace won't cover every appointment

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-064 §3k](docs/adr/adr-064-queue-tips-llm-summary.md) · [OPERATIONAL_SUGGESTIONS.md §3.3](docs/OPERATIONAL_SUGGESTIONS.md)

#### Added
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The AI-phrased queue-tips summary now tells
  Admin (clinic-wide, Practitioner Room throughput), Nurse (Nursing Room throughput only), and Front
  Desk (check-in throughput only) when today's actual pace projects short of covering every booked
  appointment, and roughly how many minutes to spend on each of the remaining ones to still cover
  them all — the same mid-day pace check a practitioner's own workload suggestion already had,
  generalized to the other three roles. The "how much time is left" figure needed for this is derived
  from the scheduled end of the last actually-booked appointment of the day, not a new setting — this
  app has no clinic/role "operating hours" concept to configure one from.
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — The practitioner's own existing pace
  suggestion (`get_my_workload_suggestion`) gained the same "about this many minutes on each remaining
  one" figure, which it did not previously state explicitly.

#### Changed
- **2026-09-12** · `backend` · Divyanshu (AI-assisted) — `_pace_fact` moved from
  `api/v1/providers/api.py` (private, single-caller) to `services/queue_stage_log.py` (shared, as
  `pace_fact`) now that a second caller needs the identical judgment. No behavior change; every
  existing call site and test keeps working via `pace_fact as _pace_fact`.

---

### 2026-09-11 · Automated test coverage restored for the AI queue-tips and workload-suggestion features

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-11** · `backend` · Divyanshu (AI-assisted) — Rebuilt the three test files covering the
  AI-phrased queue-tips summary, the Queue Stage Log room-timing service, and the practitioner
  workload suggestion (89 tests), after they were found missing from disk. Closes the "no automated
  test" gap noted in ADR-064 since v1.9.

---

### 2026-09-11 · Queue-tips summary now warns when a booked appointment's doctor isn't available

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Added
- **2026-09-11** · `backend` · Divyanshu (AI-assisted) — The AI summary now tells Front Desk, Nurses,
  and Admins when one or more of today's appointments are booked with a practitioner who has since
  become unavailable (an approved day off, or a declared unavailable window) — exactly the situation
  that needs a doctor reassigned. States only how many, never which patient or doctor by name; staff
  decide who to move it to.

---

### 2026-09-11 · Queue-tips summary now shows long waits in hours, not just raw minutes

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md)

#### Changed
- **2026-09-11** · `backend` · Divyanshu (AI-assisted) — A wait or delay longer than an hour now reads
  as "8hr 10min" in the AI-phrased summary, matching how the same figure already appears on the
  queue card itself, instead of a raw minute count like "490 minutes."

---

### 2026-09-10 · A practitioner's extra-hours slot length now matches the type of visit being booked

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-062 decision 11](docs/adr/adr-062-practitioner-self-service-availability.md) · [docs/PRACTITIONER_AVAILABILITY.md §4](docs/PRACTITIONER_AVAILABILITY.md)

#### Changed
- **2026-09-10** · `backend` + `frontend` · Divyanshu (AI-assisted) — When booking or reassigning into a
  practitioner's self-declared extra-availability hours, the length of each bookable slot now matches the
  specific appointment type being booked (e.g. a quick follow-up gets shorter slots than a new-patient
  consultation) instead of always using one clinic-wide default. Falls back to that same clinic-wide
  default exactly as before when no appointment type is known.

---

### 2026-09-10 · A practitioner's extra-hours slot length now follows clinic settings, not a hardcoded number

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [ADR-062 decision 10](docs/adr/adr-062-practitioner-self-service-availability.md) · [docs/PRACTITIONER_AVAILABILITY.md §4](docs/PRACTITIONER_AVAILABILITY.md)

#### Fixed
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — Extra bookable slots generated from a
  practitioner's self-declared "Available" hours were always chopped into 20-minute blocks, regardless
  of clinic configuration. They now use the clinic's actual configured appointment length, read fresh on
  every request instead of frozen at a private constant. Found while a practitioner's evening
  availability, added beyond their normal schedule, showed a different — and unexplained — time
  granularity than their normal-schedule morning slots on the same booking screen.

---

### 2026-09-10 · Live Queue tips now show real live data, with an optional LLM-phrased summary

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md) · [ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md) · [docs/OPERATIONAL_SUGGESTIONS.md](docs/OPERATIONAL_SUGGESTIONS.md)

#### Added
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — The Live Queue tips panel can now show how long a
  card has actually been in its current room right now, compared against that room's own historical
  average — previously it only had coarser figures. A new endpoint computes this and, only when a user
  clicks a button (never automatically), asks the configured AI provider to phrase one short summary
  sentence from those numbers — the AI never decides what to show, only how to word it.
  - **2026-09-10** update — This summary now genuinely differs by who's looking: an Admin, a Nurse, and
    Front Desk each get different facts emphasized, and a role with nothing relevant (e.g. Practitioner)
    gets no summary at all — the AI isn't even called for them.
  - **2026-09-10** update — The summary can now also say when a room sits idle while another is backed
    up, and how late a specific appointment is running against its originally booked time — each shown
    only to the role that can actually do something about it (a Nurse sees the one room-move they can
    make; Front Desk sees only the rooms they can reassign out of; an Admin sees the whole board). Never
    a "this room is too crowded" verdict — just the plain fact that one room is empty while another
    isn't ([ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md)).
  - **2026-09-10** update — The summary now also says what to do about a fact, not just states it —
    e.g. "move a patient into Nursing Room," "record their vitals," "collect the pending payment." A
    Nurse is also now told when a Nursing Room patient still needs vitals recorded. Every suggested
    next step is fixed and operational (never a clinical one) — nothing here clicks anything itself.
  - **2026-09-10** update — A Nurse can now also see when a patient has been with the practitioner
    longer than usual. A person holding more than one role (e.g. Nurse and Front Desk) now sees
    facts from every one of their roles, not just one. Also fixed: an empty-room suggestion could
    previously recommend moving a patient across several stages at once (e.g. straight from Arriving
    Soon to Checkout) — it now only ever suggests a move between two directly adjacent stages.
  - **2026-09-10** update — A Nurse (and now the practitioner too, on their own patients only) is
    told when a patient's vitals are already recorded but they've still been waiting in Nursing Room
    much longer than usual — ready to move on, not just sitting there.
  - **2026-09-10** update — The summary now covers everything that's actually true at once instead of
    only the single most pressing thing — e.g. an empty room, a very overdue appointment, and a
    staffing note can all appear together when all three are real, instead of two of the three being
    silently dropped.
  - **2026-09-10** update — A Practitioner logging in now sees a summary too, about their own
    patients only across the whole day's queue — previously they saw nothing at all here.
  - **2026-09-10** update — A slower-than-usual (but genuinely successful) refresh no longer shows a
    false "couldn't refresh" message — the wait allowed before giving up was raised from 20 to 40
    seconds, after a real call was confirmed taking just over 20.
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — A practitioner can now see, on request, whether
  today's appointment load leaves them with real spare time against their actual scheduled hours — informational
  only, they decide what to do with it. The originally requested cross-clinic version of this ("you have
  fewer patients at this clinic than the other") was not built — this deployment has no working way to
  represent one practitioner across two clinics yet ([ADR-064](docs/adr/adr-064-queue-tips-llm-summary.md)).
  - **2026-09-10** update — This can now also warn mid-day, using what has actually happened so far
    today (not just the morning forecast) — e.g. "you've completed 2 in 2 hours, 8 remain, you may be
    running long." Works even on a day with no prior history at all, which previously showed nothing.
  - **2026-09-10** update — A practitioner can now also be told, on their own patients only, when one
    of them already has vitals recorded but has been waiting in Nursing Room much longer than usual —
    ready and waiting for them specifically, never about another practitioner's patients.
- **2026-09-10** · `frontend` · Divyanshu (AI-assisted) — The Live Queue tips panel now collapses to one
  line, with a button that refreshes it with live numbers and expands to show the full detail.
  - **2026-09-10** update — Replaced the same day: no more pill badges or an expandable detail list — just
    one plain-text line, moved into the header row itself (between the screen title and the search box)
    instead of its own row below it.

#### Fixed
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — The live summary sentence sometimes read the raw
  code name of a room ("waiting_room") instead of its real name ("Waiting Room"). Fixed; covered by a test.
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — Caught live, before anyone else saw it: the
  empty-room suggestion could recommend moving a patient from Arriving Soon straight to Checkout,
  skipping four real stages of the visit. It now only ever suggests a move between two stages that
  are actually next to each other in the real patient flow.
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — The summary was silently showing only the single
  most pressing thing even when several were true at once — e.g. an empty room and a very overdue
  appointment happening together would only ever mention one. It now covers everything that applies.
- **2026-09-10** · `frontend` · Divyanshu (AI-assisted) — The queue-summary line was cut off with "…"
  after one line, hiding most of a longer summary. It now wraps and shows in full.
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — The summary could name a room as badly
  overdue (e.g. "Waiting Room, 1381 minutes") when that room was actually empty on the board. Root
  cause was a leftover record from a previous day that was never cleaned up — the summary now only
  ever looks at today's activity, matching what the board itself already shows.

#### Security
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — Both new AI calls above receive only room names,
  counts, and minutes — never a patient's name, and never a raw record. Confirmed by an automated test that
  checks the exact set of fields sent, not just spot-checked by eye.
  - **2026-09-10** update — **Every single call to either new feature had been silently failing to write its
    required audit-log entry** since the day this shipped: the log doctype's allowed-purpose list was never
    updated to include the two new call types, so each attempt raised a validation error that was caught and
    swallowed (by design, so the feature itself never broke) — meaning the AI calls were working, but leaving
    **no audit trail at all**. Fixed; confirmed the fix took effect on the live database.

### 2026-09-10 · A manually-refunded visit no longer counts as still paid for the next reschedule

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Fixed
- **2026-09-10** · `backend` · Divyanshu (AI-assisted) — When a visit's payment was refunded through the plain billing-page refund action (not through reassign/reschedule), the system had no way to know that refund happened — it kept treating the visit as still fully paid. If that visit were later reassigned or rescheduled, the next charge or refund would have been calculated against money the patient no longer actually held. Fixed so any refund is recognized, however it was issued.

---

### 2026-09-09 · Three fixes from live testing: reassign button, room timing, payment total

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — Front desk and nurse can now reassign a visit's doctor from a Nursing Room card — the button was silently missing there for anyone but a nurse.
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Moving a visit between rooms (check-in, confirm, cancel) now correctly updates its per-room timing record — previously the record could get stuck showing the wrong room indefinitely.
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — The "Paid" amount shown on a visit no longer includes money that was later refunded, after a doctor change was reversed.
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — An extra invoice raised for a doctor-change payment top-up no longer shows a large, fabricated "discount" on the printed invoice — the total charged was always correct, only the line-item breakdown was misleading.

---

### 2026-09-09 · Reassigning for an emergency now lets you waive the fee increase

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063 §1.8](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — When reassigning a visit to a doctor who charges more, you can now check "Keep the original fee" so the patient is never asked to pay the difference — useful when the reassignment is the clinic's decision (e.g. the original, cheaper doctor became unavailable), not the patient's.

---

### 2026-09-09 · Reassigning to a different-fee doctor is now allowed — you'll be asked to settle the difference

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063 §1.6](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` + `frontend` · Divyanshu (AI-assisted) — Reassigning a visit to a doctor who charges a different consultation fee is no longer blocked. If the new doctor's fee is higher or lower, you're shown the difference and can collect the extra amount now or later, or the refund is issued immediately — the same choice already offered when rescheduling a visit.
  - **2026-09-09** update — The doctor list no longer shows a "Fee differs" hint next to a name before you pick them; the fee is shown once, after you've picked a doctor and a time, same as before.

---

### 2026-09-09 · Reassigning a visit now lets you pick a doctor and a real open time together

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063 §1.5](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` + `frontend` · Divyanshu (AI-assisted) — Reassigning a visit to a different doctor now shows that doctor's real open times for the day and lets you pick one, instead of only offering the exact same time slot. Only doctors who charge the same consultation fee are offered, so this never creates an unexpected charge or refund.

#### Fixed
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Rescheduling a visit to a new doctor and time together now checks that the new doctor can actually take it (not on leave, not marked unavailable) — previously only a plain reschedule (same doctor) checked this.

---

### 2026-09-09 · The reassign picker now shows who's actually free before you pick

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063 §1.4](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` + `frontend` · Divyanshu (AI-assisted) — The reassign-practitioner picker now shows, next to each doctor's name, whether they can actually take this visit's exact time slot — and why not, when they can't (on leave, marked unavailable, or already booked). Previously this was only discoverable after picking a name and clicking Reassign.

---

### 2026-09-09 · Reassigning a practitioner now keeps the record's heading correct and checks the new practitioner's slot

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [ADR-063 §1.3](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Reassigning an appointment to a new practitioner no longer leaves the old practitioner's name in the record's title/heading forever afterward.
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Reassigning to a new practitioner now checks that they can actually take the slot — blocked if they've declared themselves unavailable, are on holiday/leave, or already have a different patient booked at that exact time. Previously none of this was checked at all. ([why](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md))

---

### 2026-09-09 · Clinical Command Center (formerly Live Queue): reassignment, per-room time tracking, tips, rename

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [CLINICAL_COMMAND_CENTER.md](docs/CLINICAL_COMMAND_CENTER.md)

#### Added
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Every visit's time in each of the five Clinical Command Center rooms (Arriving Soon, Waiting Room, Nursing Room, Practitioner Room, Checkout) is now recorded for reporting, via a new `Queue Stage Log` and a new "Queue Stage Breakdown" report — verified with 8 passing tests against the live database. ([why a new table instead of a child table on the appointment](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md))
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — Clicking a practitioner's name on a queue card in Arriving Soon, Waiting Room, or Nursing Room now offers reassigning the visit to another practitioner, with a confirmation step. Still fully blocked once a doctor's notes exist for that visit, unchanged from before.
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — The Clinical Command Center board now shows short, role-specific tips (e.g. the longest-waiting patient right now, how many arriving patients still owe payment) computed from data already on screen.
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — A new "Queue Stage Breakdown" report, alongside the existing Queue Wait Times report, shows average and median time per room, filterable to a single room.

#### Changed
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — "Live Queue" is now labelled "Clinical Command Center" throughout. ([the naming overlap with the existing, separate admin Command Centre tab was a knowingly accepted tradeoff](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md))

---

### 2026-09-09 · Clinical Command Center design: ADR-063 + mechanism doc

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend (docs only) · **Branch:** `dev`
**Related:** [ADR-063](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md) · [CLINICAL_COMMAND_CENTER.md](docs/CLINICAL_COMMAND_CENTER.md)

#### Added
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Filed the design for the Live Queue's four requested changes — inline practitioner reassignment, per-room time tracking for reporting, role-based dashboard tips, and a rename to "Clinical Command Center" — as an ADR plus a build-order checklist. No code yet. ([detail](docs/adr/adr-063-clinical-command-center-reassign-and-stage-logging.md))

---
### 2026-09-12 · Appointment Report — drilling a card now lands on the report's period

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Fixed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — Clicking a figure in the Appointment Report now opens the appointment list for **the period the report was showing**. Previously the list kept whatever period it had been on, so switching the report to This Month and clicking "13 appointments" returned a list still filtered to This Week — a handful of rows under a number that had counted the whole month. The matching period button lights up, and the same correction applies to the Cancelled and No show figures.

---

### 2026-09-12 · Appointment Report drawer — Needs attention removed, footer link renamed

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Removed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — The **Needs attention** block (Stuck in a state · Unsigned encounters · Checked out, unpaid) no longer appears in the Appointment Report drawer, on request. It is unchanged on the Patient Demographics report.

#### Changed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — The link at the bottom of the Appointment Report drawer now reads **View full report** instead of "Appointments", which said nothing on a screen already called Appointments. It opens the same full Patient Flow report it always did, carrying the period and practitioner you were looking at.

---

### 2026-09-12 · Billing — patient photos broken in the New Sales Invoice picker

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Fixed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — Patient photos now appear in the **New Sales Invoice** patient search and on the selected patient, instead of a broken-image icon. Patients without a photo were unaffected throughout — they show a letter circle — which is why only some rows looked wrong. Fixed in both the billing drawer and the full-page `/billing/invoices/new` version of the same screen.

---

### 2026-09-12 · Narzim Drive — Copy link removed from the share dialog

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Removed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — The **Copy link** button is gone from the Narzim Drive share dialog, on request. Sharing is unchanged: pick colleagues from the list and press Done. Access was never granted by holding a link — a recipient still needs to be on the access list — so nothing about who can open a document changes.

---

### 2026-09-12 · Narzim Drive — sidebar link did nothing inside a folder

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Fixed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — Clicking **Narzim Drive** in the sidebar while inside a folder now returns to the top of the drive. It previously did nothing at all, leaving you in the folder with no indication the click had registered.

#### Changed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — The folder you have open in Narzim Drive is now part of the page address, so a folder can be bookmarked or shared as a link, and the browser's Back button steps out of a folder instead of leaving the drive entirely.

---

### 2026-09-12 · Narzim Drive — moving a damaged document failed silently

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md)

#### Fixed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — Actions in Documents (move to folder, rename, delete a folder) now report when they fail. Previously a failure did nothing visible at all: the document stayed where it was with no message, and the only sign anything had happened was an error in the browser's network tab.
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — Error messages from the server are now shown as written instead of being replaced with a generic "Failed to …", so an explanation like "its stored file is missing" reaches the person who needs it.
- **2026-09-12** · `backend` · Anant Sharma (AI-assisted) — Moving a document whose stored file is missing is now refused with an explanation saying the document is damaged and cannot be previewed or downloaded either. Frappe Drive reported every such failure with the same fixed sentence regardless of cause and named no document.

---

### 2026-09-12 · Practitioner filter on the Appointments list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-018](docs/adr/)

#### Security
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — A doctor who can only see their own appointments no longer sees the whole clinic's roster in the Appointments list's **Practitioner** column filter. The column now shows a plain, non-clickable heading explaining that only their own appointments are visible — matching what the Calendar view has always done. Previously the dropdown listed every colleague by name and, because these users' rows are already fixed to themselves, ticking a name changed nothing while still turning the heading amber and showing a count, so it read as a filter that had been applied.

---

### 2026-09-11 · Patient Reports drawer on the Appointments and Patients lists

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `fix/list-avatars-and-mrn-columns`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md)

#### Added
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Appointments and Patients screens now have a **List / Report** toggle. Selecting Report opens that screen's report in a side drawer over the list — clinic activity on Appointments, the patient registry on Patients — using the same date range and practitioner filter the list was showing, and stating that scope in words so its totals cannot be mistaken for the list's row count. The list stays put behind the drawer, so closing it returns to exactly the rows you were on.
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — New **Patient Panel** report describing the patient registry: totals, new and seen patients, patients with an upcoming appointment, and patients not seen in over 12 months, plus breakdowns by pediatric age band, gender, last visit, visit frequency and practitioner. It also reports how many patients have never been seen and how many are missing a date of birth.
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — Reports can now be narrowed by patient gender and record status, which the Patients list already filtered by.

#### Added
- **2026-09-11** · `docs` · Anant Sharma (AI-assisted) — New [data-flow document](docs/patient-report/DATA_FLOW.md) for the report views: the seven hops from the browser to the database, which doctype and field feeds every card and chart on both reports, who is allowed to see what, and how to add a new card without it silently rendering a raw key.

#### Added
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — Each report is now named for what it shows — **Appointment Report** on Appointments, **Patient Report** on Patients — and both open on **This Month**. A list already showing this month lights the This Month button rather than an anonymous custom range.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — A filter applied by clicking a report card now stays in the address bar, so opening a record and pressing Back returns to the same filtered list instead of an unfiltered one. On both screens.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — Both reports now carry their own filters — **Today · This Week · This Month · This Quarter · This Year**, a practitioner selector and a custom date range. They open matching whatever the list was filtered to, and can then be changed without disturbing the list behind them, so asking "how did this quarter go" no longer costs you your place in the list.

#### Changed
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — Report cards are now clickable. Clicking one filters the list behind the drawer and closes it: Total Appointments clears the status filter, No-show Rate filters to No Show, Total Patients clears the filters, New Patients sets the registration window, and Active Patients sets the visit window to the last 12 months. Completed is the one card that navigates — to the **encounters** list, where its records actually live. Capacity Used and Lapsed stay non-interactive: there is no list of schedule slots, and no "not seen since" filter. ([how](docs/patient-report/DATA_FLOW.md))
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — **Active Patients** now means *seen at least once in the last 12 months*, not "the record is enabled". On the current database that changes the figure from 659 to 58, and it is the honest one: every patient record is marked enabled while only 58 have ever attended. Active, Lapsed and Never-seen now add up to the total and agree with the Last Visit chart. ([spec](docs/patient-report/PATIENT_PAGE_REPORT.md))
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The report view shows exactly four cards, then charts: Total · New · Active · Lapsed on Patients, and Total Appointments · Cancelled · Checkout · No Show on Appointments — all four clickable. The other figures each report returns are on the full report page rather than stacked above the charts.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Appointments report now shows clinic activity in full — the booked → checked-in → in-consultation → completed funnel, appointments by hour, outcomes, new vs returning, wait-time buckets, average wait by hour, reschedule timing and outcome, and a needs-attention count for appointments stuck in a state, unsigned encounters and checked-out-but-unpaid visits. The other report sections keep their own pages under Reports. ([spec](docs/patient-report/APPOINTMENT_PAGE_REPORT.md))

#### Removed
- **2026-09-12** · `frontend` · Anant Sharma (AI-assisted) — The Appointment report no longer shows **Wait Times** or **Average Wait by Hour**. Neither could show anything: a wait needs both a check-in time and a consultation start recorded against the same appointment, and no appointment currently has both — so one card showed four permanent zeros and the other drew nothing. They can come back once check-in times are being captured.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Patients report no longer shows the **Patients by Practitioner** or **Registrations** charts; it now shows age distribution, last visit, gender and visits per patient. The figures are still produced by the server, so either chart can be brought back. ([spec](docs/patient-report/PATIENT_PAGE_REPORT.md))
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The **+ New** (new encounter) button has been removed from the Encounters list toolbar. Starting an encounter from the patient's chart is unchanged, and that remains the way to begin one; the blank new-encounter form is no longer linked from anywhere.

#### Fixed
- **2026-09-11** · `backend` + `frontend` · Anant Sharma (AI-assisted) — Clicking **Active Patients** showed more patients than the card counted (58 on the card, 102 in the list). The card counts patients the clinic actually saw; the list was counting everyone with an appointment on the calendar, cancellations and no-shows included. The list can now be narrowed to attended visits, and the card opens exactly the people it counted.
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — A patient's age, last-visit recency and lapsed status are now measured as of today rather than as of the end of the selected reporting period. Choosing a wider period previously made patients look older and their last visit look months further in the past than it was.
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — The patients-per-practitioner breakdown counts patients rather than appointments, so a patient with several visits to the same doctor is no longer counted several times.

### 2026-09-11 · Scribe answers and suggestions follow the language you picked

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md)

#### Fixed
- **2026-09-11** · `backend` · Anant Sharma (AI-assisted) — In the Documents screen's Scribe panel, the suggested questions under "Prueba a preguntar" now appear in Spanish when the app language is Spanish, instead of always being written in English under a translated heading. The document summary and Scribe's answers follow the same setting, so an English PDF read by a Spanish-speaking clinician is now summarised and answered in Spanish.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Documents screen now tells the server which language the app is set to when it asks for a summary or a Scribe answer; previously the language switcher never left the browser.

### 2026-09-11 · Two reports removed from the Reports hub

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md)

#### Removed
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Chronic Care Management report is no longer listed under Clinical Reports on the Analytics & Reports page, for every role including Admin. The report itself is untouched and still opens for anyone with the direct link.
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — The Utilization Rate report is no longer listed under Provider Performance on the Analytics & Reports page. It was already visible only to Admins; the report itself is untouched and still opens for anyone with the direct link.

### 2026-09-11 · Reschedule opens with the appointment already filled in

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md)

#### Fixed
- **2026-09-11** · `frontend` · Anant Sharma (AI-assisted) — Rescheduling an appointment now opens with the patient and appointment details already filled in the first time, instead of showing an empty patient search box that only prefilled if you closed the panel and clicked Reschedule again.

### 2026-09-10 · MRN is a column on the Billing invoices table

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Changed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — On the Billing invoices table, the MRN now has its own column instead of sitting as small grey text under the patient's name. The Patients, Appointments, Encounters and Billing lists now all show it the same way.

#### Fixed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — The "no invoices" message on the Billing table now spans the full width of the table again, instead of stopping one column short.

### 2026-09-10 · MRN is a column on the Patients list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Changed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — On the Patients list, the MRN now has its own column instead of sitting as small grey text under the patient's name, so it can be read straight down the page. The Patients, Appointments and Encounters lists now all show it the same way. The mobile view is unchanged.
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — In Spanish, the Appointments list now labels the MRN column "Expediente", matching the Patients list, rather than leaving the English acronym untranslated.

### 2026-09-10 · MRN and appointment number are columns on the Appointments list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Changed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — On the Appointments list, the MRN and the appointment number now each have their own column instead of sitting as small grey text under the patient's name and the appointment time. Both can now be read straight down the page, and the table matches the Encounters list. The mobile and card views are unchanged.

### 2026-09-10 · Profile photos show on the Encounters list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Fixed
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — A patient's profile photo now appears on the Encounters list. The photo was being looked up correctly and then dropped before the response was sent, so the list always fell back to an initials chip.

#### Added
- **2026-09-10** · `backend` + `frontend` · Anant Sharma (AI-assisted) — Practitioners now show their profile photo in the PRACTITIONER column, falling back to the initials chip when they have none. The photo is read from the practitioner record and, failing that, from the doctor's own account picture — which is where the profile page's uploader saves it, and so is usually the one that has a photo.
### 2026-09-12 · WhatsApp auto-replies verified on a real phone; four defects fixed

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-12](WORK_LOG.md) · [ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md)

#### Security
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — Texting "cancel" no longer unsubscribes a
  patient from all clinic messages. The word was both an opt-out keyword and the way to cancel an
  appointment, so a patient asking about their visit was silently cut off from every future
  notification with no way to know. Opting out is now "alto", "baja", "stop" or "unsubscribe".
  ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — Auto-replies now require recorded consent,
  which was described in the design but missing from the code.

#### Fixed
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — WhatsApp messages from patients whose phone
  number was typed with spaces or dashes now reach their record. Previously they arrived unattached
  to any patient, in the wrong language, and with replies refused.
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — Appointment messages now read "12-09-2026 a
  las 15:01" instead of the raw "2026-09-12 a las 15:01:00".
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — Texting "cancel" now returns the portal link
  as intended; the old direct-cancel path was intercepting it and silently doing nothing.

#### Removed
- **2026-09-12** · `backend` · Ashutosh (AI-assisted) — Cancelling an appointment by WhatsApp reply
  is retired in favour of the portal link. It had no confirmation step, and "no" was one of its
  trigger words — so replying "no" to any message cancelled the next appointment.

---

### 2026-09-11 · WhatsApp keyword auto-replies (built, not yet switched on)

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md)

#### Added
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Patients can text `book`, `cancel` or
  `reschedule` on WhatsApp and get a link to the patient portal, in their own language. Keywords are
  editable in the Desk, so the clinic can add its own words without a deployment. **Every keyword
  ships switched off** and cannot be switched on until its message is approved by Meta.
  ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — A message that matches no keyword now gets a
  reply saying the team will see it and pointing to the portal, at most once a day per number.
  Previously such a message got no reply at all, so someone reporting an urgent symptom could
  believe the clinic had been told.

#### Security
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Every auto-reply is a pre-approved template
  carrying no patient information; the block on free-text WhatsApp sending is unchanged, and tests
  now assert both. A reply is never sent to someone who has just asked to stop.

---

### 2026-09-11 · The front desk is told when a patient cancels in the portal

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md)

#### Fixed
- **2026-09-11** · `backend` + `frontend` · Ashutosh (AI-assisted) — When a patient cancels an
  appointment in the portal, the front desk now gets a notification. Previously the slot simply
  opened and nobody at the clinic was told, at any point.

#### Added
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — WhatsApp templates can now carry the patient
  portal's address as a variable, resolved per environment from site configuration so a staging site
  never links patients at production. Not yet used by any live notification.

#### Security
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — A reword of the appointment-cancellation
  message was reverted the same day: the text patients receive comes from the approved Meta
  template, so changing our copy first would have sent "call us at <web address>". Template changes
  must be approved at Meta before our configuration follows, and a test now enforces that the two
  match. ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))

---

### 2026-09-11 · Cancelling in the patient portal now tells the clinic

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md)

#### Fixed
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — A patient cancelling an appointment in the
  portal now sends the WhatsApp cancellation template and the in-app notification, the same as when
  staff cancel it. Previously the appointment was cancelled and **nobody was notified at all** —
  no error, no log. Booking and rescheduling from the portal were already correct and are unchanged.

#### Changed
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — ADR-066 accepted: all three WhatsApp
  keywords (`book`, `cancel`, `reschedule`) will reply with a patient-portal link, and the keywords
  that cancelled an appointment directly are retired — which also removes the case where replying
  `no` cancelled the next appointment with no confirmation step.
  ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))

---

### 2026-09-11 · ADR-066 — WhatsApp keyword auto-replies, built in-house

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md)

#### Added
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — ADR-066 (Proposed): WhatsApp keyword
  auto-replies will be built in our own app by extending the inbound intent handling that already
  exists, and replies stay **template-only**, so the notification-only guarantee is unchanged.
  ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))

#### Security
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Recorded a gap that is live today: a patient
  message matching no keyword receives **no reply at all**, so someone reporting an urgent symptom
  out of hours sees a delivered message and may believe the clinic was told. ADR-066 proposes a
  "this number is not monitored" reply, carrying no patient information and never sent in response
  to an opt-out. ([ADR-066](docs/adr/adr-066-whatsapp-keyword-auto-replies.md))
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Flagged for separate review: `no` is a
  cancellation keyword and cancellation runs with no confirmation step, so a patient replying "no"
  cancels their next appointment. Not changed here.

---

### 2026-09-11 · Decided not to adopt the third-party WhatsApp chatbot app

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-11](WORK_LOG.md) · [Evaluation](docs/Discuss_frappe_whatsapp_chatbot.md)

#### Added
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Recorded why we are not using
  `frappe_whatsapp_chatbot` for the WhatsApp auto-reply requirement: its Commons Clause licence
  forbids use in a product that is sold, and two of its technical problems cannot be switched off.
  ([evaluation](docs/Discuss_frappe_whatsapp_chatbot.md))

#### Security
- **2026-09-11** · `backend` · Ashutosh (AI-assisted) — Blocked a path that would have sent patient
  data to an unregistered LLM: the rejected app lets an administrator point an AI context at **any**
  doctype from a Desk form, with no allowlist and no permission check, bypassing the ADR-026
  provider allowlist and the active `ComplianceProfile`. Nothing was installed on any site.
  ([evaluation §4.3](docs/Discuss_frappe_whatsapp_chatbot.md))

---

### 2026-09-10 · The Documents screen works again, and stops hiding its own failures

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md) · [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md)

#### Fixed
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — The Documents screen loads documents again. The screen was rewired to Frappe Drive on the frontend, but the backend half of that migration was never merged, so every request had been failing since. Nothing was lost — the documents were there the whole time. ([migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

#### Security
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — A failure to load documents now says so, with a Try again button, instead of showing a green tick and "You're all caught up". Telling a clinician their chart is empty when the truth is that the request failed invites them to re-file records they had already filed.

### 2026-09-10 · Documentation for the Narzim Drive document agent

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Scribe document agent](docs/narzim-drive/SCRIBE_DOCUMENT_AGENT.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Added
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — A short guide to how Scribe reads a document, the fourteen rules that constrain it, and what it cannot do. ([read it](docs/narzim-drive/SCRIBE_DOCUMENT_AGENT.md))

#### Changed
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — The Narzim Drive documents now say what was actually built rather than what was proposed: the design note is marked superseded, and the migration plan records which stages are finished and which were deliberately skipped.

### 2026-09-10 · Scribe's panel can be resized and minimised

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Added
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — **Scribe's panel can now be widened by dragging its left edge, and minimised to a small bar** when the document needs the full screen. Minimising keeps the conversation — only closing discards it. The width you choose is remembered for next time, and the document, the page arrows and the preview all move with the panel instead of staying at a fixed position.

### 2026-09-10 · The document assistant is Scribe

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Changed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — **The document panel is now presented as Scribe, the Documentation Specialist from the AI Workforce**, with the same portrait and name used on that page, instead of an anonymous "Narzim Summary" heading. Someone who meets Scribe on the AI Workforce page and again on a document is meeting the same worker.

### 2026-09-10 · Suggested questions stay available while you read

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Changed
- **2026-09-10** · `frontend` · Anant Sharma (AI-assisted) — **The suggested questions no longer disappear after the first question.** They sit above the box you type in and stay there for the whole conversation, which is when you are most likely to want one. A question you have already asked is removed from the list rather than offered again.

### 2026-09-10 · The panel suggests questions you can ask

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Added
- **2026-09-10** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **The summary panel now offers three or four questions to start from**, drawn from the document in front of you — "What blood group is listed?" on a registration form, "What encryption strategy is recommended?" on a technical analysis. They are produced while the document is being summarised rather than by a second request, so they cost nothing extra, and only questions the document can actually answer are offered.

### 2026-09-10 · A document's page count is no longer answered wrongly

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Fixed
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — **Asked how many pages a three-page document had, the answer was "2 pages".** Only the pages judged relevant to the question were being read, so anything counted — pages, sections, items — was counted from a part of the document and reported as the whole. Short documents are now read in full, and where a long one cannot be, the answer is told the real size and which part it is seeing. A question containing a typo is now understood rather than refused.

### 2026-09-10 · Questions about a document are answered, not refused

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Fixed
- **2026-09-10** · `backend` · Anant Sharma (AI-assisted) — **Reasonable questions about a document were answered "that is not in this document".** Asking what a document said about a subject it discusses on every page, or which language it was written in, both got a refusal. Questions are now read as "what does this document say about this", and plain observations — the language, how long it is, which fields are blank — are treated as reading the page rather than as outside knowledge. Questions the document genuinely cannot answer are still refused, and answers still cite the page.

### 2026-09-09 · The summary says what a document contains

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **The summary described what a document was not, and claimed it had not been filed to a patient's chart.** On a completed registration form it read: "This does not look like a medical document… and has therefore not been added to the patient's chart" — wording belonging to a different feature, where uploads really are filed to a chart. Nothing in Narzim Drive is filed anywhere, so the consequence was invented and the one useful thing — what the document holds — was missing. A summary now names the document type and lists what is actually on the page.

### 2026-09-09 · Questions about scans and photos are answered properly

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Questions about a photographed or scanned document were always answered "that is not in this document".** Handwriting was being read by text recognition, which reproduces printed labels well and handwritten answers as nonsense, so the answer was honest but useless — asking for the first name on a completed registration form found nothing. Photographs and scans are now read as images, so handwritten entries can be answered.

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Closed a hole where a document's text could be read by someone not allowed to see it.** Extracted text is briefly cached to avoid re-reading a file for each question, and the cache was consulted before the permission check — so anyone holding the document's identifier could receive text from a document that was never shared with them. The permission check now comes first.

### 2026-09-09 · The document summary panel now reads the document

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Security
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — **The "Narzim Summary" panel no longer invents laboratory results.** It showed the same five hormone values over every document — a scanned patient registration form was captioned with invented lab results and a clinical instruction, under "Generated by AI". The panel now reads the document it is open on: the summary and every answer come from that file, questions are answered only from it ("that is not in this document" when the answer is absent), and it states how many pages it read. When a summary cannot be produced it says so instead of showing something plausible. ([design](docs/narzim-drive/DOCUMENT_SUMMARY.md))

### 2026-09-09 · Documents can be summarised and questioned — for real

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Document summary design](docs/narzim-drive/DOCUMENT_SUMMARY.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **A document in Narzim Drive can now actually be summarised, and asked questions about.** The summary is produced from the file itself and says what kind of document it is, in English and Spanish. Questions are answered only from the document, with the page quoted; if the answer is not in there, it says so instead of guessing. Every answer states how much of the document was read. Off by default — an administrator turns it on per site. ([design](docs/narzim-drive/DOCUMENT_SUMMARY.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Long documents are read in full rather than in part: beyond eight pages the file is read in sections and the sections combined, so a 20-page report is not summarised from its first third.

### 2026-09-09 · Notes can be formatted

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — **Notes in Narzim Drive can now be formatted** — headings, bold, italic, underline, strikethrough, bulleted and numbered lists, quotes, code blocks and links. Previously a note was plain text with no formatting at all. Uses the same editor as task descriptions, so it behaves the way the rest of the app already does.

### 2026-09-09 · Private documents are private again

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Every member of the clinic could read every document in Narzim Drive, including ones marked Private.** Moving to Frappe Drive brought its shared-team model with it: a document you had not shared with anyone was still listed and readable by all staff, while the screen labelled it Private. Documents are now visible only to the person who created them and to anyone they explicitly share with — administrators included, since being able to administer the system is not the same as being entitled to read a colleague's notes. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · Two notes can share a name

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Creating a second note with the same name failed outright.** Every note is stored in a folder named after its title, so a second "Consulta" — or a new note reusing the name of one already in the trash — crashed with a server error and nothing was created. Repeated names are now numbered automatically, the way duplicate file names always have been. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · A note now has one text, not two

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **MIGRATION** **A note could hold two different texts at once.** Notes were stored twice — one copy used by Narzim Drive, another by Frappe Drive's own editor — and neither could see the other, so the same note showed different content depending on where it was opened. One note had 7,491 characters in one copy and a different sentence in the other. Notes now keep a single text that both screens read and write. Existing notes are converted by a migration; no text was deleted. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · Note text is saved and shown again

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — **Opening a note showed an empty page, and saving kept only the title.** The editor was filled from the document list, which carries titles but no text, so every note looked blank and every save sent an empty body. The editor now loads the actual note, and cannot be saved before the text has arrived. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — A note that fails to save now says so and keeps your text on screen. It previously failed silently, leaving a note that looked saved and was not.

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — An empty body can never overwrite a saved note. This is what stopped the defect above from erasing real text rather than merely failing to add it, and it is now a rule with a test rather than an accident.

### 2026-09-09 · Opening Narzim Drive no longer downloads your files

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **Simply opening the Documents screen was saving every PDF on it to the user's computer, repeatedly.** Files were served marked "save this", and the document cards fetch the same file to draw their preview — so each redraw started another download. One visit produced five copies of the same file. Files are now shown in place, and only saved when the user actually asks to download one. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · Folders in Narzim Drive are real

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `frontend` + `backend` · Anant Sharma (AI-assisted) — **Creating a folder in Narzim Drive now actually creates it.** Folders existed only in the browser, so a folder — and whatever a clinician had just filed into it — disappeared on the next page load, with no error shown at any point. Folders, renaming, deleting, and moving a document into a folder are all stored now, and a document's folder is whatever the server says it is. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · The old document store has been removed

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Removed
- **2026-09-09** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **MIGRATION** **Narzim Drive no longer uses the old `Clinical Document` store; everything now lives in Frappe Drive.** Uploading, opening, renaming, sharing and deleting a document all go to Drive. The old store, its API and its screens' endpoints have been deleted, and a migration removes the leftover records and files. Run `bench --site <site> migrate` to apply it. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Closed a hole where any staff member could read another person's private documents.** Because attachments were filed against the old store, Frappe granted anyone holding a clinical role the ability to list and download them — including documents marked Private, and ones their owner had been told were permanently deleted. Measured before the fix: a front-desk account could open all 14. Removing that store and its files closes the route rather than moving it. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

#### Fixed
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — Uploading a file from the Documents screen filed it in the old store instead of Frappe Drive. It now goes to Drive.

### 2026-09-09 · Narzim Drive now runs on Frappe Drive

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Narzim Drive has real folders.** Documents can be filed into folders that survive a reload, moved between them, and renamed. Previously the folders on the Documents screen existed only in the browser and vanished the moment the page was refreshed. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Deleting a document can now be undone.** Items go to a trash and can be restored; nothing is destroyed on delete. The old Drive had no way back once a document was removed. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Every file read from Narzim Drive is now recorded**, so the clinic can answer who opened a document and when. Frappe Drive keeps no such record on its own. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Sharing is restricted to colleagues who already hold a clinical role. Sharing with an unrecognised email address is refused outright — Frappe Drive would otherwise have created an account for it.
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Uploads keep the previous limits (25 MB; images, PDFs and spreadsheets only), so moving to Frappe Drive did not quietly widen what may be stored.

#### Fixed
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Worked around a defect in Frappe Drive itself: a restored note failed with "This file doesn't exist on disk", because Drive skips notes when moving to trash but not when restoring. Notes now restore correctly. Frappe Drive is not modified.

### 2026-09-09 · Frappe Drive can no longer be reached anonymously

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [Drive migration plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **Frappe Drive, installed on this bench on 2026-09-08, was reachable without logging in; it no longer is.** Anyone who could reach the site could load Drive's file manager, read which people have access to a given file, and reach its sign-up page — all without an account. Drive also records nothing when a file is read, so such a visit left no trace. Verified before and after: reading a file's access list returned data to an anonymous visitor and now refuses. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — **"Anyone with the link" sharing is now impossible in Drive, not merely hidden.** Drive's share dialog could publish a file to the open internet in one click; the setting that does this can no longer be saved by any route — the screen, a background job or the console alike. Sharing with a named colleague or with the whole team is unchanged. No such share existed on this site, and a test now keeps it that way. ([why](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — A written plan for moving Narzim Drive off the `Clinical Document` doctype onto Frappe Drive, including what it would cost and the two questions that must be answered before it starts. ([plan](docs/narzim-drive/DRIVE_MIGRATION_PLAN.md))

### 2026-09-09 · Document sharing actually shares

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [ADR-063](docs/adr/adr-063-drive-access-list.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — The Share dialog's search box now works.
  It was a plain input with nothing listening to it, so typing a colleague's name could never find
  anyone. ([why](docs/adr/adr-063-drive-access-list.md))
  - **2026-09-09** update — the first fix reused the detail page's collapsed picker, which still
    showed no list on an unshared document; the staff list is now inline and visible on open.
  - **2026-09-09** update — folder sharing works too. The folder dialog was a stub reading "folder
    sharing is not available yet"; files and folders now use one dialog, and sharing a folder gives
    access to what is inside it.
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — "People with access" lists everyone who
  actually has access. It previously showed only the owner, no matter who the file was shared with.
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — "General access" is saved. Changing it
  previously did nothing at all: **Done** discarded the choice.
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Removing a colleague from a document's
  access list now revokes their access. Sharing could only ever grant, so unchecking a name left the
  person able to open the file.

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — `get_access` and `set_access` on the
  Narzim Drive API: read who can open an entry, and save an access list exactly as given.
  ([why](docs/adr/adr-063-drive-access-list.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — 10 tests covering the access list,
  including that a dropped colleague loses their grant and that a denial row is not read as access.

#### Removed
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — The "Anyone with the link" sharing
  option, which said "anyone on the internet with the link can view". The backend has always refused
  public sharing, so the option could never have worked.

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Changing who can see a document now
  requires write permission on it. Frappe Drive grants every team member the ability to re-share, so
  any colleague could previously widen access to someone else's clinical document.
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — "Restricted" no longer claims "only
  people with access can open". Every member of the clinic's Drive team can read every file in it,
  so the old wording was false; the underlying permission model is recorded as an open decision in
  [KNOWN_ISSUES](docs/KNOWN_ISSUES.md).

### 2026-09-09 · Move to Patient actually files the document

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [ADR-061](docs/adr/adr-061-drive-to-patient-chart-move.md) · [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Fixed
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — Narzim Drive's **Move to Patient** now
  files the document on the patient's chart. It previously reported "Moved!" after a 900 ms timer
  and made no request at all, so documents staff believed were filed were never on the chart.
  ([why](docs/adr/adr-061-drive-to-patient-chart-move.md))
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — The patient picker in that dialog sent
  the patient's *display name* where the record ID belonged, which would have failed for every
  patient registered through the app (527 of 659 on the dev site).
- **2026-09-09** · `frontend` · Anant Sharma (AI-assisted) — The dialog now reports what actually
  happened, including partial results, and keeps a selection that filed nothing so it can be
  retried. Removed the "Backend endpoint not yet available" notice it used to show.

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — `move_to_patient` on the Narzim Drive
  API: files selected Drive files onto a patient's chart as `Patient Medical Record` documents and
  trashes the Drive originals. Folders and notes are refused; a selection returns per-item results.
  ([why](docs/adr/adr-061-drive-to-patient-chart-move.md))
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — 11 tests covering the bridge, including
  that a moved document is reachable through the chart's own read path and that deleting the chart
  row removes the stored file.

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — A move leaves exactly one copy of the
  patient data, erasable by one path (PHI-4): the bytes go into the chart's own store and the Drive
  source is trashed. Reading them out of Drive writes an `Access Log` row, and moving a document
  requires write permission on it — the same permission Drive requires to delete it, so a colleague
  cannot remove a document from someone else's drive.

### 2026-09-10 · WhatsApp notifications go bilingual, and the channel is wired to a real Meta account

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/whatsapp-integrate-backend` / `feat/whatsapp-integrate-frontend`
**Related:** [WhatsApp design + compliance spec §16](docs/security/WHATSAPP_HIPAA_COMPLIANT.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Added
- **2026-09-10** · `frontend` · Ashutosh (AI-assisted) — Registering a patient now asks which language they want their messages in, on both the Register Patient form and the New Appointment form. The question appears once WhatsApp notifications are agreed to, and leaving it unanswered means English.
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — Appointment notifications are sent in the patient's own language. Spanish and English versions of six templates are approved with Meta; if a translation is missing the message still goes, in the clinic's default language, rather than not going at all.
- **2026-09-10** · `frontend` · Ashutosh (AI-assisted) — **Settings → System → WhatsApp Templates**: every patient notification, when it fires, which languages Meta has approved, and whether it can actually send. A notification that is switched on but has no approved template is called out rather than left looking healthy.
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — A patient's language choice now also applies to their patient-portal login, so someone who asked for Spanish is not shown an English portal.
- **2026-09-09** · `backend` · Ashutosh (AI-assisted) — Eight notification templates created and approved with Meta, in Spanish; six of them also in English.

#### Security
- **2026-09-09** · `backend` · Ashutosh (AI-assisted) — Inbound WhatsApp webhooks are now genuinely authenticated. The signature check shipped on 2026-08-31 had no secret configured, so it accepted every request; with the secret in place a forged or missing signature is rejected. ([detail](docs/security/WHATSAPP_HIPAA_COMPLIANT.md))

#### Fixed
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — Cancelling an appointment never sent the cancellation notification. The template was switched on and approved, and the code path that cancels could not reach it — so it failed silently rather than visibly.
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — A patient's WhatsApp conversation now moves to the top of the staff inbox when a notification is sent to them. Previously only messages *from* the patient updated the ordering, so the busiest threads sank to the bottom.
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — Sent messages now record which template produced them, so sends can be counted and filtered per notification.
- **2026-09-09** · `backend` · Ashutosh (AI-assisted) — The WhatsApp account held credentials from a previous Meta account and an access token that expired on 10 July. All six credentials replaced and verified against Meta; the new token does not expire.

#### Known issue
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — **No notification can be delivered yet.** Meta requires the sender's display name to be approved before a business may message anyone, and "Narzim Care" is still in review. Nothing else is outstanding; sends resume on approval with no further change. ([detail](docs/security/WHATSAPP_HIPAA_COMPLIANT.md))
- **2026-09-10** · `backend` · Ashutosh (AI-assisted) — Meta classified the two "update available" notifications as marketing rather than transactional, which means a patient who has opted out of marketing will not receive them, and no English version can be added. Reworded replacements are proposed but not yet submitted.

---

### 2026-09-08 · Narzim GPT: guided clinical tasks, and it stops leaking patient names

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend · **Branch:** `Enhance/NarzimGPTAI` (backend) / `Enhance/NarzimGPT-Frontend` (frontend)
**Related:** [Guided clinical tasks design](docs/ai/NARZIMGPT_CAPABILITIES.md) · [WORK_LOG — 2026-09-08](WORK_LOG.md)

#### Security
- **2026-09-08** · `backend` · Ashutosh (AI-assisted) — A question naming a patient, or carrying an MRN, appointment or encounter number, is now refused before it leaves the server. Previously the assistant declined to answer such questions, but the message had already been sent to the AI provider and saved. Nothing is sent and nothing is saved now. ([why](docs/ai/NARZIMGPT_CAPABILITIES.md))

#### Added
- **2026-09-08** · `frontend` + `backend` · Ashutosh (AI-assisted) — Conversations can be removed from Narzim GPT history: a **⋯** menu on each row offers **Remove**, and **Clear all** empties the list. Clearing everything asks for confirmation first. Nothing is deleted from the clinic's records — the conversation leaves your sidebar while the clinic keeps its internal copy for auditing, as a clinical system requires.
- **2026-09-08** · `frontend` · Ashutosh (AI-assisted) — Narzim GPT opens with three guided task groups — **Look up**, **Work up** and **Treat** — each offering five common clinical tasks. Picking one starts the question for you and suggests ways to finish it. Typing your own question still works exactly as before.
- **2026-09-08** · `backend` · Ashutosh (AI-assisted) — Clinical answers now include what this clinic actually stocks. Asked about a medication or lab test in your own catalogue, Narzim GPT names the forms and strengths on your formulary instead of listing whatever is commercially available. It never claims something is unavailable, because a catalogue can be incomplete or spell a drug differently.
- **2026-09-08** · `frontend` · Ashutosh (AI-assisted) — A standing note under the question box states that Narzim GPT holds no access to patient records and is not for autonomous decisions.
  - **2026-09-08** update — the "no access to patient records" clause was dropped at the product owner's request. Since a question naming a patient is now refused outright with an explanation, users meet the limit at the moment it matters rather than in permanent small print. The note now reads "Medical knowledge only. Not for autonomous decisions. Check sources and use your clinical judgement."

#### Changed
- **2026-09-08** · `frontend` · Ashutosh (AI-assisted) — Each guided task now draws its four suggested questions from a pool of ten, so opening the same task twice offers different questions. The pools are written for a paediatric and general clinic and localised for Mexico rather than translated. They are drafted and still awaiting clinical sign-off.
- **2026-09-08** · `frontend` · Ashutosh (AI-assisted) — The heading above the question box now reads "How can I help today?".

- **2026-09-08** · `backend` · Ashutosh (AI-assisted) — Assistant prompt updated to `narzim-assistant-v3`, adding the rule that it may say what the clinic's catalogue holds but never that something is missing from it.

#### Fixed
- **2026-09-08** · `frontend` · Ashutosh (AI-assisted) — The suggestion list and the task list now close when you click elsewhere or press Escape. Clicking into the question box itself no longer dismisses them.

---

### 2026-09-09 · Practitioner Availability screen: delete-from-modal, redesign, wording, and a read-only holiday list

**Author(s):** Divyanshu (AI-assisted) · **Repos:** backend + frontend · **Branch:** `dev`
**Related:** [ADR-063](docs/adr/adr-062-practitioner-self-service-availability.md) · [PRACTITIONER_AVAILABILITY.md](docs/PRACTITIONER_AVAILABILITY.md) · [KNOWN_ISSUES](docs/KNOWN_ISSUES.md)

#### Added
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — The Availability details view now has a Delete button next to Close, so a practitioner can remove a declared override without leaving the modal first.
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — The Availability details modal and the "Add" dialog were redesigned to match the site's visual language (icon header, teal accents, sectioned date/time block) instead of a bare white box; the toggle and Save button colors now match the site's teal instead of black.
- **2026-09-09** · `backend` + `frontend` · Divyanshu (AI-assisted) — Practitioners can now see their own company's holiday calendar, read-only, on the same profile screen (`get_my_holidays` / `practitioner-holidays-card.tsx`), with a search box and a scrollable, sticky-header table. ([why Company-resolved, not Employee-resolved](docs/adr/adr-062-practitioner-self-service-availability.md))

#### Changed
- **2026-09-09** · `frontend` · Divyanshu (AI-assisted) — The Availability card's title changed from "Availability" to "Practitioner Availability," and its "+ Add" button and the Add dialog's title changed to "Add Practitioner Availability."

#### Security
- **2026-09-09** · `backend` · Divyanshu (AI-assisted) — Recorded, not yet fixed: `assert_bookable`'s holiday/leave check has never actually blocked a booking in this app, because the core function it calls can never resolve a practitioner's Employee record. ([detail](docs/KNOWN_ISSUES.md))

---

### 2026-09-09 · Patient Education module (backend + Patient 360/Encounter API contract)

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `feat/patient-education`
**Related:** [WORK_LOG — 2026-09-09](WORK_LOG.md)

#### Added
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — New `Patient Education Resource` doctype: practitioners can create patient-facing education content manually or generate a first draft with Narzim AI, gated by a mandatory Draft → Pending Approval → Approved → Published workflow enforced entirely server-side via action-based whitelisted methods (`api/v1/patient_education/api.py`) — never a generic status setter. AI-generated drafts always persist as `status="Draft"`; nothing in the generation path (`services/patient_education.py`) can set any other status.
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — New semantic validation layer (`services/patient_education_validation.py`): patient/encounter/medication relationship checks (rejects cross-patient mismatches), title/content placeholder and meaninglessness detection, a strict workflow-transition map, and a full re-validation gate re-run immediately before approval and before publication — not only at creation.
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — Thin delegate endpoints added to the existing `patients/api.py` (`get_patient_education`, the new Patient 360 tab) and `encounters/api.py` (`get_encounter_education`, the new Encounter section), so both entry points follow this codebase's existing per-file tab-endpoint convention while the real logic lives in one module.
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — `AI Settings.enable_patient_education` feature flag (default OFF) gates AI generation; manual creation is unaffected if it's off or the LLM is unavailable. New `AI Prompt Log` purpose option `Patient Education Generation`.

#### Security
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — `status`, `approved_by`, `approved_at`, and `portal_visible` are never accepted as request parameters on any endpoint — always server-derived, and re-checked on every workflow transition. Verified with 18 end-to-end tests: cross-patient encounter/medication rejection, non-practitioner role rejection, publish-without-approval rejection, and every invalid status transition (`Draft→Published`, `Pending Approval→Published`, `Rejected→Published`, re-approving an already-approved record).

#### Not included in this pass
- **2026-09-09** · `backend` · Anant Sharma (AI-assisted) — The Patient Portal (`EB_Healthcare_PatientPortal`) list/detail/mark-viewed UI is deliberately deferred; only its API contract is fixed (`patient = _session_patient() AND status = "Published" AND portal_visible = 1`, mirroring `patient_portal/api.py`'s existing ownership pattern). The clinical EHR frontend (`EB_Healthcare_EHR`) Patient 360 tab and Encounter section are covered separately below/in a follow-up entry once added.

---

### 2026-09-07 · The patient portal address now comes from site configuration

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/portal-url-from-site-config`
**Related:** [QR generation spec](docs/scanner/QR_GENERATION.md) · [WORK_LOG — 2026-09-07](WORK_LOG.md)

#### Changed
- **2026-09-07** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **The address the patient QR points at is now read from the site's own configuration instead of being fixed when the app is built.** It had to be set separately for every environment and could not survive a build being promoted from dev to pre to production — the address would have been the wrong one. It is now read from the same single setting the patient invitation emails already use, so a printed QR card and an emailed link can no longer point to different places. ([detail](docs/scanner/QR_GENERATION.md))
- **2026-09-07** · `frontend` · Anant Sharma (AI-assisted) — The QR page now tells three situations apart instead of one: still loading, could not reach the server (offering Try again), and genuinely not configured (naming the setting an administrator must fill in). Previously anything other than success looked like a configuration problem, which would send an administrator to edit environment settings because the network dropped a request.

#### Fixed
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — Recorded a defect found while doing this, and deliberately **not** fixed here: on a site where the portal address is unset, patient welcome and password-reset **emails link the patient to `localhost`** — a dead link on their phone, with no error shown to anyone. Written up in [KNOWN_ISSUES](docs/KNOWN_ISSUES.md) because changing how email links resolve affects every flow that provisions a login.

### 2026-09-08 · The patient portal we audited turns out not to be the patient portal

**Author(s):** Gaurav (AI-assisted) · **Repos:** backend (docs only) · **Branch:** `dev`
**Related:** [Patient Portal audit](docs/audit/portal/README.md) · [WORK_LOG — 2026-09-08](WORK_LOG.md)

#### Added
- **2026-09-08** · `backend` · Gaurav (AI-assisted) — Filed the patient-portal audit (PP1-PP16, carried out 2026-09-03), the first review of the only surface a patient touches unsupervised. Its headline: `Healthcare_Patient_Portal` is a design prototype — 3,341 lines, 11 screens, zero backend calls — so the working portal is a different repo and has never been audited. ([detail](docs/audit/portal/README.md))

#### Fixed
- **2026-09-08** · `backend` · Gaurav (AI-assisted) — The audit document is no longer at risk of having a generated file list appended beneath its revision history: it sits at a directory README, which `scripts/gen_doc_indexes.py` treats as an index. Marked `INDEX: manual`.

---
### 2026-09-07 · Encounter V3 stops claiming authorship it does not have

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-07](WORK_LOG.md)

#### Fixed
- **2026-09-07** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — An empty box in Review SOAP no longer shows the word **AI** beside it. On an encounter with no transcript all six boxes were labelled as AI-written, and a screen reader announced "AI generated" for each — text that did not exist and that no AI had produced. An empty box now shows only the "empty" badge it always had.
- **2026-09-07** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The copilot panel no longer says **"Listening to the consultation"** when nothing is being recorded. It now reports what is actually happening — not recording yet, starting, listening, paused, finishing, finished, or stopped after a connection problem — and says "Ambient documentation is off" on a clinic where recording is disabled.
- **2026-09-07** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Six code comments that stopped being true when AI suggestions were switched on were corrected, including one naming a file that no longer exists and one describing a feature deleted in `8a52975`.

#### Security
- **2026-09-07** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Removed the suggested question *"Check the paracetamol dose against her weight"* from the pre-signing panel. Neither the drug nor the patient's gender came from the encounter — it was prototype copy being offered verbatim to a clinician over a real patient's record.

---
### 2026-09-07 · UI and UX defects reported from the clinic

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend · **Branch:** `bug-fix/ui-ux` (backend) / `fix/ui-ux-frontend` (frontend)
**Related:** [EB role authorization](docs/security/EB_ROLE_AUTHORIZATION.md) · [WORK_LOG — 2026-09-07](WORK_LOG.md)

#### Security
- **2026-09-07** · `backend` · Ashutosh (AI-assisted) — A Healthcare Admin opening Narzim GPT could see the screen but got "You do not have permission to perform this action" on every message. They now have the same access to it as every other clinical role.

#### Fixed
- **2026-09-07** · `frontend` · Ashutosh (AI-assisted) — The Live Queue's practitioner filter listed one row per practitioner record rather than one per name, so ticking a name silently ticked every other practitioner sharing it and the choice could not be made at all. It now lists one row per name, says how many records a shared name covers, and scrolls instead of running off the bottom of the screen.
- **2026-09-07** · `frontend` · Ashutosh (AI-assisted) — Closing a submitted and paid invoice warned that it had not been saved and offered to discard it. It now closes without a warning, because there is nothing left to discard.
- **2026-09-07** · `frontend` · Ashutosh (AI-assisted) — The patient chart's Timeline no longer crushes its columns on a narrow screen: record numbers stay on one line, the encounter chip no longer prints over the appointment time, and the table scrolls sideways instead. Column headings now line up with the rows beneath them.
- **2026-09-07** · `backend` + `frontend` · Ashutosh (AI-assisted) — Team chat shows a colleague's profile picture where they have one, instead of always falling back to their initials.

#### Added
- **2026-09-07** · `backend` · Ashutosh (AI-assisted) — Checks over the role-permission spec that fail the build if an administrator is ever given less access than a receptionist or a nurse, if a role can create records it cannot read, or if a permission names a role that does not exist.

---
### 2026-09-07 · Narzim GPT now works for admin accounts

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `docs/qr-self-registration`
**Related:** [Narzim assistant design §4.1](docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md) · [WORK_LOG — 2026-09-07](WORK_LOG.md)

#### Fixed
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — Clinic and platform admins could not use Narzim GPT at all. The assistant was in their sidebar and the message box accepted typing, but sending one answered "You do not have permission to perform this action." — admin was the only staff role never granted permission to write a message, because it had originally been added to the assistant only so it could see the per-user usage and cost breakdown. Admins now have the same access as practitioners, nurses, front desk and clinic staff. ([detail](docs/ai/NARZIM_AI_ASSISTANT_DESIGN.md))

#### Changed
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — The permission spec (`eb_docperm_spec.json`) grants `EB_Healthcare Admin` create + write on `AI Narzim Assistant Message`. Deleting messages stays disallowed for every staff role, admin included. ([why](WORK_LOG.md))


### 2026-09-04 · WhatsApp becomes a notification-only channel

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/whatsapp-backend-fix` (backend) / `feat/whatsapp-fixx` (frontend)
**Related:** [WhatsApp design + compliance spec](docs/security/WHATSAPP_HIPAA_COMPLIANT.md) · [gap #28](docs/security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md) · [WORK_LOG — 2026-09-04](WORK_LOG.md)

#### Security
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Clinic staff can no longer type a free-text message, attach a file, or send a clinical PDF to a patient on WhatsApp. All five paths that could do so now refuse with an explanation. Meta has signed no confidentiality agreement, so content a patient never asked for cannot go through that channel. ([why](docs/security/WHATSAPP_HIPAA_COMPLIANT.md))
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Sending a signed encounter summary as a PDF over WhatsApp is removed. It was the single most disclosing path in the system — an entire visit's clinical record to a processor with no agreement in place. The same PDF is still served in the patient portal, and Email to parent is unaffected.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — The WhatsApp template guard now checks **every** enabled template, not only automatic ones. A staff-sent template carrying a patient's name was previously allowed through on the reasoning that a person was accountable for it; that reasoning does not make the disclosure permitted.
- **2026-09-04** · `frontend` · Ashutosh (AI-assisted) — The message box, attach button and send button are gone from both WhatsApp views — the patient chart's WhatsApp tab and the app-shell chat widget — replaced by a line explaining that WhatsApp carries notifications only and a **Send Notification** button. Received messages and sent notifications are still shown in full.
- **2026-09-04** · `frontend` · Ashutosh (AI-assisted) — The encounter report's "send summary over WhatsApp" action is removed, along with the three routes that carried free text, attachments and the summary PDF.

#### Added
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Patients (or a parent or legal guardian for a child) can now be recorded as having authorized WhatsApp notifications, and **nothing is sent to anyone without it**. The authorization is to a specific phone number, so it does not follow a number change to whoever holds the new one. ([why](docs/adr/adr-060-patient-communication-consent.md))
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Replying `ALTO`, `BAJA`, `CANCELAR`, `STOP` or `UNSUBSCRIBE` on WhatsApp withdraws the authorization immediately. WhatsApp itself does not do this for appointment-type messages, so the clinic has to.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — A consent cannot be recorded for a patient with no date of birth, because without one the system cannot tell whether the patient may authorize it themselves or whether a parent must. 239 patients are currently in that state.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — A parent's authorization for a child now carries an end date at the child's 18th birthday, after which only the patient can authorize. An adult's own authorization never expires.

- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Booking an appointment for a patient who has consented now sends them a WhatsApp notification carrying the date, the time and the clinic's name — and nothing that identifies them. Six templates are ready; they start disabled until Meta approves them. ([what is still needed](docs/security/WHATSAPP_HIPAA_COMPLIANT.md#15-go-live-checklist--what-is-built-and-exactly-what-you-must-provide))
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Recording a patient's consent again now replaces the previous one for that number instead of sitting alongside it. Two live authorizations meant "Withdraw" only cancelled one, so a patient who asked to stop would have kept receiving notifications.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Consent ticked while booking a new patient is now saved as part of the booking itself, so a patient who agreed can never end up without a record of it.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Front-desk staff can now record and withdraw a patient's WhatsApp authorization. Without this there was no way for a clinic to record one at all, so no notification could ever have been sent. ([why](docs/adr/adr-060-patient-communication-consent.md))
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — A parent's authorization now ends automatically on the child's 18th birthday, with a warning to the parent 14 days beforehand and a reminder for the front desk to ask the young adult whether they want notifications for their own number.

#### Removed
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — The five old notification templates that carried a patient's name, their doctor's name, the test they had taken or an invoice total. Sending a summary of a visit as a PDF over WhatsApp is gone with them.
- **2026-09-04** · `frontend` · Ashutosh (AI-assisted) — Routes `whatsapp/conversations/[id]/reply`, `whatsapp/conversations/[id]/send-media` and `whatsapp/encounters/[id]/send-summary`, and the `useWaReply` / `useWaSendMedia` hooks.

#### Added
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — A WhatsApp notification about a patient is now recorded as an access to that patient's record, the same way opening their chart is. Without it, a patient asking "who has my information been shared with?" would have been shown every clinician who opened the chart and none of the messages the system sent about them.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — 8 tests proving each of the five paths refuses, asserted against the API rather than the screen, because hiding a button does not remove a capability.
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — [`WHATSAPP_HIPAA_COMPLIANT.md`](docs/security/WHATSAPP_HIPAA_COMPLIANT.md): the design for WhatsApp as a consent-based, template-only notification channel, with the six decisions taken on it and the Meta credential inventory.

#### Fixed
- **2026-09-04** · `backend` · Ashutosh (AI-assisted) — Two claims in the HIPAA register were wrong and are corrected: the free-text paths were described as callable by anyone (they are limited to five clinical roles and scoped to a clinic), and the webhook signature check was marked done when the Meta App Secret it needs is not set on any environment, so unsigned webhooks are still accepted today.

---
### 2026-09-04 · A reload during recording no longer destroys the encounter

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend · **Branch:** `feat/ai-session-consent-reattach`
**Related:** [ADR-059](docs/adr/adr-059-stale-recording-session-resume-or-supersede.md) · [investigation](docs/_archive/prompts/2026-09-04-dev-mic-record-consent-missing.md)

#### Fixed
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **Reloading the tab mid-recording no longer makes an encounter permanently un-recordable.** A session only leaves `Recording` when the clinician presses stop, so a reload or a closed tab stranded it there; the consent gate then asked again and the answer was rejected for ever. 31 encounters were stuck this way, the oldest since 29 August. Answering the gate now resumes the recording where real consent evidence exists, and starts a clean one where it does not. ([why](docs/adr/adr-059-stale-recording-session-resume-or-supersede.md))
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A clinician who lands on an encounter a colleague is already recording is now told exactly that, instead of "Consent can only be recorded before recording starts." The colleague's recording is left running.

#### Security
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **A recording that nobody consented to can never be resumed.** Sessions opened by V1's auto-start carry `consent_obtained = 1` written in the browser with no one asked — 25 of the 31 stuck sessions. These are now closed and a real consent question asked, rather than being adopted as though consent had been given. ([PHI-2](CLAUDE.md))
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Consent is never back-dated. Resuming a recording leaves the original consent record untouched, so `consent_obtained_at` keeps the time the family actually answered.

#### Added
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `get_active_session` now reports `consent_method`, the only field that separates a consent a human gave from one the browser asserted. First test coverage for that endpoint.

---


### 2026-09-04 · Encounters list — filter by more than one status at a time

**Author(s):** Ishmita (AI-assisted) · **Repos:** backend + frontend · **Branch:** `docs/qr-self-registration` (backend) / `dev` (frontend)
**Related:** [Encounters screen spec §4.2, §7.2, §10.5](docs/ENCOUNTERS_SCREEN_SPEC.md) · [WORK_LOG — 2026-09-04](WORK_LOG.md)

#### Fixed
- **2026-09-04** · `frontend` · Ishmita (AI-assisted) — Unsigned notes could go missing from the Encounters list. "Unsigned" covers two underlying states, and only the first page ever showed both — so a doctor paging through a long backlog was shown a list that silently omitted some of the unsigned notes it existed to find. The list is now a single query, so every page is complete and the count matches. ([detail](docs/ENCOUNTERS_SCREEN_SPEC.md))

#### Changed
- **2026-09-04** · `frontend` · Ishmita (AI-assisted) — The Encounters list's Status filter now accepts several statuses at once, for example Unsigned together with Completed. The tick boxes were already drawn as tick boxes but behaved as a single choice; the panel now stays open while you pick, and each chosen status gets its own removable chip. ([detail](docs/ENCOUNTERS_SCREEN_SPEC.md))
- **2026-09-04** · `frontend` · Ishmita (AI-assisted) — "All except cancelled" remains a single choice that replaces the others, because it means "not cancelled" in a stricter sense than ticking the other three, and combining them would ask two different questions at once.
- **2026-09-04** · `backend` · Ishmita (AI-assisted) — `list_encounters` and `get_encounters` accept a new optional `status_in` (comma-separated statuses) alongside the existing single `status`, which is unchanged and still wins if both are sent. An unrecognised value is rejected with a 400 rather than returned as an empty list, so a typo cannot read as "this clinic saw nobody". ([detail](docs/ENCOUNTERS_SCREEN_SPEC.md))

### 2026-09-03 · QR self-registration and self-booking — the requirement, written down

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs only) · **Branch:** `dev`
**Related:** [Requirement](docs/scanner/REQUIREMENT.md) · [WORK_LOG — 2026-09-03](WORK_LOG.md)

#### Added
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — Requirement for the paper-form scanner ([docs/scanner/FORM_SCANNER.md](docs/scanner/FORM_SCANNER.md)), written against the clinic's real registration form and the live Register Patient drawer: the field-by-field mapping, the OCR decision (vision LLM for handwriting; Tesseract only to identify the form and as the fallback), the two-consent problem, and 12 Phase 1 tasks. Records a **blocking** contract mismatch — a completed paper form cannot be submitted through `patient_portal.register()`, and guardian details would be dropped for a pediatric patient.
- **2026-09-03** · `backend` · Anant Sharma (AI-assisted) — Two decision records for the QR patient journey, both **Proposed** and neither implemented: [ADR-057](docs/adr/adr-057-patient-duplicate-match-blind-claim-and-verify.md) — how a returning patient is recognised without revealing anyone's identity to an anonymous caller, and [ADR-058](docs/adr/adr-058-registration-form-vision-extraction.md) — how a photographed registration form is read, as a proposal the person confirms rather than anything that writes itself.
- **2026-09-03** · `backend` · Anant Sharma (AI-assisted) — New requirement document for the QR-scan patient journey: scan a clinic's QR, register (by typing the form or by photographing a paper one), confirm the details, book an appointment. Records that roughly 70 % of the flow is already live on the patient portal URL, names the 6 things that are actually missing, and puts 36 numbered requirements and 3 undecided questions in front of a decision. ([requirement](docs/scanner/REQUIREMENT.md))
  - **2026-09-03** update — Filed into its own folder as `docs/scanner/REQUIREMENT.md` with an index of its own; the two ADRs stay in `docs/adr/` because ADR numbering and indexing are central.
  - **2026-09-04** update — Flow decided: the front desk scans from the Patients page and the existing Register Patient drawer opens pre-filled; the Save press stays the only thing that writes. One new endpoint specified for the frontend repo.
  - **2026-09-04** update — All scanner documents now live in one folder, `docs/scanner/`. The ADRs stay under `docs/adr/`, where the numbering gate can see them.
  - **2026-09-04** update — Build plan split out into [docs/scanner/BUILD_PLAN.md](docs/scanner/BUILD_PLAN.md), which now owns the phased task list.

#### Added
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — First working piece of the form scanner: the value normalisers that turn what a parent writes by hand into what the patient API will actually accept — `A+` into `A Positive`, `FEMENINO` into `Female`, `MADRE` into `Mother`, `MÉXICO` into `Mexico`, `08/03/2019` into a real date. Anything it cannot recognise is handed back as an empty field with the original handwriting shown beside it, so a person chooses — it never guesses. Also cross-checks the form's handwritten Age against its Date of Birth, which catches a misread for free. ([plan](docs/scanner/BUILD_PLAN.md))
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — Plain-language note on which OCR we use and why ([docs/scanner/OCR_CHOICE.md](docs/scanner/OCR_CHOICE.md)): free OCR returns text, not fields, so it cannot tell a first name from a surname on a form; also records that Tesseract's install on Frappe Cloud is documented as never actually verified, which would fail silently.
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — The scanner flow written out end to end ([docs/scanner/FLOW.md](docs/scanner/FLOW.md)): what the front desk sees at each step, the eleven things the backend does, the data contract between them, and what happens when each step fails — every failure still lets the patient be registered by typing.
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — The form scanner's backend is built: a new staff-only endpoint reads a photographed paper registration form and returns the details for the Register Patient form to be filled in with, ready for a person to check and correct. It creates nothing — the Save press is still the only thing that registers a patient. Off by default. ([flow](docs/scanner/FLOW.md) · [plan](docs/scanner/BUILD_PLAN.md))
- **2026-09-04** · `frontend` · Anant Sharma (AI-assisted) — **Front desk can now scan a paper registration form.** A new **Scan form** button on the Patients page opens the camera (or a file picker), takes one or more pages of the same form, reads it, and opens the usual Register Patient drawer with the details already filled in. An amber banner names the fields worth checking and shows what the paper actually said for each. Everything stays editable and **nothing is saved until Register patient is pressed** — the scan fills the form, it does not register anyone. ([flow](docs/scanner/FLOW.md))
  - **2026-09-04** update — The duplicate-patient banner is **not** included: it needs a duplicate check the backend does not perform yet, and building it would have meant inventing a contract. Recorded in [the plan](docs/scanner/BUILD_PLAN.md) as blocked.

#### Security
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — The scanner **refuses to send anything to an AI provider that the clinic's compliance profile does not name**, and says so in plain words instead of failing quietly. Right now that means it refuses on this site, because the profile says one provider while the site is configured for another — a mismatch that already existed for lab reading. The rule is now enforced by the code rather than written in a document. ([why](docs/adr/adr-058-registration-form-vision-extraction.md))
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — **The record of which companies process patient data is now correct.** It named Anthropic and Groq while the system had been sending patient data to OpenAI and Deepgram for months; it now names OpenAI and Deepgram. This mattered beyond the scanner — the same wrong record covered AI recording and lab reading. The India profile is left alone and marked unverified rather than guessed at. Naming them is not the same as having their data-processing terms reviewed, which is still outstanding. ([why](docs/scanner/BUILD_PLAN.md))
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — A form scan that fails now leaves an audit record. It did not before: the record was written but discarded when the failed request rolled back, so the calls most worth having a record of were the ones with none. Found by running a real failure, not by reading the code. The record stores the error's type only, never its message.
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — **Scan failures now say what is actually wrong.** A scan was failing with "you hit the rate limit, try after sometime" when the real cause was that the AI provider account had run out of credit — so the front desk was told to wait and retry, which could never work, and the administrator who could fix it was never told. Exhausted credit, a genuine rate limit, a timeout and a rejected key now each get their own message naming who has to act. ([why](docs/scanner/FLOW.md))
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — Written up how the front-desk QR works ([docs/scanner/QR_GENERATION.md](docs/scanner/QR_GENERATION.md)): a receptionist opens a dialog on the Patients page, shows the code on screen or prints a laminated card, and the code carries nothing but the portal's registration address — so photographing it reveals nothing about anybody. Also records why an online QR service is not used, and the size, contrast and margin settings that decide whether a phone can actually read it.
- **2026-09-04** · `backend` · Anant Sharma (AI-assisted) — Every scanner document now opens with a **30-second brief** and closes with a short **conclusion**, both in plain language: what the document is, whether it needs a decision from the reader, and the one thing to take away. A reviewer can now approve or question the work without reading 200 lines. ([start here](docs/scanner/README.md))
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — Written up what happens when the front desk scans a form for a patient we already have ([docs/scanner/DUPLICATE_CHECK.md](docs/scanner/DUPLICATE_CHECK.md)): we show who we think it is, with what matched and their date of birth, and the receptionist decides. Records that a shared family phone or email must never count as a match on its own — one parent's number is used for every sibling, so matching on it would say two different children are the same child.

#### Added
- **2026-09-07** · `frontend` · Anant Sharma (AI-assisted) — **The front desk can now show a patient a QR code to register on their own phone.** A `Patient QR` button on the Patients page opens the code, with the web address written underneath so it can be read out if a camera will not cooperate, and buttons to copy it, save it as an image, or print a card for the counter. The code contains nothing but the address of the sign-up page — nothing about any patient — so it is safe to print and leave out. The button hides itself if the portal address has not been configured, rather than showing a code that goes nowhere. ([how](docs/scanner/QR_GENERATION.md))
- **2026-09-07** · `backend` + `frontend` · Anant Sharma (AI-assisted) — **Scanning a form for someone we already have now says so, before a second record is created.** If the ID number matches, or the name and date of birth match, the receptionist is shown who we think it is — with their MRN, date of birth and when they were registered, and exactly which details matched — and chooses "open this chart" or "none of these". A name-only match shows a note instead of interrupting, because a pop-up on every namesake teaches people to click past it. It warns and never forbids: two children really can share a name and a birthday. ([detail](docs/scanner/DUPLICATE_CHECK.md))
  - **2026-09-07** update — Four defects fixed after testing on real records. **Two patients with the same name were not both shown**: the search only looked for the longest word in the name, so someone recorded under a shorter name was never even found, and a date-of-birth match stopped the search early. **A weaker name-only match showed nothing at all** — it now shows a warning inside the registration window, which also explains why the warning sometimes seemed to disappear on a second upload. And phone numbers were compared exactly, so a form's `8345964233` never matched a stored `+52 8345964233` — meaning the phone check had never worked on real data.
  - **2026-09-07** update — The check now shows **one screen listing everyone who matched** — by name, date of birth, phone or email — instead of a screen for strong matches and a note for weaker ones. A patient found only by a shared phone or email is listed too, but labelled *"different name — likely a family member sharing this contact"*: in a children's clinic one parent's number is used for every sibling, so calling that a duplicate would be wrong.
  - **2026-09-08** update — **Looking at a possible match no longer loses the scanned form.** Opening a candidate's chart and pressing Back now returns to the same screen with everything still filled in; previously it landed on a bare patient list and the form had to be photographed again, which costs another AI reading. The list itself was also tidied: the "Open this chart" button now sits in the same place on every row, and the notes under each patient read as one block instead of three separate warnings.
  - **2026-09-08** update — Two follow-ups on that: Back now returns to the match screen whether the browser reuses the page or rebuilds it (only one of the two was handled, so the other still landed on the empty patient list), and the screen is now restored **once** rather than reappearing on every later visit to the patient list.
  - **2026-09-07** update — **A single misread letter no longer hides a duplicate.** Three patients named Texes existed and only two were listed: the scan had read "Texes Longer" as "Texes Longe", and one dropped letter made it a different surname entirely. Names now tolerate one wrong or missing letter per word, and a patient sharing only part of a name is listed too, marked *"shares part of the name — probably a different person"*. All same-named patients now appear, each showing exactly what matched.
  - **2026-09-07** update — [docs/scanner/DUPLICATE_CHECK.md](docs/scanner/DUPLICATE_CHECK.md) now documents the whole process end to end: when the check runs, what is sent to it, the four database lookups, how names and phone numbers are compared, the five levels of certainty, what comes back, what the screen shows, what happens on each choice, what is recorded, and what happens if the check itself fails.
  - **2026-09-07** update — The same code is now also a permanent page under **Settings › System › Patient Appointment QR**, so a card can be printed once and left on the counter without going through the Patients screen. If the portal address has not been configured, the page explains that and names the setting instead of showing a code that would lead nowhere.
  - **2026-09-07** update — The QR button was removed from the Patients page; the code now lives only under Settings. Showing a QR is a one-off administrative act — print the card, put it on the counter — rather than something done per patient, and a button on the patient list implied the code was somehow specific to that patient.

#### Security
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — **Patient self-registration is now rate limited.** It was an open, unauthenticated endpoint that created a patient and an enabled login on every call, with no throttle — and it answers a matching ID number by naming the existing patient's MRN, so anyone could have submitted ID numbers in a loop to learn which ones belong to our patients. Capped at 30 per hour from one address, which is far above real clinic use. ([detail](docs/scanner/REQUIREMENT.md))

#### Changed
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — **Form scanning now works end to end.** A full scan was run and every detail came back correct: names, gender written in Spanish, the date, blood group written as `A+`, the guardian's relation written as `MADRE`, the address, and the ID number — with the consent tick box and signature both recognised. It took **5 seconds** and **cost less than one cent**, and no patient record was created until Save, as intended. Still untested: a form filled in by hand rather than typed. ([detail](docs/scanner/BUILD_PLAN.md))
- **2026-09-07** · `backend` · Anant Sharma (AI-assisted) — Corrected the running cost of form scanning from an estimate to a measurement: **$0.0079 per scan, about $4.76 a month** at 20 registrations a day. The earlier estimate of roughly a cent per scan was **48% too high**. ([detail](docs/scanner/OCR_CHOICE.md))

#### Security
- **2026-09-03** · `backend` · Anant Sharma (AI-assisted) — Documented two gaps that are **live on the patient portal registration URL today**, independent of any QR code: a patient who already has a chart but no national ID on file is not recognised and gets a second chart (splitting their allergy and medication history), and the unauthenticated `register()` endpoint has no rate limit while creating both a Patient and a website user per call. Recorded as G-3 and G-5; neither is fixed by this change. ([detail](docs/scanner/REQUIREMENT.md))
  - **2026-09-03** update — Requirement v1.1 after confirming there is only **one** clinic: multi-clinic QR scoping deferred, and a third live defect recorded — the patient booking wizard currently offers "Social Angel", the platform company, as a bookable clinic, so a patient who picks it reaches an empty practitioner list and a dead end (G-7). Also recorded, from the bench: 653 of 654 patients have no national ID, so the system's only duplicate guard is inert for almost every existing chart — and because `dob` and `mobile` are optional fields, the proposed name+DOB replacement is weaker than first written. Seeded data, so the percentages are a warning rather than a production measurement.

### 2026-09-03 · Consent for AI recording becomes real, server-checked evidence

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `audit/capture-and-review-note` (backend) / `docs/encounter-v3-audit` (frontend)
**Related:** [ADR-056](docs/adr/adr-056-consent-server-derived-evidence.md) · [prompt archive](docs/_archive/prompts/2026-09-03-consent-server-derived-evidence.md)

#### Security
- **2026-09-03** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The Guided (V3) encounter screen's recording session no longer starts on a client's bare claim that consent was asked. A new `record_consent` call now writes who asked and when, server-side, and the session refuses to start without it. ([why](docs/adr/adr-056-consent-server-derived-evidence.md))
- **2026-09-03** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Every AI recording session created before this change is labelled `consent_method = "unverified"` — the true historical consent status is not knowable, so it is stated honestly rather than guessed. 263 rows flagged on the local bench.
- **2026-09-03** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Clicking "they agreed" on the Guided screen's consent question now only opens the microphone once the server has actually recorded the consent; a failed write leaves the question on screen with a visible error instead of quietly proceeding.

#### Added
- **2026-09-03** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `record_consent(encounter, method)`, a new whitelisted endpoint; two new fields on `AI Encounter Session` (`consent_by`, `consent_method`).
- **2026-09-03** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — New `/api/ai/session/consent` route.

---

### 2026-09-02 · The recording screen stops claiming things it never checked

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `audit/capture-and-review-note` (backend) / `fix/drop-path-tells-the-truth` (frontend)
**Related:** [Capture audit](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md) · [WORK_LOG — 2026-09-02](WORK_LOG.md)

#### Security
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — When the speech service drops, the screen no longer says "everything transcribed so far is saved" without checking. It now says finished lines were saved and anything still being spoken was not, and if a save really failed you get the counts and a Retry instead of a false reassurance. ([why](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md))
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — A dropped recording no longer closes the visit's recording session when the transcript failed to save, so the words can still be retried. Previously the session was closed either way, which made a failed save permanent.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Correcting a transcript now refuses a badly numbered set of lines instead of deleting rows by position. Nothing was being lost, but the old cleanup would have silently deleted the last line of every corrected transcript if a caller ever numbered from 1.

#### Added
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Lines still being spoken are marked "Not saved yet" in the transcript, so it is visible which words are safe and which are not.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Every AI call now records how much of its prompt was reused from cache and how many tokens went on reasoning, not just the chat assistant. First measurement: 72% of a note-gap prompt was cached.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — An audit of the capture screen: what one press of "Review the note" costs, where every row is written, and eight gaps with their evidence. ([read it](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md))

#### Fixed
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The "said but not written" check was recording a cost of zero on every call. It now records what it actually costs. **Historical rows are still wrong** and need a separate backfill — see the audit, gap G5.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — "Could not verify the transcript's speaker labels" no longer appears over a perfectly good transcript. Two processing passes were running at once and one lost a write race.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The "Still checking the consultation" line no longer stays on screen for ever after pausing the microphone.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The consultation screen no longer stutters while you talk, and the note now appears about twelve seconds sooner because the "said but not written" check runs underneath it instead of in front of it.

### 2026-09-28 · Appointment reminders now reach patients on WhatsApp

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend · **Branch:** `feat/whatsapp-cont-backend`
**Related:** [deploy_whatsapp.md](docs/deploy_whatsapp.md) · [WHATSAPP_INTEGRATION §17](docs/WHATSAPP_INTEGRATION.md) · [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Added
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — **Patients now get a WhatsApp reminder before their appointment.** The config and its approved template had existed for weeks with nothing calling them; the 5-minute job that owns reminders drove in-app and push only. It reaches people the in-app reminder cannot: the in-app half needs a portal login, the WhatsApp half needs only a consented mobile. Timing still comes from EB Clinic Settings, per clinic. ([deploy guide](docs/deploy_whatsapp.md))

#### Fixed
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — **"Consent Ending" had been sending nothing for weeks, silently.** Its `phone_field_path` was empty, and a send with no phone path returns before the consent gate with no error at all — so the daily job ran, reported success and messaged nobody. Both it and Appointment Reminder are repaired by a patch; the seed now sets the field per config so fresh sites cannot land in that state.
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The consent-ending warning goes to the number the consent actually covers (`phone_number`), not the patient's own mobile. On a guardian's consent those differ, and messaging the child's number would have failed the consent gate anyway.

#### Notes
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The two reminder channels are guarded separately, so one can be skipped or retried without affecting the other. Verified end to end against a real appointment and a real handset; repeat cron runs send nothing further.


### 2026-09-28 · Inbound patient WhatsApp messages were being discarded

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend (docs) · **Branch:** `feat/whatsapp-cont-backend`
**Related:** [WHATSAPP_INTEGRATION §17](docs/WHATSAPP_INTEGRATION.md) · [KNOWN_ISSUES](docs/KNOWN_ISSUES.md) · [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Security
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — **Every inbound patient WhatsApp message has been silently discarded**, along with every delivery receipt. The Meta app's webhook `callback_url` points at an ngrok tunnel that no longer exists, so Meta has been POSTing patient messages to a 404. Measured: 0 inbound in 6 hours against 23 outbound. Needs a reachable URL — no code change. ([known issue](docs/KNOWN_ISSUES.md))

#### Notes
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The keyword auto-reply is **not** broken: `_match("I want to book appointment")` resolves to `auto_reply_book_v3`, proven by posting a signed webhook to the local endpoint — the reply went out two seconds later. It only looked broken because the chat shows a stale "waiting for a clinician" banner from an older message.
- **2026-09-28** · `docs` · Ashutosh (AI-assisted) — `WHATSAPP_INTEGRATION.md` §17 now documents the two URLs that must be publicly reachable by Meta, why an unreachable header image is invisible (accepted, `wamid` issued, never delivered, `health_status` still `AVAILABLE`), and the one-comparison diagnosis: send a template with a header and one without.


### 2026-09-28 · WhatsApp notifications were silently dropped by a dead image URL

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend (site config + template data) · **Branch:** `feat/whatsapp-cont-backend`
**Related:** [WORK_LOG — 2026-09-28](WORK_LOG.md)

#### Fixed
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — **Booking an appointment sent no WhatsApp at all on the production account, with no error anywhere.** `whatsapp_header_image_url` pointed at an ngrok tunnel that had died. Every branded template is approved with an image header, and Meta fetches that image when building the message — if the fetch fails the message is accepted, given a message id, and then silently dropped. Now points at `https://mycare.narzim.com/narzim-logo.png`, on the portal's own domain. Verified end to end with a real booking.
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — 12 `WhatsApp Templates` records declared `header_type: IMAGE` with no image configured, so notifications went out with no header at all against templates that require one. All now carry the header image.
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — The production WhatsApp number had **never been registered on Cloud API**, which is why the approved display name "Narzim Healthcare" could not activate. Registered; the name went live immediately.

#### Security
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — **No app was subscribed to the production WABA's webhooks** (`subscribed_apps: []`). Beyond losing delivery receipts, every inbound patient reply to the production number would have been discarded without trace. Subscribed.

#### Notes
- **2026-09-28** · `backend` · Ashutosh (AI-assisted) — For anyone who meets this again: an unreachable template header image produces `200` + a `wamid` + `message_status: accepted` and no delivery, no error and no webhook. `health_status` stays `AVAILABLE` because it reports account health, not media fetchability. The fastest diagnosis is to send one template **with** a header and one **without** — that single comparison isolates it in minutes.


### 2026-09-25 · Staff banners name the patient, without sending the name through Google

**Author(s):** Ashutosh (AI-assisted) · **Repos:** backend + EHR frontend · **Branch:** `dev`
**Related:** [ADR-093](docs/adr/adr-093-patient-name-in-staff-push-banners.md) · [PUSH_NOTIFICATIONS §4.4](docs/PUSH_NOTIFICATIONS.md) · [WORK_LOG — 2026-09-25](WORK_LOG.md)

#### Changed
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — **A staff desktop notification now reads "Khalid Kashmiri sent a message" rather than "New message from a patient"**, so a message can be triaged without opening the app. It reuses the same sentence the in-app bell already shows, so the two cannot drift apart. ([ADR-093](docs/adr/adr-093-patient-name-in-staff-push-banners.md))

#### Added
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — `push.api.notification_preview(event_type, ref)` returns the subject of the notification row **addressed to the caller**, for the service worker to put on the banner. A caller can only read back a notification already sent to them; a guessed reference returns an empty string.

#### Security
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — **The FCM payload is unchanged and still content-free.** The patient's name is fetched by the service worker from our own origin at display time, so Google's copy remains a generic title plus three identifiers. This is deliberate: it is the reason FCM stays out of the subprocessor register on the same argument the `mx` profile makes for NCBI, and it keeps the pending Google data-terms check the same size.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — Accepted risk, recorded rather than assumed: a banner naming a patient can appear on an unattended front-desk screen. Four options were put to the product owner and "on for everyone, no toggle" was chosen. The banner is still suppressed whenever an EHR window is visible and carries no message text. ([ADR-093](docs/adr/adr-093-patient-name-in-staff-push-banners.md))


### 2026-09-25 · Staff now get desktop notifications when the EHR is closed

**Author(s):** Ashutosh (AI-assisted) · **Repos:** EHR frontend (+ backend docs) · **Branch:** `dev`
**Related:** [PUSH_NOTIFICATIONS §4.8](docs/PUSH_NOTIFICATIONS.md) · [KNOWN_ISSUES](docs/KNOWN_ISSUES.md) · [WORK_LOG — 2026-09-25](WORK_LOG.md)

#### Added
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — **A patient message, booking, cancellation or reschedule now raises a desktop notification for the staff who should see it, even with every EHR tab closed.** Previously the backend addressed these to the EHR and found no device to send to, so out-of-hours they reached nobody until someone opened the app. Who receives one is unchanged — the Patient Coordinator and Front Desk roles, or the one person a conversation was assigned to. ([§4.8](docs/PUSH_NOTIFICATIONS.md))
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — An opt-in card on the EHR notifications page asks for notification permission from an explicit click, never on page load, and states that notifications stop at sign-out so a shared workstation never alerts the next person.

#### Changed
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — The EHR's CSP allows two Firebase origins in `connect-src` so token registration is not blocked. The test asserting no other third-party origin appears was widened to exactly three named origins rather than removed — that test is the thing preventing the BFF guarantee eroding quietly.
- **2026-09-25** · `docs` · Ashutosh (AI-assisted) — The `KNOWN_ISSUES` entry "Neither frontend sets a Content-Security-Policy" was **wrong**: both have had one since 2026-09-02. It is built in `csp.ts` and applied in `proxy.ts`, not `next.config.ts`, so the grep behind the original entry missed it. Rewritten around what is genuinely still open — both policies are Report-Only and therefore block nothing. ([entry](docs/KNOWN_ISSUES.md))

#### Security
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — Push registration is dropped on sign-out **before** the session is torn down, because unregistering is an authenticated call. Clinic workstations are shared, so a token left live would send the previous user's patient notifications to whoever signs in next.
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — The EHR's service worker is push-only and deliberately caches nothing. The portal's equivalent owns an offline shell; doing that here would let the EHR serve a stale patient chart, which is worse than an honest network error.

#### Fixed
- **2026-09-25** · `frontend` · Ashutosh (AI-assisted) — **The EHR's notification icon was a rounded square while the portal's was a circle**, so the same product showed two different shapes side by side in macOS Notification Centre. The EHR's notification icons now come from the circular Narzim mark and are byte-identical to the portal's. The in-app header logo (`narzim-logo.png`, a rounded square) is unchanged — only the notification assets moved.

#### Notes
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — **No backend change was required.** `_APPS` already accepted `"EHR"`, the doctype already allowed it, and every staff event was already routed there. The work was entirely a missing receiver. The deferral had also recorded the CSP as a precondition; by the time it was picked up that precondition had been met three weeks earlier, so a one-line change had been reading as a blocker.


### 2026-09-25 · Push notifications carry the real logo, and finally speak Spanish

**Author(s):** Ashutosh (AI-assisted) · **Repos:** patient portal + backend · **Branch:** `dev`
**Related:** [PUSH_NOTIFICATIONS §4.7–4.8](docs/PUSH_NOTIFICATIONS.md) · [WORK_LOG — 2026-09-25](WORK_LOG.md)

#### Fixed
- **2026-09-25** · `patient-portal` · Ashutosh (AI-assisted) — **Push notifications showed a navy square with a white cross instead of the Narzim logo.** That placeholder had never been the product's mark. All portal icons are now generated from `src/app/icon.png`, the same 660x660 pulse mark the portal header and the Apple touch icon already used. ([assets](docs/PUSH_NOTIFICATIONS.md))
- **2026-09-25** · `patient-portal` · Ashutosh (AI-assisted) — The notification **badge** pointed at the full-colour 192px icon. Android masks a badge to a flat silhouette, so it rendered as a solid grey blob; it is now a dedicated 96px alpha stencil of the pulse glyph alone.
- **2026-09-25** · `patient-portal` · Ashutosh (AI-assisted) — The web app manifest advertised no **maskable** icon, so Android letterboxed the round mark inside a white square on the home screen. A full-bleed maskable variant is now declared.
- **2026-09-25** · `patient-portal` · Ashutosh (AI-assisted) — The manifest called the app **"Patient Portal"** with a `theme_color` of `#2563eb`, a blue that appears nowhere in the brand. It now reads "Narzim · Patient Portal" and tints to the mark's own teal `#0E5358`, matching the title already set in `layout.tsx`.
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — **Push notifications reached Spanish-speaking patients in English**, in the jurisdiction where Spanish is the locked default. The machinery to render in the reader's language was already correct; the strings were simply never in the catalogue. All 22 event titles and the 8 patient-facing bodies are now translated, patient copy using informal *tú* to match the portal. ([§4.7](docs/PUSH_NOTIFICATIONS.md))

#### Changed
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — Patient-facing push copy is warmer and now carries a second line: *"See you soon 👋 / Tap to see your appointment details"* rather than a bare label. Staff events keep title-only banners, because their titles already say the whole thing. The payload stays content-free — no patient name, no message text ever reaches the lock screen.

#### Notes
- **2026-09-25** · `backend` · Ashutosh (AI-assisted) — Recorded a trap that cost real time: `_()` reads a compiled `es.mo` build artefact under `sites/assets/`, **never** `locale/es.po`. Editing the `.po` alone changes nothing, and the failure looks like a routing bug. `bench build` compiles it; `bench migrate` does not. The `.mo` on this bench had been stale since 2026-07-01, holding 150 of 181 messages.


### 2026-09-10 · Frappe Assistant Core evaluated, and the developer verification path made one line

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend (docs + dev tooling) · **Branch:** `docs/remedisys-v2-target-architecture`
**Related:** [FAC evaluation](docs/architecture/FAC_EVALUATION.md) · [ADR-030](docs/adr/adr-030-llm-curated-tool-access.md) · [WORK_LOG — 2026-09-10](WORK_LOG.md)

#### Added
- **2026-09-11** · `docs` · Sarvesh-SocialAngel (AI-assisted) — **The token argument is now explained from scratch, for a reader who has never thought about tokens.** Two small worked examples, both counted with the real tokenizer rather than described: the same fact written as a sentence costs 7 tokens and written as JSON costs 16, and one prescription row costs **124 tokens** the generic way against **18** ours, because the generic call asks for all sixteen fields when the doctor needed three. Multiplied by the 200 rows such a call is allowed to return, that is 24,800 tokens against our own 4,000-token limit, from a single call on a single table. This is the mechanism behind the headline number, and it is easier to check than the headline. ([plain-language explanation](docs/architecture/FAC_DECISION_SUMMARY.md#first-in-plain-language-what-a-token-is-and-why-json-is-expensive))

#### Changed
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — **Every token figure in the FAC documents has been recounted with a real tokenizer instead of a rule of thumb**, after the question "how was this calculated?" was asked and the honest answer was "bytes divided by four". That shorthand undercounts JSON by about a fifth, because braces, quotes and field names cost more than plain prose. Recounted with `tiktoken`: our tools send **1,027** tokens for one patient's context and the generic approach sends **104,551**, so the headline moves from 97x to **102x**. Every earlier claim was conservative rather than overstated. The decisive 373x context figure came out identical either way. A per-call breakdown is now printed so anyone can check the totals add up. ([method](docs/architecture/FAC_DECISION_SUMMARY.md#how-those-token-numbers-were-counted))

#### Changed
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The bottom line in both FAC documents now sits at the **end** rather than the top, which is where a bottom line belongs. The short team version reads as evidence first and verdict last (§9), with the clinical story moved up to §3 so the point lands early without pre-announcing the conclusion. Content unchanged; only the order. ([team summary](docs/architecture/FAC_DECISION_SUMMARY.md))

#### Changed
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — **Both FAC documents now open with the finding that actually decides it, which had been buried in the middle.** The reason anyone wanted FAC was the belief that it removes the work of building tools. It does not, not for this product: its 24 tools are generic get, list, create, update, delete, search and report, and **not one of them knows what an allergy is, what a context budget is, or that a clinical change must be reviewed by a doctor first.** We would write all 36 of our tools either way. FAC's own extension hook for other apps to add tools is the upstream admission of the same thing. ([bottom line](docs/architecture/FAC_DECISION_SUMMARY.md))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Recorded where FAC **is** a good fit, so the recommendation is not read as a blanket dismissal: an outside general-purpose AI client such as Claude Code or ChatGPT exploring a Frappe site, where nobody can predict the questions and a wide generic surface earns its place. Our clinical copilot is the opposite case, and there the narrowness of our own tools is the safety feature rather than a limitation.

#### Added
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — There is now a **two-page version of the FAC decision for the team**, separate from the 25-section evaluation: the question, one story about prescribing amoxicillin to a 4-year-old, the measured numbers, and the conclusion. It also answers two things a reviewer asked for that the long version had not addressed head-on. First, the security of **our own** tools, counted rather than assumed: all 13 read tools carry a permission check, the write gate is document-level, and there is no raw SQL, no permission bypass and no database write anywhere in the tool layer, but three real weaknesses were found and written down. Second, whether FAC could simply host all 36 of our tools: it could, via its `assistant_tools` hook, at which point FAC contributes only a transport we do not need, an audit log we are not allowed to use, and an AGPL licence around our clinical code. ([team summary](docs/architecture/FAC_DECISION_SUMMARY.md))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Measured our tools against the generic equivalent for one real patient context: **4 calls, 45.6 ms and 3,449 bytes ours, against 6 calls, 77.6 ms and 335,722 bytes generic. 97x more data for the same answer.** Two calls caused it: listing vital signs returned 104 KB and listing the patient's encounters returned 227 KB. ([§4](docs/architecture/FAC_DECISION_SUMMARY.md#4-speed-measured-same-clinical-question))

#### Changed
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — **The FAC evaluation has been rewritten around the right question.** It was framed as "is this useful to Claude Code", which is a developer-tooling question. The question that matters is whether it should be the tool layer for the **production clinical AI the doctor uses**, and that is now section 25 and the executive summary. Claude Code is kept in as a separate, much less important developer note. ([evaluation](docs/architecture/FAC_EVALUATION.md))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Written down, with file and line references, where our production AI actually runs: the frontend holds **no** model library and calls no AI provider. It proxies to the backend, which runs the model and a tool loop capped at twenty steps inside Frappe. Worth recording because the phrase "frontend LLM" suggests otherwise, and the wrong picture leads to the wrong answer about FAC. ([§2.10](docs/architecture/FAC_EVALUATION.md#210-the-production-ai-runtime-precisely-added-v20))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Corrected our own measurement: the 85 ms per call quoted earlier was a read that does real database work, not the cost of the network hop, which is about **5 ms**. This makes the case against FAC in production *less* about speed and more about context size and server capacity, and the document now says so.

#### Security
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — **Measured what a generic tool would cost the clinical AI in context, and it is not a small number.** Reading one patient's encounter history the generic way costs **269,239 tokens** on this site, against **721** the way we do it now: 373 times more, and 67 times our own 4,000-token limit. Even a realistic long-term patient with forty visits is nearly three times over the limit. The limits in our tool layer are not tuning knobs, they are what makes the rule true. ([§25.7](docs/architecture/FAC_EVALUATION.md#257-token-usage-measured))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Recorded that adopting FAC for the clinical AI would let a language model write a prescription **with no allergy check, no duplicate check and no physician review**, because those live in our tool layer and not in the model. Our write tools cannot touch the database at all; they can only propose. ([§25.3](docs/architecture/FAC_EVALUATION.md#253-clinical-safety))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Also recorded the one genuine hole FAC exposed in **our** design, which is worth more than the rest of the evaluation: we cannot reconstruct *why* the AI suggested something, because our audit log deliberately stores tool names and no content. FAC would fix that by storing patient data for 180 days, which we will not do. The proper fix is already a top-priority item in the AI plan. ([§25.10](docs/architecture/FAC_EVALUATION.md#2510-the-honest-case-for-fac-in-production))

#### Added
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — There is now a full evaluation of whether **Frappe Assistant Core** belongs in this project, in twenty-four sections, with every claim either measured on the live dev site or traced to a file. The answer: **do not install it**. It would be defensible on a bench with no real patients, and it has no place anywhere near the product, but across seventeen developer tasks it turned out to provide nothing we do not now have. ([evaluation](docs/architecture/FAC_EVALUATION.md))
- **2026-09-10** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Checking whether something actually saved is now **one line instead of five**. [`scripts/dev/frappe_probe.sh`](scripts/dev/frappe_probe.sh) reads the local site over HTTP, caches its login for forty minutes, and has subcommands for counts, child-table rows, a whole document, live schema and any whitelisted method. Measured at about a fifth of a second per read, against roughly three seconds for the `bench` equivalent.
- **2026-09-10** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The same script can show the fields a DocType **really** has on the site, including customisations. This matters more than it sounds: Patient Encounter has 39 fields in the file on disk and 3 extra custom fields plus one overridden property on the live site, so code written from the file alone is written against a schema the site does not have.
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The evaluation now includes an **incremental-value test**: seventeen developer tasks, each asking not "is FAC useful" but "what does FAC give us that we do not already have". The answer is nothing, on all seventeen, once the one-line read helper exists. It also separates four things that are usually muddled together: the FAC app, the MCP protocol, our own clinical tool registry, and plain scripts. ([§21 and §22](docs/architecture/FAC_EVALUATION.md#21-incremental-value-test))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Recorded a correction that matters for any future "let us just expose our tools over MCP" plan: our clinical tool registry **cannot** answer developer questions, because every tool in it requires an encounter and a patient by design. Exposing it over MCP would not give a developer a way to ask "what fields does this DocType have". ([§22.2](docs/architecture/FAC_EVALUATION.md#222-architecture-b-has-a-defect-that-must-be-said-plainly))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The command reference now has a section on **which door to use** when verifying against Frappe, with the measured cost of each, and a note that "the database has it but the screen is empty" is usually a bug above Frappe that no amount of database reading can see. ([reference](docs/CLAUDE_CODE_COMMANDS.md))

#### Security
- **2026-09-10** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The new script **refuses to run against anything that is not a local host**, so it cannot be pointed at the production site by accident or by a stray environment variable. Its credentials live in a gitignored file and are never read from the repository. ([why](docs/architecture/FAC_EVALUATION.md#15-development-vs-production))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Recorded that Frappe Assistant Core's audit trail stores both the arguments and the **results** of every tool call, for 180 days by default, and redacts credentials rather than patient data. On a site holding real patients that is patient data written into a second store, which our own rules forbid. This is the main reason the evaluation keeps it off any site with patients. ([evaluation §14](docs/architecture/FAC_EVALUATION.md#14-security--phi--hipaa))
- **2026-09-10** · `docs` · Sarvesh-SocialAngel (AI-assisted) — Restated, because it is still open: Frappe Assistant Core was installed on `remedisys.localhost` on 2026-08-27 against an accepted decision record that rejects it by name, and that contradiction has not been resolved either way. ([ADR-030](docs/adr/adr-030-llm-curated-tool-access.md))

---

### 2026-09-04 · The follow-up interval the note already states

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `feat/extract-followup-from-plan`
**Related:** [plan](docs/planning/ENCOUNTER_V3_VALIDATION_AND_FOLLOWUP_PLAN.md) §5 · [WORK_LOG](WORK_LOG.md)

#### Added
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **A note that says "return for follow-up in 3 days" now fills the follow-up field with 3 days.** The interval was already written in the Plan and the physician still had to re-enter it by hand. Reads Spanish too ("seguimiento en 2 semanas"). Uses the extraction call the encounter already makes — no additional AI request. ([prompt](prompts/note-extract-v2.txt))

#### Security
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **A review date is never invented.** "Return if symptoms worsen" states no interval, so nothing is filled — a conditional instruction and a scheduled review are different clinical things, and turning one into the other would put an appointment on the record the clinician never ordered. Verified against the live model on four notes including that exact case.
- **2026-09-04** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — **An interval the form cannot represent leaves the field empty rather than rounding.** A note reading "recheck in 10 days" no longer becomes a 1-week appointment: the six offered intervals are matched exactly or not at all. Rounding a clinical interval silently is how a prior bug booked seven days for a value nobody chose.

### 2026-09-04 · A reload during recording no longer destroys the encounter

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend · **Branch:** `feat/ai-session-consent-reattach`
**Related:** [ADR-059](docs/adr/adr-059-stale-recording-session-resume-or-supersede.md) · [investigation](docs/_archive/prompts/2026-09-04-dev-mic-record-consent-missing.md)

#### Fixed
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **Reloading the tab mid-recording no longer makes an encounter permanently un-recordable.** A session only leaves `Recording` when the clinician presses stop, so a reload or a closed tab stranded it there; the consent gate then asked again and the answer was rejected for ever. 31 encounters were stuck this way, the oldest since 29 August. Answering the gate now resumes the recording where real consent evidence exists, and starts a clean one where it does not. ([why](docs/adr/adr-059-stale-recording-session-resume-or-supersede.md))
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — A clinician who lands on an encounter a colleague is already recording is now told exactly that, instead of "Consent can only be recorded before recording starts." The colleague's recording is left running.

#### Security
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — **A recording that nobody consented to can never be resumed.** Sessions opened by V1's auto-start carry `consent_obtained = 1` written in the browser with no one asked — 25 of the 31 stuck sessions. These are now closed and a real consent question asked, rather than being adopted as though consent had been given. ([PHI-2](CLAUDE.md))
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Consent is never back-dated. Resuming a recording leaves the original consent record untouched, so `consent_obtained_at` keeps the time the family actually answered.

#### Added
- **2026-09-04** · `backend` · Sarvesh-SocialAngel (AI-assisted) — `get_active_session` now reports `consent_method`, the only field that separates a consent a human gave from one the browser asserted. First test coverage for that endpoint.

### 2026-09-03 · Every reports gap now says who it hurts and shows the numbers

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `feat/reports-hidden-and-role-gate-docs`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [`GAPS.md`](docs/reports/GAPS.md)

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **All 54 reports defects now describe a real person hitting them**, in the same shape: who does what, what the screen says, what the database actually holds, and what follows. The register previously listed 54 correct technical findings and no reason to care about any of them. ([register](docs/reports/GAPS.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Each one carries a worked example with the real measured values — the 0-minute "fastest doctor", the 149-millisecond check-in, the 22.5-hour working day — so a figure can be checked rather than taken on trust.
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — For the five gaps that have **no data to measure**, the example states the measured absence (`Holiday List`: 0 rows) instead of an estimate, so nothing in the document is inferred.

#### Fixed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **One gap turned out to be already fixed and nobody had noticed.** The reports guide that described a landing page which no longer exists was superseded on 3 September; the register still listed it as outstanding. Count is now 54 found, 1 fixed, 53 open. ([G-44](docs/reports/GAPS.md#g-44))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Corrected the hidden-report count from two to three, stale since Claims Status was hidden earlier the same day. ([G-17](docs/reports/GAPS.md#g-17))


### 2026-09-03 · Claims Status hidden until insurance ships

**Author(s):** Anant Sharma (AI-assisted), at Ishmita's request · **Repos:** frontend + backend (docs) · **Branch:** `feat/reports-hidden-and-role-gate-docs`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [G-29](docs/reports/GAPS.md#g-29) · [`12-claims-status.md`](docs/reports/12-claims-status.md)

#### Changed
- **2026-09-03** · `frontend` · Anant Sharma (AI-assisted) — **Claims Status is no longer listed on the Reports page.** No insurance claims exist in the system yet, so all four of its figures read zero — which a reader takes as "nothing was rejected" rather than "insurance is not running yet". It comes back when insurance goes live. Nothing was deleted: anyone holding the direct link can still open the page. ([the report](docs/reports/12-claims-status.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Recorded the cost of hiding it rather than leaving it implied: **Front Desk can now reach exactly one financial report**, Payment Methods. Of the two that are hidden, Outstanding Balances is the one that could be restored today — it has 94 real rows — while Claims Status has to wait for Phase 3 insurance. ([G-29](docs/reports/GAPS.md#g-29))

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **One place now records every report hidden from the Reports page, why it was hidden, and the specific thing that brings it back.** Writing it down immediately surfaced that Outstanding Balances has been hidden since 31 August for a reason that stopped applying the same day — the clinic's only view of aged debt, 94 real invoices, sitting one line away from being usable. ([the register](docs/reports/HIDDEN_REPORTS.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Stated explicitly that hiding a report is **not** a permission: the page, its route and its endpoint all keep working, so the role gate on the endpoint is the only real boundary. ([why](docs/reports/HIDDEN_REPORTS.md))

### 2026-09-03 · A single ordered plan for all Reports work

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [`BACKLOG.md`](docs/reports/BACKLOG.md)

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **There is now one ordered plan for everything outstanding on Reports: 55 items in 7 phases**, covering all 54 known defects plus the reports we should build. Each task says how big it is, which file it touches, and what it depends on. ([the plan](docs/reports/BACKLOG.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — The plan states **why** the order is what it is, so it can be argued with: anything that could affect a person comes first, then stopping a wrong number from being believed, then making reachable the reports that already work — and only then charts and styling.
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **A one-week option** is written out for when there isn't more time: it closes the money exposure and the person-affecting risk, makes what the clinic is owed reachable again, and ships the two most urgent missing reports.

#### Changed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Removed the second, shorter priority list that had grown in the role-coverage document. Ordering now has one owner, so the two cannot drift apart.

### 2026-09-03 · The gap register now says how many are fixed

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [`GAPS.md`](docs/reports/GAPS.md)

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **The Reports defect list now tells you where it stands: 54 found, 0 fixed, as of 3 September.** Every entry carries a state, and the page says how that state was checked — 24 of them re-tested against the current code, all still reproducing. ([register](docs/reports/GAPS.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Added the rule for keeping it honest: when something is fixed, mark it fixed with the date and say what changed — never delete the entry, because the record of what was wrong is what stops it happening again.

### 2026-09-03 · Which reports to keep, cut, and build — decided on measurement

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [portfolio decision](docs/reports/ROLE_COVERAGE.md)

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Every report now has a keep / fix / merge / cut verdict, scored on five things you can check** — how much of it actually has values, whether its inputs measure what its name says, whether anyone can reach it, whether another report already answers it, and whether you can act on it. ([the scorecard](docs/reports/ROLE_COVERAGE.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Eleven reports we should have, each confirmed against the live database** rather than assumed — including a lab results-awaiting-review queue, an immunization due list, and aged unsigned notes. Seven more are listed as blocked, each naming exactly what blocks it, so nothing gets promised that cannot be built. ([the list](docs/reports/ROLE_COVERAGE.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **14 completed lab results have never been reviewed**, the oldest since 18 August. Nothing in the product shows them. Recorded as a gap, and as the highest-value report the module does not have. ([G-52](docs/reports/GAPS.md#g-52))

#### Fixed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Corrected a figure we had labelled "revenue leakage".** The 24,200.72 MXN was billed and collected — it just cannot be credited to any doctor. The same invoices also carry 16,938.08 in credit notes, so the clinic actually kept 7,262.64 of it. ([G-24](docs/reports/GAPS.md#g-24))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Recorded that crediting those invoices to a doctor via the patient is **not possible**: 113 of the 115 patients have no encounter at all in the period. The fix has to happen in billing, when the charge is raised.

#### Added
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **46 attended appointments raised no invoice last month, 27 of them with a written-up consultation** — work that may never have been charged for. No report asks this, because every financial report starts from invoices. ([G-54](docs/reports/GAPS.md#g-54))

#### Changed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Two reports are now marked for removal:** Chronic Care (only 1 of its 4 figures has a value, and the rest repeats Diagnosis Trends) and Average Visit Time's doctor-versus-doctor ranking (it names a "fastest" doctor whose average consultation is zero minutes, from a single visit). Both metrics survive elsewhere; the separate pages do not.
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **The utilization problem turned out to be far smaller than reported.** Ten practitioners are each rostered onto all three shifts at once, which is where the 22.5-hour working day comes from. It is about twenty duplicate rows to delete, not a schedule redesign — and the write-up now also says what fixing it will *not* achieve. ([G-37](docs/reports/GAPS.md#g-37))

### 2026-09-03 · One report, one file — reporting documentation consolidated

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md) · [`docs/reports/`](docs/reports/README.md)

#### Changed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Everything about a report is now in one file.** Reporting documentation was spread over 37 files in three folders, and a single report's facts sat in as many as five of them. Open the numbered file for the report you want and it now tells you what it is for, the formula behind every figure on the page, whether those figures can be trusted, and what is wrong with it. ([start here](docs/reports/README.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Rules that apply to every report — the date window, who can see whose data, what a dash means, the response shape, and the five different things "collected" and "outstanding" can mean — are now stated once in Part 2 of the index instead of being repeated in each report. ([shared mechanics](docs/reports/README.md))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Dated audits and snapshots moved to [`docs/reports/archive/`](docs/reports/archive/README.md), so the folder you browse holds only documents that still claim to be true. **Nothing was deleted** — the six absorbed documents are in the archive marked `superseded`, each naming what replaced it.
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Each report page now records what the screen *actually* shows, which is not always what the API returns: the hourly chart's four toggled series, the *Completed* → **Checkout** rename, and that R-10 is titled **"Financial Report"** since 2026-09-01 though its address is unchanged.

#### Fixed
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — Corrected a claim that the removed Financial Report rows were "still reachable" through a detail endpoint. They are not: nothing in the app can call it. ([G-11](docs/reports/GAPS.md#g-11))
- **2026-09-03** · `docs` · Anant Sharma (AI-assisted) — **Six** figures are now known to be calculated and never shown, across four reports — up from two. They are disproportionately the ones that would tell a reader the remaining figures are unreliable. ([G-51](docs/reports/GAPS.md#g-51))

### 2026-09-03 · Appointment list shows the date; Encounters list shows one identifier per row

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-03](WORK_LOG.md)

#### Added
- **2026-09-03** · `frontend` · Anant Sharma (AI-assisted) — The Appointments list now has a **Date** column, between Patient and Time. Viewing a week, a month or a custom range previously showed only a clock time on every row, with no way to tell which day an appointment fell on.

#### Changed
- **2026-09-03** · `frontend` · Anant Sharma (AI-assisted) — The Encounters list no longer prints the appointment number underneath the encounter number. The column now shows the encounter number alone. Opening the linked appointment is unchanged — it is still on the row's `⋮` menu, and the appointment number is still searchable.

### 2026-09-02 · The recording screen stops claiming things it never checked

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend + frontend · **Branch:** `audit/capture-and-review-note` (backend) / `fix/drop-path-tells-the-truth` (frontend)
**Related:** [Capture audit](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md) · [WORK_LOG — 2026-09-02](WORK_LOG.md)

#### Security
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — When the speech service drops, the screen no longer says "everything transcribed so far is saved" without checking. It now says finished lines were saved and anything still being spoken was not, and if a save really failed you get the counts and a Retry instead of a false reassurance. ([why](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md))
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — A dropped recording no longer closes the visit's recording session when the transcript failed to save, so the words can still be retried. Previously the session was closed either way, which made a failed save permanent.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Correcting a transcript now refuses a badly numbered set of lines instead of deleting rows by position. Nothing was being lost, but the old cleanup would have silently deleted the last line of every corrected transcript if a caller ever numbered from 1.

#### Added
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Lines still being spoken are marked "Not saved yet" in the transcript, so it is visible which words are safe and which are not.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — Every AI call now records how much of its prompt was reused from cache and how many tokens went on reasoning, not just the chat assistant. First measurement: 72% of a note-gap prompt was cached.
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — An audit of the capture screen: what one press of "Review the note" costs, where every row is written, and eight gaps with their evidence. ([read it](docs/audit/ENCOUNTER_CAPTURE_AUDIT.md))

#### Fixed
- **2026-09-02** · `backend` · Sarvesh-SocialAngel (AI-assisted) — The "said but not written" check was recording a cost of zero on every call. It now records what it actually costs. **Historical rows are still wrong** and need a separate backfill — see the audit, gap G5.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — "Could not verify the transcript's speaker labels" no longer appears over a perfectly good transcript. Two processing passes were running at once and one lost a write race.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The "Still checking the consultation" line no longer stays on screen for ever after pausing the microphone.
- **2026-09-02** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The consultation screen no longer stutters while you talk, and the note now appears about twelve seconds sooner because the "said but not written" check runs underneath it instead of in front of it.

### 2026-09-02 · Every report now has a written verdict, and the module has a current defect list

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-02](WORK_LOG.md) · [`docs/reports/`](docs/reports/README.md)

#### Added
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Every report now has its own page saying what it is for, how its numbers are worked out, when they can be trusted, and **whether it is worth keeping** — with a worked example using real figures from the live site. 17 reports, including the landing-page figures nothing currently displays. ([index](docs/reports/README.md))
  - **2026-09-02** update — Reports are now numbered **R-01 to R-17**, grouped the way the product groups them, so a report can be referred to by number in a ticket or a conversation. The number is on each page and in the index. ([how the numbering works](docs/reports/README.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — A current list of everything wrong with Reports: **51 items**, ranked by severity, each with the evidence behind it and a suggested fix. Replaces the frozen August audit as the place to look. ([register](docs/reports/GAPS.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — What each role can actually open today, what their job needs, and which reports should be built for Front Desk, Nurse, Practitioner and Admin — in priority order, marked by whether the data already exists. ([role coverage](docs/reports/ROLE_COVERAGE.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — A presentation standard for reports: which chart suits which kind of number, which colours may mean what, what must always be shown beside a figure, and what "customizable" should mean. ([standard](docs/reports/DESIGN_STANDARD.md))

#### Security
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — **Recorded that the Reports landing-page figures have no role check.** The two methods behind them return clinic revenue and total money owed to any role that can read appointments, including Nurse — the report the rest of the module is careful to withhold. Nothing in the app calls them today, but they remain callable. ([G-42](docs/reports/GAPS.md#g-42))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Recorded that **4 of 45 vaccine doses have no recorded consent**, that the report shows this only as a percentage, and that there is no way to find out which four children. ([G-01](docs/reports/GAPS.md#g-01))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Recorded that Average Visit Time names a **fastest doctor whose average consultation is zero minutes, from one encounter**, and marks them as meeting target — on an admin page used to compare clinicians. ([G-33](docs/reports/GAPS.md#g-33))

#### Fixed
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Recorded that Revenue by Provider stopped showing its refund warning: it looks for a figure the server no longer sends, so **16,938 MXN refunded to patients is stated nowhere on the page**. ([G-04](docs/reports/GAPS.md#g-04))

### 2026-09-02 · Every report card now has a written derivation

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-02](WORK_LOG.md) · [`docs/reports/archive/REPORTS_CARDS.md`](docs/reports/archive/REPORTS_CARDS.md)

#### Added
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — You can now look up any number on any Reports page and find out how it was worked out and which record it came from. Five documents: one for the rules every report shares, and one each for [Operations](docs/reports/archive/REPORTS_CARDS_OPERATIONS.md), [Clinical](docs/reports/archive/REPORTS_CARDS_CLINICAL.md), [Financial](docs/reports/archive/REPORTS_CARDS_FINANCIAL.md) and [Provider](docs/reports/archive/REPORTS_CARDS_PROVIDERS.md) reports — 16 reports, every card and chart. ([index](docs/reports/archive/REPORTS_CARDS.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Each report now states in writing what it deliberately does **not** measure, and why — no-show reasons, chronic classification, vaccination coverage, per-provider refunds — so an empty card can be told apart from a broken one.
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — The three different meanings of "collected" across the financial screens are written down side by side, with the basis each one uses. ([detail](docs/reports/archive/REPORTS_CARDS_FINANCIAL.md))

#### Changed
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — [`REPORTS_API.md`](docs/reports/API.md) and [`REPORTS_GUIDE.md`](docs/reports/archive/REPORTS_GUIDE.md) now point at the new reference; they keep the contract and the page descriptions, and no longer imply they explain the arithmetic.

### 2026-09-02 · Reports: filter any report by practitioner, and three cards fewer

**Author(s):** Ishmita (AI-assisted) · **Repos:** frontend · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-02](WORK_LOG.md)

#### Added
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **Every report can now be filtered to one practitioner.** The "Filter by practitioner" selector beside the period buttons is on all 15 period-based reports, up from 3. The choice stays in the address bar, so Back returns to it, and it travels into any card you drill into. My Performance is excluded — it is already your own numbers.
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — Revenue by Provider is one of them. Note that with a single doctor selected its comparison cards stop being comparisons: Top Earner is whoever you picked, and their share is 100%.

#### Added
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — Billing can be filtered by payment method. It arrives from a Payment Methods report card as a removable chip, alongside the status and practitioner filters.

#### Removed
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — Queue Wait Times no longer shows the **Median wait** card, and Check-in Rates no longer shows **Median lateness**. Both figures are still calculated and returned, so either card can be put back by request.
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **Diagnosis Trends is no longer listed** on Analytics & Reports. The report itself still works for anyone holding the link — listing only, same as Outstanding Balances.

#### Changed
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — On Payment Methods, **"Daily Collection Trend" is now "Collection Trend" and leads the page**, above Payment Split and Method Volume — when the money arrived is the question a cash-flow page is opened with. ([why](WORK_LOG.md))

#### Fixed
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **The date filter on every report said "All dates" when it was not showing all dates.** A period is always in force — This Month if you pick nothing — so the pill now reads "Custom range", matching Appointments and Patients. The data it returned was always correct; the label was not. ([why](WORK_LOG.md))
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **The Arrival Status donut on Check-in Rates had an unlabelled legend** — four coloured dots and no words, so nothing said which slice was On-time, Early, Late or No-show. The names are back, and translated. Slice colours are unchanged. ([why](WORK_LOG.md))
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **The collection trend rendered as a single dot in an empty box.** It only plotted days that took a payment, so one paying day had no line to draw, the axis showed a raw `2026-09-01`, and the amounts wrapped onto two lines. It is now a filled area over the whole period to date, with readable dates and amounts. Days still to come are left off rather than drawn as zero — the chart does not claim nothing was collected on a day that has not happened.
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **Clicking a payment-method card no longer opens every payment.** Wire Transfer opened a list that included Cash, because all four method cards led to the same unfiltered invoice list. Each card now opens the invoices settled by that tender, shown as a removable filter chip. An invoice part-paid two ways appears under both of its methods, which is why a method's rows can overlap. ([why](WORK_LOG.md))
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — **Financial report cards stopped opening once you picked a practitioner.** Payment Methods lost all five drill-downs, Revenue by Provider lost Total Collected and Outstanding Balances lost every money card, with nothing on screen explaining why. The practitioner now travels with the link: the card opens Billing already narrowed to that doctor, shown as a removable filter chip. Introduced by the practitioner-filter rollout earlier the same day. ([why](WORK_LOG.md))
  - **2026-09-02** update — the link carries the practitioner's *name*, not their id, because that is what Billing's filter matches on. Two doctors sharing a display name will therefore open each other's invoices; the id-based alternative is recorded in the WORK_LOG entry.
- **2026-09-02** · `frontend` · Ishmita (AI-assisted) — On Revenue by Provider the **Billed** card read `12008` and **Outstanding** read `0`, with no thousands separator and no currency, beside a correctly formatted `12,008 MXN`. Both now read as money. The page had been deciding which cards were money from a fixed list that was not updated when those two cards were added. ([why](WORK_LOG.md))

### 2026-09-02 · The Vaccines table on Treatment Plan Templates reaches every site

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend · **Branch:** `dev`
**Related:** [adr-049-vaccines-in-treatment-plan-templates](docs/adr/adr-049-vaccines-in-treatment-plan-templates.md) · [WORK_LOG 2026-09-02](WORK_LOG.md)

#### Fixed

- **2026-09-02** · `backend` · Anant Sharma (AI-assisted) — The **Vaccines** table on Treatment Plan
  Templates was missing on every site except the one it was built on, including `dev` and a second
  developer's machine after a clean pull. It is now created during `bench migrate` instead of
  depending only on the fixture import.
  ([why](docs/adr/adr-049-vaccines-in-treatment-plan-templates.md))

### 2026-09-02 · All reporting documentation moved under one folder

**Author(s):** Anant Sharma (AI-assisted) · **Repos:** backend (docs + one script) · **Branch:** `dev`
**Related:** [REPORTS_CHANGES_2026-09-01](docs/reports/archive/REPORTS_CHANGES_2026-09-01.md) · [docs/reports/](docs/reports/README.md)

#### Changed

- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — The nine reporting documents now live in
  **`docs/reports/`** instead of being split between `docs/` and `docs/audit/`. Every reference to
  them across the repository was repointed — 62 links were broken by the move and all 62 now
  resolve. ([index](docs/reports/README.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — Recorded the 2026-09-01 report changes:
  what shipped, the two decisions worth keeping, the QA data that was cancelled, and six open items.
  ([record](docs/reports/archive/REPORTS_CHANGES_2026-09-01.md))
- **2026-09-02** · `docs` · Anant Sharma (AI-assisted) — `REPORTS_API.md` and `REPORTS_GUIDE.md`
  corrected: both are `living` and both still described the pages as they were before 2026-09-01.
  The API contract now documents the four `by_hour` series and which Patient Flow KPIs the page
  renders versus what the endpoint returns; the guide reflects the Financial Report rename, the
  Outstanding card, and the Checkout rename.

#### Fixed

- **2026-09-02** · `backend` · Anant Sharma (AI-assisted) — `scripts/gen_doc_indexes.py` crashed
  under the system Python (3.9) because `Path.write_text(newline=...)` needs 3.10+. The
  documentation-index gate could therefore never be satisfied from a shell without the bench venv
  active, and the crash presented as a stale index rather than as an error.

### 2026-09-01 · Signing becomes two acts, and a note that was in the record but invisible

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend (docs) + frontend · **Branch:** `docs/encounter-flow-and-post-merge-sync` (backend) / `feature/encounter-progressive-disclosure` (frontend)
**Related:** [ADR-055](docs/adr/adr-055-sign-then-acknowledge-before-submit.md) · [ENCOUNTER_V3](docs/architecture/ENCOUNTER_V3.md) · [WORK_LOG — 2026-09-01](WORK_LOG.md)

#### Changed
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — **Sign & Close no longer files the encounter.** It saves your work and shows you the finished report; the encounter is filed only when you press "Sign & finish", which then takes you to the patient's chart. Back returns you to the note with nothing written. Same in both the classic and guided screens. ([why](docs/adr/adr-055-sign-then-acknowledge-before-submit.md))
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The report shown before signing says plainly that it is not on the chart yet, and does not offer to email or WhatsApp it to the parent. An unsigned record should not leave the clinic; you can still download or print it for yourself.
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The encounter header no longer says "Signed by" on a note nobody has signed. It shows who the visit was booked under, and who is logged in now, with a "covering" mark when they differ.
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Pressing "Review the note" now pauses the microphone before it starts processing, so nothing said mid-processing lands in a note already being written from the transcript. It does not restart on its own when you go back.

#### Fixed
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The microphone panel no longer appears before the family has agreed. Until then it was a locked control explaining that it was locked, sitting between you and the consent question.
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — **Review Details showed a sliver of one line instead of the text.** The text was in the record the whole time and there was no scrollbar to reach it. Same defect fixed in the vital-signs note field, where it had no symptom only because that box is usually empty.
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Closing the report after signing returns to the encounter instead of jumping to the patient's chart, and the back arrow in the header now does something — it had no handler at all.
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — The processing screen for Fill Encounter now shows the pass completing, instead of disappearing part-ticked.

#### Added
- **2026-09-01** · `frontend` · Sarvesh-SocialAngel (AI-assisted) — Both processing screens name every stage of work that actually runs: the note check after validation, and the considerations pass that used to run with nothing on screen to show for it. Restyled with a live progress sweep, and every animation switches off for anyone who has asked their system to reduce motion.
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — [ADR-055](docs/adr/adr-055-sign-then-acknowledge-before-submit.md) records why the report itself is the gate rather than a confirmation dialog, and names the alternative that was proposed and rejected.

### 2026-09-01 · Documents brought in line with the merge

**Author(s):** Sarvesh-SocialAngel (AI-assisted) · **Repos:** backend (documents only) · **Branch:** `dev`
**Related:** [WORK_LOG — 2026-09-01](WORK_LOG.md) · [FLOWS_ENCOUNTER](docs/flows/FLOWS_ENCOUNTER.md)

#### Added
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — A short readable document for the encounter flow: what a doctor does, in order, with one story and one worked example per step. ([flows/FLOWS_ENCOUNTER.md](docs/flows/FLOWS_ENCOUNTER.md))

#### Security
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The HIPAA and SOC 2 readiness assessment said no patient data is kept in browser storage. That is true of the patient portal and false of the clinic app, which keeps the whole draft consultation note there today. Corrected, and pointed at the gap register entry that had it right all along. ([security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md](docs/security/REQUIREMENTS_FOR_HIPAA_AND_SOC2.md))

#### Changed
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The encounter design document listed three items as open that had shipped the same day it was written, including the eval harness and the "said but not written" cards. Corrected, with a table of what closed them. ([architecture/ENCOUNTER_V3.md](docs/architecture/ENCOUNTER_V3.md))
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The step-navigation requirement said "Nothing implemented" a day after it shipped. It now records that two rules were built as asked and the third was answered a better way: a note that already has text is never regenerated, so going back never needed blocking. ([prompts/2026-08-31-encounter-step-navigation.md](docs/_archive/prompts/2026-08-31-encounter-step-navigation.md))
- **2026-09-01** · `docs` · Sarvesh-SocialAngel (AI-assisted) — The Step 1 plan now says plainly that V1's browser-stored clinical draft is still present on `dev`. The commit removing it is written but not merged, and an unqualified "fixed" would retire a compliance item no deployment has. ([architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md](docs/architecture/ENCOUNTER_V3_STEP1_IMPLEMENTATION_PLAN.md))


## Revision history

| Version | Date | Author | Change |
|---|---|---|---|
| 9.41 | 2026-10-01 | Divyanshu (AI-assisted) | New group: Checkout lists every bill still owing (frontend) |
| 9.40 | 2026-10-01 | Divyanshu (AI-assisted) | New group: the billing cart runs as the clerk (ADR-122) |
| 9.39 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-refund-preview-from-server`: entries and rows from both sides kept; version numbers below may overlap |
| 9.36 | 2026-10-01 | Divyanshu (AI-assisted) | New group: the Refund dialog shows the amount the server will pay (ADR-121) |
| 9.38 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-rounding-residue`: entries and rows from both sides kept; version numbers below may overlap |
| 9.35 | 2026-10-01 | Divyanshu (AI-assisted) | New group: a rounding residue is neither a debt nor a waiver (ADR-119) |
| 9.37 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/billing-concurrent-money-moves`: entries and rows from both sides kept; version numbers below may overlap |
| 9.34 | 2026-10-01 | Divyanshu (AI-assisted) | New group: two refunds or payments at once on one bill (ADR-118) |
| 9.36 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `fix/reschedule-partly-paid-balance`: entries and rows from both sides kept; version numbers below may overlap |
| 9.33 | 2026-10-01 | Divyanshu (AI-assisted) | New group: a reschedule or cancel of a bill that is not fully paid no longer bills twice (ADR-117) |
| 9.35 | 2026-10-01 | Sarvesh-SocialAngel (AI-assisted) | Renumbered from 117 to 120: open billing PRs #482/#483 also took that number, and no branch uses 120 (ADR-042: the unmerged side moves) |
| 9.31 | 2026-10-01 | Divyanshu (AI-assisted) | Refunds today counts cash paid out; invoice preview Visit resolves a reschedule's visit (ADR-116); merged `dev` |
| 9.29 | 2026-10-01 | Divyanshu (AI-assisted) | Merged `dev` into `feat/appointment-refund-everything`: every dated entry from both sides kept; revision rows from both sides kept, so version numbers below overlap
| 9.28 | 2026-09-30 | Divyanshu (AI-assisted) | Unbilled appointments show the tax-inclusive amount |
| 9.27 | 2026-09-30 | Divyanshu (AI-assisted) | Appointments row shows the billed total |
| 9.26 | 2026-09-30 | Divyanshu (AI-assisted) | One refund for a cancelled appointment, across every invoice a reschedule spread its money over |
| 9.25 | 2026-09-30 | Divyanshu (AI-assisted) | Cancel after a dearer pay-later reschedule closes the extra invoice and allows the refund |
| 9.24 | 2026-09-30 | Divyanshu (AI-assisted) | Appointment summary nets a refund's waiver too |
| 9.23 | 2026-09-30 | Divyanshu (AI-assisted) | Refund dialog splits cash from waiver; one payment method on every screen |
| 9.22 | 2026-09-30 | Divyanshu (AI-assisted) | Payment method on replacement invoices; Reverse waiver instead of Refund |
| 9.21 | 2026-09-30 | Divyanshu (AI-assisted) | Waiver write-off for front desk; deadlock no longer hides the real error |
| 9.20 | 2026-09-30 | Divyanshu (AI-assisted) | Refunds go back through the tender the money came in by |
| 9.19 | 2026-09-30 | Divyanshu (AI-assisted) | New group: only front desk and admin move money; reassign settles the fee |
| 9.18 | 2026-09-30 | Divyanshu (AI-assisted) | New group: reschedule and cancel touch only the appointment's own invoice line |
| 9.18 | 2026-09-30 | Satyakam (AI-assisted) | Merged `dev` (#471, #472, #473, #475) into `feat/narzim-gpt-experience`: every dated entry from both sides kept in full; version numbers below overlap because both branches bumped independently |
| 9.17 | 2026-09-30 | Satyakam (AI-assisted) | New group: the gaps found in review |
| 9.16 | 2026-09-30 | Satyakam (AI-assisted) | New group: follow-up suggestions read as the clinician's own request |
| 9.15 | 2026-09-30 | Satyakam (AI-assisted) | New group: Narzim GPT task lists, recent visits, dictation cue, template type help (frontend) |
| 9.14 | 2026-09-30 | Satyakam (AI-assisted) | New group: Narzim GPT start screen (frontend) |
| 9.17 | 2026-09-30 | Divyanshu (AI-assisted) | Partial refund rows explain why Refund is unavailable |
| 9.16 | 2026-09-30 | Divyanshu (AI-assisted) | New group: full payment in one go; refunds show and carry the exact discount; one refund dialog |
| 9.15 | 2026-09-30 | Anant Sharma (AI-assisted) | Reports v3 ADRs renumbered a second time, 103/104/105 → 111/112/113: `dev` merged its own 103–110 while this branch was in review. Per ADR-042 the unmerged side moves; never merged under the old numbers, and every citation updated in both repos. This log's own Reports v3 entries updated; `dev`'s ADR-103/104 references left alone, since those are different decisions |
| 9.13 | 2026-09-30 | Satyakam (AI-assisted) | Merged `dev` (#467, #469, #470) into `feat/narzim-gpt-experience`: every dated entry from both sides kept in full; version numbers below overlap because both branches bumped independently |
| 9.12 | 2026-09-30 | Satyakam (AI-assisted) | ADRs 103–108 of this branch renumbered to 105–110: `dev` merged its own adr-103 (patient history) and adr-104 (Rx print Canvas) first; per ADR-042 the unmerged side moves. Never merged under the old numbers; every citation in this log updated |
| 9.11 | 2026-09-30 | Satyakam (AI-assisted) | New group: a failed reply leaves no duplicate or orphan question |
| 9.10 | 2026-09-30 | Satyakam (AI-assisted) | New group: answers agree with the record |
| 9.9 | 2026-09-30 | Satyakam (AI-assisted) | New group: no citations on record questions; follow-up questions after every answer |
| 9.8 | 2026-09-30 | Satyakam (AI-assisted) | New group: a document from a template is filled from the chart |
| 9.7 | 2026-09-30 | Satyakam (AI-assisted) | Medication answers report orders as well as prescriptions |
| 9.6 | 2026-09-30 | Satyakam (AI-assisted) | New group: Narzim GPT medications on the linked visit, attached templates, rename and favourites |
| 9.5 | 2026-09-30 | Satyakam (AI-assisted) | New group: Live dictation in the Narzim GPT composers |
| 9.4 | 2026-09-30 | Satyakam (AI-assisted) | New group: Template studio: drafts, delete, instant examples, printed labels |
| 9.3 | 2026-09-30 | Satyakam (AI-assisted) | New group: Narzim GPT answers a question about the chart in front of you |
| 9.9 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Update: frontend implementation done — Advice + attached Canvas now render in both Rx print surfaces |
| 9.8 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | New group: ADR-104 recorded (Rx print Canvas rendering approach) |
| 9.7 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased feature/v9-advice-connect onto dev (post #469 merge): every dated group/entry from both sides kept in full, newest first |
| 9.6 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased feature/v9-service-request-active-status onto dev (4/4): ADR-098 renumbered to 103 (098 was already claimed for billing) |
| 9.5 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased feature/v9-service-request-active-status onto dev (3/4) |
| 9.4 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased feature/v9-service-request-active-status onto dev (2/4) |
| 9.3 | 2026-09-30 | Sarvesh-SocialAngel (AI-assisted) | Rebased feature/v9-service-request-active-status onto dev (1/4): every dated group/entry kept in full |
| 9.2 | 2026-09-29 | Divyanshu (AI-assisted) | New group: Medications tab shows submitted encounters only (backend) |
| 9.1 | 2026-09-29 | Divyanshu (AI-assisted) | Moved the uncommitted billing work (from `docs/agentic-dev-restructure`) onto `dev`: every dated entry from both sides kept in full, newest first; the billing entries' ADR citations renumbered 095-099 -> 098-102 (dev had merged Encounter Canvas ADRs 095-097). Version numbers below overlap because both branches bumped independently |
| 8.4 | 2026-09-29 | Divyanshu (AI-assisted) | New group: Refunded totals fixed; multi-select pills; search minimum length (frontend) |
| 8.3 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the invoice-totals entry: the fix now actually reaches the browser, a second total bug fixed, row-visibility fixed |
| 8.2 | 2026-09-29 | Divyanshu (AI-assisted) | New group: invoice list totals fixed; Unpaid pill restored (backend + frontend) |
| 8.1 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the Checkout entry: badge count fixed, Unpaid pill removed; new Fixed entry: payment row Collect-now gating |
| 8.0 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the Checkout entry: one row per patient; amended the invoice-sheet entry: Amount field restyled |
| 7.9 | 2026-09-29 | Divyanshu (AI-assisted) | New group: Checkout unbilled-only; Unpaid/Partly-Paid filter fixed (frontend) |
| 7.8 | 2026-09-29 | Divyanshu (AI-assisted) | New group: Checkout default selection, no Outstanding list, no Paid badge (frontend) |
| 7.7 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the invoice-sheet entry: Ctrl+Enter shortcut removed |
| 7.6 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the invoice-sheet entry: per-line discount amount, footer rebuilt, drawer widened |
| 7.5 | 2026-09-29 | Divyanshu (AI-assisted) | New group: New sales invoice sheet wording fixes (frontend) |
| 7.4 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the print entry: three fixes from a real printed invoice |
| 7.3 | 2026-09-29 | Divyanshu (AI-assisted) | New group: printed invoice matches the design (backend + frontend) |
| 7.2 | 2026-09-29 | Divyanshu (AI-assisted) | New group: Checkout walk-in + outstanding invoices; invoice view redesigned (frontend) |
| 7.1 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the dashboard KPI entry (Payment Entry receipts, permissions) and the 7-column entry (chip width) |
| 7.0 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the item-summary and 7-column entries: repeats collapse, overflow translated, Items cell wraps |
| 6.9 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the 7-column entry: Status pill alignment |
| 6.8 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the 7-column entry: Collect restored on the row |
| 6.7 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the 7-column entry: row actions matched to the mock |
| 6.6 | 2026-09-29 | Divyanshu (AI-assisted) | Amended the 7-column entry: MRN removed entirely, Billing header restyled to the mock |
| 6.5 | 2026-09-29 | Divyanshu (AI-assisted) | New group: 2026-09-29 Invoices table collapsed to 7 columns (frontend) |
| 6.4 | 2026-09-29 | Divyanshu (AI-assisted) | New group: 2026-09-29 Invoice list rows carry an item summary (backend) |
| 6.3 | 2026-09-29 | Divyanshu (AI-assisted) | New group: 2026-09-29 Dashboard revenue KPIs are now clinic-wide (backend) |
| 6.2 | 2026-09-28 | Divyanshu (AI-assisted) | New group: 2026-09-28 Billing screen restyle + Checkout tab (frontend) |

| 6.9 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Update: cancel fix also covers On-Hold orders + a stale cancelled-Service-Request status |
| 6.8 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Three encounter gaps fixed: cancel-with-orders, order status in Patient History, Advice/Canvas read permission |
| 6.7 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Order status actions match core Desk's menu |
| 6.6 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | list_active_orders added for v9 "Active now" |
| 6.5 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Fix: Service Request status now resolved and settable, same as Medication Request |
| 6.5 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | v9 Advice connected: Copy to Rx Pad fills it from the SOAP, Ask AI reads/changes it, Canvas save+reopen |
| 6.4 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | v9: separate AI-proposed order cards removed; Copy to Rx Pad extracts full order details from the SOAP |
| 6.3 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | Rebased PR #460 (`feature/encounter-canvas`) onto `dev`: every dated group/entry from both sides kept in full, newest first; doc and endpoint indexes regenerated |
| 6.2 | 2026-09-29 | Sarvesh-SocialAngel (AI-assisted) | v9 Scribe group: editable SOAP, AI-proposed Assessment/Plan and orders, Copy to Rx Pad from the SOAP |
| 4.95 | 2026-09-28 | Divyanshu (AI-assisted) | Rebased PR #458 (`docs/agentic-dev-restructure`) onto `dev`: entries from both kept in full, regenerated the doc and endpoint indexes afterward |
| 4.94 | 2026-09-25 | Satyakam (AI-assisted) | Agentic documentation restructure recorded |
| 4.93 | 2026-09-25 | Satyakam (AI-assisted) | Links repointed: session transcripts and screen audits moved to `docs/_archive/` |
| 4.92 | 2026-09-25 | Satyakam (AI-assisted) | Removed two duplicated `[Unreleased]` headings left by merges; rolled 2026-08 groups into `docs/changelog/` |
| 4.91 | 2026-09-24 | Anant Sharma (AI-assisted) | Note editor scrolling and centring corrected |
| 4.90 | 2026-09-24 | Anant Sharma (AI-assisted) | Unsaved note changes are confirmed before discarding |
| 4.89 | 2026-09-24 | Anant Sharma (AI-assisted) | Note editor opens as a centred modal |
| 4.88 | 2026-09-24 | Anant Sharma (AI-assisted) | Rename no longer lets the extension be edited away |
| 4.87 | 2026-09-24 | Anant Sharma (AI-assisted) | Type filter on Documents |
| 4.86 | 2026-09-24 | Anant Sharma (AI-assisted) | New menu reads Note / File / Folder |
| 4.85 | 2026-09-24 | Anant Sharma (AI-assisted) | Folders starrable from the folder card and menu |
| 4.84 | 2026-09-24 | Anant Sharma (AI-assisted) | Favourites tab, star control, per-user favourites |
| 4.83 | 2026-09-24 | Anant Sharma (AI-assisted) | Trash previews restored; a deleted document no longer shows another's contents |
| 4.82 | 2026-09-24 | Anant Sharma (AI-assisted) | Unloadable images fall back to the standard placeholder |
| 4.81 | 2026-09-24 | Anant Sharma (AI-assisted) | Drive note tiles show their text; excerpt truncated server-side |
| 4.80 | 2026-09-24 | Anant Sharma (AI-assisted) | Narzim Drive PDF thumbnails restored without relaxing X-Frame-Options |
| 4.78 | 2026-09-23 | Nishant | NOM-024-SSA3-2012 cited across living documents |
| 4.77 | 2026-09-23 | Nishant | Compliance plan and ADR-007: stale facts corrected |
| 4.76 | 2026-09-23 | Nishant | Update to 4.75: the platform README follows the destination-only rule |
| 4.75 | 2026-09-23 | Nishant | Platform V2: architecture documents describe only the target |
| 4.74 | 2026-09-23 | Nishant | Platform V2: the transition runbook, made visual and completed |
| 4.73 | 2026-09-23 | Nishant | Platform V2: files, EFS now and S3 later |
| 4.72 | 2026-09-23 | Nishant | Platform V2: the transition runbook |
| 4.71 | 2026-09-23 | Nishant | Platform V2: browser telemetry and per-cell providers |
| 4.70 | 2026-09-23 | Nishant | Platform V2: telemetry stays in the cell |
| 4.69 | 2026-09-23 | Nishant | Platform V2: Terraform and the delivery pipeline |
| 4.68 | 2026-09-23 | Nishant | Platform V2: contract invariant and post-transition frontend |
| 4.62 | 2026-09-21 | Divyanshu (AI-assisted) | Financial-report verification and the seven fixes recorded (G-04, G-57 – G-62). Resolved a `git stash pop` conflict (`Updated upstream`/`Stashed changes`, not a merge): dev's entries kept in full, this branch's two entries re-applied, and the ~21 Narzim entries dropped from the working tree because they are already committed on `feature/narzim-gpt` and would have duplicated on its merge. Numbered 4.62 rather than 4.45 so it cannot collide with that branch's committed 4.45–4.61 |
| 4.61 | 2026-09-18 | Divyanshu (AI-assisted) | `get_suggestions` — role-aware localised starter cards; PR #493's backend complete |
| 4.60 | 2026-09-18 | Divyanshu (AI-assisted) | AI Source Cache: external fetches stored for reproducibility, 30-day retention with its purge (ADR-079) |
| 4.59 | 2026-09-18 | Divyanshu (AI-assisted) | PHI-1 enforced at both LLM dispatchers, the Deepgram token mint and the AI Settings save (ADR-078) |
| 4.58 | 2026-09-18 | Divyanshu (AI-assisted) | Clinical Web enabled under ADR-077; pasted addresses screened for patient identifiers |
| 4.57 | 2026-09-18 | Divyanshu (AI-assisted) | Streaming replies gain retrieval and citations; prompt assembly deduplicated |
| 4.56 | 2026-09-18 | Divyanshu (AI-assisted) | PubMed search and pasted-URL fetch — built behind gates that refuse until a profile names the provider |
| 4.22 | 2026-09-14 | Divyanshu (AI-assisted) | Resolved a `git stash pop` conflict (marked `Updated upstream`/`Stashed changes`, not a branch merge) between Anant Sharma's `feat/ui-fixes` entries and this branch's ToDo/notification entry — both kept, nothing dropped |
| 3.50 | 2026-09-02 | Anant Sharma (AI-assisted) | Per-report reference under docs/reports/; practitioner filter across every report |
| 3.47 | 2026-09-02 | Anant Sharma (AI-assisted) | Reporting docs consolidated under docs/reports/ (62 links repointed); 2026-09-01 report changes recorded; the two living reports docs corrected; gen_doc_indexes.py Python 3.9 crash fixed |
| 3.11 | 2026-08-26 | Divyanshu (AI-assisted) | A test printed twice on one report keeps both readings |
| 1.7 | 2026-08-21 | Ashutosh (AI-assisted) | Notification feed excludes Email Queue alerts; tab/badge counts unified |
| 1.4 | 2026-08-20 | Sarvesh (AI-assisted) | Frontend constitution consolidated; FE-1…FE-14 hard rules |
| 1.3 | 2026-08-20 | Sarvesh (AI-assisted) | Frontend parity; script defects; four-approaches rule |
| 1.2 | 2026-08-20 | Sarvesh (AI-assisted) | Version-bump gate entries; corrected attribution entry |
| 1.1 | 2026-08-20 | Sarvesh (AI-assisted) | Every entry now carries date · repo · author; added per-release metadata and verification lines |
| 1.0 | 2026-08-20 | Sarvesh (AI-assisted) | Initial changelog; backfilled with the 2026-08-20 work |
