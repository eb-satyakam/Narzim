#!/bin/bash
# Install helper for the install/uninstall CI test.
# Mirrors the upstream Healthcare CI install pattern.
# Called from .github/workflows/install-uninstall.yml.

set -ex

cd ~ || exit

sudo apt update
sudo apt remove -y mysql-server mysql-client || true
sudo apt install -y libcups2-dev redis-server mariadb-client

pip install frappe-bench

# Pin to v16 line — see ADR-004.
FRAPPE_BRANCH="version-16"

git clone https://github.com/frappe/frappe --branch "${FRAPPE_BRANCH}" --depth 1
bench init --skip-assets --frappe-path ~/frappe --python "$(which python)" frappe-bench

# Site scaffolding
mkdir -p ~/frappe-bench/sites/test_site
cp -r "${GITHUB_WORKSPACE}/.github/helper/site_config.json" ~/frappe-bench/sites/test_site/

# Charset for Frappe (utf8mb4). Do NOT pre-create the database or user
# here — `bench reinstall` creates both via root credentials below, and a
# pre-existing row at 'localhost' will collide with bench's '%' host CREATE.
mariadb --host 127.0.0.1 --port 3306 -u root -proot -e "SET GLOBAL character_set_server = 'utf8mb4'"
mariadb --host 127.0.0.1 --port 3306 -u root -proot -e "SET GLOBAL collation_server = 'utf8mb4_unicode_ci'"

cd ~/frappe-bench || exit

# Disable processes we don't need for an install/uninstall test
sed -i 's/watch:/# watch:/g' Procfile
sed -i 's/schedule:/# schedule:/g' Procfile
sed -i 's/socketio:/# socketio:/g' Procfile
sed -i 's/redis_socketio:/# redis_socketio:/g' Procfile

# Fetch required dependencies — versions pinned per ADR-004 (Frappe v16).
bench get-app payments --branch "${FRAPPE_BRANCH}"
bench get-app https://github.com/frappe/erpnext --branch "${FRAPPE_BRANCH}"
bench get-app https://github.com/frappe/healthcare --branch "${FRAPPE_BRANCH}"

# Get our app from the checked-out PR / branch
bench get-app remedisys_healthcare_ai "${GITHUB_WORKSPACE}"

# eb_frappe_jwt is a required_app of remedisys_healthcare_ai.
# It MUST be get-app'd (and therefore pip-installed into the venv) BEFORE
# bench start, so gunicorn workers can import it on their first request.
# Pass the token via EB_JWT_REPO_TOKEN env var from the workflow secret.
if [ -n "${EB_JWT_LOCAL_PATH:-}" ]; then
  bench get-app eb_frappe_jwt "${EB_JWT_LOCAL_PATH}"
elif [ -n "${EB_JWT_REPO_TOKEN:-}" ]; then
  bench get-app eb_frappe_jwt \
    "https://x-access-token:${EB_JWT_REPO_TOKEN}@github.com/eBasics-Services-P-Limited/eb_frappe_jwt"
else
  echo "ERROR: eb_frappe_jwt required. Set EB_JWT_REPO_TOKEN (private) or EB_JWT_LOCAL_PATH." >&2
  exit 1
fi

bench setup requirements --dev
CI=Yes bench build --app frappe &

bench start &> bench_run_logs.txt &

# Provision the site. `install_apps` in site_config.json drives the initial
# install order (payments, erpnext, healthcare) — do not repeat it here, or
# `bench install-app` will fail on the second call with "already installed".
bench --site test_site reinstall --yes
